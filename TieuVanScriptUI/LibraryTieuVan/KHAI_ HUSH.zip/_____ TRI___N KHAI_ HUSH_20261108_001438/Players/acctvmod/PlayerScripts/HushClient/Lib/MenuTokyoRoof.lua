-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTokyoRoof

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {}
v_u_4.__index = v_u_4
v_u_4.FOLDER = "LobbyRoof"
v_u_4.FX = {
	["grade"] = "LobbyRoofGrade",
	["bloom"] = "LobbyRoofBloom",
	["dof"] = "LobbyRoofDoF"
}
v_u_4.OVERLAY = "roof"
function v_u_4.template(p5) -- name: template
	-- upvalues: (copy) v_u_2
	local v6 = v_u_2
	for _, v7 in p5.TEMPLATE_PATH do
		if v6 then
			v6 = v6:FindFirstChild(v7)
		else
			v6 = nil
		end
	end
	return v6
end
function v_u_4.countParts(p8) -- name: countParts
	local v9 = 0
	for _, v10 in {
		"Roof",
		"Signs",
		"Sky",
		"Kit"
	} do
		local v11 = p8:FindFirstChild(v10)
		if not v11 then
			continue
		end
		v9 = v9 + #v11:GetChildren()
	end
	return v9
end
local function v_u_29(p12, p13, p14) -- name: cull
	local v15 = 0
	local v16 = {}
	local v17 = {}
	for _, v18 in {
		"Roof",
		"Signs",
		"Sky",
		"Kit"
	} do
		local v19 = p12:FindFirstChild(v18)
		if not v19 then
			continue
		end
		for _, v20 in v19:GetChildren() do
			if p13.keeps(v20:GetAttribute("Detail"), p14) then
				continue
			end
			v20:Destroy()
			v15 = v15 + 1
		end
	end
	local v21 = p12:FindFirstChild("Lights")
	if v21 then
		for _, v22 in v21:GetChildren() do
			local v23 = v22:GetAttribute("Rank")
			if type(v23) ~= "number" then
				continue
			end
			table.insert(v16, v23)
			v17[v23] = v22
		end
		local v24 = p13.pickLights(v16, p14)
		for v25, v26 in v17 do
			if v24[v25] then
				continue
			end
			v26:Destroy()
			v15 = v15 + 1
		end
	end
	local v27 = 0
	if v21 then
		for _, v28 in v21:GetChildren() do
			if not v28:FindFirstChildOfClass("PointLight") then
				continue
			end
			v27 = v27 + 1
		end
	end
	return v15, v27
end
local function v_u_36(p30) -- name: useLowMaps
	local v31 = 0
	for _, v32 in p30:GetDescendants() do
		if not v32:IsA("SurfaceAppearance") then
			continue
		end
		for v33, v34 in v32:GetAttributes() do
			if type(v34) ~= "string" or (string.sub(v33, 1, 2) ~= "Lo" or v34 == "") then
				continue
			end
			local v35 = string.sub(v33, 3)
			if v35 == "EmissiveMask" then
				v32.EmissiveMaskContent = Content.fromUri(v34)
				v31 = v31 + 1
			else
				if v35 ~= "ColorMap" and (v35 ~= "NormalMap" and (v35 ~= "RoughnessMap" and v35 ~= "MetalnessMap")) then
					continue
				end
				v32[v35] = v34
				v31 = v31 + 1
			end
		end
	end
	return v31
end
function v_u_4.new(p_u_37) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_36
	local v_u_38 = p_u_37.cctx.shared.LobbyRoofPlan
	local v39 = v_u_4.template(v_u_38)
	local v40 = v_u_38.mountDecision
	local v_u_41 = v_u_38.FLAG
	local v42, v43 = pcall(function()
		-- upvalues: (copy) p_u_37, (copy) v_u_41
		return p_u_37.cctx.config.flag(v_u_41)
	end)
	local v44
	if v42 then
		v44 = v43 == true
	else
		v44 = nil
	end
	local v45
	if v39 then
		v45 = v_u_4.countParts(v39)
	else
		v45 = nil
	end
	local v46, v47 = v40(v44, v45)
	if not (v46 and v39) then
		return nil, v47
	end
	local v_u_48 = p_u_37.cctx.controllers.Atmosphere
	local v_u_49 = 3
	if v_u_48 and v_u_48.quality then
		local v50 = v_u_48.quality
		local v51, v52 = pcall(v50)
		if v51 then
			v_u_49 = v_u_38.qualityOf(v52)
		end
	end
	local v53 = v_u_4
	local v_u_54 = setmetatable({}, v53)
	v_u_54.scene = p_u_37
	v_u_54.P = v_u_38
	v_u_54.quality = v_u_49
	v_u_54.atmo = v_u_48
	local v_u_55 = v39:Clone()
	v_u_55.Name = v_u_4.FOLDER
	local v56, v57 = v_u_29(v_u_55, v_u_38, v_u_49)
	v_u_54.culled = v56
	v_u_54.lowMaps = v_u_49 > 2 and 0 or v_u_36(v_u_55)
	v_u_54.lights = v57
	v_u_55.Parent = p_u_37.root
	local v58 = CFrame.new
	local v59 = p_u_37.origin
	local v60 = v_u_38.ORIGIN_LIFT
	v_u_55:PivotTo(v58(v59 + Vector3.new(0, v60, 0)))
	v_u_54.model = v_u_55
	v_u_54.sky = v_u_55:FindFirstChild("Sky")
	v_u_54.skyShown = true
	v_u_54.camAt = 0
	v_u_54.focusAt = 0
	v_u_54.fx = {}
	v_u_54.reduced = false
	local v67, v68 = pcall(function()
		-- upvalues: (copy) p_u_37, (copy) v_u_55, (copy) v_u_48, (copy) v_u_38, (ref) v_u_49
		return p_u_37.cctx.lib.LobbyNeon.new(v_u_55, {
			["plan"] = p_u_37.cctx.shared.LobbyNeonPlan,
			["flashingOff"] = function() -- name: flashingOff
				-- upvalues: (ref) v_u_48
				local v61
				if v_u_48 == nil or v_u_48.flashingOff == nil then
					v61 = false
				else
					v61 = v_u_48.flashingOff() == true
				end
				return v61
			end,
			["flickerOn"] = function() -- name: flickerOn
				-- upvalues: (ref) p_u_37, (ref) v_u_38
				local v_u_62 = p_u_37
				local v_u_63 = v_u_38.FLAG_FLICKER
				local v64, v65 = pcall(function()
					-- upvalues: (copy) v_u_62, (copy) v_u_63
					return v_u_62.cctx.config.flag(v_u_63)
				end)
				local v66
				if v64 then
					v66 = v65 == true
				else
					v66 = nil
				end
				return v66 ~= false
			end,
			["every"] = v_u_49 <= 2 and 2 or 1
		})
	end)
	if v67 then
		v_u_54.neon = v68
	else
		warn("[MenuTokyoRoof] flicker:", v68)
	end
	local v69, v70 = pcall(function()
		-- upvalues: (copy) v_u_54
		v_u_54:_fx()
	end)
	if not v69 then
		warn("[MenuTokyoRoof] effects:", v70)
	end
	return v_u_54, "roof"
end
function v_u_4._reducedNow(p71) -- name: _reducedNow
	local v72 = p71.atmo
	if not (v72 and v72.flashingOff) then
		return false
	end
	local v73 = v72.flashingOff
	local v74, v75 = pcall(v73)
	if v74 then
		v74 = v75 == true
	end
	return v74
end
function v_u_4._fx(p76) -- name: _fx
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v77 = p76.P
	p76.reduced = p76:_reducedNow()
	local v78 = v77.fxSpec(p76.quality, p76.reduced)
	if v78.grade then
		local v79 = v_u_4.FX.grade
		local v80 = v_u_1:FindFirstChild(v79)
		if v80 then
			v80:Destroy()
		end
		local v81 = Instance.new("ColorCorrectionEffect")
		v81.Name = v79
		v81.Parent = v_u_1
		p76.fx[v79] = v81
		v81.Saturation = v78.grade.Saturation
		v81.Contrast = v78.grade.Contrast
		v81.Brightness = v78.grade.Brightness
		local v82 = v78.grade.TintColor
		v81.TintColor = Color3.new(v82[1], v82[2], v82[3])
	end
	if v78.bloom then
		local v83 = v_u_4.FX.bloom
		local v84 = v_u_1:FindFirstChild(v83)
		if v84 then
			v84:Destroy()
		end
		local v85 = Instance.new("BloomEffect")
		v85.Name = v83
		v85.Parent = v_u_1
		p76.fx[v83] = v85
		v85.Intensity = v78.bloom.Intensity
		v85.Size = v78.bloom.Size
		v85.Threshold = v78.bloom.Threshold
	end
	if v78.dof then
		local v86 = v_u_4.FX.dof
		local v87 = v_u_1:FindFirstChild(v86)
		if v87 then
			v87:Destroy()
		end
		local v88 = Instance.new("DepthOfFieldEffect")
		v88.Name = v86
		v88.Parent = v_u_1
		p76.fx[v86] = v88
		v88.FarIntensity = v78.dof.FarIntensity
		v88.NearIntensity = v78.dof.NearIntensity
		v88.FocusDistance = 40
		v88.InFocusRadius = 20
	end
	local v89 = p76.atmo
	if v89 and (v89.setOverlay and v78.haze) then
		local v90 = v89.setOverlay
		local v91 = v_u_4.OVERLAY
		local v92 = {
			["Color"] = nil,
			["Decay"] = nil,
			["Density"] = nil,
			["Haze"] = nil,
			["weight"] = 1
		}
		local v93 = v78.haze.Color
		v92.Color = Color3.new(v93[1], v93[2], v93[3])
		local v94 = v78.haze.Decay
		v92.Decay = Color3.new(v94[1], v94[2], v94[3])
		v92.Density = v78.haze.Density
		v92.Haze = v78.haze.Haze
		pcall(v90, v91, v92, 1.5)
		p76.overlay = true
	end
end
function v_u_4._followFocus(p95) -- name: _followFocus
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v96 = p95.fx[v_u_4.FX.dof]
	if v96 then
		local v97 = v_u_1:FindFirstChild("DepthOfField")
		if v97 and v97:IsA("DepthOfFieldEffect") then
			v96.FocusDistance = v97.FocusDistance
			v96.InFocusRadius = v97.InFocusRadius
			v96.Enabled = v97.Enabled
		end
	end
	local v98 = p95:_reducedNow()
	if v98 ~= p95.reduced then
		p95.reduced = v98
		local v99 = p95.fx[v_u_4.FX.bloom]
		if v99 then
			v99.Intensity = p95.P.fxSpec(p95.quality, v98).bloom.Intensity
		end
	end
end
function v_u_4._camera(p100) -- name: _camera
	-- upvalues: (copy) v_u_3
	local v101 = v_u_3.CurrentCamera
	if v101 and p100.sky then
		local v102 = v101.CFrame.Position.X - p100.scene.origin.X
		local v103 = p100.P.skyVisible(p100.skyShown, v102)
		if v103 ~= p100.skyShown then
			p100.skyShown = v103
			local v104 = p100.sky
			local v105
			if v103 then
				v105 = p100.model
			else
				v105 = nil
			end
			v104.Parent = v105
		end
	end
end
function v_u_4.step(p106, p107) -- name: step
	if p106.model then
		if p106.neon then
			p106.neon:step(p107)
		end
		p106.camAt = p106.camAt - p107
		if p106.camAt <= 0 then
			p106.camAt = 0.25
			local v108 = p106._camera
			pcall(v108, p106)
		end
		p106.focusAt = p106.focusAt - p107
		if p106.focusAt <= 0 then
			p106.focusAt = 0.25
			local v109 = p106._followFocus
			pcall(v109, p106)
		end
	end
end
function v_u_4.state(p110) -- name: state
	local v111 = 0
	if p110.model then
		for _, v112 in p110.model:GetDescendants() do
			if not v112:IsA("BasePart") then
				continue
			end
			v111 = v111 + 1
		end
	end
	local v113 = {}
	for v114 in p110.fx do
		table.insert(v113, v114)
	end
	table.sort(v113)
	local v115 = {
		["quality"] = p110.quality,
		["parts"] = v111,
		["culled"] = p110.culled,
		["lowMaps"] = p110.lowMaps,
		["lights"] = p110.lights,
		["skyShown"] = p110.skyShown,
		["fx"] = v113
	}
	local v116
	if p110.neon then
		v116 = p110.neon:state()
	else
		v116 = nil
	end
	v115.neon = v116
	v115.overlay = p110.overlay == true
	return v115
end
function v_u_4.destroy(p117) -- name: destroy
	-- upvalues: (copy) v_u_4
	if p117.neon then
		local v118 = p117.neon.destroy
		local v119 = p117.neon
		pcall(v118, v119)
		p117.neon = nil
	end
	for v120, v_u_121 in p117.fx do
		pcall(function()
			-- upvalues: (copy) v_u_121
			v_u_121:Destroy()
		end)
		p117.fx[v120] = nil
	end
	if p117.overlay and (p117.atmo and p117.atmo.setOverlay) then
		local v122 = p117.atmo.setOverlay
		local v123 = v_u_4.OVERLAY
		pcall(v122, v123, nil, 1)
		p117.overlay = false
	end
	if p117.sky and not p117.sky.Parent then
		p117.sky:Destroy()
	end
	p117.sky = nil
	if p117.model then
		p117.model:Destroy()
		p117.model = nil
	end
end
return v_u_4