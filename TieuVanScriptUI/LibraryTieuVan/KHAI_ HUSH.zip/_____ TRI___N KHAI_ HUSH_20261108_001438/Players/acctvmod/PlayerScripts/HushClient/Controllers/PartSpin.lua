-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / PartSpin

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {
	["name"] = "PartSpin",
	["order"] = 93,
	["TAG"] = "HushSpin",
	["TUNE"] = {
		["maxParts"] = 48,
		["range"] = 140,
		["maxDt"] = 0.1
	}
}
local v_u_6 = v_u_5.TUNE
function v_u_5.derive(p7, p8, p9, p10, p11) -- name: derive
	local v12 = p7.Rotation
	return v12:VectorToObjectSpace(p8), v12:VectorToObjectSpace((p9 - p10) * p11)
end
function v_u_5.advance(p13, p14, p15, p16) -- name: advance
	if p14.Magnitude < 1e-6 then
		return p13
	end
	local v17 = CFrame.fromAxisAngle(p14.Unit, p16)
	return (p13 * CFrame.new(p15) * v17 * CFrame.new(-p15)):Orthonormalize()
end
local v_u_18 = {}
local v_u_19 = 0
local v_u_20 = 0
local v_u_21 = nil
local function v_u_24(p22) -- name: frameShown
	while p22 ~= nil do
		if p22:IsA("GuiObject") then
			if not p22.Visible then
				return false
			end
		elseif p22:IsA("LayerCollector") then
			local v23 = p22.Enabled
			if v23 then
				v23 = p22:IsDescendantOf(game)
			end
			return v23
		end
		p22 = p22.Parent
	end
	return false
end
local function v_u_27(p25) -- name: viewportTick
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v26 = v_u_2.LocalPlayer
	if v26 == nil and true or v26:GetAttribute("PartSpin") ~= false then
		v_u_5.update(p25, nil, "viewport")
	end
end
local function v_u_32(p28, p29) -- name: setVp
	-- upvalues: (ref) v_u_20, (ref) v_u_21, (copy) v_u_3, (copy) v_u_27
	local v30 = p28.vf ~= nil
	p28.vf = p29
	local v31 = p29 ~= nil
	if v31 and not v30 then
		v_u_20 = v_u_20 + 1
	elseif v30 and not v31 then
		v_u_20 = v_u_20 - 1
	end
	if v_u_20 > 0 and v_u_21 == nil then
		v_u_21 = v_u_3.RenderStepped:Connect(v_u_27)
	elseif v_u_20 <= 0 and v_u_21 ~= nil then
		v_u_21:Disconnect()
		v_u_21 = nil
		v_u_20 = 0
	end
end
local function v_u_45(p_u_33) -- name: register
	-- upvalues: (copy) v_u_18, (ref) v_u_19, (copy) v_u_6, (copy) v_u_4, (copy) v_u_32, (ref) v_u_20, (ref) v_u_21, (copy) v_u_3, (copy) v_u_27
	if v_u_18[p_u_33] == nil and (v_u_19 < v_u_6.maxParts and p_u_33:IsA("BasePart")) then
		if p_u_33:IsDescendantOf(v_u_4) then
			return
		else
			local v34 = p_u_33:GetAttribute("SpinLocalAxis")
			local v35 = p_u_33:GetAttribute("SpinLocalPivot")
			local v36 = p_u_33:GetAttribute("SpinSize")
			local v37 = p_u_33:GetAttribute("SpinSpeed")
			if typeof(v34) == "Vector3" and (typeof(v35) == "Vector3" and type(v37) == "number") then
				if typeof(v36) == "Vector3" and (v36.X > 1e-6 and (v36.Y > 1e-6 and v36.Z > 1e-6)) then
					local v38 = v35.X * p_u_33.Size.X / v36.X
					local v39 = v35.Y * p_u_33.Size.Y / v36.Y
					local v40 = v35.Z * p_u_33.Size.Z / v36.Z
					v35 = Vector3.new(v38, v39, v40)
				end
				local v_u_41 = {
					["la"] = nil,
					["lp"] = nil,
					["speed"] = nil,
					["vf"] = nil,
					["conn"] = nil,
					["la"] = v34,
					["lp"] = v35,
					["speed"] = v37
				}
				v_u_18[p_u_33] = v_u_41
				v_u_19 = v_u_19 + 1
				v_u_32(v_u_41, p_u_33:FindFirstAncestorWhichIsA("ViewportFrame"))
				v_u_41.conn = p_u_33.AncestryChanged:Connect(function()
					-- upvalues: (ref) v_u_18, (copy) p_u_33, (copy) v_u_41, (ref) v_u_32
					if v_u_18[p_u_33] == v_u_41 then
						v_u_32(v_u_41, p_u_33:FindFirstAncestorWhichIsA("ViewportFrame"))
					end
				end)
				p_u_33.Destroying:Once(function()
					-- upvalues: (copy) p_u_33, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_3, (ref) v_u_27
					local v42 = p_u_33
					local v43 = v_u_18[v42]
					if v43 ~= nil then
						v_u_18[v42] = nil
						v_u_19 = v_u_19 - 1
						local v44 = v43.vf ~= nil
						v43.vf = nil
						if v44 then
							v_u_20 = v_u_20 - 1
						end
						if v_u_20 > 0 and v_u_21 == nil then
							v_u_21 = v_u_3.RenderStepped:Connect(v_u_27)
						elseif v_u_20 <= 0 and v_u_21 ~= nil then
							v_u_21:Disconnect()
							v_u_21 = nil
							v_u_20 = 0
						end
						if v43.conn then
							v43.conn:Disconnect()
							v43.conn = nil
						end
					end
				end)
			end
		end
	else
		return
	end
end
function v_u_5.rescan() -- name: rescan
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_45
	for _, v46 in v_u_1:GetTagged(v_u_5.TAG) do
		v_u_45(v46)
	end
end
function v_u_5.active() -- name: active
	-- upvalues: (ref) v_u_19
	return v_u_19
end
function v_u_5.viewportParts() -- name: viewportParts
	-- upvalues: (ref) v_u_20
	return v_u_20
end
function v_u_5.update(p47, p48, p49) -- name: update
	-- upvalues: (copy) v_u_6, (copy) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (copy) v_u_3, (copy) v_u_27, (copy) v_u_24, (copy) v_u_5
	local v50 = v_u_6.maxDt
	local v51 = math.clamp(p47, 0, v50)
	if v51 > 0 then
		local v52 = p49 ~= "viewport"
		local v53 = p49 ~= "world"
		if v52 then
			if not p48 then
				local v54 = workspace.CurrentCamera
				if v54 then
					p48 = v54.CFrame.Position
				else
					p48 = nil
				end
			end
		else
			p48 = nil
		end
		for v55, v56 in v_u_18 do
			if v55.Parent == nil then
				local v57 = v_u_18[v55]
				if v57 == nil then
					continue
				end
				v_u_18[v55] = nil
				v_u_19 = v_u_19 - 1
				local v58 = v57.vf ~= nil
				v57.vf = nil
				if v58 then
					v_u_20 = v_u_20 - 1
				end
				if v_u_20 > 0 and v_u_21 == nil then
					v_u_21 = v_u_3.RenderStepped:Connect(v_u_27)
				elseif v_u_20 <= 0 and v_u_21 ~= nil then
					v_u_21:Disconnect()
					v_u_21 = nil
					v_u_20 = 0
				end
				if not v57.conn then
					continue
				end
				v57.conn:Disconnect()
				v57.conn = nil
			elseif v56.vf == nil then
				if not v52 or (not v55:IsDescendantOf(workspace) or p48 ~= nil and (v55.Position - p48).Magnitude > v_u_6.range) then
					continue
				end
				local v59
				if v55.Anchored then
					v59 = nil
				else
					v59 = v55:FindFirstChildOfClass("Weld")
					if not v59 or v59.Part1 ~= v55 then
						v59 = nil
					end
				end
				if v59 then
					v59.C0 = v_u_5.advance(v59.C0, v56.la, v56.lp, v56.speed * v51)
				else
					v55.CFrame = v_u_5.advance(v55.CFrame, v56.la, v56.lp, v56.speed * v51)
				end
			else
				if not (v53 and v_u_24(v56.vf)) then
					continue
				end
				v55.CFrame = v_u_5.advance(v55.CFrame, v56.la, v56.lp, v56.speed * v51)
			end
		end
	end
end
local v_u_60 = false
function v_u_5.init(p61) -- name: init
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (ref) v_u_60, (copy) v_u_1, (copy) v_u_45
	p61.command("partspin.state", function()
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_2
		local v62 = v_u_5.active()
		local v63 = v_u_6.maxParts
		local v64 = v_u_2.LocalPlayer
		return ("part spin: %d parts turn (budget %d), switch %s"):format(v62, v63, (v64 == nil and true or v64:GetAttribute("PartSpin") ~= false) and "on" or "off")
	end)
	if not v_u_60 then
		v_u_60 = true
		v_u_1:GetInstanceAddedSignal(v_u_5.TAG):Connect(v_u_45)
		v_u_5.rescan()
	end
end
function v_u_5.step(p65) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (ref) v_u_21
	local v66 = v_u_2.LocalPlayer
	if v66 == nil and true or v66:GetAttribute("PartSpin") ~= false then
		v_u_5.update(p65, nil, v_u_21 ~= nil and "world" or nil)
	end
end
return v_u_5