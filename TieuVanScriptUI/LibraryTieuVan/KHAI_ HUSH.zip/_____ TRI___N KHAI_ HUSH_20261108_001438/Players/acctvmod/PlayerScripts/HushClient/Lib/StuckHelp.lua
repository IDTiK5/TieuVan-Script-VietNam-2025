-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / StuckHelp

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = "idle"
local v_u_15 = 0
local v_u_16 = ""
local v_u_17 = ""
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = 0
local v_u_21 = 0
local v_u_22 = "none"
local v_u_23 = false
local v_u_24 = nil
local v_u_25 = false
local function v_u_42(p26) -- name: build
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (ref) v_u_11, (ref) v_u_13, (copy) v_u_3
	if v_u_8 and (v_u_8.Parent and v_u_9) then
		return true
	end
	local v_u_27 = p26 and p26.lib
	if v_u_27 then
		v_u_27 = p26.lib.HushUI
	end
	local v_u_28 = p26 and p26.shared
	if v_u_28 then
		v_u_28 = p26.shared.Theme
	end
	if not (v_u_27 and v_u_28) then
		return false
	end
	local function v40()
		-- upvalues: (copy) v_u_27, (copy) v_u_28, (ref) v_u_8, (ref) v_u_12, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
		local v29, v30 = v_u_27.screen("HushStuckHelp", v_u_28.layer.inventory + 5, {
			["insets"] = "Device"
		})
		v_u_8 = v29
		local v31 = v_u_28.color
		local v32 = Instance.new("Frame")
		v32.Name = "Pill"
		v32.AnchorPoint = Vector2.new(0, 0)
		v32.Size = UDim2.fromOffset(300, 34)
		v32.BackgroundColor3 = Color3.fromRGB(14, 12, 20)
		v32.BackgroundTransparency = 0.12
		v32.BorderSizePixel = 0
		v32.Visible = false
		v32.Parent = v30
		local v33 = Instance.new("UICorner")
		v33.CornerRadius = UDim.new(0, 6)
		v33.Parent = v32
		local v34 = Instance.new("UIStroke")
		v34.Color = Color3.fromRGB(240, 170, 60)
		v34.Thickness = 1.5
		v34.Parent = v32
		local v35 = Instance.new("Frame")
		v35.Name = "Fill"
		v35.BackgroundColor3 = Color3.fromRGB(240, 170, 60)
		v35.BackgroundTransparency = 0.45
		v35.BorderSizePixel = 0
		v35.Size = UDim2.new(0, 0, 1, 0)
		v35.Parent = v32
		local v36 = Instance.new("UICorner")
		v36.CornerRadius = UDim.new(0, 6)
		v36.Parent = v35
		local v37 = v_u_27.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["textSize"] = 13,
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["track"] = false,
			["parent"] = v32,
			["color"] = v31.text,
			["size"] = UDim2.fromScale(1, 1)
		})
		v37.ZIndex = 3
		local v38 = Instance.new("TextButton")
		v38.Name = "Hold"
		v38.BackgroundTransparency = 1
		v38.Text = ""
		v38.AutoButtonColor = false
		v38.Size = UDim2.fromScale(1, 1)
		v38.ZIndex = 4
		v38.Parent = v32
		v38.InputBegan:Connect(function(p39)
			-- upvalues: (ref) v_u_12
			if p39.UserInputType == Enum.UserInputType.MouseButton1 or p39.UserInputType == Enum.UserInputType.Touch then
				v_u_12 = p39
			end
		end)
		v_u_9 = v32
		v_u_10 = v35
		v_u_11 = v37
	end
	if pcall(v40) then
		if not v_u_13 then
			v_u_13 = v_u_3.InputEnded:Connect(function(p41)
				-- upvalues: (ref) v_u_12
				if p41 == v_u_12 then
					v_u_12 = nil
				end
			end)
		end
		return true
	end
	if v_u_8 then
		v_u_8:Destroy()
	end
	v_u_8 = nil
	v_u_9 = nil
	v_u_10 = nil
	v_u_11 = nil
	return false
end
local function v_u_50(p43, p44) -- name: place
	-- upvalues: (ref) v_u_9, (ref) v_u_5
	local v45 = v_u_9
	if v45 then
		local v46 = p43.shared.Theme
		local v47 = v46.refSize()
		local v48 = v46.uiScale()
		local v49 = v_u_5.pillRect(v47.X * v48, v47.Y * v48, v48, p44)
		v45.Size = UDim2.fromOffset(v49.w, v49.h)
		v45.Position = UDim2.fromOffset(v49.x, v49.y)
	end
end
local function v_u_53() -- name: liftPillVisible
	-- upvalues: (copy) v_u_1
	local v51 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if v51 then
		v51 = v51:FindFirstChild("HushLiftSendUp")
	end
	if not v51 then
		return false
	end
	for _, v52 in v51:GetDescendants() do
		if v52.Name ~= "Pill" or not v52:IsA("GuiObject") then
			continue
		end
		return v52.Visible
	end
	return false
end
local function v_u_63(p54, p55, p56, p57, p58) -- name: blockedNow
	-- upvalues: (ref) v_u_5
	if p54:GetAttribute("Place") ~= "Raid" or (p54:GetAttribute("RaidStatus") ~= "Alive" or p54:GetAttribute("RaidClientReady") ~= true) then
		return true
	end
	if not p56 or (not p57 or (not p58 or (p57.Health <= 0 or (p56:GetAttribute("Dead") == true or p56:GetAttribute("Downed") == true)))) then
		return true
	end
	if p57.SeatPart ~= nil or p57.Sit then
		return true
	end
	if v_u_5.clientFight(p56:GetAttribute("LastHitAt"), p56:GetAttribute("LastShotAt"), p56:GetAttribute("LastMeleeAt"), workspace:GetServerTimeNow()) then
		return true
	end
	local v59 = p56:GetAttribute("Action")
	if v59 ~= nil and v59 ~= "" or p54:GetAttribute("PredAction") ~= nil and p54:GetAttribute("PredAction") ~= "" then
		return true
	end
	if p58.Anchored or p56:GetAttribute("HushHeld") ~= nil then
		return true
	end
	local v60
	if p55 then
		local v61 = p55.blockers
		if type(v61) == "function" then
			v60 = p55.blockers()
		else
			v60 = nil
		end
	else
		v60 = nil
	end
	if v60 then
		if v60.enabled == false or (v60.blocked == true or v60.modal == true) then
			return true
		end
		local v62 = v60.open
		if type(v62) == "table" and (v62.inv == true or (v62.map == true or v62.set == true)) then
			return true
		end
	end
	return false
end
local function v_u_124(p_u_64, p65, p66) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_63, (ref) v_u_14, (ref) v_u_15, (ref) v_u_5, (ref) v_u_6, (ref) v_u_25, (ref) v_u_24, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7, (ref) v_u_17, (copy) v_u_53, (copy) v_u_42, (ref) v_u_18, (copy) v_u_50, (copy) v_u_3, (ref) v_u_10, (ref) v_u_11, (ref) v_u_19
	local v67 = v_u_1.LocalPlayer
	local v68 = v67.Character
	local v69
	if v68 then
		v69 = v68:FindFirstChildOfClass("Humanoid")
	else
		v69 = v68
	end
	local v70
	if v68 then
		v70 = v68:FindFirstChild("HumanoidRootPart")
	else
		v70 = v68
	end
	local v71 = os.clock()
	local v72 = v_u_63(v67, p65, v68, v69, v70)
	local v73 = false
	if p65 then
		local v74 = p65.device
		if type(v74) == "function" then
			local v75 = p65.device
			local v76
			v73, v76 = pcall(v75)
			if v73 then
				v73 = v76 == "Gamepad"
			end
		end
	end
	local v77 = false
	if p65 then
		local v78 = p65.device
		if type(v78) == "function" then
			local v79 = p65.device
			local v80
			v77, v80 = pcall(v79)
			if v77 then
				v77 = v80 == "Touch"
			end
		end
	end
	local v81 = (v67:GetAttribute("Place") ~= "Raid" or v68 ~= nil and v68:GetAttribute("Dead") == true or v69 == nil) and true or v69.Health <= 0
	if v_u_14 == "reply" then
		if v71 - v_u_15 >= v_u_5.TUNE.REPLY_SHOW or v81 then
			v_u_5.clientClear(v_u_6)
			if v_u_25 ~= false then
				v_u_25 = false
				local v82 = v_u_24
				if v82 then
					local v83 = v82.setPadChordSwallow
					if type(v83) == "function" then
						local v84 = v82.setPadChordSwallow
						pcall(v84, false)
					end
				end
			end
			if v_u_9 then
				v_u_9.Visible = false
			end
			v_u_12 = nil
			if v_u_7 then
				local v85 = v_u_7
				v_u_7.t = 0
				v85.fired = false
			end
			v_u_17 = ""
			v_u_14 = "idle"
		end
		return
	end
	if v_u_14 == "wait" then
		if v71 - v_u_15 >= 4 or v81 then
			v_u_5.clientClear(v_u_6)
			if v_u_25 ~= false then
				v_u_25 = false
				local v86 = v_u_24
				if v86 then
					local v87 = v86.setPadChordSwallow
					if type(v87) == "function" then
						local v88 = v86.setPadChordSwallow
						pcall(v88, false)
					end
				end
			end
			if v_u_9 then
				v_u_9.Visible = false
			end
			v_u_12 = nil
			if v_u_7 then
				local v89 = v_u_7
				v_u_7.t = 0
				v89.fired = false
			end
			v_u_17 = ""
			v_u_14 = "idle"
		end
		return
	end
	local v90, v91, v92
	if v70 and v69 then
		v90 = v70.Position.X
		v91 = v70.Position.Z
		v92 = v69.MoveDirection.Magnitude
	else
		v90 = 0
		v91 = 0
		v92 = 0
	end
	local v93 = v_u_5.clientStep(v_u_6, v71, v90, v91, v92, v72)
	if v93 and v_u_53() then
		v93 = false
	end
	if not v93 then
		if v_u_14 == "offer" then
			if v_u_25 ~= false then
				v_u_25 = false
				local v94 = v_u_24
				if v94 then
					local v95 = v94.setPadChordSwallow
					if type(v95) == "function" then
						local v96 = v94.setPadChordSwallow
						pcall(v96, false)
					end
				end
			end
			if v_u_9 then
				v_u_9.Visible = false
			end
			v_u_12 = nil
			if v_u_7 then
				local v97 = v_u_7
				v_u_7.t = 0
				v97.fired = false
			end
			v_u_17 = ""
			v_u_14 = "idle"
		end
		return
	end
	if not v_u_42(p_u_64) then
		return
	end
	local v98 = v_u_9
	if v_u_14 ~= "offer" then
		v_u_14 = "offer"
		v_u_18 = v_u_18 + 1
		v_u_7 = v_u_5.holdNew()
		v_u_50(p_u_64, v77)
		v98.Visible = true
	end
	if v73 ~= v_u_25 then
		v_u_25 = v73
		local v99 = v_u_24
		if v99 then
			local v100 = v99.setPadChordSwallow
			if type(v100) == "function" then
				local v101 = v99.setPadChordSwallow
				pcall(v101, v73)
			end
		end
	end
	local v102
	if v_u_12 == nil then
		if v73 then
			local function v104()
				-- upvalues: (ref) v_u_3
				local v103 = v_u_3:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonL1)
				if v103 then
					v103 = v_u_3:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR1)
				end
				return v103
			end
			local v105
			v102, v105 = pcall(v104)
			if v102 then
				v102 = v105 == true
			end
		else
			v102 = v73
		end
	else
		v102 = true
	end
	local v106, v107 = v_u_5.holdStep(v_u_7, v102, p66, true)
	v_u_10.Size = UDim2.new(v106, 0, 1, 0)
	local v108 = nil
	local v109 = nil
	if v73 and p65 then
		local v110 = p65.keyName
		if type(v110) == "function" then
			local v111 = p65.keyName
			local v112
			v112, v108 = pcall(v111, "ButtonL1")
			local v113 = p65.keyName
			local v114
			v114, v109 = pcall(v113, "ButtonR1")
			if not v112 or (type(v108) ~= "string" or (v108 == "" or v108 == "-")) then
				v108 = nil
			end
			if not v114 or (type(v109) ~= "string" or (v109 == "" or v109 == "-")) then
				v109 = nil
			end
		end
	end
	local v115 = v_u_5.label(v73, v108, v109)
	if v115 == v_u_17 or not v_u_11 then
		if not v107 then
			return
		end
	else
		v_u_17 = v115
		local v116 = p_u_64.lib.HushUI
		if v116 then
			local v117 = v116.setText
			if type(v117) == "function" then
				v116.setText(v_u_11, v115)
				if not v107 then
					return
				end
			else
				v_u_11.Text = v115
				if not v107 then
					return
				end
			end
		else
			v_u_11.Text = v115
			if not v107 then
				return
			end
		end
	end
	v_u_19 = v_u_19 + 1
	v_u_14 = "wait"
	v_u_15 = v71
	if v_u_25 ~= false then
		v_u_25 = false
		local v118 = v_u_24
		if v118 then
			local v119 = v118.setPadChordSwallow
			if type(v119) == "function" then
				local v120 = v118.setPadChordSwallow
				pcall(v120, false)
			end
		end
	end
	if v_u_17 ~= "..." and v_u_11 then
		v_u_17 = "..."
		local v121 = p_u_64.lib.HushUI
		if v121 then
			local v122 = v121.setText
			if type(v122) == "function" then
				v121.setText(v_u_11, "...")
			else
				v_u_11.Text = "..."
			end
		else
			v_u_11.Text = "..."
		end
	end
	task.spawn(function()
		-- upvalues: (copy) p_u_64
		local v123 = p_u_64.net.fire
		pcall(v123, "mv.free")
	end)
end
function v_u_4.start(p_u_125, p_u_126) -- name: start
	-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_24, (ref) v_u_7, (copy) v_u_2, (ref) v_u_23, (copy) v_u_124, (ref) v_u_21, (ref) v_u_25, (ref) v_u_9, (ref) v_u_12, (ref) v_u_17, (ref) v_u_14, (ref) v_u_20, (ref) v_u_22, (copy) v_u_42, (ref) v_u_15, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11, (copy) v_u_4
	if v_u_6 == nil then
		local v127, v128 = pcall(function()
			-- upvalues: (copy) p_u_125
			return p_u_125.shared.StuckRules
		end)
		if v127 and type(v128) == "table" then
			v_u_5 = v128
			v_u_24 = p_u_126
			v_u_6 = v_u_5.clientNew()
			v_u_7 = v_u_5.holdNew()
			v_u_2.Heartbeat:Connect(function(p129)
				-- upvalues: (ref) v_u_23, (ref) v_u_124, (copy) p_u_125, (copy) p_u_126, (ref) v_u_21, (ref) v_u_25, (ref) v_u_24, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7, (ref) v_u_17, (ref) v_u_14
				if not v_u_23 then
					local v130 = v_u_124
					local v131 = p_u_125
					local v132 = p_u_126
					local v133, v134 = pcall(v130, v131, v132, p129)
					if not v133 then
						v_u_21 = v_u_21 + 1
						if v_u_21 <= 2 then
							warn("[StuckHelp] step failed:", v134)
						end
						if v_u_21 >= 5 then
							v_u_23 = true
							if v_u_25 ~= false then
								v_u_25 = false
								local v135 = v_u_24
								if v135 then
									local v136 = v135.setPadChordSwallow
									if type(v136) == "function" then
										local v137 = v135.setPadChordSwallow
										pcall(v137, false)
									end
								end
							end
							if v_u_9 then
								v_u_9.Visible = false
							end
							v_u_12 = nil
							if v_u_7 then
								local v138 = v_u_7
								v_u_7.t = 0
								v138.fired = false
							end
							v_u_17 = ""
							v_u_14 = "idle"
							warn("[StuckHelp] switched off after 5 errors")
						end
					end
				end
			end)
			local function v151()
				-- upvalues: (copy) p_u_125, (ref) v_u_20, (ref) v_u_22, (ref) v_u_5, (ref) v_u_42, (ref) v_u_6, (ref) v_u_25, (ref) v_u_24, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7, (ref) v_u_17, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11
				p_u_125.net.listen("mv.freeReply", function(p139)
					-- upvalues: (ref) v_u_20, (ref) v_u_22, (ref) v_u_5, (ref) v_u_42, (ref) p_u_125, (ref) v_u_6, (ref) v_u_25, (ref) v_u_24, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7, (ref) v_u_17, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11
					v_u_20 = v_u_20 + 1
					local v140
					if type(p139) == "table" then
						v140 = p139.c
					else
						v140 = nil
					end
					v_u_22 = tostring(v140)
					local v141 = v_u_5.replyText(v140)
					if v141 == nil or not v_u_42(p_u_125) then
						v_u_5.clientClear(v_u_6)
						if v_u_25 ~= false then
							v_u_25 = false
							local v142 = v_u_24
							if v142 then
								local v143 = v142.setPadChordSwallow
								if type(v143) == "function" then
									local v144 = v142.setPadChordSwallow
									pcall(v144, false)
								end
							end
						end
						if v_u_9 then
							v_u_9.Visible = false
						end
						v_u_12 = nil
						if v_u_7 then
							local v145 = v_u_7
							v_u_7.t = 0
							v145.fired = false
						end
						v_u_17 = ""
						v_u_14 = "idle"
					else
						local v146 = os.clock()
						v_u_14 = "reply"
						v_u_15 = v146
						v_u_16 = v141
						if v_u_9 then
							v_u_9.Visible = true
						end
						if v_u_10 then
							v_u_10.Size = UDim2.new(v140 == "ok" and 1 or 0, 0, 1, 0)
						end
						local v147 = p_u_125
						local v148 = v_u_16
						if v148 ~= v_u_17 and v_u_11 then
							v_u_17 = v148
							local v149 = v147.lib.HushUI
							if v149 then
								local v150 = v149.setText
								if type(v150) == "function" then
									v149.setText(v_u_11, v148)
									return
								end
							end
							v_u_11.Text = v148
						end
					end
				end)
			end
			pcall(v151)
			local function v152()
				-- upvalues: (copy) p_u_125, (ref) v_u_4
				p_u_125.command("stuck.state", function()
					-- upvalues: (ref) v_u_4
					return v_u_4.state()
				end)
			end
			pcall(v152)
		end
	else
		return
	end
end
function v_u_4.state() -- name: state
	-- upvalues: (ref) v_u_14, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (ref) v_u_21, (ref) v_u_23, (ref) v_u_6
	local v153 = v_u_23
	return string.format("stuckhelp mode=%s offers=%d sends=%d replies=%d last=%s errors=%d off=%s stuckFor=%.1f", v_u_14, v_u_18, v_u_19, v_u_20, v_u_22, v_u_21, tostring(v153), v_u_6 and (v_u_6.stuckFor or 0) or 0)
end
return v_u_4