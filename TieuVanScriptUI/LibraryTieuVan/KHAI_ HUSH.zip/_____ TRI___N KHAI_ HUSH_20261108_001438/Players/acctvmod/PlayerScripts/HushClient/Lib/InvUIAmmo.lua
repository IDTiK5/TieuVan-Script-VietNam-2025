-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIAmmo

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v2 = require(v1:WaitForChild("Theme"))
local v_u_3 = require(v1:WaitForChild("Items"))
local v_u_4 = require(v1:WaitForChild("Grid"))
local v_u_5 = require(v1:WaitForChild("Config"))
local v_u_6 = v2.color
local v_u_7 = {}
local v_u_8 = {
	["FMJ"] = 1,
	["HP"] = 2,
	["AP"] = 3
}
local v_u_9 = { "FMJ", "HP", "AP" }
local v_u_10 = {
	["raid"] = { "pockets", "vest", "bag" },
	["menu"] = {
		"stash",
		"lo_pockets",
		"lo_vest",
		"lo_bag"
	}
}
function v_u_7.carried(p11, p12) -- name: carried
	-- upvalues: (copy) v_u_10
	return table.find(v_u_10[p11 == "raid" and "raid" or "menu"], p12) ~= nil
end
function v_u_7.gunReach(p13, p14, p15, p16) -- name: gunReach
	if p13 ~= "raid" or p14 ~= "Raid" then
		return true
	end
	local v17
	if type(p15) == "string" and p15 ~= "" then
		v17 = p15 == tostring(p16)
	else
		v17 = false
	end
	return v17
end
function v_u_7.heldUid() -- name: heldUid
	local v18 = game:GetService("Players").LocalPlayer
	if v18 then
		v18 = v18.Character
	end
	if v18 then
		v18 = v18:GetAttribute("WeaponUid")
	end
	if type(v18) == "string" and v18 ~= "" then
		return v18
	else
		return nil
	end
end
function v_u_7.liveState() -- name: liveState
	-- upvalues: (copy) v_u_7
	local v19 = game:GetService("Players").LocalPlayer
	if v19 then
		return true, v19:GetAttribute("Place"), v_u_7.heldUid()
	else
		return false, nil, nil
	end
end
function v_u_7.reaches(p20, p21) -- name: reaches
	-- upvalues: (copy) v_u_7
	local v22, v23, v24 = v_u_7.liveState()
	return not v22 and true or v_u_7.gunReach(p20, v23, v24, p21)
end
function v_u_7.lootUnload() -- name: lootUnload
	-- upvalues: (copy) v_u_5
	local v25 = v_u_5.flag
	local v26, v27 = pcall(v25, "UnloadFromContainer")
	return not v26 or v27 ~= false
end
function v_u_7.inLoot(p28, p29) -- name: inLoot
	-- upvalues: (copy) v_u_7
	local v30
	if p28 == "raid" and (type(p29) == "table" and p29.kind == "grid") then
		local v31 = p29.container
		if type(v31) == "string" and (p29.container ~= "secure" and p29.container ~= "ground") then
			v30 = not v_u_7.carried(p28, p29.container)
		else
			v30 = false
		end
	else
		v30 = false
	end
	return v30
end
function v_u_7.groundActs(p32, p33, p34, p35) -- name: groundActs
	-- upvalues: (copy) v_u_7
	local v36
	if type(p34) == "table" and (p34.category == "firearm" and type(p33) == "table") then
		local v37 = p33.ammo
		if type(v37) == "number" then
			v36 = p33.ammo > 0
		else
			v36 = false
		end
	else
		v36 = false
	end
	if v36 and v_u_7.lootUnload() then
		table.insert(p32, p35 and {
			["id"] = "unload",
			["text"] = "Unload",
			["icon"] = "unequip"
		} or {
			["id"] = "unload",
			["text"] = "Unload"
		})
	end
end
function v_u_7.label(p38) -- name: label
	-- upvalues: (copy) v_u_3, (copy) v_u_9
	local v39 = type(p38) == "string" and v_u_3.get(p38) or nil
	if v39 and v39.category == "ammo" then
		return v39.ammoType or v_u_9[v39.tier or 1]
	else
		return nil
	end
end
function v_u_7.color(p40) -- name: color
	-- upvalues: (copy) v_u_9, (copy) v_u_6
	if type(p40) == "number" then
		p40 = v_u_9[p40]
	end
	if p40 == "HP" then
		return v_u_6.success or v_u_6.text2
	elseif p40 == "AP" then
		return v_u_6.info or v_u_6.text2
	else
		return v_u_6.text2
	end
end
function v_u_7.slotItem(p41, p42) -- name: slotItem
	local v43
	if type(p41) == "table" then
		v43 = p41.kit or nil
	else
		v43 = nil
	end
	if type(v43) == "table" then
		local v44 = v43.slots
		if v44 then
			v44 = v43.slots[p42]
		end
		if v44 == nil then
			v44 = v43[p42]
		end
		if type(v44) == "table" then
			return v44
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_7.choices(p45, p46, p47) -- name: choices
	-- upvalues: (copy) v_u_10, (copy) v_u_3, (copy) v_u_7, (copy) v_u_8
	local v48 = {}
	if type(p45) == "table" then
		local v49 = p45.containers
		if type(v49) == "table" and p47 then
			local v50 = {}
			for _, v51 in v_u_10[p46 == "raid" and "raid" or "menu"] do
				local v52 = p45.containers[v51]
				if type(v52) ~= "table" then
					continue
				end
				local v53 = v52.items
				if type(v53) ~= "table" or v52.world == true then
					continue
				end
				for _, v54 in v52.items do
					local v55
					if type(v54) == "table" then
						v55 = v_u_3.get(v54.id) or nil
					else
						v55 = nil
					end
					if not v55 or (v55.category ~= "ammo" or v55.caliber ~= p47) then
						continue
					end
					local v56 = v55.id
					local v57 = v50[v55.id] or 0
					local v58 = v54.n
					v50[v56] = v57 + (tonumber(v58) or 1)
				end
			end
			for v59, v60 in v50 do
				local v61 = {
					["id"] = v59,
					["type"] = v_u_7.label(v59) or "?",
					["n"] = v60
				}
				table.insert(v48, v61)
			end
			table.sort(v48, function(p62, p63)
				-- upvalues: (ref) v_u_8
				local v64 = v_u_8[p62.type] or 9
				local v65 = v_u_8[p63.type] or 9
				if v64 == v65 then
					return p62.id < p63.id
				else
					return v64 < v65
				end
			end)
			return v48
		end
	end
	return v48
end
function v_u_7.weapons(p66, p67) -- name: weapons
	-- upvalues: (copy) v_u_3
	local v68 = {}
	for _, v69 in { "primary", "secondary" } do
		local v70
		if type(p66) == "table" then
			v70 = p66.kit or nil
		else
			v70 = nil
		end
		local v71
		if type(v70) == "table" then
			v71 = v70.slots
			if v71 then
				v71 = v70.slots[v69]
			end
			if v71 == nil then
				v71 = v70[v69]
			end
			if type(v71) ~= "table" then
				v71 = nil
			end
		else
			v71 = nil
		end
		local v72
		if v71 then
			v72 = v_u_3.get(v71.id)
		else
			v72 = v71
		end
		if not v72 or (v72.category ~= "firearm" or v72.caliber ~= p67) then
			continue
		end
		local v73 = v71.uid
		if type(v73) ~= "string" then
			continue
		end
		local v74 = {
			["uid"] = v71.uid,
			["slot"] = v69,
			["def"] = v72,
			["item"] = v71
		}
		table.insert(v68, v74)
	end
	return v68
end
local function v_u_80(p75, p76) -- name: weaponByUid
	for _, v77 in { "primary", "secondary" } do
		local v78
		if type(p75) == "table" then
			v78 = p75.kit or nil
		else
			v78 = nil
		end
		local v79
		if type(v78) == "table" then
			v79 = v78.slots
			if v79 then
				v79 = v78.slots[v77]
			end
			if v79 == nil then
				v79 = v78[v77]
			end
			if type(v79) ~= "table" then
				v79 = nil
			end
		else
			v79 = nil
		end
		if not v79 or v79.uid ~= p76 then
			continue
		end
		return v79
	end
	return nil
end
function v_u_7.nextChoice(p81, p82) -- name: nextChoice
	-- upvalues: (copy) v_u_80, (copy) v_u_3, (copy) v_u_7, (copy) v_u_8
	local v83 = v_u_80(p81, p82)
	local v84
	if v83 then
		v84 = v_u_3.get(v83.id)
	else
		v84 = v83
	end
	if v84 and v84.category == "firearm" then
		local v85 = v_u_7.choices(p81, "raid", v84.caliber)
		if #v85 == 0 then
			return nil, nil
		else
			local v86 = v_u_8[v_u_7.label(v83.ammoId) or ""] or 0
			local v87 = nil
			local v88 = nil
			for _, v89 in v85 do
				local v90 = v_u_8[v89.type] or 9
				if v89.id == v83.ammoId then
					continue
				end
				if v86 < v90 then
					v87 = v87 or v89
				end
				if v88 then
					continue
				end
				v88 = v89
			end
			local v91 = v87 or v88
			if v91 then
				return v91.id, v91.type
			else
				return nil, nil
			end
		end
	else
		return nil, nil
	end
end
function v_u_7.weaponActs(p92, p93, p94, p95, p96) -- name: weaponActs
	-- upvalues: (copy) v_u_7
	local v97 = {}
	if p96 and (v_u_7.inLoot(p93, p96) and v_u_7.lootUnload()) then
		return v97
	end
	if not v_u_7.reaches(p93, p94.uid) then
		return v97
	end
	local v98 = v_u_7.choices
	if p95 then
		p95 = p95.caliber
	end
	local v99 = v98(p92, p93, p95)
	if #v99 == 0 then
		table.insert(v97, {
			["id"] = "load",
			["text"] = "Load ammo"
		})
		return v97
	end
	local v100 = p94.ammoPref
	local v101
	if type(v100) == "string" then
		v101 = p94.ammoPref
	else
		v101 = p94.ammoId
	end
	for _, v102 in v99 do
		local v103 = {
			["id"] = "load:" .. v102.id,
			["text"] = ("Load %s (%d)"):format(v102.type, v102.n),
			["kind"] = v102.id == v101 and "current" or nil
		}
		table.insert(v97, v103)
	end
	return v97
end
function v_u_7.stackActs(p104, p105, p106, p107) -- name: stackActs
	-- upvalues: (copy) v_u_7
	local v108 = {}
	if p107 and (p107.category == "ammo" and (p106 and (p106.kind == "grid" and v_u_7.carried(p105, p106.container)))) then
		for _, v109 in v_u_7.weapons(p104, p107.caliber) do
			if not v_u_7.reaches(p105, v109.uid) then
				continue
			end
			local v110 = {
				["id"] = "loadinto:" .. v109.uid
			}
			local v111 = v109.def.short or v109.def.name
			v110.text = "Load into " .. tostring(v111)
			table.insert(v108, v110)
		end
	end
	return v108
end
function v_u_7.opFor(p112, p113, p114) -- name: opFor
	return string.sub(p112, 1, 5) == "load:" and {
		["op"] = "load",
		["weaponUid"] = nil,
		["ammoId"] = nil,
		["weaponUid"] = p113,
		["ammoId"] = string.sub(p112, 6)
	} or (string.sub(p112, 1, 9) == "loadinto:" and p114 and {
		["op"] = "load",
		["weaponUid"] = nil,
		["ammoId"] = nil,
		["weaponUid"] = string.sub(p112, 10),
		["ammoId"] = p114.id
	} or nil)
end
local v_u_115 = 0
function v_u_7.load(p116, p117, p118) -- name: load
	-- upvalues: (ref) v_u_115
	if game:GetService("Players").LocalPlayer:GetAttribute("Place") ~= "Raid" then
		return "not in raid"
	end
	if not p116 or (type(p117) ~= "string" or type(p118) ~= "string") then
		return "bad args"
	end
	local v119 = os.clock()
	if v119 - v_u_115 < 0.4 then
		return "debounced"
	end
	v_u_115 = v119
	local v120 = p116.fire
	pcall(v120, "inv.op", {
		["op"] = "load",
		["weaponUid"] = nil,
		["ammoId"] = nil,
		["weaponUid"] = p117,
		["ammoId"] = p118
	})
	return "sent"
end
function v_u_7.dropTarget(_, p121, p122, p123, p124, p125) -- name: dropTarget
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	local v126
	if type(p122) == "table" then
		v126 = v_u_3.get(p122.id) or nil
	else
		v126 = nil
	end
	local v127
	if type(p124) == "table" then
		v127 = v_u_3.get(p124.id) or nil
	else
		v127 = nil
	end
	if v126 and (v126.category == "ammo" and (v127 and v127.category == "firearm")) then
		local v128 = p124.uid
		if type(v128) == "string" then
			local v129 = not p123 or (p123.kind ~= "grid" or v_u_7.carried(p121, p123.container))
			if not v129 then
				if p121 == "raid" then
					v129 = p123.container ~= "secure"
				else
					v129 = false
				end
			end
			return v129 and ((p125 == nil or p121 ~= "raid" or v_u_7.carried("raid", p125)) and v_u_7.reaches(p121, p124.uid)) and {
				["kind"] = "load",
				["weaponUid"] = nil,
				["ammoId"] = nil,
				["ammoUid"] = nil,
				["ok"] = nil,
				["weaponUid"] = p124.uid,
				["ammoId"] = p122.id,
				["ammoUid"] = p122.uid,
				["ok"] = v126.caliber == v127.caliber
			} or nil
		end
	end
	return nil
end
function v_u_7.hover(p130, p131, p132, p133, p134, p135, p136) -- name: hover
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4
	local v137 = p131 and p131.inst
	if v137 then
		v137 = v_u_3.get(p131.inst.id)
	end
	local v138
	if type(p132) == "table" then
		v138 = v_u_3.get(p132.id) or nil
	else
		v138 = nil
	end
	if not v137 or (v137.category ~= "ammo" or (not v138 or v138.category ~= "firearm")) then
		return false
	end
	local v139 = v_u_7.dropTarget(p130.work, p130.mode, p131.inst, p131.from, p132, p133)
	local v140
	if v139 and v139.ok then
		v140 = v_u_6.success
	else
		v140 = v_u_6.danger
	end
	p134.Visible = true
	p134.BackgroundColor3 = v140
	if p135 then
		p135.Color = v140
	end
	if p136 then
		local v141 = p132.x
		if type(v141) == "number" then
			local v142, v143 = v_u_4.size(p132)
			p134.Position = UDim2.fromOffset(p132.x * p136, p132.y * p136)
			p134.Size = UDim2.fromOffset(v142 * p136, v143 * p136)
		end
	end
	p131.gStroke.Color = v140
	p131.target = v139
	return true
end
function v_u_7.dropOp(p144, _) -- name: dropOp
	return {
		["op"] = "load",
		["weaponUid"] = nil,
		["ammoId"] = nil,
		["weaponUid"] = p144.weaponUid,
		["ammoId"] = p144.ammoId,
		["ammoUid"] = p144.ammoUid
	}
end
function v_u_7.stripActs(p145, p146, p147, p148, p149, p150) -- name: stripActs
	-- upvalues: (copy) v_u_7
	local v151 = {}
	if p150 or not (p147 and p148) then
		return v151
	end
	local v152, v153, v154, v155, v156, v157, v158
	if p148.category ~= "firearm" then
		if p148.category == "firearm" then
			if not p149 and v_u_7.inLoot(p146, p147) then
				v152 = p147.item
				if type(p148) == "table" and (p148.category == "firearm" and type(v152) == "table") then
					v153 = v152.ammo
					if type(v153) == "number" then
						v154 = v152.ammo > 0
					else
						v154 = false
					end
				else
					v154 = false
				end
				if v154 and v_u_7.lootUnload() then
					table.insert(v151, {
						["id"] = "unload",
						["text"] = "Unload",
						["icon"] = "unequip"
					})
					return v151
				end
			end
		elseif not p149 then
			for v174, v175 in v_u_7.stackActs(p145, p146, p147, p148) do
				v155 = v175.id
				v156 = string.sub(v155, 10)
				for v176, v177 in v_u_7.weapons(p145, p148.caliber) do
					if v177.uid ~= v156 or not v_u_7.reaches(p146, v177.uid) then
						continue
					end
					v157 = {
						["id"] = nil,
						["text"] = nil,
						["icon"] = "load",
						["id"] = v175.id
					}
					v158 = v177.def.short or v177.def.name
					v157.text = "Into " .. tostring(v158)
					table.insert(v151, v157)
				end
			end
		end
		return v151
	end
	local v163, v164, v165, v166
	if p147.kind == "slot" then
		v178 = v_u_7.choices(p145, p146, p148.caliber)
		v179 = p147.item
		v180 = type(v179) == "table" and not v_u_7.reaches(p146, p147.item.uid) and {} or v178
		if p149 then
			for v181, v182 in v180 do
				v163 = {
					["id"] = nil,
					["text"] = nil,
					["icon"] = "load",
					["id"] = "load:" .. v182.id,
					["text"] = ("%s %d"):format(v182.type, v182.n)
				}
				table.insert(v151, v163)
			end
			table.insert(v151, {
				["id"] = "loadback",
				["text"] = "Back",
				["icon"] = "cancel"
			})
		elseif #v180 == 1 then
			v164 = {
				["id"] = nil,
				["text"] = nil,
				["icon"] = "load",
				["id"] = "load:" .. v180[1].id,
				["text"] = "Load " .. v180[1].type
			}
			table.insert(v151, v164)
		elseif #v180 > 1 then
			table.insert(v151, {
				["id"] = "loadpick",
				["text"] = "Load",
				["icon"] = "load"
			})
		end
		if not p149 then
			v165 = p147.item
			if type(v165) == "table" then
				v166 = p147.item.ammo
				if type(v166) == "number" and p147.item.ammo > 0 then
					table.insert(v151, {
						["id"] = "unload",
						["text"] = "Unload",
						["icon"] = "unequip"
					})
					return v151
				end
			end
		end
		return v151
	end
	if p147.kind ~= "grid" then
		if p148.category == "firearm" then
			if not p149 and v_u_7.inLoot(p146, p147) then
				v152 = p147.item
				if type(p148) == "table" and (p148.category == "firearm" and type(v152) == "table") then
					v153 = v152.ammo
					if type(v153) == "number" then
						v154 = v152.ammo > 0
					else
						v154 = false
					end
				else
					v154 = false
				end
				if v154 and v_u_7.lootUnload() then
					table.insert(v151, {
						["id"] = "unload",
						["text"] = "Unload",
						["icon"] = "unequip"
					})
					return v151
				end
			end
		elseif not p149 then
			for v174, v175 in v_u_7.stackActs(p145, p146, p147, p148) do
				v155 = v175.id
				v156 = string.sub(v155, 10)
				for v176, v177 in v_u_7.weapons(p145, p148.caliber) do
					if v177.uid ~= v156 or not v_u_7.reaches(p146, v177.uid) then
						continue
					end
					v157 = {
						["id"] = nil,
						["text"] = nil,
						["icon"] = "load",
						["id"] = v175.id
					}
					v158 = v177.def.short or v177.def.name
					v157.text = "Into " .. tostring(v158)
					table.insert(v151, v157)
				end
			end
		end
		return v151
	end
	local v173 = p147.container
	if v173 ~= nil and p146 == "raid" and not v_u_7.carried("raid", v173) then
		if p148.category == "firearm" then
			if not p149 and v_u_7.inLoot(p146, p147) then
				v152 = p147.item
				if type(p148) == "table" and (p148.category == "firearm" and type(v152) == "table") then
					v153 = v152.ammo
					if type(v153) == "number" then
						v154 = v152.ammo > 0
					else
						v154 = false
					end
				else
					v154 = false
				end
				if v154 and v_u_7.lootUnload() then
					table.insert(v151, {
						["id"] = "unload",
						["text"] = "Unload",
						["icon"] = "unequip"
					})
					return v151
				end
			end
		elseif not p149 then
			for v174, v175 in v_u_7.stackActs(p145, p146, p147, p148) do
				v155 = v175.id
				v156 = string.sub(v155, 10)
				for v176, v177 in v_u_7.weapons(p145, p148.caliber) do
					if v177.uid ~= v156 or not v_u_7.reaches(p146, v177.uid) then
						continue
					end
					v157 = {
						["id"] = nil,
						["text"] = nil,
						["icon"] = "load",
						["id"] = v175.id
					}
					v158 = v177.def.short or v177.def.name
					v157.text = "Into " .. tostring(v158)
					table.insert(v151, v157)
				end
			end
		end
		return v151
	end
	local v178 = v_u_7.choices(p145, p146, p148.caliber)
	local v179 = p147.item
	local v180 = type(v179) == "table" and not v_u_7.reaches(p146, p147.item.uid) and {} or v178
	if p149 then
		for v181, v182 in v180 do
			v163 = {
				["id"] = nil,
				["text"] = nil,
				["icon"] = "load",
				["id"] = "load:" .. v182.id,
				["text"] = ("%s %d"):format(v182.type, v182.n)
			}
			table.insert(v151, v163)
		end
		table.insert(v151, {
			["id"] = "loadback",
			["text"] = "Back",
			["icon"] = "cancel"
		})
	elseif #v180 == 1 then
		v164 = {
			["id"] = nil,
			["text"] = nil,
			["icon"] = "load",
			["id"] = "load:" .. v180[1].id,
			["text"] = "Load " .. v180[1].type
		}
		table.insert(v151, v164)
	elseif #v180 > 1 then
		table.insert(v151, {
			["id"] = "loadpick",
			["text"] = "Load",
			["icon"] = "load"
		})
	end
	if not p149 then
		v165 = p147.item
		if type(v165) == "table" then
			v166 = p147.item.ammo
			if type(v166) == "number" and p147.item.ammo > 0 then
				table.insert(v151, {
					["id"] = "unload",
					["text"] = "Unload",
					["icon"] = "unequip"
				})
				return v151
			end
		end
	end
	return v151
end
function v_u_7.describe(p183) -- name: describe
	local v184 = {}
	for _, v185 in p183 do
		local v186 = v185.id .. "=" .. v185.text .. (not v185.kind and "" or " [" .. v185.kind .. "]")
		table.insert(v184, v186)
	end
	return table.concat(v184, " | ")
end
return v_u_7