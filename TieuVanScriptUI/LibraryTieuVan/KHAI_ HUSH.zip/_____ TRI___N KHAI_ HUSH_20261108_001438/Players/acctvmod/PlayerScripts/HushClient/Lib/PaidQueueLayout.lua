-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PaidQueueLayout

local v_u_110 = {
	["PAD"] = 10,
	["COIN"] = 18,
	["GAP_IN"] = 6,
	["GAP"] = 8,
	["TEXT"] = 13,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["MIN_DEPLOY"] = 180,
	["HINT_H"] = 22,
	["HINT_PAD"] = 8,
	["HINT_SIZES"] = { 12, 11, 10 },
	["HINT_GAP"] = 8,
	["SEARCH_GAP"] = 5,
	["CARD_PAD"] = 24,
	["CARD_BULLET"] = 18,
	["CARD_BODY"] = 15,
	["CARD_LINE"] = 20,
	["CARD_GAP"] = 8,
	["CARD_TITLE"] = 32,
	["CARD_TOP"] = 24,
	["CARD_FOOT"] = 40,
	["textW"] = function(p1, p2, p3) -- name: textW
		-- upvalues: (copy) v_u_110
		local v4 = (utf8.len(p1) or #p1) * p2
		local v5
		if p3 == true then
			v5 = v_u_110.CHAR_CAPS
		else
			v5 = v_u_110.CHAR
		end
		local v6 = v4 * v5 + 2
		return math.ceil(v6)
	end,
	["label"] = function(p7) -- name: label
		return p7 and "PAID QUEUE" or "FREE QUEUE"
	end,
	["chip"] = function(p8, p9, p10) -- name: chip
		-- upvalues: (copy) v_u_110
		local v11
		if type(p10) == "table" then
			v11 = p10.paid == true
		else
			v11 = false
		end
		local v12 = v_u_110.label(v11)
		local v13 = v_u_110.textW(v12, v_u_110.TEXT, true)
		local v14 = v_u_110.PAD + v_u_110.COIN + v_u_110.GAP_IN + v13 + v_u_110.PAD
		local v15
		if p8 - v14 - v_u_110.GAP < v_u_110.MIN_DEPLOY then
			local v16 = v_u_110.PAD * 2 + v_u_110.COIN
			v14 = math.max(p9, v16)
			v15 = "icon"
		else
			v15 = "full"
		end
		local v17 = p8 - v_u_110.MIN_DEPLOY - v_u_110.GAP
		local v18 = v_u_110.PAD * 2 + v_u_110.COIN
		if v17 < math.min(v14, v18) then
			return {
				["mode"] = "none",
				["chip"] = nil,
				["deploy"] = nil,
				["coin"] = nil,
				["text"] = nil,
				["size"] = nil,
				["label"] = nil,
				["fits"] = true,
				["textW"] = nil,
				["chip"] = {
					["x"] = nil,
					["y"] = 0,
					["w"] = 0,
					["h"] = nil,
					["x"] = p8,
					["h"] = p9
				},
				["deploy"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = p8,
					["h"] = p9
				},
				["coin"] = {
					["x"] = nil,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0,
					["x"] = p8
				},
				["text"] = {
					["x"] = nil,
					["y"] = 0,
					["w"] = 0,
					["h"] = nil,
					["x"] = p8,
					["h"] = p9
				},
				["size"] = v_u_110.TEXT,
				["label"] = v12,
				["textW"] = v13
			}
		end
		local v19 = p8 - v_u_110.MIN_DEPLOY - v_u_110.GAP
		local v20 = math.max(0, v19)
		local v21 = math.min(v14, v20)
		local v22 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = p8 - v21,
			["w"] = v21,
			["h"] = p9
		}
		local v23 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = p8 - v21 - v_u_110.GAP,
			["h"] = p9
		}
		local v24
		if v15 == "full" then
			local v25 = v22.x + v_u_110.PAD
			local v26 = (p9 - v_u_110.COIN) / 2
			v24 = {
				["x"] = v25,
				["y"] = math.floor(v26),
				["w"] = v_u_110.COIN,
				["h"] = v_u_110.COIN
			}
		else
			local v27 = v22.x
			local v28 = (v21 - v_u_110.COIN) / 2
			local v29 = v27 + math.floor(v28)
			local v30 = (p9 - v_u_110.COIN) / 2
			v24 = {
				["x"] = v29,
				["y"] = math.floor(v30),
				["w"] = v_u_110.COIN,
				["h"] = v_u_110.COIN
			}
		end
		local v31
		if v15 == "full" then
			v31 = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v24.x + v_u_110.COIN + v_u_110.GAP_IN,
				["w"] = v22.x + v21 - v_u_110.PAD - (v24.x + v_u_110.COIN + v_u_110.GAP_IN),
				["h"] = p9
			}
		else
			v31 = {
				["x"] = nil,
				["y"] = 0,
				["w"] = 0,
				["h"] = nil,
				["x"] = v22.x,
				["h"] = p9
			}
		end
		local v32 = v15 == "icon" and true or v13 <= v31.w
		return {
			["mode"] = v15,
			["chip"] = v22,
			["deploy"] = v23,
			["coin"] = v24,
			["text"] = v31,
			["size"] = v_u_110.TEXT,
			["label"] = v12,
			["fits"] = v32,
			["textW"] = v13
		}
	end,
	["searchDock"] = function(p33, p34, p35, p36) -- name: searchDock
		-- upvalues: (copy) v_u_110
		local v37 = v_u_110.chip(p33, p35, p36)
		local v38 = p34 + v_u_110.SEARCH_GAP
		local v39 = {
			["mode"] = v37.mode,
			["h"] = v38 + p35,
			["box"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p33,
				["h"] = p34
			},
			["chip"] = {
				["x"] = v37.chip.x,
				["y"] = v38,
				["w"] = v37.chip.w,
				["h"] = p35
			},
			["stop"] = {
				["x"] = v37.deploy.x,
				["y"] = v38,
				["w"] = v37.deploy.w,
				["h"] = p35
			},
			["deploy"] = v37.deploy,
			["fits"] = v37.fits
		}
		return v39
	end,
	["hint"] = function(p_u_40, p_u_41, p42) -- name: hint
		-- upvalues: (copy) v_u_110
		local v_u_43
		if type(p42) == "table" then
			v_u_43 = p42.compact == true
		else
			v_u_43 = false
		end
		local v_u_44
		if type(p42) == "table" then
			local v45 = p42.SH
			v_u_44 = type(v45) ~= "number" and 44 or p42.SH
		else
			v_u_44 = 44
		end
		local v46
		if type(p42) == "table" then
			local v47 = p42.room
			if type(v47) == "number" and not v_u_43 then
				v46 = p42.room
			else
				v46 = nil
			end
		else
			v46 = nil
		end
		if v46 ~= nil then
			for _, v48 in v_u_110.HINT_SIZES do
				for _, v49 in p_u_41 do
					local v50 = v_u_110.textW(v49, v48) + 2 * v_u_110.HINT_PAD
					if v50 > v46 - v_u_110.HINT_GAP then
						continue
					end
					local v51 = {
						["x"] = nil,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["text"] = nil,
						["size"] = nil,
						["pad"] = nil,
						["fits"] = true,
						["side"] = "left",
						["x"] = -(v50 + v_u_110.HINT_GAP)
					}
					local v52 = (v_u_44 - v_u_110.HINT_H) / 2
					v51.y = math.floor(v52)
					v51.w = v50
					v51.h = v_u_110.HINT_H
					v51.text = v49
					v51.size = v48
					v51.pad = v_u_110.HINT_PAD
					return v51
				end
			end
		end
		local v_u_53
		if v_u_43 and type(p42) == "table" then
			local v54 = p42.reserve
			v_u_53 = (type(v54) ~= "number" or p42.reserve <= 0) and 0 or p42.reserve
		else
			v_u_53 = 0
		end
		local function v61(p55) -- name: try
			-- upvalues: (copy) p_u_40, (ref) v_u_110, (copy) p_u_41, (copy) v_u_43, (copy) v_u_44, (copy) v_u_53
			local v56 = p_u_40 - p55 - 2 * v_u_110.HINT_PAD
			for _, v57 in v_u_110.HINT_SIZES do
				for _, v58 in p_u_41 do
					local v59 = v_u_110.textW(v58, v57)
					if v59 > v56 then
						continue
					end
					local v60 = v59 + 2 * v_u_110.HINT_PAD
					return {
						["x"] = nil,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["text"] = nil,
						["size"] = nil,
						["pad"] = nil,
						["fits"] = true,
						["side"] = "below",
						["overRail"] = nil,
						["x"] = v_u_43 and p55 == 0 and 0 or p_u_40 - v60,
						["y"] = v_u_44 + 4,
						["w"] = v60,
						["h"] = v_u_110.HINT_H,
						["text"] = v58,
						["size"] = v57,
						["pad"] = v_u_110.HINT_PAD,
						["overRail"] = v_u_53 > 0 and p55 == 0 and true or nil
					}
				end
			end
			return nil
		end
		local v62
		if v_u_53 > 0 then
			v62 = v61(v_u_53)
		else
			v62 = nil
		end
		local v63 = v62 or v61(0)
		if v63 ~= nil then
			return v63
		end
		local v64 = p_u_41[#p_u_41]
		local v65 = v_u_110.HINT_SIZES[#v_u_110.HINT_SIZES]
		local v66 = math.max(0, p_u_40)
		return {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["text"] = nil,
			["size"] = nil,
			["pad"] = nil,
			["fits"] = false,
			["side"] = "below",
			["overRail"] = nil,
			["y"] = v_u_44 + 4,
			["w"] = v66,
			["h"] = v_u_110.HINT_H,
			["text"] = v64,
			["size"] = v65,
			["pad"] = v_u_110.HINT_PAD,
			["overRail"] = v_u_53 > 0 and true or nil
		}
	end,
	["RAIL_PHONE"] = 132,
	["RAIL_MINI"] = 216,
	["railReserve"] = function(p67) -- name: railReserve
		-- upvalues: (copy) v_u_110
		local v68
		if p67 then
			v68 = v_u_110.RAIL_PHONE
		else
			v68 = v_u_110.RAIL_MINI
		end
		return v68 + v_u_110.HINT_GAP
	end,
	["noteH"] = function(p69, p70, p71) -- name: noteH
		local v72 = p71 or 13
		local v73 = (utf8.len(p69) or #p69) * v72 * 0.6
		local v74 = p70 * 0.92
		local v75 = v73 / math.max(40, v74)
		local v76 = math.ceil(v75)
		return math.max(1, v76) * (v72 + 4) + 2
	end,
	["modalLimits"] = function(p77, p78, p79, p80) -- name: modalLimits
		local v81 = p80 or {
			["l"] = 0,
			["r"] = 0,
			["t"] = 0,
			["b"] = 0
		}
		local v82 = p78 - v81.l - v81.r - 32
		local v83 = math.min(p77, v82)
		local v84 = p79 * 0.9
		local v85 = p79 - v81.t - v81.b - 16
		local v86 = math.min(v84, v85)
		return v83, math.floor(v86)
	end,
	["card"] = function(p87, p88, p89) -- name: card
		-- upvalues: (copy) v_u_110
		local v90 = p89.width
		local v91 = type(v90) ~= "number" and 480 or p89.width
		local v92, v93 = v_u_110.modalLimits(v91, p87, p88, p89.safe)
		local v94 = v92 - 2 * v_u_110.CARD_PAD - v_u_110.CARD_BULLET
		local v95 = v_u_110.CARD_TOP + v_u_110.CARD_TITLE
		local v96 = {}
		for _, v97 in p89.bullets do
			local v98 = v_u_110.CARD_BODY
			local v99 = (utf8.len(v97) or #v97) * v98 * 0.6
			local v100 = v94 * 0.92
			local v101 = v99 / math.max(40, v100)
			local v102 = math.ceil(v101)
			local v103 = math.max(1, v102)
			table.insert(v96, v103)
			v95 = v95 + (v_u_110.CARD_GAP + v103 * v_u_110.CARD_LINE)
		end
		local v104 = p89.buttonH
		local v105 = type(v104) ~= "number" and 40 or p89.buttonH
		local v106 = v_u_110.CARD_FOOT + v105
		local v107 = v95 + 3 + v106
		local v108 = v93 < v107
		local v109 = math.min(v107, v93)
		return {
			["w"] = v92,
			["h"] = v109,
			["natural"] = v107,
			["maxH"] = v93,
			["scroll"] = v108,
			["button"] = {
				["x"] = nil,
				["y"] = nil,
				["w"] = 140,
				["h"] = nil,
				["x"] = v92 - v_u_110.CARD_PAD - 140,
				["y"] = v109 - v_u_110.CARD_FOOT + 16 - v105,
				["h"] = v105
			},
			["lines"] = v96,
			["textW"] = v94,
			["bodyH"] = v109 - v106
		}
	end
}
return v_u_110