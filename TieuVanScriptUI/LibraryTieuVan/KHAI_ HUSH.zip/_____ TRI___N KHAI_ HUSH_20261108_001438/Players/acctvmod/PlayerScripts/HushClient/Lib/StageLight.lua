-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / StageLight

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Workspace")
local v3 = {}
local v_u_4 = {
	"Ambient",
	"OutdoorAmbient",
	"Brightness",
	"ClockTime",
	"ExposureCompensation",
	"FogColor",
	"FogEnd",
	"FogStart",
	"GlobalShadows",
	"EnvironmentDiffuseScale",
	"EnvironmentSpecularScale",
	"ColorShift_Top",
	"ColorShift_Bottom"
}
local v_u_5 = {
	"Density",
	"Offset",
	"Color",
	"Decay",
	"Glare",
	"Haze"
}
local v_u_6 = {
	["Ambient"] = nil,
	["OutdoorAmbient"] = nil,
	["Brightness"] = 0,
	["ClockTime"] = 0,
	["ExposureCompensation"] = 0,
	["FogColor"] = nil,
	["FogEnd"] = 100000,
	["FogStart"] = 0,
	["GlobalShadows"] = true,
	["EnvironmentDiffuseScale"] = 0.25,
	["EnvironmentSpecularScale"] = 0.6,
	["ColorShift_Top"] = nil,
	["ColorShift_Bottom"] = nil,
	["Ambient"] = Color3.fromRGB(46, 48, 62),
	["OutdoorAmbient"] = Color3.fromRGB(46, 48, 62),
	["FogColor"] = Color3.fromRGB(10, 11, 14),
	["ColorShift_Top"] = Color3.new(0, 0, 0),
	["ColorShift_Bottom"] = Color3.new(0, 0, 0)
}
local v_u_7 = {
	["Density"] = 0.32,
	["Offset"] = 0,
	["Color"] = nil,
	["Decay"] = nil,
	["Glare"] = 0,
	["Haze"] = 0.6,
	["Color"] = Color3.fromRGB(22, 24, 30),
	["Decay"] = Color3.fromRGB(10, 11, 14)
}
local function v_u_22() -- name: newOverrides
	local v_u_8 = {}
	return {
		["set"] = function(p_u_9, p_u_10, p11) -- name: set
			-- upvalues: (copy) v_u_8
			for _, v_u_12 in v_u_8 do
				if v_u_12.inst ~= p_u_9 or v_u_12.prop ~= p_u_10 then
					continue
				end
				v_u_12.want = p11
				pcall(function()
					-- upvalues: (copy) v_u_12
					v_u_12.inst[v_u_12.prop] = v_u_12.want
					v_u_12.last = v_u_12.inst[v_u_12.prop]
				end)
				return
			end
			local v13, v14 = pcall(function()
				-- upvalues: (copy) p_u_9, (copy) p_u_10
				return p_u_9[p_u_10]
			end)
			if v13 then
				local v_u_15 = {
					["inst"] = nil,
					["prop"] = nil,
					["want"] = nil,
					["ext"] = nil,
					["last"] = nil,
					["inst"] = p_u_9,
					["prop"] = p_u_10,
					["want"] = p11,
					["ext"] = v14
				}
				local v16 = v_u_8
				table.insert(v16, v_u_15)
				pcall(function()
					-- upvalues: (copy) v_u_15
					v_u_15.inst[v_u_15.prop] = v_u_15.want
					v_u_15.last = v_u_15.inst[v_u_15.prop]
				end)
			end
		end,
		["apply"] = function() -- name: apply
			-- upvalues: (copy) v_u_8
			for _, v_u_17 in v_u_8 do
				local v18, v19 = pcall(function()
					-- upvalues: (copy) v_u_17
					return v_u_17.inst[v_u_17.prop]
				end)
				if not v18 or v19 == v_u_17.last then
					continue
				end
				if v_u_17.last ~= nil then
					v_u_17.ext = v19
				end
				pcall(function()
					-- upvalues: (copy) v_u_17
					v_u_17.inst[v_u_17.prop] = v_u_17.want
					v_u_17.last = v_u_17.inst[v_u_17.prop]
				end)
			end
		end,
		["restore"] = function() -- name: restore
			-- upvalues: (copy) v_u_8
			for v20 = #v_u_8, 1, -1 do
				local v_u_21 = v_u_8[v20]
				pcall(function()
					-- upvalues: (copy) v_u_21
					v_u_21.inst[v_u_21.prop] = v_u_21.ext
				end)
			end
			table.clear(v_u_8)
		end,
		["count"] = function() -- name: count
			-- upvalues: (copy) v_u_8
			return #v_u_8
		end
	}
end
local function v_u_30(p23, p24, p_u_25, p26) -- name: capInstance
	for _, v_u_27 in p26 do
		local v28, v29 = pcall(function()
			-- upvalues: (copy) p_u_25, (copy) v_u_27
			return p_u_25[v_u_27]
		end)
		if not v28 then
			continue
		end
		p23[p24 .. "." .. v_u_27] = v29
	end
end
function v3.capture() -- name: capture
	-- upvalues: (copy) v_u_30, (copy) v_u_1, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v31 = {}
	v_u_30(v31, "Lighting", v_u_1, v_u_4)
	local v32 = v_u_1:FindFirstChildOfClass("Atmosphere")
	if v32 then
		v_u_30(v31, "Atmosphere", v32, v_u_5)
	end
	local v33 = 0
	for _, v34 in { v_u_1, v_u_2.CurrentCamera } do
		if not v34 then
			continue
		end
		for _, v35 in v34:GetChildren() do
			if not v35:IsA("PostEffect") or string.find(v35.Name, "^CrateStage_") then
				continue
			end
			v33 = v33 + 1
			v31["Post." .. v34.Name .. "." .. v35.Name] = v35.Enabled
		end
	end
	v31.PostCount = v33
	local v36 = 0
	for _, v37 in v_u_1:GetChildren() do
		if not string.find(v37.Name, "^CrateStage_") then
			continue
		end
		v36 = v36 + 1
	end
	v31.OwnEffects = v36
	return v31
end
local v_u_38 = {}
v_u_38.__index = v_u_38
function v3.new(p39) -- name: new
	-- upvalues: (copy) v_u_38, (copy) v_u_22
	local v40 = v_u_38
	local v41 = setmetatable({}, v40)
	v41.quality = p39 == "low" and "low" or "high"
	v41.ov = v_u_22()
	v41.own = {}
	v41.entered = false
	v41.guis = {}
	return v41
end
function v_u_38.enter(p42) -- name: enter
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_2
	if not p42.entered then
		p42.entered = true
		local v43 = p42.ov
		for v44, v45 in v_u_6 do
			v43.set(v_u_1, v44, v45)
		end
		local v46 = v_u_1:FindFirstChildOfClass("Atmosphere")
		if v46 then
			for v47, v48 in v_u_7 do
				v43.set(v46, v47, v48)
			end
		else
			local v49 = v_u_7
			v46 = Instance.new("Atmosphere")
			v46.Name = "CrateStage_Atmosphere"
			for v50, v51 in v49 do
				v46[v50] = v51
			end
			v46.Parent = v_u_1
			p42.own.atmo = v46
		end
		p42.atmo = v46
		for _, v52 in { v_u_1, v_u_2.CurrentCamera } do
			if not v52 then
				continue
			end
			for _, v53 in v52:GetChildren() do
				if not v53:IsA("PostEffect") or (not v53.Enabled or string.find(v53.Name, "^CrateStage_")) then
					continue
				end
				v43.set(v53, "Enabled", false)
			end
		end
		local v54 = p42.own
		local v55 = Instance.new("BloomEffect")
		v55.Name = "CrateStage_Bloom"
		for v56, v57 in {
			["Intensity"] = 0.45,
			["Size"] = 22,
			["Threshold"] = 0.95
		} do
			v55[v56] = v57
		end
		v55.Parent = v_u_1
		v54.bloom = v55
		local v58 = p42.own
		local v59 = {
			["Contrast"] = 0.12,
			["Saturation"] = 0.05,
			["Brightness"] = 0,
			["TintColor"] = nil,
			["TintColor"] = Color3.new(1, 1, 1)
		}
		local v60 = Instance.new("ColorCorrectionEffect")
		v60.Name = "CrateStage_Grade"
		for v61, v62 in v59 do
			v60[v61] = v62
		end
		v60.Parent = v_u_1
		v58.grade = v60
	end
end
function v_u_38.step(p63) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if p63.entered then
		p63.ov.apply()
		local v64 = os.clock()
		if v64 - (p63.scanAt or 0) > 0.5 then
			p63.scanAt = v64
			local v65 = game:GetService("Players").LocalPlayer
			if v65 then
				v65 = v65:FindFirstChild("PlayerGui")
			end
			if v65 and p63.guiNames then
				for v66 in p63.guiNames do
					local v67 = v65:FindFirstChild(v66)
					if not (v67 and (v67:IsA("LayerCollector") and v67.Enabled)) then
						continue
					end
					p63.ov.set(v67, "Enabled", false)
				end
			end
			for _, v68 in { v_u_1, v_u_2.CurrentCamera } do
				if not v68 then
					continue
				end
				for _, v69 in v68:GetChildren() do
					if not v69:IsA("PostEffect") or (not v69.Enabled or string.find(v69.Name, "^CrateStage_")) then
						continue
					end
					p63.ov.set(v69, "Enabled", false)
				end
			end
		end
	end
end
function v_u_38.set(p70, p71, p72) -- name: set
	-- upvalues: (copy) v_u_1
	local v73 = p70.own
	if p71 == "bloom" and v73.bloom then
		v73.bloom.Intensity = p72
		return
	elseif p71 == "bloomSize" and v73.bloom then
		v73.bloom.Size = p72
		return
	elseif p71 == "grade" and v73.grade then
		v73.grade.TintColor = p72
		return
	elseif p71 == "contrast" and v73.grade then
		v73.grade.Contrast = p72
		return
	elseif p71 == "saturation" and v73.grade then
		v73.grade.Saturation = p72
		return
	elseif p71 == "brightness" and v73.grade then
		v73.grade.Brightness = p72
		return
	elseif p71 == "atmoColor" and p70.atmo then
		p70.ov.set(p70.atmo, "Color", p72)
		return
	elseif p71 == "atmoDensity" and p70.atmo then
		p70.ov.set(p70.atmo, "Density", p72)
		return
	elseif p71 == "atmoHaze" and p70.atmo then
		p70.ov.set(p70.atmo, "Haze", p72)
	elseif p71 == "exposure" then
		p70.ov.set(v_u_1, "ExposureCompensation", p72)
	end
end
function v_u_38.hideGui(p74, p75) -- name: hideGui
	if p75 and p75:IsA("LayerCollector") then
		p74.ov.set(p75, "Enabled", false)
		local v76 = p74.guis
		table.insert(v76, p75)
		p74.guiNames = p74.guiNames or {}
		p74.guiNames[p75.Name] = true
	end
end
function v_u_38.count(p77) -- name: count
	return p77.ov.count()
end
function v_u_38.leave(p78) -- name: leave
	if p78.entered then
		p78.entered = false
		p78.ov.restore()
		for _, v_u_79 in p78.own do
			pcall(function()
				-- upvalues: (copy) v_u_79
				v_u_79:Destroy()
			end)
		end
		table.clear(p78.own)
		table.clear(p78.guis)
	end
end
return v3