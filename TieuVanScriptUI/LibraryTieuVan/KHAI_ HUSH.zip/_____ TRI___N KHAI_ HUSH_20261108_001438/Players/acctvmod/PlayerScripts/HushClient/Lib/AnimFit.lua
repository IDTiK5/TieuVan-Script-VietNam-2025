-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimFit

local v_u_48 = {
	["MAX_SAMPLES"] = 160,
	["TOLERANCE"] = 0.03,
	["depth"] = function(p1, p2) -- name: depth
		local v3 = p2.inv * p1
		local v4 = p2.half.X
		local v5 = v3.X
		local v6 = v4 - math.abs(v5)
		local v7 = p2.half.Y
		local v8 = v3.Y
		local v9 = v7 - math.abs(v8)
		local v10 = p2.half.Z
		local v11 = v3.Z
		local v12 = v10 - math.abs(v11)
		return (v6 <= 0 or (v9 <= 0 or v12 <= 0)) and 0 or math.min(v6, v9, v12)
	end,
	["bounds"] = function(p13, p14) -- name: bounds
		local v15 = p14 or 0
		local v16 = Vector3.new(inf, inf, inf)
		local v17 = Vector3.new(-inf, -inf, -inf)
		for _, v18 in p13 do
			local v19 = v18.half + Vector3.new(v15, v15, v15)
			for _, v20 in { -1, 1 } do
				for _, v21 in { -1, 1 } do
					for _, v22 in { -1, 1 } do
						local v23 = v18.cf
						local v24 = v19.X * v20
						local v25 = v19.Y * v21
						local v26 = v19.Z * v22
						local v27 = v23 * Vector3.new(v24, v25, v26)
						v16 = v16:Min(v27)
						v17 = v17:Max(v27)
					end
				end
			end
		end
		return v16, v17
	end,
	["worst"] = function(p28, p29, p30, p31, p32) -- name: worst
		-- upvalues: (copy) v_u_48
		if not (p31 and p32) then
			p31, p32 = v_u_48.bounds(p30, 0)
		end
		local v33 = p31.X
		local v34 = p31.Y
		local v35 = p31.Z
		local v36 = p32.X
		local v37 = p32.Y
		local v38 = p32.Z
		local v39 = 0
		local v40 = 0
		local v41 = 0
		for v42, v43 in p29 do
			local v44 = p28 * v43
			if v33 > v44.X or (v44.X > v36 or (v34 > v44.Y or (v44.Y > v37 or (v35 > v44.Z or v44.Z > v38)))) then
				continue
			end
			for v45, v46 in p30 do
				local v47 = v_u_48.depth(v44, v46)
				if v39 >= v47 then
					continue
				end
				v41 = v45
				v40 = v42
				v39 = v47
			end
		end
		return v39, v40, v41
	end
}
local v_u_49 = {}
local function v_u_66(p50, p51) -- name: escape
	local v52 = p51.inv * p50
	local v53 = p51.half.X
	local v54 = v52.X
	local v55 = v53 - math.abs(v54)
	local v56 = p51.half.Y
	local v57 = v52.Y
	local v58 = v56 - math.abs(v57)
	local v59 = p51.half.Z
	local v60 = v52.Z
	local v61 = v59 - math.abs(v60)
	if v55 <= 0 or (v58 <= 0 or v61 <= 0) then
		return nil
	end
	local v62
	if v55 <= v58 and v55 <= v61 then
		if v52.X < 0 then
			v55 = -v55
		end
		v62 = Vector3.new(v55, 0, 0)
	elseif v58 <= v61 then
		local v63 = 0
		if v52.Y < 0 then
			v58 = -v58
		end
		v62 = Vector3.new(v63, v58, 0)
	else
		local v64 = 0
		local v65 = 0
		if v52.Z < 0 then
			v61 = -v61
		end
		v62 = Vector3.new(v64, v65, v61)
	end
	return p51.cf:VectorToWorldSpace(v62)
end
for v67 = -1, 1 do
	for v68 = -1, 1 do
		if v67 == 0 then
			local _ = v68 == 0
		end
		local v69 = Vector3.new(v67, v68, -1).Unit
		table.insert(v_u_49, v69)
		if v67 ~= 0 or v68 ~= 0 then
			local v70 = Vector3.new(v67, v68, 0).Unit
			table.insert(v_u_49, v70)
		end
		if v67 == 0 then
			local _ = v68 == 0
		end
		local v71 = Vector3.new(v67, v68, 1).Unit
		table.insert(v_u_49, v71)
	end
end
for _, v72 in { -1, 1 } do
	for _, v73 in { -1.618033988749895, 1.618033988749895 } do
		local v74 = Vector3.new(0, v72, v73).Unit
		table.insert(v_u_49, v74)
		local v75 = Vector3.new(v72, v73, 0).Unit
		table.insert(v_u_49, v75)
		local v76 = Vector3.new(v73, 0, v72).Unit
		table.insert(v_u_49, v76)
	end
end
function v_u_48.thin(p77, p78) -- name: thin
	-- upvalues: (copy) v_u_48, (copy) v_u_49
	local v79 = p78 or v_u_48.MAX_SAMPLES
	if #p77 <= v79 then
		return p77
	end
	local v80 = {}
	for _, v81 in v_u_49 do
		local v82 = (-1 / 0)
		local v83 = 0
		for v84, v85 in p77 do
			local v86 = v85:Dot(v81)
			if v82 >= v86 then
				continue
			end
			v83 = v84
			v82 = v86
		end
		if v83 <= 0 then
			break
		end
		v80[v83] = true
	end
	local v87 = 0.1
	local v88 = {}
	for _ = 1, 30 do
		local v89 = {}
		v88 = {}
		for v90, v91 in p77 do
			if not v80[v90] then
				continue
			end
			local v92 = v91.X / v87
			local v93 = math.floor(v92)
			local v94 = v91.Y / v87
			local v95 = math.floor(v94)
			local v96 = v91.Z / v87
			v89[v93 .. "," .. v95 .. "," .. math.floor(v96)] = true
		end
		for v97, v98 in p77 do
			if v80[v97] then
				table.insert(v88, v98)
			else
				local v99 = v98.X / v87
				local v100 = math.floor(v99)
				local v101 = v98.Y / v87
				local v102 = math.floor(v101)
				local v103 = v98.Z / v87
				local v104 = v100 .. "," .. v102 .. "," .. math.floor(v103)
				if v89[v104] then
					continue
				end
				v89[v104] = true
				table.insert(v88, v98)
			end
		end
		if #v88 <= v79 then
			break
		end
		local v105 = v87 * 1.25
		v87 = v105
	end
	local v106
	if v79 < #v88 then
		v106 = {}
		for v107 = 1, v79 do
			v106[v107] = v88[v107]
		end
	else
		v106 = v88
	end
	return v106
end
function v_u_48.samplesOf(p108, p109, p110, p111) -- name: samplesOf
	-- upvalues: (copy) v_u_48
	local v112 = p110:Inverse()
	local v113 = {}
	for _, v114 in p108:GetDescendants() do
		if not v114:IsA("BasePart") or (v114 == p109 or (v114.Transparency >= 0.95 or (v114:GetAttribute("SkinPlate") == true or p111 and p111(v114)))) then
			continue
		end
		local v115 = v112 * p109.CFrame:ToObjectSpace(v114.CFrame)
		local v116 = v114.Size / 2
		local v117 = v114.Size.X / 0.45
		local v118 = math.ceil(v117)
		local v119 = math.clamp(v118, 1, 8)
		local v120 = v114.Size.Y / 0.45
		local v121 = math.ceil(v120)
		local v122 = math.clamp(v121, 1, 8)
		local v123 = v114.Size.Z / 0.45
		local v124 = math.ceil(v123)
		local v125 = math.clamp(v124, 1, 8)
		for v126 = 0, v119 do
			for v127 = 0, v122 do
				for v128 = 0, v125 do
					if v126 ~= 0 and (v126 ~= v119 and (v127 ~= 0 and (v127 ~= v122 and (v128 ~= 0 and v128 ~= v125)))) then
						continue
					end
					local v129 = v116.X * (v126 * 2 / v119 - 1)
					local v130 = v116.Y * (v127 * 2 / v122 - 1)
					local v131 = v116.Z * (v128 * 2 / v125 - 1)
					local v132 = v115 * Vector3.new(v129, v130, v131)
					table.insert(v113, v132)
				end
			end
		end
	end
	return v_u_48.thin(v113)
end
local v_u_133 = {
	["UpperTorso"] = "torso",
	["LowerTorso"] = "torso",
	["Head"] = "head",
	["RightUpperLeg"] = "legs",
	["LeftUpperLeg"] = "legs",
	["RightLowerLeg"] = "legs",
	["LeftLowerLeg"] = "legs"
}
function v_u_48.boxesOf(p134, p135, p136) -- name: boxesOf
	-- upvalues: (copy) v_u_133
	local v137 = p136 or 0.04
	local v138 = {}
	for v139, v140 in v_u_133 do
		local v141 = p134(v139)
		local v142 = p135(v139)
		if not (v141 and v142) then
			continue
		end
		local v143 = v141.X / 2 - v137
		local v144 = math.max(0.05, v143)
		local v145 = v141.Y / 2 - v137
		local v146 = math.max(0.05, v145)
		local v147 = v141.Z / 2 - v137
		local v148 = math.max(0.05, v147)
		local v149 = Vector3.new(v144, v146, v148)
		if v139 == "Head" then
			local v150 = v149.X * 0.9
			local v151 = v149.Y * 0.92
			local v152 = v149.Z * 0.9
			v149 = Vector3.new(v150, v151, v152)
		end
		local v153 = {
			["name"] = v139,
			["cf"] = v142,
			["inv"] = v142:Inverse(),
			["half"] = v149,
			["group"] = v140
		}
		table.insert(v138, v153)
	end
	table.sort(v138, function(p154, p155)
		return p154.name < p155.name
	end)
	return v138
end
function v_u_48.pushOut(p156, p157, p158) -- name: pushOut
	-- upvalues: (copy) v_u_66
	for _ = 1, 4 do
		local v159 = false
		for _, v160 in p157 do
			local v161 = v_u_66(p156, {
				["name"] = v160.name,
				["cf"] = v160.cf,
				["inv"] = v160.inv,
				["half"] = v160.half + Vector3.new(p158, p158, p158),
				["group"] = v160.group
			})
			if not v161 then
				continue
			end
			p156 = p156 + v161
			v159 = true
		end
		if v159 then
			break
		end
	end
	return p156
end
local function v_u_191(p162, p163, p164, p165) -- name: pushRadialOne
	local v166 = p163.half + Vector3.new(p164, p164, p164)
	local v167 = p163.inv * p162
	local v168 = v167.X
	local v169 = math.abs(v168) / v166.X
	local v170 = v167.Y
	local v171 = math.abs(v170) / v166.Y
	local v172 = v167.Z
	local v173 = math.abs(v172) / v166.Z
	local v174 = math.max(v169, v173)
	if v174 >= 1 or v171 >= 1 then
		return p162
	end
	local v175 = v167.X
	local v176 = v167.Z
	if v174 < 0.001 then
		v175 = -v166.X * 0.001
		v174 = 0.001
		v176 = 0
	end
	local v177 = 1 / v174
	local v178 = v175 * v177
	local v179 = v167.Y
	local v180 = v176 * v177
	local v181 = Vector3.new(v178, v179, v180)
	local v182 = v166.Y
	local v183 = v167.Y
	local v184 = (v182 - math.abs(v183)) / math.max(p165, 0.001)
	local v185 = math.clamp(v184, 0, 1)
	local v186 = v185 * v185 * (3 - v185 * 2)
	local v187 = v167.X + (v181.X - v167.X) * v186
	local v188 = v167.Y
	local v189 = v167.Z + (v181.Z - v167.Z) * v186
	local v190 = Vector3.new(v187, v188, v189)
	return p163.cf * v190
end
function v_u_48.pushOutRadial(p192, p193, p194, p195) -- name: pushOutRadial
	-- upvalues: (copy) v_u_191
	for _ = 1, 3 do
		local v196 = false
		for _, v197 in p193 do
			local v198 = v_u_191(p192, v197, p194, p195 or 0.35)
			if (v198 - p192).Magnitude <= 0.00001 then
				continue
			end
			p192 = v198
			v196 = true
		end
		if v196 then
			break
		end
	end
	return p192
end
function v_u_48.fit(p199, p200, p201, p202) -- name: fit
	-- upvalues: (copy) v_u_48, (copy) v_u_66
	local v203 = p202.margin or 0.03
	local v204 = p202.maxShift or 1.2
	local v205 = p202.iterations or 8
	local v206 = p202.gripOffset or Vector3.new(0, 0, 0)
	local v207 = {}
	for _, v208 in p201 do
		local v209 = {
			["name"] = v208.name,
			["cf"] = v208.cf,
			["inv"] = v208.inv,
			["half"] = v208.half + Vector3.new(v203, v203, v203),
			["group"] = v208.group
		}
		table.insert(v207, v209)
	end
	local v210, v211 = v_u_48.bounds(v207, 0)
	local v212 = v210.X
	local v213 = v210.Y
	local v214 = v210.Z
	local v215 = v211.X
	local v216 = v211.Y
	local v217 = v211.Z
	local v218 = p202.start or p199
	local v219 = 0
	for v220 = 1, v205 do
		v219 = v220
		local v221 = 0
		local v222 = Vector3.new(0, 0, 0)
		local v223 = false
		for _, v224 in p200 do
			local v225 = v218 * v224
			if v225.X < v212 or (v215 < v225.X or (v225.Y < v213 or (v216 < v225.Y or (v225.Z < v214 or v217 < v225.Z)))) then
				continue
			end
			for _, v226 in v207 do
				local v227 = v_u_66(v225, v226)
				if not v227 then
					continue
				end
				if v221 < v227.Magnitude then
					v221 = v227.Magnitude
				end
				local v228 = v227.X
				local v229 = math.abs(v228)
				local v230 = v222.X
				local v231
				if math.abs(v230) < v229 then
					v231 = v227.X
				else
					v231 = v222.X
				end
				local v232 = v227.Y
				local v233 = math.abs(v232)
				local v234 = v222.Y
				local v235
				if math.abs(v234) < v233 then
					v235 = v227.Y
				else
					v235 = v222.Y
				end
				local v236 = v227.Z
				local v237 = math.abs(v236)
				local v238 = v222.Z
				local v239
				if math.abs(v238) < v237 then
					v239 = v227.Z
				else
					v239 = v222.Z
				end
				v222 = Vector3.new(v231, v235, v239)
			end
		end
		if v221 > 0.004 then
			v218 = v218 + v222 * 0.85
			v223 = true
		end
		local v240 = v218 * v206 - p202.shoulderR
		local v241 = v240.Magnitude - p202.reachR
		if v241 > 0.01 then
			v218 = v218 - v240.Unit * v241
			v223 = true
		end
		if p202.shoulderL and (p202.reachL and p202.support) then
			local v242 = v218 * p202.support - p202.shoulderL
			local v243 = v242.Magnitude - p202.reachL
			if v243 > 0.04 then
				v218 = v218 - v242.Unit * v243 * 0.6
				v223 = true
			end
		end
		local v244 = v218.Position - p199.Position
		if v204 < v244.Magnitude then
			v218 = v218 - v244.Unit * (v244.Magnitude - v204)
		end
		if v223 then
			break
		end
	end
	local v245
	if v_u_48.worst(v218, p200, p201, v210, v211) <= v_u_48.TOLERANCE and (v218.Position - p199.Position).Magnitude > 0.02 then
		v245 = v218
		local v246 = 0
		local v247 = 1
		for _ = 1, 3 do
			local v248 = (v246 + v247) / 2
			local v249 = p199:Lerp(v218, v248)
			if v_u_48.worst(v249, p200, p201, v210, v211) <= v_u_48.TOLERANCE then
				v245 = v249
				v247 = v248
			else
				v246 = v248
			end
		end
	else
		v245 = v218
	end
	local v250, v251, v252 = v_u_48.worst(v245, p200, p201, v210, v211)
	local v253 = (v245 * v206 - p202.shoulderR).Magnitude
	local v254 = not (p202.shoulderL and p202.support) and 0 or (v245 * p202.support - p202.shoulderL).Magnitude
	local v255 = {
		["depth"] = v250,
		["shift"] = (v245.Position - p199.Position).Magnitude,
		["iterations"] = v219,
		["reachR"] = v253,
		["reachL"] = v254
	}
	local v256
	if v250 <= v_u_48.TOLERANCE and v253 <= p202.reachR + 0.02 then
		v256 = v254 == 0 and true or v254 <= (p202.reachL or 0) + 0.05
	else
		v256 = false
	end
	v255.ok = v256
	local v257
	if v252 > 0 then
		v257 = p201[v252].group
	else
		v257 = nil
	end
	v255.group = v257
	v255.sample = v251
	return v245, v255
end
return v_u_48