-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlay

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = {}
local v_u_4 = v_u_2.LocalPlayer
local v_u_5 = {
	{
		["id"] = "Normal",
		["line"] = "The town as it is",
		["sub"] = "The town as it is. Raids last 20 min. Bites turn you in 6 min.",
		["tags"] = nil,
		["tags"] = { "Standard infected", "Standard loot", "20 min raid" }
	},
	{
		["id"] = "Hard",
		["line"] = "More, faster infected",
		["sub"] = "More of them, and faster. Raids last 23 min. Bites turn you in 4.5 min.",
		["tags"] = nil,
		["tags"] = {
			"+81% infected",
			"More runners",
			"Scratches infect",
			"Boss active",
			"+3 min raid time",
			"More ammo at dusk and night"
		}
	},
	{
		["id"] = "Nightmare",
		["line"] = "Night only, fast bites",
		["sub"] = "Only at night. Raids last 25 min. Bites turn you in 4 min.",
		["tags"] = nil,
		["tags"] = {
			"Night only",
			"+125% infected",
			"Scratches infect",
			"Two bosses",
			"+5 min raid time",
			"More ammo per find"
		}
	}
}
local v_u_6 = {
	["Normal"] = {
		["sub"] = "Common to rare finds. Epic gear is rare, no legendary gear, no gold.",
		["gold"] = "None",
		["fact"] = "Epic gear rare, no legendary, no gold"
	},
	["Hard"] = {
		["sub"] = "Epic and legendary gear, rare gold guns, hazard pay %d%%.",
		["gold"] = "Rare",
		["fact"] = "Epic and legendary gear, rare gold guns"
	},
	["Nightmare"] = {
		["sub"] = "Most epic and legendary gear, the best chance of gold guns, hazard pay %d%%.",
		["gold"] = "Best chance",
		["fact"] = "Most epic and legendary gear, best gold odds"
	}
}
local v_u_7 = {}
local v8 = {
	["id"] = "Day",
	["text"] = "Day",
	["odds"] = "Clear view",
	["effect"] = "Daylight: you see far and spot the infected early. Fewest runners.",
	["tip"] = nil,
	["tip"] = {
		["title"] = "DAY",
		["body"] = "Full daylight. You see far and spot the infected early.",
		["lines"] = nil,
		["lines"] = {
			{
				["label"] = "Your sight",
				["value"] = "Far"
			},
			{
				["label"] = "Runners",
				["value"] = "Few"
			},
			{
				["label"] = "Loot",
				["value"] = "Standard"
			},
			{
				["label"] = "Rare night finds",
				["value"] = "Few"
			}
		}
	}
}
local v9 = {
	["id"] = "Dusk",
	["text"] = "Dusk",
	["odds"] = "Fading light",
	["effect"] = "Low sun: you see less far. More runners, slightly better loot, some night finds.",
	["tip"] = nil,
	["tip"] = {
		["title"] = "DUSK",
		["body"] = "The sun is low and the street lamps come on. You see less far and more runners are out. Suppressors, weapon lights, AP rounds and jewelry turn up more often.",
		["lines"] = nil,
		["lines"] = {
			{
				["label"] = "Your sight",
				["value"] = "Medium"
			},
			{
				["label"] = "Runners",
				["value"] = "More"
			},
			{
				["label"] = "Loot",
				["value"] = "A bit better"
			},
			{
				["label"] = "Rare night finds",
				["value"] = "More"
			},
			{
				["label"] = "Ammo (Hard, Nightmare)",
				["value"] = "+30%"
			}
		}
	}
}
local v10 = {
	["id"] = "Night",
	["text"] = "Night",
	["odds"] = "Pitch dark",
	["effect"] = "Dark: you need your flashlight, which also gives you away. Most runners, best loot, rare night finds.",
	["tip"] = nil,
	["tip"] = {
		["title"] = "NIGHT",
		["body"] = "Dark streets. The infected see less far in the dark, but a lit flashlight gives you away from further off. Suppressors, weapon lights, AP rounds and jewelry turn up far more often.",
		["lines"] = nil,
		["lines"] = {
			{
				["label"] = "Your sight",
				["value"] = "Short"
			},
			{
				["label"] = "Runners",
				["value"] = "Many"
			},
			{
				["label"] = "Loot",
				["value"] = "Best"
			},
			{
				["label"] = "Rare night finds",
				["value"] = "Many"
			},
			{
				["label"] = "Ammo (Hard, Nightmare)",
				["value"] = "+50%"
			}
		}
	}
}
__set_list(v_u_7, 1, {{
	["id"] = "Any",
	["text"] = "Any",
	["odds"] = "Random",
	["effect"] = "The director picks day, dusk or night when the raid starts.",
	["tip"] = nil,
	["tip"] = {
		["title"] = "ANY TIME",
		["body"] = "The director picks the time when the raid starts: day 4 in 10 raids, dusk and night 3 in 10 each."
	}
}, v8, v9, v10})
local v_u_11 = {
	{ "primary", "Primary" },
	{ "secondary", "Sidearm" },
	{ "melee", "Melee" },
	{ "armor", "Armor" },
	{ "helmet", "Helmet" },
	{ "bag", "Backpack" },
	{ "secure", "Secure case" }
}
local v_u_12 = nil
local function v13()
	-- upvalues: (ref) v_u_12
	v_u_12 = require((script.Parent:WaitForChild("MenuSearch", 5)))
end
pcall(v13)
v_u_3.REGION_NAMES = {
	["NA"] = "North America",
	["SA"] = "South America",
	["EU"] = "Europe",
	["AS"] = "Asia",
	["OC"] = "Oceania",
	["MEA"] = "Middle East & Africa"
}
v_u_3.MAP_ANSWER_WAIT = 10
function v_u_3.partyNotice(p14) -- name: partyNotice
	if type(p14) == "table" then
		return p14.notice
	else
		return nil
	end
end
function v_u_3.mapSyncStep(p15, p16, p17, p18) -- name: mapSyncStep
	-- upvalues: (copy) v_u_3
	if type(p15) ~= "table" then
		return "none"
	end
	if p16 == p15.id then
		return "accepted"
	end
	if type(p17) == "table" and (p17 ~= p15.notice and (p17.code == "map_refused" and p17.mapId == p15.id)) then
		return "refused"
	end
	local v19 = p15.at
	return p18 - (tonumber(v19) or 0) >= v_u_3.MAP_ANSWER_WAIT and "timeout" or "wait"
end
function v_u_3.new(p_u_20, p_u_21) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (ref) v_u_12, (copy) v_u_6, (copy) v_u_5, (copy) v_u_7, (copy) v_u_11, (copy) v_u_1, (copy) v_u_3
	local v22 = game:GetService("RunService")
	local v_u_23 = p_u_20.ui
	local v_u_24 = p_u_20.theme
	local v_u_25 = v_u_24.color
	local v_u_26 = p_u_20.kit
	local v_u_27 = p_u_20.compact()
	local v_u_47 = {
		["why"] = function() -- name: why
			-- upvalues: (copy) v_u_47, (copy) p_u_20
			if v_u_47.whyMod then
				return v_u_47.whyMod
			else
				local function v28()
					-- upvalues: (ref) p_u_20
					return p_u_20.cctx.lib.PlayWhy
				end
				local v29, v30 = pcall(v28)
				if v29 and type(v30) == "table" then
					v_u_47.whyMod = v30
					return v30
				else
					warn("[MenuPlay] lib missing: PlayWhy")
					return {}
				end
			end
		end,
		["pv"] = function() -- name: pv
			-- upvalues: (copy) v_u_47, (copy) p_u_20
			if v_u_47.pvMod == nil then
				local function v31()
					-- upvalues: (ref) p_u_20
					return p_u_20.cctx.lib.MenuPlayPvpve
				end
				local v32, v33 = pcall(v31)
				local v34 = v_u_47
				if not v32 or type(v33) ~= "table" then
					v33 = false
				end
				v34.pvMod = v33
			end
			return v_u_47.pvMod
		end,
		["pvHard"] = function() -- name: pvHard
			-- upvalues: (copy) v_u_47
			local v35 = v_u_47.pv()
			local v36
			if v35 == false then
				v36 = false
			else
				v36 = v35.hardOnly() == true
			end
			return v36
		end,
		["pvPublic"] = function() -- name: pvPublic
			-- upvalues: (copy) v_u_47
			local v37 = v_u_47.pv()
			local v38
			if v37 == false then
				v38 = false
			else
				v38 = v37.publicOnly() == true
			end
			return v38
		end,
		["pvFacts"] = function(p39) -- name: pvFacts
			-- upvalues: (copy) v_u_47
			if v_u_47.pvHard() then
				return v_u_47.pv().facts(p39)
			else
				return p39
			end
		end,
		["timeLocked"] = function() -- name: timeLocked
			-- upvalues: (copy) p_u_20
			local function v40()
				-- upvalues: (ref) p_u_20
				return p_u_20.cctx.shared.GameMode.rule("timeChoice")
			end
			local v41, v42 = pcall(v40)
			if v41 then
				v41 = v42 == false
			end
			return v41
		end,
		["lockedTime"] = function(p_u_43) -- name: lockedTime
			-- upvalues: (copy) p_u_20
			local function v44()
				-- upvalues: (ref) p_u_20, (copy) p_u_43
				return p_u_20.cctx.shared.TimeRule.resolve(false, p_u_20.cctx.shared.GameMode.rule("lockedTime"), p_u_43, nil)
			end
			local v45, v46 = pcall(v44)
			if v45 and type(v46) == "string" then
				return v46
			else
				return p_u_43
			end
		end
	}
	local v_u_48 = {
		["difficulty"] = "Normal",
		["timeOfDay"] = "Any",
		["freeRaid"] = false,
		["mapId"] = "stillwater",
		["privateRaid"] = false,
		["privateFriends"] = false,
		["privTouched"] = false,
		["raidTouched"] = false
	}
	if v_u_47.pvHard() then
		v_u_48.difficulty = "Hard"
	end
	local v_u_49 = 0
	local v_u_50 = nil
	local v_u_51 = ""
	local v_u_52 = {}
	local v53 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
	local v54 = p_u_20.playColW
	local v_u_55
	if type(v54) == "function" then
		v_u_55 = p_u_20.playColW()
	else
		v_u_55 = v_u_27 and 440 or 520
	end
	local v_u_56 = v_u_23.new("Frame", {
		["Name"] = "Column",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -24, 0, 8),
		["Size"] = UDim2.new(0, v_u_55, 1, -8)
	}, p_u_21)
	local v57 = v_u_24.isPhone
	local v58 = (type(v57) == "function" and v_u_24.isPhone() and 18 or 38) + 12 + 4 + v_u_24.touch(v_u_27 and 44 or 56) + 14
	local v_u_59 = math.max(v_u_27 and 104 or 132, v58)
	local v_u_60 = v_u_23.list({
		["parent"] = nil,
		["name"] = "Scroll",
		["size"] = nil,
		["gap"] = nil,
		["parent"] = v_u_56,
		["size"] = UDim2.new(1, 9, 1, -v_u_59 - 12),
		["gap"] = v_u_27 and 8 or 16
	})
	if not pcall(function()
		-- upvalues: (copy) v_u_47, (copy) p_u_20, (copy) v_u_56, (copy) v_u_60, (copy) v_u_55, (copy) v_u_59, (copy) p_u_21
		local v61 = {
			["col"] = v_u_56,
			["scroll"] = v_u_60,
			["colW"] = v_u_55,
			["dockH"] = v_u_59
		}
		v_u_47.sheet = p_u_20.cctx.lib.MenuPlaySheet.attach(p_u_20, v_u_47, v61)
		local v62 = {
			["col"] = v_u_56,
			["colW"] = v_u_55,
			["dockH"] = v_u_59
		}
		v_u_47.brief = p_u_20.cctx.lib.MenuPlayBrief.attach(p_u_20, p_u_21, v_u_47, v62)
	end) or (v_u_47.sheet == nil or v_u_47.brief == nil) then
		if v_u_47.sheet then
			local v63 = v_u_47.sheet.destroy
			pcall(v63, true)
		end
		if v_u_47.brief then
			local v64 = v_u_47.brief.destroy
			pcall(v64)
		end
		v_u_47.sheet = nil
		v_u_47.brief = nil
		v_u_60.Parent = v_u_56
		v_u_60.Size = UDim2.new(1, 9, 1, -v_u_59 - 12)
	end
	local v_u_65 = v_u_24.space.m
	local function v70(p66, p67, p68) -- name: section
		-- upvalues: (copy) v_u_26, (copy) v_u_60, (copy) v_u_23, (copy) v_u_65
		local v69 = v_u_26.section(v_u_60, p66, p67, p68)
		v_u_23.pad(v69, {
			v_u_65 - 12,
			v_u_65,
			0,
			0
		})
		return v69
	end
	local v_u_71 = nil
	local v72, v73 = pcall(function()
		-- upvalues: (copy) p_u_20
		return p_u_20.cctx.lib.MenuTutorialCard
	end)
	if v72 and type(v73) == "table" then
		local v74 = v73.new
		if type(v74) == "function" then
			local v75 = v73.new
			local v76
			if v_u_47.brief then
				v76 = v_u_47.brief.host("tutorial")
			else
				v76 = v_u_60
			end
			local v77 = v_u_47.brief and {
				["form"] = "row"
			} or nil
			local v78, v79 = pcall(v75, p_u_20, v76, 0, v77)
			if v78 then
				v_u_71 = v79
			else
				warn("[MenuPlay] tutorial card failed:", v79)
				v_u_4:SetAttribute("ClientError", "menu tutorial card: " .. tostring(v79))
			end
		end
	end
	p_u_20.tutorialCard = v_u_71
	function v_u_47.firstRaidGate() -- name: firstRaidGate
		-- upvalues: (copy) p_u_20, (copy) v_u_47
		local function v80()
			-- upvalues: (ref) p_u_20
			return p_u_20.cctx.lib.MenuTutorialCard
		end
		local v81, v82 = pcall(v80)
		if v81 and type(v82) == "table" then
			local v83 = v82.gateDeploy
			if type(v83) == "function" then
				local v84 = v82.gateDeploy
				local v85 = p_u_20
				local function v86()
					-- upvalues: (ref) v_u_47
					v_u_47.deploy()
				end
				local v87, v88 = pcall(v84, v85, v86)
				if v87 then
					v87 = v88 == true
				end
				return v87
			end
		end
		return false
	end
	local v_u_89 = nil
	local function v90()
		-- upvalues: (ref) v_u_89, (copy) p_u_20
		v_u_89 = p_u_20.cctx.shared.Maps
	end
	pcall(v90)
	local v_u_91
	if v_u_89 then
		local v92 = v_u_89.LIST
		v_u_91 = (type(v92) ~= "table" or #v_u_89.LIST <= 0) and {
			{
				["id"] = "stillwater",
				["name"] = "Stillwater",
				["tagline"] = "Quarantine zone, Wabash County",
				["size"] = "Small town",
				["raidMinutes"] = 20,
				["maxSurvivors"] = 12,
				["enabled"] = true
			}
		} or v_u_89.LIST
	else
		v_u_91 = {
			{
				["id"] = "stillwater",
				["name"] = "Stillwater",
				["tagline"] = "Quarantine zone, Wabash County",
				["size"] = "Small town",
				["raidMinutes"] = 20,
				["maxSurvivors"] = 12,
				["enabled"] = true
			}
		}
	end
	local v_u_93 = nil
	local function v94()
		-- upvalues: (ref) v_u_93, (copy) p_u_20
		v_u_93 = p_u_20.cctx.shared.MapUnlock
	end
	pcall(v94)
	local function v_u_118(p95) -- name: raidLock
		-- upvalues: (ref) v_u_89, (ref) v_u_93, (ref) v_u_4, (copy) v_u_47, (copy) p_u_20, (ref) v_u_2
		if v_u_89 then
			local v96 = v_u_89.accessFor
			if type(v96) == "function" and (v_u_93 and p95.enabled ~= true) then
				local v97 = v_u_89.accessFor
				local v98 = v_u_4
				local v99, v100 = pcall(v97, p95, v98)
				if not v99 or type(v100) ~= "table" then
					return nil
				end
				if v100.ok == true then
					local v101 = p_u_20.myParty()
					if v101 ~= nil and (#v101.members > 1 and p_u_20.isLeader()) then
						for _, v102 in v101.members do
							local v103
							if v102.userId == v_u_4.UserId then
								v103 = nil
							else
								local v104 = v_u_2
								local v105 = v102.userId
								v103 = v104:GetPlayerByUserId(tonumber(v105) or 0)
							end
							if not v103 then
								continue
							end
							local v106 = v_u_89.accessFor
							local v107, v108 = pcall(v106, p95, v103)
							if not v107 or (type(v108) ~= "table" or (v108.ok == true or v108.why ~= "raids" and (v108.why ~= "unreadable" and v108.why ~= "quest"))) then
								continue
							end
							local v109 = v_u_93.card
							local v110 = v_u_47.displayName
							local v111 = v109(v108, (tostring(v110(p95))))
							local v112 = v102.displayName or (v102.name or "A member")
							local v113 = tostring(v112)
							v111.who = "mate"
							v111.mate = v113
							local v114
							if v108.why == "raids" then
								v114 = v_u_93.shortLine(v113, v108.short or 1)
							elseif v108.why == "quest" then
								v114 = v_u_93.memberQuestLine(v113, v108.missing)
							else
								v114 = v113 .. " cannot enter yet"
							end
							v111.line = v114
							return v111
						end
					end
					return nil
				end
				if v100.why ~= "raids" and (v100.why ~= "unreadable" and v100.why ~= "quest") then
					return nil
				end
				local v115 = v_u_93.card
				local v116 = v_u_47.displayName
				local v117 = v115(v100, (tostring(v116(p95))))
				v117.who = "self"
				v117.line = v117.lockText
				return v117
			end
		end
		return nil
	end
	local function v_u_134(p119) -- name: access
		-- upvalues: (copy) v_u_47, (ref) v_u_89, (ref) v_u_4, (copy) v_u_118
		if p119.enabled == true then
			return "open"
		end
		local v120, v121, v122, v123, v124, v125, v126, v127
		if v_u_47.rotation then
			local v128
			if v_u_89 then
				local v129 = v_u_89.isOpenFor
				if type(v129) == "function" then
					local v130 = v_u_89.isOpenFor
					local v131 = v_u_4
					local v132, v133 = pcall(v130, p119, v131)
					if v132 then
						if v133 == true then
							v128 = v_u_118(p119) == nil
						else
							v128 = false
						end
						if v128 then
							return "open"
						else
							v120 = p119.gate
							if type(v120) ~= "string" then
								return "soon"
							end
							v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
							if v121 and v121:GetAttribute("MapGate_" .. p119.gate) == true then
								return v_u_118(p119) and "raids" or "open"
							end
							if not v_u_89 then
								v122 = p119.enabled == true
								return v122 and "test" or "locked"
							end
							v123 = v_u_89.isOpenFor
							if type(v123) == "function" then
								v124 = v_u_89.isOpenFor
								v125 = v_u_4
								v126, v127 = pcall(v124, p119, v125)
								if v126 then
									if v127 == true then
										v122 = v_u_118(p119) == nil
									else
										v122 = false
									end
									return v122 and "test" or "locked"
								else
									v122 = p119.enabled == true
									return v122 and "test" or "locked"
								end
							else
								v122 = p119.enabled == true
								return v122 and "test" or "locked"
							end
						end
					else
						v128 = p119.enabled == true
						if v128 then
							return "open"
						else
							v120 = p119.gate
							if type(v120) ~= "string" then
								return "soon"
							end
							v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
							if v121 and v121:GetAttribute("MapGate_" .. p119.gate) == true then
								return v_u_118(p119) and "raids" or "open"
							end
							if not v_u_89 then
								v122 = p119.enabled == true
								return v122 and "test" or "locked"
							end
							v123 = v_u_89.isOpenFor
							if type(v123) == "function" then
								v124 = v_u_89.isOpenFor
								v125 = v_u_4
								v126, v127 = pcall(v124, p119, v125)
								if v126 then
									if v127 == true then
										v122 = v_u_118(p119) == nil
									else
										v122 = false
									end
									return v122 and "test" or "locked"
								else
									v122 = p119.enabled == true
									return v122 and "test" or "locked"
								end
							else
								v122 = p119.enabled == true
								return v122 and "test" or "locked"
							end
						end
					end
				else
					v128 = p119.enabled == true
					if v128 then
						return "open"
					else
						v120 = p119.gate
						if type(v120) ~= "string" then
							return "soon"
						end
						v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
						if v121 and v121:GetAttribute("MapGate_" .. p119.gate) == true then
							return v_u_118(p119) and "raids" or "open"
						end
						if not v_u_89 then
							v122 = p119.enabled == true
							return v122 and "test" or "locked"
						end
						v123 = v_u_89.isOpenFor
						if type(v123) == "function" then
							v124 = v_u_89.isOpenFor
							v125 = v_u_4
							v126, v127 = pcall(v124, p119, v125)
							if v126 then
								if v127 == true then
									v122 = v_u_118(p119) == nil
								else
									v122 = false
								end
								return v122 and "test" or "locked"
							else
								v122 = p119.enabled == true
								return v122 and "test" or "locked"
							end
						else
							v122 = p119.enabled == true
							return v122 and "test" or "locked"
						end
					end
				end
			else
				v128 = p119.enabled == true
				if v128 then
					return "open"
				else
					v120 = p119.gate
					if type(v120) ~= "string" then
						return "soon"
					end
					v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
					if v121 and v121:GetAttribute("MapGate_" .. p119.gate) == true then
						return v_u_118(p119) and "raids" or "open"
					end
					if not v_u_89 then
						v122 = p119.enabled == true
						return v122 and "test" or "locked"
					end
					v123 = v_u_89.isOpenFor
					if type(v123) == "function" then
						v124 = v_u_89.isOpenFor
						v125 = v_u_4
						v126, v127 = pcall(v124, p119, v125)
						if v126 then
							if v127 == true then
								v122 = v_u_118(p119) == nil
							else
								v122 = false
							end
							return v122 and "test" or "locked"
						else
							v122 = p119.enabled == true
							return v122 and "test" or "locked"
						end
					else
						v122 = p119.enabled == true
						return v122 and "test" or "locked"
					end
				end
			end
		else
			v120 = p119.gate
			if type(v120) ~= "string" then
				return "soon"
			end
			v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
			if v121 and v121:GetAttribute("MapGate_" .. p119.gate) == true then
				return v_u_118(p119) and "raids" or "open"
			end
			if not v_u_89 then
				v122 = p119.enabled == true
				return v122 and "test" or "locked"
			end
			v123 = v_u_89.isOpenFor
			if type(v123) == "function" then
				v124 = v_u_89.isOpenFor
				v125 = v_u_4
				v126, v127 = pcall(v124, p119, v125)
				if v126 then
					if v127 == true then
						v122 = v_u_118(p119) == nil
					else
						v122 = false
					end
					return v122 and "test" or "locked"
				else
					v122 = p119.enabled == true
					return v122 and "test" or "locked"
				end
			else
				v122 = p119.enabled == true
				return v122 and "test" or "locked"
			end
		end
	end
	local function v_u_154(p135) -- name: mapDef
		-- upvalues: (copy) v_u_91, (ref) v_u_89, (ref) v_u_4, (copy) v_u_118
		-- block 32
		for _, v136 in v_u_91 do
			if v136.id ~= p135 then
				continue
			end
			local v137
			if v_u_89 then
				local v138 = v_u_89.isOpenFor
				if type(v138) == "function" then
					local v139 = v_u_89.isOpenFor
					local v140 = v_u_4
					local v141, v142 = pcall(v139, v136, v140)
					if v141 then
						if v142 == true then
							v137 = v_u_118(v136) == nil
						else
							v137 = false
						end
						if not v137 then
							continue
						end
						return v136
					else
						v137 = v136.enabled == true
						if not v137 then
							continue
						end
						return v136
					end
				else
					v137 = v136.enabled == true
					if not v137 then
						continue
					end
					return v136
				end
			else
				v137 = v136.enabled == true
				if not v137 then
					continue
				end
				return v136
			end
		end
		local v143, v144, v145
		-- GenericForInit
v143, v144, v145 = v_u_91, nil, nil
[internal control] = v145
-- end GenericForInit
		local v146, v147
		-- GenericForNext
v146, v147 = v143(v144, [internal control])
if v146 ~= nil
[internal control] = v146
-- end GenericForNext
		-- block 2
		goto l31
		::l17::
		local v148
		if v_u_89 then
			local v149 = v_u_89.isOpenFor
			if type(v149) == "function" then
				local v150 = v_u_89.isOpenFor
				local v151 = v_u_4
				local v152, v153 = pcall(v150, v147, v151)
				if v152 then
					if v153 == true then
						v148 = v_u_118(v147) == nil
					else
						v148 = false
					end
					if not v148 then
						continue
					end
					return v147
				else
					v148 = v147.enabled == true
					if not v148 then
						continue
					end
					return v147
				end
			else
				v148 = v147.enabled == true
				if not v148 then
					continue
				end
				return v147
			end
		else
			v148 = v147.enabled == true
			if not v148 then
				continue
			end
			return v147
		end
		-- block 18
		goto l17
		::l31::
		return v_u_91[1]
	end
	local function v_u_160() -- name: squadMap
		-- upvalues: (copy) p_u_20, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154
		local v155 = p_u_20.myParty()
		local v156
		if v155 == nil or #v155.members <= 1 then
			v156 = false
		else
			v156 = not p_u_20.isLeader()
		end
		if not v156 then
			return v_u_154(v_u_48.mapId)
		end
		local v157 = v_u_48.mapId
		for _, v159 in v_u_91 do
			if v159.id ~= v157 then
				continue
			end
		end
		local v159 = nil
		return v159 or v_u_154(v_u_48.mapId)
	end
	local function v_u_173(p161) -- name: mapStats
		-- upvalues: (copy) p_u_20, (copy) v_u_48, (ref) v_u_12
		if p161.teaser == true then
			local v162 = p161.size or "Unknown"
			return ("%s  \194\183  details follow"):format((tostring(v162)))
		end
		local v_u_163 = 0
		local function v166()
			-- upvalues: (ref) v_u_163, (ref) p_u_20, (ref) v_u_48
			local v164 = p_u_20.cctx.shared.Difficulty.extraMinutes
			local v165 = v_u_48.difficulty
			v_u_163 = tonumber(v164(v165)) or 0
		end
		pcall(v166)
		local function v167()
			-- upvalues: (ref) p_u_20
			return p_u_20.cctx.shared.GameMode.isPvpve()
		end
		local v168, v169 = pcall(v167)
		local v170 = p161.size or "Town"
		local v171 = tostring(v170)
		local v172 = p161.raidMinutes
		return ("%s  \194\183  %d min raid  \194\183  up to %d survivors  \194\183  %s"):format(v171, (tonumber(v172) or 20) + v_u_163, v_u_12 and v_u_12.seatsFor(p161.maxSurvivors) or 12, v168 and v169 == true and "PvPvE" or "PvE")
	end
	v_u_48.mapId = v_u_154(v_u_89 and (v_u_89.DEFAULT or "stillwater") or "stillwater").id
	local v_u_174 = v_u_48.mapId
	local function v_u_176() -- name: viewDef
		-- upvalues: (copy) v_u_91, (ref) v_u_174, (copy) v_u_154, (copy) v_u_48
		for _, v175 in v_u_91 do
			if v175.id ~= v_u_174 then
				continue
			end
			return v175
		end
		return v_u_154(v_u_48.mapId)
	end
	function v_u_47.stateWords(p177, p178, p179) -- name: stateWords
		-- upvalues: (copy) v_u_47
		local v180 = p177 == "open" and true or p177 == "test"
		local v181 = v_u_47.why().gateWords(p177)
		local v182 = v181.tag
		local v183
		if p178 and v180 then
			v183 = p177 == "test" and "Selected \194\183 test access" or "Selected"
		elseif p177 == "test" then
			v183 = "Test access"
		elseif v180 then
			v183 = "Open"
		elseif p179 then
			v183 = p179.stateText or p179.progressText
		else
			v183 = v181.row
		end
		local v184
		if p177 == "open" then
			v184 = p178 and "SELECTED" or "OPEN"
		else
			v184 = v181.chip
		end
		return v184, v183, v182
	end
	function v_u_47.displayName(p185) -- name: displayName
		-- upvalues: (copy) p_u_20
		local v_u_186 = nil
		local function v187()
			-- upvalues: (ref) v_u_186, (ref) p_u_20
			v_u_186 = p_u_20.cctx.shared.MapReveal
		end
		pcall(v187)
		if v_u_186 then
			local v188 = v_u_186.fields
			if type(v188) == "function" then
				local v189 = v_u_186.fields(p185, v_u_186.clientRevealed() == true).name
				return tostring(v189)
			end
		end
		local v190 = p185.name
		return tostring(v190)
	end
	function v_u_47.describePin(p191) -- name: describePin
		-- upvalues: (copy) p_u_20, (ref) v_u_89, (copy) v_u_134, (copy) v_u_118, (copy) v_u_48, (ref) v_u_4, (copy) v_u_47, (copy) v_u_91, (ref) v_u_174
		local v_u_192 = nil
		local v_u_193 = nil
		local function v194()
			-- upvalues: (ref) v_u_192, (ref) p_u_20, (ref) v_u_193
			v_u_192 = p_u_20.cctx.shared.MapReveal
			v_u_193 = p_u_20.cctx.shared.GlobeText
		end
		pcall(v194)
		local v195
		if v_u_192 == nil then
			v195 = false
		else
			local v196 = v_u_192.clientRevealed
			if type(v196) == "function" then
				v195 = v_u_192.clientRevealed() == true
			else
				v195 = false
			end
		end
		local v197
		if v_u_89 == nil then
			v197 = false
		else
			local v198 = v_u_89.hiddenFor
			if type(v198) == "function" then
				v197 = v_u_89.hiddenFor(p191, v195) == true
			else
				v197 = false
			end
		end
		local v199 = p191.county or ""
		local v200 = tostring(v199)
		if v_u_192 then
			local v201 = v_u_192.fields
			if type(v201) == "function" then
				local v202 = v_u_192.fields(p191, v195).county
				v200 = tostring(v202)
			end
		end
		local v203 = v_u_134(p191)
		local v204
		if v203 == "raids" then
			v204 = v_u_118(p191)
		else
			v204 = nil
		end
		local v205, v206, v207, v208, v209, v210, v211, v212, v213, v214, v215, v216, v217, v218, v219, v220, v221
		if p191.id == v_u_48.mapId then
			if v_u_89 then
				local v222 = v_u_89.isOpenFor
				if type(v222) == "function" then
					local v223 = v_u_89.isOpenFor
					local v224 = v_u_4
					local v225, v226 = pcall(v223, p191, v224)
					if v225 then
						if v226 == true then
							v205 = v_u_118(p191) == nil
						else
							v205 = false
						end
						v206 = v_u_47.stateWords(v203, v205, v204)
						v207 = p_u_20.myParty()
						if v207 == nil then
							v208 = false
						else
							v209 = v207.searching
							v208 = type(v209) == "table"
						end
						v210 = p_u_20.myParty()
						if v210 == nil or #v210.members <= 1 then
							v211 = false
						else
							v211 = not p_u_20.isLeader()
						end
						v212 = v_u_193
						v213 = 1
						for v231, v232 in v_u_91 do
							if v232.id ~= p191.id then
								continue
							end
							v213 = v231
						end
						v214 = {
							["id"] = p191.id,
							["name"] = v_u_47.displayName(p191),
							["hidden"] = v197,
							["geo"] = p191.geo,
							["fuzz"] = p191.fuzz,
							["place"] = v200,
							["underground"] = p191.underground == true,
							["site"] = p191.site,
							["state"] = v203,
							["chip"] = v206
						}
						if v204 then
							v215 = v204.line
							v216 = tostring(v215)
						else
							v216 = ""
						end
						v214.line = v216
						if v204 then
							v217 = v204.frac
							v218 = tonumber(v217) or 0
						else
							v218 = 0
						end
						v214.progress = v218
						if v204 then
							v219 = v204.progressText
							v220 = tostring(v219)
						else
							v220 = ""
						end
						v214.progressText = v220
						v214.deploy = v205
						v214.viewing = p191.id == v_u_174
						v214.frozen = v208 or v211
						if v208 then
							v221 = not v212 and "Locked while searching. Stop the search to change." or v212.SEARCH
						elseif v211 then
							v221 = not v212 and "The squad leader picks the area." or v212.MEMBER
						else
							v221 = nil
						end
						v214.why = v221
						v214.order = v213
						return v214
					end
					v205 = p191.enabled == true
				else
					v205 = p191.enabled == true
				end
			else
				v205 = p191.enabled == true
			end
			v206 = v_u_47.stateWords(v203, v205, v204)
			v207 = p_u_20.myParty()
			if v207 == nil then
				v208 = false
			else
				v209 = v207.searching
				v208 = type(v209) == "table"
			end
			v210 = p_u_20.myParty()
			if v210 == nil or #v210.members <= 1 then
				v211 = false
			else
				v211 = not p_u_20.isLeader()
			end
			v212 = v_u_193
			v213 = 1
			for v231, v232 in v_u_91 do
				if v232.id ~= p191.id then
					continue
				end
				v213 = v231
			end
			v214 = {
				["id"] = p191.id,
				["name"] = v_u_47.displayName(p191),
				["hidden"] = v197,
				["geo"] = p191.geo,
				["fuzz"] = p191.fuzz,
				["place"] = v200,
				["underground"] = p191.underground == true,
				["site"] = p191.site,
				["state"] = v203,
				["chip"] = v206
			}
			if v204 then
				v215 = v204.line
				v216 = tostring(v215)
			else
				v216 = ""
			end
			v214.line = v216
			if v204 then
				v217 = v204.frac
				v218 = tonumber(v217) or 0
			else
				v218 = 0
			end
			v214.progress = v218
			if v204 then
				v219 = v204.progressText
				v220 = tostring(v219)
			else
				v220 = ""
			end
			v214.progressText = v220
			v214.deploy = v205
			v214.viewing = p191.id == v_u_174
			v214.frozen = v208 or v211
			if v208 then
				v221 = not v212 and "Locked while searching. Stop the search to change." or v212.SEARCH
			elseif v211 then
				v221 = not v212 and "The squad leader picks the area." or v212.MEMBER
			else
				v221 = nil
			end
			v214.why = v221
			v214.order = v213
			return v214
		else
			v205 = false
			v206 = v_u_47.stateWords(v203, v205, v204)
			v207 = p_u_20.myParty()
			if v207 == nil then
				v208 = false
			else
				v209 = v207.searching
				v208 = type(v209) == "table"
			end
			v210 = p_u_20.myParty()
			if v210 == nil or #v210.members <= 1 then
				v211 = false
			else
				v211 = not p_u_20.isLeader()
			end
			v212 = v_u_193
			v213 = 1
			for v231, v232 in v_u_91 do
				if v232.id ~= p191.id then
					continue
				end
				v213 = v231
			end
			v214 = {
				["id"] = p191.id,
				["name"] = v_u_47.displayName(p191),
				["hidden"] = v197,
				["geo"] = p191.geo,
				["fuzz"] = p191.fuzz,
				["place"] = v200,
				["underground"] = p191.underground == true,
				["site"] = p191.site,
				["state"] = v203,
				["chip"] = v206
			}
			if v204 then
				v215 = v204.line
				v216 = tostring(v215)
			else
				v216 = ""
			end
			v214.line = v216
			if v204 then
				v217 = v204.frac
				v218 = tonumber(v217) or 0
			else
				v218 = 0
			end
			v214.progress = v218
			if v204 then
				v219 = v204.progressText
				v220 = tostring(v219)
			else
				v220 = ""
			end
			v214.progressText = v220
			v214.deploy = v205
			v214.viewing = p191.id == v_u_174
			v214.frozen = v208 or v211
			if v208 then
				v221 = not v212 and "Locked while searching. Stop the search to change." or v212.SEARCH
			elseif v211 then
				v221 = not v212 and "The squad leader picks the area." or v212.MEMBER
			else
				v221 = nil
			end
			v214.why = v221
			v214.order = v213
			return v214
		end
	end
	local v233 = 0
	v233 = 0
	local v_u_234 = v53
	local v_u_235 = v_u_174
	local v_u_236 = v233
	local v_u_237 = v_u_89
	for _, v238 in v_u_91 do
		local v239
		if v_u_237 then
			local v240 = v_u_237.isOpenFor
			if type(v240) == "function" then
				local v241 = v_u_237.isOpenFor
				local v242 = v_u_4
				local v243, v244 = pcall(v241, v238, v242)
				if v243 then
					if v244 == true then
						v239 = v_u_118(v238) == nil
					else
						v239 = false
					end
					if not v239 then
						continue
					end
					v233 = v_u_236 + 1
					v_u_236 = v233
				else
					v239 = v238.enabled == true
					if not v239 then
						continue
					end
					v233 = v_u_236 + 1
					v_u_236 = v233
				end
			else
				v239 = v238.enabled == true
				if not v239 then
					continue
				end
				v233 = v_u_236 + 1
				v_u_236 = v233
			end
		else
			v239 = v238.enabled == true
			if not v239 then
				continue
			end
			v233 = v_u_236 + 1
			v_u_236 = v233
		end
	end
	local v_u_245, v_u_246 = v_u_26.card(v_u_60, {
		["order"] = 1,
		["accent"] = true,
		["gap"] = 4
	})
	v_u_245.Name = "Operation"
	local v_u_247 = v_u_23.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, 0, 0, 16)
	}, v_u_246)
	v_u_23.label({
		["parent"] = nil,
		["text"] = "Operation area",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_247,
		["color"] = v_u_25.text2,
		["size"] = UDim2.new(0.42, 0, 1, 0)
	}).Name = "Title"
	local v_u_248 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_247,
		["text"] = ("%d of %d open"):format(v_u_236, #v_u_91),
		["color"] = v_u_25.muted,
		["position"] = UDim2.fromScale(1, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0.58, 0, 1, 0)
	})
	local v249 = v_u_24.touch(v_u_27 and 52 or 62)
	local v_u_250 = v_u_23.new("TextButton", {
		["Name"] = "MapSelect",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Selectable"] = true,
		["BackgroundColor3"] = v_u_25.bgDeep,
		["Size"] = UDim2.new(1, 0, 0, v249)
	}, v_u_246)
	v_u_250.SelectionImageObject = v_u_23.selectionImage()
	local v_u_251 = v_u_23.stroke(v_u_250, v_u_25.line)
	local v_u_252 = v_u_23.label({
		["parent"] = nil,
		["name"] = "MapName",
		["text"] = "",
		["style"] = "h1",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_250,
		["textSize"] = v_u_27 and 30 or 38,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(1, -64, 1, 0)
	})
	local v_u_253 = v_u_23.new("Frame", {
		["Name"] = "Chevron",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.raised,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -10, 0.5, 0),
		["Size"] = UDim2.fromOffset(32, 32)
	}, v_u_250)
	v_u_23.stroke(v_u_253, v_u_25.line)
	local v_u_254 = nil
	local function v_u_260(p255) -- name: setChevron
		-- upvalues: (ref) v_u_254, (copy) v_u_23, (copy) v_u_253, (copy) v_u_25
		if v_u_254 then
			v_u_254:Destroy()
		end
		local v256 = v_u_23.icon
		local v257 = p255 and "chevronUp" or "chevronDown"
		local v258 = {
			["parent"] = nil,
			["size"] = 16,
			["thickness"] = 2,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v_u_253
		}
		local v259
		if p255 then
			v259 = v_u_25.accent
		else
			v259 = v_u_25.text2
		end
		v258.color = v259
		v258.position = UDim2.fromScale(0.5, 0.5)
		v258.anchor = Vector2.new(0.5, 0.5)
		v_u_254 = v256(v257, v258)
	end
	v_u_260(false)
	local v_u_261 = v_u_27 and 104 or 118
	local v_u_262 = v_u_23.new("Frame", {
		["Name"] = "Soon",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_25.accentDeep,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -52, 0.5, 0),
		["Size"] = UDim2.fromOffset(v_u_261, 24)
	}, v_u_250)
	local v_u_263 = v_u_23.stroke(v_u_262, v_u_25.accentDim)
	local v_u_264 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "Coming soon",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_262,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(6, 0),
		["size"] = UDim2.new(1, -12, 1, 0)
	})
	local v_u_265 = v_u_23.icon("lock", {
		["parent"] = nil,
		["size"] = 12,
		["thickness"] = 1.5,
		["color"] = nil,
		["position"] = nil,
		["parent"] = v_u_262,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(8, 6)
	})
	v_u_265.Visible = false
	local v_u_266 = v_u_23.new("Frame", {
		["Name"] = "RaidBar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_25.line,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 12, 1, -5),
		["Size"] = UDim2.new(1, -24, 0, 3)
	}, v_u_250)
	local v_u_267 = v_u_23.new("Frame", {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.accent,
		["Size"] = UDim2.fromScale(0, 1)
	}, v_u_266)
	local v_u_268 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Tagline",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v_u_246,
		["color"] = v_u_25.text2
	})
	local v_u_269 = v_u_23.label({
		["parent"] = nil,
		["name"] = "MapStats",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["order"] = 4,
		["fit"] = true,
		["parent"] = v_u_246,
		["color"] = v_u_25.muted,
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v_u_270 = v_u_23.new("Frame", {
		["Name"] = "MapOptions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 6,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_246)
	v_u_23.layout(v_u_270, "v", 4)
	v_u_23.pad(v_u_270, {
		0,
		0,
		4,
		4
	})
	local v_u_271 = {}
	local v272 = false
	local v273, v274 = pcall(function()
		-- upvalues: (copy) p_u_20
		return p_u_20.cctx.lib.MenuActs
	end)
	if v273 and type(v274) == "table" then
		local v275 = v274.plan
		if type(v275) == "function" then
			local v276 = v274.plan
			local v277, v278 = pcall(v276, v_u_91, v_u_237)
			if v277 and type(v278) == "table" then
				v_u_47.actPlan = v278
			end
		end
	end
	local v_u_279 = v272
	for v286, v_u_281 in v_u_91 do
		local v282 = v_u_23.new
		local v283 = "TextButton"
		local v284 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = true
		}
		local v285 = v_u_281.id
		v284.Name = "Map_" .. tostring(v285)
		v284.BackgroundColor3 = v_u_25.raised
		v284.Size = UDim2.new(1, 0, 0, v_u_24.touch(v_u_27 and 52 or 58))
		if v_u_47.actPlan then
			local v286 = v_u_47.actPlan.order[v_u_281.id] or v286
		end
		v284.LayoutOrder = v286
		local v287 = v282(v283, v284, v_u_270)
		v287.SelectionImageObject = v_u_23.selectionImage()
		local v288 = v_u_23.stroke(v287, v_u_25.line)
		local v289 = v_u_23.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_25.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v287)
		local v290 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "h3",
			["textSize"] = 17,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v287,
			["text"] = v_u_47.displayName(v_u_281),
			["position"] = UDim2.fromOffset(14, 7),
			["size"] = UDim2.new(0.62, -14, 0, 22)
		})
		local v291 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Tagline",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v287,
			["text"] = v_u_281.tagline or "",
			["color"] = v_u_25.text2,
			["position"] = UDim2.new(0, 14, 1, -24),
			["size"] = UDim2.new(0.62, -14, 0, 18)
		})
		local v292 = v_u_23.label({
			["parent"] = nil,
			["name"] = "State",
			["text"] = "",
			["style"] = "micro",
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v287,
			["position"] = UDim2.new(1, -12, 0, 9),
			["anchor"] = Vector2.new(1, 0),
			["size"] = UDim2.new(0.38, -12, 0, 14)
		})
		local v293 = v_u_23.label
		local v294 = {
			["parent"] = nil,
			["name"] = "Length",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v287
		}
		local v295
		if v_u_281.teaser == true then
			local v296 = v_u_281.size or ""
			v295 = tostring(v296)
		else
			local v297 = v_u_281.raidMinutes
			local v298 = tonumber(v297) or 20
			local v299 = v_u_281.size or ""
			v295 = ("%d min  \194\183  %s"):format(v298, (tostring(v299)))
		end
		v294.text = v295
		v294.color = v_u_25.muted
		v294.position = UDim2.new(1, -12, 1, -24)
		v294.anchor = Vector2.new(1, 0)
		v294.size = UDim2.new(0.38, -12, 0, 16)
		local v300 = v293(v294)
		local v301 = v_u_23.icon("lock", {
			["parent"] = nil,
			["name"] = "RaidLock",
			["size"] = 12,
			["thickness"] = 1.5,
			["color"] = nil,
			["position"] = nil,
			["parent"] = v287,
			["color"] = v_u_25.accent,
			["position"] = UDim2.new(0, 14, 1, -21)
		})
		v301.Visible = false
		local v302 = v_u_23.new("Frame", {
			["Name"] = "RaidBar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_25.line,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 14, 1, -4),
			["Size"] = UDim2.new(1, -28, 0, 3)
		}, v287)
		local v_u_303 = {
			["btn"] = nil,
			["stroke"] = nil,
			["edge"] = nil,
			["name"] = nil,
			["tagline"] = nil,
			["state"] = nil,
			["def"] = nil,
			["hover"] = false,
			["length"] = nil,
			["lock"] = nil,
			["bar"] = nil,
			["fill"] = nil,
			["btn"] = v287,
			["stroke"] = v288,
			["edge"] = v289,
			["name"] = v290,
			["tagline"] = v291,
			["state"] = v292,
			["def"] = v_u_281,
			["length"] = v300,
			["lock"] = v301,
			["bar"] = v302,
			["fill"] = v_u_23.new("Frame", {
				["Name"] = "Fill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_25.accent,
				["Size"] = UDim2.fromScale(0, 1)
			}, v302)
		}
		v_u_271[v_u_281.id] = v_u_303
		v287.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_303, (copy) v_u_23, (copy) v_u_24, (copy) v_u_47
			v_u_303.hover = true
			v_u_23.sound(v_u_24.sounds.hover)
			v_u_47.paint()
		end)
		v287.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_303, (copy) v_u_47
			v_u_303.hover = false
			v_u_47.paint()
		end)
		v287.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_303, (copy) v_u_47
			v_u_303.hover = true
			v_u_47.paint()
		end)
		v287.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_303, (copy) v_u_47
			v_u_303.hover = false
			v_u_47.paint()
		end)
		v287.Activated:Connect(function(p304)
			-- upvalues: (copy) v_u_47, (copy) v_u_281, (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250
			local v305
			if p304 == nil then
				v305 = false
			else
				v305 = string.find(p304.UserInputType.Name, "Gamepad") ~= nil
			end
			v_u_47.viewMap(v_u_281.id)
			v_u_279 = false
			v_u_270.Visible = false
			v_u_260(false)
			v_u_251.Color = v_u_25.line
			if v305 then
				local v306 = game:GetService("GuiService")
				local _ = v_u_271[v_u_235]
				v306.SelectedObject = v_u_250
			end
		end)
	end
	v_u_23.label({
		["parent"] = nil,
		["name"] = "More",
		["text"] = "Locked areas can be viewed, not deployed to",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["order"] = nil,
		["track"] = false,
		["fit"] = true,
		["parent"] = v_u_270,
		["color"] = v_u_25.muted,
		["size"] = UDim2.new(1, 0, 0, 18),
		["order"] = not v_u_47.actPlan and 99 or v_u_47.actPlan.hintOrder
	})
	if v_u_47.actPlan then
		local v307, v308 = pcall(function()
			-- upvalues: (copy) p_u_20, (copy) v_u_270, (copy) v_u_247, (copy) v_u_47, (ref) v_u_237, (copy) v_u_27, (copy) v_u_261
			return p_u_20.cctx.lib.MenuActs.attach(p_u_20, {
				["host"] = v_u_270,
				["head"] = v_u_247,
				["plan"] = v_u_47.actPlan,
				["maps"] = v_u_237,
				["compact"] = v_u_27,
				["soonW"] = v_u_261,
				["soonText"] = v_u_47.why().gateWords("soon").tag
			})
		end)
		if v307 and type(v308) == "table" then
			v_u_47.acts = v308
		else
			warn("[MenuPlay] acts failed:", v308)
			v_u_4:SetAttribute("ClientError", "menu acts: " .. tostring(v308))
		end
	end
	v_u_250.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_24, (ref) v_u_279, (copy) v_u_251, (copy) v_u_25
		v_u_23.sound(v_u_24.sounds.hover)
		if not v_u_279 then
			v_u_251.Color = v_u_25.lineStrong
		end
	end)
	v_u_250.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_279, (copy) v_u_251, (copy) v_u_25
		if not v_u_279 then
			v_u_251.Color = v_u_25.line
		end
	end)
	v_u_250.Activated:Connect(function(p309)
		-- upvalues: (copy) p_u_20, (copy) v_u_23, (copy) v_u_24, (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250
		local v310 = p_u_20.myParty()
		local v311
		if v310 == nil then
			v311 = false
		else
			local v312 = v310.searching
			v311 = type(v312) == "table"
		end
		if v311 then
			v_u_23.sound(v_u_24.sounds.error)
			v_u_23.toast("Locked while searching", "warn", "Stop the search to change the conditions.")
			return
		else
			local v313 = p_u_20.myParty()
			if v313 == nil or (#v313.members <= 1 or p_u_20.isLeader()) then
				local v314 = v_u_23.sound
				local v315
				if v_u_279 then
					v315 = v_u_24.sounds.click
				else
					v315 = v_u_24.sounds.open or v_u_24.sounds.click
				end
				v314(v315)
				local v316 = not v_u_279
				local v317
				if p309 == nil then
					v317 = false
				else
					v317 = string.find(p309.UserInputType.Name, "Gamepad") ~= nil
				end
				v_u_279 = v316
				v_u_270.Visible = v316
				v_u_260(v316)
				local v318 = v_u_251
				local v319
				if v316 then
					v319 = v_u_25.accent
				else
					v319 = v_u_25.line
				end
				v318.Color = v319
				if v317 then
					local v320 = game:GetService("GuiService")
					local v321 = v_u_271[v_u_235]
					local v322
					if v316 and v321 then
						v322 = v321.btn
					else
						v322 = v_u_250
					end
					v320.SelectedObject = v322
				end
			else
				v_u_23.sound(v_u_24.sounds.error)
				v_u_23.toast("Only the squad leader can change this", "warn")
			end
		end
	end)
	local function v_u_323(_) end
	local function v_u_383() -- name: paintMap
		-- upvalues: (copy) v_u_91, (ref) v_u_235, (copy) v_u_154, (copy) v_u_48, (ref) v_u_236, (ref) v_u_237, (ref) v_u_4, (copy) v_u_118, (copy) v_u_134, (copy) v_u_23, (copy) v_u_252, (copy) v_u_47, (copy) v_u_25, (copy) v_u_262, (copy) v_u_264, (copy) v_u_263, (copy) v_u_265, (copy) v_u_261, (copy) v_u_268, (copy) v_u_269, (copy) v_u_173, (copy) v_u_266, (copy) v_u_267, (copy) v_u_248, (copy) v_u_271, (ref) v_u_323
		for _, v325 in v_u_91 do
			if v325.id ~= v_u_235 then
				continue
			end
		end
		local v325 = v_u_154(v_u_48.mapId)
		v_u_236 = 0
		for _, v326 in v_u_91 do
			local v327
			if v_u_237 then
				local v328 = v_u_237.isOpenFor
				if type(v328) == "function" then
					local v329 = v_u_237.isOpenFor
					local v330 = v_u_4
					local v331, v332 = pcall(v329, v326, v330)
					if v331 then
						if v332 == true then
							v327 = v_u_118(v326) == nil
						else
							v327 = false
						end
						if not v327 then
							continue
						end
						v_u_236 = v_u_236 + 1
					else
						v327 = v326.enabled == true
						if not v327 then
							continue
						end
						v_u_236 = v_u_236 + 1
					end
				else
					v327 = v326.enabled == true
					if not v327 then
						continue
					end
					v_u_236 = v_u_236 + 1
				end
			else
				v327 = v326.enabled == true
				if not v327 then
					continue
				end
				v_u_236 = v_u_236 + 1
			end
		end
		local v333 = v_u_134(v325)
		local v334 = (v333 == "locked" or v333 == "soon") and true or v333 == "raids"
		local v335
		if v333 == "raids" then
			v335 = v_u_118(v325)
		else
			v335 = nil
		end
		v_u_23.setText(v_u_252, v_u_47.displayName(v325))
		local v336 = v_u_252
		local v337
		if v334 then
			v337 = v_u_25.text2
		else
			v337 = v_u_25.text
		end
		v336.TextColor3 = v337
		v_u_262.Visible = v333 ~= "open"
		v_u_23.setText(v_u_264, (select(3, v_u_47.stateWords(v333, true, v335))))
		local v338 = v_u_264
		local v339
		if v333 == "test" then
			v339 = v_u_25.info
		else
			v339 = v_u_25.accent
		end
		v338.TextColor3 = v339
		local v340 = v_u_263
		local v341
		if v333 == "test" then
			v341 = v_u_25.info
		else
			v341 = v_u_25.accentDim
		end
		v340.Color = v341
		local v342 = v_u_262
		local v343
		if v333 == "test" then
			v343 = v_u_25.bgDeep
		else
			v343 = v_u_25.accentDeep
		end
		v342.BackgroundColor3 = v343
		v_u_265.Visible = v333 == "locked" and true or v333 == "raids"
		v_u_264.Position = UDim2.fromOffset(v_u_265.Visible and 22 or 6, 0)
		v_u_264.Size = UDim2.new(1, v_u_265.Visible and -28 or -12, 1, 0)
		v_u_252.Size = UDim2.new(1, v333 == "open" and -64 or -64 - v_u_261 - 8, 1, 0)
		local v344 = v_u_23.setText
		local v345 = v_u_268
		local v346
		if v335 then
			v346 = v335.line
		else
			local v347 = v325.tagline or ""
			v346 = tostring(v347)
		end
		v344(v345, v346)
		local v348 = v_u_268
		local v349
		if v335 then
			v349 = v_u_25.accent
		else
			v349 = v_u_25.text2
		end
		v348.TextColor3 = v349
		local v350 = v_u_23.setText
		local v351 = v_u_269
		local v352
		if v335 then
			v352 = v335.progressText
		else
			v352 = v_u_173(v325)
		end
		v350(v351, v352)
		local v353 = v_u_269
		local v354
		if v335 then
			v354 = v_u_25.accent
		else
			v354 = v_u_25.muted
		end
		v353.TextColor3 = v354
		v_u_266.Visible = v335 ~= nil
		if v335 then
			v_u_267.Size = UDim2.fromScale(v335.frac, 1)
		end
		local v355 = 1
		for v356, v357 in v_u_91 do
			if v357.id ~= v325.id then
				continue
			end
			v355 = v356
		end
		v_u_23.setText(v_u_248, ("Map %d of %d  \194\183  %d of %d open"):format(v355, #v_u_91, v_u_236, #v_u_91))
		for v358, v359 in v_u_271 do
			local v360 = v358 == v325.id
			local v361 = v_u_134(v359.def)
			local v362 = v361 == "open" and true or v361 == "test"
			local v363
			if v361 == "raids" then
				v363 = v_u_118(v359.def)
			else
				v363 = nil
			end
			local v364 = v359.stroke
			local v365
			if v360 then
				if v362 then
					v365 = v_u_25.accent
				else
					v365 = v_u_25.accentDim
				end
			elseif v359.hover then
				v365 = v_u_25.lineStrong
			else
				v365 = v_u_25.line
			end
			v364.Color = v365
			local v366 = v359.btn
			local v367
			if v360 then
				v367 = v_u_25.accentDeep
			else
				v367 = v_u_25.raised
			end
			v366.BackgroundColor3 = v367
			v359.edge.Visible = v360
			local v368 = v359.edge
			local v369
			if v362 then
				v369 = v_u_25.accent
			else
				v369 = v_u_25.accentDim
			end
			v368.BackgroundColor3 = v369
			local v370 = v359.name
			local v371
			if v362 then
				v371 = v_u_25.text
			else
				v371 = v_u_25.text2
			end
			v370.TextColor3 = v371
			v_u_23.setText(v359.name, v_u_47.displayName(v359.def))
			v_u_23.setText(v359.state, (select(2, v_u_47.stateWords(v361, v360, v363))))
			local v372 = v359.state
			local v373
			if v361 == "test" and not v360 then
				v373 = v_u_25.info
			elseif v360 then
				v373 = v_u_25.accent
			elseif v362 then
				v373 = v_u_25.text2
			else
				v373 = v_u_25.accentDim
			end
			v372.TextColor3 = v373
			v359.lock.Visible = v363 ~= nil
			v359.bar.Visible = v363 ~= nil
			v359.length.Visible = v363 == nil
			if v363 then
				v359.fill.Size = UDim2.fromScale(v363.frac, 1)
				v_u_23.setText(v359.tagline, v363.line)
				v359.tagline.TextColor3 = v_u_25.accent
				v359.tagline.Position = UDim2.new(0, 30, 1, -24)
				v359.tagline.Size = UDim2.new(1, -42, 0, 18)
			else
				local v374 = v_u_23.setText
				local v375 = v359.tagline
				local v376 = v359.def.tagline or ""
				v374(v375, (tostring(v376)))
				v359.tagline.TextColor3 = v_u_25.text2
				v359.tagline.Position = UDim2.new(0, 14, 1, -24)
				v359.tagline.Size = UDim2.new(0.62, -14, 0, 18)
			end
		end
		if v_u_47.acts then
			local v377 = v_u_47.acts.paint
			pcall(v377, v325)
		end
		v_u_323(v325)
		local v378 = v_u_4
		local v379 = v325.id
		local v380 = tostring(v379)
		local v381 = v_u_48.mapId
		v378:SetAttribute("MenuPlayMap", ("view=%s deploy=%s closed=%s access=%s"):format(v380, tostring(v381), tostring(v334), v333))
		if v_u_47.globe then
			local v382 = v_u_47.globe.sync
			pcall(v382)
		end
	end
	local v384 = v_u_27 and 96 or 132
	local v_u_385 = v_u_23.new("Frame", {
		["Name"] = "MapArt",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 7,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_25.bgDeep,
		["Size"] = UDim2.new(1, 0, 0, v384)
	}, v_u_246)
	v_u_23.stroke(v_u_385, v_u_25.line)
	local v386 = v_u_24.isPhone
	local v387
	if type(v386) == "function" then
		v387 = v_u_24.isPhone() == true
	else
		v387 = false
	end
	v_u_385.Visible = not v387
	local v_u_388 = nil
	local v389, v390 = pcall(function()
		-- upvalues: (copy) p_u_20
		return p_u_20.cctx.lib.MapPicture
	end)
	if v389 and type(v390) == "table" then
		local v391 = v390.new
		if type(v391) == "function" then
			local v392 = v390.new
			local v393, v394 = pcall(v392, v_u_385, {
				["height"] = v384,
				["theme"] = v_u_24
			})
			if v393 then
				v_u_388 = v394
			else
				warn("[MenuPlay] map picture failed:", v394)
				v_u_4:SetAttribute("ClientError", "menu map picture: " .. tostring(v394))
			end
		end
	end
	local v_u_395 = v_u_23.new("Frame", {
		["Name"] = "Overlay",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_385)
	local v396 = v_u_23.new("Frame", {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_395)
	for v397 = 1, 11 do
		v_u_23.new("Frame", {
			["Name"] = "V",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_25.text2,
			["BackgroundTransparency"] = v397 == 6 and 0.66 or 0.78,
			["Position"] = UDim2.new(v397 / 12, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}, v396)
	end
	for v398 = 1, 3 do
		v_u_23.new("Frame", {
			["Name"] = "H",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_25.text2,
			["BackgroundTransparency"] = v398 == 2 and 0.66 or 0.78,
			["Position"] = UDim2.new(0, 0, v398 / 4, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}, v396)
	end
	local v_u_399 = {}
	local function v409(p400, p401, p402, p403, p404, p405, p406) -- name: plateLabel
		-- upvalues: (copy) v_u_23, (copy) v_u_25, (copy) v_u_395
		local v407 = v_u_23.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["Name"] = p400,
			["BackgroundColor3"] = v_u_25.bgDeep,
			["AnchorPoint"] = p404,
			["Position"] = p405,
			["Size"] = UDim2.fromOffset(p406, 18)
		}, v_u_395)
		local v408 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v407,
			["text"] = p401,
			["style"] = p402,
			["color"] = p403,
			["position"] = UDim2.fromOffset(4, 0),
			["size"] = UDim2.new(1, -8, 1, 0)
		})
		v408.ZIndex = 3
		return v407, v408
	end
	for _, v410 in { Vector2.new(0.08, 0.42), Vector2.new(0.9, 0.2), Vector2.new(0.62, 0.86) } do
		local v411 = v_u_23.new("Frame", {
			["Name"] = "Exfil",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_25.accent,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(v410.X, v410.Y),
			["Size"] = UDim2.fromOffset(8, 8)
		}, v_u_395)
		v_u_23.stroke(v411, v_u_25.bgDeep)
		table.insert(v_u_399, v411)
	end
	local v_u_412 = v409("ExfilTag", "Exfil", "micro", v_u_25.accent, Vector2.new(0, 1), UDim2.new(0, 6, 1, -6), 56)
	local v_u_413, v_u_414 = v409("Coords", "N 39.21  W 87.14", "monoS", v_u_25.text2, Vector2.new(1, 0), UDim2.new(1, -6, 0, 6), 150)
	local v_u_415 = v_u_23.new("Frame", {
		["Name"] = "SoonStamp",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_25.bgDeep,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.56),
		["Size"] = UDim2.fromOffset(v_u_27 and 200 or 232, v_u_27 and 46 or 54)
	}, v_u_395)
	v_u_23.stroke(v_u_415, v_u_25.accent)
	local v_u_416 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Coming soon",
		["style"] = "h3",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_415,
		["textSize"] = v_u_27 and 17 or 20,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(8, v_u_27 and 4 or 6),
		["size"] = UDim2.new(1, -16, 0, v_u_27 and 22 or 24)
	})
	local v_u_417 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = "Not open for deployment yet",
		["style"] = "small",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["track"] = false,
		["parent"] = v_u_415,
		["color"] = v_u_25.text2,
		["position"] = UDim2.new(0, 8, 1, v_u_27 and -20 or -23),
		["size"] = UDim2.new(1, -16, 0, 16)
	})
	v_u_416.ZIndex = 4
	v_u_417.ZIndex = 4
	local v_u_418 = v_u_23.new("Frame", {
		["Name"] = "RaidBar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_25.line,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 12, 1, -6),
		["Size"] = UDim2.new(1, -24, 0, 3)
	}, v_u_415)
	local v_u_419 = v_u_23.new("Frame", {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_25.accent,
		["Size"] = UDim2.fromScale(0, 1)
	}, v_u_418)
	v_u_323 = function(p420)
		-- upvalues: (ref) v_u_388, (copy) v_u_134, (copy) v_u_415, (copy) v_u_47, (copy) v_u_23, (copy) v_u_416, (copy) v_u_417, (copy) v_u_118, (copy) v_u_418, (copy) v_u_419, (copy) v_u_55, (copy) v_u_27, (copy) v_u_399, (copy) v_u_412, (copy) v_u_414, (copy) v_u_413
		if v_u_388 then
			local v421 = v_u_388.set
			pcall(v421, p420)
		end
		local v422 = v_u_134(p420)
		local v423 = (v422 == "locked" or v422 == "soon") and true or v422 == "raids"
		v_u_415.Visible = v423
		local v424 = v_u_47.why().gateWords(v422)
		v_u_23.setText(v_u_416, v424.stampT)
		v_u_23.setText(v_u_417, v424.stampS)
		local v425
		if v422 == "raids" then
			v425 = v_u_118(p420)
		else
			v425 = nil
		end
		v_u_418.Visible = v425 ~= nil
		if v425 then
			v_u_23.setText(v_u_416, v425.line)
			v_u_23.setText(v_u_417, v425.progressText)
			v_u_419.Size = UDim2.fromScale(v425.frac, 1)
		end
		local v426 = v_u_415
		local v427 = UDim2.fromOffset
		local v428
		if v425 then
			local v429 = v_u_55 - 24
			local v430 = math.max(200, v429)
			local v431 = v_u_27 and 280 or 330
			v428 = math.min(v430, v431)
		else
			v428 = v_u_27 and 200 or 232
		end
		local v432
		if v425 then
			v432 = v_u_27 and 66 or 74
		else
			v432 = v_u_27 and 46 or 54
		end
		v426.Size = v427(v428, v432)
		local v433 = v_u_417
		local v434
		if v425 then
			v434 = UDim2.new(0, 8, 1, v_u_27 and -30 or -32)
		else
			v434 = UDim2.new(0, 8, 1, v_u_27 and -20 or -23)
		end
		v433.Position = v434
		for _, v435 in v_u_399 do
			v435.Visible = not v423
		end
		v_u_412.Visible = not v423
		local v436 = p420.coords or ""
		local v437 = tostring(v436)
		v_u_23.setText(v_u_414, v437)
		v_u_413.Visible = v437 ~= ""
		local v438 = v_u_413
		local v439 = UDim2.fromOffset
		local v440 = v_u_55 * 0.6
		local v441 = math.floor(v440)
		local v442 = (utf8.len(v437) or #v437) * 7.4
		local v443 = math.ceil(v442) + 16
		v438.Size = v439(math.min(v441, v443), 18)
	end
	local v_u_444 = v70("Current task", 5, "")
	local v445 = v_u_23.new("TextButton", {
		["Name"] = "CurrentTask",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 6,
		["Selectable"] = true,
		["BackgroundColor3"] = v_u_25.raised,
		["Size"] = UDim2.new(1, 0, 0, v_u_27 and 78 or 92)
	}, v_u_60)
	v445.SelectionImageObject = v_u_23.selectionImage()
	local v_u_446 = v_u_23.stroke(v445, v_u_25.line)
	local v_u_447 = v_u_23.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v445)
	local v_u_448 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Kicker",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v445,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(v_u_65, v_u_27 and 6 or 9),
		["size"] = UDim2.new(1, -v_u_65 * 2 - 24, 0, 14)
	})
	local v_u_449 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Loading tasks...",
		["style"] = "h3",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v445,
		["textSize"] = v_u_27 and 16 or 18,
		["position"] = UDim2.fromOffset(v_u_65, v_u_27 and 20 or 24),
		["size"] = UDim2.new(1, -v_u_65 * 2 - 24, 0, 22)
	})
	local v_u_450 = v_u_26.bar(v445, {
		["label"] = " ",
		["right"] = "",
		["value"] = 0,
		["labelStyle"] = "small"
	})
	v_u_450.frame.Position = UDim2.new(0, v_u_65, 1, v_u_27 and -44 or -48)
	v_u_450.frame.Size = UDim2.new(1, -v_u_65 * 2 - 24, 0, 40)
	if v_u_450.left then
		v_u_450.left.Size = UDim2.new(0.74, 0, 0, 20)
		v_u_450.left.TextTruncate = Enum.TextTruncate.AtEnd
	end
	if v_u_450.right then
		v_u_450.right.Position = UDim2.fromScale(0.74, 0)
		v_u_450.right.Size = UDim2.new(0.26, 0, 0, 20)
	end
	v_u_23.label({
		["parent"] = nil,
		["name"] = "Chevron",
		["text"] = "\226\128\186",
		["style"] = "h2",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["parent"] = v445,
		["color"] = v_u_25.text2,
		["position"] = UDim2.new(1, -v_u_65, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0, 20, 1, 0)
	})
	local v_u_451 = nil
	v445.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_446, (copy) v_u_25, (copy) v_u_23, (copy) v_u_24
		v_u_446.Color = v_u_25.lineStrong
		v_u_23.sound(v_u_24.sounds.hover)
	end)
	v445.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_446, (copy) v_u_25
		v_u_446.Color = v_u_25.line
	end)
	function v_u_47.taskPress() -- name: taskPress
		-- upvalues: (copy) v_u_23, (copy) v_u_24, (copy) v_u_47, (copy) p_u_20, (ref) v_u_451
		v_u_23.sound(v_u_24.sounds.click)
		if v_u_47.tasksAsked == true then
			local v452 = p_u_20.cache
			if type(v452) == "table" then
				local v453 = p_u_20.cache.tasks
				if type(v453) == "table" then
					local v454 = p_u_20.cache.tasks.data
					if type(v454) == "table" then
						if p_u_20.openTask then
							p_u_20.openTask(v_u_451)
						else
							p_u_20.setTab("tasks")
						end
					end
					if v_u_47.fetchTask then
						v_u_47.fetchTask(true)
						return
					end
				elseif v_u_47.fetchTask then
					v_u_47.fetchTask(true)
					return
				end
				if p_u_20.openTask then
					p_u_20.openTask(v_u_451)
				else
					p_u_20.setTab("tasks")
				end
			elseif p_u_20.openTask then
				p_u_20.openTask(v_u_451)
			else
				p_u_20.setTab("tasks")
			end
		elseif p_u_20.openTask then
			p_u_20.openTask(v_u_451)
		else
			p_u_20.setTab("tasks")
		end
	end
	v445.Activated:Connect(v_u_47.taskPress)
	v_u_47.taskParts = {
		["kicker"] = v_u_448,
		["title"] = v_u_449,
		["bar"] = v_u_450,
		["edge"] = v_u_447
	}
	local function v_u_507() -- name: paintTask
		-- upvalues: (copy) p_u_20, (copy) v_u_444, (ref) v_u_451, (copy) v_u_47, (copy) v_u_448, (copy) v_u_449, (copy) v_u_450, (copy) v_u_25, (copy) v_u_447
		-- block 87
		local v455 = p_u_20.cache and (p_u_20.cache.tasks and p_u_20.cache.tasks.data) or nil
		local v_u_456 = nil
		local function v457()
			-- upvalues: (ref) v_u_456, (ref) p_u_20
			v_u_456 = p_u_20.cctx.shared.Tasks
		end
		pcall(v457)
		local v458
		if p_u_20.firstOpenTask then
			v458 = p_u_20.firstOpenTask(nil)
		else
			v458 = nil
		end
		local v_u_459
		if v458 and v_u_456 then
			v_u_459 = v_u_456.get(v458) or nil
		else
			v_u_459 = nil
		end
		local v460 = v_u_444:FindFirstChild("Right")
		local v461
		if type(v455) == "table" then
			local v462 = v455.counts
			if type(v462) == "table" then
				v461 = v455.counts or nil
			else
				v461 = nil
			end
		else
			v461 = nil
		end
		if v460 then
			local v463
			if v461 then
				local v464 = v461.active
				local v465 = tonumber(v464) or 0
				local v466 = v461.ready
				v463 = ("%d ACTIVE  \194\183  %d READY"):format(v465, tonumber(v466) or 0)
			else
				v463 = ""
			end
			v460.Text = v463
		end
		v_u_451 = v458
		if type(v455) ~= "table" then
			local v467, v468 = v_u_47.why().taskLoad(v_u_47.tasksAsked == true)
			v_u_448.Text = v467
			v_u_449.Text = v468
			v_u_450.frame.Visible = false
			return
		end
		if not v_u_459 then
			v_u_448.Text = "NO OPEN TASK"
			v_u_448.TextColor3 = v_u_25.muted
			v_u_447.BackgroundColor3 = v_u_25.muted
			local v469 = v455.order
			local v470 = v_u_456
			local v471 = nil
			for _, v472 in type(v469) == "table" and (v455.order or {}) or {} do
				local v473 = v455.tasks
				if v473 then
					v473 = v455.tasks[v472]
				end
				if type(v473) ~= "table" or v473.state ~= "locked" then
					continue
				end
				local v474 = v473.lock
				if type(v474) ~= "string" then
					continue
				end
				v471 = v472
			end
			local v475
			if v471 and v470 then
				v475 = v470.get(v471) or nil
			else
				v475 = nil
			end
			if v475 then
				v_u_451 = v471
				v_u_448.Text = "NEXT JOB  \194\183  LOCKED"
				v_u_449.Text = v475.title
				v_u_450.frame.Visible = true
				local v476 = v_u_450.left
				local v477 = v455.tasks[v471].lock
				v476.Text = tostring(v477)
				v_u_450.setRight("")
				v_u_450.bar.setColor(v_u_25.muted)
				v_u_450.set(0)
			else
				v_u_449.Text = "Every job is done, for now"
				v_u_450.frame.Visible = false
			end
			return
		end
		local v478 = v455.tasks and v455.tasks[v458] or {}
		local v479 = v478.state or "available"
		local v480 = tostring(v479)
		local v_u_481 = v_u_459.giver
		local function v482()
			-- upvalues: (ref) v_u_481, (ref) p_u_20, (copy) v_u_459
			v_u_481 = p_u_20.cctx.shared.Traders.defs[v_u_459.giver].name
		end
		pcall(v482)
		local v483
		if v480 == "ready" then
			v483 = v_u_25.success
		elseif v480 == "active" then
			v483 = v_u_25.accent
		else
			v483 = v_u_25.info
		end
		v_u_447.BackgroundColor3 = v483
		v_u_448.TextColor3 = v483
		v_u_448.Text = v_u_47.why().taskKicker(v480 == "ready" and "READY TO HAND IN" or (v480 == "active" and "CURRENT TASK" or "NEW TASK"), v_u_481, v478.lockLine, v480)
		v_u_449.Text = v_u_459.title
		v_u_450.frame.Visible = true
		if v480 == "ready" then
			v_u_450.left.Text = "Done. Hand it in at TASKS for the reward"
			v_u_450.setRight("")
			v_u_450.bar.setColor(v_u_25.success)
			v_u_450.set(1)
			return
		end
		local v484, v485, v486
		-- GenericForInit
v484, v485, v486 = v_u_459.objectives, nil, nil
[internal control] = v486
-- end GenericForInit
		local v487 = nil
		local v488 = 0
		local v489 = 1
		local v490, v491
		-- GenericForNext
v490, v491 = v484(v485, [internal control])
if v490 ~= nil
[internal control] = v490
-- end GenericForNext
		::l30::
		local v492 = v487 or v_u_459.objectives[1]
		local v493 = v492 and (v492.desc or "") or ""
		local v494 = tostring(v493)
		local v495
		if v492 and (v492.hint and v480 ~= "ready") then
			v495 = v492.hint
			v494 = v494 .. "  \194\183  " .. tostring(v495)
		end
		v_u_450.left.Text = "Next: " .. v494
		v_u_450.setRight(("%d / %d"):format(v488, v489))
		v_u_450.bar.setColor(v_u_25.accent)
		local v496 = v_u_450.set
		local v497 = v488 / math.max(1, v489)
		v496((math.clamp(v497, 0, 1)))
		return
		::l62::
		local v498 = v478.progress
		local v499
		if type(v498) == "table" then
			local v500 = v478.progress[v490]
			v499 = tonumber(v500) or 0
		else
			v499 = 0
		end
		local v501 = v478.need
		local v502, v503, v504, v505
		if type(v501) == "table" then
			local v506 = v478.need[v490]
			v502 = tonumber(v506)
			if v502 then
				if v499 >= v502 then
					continue
				end
				if v491.event == "handover" then
					v503 = v478.stash
					if type(v503) == "table" then
						v504 = v478.stash[v490]
						if tonumber(v504) and v478.stash[v490] > 0 then
							v487 = table.clone(v491)
							v505 = v491.desc
							v487.desc = ("%s (%d in stash)"):format(tostring(v505), v478.stash[v490])
							v489 = v502
							v488 = v499
						else
							v489 = v502
							v488 = v499
							v487 = v491
						end
					else
						v489 = v502
						v488 = v499
						v487 = v491
					end
				else
					v489 = v502
					v488 = v499
					v487 = v491
				end
				v492 = v487 or v_u_459.objectives[1]
				v493 = v492 and (v492.desc or "") or ""
				v494 = tostring(v493)
				if v492 and (v492.hint and v480 ~= "ready") then
					v495 = v492.hint
					v494 = v494 .. "  \194\183  " .. tostring(v495)
				end
				v_u_450.left.Text = "Next: " .. v494
				v_u_450.setRight(("%d / %d"):format(v488, v489))
				v_u_450.bar.setColor(v_u_25.accent)
				v496 = v_u_450.set
				v497 = v488 / math.max(1, v489)
				v496((math.clamp(v497, 0, 1)))
			else
				v502 = v491.count or 1
				if v499 >= v502 then
					continue
				end
				if v491.event == "handover" then
					v503 = v478.stash
					if type(v503) == "table" then
						v504 = v478.stash[v490]
						if tonumber(v504) and v478.stash[v490] > 0 then
							v487 = table.clone(v491)
							v505 = v491.desc
							v487.desc = ("%s (%d in stash)"):format(tostring(v505), v478.stash[v490])
							v489 = v502
							v488 = v499
						else
							v489 = v502
							v488 = v499
							v487 = v491
						end
					else
						v489 = v502
						v488 = v499
						v487 = v491
					end
				else
					v489 = v502
					v488 = v499
					v487 = v491
				end
				v492 = v487 or v_u_459.objectives[1]
				v493 = v492 and (v492.desc or "") or ""
				v494 = tostring(v493)
				if v492 and (v492.hint and v480 ~= "ready") then
					v495 = v492.hint
					v494 = v494 .. "  \194\183  " .. tostring(v495)
				end
				v_u_450.left.Text = "Next: " .. v494
				v_u_450.setRight(("%d / %d"):format(v488, v489))
				v_u_450.bar.setColor(v_u_25.accent)
				v496 = v_u_450.set
				v497 = v488 / math.max(1, v489)
				v496((math.clamp(v497, 0, 1)))
			end
		else
			v502 = v491.count or 1
			if v499 >= v502 then
				continue
			end
			if v491.event == "handover" then
				v503 = v478.stash
				if type(v503) == "table" then
					v504 = v478.stash[v490]
					if tonumber(v504) and v478.stash[v490] > 0 then
						v487 = table.clone(v491)
						v505 = v491.desc
						v487.desc = ("%s (%d in stash)"):format(tostring(v505), v478.stash[v490])
						v489 = v502
						v488 = v499
					else
						v489 = v502
						v488 = v499
						v487 = v491
					end
				else
					v489 = v502
					v488 = v499
					v487 = v491
				end
			else
				v489 = v502
				v488 = v499
				v487 = v491
			end
			v492 = v487 or v_u_459.objectives[1]
			v493 = v492 and (v492.desc or "") or ""
			v494 = tostring(v493)
			if v492 and (v492.hint and v480 ~= "ready") then
				v495 = v492.hint
				v494 = v494 .. "  \194\183  " .. tostring(v495)
			end
			v_u_450.left.Text = "Next: " .. v494
			v_u_450.setRight(("%d / %d"):format(v488, v489))
			v_u_450.bar.setColor(v_u_25.accent)
			v496 = v_u_450.set
			v497 = v488 / math.max(1, v489)
			v496((math.clamp(v497, 0, 1)))
			return
		end
		-- block 67
		goto l30
		-- block 68
		goto l62
	end
	function v_u_47.fetchTask(p_u_508) -- name: fetchTask
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) p_u_21, (copy) v_u_507
		task.spawn(function()
			-- upvalues: (ref) p_u_20, (copy) p_u_508, (ref) v_u_47, (ref) p_u_21, (ref) v_u_507
			p_u_20.fetch("tasks", nil, p_u_508 and 1 or 15)
			v_u_47.tasksAsked = true
			if p_u_21.Parent then
				v_u_507()
				if v_u_47.brief then
					local v509 = v_u_47.brief.paint
					pcall(v509)
				end
			end
		end)
	end
	local v_u_510 = v_u_23.new("Frame", {
		["Name"] = "SearchLock",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 9,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 20)
	}, v_u_60)
	v_u_23.icon("lock", {
		["parent"] = nil,
		["size"] = 12,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v_u_510,
		["color"] = v_u_25.accentDim,
		["position"] = UDim2.new(0, v_u_65, 0.5, 0),
		["anchor"] = Vector2.new(0, 0.5)
	})
	v_u_23.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "Locked while searching. Stop the search to change.",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_510,
		["color"] = v_u_25.text2,
		["position"] = UDim2.fromOffset(v_u_65 + 20, 0),
		["size"] = UDim2.new(1, -v_u_65 * 2 - 20, 1, 0)
	})
	local v_u_511 = {
		["Normal"] = 6,
		["Hard"] = 4.5,
		["Nightmare"] = 4
	}
	local function v_u_599(p_u_512) -- name: diffFacts
		-- upvalues: (copy) p_u_20, (copy) v_u_511, (copy) v_u_91, (ref) v_u_235, (copy) v_u_154, (copy) v_u_48, (ref) v_u_6
		local function v513()
			-- upvalues: (ref) p_u_20
			return p_u_20.cctx.shared.Difficulty
		end
		local v514, v_u_515 = pcall(v513)
		if v514 and type(v_u_515) == "table" then
			local v516 = v_u_515.get
			if type(v516) == "function" then
				local v517 = v_u_515.get(p_u_512)
				local v518 = v_u_515.get("Normal")
				if type(v517) ~= "table" or type(v518) ~= "table" then
					return nil
				end
				local function v521()
					-- upvalues: (ref) p_u_20, (copy) p_u_512, (ref) v_u_511
					local v519 = p_u_20.cctx.config
					local v520
					if p_u_512 == "Hard" then
						v520 = v519.INFECTION_TIME_HARD
					elseif p_u_512 == "Nightmare" then
						v520 = v519.INFECTION_TIME_NIGHTMARE
					else
						v520 = v519.INFECTION_TIME
					end
					if type(v520) == "number" and v520 > 0 then
						v_u_511[p_u_512] = v520 / 60
					end
				end
				pcall(v521)
				local v522 = v517.raidMinutes
				local v_u_523 = tonumber(v522) or 20
				local function v530()
					-- upvalues: (ref) v_u_91, (ref) v_u_235, (ref) v_u_154, (ref) v_u_48, (copy) v_u_515, (copy) p_u_512, (ref) v_u_523
					for _, v525 in v_u_91 do
						if v525.id ~= v_u_235 then
							continue
						end
					end
					local v525 = v_u_154(v_u_48.mapId)
					local v526 = v_u_515.raidMinutes
					local v527 = p_u_512
					local v528
					if v525 then
						v528 = v525.id
					else
						v528 = nil
					end
					local v529 = tonumber(v526(v527, v528))
					if v529 and v529 > 0 then
						v_u_523 = v529
					end
				end
				pcall(v530)
				local v531 = v517.density
				local v532 = tonumber(v531) or 1
				local v533 = v518.density
				local v534 = tonumber(v533) or 1
				local v535 = (v532 / math.max(0.01, v534) - 1) * 100 + 0.5
				local v536 = math.floor(v535)
				local v537 = v517.lootValueMul
				local v_u_538 = tonumber(v537)
				local v539 = v517.hazardPay
				local v_u_540 = tonumber(v539)
				local v_u_541 = false
				local function v544()
					-- upvalues: (ref) v_u_541, (copy) v_u_515
					local v542 = v_u_515.tiersOn
					local v543
					if type(v542) == "function" then
						v543 = v_u_515.tiersOn() == true
					else
						v543 = false
					end
					v_u_541 = v543
				end
				pcall(v544)
				local v545
				if v_u_541 then
					v545 = v_u_6[p_u_512]
				else
					v545 = nil
				end
				if v_u_541 then
					pcall(function()
						-- upvalues: (ref) v_u_538, (copy) v_u_515, (copy) p_u_512, (ref) v_u_540
						local v546 = v_u_515.lootValueMul
						local v547 = p_u_512
						v_u_538 = tonumber(v546(v547))
						local v548 = v_u_515.hazardPay
						local v549 = p_u_512
						v_u_540 = tonumber(v548(v549))
					end)
				end
				local v550 = p_u_512 ~= "Normal"
				local v551 = v_u_511[p_u_512] or 6
				local v552
				if v551 == math.floor(v551) then
					v552 = ("%d"):format(v551)
				else
					v552 = ("%.1f"):format(v551)
				end
				local v553 = {}
				local v554 = {}
				if p_u_512 == "Nightmare" then
					table.insert(v553, {
						["label"] = "Time",
						["value"] = "Night only"
					})
				end
				if v536 > 0 then
					local v555 = {
						["label"] = "Infected",
						["value"] = nil,
						["value"] = ("+%d%%"):format(v536)
					}
					table.insert(v553, v555)
					table.insert(v554, ("+%d%% infected"):format(v536))
				else
					table.insert(v553, {
						["label"] = "Infected",
						["value"] = "Standard"
					})
					table.insert(v554, "Standard infected")
				end
				if v_u_538 then
					local v556 = v_u_538 - 1
					local v557 = math.abs(v556) < 0.005 and "Standard" or ("x%.2f"):format(v_u_538)
					table.insert(v553, {
						["label"] = "Loot value",
						["value"] = nil,
						["value"] = v557
					})
					local v558 = v557 == "Standard" and "Standard loot" or "Loot " .. v557
					if v545 then
						if v557 == "Standard" then
							v558 = v545.fact
						else
							v558 = v558 .. "  \194\183  " .. v545.fact
						end
					end
					table.insert(v554, v558)
				end
				if v545 then
					local v559 = {
						["label"] = "Gold guns",
						["value"] = nil,
						["value"] = v545.gold
					}
					table.insert(v553, v559)
				end
				if v_u_540 and v_u_540 > 0 then
					local v560 = v_u_540 * 100 + 0.5
					local v561 = math.floor(v560)
					local v562 = {
						["label"] = "Hazard pay",
						["value"] = nil,
						["wide"] = nil,
						["value"] = ("%d%% of FIR value in cash"):format(v561),
						["wide"] = v545 and true or nil
					}
					table.insert(v553, v562)
					table.insert(v554, ("%d%% hazard pay"):format(v561))
				end
				table.insert(v553, {
					["label"] = "Scratches",
					["value"] = nil,
					["value"] = v550 and "Can infect" or "Never infect"
				})
				if v550 then
					table.insert(v554, "Scratches infect")
				end
				local v563 = {
					["label"] = "Bites turn you in",
					["value"] = nil,
					["value"] = v552 .. " min"
				}
				table.insert(v553, v563)
				if p_u_512 ~= "Normal" then
					local v564 = {
						["label"] = "Runners",
						["value"] = nil,
						["value"] = p_u_512 == "Nightmare" and "Most" or "More"
					}
					table.insert(v553, v564)
					local v565, v566 = pcall(function()
						-- upvalues: (copy) v_u_515, (copy) p_u_512
						return v_u_515.ammoCountTimeMul(p_u_512, "Night")
					end)
					if v565 and (type(v566) == "number" and v566 > 1.001) then
						local v567 = {
							["label"] = "Ammo per find at night",
							["value"] = nil
						}
						local v568 = (v566 - 1) * 100 + 0.5
						v567.value = ("+%d%%"):format((math.floor(v568)))
						table.insert(v553, v567)
					end
					local v569, v570 = pcall(function()
						-- upvalues: (copy) v_u_515, (copy) p_u_512
						return v_u_515.nightLootMul(p_u_512, "Dusk")
					end)
					local v571, v572 = pcall(function()
						-- upvalues: (copy) v_u_515, (copy) p_u_512
						return v_u_515.nightLootMul(p_u_512, "Night")
					end)
					local v573
					if v569 and type(v570) == "number" then
						local v574 = (v570 - 1) * 100 + 0.5
						v573 = math.floor(v574)
					else
						v573 = 0
					end
					local v575
					if v571 and type(v572) == "number" then
						local v576 = (v572 - 1) * 100 + 0.5
						v575 = math.floor(v576)
					else
						v575 = 0
					end
					if v573 > 0 or v575 > 0 then
						local v577 = {
							["label"] = "Rarer loot at dusk, night",
							["value"] = nil,
							["value"] = ("+%d%%, +%d%%"):format(v573, v575)
						}
						table.insert(v553, v577)
						table.insert(v554, ("Rarer loot at dusk +%d%%, night +%d%%"):format(v573, v575))
					end
				end
				local v578 = v517.bosses
				local v579 = type(v578) == "table" and #v517.bosses or 0
				if v579 > 0 then
					local v580 = {
						["label"] = "Bosses",
						["value"] = nil,
						["value"] = tostring(v579)
					}
					table.insert(v553, v580)
				end
				local v_u_581 = false
				local function v585()
					-- upvalues: (ref) v_u_91, (ref) v_u_235, (ref) v_u_154, (ref) v_u_48, (ref) v_u_581
					for _, v583 in v_u_91 do
						if v583.id ~= v_u_235 then
							continue
						end
					end
					local v583 = v_u_154(v_u_48.mapId)
					local v584
					if v583 == nil then
						v584 = false
					else
						v584 = v583.teaser == true
					end
					v_u_581 = v584
				end
				pcall(v585)
				if not v_u_581 then
					local v586 = {
						["label"] = "Raid",
						["value"] = nil,
						["value"] = ("%d min"):format(v_u_523)
					}
					table.insert(v553, v586)
					table.insert(v554, ("%d min raid"):format(v_u_523))
				end
				local v587 = v_u_581 and "" or ("Raids last %d min. "):format(v_u_523)
				local v588
				if p_u_512 == "Normal" then
					local v_u_589 = "town"
					local function v593()
						-- upvalues: (ref) v_u_91, (ref) v_u_235, (ref) v_u_154, (ref) v_u_48, (ref) v_u_589
						for _, v591 in v_u_91 do
							if v591.id ~= v_u_235 then
								continue
							end
						end
						local v591 = v_u_154(v_u_48.mapId)
						if v591 then
							local v592 = v591.noun
							if type(v592) == "string" then
								v_u_589 = v591.noun
							end
						end
					end
					pcall(v593)
					v588 = ("The %s as it is. %sBites turn you in %s min; a scratch never infects."):format(v_u_589, v587, v552)
				elseif p_u_512 == "Hard" then
					v588 = ("More of them, and faster. %sEven a scratch can infect; bites turn you in %s min."):format(v587, v552)
				else
					v588 = ("Only at night, the most of them. %sEven a scratch can infect; bites turn you in %s min."):format(v587, v552)
				end
				if v545 then
					local v594 = v545.sub
					local v595 = (v_u_540 or 0) * 100 + 0.5
					v588 = v594:format((math.floor(v595))) .. " " .. v588
				elseif v_u_540 and v_u_540 > 0 then
					local v596 = v_u_540 * 100 + 0.5
					v588 = v588 .. (" Extracting pays %d%% of your found-in-raid value in cash on top."):format((math.floor(v596)))
				end
				local v597, v598 = pcall(function()
					return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Config", 5))).flag("RaidMods") == true
				end)
				if v597 and v598 then
					v588 = v588 .. " Random conditions can appear in any raid."
				end
				return {
					["sub"] = v588,
					["lines"] = v553,
					["facts"] = table.concat(v554, "  \194\183  ")
				}
			end
		end
		return nil
	end
	v70("Difficulty", 10)
	local v600 = v_u_23.new("Frame", {
		["Name"] = "Difficulty",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 11,
		["Size"] = UDim2.new(1, 0, 0, v_u_27 and 96 or 112)
	}, v_u_60)
	v_u_23.layout(v600, "h", 8)
	local v_u_601 = {}
	local v602
	if v_u_47.pvHard() then
		v602 = v_u_47.pv().diffs(v_u_5)
	else
		v602 = v_u_5
	end
	for v603, v_u_604 in v602 do
		local v605 = v_u_23.new
		local v606 = "TextButton"
		local v607 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["Name"] = v_u_604.id,
			["BackgroundColor3"] = v_u_25.raised,
			["LayoutOrder"] = v603
		}
		local v608
		if v_u_47.pvHard() then
			v608 = UDim2.new(1, 0, 1, 0)
		else
			v608 = UDim2.new(0.3333333333333333, -5.333333333333333, 1, 0)
		end
		v607.Size = v608
		local v609 = v605(v606, v607, v600)
		v609.SelectionImageObject = v_u_23.selectionImage()
		local v610 = v_u_23.stroke(v609, v_u_25.line)
		local v611 = v_u_23.new("Frame", {
			["Name"] = "Top",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["BackgroundColor3"] = v_u_25.accent,
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v609)
		local v612 = v_u_23.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v609,
			["text"] = v_u_604.id,
			["position"] = UDim2.fromOffset(v_u_65, 8),
			["size"] = UDim2.new(1, -v_u_65 * 2 - 18, 0, 22)
		})
		local v613 = v_u_23.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v609,
			["text"] = v_u_604.line,
			["color"] = v_u_25.text2,
			["position"] = UDim2.fromOffset(v_u_65, 32),
			["size"] = UDim2.new(1, -v_u_65 * 2, 0, 34)
		})
		v613.TextYAlignment = Enum.TextYAlignment.Top
		local v_u_614 = {
			["btn"] = nil,
			["stroke"] = nil,
			["top"] = nil,
			["name"] = nil,
			["req"] = nil,
			["lock"] = nil,
			["locked"] = false,
			["hover"] = false,
			["sub"] = nil,
			["line"] = nil,
			["btn"] = v609,
			["stroke"] = v610,
			["top"] = v611,
			["name"] = v612,
			["req"] = v_u_23.label({
				["parent"] = nil,
				["name"] = "Req",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v609,
				["color"] = v_u_25.muted,
				["position"] = UDim2.new(0, v_u_65, 1, -22),
				["size"] = UDim2.new(1, -v_u_65 * 2, 0, 14)
			}),
			["lock"] = v_u_23.icon("lock", {
				["parent"] = nil,
				["size"] = 14,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v609,
				["color"] = v_u_25.muted,
				["position"] = UDim2.new(1, -v_u_65, 0, 12),
				["anchor"] = Vector2.new(1, 0)
			}),
			["sub"] = v613,
			["line"] = v_u_604.line
		}
		v_u_601[v_u_604.id] = v_u_614
		v609.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_614, (copy) v_u_23, (copy) v_u_24, (copy) v_u_47
			v_u_614.hover = true
			v_u_23.sound(v_u_24.sounds.hover)
			v_u_47.paint()
		end)
		v609.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_614, (copy) v_u_47
			v_u_614.hover = false
			v_u_47.paint()
		end)
		v609.Activated:Connect(function()
			-- upvalues: (copy) v_u_614, (copy) v_u_23, (copy) v_u_24, (copy) v_u_604, (copy) v_u_47, (copy) p_u_20
			if v_u_614.locked then
				v_u_23.sound(v_u_24.sounds.error)
				v_u_23.toast(v_u_604.id .. " is locked", "warn", v_u_47.dl(v_u_604.id).long)
				if v_u_604.id == "Nightmare" and (p_u_20.openTask and not (v_u_47.ladder and v_u_47.ladder.on())) then
					p_u_20.openTask("doc_final")
				end
			else
				v_u_47.choose("difficulty", v_u_604.id)
			end
		end)
		v_u_23.tooltip(v609, function()
			-- upvalues: (copy) v_u_47, (copy) v_u_599, (copy) v_u_604, (copy) v_u_614
			local v615 = v_u_47.pvFacts((v_u_599(v_u_604.id)))
			local v616 = {}
			for _, v617 in not v615 and {} or v615.lines do
				table.insert(v616, v617)
			end
			if not v615 then
				for _, v618 in v_u_604.tags do
					table.insert(v616, {
						["label"] = nil,
						["value"] = "",
						["label"] = v618
					})
				end
			end
			local v619
			if v615 then
				v619 = v615.sub
			else
				v619 = v_u_604.sub
			end
			if v_u_614.locked then
				v619 = v619 .. " " .. v_u_47.dl(v_u_604.id).long
			end
			return {
				["title"] = string.upper(v_u_604.id),
				["body"] = v619,
				["lines"] = v616
			}
		end)
	end
	local v_u_620 = v_u_23.new("Frame", {
		["Name"] = "DiffFacts",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 12,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.pad(v_u_620, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	local v_u_621 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Facts",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_620,
		["color"] = v_u_25.text2
	})
	v_u_47.taskNoteBox = v_u_23.new("Frame", {
		["Name"] = "TaskNote",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 13,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.pad(v_u_47.taskNoteBox, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	v_u_47.taskNote = v_u_23.label({
		["parent"] = nil,
		["name"] = "Note",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_47.taskNoteBox,
		["color"] = v_u_25.accent
	})
	pcall(function()
		-- upvalues: (copy) v_u_47, (copy) p_u_20, (copy) v_u_246, (copy) v_u_271, (copy) v_u_620, (copy) v_u_48, (copy) v_u_160, (copy) v_u_176, (copy) v_u_55, (copy) v_u_27, (copy) v_u_52
		v_u_47.ladder = p_u_20.cctx.lib.PlayLadder.attach(p_u_20, v_u_47, {
			["op"] = v_u_246,
			["rows"] = v_u_271,
			["facts"] = v_u_620,
			["sel"] = v_u_48,
			["map"] = v_u_160,
			["view"] = v_u_176,
			["w"] = v_u_55,
			["compact"] = v_u_27,
			["conns"] = v_u_52,
			["pvpve"] = v_u_47.pvHard()
		})
	end)
	v70("Time of day", 20, v_u_47.why().WEATHER)
	local v_u_622 = v_u_23.new("Frame", {
		["Name"] = "Time",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 21,
		["Size"] = UDim2.new(1, 0, 0, v_u_24.touch(v_u_27 and 48 or 56))
	}, v_u_60)
	v_u_23.layout(v_u_622, "h", 8)
	local v_u_623 = {}
	for v624, v_u_625 in v_u_7 do
		local v_u_626 = v_u_23.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["Name"] = v_u_625.id,
			["BackgroundColor3"] = v_u_25.raised,
			["LayoutOrder"] = v624,
			["Size"] = UDim2.new(0.25, -6, 1, 0)
		}, v_u_622)
		v_u_626.SelectionImageObject = v_u_23.selectionImage()
		local v_u_627 = v_u_23.stroke(v_u_626, v_u_25.line)
		local v628 = {
			["btn"] = v_u_626,
			["stroke"] = v_u_627,
			["l1"] = v_u_23.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = 16,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_626,
				["text"] = v_u_625.text,
				["position"] = UDim2.fromOffset(0, 6),
				["size"] = UDim2.new(1, 0, 0.5, -2)
			}),
			["l2"] = v_u_23.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v_u_626,
				["text"] = v_u_625.odds,
				["position"] = UDim2.new(0, 4, 0.5, 0),
				["size"] = UDim2.new(1, -8, 0.5, -4)
			})
		}
		v_u_623[v_u_625.id] = v628
		v_u_626.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_24, (copy) p_u_20, (copy) v_u_627, (copy) v_u_25
			v_u_23.sound(v_u_24.sounds.hover)
			local v629 = p_u_20.myParty()
			local v630
			if v629 == nil then
				v630 = false
			else
				local v631 = v629.searching
				v630 = type(v631) == "table"
			end
			if not v630 then
				v_u_627.Color = v_u_25.lineStrong
			end
		end)
		v_u_626.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_47
			v_u_47.paint()
		end)
		v_u_23.tooltip(v_u_626, function()
			-- upvalues: (copy) v_u_625
			return v_u_625.tip
		end)
		v_u_626.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_626
			local v632 = v_u_23.showTooltip
			local v633 = v_u_626
			pcall(v632, v633)
		end)
		v_u_626.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_23
			local v634 = v_u_23.hideTooltip
			pcall(v634)
		end)
		v_u_626.Activated:Connect(function()
			-- upvalues: (copy) p_u_20, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (copy) v_u_47, (copy) v_u_23, (copy) v_u_24, (copy) v_u_625
			local v635 = p_u_20.myParty()
			local v636
			if v635 == nil or #v635.members <= 1 then
				v636 = false
			else
				v636 = not p_u_20.isLeader()
			end
			local v637
			if v636 then
				local v638 = v_u_48.mapId
				for _, v640 in v_u_91 do
					if v640.id ~= v638 then
						continue
					end
				end
				local v640 = nil
				v637 = v640 or v_u_154(v_u_48.mapId)
			else
				v637 = v_u_154(v_u_48.mapId)
			end
			local v641 = type(v637) == "table" and v637.fixedTime or nil
			local v642
			if type(v641) == "table" then
				v642 = v641[v_u_48.difficulty] or v641.Normal
			else
				v642 = nil
			end
			if v_u_47.timeLocked() then
				v642 = v_u_47.lockedTime(v642)
			end
			if v642 then
				v_u_23.sound(v_u_24.sounds.error)
				local v643 = v_u_23.toast
				local v644 = "%s sets its own time"
				local v645 = v_u_47.displayName
				local v646 = p_u_20.myParty()
				local v647
				if v646 == nil or #v646.members <= 1 then
					v647 = false
				else
					v647 = not p_u_20.isLeader()
				end
				local v650
				if v647 then
					local v649 = v_u_48.mapId
					for _, v650 in v_u_91 do
						if v650.id ~= v649 then
							continue
						end
					end
					v650 = nil
					if not v650 then
						v650 = v_u_154(v_u_48.mapId)
					end
				else
					v650 = v_u_154(v_u_48.mapId)
				end
				v643(v644:format(v645(v650)), "warn", ("Underground: %s on the surface, dark below."):format(string.lower(v642)))
				return
			elseif v_u_48.difficulty == "Nightmare" and v_u_625.id ~= "Night" then
				v_u_23.sound(v_u_24.sounds.error)
				v_u_23.toast("Nightmare is always at night", "warn")
			else
				v_u_47.choose("timeOfDay", v_u_625.id)
			end
		end)
	end
	local v651 = v_u_23.new("Frame", {
		["Name"] = "TimeEffect",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 22,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.pad(v651, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	local v_u_652 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Effect",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v651,
		["color"] = v_u_25.text2
	})
	local v_u_653 = v70("Extract intel", 30, "")
	local v_u_654 = v_u_23.new("Frame", {
		["Name"] = "Intel",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 31,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.layout(v_u_654, "v", 4)
	local v_u_655 = v70("Needed", 35, "")
	local v_u_656 = v_u_23.new("Frame", {
		["Name"] = "Needed",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 36,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.pad(v_u_656, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	local v_u_657 = v_u_27 and 44 or 52
	local v_u_658 = ""
	local function v_u_669() -- name: paintNeeded
		-- upvalues: (copy) v_u_26, (copy) v_u_655, (ref) v_u_658, (copy) v_u_656, (copy) v_u_23, (copy) v_u_657
		local v659 = v_u_26.wishList
		local v660 = type(v659) ~= "function" and {} or v_u_26.wishList()
		local v661 = table.concat(v660, ",")
		local v662 = v_u_655:FindFirstChild("Right")
		if v662 then
			local v663
			if #v660 > 0 then
				local v664 = #v660
				v663 = tostring(v664)
			else
				v663 = ""
			end
			v662.Text = v663
		end
		if v661 == v_u_658 and #v_u_656:GetChildren() > 1 then
			return
		else
			v_u_658 = v661
			v_u_26.clear(v_u_656)
			if #v660 == 0 then
				v_u_26.empty(v_u_656, "Star an item in TRADERS, TASKS or COLLECTION to mark it as needed. In a raid it shows a star, so you do not walk past it.", 1).Size = UDim2.new(1, 0, 0, 0)
			else
				local v665 = v_u_23.new("Frame", {
					["Name"] = "Grid",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_656)
				v_u_23.new("UIGridLayout", {
					["CellSize"] = UDim2.fromOffset(v_u_657, v_u_657),
					["CellPadding"] = UDim2.fromOffset(4, 4),
					["SortOrder"] = Enum.SortOrder.LayoutOrder
				}, v665)
				for v666, v667 in v660 do
					local v668 = {
						["size"] = v_u_657,
						["order"] = v666
					}
					v_u_26.itemCell(v665, v667, v668)
				end
			end
		end
	end
	if p_u_20.changed then
		local v670 = p_u_20.changed
		table.insert(v_u_52, v670:Connect(function(p671)
			-- upvalues: (copy) v_u_669
			if p671 == "wish" then
				task.defer(v_u_669)
			end
		end))
	end
	v70("Loadout", 40)
	local v672 = v_u_23.new("Frame", {
		["Name"] = "Loadout",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 41,
		["BackgroundColor3"] = v_u_25.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.stroke(v672, v_u_25.line)
	v_u_23.pad(v672, {
		v_u_65,
		v_u_65,
		10,
		10
	})
	v_u_23.layout(v672, "v", 2)
	local v_u_673 = {}
	for v674, v675 in v_u_11 do
		local _, v676 = v_u_26.stat(v672, v675[2], "-", v674)
		v_u_673[v675[1]] = v676
		v676.FontFace = v_u_24.font.bodyMedium
		v676.TextSize = 14
	end
	v_u_23.divider({
		["parent"] = nil,
		["order"] = 20,
		["parent"] = v672
	})
	local _, v_u_677 = v_u_26.stat(v672, "Kit sells for", "$0", 21, v_u_25.accent)
	local _, v_u_678 = v_u_26.stat(v672, "Weight", "0 kg", 22)
	local v_u_679 = v_u_23.label({
		["parent"] = nil,
		["name"] = "FreeNote",
		["text"] = "Free raid: you go in with a random kit. Your loadout stays safe in the stash.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 23,
		["visible"] = false,
		["parent"] = v672,
		["color"] = v_u_25.info
	})
	v_u_23.button({
		["parent"] = nil,
		["text"] = "Edit loadout",
		["kind"] = "ghost",
		["icon"] = "backpack",
		["height"] = 36,
		["order"] = 42,
		["onClick"] = nil,
		["parent"] = v_u_60,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_20
			p_u_20.setTab("character")
		end
	})
	v70("Free raid", 50)
	local v680 = v_u_23.new("Frame", {
		["Name"] = "Free",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 51,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.layout(v680, "v", 2)
	v_u_23.pad(v680, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	local _, v_u_682 = v_u_23.toggle({
		["parent"] = nil,
		["label"] = "Random kit, nothing at stake",
		["width"] = nil,
		["order"] = 1,
		["onChange"] = nil,
		["parent"] = v680,
		["width"] = v_u_55 - v_u_65 * 2,
		["onChange"] = function(p681) -- name: onChange
			-- upvalues: (copy) v_u_47
			v_u_47.choose("freeRaid", p681)
		end
	})
	local v_u_683 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Cooldown",
		["text"] = "",
		["style"] = "monoS",
		["order"] = 2,
		["parent"] = v680
	})
	v_u_47.privSec = v70(v_u_47.pvPublic() and "Public raids" or "Private raid", 55)
	local v684 = v_u_23.new("Frame", {
		["Name"] = "Private",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 56,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_60)
	v_u_23.layout(v684, "v", 2)
	v_u_23.pad(v684, {
		v_u_65,
		v_u_65,
		0,
		0
	})
	local v686, v_u_687 = v_u_23.toggle({
		["parent"] = nil,
		["name"] = "PrivateRaid",
		["label"] = "Only my squad, no other survivors",
		["width"] = nil,
		["order"] = 1,
		["onChange"] = nil,
		["parent"] = v684,
		["width"] = v_u_55 - v_u_65 * 2,
		["onChange"] = function(p685) -- name: onChange
			-- upvalues: (copy) v_u_47
			v_u_47.choose("privateRaid", p685)
		end
	})
	local v_u_689, v_u_690 = v_u_23.toggle({
		["parent"] = nil,
		["name"] = "PrivateFriends",
		["label"] = "Let friends\' squads in",
		["width"] = nil,
		["order"] = 2,
		["visible"] = false,
		["onChange"] = nil,
		["parent"] = v684,
		["width"] = v_u_55 - v_u_65 * 2,
		["onChange"] = function(p688) -- name: onChange
			-- upvalues: (copy) v_u_47
			v_u_47.choose("privateFriends", p688)
		end
	})
	local v_u_691 = v_u_23.label({
		["parent"] = nil,
		["name"] = "PrivateNote",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v684,
		["color"] = v_u_25.text2
	})
	v_u_23.tooltip(v686, function()
		-- upvalues: (copy) v_u_47
		return {
			["title"] = "PRIVATE RAID",
			["body"] = nil,
			["body"] = v_u_47.why().privateTip()
		}
	end)
	v_u_23.tooltip(v_u_689, function()
		return {
			["title"] = "FRIENDS\' SQUADS",
			["body"] = "Squads with a Roblox friend of one of your squad members may still join your private raid. Everybody else stays out."
		}
	end)
	if v_u_47.pvPublic() then
		v686.Visible = false
	end
	if v_u_47.pvPublic() then
		local v_u_692 = p_u_20.cctx.lib
		local v693, v694 = pcall(function()
			-- upvalues: (copy) v_u_692
			return v_u_692.MenuPlayQueue
		end)
		if v693 and type(v694) == "table" then
			local v695 = v694.build
			if type(v695) == "function" then
				local v696 = v694.build
				local v697 = {
					["width"] = nil,
					["order"] = 57,
					["width"] = v_u_55 - v_u_65 * 2
				}
				local v698, _, v699 = pcall(v696, p_u_20, v_u_60, v697)
				if not v698 or type(v699) ~= "table" then
					v699 = nil
				end
				v_u_47.queueApi = v699
			end
		end
		local v700, v701 = pcall(function()
			-- upvalues: (copy) v_u_692
			return v_u_692.MenuInputQueue
		end)
		if v700 and type(v701) == "table" then
			local v702 = v701.build
			if type(v702) == "function" then
				local v703 = v701.build
				local v704 = {
					["width"] = nil,
					["order"] = 58,
					["width"] = v_u_55 - v_u_65 * 2
				}
				local v705, _, v706 = pcall(v703, p_u_20, v_u_60, v704)
				if not v705 or type(v706) ~= "table" then
					v706 = nil
				end
				v_u_47.inputApi = v706
			end
		end
		local v707, v708 = pcall(function()
			-- upvalues: (copy) v_u_692
			return v_u_692.MenuWipeTimer
		end)
		if v707 and type(v708) == "table" then
			local v709 = v708.mountLine
			if type(v709) == "function" then
				local v710 = v708.mountLine
				local v711, v712 = pcall(v710, p_u_20, v_u_60, {
					["order"] = 59
				})
				if not v711 or type(v712) ~= "table" then
					v712 = nil
				end
				v_u_47.wipeLine = v712
			end
		end
	end
	v_u_23.new("Frame", {
		["Name"] = "Spacer",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 99,
		["Size"] = UDim2.new(1, 0, 0, 8)
	}, v_u_60)
	local v_u_713 = v_u_23.new("Frame", {
		["Name"] = "MoreFade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Active"] = false,
		["BackgroundColor3"] = v_u_25.bgDeep,
		["Position"] = UDim2.new(0, 0, 1, -v_u_59 - 12 - 40),
		["Size"] = UDim2.new(1, 0, 0, 52)
	}, v_u_56)
	v_u_23.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.55, 0.3),
			NumberSequenceKeypoint.new(0.77, 0),
			NumberSequenceKeypoint.new(1, 0)
		})
	}, v_u_713)
	local function v720() -- name: updateMoreFade
		-- upvalues: (copy) v_u_47, (copy) v_u_713, (copy) v_u_24, (copy) v_u_60
		if v_u_47.sheet then
			v_u_713.Visible = false
		else
			local v714 = v_u_24.uiScale()
			local v715 = math.max(v714, 0.01)
			local v716 = v_u_60.AbsoluteCanvasSize.Y / v715
			local v717 = v_u_60.AbsoluteWindowSize.Y / v715
			local v718 = v_u_713
			local v719
			if v717 + 4 < v716 then
				v719 = v_u_60.CanvasPosition.Y < v716 - v717 - 8
			else
				v719 = false
			end
			v718.Visible = v719
		end
	end
	local v721 = v_u_60:GetPropertyChangedSignal("CanvasPosition")
	table.insert(v_u_52, v721:Connect(v720))
	local v722 = v_u_60:GetPropertyChangedSignal("AbsoluteCanvasSize")
	table.insert(v_u_52, v722:Connect(v720))
	local v_u_723 = v_u_23.new("Frame", {
		["Name"] = "Deploy",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.08,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.bg,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, v_u_59)
	}, v_u_56)
	v_u_23.stroke(v_u_723, v_u_25.line)
	v_u_23.pad(v_u_723, {
		16,
		16,
		12,
		14
	})
	local v_u_724 = v_u_23.new("Frame", {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.accent,
		["Position"] = UDim2.fromOffset(-16, -12),
		["Size"] = UDim2.new(1, 32, 0, 2)
	}, v_u_723)
	local v_u_725 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Summary",
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_723,
		["color"] = v_u_25.text,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v_u_725.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_726 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_723,
		["position"] = UDim2.fromOffset(0, 20),
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v_u_726.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_727 = v_u_23.new("Frame", {
		["Name"] = "SearchFill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_25.accent,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_724)
	local v_u_728 = v_u_27 and 32 or 46
	local v_u_729 = v_u_27 and 12 or 13
	local v730 = v_u_27 and 100 or 124
	local v_u_731 = v_u_729 + 2 + v_u_728
	local v_u_732 = v_u_24.touch(v_u_27 and 38 or 40)
	local v_u_733 = v_u_23.new("Frame", {
		["Name"] = "Search",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, v_u_731)
	}, v_u_723)
	local v_u_734 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Caption",
		["text"] = "At the latest",
		["style"] = "caps",
		["textSize"] = nil,
		["color"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_733,
		["textSize"] = v_u_729,
		["color"] = v_u_25.text2,
		["size"] = UDim2.fromOffset(v730, v_u_729 + 2)
	})
	local v_u_735 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Clock",
		["text"] = "0:00",
		["style"] = "monoL",
		["textSize"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_733,
		["textSize"] = v_u_728,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(0, v_u_729 + 2),
		["size"] = UDim2.fromOffset(v730, v_u_728)
	})
	v_u_735.TextYAlignment = Enum.TextYAlignment.Center
	local v736 = v_u_23.icon
	local v737 = {
		["parent"] = nil,
		["size"] = nil,
		["thickness"] = 2,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v_u_733,
		["size"] = v_u_27 and 18 or 22,
		["color"] = v_u_25.accent
	}
	local v738 = UDim2.fromOffset
	local v739 = v_u_729 + 2
	local v740 = v_u_728 / 2
	v737.position = v738(2, v739 + math.floor(v740))
	v737.anchor = Vector2.new(0, 0.5)
	local v_u_741 = v736("arrowUp", v737)
	v_u_741.Name = "DeployArrow"
	v_u_741.Visible = false
	local v_u_742 = {}
	for v743 = 1, 3 do
		local v744 = v_u_23.new
		local v745 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Name"] = "Dot" .. v743,
			["BackgroundColor3"] = v_u_25.accent,
			["AnchorPoint"] = Vector2.new(0, 0.5)
		}
		local v746 = UDim2.fromOffset
		local v747 = (v_u_27 and 26 or 34) + (v743 - 1) * 12
		local v748 = v_u_729 + 2
		local v749 = v_u_728 / 2
		v745.Position = v746(v747, v748 + math.floor(v749))
		v745.Size = UDim2.fromOffset(6, 6)
		local v750 = v744("Frame", v745, v_u_733)
		table.insert(v_u_742, v750)
	end
	local v751 = v730 + 12
	local v752 = v_u_27 and 15 or 18
	local v_u_753 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_733,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(v751, 0),
		["size"] = UDim2.new(1, -v751, 0, v_u_27 and 15 or 16)
	})
	local v_u_754 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["textSize"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_733,
		["textSize"] = v_u_27 and 12 or 13,
		["color"] = v_u_25.text,
		["position"] = UDim2.fromOffset(v751, v_u_27 and 16 or 21),
		["size"] = UDim2.new(1, -v751, 0, v752)
	})
	local v_u_755 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Hint",
		["text"] = "",
		["style"] = "small",
		["textSize"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_733,
		["textSize"] = v_u_27 and 12 or 13,
		["color"] = v_u_25.text2,
		["position"] = UDim2.fromOffset(v751, v_u_27 and 31 or 41),
		["size"] = UDim2.new(1, -v751, 0, v752)
	})
	for _, v756 in {
		v_u_734,
		v_u_753,
		v_u_754,
		v_u_755
	} do
		v756.TextTruncate = Enum.TextTruncate.AtEnd
	end
	local v_u_757 = false
	local v_u_758 = {}
	local v_u_759, v_u_760 = v_u_23.button({
		["parent"] = nil,
		["text"] = "Deploy",
		["kind"] = "primary",
		["icon"] = "arrowUp",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_723,
		["size"] = UDim2.new(1, 0, 0, v_u_24.touch(v_u_27 and 44 or 56)),
		["position"] = UDim2.fromScale(0, 1),
		["anchor"] = Vector2.new(0, 1),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_47
			v_u_47.deploy()
		end
	})
	v_u_759.Name = "DeployButton"
	if v_u_760.label then
		v_u_760.label.TextSize = v_u_27 and 20 or 24
	end
	local v_u_761 = v_u_59
	local function v_u_769(p762) -- name: setDepH
		-- upvalues: (ref) v_u_761, (copy) v_u_723, (copy) v_u_47, (copy) v_u_60, (copy) v_u_713, (copy) v_u_24
		if p762 == v_u_761 then
			return
		else
			v_u_761 = p762
			v_u_723.Size = UDim2.new(1, 0, 0, p762)
			if v_u_47.sheet then
				v_u_47.sheet.setDockH(p762)
				return
			else
				v_u_60.Size = UDim2.new(1, 9, 1, -p762 - 12)
				v_u_713.Position = UDim2.new(0, 0, 1, -p762 - 12 - 40)
				if v_u_47.sheet then
					v_u_713.Visible = false
				else
					local v763 = v_u_24.uiScale()
					local v764 = math.max(v763, 0.01)
					local v765 = v_u_60.AbsoluteCanvasSize.Y / v764
					local v766 = v_u_60.AbsoluteWindowSize.Y / v764
					local v767 = v_u_713
					local v768
					if v766 + 4 < v765 then
						v768 = v_u_60.CanvasPosition.Y < v765 - v766 - 8
					else
						v768 = false
					end
					v767.Visible = v768
				end
			end
		end
	end
	local v_u_770 = v_u_27 and 20 or 18
	local v_u_771 = 0
	local v_u_772 = v_u_23.label({
		["parent"] = nil,
		["name"] = "DeployPlan",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_723,
		["color"] = v_u_25.accent,
		["position"] = UDim2.fromOffset(0, v_u_27 and 38 or 40),
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	v_u_772.TextTruncate = Enum.TextTruncate.AtEnd
	v_u_772.Visible = false
	local function v_u_782() -- name: paintPlanLine
		-- upvalues: (ref) v_u_234, (ref) v_u_1, (ref) v_u_757, (copy) v_u_772, (ref) v_u_771, (copy) v_u_770, (copy) v_u_769, (copy) v_u_59, (ref) v_u_4
		local v773
		if v_u_234 then
			local v774 = v_u_234
			v773 = tonumber(v774:GetAttribute("DeployCloseAt")) or 0
		else
			v773 = 0
		end
		local v775 = (v773 or 0) - v_u_1.now()
		local v776 = (v773 or 0) > 0 and v775 > -1 and not v_u_757
		if v776 then
			local v777
			if v_u_234 == nil then
				v777 = false
			else
				v777 = v_u_234:GetAttribute("DeployClosed") == true
			end
			v776 = not v777
		end
		local v778
		if v776 then
			local v779 = math.floor(v775)
			local v780 = math.max(0, v779)
			local v781
			if v780 >= 3600 then
				v781 = ("%d:%02d:%02d"):format(v780 // 3600, v780 % 3600 // 60, v780 % 60)
			else
				v781 = ("%d:%02d"):format(v780 // 60, v780 % 60)
			end
			v778 = ("Deployments close in %s (%s your time)"):format(v781, (os.date("%H:%M", v773)))
			if v_u_772.Text ~= v778 then
				v_u_772.Text = v778
			end
		else
			v778 = ""
		end
		v_u_772.Visible = v776
		v_u_771 = not v776 and 0 or v_u_770
		if not v_u_757 then
			v_u_769(v_u_59 + v_u_771)
		end
		if v_u_4:GetAttribute("MenuPlayDeployPlan") ~= v778 then
			v_u_4:SetAttribute("MenuPlayDeployPlan", v778)
		end
	end
	local v_u_783 = 0
	local v784 = v22.Heartbeat
	local function v786(p785)
		-- upvalues: (ref) v_u_783, (copy) p_u_21, (copy) v_u_782
		v_u_783 = v_u_783 + p785
		if v_u_783 >= 1 and p_u_21.Parent then
			v_u_783 = 0
			v_u_782()
		end
	end
	table.insert(v_u_52, v784:Connect(v786))
	local function v_u_809(p787) -- name: setSearchMode
		-- upvalues: (ref) v_u_757, (copy) v_u_758, (copy) v_u_733, (copy) v_u_725, (copy) v_u_47, (copy) v_u_726, (copy) v_u_727, (copy) v_u_724, (copy) v_u_25, (copy) v_u_759, (copy) v_u_732, (copy) v_u_24, (copy) v_u_27, (copy) v_u_760, (copy) v_u_769, (copy) v_u_59, (copy) v_u_731, (ref) v_u_771, (copy) v_u_772, (copy) v_u_653, (copy) v_u_654
		if p787 ~= v_u_757 then
			v_u_757 = p787
			table.clear(v_u_758)
			v_u_733.Visible = p787
			local v788 = v_u_725
			local v789 = not p787
			if v789 then
				v789 = not v_u_47.briefPhone
			end
			v788.Visible = v789
			v_u_726.Visible = not p787
			v_u_727.Visible = p787
			local v790 = v_u_724
			local v791
			if p787 then
				v791 = v_u_25.line
			else
				v791 = v_u_25.accent
			end
			v790.BackgroundColor3 = v791
			v_u_724.Size = UDim2.new(1, 32, 0, p787 and 3 or 2)
			local v792 = v_u_759
			local v793 = UDim2.new
			local v794 = 1
			local v795 = -(v_u_47.paidChipW or 0)
			local v796 = 0
			local v797
			if p787 then
				v797 = v_u_732
			else
				v797 = v_u_24.touch(v_u_27 and 44 or 56)
			end
			v792.Size = v793(v794, v795, v796, v797)
			if v_u_47.paidChip ~= nil then
				local v798 = v_u_47.paidChip.paint
				pcall(v798)
			end
			if v_u_760.label then
				local v799 = v_u_760.label
				local v800
				if p787 then
					v800 = v_u_27 and 16 or 18
				else
					v800 = v_u_27 and 20 or 24
				end
				v799.TextSize = v800
			end
			local v801 = v_u_760._icons
			if type(v801) == "table" then
				for _, v802 in v_u_760._icons do
					v802.Visible = not p787
				end
			end
			local v803 = v_u_769
			local v804
			if p787 then
				local v805 = v_u_59
				local v806 = v_u_731 + 12 + 5 + v_u_732 + 14
				v804 = math.max(v805, v806)
			else
				v804 = v_u_59 + v_u_771
			end
			v803(v804)
			local v807 = v_u_772
			local v808 = v_u_772.Visible
			if v808 then
				v808 = not p787
			end
			v807.Visible = v808
			v_u_653.Visible = not p787
			v_u_654.Visible = not p787
		end
	end
	if v_u_47.sheet then
		local v810 = v_u_47.sheet.dock
		pcall(v810, {
			["dock"] = v_u_723,
			["deployBtn"] = v_u_759,
			["moreFade"] = v_u_713,
			["mapField"] = v_u_250,
			["mapOpen"] = function() -- name: mapOpen
				-- upvalues: (ref) v_u_279
				return v_u_279
			end,
			["foldMap"] = function() -- name: foldMap
				-- upvalues: (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250
				v_u_279 = false
				v_u_270.Visible = false
				v_u_260(false)
				v_u_251.Color = v_u_25.line
				local v811 = game:GetService("GuiService")
				local _ = v_u_271[v_u_235]
				v811.SelectedObject = v_u_250
			end
		})
	end
	if v_u_47.brief then
		local v812 = v_u_47.brief.dock
		pcall(v812, {
			["dep"] = v_u_723,
			["deployBtn"] = v_u_759,
			["summary"] = v_u_725,
			["status"] = v_u_726,
			["planLine"] = v_u_772
		})
	end
	local function v_u_864(p813, p814) -- name: paintSearch
		-- upvalues: (ref) v_u_3, (ref) v_u_12, (copy) v_u_735, (copy) v_u_741, (copy) v_u_742, (copy) v_u_734, (copy) v_u_758, (copy) v_u_23, (copy) v_u_753, (copy) v_u_754, (copy) v_u_47, (copy) v_u_755, (copy) v_u_25, (copy) v_u_729, (copy) v_u_728, (copy) v_u_727, (copy) v_u_27
		local v815 = os.clock()
		local v816
		if p813 == nil then
			v816 = false
		else
			v816 = p813.phase == "starting"
		end
		local v817 = v_u_3.REGION_NAMES
		local v818 = p814.region
		local v819 = v817[tostring(v818)]
		local v820 = not v819 and "" or "  \194\183  " .. v819
		local v821
		if v_u_12 and p813 then
			v821 = v_u_12.found(p813)
		else
			v821 = nil
		end
		v_u_735.Visible = not v816
		v_u_741.Visible = v816
		for _, v822 in v_u_742 do
			v822.Visible = v816
		end
		if v816 then
			local v823 = v_u_734
			if v_u_758[v823] ~= "Moving out" then
				v_u_758[v823] = "Moving out"
				v_u_23.setText(v823, "Moving out")
			end
			local v824 = v_u_753
			local v825 = "Deploying" .. v820
			if v_u_758[v824] ~= v825 then
				v_u_758[v824] = v825
				v_u_23.setText(v824, v825)
			end
			local v826 = p813.startedFor
			local v827 = tonumber(v826) or 0
			local v828 = v_u_754
			local v829 = v_u_47.why().connectLine
			local v830 = string.rep
			local v831 = v815 * 2
			local v832 = v829(v827, v830(".", math.floor(v831) % 3 + 1))
			if v_u_758[v828] ~= v832 then
				v_u_758[v828] = v832
				v_u_23.setText(v828, v832)
			end
			local v833 = v_u_755
			local v834 = v_u_47.why().raidLine(v821)
			if v_u_758[v833] ~= v834 then
				v_u_758[v833] = v834
				v_u_23.setText(v833, v834)
			end
			v_u_755.TextColor3 = v_u_25.text2
			for v835, v836 in v_u_742 do
				v836.BackgroundTransparency = (v815 * 1.6 - (v835 - 1) * 0.22) % 1 < 0.5 and 0 or 0.75
			end
			local v837 = v815 * 5
			local v838 = math.sin(v837) * 2 + 0.5
			local v839 = math.floor(v838)
			local v840 = v_u_741
			local v841 = UDim2.fromOffset
			local v842 = v_u_729 + 2
			local v843 = v_u_728 / 2
			v840.Position = v841(2, v842 + math.floor(v843) - v839)
			v_u_727.Size = UDim2.fromScale(0, 1)
		else
			local v844 = not p813 and 0 or p813.remaining
			local v845 = v_u_734
			if v_u_758[v845] ~= "At the latest" then
				v_u_758[v845] = "At the latest"
				v_u_23.setText(v845, "At the latest")
			end
			local v846 = v_u_735
			local v847 = not v_u_12 and "0:00" or v_u_12.clock(v844)
			if v_u_758[v846] ~= v847 then
				v_u_758[v846] = v847
				v_u_23.setText(v846, v847)
			end
			local v848 = v_u_735
			local v849
			if v844 <= 5 then
				local v850 = v815 * 3.141592653589793 * 2 / 0.9
				v849 = (0.5 - math.cos(v850) * 0.5) * 0.3
			else
				v849 = 0
			end
			v848.TextTransparency = v849
			local v851 = v_u_753
			local v852 = v_u_47.inputTitle("Searching for survivors" .. v820, v_u_753.AbsoluteSize.X)
			if v_u_758[v851] ~= v852 then
				v_u_758[v851] = v852
				v_u_23.setText(v851, v852)
			end
			local v853 = v_u_754
			local v854 = v_u_47.why().groupLine(v821)
			if v_u_758[v853] ~= v854 then
				v_u_758[v853] = v854
				v_u_23.setText(v853, v854)
			end
			if p814.regionWait == true and v_u_47.pv() then
				local v855 = v_u_753
				local v856 = v_u_47.pv().waitTitle()
				if v_u_758[v855] ~= v856 then
					v_u_758[v855] = v856
					v_u_23.setText(v855, v856)
				end
				local v857 = v_u_754
				local v858 = v_u_47.pv().waitLine()
				if v_u_758[v857] ~= v858 then
					v_u_758[v857] = v858
					v_u_23.setText(v857, v858)
				end
			end
			local v859
			if p813 then
				v859 = p813.soon
			else
				v859 = nil
			end
			if v859 then
				local v860 = v_u_755
				local v861 = "Likely sooner: " .. v_u_12.clock(v859)
				if v_u_758[v860] ~= v861 then
					v_u_758[v860] = v861
					v_u_23.setText(v860, v861)
				end
				v_u_755.TextColor3 = v_u_25.text
			else
				local v862 = v_u_755
				local v863 = v_u_47.why().stopHint(v_u_27)
				if v_u_758[v862] ~= v863 then
					v_u_758[v862] = v863
					v_u_23.setText(v862, v863)
				end
				v_u_755.TextColor3 = v_u_25.text2
			end
			v_u_727.Size = UDim2.fromScale(not p813 and 0 or p813.frac, 1)
		end
	end
	local v865 = v_u_24.isPhone
	local v866
	if type(v865) == "function" then
		v866 = v_u_24.isPhone() == true
	else
		v866 = false
	end
	local v867
	if v866 then
		local v868 = v_u_24.uiScale()
		local v869 = 11 / math.max(v868, 0.1)
		local v870 = math.ceil(v869)
		v867 = math.max(12, v870)
	else
		v867 = nil
	end
	local v871
	if v867 == nil then
		v871 = 16
	else
		local v872 = v867 * 1.25
		v871 = math.ceil(v872) * 2
	end
	local v873 = v871 - (v866 and 22 or 16)
	local v_u_874 = v_u_23.new("Frame", {
		["Name"] = "Plate",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 24, 1, -6),
		["Size"] = UDim2.new(1, -v_u_55 - 96, 0, (v_u_27 and 92 or 120) + v873)
	}, p_u_21)
	v_u_23.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h1",
		["textSize"] = nil,
		["size"] = nil,
		["parent"] = v_u_874,
		["text"] = p_u_20.cctx.player.DisplayName,
		["textSize"] = v_u_27 and 24 or 32,
		["size"] = UDim2.new(1, 0, 0, v_u_27 and 30 or 40)
	})
	local v_u_875 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Stats",
		["text"] = "",
		["style"] = "monoS",
		["position"] = nil,
		["size"] = nil,
		["textSize"] = nil,
		["wrap"] = nil,
		["parent"] = v_u_874,
		["position"] = UDim2.fromOffset(0, v_u_27 and 30 or 40),
		["size"] = UDim2.new(1, 0, 0, v871),
		["textSize"] = v867,
		["wrap"] = v866 and true or nil
	})
	local v876 = v_u_23.new("Frame", {
		["Name"] = "Radio",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, (v_u_27 and 52 or 66) + v873),
		["Size"] = UDim2.new(1, 0, 0, v866 and 36 or 40)
	}, v_u_874)
	local v_u_877 = v_u_23.new("Frame", {
		["Name"] = "Live",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_25.danger,
		["Position"] = UDim2.fromOffset(0, 5),
		["Size"] = UDim2.fromOffset(6, 6)
	}, v876)
	if not v866 then
		v_u_23.label({
			["parent"] = nil,
			["text"] = "Emergency band 121.5",
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v876,
			["color"] = v_u_25.text2,
			["position"] = UDim2.fromOffset(12, 0),
			["size"] = UDim2.new(1, -12, 0, 16)
		})
	end
	local v_u_878 = v_u_23.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["wrap"] = nil,
		["valign"] = nil,
		["parent"] = v876,
		["color"] = v_u_25.text,
		["position"] = UDim2.fromOffset(12, v866 and 0 or 16),
		["size"] = UDim2.new(1, -12, 0, v866 and 34 or 20),
		["wrap"] = v866 and true or nil,
		["valign"] = v866 and "top" or nil
	})
	local v_u_879 = {
		"...all units, Stillwater perimeter remains closed. Noise discipline in effect...",
		"...if anyone can hear this, the clinic on Route 9 is still open. Bring bandages...",
		"...repeat, do not approach the hospital after dark...",
		"...storm front moving in from the west. Expect rain through the night...",
		"...Hale\'s unit went silent at the checkpoint. Nobody goes near it alone...",
		"...the school doors are chained. Whatever is inside is loud when it wakes...",
		"...smuggler\'s boat runs at the pier. Bring cash, not questions...",
		"...Operation Hush is still in effect. Weapons free on any sound source..."
	}
	local v_u_880 = math.random(1, #v_u_879)
	local v_u_881 = 0
	(function() -- name: setLine
		-- upvalues: (ref) v_u_880, (copy) v_u_879, (copy) v_u_878, (copy) v_u_23
		v_u_880 = v_u_880 % #v_u_879 + 1
		v_u_878.Text = v_u_879[v_u_880]
		v_u_878.TextTransparency = 1
		v_u_23.tween(v_u_878, {
			["TextTransparency"] = 0
		}, "slower")
	end)()
	local function v_u_887(p882) -- name: unlocked
		-- upvalues: (copy) v_u_47, (copy) p_u_20
		if v_u_47.pvHard() then
			local v883 = p882 == "Hard"
			if p882 == "Hard" then
				return v883, "Open"
			else
				return v883, "Not available here"
			end
		elseif p882 == "Normal" then
			return true, "Open"
		elseif v_u_47.ladder and v_u_47.ladder.on() then
			return v_u_47.ladder.unlocked(p882)
		else
			local v884 = p_u_20.profile
			local v885
			if type(v884) == "table" then
				local v886 = v884.unlocked
				v885 = type(v886) == "table" and (v884.unlocked or {}) or {}
			else
				v885 = {}
			end
			if v885[p882] == true then
				return true, "Unlocked"
			else
				return false, v_u_47.dl(p882).short
			end
		end
	end
	function v_u_47.dl(p888) -- name: dl
		-- upvalues: (copy) v_u_47, (copy) p_u_20
		local v889
		if v_u_47.ladder and v_u_47.ladder.on() then
			v889 = v_u_47.ladder.lock(p888)
		else
			v889 = nil
		end
		return v889 or v_u_47.why().diffLock(p888, p_u_20.derived().hardProgress)
	end
	local function v_u_899() -- name: savedRaid
		-- upvalues: (copy) p_u_20
		local v890 = p_u_20.profile
		local v891
		if type(v890) == "table" then
			local v892 = v890.settings
			v891 = type(v892) == "table" and v890.settings or nil
		else
			v891 = nil
		end
		if not v891 then
			return nil, nil, nil
		end
		local v893 = v891.raidDifficulty
		local v894
		if type(v893) == "string" then
			v894 = v891.raidDifficulty
		else
			v894 = nil
		end
		local v895 = v891.raidTime
		local v896
		if type(v895) == "string" then
			v896 = v891.raidTime
		else
			v896 = nil
		end
		local v897 = v891.raidMap
		local v898
		if type(v897) == "string" then
			v898 = v891.raidMap
		else
			v898 = nil
		end
		return v894, v896, v898
	end
	local function v_u_908() -- name: applySavedRaid
		-- upvalues: (copy) v_u_899, (copy) v_u_48, (copy) v_u_154, (ref) v_u_235, (copy) v_u_887, (ref) v_u_7
		local v900, v901, v902 = v_u_899()
		if v_u_48.raidTouched then
			if (v900 == nil or v900 == v_u_48.difficulty) and ((v901 == nil or v901 == v_u_48.timeOfDay) and (v902 == nil or v902 == v_u_48.mapId)) then
				v_u_48.raidTouched = false
			end
		else
			if v902 then
				local v903 = v_u_154(v902)
				if v903.id == v902 and v903.id ~= v_u_48.mapId then
					v_u_48.mapId = v903.id
					v_u_235 = v903.id
				end
			end
			if v900 and (v900 == "Normal" or (v900 == "Hard" or v900 == "Nightmare")) and v_u_887(v900) then
				v_u_48.difficulty = v900
			end
			if v901 then
				for _, v905 in v_u_7 do
					if v905.id ~= v901 then
						continue
					end
				end
				local v905 = v_u_7[1]
				if v905 then
					for _, v907 in v_u_7 do
						if v907.id ~= v901 then
							continue
						end
					end
					local v907 = v_u_7[1]
					if v907.id == v901 then
						v_u_48.timeOfDay = v901
					end
				end
			end
			if v_u_48.difficulty == "Nightmare" then
				v_u_48.timeOfDay = "Night"
			end
		end
	end
	function v_u_47.wirePaint() -- name: wirePaint
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) v_u_760
		local v909 = p_u_20.myParty()
		local v910 = p_u_20.myParty()
		local v911
		if v910 == nil then
			v911 = false
		else
			local v912 = v910.searching
			v911 = type(v912) == "table"
		end
		if v_u_47.queueApi then
			v_u_47.queueApi.lock(v911)
			local v913 = v_u_47.queueApi.set
			local v914
			if v909 then
				v914 = v909.queue
			else
				v914 = nil
			end
			v913(v914)
		end
		if v_u_47.inputApi then
			v_u_47.inputApi.lock(v911)
			local v915 = v_u_47.inputApi.set
			local v916
			if v909 then
				v916 = v909.input
			else
				v916 = nil
			end
			v915(v916)
		end
		if v_u_47.wipeLine then
			local v917 = v_u_47.wipeLine.refresh
			if type(v917) == "function" then
				v_u_47.wipeLine.refresh()
			end
		end
		local v918 = v_u_47.holdCard()
		if v918 ~= nil and not v911 then
			local v919 = p_u_20.partyDeploying
			if type(v919) ~= "function" or p_u_20.partyDeploying() ~= true then
				local function v920()
					-- upvalues: (ref) p_u_20
					return p_u_20.cctx.lib.MenuPvpHoldCard
				end
				local v921, v922 = pcall(v920)
				if v921 and type(v922) == "table" then
					local v923 = v922.deployText
					if type(v923) == "function" then
						v_u_760.setText(v922.deployText(v918))
						v_u_760.setKind("secondary")
						v_u_760.setEnabled(true)
					end
				end
			end
		end
	end
	function v_u_47.inputTitle(p_u_924, p_u_925) -- name: inputTitle
		-- upvalues: (copy) p_u_20
		local function v926()
			-- upvalues: (ref) p_u_20, (copy) p_u_924, (copy) p_u_925
			return p_u_20.cctx.lib.MenuInputQueueMount.title(p_u_20, p_u_924, p_u_925)
		end
		local v927, v928 = pcall(v926)
		if v927 and type(v928) == "string" then
			return v928
		else
			return p_u_924
		end
	end
	function v_u_47.holdCard() -- name: holdCard
		-- upvalues: (copy) p_u_20
		local v929 = p_u_20.party
		local v930
		if type(v929) == "table" then
			v930 = v929.hold
		else
			v930 = nil
		end
		if type(v930) == "table" then
			return v930
		else
			return nil
		end
	end
	function v_u_47.paint() -- name: paint
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) v_u_48, (ref) v_u_3, (copy) v_u_23, (copy) v_u_24, (copy) v_u_154, (copy) v_u_91, (ref) v_u_235, (ref) v_u_908, (ref) v_u_237, (ref) v_u_4, (copy) v_u_118, (copy) v_u_383, (copy) v_u_510, (copy) v_u_601, (copy) v_u_887, (copy) v_u_25, (copy) v_u_623, (copy) v_u_599, (copy) v_u_620, (copy) v_u_621, (ref) v_u_7, (copy) v_u_622, (copy) v_u_652, (copy) v_u_682, (copy) v_u_679, (copy) v_u_687, (copy) v_u_690, (copy) v_u_689, (copy) v_u_691, (copy) v_u_725, (copy) v_u_134, (ref) v_u_12, (ref) v_u_49, (copy) v_u_809, (copy) v_u_760, (copy) v_u_864, (copy) v_u_726, (ref) v_u_234, (copy) v_u_683
		local v931 = p_u_20.myParty()
		local v932
		if v931 then
			local v933 = v931.settings
			if type(v933) == "table" then
				v932 = v931.settings
			else
				v932 = nil
			end
		else
			v932 = nil
		end
		local v934 = p_u_20.isLeader()
		local v935 = p_u_20.myParty()
		local v936
		if v935 == nil then
			v936 = false
		else
			v936 = #v935.members > 1
		end
		local v937 = false
		if not (v932 and v936) then
			v_u_47.pendingMap = nil
		end
		local v938, v967, v940, v941, v942, v943, v944, v945
		if v932 and v936 then
			v_u_48.difficulty = v932.difficulty or v_u_48.difficulty
			v_u_48.timeOfDay = v932.timeOfDay or "Any"
			v_u_48.freeRaid = v932.freeRaid == true
			v_u_48.privateRaid = v932.privateRaid == true
			v_u_48.privateFriends = v932.privateFriends == true
			local v946 = v932.mapId
			if type(v946) == "string" then
				local v947 = not v934 and "none" or v_u_3.mapSyncStep(v_u_47.pendingMap, v932.mapId, v_u_3.partyNotice(p_u_20.party), os.clock())
				if v947 == "wait" then
					v937 = true
					if not v934 then
						v_u_235 = v_u_48.mapId
					end
					if not (v932 and v936) then
						v_u_908()
					end
					if (v934 or not v936) and v_u_154(v_u_48.mapId).id ~= v_u_48.mapId then
						v_u_48.mapId = v_u_154(v_u_48.mapId).id
					end
					if v_u_47.rotation then
						v_u_47.rotation.sync()
					end
					if not v937 and v_u_235 ~= v_u_48.mapId then
						v938 = v_u_235
						for v966, v967 in v_u_91 do
							if v967.id ~= v938 then
								continue
							end
						end
						v967 = nil
						if v967 then
							if v_u_237 then
								v940 = v_u_237.isOpenFor
								if type(v940) == "function" then
									v941 = v_u_237.isOpenFor
									v942 = v_u_4
									v943, v944 = pcall(v941, v967, v942)
									if v943 then
										if v944 == true then
											v945 = v_u_118(v967) == nil
										else
											v945 = false
										end
										if v945 then
											v_u_235 = v_u_48.mapId
										end
									else
										v945 = v967.enabled == true
										if v945 then
											v_u_235 = v_u_48.mapId
										end
									end
								else
									v945 = v967.enabled == true
									if v945 then
										v_u_235 = v_u_48.mapId
									end
								end
							else
								v945 = v967.enabled == true
								if v945 then
									v_u_235 = v_u_48.mapId
								end
							end
						end
					end
				else
					if v947 == "refused" then
						local v950 = v_u_47.pendingMap
						local v951
						if type(v950) == "table" then
							local v952 = v_u_3.partyNotice
							local v953 = p_u_20.party
							if type(v952(v953)) == "table" and v_u_3.partyNotice(p_u_20.party).code == "map_refused" then
								v951 = v_u_3.partyNotice(p_u_20.party).mapId == v950.id
							else
								v951 = false
							end
						else
							v951 = false
						end
						if not v951 then
							v_u_23.sound(v_u_24.sounds.error)
							v_u_23.toast("Map change refused", "warn", "The squad stays on " .. v_u_47.displayName((v_u_154(v932.mapId))))
						end
					end
					v_u_47.pendingMap = nil
					local v954 = v_u_48
					local v955
					if v934 then
						v955 = v_u_154(v932.mapId).id
						v954.mapId = v955
					else
						local v956 = v932.mapId
						for _, v958 in v_u_91 do
							if v958.id ~= v956 then
								continue
							end
						end
						local v958 = nil
						if v958 then
							v955 = v932.mapId
							v954.mapId = v955
						else
							v955 = v_u_154(v932.mapId).id
							v954.mapId = v955
						end
					end
					if not v934 then
						v_u_235 = v_u_48.mapId
					end
					if not (v932 and v936) then
						v_u_908()
					end
					if (v934 or not v936) and v_u_154(v_u_48.mapId).id ~= v_u_48.mapId then
						v_u_48.mapId = v_u_154(v_u_48.mapId).id
					end
					if v_u_47.rotation then
						v_u_47.rotation.sync()
					end
					if not v937 and v_u_235 ~= v_u_48.mapId then
						v938 = v_u_235
						for v966, v967 in v_u_91 do
							if v967.id ~= v938 then
								continue
							end
						end
						v967 = nil
						if v967 then
							if v_u_237 then
								v940 = v_u_237.isOpenFor
								if type(v940) == "function" then
									v941 = v_u_237.isOpenFor
									v942 = v_u_4
									v943, v944 = pcall(v941, v967, v942)
									if v943 then
										if v944 == true then
											v945 = v_u_118(v967) == nil
										else
											v945 = false
										end
										if v945 then
											v_u_235 = v_u_48.mapId
										end
									else
										v945 = v967.enabled == true
										if v945 then
											v_u_235 = v_u_48.mapId
										end
									end
								else
									v945 = v967.enabled == true
									if v945 then
										v_u_235 = v_u_48.mapId
									end
								end
							else
								v945 = v967.enabled == true
								if v945 then
									v_u_235 = v_u_48.mapId
								end
							end
						end
					end
				end
			else
				if not v934 then
					v_u_235 = v_u_48.mapId
				end
				if not (v932 and v936) then
					v_u_908()
				end
				if (v934 or not v936) and v_u_154(v_u_48.mapId).id ~= v_u_48.mapId then
					v_u_48.mapId = v_u_154(v_u_48.mapId).id
				end
				if v_u_47.rotation then
					v_u_47.rotation.sync()
				end
				if not v937 and v_u_235 ~= v_u_48.mapId then
					v938 = v_u_235
					for v966, v967 in v_u_91 do
						if v967.id ~= v938 then
							continue
						end
					end
					v967 = nil
					if v967 then
						if v_u_237 then
							v940 = v_u_237.isOpenFor
							if type(v940) == "function" then
								v941 = v_u_237.isOpenFor
								v942 = v_u_4
								v943, v944 = pcall(v941, v967, v942)
								if v943 then
									if v944 == true then
										v945 = v_u_118(v967) == nil
									else
										v945 = false
									end
									if v945 then
										v_u_235 = v_u_48.mapId
									end
								else
									v945 = v967.enabled == true
									if v945 then
										v_u_235 = v_u_48.mapId
									end
								end
							else
								v945 = v967.enabled == true
								if v945 then
									v_u_235 = v_u_48.mapId
								end
							end
						else
							v945 = v967.enabled == true
							if v945 then
								v_u_235 = v_u_48.mapId
							end
						end
					end
				end
			end
		else
			if not (v_u_48.privTouched or v_u_47.pvPublic()) then
				local v963 = p_u_20.profile
				local v964
				if type(v963) == "table" then
					local v965 = v963.settings
					if type(v965) == "table" then
						v964 = v963.settings.raidPrivacy or nil
					else
						v964 = nil
					end
				else
					v964 = nil
				end
				if v964 == "public" or (v964 == "private" or v964 == "friends") then
					v_u_48.privateRaid = v964 ~= "public"
					v_u_48.privateFriends = v964 == "friends"
				end
			end
			if not (v932 and v936) then
				v_u_908()
			end
			if (v934 or not v936) and v_u_154(v_u_48.mapId).id ~= v_u_48.mapId then
				v_u_48.mapId = v_u_154(v_u_48.mapId).id
			end
			if v_u_47.rotation then
				v_u_47.rotation.sync()
			end
			if not v937 and v_u_235 ~= v_u_48.mapId then
				v938 = v_u_235
				for v966, v967 in v_u_91 do
					if v967.id ~= v938 then
						continue
					end
				end
				v967 = nil
				if v967 then
					if v_u_237 then
						v940 = v_u_237.isOpenFor
						if type(v940) == "function" then
							v941 = v_u_237.isOpenFor
							v942 = v_u_4
							v943, v944 = pcall(v941, v967, v942)
							if v943 then
								if v944 == true then
									v945 = v_u_118(v967) == nil
								else
									v945 = false
								end
								if v945 then
									v_u_235 = v_u_48.mapId
								end
							else
								v945 = v967.enabled == true
								if v945 then
									v_u_235 = v_u_48.mapId
								end
							end
						else
							v945 = v967.enabled == true
							if v945 then
								v_u_235 = v_u_48.mapId
							end
						end
					else
						v945 = v967.enabled == true
						if v945 then
							v_u_235 = v_u_48.mapId
						end
					end
				end
			end
		end
		v_u_383()
		if v_u_47.ladder then
			local v968 = v_u_47.ladder.paint
			pcall(v968)
		end
		local v969
		if v935 == nil then
			v969 = false
		else
			local v970 = v935.searching
			v969 = type(v970) == "table"
		end
		v_u_510.Visible = v969
		for v971, v972 in v_u_601 do
			local v973, v974 = v_u_887(v971)
			local v_u_975 = "town"
			local function v979()
				-- upvalues: (ref) v_u_91, (ref) v_u_235, (ref) v_u_154, (ref) v_u_48, (ref) v_u_975
				for _, v977 in v_u_91 do
					if v977.id ~= v_u_235 then
						continue
					end
				end
				local v977 = v_u_154(v_u_48.mapId)
				if v977 then
					local v978 = v977.noun
					if type(v978) == "string" then
						v_u_975 = v977.noun
					end
				end
			end
			pcall(v979)
			local v980 = v_u_23.setText
			local v981 = v972.sub
			local v982
			if v971 == "Normal" then
				v982 = ("The %s as it is"):format(v_u_975)
			else
				v982 = v972.line
			end
			v980(v981, v982)
			v972.locked = not v973
			v972.lock.Visible = not v973
			v_u_23.setText(v972.req, v973 and v971 == v_u_48.difficulty and "Selected" or v974)
			local v983 = v971 == v_u_48.difficulty
			if v969 then
				local v984 = v972.stroke
				local v985
				if v983 then
					v985 = v_u_25.accentDim
				else
					v985 = v_u_25.line
				end
				v984.Color = v985
				v972.top.BackgroundTransparency = 1
				v972.btn.BackgroundColor3 = v_u_25.raised
				local v986 = v972.name
				local v987
				if v983 then
					v987 = v_u_25.text
				else
					v987 = v_u_25.muted
				end
				v986.TextColor3 = v987
				local v988 = v972.req
				local v989
				if v983 then
					v989 = v_u_25.text2
				else
					v989 = v_u_25.muted
				end
				v988.TextColor3 = v989
			else
				local v990 = v972.stroke
				local v991
				if v983 then
					v991 = v_u_25.accent
				elseif v972.hover then
					v991 = v_u_25.lineStrong
				else
					v991 = v_u_25.line
				end
				v990.Color = v991
				v972.top.BackgroundTransparency = v983 and 0 or 1
				local v992 = v972.btn
				local v993
				if v983 then
					v993 = v_u_25.accentDeep
				else
					v993 = v_u_25.raised
				end
				v992.BackgroundColor3 = v993
				local v994 = v972.name
				local v995
				if v973 then
					v995 = v_u_25.text
				else
					v995 = v_u_25.muted
				end
				v994.TextColor3 = v995
				local v996 = v972.req
				local v997
				if v983 then
					v997 = v_u_25.accent
				elseif v973 then
					v997 = v_u_25.text2
				else
					v997 = v_u_25.muted
				end
				v996.TextColor3 = v997
			end
		end
		local v998 = p_u_20.myParty()
		local v999
		if v998 == nil or #v998.members <= 1 then
			v999 = false
		else
			v999 = not p_u_20.isLeader()
		end
		local v1002
		if v999 then
			local v1001 = v_u_48.mapId
			for _, v1002 in v_u_91 do
				if v1002.id ~= v1001 then
					continue
				end
			end
			v1002 = nil
			if not v1002 then
				v1002 = v_u_154(v_u_48.mapId)
			end
		else
			v1002 = v_u_154(v_u_48.mapId)
		end
		local v1003
		if type(v1002) == "table" then
			v1003 = v1002.fixedTime or nil
		else
			v1003 = nil
		end
		local v_u_1004
		if type(v1003) == "table" then
			v_u_1004 = v1003[v_u_48.difficulty] or v1003.Normal
		else
			v_u_1004 = nil
		end
		if v_u_47.timeLocked() then
			v_u_1004 = v_u_47.lockedTime(v_u_1004)
		end
		for v1005, v1006 in v_u_623 do
			local v1007
			if v_u_1004 then
				v1007 = v1005 == v_u_1004
			else
				v1007 = v1005 == v_u_48.timeOfDay
			end
			local v1008
			if v_u_48.difficulty == "Nightmare" and v1005 ~= "Night" then
				v1008 = true
			elseif v_u_1004 == nil then
				v1008 = false
			else
				v1008 = v1005 ~= v_u_1004
			end
			if v_u_1004 then
				local v1009 = v1006.stroke
				local v1010
				if v1007 then
					v1010 = v_u_25.accentDim
				else
					v1010 = v_u_25.line
				end
				v1009.Color = v1010
				v1006.btn.BackgroundColor3 = v_u_25.raised
				local v1011 = v1006.l1
				local v1012
				if v1007 then
					v1012 = v_u_25.text
				else
					v1012 = v_u_25.muted
				end
				v1011.TextColor3 = v1012
				v1006.l2.TextColor3 = v_u_25.muted
			elseif v969 then
				local v1013 = v1006.stroke
				local v1014
				if v1007 then
					v1014 = v_u_25.accentDim
				else
					v1014 = v_u_25.line
				end
				v1013.Color = v1014
				v1006.btn.BackgroundColor3 = v_u_25.raised
				local v1015 = v1006.l1
				local v1016
				if v1007 then
					v1016 = v_u_25.text
				else
					v1016 = v_u_25.muted
				end
				v1015.TextColor3 = v1016
				v1006.l2.TextColor3 = v_u_25.muted
			else
				local v1017 = v1006.stroke
				local v1018
				if v1007 then
					v1018 = v_u_25.accent
				else
					v1018 = v_u_25.line
				end
				v1017.Color = v1018
				local v1019 = v1006.btn
				local v1020
				if v1007 then
					v1020 = v_u_25.accentDeep
				else
					v1020 = v_u_25.raised
				end
				v1019.BackgroundColor3 = v1020
				local v1021 = v1006.l1
				local v1022
				if v1008 then
					v1022 = v_u_25.muted
				elseif v1007 then
					v1022 = v_u_25.accent
				else
					v1022 = v_u_25.text
				end
				v1021.TextColor3 = v1022
				local v1023 = v1006.l2
				local v1024
				if v1008 then
					v1024 = v_u_25.muted
				else
					v1024 = v_u_25.text2
				end
				v1023.TextColor3 = v1024
			end
		end
		local v1025 = v_u_47.pvFacts((v_u_599(v_u_48.difficulty)))
		local v1026 = not v1025 and "" or v1025.facts
		v_u_620.Visible = v1026 ~= ""
		if v_u_621.Text ~= v1026 then
			v_u_621.Text = v1026
		end
		local v_u_1027 = ""
		local function v1032()
			-- upvalues: (ref) p_u_20, (copy) v_u_1004, (ref) v_u_48, (ref) v_u_47, (ref) v_u_1027
			local v1028 = p_u_20.cache and p_u_20.cache.tasks
			if v1028 then
				v1028 = p_u_20.cache.tasks.data
			end
			local v1029 = p_u_20.cctx.shared.TaskConds
			if type(v1028) == "table" then
				local v1030
				if v_u_1004 then
					v1030 = v_u_1004
				else
					v1030 = v_u_48.difficulty == "Nightmare" and "Night" or v_u_48.timeOfDay
				end
				local v1031 = v_u_47.why()
				v_u_1027 = v1031.taskNoteText(v1031.taskNotes(p_u_20.cctx.shared.Tasks, v1029, v1028, v_u_48.difficulty, v1030))
			end
		end
		v_u_1027 = not pcall(v1032) and "" or v_u_1027
		v_u_47.taskNoteBox.Visible = v_u_1027 ~= ""
		if v_u_47.taskNote.Text ~= v_u_1027 then
			v_u_47.taskNote.Text = v_u_1027
		end
		local v1033 = v_u_48.difficulty == "Nightmare" and "Night" or v_u_48.timeOfDay
		for _, v1035 in v_u_7 do
			if v1035.id ~= v1033 then
				continue
			end
		end
		local v1035 = v_u_7[1]
		local v1036 = v1035.effect or ""
		local v1037 = tostring(v1036)
		v_u_622.Visible = not v_u_47.timeLocked()
		if v_u_1004 and v_u_47.timeLocked() then
			local v1038 = "Time of day: %s. Every raid on %s runs at this time."
			local v1039 = string.upper(v_u_1004)
			local v1040 = v_u_47.displayName
			local v1041 = p_u_20.myParty()
			local v1042
			if v1041 == nil or #v1041.members <= 1 then
				v1042 = false
			else
				v1042 = not p_u_20.isLeader()
			end
			local v1045
			if v1042 then
				local v1044 = v_u_48.mapId
				for _, v1045 in v_u_91 do
					if v1045.id ~= v1044 then
						continue
					end
				end
				v1045 = nil
				if not v1045 then
					v1045 = v_u_154(v_u_48.mapId)
				end
			else
				v1045 = v_u_154(v_u_48.mapId)
			end
			v1037 = v1038:format(v1039, v1040(v1045))
		elseif v_u_1004 then
			local v1046 = "Underground: %s on the surface, dark below. %s sets its own time (Normal and Hard at dusk, Nightmare at night). Bring a light."
			local v1047 = string.lower(v_u_1004)
			local v1048 = v_u_47.displayName
			local v1049 = p_u_20.myParty()
			local v1050
			if v1049 == nil or #v1049.members <= 1 then
				v1050 = false
			else
				v1050 = not p_u_20.isLeader()
			end
			local v1053
			if v1050 then
				local v1052 = v_u_48.mapId
				for _, v1053 in v_u_91 do
					if v1053.id ~= v1052 then
						continue
					end
				end
				v1053 = nil
				if not v1053 then
					v1053 = v_u_154(v_u_48.mapId)
				end
			else
				v1053 = v_u_154(v_u_48.mapId)
			end
			v1037 = v1046:format(v1047, v1048(v1053))
		elseif v_u_48.difficulty == "Nightmare" then
			v1037 = "Nightmare is always at night. " .. v1037
		end
		if v_u_652.Text ~= v1037 then
			v_u_652.Text = v1037
		end
		v_u_682.set(v_u_48.freeRaid)
		v_u_679.Visible = v_u_48.freeRaid
		v_u_687.set(v_u_48.privateRaid)
		v_u_690.set(v_u_48.privateFriends)
		v_u_689.Visible = v_u_48.privateRaid
		local v1054 = v_u_48.privateRaid and (v_u_48.privateFriends and "No matchmaking. Only squads with a friend of your squad may join." or "No matchmaking. Your squad stays alone in its raid.") or "Off: other squads may share your raid."
		if v936 and not v934 then
			v1054 = v1054 .. " The squad leader decides."
		end
		if v_u_47.pvPublic() then
			v1054 = v_u_47.why().publicOnlyTip()
		end
		v_u_23.setText(v_u_691, v1054)
		v_u_4:SetAttribute("MenuPlayPrivate", (v_u_48.privateRaid and "on" or "off") .. " " .. (v_u_48.privateFriends and "friends" or "nofriends"))
		local v1055 = string.upper(v_u_48.difficulty)
		local v1056
		if v_u_1004 then
			v1056 = string.upper(v_u_1004)
		else
			v1056 = v_u_48.difficulty == "Nightmare" and "NIGHT" or (v_u_48.timeOfDay == "Any" and "ANY TIME" or string.upper(v_u_48.timeOfDay))
		end
		local v1057 = v_u_23.setText
		local v1058 = v_u_725
		local v1059 = "%s \194\183 %s \194\183 %s%s%s"
		for _, v1061 in v_u_91 do
			if v1061.id ~= v_u_235 then
				continue
			end
		end
		local v1061 = v_u_154(v_u_48.mapId)
		local v1062
		if v_u_237 then
			local v1063 = v_u_237.isOpenFor
			if type(v1063) == "function" then
				local v1064 = v_u_237.isOpenFor
				local v1065 = v_u_4
				local v1066, v1067 = pcall(v1064, v1061, v1065)
				if v1066 then
					if v1067 == true then
						v1062 = v_u_118(v1061) == nil
					else
						v1062 = false
					end
				else
					v1062 = v1061.enabled == true
				end
			else
				v1062 = v1061.enabled == true
			end
		else
			v1062 = v1061.enabled == true
		end
		local v1068
		if v1062 or not v934 and v936 then
			local v1069 = v_u_134
			local v1070 = p_u_20.myParty()
			local v1071
			if v1070 == nil or #v1070.members <= 1 then
				v1071 = false
			else
				v1071 = not p_u_20.isLeader()
			end
			local v1074
			if v1071 then
				local v1073 = v_u_48.mapId
				for _, v1074 in v_u_91 do
					if v1074.id ~= v1073 then
						continue
					end
				end
				v1074 = nil
				if not v1074 then
					v1074 = v_u_154(v_u_48.mapId)
				end
			else
				v1074 = v_u_154(v_u_48.mapId)
			end
			if v1069(v1074) == "test" then
				local v1075 = v_u_47.displayName
				local v1076 = p_u_20.myParty()
				local v1077
				if v1076 == nil or #v1076.members <= 1 then
					v1077 = false
				else
					v1077 = not p_u_20.isLeader()
				end
				local v1080
				if v1077 then
					local v1079 = v_u_48.mapId
					for _, v1080 in v_u_91 do
						if v1080.id ~= v1079 then
							continue
						end
					end
					v1080 = nil
					if not v1080 then
						v1080 = v_u_154(v_u_48.mapId)
					end
				else
					v1080 = v_u_154(v_u_48.mapId)
				end
				v1068 = v1075(v1080) .. " \194\183 TEST"
			else
				local v1081 = v_u_47.displayName
				local v1082 = p_u_20.myParty()
				local v1083
				if v1082 == nil or #v1082.members <= 1 then
					v1083 = false
				else
					v1083 = not p_u_20.isLeader()
				end
				local v1086
				if v1083 then
					local v1085 = v_u_48.mapId
					for _, v1086 in v_u_91 do
						if v1086.id ~= v1085 then
							continue
						end
					end
					v1086 = nil
					if not v1086 then
						v1086 = v_u_154(v_u_48.mapId)
					end
				else
					v1086 = v_u_154(v_u_48.mapId)
				end
				v1068 = v1081(v1086)
			end
		else
			local v1087 = v_u_47.displayName
			for _, v1089 in v_u_91 do
				if v1089.id ~= v_u_235 then
					continue
				end
			end
			local v1089 = v_u_154(v_u_48.mapId)
			local v1090 = v1087(v1089)
			local v1091 = v_u_47.why().gateWords
			local v1092 = v_u_134
			local v1093 = " \194\183 "
			for _, v1095 in v_u_91 do
				if v1095.id ~= v_u_235 then
					continue
				end
			end
			local v1095 = v_u_154(v_u_48.mapId)
			v1068 = v1090 .. v1093 .. v1091((v1092(v1095))).summary
		end
		v1057(v1058, v1059:format(v1068, v1055, v1056, v_u_48.privateRaid and " \194\183 PRIVATE" or "", v_u_48.freeRaid and " \194\183 FREE RAID" or ""))
		v_u_725.TextColor3 = v_u_25.text
		local v1096
		if v935 then
			v1096 = v935.block or nil
		else
			v1096 = nil
		end
		local v1097 = v935 and #v935.members or 1
		local v1098 = nil
		if v935 then
			for _, v1099 in v935.members do
				if v1099.userId ~= v_u_4.UserId then
					continue
				end
				v1098 = v1099
			end
		end
		local v1100 = p_u_20.derived().freeRaidIn
		local v1101 = tonumber(v1100) or 0
		local v1102
		if v935 then
			local v1103 = v935.deploying
			if type(v1103) == "table" then
				v1102 = v935.deploying
			else
				v1102 = nil
			end
		else
			v1102 = nil
		end
		local v1104
		if v1102 == nil or v1102.tutorial == true then
			local v1105 = p_u_20.partyDeploying
			if type(v1105) == "function" then
				v1104 = p_u_20.partyDeploying() == true
			else
				v1104 = false
			end
		else
			v1104 = true
		end
		local v1106
		if v935 then
			local v1107 = v935.searching
			if type(v1107) == "table" then
				v1106 = v935.searching
			else
				v1106 = nil
			end
		else
			v1106 = nil
		end
		local v1108
		if v_u_12 and v935 then
			v1108 = v_u_12.state(v935)
		else
			v1108 = nil
		end
		local v1109 = v1108 and (v1108.phase == "found" or v1108.phase == "deploying") and true or v1104
		local v1110
		if v1106 == nil then
			v1110 = false
		else
			v1110 = not v1109
		end
		if os.clock() >= v_u_49 and not v1109 or v1110 then
			v_u_47.depSince = nil
		end
		v_u_809(v1110)
		local v1111
		if v1106 and not v1109 then
			v_u_49 = 0
			v_u_760.setText("Stop search")
			v_u_760.setKind("secondary")
			v_u_760.setEnabled(true)
			v_u_864(v1108, v1106)
			if v1101 > 0 then
				v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
				v_u_683.TextColor3 = v_u_25.text2
			else
				v_u_23.setText(v_u_683, "Available now")
				v_u_683.TextColor3 = v_u_25.success
			end
			if v_u_47.wirePaint then
				v1111 = v_u_47.wirePaint
				pcall(v1111)
			end
			return
		end
		if os.clock() < v_u_49 or v1109 then
			v_u_760.setText("Deploying")
			v_u_760.setKind("primary")
			v_u_760.setEnabled(false)
			local v1112
			if v935 then
				local v1113 = v935.deploying
				if type(v1113) == "table" then
					v1112 = v935.deploying.match
				else
					v1112 = nil
				end
			else
				v1112 = nil
			end
			local v1114
			if v_u_12 and v1112 then
				v1114 = v_u_12.matchLine(v1112)
			else
				v1114 = nil
			end
			v_u_47.depSince = v_u_47.depSince or os.clock()
			local v1115 = v_u_47.why().waitLine(os.clock() - v_u_47.depSince)
			v_u_23.setText(v_u_726, v1114 or (v1115 or (v936 and not v934 and "Your squad leader deployed. Moving out..." or "Requesting insertion...")))
			local v1116 = v_u_726
			local v1117
			if v1114 then
				v1117 = v_u_25.success
			else
				v1117 = v_u_25.text2
			end
			v1116.TextColor3 = v1117
			if v1101 > 0 then
				v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
				v_u_683.TextColor3 = v_u_25.text2
			else
				v_u_23.setText(v_u_683, "Available now")
				v_u_683.TextColor3 = v_u_25.success
			end
			if v_u_47.wirePaint then
				v1111 = v_u_47.wirePaint
				pcall(v1111)
			end
			return
		end
		if not v936 or v934 then
			v_u_760.setKind("primary")
			local v1118 = not v_u_887(v_u_48.difficulty)
			local v1119 = v_u_48.freeRaid
			if v1119 then
				v1119 = v1101 > 0
			end
			local v1120
			if v_u_234 == nil then
				v1120 = false
			else
				v1120 = v_u_234:GetAttribute("DeployClosed") == true
			end
			if v1120 then
				v_u_760.setKind("secondary")
				v_u_760.setText("Closed")
				v_u_760.setEnabled(false)
				local v1121 = v_u_23.setText
				local v1122 = v_u_726
				local v1123 = v_u_234
				if v1123 then
					v1123 = v_u_234:GetAttribute("DeployMsg")
				end
				v1121(v1122, (type(v1123) ~= "string" or v1123 == "") and "Deployments are closed right now. Raids in progress can still finish." or v1123)
				v_u_726.TextColor3 = v_u_25.danger
				if v1101 > 0 then
					v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
					v_u_683.TextColor3 = v_u_25.text2
				else
					v_u_23.setText(v_u_683, "Available now")
					v_u_683.TextColor3 = v_u_25.success
				end
				if v_u_47.wirePaint then
					v1111 = v_u_47.wirePaint
					pcall(v1111)
				end
			else
				for _, v1125 in v_u_91 do
					if v1125.id ~= v_u_235 then
						continue
					end
				end
				local v1125 = v_u_154(v_u_48.mapId)
				local v1126, v1127, v1128, v1129, v1174, v1131, v1132, v1133, v1134, v1176, v1136, v1178, v1138, v1180, v1140, v1141, v1142, v1143
				if v_u_237 then
					local v1144 = v_u_237.isOpenFor
					if type(v1144) == "function" then
						local v1145 = v_u_237.isOpenFor
						local v1146 = v_u_4
						local v1147, v1148 = pcall(v1145, v1125, v1146)
						if v1147 then
							if v1148 == true then
								v1126 = v_u_118(v1125) == nil
							else
								v1126 = false
							end
							if v1126 then
								if v1118 then
									v_u_760.setText("Locked")
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, v_u_47.dl(v_u_48.difficulty).status)
									v_u_726.TextColor3 = v_u_25.danger
								elseif v1119 then
									v_u_760.setText("Free raid in " .. v_u_23.clock(v1101))
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, v_u_47.why().FREE_BLOCKED)
									v_u_726.TextColor3 = v_u_25.text2
								elseif v1096 and v936 then
									v_u_760.setText("Deploy")
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, (tostring(v1096)))
									v_u_726.TextColor3 = v_u_25.accent
								else
									v_u_760.setText(v1097 <= 1 and "Deploy" or ("Deploy squad (%d)"):format(v1097))
									v_u_760.setEnabled(true)
									v_u_23.setText(v_u_726, v1097 > 1 and "Everyone is ready." or "Solo. Invite survivors with the squad bar above.")
									v_u_726.TextColor3 = v_u_25.text2
									if v_u_134((v_u_154(v_u_48.mapId))) == "test" then
										v_u_23.setText(v_u_726, ("Test access: %s is still locked for other players."):format(v_u_47.displayName((v_u_154(v_u_48.mapId)))))
										v_u_726.TextColor3 = v_u_25.info
									end
								end
							else
								v_u_760.setKind("secondary")
								v1127 = v_u_760.setText
								v1128 = v_u_47.why().gateWords
								v1129 = v_u_134
								for v1173, v1174 in v_u_91 do
									if v1174.id ~= v_u_235 then
										continue
									end
								end
								v1174 = v_u_154(v_u_48.mapId)
								v1127(v1128((v1129(v1174))).btn)
								v_u_760.setEnabled(false)
								v1131 = v_u_23.setText
								v1132 = v_u_726
								v1133 = v_u_47.displayName
								v1134 = "%s is not open yet. Pick %s to deploy."
								for v1175, v1176 in v_u_91 do
									if v1176.id ~= v_u_235 then
										continue
									end
								end
								v1176 = v_u_154(v_u_48.mapId)
								v1131(v1132, v1134:format(v1133(v1176), v_u_47.displayName((v_u_154(v_u_48.mapId)))))
								v_u_726.TextColor3 = v_u_25.accent
								v1136 = v_u_134
								for v1177, v1178 in v_u_91 do
									if v1178.id ~= v_u_235 then
										continue
									end
								end
								v1178 = v_u_154(v_u_48.mapId)
								if v1136(v1178) == "raids" then
									v1138 = v_u_118
									for v1179, v1180 in v_u_91 do
										if v1180.id ~= v_u_235 then
											continue
										end
									end
									v1180 = v_u_154(v_u_48.mapId)
									v1140 = v1138(v1180)
								else
									v1140 = nil
								end
								if v1140 then
									v1141 = v_u_23.setText
									v1142 = v_u_726
									if v1140.kind == "quest" then
										v1143 = v1140.progressText .. "."
									else
										v1143 = ("%s. Pick %s to deploy."):format(v1140.line, v_u_47.displayName((v_u_154(v_u_48.mapId))))
									end
									v1141(v1142, v1143)
								end
							end
						else
							v1126 = v1125.enabled == true
							if v1126 then
								if v1118 then
									v_u_760.setText("Locked")
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, v_u_47.dl(v_u_48.difficulty).status)
									v_u_726.TextColor3 = v_u_25.danger
								elseif v1119 then
									v_u_760.setText("Free raid in " .. v_u_23.clock(v1101))
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, v_u_47.why().FREE_BLOCKED)
									v_u_726.TextColor3 = v_u_25.text2
								elseif v1096 and v936 then
									v_u_760.setText("Deploy")
									v_u_760.setEnabled(false)
									v_u_23.setText(v_u_726, (tostring(v1096)))
									v_u_726.TextColor3 = v_u_25.accent
								else
									v_u_760.setText(v1097 <= 1 and "Deploy" or ("Deploy squad (%d)"):format(v1097))
									v_u_760.setEnabled(true)
									v_u_23.setText(v_u_726, v1097 > 1 and "Everyone is ready." or "Solo. Invite survivors with the squad bar above.")
									v_u_726.TextColor3 = v_u_25.text2
									if v_u_134((v_u_154(v_u_48.mapId))) == "test" then
										v_u_23.setText(v_u_726, ("Test access: %s is still locked for other players."):format(v_u_47.displayName((v_u_154(v_u_48.mapId)))))
										v_u_726.TextColor3 = v_u_25.info
									end
								end
							else
								v_u_760.setKind("secondary")
								v1127 = v_u_760.setText
								v1128 = v_u_47.why().gateWords
								v1129 = v_u_134
								for v1173, v1174 in v_u_91 do
									if v1174.id ~= v_u_235 then
										continue
									end
								end
								v1174 = v_u_154(v_u_48.mapId)
								v1127(v1128((v1129(v1174))).btn)
								v_u_760.setEnabled(false)
								v1131 = v_u_23.setText
								v1132 = v_u_726
								v1133 = v_u_47.displayName
								v1134 = "%s is not open yet. Pick %s to deploy."
								for v1175, v1176 in v_u_91 do
									if v1176.id ~= v_u_235 then
										continue
									end
								end
								v1176 = v_u_154(v_u_48.mapId)
								v1131(v1132, v1134:format(v1133(v1176), v_u_47.displayName((v_u_154(v_u_48.mapId)))))
								v_u_726.TextColor3 = v_u_25.accent
								v1136 = v_u_134
								for v1177, v1178 in v_u_91 do
									if v1178.id ~= v_u_235 then
										continue
									end
								end
								v1178 = v_u_154(v_u_48.mapId)
								if v1136(v1178) == "raids" then
									v1138 = v_u_118
									for v1179, v1180 in v_u_91 do
										if v1180.id ~= v_u_235 then
											continue
										end
									end
									v1180 = v_u_154(v_u_48.mapId)
									v1140 = v1138(v1180)
								else
									v1140 = nil
								end
								if v1140 then
									v1141 = v_u_23.setText
									v1142 = v_u_726
									if v1140.kind == "quest" then
										v1143 = v1140.progressText .. "."
									else
										v1143 = ("%s. Pick %s to deploy."):format(v1140.line, v_u_47.displayName((v_u_154(v_u_48.mapId))))
									end
									v1141(v1142, v1143)
								end
							end
						end
					else
						v1126 = v1125.enabled == true
						if v1126 then
							if v1118 then
								v_u_760.setText("Locked")
								v_u_760.setEnabled(false)
								v_u_23.setText(v_u_726, v_u_47.dl(v_u_48.difficulty).status)
								v_u_726.TextColor3 = v_u_25.danger
							elseif v1119 then
								v_u_760.setText("Free raid in " .. v_u_23.clock(v1101))
								v_u_760.setEnabled(false)
								v_u_23.setText(v_u_726, v_u_47.why().FREE_BLOCKED)
								v_u_726.TextColor3 = v_u_25.text2
							elseif v1096 and v936 then
								v_u_760.setText("Deploy")
								v_u_760.setEnabled(false)
								v_u_23.setText(v_u_726, (tostring(v1096)))
								v_u_726.TextColor3 = v_u_25.accent
							else
								v_u_760.setText(v1097 <= 1 and "Deploy" or ("Deploy squad (%d)"):format(v1097))
								v_u_760.setEnabled(true)
								v_u_23.setText(v_u_726, v1097 > 1 and "Everyone is ready." or "Solo. Invite survivors with the squad bar above.")
								v_u_726.TextColor3 = v_u_25.text2
								if v_u_134((v_u_154(v_u_48.mapId))) == "test" then
									v_u_23.setText(v_u_726, ("Test access: %s is still locked for other players."):format(v_u_47.displayName((v_u_154(v_u_48.mapId)))))
									v_u_726.TextColor3 = v_u_25.info
								end
							end
						else
							v_u_760.setKind("secondary")
							v1127 = v_u_760.setText
							v1128 = v_u_47.why().gateWords
							v1129 = v_u_134
							for v1173, v1174 in v_u_91 do
								if v1174.id ~= v_u_235 then
									continue
								end
							end
							v1174 = v_u_154(v_u_48.mapId)
							v1127(v1128((v1129(v1174))).btn)
							v_u_760.setEnabled(false)
							v1131 = v_u_23.setText
							v1132 = v_u_726
							v1133 = v_u_47.displayName
							v1134 = "%s is not open yet. Pick %s to deploy."
							for v1175, v1176 in v_u_91 do
								if v1176.id ~= v_u_235 then
									continue
								end
							end
							v1176 = v_u_154(v_u_48.mapId)
							v1131(v1132, v1134:format(v1133(v1176), v_u_47.displayName((v_u_154(v_u_48.mapId)))))
							v_u_726.TextColor3 = v_u_25.accent
							v1136 = v_u_134
							for v1177, v1178 in v_u_91 do
								if v1178.id ~= v_u_235 then
									continue
								end
							end
							v1178 = v_u_154(v_u_48.mapId)
							if v1136(v1178) == "raids" then
								v1138 = v_u_118
								for v1179, v1180 in v_u_91 do
									if v1180.id ~= v_u_235 then
										continue
									end
								end
								v1180 = v_u_154(v_u_48.mapId)
								v1140 = v1138(v1180)
							else
								v1140 = nil
							end
							if v1140 then
								v1141 = v_u_23.setText
								v1142 = v_u_726
								if v1140.kind == "quest" then
									v1143 = v1140.progressText .. "."
								else
									v1143 = ("%s. Pick %s to deploy."):format(v1140.line, v_u_47.displayName((v_u_154(v_u_48.mapId))))
								end
								v1141(v1142, v1143)
							end
						end
					end
				else
					v1126 = v1125.enabled == true
					if v1126 then
						if v1118 then
							v_u_760.setText("Locked")
							v_u_760.setEnabled(false)
							v_u_23.setText(v_u_726, v_u_47.dl(v_u_48.difficulty).status)
							v_u_726.TextColor3 = v_u_25.danger
						elseif v1119 then
							v_u_760.setText("Free raid in " .. v_u_23.clock(v1101))
							v_u_760.setEnabled(false)
							v_u_23.setText(v_u_726, v_u_47.why().FREE_BLOCKED)
							v_u_726.TextColor3 = v_u_25.text2
						elseif v1096 and v936 then
							v_u_760.setText("Deploy")
							v_u_760.setEnabled(false)
							v_u_23.setText(v_u_726, (tostring(v1096)))
							v_u_726.TextColor3 = v_u_25.accent
						else
							v_u_760.setText(v1097 <= 1 and "Deploy" or ("Deploy squad (%d)"):format(v1097))
							v_u_760.setEnabled(true)
							v_u_23.setText(v_u_726, v1097 > 1 and "Everyone is ready." or "Solo. Invite survivors with the squad bar above.")
							v_u_726.TextColor3 = v_u_25.text2
							if v_u_134((v_u_154(v_u_48.mapId))) == "test" then
								v_u_23.setText(v_u_726, ("Test access: %s is still locked for other players."):format(v_u_47.displayName((v_u_154(v_u_48.mapId)))))
								v_u_726.TextColor3 = v_u_25.info
							end
						end
					else
						v_u_760.setKind("secondary")
						v1127 = v_u_760.setText
						v1128 = v_u_47.why().gateWords
						v1129 = v_u_134
						for v1173, v1174 in v_u_91 do
							if v1174.id ~= v_u_235 then
								continue
							end
						end
						v1174 = v_u_154(v_u_48.mapId)
						v1127(v1128((v1129(v1174))).btn)
						v_u_760.setEnabled(false)
						v1131 = v_u_23.setText
						v1132 = v_u_726
						v1133 = v_u_47.displayName
						v1134 = "%s is not open yet. Pick %s to deploy."
						for v1175, v1176 in v_u_91 do
							if v1176.id ~= v_u_235 then
								continue
							end
						end
						v1176 = v_u_154(v_u_48.mapId)
						v1131(v1132, v1134:format(v1133(v1176), v_u_47.displayName((v_u_154(v_u_48.mapId)))))
						v_u_726.TextColor3 = v_u_25.accent
						v1136 = v_u_134
						for v1177, v1178 in v_u_91 do
							if v1178.id ~= v_u_235 then
								continue
							end
						end
						v1178 = v_u_154(v_u_48.mapId)
						if v1136(v1178) == "raids" then
							v1138 = v_u_118
							for v1179, v1180 in v_u_91 do
								if v1180.id ~= v_u_235 then
									continue
								end
							end
							v1180 = v_u_154(v_u_48.mapId)
							v1140 = v1138(v1180)
						else
							v1140 = nil
						end
						if v1140 then
							v1141 = v_u_23.setText
							v1142 = v_u_726
							if v1140.kind == "quest" then
								v1143 = v1140.progressText .. "."
							else
								v1143 = ("%s. Pick %s to deploy."):format(v1140.line, v_u_47.displayName((v_u_154(v_u_48.mapId))))
							end
							v1141(v1142, v1143)
						end
					end
				end
				if v1101 > 0 then
					v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
					v_u_683.TextColor3 = v_u_25.text2
				else
					v_u_23.setText(v_u_683, "Available now")
					v_u_683.TextColor3 = v_u_25.success
				end
				if v_u_47.wirePaint then
					v1111 = v_u_47.wirePaint
					pcall(v1111)
				end
			end
		end
		if v1098 then
			v1098 = v1098.ready
		end
		v_u_760.setText(v1098 and "Ready, waiting for leader" or "Ready up")
		v_u_760.setKind(v1098 and "secondary" or "primary")
		v_u_760.setEnabled(true)
		v_u_23.setText(v_u_726, "Your squad leader picks the conditions and deploys.")
		v_u_726.TextColor3 = v_u_25.text2
		local v1181 = p_u_20.myParty()
		local v1182
		if v1181 == nil or #v1181.members <= 1 then
			v1182 = false
		else
			v1182 = not p_u_20.isLeader()
		end
		local v1185
		if v1182 then
			local v1184 = v_u_48.mapId
			for _, v1185 in v_u_91 do
				if v1185.id ~= v1184 then
					continue
				end
			end
			v1185 = nil
			if not v1185 then
				v1185 = v_u_154(v_u_48.mapId)
			end
		else
			v1185 = v_u_154(v_u_48.mapId)
		end
		local v1186
		if v_u_237 then
			local v1187 = v_u_237.isOpenFor
			if type(v1187) == "function" then
				local v1188 = v_u_237.isOpenFor
				local v1189 = v_u_4
				local v1190, v1191 = pcall(v1188, v1185, v1189)
				if v1190 then
					if v1191 == true then
						v1186 = v_u_118(v1185) == nil
					else
						v1186 = false
					end
				else
					v1186 = v1185.enabled == true
				end
			else
				v1186 = v1185.enabled == true
			end
		else
			v1186 = v1185.enabled == true
		end
		if not v1186 then
			local v1192 = v_u_23.setText
			local v1193 = v_u_726
			local v1194 = v_u_47.displayName
			v1192(v1193, ("Your squad leader picked %s. It is still locked for you."):format((tostring(v1194(v1185)))))
			v_u_726.TextColor3 = v_u_25.danger
			local v1195
			if v_u_134(v1185) == "raids" then
				v1195 = v_u_118(v1185)
			else
				v1195 = nil
			end
			if v1195 then
				local v1196 = v_u_23.setText
				local v1197 = v_u_726
				local v1198 = v_u_47.displayName
				v1196(v1197, ("Your squad leader picked %s. %s (%s)."):format(tostring(v1198(v1185)), v1195.lockText, v1195.progressText))
			end
		end
		local v1199 = v_u_887(v_u_48.difficulty)
		local v1200 = v_u_47.why().memberStatus
		local v1201 = {}
		local v1202
		if v_u_234 == nil then
			v1202 = false
		else
			v1202 = v_u_234:GetAttribute("DeployClosed") == true
		end
		v1201.closed = v1202
		local v1203 = v_u_234
		if v1203 then
			v1203 = v_u_234:GetAttribute("DeployMsg")
		end
		v1201.closedText = (type(v1203) ~= "string" or v1203 == "") and "Deployments are closed right now. Raids in progress can still finish." or v1203
		v1201.diff = v_u_48.difficulty
		v1201.diffOk = v1199
		v1201.lock = v_u_47.dl(v_u_48.difficulty)
		v1201.freeRaid = v_u_48.freeRaid
		v1201.freeIn = v1101
		local v1204 = v1200(v1201)
		if v1204 == nil then
			if v1101 > 0 then
				v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
				v_u_683.TextColor3 = v_u_25.text2
			else
				v_u_23.setText(v_u_683, "Available now")
				v_u_683.TextColor3 = v_u_25.success
			end
			if v_u_47.wirePaint then
				v1111 = v_u_47.wirePaint
				pcall(v1111)
			end
			return
		end
		local v1205
		if v_u_234 == nil then
			v1205 = false
		else
			v1205 = v_u_234:GetAttribute("DeployClosed") == true
		end
		local v1206, v1207
		if v1205 then
			v_u_23.setText(v_u_726, v1204.text)
			v1206 = v_u_726
			if v1204.tone == "danger" then
				v1207 = v_u_25.danger
			else
				v1207 = v_u_25.accent
			end
			v1206.TextColor3 = v1207
			if v1204.btn then
				v_u_760.setText(v1204.btn)
				v_u_760.setEnabled(false)
			end
			if v1101 > 0 then
				v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
				v_u_683.TextColor3 = v_u_25.text2
			else
				v_u_23.setText(v_u_683, "Available now")
				v_u_683.TextColor3 = v_u_25.success
			end
			if v_u_47.wirePaint then
				v1111 = v_u_47.wirePaint
				pcall(v1111)
			end
			return
		else
			local v1208
			if v_u_237 then
				local v1209 = v_u_237.isOpenFor
				if type(v1209) == "function" then
					local v1210 = v_u_237.isOpenFor
					local v1211 = v_u_4
					local v1212, v1213 = pcall(v1210, v1185, v1211)
					if v1212 then
						if v1213 == true then
							v1208 = v_u_118(v1185) == nil
						else
							v1208 = false
						end
						if v1208 then
							v_u_23.setText(v_u_726, v1204.text)
							v1206 = v_u_726
							if v1204.tone == "danger" then
								v1207 = v_u_25.danger
							else
								v1207 = v_u_25.accent
							end
							v1206.TextColor3 = v1207
							if v1204.btn then
								v_u_760.setText(v1204.btn)
								v_u_760.setEnabled(false)
							end
							if v1101 > 0 then
								v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
								v_u_683.TextColor3 = v_u_25.text2
							else
								v_u_23.setText(v_u_683, "Available now")
								v_u_683.TextColor3 = v_u_25.success
							end
							if v_u_47.wirePaint then
								v1111 = v_u_47.wirePaint
								pcall(v1111)
							end
						else
							if v1101 > 0 then
								v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
								v_u_683.TextColor3 = v_u_25.text2
							else
								v_u_23.setText(v_u_683, "Available now")
								v_u_683.TextColor3 = v_u_25.success
							end
							if v_u_47.wirePaint then
								v1111 = v_u_47.wirePaint
								pcall(v1111)
							end
						end
					else
						v1208 = v1185.enabled == true
						if v1208 then
							v_u_23.setText(v_u_726, v1204.text)
							v1206 = v_u_726
							if v1204.tone == "danger" then
								v1207 = v_u_25.danger
							else
								v1207 = v_u_25.accent
							end
							v1206.TextColor3 = v1207
							if v1204.btn then
								v_u_760.setText(v1204.btn)
								v_u_760.setEnabled(false)
							end
							if v1101 > 0 then
								v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
								v_u_683.TextColor3 = v_u_25.text2
							else
								v_u_23.setText(v_u_683, "Available now")
								v_u_683.TextColor3 = v_u_25.success
							end
							if v_u_47.wirePaint then
								v1111 = v_u_47.wirePaint
								pcall(v1111)
							end
						else
							if v1101 > 0 then
								v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
								v_u_683.TextColor3 = v_u_25.text2
							else
								v_u_23.setText(v_u_683, "Available now")
								v_u_683.TextColor3 = v_u_25.success
							end
							if v_u_47.wirePaint then
								v1111 = v_u_47.wirePaint
								pcall(v1111)
							end
						end
					end
				else
					v1208 = v1185.enabled == true
					if v1208 then
						v_u_23.setText(v_u_726, v1204.text)
						v1206 = v_u_726
						if v1204.tone == "danger" then
							v1207 = v_u_25.danger
						else
							v1207 = v_u_25.accent
						end
						v1206.TextColor3 = v1207
						if v1204.btn then
							v_u_760.setText(v1204.btn)
							v_u_760.setEnabled(false)
						end
						if v1101 > 0 then
							v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
							v_u_683.TextColor3 = v_u_25.text2
						else
							v_u_23.setText(v_u_683, "Available now")
							v_u_683.TextColor3 = v_u_25.success
						end
						if v_u_47.wirePaint then
							v1111 = v_u_47.wirePaint
							pcall(v1111)
						end
					else
						if v1101 > 0 then
							v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
							v_u_683.TextColor3 = v_u_25.text2
						else
							v_u_23.setText(v_u_683, "Available now")
							v_u_683.TextColor3 = v_u_25.success
						end
						if v_u_47.wirePaint then
							v1111 = v_u_47.wirePaint
							pcall(v1111)
						end
					end
				end
			else
				v1208 = v1185.enabled == true
				if v1208 then
					v_u_23.setText(v_u_726, v1204.text)
					v1206 = v_u_726
					if v1204.tone == "danger" then
						v1207 = v_u_25.danger
					else
						v1207 = v_u_25.accent
					end
					v1206.TextColor3 = v1207
					if v1204.btn then
						v_u_760.setText(v1204.btn)
						v_u_760.setEnabled(false)
					end
					if v1101 > 0 then
						v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
						v_u_683.TextColor3 = v_u_25.text2
					else
						v_u_23.setText(v_u_683, "Available now")
						v_u_683.TextColor3 = v_u_25.success
					end
					if v_u_47.wirePaint then
						v1111 = v_u_47.wirePaint
						pcall(v1111)
					end
				else
					if v1101 > 0 then
						v_u_23.setText(v_u_683, "Next free raid in " .. v_u_23.clock(v1101))
						v_u_683.TextColor3 = v_u_25.text2
					else
						v_u_23.setText(v_u_683, "Available now")
						v_u_683.TextColor3 = v_u_25.success
					end
					if v_u_47.wirePaint then
						v1111 = v_u_47.wirePaint
						pcall(v1111)
					end
				end
			end
		end
	end
	local function v_u_1225() -- name: paintLoadout
		-- upvalues: (copy) p_u_20, (copy) v_u_673, (copy) v_u_26, (copy) v_u_25, (copy) v_u_677, (copy) v_u_678
		local v1214 = p_u_20.slots()
		for v1215, v1216 in v_u_673 do
			local v1217 = v1214[v1215]
			if type(v1217) == "table" and v1217.id then
				v1216.Text = v_u_26.itemName(v1217.id)
				v1216.TextColor3 = v_u_25.text
			else
				v1216.Text = "Empty"
				v1216.TextColor3 = v_u_25.muted
			end
		end
		local v1218 = p_u_20.profile
		if v1218 then
			v1218 = p_u_20.profile.inv
		end
		local v1219 = p_u_20.cctx.lib.InvUITile.sellKit
		local v1220, v1221 = pcall(v1219, v1218)
		v_u_677.Text = v_u_26.money((not v1220 or type(v1221) ~= "number") and (type(v1218) == "table" and (v1218.value or 0) or 0) or v1221)
		local v1222 = v_u_678
		local v1223 = "%.1f kg"
		local v1224
		if type(v1218) == "table" then
			v1224 = v1218.weight
		else
			v1224 = false
		end
		v1222.Text = v1223:format(tonumber(v1224) or 0)
	end
	function v_u_47.briefState() -- name: briefState
		-- upvalues: (copy) v_u_91, (ref) v_u_235, (copy) v_u_154, (copy) v_u_48, (copy) p_u_20, (copy) v_u_47, (copy) v_u_134, (copy) v_u_118, (ref) v_u_237, (copy) v_u_887, (ref) v_u_234, (copy) v_u_677, (copy) v_u_173, (ref) v_u_5, (ref) v_u_7
		for _, v_u_1227 in v_u_91 do
			if v_u_1227.id ~= v_u_235 then
				continue
			end
		end
		local v_u_1227 = v_u_154(v_u_48.mapId)
		local v1228 = p_u_20.myParty()
		local v_u_1229 = v1228 and #v1228.members or 1
		local function v1236()
			-- upvalues: (ref) p_u_20, (ref) v_u_48, (copy) v_u_1229, (ref) v_u_47
			local v1230 = p_u_20.cctx.lib.PlayModeSel.sync
			local v1231 = p_u_20
			local v1232 = v_u_48
			local v1233 = p_u_20.myParty()
			local v1234
			if v1233 then
				local v1235 = v1233.settings
				if type(v1235) == "table" then
					v1234 = v1233.settings
				else
					v1234 = nil
				end
			else
				v1234 = nil
			end
			v1230(v1231, v1232, v1234, v_u_1229 > 1, v_u_47.pvHard())
		end
		pcall(v1236)
		local v1237 = {}
		local v1238 = nil
		for _, v1239 in not v1228 and {} or v1228.members do
			local v1240 = v1239.userId
			table.insert(v1237, v1240)
			if v1239.isLeader ~= true and (not v1228 or v1228.leader ~= v1239.userId) then
				continue
			end
			local v1241 = v1239.displayName or v1239.name or ""
			v1238 = tostring(v1241)
		end
		v_u_47.why()
		local v1242 = v_u_134(v_u_1227)
		local v1243
		if v1242 == "raids" then
			v1243 = v_u_118(v_u_1227)
		else
			v1243 = nil
		end
		local v_u_1244 = nil
		local function v1245()
			-- upvalues: (ref) v_u_1244, (ref) v_u_237, (copy) v_u_1227
			v_u_1244 = v_u_237.actOf(v_u_1227)
		end
		pcall(v1245)
		local v1246 = nil
		local v1247
		if v_u_47.pvHard() then
			v1247 = v_u_1244
		else
			v1247 = v_u_1244
			for _, v1248 in { "Hard", "Nightmare" } do
				local v1249, _ = v_u_887(v1248)
				if v1249 or v1246 ~= nil then
					continue
				end
				v1246 = {
					["name"] = v1248,
					["short"] = v_u_47.dl(v1248).short
				}
			end
		end
		local v1250 = v_u_1227.noun or "town"
		local v1251 = tostring(v1250)
		local v_u_1252 = 0
		local v_u_1253 = 4
		local function v1257()
			-- upvalues: (ref) v_u_1252, (ref) p_u_20, (ref) v_u_48, (ref) v_u_1253
			local v1254 = p_u_20.cctx.shared.Difficulty.extraMinutes
			local v1255 = v_u_48.difficulty
			v_u_1252 = tonumber(v1254(v1255)) or 0
			local v1256 = p_u_20.cctx.shared.Config.SQUAD_MAX
			v_u_1253 = tonumber(v1256) or 4
		end
		pcall(v1257)
		local v1258 = {
			["pvpve"] = v_u_47.pvHard(),
			["difficulty"] = v_u_48.difficulty,
			["timeOfDay"] = v_u_48.timeOfDay,
			["freeRaid"] = v_u_48.freeRaid,
			["privateRaid"] = v_u_48.privateRaid,
			["privateFriends"] = v_u_48.privateFriends,
			["viewMode"] = v_u_48.viewMode,
			["showMode"] = v_u_48.viewMode ~= nil
		}
		local v1259 = p_u_20.myParty()
		local v1260
		if v1259 == nil then
			v1260 = false
		else
			local v1261 = v1259.searching
			v1260 = type(v1261) == "table"
		end
		v1258.searching = v1260
		local v1262
		if v_u_234 == nil then
			v1262 = false
		else
			v1262 = v_u_234:GetAttribute("DeployClosed") == true
		end
		v1258.closed = v1262
		local v1263 = v_u_234
		if v1263 then
			v1263 = v_u_234:GetAttribute("DeployMsg")
		end
		v1258.closedText = (type(v1263) ~= "string" or v1263 == "") and "Deployments are closed right now. Raids in progress can still finish." or v1263
		local v1264 = p_u_20.myParty()
		local v1265
		if v1264 == nil or #v1264.members <= 1 then
			v1265 = false
		else
			v1265 = not p_u_20.isLeader()
		end
		v1258.member = v1265
		v1258.memberName = v1238
		v1258.partySize = v_u_1229
		v1258.partyMax = v_u_1253
		v1258.memberIds = v1237
		v1258.kitValue = v_u_677.Text
		local v1266 = p_u_20.myParty()
		local v1267
		if v1266 == nil or #v1266.members <= 1 then
			v1267 = false
		else
			v1267 = not p_u_20.isLeader()
		end
		local v1268, v1271
		if v1267 then
			local v1270 = v_u_48.mapId
			v1268 = v_u_1252
			for _, v1271 in v_u_91 do
				if v1271.id ~= v1270 then
					continue
				end
			end
			v1271 = nil
			if not v1271 then
				v1271 = v_u_154(v_u_48.mapId)
			end
		else
			v1271 = v_u_154(v_u_48.mapId)
			v1268 = v_u_1252
		end
		local v1272
		if type(v1271) == "table" then
			v1272 = v1271.fixedTime or nil
		else
			v1272 = nil
		end
		local v1273
		if type(v1272) == "table" then
			v1273 = v1272[v_u_48.difficulty] or v1272.Normal
		else
			v1273 = nil
		end
		if v_u_47.timeLocked() then
			v1273 = v_u_47.lockedTime(v1273)
		end
		v1258.fixedTime = v1273
		v1258.nextLock = v1246
		v1258.mapDef = v_u_1227
		local v1274 = {
			["name"] = v_u_47.displayName(v_u_1227)
		}
		local v1275
		if v1247 == nil then
			v1275 = nil
		else
			v1275 = ("Act %d"):format(v1247)
		end
		v1274.act = v1275
		local v1276
		if v1242 == "open" then
			v1276 = nil
		else
			v1276 = select(3, v_u_47.stateWords(v1242, true, v1243))
		end
		v1274.tag = v1276
		local v1277
		if v1243 then
			v1277 = v1243.line
		else
			local v1278 = v_u_1227.tagline or ""
			v1277 = tostring(v1278)
		end
		v1274.tagline = v1277
		local v1279
		if v1243 then
			v1279 = v1243.progressText
		else
			v1279 = v_u_173(v_u_1227)
		end
		v1274.stats = v1279
		local v1280 = v_u_1227.raidMinutes
		v1274.minutes = (tonumber(v1280) or 20) + v1268
		v1258.map = v1274
		v1258.words = {
			["diffLine"] = {
				["Normal"] = ("The %s as it is"):format(v1251),
				["Hard"] = v_u_5[2].line,
				["Nightmare"] = v_u_5[3].line
			},
			["timeOdds"] = {
				["Any"] = v_u_7[1].odds,
				["Day"] = v_u_7[2].odds,
				["Dusk"] = v_u_7[3].odds,
				["Night"] = v_u_7[4].odds
			}
		}
		return v1258
	end
	local function v_u_1319() -- name: paintIntel
		-- upvalues: (copy) v_u_26, (copy) v_u_654, (copy) p_u_20, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (ref) v_u_51, (ref) v_u_50, (copy) v_u_653, (copy) v_u_23, (copy) v_u_25, (copy) v_u_65, (copy) v_u_47
		v_u_26.clear(v_u_654)
		local v_u_1281 = nil
		local function v1282()
			-- upvalues: (ref) v_u_1281, (ref) p_u_20
			v_u_1281 = p_u_20.cctx.shared.Extracts
		end
		pcall(v1282)
		local v1283
		if v_u_1281 then
			local v1284 = v_u_1281.DEFS
			v1283 = type(v1284) ~= "table" and {} or v_u_1281.DEFS
		else
			v1283 = {}
		end
		local v1285 = p_u_20.myParty()
		local v1286
		if v1285 == nil or #v1285.members <= 1 then
			v1286 = false
		else
			v1286 = not p_u_20.isLeader()
		end
		local v1289
		if v1286 then
			local v1288 = v_u_48.mapId
			for _, v1289 in v_u_91 do
				if v1289.id ~= v1288 then
					continue
				end
			end
			v1289 = nil
			if not v1289 then
				v1289 = v_u_154(v_u_48.mapId)
			end
		else
			v1289 = v_u_154(v_u_48.mapId)
		end
		local v1290 = v1289.id
		v_u_51 = v1290
		local v1291
		if v_u_1281 then
			local v1292 = v_u_1281.defsFor
			if type(v1292) == "function" then
				local v1293 = v_u_1281.defsFor
				local v1294
				v1294, v1291 = pcall(v1293, v1290)
				if v1294 then
					if type(v1291) ~= "table" then
						v1291 = v1283
					end
				else
					v1291 = v1283
				end
			else
				v1291 = v1283
			end
		else
			v1291 = v1283
		end
		local v1295 = #v1291 > 0
		for _, v1296 in v1291 do
			if v1296.always == true then
				continue
			end
			v1295 = false
		end
		local v1297 = v_u_50 or 0
		local v1298 = v_u_653:FindFirstChild("Right")
		if v1298 then
			v1298.Text = ("RADIO L%d"):format(v1297)
		end
		for v1299, v1300 in v1291 do
			local v1301 = v1300.always == true and true or v1297 >= 1
			local v1302 = v_u_23.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = v1300.id,
				["BackgroundColor3"] = v_u_25.raised,
				["Size"] = UDim2.new(1, 0, 0, 34),
				["LayoutOrder"] = v1299
			}, v_u_654)
			v_u_23.stroke(v1302, v_u_25.line)
			local v1303 = v_u_23.new
			local v1304 = "Frame"
			local v1305 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = 45
			}
			local v1306
			if v1300.always then
				v1306 = v_u_25.success
			elseif v1301 then
				v1306 = v_u_25.accent
			else
				v1306 = v_u_25.muted
			end
			v1305.BackgroundColor3 = v1306
			v1305.AnchorPoint = Vector2.new(0, 0.5)
			v1305.Position = UDim2.new(0, v_u_65, 0.5, 0)
			v1305.Size = UDim2.fromOffset(6, 6)
			v1303(v1304, v1305, v1302).Name = "Dot"
			local v1307 = v_u_23.label
			local v1308 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 14,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1302,
				["text"] = not v1301 and "Unknown exit" or v1300.name
			}
			local v1309
			if v1301 then
				v1309 = v_u_25.text
			else
				v1309 = v_u_25.muted
			end
			v1308.color = v1309
			v1308.position = UDim2.fromOffset(v_u_65 + 16, 0)
			v1308.size = UDim2.new(0.5, -v_u_65 - 16, 1, 0)
			v1307(v1308)
			v_u_23.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1302,
				["text"] = v_u_47.why().radioRow(v1301, v1300.always == true, v1300.condition),
				["position"] = UDim2.fromScale(0.5, 0),
				["size"] = UDim2.new(0.5, -v_u_65, 1, 0)
			})
			if v1300.always or (v1297 >= 1 or v1299 <= 2) then
				continue
			end
			v1302:Destroy()
		end
		local v1310 = v_u_26.empty(v_u_654, v_u_47.why().radioNote(v1295, #v1291, v1297), 99)
		local v1311 = {
			v_u_65,
			v_u_65,
			0,
			0
		}
		v_u_23.pad(v1310, v1311)
		local function v1318()
			-- upvalues: (ref) p_u_20, (ref) v_u_654, (ref) v_u_48, (ref) v_u_91, (ref) v_u_154, (ref) v_u_653
			p_u_20.cctx.lib.HideoutIntel.attach(v_u_654, p_u_20, function()
				-- upvalues: (ref) v_u_48
				return v_u_48.difficulty
			end, function()
				-- upvalues: (ref) p_u_20, (ref) v_u_48, (ref) v_u_91, (ref) v_u_154
				local v1312 = p_u_20.myParty()
				local v1313
				if v1312 == nil or #v1312.members <= 1 then
					v1313 = false
				else
					v1313 = not p_u_20.isLeader()
				end
				local v1314
				if v1313 then
					local v1315 = v_u_48.mapId
					for _, v1317 in v_u_91 do
						if v1317.id ~= v1315 then
							continue
						end
					end
					local v1317 = nil
					v1314 = v1317 or v_u_154(v_u_48.mapId)
				else
					v1314 = v_u_154(v_u_48.mapId)
				end
				return v1314.id
			end, v_u_653)
		end
		pcall(v1318)
	end
	local function v_u_1326() -- name: syncIntel
		-- upvalues: (ref) v_u_51, (copy) p_u_20, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (copy) v_u_1319
		local v1320 = v_u_51
		local v1321 = p_u_20.myParty()
		local v1322
		if v1321 == nil or #v1321.members <= 1 then
			v1322 = false
		else
			v1322 = not p_u_20.isLeader()
		end
		local v1325
		if v1322 then
			local v1324 = v_u_48.mapId
			for _, v1325 in v_u_91 do
				if v1325.id ~= v1324 then
					continue
				end
			end
			v1325 = nil
			if not v1325 then
				v1325 = v_u_154(v_u_48.mapId)
			end
		else
			v1325 = v_u_154(v_u_48.mapId)
		end
		if v1320 ~= v1325.id then
			v_u_1319()
		end
	end
	function v_u_47.viewMap(p1327) -- name: viewMap
		-- upvalues: (copy) v_u_91, (copy) p_u_20, (copy) v_u_23, (copy) v_u_24, (ref) v_u_235, (ref) v_u_237, (ref) v_u_4, (copy) v_u_118, (copy) v_u_48, (copy) v_u_47, (copy) v_u_134
		local v1328 = nil
		for _, v1329 in v_u_91 do
			if v1329.id ~= p1327 then
				continue
			end
			v1328 = v1329
		end
		if not v1328 then
			return false
		end
		local v1330 = p_u_20.myParty()
		local v1331
		if v1330 == nil then
			v1331 = false
		else
			local v1332 = v1330.searching
			v1331 = type(v1332) == "table"
		end
		if v1331 then
			v_u_23.sound(v_u_24.sounds.error)
			v_u_23.toast("Locked while searching", "warn", "Stop the search to change the conditions.")
			return false
		end
		local v1333 = p_u_20.myParty()
		if v1333 ~= nil and (#v1333.members > 1 and not p_u_20.isLeader()) then
			v_u_23.sound(v_u_24.sounds.error)
			v_u_23.toast("Only the squad leader can change this", "warn")
			return false
		end
		v_u_235 = v1328.id
		local v1334, v1335, v1336, v1337, v1338, v1339
		if v_u_237 then
			local v1340 = v_u_237.isOpenFor
			if type(v1340) == "function" then
				local v1341 = v_u_237.isOpenFor
				local v1342 = v_u_4
				local v1343, v1344 = pcall(v1341, v1328, v1342)
				if v1343 then
					if v1344 == true then
						v1334 = v_u_118(v1328) == nil
					else
						v1334 = false
					end
					if v1334 and v1328.id ~= v_u_48.mapId then
						v_u_47.choose("mapId", v1328.id)
					else
						v_u_23.sound(v_u_24.sounds.select or v_u_24.sounds.click)
						v_u_47.paint()
						if v_u_134(v1328) == "raids" then
							v1335 = v_u_118(v1328)
						else
							v1335 = nil
						end
						if v1335 then
							v_u_23.sound(v_u_24.sounds.error)
							v1336 = v_u_23.toast
							v1337 = v1335.line
							v1338 = v1335.progressText
							v1339 = v_u_47.displayName
							v1336(v1337, "warn", v1338 .. "  \194\183  " .. tostring(v1339(v1328)))
						end
					end
					return true
				else
					v1334 = v1328.enabled == true
					if v1334 and v1328.id ~= v_u_48.mapId then
						v_u_47.choose("mapId", v1328.id)
					else
						v_u_23.sound(v_u_24.sounds.select or v_u_24.sounds.click)
						v_u_47.paint()
						if v_u_134(v1328) == "raids" then
							v1335 = v_u_118(v1328)
						else
							v1335 = nil
						end
						if v1335 then
							v_u_23.sound(v_u_24.sounds.error)
							v1336 = v_u_23.toast
							v1337 = v1335.line
							v1338 = v1335.progressText
							v1339 = v_u_47.displayName
							v1336(v1337, "warn", v1338 .. "  \194\183  " .. tostring(v1339(v1328)))
						end
					end
					return true
				end
			else
				v1334 = v1328.enabled == true
				if v1334 and v1328.id ~= v_u_48.mapId then
					v_u_47.choose("mapId", v1328.id)
				else
					v_u_23.sound(v_u_24.sounds.select or v_u_24.sounds.click)
					v_u_47.paint()
					if v_u_134(v1328) == "raids" then
						v1335 = v_u_118(v1328)
					else
						v1335 = nil
					end
					if v1335 then
						v_u_23.sound(v_u_24.sounds.error)
						v1336 = v_u_23.toast
						v1337 = v1335.line
						v1338 = v1335.progressText
						v1339 = v_u_47.displayName
						v1336(v1337, "warn", v1338 .. "  \194\183  " .. tostring(v1339(v1328)))
					end
				end
				return true
			end
		else
			v1334 = v1328.enabled == true
			if v1334 and v1328.id ~= v_u_48.mapId then
				v_u_47.choose("mapId", v1328.id)
			else
				v_u_23.sound(v_u_24.sounds.select or v_u_24.sounds.click)
				v_u_47.paint()
				if v_u_134(v1328) == "raids" then
					v1335 = v_u_118(v1328)
				else
					v1335 = nil
				end
				if v1335 then
					v_u_23.sound(v_u_24.sounds.error)
					v1336 = v_u_23.toast
					v1337 = v1335.line
					v1338 = v1335.progressText
					v1339 = v_u_47.displayName
					v1336(v1337, "warn", v1338 .. "  \194\183  " .. tostring(v1339(v1328)))
				end
			end
			return true
		end
	end
	function v_u_47.openList(p1345) -- name: openList
		-- upvalues: (copy) v_u_47, (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250, (copy) v_u_245, (copy) v_u_60
		if v_u_47.sheet then
			v_u_47.sheet.open("map")
		end
		local v1346 = p1345 == true
		v_u_279 = true
		v_u_270.Visible = true
		v_u_260(true)
		v_u_251.Color = v_u_25.accent
		if v1346 then
			local v1347 = game:GetService("GuiService")
			local v1348 = v_u_271[v_u_235]
			local v1349
			if v1348 then
				v1349 = v1348.btn
			else
				v1349 = v_u_250
			end
			v1347.SelectedObject = v1349
		end
		local v1350 = v_u_245.AbsolutePosition.Y - v_u_60.AbsolutePosition.Y + v_u_60.CanvasPosition.Y
		local v1351 = v_u_60
		local v1352 = Vector2.new
		local v1353 = v1350 - 8
		v1351.CanvasPosition = v1352(0, (math.max(0, v1353)))
	end
	function v_u_47.closeList(p1354) -- name: closeList
		-- upvalues: (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250
		local v1355 = p1354 == true
		v_u_279 = false
		v_u_270.Visible = false
		v_u_260(false)
		v_u_251.Color = v_u_25.line
		if v1355 then
			local v1356 = game:GetService("GuiService")
			local _ = v_u_271[v_u_235]
			v1356.SelectedObject = v_u_250
		end
	end
	function v_u_47.choose(p1357, p_u_1358) -- name: choose
		-- upvalues: (copy) p_u_20, (copy) v_u_23, (copy) v_u_24, (copy) v_u_47, (copy) v_u_48, (ref) v_u_3, (copy) p_u_21, (ref) v_u_51, (copy) v_u_91, (copy) v_u_154, (copy) v_u_1319
		local v1359 = p_u_20.myParty()
		local v1360
		if v1359 == nil then
			v1360 = false
		else
			local v1361 = v1359.searching
			v1360 = type(v1361) == "table"
		end
		if v1360 then
			v_u_23.sound(v_u_24.sounds.error)
			v_u_23.toast("Locked while searching", "warn", "Stop the search to change the conditions.")
			v_u_47.paint()
			return
		else
			local v1362 = p_u_20.myParty()
			local v1363
			if v1362 == nil then
				v1363 = false
			else
				v1363 = #v1362.members > 1
			end
			if v1363 and not p_u_20.isLeader() then
				v_u_23.toast("Only the squad leader can change this", "warn")
				v_u_47.paint()
			else
				v_u_48[p1357] = p_u_1358
				if p1357 == "mapId" and (v_u_47.ladder and v_u_47.ladder.on()) then
					v_u_47.ladder.fit()
				end
				if p1357 == "mapId" and (v1362 and #v1362.members > 1) then
					v_u_47.pendingMap = {
						["id"] = p_u_1358,
						["at"] = os.clock(),
						["notice"] = v_u_3.partyNotice(p_u_20.party)
					}
					task.delay(v_u_3.MAP_ANSWER_WAIT + 0.2, function()
						-- upvalues: (ref) v_u_47, (copy) p_u_1358, (ref) p_u_21
						if v_u_47.pendingMap and (v_u_47.pendingMap.id == p_u_1358 and p_u_21.Parent) then
							local v1364 = v_u_47.paint
							pcall(v1364)
						end
					end)
				end
				if p1357 == "difficulty" and p_u_1358 == "Nightmare" then
					v_u_48.timeOfDay = "Night"
				end
				if v1362 then
					p_u_20.partyOp({
						["op"] = "settings",
						["difficulty"] = nil,
						["timeOfDay"] = nil,
						["freeRaid"] = nil,
						["mapId"] = nil,
						["privateRaid"] = nil,
						["privateFriends"] = nil,
						["viewMode"] = nil,
						["difficulty"] = v_u_48.difficulty,
						["timeOfDay"] = v_u_48.timeOfDay == "Any" and "" or v_u_48.timeOfDay,
						["freeRaid"] = v_u_48.freeRaid,
						["mapId"] = v_u_48.mapId,
						["privateRaid"] = v_u_48.privateRaid,
						["privateFriends"] = v_u_48.privateFriends,
						["viewMode"] = v_u_48.viewMode
					})
				end
				if p1357 == "difficulty" or (p1357 == "timeOfDay" or p1357 == "mapId") then
					v_u_48.raidTouched = true
					if not v1362 then
						local v1365 = p_u_20.op
						local v1366 = {
							["op"] = "setting",
							["settings"] = nil,
							["settings"] = {
								["raidDifficulty"] = v_u_48.difficulty,
								["raidTime"] = v_u_48.timeOfDay,
								["raidMap"] = v_u_48.mapId
							}
						}
						pcall(v1365, v1366)
					end
				end
				if p1357 == "privateRaid" or p1357 == "privateFriends" then
					v_u_48.privTouched = true
					if not v1362 then
						local v1367 = p_u_20.op
						local v1368 = {
							["op"] = "setting",
							["key"] = "raidPrivacy",
							["value"] = nil,
							["value"] = v_u_48.privateRaid and (v_u_48.privateFriends and "friends" or "private") or "public"
						}
						pcall(v1367, v1368)
					end
				end
				v_u_23.sound(v_u_24.sounds.select or v_u_24.sounds.click)
				v_u_47.paint()
				local v1369 = v_u_51
				local v1370 = p_u_20.myParty()
				local v1371
				if v1370 == nil or #v1370.members <= 1 then
					v1371 = false
				else
					v1371 = not p_u_20.isLeader()
				end
				local v1374
				if v1371 then
					local v1373 = v_u_48.mapId
					for _, v1374 in v_u_91 do
						if v1374.id ~= v1373 then
							continue
						end
					end
					v1374 = nil
					if not v1374 then
						v1374 = v_u_154(v_u_48.mapId)
					end
				else
					v1374 = v_u_154(v_u_48.mapId)
				end
				if v1369 ~= v1374.id then
					v_u_1319()
				end
			end
		end
	end
	function v_u_47.deploy() -- name: deploy
		-- upvalues: (ref) v_u_4, (copy) p_u_20, (copy) v_u_23, (copy) v_u_24, (ref) v_u_234, (copy) v_u_47, (copy) v_u_91, (ref) v_u_235, (copy) v_u_154, (copy) v_u_48, (ref) v_u_237, (copy) v_u_118, (copy) v_u_134, (ref) v_u_49
		if v_u_4:GetAttribute("LoadingVisible") == true then
			return
		end
		local v1375 = p_u_20.myParty()
		if v1375 then
			local v1376 = v1375.searching
			if type(v1376) == "table" then
				p_u_20.partyOp({
					["op"] = "cancelSearch"
				})
				v_u_23.sound(v_u_24.sounds.click or v_u_24.sounds.select)
				return
			end
		end
		local v1377
		if v_u_234 == nil then
			v1377 = false
		else
			v1377 = v_u_234:GetAttribute("DeployClosed") == true
		end
		if v1377 then
			v_u_23.sound(v_u_24.sounds.error)
			local v1378 = v_u_23.toast
			local v1379 = "Deployments closed"
			local v1380 = "warn"
			local v1381 = v_u_234
			if v1381 then
				v1381 = v_u_234:GetAttribute("DeployMsg")
			end
			v1378(v1379, v1380, (type(v1381) ~= "string" or v1381 == "") and "Deployments are closed right now. Raids in progress can still finish." or v1381)
			return
		end
		local v1382 = v_u_47.holdCard
		if v1382 then
			v1382 = v_u_47.holdCard()
		end
		if v1382 ~= nil then
			local function v1383()
				-- upvalues: (ref) p_u_20
				return p_u_20.cctx.lib.MenuPvpHoldCard
			end
			local v1384, v1385 = pcall(v1383)
			if v1384 and type(v1385) == "table" then
				local v1386 = v1385.open
				if type(v1386) == "function" then
					v_u_23.sound(v_u_24.sounds.error)
					local v1387 = v1385.open
					local v1388 = p_u_20
					pcall(v1387, v1388, v1382)
					return
				end
			end
		end
		local function v1389()
			-- upvalues: (ref) p_u_20
			return p_u_20.cctx.lib.MenuPaidQueue
		end
		local v1390, v1391 = pcall(v1389)
		if v1390 and type(v1391) == "table" then
			local v1392 = v1391.deployGate
			if type(v1392) == "function" then
				local v1393 = v1391.deployGate
				local v1394 = p_u_20
				local v1395, v1396, v1397 = pcall(v1393, v1394)
				if v1395 and v1396 == false then
					v_u_23.sound(v_u_24.sounds.error)
					v_u_23.toast(type(v1397) ~= "string" and "Accept the first visit card before you deploy." or v1397, "warn")
					local function v1398()
						-- upvalues: (ref) p_u_20
						p_u_20.cctx.lib.MenuPvpveIntro.showCard(p_u_20)
					end
					pcall(v1398)
					return
				end
			end
		end
		local v1399 = p_u_20.myParty()
		for _, v1401 in v_u_91 do
			if v1401.id ~= v_u_235 then
				continue
			end
		end
		local v1401 = v_u_154(v_u_48.mapId)
		local v1402, v1403, v1455, v1405, v1457, v1407, v1408, v1409, v1459, v1411, v1412, v1413, v1414, v1415, v1416, v1417, v1418, v1419, v1420, v1421, v1422, v1423, v1471
		if v_u_237 then
			local v1425 = v_u_237.isOpenFor
			if type(v1425) == "function" then
				local v1426 = v_u_237.isOpenFor
				local v1427 = v_u_4
				local v1428, v1429 = pcall(v1426, v1401, v1427)
				if v1428 then
					if v1429 == true then
						v1402 = v_u_118(v1401) == nil
					else
						v1402 = false
					end
					if not v1402 and (v1399 == nil or (#v1399.members <= 1 or p_u_20.isLeader())) then
						v_u_23.sound(v_u_24.sounds.error)
						v1403 = v_u_134
						for v1454, v1455 in v_u_91 do
							if v1455.id ~= v_u_235 then
								continue
							end
						end
						v1455 = v_u_154(v_u_48.mapId)
						if v1403(v1455) == "raids" then
							v1405 = v_u_118
							for v1456, v1457 in v_u_91 do
								if v1457.id ~= v_u_235 then
									continue
								end
							end
							v1457 = v_u_154(v_u_48.mapId)
							v1407 = v1405(v1457)
						else
							v1407 = nil
						end
						if v1407 then
							v_u_23.toast(v1407.line, "warn", v1407.progressText .. "  \194\183  Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
						else
							v1408 = v_u_23.toast
							v1409 = v_u_47.displayName
							for v1458, v1459 in v_u_91 do
								if v1459.id ~= v_u_235 then
									continue
								end
							end
							v1459 = v_u_154(v_u_48.mapId)
							v1408(v1409(v1459) .. " is not open yet", "warn", "Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
						end
					end
					if v1399 ~= nil and (#v1399.members > 1 and not p_u_20.isLeader()) or v_u_235 == v_u_48.mapId then
						if v_u_47.firstRaidGate and v_u_47.firstRaidGate() then
							return
						else
							if v_u_47.sheet then
								v_u_47.sheet.close("deploy")
							end
							v1411 = p_u_20.myParty()
							if v1411 == nil then
								v1412 = false
							else
								v1412 = #v1411.members > 1
							end
							if v1412 and not p_u_20.isLeader() then
								p_u_20.partyOp({
									["op"] = "ready"
								})
							else
								v_u_49 = os.clock() + 6
								v1413 = p_u_20.cctx.emit
								v1414 = "transit.info"
								v1415 = {
									["kind"] = "deploy",
									["map"] = nil,
									["mapId"] = nil,
									["difficulty"] = nil,
									["timeOfDay"] = nil,
									["map"] = v_u_47.displayName((v_u_154(v_u_48.mapId))),
									["mapId"] = v_u_48.mapId,
									["difficulty"] = v_u_48.difficulty
								}
								v1416 = v_u_154(v_u_48.mapId)
								if type(v1416) == "table" then
									v1417 = v1416.fixedTime or nil
								else
									v1417 = nil
								end
								if type(v1417) == "table" then
									v1418 = v1417[v_u_48.difficulty] or v1417.Normal
								else
									v1418 = nil
								end
								if v_u_47.timeLocked() then
									v1418 = v_u_47.lockedTime(v1418)
								end
								if v1418 then
									v1419 = v_u_154(v_u_48.mapId)
									v1420 = type(v1419) == "table" and v1419.fixedTime or nil
									if type(v1420) == "table" then
										v1421 = v1420[v_u_48.difficulty] or v1420.Normal
									else
										v1421 = nil
									end
									if v_u_47.timeLocked() then
										v1421 = v_u_47.lockedTime(v1421)
									end
								elseif v_u_48.difficulty == "Nightmare" then
									v1421 = "Night"
								elseif v_u_48.timeOfDay == "Any" then
									v1421 = nil
								else
									v1421 = v_u_48.timeOfDay
								end
								v1415.timeOfDay = v1421
								v1413(v1414, v1415)
								v_u_23.sound("deploy")
								v1422 = p_u_20.partyOp
								v1423 = {
									["op"] = "deploy",
									["difficulty"] = nil,
									["timeOfDay"] = nil,
									["freeRaid"] = nil,
									["mapId"] = nil,
									["privateRaid"] = nil,
									["privateFriends"] = nil,
									["viewMode"] = nil,
									["difficulty"] = v_u_48.difficulty,
									["timeOfDay"] = v_u_48.timeOfDay,
									["freeRaid"] = v_u_48.freeRaid
								}
								for v1470, v1471 in v_u_91 do
									if v1471.id ~= v_u_235 then
										continue
									end
								end
								v1471 = v_u_154(v_u_48.mapId)
								v1423.mapId = v1471.id
								v1423.privateRaid = v_u_48.privateRaid
								v1423.privateFriends = v_u_48.privateFriends
								v1423.viewMode = v_u_48.viewMode
								v1422(v1423)
								v_u_47.paint()
							end
						end
					end
				else
					v1402 = v1401.enabled == true
					if not v1402 and (v1399 == nil or (#v1399.members <= 1 or p_u_20.isLeader())) then
						v_u_23.sound(v_u_24.sounds.error)
						v1403 = v_u_134
						for v1454, v1455 in v_u_91 do
							if v1455.id ~= v_u_235 then
								continue
							end
						end
						v1455 = v_u_154(v_u_48.mapId)
						if v1403(v1455) == "raids" then
							v1405 = v_u_118
							for v1456, v1457 in v_u_91 do
								if v1457.id ~= v_u_235 then
									continue
								end
							end
							v1457 = v_u_154(v_u_48.mapId)
							v1407 = v1405(v1457)
						else
							v1407 = nil
						end
						if v1407 then
							v_u_23.toast(v1407.line, "warn", v1407.progressText .. "  \194\183  Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
						else
							v1408 = v_u_23.toast
							v1409 = v_u_47.displayName
							for v1458, v1459 in v_u_91 do
								if v1459.id ~= v_u_235 then
									continue
								end
							end
							v1459 = v_u_154(v_u_48.mapId)
							v1408(v1409(v1459) .. " is not open yet", "warn", "Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
						end
					end
					if v1399 ~= nil and (#v1399.members > 1 and not p_u_20.isLeader()) or v_u_235 == v_u_48.mapId then
						if v_u_47.firstRaidGate and v_u_47.firstRaidGate() then
							return
						else
							if v_u_47.sheet then
								v_u_47.sheet.close("deploy")
							end
							v1411 = p_u_20.myParty()
							if v1411 == nil then
								v1412 = false
							else
								v1412 = #v1411.members > 1
							end
							if v1412 and not p_u_20.isLeader() then
								p_u_20.partyOp({
									["op"] = "ready"
								})
							else
								v_u_49 = os.clock() + 6
								v1413 = p_u_20.cctx.emit
								v1414 = "transit.info"
								v1415 = {
									["kind"] = "deploy",
									["map"] = nil,
									["mapId"] = nil,
									["difficulty"] = nil,
									["timeOfDay"] = nil,
									["map"] = v_u_47.displayName((v_u_154(v_u_48.mapId))),
									["mapId"] = v_u_48.mapId,
									["difficulty"] = v_u_48.difficulty
								}
								v1416 = v_u_154(v_u_48.mapId)
								if type(v1416) == "table" then
									v1417 = v1416.fixedTime or nil
								else
									v1417 = nil
								end
								if type(v1417) == "table" then
									v1418 = v1417[v_u_48.difficulty] or v1417.Normal
								else
									v1418 = nil
								end
								if v_u_47.timeLocked() then
									v1418 = v_u_47.lockedTime(v1418)
								end
								if v1418 then
									v1419 = v_u_154(v_u_48.mapId)
									v1420 = type(v1419) == "table" and v1419.fixedTime or nil
									if type(v1420) == "table" then
										v1421 = v1420[v_u_48.difficulty] or v1420.Normal
									else
										v1421 = nil
									end
									if v_u_47.timeLocked() then
										v1421 = v_u_47.lockedTime(v1421)
									end
								elseif v_u_48.difficulty == "Nightmare" then
									v1421 = "Night"
								elseif v_u_48.timeOfDay == "Any" then
									v1421 = nil
								else
									v1421 = v_u_48.timeOfDay
								end
								v1415.timeOfDay = v1421
								v1413(v1414, v1415)
								v_u_23.sound("deploy")
								v1422 = p_u_20.partyOp
								v1423 = {
									["op"] = "deploy",
									["difficulty"] = nil,
									["timeOfDay"] = nil,
									["freeRaid"] = nil,
									["mapId"] = nil,
									["privateRaid"] = nil,
									["privateFriends"] = nil,
									["viewMode"] = nil,
									["difficulty"] = v_u_48.difficulty,
									["timeOfDay"] = v_u_48.timeOfDay,
									["freeRaid"] = v_u_48.freeRaid
								}
								for v1470, v1471 in v_u_91 do
									if v1471.id ~= v_u_235 then
										continue
									end
								end
								v1471 = v_u_154(v_u_48.mapId)
								v1423.mapId = v1471.id
								v1423.privateRaid = v_u_48.privateRaid
								v1423.privateFriends = v_u_48.privateFriends
								v1423.viewMode = v_u_48.viewMode
								v1422(v1423)
								v_u_47.paint()
							end
						end
					end
				end
			else
				v1402 = v1401.enabled == true
				if not v1402 and (v1399 == nil or (#v1399.members <= 1 or p_u_20.isLeader())) then
					v_u_23.sound(v_u_24.sounds.error)
					v1403 = v_u_134
					for v1454, v1455 in v_u_91 do
						if v1455.id ~= v_u_235 then
							continue
						end
					end
					v1455 = v_u_154(v_u_48.mapId)
					if v1403(v1455) == "raids" then
						v1405 = v_u_118
						for v1456, v1457 in v_u_91 do
							if v1457.id ~= v_u_235 then
								continue
							end
						end
						v1457 = v_u_154(v_u_48.mapId)
						v1407 = v1405(v1457)
					else
						v1407 = nil
					end
					if v1407 then
						v_u_23.toast(v1407.line, "warn", v1407.progressText .. "  \194\183  Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
					else
						v1408 = v_u_23.toast
						v1409 = v_u_47.displayName
						for v1458, v1459 in v_u_91 do
							if v1459.id ~= v_u_235 then
								continue
							end
						end
						v1459 = v_u_154(v_u_48.mapId)
						v1408(v1409(v1459) .. " is not open yet", "warn", "Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
					end
				end
				if v1399 ~= nil and (#v1399.members > 1 and not p_u_20.isLeader()) or v_u_235 == v_u_48.mapId then
					if v_u_47.firstRaidGate and v_u_47.firstRaidGate() then
						return
					else
						if v_u_47.sheet then
							v_u_47.sheet.close("deploy")
						end
						v1411 = p_u_20.myParty()
						if v1411 == nil then
							v1412 = false
						else
							v1412 = #v1411.members > 1
						end
						if v1412 and not p_u_20.isLeader() then
							p_u_20.partyOp({
								["op"] = "ready"
							})
						else
							v_u_49 = os.clock() + 6
							v1413 = p_u_20.cctx.emit
							v1414 = "transit.info"
							v1415 = {
								["kind"] = "deploy",
								["map"] = nil,
								["mapId"] = nil,
								["difficulty"] = nil,
								["timeOfDay"] = nil,
								["map"] = v_u_47.displayName((v_u_154(v_u_48.mapId))),
								["mapId"] = v_u_48.mapId,
								["difficulty"] = v_u_48.difficulty
							}
							v1416 = v_u_154(v_u_48.mapId)
							if type(v1416) == "table" then
								v1417 = v1416.fixedTime or nil
							else
								v1417 = nil
							end
							if type(v1417) == "table" then
								v1418 = v1417[v_u_48.difficulty] or v1417.Normal
							else
								v1418 = nil
							end
							if v_u_47.timeLocked() then
								v1418 = v_u_47.lockedTime(v1418)
							end
							if v1418 then
								v1419 = v_u_154(v_u_48.mapId)
								v1420 = type(v1419) == "table" and v1419.fixedTime or nil
								if type(v1420) == "table" then
									v1421 = v1420[v_u_48.difficulty] or v1420.Normal
								else
									v1421 = nil
								end
								if v_u_47.timeLocked() then
									v1421 = v_u_47.lockedTime(v1421)
								end
							elseif v_u_48.difficulty == "Nightmare" then
								v1421 = "Night"
							elseif v_u_48.timeOfDay == "Any" then
								v1421 = nil
							else
								v1421 = v_u_48.timeOfDay
							end
							v1415.timeOfDay = v1421
							v1413(v1414, v1415)
							v_u_23.sound("deploy")
							v1422 = p_u_20.partyOp
							v1423 = {
								["op"] = "deploy",
								["difficulty"] = nil,
								["timeOfDay"] = nil,
								["freeRaid"] = nil,
								["mapId"] = nil,
								["privateRaid"] = nil,
								["privateFriends"] = nil,
								["viewMode"] = nil,
								["difficulty"] = v_u_48.difficulty,
								["timeOfDay"] = v_u_48.timeOfDay,
								["freeRaid"] = v_u_48.freeRaid
							}
							for v1470, v1471 in v_u_91 do
								if v1471.id ~= v_u_235 then
									continue
								end
							end
							v1471 = v_u_154(v_u_48.mapId)
							v1423.mapId = v1471.id
							v1423.privateRaid = v_u_48.privateRaid
							v1423.privateFriends = v_u_48.privateFriends
							v1423.viewMode = v_u_48.viewMode
							v1422(v1423)
							v_u_47.paint()
						end
					end
				end
			end
		else
			v1402 = v1401.enabled == true
			if not v1402 and (v1399 == nil or (#v1399.members <= 1 or p_u_20.isLeader())) then
				v_u_23.sound(v_u_24.sounds.error)
				v1403 = v_u_134
				for v1454, v1455 in v_u_91 do
					if v1455.id ~= v_u_235 then
						continue
					end
				end
				v1455 = v_u_154(v_u_48.mapId)
				if v1403(v1455) == "raids" then
					v1405 = v_u_118
					for v1456, v1457 in v_u_91 do
						if v1457.id ~= v_u_235 then
							continue
						end
					end
					v1457 = v_u_154(v_u_48.mapId)
					v1407 = v1405(v1457)
				else
					v1407 = nil
				end
				if v1407 then
					v_u_23.toast(v1407.line, "warn", v1407.progressText .. "  \194\183  Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
				else
					v1408 = v_u_23.toast
					v1409 = v_u_47.displayName
					for v1458, v1459 in v_u_91 do
						if v1459.id ~= v_u_235 then
							continue
						end
					end
					v1459 = v_u_154(v_u_48.mapId)
					v1408(v1409(v1459) .. " is not open yet", "warn", "Pick " .. v_u_47.displayName((v_u_154(v_u_48.mapId))) .. " to deploy.")
				end
			end
			if v1399 ~= nil and (#v1399.members > 1 and not p_u_20.isLeader()) or v_u_235 == v_u_48.mapId then
				if v_u_47.firstRaidGate and v_u_47.firstRaidGate() then
					return
				else
					if v_u_47.sheet then
						v_u_47.sheet.close("deploy")
					end
					v1411 = p_u_20.myParty()
					if v1411 == nil then
						v1412 = false
					else
						v1412 = #v1411.members > 1
					end
					if v1412 and not p_u_20.isLeader() then
						p_u_20.partyOp({
							["op"] = "ready"
						})
					else
						v_u_49 = os.clock() + 6
						v1413 = p_u_20.cctx.emit
						v1414 = "transit.info"
						v1415 = {
							["kind"] = "deploy",
							["map"] = nil,
							["mapId"] = nil,
							["difficulty"] = nil,
							["timeOfDay"] = nil,
							["map"] = v_u_47.displayName((v_u_154(v_u_48.mapId))),
							["mapId"] = v_u_48.mapId,
							["difficulty"] = v_u_48.difficulty
						}
						v1416 = v_u_154(v_u_48.mapId)
						if type(v1416) == "table" then
							v1417 = v1416.fixedTime or nil
						else
							v1417 = nil
						end
						if type(v1417) == "table" then
							v1418 = v1417[v_u_48.difficulty] or v1417.Normal
						else
							v1418 = nil
						end
						if v_u_47.timeLocked() then
							v1418 = v_u_47.lockedTime(v1418)
						end
						if v1418 then
							v1419 = v_u_154(v_u_48.mapId)
							v1420 = type(v1419) == "table" and v1419.fixedTime or nil
							if type(v1420) == "table" then
								v1421 = v1420[v_u_48.difficulty] or v1420.Normal
							else
								v1421 = nil
							end
							if v_u_47.timeLocked() then
								v1421 = v_u_47.lockedTime(v1421)
							end
						elseif v_u_48.difficulty == "Nightmare" then
							v1421 = "Night"
						elseif v_u_48.timeOfDay == "Any" then
							v1421 = nil
						else
							v1421 = v_u_48.timeOfDay
						end
						v1415.timeOfDay = v1421
						v1413(v1414, v1415)
						v_u_23.sound("deploy")
						v1422 = p_u_20.partyOp
						v1423 = {
							["op"] = "deploy",
							["difficulty"] = nil,
							["timeOfDay"] = nil,
							["freeRaid"] = nil,
							["mapId"] = nil,
							["privateRaid"] = nil,
							["privateFriends"] = nil,
							["viewMode"] = nil,
							["difficulty"] = v_u_48.difficulty,
							["timeOfDay"] = v_u_48.timeOfDay,
							["freeRaid"] = v_u_48.freeRaid
						}
						for v1470, v1471 in v_u_91 do
							if v1471.id ~= v_u_235 then
								continue
							end
						end
						v1471 = v_u_154(v_u_48.mapId)
						v1423.mapId = v1471.id
						v1423.privateRaid = v_u_48.privateRaid
						v1423.privateFriends = v_u_48.privateFriends
						v1423.viewMode = v_u_48.viewMode
						v1422(v1423)
						v_u_47.paint()
					end
				end
			end
		end
		for _, v1463 in v_u_91 do
			if v1463.id ~= v_u_235 then
				continue
			end
		end
		local v1463 = v_u_154(v_u_48.mapId)
		local v1464
		if v_u_237 then
			local v1465 = v_u_237.isOpenFor
			if type(v1465) == "function" then
				local v1466 = v_u_237.isOpenFor
				local v1467 = v_u_4
				local v1468, v1469 = pcall(v1466, v1463, v1467)
				if v1468 then
					if v1469 == true then
						v1464 = v_u_118(v1463) == nil
					else
						v1464 = false
					end
					if v1464 then
						v_u_23.sound(v_u_24.sounds.error)
						v_u_235 = v_u_48.mapId
						v_u_47.paint()
						v_u_23.toast("Deploy map is " .. v_u_47.displayName((v_u_154(v_u_48.mapId))), "warn", "The map you picked was not accepted. Pick it again.")
						return
					end
				else
					v1464 = v1463.enabled == true
					if v1464 then
						v_u_23.sound(v_u_24.sounds.error)
						v_u_235 = v_u_48.mapId
						v_u_47.paint()
						v_u_23.toast("Deploy map is " .. v_u_47.displayName((v_u_154(v_u_48.mapId))), "warn", "The map you picked was not accepted. Pick it again.")
						return
					end
				end
			else
				v1464 = v1463.enabled == true
				if v1464 then
					v_u_23.sound(v_u_24.sounds.error)
					v_u_235 = v_u_48.mapId
					v_u_47.paint()
					v_u_23.toast("Deploy map is " .. v_u_47.displayName((v_u_154(v_u_48.mapId))), "warn", "The map you picked was not accepted. Pick it again.")
					return
				end
			end
		else
			v1464 = v1463.enabled == true
			if v1464 then
				v_u_23.sound(v_u_24.sounds.error)
				v_u_235 = v_u_48.mapId
				v_u_47.paint()
				v_u_23.toast("Deploy map is " .. v_u_47.displayName((v_u_154(v_u_48.mapId))), "warn", "The map you picked was not accepted. Pick it again.")
				return
			end
		end
		if v_u_47.firstRaidGate and v_u_47.firstRaidGate() then
			return
		else
			if v_u_47.sheet then
				v_u_47.sheet.close("deploy")
			end
			v1411 = p_u_20.myParty()
			if v1411 == nil then
				v1412 = false
			else
				v1412 = #v1411.members > 1
			end
			if v1412 and not p_u_20.isLeader() then
				p_u_20.partyOp({
					["op"] = "ready"
				})
			else
				v_u_49 = os.clock() + 6
				v1413 = p_u_20.cctx.emit
				v1414 = "transit.info"
				v1415 = {
					["kind"] = "deploy",
					["map"] = nil,
					["mapId"] = nil,
					["difficulty"] = nil,
					["timeOfDay"] = nil,
					["map"] = v_u_47.displayName((v_u_154(v_u_48.mapId))),
					["mapId"] = v_u_48.mapId,
					["difficulty"] = v_u_48.difficulty
				}
				v1416 = v_u_154(v_u_48.mapId)
				if type(v1416) == "table" then
					v1417 = v1416.fixedTime or nil
				else
					v1417 = nil
				end
				if type(v1417) == "table" then
					v1418 = v1417[v_u_48.difficulty] or v1417.Normal
				else
					v1418 = nil
				end
				if v_u_47.timeLocked() then
					v1418 = v_u_47.lockedTime(v1418)
				end
				if v1418 then
					v1419 = v_u_154(v_u_48.mapId)
					v1420 = type(v1419) == "table" and v1419.fixedTime or nil
					if type(v1420) == "table" then
						v1421 = v1420[v_u_48.difficulty] or v1420.Normal
					else
						v1421 = nil
					end
					if v_u_47.timeLocked() then
						v1421 = v_u_47.lockedTime(v1421)
					end
				elseif v_u_48.difficulty == "Nightmare" then
					v1421 = "Night"
				elseif v_u_48.timeOfDay == "Any" then
					v1421 = nil
				else
					v1421 = v_u_48.timeOfDay
				end
				v1415.timeOfDay = v1421
				v1413(v1414, v1415)
				v_u_23.sound("deploy")
				v1422 = p_u_20.partyOp
				v1423 = {
					["op"] = "deploy",
					["difficulty"] = nil,
					["timeOfDay"] = nil,
					["freeRaid"] = nil,
					["mapId"] = nil,
					["privateRaid"] = nil,
					["privateFriends"] = nil,
					["viewMode"] = nil,
					["difficulty"] = v_u_48.difficulty,
					["timeOfDay"] = v_u_48.timeOfDay,
					["freeRaid"] = v_u_48.freeRaid
				}
				for v1470, v1471 in v_u_91 do
					if v1471.id ~= v_u_235 then
						continue
					end
				end
				v1471 = v_u_154(v_u_48.mapId)
				v1423.mapId = v1471.id
				v1423.privateRaid = v_u_48.privateRaid
				v1423.privateFriends = v_u_48.privateFriends
				v1423.viewMode = v_u_48.viewMode
				v1422(v1423)
				v_u_47.paint()
			end
		end
	end
	function v_u_47.pvIntro() -- name: pvIntro
		-- upvalues: (copy) p_u_20, (copy) p_u_21, (copy) v_u_47, (copy) v_u_60
		local function v1472()
			-- upvalues: (ref) p_u_20
			return p_u_20.cctx.lib.MenuPvpveIntro
		end
		local v1473, v1474 = pcall(v1472)
		if v1473 and type(v1474) == "table" then
			local v1475 = v1474.start
			local v1476 = p_u_20
			local v1477 = p_u_21
			local function v1479()
				-- upvalues: (ref) v_u_47, (ref) v_u_60
				local v1478
				if v_u_47.brief then
					v1478 = v_u_47.brief.tile("difficulty")
					if not v1478 then
						return v_u_47.brief.frame
					end
				else
					v1478 = v_u_60:FindFirstChild("Difficulty")
				end
				return v1478
			end
			local function v1481()
				-- upvalues: (ref) v_u_47, (ref) p_u_21
				local v1480
				if v_u_47.shown == true then
					v1480 = p_u_21.Parent ~= nil
				else
					v1480 = false
				end
				return v1480
			end
			local v1482, v1483 = pcall(v1475, v1476, v1477, v1479, v1481)
			local v1484 = v_u_47
			if not v1482 then
				v1483 = nil
			end
			v1484.introHandle = v1483
		end
	end
	function v_u_47.padFirst() -- name: padFirst
		-- upvalues: (copy) v_u_47
		if v_u_47.brief then
			return v_u_47.brief.padFirst()
		else
			return nil
		end
	end
	function v_u_47.show() -- name: show
		-- upvalues: (copy) v_u_47, (ref) v_u_51, (copy) p_u_20, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (copy) v_u_1319, (copy) p_u_21, (copy) v_u_507, (copy) v_u_669, (copy) v_u_1225, (copy) v_u_874, (copy) v_u_24, (copy) v_u_875, (ref) v_u_50, (ref) v_u_71, (copy) v_u_60
		v_u_47.shown = true
		v_u_47.paint()
		if v_u_47.globe then
			local v1485 = v_u_47.globe.show
			pcall(v1485)
		end
		local v1486 = v_u_51
		local v1487 = p_u_20.myParty()
		local v1488
		if v1487 == nil or #v1487.members <= 1 then
			v1488 = false
		else
			v1488 = not p_u_20.isLeader()
		end
		local v1491
		if v1488 then
			local v1490 = v_u_48.mapId
			for _, v1491 in v_u_91 do
				if v1491.id ~= v1490 then
					continue
				end
			end
			v1491 = nil
			if not v1491 then
				v1491 = v_u_154(v_u_48.mapId)
			end
		else
			v1491 = v_u_154(v_u_48.mapId)
		end
		if v1486 ~= v1491.id then
			v_u_1319()
		end
		local v_u_1492 = false
		task.spawn(function()
			-- upvalues: (ref) p_u_20, (copy) v_u_1492, (ref) v_u_47, (ref) p_u_21, (ref) v_u_507
			p_u_20.fetch("tasks", nil, v_u_1492 and 1 or 15)
			v_u_47.tasksAsked = true
			if p_u_21.Parent then
				v_u_507()
				if v_u_47.brief then
					local v1493 = v_u_47.brief.paint
					pcall(v1493)
				end
			end
		end)
		v_u_669()
		v_u_1225()
		local function v1499()
			-- upvalues: (ref) p_u_20, (ref) v_u_47, (ref) v_u_874, (ref) v_u_24
			local v1494 = p_u_20.cctx.lib.MenuPlayStats.line
			local v1495 = p_u_20.profile
			local v1496 = v_u_47.pvPublic()
			local v1497 = v_u_874.AbsoluteSize.X
			local v1498 = v_u_24.uiScale()
			return v1494(v1495, v1496, v1497 / math.max(v1498, 0.01))
		end
		local v1500, v1501 = pcall(v1499)
		if v1500 and type(v1501) == "string" then
			v_u_875.Text = v1501
		end
		task.spawn(function()
			-- upvalues: (ref) p_u_20, (ref) v_u_50, (ref) p_u_21, (ref) v_u_1319
			local v1502 = p_u_20.fetch("hideout", nil, 60)
			if type(v1502) == "table" then
				local v1503 = v1502.effects
				if type(v1503) == "table" then
					local v1504 = v1502.effects.radioIntel
					v_u_50 = tonumber(v1504) or 0
				end
			end
			if p_u_21.Parent then
				v_u_1319()
			end
		end)
		if v_u_71 then
			local v1505 = v_u_71.paint
			pcall(v1505)
			if v_u_71.frame.Visible then
				v_u_60.CanvasPosition = Vector2.zero
			end
		end
		v_u_47.pvIntro()
	end
	function v_u_47.hide() -- name: hide
		-- upvalues: (copy) v_u_47, (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25
		v_u_47.shown = false
		v_u_279 = false
		v_u_270.Visible = false
		v_u_260(false)
		v_u_251.Color = v_u_25.line
		if v_u_47.globe then
			local v1506 = v_u_47.globe.hide
			pcall(v1506)
		end
	end
	local function v_u_1519(p1507) -- name: watchLock
		-- upvalues: (ref) v_u_234, (copy) v_u_52, (copy) p_u_21, (copy) v_u_47, (copy) v_u_1326
		v_u_234 = p1507
		for _, v1508 in { "DeployClosed", "DeployMsg" } do
			local v1509 = v_u_52
			local v1510 = p1507:GetAttributeChangedSignal(v1508)
			local function v1512()
				-- upvalues: (ref) p_u_21, (ref) v_u_47
				if p_u_21.Parent then
					local v1511 = v_u_47.paint
					pcall(v1511)
				end
			end
			table.insert(v1509, v1510:Connect(v1512))
		end
		local v1513 = v_u_52
		local v1514 = p1507.AttributeChanged
		local function v1518(p1515)
			-- upvalues: (ref) p_u_21, (ref) v_u_47, (ref) v_u_1326
			if p_u_21.Parent and (string.sub(p1515, 1, 8) == "MapGate_" or p1515 == "MapAccessLive") then
				local v1516 = v_u_47.paint
				pcall(v1516)
				local v1517 = v_u_1326
				pcall(v1517)
			end
		end
		table.insert(v1513, v1514:Connect(v1518))
	end
	local v1520 = v_u_4:GetAttributeChangedSignal("MapTester")
	table.insert(v_u_52, v1520:Connect(function()
		-- upvalues: (copy) p_u_21, (copy) v_u_47, (copy) v_u_1326
		if p_u_21.Parent then
			local v1521 = v_u_47.paint
			pcall(v1521)
			local v1522 = v_u_1326
			pcall(v1522)
		end
	end))
	local v1523 = v_u_4:GetAttributeChangedSignal("FinishedRaids")
	table.insert(v_u_52, v1523:Connect(function()
		-- upvalues: (copy) p_u_21, (copy) v_u_47, (copy) v_u_1326
		if p_u_21.Parent then
			local v1524 = v_u_47.paint
			pcall(v1524)
			local v1525 = v_u_1326
			pcall(v1525)
		end
	end))
	local v1526 = v_u_4:GetAttributeChangedSignal("MapQuests")
	table.insert(v_u_52, v1526:Connect(function()
		-- upvalues: (copy) p_u_21, (copy) v_u_47, (copy) v_u_1326
		if p_u_21.Parent then
			local v1527 = v_u_47.paint
			pcall(v1527)
			local v1528 = v_u_1326
			pcall(v1528)
		end
	end))
	if v_u_234 then
		v_u_1519(v_u_234)
	else
		task.spawn(function()
			-- upvalues: (copy) p_u_21, (copy) v_u_1519, (copy) v_u_47
			local v1529 = game:GetService("ReplicatedStorage"):WaitForChild("Config", 30)
			if v1529 and p_u_21.Parent then
				v_u_1519(v1529)
				local v1530 = v_u_47.paint
				pcall(v1530)
			end
		end)
	end
	function v_u_47.onBack() -- name: onBack
		-- upvalues: (copy) v_u_47, (ref) v_u_279, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25
		local v1531 = v_u_47.globe
		local v1532 = v_u_47.sheet
		if v1531 and (v1531.isOpen and v1531.isOpen()) then
			local v1533 = v1531.closeBack
			return pcall(v1533) or true
		end
		if v1532 and (v1532.isOpen and v1532.isOpen()) then
			local v1534 = v1532.close
			return pcall(v1534, "back") or true
		end
		if not v_u_279 then
			return false
		end
		v_u_279 = false
		v_u_270.Visible = false
		v_u_260(false)
		v_u_251.Color = v_u_25.line
		return true
	end
	local v_u_1535 = nil
	local function v1536()
		-- upvalues: (ref) v_u_1535, (copy) p_u_20
		v_u_1535 = p_u_20.cctx.lib.VirtualPad
	end
	pcall(v1536)
	if v_u_1535 and v_u_1535.InputBegan then
		local v1537 = v_u_1535.InputBegan
		local function v1543(p1538)
			-- upvalues: (copy) p_u_21, (ref) v_u_279, (copy) v_u_47, (ref) v_u_4, (copy) v_u_23, (copy) v_u_24, (copy) v_u_270, (copy) v_u_260, (copy) v_u_251, (copy) v_u_25, (copy) v_u_271, (ref) v_u_235, (copy) v_u_250
			if p1538.KeyCode == Enum.KeyCode.ButtonB and p_u_21.Parent then
				if v_u_279 and (p_u_21.Visible and not (v_u_47.globe and (v_u_47.globe.isOpen and v_u_47.globe.isOpen()))) then
					v_u_4:SetAttribute("MenuPlayPadB", "fold")
					local v1539 = v_u_23.takeBack
					pcall(v1539)
					v_u_23.sound(v_u_24.sounds.click)
					v_u_279 = false
					v_u_270.Visible = false
					v_u_260(false)
					v_u_251.Color = v_u_25.line
					local v1540 = game:GetService("GuiService")
					local _ = v_u_271[v_u_235]
					v1540.SelectedObject = v_u_250
					local v_u_1541 = game:GetService("GuiService")
					task.defer(function()
						-- upvalues: (ref) v_u_250, (copy) v_u_1541
						if v_u_250.Parent and v_u_1541.SelectedObject ~= v_u_250 then
							v_u_1541.SelectedObject = v_u_250
						end
					end)
					return
				elseif v_u_47.sheet and (v_u_47.sheet.isOpen() and (p_u_21.Visible and not (v_u_47.globe and (v_u_47.globe.isOpen and v_u_47.globe.isOpen())))) then
					v_u_4:SetAttribute("MenuPlayPadB", "sheet")
					v_u_47.sheet.close("pad")
					local v1542 = v_u_23.takeBack
					pcall(v1542)
				else
					v_u_4:SetAttribute("MenuPlayPadB", "pass")
				end
			else
				return
			end
		end
		table.insert(v_u_52, v1537:Connect(v1543))
	end
	function v_u_47.refresh(p1544, p1545) -- name: refresh
		-- upvalues: (copy) p_u_20, (ref) v_u_49, (copy) v_u_47, (ref) v_u_51, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (copy) v_u_1319, (copy) v_u_1225, (copy) v_u_874, (copy) v_u_24, (copy) v_u_875, (copy) v_u_669, (copy) p_u_21, (copy) v_u_507
		if p1544 ~= "result" or type(p1545) ~= "table" then
			if p1544 == "party" then
				local v1546 = p_u_20.party
				if type(v1546) == "table" and v1546.notice then
					v_u_49 = 0
				end
			end
			v_u_47.paint()
			local v1547 = v_u_51
			local v1548 = p_u_20.myParty()
			local v1549
			if v1548 == nil or #v1548.members <= 1 then
				v1549 = false
			else
				v1549 = not p_u_20.isLeader()
			end
			local v1552
			if v1549 then
				local v1551 = v_u_48.mapId
				for _, v1552 in v_u_91 do
					if v1552.id ~= v1551 then
						continue
					end
				end
				v1552 = nil
				if not v1552 then
					v1552 = v_u_154(v_u_48.mapId)
				end
			else
				v1552 = v_u_154(v_u_48.mapId)
			end
			if v1547 ~= v1552.id then
				v_u_1319()
			end
			v_u_1225()
			local function v1558()
				-- upvalues: (ref) p_u_20, (ref) v_u_47, (ref) v_u_874, (ref) v_u_24
				local v1553 = p_u_20.cctx.lib.MenuPlayStats.line
				local v1554 = p_u_20.profile
				local v1555 = v_u_47.pvPublic()
				local v1556 = v_u_874.AbsoluteSize.X
				local v1557 = v_u_24.uiScale()
				return v1553(v1554, v1555, v1556 / math.max(v1557, 0.01))
			end
			local v1559, v1560 = pcall(v1558)
			if v1559 and type(v1560) == "string" then
				v_u_875.Text = v1560
			end
			if p1544 == "profile" then
				v_u_669()
				local v_u_1561 = true
				task.spawn(function()
					-- upvalues: (ref) p_u_20, (copy) v_u_1561, (ref) v_u_47, (ref) p_u_21, (ref) v_u_507
					p_u_20.fetch("tasks", nil, v_u_1561 and 1 or 15)
					v_u_47.tasksAsked = true
					if p_u_21.Parent then
						v_u_507()
						if v_u_47.brief then
							local v1562 = v_u_47.brief.paint
							pcall(v1562)
						end
					end
				end)
			end
		end
	end
	function v_u_47.tick() -- name: tick
		-- upvalues: (ref) v_u_881, (copy) v_u_877, (ref) v_u_880, (copy) v_u_879, (copy) v_u_878, (copy) v_u_23, (copy) p_u_20, (copy) v_u_47, (ref) v_u_51, (copy) v_u_48, (copy) v_u_91, (copy) v_u_154, (copy) v_u_1319
		v_u_881 = v_u_881 + 1
		v_u_877.BackgroundTransparency = v_u_881 % 2 == 0 and 0 or 0.6
		if v_u_881 >= 9 then
			v_u_881 = 0
			v_u_880 = v_u_880 % #v_u_879 + 1
			v_u_878.Text = v_u_879[v_u_880]
			v_u_878.TextTransparency = 1
			v_u_23.tween(v_u_878, {
				["TextTransparency"] = 0
			}, "slower")
		end
		local v1563 = p_u_20.derived()
		local v1564 = v1563.freeRaidIn
		if tonumber(v1564) and v1563.freeRaidIn > 0 then
			v1563.freeRaidIn = v1563.freeRaidIn - 1
		end
		v_u_47.paint()
		local v1565 = v_u_51
		local v1566 = p_u_20.myParty()
		local v1567
		if v1566 == nil or #v1566.members <= 1 then
			v1567 = false
		else
			v1567 = not p_u_20.isLeader()
		end
		local v1570
		if v1567 then
			local v1569 = v_u_48.mapId
			for _, v1570 in v_u_91 do
				if v1570.id ~= v1569 then
					continue
				end
			end
			v1570 = nil
			if not v1570 then
				v1570 = v_u_154(v_u_48.mapId)
			end
		else
			v1570 = v_u_154(v_u_48.mapId)
		end
		if v1565 ~= v1570.id then
			v_u_1319()
		end
	end
	function v_u_47.destroy() -- name: destroy
		-- upvalues: (copy) v_u_47, (copy) v_u_52, (ref) v_u_71, (copy) p_u_20
		if v_u_47.globe then
			local v1571 = v_u_47.globe.destroy
			pcall(v1571)
		end
		for _, v1572 in v_u_52 do
			v1572:Disconnect()
		end
		if v_u_71 then
			local v1573 = v_u_71.destroy
			pcall(v1573)
			if p_u_20.tutorialCard == v_u_71 then
				p_u_20.tutorialCard = nil
			end
			v_u_71 = nil
		end
	end
	local v1574 = v22.Heartbeat
	local function v1582()
		-- upvalues: (copy) p_u_21, (copy) p_u_20, (ref) v_u_757, (copy) v_u_47, (copy) v_u_864, (ref) v_u_12
		if p_u_21.Parent then
			local v1575 = p_u_20.myParty()
			local v1576
			if v1575 then
				local v1577 = v1575.searching
				if type(v1577) == "table" then
					v1576 = v1575.searching
				else
					v1576 = nil
				end
			else
				v1576 = nil
			end
			if v1576 then
				if v_u_757 then
					local v1578 = v_u_864
					local v1579
					if v_u_12 then
						v1579 = v_u_12.state(v1575)
					else
						v1579 = nil
					end
					pcall(v1578, v1579, v1576)
				else
					local v1580 = v_u_47.paint
					pcall(v1580)
				end
			else
				if v_u_757 then
					local v1581 = v_u_47.paint
					pcall(v1581)
				end
				return
			end
		else
			return
		end
	end
	table.insert(v_u_52, v1574:Connect(v1582))
	local function v1590()
		-- upvalues: (copy) p_u_20, (copy) p_u_21, (copy) v_u_47, (ref) v_u_4, (copy) v_u_725, (copy) v_u_759, (copy) v_u_385
		p_u_20.cctx.command("menu.map", function(p1583)
			-- upvalues: (ref) p_u_21, (ref) v_u_47, (ref) v_u_4, (ref) v_u_725, (ref) v_u_759, (ref) v_u_385
			if not p_u_21.Parent then
				return "menu play tab is gone"
			end
			if p1583[1] and not v_u_47.viewMap(string.lower(p1583[1])) then
				local v1584 = p1583[1]
				return "not shown: " .. tostring(v1584)
			end
			local v1585 = v_u_4
			local v1586 = tostring(v1585:GetAttribute("MenuPlayMap"))
			local v1587 = v_u_725.Text
			local v1588 = v_u_759:FindFirstChild("Text", true)
			local v1589 = v_u_385
			return ("%s summary=%s button=%s picture=%s"):format(v1586, v1587, not (v1588 and v1588:IsA("TextLabel")) and "?" or v1588.Text, (tostring(v1589:GetAttribute("MapPicture"))))
		end)
	end
	pcall(v1590)
	v_u_1319()
	v_u_47.paint()
	v_u_669()
	v_u_1225()
	v_u_507()
	pcall(function()
		-- upvalues: (copy) p_u_20, (copy) p_u_21, (copy) v_u_47
		p_u_20.cctx.lib.MenuRail.attach(p_u_20, p_u_21, v_u_47)
	end)
	pcall(function()
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) v_u_60, (copy) v_u_55
		local v1591 = p_u_20.cctx.lib.MenuPassWidget.attach
		local v1592 = p_u_20
		local v1593
		if v_u_47.brief then
			v1593 = v_u_47.brief.host("pass")
		else
			v1593 = v_u_60
		end
		v1591(v1592, v1593, v_u_47, v_u_47.brief and {
			["w"] = nil,
			["fill"] = true,
			["w"] = v_u_55
		} or nil)
	end)
	pcall(function()
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) v_u_723, (copy) v_u_759, (copy) v_u_55, (copy) v_u_27, (copy) p_u_21
		local v1594 = {
			["dep"] = v_u_723,
			["deployBtn"] = v_u_759,
			["colW"] = v_u_55,
			["compact"] = v_u_27,
			["page"] = p_u_21
		}
		p_u_20.cctx.lib.MenuPaidQueue.attach(p_u_20, v_u_47, v1594)
	end)
	if v_u_47.brief then
		local v1595 = v_u_47.brief.finish
		pcall(v1595)
	end
	pcall(function()
		-- upvalues: (copy) p_u_20, (copy) v_u_47, (copy) v_u_56, (copy) v_u_246, (copy) v_u_55, (copy) v_u_27, (copy) v_u_48, (ref) v_u_761
		local v1596 = {
			["col"] = v_u_56,
			["op"] = v_u_246,
			["w"] = v_u_55,
			["compact"] = v_u_27,
			["sel"] = v_u_48,
			["dep"] = function() -- name: dep
				-- upvalues: (ref) v_u_761
				return v_u_761
			end
		}
		p_u_20.cctx.lib.MenuRotationPlay.attach(p_u_20, v_u_47, v1596)
	end)
	local v_u_1597 = nil
	local function v1598()
		-- upvalues: (ref) v_u_1597, (copy) p_u_20
		v_u_1597 = p_u_20.cctx.lib.MenuGlobe
	end
	pcall(v1598)
	local v1599 = v_u_1597
	if type(v1599) == "table" then
		local v1600 = v_u_1597.attach
		if type(v1600) == "function" and not v_u_47.rotation then
			local function v1618()
				-- upvalues: (copy) v_u_47, (ref) v_u_1597, (copy) p_u_20, (copy) p_u_21, (copy) v_u_91, (copy) v_u_48, (ref) v_u_235, (copy) v_u_270, (copy) v_u_245, (copy) v_u_56, (copy) v_u_55, (copy) v_u_27, (copy) v_u_60, (copy) v_u_250, (copy) v_u_874
				local v1601 = v_u_47
				local v1602 = v_u_1597.attach
				local v1603 = p_u_20
				local v1604 = p_u_21
				local v1605 = v_u_47
				local v1615 = {
					["pins"] = function() -- name: pins
						-- upvalues: (ref) v_u_91, (ref) v_u_47
						local v1606 = {}
						for _, v1607 in v_u_91 do
							local v1608 = v_u_47.describePin
							table.insert(v1606, v1608(v1607))
						end
						return v1606
					end,
					["pick"] = v_u_47.viewMap,
					["deployId"] = function() -- name: deployId
						-- upvalues: (ref) v_u_48
						return v_u_48.mapId
					end,
					["viewId"] = function() -- name: viewId
						-- upvalues: (ref) v_u_235
						return v_u_235
					end,
					["frozen"] = function() -- name: frozen
						-- upvalues: (ref) p_u_20
						local v1609 = p_u_20.myParty()
						local v1610
						if v1609 == nil then
							v1610 = false
						else
							local v1611 = v1609.searching
							v1610 = type(v1611) == "table"
						end
						local v1612 = p_u_20.myParty()
						local v1613
						if v1612 == nil or #v1612.members <= 1 then
							v1613 = false
						else
							v1613 = not p_u_20.isLeader()
						end
						local v1614 = v1610 or v1613
						if v1610 then
							return v1614, "search"
						elseif v1613 then
							return v1614, "member"
						else
							return v1614, nil
						end
					end,
					["list"] = v_u_47.openList,
					["listHost"] = v_u_270,
					["opCard"] = v_u_245,
					["column"] = v_u_56,
					["colW"] = v_u_55,
					["compact"] = v_u_27,
					["scrolls"] = { v_u_60 }
				}
				local v1616
				if v_u_47.brief then
					v1616 = v_u_47.brief.first()
				else
					v1616 = v_u_250
				end
				v1615.columnFirst = v1616
				local v1617
				if v_u_47.rail and (v_u_47.rail.cards and v_u_47.rail.cards.mail) then
					v1617 = v_u_47.rail.cards.mail.btn
				else
					v1617 = nil
				end
				v1615.rail = v1617
				v1615.plate = v_u_874
				v1601.globe = v1602(v1603, v1604, v1605, v1615)
			end
			local function v1620(p1619)
				-- upvalues: (ref) v_u_4
				warn("[MenuPlay] globe attach failed: " .. tostring(p1619))
				v_u_4:SetAttribute("ClientError", "globe: " .. tostring(p1619))
				return p1619
			end
			xpcall(v1618, v1620)
		end
	end
	local v1621 = v_u_4:GetAttributeChangedSignal("MapRevealed")
	table.insert(v_u_52, v1621:Connect(function()
		-- upvalues: (copy) v_u_47
		v_u_47.paint()
	end))
	return v_u_47
end
return v_u_3