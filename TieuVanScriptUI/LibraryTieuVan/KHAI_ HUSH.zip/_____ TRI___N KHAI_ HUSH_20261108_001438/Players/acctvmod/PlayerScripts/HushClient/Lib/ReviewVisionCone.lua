-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewVisionCone

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = {}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
function v_u_3.use(p9) -- name: use
	-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
	v_u_4 = type(p9) ~= "table" and {} or p9
	v_u_6 = nil
	v_u_7 = nil
	v_u_8 = nil
end
local v_u_10 = {
	["wid"] = "",
	["mods"] = "",
	["mag"] = 1,
	["class"] = ""
}
local v_u_11 = {
	["root"] = nil,
	["char"] = nil,
	["folder"] = nil,
	["aiming"] = false,
	["sightMag"] = 1,
	["class"] = "",
	["speed"] = 0,
	["shift"] = nil
}
function v_u_3.init(p12) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
	v_u_5 = p12
	v_u_6 = nil
	v_u_7 = nil
end
local function v_u_14() -- name: raidFolder
	-- upvalues: (ref) v_u_4, (copy) v_u_2
	if v_u_4.folder == nil then
		local v13 = v_u_2:FindFirstChild("HushRuntime") or workspace:FindFirstChild("HushRuntime")
		if v13 == nil then
			return nil
		else
			return v13:FindFirstChild("Raid")
		end
	elseif v_u_4.folder == false then
		return nil
	else
		return v_u_4.folder
	end
end
function v_u_3.optic(p15, p16, p17) -- name: optic
	-- upvalues: (copy) v_u_10, (ref) v_u_4, (ref) v_u_5
	local v_u_18 = type(p15) ~= "string" and "" or p15
	local v_u_19 = type(p16) ~= "string" and "" or p16
	if v_u_10.wid ~= v_u_18 or v_u_10.mods ~= v_u_19 then
		local v20 = v_u_10
		v_u_10.wid = v_u_18
		v20.mods = v_u_19
		local v21 = v_u_10
		v_u_10.mag = 1
		v21.class = ""
		local function v32()
			-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_18, (copy) v_u_19, (ref) v_u_10
			local v22
			if v_u_4.weapons == nil then
				v22 = v_u_5.shared.Weapons
			else
				v22 = v_u_4.weapons
			end
			local v23
			if v_u_4.sights == nil then
				v23 = v_u_5.shared.Sights
			else
				v23 = v_u_4.sights
			end
			local v24
			if v_u_18 == "" then
				v24 = nil
			else
				v24 = v22.get(v_u_18)
			end
			if v24 then
				local v25
				if v_u_19 == "" then
					v25 = nil
				else
					v25 = string.split(v_u_19, ",")
				end
				local v26 = v23.get(v23.of(v_u_18, v25, v24))
				local v27 = v_u_10
				local v28
				if v26 then
					local v29 = v26.mag
					v28 = type(v29) ~= "number" and 1 or v26.mag
				else
					v28 = 1
				end
				v27.mag = v28
				local v30 = v_u_10
				local v31 = v24.class
				v30.class = type(v31) ~= "string" and "" or v24.class
			end
		end
		pcall(v32)
	end
	return v_u_10.mag, v_u_10.class, p17 == true
end
local function v_u_39() -- name: watched
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (ref) v_u_6, (ref) v_u_5
	local v33
	if v_u_4.player == nil then
		v33 = v_u_1.LocalPlayer
	else
		v33 = v_u_4.player
	end
	if v33 == nil or (v33:GetAttribute("OverwatchReviewer") ~= true or type(v33:GetAttribute("OverwatchTarget")) ~= "number") then
		return nil, nil
	else
		local v34
		if v_u_4.cam == nil then
			if v_u_6 == nil then
				local v35 = v_u_5
				if type(v35) == "table" then
					local v36 = v_u_5.lib
					if type(v36) == "table" then
						v_u_6 = v_u_5.lib.ReviewCamera
					end
				end
			end
			v34 = v_u_6
		elseif v_u_4.cam == false then
			v34 = nil
		else
			v34 = v_u_4.cam
		end
		if v34 == nil then
			return nil, nil
		else
			local v37 = v34.targetRoot()
			if v37 == nil then
				return nil, nil
			else
				local v38 = v37.Parent
				if v38 == nil or (v38 == workspace or not v38:IsA("Model")) then
					return nil, nil
				elseif v38:GetAttribute("Dead") == true then
					return nil, nil
				else
					return v37, v38
				end
			end
		end
	end
end
function v_u_3.source(p40) -- name: source
	-- upvalues: (copy) v_u_39, (copy) v_u_14, (copy) v_u_3, (copy) v_u_11
	if p40 ~= true then
		return nil
	end
	local v41, v42 = v_u_39()
	if v41 == nil then
		return nil
	end
	local v43 = v_u_14()
	if v43 == nil then
		return nil
	end
	local v44, v45, v46 = v_u_3.optic(v42:GetAttribute("Weapon"), v42:GetAttribute("WeaponMods"), v42:GetAttribute("Aiming"))
	local v47 = v41.AssemblyLinearVelocity
	local v48 = v_u_11
	local v49 = v_u_11
	v_u_11.root = v41
	v48.char = v42
	v49.folder = v43
	local v50 = v_u_11
	local v51 = v_u_11
	v_u_11.sightMag = v44
	v50.class = v45
	v51.aiming = v46
	local v52 = v_u_11
	local v53 = v47.X * v47.X + v47.Z * v47.Z
	v52.speed = math.sqrt(v53)
	v_u_11.shift = nil
	return v_u_11
end
function v_u_3.scope(p54, p55, p56, p57, p58, p59) -- name: scope
	-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_5
	local v60
	if v_u_4.scope == nil then
		if v_u_7 == nil then
			local v61 = v_u_5
			if type(v61) == "table" then
				local v62 = v_u_5.lib
				if type(v62) == "table" then
					v_u_7 = v_u_5.lib.ScopeCone
				end
			end
		end
		v60 = v_u_7
	elseif v_u_4.scope == false then
		v60 = nil
	else
		v60 = v_u_4.scope
	end
	if v60 == nil then
		return p57, p58, false
	end
	local v63 = v60.active(p55, p56, false, p54.aiming)
	local v64 = v60.mag(p54.sightMag, p54.class)
	local v65, v66 = v60.evaluate(v63, v64, p54.class, p57, p54.speed, p54.shift)
	local v67 = v60.blendHalf(p58, v66, p59)
	if v63 then
		v63 = v66 < v60.TUNE.HALF_BASE
	end
	return v65, v67, v63
end
function v_u_3.hudFacts() -- name: hudFacts
	-- upvalues: (copy) v_u_39, (copy) v_u_3, (ref) v_u_4, (ref) v_u_8, (copy) v_u_2
	local v68, v69 = v_u_39()
	if v68 == nil then
		return nil, nil
	end
	local v70 = v69:GetAttribute("Weapon")
	local v71, _, v72 = v_u_3.optic(v70, v69:GetAttribute("WeaponMods"), v69:GetAttribute("Aiming"))
	local v73
	if type(v70) == "string" and v70 ~= "" then
		v73 = string.sub(v70, 1, 24)
	else
		v73 = nil
	end
	local v74
	if v_u_4.rules == nil then
		if v_u_8 == nil then
			v_u_8 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		end
		v74 = v_u_8
	else
		v74 = v_u_4.rules
	end
	return v74.scopePack(v71, v72), v73
end
function v_u_3.sightCode() -- name: sightCode
	-- upvalues: (copy) v_u_3
	return v_u_3.hudFacts()
end
function v_u_3.weaponName() -- name: weaponName
	-- upvalues: (copy) v_u_3
	local _, v75 = v_u_3.hudFacts()
	return v75
end
return v_u_3