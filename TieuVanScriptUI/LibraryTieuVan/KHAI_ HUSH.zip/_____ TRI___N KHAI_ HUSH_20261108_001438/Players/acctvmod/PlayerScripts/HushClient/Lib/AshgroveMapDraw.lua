-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AshgroveMapDraw

local v_u_1 = game:GetService("TextService")
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v3, v_u_4 = pcall(function()
	return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapTagPlace", 5)))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v5, v_u_6 = pcall(function()
	return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapReveal", 5)))
end)
if not v5 or type(v_u_6) ~= "table" then
	v_u_6 = nil
end
local v_u_7 = {}
local v8, v_u_9 = pcall(function()
	return require((script.Parent:WaitForChild("AshgroveMapData", 5)))
end)
if not v8 or type(v_u_9) ~= "table" then
	v_u_9 = nil
end
local v10, v11 = pcall(function()
	return require((script.Parent:WaitForChild("MapDraw", 5)))
end)
local v12 = nil
if v10 and type(v11) == "table" then
	local v13 = v11.INK
	if type(v13) == "table" then
		v12 = v11.INK
	end
end
local v_u_14 = {
	["paper"] = Color3.fromHex("D8CDB2"),
	["paperLight"] = Color3.fromHex("E6DCC4"),
	["paperEdge"] = Color3.fromHex("A99C7E"),
	["crease"] = Color3.fromHex("BDB091"),
	["grid"] = Color3.fromHex("C3B697"),
	["ink"] = Color3.fromHex("372F26"),
	["inkSoft"] = Color3.fromHex("6A5E4C"),
	["field"] = Color3.fromHex("CFC598"),
	["park"] = Color3.fromHex("B9BE92"),
	["forest"] = Color3.fromHex("B4B98F"),
	["tree"] = Color3.fromHex("7C8758"),
	["water"] = Color3.fromHex("8DA4AE"),
	["waterInk"] = Color3.fromHex("44606E"),
	["bank"] = Color3.fromHex("BDC0A6"),
	["lot"] = Color3.fromHex("C6BCA5"),
	["road"] = Color3.fromHex("F0E8D4"),
	["roadCase"] = Color3.fromHex("5D5345"),
	["highway"] = Color3.fromHex("F2DFA9"),
	["build"] = Color3.fromHex("8C806D"),
	["buildEdge"] = Color3.fromHex("4A4136"),
	["landmark"] = Color3.fromHex("9C4B39"),
	["landmarkEdge"] = Color3.fromHex("5E2A1F"),
	["red"] = Color3.fromHex("B0322A"),
	["redDeep"] = Color3.fromHex("7E2019"),
	["green"] = Color3.fromHex("3E6E4A")
}
if v12 then
	for v15, v16 in v12 do
		v_u_14[v15] = v16
	end
end
v_u_14.rock = Color3.fromHex("B2A688")
v_u_14.rockInk = Color3.fromHex("5A4D38")
v_u_14.tunnel = Color3.fromHex("7E2019")
v_u_14.armyGrid = Color3.fromHex("8E8E86")
v_u_14.tarmac = v_u_14.rock
v_u_14.padConcrete = Color3.fromHex("C8BEA7")
v_u_14.padAsphalt = Color3.fromHex("BBB19A")
v_u_14.padGravel = Color3.fromHex("CDC0A0")
v_u_14.padDirt = Color3.fromHex("C4AE88")
v_u_14.tent = Color3.fromHex("DDD3B9")
v_u_7.INK = v_u_14
v_u_7.KEY = {
	{ "landmark", "Landmark" },
	{ "build", "Building" },
	{ "forest", "Woods" },
	{ "rock", "Rock" },
	{ "road", "Road" },
	{ "tunnel", "Tunnel" }
}
function v_u_7.available() -- name: available
	-- upvalues: (ref) v_u_9
	local v17
	if v_u_9 == nil then
		v17 = false
	else
		local v18 = v_u_9.LOTS
		if type(v18) == "table" and #v_u_9.LOTS > 0 then
			local v19 = v_u_9.HALF
			v17 = type(v19) == "number"
		else
			v17 = false
		end
	end
	return v17
end
function v_u_7.data() -- name: data
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_7.placeOf(p20) -- name: placeOf
	-- upvalues: (ref) v_u_9
	if v_u_9 then
		local v21 = v_u_9.PLACES
		if type(v21) == "table" and type(p20) == "string" then
			local v22 = v_u_9.PLACES[string.lower(p20)]
			if type(v22) == "table" then
				return v22[1], v22[2], v22[3]
			else
				return nil, nil, nil
			end
		end
	end
	return nil, nil, nil
end
local function v_u_35(p23, p24, p25, p26, p27, p28, p29) -- name: text
	-- upvalues: (ref) v_u_14
	local v30 = Instance.new("TextLabel")
	v30.Name = "Txt"
	v30.BackgroundTransparency = 1
	v30.AnchorPoint = Vector2.new(0.5, 0.5)
	v30.Position = UDim2.fromOffset(p25.X, p25.Y)
	local v31 = UDim2.fromOffset
	local v32 = (utf8.len(p24) or #p24) * p26 * 0.62 + 8
	v30.Size = v31(math.max(20, v32), p26 + 4)
	v30.FontFace = p27
	v30.TextSize = p26
	v30.TextColor3 = p28
	v30.TextStrokeColor3 = v_u_14.paper
	v30.TextStrokeTransparency = 0.25
	v30.Text = p24
	v30.TextTruncate = Enum.TextTruncate.AtEnd
	if p29 then
		for v33, v34 in p29 do
			v30[v33] = v34
		end
	end
	v30.Parent = p23
	return v30
end
local function v_u_41(p36) -- name: spaced
	local v37 = utf8.char(8202)
	local v38 = {}
	for _, v39 in utf8.codes(string.upper(p36)) do
		local v40 = utf8.char
		table.insert(v38, v40(v39))
	end
	return table.concat(v38, v37)
end
local v_u_42 = {
	"A",
	"B",
	"C",
	"D",
	"E",
	"F"
}
function v_u_7.gridRef(p43, p44) -- name: gridRef
	-- upvalues: (ref) v_u_9, (copy) v_u_42
	local v45 = not v_u_9 and 750 or v_u_9.HALF
	local v46 = v45 * 2 / 250 + 0.5
	local v47 = math.floor(v46)
	local v48 = (p43 + v45) / 250
	local v49 = math.floor(v48) + 1
	local v50 = math.clamp(v49, 1, v47)
	local v51 = (p44 + v45) / 250
	local v52 = math.floor(v51) + 1
	local v53 = math.clamp(v52, 1, v47)
	return (v_u_42[v50] or "?") .. tostring(v53)
end
function v_u_7.build(p54, p55, p56, p57, p_u_58) -- name: build
	-- upvalues: (ref) v_u_9, (copy) v_u_35, (copy) v_u_2, (ref) v_u_14, (ref) v_u_4, (copy) v_u_41, (copy) v_u_42, (ref) v_u_6, (copy) v_u_1, (copy) v_u_7
	local v59 = v_u_9
	assert(v59, "AshgroveMapData missing")
	local v_u_60 = v_u_35
	local v61
	if p_u_58 then
		v61 = p_u_58.phone
	else
		v61 = v_u_2.isPhone()
	end
	local v_u_62 = v_u_9.HALF
	local v63 = p55 * 0.035
	local v64 = math.floor(v63)
	local v_u_65 = p55 - v64 * 2
	local v_u_66 = v_u_65 / (v_u_62 * 2)
	local v67 = p55 / 880
	local v68 = p57 and p57.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
	local v69 = p57 and p57.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v70 = p57 and p57.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v71 = p57 and p57.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v72 = {
		["Name"] = "Sheet",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_14.paper,
		["Size"] = UDim2.fromOffset(p55, p55)
	}
	local v_u_73 = Instance.new("Frame")
	v_u_73.BorderSizePixel = 0
	local v_u_74 = 0
	local v_u_75 = 0
	for v76, v77 in v72 do
		v_u_73[v76] = v77
	end
	v_u_73.Parent = p54
	local v78 = v_u_14.paperEdge
	local v79 = Instance.new("UIStroke")
	v79.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v79.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v79.Color = v78
	v79.Thickness = 2
	v79.Transparency = 0
	v79.Parent = v_u_73
	local v80 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v_u_14.paperLight,
		["Position"] = UDim2.fromOffset(v64, v64),
		["Size"] = UDim2.fromOffset(v_u_65, v_u_65)
	}
	local v81 = Instance.new("Frame")
	v81.BorderSizePixel = 0
	for v82, v83 in v80 do
		v81[v82] = v83
	end
	v81.Parent = v_u_73
	local v84 = v_u_14.ink
	local v85 = Instance.new("UIStroke")
	v85.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v85.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v85.Color = v84
	v85.Thickness = 1
	v85.Transparency = 0
	v85.Parent = v81
	local function v_u_100(p86, p87, p88, p89, p90, p91) -- name: seg
		-- upvalues: (ref) v_u_74
		local v92 = p88 - p87
		v_u_74 = v_u_74 + 1
		local v93 = {
			["Name"] = "Seg",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = p90,
			["BackgroundTransparency"] = p91 or 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset((p87.X + p88.X) / 2, (p87.Y + p88.Y) / 2),
			["Size"] = UDim2.fromOffset(v92.Magnitude + p89 * 0.5, p89)
		}
		local v94 = v92.Y
		local v95 = v92.X
		local v96 = math.atan2(v94, v95)
		v93.Rotation = math.deg(v96)
		local v97 = Instance.new("Frame")
		v97.BorderSizePixel = 0
		for v98, v99 in v93 do
			v97[v98] = v99
		end
		v97.Parent = p86
		return v97
	end
	local v101 = {
		["Name"] = "Ground",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v102 = Instance.new("Frame")
	v102.BorderSizePixel = 0
	local function v130(p103, p104, p105, p106, p107, p108, p109) -- name: rect
		-- upvalues: (copy) v_u_62, (copy) v_u_66, (ref) v_u_74
		local v110 = math.min(p104, p106)
		local v111 = math.min(p105, p107)
		local v112 = Vector2.new((v110 + v_u_62) * v_u_66, (v111 + v_u_62) * v_u_66)
		local v113 = math.max(p104, p106)
		local v114 = math.max(p105, p107)
		local v115 = Vector2.new((v113 + v_u_62) * v_u_66, (v114 + v_u_62) * v_u_66)
		v_u_74 = v_u_74 + 1
		local v116 = {
			["BackgroundColor3"] = p108,
			["BackgroundTransparency"] = p109 or 0
		}
		local v117 = UDim2.fromOffset
		local v118 = v112.X
		local v119 = math.floor(v118)
		local v120 = v112.Y
		v116.Position = v117(v119, (math.floor(v120)))
		local v121 = UDim2.fromOffset
		local v122 = v115.X - v112.X
		local v123 = math.ceil(v122)
		local v124 = math.max(1, v123)
		local v125 = v115.Y - v112.Y
		local v126 = math.ceil(v125)
		v116.Size = v121(v124, (math.max(1, v126)))
		local v127 = Instance.new("Frame")
		v127.BorderSizePixel = 0
		for v128, v129 in v116 do
			v127[v128] = v129
		end
		v127.Parent = p103
		return v127
	end
	local function v145(p131, p132, p133, p134, p135, p136, p137, p138) -- name: dashed
		-- upvalues: (copy) v_u_100
		local v139 = p133 - p132
		local v140 = v139.Magnitude
		if v140 >= 1 then
			local v141 = v139 / v140
			local v142 = 0
			while v142 < v140 do
				local v143 = v142 + p134
				local v144 = math.min(v140, v143)
				if v144 - v142 > 1 then
					v_u_100(p131, p132 + v141 * v142, p132 + v141 * v144, p136, p137, p138)
				end
				v142 = v144 + p135
			end
		end
	end
	local function v168(p146, p147, p148, p149, p150, p151, p152, p153) -- name: box
		-- upvalues: (copy) v_u_62, (copy) v_u_66, (ref) v_u_74
		local v154 = Vector2.new((p147 + v_u_62) * v_u_66, (p148 + v_u_62) * v_u_66)
		local v155 = p151 % 180
		local v156 = -p151
		local v157 = v155 - 90
		if math.abs(v157) < 1 then
			local v158 = p150
			p150 = p149
			p149 = v158
			v156 = 0
		elseif v155 < 1 or v155 > 179 then
			v156 = 0
		end
		local v159 = p153 or 2
		v_u_74 = v_u_74 + 1
		local v160 = {
			["BackgroundColor3"] = p152,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v154.X, v154.Y)
		}
		local v161 = UDim2.fromOffset
		local v162 = p149 * v_u_66
		local v163 = math.max(v159, v162)
		local v164 = p150 * v_u_66
		v160.Size = v161(v163, (math.max(v159, v164)))
		v160.Rotation = v156
		local v165 = Instance.new("Frame")
		v165.BorderSizePixel = 0
		for v166, v167 in v160 do
			v165[v166] = v167
		end
		v165.Parent = p146
		return v165
	end
	local function v171(p169, p170) -- name: toPx
		-- upvalues: (copy) v_u_62, (copy) v_u_66
		return Vector2.new((p169 + v_u_62) * v_u_66, (p170 + v_u_62) * v_u_66)
	end
	for v172, v173 in v101 do
		v102[v172] = v173
	end
	v102.Parent = v81
	local v174 = v_u_9.FIELD
	v130(v102, v174[1], v174[2], v174[3], v174[4], v_u_14.field, 0.55).Name = "Field"
	for _, v175 in v_u_9.WOODS do
		v130(v102, v175[1], v175[2], v175[3], v175[4], v_u_14.forest, 0.1).Name = "Forest"
	end
	local v176 = v_u_62 * 2 / 250 + 0.5
	local v177 = math.floor(v176)
	local v178
	for v179 = 1, v177 - 1 do
		local v180 = v179 / v177
		v178 = v_u_74 + 2
		local v181 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.grid,
			["Position"] = UDim2.new(v180, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v182 = Instance.new("Frame")
		v182.BorderSizePixel = 0
		v_u_74 = v178
		for v183, v184 in v181 do
			v182[v183] = v184
		end
		v182.Parent = v102
		local v185 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.grid,
			["Position"] = UDim2.new(0, 0, v180, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v186 = Instance.new("Frame")
		v186.BorderSizePixel = 0
		for v187, v188 in v185 do
			v186[v187] = v188
		end
		v186.Parent = v102
	end
	local v189 = v_u_9.ARMY_STEP
	local v190 = v_u_62 * 2 / v189 + 0.5
	local v191 = math.floor(v190)
	for v192 = 1, v191 - 1 do
		local v193 = v192 / v191
		v178 = v_u_74 + 2
		local v194 = {
			["Name"] = "ArmyGrid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.62,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.armyGrid,
			["Position"] = UDim2.new(v193, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v195 = Instance.new("Frame")
		v195.BorderSizePixel = 0
		v_u_74 = v178
		for v196, v197 in v194 do
			v195[v196] = v197
		end
		v195.Parent = v102
		local v198 = {
			["Name"] = "ArmyGrid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.62,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.armyGrid,
			["Position"] = UDim2.new(0, 0, v193, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v199 = Instance.new("Frame")
		v199.BorderSizePixel = 0
		for v200, v201 in v198 do
			v199[v200] = v201
		end
		v199.Parent = v102
	end
	local v202 = 0
	for _, v203 in v_u_9.TREES do
		local v204 = v203[1]
		local v205 = v203[2]
		local v206 = Vector2.new((v204 + v_u_62) * v_u_66, (v205 + v_u_62) * v_u_66)
		local v207 = v203[3] * v_u_66
		local v208 = math.max(3, v207)
		v178 = v_u_74 + 1
		v202 = v202 + 1
		local v209 = {
			["Name"] = "T",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.18,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.tree,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v206.X, v206.Y),
			["Size"] = UDim2.fromOffset(v208, v208)
		}
		local v210 = Instance.new("Frame")
		v210.BorderSizePixel = 0
		v_u_74 = v178
		for v211, v212 in v209 do
			v210[v211] = v212
		end
		v210.Parent = v102
		local v213 = UDim.new(0.5, 0)
		local v214 = Instance.new("UICorner")
		v214.CornerRadius = v213
		v214.Parent = v210
	end
	local v215 = v_u_9.CONTOUR_STEP
	local v216 = v67 * 9 + 0.5
	local v217 = math.floor(v216)
	local v218 = math.max(7, v217)
	local v219 = v67 * 5 + 0.5
	local v220 = math.floor(v219)
	local v221 = math.max(3, v220)
	local v222 = 0
	local v223 = 0
	for _, v224 in v_u_9.ROCKS do
		local v225 = v130(v102, v224[1], v224[2], v224[3], v224[4], v_u_14.rock, 0.05)
		local v226 = v224[6]
		v225.Name = "Rock_" .. tostring(v226)
		local v227 = v224[5] / 22
		local v228 = math.floor(v227)
		local v229 = math.max(1, v228)
		for v230 = 1, math.min(4, v229) do
			local v231 = v230 * v215
			if v224[3] - v224[1] <= v231 * 2 + 6 or v224[4] - v224[2] <= v231 * 2 + 6 then
				continue
			end
			local v232 = v130(v102, v224[1] + v231, v224[2] + v231, v224[3] - v231, v224[4] - v231, v_u_14.rock, 1)
			v232.Name = "Contour"
			local v233 = v_u_14.rockInk
			local v234 = Instance.new("UIStroke")
			v234.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v234.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v234.Color = v233
			v234.Thickness = 1
			v234.Transparency = 0.45
			v234.Parent = v232
			v222 = v222 + 1
		end
		local v235 = v224[1]
		local v236 = v224[2]
		local v237 = Vector2.new((v235 + v_u_62) * v_u_66, (v236 + v_u_62) * v_u_66)
		local v238 = v224[3]
		local v239 = v224[4]
		local v240 = Vector2.new((v238 + v_u_62) * v_u_66, (v239 + v_u_62) * v_u_66)
		for v241 = 1, 4 do
			local v242
			if v241 <= 2 then
				v242 = v240.X - v237.X
			else
				v242 = v240.Y - v237.Y
			end
			local v243 = v242 / v218
			local v244 = math.floor(v243)
			local v245 = math.min(70, v244)
			for v246 = 1, v245 do
				local v247 = (v246 - 0.5) / v245
				local v248, v249
				if v241 == 1 then
					v248 = Vector2.new(v237.X + v242 * v247, v237.Y)
					v249 = Vector2.new(v237.X + v242 * v247, v237.Y + v221)
				elseif v241 == 2 then
					v248 = Vector2.new(v237.X + v242 * v247, v240.Y)
					v249 = Vector2.new(v237.X + v242 * v247, v240.Y - v221)
				elseif v241 == 3 then
					v248 = Vector2.new(v237.X, v237.Y + v242 * v247)
					v249 = Vector2.new(v237.X + v221, v237.Y + v242 * v247)
				else
					v248 = Vector2.new(v240.X, v237.Y + v242 * v247)
					v249 = Vector2.new(v240.X - v221, v237.Y + v242 * v247)
				end
				if v248.X <= 1 or (v248.X >= v_u_65 - 1 or (v248.Y <= 1 or v248.Y >= v_u_65 - 1)) then
					continue
				end
				v_u_100(v102, v248, v249, 1, v_u_14.rockInk, 0.35)
				v223 = v223 + 1
			end
		end
	end
	local v250 = {
		["Name"] = "Pads",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v251 = Instance.new("Frame")
	v251.BorderSizePixel = 0
	for v252, v253 in v250 do
		v251[v252] = v253
	end
	v251.Parent = v81
	local v254 = table.clone(v_u_9.PADS)
	table.sort(v254, function(p255, p256)
		return (p255[3] - p255[1]) * (p255[4] - p255[2]) > (p256[3] - p256[1]) * (p256[4] - p256[2])
	end)
	local v257 = {
		["concrete"] = v_u_14.padConcrete,
		["asphalt"] = v_u_14.padAsphalt,
		["gravel"] = v_u_14.padGravel,
		["dirt"] = v_u_14.padDirt,
		["grass"] = v_u_14.park
	}
	for _, v258 in v254 do
		local v259 = v130(v251, v258[1], v258[2], v258[3], v258[4], v257[v258[5]] or v_u_14.lot, 0)
		local v260 = v258[6]
		v259.Name = "Pad_" .. tostring(v260)
	end
	local v261 = {
		["Name"] = "Tunnels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v262 = Instance.new("Frame")
	v262.BorderSizePixel = 0
	for v263, v264 in v261 do
		v262[v263] = v264
	end
	v262.Parent = v81
	local v265 = v_u_66 * 11
	local v266 = math.max(5, v265)
	local v267 = v_u_66 * 7
	local v268 = math.max(3, v267)
	for _, v269 in v_u_9.TUNNELS do
		local v270 = v269[4]
		local v271 = v269[3] * 0.7
		local v272 = math.max(8, v271) * v_u_66 + 0.5
		local v273 = math.floor(v272)
		local v274 = math.max(2, v273)
		for v275 = 1, #v270 - 1 do
			local v276 = v270[v275][1]
			local v277 = v270[v275][2]
			local v278 = Vector2.new((v276 + v_u_62) * v_u_66, (v277 + v_u_62) * v_u_66)
			local v279 = v270[v275 + 1][1]
			local v280 = v270[v275 + 1][2]
			v145(v262, v278, Vector2.new((v279 + v_u_62) * v_u_66, (v280 + v_u_62) * v_u_66), v266, v268, v274, v_u_14.tunnel, 0.1)
		end
	end
	local v281 = {
		["Name"] = "RoadCase",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v282 = Instance.new("Frame")
	v282.BorderSizePixel = 0
	for v283, v284 in v281 do
		v282[v283] = v284
	end
	v282.Parent = v81
	local v285 = {
		["Name"] = "RoadFill",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v286 = Instance.new("Frame")
	v286.BorderSizePixel = 0
	for v287, v288 in v285 do
		v286[v287] = v288
	end
	v286.Parent = v81
	local v289 = v67 * 1.6 + 0.5
	local v290 = math.floor(v289)
	local v291 = math.max(1, v290)
	for _, v292 in v_u_9.ROADS do
		local v293 = v292[1]
		local v294 = v292[2]
		local v295 = Vector2.new((v293 + v_u_62) * v_u_66, (v294 + v_u_62) * v_u_66)
		local v296 = v292[3]
		local v297 = v292[4]
		local v298 = Vector2.new((v296 + v_u_62) * v_u_66, (v297 + v_u_62) * v_u_66)
		local v299 = v292[6]
		if v299 == "track" then
			local v300 = (v295 + v298) / 2
			local v301
			if v292[7] == "z" then
				v301 = Vector2.new(v300.X, v295.Y)
			else
				v301 = Vector2.new(v295.X, v300.Y)
			end
			local v302
			if v292[7] == "z" then
				v302 = Vector2.new(v300.X, v298.Y)
			else
				v302 = Vector2.new(v298.X, v300.Y)
			end
			local v303 = v_u_66 * 6
			local v304 = math.max(3, v303)
			local v305 = v_u_66 * 4
			local v306 = math.max(2, v305)
			local v307 = v67 * 2 + 0.5
			local v308 = math.floor(v307)
			v145(v286, v301, v302, v304, v306, math.max(2, v308), v_u_14.roadCase, 0.1)
		else
			v178 = v_u_74 + 2
			local v309 = {
				["Name"] = "Case",
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_14.roadCase
			}
			local v310 = UDim2.fromOffset
			local v311 = v295.X
			local v312 = math.floor(v311) - v291
			local v313 = v295.Y
			v309.Position = v310(v312, math.floor(v313) - v291)
			local v314 = UDim2.fromOffset
			local v315 = v298.X - v295.X
			local v316 = math.ceil(v315) + v291 * 2
			local v317 = v298.Y - v295.Y
			v309.Size = v314(v316, math.ceil(v317) + v291 * 2)
			local v318 = Instance.new("Frame")
			v318.BorderSizePixel = 0
			v_u_74 = v178
			for v319, v320 in v309 do
				v318[v319] = v320
			end
			v318.Parent = v282
			v318:SetAttribute("Road", v292[5])
			if v299 == "street" then
				v318.BackgroundTransparency = 0.35
			end
			local v321 = {
				["Name"] = "Road",
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil
			}
			local v322
			if v299 == "main" then
				v322 = v_u_14.highway
			else
				v322 = v_u_14.road
			end
			v321.BackgroundColor3 = v322
			local v323 = UDim2.fromOffset
			local v324 = v295.X
			local v325 = math.floor(v324)
			local v326 = v295.Y
			v321.Position = v323(v325, (math.floor(v326)))
			local v327 = UDim2.fromOffset
			local v328 = v298.X - v295.X
			local v329 = math.ceil(v328)
			local v330 = math.max(1, v329)
			local v331 = v298.Y - v295.Y
			local v332 = math.ceil(v331)
			v321.Size = v327(v330, (math.max(1, v332)))
			local v333 = Instance.new("Frame")
			v333.BorderSizePixel = 0
			for v334, v335 in v321 do
				v333[v334] = v335
			end
			v333.Parent = v286
			v333:SetAttribute("Road", v292[5])
		end
	end
	local v336 = {
		["Name"] = "Buildings",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v337 = Instance.new("Frame")
	v337.BorderSizePixel = 0
	for v338, v339 in v336 do
		v337[v338] = v339
	end
	v337.Parent = v81
	local v340 = {
		["Name"] = "Props",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v341 = Instance.new("Frame")
	v341.BorderSizePixel = 0
	for v342, v343 in v340 do
		v341[v342] = v343
	end
	v341.Parent = v81
	local v344 = {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_345 = Instance.new("Frame")
	v_u_345.BorderSizePixel = 0
	for v346, v347 in v344 do
		v_u_345[v346] = v347
	end
	v_u_345.Parent = v81
	local v_u_348 = {}
	local v_u_349 = {}
	local v_u_350 = {}
	local v_u_351 = false
	local v_u_352 = {}
	local function v_u_359(p353, p354, p355, p356, p357) -- name: overlaps
		for _, v358 in p357 do
			if p353 >= v358[3] or (v358[1] >= p355 or (p354 >= v358[4] or v358[2] >= p356)) then
				continue
			end
			return true
		end
		return false
	end
	local function v_u_365(p360, p361, p362, p363, p364) -- name: free
		-- upvalues: (copy) v_u_65, (copy) v_u_359, (copy) v_u_348, (copy) v_u_352
		if p360 < 3 or (p361 < 3 or (v_u_65 - 3 < p362 or v_u_65 - 3 < p363)) then
			return false
		end
		if v_u_359(p360, p361, p362, p363, v_u_348) then
			return false
		end
		if p364 then
			p364 = v_u_359(p360, p361, p362, p363, v_u_352)
		end
		return not p364
	end
	local function v395(p366, p367, p368, p369, p370, p371, p372, p373) -- name: label
		-- upvalues: (ref) v_u_2, (copy) p_u_58, (copy) v_u_365, (copy) v_u_348, (copy) v_u_349, (ref) v_u_75, (ref) v_u_74, (copy) v_u_345, (copy) v_u_60, (ref) v_u_351, (copy) v_u_350
		local v374 = v_u_2.phoneText
		local v375 = "caption"
		local v376
		if p_u_58 then
			v376 = p_u_58.scale
		else
			v376 = nil
		end
		local v377
		if p_u_58 then
			v377 = p_u_58.phone
		else
			v377 = nil
		end
		local v378 = v374(p368, v375, v376, v377)
		local v379 = (utf8.len(p366) or #p366) * v378 * 0.56 + 6
		local v380 = v378 + 2
		local v381
		if p371 then
			v381 = p371.Rotation
		else
			v381 = p371
		end
		if v381 then
			if math.abs(v381) ~= 90 then
				local v382 = v379
				v379 = v380
				v380 = v382
			end
		else
			local v383 = v379
			v379 = v380
			v380 = v383
		end
		if not (p372 or v_u_365(p367.X - v380 / 2, p367.Y - v379 / 2, p367.X + v380 / 2, p367.Y + v379 / 2, p373)) then
			return nil
		end
		local v384 = {
			p367.X - v380 / 2,
			p367.Y - v379 / 2,
			p367.X + v380 / 2,
			p367.Y + v379 / 2
		}
		local v385 = v_u_348
		table.insert(v385, v384)
		v_u_349[v384] = true
		v_u_75 = v_u_75 + 1
		v_u_74 = v_u_74 + 1
		local v386 = v_u_345
		local v387 = v_u_60
		local v388 = v_u_2.phoneText
		local v389 = "caption"
		local v390
		if p_u_58 then
			v390 = p_u_58.scale
		else
			v390 = nil
		end
		local v391
		if p_u_58 then
			v391 = p_u_58.phone
		else
			v391 = nil
		end
		local v392 = v387(v386, p366, p367, v388(v378, v389, v390, v391), p369, p370, p371)
		if v_u_351 then
			local v393 = v_u_350
			local v394 = {
				["id"] = "",
				["kind"] = "name",
				["rect"] = nil,
				["obj"] = nil,
				["rect"] = v_u_348[#v_u_348],
				["obj"] = v392
			}
			table.insert(v393, v394)
		end
		return v392
	end
	local v396 = {}
	if p56 then
		local v397 = p56.buildings
		if type(v397) == "table" and #p56.buildings >= 8 then
			for _, v398 in p56.buildings do
				local v399 = v398.cf
				if typeof(v399) ~= "CFrame" then
					continue
				end
				local v400 = v398.size
				if typeof(v400) ~= "Vector3" then
					continue
				end
				local _, v401, _ = v398.cf:ToOrientation()
				local v402 = {
					["kind"] = v398.kind
				}
				local v403 = string.lower
				local v404 = v398.id
				v402.id = v403((tostring(v404)))
				v402.x = v398.cf.X
				v402.z = v398.cf.Z
				v402.w = v398.size.X
				v402.d = v398.size.Z
				v402.yaw = math.deg(v401)
				v402.name = v398.name
				table.insert(v396, v402)
			end
		end
	end
	if #v396 == 0 then
		for _, v405 in v_u_9.LOTS do
			local v406 = {
				["kind"] = nil,
				["id"] = nil,
				["x"] = nil,
				["z"] = nil,
				["w"] = nil,
				["d"] = nil,
				["yaw"] = 0,
				["name"] = nil,
				["kind"] = v405[2],
				["id"] = v405[1],
				["x"] = v405[4],
				["z"] = v405[5],
				["w"] = v405[6],
				["d"] = v405[7],
				["name"] = v405[9]
			}
			table.insert(v396, v406)
		end
	end
	local v407 = {}
	local v_u_408 = {}
	for _, v409 in v396 do
		local v410 = v_u_9.LANDMARKS[v409.id]
		local v411 = v_u_9.LANDMARK_KINDS[v409.kind]
		local v412
		if v410 == nil then
			if v411 == nil then
				v412 = false
			else
				v412 = v_u_9.NAMES[v409.id] == nil
			end
		else
			v412 = true
		end
		local v413 = v409.x
		local v414 = v409.z
		local v415 = v409.w
		local v416 = v409.d
		local v417 = v409.yaw
		local v418
		if v412 then
			v418 = v_u_14.landmark
		else
			v418 = v_u_14.build
		end
		local v419 = v168(v337, v413, v414, v415, v416, v417, v418)
		local v420 = v409.id
		v419.Name = "B_" .. tostring(v420)
		local v421
		if v412 then
			v421 = v_u_14.landmarkEdge
		else
			v421 = v_u_14.buildEdge
		end
		local v422 = Instance.new("UIStroke")
		v422.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v422.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v422.Color = v421
		v422.Thickness = 1
		v422.Transparency = 0.1
		v422.Parent = v419
		local v423 = v409.id
		local v424 = {}
		local v425 = v409.x
		local v426 = v409.z
		local v427 = v410 or v_u_9.NAMES[v409.id]
		if not v427 then
			if v411 then
				v427 = v411
			else
				local v428 = v409.name or v409.id
				v427 = tostring(v428)
			end
		end
		__set_list(v424, 1, {v425, v426, v427})
		v_u_408[v423] = v424
		local v429 = v409.x
		local v430 = v409.z
		local v431 = Vector2.new((v429 + v_u_62) * v_u_66, (v430 + v_u_62) * v_u_66)
		local v432 = v409.yaw % 180
		local v433 = v409.w
		local v434 = v409.d
		local v435 = v432 - 90
		if math.abs(v435) >= 45 then
			local v436 = v433
			v433 = v434
			v434 = v436
		end
		local v437 = {
			v431.X - v434 * v_u_66 / 2 - 1,
			v431.Y - v433 * v_u_66 / 2 - 1,
			v431.X + v434 * v_u_66 / 2 + 1,
			v431.Y + v433 * v_u_66 / 2 + 1
		}
		table.insert(v_u_352, v437)
		if not v412 then
			continue
		end
		local v438 = {
			["text"] = v410 or v411,
			["b"] = v409,
			["px"] = v431,
			["wpx"] = v434 * v_u_66,
			["hpx"] = v433 * v_u_66
		}
		table.insert(v407, v438)
	end
	local v439 = v_u_9.TRAM_LINE
	local v440 = v67 * 1.6 + 0.5
	local v441 = math.floor(v440)
	local v442 = math.max(1, v441)
	for v443 = 1, #v439 - 1 do
		local v444 = v439[v443][1]
		local v445 = v439[v443][2]
		local v446 = Vector2.new((v444 + v_u_62) * v_u_66, (v445 + v_u_62) * v_u_66)
		local v447 = v439[v443 + 1][1]
		local v448 = v439[v443 + 1][2]
		local v449 = Vector2.new((v447 + v_u_62) * v_u_66, (v448 + v_u_62) * v_u_66)
		local v450 = v_u_66 * 14
		local v451 = math.max(6, v450)
		local v452 = v_u_66 * 7
		v145(v341, v446, v449, v451, math.max(3, v452), v442, v_u_14.ink, 0.05)
	end
	local v453 = v67 * 4 + 0.5
	local v454 = math.floor(v453)
	local v455 = math.max(3, v454)
	for _, v456 in v_u_9.TRAM_MASTS do
		local v457 = v456[1]
		local v458 = v456[2]
		local v459 = Vector2.new((v457 + v_u_62) * v_u_66, (v458 + v_u_62) * v_u_66)
		v178 = v_u_74 + 1
		local v460 = {
			["Name"] = "Mast",
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = v_u_14.paperLight,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v459.X, v459.Y),
			["Size"] = UDim2.fromOffset(v455, v455)
		}
		local v461 = Instance.new("Frame")
		v461.BorderSizePixel = 0
		v_u_74 = v178
		for v462, v463 in v460 do
			v461[v462] = v463
		end
		v461.Parent = v341
		local v464 = v_u_14.ink
		local v465 = Instance.new("UIStroke")
		v465.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v465.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v465.Color = v464
		v465.Thickness = 1.2
		v465.Transparency = 0
		v465.Parent = v461
	end
	local v466 = v67 * 7 + 0.5
	local v467 = math.floor(v466)
	local v468 = math.max(5, v467)
	for _, v469 in v_u_9.TRAM_STATIONS do
		local v470 = v469[3]
		local v471 = v469[4]
		local v472 = Vector2.new((v470 + v_u_62) * v_u_66, (v471 + v_u_62) * v_u_66)
		v178 = v_u_74 + 1
		local v473 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45
		}
		local v474 = v469[1]
		v473.Name = "TramStation_" .. tostring(v474)
		v473.BackgroundColor3 = v_u_14.red
		v473.AnchorPoint = Vector2.new(0.5, 0.5)
		v473.Position = UDim2.fromOffset(v472.X, v472.Y)
		v473.Size = UDim2.fromOffset(v468, v468)
		local v475 = Instance.new("Frame")
		v475.BorderSizePixel = 0
		v_u_74 = v178
		for v476, v477 in v473 do
			v475[v476] = v477
		end
		v475.Parent = v341
		local v478 = v_u_14.redDeep
		local v479 = Instance.new("UIStroke")
		v479.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v479.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v479.Color = v478
		v479.Thickness = 1.2
		v479.Transparency = 0
		v479.Parent = v475
	end
	local v480 = v67 * 13 + 0.5
	local v481 = math.floor(v480)
	local v482 = math.max(10, v481)
	local v483 = v_u_2.phoneText
	local v484 = "text"
	local v485
	if p_u_58 then
		v485 = p_u_58.scale
	else
		v485 = nil
	end
	local v486
	if p_u_58 then
		v486 = p_u_58.phone
	else
		v486 = nil
	end
	local v487 = v483(v482, v484, v485, v486)
	table.sort(v407, function(p488, p489)
		return p488.b.w * p488.b.d > p489.b.w * p489.b.d
	end)
	for v490, v491 in v407 do
		local v492 = string.upper(v491.text)
		local v493 = (utf8.len(v492) or #v492) * v487 * 0.56 + 6
		local v494 = v487 + 2
		local v495 = v491.px
		local v496 = false
		for _, v497 in {
			Vector2.new(v495.X, v495.Y + v491.hpx / 2 + v494 / 2 + 3),
			Vector2.new(v495.X, v495.Y - v491.hpx / 2 - v494 / 2 - 3),
			Vector2.new(v495.X + v491.wpx / 2 + v493 / 2 + 3, v495.Y),
			Vector2.new(v495.X - v491.wpx / 2 - v493 / 2 - 3, v495.Y)
		} do
			if not v395(v492, v497, v487, v69, v_u_14.redDeep) then
				continue
			end
			v496 = true
		end
		if v496 or v490 > 14 then
			break
		end
		v395(v492, v495, v487, v69, v_u_14.redDeep, nil, true)
	end
	local v498 = #v_u_348
	local v499 = v67 * 13 + 0.5
	local v500 = math.floor(v499)
	local v501 = math.max(10, v500)
	local v502 = v_u_2.phoneText
	local v503 = "caption"
	local v504
	if p_u_58 then
		v504 = p_u_58.scale
	else
		v504 = nil
	end
	local v505
	if p_u_58 then
		v505 = p_u_58.phone
	else
		v505 = nil
	end
	local v506 = v502(v501, v503, v504, v505)
	local v507
	if v_u_4 == nil then
		v507 = false
	else
		v507 = v_u_4.clean()
	end
	v_u_351 = v507
	local v508 = {}
	for _, v509 in {
		0.5,
		0.15,
		0.85,
		0.3,
		0.7,
		0.05,
		0.95
	} do
		for _, v510 in {
			0.5,
			0.25,
			0.75,
			0.1,
			0.9
		} do
			table.insert(v508, { v510, v509 })
		end
	end
	local v511 = {}
	local v512 = {}
	for _, v513 in v407 do
		v511[string.upper(v513.text)] = true
	end
	for _, v514 in v_u_9.AREAS do
		local v515 = v514[5]
		local v516 = v_u_41(v514[2])
		local v517 = v511[string.upper(v514[2])] == true
		for _, v518 in v508 do
			local v519 = v515[1] + (v515[3] - v515[1]) * v518[1]
			local v520 = v515[2] + (v515[4] - v515[2]) * v518[2]
			if not v395(v516, Vector2.new((v519 + v_u_62) * v_u_66, (v520 + v_u_62) * v_u_66), v506, v68, v_u_14.inkSoft, {
				["TextStrokeTransparency"] = 0.45
			}, false, true) then
				continue
			end
			v517 = true
		end
		if v517 then
			break
		end
		table.insert(v512, v514)
	end
	for _, v521 in v512 do
		local v522 = v521[5]
		local v523 = v_u_41(v521[2])
		for _, v524 in v508 do
			local v525 = v522[1] + (v522[3] - v522[1]) * v524[1]
			local v526 = v522[2] + (v522[4] - v522[2]) * v524[2]
			if not v395(v523, Vector2.new((v525 + v_u_62) * v_u_66, (v526 + v_u_62) * v_u_66), v506, v68, v_u_14.inkSoft, {
				["TextStrokeTransparency"] = 0.45
			}, false, false) then
				continue
			end
			break
			break
		end
	end
	local v527 = v67 * 11 + 0.5
	local v528 = math.floor(v527)
	local v529 = math.max(9, v528)
	local v530 = v_u_2.phoneText
	local v531 = "caption"
	local v532
	if p_u_58 then
		v532 = p_u_58.scale
	else
		v532 = nil
	end
	local v533
	if p_u_58 then
		v533 = p_u_58.phone
	else
		v533 = nil
	end
	local v534 = v530(v529, v531, v532, v533)
	local v535 = {}
	for _, v536 in v_u_9.ROADS do
		local v537 = v536[5]
		local v538 = v536[3] - v536[1] > v536[4] - v536[2]
		local v539
		if v538 then
			v539 = v536[3] - v536[1]
		else
			v539 = v536[4] - v536[2]
		end
		local v540 = v535[v537] or 0
		local v541 = v537 == "The Serpentine" and 2 or 1
		if v537 == "" or (v540 >= v541 or v536[6] == "track") or v539 * v_u_66 <= (utf8.len(v537) or #v537) * v534 * 0.5 then
			continue
		end
		for _, v542 in {
			0.5,
			0.3,
			0.7,
			0.15,
			0.85
		} do
			local v543
			if v538 then
				v543 = v536[1] + (v536[3] - v536[1]) * v542
			else
				v543 = (v536[1] + v536[3]) / 2
			end
			local v544
			if v538 then
				v544 = (v536[2] + v536[4]) / 2
			else
				v544 = v536[2] + (v536[4] - v536[2]) * v542
			end
			if not v395(string.upper(v537), Vector2.new((v543 + v_u_62) * v_u_66, (v544 + v_u_62) * v_u_66), v534, v71, v_u_14.inkSoft, {
				["Rotation"] = nil,
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.1,
				["Rotation"] = v538 and 0 or 90,
				["TextStrokeColor3"] = v_u_14.road
			}) then
				continue
			end
			v535[v537] = v540 + 1
		end
	end
	local v545 = 10 * v67 + 0.5
	local v546 = math.floor(v545)
	local v547 = math.max(9, v546)
	local v548 = v_u_2.phoneText
	local v549 = "caption"
	local v550
	if p_u_58 then
		v550 = p_u_58.scale
	else
		v550 = nil
	end
	local v551
	if p_u_58 then
		v551 = p_u_58.phone
	else
		v551 = nil
	end
	local v552 = v548(v547, v549, v550, v551)
	for _, v553 in v_u_9.TUNNELS do
		local v554 = v553[4]
		local v555 = v554[1]
		local v556 = v554[#v554]
		local v557 = v556[1] - v555[1]
		local v558 = math.abs(v557)
		local v559 = v556[2] - v555[2]
		local v560 = math.abs(v559) < v558
		for _, v561 in {
			0.5,
			0.35,
			0.65,
			0.2,
			0.8
		} do
			local v562 = v555[1] + (v556[1] - v555[1]) * v561
			local v563 = v555[2] + (v556[2] - v555[2]) * v561
			local v564
			if v560 then
				v564 = v562
			else
				v564 = v562 + 12
			end
			local v565
			if v560 then
				v565 = v563 + 12
			else
				v565 = v563
			end
			local v566 = Vector2.new((v564 + v_u_62) * v_u_66, (v565 + v_u_62) * v_u_66)
			local v567 = {
				["Rotation"] = nil,
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.2,
				["Rotation"] = v560 and 0 or 90,
				["TextStrokeColor3"] = v_u_14.paper
			}
			if v395(string.upper(v553[2]) .. " (UNDERGROUND)", v566, v552, v71, v_u_14.tunnel, v567) or v395(string.upper(v553[2]), v566, v552, v71, v_u_14.tunnel, v567) then
				break
			end
			if not v560 then
				v562 = v562 - 12
			end
			if v560 then
				v563 = v563 - 12
			end
			local v568 = Vector2.new((v562 + v_u_62) * v_u_66, (v563 + v_u_62) * v_u_66)
			if not v395(string.upper(v553[2]), v568, v552, v71, v_u_14.tunnel, v567) then
				continue
			end
			break
			break
		end
	end
	local v569 = v_u_9.TRAM_LINE
	local v570 = v569[#v569 - 4] or v569[1]
	local v571 = v569[#v569 - 3] or v569[2]
	local v572 = (v570[1] + v571[1]) / 2 + 14
	local v573 = (v570[2] + v571[2]) / 2
	v395("ROPEWAY", Vector2.new((v572 + v_u_62) * v_u_66, (v573 + v_u_62) * v_u_66), v552, v71, v_u_14.ink, {
		["Rotation"] = 90,
		["TextStrokeColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["TextStrokeColor3"] = v_u_14.paper
	})
	for _, v574 in { 0.3333333333333333, 0.6666666666666666 } do
		local v575 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_14.paperLight,
			["Position"] = UDim2.new(v574, 0, 0, 0),
			["Size"] = UDim2.new(0, 2, 1, 0)
		}
		local v576 = Instance.new("Frame")
		v576.BorderSizePixel = 0
		for v577, v578 in v575 do
			v576[v577] = v578
		end
		v576.Parent = v_u_73
		local v579 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_14.crease,
			["Position"] = UDim2.new(v574, 2, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v580 = Instance.new("Frame")
		v580.BorderSizePixel = 0
		for v581, v582 in v579 do
			v580[v581] = v582
		end
		v580.Parent = v_u_73
	end
	local v583 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_14.paperLight,
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v584 = Instance.new("Frame")
	v584.BorderSizePixel = 0
	for v585, v586 in v583 do
		v584[v585] = v586
	end
	v584.Parent = v_u_73
	local v587 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_14.crease,
		["Position"] = UDim2.new(0, 0, 0.5, 2),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v588 = Instance.new("Frame")
	v588.BorderSizePixel = 0
	for v589, v590 in v587 do
		v588[v589] = v590
	end
	v588.Parent = v_u_73
	local v591 = 12 * v67 + 0.5
	local v592 = math.floor(v591)
	local v593 = math.max(9, v592)
	local v594 = v_u_2.phoneText
	local v595 = v593
	local v596 = "caption"
	local v597
	if p_u_58 then
		v597 = p_u_58.scale
	else
		v597 = nil
	end
	local v598
	if p_u_58 then
		v598 = p_u_58.phone
	else
		v598 = nil
	end
	local v599 = v594(v595, v596, v597, v598)
	for v600 = 1, v177 do
		local v601 = v64 + v_u_65 * (v600 - 0.5) / v177
		for _, v602 in { v64 / 2, p55 - v64 / 2 } do
			local v603 = v_u_42[v600] or "?"
			local v604 = Vector2.new(v601, v602)
			local v605 = v_u_14.inkSoft
			local v606 = v_u_2.phoneText
			local v607 = "caption"
			local v608
			if p_u_58 then
				v608 = p_u_58.scale
			else
				v608 = nil
			end
			local v609
			if p_u_58 then
				v609 = p_u_58.phone
			else
				v609 = nil
			end
			local v610 = v_u_60(v_u_73, v603, v604, v606(v599, v607, v608, v609), v68, v605, nil)
			v610.ZIndex = 21
			v610.TextStrokeTransparency = 1
		end
		for _, v611 in { v64 / 2, p55 - v64 / 2 } do
			local v612 = tostring(v600)
			local v613 = Vector2.new(v611, v601)
			local v614 = v_u_14.inkSoft
			local v615 = v_u_2.phoneText
			local v616 = "caption"
			local v617
			if p_u_58 then
				v617 = p_u_58.scale
			else
				v617 = nil
			end
			local v618
			if p_u_58 then
				v618 = p_u_58.phone
			else
				v618 = nil
			end
			local v619 = v_u_60(v_u_73, v612, v613, v615(v599, v616, v617, v618), v68, v614, nil)
			v619.ZIndex = 21
			v619.TextStrokeTransparency = 1
		end
	end
	local v620 = 196 * v67
	local v621 = math.floor(v620)
	local v622 = 52 * v67
	local v623 = math.floor(v622)
	local v_u_624
	if p_u_58 and p_u_58.revealed ~= nil then
		v_u_624 = p_u_58.revealed == true
	elseif v_u_6 then
		local v625 = v_u_6.clientRevealed
		if type(v625) == "function" then
			local v626 = v_u_6.clientRevealed
			local v627, v628 = pcall(v626)
			v_u_624 = v627
			if v_u_624 then
				v_u_624 = v628 == true
			end
		else
			v_u_624 = false
		end
	else
		v_u_624 = false
	end
	local v_u_629 = v_u_41(v_u_624 and "Ashgrove" or "Unnamed")
	local v630 = 19 * v67
	local v631 = math.floor(v630)
	local v632 = math.max(13, v631)
	local v633 = v_u_2.phoneText
	local v634 = v632
	local v635 = "text"
	local v636
	if p_u_58 then
		v636 = p_u_58.scale
	else
		v636 = nil
	end
	local v637
	if p_u_58 then
		v637 = p_u_58.phone
	else
		v637 = nil
	end
	local v_u_638 = v633(v634, v635, v636, v637)
	if v61 then
		local function v639()
			-- upvalues: (ref) v_u_1, (ref) v_u_629, (copy) v_u_638
			return v_u_1:GetTextSize(v_u_629, v_u_638, Enum.Font.GothamBold, Vector2.new(1000, 100))
		end
		local v640, v641 = pcall(v639)
		local v642
		if v640 then
			v642 = v641.X
		else
			v642 = #v_u_629 * v_u_638 * 0.7
		end
		local v643 = v642 + 14
		local v644 = math.ceil(v643)
		v621 = math.max(v621, v644)
		local v645 = 34 * v67
		local v646 = math.floor(v645)
		local v647 = v_u_638 + 10
		v623 = math.max(v646, v647)
	end
	local v648 = {
		["Name"] = "Cartouche",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_14.paperLight
	}
	local v649 = UDim2.fromOffset
	local v650 = 10 * v67
	local v651 = math.floor(v650)
	local v652 = 10 * v67
	v648.Position = v649(v651, (math.floor(v652)))
	v648.Size = UDim2.fromOffset(v621, v623)
	local v653 = Instance.new("Frame")
	v653.BorderSizePixel = 0
	for v654, v655 in v648 do
		v653[v654] = v655
	end
	v653.Parent = v81
	local v656 = v_u_14.ink
	local v657 = Instance.new("UIStroke")
	v657.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v657.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v657.Color = v656
	v657.Thickness = 1
	v657.Transparency = 0
	v657.Parent = v653
	local v658 = Vector2.new
	local v659
	if v61 then
		v659 = v621 / 2
	else
		v659 = 98 * v67
	end
	local v660
	if v61 then
		v660 = v623 / 2
	else
		v660 = 19 * v67
	end
	local v661 = v658(v659, v660)
	local v662 = v_u_14.ink
	local v663 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil
	}
	local v664 = UDim2.fromOffset
	local v665
	if v61 then
		v665 = v621 - 4
	else
		v665 = 190 * v67
	end
	local v666
	if v61 then
		v666 = v623 - 4
	else
		v666 = 24 * v67
	end
	v663.Size = v664(v665, v666)
	local v667 = v661
	local v668 = v_u_2.phoneText
	local v669 = "caption"
	local v670
	if p_u_58 then
		v670 = p_u_58.scale
	else
		v670 = nil
	end
	local v671
	if p_u_58 then
		v671 = p_u_58.phone
	else
		v671 = nil
	end
	local v_u_672 = v_u_60(v653, v_u_629, v667, v668(v_u_638, v669, v670, v671), v69, v662, v663)
	v_u_672.ZIndex = 11
	if not v61 then
		local v673 = Vector2.new(98 * v67, 39 * v67)
		local v674 = v67 * 11
		local v675 = math.floor(v674)
		local v676 = math.max(9, v675)
		local v677 = v_u_14.inkSoft
		local v678 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(190 * v67, v67 * 14)
		}
		local v679 = "Mining district map"
		local v680 = v673
		local v681 = v_u_2.phoneText
		local v682 = "caption"
		local v683
		if p_u_58 then
			v683 = p_u_58.scale
		else
			v683 = nil
		end
		local v684
		if p_u_58 then
			v684 = p_u_58.phone
		else
			v684 = nil
		end
		v_u_60(v653, v679, v680, v681(v676, v682, v683, v684), v70, v677, v678).ZIndex = 11
	end
	local v685
	if v_u_4 == nil then
		v685 = false
	else
		v685 = v_u_4.clean()
	end
	local v686 = {}
	local v687 = 15 * v67
	local v688 = math.floor(v687)
	local v689 = math.max(11, v688)
	local v690 = v_u_65 - 34 * v67
	local v691 = 40 * v67
	if v685 then
		local v692 = 17 * v67 + v689 + 4
		v691 = math.max(v691, v692)
		local v693 = {
			v690 - 17 * v67 - 2,
			v691 - 17 * v67 - v689 - 4,
			v690 + 17 * v67 + 2,
			v691 + 17 * v67 + 2
		}
		table.insert(v686, v693)
		local v694 = {}
		local v695 = 10 * v67
		local v696 = math.floor(v695)
		local v697 = 10 * v67
		local v698 = math.floor(v697)
		local v699 = 10 * v67
		local v700 = math.floor(v699) + v621
		local v701 = 10 * v67
		__set_list(v694, 1, {v696, v698, v700, math.floor(v701) + v623})
		table.insert(v686, v694)
	end
	local v702 = Vector2.new
	local v703
	if v685 then
		v703 = 17 * v67 + v689 * 0.5 + 3
	else
		v703 = v67 * 22
	end
	local v704 = v702(v690, v691 - v703)
	local v705 = v_u_14.ink
	local v706 = {
		["TextStrokeTransparency"] = 1
	}
	local v707 = "N"
	local v708 = v_u_2.phoneText
	local v709 = "caption"
	local v710
	if p_u_58 then
		v710 = p_u_58.scale
	else
		v710 = nil
	end
	local v711
	if p_u_58 then
		v711 = p_u_58.phone
	else
		v711 = nil
	end
	v_u_60(v81, v707, v704, v708(v689, v709, v710, v711), v69, v705, v706).ZIndex = 10
	local v712 = {
		["Name"] = "Needle",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_14.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v690, v691),
		["Size"] = UDim2.fromOffset(2, 28 * v67)
	}
	local v713 = Instance.new("Frame")
	v713.BorderSizePixel = 0
	for v714, v715 in v712 do
		v713[v714] = v715
	end
	v713.Parent = v81
	local v716 = {
		["Name"] = "NeedleTip",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_14.red,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v690, v691 - v67 * 9),
		["Size"] = UDim2.fromOffset(v67 * 7, v67 * 7)
	}
	local v717 = Instance.new("Frame")
	v717.BorderSizePixel = 0
	for v718, v719 in v716 do
		v717[v718] = v719
	end
	v717.Parent = v81
	local v720 = {
		["Name"] = "Cross",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_14.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v690, v691),
		["Size"] = UDim2.fromOffset(16 * v67, 1)
	}
	local v721 = Instance.new("Frame")
	v721.BorderSizePixel = 0
	for v722, v723 in v720 do
		v721[v722] = v723
	end
	v721.Parent = v81
	local v724 = {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v690, v691),
		["Size"] = UDim2.fromOffset(34 * v67, 34 * v67)
	}
	local v725 = Instance.new("Frame")
	v725.BorderSizePixel = 0
	for v726, v727 in v724 do
		v725[v726] = v727
	end
	v725.Parent = v81
	local v728 = UDim.new(0.5, 0)
	local v729 = Instance.new("UICorner")
	v729.CornerRadius = v728
	v729.Parent = v725
	local v730 = v_u_14.ink
	local v731 = Instance.new("UIStroke")
	v731.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v731.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v731.Color = v730
	v731.Thickness = 1
	v731.Transparency = 0.3
	v731.Parent = v725
	local v732 = 100 / v_u_9.STUDS_TO_M * v_u_66
	local v733 = v67 * 14
	local v734 = v_u_65 - 26 * v67
	for v735 = 0, 3 do
		local v736 = {
			["Name"] = "Scale",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 10
		}
		local v737
		if v735 % 2 == 0 then
			v737 = v_u_14.ink
		else
			v737 = v_u_14.paperLight
		end
		v736.BackgroundColor3 = v737
		v736.Position = UDim2.fromOffset(v733 + v735 * v732 / 4, v734)
		local v738 = UDim2.fromOffset
		local v739 = v732 / 4
		local v740 = v67 * 5
		v736.Size = v738(v739, (math.max(3, v740)))
		local v741 = Instance.new("Frame")
		v741.BorderSizePixel = 0
		for v742, v743 in v736 do
			v741[v742] = v743
		end
		v741.Parent = v81
		local v744 = v_u_14.ink
		local v745 = Instance.new("UIStroke")
		v745.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v745.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v745.Color = v744
		v745.Thickness = 1
		v745.Transparency = 0
		v745.Parent = v741
	end
	local v746
	if v685 then
		v746 = v67 * 9 + 3
	else
		v746 = v67 * 9
	end
	local v747 = Vector2.new(v733, v734 - v746)
	local v748 = v67 * 11
	local v749 = math.floor(v748)
	local v750 = math.max(9, v749)
	local v751 = v_u_14.ink
	local v752 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v753 = "0"
	local v754 = v_u_2.phoneText
	local v755 = "caption"
	local v756
	if p_u_58 then
		v756 = p_u_58.scale
	else
		v756 = nil
	end
	local v757
	if p_u_58 then
		v757 = p_u_58.phone
	else
		v757 = nil
	end
	v_u_60(v81, v753, v747, v754(v750, v755, v756, v757), v71, v751, v752).ZIndex = 10
	local v758 = Vector2.new(v733 + v732, v734 - v746)
	local v759 = v67 * 11
	local v760 = math.floor(v759)
	local v761 = math.max(9, v760)
	local v762 = v_u_14.ink
	local v763 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v764 = "100 m"
	local v765 = v_u_2.phoneText
	local v766 = "caption"
	local v767
	if p_u_58 then
		v767 = p_u_58.scale
	else
		v767 = nil
	end
	local v768
	if p_u_58 then
		v768 = p_u_58.phone
	else
		v768 = nil
	end
	v_u_60(v81, v764, v758, v765(v761, v766, v767, v768), v71, v762, v763).ZIndex = 10
	if v685 then
		local v769 = {}
		local v770 = v733 - 8
		local v771 = v734 - v746 - 9
		local v772 = v733 + v732 + 34
		local v773 = v67 * 5
		__set_list(v769, 1, {v770, v771, v772, v734 + math.max(3, v773) + 3})
		table.insert(v686, v769)
	end
	local v774 = {}
	for _, v775 in v_u_9.AREAS do
		local v776 = {
			["id"] = v775[1],
			["name"] = v775[2],
			["ref"] = v_u_7.gridRef(v775[3], v775[4])
		}
		table.insert(v774, v776)
	end
	local function v780(p777) -- name: placeOf
		-- upvalues: (copy) v_u_408, (ref) v_u_7
		local v778 = string.lower(p777)
		local v779 = v_u_408[v778]
		if v779 then
			return v779[1], v779[2], v779[3]
		else
			return v_u_7.placeOf(v778)
		end
	end
	local v781 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v782 = Instance.new("Frame")
	v782.BorderSizePixel = 0
	for v783, v784 in v781 do
		v782[v783] = v784
	end
	v782.Parent = v81
	v_u_73:SetAttribute("Frames", v_u_74)
	if not p_u_58 then
		local v785 = game:GetService("Players").LocalPlayer
		if v785 and v_u_6 then
			local v786 = v_u_6.ATTR
			if type(v786) == "string" then
				local v_u_791 = v785:GetAttributeChangedSignal(v_u_6.ATTR):Connect(function()
					-- upvalues: (copy) p_u_58, (ref) v_u_6, (ref) v_u_624, (ref) v_u_629, (ref) v_u_41, (copy) v_u_672, (copy) v_u_73
					local v787
					if p_u_58 and p_u_58.revealed ~= nil then
						v787 = p_u_58.revealed == true
					elseif v_u_6 then
						local v788 = v_u_6.clientRevealed
						if type(v788) == "function" then
							local v789 = v_u_6.clientRevealed
							local v790
							v787, v790 = pcall(v789)
							if v787 then
								v787 = v790 == true
							end
						else
							v787 = false
						end
					else
						v787 = false
					end
					if v787 ~= v_u_624 then
						v_u_624 = v787
						v_u_629 = v_u_41(v787 and "Ashgrove" or "Unnamed")
						v_u_672.Text = v_u_629
						v_u_73:SetAttribute("Revealed", v787)
					end
				end)
				v_u_73.Destroying:Once(function()
					-- upvalues: (ref) v_u_791
					if v_u_791 then
						v_u_791:Disconnect()
					end
				end)
			end
		end
	end
	v_u_73:SetAttribute("Revealed", v_u_624)
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["labelLayer"] = nil,
		["nameRects"] = nil,
		["removable"] = nil,
		["reserved"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["field"] = true,
		["positions"] = true,
		["revealed"] = nil,
		["title"] = nil,
		["placeOf"] = nil,
		["places"] = nil,
		["stats"] = nil,
		["frame"] = v_u_73,
		["area"] = v81,
		["marks"] = v782,
		["toPx"] = v171,
		["toWorld"] = function(p792, p793) -- name: toWorld
			-- upvalues: (copy) v_u_66, (copy) v_u_62
			return Vector2.new(p792 / v_u_66 - v_u_62, p793 / v_u_66 - v_u_62)
		end,
		["inside"] = function(p794, p795) -- name: inside
			-- upvalues: (copy) v_u_62
			local v796
			if math.abs(p794) <= v_u_62 then
				v796 = math.abs(p795) <= v_u_62
			else
				v796 = false
			end
			return v796
		end,
		["placed"] = v_u_348,
		["labelLayer"] = v_u_345,
		["nameRects"] = v_u_349,
		["removable"] = v_u_350,
		["reserved"] = v686,
		["nLandmarks"] = v498,
		["scale"] = v_u_66,
		["k"] = v67,
		["ink"] = v_u_14,
		["inner"] = v_u_65,
		["innerW"] = v_u_65,
		["innerH"] = v_u_65,
		["revealed"] = function() -- name: revealed
			-- upvalues: (ref) v_u_624
			return v_u_624
		end,
		["title"] = function() -- name: title
			-- upvalues: (ref) v_u_629
			return v_u_629
		end,
		["placeOf"] = v780,
		["places"] = v774,
		["stats"] = {
			["frames"] = v_u_74,
			["labels"] = v_u_75,
			["lots"] = #v396,
			["trees"] = v202,
			["contours"] = v222,
			["ticks"] = v223,
			["tunnels"] = #v_u_9.TUNNELS
		}
	}
end
return v_u_7