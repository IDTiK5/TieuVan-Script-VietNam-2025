-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / ReviewToolsBoot

return {
	["name"] = "ReviewToolsBoot",
	["order"] = 78,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.ReviewState.init(p_u_1)
		end)
		if not v2 then
			warn("[ReviewToolsBoot] ReviewState failed to start: " .. tostring(v3))
		end
		local v4, v5 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.ReviewTools.init(p_u_1)
		end)
		if not v4 then
			warn("[ReviewToolsBoot] ReviewTools failed to start: " .. tostring(v5))
		end
	end
}