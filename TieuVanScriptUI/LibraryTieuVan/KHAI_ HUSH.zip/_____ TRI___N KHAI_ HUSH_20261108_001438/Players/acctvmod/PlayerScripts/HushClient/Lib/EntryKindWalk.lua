-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryKindWalk

local v_u_1 = require(script.Parent:WaitForChild("EntryMath"))
local v_u_10 = {
	["LENGTH"] = 34,
	["BRAKE"] = 1.1,
	["STAGGER"] = 0.3,
	["TAIL"] = 0,
	["timing"] = function(p2) -- name: timing
		-- upvalues: (copy) v_u_10
		local v3 = v_u_10.STAGGER
		local v4 = p2.dur - p2.hand - v3 * (p2.n - 1)
		local v5 = math.max(v4, 1.5)
		local v6 = v_u_10.BRAKE
		local v7 = v5 * 0.4
		local v8 = math.min(v6, v7)
		local v9 = v_u_10.LENGTH / (v5 - v8 / 2)
		return {
			["length"] = v_u_10.LENGTH,
			["walk"] = v5,
			["brake"] = v8,
			["v0"] = v9,
			["stagger"] = v3
		}
	end
}
local function v_u_16(p11, p12) -- name: progress
	if p12 <= 0 then
		return 0, 0
	end
	if p11.walk <= p12 then
		return p11.length, 0
	end
	local v13 = p11.walk - p11.brake
	if p12 <= v13 then
		return p11.v0 * p12, p11.v0
	end
	local v14 = p12 - v13
	local v15 = p11.v0 / p11.brake
	return p11.v0 * v13 + p11.v0 * v14 - 0.5 * v15 * v14 * v14, p11.v0 - v15 * v14
end
v_u_10.progress = v_u_16
function v_u_10.sample(p17, p18) -- name: sample
	-- upvalues: (copy) v_u_10, (copy) v_u_16, (copy) v_u_1
	local v19 = v_u_10.timing(p17)
	local v20 = p17.f
	local v21 = p17.r
	local v22 = {}
	for v23, v24 in p17.places do
		local v25, v26 = v_u_16(v19, p18 - v19.stagger * (v23 - 1))
		local v27 = v19.length - v25
		v22[v23] = {
			["x"] = nil,
			["y"] = nil,
			["z"] = nil,
			["yaw"] = nil,
			["pose"] = "walk",
			["k"] = 0,
			["vx"] = nil,
			["vz"] = nil,
			["vis"] = true,
			["x"] = v24.x - v20.x * v27,
			["y"] = v24.y,
			["z"] = v24.z - v20.z * v27,
			["yaw"] = p17.yaw,
			["vx"] = v20.x * v26,
			["vz"] = v20.z * v26
		}
	end
	local v28 = v_u_1.centroid(v22)
	local v29 = v_u_1.clamp
	local v30 = p17.dur - p17.hand
	local v31 = v29(p18 / math.max(v30, 0.5), 0, 1)
	local v32 = 1.361356816555577 * v_u_1.easeInOut(v31)
	local v33 = v_u_1.lerp(13, 9.5, v_u_1.smooth(v31))
	local v34 = v_u_1.lerp(1.9, 2.8, v_u_1.smooth(v31))
	local v35 = p17.side
	local v36 = v20.x * math.cos(v32) + v21.x * v35 * math.sin(v32)
	local v37 = v20.z * math.cos(v32) + v21.z * v35 * math.sin(v32)
	local v38 = v_u_1.lerp(56, 50, v_u_1.smooth(v31))
	local v39 = {
		["cam"] = {
			["px"] = v28.x + v36 * v33,
			["py"] = v28.y + v34,
			["pz"] = v28.z + v37 * v33,
			["tx"] = v28.x,
			["ty"] = v28.y + 1.4,
			["tz"] = v28.z,
			["fov"] = v38
		},
		["actors"] = v22,
		["props"] = {}
	}
	return v39
end
function v_u_10.cues(_) -- name: cues
	return {}
end
return v_u_10