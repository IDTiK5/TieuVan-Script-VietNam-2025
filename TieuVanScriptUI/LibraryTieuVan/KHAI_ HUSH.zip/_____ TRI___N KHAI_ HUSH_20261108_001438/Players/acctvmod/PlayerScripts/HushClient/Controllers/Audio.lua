-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Audio

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("CollectionService")
local v_u_7 = game:GetService("ContentProvider")
local v_u_8 = game:GetService("ReplicatedStorage")
local v_u_9 = {
	["name"] = "Audio",
	["order"] = 5
}
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = v_u_3.LocalPlayer
local v_u_24 = "Menu"
local v_u_25 = 0
local v_u_26 = {}
local v_u_27 = Vector3.new(0, 0, 0)
local v_u_28 = false
local v_u_29 = {
	["on"] = false,
	["ears"] = nil,
	["char"] = nil,
	["mod"] = nil,
	["rc"] = nil,
	["offAt"] = nil,
	["fx"] = false,
	["fxRetryAt"] = 0,
	["fxWarned"] = false
}
local v_u_30 = false
local v_u_31 = nil
local v_u_32 = 0
local v_u_33 = 0
local v_u_34 = 0
local v_u_35 = 0
local v_u_36 = 0
local v_u_37 = 0
local v_u_38 = 0
local v_u_39 = -100
local v_u_40 = Random.new()
local v_u_41 = RaycastParams.new()
v_u_41.FilterType = Enum.RaycastFilterType.Exclude
v_u_41.IgnoreWater = true
local v_u_42 = 0
local v_u_43 = {}
local v_u_44 = {
	["Master"] = 0.5,
	["Music"] = 1,
	["SFX"] = 1,
	["Ambience"] = 1,
	["UI"] = 1
}
local v_u_45 = {
	["p"] = 0,
	["readAt"] = 0,
	["override"] = nil,
	["MAX"] = 0.5,
	["STEP_QUIET"] = 0.45,
	["STEP_DULL"] = 0.5,
	["published"] = -1,
	["lastZ"] = nil,
	["cueAt"] = 0,
	["cues"] = nil,
	["cueId"] = 0,
	["cues"] = {}
}
local v_u_65 = {
	["fix"] = true,
	["SHOT_CHECK"] = 0.12,
	["OWN_SUP"] = 1,
	["c"] = nil,
	["n"] = 0,
	["occSum"] = 0,
	["occN"] = 0,
	["blocked"] = 0,
	["bench"] = nil,
	["lateN"] = 0,
	["lateSum"] = 0,
	["lateMax"] = 0,
	["warmFolder"] = nil,
	["c"] = {},
	["note"] = function(p46) -- name: note
		-- upvalues: (copy) v_u_65
		v_u_65.c[p46] = (v_u_65.c[p46] or 0) + 1
	end,
	["reset"] = function() -- name: reset
		-- upvalues: (copy) v_u_65
		table.clear(v_u_65.c)
		v_u_65.n = 0
		v_u_65.occSum = 0
		v_u_65.occN = 0
		v_u_65.blocked = 0
		v_u_65.lateN = 0
		v_u_65.lateSum = 0
		v_u_65.lateMax = 0
	end,
	["warmWeapons"] = function(p47) -- name: warmWeapons
		-- upvalues: (copy) v_u_65, (ref) v_u_11, (copy) v_u_4
		local v48 = v_u_65.warmFolder
		if not p47 then
			if v48 then
				v48:Destroy()
			end
			v_u_65.warmFolder = nil
			return 0
		end
		if not (v_u_11 and v_u_11.weapons) then
			return 0
		end
		if not (v48 and v48.Parent) then
			v48 = Instance.new("Folder")
			v48.Name = "HushWarmWpn"
			v48.Parent = v_u_4
			v_u_65.warmFolder = v48
		end
		local v49 = {
			["wpn_sup_mech"] = true,
			["wpn_dry"] = true
		}
		local v50 = 0
		for _, v51 in v_u_11.weapons do
			for _, v52 in {
				"shot",
				"sup",
				"mech",
				"tail",
				"far",
				"pump",
				"casing"
			} do
				local v53 = v51[v52]
				if type(v53) ~= "string" then
					continue
				end
				v49[v53] = true
			end
		end
		for v54 in v49 do
			local v55 = v_u_11.defs[v54]
			for _, v56 in v55 and v55.v or {} do
				local v57 = v56.id
				local v58 = tostring(v57)
				if not v48:FindFirstChild(v58) then
					local v59 = Instance.new("Sound")
					v59.Name = v58
					v59.SoundId = "rbxassetid://" .. v58
					v59.Volume = 0
					v59.Parent = v48
				end
				v50 = v50 + 1
			end
		end
		return v50
	end,
	["text"] = function() -- name: text
		-- upvalues: (copy) v_u_65
		local v60 = {}
		for v61, v62 in v_u_65.c do
			if v61 == "ok" then
				continue
			end
			local v63 = v61 .. "=" .. v62
			table.insert(v60, v63)
		end
		table.sort(v60)
		local v64 = v_u_65.n - (v_u_65.c.ok or 0)
		return string.format("own=%d ok=%d fail=%d (%.1f%%) blocked=%d avgOcc=%.2f late avg %.2f max %.2f s %s", v_u_65.n, v_u_65.c.ok or 0, v64, v_u_65.n <= 0 and 0 or 100 * v64 / v_u_65.n, v_u_65.blocked, v_u_65.occN <= 0 and 0 or v_u_65.occSum / v_u_65.occN, v_u_65.lateN <= 0 and 0 or v_u_65.lateSum / v_u_65.lateN, v_u_65.lateMax, table.concat(v60, " "))
	end
}
local v_u_66 = {}
local function v_u_75(p67, p68, p69, p70) -- name: isDuplicate
	-- upvalues: (copy) v_u_66
	local v71 = os.clock()
	local v72 = p70 or 0.6
	for v73 = #v_u_66, 1, -1 do
		local v74 = v_u_66[v73]
		if v71 - v74.t <= 1.5 then
			if v74.key ~= p67 or (v74.auto == p69 or (v71 - v74.t >= v72 or (v74.pos - p68).Magnitude >= 6)) then
				continue
			end
			return true
		end
		table.remove(v_u_66, v73)
	end
	return false
end
local function v_u_81(p76, p77, p78) -- name: remember
	-- upvalues: (copy) v_u_66
	local v79 = v_u_66
	local v80 = {
		["key"] = p76,
		["pos"] = p77,
		["t"] = os.clock(),
		["auto"] = p78
	}
	table.insert(v79, v80)
	if #v_u_66 > 64 then
		table.remove(v_u_66, 1)
	end
end
local function v_u_87(p_u_82) -- name: posOf
	local v83 = typeof(p_u_82)
	if v83 == "Vector3" then
		return p_u_82, nil
	end
	if v83 == "Instance" then
		if p_u_82:IsA("BasePart") then
			return p_u_82.Position, p_u_82
		end
		if p_u_82:IsA("Attachment") then
			return p_u_82.WorldPosition, p_u_82
		end
		if p_u_82:IsA("Model") then
			local v84 = p_u_82.PrimaryPart
			if v84 then
				return v84.Position, v84
			end
			local v85, v86 = pcall(function()
				-- upvalues: (copy) p_u_82
				return p_u_82:GetPivot()
			end)
			if v85 then
				return v86.Position, nil
			end
		end
	elseif v83 == "CFrame" then
		return p_u_82.Position, nil
	end
	return nil, nil
end
local function v_u_91() -- name: ownCharacter
	-- upvalues: (copy) v_u_23, (copy) v_u_29
	local v88 = v_u_23.Character
	if not (v88 and v88.Parent) then
		v88 = nil
	end
	if v88 or not v_u_29.on then
		return v88
	end
	local v89 = v_u_29.char
	local v90
	if v_u_29.mod then
		v90 = v_u_29.mod.ownChar
	else
		v90 = nil
	end
	if type(v90) ~= "function" then
		return nil
	end
	if not (v89 and v89.Parent) then
		v89 = nil
	end
	return v90(v88, v89, v_u_29.on, v_u_29.ears ~= nil)
end
local function v_u_99(p92, p93) -- name: isOwnBody
	-- upvalues: (copy) v_u_91
	local v94 = v_u_91()
	if not v94 then
		return false
	end
	if typeof(p92) == "Instance" and p92:IsDescendantOf(v94) then
		return true
	end
	local v95 = v94:FindFirstChild("HumanoidRootPart")
	if not (p93 and (v95 and v95:IsA("BasePart"))) then
		return false
	end
	local v96 = p93 - v95.Position
	local v97 = v96.Y
	local v98
	if math.abs(v97) < 6 then
		v98 = Vector2.new(v96.X, v96.Z).Magnitude < 1.5
	else
		v98 = false
	end
	return v98
end
local function v_u_108() -- name: refreshFilter
	-- upvalues: (copy) v_u_3, (copy) v_u_41
	local v100 = {}
	for _, v101 in v_u_3:GetPlayers() do
		if not v101.Character then
			continue
		end
		local v102 = v101.Character
		table.insert(v100, v102)
	end
	local v103 = workspace:FindFirstChild("HushLocal")
	if v103 then
		table.insert(v100, v103)
	end
	local v104 = workspace:FindFirstChild("Raid")
	if v104 then
		local v105 = v104:FindFirstChild("Items")
		if v105 then
			table.insert(v100, v105)
		end
		local v106 = v104:FindFirstChild("Extracts")
		if v106 then
			table.insert(v100, v106)
		end
		local v107 = v104:FindFirstChild("Spawns")
		if v107 then
			table.insert(v100, v107)
		end
	end
	v_u_41.FilterDescendantsInstances = v100
end
local v_u_109 = nil
local function v_u_112(p110) -- name: proxyLiveTransparency
	-- upvalues: (ref) v_u_109, (ref) v_u_10, (copy) v_u_8
	local v111 = v_u_109
	if v111 == nil then
		if v_u_10 == nil then
			v111 = require(v_u_8:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MRProxy"))
		else
			v111 = v_u_10.shared.MRProxy
		end
		v_u_109 = v111
	end
	return v111.liveTransparency(p110)
end
local function v_u_121(p113) -- name: blockerWeight
	-- upvalues: (copy) v_u_6, (copy) v_u_112
	if v_u_6:HasTag(p113, "HushWindow") then
		return p113:GetAttribute("Broken") == true and 0 or 0.35
	elseif v_u_6:HasTag(p113, "HushWall") or (v_u_6:HasTag(p113, "HushWallBase") or (v_u_6:HasTag(p113, "HushRoof") or v_u_6:HasTag(p113, "HushFloor"))) then
		return 1
	elseif p113:IsA("Terrain") then
		return 1
	elseif p113.Transparency >= 0.95 then
		return 0
	else
		local v114 = p113.Parent
		if v114 and (v114:IsA("Model") and v_u_6:HasTag(v114, "HushDoor")) then
			local v115 = v114:GetAttribute("State")
			return (v115 == "Open" or v115 == "Broken") and 0 or 0.8
		else
			if p113.Anchored and p113.CanCollide then
				local v116 = p113.Transparency
				if v116 >= 0.6 then
					v116 = v_u_112(p113)
				end
				if v116 < 0.6 then
					local v117 = p113.Size
					if v117.X * v117.Y * v117.Z > 60 then
						local v118 = v117.X
						local v119 = v117.Y
						local v120 = v117.Z
						if math.max(v118, v119, v120) > 6 then
							return 0.7
						end
					end
				end
			end
			return 0
		end
	end
end
local function v_u_131(p122, p123) -- name: occlusion
	-- upvalues: (copy) v_u_41, (copy) v_u_121
	local v124 = p123 - p122
	local v125 = v124.Magnitude
	if v125 < 3 then
		return 0
	end
	local v126 = v124 / v125
	local v127 = v125 - 1
	local v128 = 0
	for _ = 1, 4 do
		local v129 = workspace:Raycast(p122, v126 * v127, v_u_41)
		if v129 then
			v128 = v128 + v_u_121(v129.Instance) * 0.75
			if v128 >= 1 then
				return 1
			end
			local v130 = (v129.Position - p122).Magnitude + 0.4
			p122 = p122 + v126 * v130
			v127 = v127 - v130
			if v127 > 0.5 then
				continue
			end
		end
	end
	return math.clamp(v128, 0, 1)
end
local function v_u_135(p132) -- name: roofAbove
	-- upvalues: (copy) v_u_41, (copy) v_u_6
	local v133 = workspace:Raycast(p132 + Vector3.new(0, 0.5, 0), Vector3.new(0, 40, 0), v_u_41)
	if v133 then
		local v134 = v133.Instance
		if v_u_6:HasTag(v134, "HushRoof") or v_u_6:HasTag(v134, "HushFloor") then
			return true, v134
		elseif v134:IsA("BasePart") and (v134.Anchored and (v134.Size.X > 8 and (v134.Size.Z > 8 and v134.Size.Y < 4))) then
			return true, v134
		else
			return false, nil
		end
	else
		return false, nil
	end
end
local function v_u_142(p136, p137) -- name: buildingKind
	-- upvalues: (copy) v_u_43, (copy) v_u_6
	if p136 and v_u_43[p136] then
		return v_u_43[p136]
	end
	while p137 and p137 ~= workspace do
		if v_u_6:HasTag(p137, "HushBuilding") then
			local v138 = p137:GetAttribute("Kind")
			local v139 = p137:GetAttribute("BuildingId")
			if type(v138) == "string" then
				if type(v139) == "string" then
					v_u_43[v139] = v138
				end
				return v138
			end
		end
		p137 = p137.Parent
	end
	if p136 then
		for _, v140 in v_u_6:GetTagged("HushBuilding") do
			if v140:GetAttribute("BuildingId") ~= p136 then
				continue
			end
			local v141 = v140:GetAttribute("Kind")
			if type(v141) ~= "string" then
				continue
			end
			v_u_43[p136] = v141
			return v141
		end
	end
	return nil
end
local function v_u_154() -- name: updateIndoor
	-- upvalues: (ref) v_u_24, (ref) v_u_30, (ref) v_u_31, (ref) v_u_14, (ref) v_u_12, (ref) v_u_10, (copy) v_u_29, (copy) v_u_142, (ref) v_u_28, (copy) v_u_135, (ref) v_u_27
	if v_u_24 == "Raid" or v_u_24 == "Hideout" then
		local v143 = false
		local v144 = nil
		local v145 = v_u_10
		if v145 then
			v145 = v_u_10.controllers.Vision
		end
		if not v145 or v145._broken then
			v145 = nil
		end
		local v146 = false
		if v_u_24 == "Hideout" then
			v146 = true
			v143 = true
			v144 = "Hideout"
		elseif v145 and (v145.isInside and not v_u_29.ears) then
			local v147 = v145.isInside
			local v148, v149 = pcall(v147)
			if v148 then
				v146 = true
				if type(v149) == "string" and v149 ~= "" then
					v144 = v_u_142(v149, nil)
					v143 = true
				end
			end
		end
		if not v146 and v_u_28 then
			local v150
			v143, v150 = v_u_135(v_u_27)
			if v143 then
				v144 = v_u_142(nil, v150)
			end
		end
		if v143 ~= v_u_30 or v144 ~= v_u_31 then
			v_u_30 = v143
			v_u_31 = v144
			v_u_14.setIndoor(v143, v144)
			local v151 = v_u_12.effects.room
			if v151 then
				v151.Enabled = v143
				local v152 = (v144 == "Supermarket" or (v144 == "Hospital" or (v144 == "School" or v144 == "Church"))) and true or v144 == "Garage"
				v151.DecayTime = v152 and 1.4 or 0.6
				v151.WetLevel = v152 and -10 or -15
			end
		end
	elseif v_u_30 then
		v_u_30 = false
		v_u_31 = nil
		v_u_14.setIndoor(false)
		local v153 = v_u_12.effects.room
		if v153 then
			v153.Enabled = false
		end
	end
end
function v_u_9.setRoomOverride(p155) -- name: setRoomOverride
	-- upvalues: (ref) v_u_21
	if p155 ~= nil then
		if type(p155) == "table" then
			local v156 = p155.decay
			local v157
			if type(v156) == "number" and (v156 == v156 and v156 ~= (1 / 0)) then
				v157 = v156 ~= (-1 / 0)
			else
				v157 = false
			end
			if v157 then
				local v158 = p155.density
				local v159
				if type(v158) == "number" and (v158 == v158 and v158 ~= (1 / 0)) then
					v159 = v158 ~= (-1 / 0)
				else
					v159 = false
				end
				if v159 then
					local v160 = p155.diffusion
					local v161
					if type(v160) == "number" and (v160 == v160 and v160 ~= (1 / 0)) then
						v161 = v160 ~= (-1 / 0)
					else
						v161 = false
					end
					if v161 then
						local v162 = p155.dry
						local v163
						if type(v162) == "number" and (v162 == v162 and v162 ~= (1 / 0)) then
							v163 = v162 ~= (-1 / 0)
						else
							v163 = false
						end
						if v163 then
							local v164 = p155.wet
							local v165
							if type(v164) == "number" and (v164 == v164 and v164 ~= (1 / 0)) then
								v165 = v164 ~= (-1 / 0)
							else
								v165 = false
							end
							if not v165 then
								p155 = nil
							end
						else
							p155 = nil
						end
					else
						p155 = nil
					end
				else
					p155 = nil
				end
			else
				p155 = nil
			end
		else
			p155 = nil
		end
	end
	v_u_21 = p155
end
local function v_u_173() -- name: applyRoomOverride
	-- upvalues: (ref) v_u_12, (ref) v_u_21, (ref) v_u_22, (ref) v_u_30, (ref) v_u_24, (ref) v_u_31
	local v166 = v_u_12.effects.room
	if v166 == nil then
		return
	else
		local v167 = v_u_21
		if v167 == nil then
			if v_u_22 ~= nil then
				local v168 = v_u_22
				v_u_22 = nil
				v166.Density = v168.density
				v166.Diffusion = v168.diffusion
				v166.DryLevel = v168.dry
				local v169 = v_u_30
				if v169 then
					v169 = v_u_24 == "Raid" and true or v_u_24 == "Hideout"
				end
				local v170 = v_u_31
				local v171 = v_u_12.effects.room
				if v171 then
					v171.Enabled = v169
					local v172 = (v170 == "Supermarket" or (v170 == "Hospital" or (v170 == "School" or v170 == "Church"))) and true or v170 == "Garage"
					v171.DecayTime = v172 and 1.4 or 0.6
					v171.WetLevel = v172 and -10 or -15
				end
			end
		else
			if v_u_22 == nil then
				v_u_22 = {
					["density"] = v166.Density,
					["diffusion"] = v166.Diffusion,
					["dry"] = v166.DryLevel
				}
			end
			v166.Enabled = true
			v166.DecayTime = v167.decay
			v166.Density = v167.density
			v166.Diffusion = v167.diffusion
			v166.DryLevel = v167.dry
			v166.WetLevel = v167.wet
		end
	end
end
local function v_u_185(p174, p175) -- name: screenFrame
	local v176
	if p175 then
		local v177 = p175.CFrame
		local v178 = v177.RightVector
		local v179 = v178.X
		local v180 = v178.Z
		local v181 = Vector3.new(v179, 0, v180)
		if v181.Magnitude < 0.001 then
			local v182 = v177.LookVector
			local v183 = -v182.Z
			local v184 = v182.X
			v181 = Vector3.new(v183, 0, v184)
		end
		v176 = v181.Magnitude < 0.001 and Vector3.new(1, 0, 0) or v181
	else
		v176 = Vector3.new(1, 0, 0)
	end
	return CFrame.fromMatrix(p174, v176.Unit, Vector3.new(0, 1, 0))
end
local function v_u_189(p186) -- name: earPosition
	if p186 then
		local v187 = p186:FindFirstChild("Head")
		if v187 and v187:IsA("BasePart") then
			return v187.Position
		else
			local v188 = p186:FindFirstChild("HumanoidRootPart")
			if v188 and v188:IsA("BasePart") then
				return v188.Position + Vector3.new(0, 1.5, 0)
			else
				return nil
			end
		end
	else
		return nil
	end
end
local function v_u_197() -- name: updateListener
	-- upvalues: (copy) v_u_29, (ref) v_u_24, (copy) v_u_4, (copy) v_u_185, (ref) v_u_27, (ref) v_u_28, (ref) v_u_10, (copy) v_u_189, (copy) v_u_23
	local v190 = workspace.CurrentCamera
	local v191 = v_u_29.ears
	if v191 and v_u_24 == "Raid" then
		v_u_4:SetListener(Enum.ListenerType.CFrame, v_u_185(v191, v190))
		v_u_27 = v191
		v_u_28 = true
		return
	else
		local v192 = v_u_10
		if v192 then
			v192 = v_u_10.controllers.Camera
		end
		if not v192 or v192._broken then
			v192 = nil
		end
		local v193
		if v192 and (v192.mode and v192.mode() == "spectate") then
			v193 = v192.subject()
		else
			v193 = nil
		end
		local v194 = v_u_189
		local v195
		if v193 and (v193.Parent and v193.Parent:IsA("Model")) then
			v195 = v193.Parent
		else
			v195 = v_u_23.Character
			if not (v195 and v195.Parent) then
				v195 = nil
			end
		end
		local v196 = v194(v195)
		if v196 and (v_u_24 == "Raid" or v_u_24 == "Hideout") then
			v_u_4:SetListener(Enum.ListenerType.CFrame, v_u_185(v196, v190))
			v_u_27 = v196
			v_u_28 = true
		else
			v_u_4:SetListener(Enum.ListenerType.Camera)
			v_u_27 = not v190 and Vector3.new(0, 0, 0) or v190.CFrame.Position
			v_u_28 = false
		end
	end
end
function v_u_9.play(p198, p199) -- name: play
	-- upvalues: (ref) v_u_12, (copy) v_u_75, (ref) v_u_27, (ref) v_u_18, (ref) v_u_19, (ref) v_u_11
	if not v_u_12 then
		return nil
	end
	local v200 = p199 or {}
	if v200.auto and v_u_75(p198, v_u_27, true) then
		return nil
	end
	if p198 == "ev_tinnitus" and v_u_18 then
		local v201 = v_u_18.traumaMul()
		if v201 < 0.02 then
			return nil
		end
		v200 = table.clone(v200)
		v200.volume = (v200.volume or 1) * v201
	end
	local v202 = v_u_19
	if v202 then
		v202 = v_u_19.capFor(v_u_11.defs[p198], p198, v200.loop)
	end
	local v203 = v_u_12.play
	local v204 = {
		["volume"] = v200.volume,
		["pitch"] = v200.pitch,
		["fadeIn"] = v200.fadeIn
	}
	local v205
	if v202 then
		v205 = false
	else
		v205 = v200.loop
	end
	v204.loop = v205
	v204.group = v200.group
	local v206 = v203(p198, v204)
	if v206 and v202 then
		v_u_19.capHandle(v206, v202)
	end
	return v206
end
function v_u_9.ui(p207) -- name: ui
	-- upvalues: (ref) v_u_12, (ref) v_u_11
	if not v_u_12 or type(p207) ~= "string" then
		return nil
	end
	local v208 = v_u_11.ui[p207] or (not v_u_11.defs["ui_" .. p207] and "ui_click" or "ui_" .. p207)
	return v_u_12.play(v208, {
		["group"] = "UI"
	})
end
function v_u_9.play3D(p_u_209, p210, p211) -- name: play3D
	-- upvalues: (ref) v_u_12, (copy) v_u_87, (copy) v_u_9, (copy) v_u_99, (copy) v_u_75, (copy) v_u_81, (ref) v_u_19, (ref) v_u_11
	if not v_u_12 then
		return nil
	end
	local v_u_212 = p211 or {}
	local v_u_213, v_u_214 = v_u_87(p210)
	if not v_u_213 then
		return v_u_9.play(p_u_209, v_u_212)
	end
	local v_u_215 = v_u_212.auto == true
	local v_u_216
	if v_u_212.own == nil then
		v_u_216 = v_u_99(p210, v_u_213)
	else
		v_u_216 = v_u_212.own == true
	end
	local function v225() -- name: go
		-- upvalues: (ref) v_u_75, (copy) p_u_209, (copy) v_u_213, (copy) v_u_215, (ref) v_u_81, (ref) v_u_19, (ref) v_u_11, (copy) v_u_212, (copy) v_u_216, (ref) v_u_12, (copy) v_u_214
		if v_u_75(p_u_209, v_u_213, v_u_215, 0.8) then
			return nil
		end
		v_u_81(p_u_209, v_u_213, v_u_215)
		local v217 = v_u_19
		if v217 then
			v217 = v_u_19.capFor(v_u_11.defs[p_u_209], p_u_209, v_u_212.loop)
		end
		local v218
		if v217 then
			v218 = false
		else
			v218 = v_u_212.loop
		end
		if v_u_216 then
			local v219 = v_u_12.play(p_u_209, {
				["volume"] = (v_u_212.volume or 1) * 0.85,
				["pitch"] = v_u_212.pitch,
				["loop"] = v218,
				["fadeIn"] = v_u_212.fadeIn,
				["lowpass"] = v_u_212.lowpass
			})
			if v219 and v217 then
				v_u_19.capHandle(v219, v217)
			end
			return v219
		end
		local v220 = v_u_12.play
		local v221 = p_u_209
		local v222 = {
			["pos"] = v_u_213
		}
		local v223
		if v_u_212.follow == false then
			v223 = nil
		else
			v223 = v_u_214
		end
		v222.follow = v223
		v222.volume = v_u_212.volume
		v222.pitch = v_u_212.pitch
		v222.roll = v_u_212.roll
		v222.loop = v218
		v222.fadeIn = v_u_212.fadeIn
		v222.occlude = v_u_212.occlude
		v222.lowpass = v_u_212.lowpass
		local v224 = v220(v221, v222)
		v_u_12.occludeNow(v224)
		if v224 and v217 then
			v_u_19.capHandle(v224, v217)
		end
		return v224
	end
	local v226 = v_u_212.delay
	local v227 = v_u_215 and not v226 and 0.1 or v226
	if not v227 or v227 <= 0 then
		return v225()
	end
	task.delay(v227, v225)
	return nil
end
function v_u_9.loop(p228, p229, p230) -- name: loop
	-- upvalues: (ref) v_u_12, (copy) v_u_87, (ref) v_u_11
	if not v_u_12 or type(p228) ~= "string" then
		return nil
	end
	local v231 = p230 or {}
	local v232, v233
	if p229 == nil then
		v232 = nil
		v233 = nil
	else
		v232, v233 = v_u_87(p229)
	end
	local v234 = v231.group
	local v235 = v_u_11.defs[p228]
	local v236 = not v234 and (v232 and (v235 and v235.group == "Ambience")) and "AmbWorld" or v234
	return v_u_12.bed(p228, {
		["pos"] = v232,
		["follow"] = v233,
		["volume"] = v231.volume,
		["fadeIn"] = v231.fadeIn,
		["pitch"] = v231.pitch,
		["roll"] = v231.roll,
		["group"] = v236
	})
end
function v_u_9.setMusicState(p237) -- name: setMusicState
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		v_u_13.set(p237)
	end
end
function v_u_9.musicState() -- name: musicState
	-- upvalues: (ref) v_u_13
	return not v_u_13 and "silent" or v_u_13.state()
end
function v_u_9.setVolume(p238, p239) -- name: setVolume
	-- upvalues: (copy) v_u_44, (ref) v_u_12
	if type(p239) == "number" and (p239 == p239 and type(p238) == "string") then
		local v240 = math.clamp(p239, 0, 1)
		v_u_44[p238] = v240
		if v_u_12 then
			local v241 = v_u_12.groups[p238]
			if v241 then
				v241.Volume = v240
			end
		end
	else
		return
	end
end
function v_u_9.getVolume(p242) -- name: getVolume
	-- upvalues: (copy) v_u_44
	return v_u_44[p242] or 1
end
function v_u_9.isIndoor() -- name: isIndoor
	-- upvalues: (ref) v_u_30
	return v_u_30
end
function v_u_9.earDistance(p243) -- name: earDistance
	-- upvalues: (ref) v_u_27
	return (p243 - v_u_27).Magnitude
end
function v_u_9.infection() -- name: infection
	-- upvalues: (copy) v_u_45, (copy) v_u_23, (copy) v_u_2
	local v244 = os.clock()
	if v244 < v_u_45.readAt then
		return v_u_45.p
	end
	v_u_45.readAt = v244 + 0.2
	local v245 = 0
	local v246 = v_u_45.override
	if type(v246) == "number" then
		v245 = v_u_45.override
	else
		local v247 = v_u_23.Character
		if v247 and (v247:GetAttribute("Infected") == true and v247:GetAttribute("Dead") ~= true) then
			local v248 = v247:GetAttribute("InfectionEndsAt")
			local v249 = v247:GetAttribute("InfectedAt")
			if type(v248) == "number" and (type(v249) == "number" and v249 < v248) then
				local v250 = (v_u_2.now() - v249) / (v248 - v249)
				v245 = math.clamp(v250, 0, 1)
			else
				v245 = type(v248) == "number" and v248 > 0 and 0.5 or v245
			end
		end
	end
	v_u_45.p = v245
	local v251 = v245 * 100 + 0.5
	local v252 = math.floor(v251) / 100
	if v252 ~= v_u_45.published then
		v_u_45.published = v252
		v_u_23:SetAttribute("AudioHearing", v252)
	end
	return v245
end
function v_u_9.hearCues(p253) -- name: hearCues
	-- upvalues: (copy) v_u_45
	local v254 = os.clock()
	local v255 = {}
	for _, v256 in v_u_45.cues do
		if (p253 or 0) >= v256.id or v254 - v256.t >= 2 then
			continue
		end
		table.insert(v255, v256)
	end
	return v255, v_u_45.cueId
end
function v_u_9.heartbeatBoost(p257, p258) -- name: heartbeatBoost
	-- upvalues: (ref) v_u_15
	if v_u_15 and (v_u_15.heartbeatBoost and (type(p257) == "number" and type(p258) == "number")) then
		v_u_15.heartbeatBoost(p257, p258)
	end
end
v_u_9.INFECT_BED_WINDOW = 90
function v_u_9.infectionLeft() -- name: infectionLeft
	-- upvalues: (copy) v_u_45, (copy) v_u_23, (copy) v_u_2
	local v259 = v_u_45.override
	if type(v259) == "number" then
		local v260 = (1 - v_u_45.override) * 360
		return math.max(0, v260)
	end
	local v261 = v_u_23.Character
	if not v261 or (v261:GetAttribute("Infected") ~= true or v261:GetAttribute("Dead") == true) then
		return nil
	end
	local v262 = v261:GetAttribute("InfectionEndsAt")
	if type(v262) ~= "number" or v262 <= 0 then
		return nil
	end
	local v263 = v262 - v_u_2.now()
	return math.max(0, v263)
end
function v_u_9.infectionBedVol() -- name: infectionBedVol
	-- upvalues: (copy) v_u_9
	local v264 = v_u_9.infectionLeft()
	if not v264 or v264 > 90 then
		return 0
	end
	local v265 = 1 - v264 / 90
	return math.clamp(v265, 0, 1) * 0.24 + 0.16
end
function v_u_9.hearing() -- name: hearing
	-- upvalues: (copy) v_u_45, (copy) v_u_9, (ref) v_u_18
	return (1 + v_u_45.MAX * v_u_9.infection()) * (not v_u_18 and 1 or v_u_18.boost())
end
function v_u_9.threat() -- name: threat
	-- upvalues: (ref) v_u_13
	return not v_u_13 and 0 or v_u_13.threat()
end
function v_u_9.threatHint(p266) -- name: threatHint
	-- upvalues: (ref) v_u_34, (ref) v_u_35
	local v267 = v_u_34
	local v268 = math.clamp(p266, 0, 1)
	v_u_34 = math.max(v267, v268)
	v_u_35 = os.clock() + 6
end
function v_u_9.footstep(p269, p270, p271) -- name: footstep
	-- upvalues: (ref) v_u_12, (ref) v_u_15, (ref) v_u_27, (copy) v_u_23, (copy) v_u_29, (copy) v_u_9
	if v_u_12 then
		if p269 and v_u_15 then
			v_u_15.noteExternalFootstep(p269)
		end
		local v272
		if p269 then
			v272 = p269:FindFirstChild("HumanoidRootPart")
		else
			v272 = p269
		end
		local v273
		if v272 then
			v273 = v272.Position - Vector3.new(0, 2.8, 0)
		else
			v273 = v_u_27
		end
		if v272 or not p269 then
			if (not p269 or (v_u_23.Character or v_u_29.on)) and (p269 == v_u_23.Character or (v273 - v_u_27).Magnitude <= 100) then
				local v274 = 0.85
				if type(p271) == "number" then
					v274 = math.clamp(p271, 0, 1.2) * 0.95 + 0.3
				elseif p269 then
					v274 = p269:GetAttribute("Sneaking") == true and 0.35 or (p269:GetAttribute("Sprinting") == true and 1.2 or v274)
				end
				v_u_9._step(p269, p270, v273, v274, false)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_9._step(p275, p276, p277, p278, _) -- name: _step
	-- upvalues: (ref) v_u_11, (copy) v_u_23, (copy) v_u_91, (copy) v_u_9, (copy) v_u_45, (ref) v_u_12, (ref) v_u_24, (ref) v_u_30, (ref) v_u_14
	local v279
	if typeof(p276) == "EnumItem" then
		v279 = p276.Name
	else
		v279 = type(p276) ~= "string" and "Concrete" or p276
	end
	local v280 = v_u_11.footsteps[v279] or v_u_11.defaultStep
	local v281
	if p275 == nil then
		v281 = false
	else
		v281 = p275 == v_u_23.Character and true or p275 == v_u_91()
	end
	if v281 then
		p277 = nil
	end
	local v282 = not v281 and 0 or v_u_9.infection()
	local v283
	if v282 > 0.02 then
		v283 = v_u_45.STEP_DULL * v282
	else
		v283 = nil
	end
	if v281 then
		p278 = p278 * (1 - v_u_45.STEP_QUIET * v282)
	end
	local v284 = v_u_12.play(v280, {
		["pos"] = p277,
		["volume"] = p278 * (v281 and 0.935 or 1),
		["occlude"] = not v281,
		["lowpass"] = v283
	})
	if v281 then
		v_u_45.lastStep = v284
	end
	if not v281 then
		v_u_12.occludeNow(v284)
	end
	if v_u_24 == "Raid" and not (v281 and v_u_30) then
		local v285 = v_u_14.scene()
		if (v285.weather == "Rain" or v285.weather == "Storm") and (v280 ~= "step_carpet" and (v280 ~= "step_wood" and (v280 ~= "step_plank" and (v280 ~= "step_tile" and not (v281 and v_u_30))))) then
			v_u_12.play("step_water", {
				["pos"] = nil,
				["volume"] = nil,
				["occlude"] = false,
				["lowpass"] = nil,
				["pos"] = p277,
				["volume"] = p278 * 0.45,
				["lowpass"] = v283
			})
		end
	end
end
function v_u_9.gunshot(p286, p287, p288, p289) -- name: gunshot
	-- upvalues: (ref) v_u_12, (copy) v_u_75, (copy) v_u_65, (copy) v_u_81, (copy) v_u_9
	if v_u_12 and typeof(p287) == "Vector3" then
		if v_u_75("gunshot", p287, false, 0.25) then
			if p289 == true then
				local v290 = v_u_65
				v290.n = v290.n + 1
				v_u_65.note("dup")
			end
		else
			v_u_81("gunshot", p287, false)
			v_u_9._gunshot(p286, p287, p288 == true, p289 == true)
		end
	else
		return
	end
end
function v_u_9._autoGunshot(p291, p292, p293, p294) -- name: _autoGunshot
	-- upvalues: (ref) v_u_10, (ref) v_u_27, (copy) v_u_75, (copy) v_u_81, (copy) v_u_9
	local v295 = v_u_10
	if v295 then
		v295 = v_u_10.controllers.WeaponClient
	end
	if not v295 or v295._broken then
		v295 = nil
	end
	if v295 and (p293 or (p292 - v_u_27).Magnitude < 400) then
		return
	elseif not v_u_75("gunshot", p292, true, 0.8) then
		v_u_81("gunshot", p292, true)
		v_u_9._gunshot(p291, p292, p294, p293)
	end
end
local function v_u_310(p296) -- name: trackOwnShot
	-- upvalues: (copy) v_u_65, (ref) v_u_12
	local v297 = v_u_65
	v297.n = v297.n + 1
	if p296 then
		local v_u_298 = p296.voice
		local v_u_299 = p296.serial
		task.delay(v_u_65.SHOT_CHECK, function()
			-- upvalues: (copy) v_u_298, (copy) v_u_299, (ref) v_u_65
			if v_u_298.busy and v_u_298.serial == v_u_299 then
				local v_u_300 = v_u_298.sound
				local v301 = v_u_65
				v301.occSum = v301.occSum + v_u_298.occAmount
				local v302 = v_u_65
				v302.occN = v302.occN + 1
				if v_u_298.occAmount >= 0.25 then
					v_u_65.note("muffled")
					return
				elseif v_u_300.IsPlaying then
					if v_u_300.TimeLength <= 0 then
						local v_u_303 = os.clock() - v_u_65.SHOT_CHECK
						task.spawn(function()
							-- upvalues: (copy) v_u_303, (ref) v_u_298, (ref) v_u_299, (ref) v_u_65, (copy) v_u_300
							if os.clock() - v_u_303 < 3 then
								task.wait()
								if v_u_298.busy and v_u_298.serial == v_u_299 then
									if v_u_300.TimeLength <= 0 then
										continue
									end
									local v304 = os.clock() - v_u_303
									v_u_65.note("late")
									local v305 = v_u_65
									v305.lateN = v305.lateN + 1
									local v306 = v_u_65
									v306.lateSum = v306.lateSum + v304
									local v307 = v_u_65
									local v308 = v_u_65.lateMax
									v307.lateMax = math.max(v308, v304)
								else
									v_u_65.note("lost")
								end
							else
								v_u_65.note("lost")
								return
							end
						end)
					else
						v_u_65.note("ok")
					end
				else
					v_u_65.note("notPlaying")
					return
				end
			else
				v_u_65.note("cut_" .. (v_u_298.relSerial ~= v_u_299 and "reused" or v_u_298.relReason))
				return
			end
		end)
	else
		local v309 = v_u_12.lastFail
		v_u_65.note("drop_" .. ((type(v309) ~= "string" or v309 == "") and "unknown" or v309))
	end
end
function v_u_9._gunshot(p311, p_u_312, p313, p_u_314) -- name: _gunshot
	-- upvalues: (ref) v_u_11, (ref) v_u_27, (ref) v_u_30, (copy) v_u_135, (ref) v_u_18, (copy) v_u_65, (copy) v_u_131, (ref) v_u_12, (copy) v_u_310, (copy) v_u_40, (ref) v_u_13, (copy) v_u_9
	local v315 = v_u_11.weapons[p311 or ""] or v_u_11.weapons[v_u_11.defaultWeapon]
	local v_u_316 = p_u_314 and 0 or (p_u_312 - v_u_27).Magnitude
	local v317
	if p_u_314 then
		v317 = v_u_30
	elseif v_u_316 < 400 then
		v317 = v_u_135(p_u_312)
	else
		v317 = false
	end
	if v_u_18 then
		local v318 = v_u_18.onShot
		local v319 = v317 == true
		pcall(v318, p311, v_u_316, p313, p_u_314, v319)
	end
	local v320 = v315.gain * (not (p_u_314 and v_u_18) and 1 or v_u_18.shotMul())
	local v321 = v315.pitch
	local v_u_322
	if p_u_314 then
		v_u_322 = v_u_65.fix
	else
		v_u_322 = p_u_314
	end
	if p_u_314 and (v_u_65.bench and v_u_131(v_u_27, p_u_312) >= 0.25) then
		local v323 = v_u_65
		v323.blocked = v323.blocked + 1
	end
	if p313 and v315.sup then
		local v324 = 1 - v_u_316 / 90
		local v325 = math.clamp(v324, 0, 1) ^ 1.2
		if v325 > 0.01 then
			local v326 = v_u_12.play
			local v327 = v315.sup
			local v328 = {
				["pos"] = nil,
				["noRolloff"] = true,
				["volume"] = nil,
				["pitch"] = nil,
				["reverb"] = nil,
				["occlude"] = nil,
				["priority"] = nil,
				["pos"] = p_u_312,
				["volume"] = v325 * v320 * (not v_u_322 and 0.9 or v_u_65.OWN_SUP),
				["pitch"] = v321,
				["reverb"] = v317 and 0.4 or nil
			}
			local v329
			if v_u_322 then
				v329 = false
			else
				v329 = nil
			end
			v328.occlude = v329
			v328.priority = v_u_322 and 3 or nil
			local v330 = v326(v327, v328)
			if not v_u_322 then
				v_u_12.occludeNow(v330)
			end
			if p_u_314 then
				v_u_310(v330)
			end
			if v_u_316 < 30 and v315.mech then
				local v331 = v_u_12.play
				local v332 = v315.mech
				local v333 = {
					["pos"] = nil,
					["noRolloff"] = true,
					["volume"] = nil,
					["pitch"] = nil,
					["occlude"] = nil,
					["pos"] = p_u_312,
					["volume"] = (1 - v_u_316 / 30) * 0.8,
					["pitch"] = v321
				}
				local v334
				if v_u_322 then
					v334 = false
				else
					v334 = nil
				end
				v333.occlude = v334
				v331(v332, v333)
				return
			end
		elseif p_u_314 then
			local v335 = v_u_65
			v335.n = v335.n + 1
			local v336 = v_u_12.lastFail
			v_u_65.note("drop_" .. ((type(v336) ~= "string" or v336 == "") and "unknown" or v336))
		end
	else
		local v337 = v315.reach
		local v338 = v_u_316 - 12
		local v339 = 1 - math.max(v338, 0) / v337
		local v340 = math.clamp(v339, 0, 1) ^ 1.4
		local v341 = (v_u_316 - 35) / 115
		local v342 = math.clamp(v341, 0, 1)
		local v343 = v342 * v342 * (3 - v342 * 2)
		local v344 = 1 - (v_u_316 - 150) / 950
		local v345 = v343 * math.clamp(v344, 0, 1)
		local v346
		if v317 then
			local v347 = 1 - v_u_316 / 260
			v346 = math.clamp(v347, 0, 1) * 0.3
		else
			local v348 = 1 - v_u_316 / 1150
			v346 = math.clamp(v348, 0, 1) * 0.95
		end
		local v349 = v_u_316 / 700
		local v350 = math.clamp(v349, 0, 0.7)
		if v340 > 0.01 then
			local v351 = v_u_12.play
			local v352 = v315.shot
			local v353 = {
				["pos"] = nil,
				["noRolloff"] = true,
				["volume"] = nil,
				["pitch"] = nil,
				["reverb"] = nil,
				["lowpass"] = nil,
				["priority"] = nil,
				["occlude"] = nil,
				["pos"] = p_u_312,
				["volume"] = v340 * v320 * (p_u_314 and 1.05 or 1),
				["pitch"] = v321,
				["reverb"] = v317 and 0.9 or (v_u_316 > 60 and 0.25 or nil),
				["lowpass"] = v350 * 0.6,
				["priority"] = p_u_314 and 3 or 2
			}
			local v354
			if v_u_322 then
				v354 = false
			else
				v354 = nil
			end
			v353.occlude = v354
			local v355 = v351(v352, v353)
			if not v_u_322 then
				v_u_12.occludeNow(v355)
			end
			if p_u_314 then
				v_u_310(v355)
			end
		end
		if v315.mech and v_u_316 < 45 then
			local v356 = v_u_12.play
			local v357 = v315.mech
			local v358 = {
				["pos"] = nil,
				["noRolloff"] = true,
				["volume"] = nil,
				["pitch"] = nil,
				["occlude"] = nil,
				["pos"] = p_u_312,
				["volume"] = (1 - v_u_316 / 45) * (p_u_314 and 1 or 0.7),
				["pitch"] = v321
			}
			local v359
			if v_u_322 then
				v359 = false
			else
				v359 = nil
			end
			v358.occlude = v359
			v356(v357, v358)
		end
		if v346 > 0.02 and v315.tail then
			v_u_12.play(v315.tail, {
				["pos"] = nil,
				["noRolloff"] = true,
				["volume"] = nil,
				["pitch"] = nil,
				["lowpass"] = nil,
				["occlude"] = false,
				["pos"] = p_u_312,
				["volume"] = v346 * v320 * (v315.auto and 0.7 or 1),
				["pitch"] = v321 * (v317 and 1.12 or 1),
				["lowpass"] = v350
			})
		end
		if v345 > 0.02 then
			local v360 = v_u_12.play(v315.far, {
				["pos"] = nil,
				["noRolloff"] = true,
				["volume"] = nil,
				["pitch"] = nil,
				["lowpass"] = nil,
				["pos"] = p_u_312,
				["volume"] = v345 * v320,
				["pitch"] = v321 * 0.97,
				["lowpass"] = v350 * 0.5 + 0.15
			})
			v_u_12.occludeNow(v360)
		end
		if v315.pump then
			local v361 = v315.pumpDelay or 0.35
			local v_u_362 = v315.pump
			task.delay(v361, function()
				-- upvalues: (copy) v_u_316, (ref) v_u_12, (copy) v_u_362, (copy) p_u_312, (copy) p_u_314, (copy) v_u_322
				if v_u_316 < 80 then
					local v363 = v_u_12.play
					local v364 = v_u_362
					local v365 = {
						["pos"] = p_u_312
					}
					local v366 = 1 - v_u_316 / 80
					v365.volume = math.clamp(v366, 0, 1) * (p_u_314 and 1 or 0.8)
					v365.roll = { 8, 80 }
					local v367
					if v_u_322 then
						v367 = false
					else
						v367 = nil
					end
					v365.occlude = v367
					v363(v364, v365)
				end
			end)
		end
		if p_u_314 and v315.casing then
			local v_u_368 = v315.casing
			task.delay(v_u_40:NextNumber(0.3, 0.45), function()
				-- upvalues: (ref) v_u_12, (copy) v_u_368
				v_u_12.play(v_u_368, {
					["volume"] = 0.85
				})
			end)
		end
		if v340 > 0.4 then
			v_u_13.duck(v340 * 0.45, 0.35)
		end
		if p_u_314 or v_u_316 < 90 then
			v_u_9.threatHint(p_u_314 and 0.28 or 0.2)
		end
	end
end
function v_u_9.melee(p369, p370, p371) -- name: melee
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_27, (copy) v_u_9, (copy) v_u_40
	if v_u_12 then
		local v372 = v_u_11.melee[p369 or "fists"] or v_u_11.melee.fists
		local v373 = p370 or v_u_27
		if p371 == "hit" then
			v_u_9.play3D(v372.hit, v373)
			if v_u_40:NextNumber() < 0.35 then
				v_u_9.play3D("mel_hit_bone", v373, {
					["volume"] = 0.8
				})
				return
			end
		else
			v_u_9.play3D(v372.swing, v373)
		end
	end
end
function v_u_9.zombie(p374, p375, p376, p377) -- name: zombie
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_15, (copy) v_u_75, (copy) v_u_81, (copy) v_u_9, (ref) v_u_27, (copy) v_u_45, (ref) v_u_13
	if v_u_12 and typeof(p375) == "Vector3" then
		local v378 = v_u_11.zombie[p374]
		if v378 then
			local v379 = p377 == true
			local v380 = v_u_11.humanKinds
			if v380 then
				v380 = v_u_11.humanKinds[p374] == true
			end
			if not v379 and v_u_15 then
				if v380 then
					if v_u_15.noteExternalHuman then
						v_u_15.noteExternalHuman()
					end
				elseif p374 ~= "bash" and p374 ~= "horde" then
					v_u_15.noteExternalZombie()
				end
			end
			local v381 = "z_" .. p374
			if not v_u_75(v381, p375, v379, 0.7) then
				v_u_81(v381, p375, v379)
				local v382 = v378[p376 or "walker"] or v378.default
				local v383
				if v380 then
					v383 = v_u_11.humanPitch and v_u_11.humanPitch[p376 or ""] or 1
				else
					v383 = v_u_11.zombiePitch[p376 or "walker"] or 1
				end
				local v384 = v380 and 1 or v_u_9.hearing()
				local v385 = v384 - 1
				local v386
				if math.abs(v385) > 0.001 then
					local v387 = v_u_11.defs[v382]
					if v387 then
						v387 = v387.roll
					end
					if v387 then
						v386 = { v387[1], v387[2] * v384 }
					else
						v386 = { 10, 150 * v384 }
					end
				else
					v386 = nil
				end
				local v388
				if p374 == "horde" then
					if v_u_15 then
						v_u_15.externalHorde(p375)
						return
					end
					v388 = v_u_12.play(v382, {
						["pos"] = nil,
						["loop"] = false,
						["len"] = 6,
						["volume"] = nil,
						["fadeIn"] = 1,
						["roll"] = nil,
						["pos"] = p375,
						["volume"] = 1.2 * v384,
						["roll"] = v386
					})
				else
					local v389 = v_u_12.play
					local v390 = {
						["pos"] = p375,
						["pitch"] = v383
					}
					local v391 = v384 - 1
					local v392
					if math.abs(v391) > 0.001 then
						v392 = v384
					else
						v392 = nil
					end
					v390.volume = v392
					v390.roll = v386
					v388 = v389(v382, v390)
				end
				v_u_12.occludeNow(v388)
				local v393 = (p375 - v_u_27).Magnitude
				if not v380 then
					v_u_45.lastZ = v388
					if v384 > 1.001 and (v388 and (v393 > 18 and os.clock() - v_u_45.cueAt > 0.35)) then
						v_u_45.cueAt = os.clock()
						local v394 = v_u_45
						v394.cueId = v394.cueId + 1
						local v395 = v_u_45.cues
						local v396 = {
							["id"] = v_u_45.cueId,
							["pos"] = p375,
							["kind"] = p374,
							["p"] = v_u_45.p,
							["t"] = os.clock()
						}
						table.insert(v395, v396)
						if #v_u_45.cues > 8 then
							table.remove(v_u_45.cues, 1)
						end
					end
				end
				if p374 == "scream" then
					v_u_13.duck(0.35, 1.2)
					if v393 < 180 then
						v_u_9.threatHint(0.6)
						return
					end
				else
					if p374 == "attack" and v393 < 12 then
						v_u_9.threatHint(0.9)
						return
					end
					if v380 and (v382 == "z_human_shout" and v393 < 120) then
						v_u_9.threatHint(0.45)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_9.explosion(p397, p398) -- name: explosion
	-- upvalues: (ref) v_u_12, (ref) v_u_27, (ref) v_u_30, (ref) v_u_13, (ref) v_u_18, (ref) v_u_38, (copy) v_u_9
	if v_u_12 and typeof(p397) == "Vector3" then
		local v399 = p397 + Vector3.new(0, 1.5, 0)
		local v400 = (v399 - v_u_27).Magnitude
		local v401 = p398 or 20
		if v400 < 700 then
			local v402 = {
				["pos"] = nil,
				["roll"] = nil,
				["reverb"] = nil,
				["priority"] = 4,
				["pos"] = v399,
				["roll"] = { 60, 1400 },
				["reverb"] = v_u_30 and 0.6 or nil
			}
			local v403 = v_u_12.play("ev_explosion", v402)
			v_u_12.occludeNow(v403)
		end
		if v400 > 120 then
			v_u_12.play("ev_explosion_far", {
				["pos"] = nil,
				["roll"] = nil,
				["lowpass"] = 0.3,
				["priority"] = 4,
				["pos"] = v399,
				["roll"] = { 150, 2000 }
			})
		elseif v400 < 60 then
			v_u_12.play("ev_explosion_far", {
				["pos"] = nil,
				["roll"] = nil,
				["volume"] = 0.55,
				["priority"] = 3,
				["pos"] = v399,
				["roll"] = { 150, 2000 }
			})
		end
		v_u_13.duck(0.6, 2.5)
		if v400 < v401 * 1.6 then
			local v404 = 1.25 - v400 / (v401 * 1.6)
			local v_u_405 = math.clamp(v404, 0.45, 1)
			if v_u_18 then
				v_u_18.onBlast(v_u_405)
			else
				task.delay(0.45, function()
					-- upvalues: (ref) v_u_38, (copy) v_u_405
					local v406 = v_u_38
					local v407 = v_u_405
					v_u_38 = math.max(v406, v407)
				end)
				local v408 = v_u_12.play
				local v409 = {
					["volume"] = nil,
					["fadeIn"] = 0.6
				}
				local v410 = 1.4 - v400 / (v401 * 1.6)
				v409.volume = math.clamp(v410, 0.3, 1)
				v408("ev_tinnitus", v409)
			end
		end
		v_u_9.threatHint(0.5)
	end
end
function v_u_9.thunder(p411, p412) -- name: thunder
	-- upvalues: (ref) v_u_12, (ref) v_u_13
	if v_u_12 then
		local v413 = (p411 or 0) / 4000
		local v414 = math.clamp(v413, 0, 1)
		v_u_12.play("ev_thunder", {
			["volume"] = math.clamp(p412 or 1, 0, 1.4),
			["pitch"] = 1 - v414 * 0.15,
			["lowpass"] = v414 * 0.6
		})
		v_u_13.duck(0.3 * (p412 or 1), 2)
	end
end
function v_u_9._setMuffle(p415) -- name: _setMuffle
	-- upvalues: (ref) v_u_36
	v_u_36 = math.clamp(p415, 0, 1)
end
function v_u_9._hasRaidClient() -- name: _hasRaidClient
	-- upvalues: (ref) v_u_10
	local v416 = v_u_10
	if v416 then
		v416 = v_u_10.controllers.RaidClient
	end
	if not v416 or v416._broken then
		v416 = nil
	end
	return v416 ~= nil
end
function v_u_9._controller(p417) -- name: _controller
	-- upvalues: (ref) v_u_10
	local v418 = v_u_10
	if v418 then
		v418 = v_u_10.controllers[p417]
	end
	if v418 and not v418._broken then
		return v418
	else
		return nil
	end
end
local v_u_419 = {}
local v_u_420 = {
	"ev_explosion",
	"ev_explosion_far",
	"ev_tinnitus",
	"ev_flare_ignite",
	"ev_flare_loop",
	"item_bottle_break",
	"item_throw"
}
local v_u_421 = nil
local function v_u_430(p422) -- name: warm
	-- upvalues: (ref) v_u_11, (ref) v_u_421
	if v_u_11 and v_u_11.defs then
		local v423 = v_u_421
		if not (v423 and v423.Parent) then
			v423 = Instance.new("Folder")
			v423.Name = "HushWarm"
			v423.Parent = game:GetService("SoundService")
			v_u_421 = v423
		end
		for _, v424 in p422 do
			local v425 = v_u_11.defs[v424]
			for _, v426 in v425 and v425.v or {} do
				local v427 = v426.id
				local v428 = tostring(v427)
				if v423:FindFirstChild(v428) then
					continue
				end
				local v429 = Instance.new("Sound")
				v429.Name = v428
				v429.SoundId = "rbxassetid://" .. v428
				v429.Volume = 0
				v429.Parent = v423
			end
		end
	end
end
v_u_9._warm = v_u_430
local v_u_431 = nil
local function v_u_441() -- name: preloadActiveFallbacks
	-- upvalues: (ref) v_u_11, (copy) v_u_419, (copy) v_u_7, (ref) v_u_16
	local v_u_432 = {}
	for _, v433 in v_u_11.defs do
		for _, v434 in v433.v do
			if not v434.fb or v_u_419[v434.id] then
				continue
			end
			v_u_419[v434.id] = true
			local v435 = Instance.new("Sound")
			v435.SoundId = "rbxassetid://" .. v434.id
			table.insert(v_u_432, v435)
		end
	end
	if #v_u_432 ~= 0 then
		task.spawn(function()
			-- upvalues: (ref) v_u_7, (copy) v_u_432, (ref) v_u_16
			local function v439()
				-- upvalues: (ref) v_u_7, (ref) v_u_432, (ref) v_u_16
				v_u_7:PreloadAsync(v_u_432, function(p436, p437)
					-- upvalues: (ref) v_u_16
					if v_u_16 then
						local v438 = v_u_16.onPreload
						pcall(v438, p436, p437)
					end
				end)
			end
			pcall(v439)
			for _, v440 in v_u_432 do
				v440:Destroy()
			end
		end)
	end
end
local function v_u_450(p442) -- name: applyBlockedText
	-- upvalues: (ref) v_u_431, (ref) v_u_11, (copy) v_u_23, (copy) v_u_441
	local v443 = type(p442) ~= "string" and "" or p442
	if v443 ~= v_u_431 then
		v_u_431 = v443
		local v444 = {}
		local v445 = 0
		for v446 in string.gmatch(v443, "%d+") do
			local v447 = tonumber(v446)
			if not v447 then
				continue
			end
			v444[v447] = true
			v445 = v445 + 1
		end
		local v448, v449 = v_u_11.applyBlocked(v444)
		v_u_23:SetAttribute("AudioBlocked", string.format("%d blocked, %d defs on fallback, %d silent", v445, v448, v449))
		v_u_441()
	end
end
v_u_9._applyBlockedText = v_u_450
local function v_u_463(p451) -- name: readRaidScene
	-- upvalues: (copy) v_u_8, (ref) v_u_14
	local v452 = p451:GetAttribute("TimeOfDay")
	local v453 = p451:GetAttribute("Weather")
	local v454 = p451:GetAttribute("SnowLevel")
	local v455 = p451:GetAttribute("Difficulty")
	local v456 = v_u_8:FindFirstChild("HushRuntime")
	local v457 = v_u_14.setScene
	local v458 = {
		["tokyo"] = nil,
		["place"] = "Raid",
		["time"] = nil,
		["weather"] = nil,
		["snow"] = nil
	}
	local v459
	if v456 == nil then
		v459 = false
	else
		v459 = v456:GetAttribute("MapId") == "tokyo"
	end
	v458.tokyo = v459
	v458.time = type(v452) ~= "string" and "Day" or v452
	v458.weather = type(v453) ~= "string" and "Clear" or v453
	local v460
	if type(v454) == "number" then
		local v461 = v454 + 0.5
		local v462 = math.floor(v461)
		v460 = math.clamp(v462, 1, 3)
	else
		v460 = v455 == "Nightmare" and 3 or (v455 == "Hard" and 2 or 1)
	end
	v458.snow = v460
	v457(v458, 4)
end
local function v_u_528(p464, p465) -- name: onPlace
	-- upvalues: (copy) v_u_29, (ref) v_u_25, (ref) v_u_24, (copy) v_u_26, (ref) v_u_15, (ref) v_u_19, (copy) v_u_9, (ref) v_u_13, (ref) v_u_14, (ref) v_u_12, (ref) v_u_38, (ref) v_u_18, (ref) v_u_39, (ref) v_u_11, (copy) v_u_419, (copy) v_u_7, (ref) v_u_16, (copy) v_u_65, (copy) v_u_430, (copy) v_u_420, (ref) v_u_10, (copy) v_u_463
	if v_u_29.on and p464 ~= "Raid" then
		return
	else
		v_u_25 = v_u_25 + 1
		local v_u_466 = v_u_25
		v_u_24 = p464
		for _, v467 in v_u_26 do
			v467:Disconnect()
		end
		table.clear(v_u_26)
		if v_u_15 then
			v_u_15.detachRaid()
		end
		if v_u_19 then
			v_u_19.onPlace(p464, p465)
		end
		if p464 == "Transit" then
			if p465 == "Menu" then
				v_u_9.ui("deploy")
			end
			v_u_13.setAuto(false)
			v_u_13.set("silent")
			v_u_14.setEnabled(false, 1.5)
			v_u_12.stopAll(function(p468)
				return p468.is3D
			end, 1)
			v_u_9._setMuffle(0)
			return
		else
			v_u_14.setEnabled(true, 2)
			v_u_9._setMuffle(0)
			v_u_38 = 0
			if v_u_18 then
				v_u_18.reset()
			end
			if p464 == "Menu" then
				v_u_13.setAuto(false)
				v_u_14.setScene({
					["place"] = "Menu",
					["time"] = "Dusk",
					["weather"] = "Rain",
					["indoor"] = false
				}, 3)
				v_u_13.set(os.clock() - v_u_39 < 25 and "debrief" or "menu")
				local v_u_469 = {
					"ui_",
					"mus_menu",
					"mus_debrief",
					"amb_rain",
					"amb_wind"
				}
				task.spawn(function()
					-- upvalues: (ref) v_u_11, (copy) v_u_469, (ref) v_u_419, (ref) v_u_7, (ref) v_u_16
					local v470 = {}
					for _, v471 in v_u_11.idsFor(v_u_469) do
						if v_u_419[v471] then
							continue
						end
						v_u_419[v471] = true
						local v472 = Instance.new("Sound")
						v472.SoundId = "rbxassetid://" .. v471
						table.insert(v470, v472)
					end
					if #v470 ~= 0 then
						for v473 = 1, #v470, 40 do
							local v474 = v473 + 39
							local v475 = #v470
							local v_u_476 = {}
							for v477 = v473, math.min(v474, v475) do
								local v478 = v470[v477]
								table.insert(v_u_476, v478)
							end
							local function v482()
								-- upvalues: (ref) v_u_7, (copy) v_u_476, (ref) v_u_16
								v_u_7:PreloadAsync(v_u_476, function(p479, p480)
									-- upvalues: (ref) v_u_16
									if v_u_16 then
										local v481 = v_u_16.onPreload
										pcall(v481, p479, p480)
									end
								end)
							end
							pcall(v482)
						end
						for _, v483 in v470 do
							v483:Destroy()
						end
					end
				end)
				return
			elseif p464 == "Hideout" then
				v_u_13.setAuto(false)
				v_u_14.setScene({
					["place"] = "Hideout",
					["indoor"] = true
				}, 3)
				v_u_13.set("hideout")
				local v_u_484 = {
					"mus_hideout",
					"amb_",
					"step_",
					"wpn_",
					"rel_",
					"impact_"
				}
				task.spawn(function()
					-- upvalues: (ref) v_u_11, (copy) v_u_484, (ref) v_u_419, (ref) v_u_7, (ref) v_u_16
					local v485 = {}
					for _, v486 in v_u_11.idsFor(v_u_484) do
						if v_u_419[v486] then
							continue
						end
						v_u_419[v486] = true
						local v487 = Instance.new("Sound")
						v487.SoundId = "rbxassetid://" .. v486
						table.insert(v485, v487)
					end
					if #v485 ~= 0 then
						for v488 = 1, #v485, 40 do
							local v489 = v488 + 39
							local v490 = #v485
							local v_u_491 = {}
							for v492 = v488, math.min(v489, v490) do
								local v493 = v485[v492]
								table.insert(v_u_491, v493)
							end
							local function v497()
								-- upvalues: (ref) v_u_7, (copy) v_u_491, (ref) v_u_16
								v_u_7:PreloadAsync(v_u_491, function(p494, p495)
									-- upvalues: (ref) v_u_16
									if v_u_16 then
										local v496 = v_u_16.onPreload
										pcall(v496, p494, p495)
									end
								end)
							end
							pcall(v497)
						end
						for _, v498 in v485 do
							v498:Destroy()
						end
					end
				end)
				v_u_65.warmWeapons(v_u_65.fix)
			elseif p464 == "Raid" then
				v_u_14.setScene({
					["place"] = "Raid",
					["indoor"] = false
				}, 3)
				v_u_13.set("silent")
				local v_u_499 = {
					"wpn_",
					"rel_",
					"step_",
					"z_",
					"door_",
					"glass_",
					"item_",
					"amb_",
					"ev_",
					"mel_",
					"impact_",
					"mus_calm",
					"mus_tension",
					"mus_chase",
					"mus_extract",
					"bodyfall",
					"cloth",
					"light_",
					"ui_hit",
					"ui_kill",
					"ui_cam"
				}
				task.spawn(function()
					-- upvalues: (ref) v_u_11, (copy) v_u_499, (ref) v_u_419, (ref) v_u_7, (ref) v_u_16
					local v500 = {}
					for _, v501 in v_u_11.idsFor(v_u_499) do
						if v_u_419[v501] then
							continue
						end
						v_u_419[v501] = true
						local v502 = Instance.new("Sound")
						v502.SoundId = "rbxassetid://" .. v501
						table.insert(v500, v502)
					end
					if #v500 ~= 0 then
						for v503 = 1, #v500, 40 do
							local v504 = v503 + 39
							local v505 = #v500
							local v_u_506 = {}
							for v507 = v503, math.min(v504, v505) do
								local v508 = v500[v507]
								table.insert(v_u_506, v508)
							end
							local function v512()
								-- upvalues: (ref) v_u_7, (copy) v_u_506, (ref) v_u_16
								v_u_7:PreloadAsync(v_u_506, function(p509, p510)
									-- upvalues: (ref) v_u_16
									if v_u_16 then
										local v511 = v_u_16.onPreload
										pcall(v511, p509, p510)
									end
								end)
							end
							pcall(v512)
						end
						for _, v513 in v500 do
							v513:Destroy()
						end
					end
				end)
				v_u_430(v_u_420)
				v_u_65.warmWeapons(v_u_65.fix)
				task.spawn(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_466, (ref) v_u_25, (ref) v_u_463, (ref) v_u_26, (ref) v_u_13, (ref) v_u_15
					local v_u_514 = v_u_10.session.waitForRaid(90)
					if v_u_466 == v_u_25 and v_u_514 then
						v_u_463(v_u_514)
						local v515 = v_u_26
						local v516 = v_u_514:GetAttributeChangedSignal("Weather")
						local function v517()
							-- upvalues: (ref) v_u_463, (copy) v_u_514
							v_u_463(v_u_514)
						end
						table.insert(v515, v516:Connect(v517))
						local v518 = v_u_26
						local v519 = v_u_514:GetAttributeChangedSignal("TimeOfDay")
						local function v520()
							-- upvalues: (ref) v_u_463, (copy) v_u_514
							v_u_463(v_u_514)
						end
						table.insert(v518, v519:Connect(v520))
						local v521 = v_u_26
						local v522 = v_u_514:GetAttributeChangedSignal("SnowLevel")
						local function v523()
							-- upvalues: (ref) v_u_463, (copy) v_u_514
							v_u_463(v_u_514)
						end
						table.insert(v521, v522:Connect(v523))
						local v524 = v_u_26
						local v525 = v_u_514.AncestryChanged
						local function v527(_, p526)
							-- upvalues: (ref) v_u_466, (ref) v_u_25, (ref) v_u_13
							if p526 == nil and v_u_466 == v_u_25 then
								v_u_13.set("silent")
							end
						end
						table.insert(v524, v525:Connect(v527))
						v_u_15.attachRaid(v_u_514)
						v_u_13.setAuto(true)
					end
				end)
			end
		end
	end
end
local function v_u_554(p529) -- name: observerHead
	-- upvalues: (copy) v_u_29, (ref) v_u_10, (copy) v_u_3
	local v530 = nil
	if v_u_29.rc == nil then
		local function v531()
			-- upvalues: (ref) v_u_10
			return v_u_10.lib.ReviewCamera
		end
		local v532, v533 = pcall(v531)
		local v534 = v_u_29
		if not v532 or type(v533) ~= "table" then
			v533 = false
		end
		v534.rc = v533
	end
	local v535 = v_u_29.rc
	local v536
	if v535 then
		local v537 = v535.targetRoot
		if type(v537) == "function" then
			local v538 = v535.targetRoot
			local v539
			v539, v536 = pcall(v538)
			if v539 and (typeof(v536) == "Instance" and v536:IsA("BasePart")) then
				if not v536.Parent then
					v536 = v530
				end
			else
				v536 = v530
			end
		else
			v536 = v530
		end
	else
		v536 = v530
	end
	local v540
	if v536 then
		v540 = v536
	else
		local v541 = v_u_3:GetPlayerByUserId(p529)
		if v541 and v541.Character then
			v540 = v541.Character:FindFirstChild("HumanoidRootPart")
		else
			v540 = nil
		end
		if v540 then
			if not v540:IsA("BasePart") then
				v540 = v536
			end
		else
			v540 = v536
		end
	end
	if v540 then
		local v542
		if v540.Parent then
			v542 = v540.Parent:FindFirstChild("Head")
		else
			v542 = nil
		end
		local v543
		if v542 and v542:IsA("BasePart") then
			v543 = v542.Position
		else
			v543 = nil
		end
		local v544 = v540.Position
		local v545 = v_u_29.mod.earPoint
		local v546
		if v543 then
			v546 = v543.X
		else
			v546 = nil
		end
		local v547
		if v543 then
			v547 = v543.Y
		else
			v547 = nil
		end
		local v548
		if v543 then
			v548 = v543.Z
		else
			v548 = nil
		end
		local v549, v550, v551 = v545(v546, v547, v548, v544.X, v544.Y, v544.Z)
		if v549 == nil then
			return nil, nil
		else
			local v552 = v540.Parent
			local v553 = Vector3.new(v549, v550, v551)
			if v552 and v552:IsA("Model") then
				return v553, v552
			else
				return v553, nil
			end
		end
	else
		return nil, nil
	end
end
local function v_u_565() -- name: connectRelay
	-- upvalues: (copy) v_u_29, (ref) v_u_10, (copy) v_u_9
	v_u_29.fx = true
	local function v555()
		-- upvalues: (ref) v_u_10
		return v_u_10.lib.ReviewListenerFx
	end
	local v556, v_u_557 = pcall(v555)
	if v556 and type(v_u_557) == "table" then
		task.spawn(function()
			-- upvalues: (copy) v_u_557, (ref) v_u_10, (ref) v_u_9, (ref) v_u_29
			local v558 = v_u_557.install
			local v559 = v_u_10
			local v560 = v_u_9
			local function v561()
				-- upvalues: (ref) v_u_29
				return v_u_29.on == true
			end
			local v562, v563 = pcall(v558, v559, v560, v561)
			if not v562 or v563 ~= true then
				local v564 = v562 and "install refused" or v563
				v_u_29.fx = false
				v_u_29.fxRetryAt = os.clock() + 8
				if not v_u_29.fxWarned then
					v_u_29.fxWarned = true
					warn("[HUSH:Audio] observer combat.fx relay not connected, trying again:", v564)
				end
			end
		end)
	else
		v_u_29.fx = false
		v_u_29.fxRetryAt = os.clock() + 8
		if not v_u_29.fxWarned then
			v_u_29.fxWarned = true
			warn("[HUSH:Audio] observer combat.fx relay not connected, trying again:", "ReviewListenerFx missing")
		end
	end
end
local function v_u_587() -- name: syncObserver
	-- upvalues: (copy) v_u_23, (copy) v_u_29, (ref) v_u_10, (ref) v_u_18, (ref) v_u_24, (copy) v_u_528, (copy) v_u_565, (copy) v_u_554
	local v566 = v_u_23:GetAttribute("OverwatchTarget")
	if v566 == nil and not v_u_29.on then
		return
	else
		if v_u_29.mod == nil then
			local function v567()
				-- upvalues: (ref) v_u_10
				return v_u_10.lib.ReviewListener
			end
			local v568, v569 = pcall(v567)
			local v570 = v_u_29
			if not v568 or type(v569) ~= "table" then
				v569 = false
			end
			v570.mod = v569
		end
		local v571 = v_u_29.mod
		if v571 then
			local v572 = v571.decide
			local v573 = v_u_29
			local v574 = v_u_23:GetAttribute("OverwatchReviewer")
			local v575 = v_u_23.Character
			if not (v575 and v575.Parent) then
				v575 = nil
			end
			local v576, v577, v578 = v572(v573, v566, v574, v575 ~= nil, v_u_23:GetAttribute("Place"), os.clock())
			if v576 ~= v_u_29.on then
				v_u_29.on = v576
				if v_u_18 and v_u_18.observer then
					local v579 = v_u_18.observer
					pcall(v579, v576)
				end
				if v577 ~= v_u_24 then
					local v580 = v_u_528
					local v581 = v_u_24
					local v582, v583 = pcall(v580, v577, v581)
					if not v582 then
						warn("[HUSH:Audio] observer place change failed:", v583)
					end
				end
			end
			if v576 and (not v_u_29.fx and os.clock() >= v_u_29.fxRetryAt) then
				v_u_565()
			end
			local v584, v585
			if v576 and v578 then
				v584, v585 = v_u_554(v566)
			else
				v584 = nil
				v585 = nil
			end
			v_u_29.ears = v584
			local v586 = v_u_29
			if not v584 then
				v585 = nil
			end
			v586.char = v585
		else
			v_u_29.ears = nil
			v_u_29.char = nil
		end
	end
end
local function v_u_612(p588, p589) -- name: measure
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_5
	local v590 = Instance.new("Folder")
	v590.Name = "HushMeasure"
	v590.Parent = v_u_4
	local v591 = {}
	for _, v592 in p588 do
		local v593 = Instance.new("Sound")
		v593.SoundId = "rbxassetid://" .. v592
		v593.Volume = 0.001
		v593.Parent = v590
		v591[v592] = v593
	end
	local v_u_594 = {}
	for _, v595 in v591 do
		table.insert(v_u_594, v595)
	end
	local function v596()
		-- upvalues: (ref) v_u_7, (copy) v_u_594
		v_u_7:PreloadAsync(v_u_594)
	end
	pcall(v596)
	local v597 = {}
	local v598 = {}
	local v599 = {}
	for _, v600 in v591 do
		v600:Play()
	end
	local v601 = os.clock()
	while os.clock() - v601 < p589 do
		v_u_5.Heartbeat:Wait()
		for v602, v603 in v591 do
			local v604 = v603.PlaybackLoudness
			if (v597[v602] or 0) < v604 then
				v597[v602] = v604
			end
			if v604 <= 1 then
				continue
			end
			v598[v602] = (v598[v602] or 0) + v604
			v599[v602] = (v599[v602] or 0) + 1
		end
	end
	v590:Destroy()
	local v605 = {}
	for _, v606 in p588 do
		local v607 = not v599[v606] and 0 or v598[v606] / v599[v606]
		local v608 = string.format
		local v609 = v597[v606] or 0
		local v610 = math.floor(v609)
		local v611 = math.floor(v607)
		table.insert(v605, v608("%d=%d/%d", v606, v610, v611))
	end
	return table.concat(v605, " ")
end
local function v_u_624(p613, p614) -- name: envelope
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_5
	local v_u_615 = Instance.new("Sound")
	v_u_615.SoundId = "rbxassetid://" .. p613
	v_u_615.Volume = 0.001
	v_u_615.Parent = v_u_4
	local function v616()
		-- upvalues: (ref) v_u_7, (copy) v_u_615
		v_u_7:PreloadAsync({ v_u_615 })
	end
	pcall(v616)
	v_u_615:Play()
	local v617 = os.clock()
	local v618 = 0
	local v619 = {}
	while os.clock() - v617 < p614 do
		v_u_5.Heartbeat:Wait()
		if v618 > os.clock() then
			continue
		end
		v618 = os.clock() + 0.05
		local v620 = string.format
		local v621 = v_u_615.TimePosition
		local v622 = v_u_615.PlaybackLoudness
		local v623 = math.floor(v622)
		table.insert(v619, v620("%.2f:%d", v621, v623))
	end
	v_u_615:Destroy()
	return table.concat(v619, " ")
end
local function v_u_631(p_u_625, p_u_626, p_u_627) -- name: toast
	-- upvalues: (ref) v_u_10
	local function v628()
		-- upvalues: (ref) v_u_10, (copy) p_u_625, (copy) p_u_626, (copy) p_u_627
		v_u_10.lib.HushUI.toast(p_u_625, "info", p_u_626, p_u_627)
	end
	if not pcall(v628) then
		local v629 = v_u_10.controllers.HUD
		if v629 and v629.notify then
			local v630 = v629.notify
			if pcall(v630, p_u_625, "info", p_u_626) then
				return
			end
			print("[HUSH:Audio]", p_u_625, p_u_626 or "")
		else
			print("[HUSH:Audio]", p_u_625, p_u_626 or "")
		end
	end
end
local function v_u_912() -- name: registerCommands
	-- upvalues: (ref) v_u_10, (copy) v_u_23, (ref) v_u_11, (ref) v_u_12, (ref) v_u_16, (ref) v_u_24, (ref) v_u_13, (ref) v_u_30, (ref) v_u_28, (copy) v_u_29, (copy) v_u_4, (copy) v_u_91, (ref) v_u_27, (copy) v_u_9, (copy) v_u_65, (copy) v_u_631, (copy) v_u_612, (copy) v_u_624, (ref) v_u_18, (copy) v_u_45, (ref) v_u_15
	v_u_10.command("audio.blocked", function()
		-- upvalues: (ref) v_u_23, (ref) v_u_11
		local v632 = {}
		local v633 = v_u_23:GetAttribute("AudioBlocked") or "0 blocked"
		__set_list(v632, 1, {(tostring(v633))})
		for v634, v635 in v_u_11.full do
			local v636 = 0
			for _, v637 in v635 do
				if not v_u_11.isBlocked(v637.id) then
					continue
				end
				v636 = v636 + 1
			end
			local v638 = #v_u_11.defs[v634].v
			if v636 <= 0 then
				break
			end
			local v639 = v_u_11.defs[v634].v[1]
			if v639 then
				v639 = v_u_11.defs[v634].v[1].fb
			end
			local v640 = string.format
			table.insert(v632, v640("%s: %d blocked, %d active%s", v634, v636, v638, v639 and " (fallbacks)" or ""))
		end
		table.sort(v632)
		return table.concat(v632, "\n")
	end)
	v_u_10.command("audio.pickcheck", function(p641)
		-- upvalues: (ref) v_u_11, (ref) v_u_12
		local v642 = p641[1] or "z_groan"
		local v643 = p641[2]
		local v644 = tonumber(v643) or 50
		if not v_u_11.defs[v642] then
			return "unknown def " .. v642
		end
		local v645 = 0
		local v646 = {}
		local v647 = 0
		for _ = 1, v644 do
			local v648 = v_u_12.play(v642, {
				["volume"] = 0
			})
			local v649 = v648 and v648.voice
			if v649 then
				v649 = v648.voice.sound
			end
			if not v649 then
				continue
			end
			v645 = v645 + 1
			local v650 = string.match(v649.SoundId, "(%d+)$") or "?"
			v646[v650] = (v646[v650] or 0) + 1
			if v_u_11.isBlocked(tonumber(v650) or 0) then
				v647 = v647 + 1
			end
			v648:stop(0)
		end
		local v651 = {}
		for v652, v653 in v646 do
			local v654 = v652 .. "x" .. v653
			table.insert(v651, v654)
		end
		table.sort(v651)
		return string.format("%s played %d/%d blockedChosen=%d ids=%s", v642, v645, v644, v647, table.concat(v651, " "))
	end)
	v_u_10.command("audio.health", function()
		-- upvalues: (ref) v_u_16
		return not v_u_16 and "no AudioHealth" or v_u_16.stats()
	end)
	v_u_10.command("audio.reportspam", function(p655)
		-- upvalues: (ref) v_u_16, (ref) v_u_11
		if not v_u_16 then
			return "no AudioHealth"
		end
		if p655[2] == "reset" or p655[1] == "reset" then
			v_u_16._reset()
		end
		local v656 = p655[1]
		local v657 = tonumber(v656) or 100
		local v658 = v_u_11.allIds()
		local v659 = 0
		for v660 = 1, v657 do
			if not v_u_16.report(v658[(v660 - 1) % #v658 + 1], "test") then
				continue
			end
			v659 = v659 + 1
		end
		return string.format("queued %d of %d; %s", v659, v657, v_u_16.stats())
	end)
	v_u_10.command("audio.stats", function()
		-- upvalues: (ref) v_u_24, (ref) v_u_13, (ref) v_u_30, (ref) v_u_28, (ref) v_u_12
		local v661 = v_u_30
		local v662 = v_u_28
		return string.format("place=%s music=%s threat=%.2f indoor=%s listenerHead=%s %s", v_u_24, v_u_13.state(), v_u_13.threat(), tostring(v661), tostring(v662), v_u_12.stats())
	end)
	v_u_10.command("audio.observer", function()
		-- upvalues: (ref) v_u_29, (ref) v_u_4, (ref) v_u_24, (ref) v_u_23, (ref) v_u_28
		local v663 = v_u_29.ears
		local v664 = v_u_4:GetListener()
		local v665 = string.format
		local v666 = "observer=%s ears=%s place=%s realPlace=%s target=%s reviewer=%s ownBody=%s listener=%s head=%s status=%s"
		local v667 = v_u_29.on
		local v668 = tostring(v667)
		local v669 = not v663 and "nil" or tostring(v663)
		local v670 = v_u_24
		local v671 = v_u_23
		local v672 = tostring(v671:GetAttribute("Place"))
		local v673 = v_u_23
		local v674 = tostring(v673:GetAttribute("OverwatchTarget"))
		local v675 = v_u_23
		local v676 = tostring(v675:GetAttribute("OverwatchReviewer"))
		local v677 = v_u_23.Character
		if not (v677 and v677.Parent) then
			v677 = nil
		end
		local v678 = v677 ~= nil
		local v679 = v_u_28
		local v680 = v_u_23
		return v665(v666, v668, v669, v670, v672, v674, v676, tostring(v678), tostring(v664), tostring(v679), (tostring(v680:GetAttribute("AudioObserver"))))
	end)
	v_u_10.command("audio.listener", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_23, (ref) v_u_91, (ref) v_u_27
		local v681, v682 = v_u_4:GetListener()
		local v683 = workspace.CurrentCamera
		if v681 ~= Enum.ListenerType.CFrame or (typeof(v682) ~= "CFrame" or not v683) then
			return "listener=" .. tostring(v681)
		end
		local v684 = v683.CFrame.RightVector
		local v685 = v684.X
		local v686 = v684.Z
		local v687 = Vector3.new(v685, 0, v686)
		local v688 = v687.Magnitude <= 0.001 and 0 or v682.RightVector:Dot(v687.Unit)
		local v689 = v_u_23.Character
		if not (v689 and v689.Parent) then
			v689 = nil
		end
		if v689 then
			v689 = v689:FindFirstChild("HumanoidRootPart")
		end
		local v690 = v689 and v689:IsA("BasePart")
		if v690 then
			local v691 = v689.Position - Vector3.new(0, 2.8, 0)
			local v692 = v_u_91()
			if v692 then
				local v693 = v692:FindFirstChild("HumanoidRootPart")
				if v691 and (v693 and v693:IsA("BasePart")) then
					local v694 = v691 - v693.Position
					local v695 = v694.Y
					if math.abs(v695) < 6 then
						v690 = Vector2.new(v694.X, v694.Z).Magnitude < 1.5
					else
						v690 = false
					end
				else
					v690 = false
				end
			else
				v690 = false
			end
		end
		local v696 = v689 and v689:IsA("BasePart")
		if v696 then
			local v697 = v689.Position + Vector3.new(2.5, 0, 0)
			local v698 = v_u_91()
			if v698 then
				local v699 = v698:FindFirstChild("HumanoidRootPart")
				if v697 and (v699 and v699:IsA("BasePart")) then
					local v700 = v697 - v699.Position
					local v701 = v700.Y
					if math.abs(v701) < 6 then
						v696 = Vector2.new(v700.X, v700.Z).Magnitude < 1.5
					else
						v696 = false
					end
				else
					v696 = false
				end
			else
				v696 = false
			end
		end
		local v702 = string.format
		local v703 = v682.Position
		local v704 = v_u_27
		return v702("listener=CFrame pos=%s head=%s dotR=%.3f up=%.3f ownFeet=%s own2.5=%s", tostring(v703), tostring(v704), v688, v682.UpVector.Y, tostring(v690), (tostring(v696)))
	end)
	v_u_10.command("audio.side", function(p705)
		-- upvalues: (ref) v_u_27, (ref) v_u_9, (ref) v_u_4
		local v706 = workspace.CurrentCamera
		if not v706 then
			return "no camera"
		end
		local v707 = p705[2]
		local v708 = tonumber(v707) or 12
		local v709 = v706.CFrame.RightVector
		local v710 = v709.X
		local v711 = v709.Z
		local v712 = Vector3.new(v710, 0, v711).Unit
		local v713 = v_u_27
		if p705[1] == "left" then
			v708 = -v708
		end
		local v714 = v713 + v712 * v708
		local v715 = v_u_9.play3D(p705[3] or "z_groan", v714, {
			["own"] = false
		})
		local v716, v717 = v_u_4:GetListener()
		local v718 = (v716 ~= Enum.ListenerType.CFrame or typeof(v717) ~= "CFrame") and (0 / 0) or v717:PointToObjectSpace(v714).X
		local v719 = string.format
		local v720 = p705[1] or "right"
		local v721 = v715 ~= nil
		return v719("%s listenerX=%.2f voice=%s", v720, v718, (tostring(v721)))
	end)
	v_u_10.command("audio.play", function(p722)
		-- upvalues: (ref) v_u_9
		return v_u_9.play(p722[1] or "ui_click") and "ok" or "no voice / unknown"
	end)
	v_u_10.command("audio.at", function(p723)
		-- upvalues: (ref) v_u_9, (ref) v_u_27
		local v724 = p723[2]
		local v725 = tonumber(v724) or 20
		local v726 = workspace.CurrentCamera
		local v727
		if v726 then
			local v728 = v726.CFrame.LookVector.X
			local v729 = v726.CFrame.LookVector.Z
			v727 = Vector3.new(v728, 0, v729).Unit
		else
			v727 = Vector3.new(0, 0, -1)
		end
		return v_u_9.play3D(p723[1] or "z_groan", v_u_27 + v727 * v725) and "ok" or "no voice / unknown"
	end)
	v_u_10.command("audio.gun", function(p730)
		-- upvalues: (ref) v_u_9, (ref) v_u_27
		local v731 = p730[2]
		local v732 = tonumber(v731) or 30
		local v733 = workspace.CurrentCamera
		local v734
		if v733 then
			local v735 = v733.CFrame.LookVector.X
			local v736 = v733.CFrame.LookVector.Z
			v734 = Vector3.new(v735, 0, v736).Unit
		else
			v734 = Vector3.new(0, 0, -1)
		end
		v_u_9.gunshot(p730[1] or "pistol_g17", v_u_27 + v734 * v732, p730[3] == "sup", v732 <= 0)
		return "ok"
	end)
	v_u_10.command("audio.shotstats", function(p737)
		-- upvalues: (ref) v_u_65, (ref) v_u_12
		local v738 = v_u_65.text() .. " | voices: " .. v_u_12.counterText(p737[1] == "reset")
		if p737[1] == "reset" then
			v_u_65.reset()
		end
		return v738
	end)
	v_u_10.command("audio.b4fix", function(p739)
		-- upvalues: (ref) v_u_65, (ref) v_u_12, (ref) v_u_24
		local v740 = p739[1] ~= "off"
		v_u_65.fix = v740
		v_u_12.fix = v740
		local v741 = v_u_65.warmWeapons
		local v742
		if v740 then
			v742 = v_u_24 == "Raid" and true or v_u_24 == "Hideout"
		else
			v742 = v740
		end
		local v743 = v741(v742)
		return "b4fix=" .. tostring(v740) .. " warmWeapons=" .. v743
	end)
	v_u_10.command("audio.shotbench", function(p744)
		-- upvalues: (ref) v_u_65, (ref) v_u_11, (ref) v_u_9, (ref) v_u_23, (ref) v_u_12, (ref) v_u_27
		if v_u_65.bench then
			return "bench already running"
		end
		local v_u_745 = {}
		if p744[1] == nil or p744[1] == "all" then
			for v746 in v_u_11.weapons do
				table.insert(v_u_745, v746)
			end
			table.sort(v_u_745)
		else
			if not v_u_11.weapons[p744[1]] then
				local v747 = p744[1]
				return "unknown weapon " .. tostring(v747)
			end
			v_u_745 = { p744[1] }
		end
		local v748 = p744[2]
		local v_u_749 = tonumber(v748) or 75
		local v750 = p744[3] or "both"
		local v_u_751 = v750 == "both" and { "loud", "sup" } or { v750 }
		local v752 = p744[4]
		local v_u_753 = tonumber(v752) or 2.4
		local v754 = p744[5]
		local v_u_755 = tonumber(v754) or 0.1
		local v_u_756 = p744[6] or ""
		local v_u_757 = v_u_9._weapons
		v_u_65.bench = true
		v_u_23:SetAttribute("AudioShotBench", "running")
		task.spawn(function()
			-- upvalues: (ref) v_u_745, (copy) v_u_751, (ref) v_u_11, (ref) v_u_65, (ref) v_u_12, (copy) v_u_755, (copy) v_u_757, (copy) v_u_749, (copy) v_u_753, (ref) v_u_27, (ref) v_u_9, (copy) v_u_756, (ref) v_u_23
			local v_u_758 = {}
			local function v783()
				-- upvalues: (ref) v_u_745, (ref) v_u_751, (ref) v_u_11, (ref) v_u_65, (ref) v_u_12, (ref) v_u_755, (ref) v_u_757, (ref) v_u_749, (ref) v_u_753, (ref) v_u_27, (ref) v_u_9, (copy) v_u_758, (ref) v_u_756, (ref) v_u_23
				for _, v759 in v_u_745 do
					for _, v760 in v_u_751 do
						if v760 == "sup" and not v_u_11.weapons[v759].sup then
							continue
						end
						v_u_65.reset()
						v_u_12.counterText(true)
						local v761 = v_u_755
						if v_u_757 and (v_u_757.stats and v_u_757.interval) then
							local v762 = v_u_757.stats
							local v763, v764 = pcall(v762, v759, nil)
							if v763 and v764 then
								local v765 = v_u_757.interval
								local v766, v767 = pcall(v765, v764)
								if v766 and type(v767) == "number" then
									local v768 = v_u_755
									v761 = math.min(v767, v768)
								end
							end
						end
						for v769 = 1, v_u_749 do
							local v770 = v769 * 2.39996
							local v771 = v_u_753 + v769 % 3 * 0.8
							local v772 = v_u_27 + Vector3.new(0, -0.9, 0)
							local v773 = math.cos(v770)
							local v774 = math.sin(v770)
							local v775 = v772 + Vector3.new(v773, 0, v774) * v771
							v_u_9.gunshot(v759, v775, v760 == "sup", true)
							task.wait(v761)
						end
						task.wait(v_u_65.SHOT_CHECK + 0.6)
						local v776 = v_u_758
						local v777 = string.format
						local v778 = v_u_756
						local v779 = v_u_65.fix
						local v780 = tostring(v779)
						local v781 = v_u_65.text()
						local v782 = v_u_12.counterText
						table.insert(v776, v777("%s %s %s fix=%s: %s | %s", v778, v759, v760, v780, v781, v782(true)))
						v_u_23:SetAttribute("AudioShotBench", "running " .. #v_u_758)
					end
				end
			end
			local v784, v785 = pcall(v783)
			if not v784 then
				local v786 = "error: " .. tostring(v785)
				table.insert(v_u_758, v786)
			end
			v_u_23:SetAttribute("AudioShotBench", table.concat(v_u_758, "\n"))
			v_u_65.bench = nil
		end)
		return "bench started: " .. #v_u_745 .. " weapons x " .. #v_u_751 .. " modes x " .. v_u_749 .. " shots"
	end)
	v_u_10.command("audio.zombie", function(p787)
		-- upvalues: (ref) v_u_9, (ref) v_u_27
		local v788 = p787[2]
		local v789 = tonumber(v788) or 15
		local v790 = workspace.CurrentCamera
		local v791
		if v790 then
			local v792 = v790.CFrame.LookVector.X
			local v793 = v790.CFrame.LookVector.Z
			v791 = Vector3.new(v792, 0, v793).Unit
		else
			v791 = Vector3.new(0, 0, -1)
		end
		v_u_9.zombie(p787[1] or "groan", v_u_27 + v791 * v789, p787[3])
		return "ok"
	end)
	v_u_10.command("audio.music", function(p794)
		-- upvalues: (ref) v_u_9, (ref) v_u_13
		v_u_9.setMusicState(p794[1] or "auto")
		return "music " .. v_u_13.state()
	end)
	v_u_10.command("music.audition", function(p795)
		-- upvalues: (ref) v_u_13, (ref) v_u_23, (ref) v_u_11, (ref) v_u_631
		local v796 = string.lower(p795[1] or "all")
		if v796 == "stop" then
			v_u_13.stopAudition()
			v_u_23:SetAttribute("AudioAudition", nil)
			return "audition stopped, music " .. v_u_13.state()
		end
		local v797 = v796 ~= "all" and { v796 } or v_u_13.states()
		if v796 ~= "all" and #v_u_13.candidates(v796) == 0 then
			return "unknown state \'" .. v796 .. "\' (menu|hideout|calm|tension|chase|extract|debrief|all|stop)"
		end
		local v798 = p795[2]
		local v_u_799 = tonumber(v798) or 20
		local v810 = v_u_13.audition(v797, v_u_799, function(p800, p801, p802, p803)
			-- upvalues: (ref) v_u_11, (ref) v_u_23, (ref) v_u_631, (copy) v_u_799
			local v804 = v_u_11
			if v804 then
				v804 = v_u_11.musicNames
			end
			local v805 = v804 and v804[p803] or "id " .. tostring(p803)
			local v806 = string.format("%s %d/%d  %s", string.upper(p800), p801, p802, v805)
			v_u_23:SetAttribute("AudioAudition", string.format("%s %d/%d %d %s", p800, p801, p802, p803, v805))
			local v807 = v_u_631
			local v808 = string.format("music.pick %s %d", p800, p803)
			local v809 = v_u_799 - 1
			v807(v806, v808, (math.max(3, v809)))
		end, function()
			-- upvalues: (ref) v_u_23, (ref) v_u_631
			v_u_23:SetAttribute("AudioAudition", nil)
			v_u_631("Audition finished", "music.pick <state> <id> keeps one", 5)
		end)
		return string.format("auditioning %d tracks, %d s each (music.audition stop ends it)", v810, v_u_799)
	end)
	v_u_10.command("music.pick", function(p811)
		-- upvalues: (ref) v_u_13, (ref) v_u_631, (ref) v_u_11
		local v812 = string.lower(p811[1] or "")
		if #v_u_13.candidates(v812) == 0 then
			return "usage: music.pick <menu|hideout|calm|tension|chase|extract|debrief> <id|index|auto>"
		end
		local v813 = v_u_13.prefer(v812, p811[2])
		if not v813 then
			return v812 .. ": back to rotation"
		end
		local v814 = v_u_13.candidates(v812)[v813]
		local v815 = not v814 and 0 or v814.id
		local v816 = v_u_631
		local v817 = "Music "
		local v818 = string.upper(v812)
		local v819 = ": "
		local v820 = v_u_11
		if v820 then
			v820 = v_u_11.musicNames
		end
		v816(v817 .. v818 .. v819 .. (v820 and v820[v815] or "id " .. tostring(v815)), "pinned for this session", 5)
		local v821 = string.format
		local v822 = "%s -> #%d %d %s (session only; tell the lead to make it the default)"
		local v823 = v_u_11
		if v823 then
			v823 = v_u_11.musicNames
		end
		return v821(v822, v812, v813, v815, v823 and v823[v815] or "id " .. tostring(v815))
	end)
	v_u_10.command("music.list", function(p824)
		-- upvalues: (ref) v_u_13, (ref) v_u_11
		local v825 = {}
		local v826
		if p824[1] then
			v826 = { string.lower(p824[1]) }
		else
			v826 = v_u_13.states()
		end
		for _, v827 in v826 do
			local v828 = v_u_13.preferred(v827)
			for v829, v830 in v_u_13.candidates(v827) do
				local v831 = string.format
				local v832 = "%s %d%s %d %s"
				local v833 = v828 == v829 and "*" or ""
				local v834 = v830.id
				local v835 = v830.id
				local v836 = v_u_11
				if v836 then
					v836 = v_u_11.musicNames
				end
				local v837 = v836 and v836[v835] or "id " .. tostring(v835)
				table.insert(v825, v831(v832, v827, v829, v833, v834, v837))
			end
		end
		return table.concat(v825, " | ")
	end)
	v_u_10.command("audio.vol", function(p838)
		-- upvalues: (ref) v_u_9
		local v839 = v_u_9.setVolume
		local v840 = p838[1] or "Master"
		local v841 = p838[2]
		v839(v840, tonumber(v841) or 1)
		return "ok"
	end)
	v_u_10.command("audio.measure", function(p842)
		-- upvalues: (ref) v_u_11, (ref) v_u_612, (ref) v_u_23
		local v_u_843 = p842[1] or "ui_"
		local v844 = p842[2]
		local v_u_845 = tonumber(v844) or 6
		local v_u_846 = v_u_11.idsFor({ v_u_843 })
		task.spawn(function()
			-- upvalues: (ref) v_u_612, (copy) v_u_846, (copy) v_u_845, (ref) v_u_23, (copy) v_u_843
			v_u_23:SetAttribute("AudioMeasure", v_u_843 .. " " .. v_u_612(v_u_846, v_u_845))
		end)
		return "measuring " .. #v_u_846 .. " ids for " .. v_u_845 .. " s -> attribute AudioMeasure"
	end)
	v_u_10.command("audio.measureids", function(p847)
		-- upvalues: (ref) v_u_23, (ref) v_u_612
		local v848 = p847[1]
		local v_u_849 = tonumber(v848) or 6
		local v_u_850 = {}
		for v851 = 2, #p847 do
			local v852 = p847[v851]
			local v853 = tonumber(v852)
			if not v853 then
				continue
			end
			table.insert(v_u_850, v853)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_23, (ref) v_u_612, (copy) v_u_850, (copy) v_u_849
			v_u_23:SetAttribute("AudioMeasure", "ids " .. v_u_612(v_u_850, v_u_849))
		end)
		return "measuring " .. #v_u_850
	end)
	v_u_10.command("audio.env", function(p854)
		-- upvalues: (ref) v_u_23, (ref) v_u_624
		local v855 = p854[1]
		local v_u_856 = tonumber(v855)
		if not v_u_856 then
			return "usage: audio.env <id> <seconds>"
		end
		local v857 = p854[2]
		local v_u_858 = tonumber(v857) or 4
		task.spawn(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_856, (ref) v_u_624, (copy) v_u_858
			local v859 = v_u_856
			v_u_23:SetAttribute("AudioEnvelope", tostring(v859) .. " " .. v_u_624(v_u_856, v_u_858))
		end)
		return "sampling -> attribute AudioEnvelope"
	end)
	v_u_10.command("audio.infbed", function()
		-- upvalues: (ref) v_u_9, (ref) v_u_23
		local v860 = v_u_9.infectionLeft()
		local v861 = v_u_23
		local v862 = v_u_23
		return string.format("left %s bedVol %.2f window %d AudioHeartbeat %s minuteBeats %s", not v860 and "-" or string.format("%.0f", v860), v_u_9.infectionBedVol(), 90, tostring(v861:GetAttribute("AudioHeartbeat")), (tostring(v862:GetAttribute("InfectMinuteBeats"))))
	end)
	v_u_10.command("ears.show", function()
		-- upvalues: (ref) v_u_18
		return not v_u_18 and "no AudioEars" or v_u_18.text()
	end)
	v_u_10.command("ears.trauma", function(p863)
		-- upvalues: (ref) v_u_18
		if not v_u_18 then
			return "no AudioEars"
		end
		local v864 = v_u_18.debugTrauma
		local v865 = p863[1]
		v864(tonumber(v865) or 0)
		return v_u_18.text()
	end)
	v_u_10.command("ears.gear", function(p866)
		-- upvalues: (ref) v_u_18
		if not v_u_18 then
			return "no AudioEars"
		end
		v_u_18.debugGear(p866[1])
		return v_u_18.text()
	end)
	v_u_10.command("ears.shot", function(p867)
		-- upvalues: (ref) v_u_18, (ref) v_u_30
		if not v_u_18 then
			return "no AudioEars"
		end
		local v868 = v_u_18.trauma()
		v_u_18.onShot(p867[1] or "rifle_akm", 0, p867[2] == "sup", true, v_u_30)
		return string.format("trauma %.3f -> %.3f", v868, v_u_18.trauma())
	end)
	v_u_10.command("ears.blast", function(p869)
		-- upvalues: (ref) v_u_9, (ref) v_u_27
		local v870 = v_u_9.explosion
		local v871 = v_u_27
		local v872 = p869[1]
		local v873 = tonumber(v872) or 6
		local v874 = v871 + Vector3.new(v873, 0, 0)
		local v875 = p869[2]
		v870(v874, (tonumber(v875)))
		local v876 = p869[1]
		local v877 = tonumber(v876) or 6
		return "blast at " .. tostring(v877)
	end)
	v_u_10.command("ears.sting", function(p878)
		-- upvalues: (ref) v_u_9
		local v879 = v_u_9.play
		local v880 = {}
		local v881 = p878[1]
		v880.volume = tonumber(v881) or 0.25
		local v882 = v879("ev_tinnitus", v880)
		if v882 then
			v882 = v882.voice
		end
		return (not v882 or (not v882.unit or v882.unit <= 0)) and "skipped" or string.format("played vol %.3f", v882.base / v882.unit)
	end)
	v_u_10.command("audio.hearing", function(p883)
		-- upvalues: (ref) v_u_45, (ref) v_u_9
		local v884 = p883[1]
		if v884 == nil or v884 == "off" then
			v_u_45.override = nil
		else
			local v885 = tonumber(v884)
			if not v885 then
				return "usage: audio.hearing <0..1|off>"
			end
			v_u_45.override = math.clamp(v885, 0, 1)
		end
		v_u_45.readAt = 0
		return string.format("infection %.2f hearing x%.2f%s", v_u_9.infection(), v_u_9.hearing(), v_u_45.override and " (forced)" or "")
	end)
	v_u_10.command("audio.hearcheck", function(p886)
		-- upvalues: (ref) v_u_45, (ref) v_u_9, (ref) v_u_27, (ref) v_u_23, (ref) v_u_15
		local v887 = v_u_45.override
		local v888 = p886[1]
		local v889 = tonumber(v888) or 30
		local v890 = {}
		for _, v891 in { 0, 0.5, 1 } do
			v_u_45.override = v891
			v_u_45.readAt = 0
			v_u_45.lastZ = nil
			v_u_45.lastStep = nil
			v_u_9.zombie("groan", v_u_27 + Vector3.new(v889, 0, 0), "walker", true)
			local v892 = v_u_45.lastZ
			local v893 = v892 and v892.voice
			if v893 then
				v893 = v892.voice.sound
			end
			local v894 = v892 and v892.voice and (v892.voice.base or 0) or 0
			local v895 = v892 and (v892.voice and v892.voice.unit) or 0
			local v896 = v_u_23.Character
			if v896 then
				v_u_9._step(v896, "Concrete", v_u_27, 0.85, false)
			end
			local v897 = v_u_45.lastStep
			local v898 = not (v_u_15 and v_u_15.hearRadii) and "?" or v_u_15.hearRadii(1 + v_u_45.MAX * v891)
			local v899 = string.format
			local v900 = "p=%.2f hearing=x%.2f groan gain=x%.2f (base %.3f) roll=%s..%s | %s | ownStep gain=x%.2f lowpass=%.2f"
			local v901 = v_u_9.hearing()
			local v902 = v895 <= 0 and 0 or v894 / v895
			local v903
			if v893 then
				local v904 = v893.RollOffMinDistance + 0.5
				local v905 = math.floor(v904)
				v903 = tostring(v905)
			else
				v903 = "?"
			end
			local v906
			if v893 then
				local v907 = v893.RollOffMaxDistance + 0.5
				local v908 = math.floor(v907)
				v906 = tostring(v908)
			else
				v906 = "?"
			end
			local v909 = (not v897 or (not v897.voice or v897.voice.unit <= 0)) and -1 or v897.voice.base / v897.voice.unit
			local v910 = not (v897 and v897.voice) and -1 or v897.voice.fixedLowpass
			table.insert(v890, v899(v900, v891, v901, v902, v894, v903, v906, v898, v909, v910))
		end
		v_u_45.override = v887
		v_u_45.readAt = 0
		v_u_9.infection()
		local v911 = table.concat(v890, "\n")
		v_u_23:SetAttribute("AudioHearCheck", v911)
		return v911
	end)
end
function v_u_9.init(p_u_913) -- name: init
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (copy) v_u_9, (ref) v_u_16, (copy) v_u_44, (copy) v_u_131, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (copy) v_u_23, (copy) v_u_912, (ref) v_u_17
	v_u_10 = p_u_913
	v_u_11 = p_u_913.shared.Sounds
	v_u_12 = p_u_913.lib.AudioVoices
	v_u_13 = p_u_913.lib.AudioMusic
	v_u_14 = p_u_913.lib.AudioAmbience
	v_u_15 = p_u_913.lib.AudioWorld
	v_u_9._voices = v_u_12
	v_u_12.init(v_u_11)
	local v914, v_u_915 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.lib.AudioHealth
	end)
	if v914 and type(v_u_915) == "table" then
		v_u_16 = v_u_915
		v_u_915.init(p_u_913.net, p_u_913.config)
		local v_u_916 = v_u_12.play
		function v_u_12.play(p917, p918)
			-- upvalues: (copy) v_u_916, (copy) v_u_915
			local v919 = v_u_916(p917, p918)
			if v919 then
				local v920 = v_u_915.watchHandle
				pcall(v920, v919)
			end
			return v919
		end
	end
	for v921, v922 in v_u_44 do
		local v923 = v_u_12.groups[v921]
		if not v923 then
			continue
		end
		v923.Volume = v922
	end
	v_u_12.setOccluder(v_u_131)
	v_u_13.init(v_u_12, v_u_11)
	v_u_14.init(v_u_12)
	local v924, v925 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.shared.ZombieTypes
	end)
	local v926, v927 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.shared.Weapons
	end)
	local v928 = v_u_9
	if not v926 then
		v927 = nil
	end
	v928._weapons = v927
	local v929 = v_u_15.init
	local v930 = v_u_9
	local v931 = v_u_11
	if not v924 then
		v925 = nil
	end
	v929(v930, v931, v925)
	local v932, v933 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.lib.AudioEars
	end)
	if v932 and type(v933) == "table" then
		local v934 = v933.init
		local v935 = v_u_12
		local v936 = v_u_11
		local v937 = v_u_9._weapons
		local v938, v939 = pcall(v934, p_u_913, v935, v936, v937)
		if v938 then
			v_u_18 = v933
		else
			warn("[HUSH:Audio] AudioEars init failed:", v939)
		end
	end
	local v940, v941 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.lib.AudioLoopGuard
	end)
	if v940 and type(v941) == "table" then
		v_u_19 = v941
		v_u_9._guard = v941
		local v944 = {
			["heartbeatWanted"] = function() -- name: heartbeatWanted
				-- upvalues: (ref) v_u_15
				local v942
				if v_u_15.heartbeatWanted == nil then
					v942 = false
				else
					v942 = v_u_15.heartbeatWanted() == true
				end
				return v942
			end,
			["ringWanted"] = function() -- name: ringWanted
				-- upvalues: (ref) v_u_18
				local v943
				if v_u_18 == nil or v_u_18.ringWanted == nil then
					v943 = false
				else
					v943 = v_u_18.ringWanted() == true
				end
				return v943
			end,
			["resetEars"] = function() -- name: resetEars
				-- upvalues: (ref) v_u_18
				if v_u_18 then
					v_u_18.reset()
				end
			end
		}
		v941.init(p_u_913, v_u_12, v944)
	end
	local v945, v946 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.lib.ClubAudio
	end)
	if v945 and type(v946) == "table" then
		local v947 = v946.init
		local v948 = {
			["guard"] = v_u_19,
			["health"] = v_u_16,
			["audio"] = v_u_9
		}
		local v949, v950 = pcall(v947, p_u_913, v948)
		if v949 and v950 ~= nil then
			v_u_20 = v946
		elseif not v949 then
			warn("[HUSH:Audio] ClubAudio init failed:", v950)
		end
	end
	local v_u_951 = {}
	for v952 in v_u_44 do
		table.insert(v_u_951, v952)
	end
	for _, v_u_953 in v_u_951 do
		local v954 = v_u_23:GetAttribute("Volume_" .. v_u_953)
		if type(v954) == "number" then
			local v955 = v_u_9.setVolume
			if v954 > 1 then
				v954 = v954 / 100
			end
			v955(v_u_953, v954)
		end
		v_u_23:GetAttributeChangedSignal("Volume_" .. v_u_953):Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_953, (ref) v_u_9
			local v956 = v_u_23:GetAttribute("Volume_" .. v_u_953)
			if type(v956) == "number" then
				local v957 = v_u_9.setVolume
				local v958 = v_u_953
				if v956 > 1 then
					v956 = v956 / 100
				end
				v957(v958, v956)
			end
		end)
	end
	local function v_u_968(p959, p960) -- name: applySettings
		-- upvalues: (copy) v_u_968, (copy) v_u_951, (ref) v_u_9
		if type(p959) == "table" and p960 <= 2 then
			local v961 = p959.key
			if type(v961) == "string" and p959.value ~= nil then
				v_u_968({
					[p959.key] = p959.value
				}, p960 + 1)
			end
			local v962 = p959.volumes
			for _, v963 in v_u_951 do
				local v964 = p959[v963 .. "Volume"] or p959["vol" .. v963] or (p959[string.lower(v963) .. "Volume"] or p959["Volume_" .. v963])
				if type(v962) == "table" then
					local v965 = v962[v963]
					if type(v965) == "number" then
						v964 = v962[v963]
					end
				end
				if type(v964) ~= "number" then
					continue
				end
				local v966 = v_u_9.setVolume
				if v964 > 1 then
					v964 = v964 / 100
				end
				v966(v963, v964)
			end
			local v967 = p959.settings
			if type(v967) == "table" then
				v_u_968(p959.settings, p960 + 1)
			end
		end
	end
	p_u_913.on("settings.changed", function(p969)
		-- upvalues: (copy) v_u_968
		v_u_968(p969, 0)
	end)
	v_u_912()
	local v970, v971 = pcall(function()
		-- upvalues: (copy) p_u_913
		return p_u_913.lib.VoiceNoise
	end)
	if v970 and type(v971) == "table" then
		v_u_17 = v971
		local v972 = v971.init
		pcall(v972, p_u_913)
	end
end
local v_u_973 = {}
local function v_u_980(p974) -- name: applyProfileSettings
	-- upvalues: (copy) v_u_44, (copy) v_u_973, (copy) v_u_9
	local v975
	if type(p974) == "table" then
		v975 = p974.profile
	else
		v975 = false
	end
	local v976
	if type(v975) == "table" then
		v976 = v975.settings
	else
		v976 = false
	end
	if type(v976) == "table" then
		for v977 in v_u_44 do
			local v978 = v976[string.lower(v977) .. "Volume"]
			if type(v978) ~= "number" or v_u_973[v977] == v978 then
				continue
			end
			v_u_973[v977] = v978
			local v979 = v_u_9.setVolume
			if v978 > 1 then
				v978 = v978 / 100
			end
			v979(v977, v978)
		end
	end
end
local function v_u_991(p_u_981, p_u_982) -- name: listenRemote
	-- upvalues: (copy) v_u_8
	local v983 = v_u_8:FindFirstChild("HushNet")
	if v983 then
		local v984 = v983:FindFirstChild(p_u_981)
		local v985
		if v984 and v984:IsA("RemoteEvent") then
			v984.OnClientEvent:Connect(function(...)
				-- upvalues: (copy) p_u_982
				local v986 = p_u_982
				pcall(v986, ...)
			end)
			v985 = true
		else
			v985 = false
		end
		if v985 then
			return
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_8, (copy) p_u_981, (copy) p_u_982
		local v987 = v_u_8:WaitForChild("HushNet", 60)
		if v987 then
			for _ = 1, 60 do
				local v988 = v987:FindFirstChild(p_u_981)
				local v989
				if v988 and v988:IsA("RemoteEvent") then
					v988.OnClientEvent:Connect(function(...)
						-- upvalues: (ref) p_u_982
						local v990 = p_u_982
						pcall(v990, ...)
					end)
					v989 = true
				else
					v989 = false
				end
				if v989 then
					return
				end
				task.wait(2)
			end
		end
	end)
end
function v_u_9.start() -- name: start
	-- upvalues: (copy) v_u_108, (ref) v_u_10, (copy) v_u_8, (copy) v_u_450, (copy) v_u_991, (ref) v_u_39, (ref) v_u_13, (copy) v_u_980, (ref) v_u_24, (copy) v_u_23, (copy) v_u_528
	v_u_108()
	task.spawn(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_450
		local v_u_992 = v_u_10.runtime or v_u_8:WaitForChild("HushRuntime", 60)
		if v_u_992 then
			v_u_450(v_u_992:GetAttribute("SoundBlocked"))
			v_u_992:GetAttributeChangedSignal("SoundBlocked"):Connect(function()
				-- upvalues: (ref) v_u_450, (copy) v_u_992
				v_u_450(v_u_992:GetAttribute("SoundBlocked"))
			end)
		end
	end)
	v_u_991("raid.debrief", function()
		-- upvalues: (ref) v_u_39, (ref) v_u_13
		v_u_39 = os.clock()
		v_u_13.set("debrief")
	end)
	v_u_991("menu.state", v_u_980)
	local v_u_993 = ""
	local function v996(p_u_994) -- name: watchCharacter
		-- upvalues: (ref) v_u_993, (ref) v_u_24, (ref) v_u_13
		v_u_993 = ""
		p_u_994:GetAttributeChangedSignal("Action"):Connect(function()
			-- upvalues: (copy) p_u_994, (ref) v_u_993, (ref) v_u_24, (ref) v_u_13
			local v995 = p_u_994:GetAttribute("Action")
			if v995 == "Extract" and (v_u_993 ~= "Extract" and v_u_24 == "Raid") then
				v_u_13.set("extract")
			elseif v_u_993 == "Extract" and (v995 ~= "Extract" and v_u_24 == "Raid") then
				v_u_13.set("auto")
			end
			v_u_993 = type(v995) ~= "string" and "" or v995
		end)
	end
	v_u_23.CharacterAdded:Connect(v996)
	if v_u_23.Character then
		local v_u_997 = v_u_23.Character
		v_u_993 = ""
		v_u_997:GetAttributeChangedSignal("Action"):Connect(function()
			-- upvalues: (copy) v_u_997, (ref) v_u_993, (ref) v_u_24, (ref) v_u_13
			local v998 = v_u_997:GetAttribute("Action")
			if v998 == "Extract" and (v_u_993 ~= "Extract" and v_u_24 == "Raid") then
				v_u_13.set("extract")
			elseif v_u_993 == "Extract" and (v998 ~= "Extract" and v_u_24 == "Raid") then
				v_u_13.set("auto")
			end
			v_u_993 = type(v998) ~= "string" and "" or v998
		end)
	end
	v_u_10.session.onPlaceChanged(function(p999, p1000)
		-- upvalues: (ref) v_u_528
		local v1001 = v_u_528
		local v1002, v1003 = pcall(v1001, p999, p1000)
		if not v1002 then
			warn("[HUSH:Audio] place change failed:", v1003)
		end
	end)
end
function v_u_9.step(p1004) -- name: step
	-- upvalues: (copy) v_u_587, (copy) v_u_197, (ref) v_u_42, (copy) v_u_108, (ref) v_u_32, (copy) v_u_154, (ref) v_u_12, (ref) v_u_27, (ref) v_u_14, (ref) v_u_20, (ref) v_u_24, (ref) v_u_28, (ref) v_u_21, (copy) v_u_173, (ref) v_u_15, (ref) v_u_35, (ref) v_u_34, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19, (ref) v_u_38, (ref) v_u_36, (ref) v_u_37, (ref) v_u_17, (copy) v_u_29, (ref) v_u_33, (copy) v_u_23, (ref) v_u_30, (copy) v_u_65
	local v1005 = os.clock()
	v_u_587()
	v_u_197()
	if v_u_42 <= v1005 then
		v_u_42 = v1005 + 2
		v_u_108()
	end
	if v_u_32 <= v1005 then
		v_u_32 = v1005 + 0.25
		v_u_154()
	end
	v_u_12.step(p1004, v_u_27)
	v_u_14.step(p1004, v_u_27)
	if v_u_20 then
		local v1006 = v_u_20.step
		local v1007 = v_u_27
		local v1008 = v_u_24
		local v1009 = v_u_28
		local v1010, v1011 = pcall(v1006, p1004, v1007, v1008, v1009)
		if not v1010 then
			v_u_20 = nil
			v_u_21 = nil
			warn("[HUSH:Audio] ClubAudio stopped:", v1011)
		end
	end
	v_u_173()
	if v_u_24 == "Raid" or v_u_24 == "Hideout" then
		v_u_15.step(p1004, v_u_27)
	end
	if v_u_35 < v1005 then
		local v1012 = v_u_34 - p1004 * 0.15
		v_u_34 = math.max(0, v1012)
	end
	local v1013 = v_u_15.threat()
	local v1014 = v_u_13.setThreat
	local v1015 = v_u_34
	local v1016 = v_u_34
	local v1017 = math.max(v1013, v1015) + math.min(v1013, v1016) * 0.5
	v1014((math.clamp(v1017, 0, 1)))
	v_u_13.step(p1004)
	if v_u_18 then
		local v1018 = v_u_18.step
		local v1019, v1020 = pcall(v1018, p1004)
		if not v1019 then
			v_u_18 = nil
			warn("[HUSH:Audio] AudioEars stopped:", v1020)
		end
	end
	if v_u_19 then
		local v1021 = v_u_19.step
		local v1022, v1023 = pcall(v1021, p1004)
		if not v1022 then
			v_u_19 = nil
			warn("[HUSH:Audio] AudioLoopGuard stopped:", v1023)
		end
	end
	local v1024 = v_u_38 - p1004 * 0.22
	v_u_38 = math.max(0, v1024)
	local v1025 = v_u_36
	local v1026 = v_u_38
	local v1027 = math.max(v1025, v1026)
	local v1028 = v1027 - v_u_37
	if math.abs(v1028) > 0.005 then
		local v1029 = v_u_37
		local v1030 = v1027 - v_u_37
		local v1031 = p1004 * 4
		v_u_37 = v1029 + v1030 * math.min(1, v1031)
		local v1032 = v_u_12.effects.muffle
		if v1032 then
			v1032.Enabled = v_u_37 > 0.02
			v1032.HighGain = v_u_37 * -32
			v1032.MidGain = v_u_37 * -14
			v1032.LowGain = v_u_37 * 2
		end
	end
	if v_u_17 then
		local v1033 = v_u_17.step
		local v1034 = v_u_29.on and "Transit" or v_u_24
		local v1035, v1036 = pcall(v1033, p1004, v1034)
		if not v1035 then
			v_u_17 = nil
			warn("[HUSH:Audio] VoiceNoise stopped:", v1036)
		end
	end
	if v_u_33 <= v1005 then
		v_u_33 = v1005 + 1
		v_u_23:SetAttribute("AudioMusic", v_u_13.state())
		local v1037 = v_u_23
		local v1038 = v_u_13.threat() * 100
		v1037:SetAttribute("AudioThreat", math.floor(v1038) / 100)
		v_u_23:SetAttribute("AudioIndoor", v_u_30)
		v_u_23:SetAttribute("AudioVoices", v_u_12.activeCount())
		v_u_23:SetAttribute("AudioMusicVoices", v_u_13.busCount())
		v_u_23:SetAttribute("AudioOwnShots", v_u_65.text())
		local v1039 = v_u_23:GetAttribute("OverwatchTarget")
		if v_u_29.on or (v1039 ~= nil or v_u_23:GetAttribute("AudioObserver") ~= nil) then
			local v1040 = v_u_29.mod
			local v1041
			if v1040 and not v_u_29.on then
				local v1042 = v1040.why
				local v1043 = v_u_23:GetAttribute("OverwatchReviewer")
				local v1044 = v_u_23.Character
				if not (v1044 and v1044.Parent) then
					v1044 = nil
				end
				v1041 = v1042(v1039, v1043, v1044 ~= nil)
			else
				v1041 = "ok"
			end
			v_u_23:SetAttribute("AudioObserver", not v1040 and "off" or v1040.status(v_u_29.on == true, v_u_29.ears ~= nil, v1041))
		end
	end
end
v_u_9._test = {
	["blockerWeight"] = v_u_121
}
return v_u_9