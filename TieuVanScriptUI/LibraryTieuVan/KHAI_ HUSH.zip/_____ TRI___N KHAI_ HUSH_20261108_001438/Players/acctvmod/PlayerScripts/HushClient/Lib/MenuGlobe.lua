-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuGlobe

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_6 = require(v_u_5:WaitForChild("Theme"))
local v_u_7 = require(v_u_5:WaitForChild("GlobeGov"))
local v_u_8 = require(v_u_5:WaitForChild("GlobeLayout"))
require(v_u_5:WaitForChild("GlobeText"))
local v_u_9 = require(script.Parent:WaitForChild("HushUI"))
local v_u_10 = v1.LocalPlayer
local v_u_11 = math.floor
local v_u_12 = math.min
local _ = math.max
local v_u_674 = {
	["TUNING"] = {
		["DEBOUNCE_S"] = 0.15,
		["SLIDE_S"] = 0.2,
		["PHASE_A_MAX_S"] = 0.45,
		["PAD_GRAB_S"] = 0.4,
		["PRIME_FRAMES"] = 2,
		["PRIME_BOX_MS"] = 3,
		["ERRORS"] = 3,
		["ERROR_WINDOW_S"] = 10,
		["ATTR_HZ"] = 4,
		["TOUCH_MIN_SIDE"] = 1000,
		["GROUP_SPAN_MIN"] = 1,
		["POP_PAD"] = 14,
		["POP_HEAD"] = 48,
		["POP_MARGIN"] = 12,
		["POP_MAX"] = 760,
		["POP_MIN"] = 200,
		["POP_DIM"] = 0.35,
		["ROW_TEXT"] = "WORLD MAP",
		["ROW_SUB"] = "Open the globe and pick an area",
		["ROW_TAG"] = "OPEN",
		["POP_TITLE"] = "CHOOSE AN AREA"
	},
	["TEST"] = {
		["inject"] = nil
	},
	["lowQuality"] = function() -- name: lowQuality
		local v_u_13 = false
		local function v15()
			-- upvalues: (ref) v_u_13
			local v14 = settings().Rendering.QualityLevel.Value
			if v14 >= 1 and v14 <= 5 then
				v_u_13 = true
			end
		end
		pcall(v15)
		local function v17()
			-- upvalues: (ref) v_u_13
			local v16 = UserSettings():GetService("UserGameSettings").SavedQualityLevel.Value
			if v16 >= 1 and v16 <= 4 then
				v_u_13 = true
			end
		end
		pcall(v17)
		return v_u_13
	end,
	["minSide"] = function(p18, p_u_19) -- name: minSide
		-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_12, (copy) v_u_6
		local v_u_20 = nil
		if v_u_4:IsStudio() then
			local function v21()
				-- upvalues: (ref) v_u_20, (ref) v_u_10
				v_u_20 = v_u_10:GetAttribute("DevViewport")
			end
			pcall(v21)
		end
		if typeof(v_u_20) == "Vector2" and (v_u_20.X > 0 and v_u_20.Y > 0) then
			return v_u_12(v_u_20.X, v_u_20.Y)
		end
		local v_u_22 = 0
		local v23 = v_u_6.viewport
		local v24, v25 = pcall(v23)
		if v24 and (typeof(v25) == "Vector2" and (v25.X > 0 and v25.Y > 0)) then
			local v26 = v_u_12(v25.X, v25.Y)
			local v27 = v_u_22
			v_u_22 = math.max(v27, v26)
		end
		local function v32()
			-- upvalues: (ref) v_u_22, (ref) v_u_12
			local v28 = workspace.CurrentCamera
			if v28 then
				local v29 = v28.ViewportSize
				if typeof(v29) == "Vector2" and (v29.X > 0 and v29.Y > 0) then
					local v30 = v_u_22
					local v31 = v_u_12(v29.X, v29.Y)
					v_u_22 = math.max(v30, v31)
				end
			end
		end
		pcall(v32)
		local function v37()
			-- upvalues: (copy) p_u_19, (ref) v_u_22, (ref) v_u_12
			local v33 = p_u_19 and p_u_19:FindFirstAncestorWhichIsA("ScreenGui")
			if v33 then
				local v34 = v33.AbsoluteSize
				if typeof(v34) == "Vector2" and (v34.X > 0 and v34.Y > 0) then
					local v35 = v_u_22
					local v36 = v_u_12(v34.X, v34.Y)
					v_u_22 = math.max(v35, v36)
				end
			end
		end
		pcall(v37)
		return v_u_22 <= 0 and (p18 or 1000) or v_u_22
	end,
	["hardware"] = function(p38) -- name: hardware
		-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_674, (copy) v_u_4, (copy) v_u_6
		local v_u_39 = {
			["tenFoot"] = false,
			["touch"] = false,
			["accel"] = false,
			["minSide"] = 1000,
			["realTouch"] = false,
			["realAccel"] = false,
			["simulated"] = false
		}
		local function v40()
			-- upvalues: (copy) v_u_39, (ref) v_u_2
			v_u_39.tenFoot = v_u_2:IsTenFootInterface()
		end
		pcall(v40)
		local function v41()
			-- upvalues: (copy) v_u_39, (ref) v_u_3
			v_u_39.touch = v_u_3.TouchEnabled
		end
		pcall(v41)
		local function v42()
			-- upvalues: (copy) v_u_39, (ref) v_u_3
			v_u_39.accel = v_u_3.AccelerometerEnabled
		end
		pcall(v42)
		local v43 = v_u_39.touch
		local v44 = v_u_39.accel
		v_u_39.realTouch = v43
		v_u_39.realAccel = v44
		v_u_39.minSide = v_u_674.minSide(v_u_39.minSide, p38)
		if not (v_u_39.touch and v_u_39.accel) and v_u_4:IsStudio() then
			local v45 = v_u_6.isTouch
			local v46, v47 = pcall(v45)
			if v46 and v47 == true then
				v_u_39.touch = true
				v_u_39.accel = true
				v_u_39.simulated = true
			end
		end
		v_u_39.lowQuality = v_u_674.lowQuality()
		return v_u_39
	end,
	["topbarLeftW"] = function() -- name: topbarLeftW
		-- upvalues: (copy) v_u_2, (copy) v_u_6
		local v_u_48 = 0
		local function v49()
			-- upvalues: (ref) v_u_48, (ref) v_u_2
			v_u_48 = v_u_2.TopbarInset.Min.X
		end
		pcall(v49)
		v_u_48 = v_u_48 <= 0 and 120 or v_u_48
		if v_u_6.isPhone() then
			v_u_48 = v_u_48 + 120
		end
		local v50 = v_u_48 / v_u_6.uiScale()
		return math.ceil(v50) + 12
	end,
	["attach"] = function(p_u_51, p_u_52, p_u_53, p54) -- name: attach
		-- upvalues: (copy) v_u_674, (copy) v_u_5, (copy) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_11, (copy) v_u_2, (copy) v_u_3
		local v55 = os.clock()
		local v_u_56 = p54 or {}
		local v_u_57 = v_u_674.TUNING
		local v_u_58 = script.Parent
		local v_u_59 = {}
		local v_u_60 = {}
		local v_u_61 = {
			["alive"] = true,
			["built"] = false,
			["shown"] = false,
			["off"] = nil,
			["gen"] = 0,
			["errs"] = nil,
			["mode"] = "stage",
			["solved"] = nil,
			["fit"] = nil,
			["D"] = 0,
			["kind"] = "pc",
			["tier"] = "high",
			["env"] = nil,
			["layoutTok"] = 0,
			["attrAt"] = 0,
			["attrLast"] = "",
			["dotsOn"] = false,
			["tAttach"] = 0,
			["built0"] = 0,
			["phoneOn"] = nil,
			["forceTable"] = nil,
			["row"] = nil,
			["table"] = nil,
			["prevMode"] = nil,
			["open"] = false,
			["pop"] = nil,
			["wm"] = nil,
			["escConn"] = nil,
			["fromPad"] = false,
			["errs"] = {
				["sync"] = {},
				["pick"] = {}
			}
		}
		local v_u_62 = "GlobePhone"
		local function v63()
			-- upvalues: (ref) v_u_5, (copy) v_u_62
			return require(v_u_5:WaitForChild("Config")).flag(v_u_62)
		end
		local v64, v65 = pcall(v63)
		if not v64 then
			v65 = nil
		end
		v_u_61.phoneOn = v65 ~= false
		p_u_51.globeState = p_u_51.globeState or {}
		local v_u_66 = p_u_51.globeState
		local v_u_67 = nil
		local v_u_68 = nil
		local v_u_69 = nil
		local function v_u_75() -- name: switchOn
			-- upvalues: (ref) v_u_5, (ref) v_u_10
			local v70 = false
			local v_u_71 = "GlobeMap"
			local function v72()
				-- upvalues: (ref) v_u_5, (copy) v_u_71
				return require(v_u_5:WaitForChild("Config")).flag(v_u_71)
			end
			local v73, v74 = pcall(v72)
			if not v73 then
				v74 = nil
			end
			if v74 ~= false then
				v70 = v_u_10:GetAttribute("GlobeOff") == nil
			end
			return v70
		end
		local function v_u_84(p76, p77, p78, p79) -- name: setStage
			-- upvalues: (copy) p_u_51
			local v80 = p_u_51.scene
			local v81, v82 = pcall(v80)
			if not v81 then
				v82 = nil
			end
			if v82 and v82.setGlobeStage then
				local v83 = v82.setGlobeStage
				pcall(v83, v82, p76, p77, p78, p79)
			end
		end
		local function v_u_91() -- name: windowOpenNow
			-- upvalues: (copy) p_u_51
			for _, v_u_85 in { "MenuMail", "MenuInsure", "MenuGift" } do
				local function v88()
					-- upvalues: (ref) p_u_51, (copy) v_u_85
					local v86 = p_u_51.cctx.lib[v_u_85]
					if v86 then
						local v87 = v86.isOpen
						if type(v87) == "function" then
							v86 = v86.isOpen() == true
						else
							v86 = false
						end
					end
					return v86
				end
				local v89, v90 = pcall(v88)
				if not (v89 and v90) then
					continue
				end
				return true
			end
			return false
		end
		local v_u_92 = nil
		local function v_u_109() -- name: tableEnv
			-- upvalues: (copy) p_u_51, (copy) v_u_56, (copy) v_u_66, (copy) v_u_61, (ref) v_u_5, (ref) v_u_10, (copy) v_u_91, (ref) v_u_9, (copy) v_u_60, (ref) v_u_674
			return {
				["mc"] = p_u_51,
				["hooks"] = v_u_56,
				["session"] = v_u_66,
				["tier"] = function() -- name: tier
					-- upvalues: (ref) v_u_61
					return v_u_61.tier
				end,
				["switchOn"] = function() -- name: switchOn
					-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_61
					local v93 = false
					local v_u_94 = "GlobeMap"
					local function v95()
						-- upvalues: (ref) v_u_5, (copy) v_u_94
						return require(v_u_5:WaitForChild("Config")).flag(v_u_94)
					end
					local v96, v97 = pcall(v95)
					if not v96 then
						v97 = nil
					end
					if v97 ~= false then
						v93 = v_u_10:GetAttribute("GlobeOff") == nil
					end
					if v93 then
						v93 = v_u_61.phoneOn ~= false
					end
					return v93
				end,
				["windowOpen"] = v_u_91,
				["modal"] = function() -- name: modal
					-- upvalues: (ref) v_u_9
					local v98 = v_u_9.modalCount
					local v99, v100 = pcall(v98)
					if v99 then
						if type(v100) == "number" then
							v99 = v100 > 0
						else
							v99 = false
						end
					end
					return v99
				end,
				["frozenWhy"] = function() -- name: frozenWhy
					-- upvalues: (ref) v_u_56
					if v_u_56.frozen then
						local v101 = v_u_56.frozen
						local v102, v103, v104 = pcall(v101)
						if v102 and v103 then
							return v104
						end
					end
					return nil
				end,
				["pick"] = function(p105) -- name: pick
					-- upvalues: (ref) v_u_60
					return v_u_60.pick(p105)
				end,
				["topLeftW"] = v_u_674.topbarLeftW,
				["topInset"] = v_u_9.topInset,
				["onFatal"] = function(p106, p107, p108) -- name: onFatal
					-- upvalues: (ref) v_u_60
					task.defer(v_u_60.detach, p106, tostring(p107), p108)
				end
			}
		end
		local function v_u_135() -- name: setupTable
			-- upvalues: (copy) v_u_61, (ref) v_u_92, (copy) v_u_58, (copy) v_u_56, (copy) v_u_109, (ref) v_u_10
			local v110 = v_u_61.alive and not v_u_61.off
			if v110 then
				v110 = v_u_61.phoneOn ~= false
			end
			if v110 then
				if v_u_61.row and v_u_61.table then
					return
				else
					local v_u_111
					if v_u_92 then
						v_u_111 = v_u_92
					else
						local function v112()
							-- upvalues: (ref) v_u_58
							return require(v_u_58:WaitForChild("GlobeTable"))
						end
						local v113, v114 = pcall(v112)
						if v113 then
							v_u_92 = v114
						else
							local v115 = "GlobeTable: " .. tostring(v114)
							warn("[globe] " .. v115)
						end
						v_u_111 = v_u_92
					end
					if v_u_111 then
						local function v119()
							-- upvalues: (ref) v_u_56, (ref) v_u_61, (copy) v_u_111, (ref) v_u_109
							local v116
							if v_u_56.opCard then
								v116 = v_u_56.opCard:FindFirstChild("MapArt", true)
							else
								v116 = nil
							end
							local v117
							if v116 then
								v117 = v116.Parent
							else
								v117 = nil
							end
							if not v117 then
								error("no operation card")
							end
							v_u_61.table = v_u_111.new((v_u_109()))
							local v118 = {
								["op"] = nil,
								["art"] = nil,
								["order"] = 6,
								["hooks"] = nil,
								["open"] = nil,
								["op"] = v117,
								["art"] = v116,
								["hooks"] = v_u_56,
								["open"] = function() -- name: open
									-- upvalues: (ref) v_u_61
									if v_u_61.table and (v_u_61.alive and not v_u_61.off) then
										v_u_61.table.open()
									end
								end
							}
							v_u_61.row = v_u_111.row(v118)
							if not (v_u_61.row and v_u_61.table) then
								error("no row")
							end
						end
						local v120, v_u_121 = pcall(v119)
						if v120 then
							if v_u_61.shown then
								v_u_61.row.show()
							end
						else
							local v122 = "table setup failed: " .. tostring(v_u_121)
							warn("[globe] " .. v122)
							local v123 = v_u_61.row
							local v124 = v_u_61.table
							local v125 = v_u_61
							v_u_61.row = nil
							v125.table = nil
							if v124 then
								local v126 = v124.destroy
								pcall(v126)
							end
							if v123 then
								local v127 = v123.destroy
								pcall(v127)
							end
							local function v129()
								-- upvalues: (ref) v_u_10, (copy) v_u_121
								local v128 = v_u_121
								v_u_10:SetAttribute("ClientError", "globe: table " .. tostring(v128))
							end
							pcall(v129)
						end
					else
						return
					end
				end
			else
				local v130 = v_u_61.row
				local v131 = v_u_61.table
				local v132 = v_u_61
				v_u_61.row = nil
				v132.table = nil
				if v131 then
					local v133 = v131.destroy
					pcall(v133)
				end
				if v130 then
					local v134 = v130.destroy
					pcall(v134)
				end
				return
			end
		end
		local function v_u_150() -- name: measure
			-- upvalues: (ref) v_u_6, (copy) p_u_52, (copy) v_u_56, (copy) v_u_61, (copy) p_u_53, (ref) v_u_9, (ref) v_u_674
			local v136 = v_u_6.uiScale()
			local v137 = p_u_52.AbsoluteSize
			local v138 = v_u_6.safeRefSize
			local v139, v140 = pcall(v138)
			if not v139 or typeof(v140) ~= "Vector2" then
				v140 = v_u_6.refSize()
			end
			local v141 = v_u_56.compact == true
			local v142 = {
				["compact"] = v141,
				["phone"] = v_u_6.isPhone() == true and true or v_u_61.forceTable == true
			}
			if v137.X > 8 and v137.Y > 8 then
				local v143 = v137.X / v136
				local v144 = v137.Y / v136
				v142.pageW = v143
				v142.pageH = v144
			else
				local v145 = v140.X
				local v146 = v140.Y - (v141 and 64 or 120) - 30
				v142.pageW = v145
				v142.pageH = v146
			end
			local v147 = p_u_53.rail
			if v147 then
				v147 = p_u_53.rail.frame
			end
			if v147 and v147.AbsoluteSize.X > 8 then
				v142.railW = v147.AbsoluteSize.X / v136
			end
			local v148 = v_u_56.plate
			if v148 and v148.AbsoluteSize.Y > 8 then
				v142.plateH = v148.AbsoluteSize.Y / v136
			end
			local v149 = v_u_56.colW
			if type(v149) == "number" then
				v142.colW = v_u_56.colW
			end
			v142.topInset = v_u_9.topInset()
			v142.topLeftW = v_u_674.topbarLeftW()
			return v142
		end
		local function v_u_164(p151) -- name: applyLayout
			-- upvalues: (copy) v_u_61, (ref) v_u_8, (copy) v_u_150, (ref) v_u_6, (copy) v_u_60, (copy) p_u_51, (copy) v_u_135, (ref) v_u_674, (copy) p_u_52
			if v_u_61.alive and not v_u_61.off then
				local v152 = v_u_8.solve((v_u_150()))
				v_u_61.solved = v152
				v_u_6.uiScale()
				v_u_61.mode = v152.mode
				if v152.mode == "stage" then
					if v_u_61.row or v_u_61.table then
						local v153 = v_u_61.row
						local v154 = v_u_61.table
						local v155 = v_u_61
						v_u_61.row = nil
						v155.table = nil
						if v154 then
							local v156 = v154.destroy
							pcall(v156)
						end
						if v153 then
							local v157 = v153.destroy
							pcall(v157)
						end
					end
					v_u_61.prevMode = nil
					if not (v_u_61.built or p151) then
						local v158, v159 = v_u_60.build(v152)
						if not v158 then
							v_u_60.detach("error", "build", v159)
							return
						end
					end
					if v_u_61.built then
						if v_u_61.env then
							v_u_61.env.minSide = v_u_674.minSide(v_u_61.env.minSide, p_u_52)
						end
						v_u_60.rowSync()
						if v_u_61.open then
							v_u_60.layoutPopup()
						end
					else
						v_u_60.rowSync()
					end
				else
					v_u_60.shut()
					local v160 = p_u_51.scene
					local v161, v162 = pcall(v160)
					if not v161 then
						v162 = nil
					end
					if v162 and v162.setGlobeStage then
						local v163 = v162.setGlobeStage
						pcall(v163, v162, nil, nil, nil, nil)
					end
					v_u_61.prevMode = "table"
					v_u_135()
					v_u_60.rowSync()
					return
				end
			else
				return
			end
		end
		local function v_u_171() -- name: scheduleLayout
			-- upvalues: (copy) v_u_61, (copy) v_u_57, (copy) v_u_164
			local v165 = v_u_61
			v165.layoutTok = v165.layoutTok + 1
			local v_u_166 = v_u_61.layoutTok
			task.delay(v_u_57.DEBOUNCE_S, function()
				-- upvalues: (ref) v_u_61, (copy) v_u_166, (ref) v_u_164
				if v_u_61.alive and v_u_166 == v_u_61.layoutTok then
					local v167 = v_u_164
					local v168, v169 = pcall(v167)
					if not v168 then
						local v170 = "layout: " .. tostring(v169)
						warn("[globe] " .. v170)
					end
				end
			end)
		end
		local function v_u_205(p172) -- name: writeAttr
			-- upvalues: (copy) v_u_61, (copy) v_u_57, (copy) v_u_60, (ref) v_u_10
			local v173 = os.clock()
			if p172 or v173 - v_u_61.attrAt >= 1 / v_u_57.ATTR_HZ then
				v_u_61.attrAt = v173
				local v174 = v_u_60.view
				local v175 = v_u_60.dots
				local v176
				if v174 and v_u_61.built then
					local v177 = v175 and (v175.stats and v175.stats()) or nil
					local v178 = v174.stateText()
					local v179, v180 = string.match(v178, "pins=(%d+) clusters=(%d+)")
					local v181, v182, v183 = string.match(v178, "lat=([%-%d%.]+) lon=([%-%d%.]+) z=([%d%.]+)")
					local v184 = string.format
					local v185 = v_u_61.mode
					local v186 = v_u_61.tier
					local v187 = tostring(v181)
					local v188 = tostring(v182)
					local v189 = tostring(v183)
					local v190 = v177 and (v177.visible or 0) or 0
					local v191 = tostring(v190)
					local v192 = tostring(v179)
					local v193 = tostring(v180)
					local v194 = v_u_61.open
					local v195 = tostring(v194)
					local v196 = (v177 and v177.quality or 1) * 100 + 0.5
					v176 = v184("mode=%s tier=%s lat=%s lon=%s z=%s dots=%s pins=%s clusters=%s open=%s quality=%d", v185, v186, v187, v188, v189, v191, v192, v193, v195, (math.floor(v196)))
				else
					local v197 = v_u_61.mode
					local v198 = tostring(v197)
					local v199 = v_u_61.off
					v176 = "mode=" .. v198 .. " off=" .. tostring(v199) .. " open=false"
					if v_u_61.mode ~= "stage" then
						local v200 = " row="
						local v201 = v_u_61.row ~= nil
						local v202 = tostring(v201)
						local v203 = " table="
						local v204
						if v_u_61.table == nil then
							v204 = false
						else
							v204 = v_u_61.table.isOpen()
						end
						v176 = v176 .. v200 .. v202 .. v203 .. tostring(v204)
					end
				end
				if v176 ~= v_u_61.attrLast or v_u_10:GetAttribute("MenuGlobe") ~= v176 then
					v_u_61.attrLast = v176
					v_u_10:SetAttribute("MenuGlobe", v176)
				end
			end
		end
		function v_u_60.build(p_u_206) -- name: build
			-- upvalues: (ref) v_u_67, (copy) v_u_58, (ref) v_u_68, (ref) v_u_69, (copy) v_u_61, (ref) v_u_674, (copy) p_u_52, (ref) v_u_7, (copy) v_u_57, (ref) v_u_11, (copy) v_u_60, (copy) v_u_56, (ref) v_u_9, (copy) v_u_91, (copy) v_u_66, (copy) v_u_75, (copy) p_u_51
			local function v207()
				-- upvalues: (ref) v_u_67, (ref) v_u_58, (ref) v_u_68, (ref) v_u_69
				v_u_67 = require(v_u_58:WaitForChild("GlobeView"))
				v_u_68 = require(v_u_58:WaitForChild("GlobeInput"))
				v_u_69 = require(v_u_58:WaitForChild("GlobeDots"))
			end
			local v208, v209 = pcall(v207)
			local v210 = v209
			if not v208 then
				return false, v210
			end
			local v211 = v_u_61.env or v_u_674.hardware()
			v_u_61.env = v211
			v211.minSide = v_u_674.minSide(v211.minSide, p_u_52)
			v_u_61.tier = v_u_7.tierOf(v211)
			local v_u_212 = Instance.new("Folder")
			v_u_212.Name = "GlobeBuild"
			local v_u_213 = nil
			local v_u_214 = nil
			local function v266()
				-- upvalues: (ref) v_u_57, (copy) p_u_206, (ref) v_u_11, (ref) v_u_61, (ref) v_u_674, (ref) v_u_60, (ref) v_u_56, (ref) v_u_9, (ref) v_u_213, (ref) v_u_68, (ref) v_u_91, (ref) v_u_66, (ref) v_u_214, (ref) v_u_67, (copy) v_u_212, (ref) v_u_69, (ref) v_u_75, (ref) p_u_51
				local v215 = v_u_57.POP_MIN
				local v216 = v_u_11(p_u_206.D)
				local v217 = math.max(v215, v216)
				local v218 = v_u_61.env or v_u_674.hardware()
				local v219 = v218.touch and v218.minSide < v_u_57.TOUCH_MIN_SIDE and "tablet" or "pc"
				local v220 = v_u_61
				local v221 = v_u_61
				local v222 = v_u_61
				v_u_61.D = v217
				v220.kind = v219
				v221.gx = 0
				v222.gy = 0
				local function v227() -- name: listFn
					-- upvalues: (ref) v_u_61, (ref) v_u_60, (ref) v_u_56, (ref) v_u_9
					if v_u_61.open then
						v_u_60.close(false)
					end
					if not v_u_56.list then
						return nil
					end
					local v223 = v_u_9.device
					local v224, v225 = pcall(v223)
					local v226 = v_u_56.list
					if v224 then
						v224 = v225 == "Gamepad"
					end
					return v226(v224)
				end
				local v235 = {
					["kind"] = v219,
					["list"] = v227,
					["pageVisible"] = function() -- name: pageVisible
						-- upvalues: (ref) v_u_61
						return v_u_61.open
					end,
					["windowOpen"] = v_u_91,
					["blockRects"] = function() -- name: blockRects
						-- upvalues: (ref) v_u_61
						local v228 = {}
						local v229 = v_u_61.pop
						if v229 then
							v229 = v_u_61.pop.head
						end
						local v230 = v229 and (v229.Parent and v229.Visible) and {
							["x"] = v229.AbsolutePosition.X,
							["y"] = v229.AbsolutePosition.Y,
							["w"] = v229.AbsoluteSize.X,
							["h"] = v229.AbsoluteSize.Y
						} or nil
						if v230 then
							table.insert(v228, v230)
						end
						return v228
					end,
					["scrollRects"] = function() -- name: scrollRects
						return {}
					end,
					["hooks"] = {
						["onBack"] = function(p231) -- name: onBack
							-- upvalues: (ref) v_u_9, (ref) v_u_61, (ref) v_u_60
							if p231 then
								v_u_9.takeBack()
								return
							elseif v_u_61.open then
								local v232 = v_u_9.modalCount
								local v233, v234 = pcall(v232)
								if not v233 or (type(v234) ~= "number" or v234 <= 0) then
									v_u_9.takeBack()
									task.defer(v_u_60.closeBack)
								end
							else
								return
							end
						end
					}
				}
				v_u_213 = v_u_68.new(v235)
				local v236 = v_u_66.lat0
				local v237 = type(v236) == "number" and {
					["lat0"] = v_u_66.lat0,
					["lon0"] = v_u_66.lon0,
					["z"] = v_u_66.z
				} or nil
				v_u_214 = v_u_67.new(v_u_212, {
					["kind"] = nil,
					["D"] = nil,
					["tier"] = nil,
					["position"] = nil,
					["pins"] = nil,
					["pick"] = nil,
					["list"] = nil,
					["makeDots"] = nil,
					["justDragged"] = nil,
					["padOwns"] = nil,
					["inputKind"] = nil,
					["keyName"] = nil,
					["state"] = nil,
					["session"] = nil,
					["noIntro"] = true,
					["modal"] = nil,
					["switchOn"] = nil,
					["govTripped"] = nil,
					["onFatal"] = nil,
					["onState"] = nil,
					["frozenWhy"] = nil,
					["deployGeo"] = nil,
					["kind"] = v219,
					["D"] = v217,
					["tier"] = v_u_61.tier,
					["position"] = UDim2.fromOffset(0, 0),
					["pins"] = v_u_56.pins,
					["pick"] = function(p238) -- name: pick
						-- upvalues: (ref) v_u_60
						return v_u_60.pick(p238)
					end,
					["list"] = v227,
					["makeDots"] = function(p239, p240) -- name: makeDots
						-- upvalues: (ref) v_u_69, (ref) v_u_61, (ref) v_u_67
						local v241 = v_u_69.new(p239, {
							["lensR"] = p240.lensR,
							["cx"] = p240.cx,
							["cy"] = p240.cy,
							["tier"] = v_u_61.tier,
							["reduced"] = v_u_67.Motion.reduced
						})
						v_u_61.dotsObj = v241
						return v241
					end,
					["justDragged"] = v_u_213.justDragged,
					["padOwns"] = v_u_213.padOwns,
					["inputKind"] = v_u_213.inputKind,
					["keyName"] = v_u_213.keyName,
					["state"] = v237,
					["session"] = v_u_66,
					["modal"] = function() -- name: modal
						-- upvalues: (ref) v_u_9
						local v242 = v_u_9.modalCount
						local v243, v244 = pcall(v242)
						if v243 then
							if type(v244) == "number" then
								v243 = v244 > 0
							else
								v243 = false
							end
						end
						return v243
					end,
					["switchOn"] = v_u_75,
					["govTripped"] = function() -- name: govTripped
						-- upvalues: (ref) v_u_60
						local v245 = v_u_60.dots
						if not (v245 and (v245.gov and v245.gov.degraded)) then
							return false
						end
						local v246 = v245.gov.degraded
						local v247 = v245.gov
						local v248, v249 = pcall(v246, v247)
						if v248 then
							v248 = v249 == true
						end
						return v248
					end,
					["onFatal"] = function(p250, p251) -- name: onFatal
						-- upvalues: (ref) v_u_60
						task.defer(v_u_60.detach, "error", tostring(p250), p251)
					end,
					["onState"] = function(p252) -- name: onState
						-- upvalues: (ref) v_u_66
						if type(p252) == "table" then
							local v253 = v_u_66
							local v254 = v_u_66
							local v255 = v_u_66
							local v256 = p252.lat0
							local v257 = p252.lon0
							local v258 = p252.z
							v253.lat0 = v256
							v254.lon0 = v257
							v255.z = v258
						end
					end,
					["frozenWhy"] = function() -- name: frozenWhy
						-- upvalues: (ref) v_u_56
						if v_u_56.frozen then
							local v259 = v_u_56.frozen
							local v260, v261, v262 = pcall(v259)
							if v260 and v261 then
								return v262
							end
						end
						return nil
					end
				})
				if v_u_674.TEST.inject == "body" then
					error("injected after the body")
				end
				v_u_214.sync()
				if v_u_674.TEST.inject == "pins" then
					error("injected after the pins")
				end
				if v_u_674.TEST.inject == "input" then
					function v_u_213.attach()
						error("injected inside GlobeInput.attach")
					end
				end
				v_u_213.attach(v_u_214)
				v_u_61.pop = v_u_60.makePopup(v_u_212)
				v_u_214.root.Parent = v_u_61.pop.body
				v_u_214.root.Position = UDim2.fromOffset(0, 0)
				v_u_60.linkPad(v_u_214)
				local v263 = p_u_51.cctx.command
				if v263 then
					local v264 = v_u_214.commands
					pcall(v264, v263)
					local v265 = v_u_213.commands
					pcall(v265, v263)
				end
				v_u_214.dotsLayer.Visible = false
			end
			local v268, v269 = xpcall(v266, function(p267)
				return tostring(p267) .. "\n" .. debug.traceback()
			end)
			if not v268 then
				local function v270()
					-- upvalues: (ref) v_u_214
					if v_u_214 and v_u_214.destroy then
						v_u_214.destroy()
					end
				end
				pcall(v270)
				local function v271()
					-- upvalues: (ref) v_u_213
					if v_u_213 and v_u_213.destroy then
						v_u_213.destroy()
					end
				end
				pcall(v271)
				v_u_61.pop = nil
				v_u_212:Destroy()
				return false, v269
			end
			v_u_61.pop.back.Parent = p_u_52
			v_u_212:Destroy()
			local v272 = v_u_60
			local v273 = v_u_60
			local v274 = v_u_60
			local v275 = v_u_61.dotsObj
			v272.view = v_u_214
			v273.input = v_u_213
			v274.dots = v275
			v_u_61.built = true
			v_u_61.built0 = os.clock()
			return true, nil
		end
		function v_u_60.makePopup(p276) -- name: makePopup
			-- upvalues: (ref) v_u_674, (ref) v_u_6, (ref) v_u_9, (copy) v_u_60
			local v277 = v_u_674.TUNING
			local v278 = v_u_6.color
			local v279 = v_u_9.new("TextButton", {
				["Name"] = "GlobePopup",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 40,
				["Selectable"] = false,
				["Active"] = true,
				["Visible"] = false,
				["BackgroundColor3"] = Color3.new(0, 0, 0),
				["BackgroundTransparency"] = v277.POP_DIM,
				["Size"] = UDim2.fromScale(1, 1)
			}, p276)
			local v280 = v_u_9.new("Frame", {
				["Name"] = "PopupFrame",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.02,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["BackgroundColor3"] = v278.bg,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(400, 400)
			}, v279)
			v_u_9.stroke(v280, v278.lineStrong)
			v_u_9.new("TextButton", {
				["Name"] = "Sink",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 1,
				["Selectable"] = false,
				["Active"] = true,
				["Size"] = UDim2.fromScale(1, 1)
			}, v280)
			local v281 = v_u_9.new("Frame", {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Size"] = UDim2.new(1, 0, 0, v277.POP_HEAD)
			}, v280)
			v_u_9.new("Frame", {
				["Name"] = "Accent",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v278.accent,
				["Size"] = UDim2.new(1, 0, 0, 2)
			}, v280)
			v_u_9.label({
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["zindex"] = 3,
				["parent"] = v281,
				["text"] = v277.POP_TITLE,
				["color"] = v278.text2,
				["position"] = UDim2.fromOffset(v277.POP_PAD + 2, 0),
				["size"] = UDim2.new(1, -(v277.POP_PAD + 70), 1, 0)
			})
			local v282 = v_u_9.closeIcon({
				["parent"] = nil,
				["name"] = "PopupClose",
				["size"] = 40,
				["anchor"] = nil,
				["position"] = nil,
				["tooltip"] = "Close",
				["onClick"] = nil,
				["parent"] = v281,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -8, 0.5, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_60
					v_u_60.close(true)
				end
			})
			v282.ZIndex = 4
			local v283 = v_u_9.new("Frame", {
				["Name"] = "Body",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Position"] = UDim2.fromOffset(v277.POP_PAD, v277.POP_HEAD),
				["Size"] = UDim2.fromOffset(200, 200)
			}, v280)
			v279.Activated:Connect(function()
				-- upvalues: (ref) v_u_60
				v_u_60.close(true)
			end)
			return {
				["back"] = v279,
				["frame"] = v280,
				["head"] = v281,
				["body"] = v283,
				["x"] = v282
			}
		end
		function v_u_60.linkPad(p284) -- name: linkPad
			-- upvalues: (copy) v_u_61, (ref) v_u_9
			local v285 = v_u_61.pop
			if v285 and (p284 and p284.focus) then
				local v286 = p284.focus
				local v287 = v285.x
				v286.NextSelectionLeft = v286
				v286.NextSelectionRight = v287
				v287.NextSelectionLeft = v286
				v287.NextSelectionDown = v286
				v287.NextSelectionUp = v287
				v287.NextSelectionRight = v287
				v287.SelectionImageObject = v_u_9.selectionImage()
			end
		end
		function v_u_60.popupHost() -- name: popupHost
			-- upvalues: (copy) p_u_52
			local v288 = p_u_52.Parent
			while v288 and not v288:IsA("LayerCollector") do
				if v288:FindFirstChildOfClass("UIScale") then
					return v288
				end
				v288 = v288.Parent
			end
			return p_u_52
		end
		function v_u_60.layoutPopup() -- name: layoutPopup
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (ref) v_u_674, (ref) v_u_6, (copy) p_u_52, (ref) v_u_11, (copy) v_u_57
			local v289 = v_u_61.pop
			local v290 = v_u_60.view
			if v289 and v290 then
				local v291 = v_u_674.TUNING
				local v292 = v_u_6.uiScale()
				local v293 = v_u_60.popupHost()
				if v289.back.Parent ~= v293 then
					v289.back.Parent = v293
				end
				if v293 == p_u_52 then
					v289.frame.Position = UDim2.fromScale(0.5, 0.5)
				else
					local v294 = (p_u_52.AbsolutePosition + p_u_52.AbsoluteSize / 2 - v289.back.AbsolutePosition) / v292
					v289.frame.Position = UDim2.fromOffset(v_u_11(v294.X), (v_u_11(v294.Y)))
				end
				local v295 = p_u_52.AbsoluteSize
				local v296 = v295.X / v292
				local v297 = v295.Y / v292
				if v295.X < 8 or v295.Y < 8 then
					local v298 = v_u_6.refSize()
					v296 = v298.X
					v297 = v298.Y - 150
				end
				local v299 = v297 - 2 * v291.POP_MARGIN - v291.POP_HEAD - v291.POP_PAD * 2
				local v300 = v296 - 2 * v291.POP_MARGIN - v291.POP_PAD * 2
				local v301 = v291.POP_MAX
				local v302 = v_u_11((math.min(v299, v300, v301)))
				local v303 = v291.POP_MIN
				local v304 = math.max(v303, v302)
				v289.frame.Size = UDim2.fromOffset(v304 + v291.POP_PAD * 2, v304 + v291.POP_PAD * 2 + v291.POP_HEAD)
				v289.body.Size = UDim2.fromOffset(v304, v304)
				v290.root.Position = UDim2.fromOffset(0, 0)
				if v_u_61.env then
					v_u_61.env.minSide = v_u_674.minSide(v_u_61.env.minSide, p_u_52)
				end
				local v305 = v_u_61.env or v_u_674.hardware()
				local v306 = v305.touch and v305.minSide < v_u_57.TOUCH_MIN_SIDE and "tablet" or "pc"
				if v304 ~= v_u_61.D or v306 ~= v_u_61.kind then
					local v307 = v_u_61
					v_u_61.D = v304
					v307.kind = v306
					local v308 = v290.setSize
					pcall(v308, v304, v306)
				end
				local v309 = v_u_61
				v_u_61.gx = 0
				v309.gy = 0
				if v289.x then
					v289.x.Size = UDim2.fromOffset(v_u_6.touch(40), v_u_6.touch(40))
				end
			end
		end
		local function v_u_318() -- name: padGrab
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (ref) v_u_9, (ref) v_u_2
			if v_u_61.alive and (not v_u_61.off and (v_u_61.open and (v_u_60.view and (v_u_60.view.focus and v_u_61.pop)))) then
				local v310 = v_u_9.device
				local v311, v312 = pcall(v310)
				if v311 and v312 == "Gamepad" then
					local v313 = v_u_9.modalCount
					local v314, v315 = pcall(v313)
					if not v314 or (type(v315) ~= "number" or v315 <= 0) then
						local v316 = v_u_2.SelectedObject
						local v317 = v_u_60.view.focus
						if (v316 == nil or not v316:IsDescendantOf(v_u_61.pop.back)) and (v317.Selectable and v317.Visible) then
							v_u_2.SelectedObject = v317
						end
					end
				else
					return
				end
			else
				return
			end
		end
		v_u_60.padGrab = v_u_318
		function v_u_60.showNow() -- name: showNow
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (copy) v_u_164, (copy) v_u_318, (copy) v_u_57, (copy) p_u_52, (copy) v_u_66, (copy) v_u_205
			local v319 = v_u_61
			v319.gen = v319.gen + 1
			local v_u_320 = v_u_61.gen
			local v_u_321 = v_u_60.view
			local v_u_322 = v_u_321.dotsLayer
			v_u_322.Visible = false
			v_u_61.dotsOn = false
			v_u_164()
			v_u_321.show({
				["noIntro"] = true
			})
			local v_u_323 = os.clock()
			v_u_61.tShow = v_u_323
			task.delay(0.1, v_u_318)
			task.delay(0.25, v_u_318)
			task.delay(v_u_57.SLIDE_S - 0.03, function()
				-- upvalues: (ref) v_u_61, (copy) v_u_320, (ref) v_u_60, (ref) v_u_57, (copy) v_u_323, (copy) v_u_322, (copy) v_u_321, (ref) p_u_52, (ref) v_u_66, (ref) v_u_205
				if v_u_61.alive and (v_u_61.gen == v_u_320 and (v_u_61.open and not v_u_61.off)) then
					local v324 = v_u_60.dots
					if v324 and v324.prime then
						for _ = 1, v_u_57.PRIME_FRAMES do
							local v325 = v324.prime
							local v326 = v_u_57.PRIME_BOX_MS
							pcall(v325, v326)
							task.wait()
							if v_u_61.alive and (v_u_61.gen == v_u_320 and (v_u_61.open and not v_u_61.off)) then
								continue
							end
							return
						end
					end
					if v324 and v324.rebaseline then
						local v327 = v324.rebaseline
						pcall(v327)
					end
					if v324 then
						v324 = v324._self
					end
					local v328 = os.clock()
					if v324 and (v324.bl and (v324.bl.phase == "A" and (v324.bl.n < 14 and (os.clock() - v_u_323 < v_u_57.PHASE_A_MAX_S and os.clock() - v328 < 1)))) then
						task.wait()
						if v_u_61.alive and (v_u_61.gen == v_u_320 and (v_u_61.open and not v_u_61.off)) then
							continue
						end
					else
						v_u_322.Visible = true
						v_u_61.dotsOn = true
						v_u_61.tDots = os.clock()
						local v329 = v_u_321.veilIn
						local v330 = p_u_52
						pcall(v329, v330)
						if v_u_66.introDone or v_u_66.lat0 then
							if not v_u_66.introDone then
								v_u_66.introDone = true
							end
						else
							v_u_66.introDone = true
							local v331 = v_u_321.intro
							pcall(v331)
						end
						v_u_321.wake()
						v_u_205(true)
					end
				else
					return
				end
			end)
		end
		function v_u_60.rowSync() -- name: rowSync
			-- upvalues: (copy) v_u_56, (copy) v_u_61, (copy) v_u_60
			local v332 = v_u_56.listHost
			local v333 = v_u_61.alive and (not v_u_61.off and v_u_61.built)
			if v333 then
				if v_u_61.mode == "stage" and v332 ~= nil then
					v333 = v332.Parent ~= nil
				else
					v333 = false
				end
			end
			if v333 and not v_u_61.wm then
				local v334 = v_u_60.makeRow
				local v335, v336 = pcall(v334, v332)
				if not v335 then
					local v337 = "row: " .. tostring(v336)
					warn("[globe] " .. v337)
					v_u_61.wm = nil
					return
				end
			elseif not v333 and v_u_61.wm then
				local v_u_338 = v_u_61.wm
				v_u_61.wm = nil
				pcall(function()
					-- upvalues: (copy) v_u_338
					v_u_338.btn:Destroy()
				end)
			end
		end
		function v_u_60.makeRow(p339) -- name: makeRow
			-- upvalues: (ref) v_u_674, (ref) v_u_6, (ref) v_u_9, (copy) v_u_56, (copy) v_u_60, (copy) v_u_61
			local v340 = v_u_674.TUNING
			local v_u_341 = v_u_6.color
			local v342 = v_u_9.new("TextButton", {
				["Name"] = "WorldMapRow",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 0,
				["Selectable"] = true,
				["BackgroundColor3"] = v_u_341.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(v_u_56.compact and 52 or 58))
			}, p339)
			v342.SelectionImageObject = v_u_9.selectionImage()
			local v_u_343 = v_u_9.stroke(v342, v_u_341.line)
			v_u_9.new("Frame", {
				["Name"] = "Edge",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_341.info,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v342)
			v_u_9.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = 17,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v342,
				["text"] = v340.ROW_TEXT,
				["position"] = UDim2.fromOffset(14, 7),
				["size"] = UDim2.new(0.62, -14, 0, 22)
			})
			v_u_9.label({
				["parent"] = nil,
				["name"] = "Tagline",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v342,
				["text"] = v340.ROW_SUB,
				["color"] = v_u_341.text2,
				["position"] = UDim2.new(0, 14, 1, -24),
				["size"] = UDim2.new(0.9, -14, 0, 18)
			})
			v_u_9.label({
				["parent"] = nil,
				["name"] = "State",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["anchor"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v342,
				["text"] = v340.ROW_TAG,
				["color"] = v_u_341.info,
				["position"] = UDim2.new(1, -12, 0, 9),
				["anchor"] = Vector2.new(1, 0),
				["size"] = UDim2.new(0.38, -12, 0, 14)
			})
			v342.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_6, (copy) v_u_343, (copy) v_u_341
				v_u_9.sound(v_u_6.sounds.hover)
				v_u_343.Color = v_u_341.lineStrong
			end)
			v342.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_343, (copy) v_u_341
				v_u_343.Color = v_u_341.line
			end)
			v342.SelectionGained:Connect(function()
				-- upvalues: (copy) v_u_343, (copy) v_u_341
				v_u_343.Color = v_u_341.lineStrong
			end)
			v342.SelectionLost:Connect(function()
				-- upvalues: (copy) v_u_343, (copy) v_u_341
				v_u_343.Color = v_u_341.line
			end)
			v342.Activated:Connect(function(p344)
				-- upvalues: (ref) v_u_60
				local v345
				if p344 == nil then
					v345 = false
				else
					v345 = string.find(p344.UserInputType.Name, "Gamepad") ~= nil
				end
				v_u_60.open(v345)
			end)
			v_u_61.wm = {
				["btn"] = v342
			}
		end
		function v_u_60.open(p346) -- name: open
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (copy) v_u_205
			if not v_u_61.alive or (v_u_61.off or (v_u_61.open or (not v_u_61.built or (v_u_61.mode ~= "stage" or not (v_u_61.pop and v_u_60.view))))) then
				return false
			end
			if not v_u_61.shown then
				return false
			end
			v_u_61.open = true
			v_u_61.fromPad = p346 == true
			v_u_9.sound(v_u_6.sounds.open or v_u_6.sounds.click)
			v_u_61.pop.back.Visible = true
			if v_u_61.escConn then
				v_u_61.escConn:Disconnect()
			end
			v_u_61.escConn = v_u_3.InputBegan:Connect(function(p347, _)
				-- upvalues: (ref) v_u_61, (ref) v_u_9, (ref) v_u_60
				if p347.UserInputType == Enum.UserInputType.Keyboard and (p347.KeyCode == Enum.KeyCode.Escape and v_u_61.open) then
					local v348 = v_u_9.modalCount
					local v349, v350 = pcall(v348)
					if v349 and (type(v350) == "number" and v350 > 0) then
						return
					end
					v_u_9.takeBack()
					v_u_60.close(true)
				end
			end)
			local v351 = v_u_60.showNow
			local v352, v353 = pcall(v351)
			if v352 then
				if p346 == true and (v_u_60.view.focus and v_u_60.view.focus.Selectable) then
					v_u_2.SelectedObject = v_u_60.view.focus
				end
				local v354 = v_u_205
				pcall(v354, true)
				return true
			end
			local v355 = "open: " .. tostring(v353)
			warn("[globe] " .. v355)
			v_u_60.close(false)
			v_u_60.detach("error", "show", v353)
			return false
		end
		function v_u_60.close(p356) -- name: close
			-- upvalues: (copy) v_u_61, (ref) v_u_2, (copy) v_u_60, (ref) v_u_9, (copy) v_u_205
			if not v_u_61.open then
				return false
			end
			v_u_61.open = false
			local v357 = v_u_61
			v357.gen = v357.gen + 1
			v_u_61.dotsOn = false
			if v_u_61.escConn then
				v_u_61.escConn:Disconnect()
				v_u_61.escConn = nil
			end
			local v358 = v_u_61.pop
			local v359 = v_u_2.SelectedObject
			local v360
			if v358 == nil or v359 == nil then
				v360 = false
			else
				v360 = v359:IsDescendantOf(v358.back)
			end
			local function v361()
				-- upvalues: (ref) v_u_60
				if v_u_60.view then
					v_u_60.view.dotsLayer.Visible = false
					v_u_60.view.hide()
				end
			end
			pcall(v361)
			if v358 then
				v358.back.Visible = false
			end
			if p356 then
				local v362 = v_u_9.device
				local v_u_363, v364 = pcall(v362)
				if v_u_363 then
					v_u_363 = v364 == "Gamepad"
				end
				if (v_u_363 or v360) and (v_u_61.wm and v_u_61.wm.btn.Parent) then
					v_u_2.SelectedObject = v_u_61.wm.btn
					task.defer(function()
						-- upvalues: (ref) v_u_61, (ref) v_u_2, (copy) v_u_363
						if v_u_61.alive and (not v_u_61.open and (v_u_61.wm and (v_u_61.wm.btn.Parent and (v_u_2.SelectedObject ~= v_u_61.wm.btn and (v_u_363 or v_u_2.SelectedObject == nil))))) then
							v_u_2.SelectedObject = v_u_61.wm.btn
						end
					end)
				end
			end
			local v365 = v_u_205
			pcall(v365, true)
			return true
		end
		function v_u_60.closeBack() -- name: closeBack
			-- upvalues: (copy) v_u_61, (copy) v_u_60
			if v_u_61.open then
				v_u_60.close(true)
			end
		end
		function v_u_60.shut() -- name: shut
			-- upvalues: (copy) v_u_61, (copy) v_u_60
			if v_u_61.open then
				v_u_60.close(false)
			elseif v_u_61.built and (v_u_60.view and (v_u_60.view.isShown and v_u_60.view.isShown())) then
				local function v366()
					-- upvalues: (ref) v_u_60
					v_u_60.view.dotsLayer.Visible = false
					v_u_60.view.hide()
				end
				pcall(v366)
			end
			v_u_61.dotsOn = false
		end
		function v_u_60.isOpen() -- name: isOpen
			-- upvalues: (copy) v_u_61
			return v_u_61.open
		end
		local function v_u_375(p367, p368, ...) -- name: safe
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (copy) v_u_57
			if not v_u_61.alive or v_u_61.off then
				return nil
			end
			local v370, v371 = xpcall(p368, function(p369)
				return tostring(p369) .. "\n" .. debug.traceback()
			end, ...)
			if v370 then
				return v371
			end
			local v372 = p367 .. " failed: " .. tostring(v371)
			warn("[globe] " .. v372)
			v_u_61.lastError = tostring(v371)
			if p367 == "show" then
				v_u_60.detach("error", p367, v371)
			elseif p367 == "sync" or p367 == "pick" then
				local v373 = v_u_61.errs[p367]
				local v374 = os.clock()
				table.insert(v373, v374)
				while #v373 > 0 and v374 - v373[1] > v_u_57.ERROR_WINDOW_S do
					table.remove(v373, 1)
				end
				if #v373 >= v_u_57.ERRORS then
					v_u_60.detach("error", p367, v371)
				end
			end
			return nil
		end
		v_u_60.safe = v_u_375
		function v_u_60.show() -- name: show
			-- upvalues: (copy) v_u_61, (copy) v_u_375, (ref) v_u_8, (copy) v_u_150, (ref) v_u_6, (copy) v_u_60, (copy) v_u_164
			if v_u_61.alive and not v_u_61.off then
				v_u_375("show", function()
					-- upvalues: (ref) v_u_61, (ref) v_u_8, (ref) v_u_150, (ref) v_u_6, (ref) v_u_60, (ref) v_u_164
					v_u_61.shown = true
					if v_u_61.mode == "stage" and not v_u_61.built then
						local v376 = v_u_8.solve((v_u_150()))
						v_u_61.solved = v376
						v_u_6.uiScale()
						if v376.mode == "stage" then
							local v377, v378 = v_u_60.build(v376)
							if not v377 then
								error(v378)
							end
						end
					end
					v_u_164()
					if v_u_61.row and v_u_61.mode ~= "stage" then
						v_u_61.row.show()
					end
				end)
			end
		end
		function v_u_60.hide() -- name: hide
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (copy) p_u_51, (copy) v_u_205
			if v_u_61.alive then
				local v379 = v_u_61
				v379.gen = v379.gen + 1
				v_u_61.shown = false
				v_u_61.dotsOn = false
				if v_u_61.table then
					local v380 = v_u_61.table.close
					pcall(v380, "hide")
				end
				if v_u_61.row then
					local v381 = v_u_61.row.hide
					pcall(v381)
				end
				local function v386()
					-- upvalues: (ref) v_u_60, (ref) p_u_51
					v_u_60.shut()
					local v382 = p_u_51.scene
					local v383, v384 = pcall(v382)
					if not v383 then
						v384 = nil
					end
					if v384 and v384.setGlobeStage then
						local v385 = v384.setGlobeStage
						pcall(v385, v384, nil, nil, nil, nil)
					end
				end
				local v387, v388 = pcall(v386)
				if not v387 then
					local v389 = "hide cleanup: " .. tostring(v388)
					warn("[globe] " .. v389)
				end
				local v390 = v_u_205
				pcall(v390, true)
			end
		end
		function v_u_60.sync() -- name: sync
			-- upvalues: (copy) v_u_375, (copy) v_u_61, (copy) v_u_60, (copy) v_u_205
			v_u_375("sync", function()
				-- upvalues: (ref) v_u_61, (ref) v_u_60, (ref) v_u_205
				if v_u_61.off then
					return
				else
					if v_u_61.table then
						v_u_61.table.sync()
					end
					if v_u_61.row then
						v_u_61.row.sync()
					end
					if v_u_61.built then
						v_u_60.view.sync()
						v_u_205()
					end
				end
			end)
		end
		function v_u_60.pick(p391) -- name: pick
			-- upvalues: (copy) v_u_375, (copy) v_u_56, (copy) v_u_61, (copy) v_u_60, (copy) p_u_53
			local v392 = v_u_375("pick", v_u_56.pick, p391)
			if v392 ~= nil and v_u_61.open then
				local v_u_393 = v_u_61.fromPad
				task.defer(function()
					-- upvalues: (ref) v_u_61, (ref) v_u_60, (ref) p_u_53, (copy) v_u_393
					if v_u_61.alive and v_u_61.open then
						v_u_60.close(false)
						local v394 = p_u_53.closeList
						if type(v394) == "function" then
							local v395 = p_u_53.closeList
							local v396 = v_u_393 == true
							pcall(v395, v396)
						end
					end
				end)
			end
			return v392
		end
		function v_u_60.dropPopup() -- name: dropPopup
			-- upvalues: (copy) v_u_61
			v_u_61.open = false
			if v_u_61.escConn then
				v_u_61.escConn:Disconnect()
				v_u_61.escConn = nil
			end
			local v_u_397 = v_u_61.pop
			local v_u_398 = v_u_61.wm
			local v399 = v_u_61
			v_u_61.pop = nil
			v399.wm = nil
			if v_u_397 then
				pcall(function()
					-- upvalues: (copy) v_u_397
					v_u_397.back:Destroy()
				end)
			end
			if v_u_398 then
				pcall(function()
					-- upvalues: (copy) v_u_398
					v_u_398.btn:Destroy()
				end)
			end
		end
		function v_u_60.destroy() -- name: destroy
			-- upvalues: (copy) v_u_61, (copy) v_u_84, (copy) v_u_60, (copy) v_u_59, (ref) v_u_10
			if v_u_61.alive then
				v_u_61.alive = false
				local v400 = v_u_61
				v400.gen = v400.gen + 1
				local v401 = v_u_61.row
				local v402 = v_u_61.table
				local v403 = v_u_61
				v_u_61.row = nil
				v403.table = nil
				if v402 then
					local v404 = v402.destroy
					pcall(v404)
				end
				if v401 then
					local v405 = v401.destroy
					pcall(v405)
				end
				local v406 = v_u_84
				pcall(v406, nil)
				v_u_60.dropPopup()
				for _, v_u_407 in v_u_59 do
					pcall(function()
						-- upvalues: (copy) v_u_407
						v_u_407:Disconnect()
					end)
				end
				table.clear(v_u_59)
				if v_u_60.view then
					local v408 = v_u_60.view.destroy
					local v409, v410 = pcall(v408)
					if not v409 then
						local v411 = "destroy cleanup: " .. tostring(v410)
						warn("[globe] " .. v411)
					end
					v_u_60.view = nil
				end
				local v412 = v_u_60
				v_u_60.input = nil
				v412.dots = nil
				v_u_61.built = false
				local function v413()
					-- upvalues: (ref) v_u_10, (ref) v_u_61
					if v_u_10:GetAttribute("MenuGlobe") == v_u_61.attrLast then
						v_u_10:SetAttribute("MenuGlobe", nil)
					end
				end
				pcall(v413)
			end
		end
		function v_u_60.detach(p414, p_u_415, p416) -- name: detach
			-- upvalues: (copy) v_u_61, (copy) v_u_84, (copy) v_u_60, (ref) v_u_10, (copy) v_u_205
			if not v_u_61.off then
				v_u_61.off = p414
				local v417 = v_u_61
				v417.gen = v417.gen + 1
				v_u_61.dotsOn = false
				local v418 = v_u_61.row
				local v419 = v_u_61.table
				local v420 = v_u_61
				v_u_61.row = nil
				v420.table = nil
				if v419 then
					local v421 = v419.destroy
					pcall(v421)
				end
				if v418 then
					local v422 = v418.destroy
					pcall(v422)
				end
				local v423 = v_u_84
				pcall(v423, nil)
				v_u_60.dropPopup()
				local v424 = v_u_60.view
				local v425 = v_u_60
				local v426 = v_u_60
				v_u_60.view = nil
				v425.input = nil
				v426.dots = nil
				if v424 then
					local v427 = v424.destroy
					local v428, v429 = pcall(v427)
					if not v428 then
						local v430 = "detach cleanup: " .. tostring(v429)
						warn("[globe] " .. v430)
					end
				end
				v_u_61.built = false
				if p414 == "error" then
					local v431 = "off after an error in " .. tostring(p_u_415) .. ": " .. tostring(p416)
					warn("[globe] " .. v431)
					local function v433()
						-- upvalues: (ref) v_u_10, (copy) p_u_415
						v_u_10:SetAttribute("GlobeOff", "error")
						local v432 = p_u_415
						v_u_10:SetAttribute("ClientError", "globe: " .. tostring(v432))
					end
					pcall(v433)
				end
				local v434 = v_u_205
				pcall(v434, true)
			end
		end
		function v_u_60.reattach() -- name: reattach
			-- upvalues: (copy) v_u_61, (copy) p_u_53, (copy) v_u_60, (ref) v_u_10, (ref) v_u_8, (copy) v_u_150, (ref) v_u_6, (copy) v_u_164, (copy) v_u_135, (copy) v_u_205
			if not v_u_61.alive then
				return false
			end
			if p_u_53.globe == nil then
				p_u_53.globe = v_u_60
			end
			v_u_61.off = nil
			v_u_61.errs = {
				["sync"] = {},
				["pick"] = {}
			}
			local function v435()
				-- upvalues: (ref) v_u_10
				if v_u_10:GetAttribute("GlobeOff") ~= nil then
					v_u_10:SetAttribute("GlobeOff", nil)
				end
			end
			pcall(v435)
			local v436 = v_u_8.solve((v_u_150()))
			v_u_61.solved = v436
			v_u_6.uiScale()
			v_u_61.mode = v436.mode
			if v436.mode == "stage" then
				local v437, v438 = v_u_60.build(v436)
				if not v437 then
					v_u_60.detach("error", "build", v438)
					return false
				end
				v_u_164()
			else
				v_u_135()
			end
			local v439 = v_u_205
			pcall(v439, true)
			return true
		end
		function v_u_60.relayout() -- name: relayout
			-- upvalues: (copy) v_u_164
			v_u_164()
		end
		function v_u_60.layout() -- name: layout
			-- upvalues: (copy) v_u_61
			return v_u_61.solved
		end
		function v_u_60.state() -- name: state
			-- upvalues: (copy) v_u_61
			return v_u_61
		end
		function v_u_60.stats() -- name: stats
			-- upvalues: (copy) v_u_60, (copy) v_u_61
			local v440 = v_u_60.dots and (v_u_60.dots.stats and v_u_60.dots.stats()) or {}
			return {
				["off"] = v_u_61.off,
				["built"] = v_u_61.built,
				["shown"] = v_u_61.shown,
				["mode"] = v_u_61.mode,
				["tier"] = v_u_61.tier,
				["D"] = v_u_61.D,
				["kind"] = v_u_61.kind,
				["tAttach"] = v_u_61.tAttach,
				["dots"] = v440,
				["fit"] = v_u_61.fit,
				["dotsOn"] = v_u_61.dotsOn,
				["open"] = v_u_61.open,
				["row_wm"] = v_u_61.wm ~= nil,
				["row"] = v_u_61.row and v_u_61.row.stats() or nil,
				["table"] = v_u_61.table and v_u_61.table.stats() or nil
			}
		end
		v_u_60.hooks = v_u_56
		local function v488() -- name: wire
			-- upvalues: (copy) v_u_59, (copy) p_u_52, (copy) v_u_171, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (copy) v_u_61, (copy) v_u_318, (ref) v_u_10, (copy) v_u_60, (ref) v_u_5, (copy) v_u_164
			local v441 = v_u_59
			local v442 = p_u_52:GetPropertyChangedSignal("AbsoluteSize")
			local v443 = v_u_171
			table.insert(v441, v442:Connect(v443))
			local v444 = v_u_59
			local v445 = v_u_6.scaleChanged
			local v446 = v_u_171
			table.insert(v444, v445:Connect(v446))
			local v447 = v_u_59
			local v448 = v_u_3.LastInputTypeChanged
			local v449 = v_u_171
			table.insert(v447, v448:Connect(v449))
			local v450 = v_u_59
			local v451 = v_u_2:GetPropertyChangedSignal("SelectedObject")
			local function v453()
				-- upvalues: (ref) v_u_2, (ref) v_u_61, (ref) v_u_318
				local v452 = v_u_2.SelectedObject
				if v_u_61.alive and (v_u_61.open and (v452 ~= nil and (v_u_61.pop and not v452:IsDescendantOf(v_u_61.pop.back)))) then
					task.delay(0.05, v_u_318)
				end
			end
			table.insert(v450, v451:Connect(v453))
			local v454 = v_u_59
			local v455 = v_u_10:GetAttributeChangedSignal("GlobeOff")
			local function v462()
				-- upvalues: (ref) v_u_61, (ref) v_u_10, (ref) v_u_60, (ref) v_u_5
				if v_u_61.alive then
					local v456 = v_u_10:GetAttribute("GlobeOff")
					if v456 == nil or v_u_61.off then
						if v456 == nil and (v_u_61.off and v_u_61.off ~= "error") then
							local v457 = false
							local v_u_458 = "GlobeMap"
							local function v459()
								-- upvalues: (ref) v_u_5, (copy) v_u_458
								return require(v_u_5:WaitForChild("Config")).flag(v_u_458)
							end
							local v460, v461 = pcall(v459)
							if not v460 then
								v461 = nil
							end
							if v461 ~= false then
								v457 = v_u_10:GetAttribute("GlobeOff") == nil
							end
							if v457 then
								v_u_60.reattach()
							end
						end
					else
						v_u_60.detach("switch")
					end
				else
					return
				end
			end
			table.insert(v454, v455:Connect(v462))
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_61, (ref) v_u_59, (ref) v_u_60, (ref) v_u_10, (ref) v_u_164
				local function v463()
					-- upvalues: (ref) v_u_5
					return require(v_u_5:WaitForChild("Config"))
				end
				local v464, v465 = pcall(v463)
				if v464 then
					local v466 = v465.watchFlag
					if type(v466) == "function" then
						local function v_u_473(p467)
							-- upvalues: (ref) v_u_61, (ref) v_u_60, (ref) v_u_5, (ref) v_u_10
							if p467 == false then
								if not v_u_61.off then
									v_u_60.detach("switch")
									return
								end
							elseif v_u_61.off == "switch" then
								local v468 = false
								local v_u_469 = "GlobeMap"
								local function v470()
									-- upvalues: (ref) v_u_5, (copy) v_u_469
									return require(v_u_5:WaitForChild("Config")).flag(v_u_469)
								end
								local v471, v472 = pcall(v470)
								if not v471 then
									v472 = nil
								end
								if v472 ~= false then
									v468 = v_u_10:GetAttribute("GlobeOff") == nil
								end
								if v468 then
									v_u_60.reattach()
								end
							end
						end
						local v475 = v465.watchFlag("GlobeMap", function(p474)
							-- upvalues: (ref) v_u_61, (copy) v_u_473
							if v_u_61.alive then
								v_u_473(p474)
							end
						end)
						if v475 then
							if v_u_61.alive then
								local v476 = v_u_59
								table.insert(v476, v475)
							else
								v475:Disconnect()
							end
						end
						local function v_u_484(p477)
							-- upvalues: (ref) v_u_61, (ref) v_u_164
							v_u_61.phoneOn = p477 ~= false
							if v_u_61.alive and not v_u_61.off then
								if v_u_61.phoneOn then
									if v_u_61.mode ~= "stage" then
										local v478 = v_u_164
										pcall(v478)
										return
									end
								else
									local v479 = v_u_61.row
									local v480 = v_u_61.table
									local v481 = v_u_61
									v_u_61.row = nil
									v481.table = nil
									if v480 then
										local v482 = v480.destroy
										pcall(v482)
									end
									if v479 then
										local v483 = v479.destroy
										pcall(v483)
									end
								end
							end
						end
						local v486 = v465.watchFlag("GlobePhone", function(p485)
							-- upvalues: (ref) v_u_61, (copy) v_u_484
							if v_u_61.alive then
								v_u_484(p485)
							end
						end)
						if v486 then
							if v_u_61.alive then
								local v487 = v_u_59
								table.insert(v487, v486)
								return
							end
							v486:Disconnect()
						end
						return
					end
				end
			end)
		end
		local function v654() -- name: commands
			-- upvalues: (copy) p_u_51, (copy) v_u_60, (ref) v_u_10, (copy) v_u_61, (copy) v_u_164, (ref) v_u_2, (ref) v_u_9, (ref) v_u_674
			local v_u_489 = p_u_51.cctx.command
			if v_u_489 then
				local function v494(p490)
					-- upvalues: (ref) v_u_60, (ref) v_u_10
					if not p490[1] then
						return "usage: globe.pick <id>"
					end
					local v491 = v_u_60.pick(string.lower(p490[1]))
					local v492 = p490[1]
					local v493 = v_u_10
					return "pick " .. tostring(v492) .. " -> " .. tostring(v491) .. "; " .. tostring(v493:GetAttribute("MenuPlayMap"))
				end
				pcall(v_u_489, "globe.pick", v494)
				local function v503()
					-- upvalues: (ref) v_u_60, (ref) v_u_61, (ref) v_u_10
					if v_u_60.dots and (v_u_60.dots.gov and v_u_60.dots.gov.enable) then
						local v495 = v_u_60.dots.gov.enable
						local v496 = v_u_60.dots.gov
						pcall(v495, v496)
					end
					local v497 = v_u_60.view
					if v497 and v497.clearFatal then
						local v498 = v497.clearFatal
						pcall(v498)
					end
					if v_u_61.off or not v_u_61.built then
						v_u_60.reattach()
					end
					local function v499()
						-- upvalues: (ref) v_u_10
						v_u_10:SetAttribute("GlobeOff", nil)
					end
					pcall(v499)
					local v500 = v_u_61.off
					local v501 = tostring(v500)
					local v502 = v_u_61.attrLast
					return "globe on: " .. v501 .. " " .. tostring(v502)
				end
				pcall(v_u_489, "globe.on", v503)
				local function v511()
					-- upvalues: (ref) v_u_60, (ref) v_u_61
					local v504 = v_u_60.open(false)
					local v505 = tostring(v504)
					local v506 = v_u_61.open
					local v507 = tostring(v506)
					local v508 = v_u_61.shown
					local v509 = tostring(v508)
					local v510 = v_u_61.off
					return "globe.open: " .. v505 .. " (open=" .. v507 .. " shown=" .. v509 .. " off=" .. tostring(v510) .. ")"
				end
				pcall(v_u_489, "globe.open", v511)
				local function v513()
					-- upvalues: (ref) v_u_60
					local v512 = v_u_60.close
					return "globe.close: " .. tostring(v512(false))
				end
				pcall(v_u_489, "globe.close", v513)
				local function v514()
					-- upvalues: (ref) v_u_10
					v_u_10:SetAttribute("GlobeOff", "manual")
					return "globe off (attribute GlobeOff = manual; globe.on lifts it)"
				end
				pcall(v_u_489, "globe.off", v514)
				local function v527(p515)
					-- upvalues: (ref) p_u_51, (ref) v_u_60
					local v516 = p_u_51.scene
					local v517, v518 = pcall(v516)
					if not v517 then
						v518 = nil
					end
					if not (v518 and v518.setSquad) then
						return "no scene"
					end
					local v519 = p515[1]
					local v520 = tonumber(v519) or 0
					local v521 = math.clamp(v520, 0, 3)
					local v522 = {}
					for v523 = 1, v521 do
						local v524 = {
							["userId"] = v523 + 100,
							["name"] = "Mate" .. v523,
							["displayName"] = "Mate" .. v523
						}
						table.insert(v522, v524)
					end
					local v525 = v518.setSquad
					pcall(v525, v518, v522)
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_60
						local v526 = v_u_60.relayout
						pcall(v526)
					end)
					return "mates " .. v521
				end
				pcall(v_u_489, "globe.squad", v527)
				local function v541(p528)
					-- upvalues: (ref) v_u_61, (ref) v_u_164
					local v529 = p528[1]
					if v529 ~= "on" and v529 ~= "open" then
						if v529 ~= "off" and v529 ~= "close" then
							return "usage: globe.table on|off|open|close"
						end
						if v_u_61.table then
							v_u_61.table.close("command")
						end
						if v529 == "off" then
							v_u_61.forceTable = nil
							v_u_164()
						end
						local v530 = v_u_61.mode
						local v531 = tostring(v530)
						local v532 = v_u_61.row ~= nil
						return "table mode: " .. v531 .. " row=" .. tostring(v532)
					end
					v_u_61.forceTable = true
					v_u_164()
					if v_u_61.shown and v_u_61.row then
						v_u_61.row.show()
					end
					if v529 == "open" and v_u_61.table then
						v_u_61.table.open()
					end
					local v533 = "table mode: "
					local v534 = v_u_61.mode
					local v535 = tostring(v534)
					local v536 = " row="
					local v537 = v_u_61.row ~= nil
					local v538 = tostring(v537)
					local v539 = " table="
					local v540
					if v_u_61.table == nil then
						v540 = false
					else
						v540 = v_u_61.table.isOpen()
					end
					return v533 .. v535 .. v536 .. v538 .. v539 .. tostring(v540)
				end
				pcall(v_u_489, "globe.table", v541)
				local function v574()
					-- upvalues: (ref) v_u_60, (ref) v_u_2, (ref) v_u_9, (ref) v_u_10, (ref) v_u_61
					local v542 = v_u_60.input
					if not v542 then
						return "no input layer"
					end
					local v543 = v542.stats and (v542.stats() or {}) or {}
					local v544 = v_u_2.SelectedObject
					local v545 = true
					local v546 = v_u_60.view
					if v546 then
						v546 = v_u_60.view.lens
					end
					while v546 and not v546:IsA("LayerCollector") do
						if v546:IsA("GuiObject") and not v546.Visible then
							v545 = false
						end
						v546 = v546.Parent
					end
					local v547 = v_u_9.modalCount
					local _, v548 = pcall(v547)
					local v549 = "globe.pad parts: lensVisible="
					local v550 = tostring(v545)
					local v551 = " layer="
					if v546 then
						v546 = v546.Name
					end
					local v552 = v_u_10
					local v553 = v549 .. v550 .. v551 .. tostring(v546) .. " modals=" .. tostring(v548) .. " crate=" .. tostring(v552:GetAttribute("CrateStageOn"))
					warn("[globe] " .. v553)
					local v554 = string.format
					local v555 = "padOwns=%s usable=%s inputKind=%s sel=%s focusSelectable=%s shown=%s dotsOn=%s presses=%s padA=%s steps=%s"
					local v556 = v542.padOwns
					local v557 = tostring(v556())
					local v558 = v542.usable
					local v559 = tostring(v558())
					local v560 = v542.inputKind
					local v561 = tostring(v560())
					if v544 then
						v544 = v544.Name
					end
					local v562 = tostring(v544)
					local v563 = v_u_60.view and v_u_60.view.focus
					if v563 then
						v563 = v_u_60.view.focus.Selectable
					end
					local v564 = tostring(v563)
					local v565 = v_u_61.shown
					local v566 = tostring(v565)
					local v567 = v_u_61.dotsOn
					local v568 = tostring(v567)
					local v569 = v543.presses
					local v570 = tostring(v569)
					local v571 = v543.padA
					local v572 = tostring(v571)
					local v573 = v543.steps
					return v554(v555, v557, v559, v561, v562, v564, v566, v568, v570, v572, (tostring(v573)))
				end
				pcall(v_u_489, "globe.pad", v574)
				local function v618()
					-- upvalues: (ref) v_u_61, (ref) v_u_674, (ref) v_u_60
					local v575 = v_u_61.env or v_u_674.hardware()
					local v576 = v_u_60.dots and (v_u_60.dots.stats and v_u_60.dots.stats()) or {}
					local v577 = string.format
					local v578 = "tier=%s kind=%s tenFoot=%s touch=%s accel=%s (real touch=%s accel=%s simulated=%s) minSide=%d lowQuality=%s caps rest=%s move=%s c=%s base=%s baseA=%s baseB=%s tAttach=%sms tFirst=%sms quality=%s%% floor=%s stepMs=%s"
					local v579 = v_u_61.tier
					local v580 = v_u_61.kind
					local v581 = v575.tenFoot
					local v582 = tostring(v581)
					local v583 = v575.touch
					local v584 = tostring(v583)
					local v585 = v575.accel
					local v586 = tostring(v585)
					local v587 = v575.realTouch
					local v588 = tostring(v587)
					local v589 = v575.realAccel
					local v590 = tostring(v589)
					local v591 = v575.simulated
					local v592 = tostring(v591)
					local v593 = v575.minSide
					local v594 = v575.lowQuality
					local v595 = tostring(v594)
					local v596 = v576.capRest
					local v597 = tostring(v596)
					local v598 = v576.capMove
					local v599 = tostring(v598)
					local v600 = v_u_60.dots and v_u_60.dots._self
					if v600 then
						v600 = v_u_60.dots._self.calC
					end
					local v601 = tostring(v600)
					local v602 = v576.base
					local v603 = tostring(v602)
					local v604 = v576.baseA
					local v605 = tostring(v604)
					local v606 = v576.baseB
					local v607 = tostring(v606)
					local v608 = v576.tAttach or 0
					local v609 = string.format("%.1f", v608)
					local v610 = v576.tFirst or 0
					local v611 = string.format("%.1f", v610)
					local v612 = v576.quality
					if v612 then
						local v613 = v576.quality * 100 + 0.5
						v612 = math.floor(v613)
					end
					local v614 = tostring(v612)
					local v615 = v576.qFloor
					local v616 = tostring(v615)
					local v617 = v576.stepMs
					return v577(v578, v579, v580, v582, v584, v586, v588, v590, v592, v593, v595, v597, v599, v601, v603, v605, v607, v609, v611, v614, v616, (tostring(v617)))
				end
				pcall(v_u_489, "globe.hw", v618)
				local function v653()
					-- upvalues: (ref) v_u_60
					local v619 = v_u_60.dots
					local v620
					if v619 then
						v620 = v619.gov
					else
						v620 = v619
					end
					if not v620 then
						return "no governor (no globe, or the mini globe)"
					end
					local v621 = v619.stats()
					local v622 = v620:target()
					local v623 = v620:ceiling()
					local v624 = string.format
					local v625 = v620:quality() * 100 + 0.5
					local v626 = math.floor(v625)
					local v627 = tostring(v620:atFloor())
					local v628 = tostring(v620:degraded())
					local v629 = tostring(v620:stepMs())
					local v630 = v621.capMove
					local v631 = tostring(v630)
					local v632 = v621.capRest
					local v633 = tostring(v632)
					local v634 = v622.move
					local v635 = tostring(v634)
					local v636 = v622.rest
					local v637 = tostring(v636)
					local v638 = v623.move
					local v639 = tostring(v638)
					local v640 = v623.rest
					local v641 = tostring(v640)
					local v642 = tostring(v620:trips())
					local v643 = tostring(v620:floorTrips())
					local v644 = tostring(v620:recoveries())
					local v645 = tostring(v620:restLevel())
					local v646 = v621.densRest
					local v647 = tostring(v646)
					local v648 = v621.densMove
					local v649 = tostring(v648)
					local v650 = v621.visible
					local v651 = tostring(v650)
					local v652 = v621.base
					return v624("quality=%d%% floor=%s degraded=%s stepMs=%s | caps in force move=%s rest=%s | wanted move=%s rest=%s | ceiling move=%s rest=%s | trips=%s floorTrips=%s recoveries=%s restLevel=%s | density rest=%s move=%s permille | visible=%s base=%s", v626, v627, v628, v629, v631, v633, v635, v637, v639, v641, v642, v643, v644, v645, v647, v649, v651, (tostring(v652)))
				end
				pcall(v_u_489, "globe.gov", v653)
				pcall(function()
					-- upvalues: (copy) v_u_489
					require(script.Parent:WaitForChild("GlobeBench", 5)).command(v_u_489)
				end)
			end
		end
		v_u_61.env = v_u_674.hardware(p_u_52)
		v_u_61.tier = v_u_7.tierOf(v_u_61.env)
		local v655 = p_u_52.Destroying
		table.insert(v_u_59, v655:Connect(function()
			-- upvalues: (copy) v_u_61, (copy) v_u_60
			if v_u_61.alive then
				v_u_60.destroy()
			end
		end))
		local v656 = v_u_8.solve((v_u_150()))
		v_u_61.solved = v656
		v_u_6.uiScale()
		v_u_61.mode = v656.mode
		v654()
		local v657 = false
		local v_u_658 = "GlobeMap"
		local function v659()
			-- upvalues: (ref) v_u_5, (copy) v_u_658
			return require(v_u_5:WaitForChild("Config")).flag(v_u_658)
		end
		local v660, v661 = pcall(v659)
		if not v660 then
			v661 = nil
		end
		if v661 ~= false then
			v657 = v_u_10:GetAttribute("GlobeOff") == nil
		end
		if not v657 then
			v_u_61.off = "switch"
			v488()
			return nil
		end
		if v_u_61.mode == "stage" then
			local v662, v_u_663 = v_u_60.build(v656)
			if not v662 then
				local v664 = "build failed: " .. tostring(v_u_663)
				warn("[globe] " .. v664)
				local function v666()
					-- upvalues: (ref) v_u_10, (copy) v_u_663
					local v665 = v_u_663
					v_u_10:SetAttribute("ClientError", "globe: " .. tostring(v665))
				end
				pcall(v666)
				local v667 = p_u_51.scene
				local v668, v669 = pcall(v667)
				if not v668 then
					v669 = nil
				end
				if v669 and v669.setGlobeStage then
					local v670 = v669.setGlobeStage
					pcall(v670, v669, nil, nil, nil, nil)
				end
				for _, v_u_671 in v_u_59 do
					pcall(function()
						-- upvalues: (copy) v_u_671
						v_u_671:Disconnect()
					end)
				end
				v_u_61.alive = false
				return nil
			end
		end
		v488()
		v_u_60.rowSync()
		local v_u_672 = p_u_53.deploy
		if type(v_u_672) == "function" then
			function p_u_53.deploy(...)
				-- upvalues: (copy) v_u_61, (copy) v_u_672
				if v_u_61.table then
					local v673 = v_u_61.table.close
					pcall(v673, "deploy")
				end
				return v_u_672(...)
			end
		end
		if v_u_61.mode ~= "stage" then
			v_u_135()
		end
		v_u_61.tAttach = (os.clock() - v55) * 1000
		return v_u_60
	end
}
return v_u_674