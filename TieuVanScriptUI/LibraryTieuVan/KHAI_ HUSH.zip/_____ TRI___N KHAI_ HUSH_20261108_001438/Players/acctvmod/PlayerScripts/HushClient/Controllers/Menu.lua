-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Menu

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {
	["name"] = "Menu",
	["order"] = 60
}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = v1.LocalPlayer
local v_u_12 = {
	{
		["id"] = "play",
		["text"] = "Play",
		["group"] = 1
	},
	{
		["id"] = "starter",
		["text"] = "Starter Pack",
		["group"] = 1,
		["starter"] = true
	},
	{
		["id"] = "character",
		["text"] = "Character",
		["group"] = 1
	},
	{
		["id"] = "traders",
		["text"] = "Traders",
		["group"] = 1
	},
	{
		["id"] = "market",
		["text"] = "Market",
		["group"] = 1,
		["flag"] = "Blackmarket",
		["rule"] = "blackmarket",
		["ruleNil"] = true
	},
	{
		["id"] = "tasks",
		["text"] = "Tasks",
		["group"] = 1
	},
	{
		["id"] = "hideout",
		["text"] = "Hideout",
		["group"] = 1
	},
	{
		["id"] = "pass",
		["text"] = "Pass",
		["group"] = 1,
		["rule"] = "seasonPass"
	},
	{
		["id"] = "clan",
		["text"] = "Clan",
		["group"] = 1,
		["rule"] = "clans"
	},
	{
		["id"] = "collection",
		["text"] = "Collection",
		["group"] = 2
	},
	{
		["id"] = "badges",
		["text"] = "Badges",
		["group"] = 2
	},
	{
		["id"] = "leaderboard",
		["text"] = "Leaderboard",
		["group"] = 2
	},
	{
		["id"] = "store",
		["text"] = "Store",
		["group"] = 3
	},
	{
		["id"] = "settings",
		["text"] = "Settings",
		["group"] = 3
	}
}
local v_u_13 = {}
local function v_u_14()
	return false
end
local function v_u_26() -- name: computeTabs
	-- upvalues: (copy) v_u_12, (ref) v_u_5, (copy) v_u_11, (ref) v_u_14, (ref) v_u_13
	local v15 = {}
	for _, v_u_16 in v_u_12 do
		local v_u_17 = true
		if v_u_16.flag then
			local function v18()
				-- upvalues: (ref) v_u_17, (ref) v_u_5, (copy) v_u_16
				v_u_17 = v_u_5.config.flag(v_u_16.flag) ~= false
			end
			pcall(v18)
		end
		if v_u_17 and v_u_16.id == "market" then
			local v19 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
			local v20
			if v19 then
				v20 = v19:GetAttribute("BmRm")
			else
				v20 = nil
			end
			local v21
			if v20 == "block" then
				v21 = v_u_11:GetAttribute("PaidTrading") ~= true
			else
				v21 = false
			end
			if v21 then
				v_u_17 = false
			end
		end
		if v_u_17 and v_u_16.starter == true then
			v_u_17 = v_u_14()
		end
		if v_u_17 and v_u_16.rule then
			local v_u_22 = false
			local function v23()
				-- upvalues: (ref) v_u_22, (ref) v_u_5, (copy) v_u_16
				v_u_22 = v_u_5.shared.GameMode.rule(v_u_16.rule) == true
			end
			pcall(v23)
			if not v_u_22 and v_u_16.ruleNil == true then
				local function v24()
					-- upvalues: (ref) v_u_22, (ref) v_u_5, (copy) v_u_16
					v_u_22 = v_u_5.shared.GameMode.rule(v_u_16.rule) == nil
				end
				pcall(v24)
			end
			v_u_17 = v_u_22
		end
		if not v_u_17 then
			continue
		end
		table.insert(v15, v_u_16)
	end
	local v25 = #v15 ~= #v_u_13
	v_u_13 = v15
	return v25
end
local v_u_27 = {
	["play"] = "play",
	["character"] = "character"
}
local v_u_28 = {
	["hideoutBuild"] = true,
	["craft"] = true,
	["hideoutCollect"] = true,
	["repair"] = true,
	["enterHideout"] = true,
	["leaveHideout"] = true
}
local v_u_29 = {}
v_u_14 = function()
	-- upvalues: (copy) v_u_29, (ref) v_u_5
	local v30 = v_u_29.profile
	if type(v30) ~= "table" then
		return false
	end
	local v_u_31 = nil
	local function v32()
		-- upvalues: (ref) v_u_31, (ref) v_u_5
		v_u_31 = v_u_5.shared.GroupStarterRules
	end
	pcall(v32)
	local v33 = v_u_31
	if type(v33) == "table" then
		local v34 = v_u_31.offerFor
		if type(v34) == "function" then
			local v_u_35 = true
			local function v36()
				-- upvalues: (ref) v_u_35, (ref) v_u_5
				v_u_35 = v_u_5.config.flag("GroupStarter") ~= false
			end
			pcall(v36)
			local v_u_37 = false
			local function v38()
				-- upvalues: (ref) v_u_37, (ref) v_u_5
				v_u_37 = v_u_5.shared.GameMode.rule("groupStarter") == true
			end
			pcall(v38)
			return v_u_31.offerFor(v30, v_u_35, v_u_37) == true
		end
	end
	return false
end
local function v_u_43()
	-- upvalues: (copy) v_u_29
	local v39 = v_u_29.profile
	local v40
	if type(v39) == "table" then
		v40 = v39.skins
	else
		v40 = nil
	end
	local v41
	if type(v40) == "table" then
		local v42 = v40.owned
		if type(v42) == "table" then
			v41 = next(v40.owned) ~= nil
		else
			v41 = false
		end
	else
		v41 = false
	end
	return v41
end
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = nil
local v_u_47 = {}
local v_u_48 = {}
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = false
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = {}
local v_u_56 = nil
local v_u_57 = nil
local v_u_58 = false
local v_u_59 = "Menu"
local v_u_60 = 0
local v_u_61 = nil
local v_u_62 = nil
local v_u_63 = false
local v_u_64 = false
local v_u_65 = {}
local v_u_66 = nil
local v_u_67 = nil
local v_u_68 = nil
local v_u_69 = 0
local v_u_70 = false
local v_u_71 = false
local v_u_72 = {}
local v_u_73 = 0
local v_u_74 = 0
local v_u_75 = (-1 / 0)
local v_u_76 = 0
local v_u_77 = false
local v_u_78 = nil
local v_u_79 = false
local v_u_80 = nil
local v_u_81 = nil
local v_u_82 = false
local v_u_83 = false
local v_u_84 = nil
local v_u_85 = 0
local v_u_86 = {}
local v_u_87 = false
local v_u_88 = nil
local v_u_89 = false
local v_u_90 = false
local v_u_91 = nil
local v_u_92 = nil
local v_u_93 = {}
local v_u_94 = nil
local v_u_95 = ""
local v_u_96 = -10
local v_u_97 = 0
local v_u_98 = nil
local v_u_99 = nil
local function v_u_100() end
local function v_u_104() -- name: W
	-- upvalues: (ref) v_u_5
	local function v101()
		-- upvalues: (ref) v_u_5
		return v_u_5.lib.MenuWhy
	end
	local v102, v103 = pcall(v101)
	if v102 and type(v103) == "table" then
		return v103
	end
	warn("[Menu] lib missing: MenuWhy")
	return {}
end
local v_u_105 = {}
function v_u_29.fetch(p106, p107, p108) -- name: fetch
	-- upvalues: (copy) v_u_29, (copy) v_u_105, (ref) v_u_68
	local v109
	if type(p107) == "table" and (p107.difficulty or p107.id) then
		local v110 = p107.difficulty or p107.id
		v109 = "/" .. tostring(v110)
	else
		v109 = ""
	end
	local v111 = p106 .. v109
	if type(p107) == "table" then
		local v112 = p107.user
		if type(v112) == "string" then
			v111 = v111 .. "/" .. string.lower(p107.user)
		end
	end
	local v113 = v_u_29.cache[v111]
	if v113 and os.clock() - v113.at < (p108 or 20) then
		return v113.data
	end
	if v_u_105[v111] then
		local v114 = v_u_105[v111]
		local v115 = coroutine.running
		table.insert(v114, v115())
		return coroutine.yield()
	end
	v_u_105[v111] = {}
	local v_u_116 = {
		["what"] = p106
	}
	if type(p107) == "table" then
		for v117, v118 in p107 do
			v_u_116[v117] = v118
		end
	end
	local v119 = nil
	local v120 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	local v_u_121 = v120
	if v_u_121 then
		v_u_121 = v120:FindFirstChild("menu.get")
	end
	if not v_u_121 then
		v_u_121 = game:GetService("ReplicatedStorage"):WaitForChild("HushNet", 10)
		if v_u_121 then
			v_u_121 = v_u_121:WaitForChild("menu.get", 10)
		end
	end
	if v_u_121 and v_u_121:IsA("RemoteFunction") then
		local v122, v123 = pcall(function()
			-- upvalues: (ref) v_u_121, (copy) v_u_116
			return v_u_121:InvokeServer(v_u_116)
		end)
		if v122 and (type(v123) == "table" and v123.error == nil) then
			v_u_29.lastError[p106] = nil
			v_u_29.cache[v111] = {
				["data"] = v123,
				["at"] = os.clock()
			}
			if v111 == "tasks" then
				v_u_68 = v123
				v119 = v123
			else
				v119 = v123
			end
		elseif v122 and type(v123) == "table" then
			local v124 = v123.error
			if type(v124) == "string" then
				v_u_29.lastError[p106] = v123.error
			end
		end
	end
	local v125 = v_u_105[v111]
	v_u_105[v111] = nil
	for _, v126 in v125 do
		task.spawn(v126, v119)
	end
	return v119
end
function v_u_29.failText(p127, p128) -- name: failText
	-- upvalues: (copy) v_u_104, (copy) v_u_29
	local v129 = v_u_104()
	local v130 = v129.failText
	if type(v130) == "function" then
		return v129.failText(v_u_29.lastError[p127], p128)
	else
		return p128
	end
end
function v_u_29.invalidate(p131) -- name: invalidate
	-- upvalues: (copy) v_u_29
	if p131 then
		for v132 in v_u_29.cache do
			if v132 ~= p131 then
				local v133 = #p131 + 1
				if string.sub(v132, 1, v133) ~= p131 .. "/" then
					continue
				end
			end
			v_u_29.cache[v132] = nil
		end
	else
		table.clear(v_u_29.cache)
	end
end
function v_u_29.op(p134) -- name: op
	-- upvalues: (ref) v_u_69, (copy) v_u_104, (ref) v_u_6
	v_u_69 = v_u_69 + 1
	p134.req = v_u_69
	local v135 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	if v135 then
		v135 = v135:FindFirstChild("menu.op")
	end
	if not (v135 and v135:IsA("RemoteEvent")) then
		v135 = nil
	end
	if v135 then
		v135:FireServer(p134)
	else
		local v136 = v_u_104().TOAST.notConnected
		local v137 = v136[1]
		local v138 = v136[2]
		local v139 = v_u_6.toast
		pcall(v139, v137, "danger", v138, nil)
	end
	return v_u_69
end
function v_u_29.partyOp(p140) -- name: partyOp
	-- upvalues: (copy) v_u_104, (ref) v_u_6
	local v141 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	if v141 then
		v141 = v141:FindFirstChild("party.op")
	end
	if not (v141 and v141:IsA("RemoteEvent")) then
		v141 = nil
	end
	if v141 then
		v141:FireServer(p140)
	else
		local v142 = v_u_104().TOAST.squads
		local v143 = v142[1]
		local v144 = v142[2]
		local v145 = v_u_6.toast
		pcall(v145, v143, "warn", v144, nil)
	end
end
function v_u_29.setTab(p146) -- name: setTab
	-- upvalues: (copy) v_u_4
	v_u_4.setTab(p146)
end
function v_u_29.compact() -- name: compact
	-- upvalues: (ref) v_u_7
	return v_u_7.refSize().X < 1320 and true or v_u_7.refSize().Y < 640
end
function v_u_29.playColW() -- name: playColW
	-- upvalues: (copy) v_u_29, (ref) v_u_7
	return v_u_29.compact() and (v_u_7.safeRefSize().X < 900 and 400 or 440) or 520
end
function v_u_29.derived() -- name: derived
	-- upvalues: (copy) v_u_29
	local v147 = v_u_29.profile
	local v148
	if type(v147) == "table" then
		local v149 = v147.derived
		v148 = type(v149) == "table" and v147.derived or {}
	else
		v148 = {}
	end
	return v148
end
function v_u_29.slots() -- name: slots
	-- upvalues: (copy) v_u_29
	local v150 = v_u_29.profile
	local v151
	if type(v150) == "table" then
		v151 = v150.inv
	else
		v151 = false
	end
	local v152
	if type(v151) == "table" then
		v152 = v151.kit
	else
		v152 = false
	end
	local v153
	if type(v152) == "table" then
		local v154 = v152.slots
		v153 = type(v154) == "table" and v152.slots or {}
	else
		v153 = {}
	end
	return v153
end
function v_u_29.myParty() -- name: myParty
	-- upvalues: (copy) v_u_29
	local v155 = v_u_29.party
	if type(v155) == "table" then
		local v156 = v155.party
		if type(v156) == "table" then
			return v155.party
		end
	end
	return nil
end
function v_u_29.isLeader() -- name: isLeader
	-- upvalues: (copy) v_u_29, (copy) v_u_11
	local v157 = v_u_29.myParty()
	return v157 == nil and true or v157.leader == v_u_11.UserId
end
function v_u_29.partyDeploying() -- name: partyDeploying
	-- upvalues: (copy) v_u_29
	local v158 = v_u_29.party
	if type(v158) ~= "table" then
		return false
	end
	local v159 = v158.party
	local v160
	if type(v159) == "table" and v159.deploying ~= nil then
		v160 = v159.deploying
	else
		v160 = v158.deploying
	end
	if type(v160) == "table" then
		return v160.tutorial ~= true
	end
	local v161
	if v160 == true then
		v161 = true
	elseif type(v160) == "number" then
		v161 = v160 > 0
	else
		v161 = false
	end
	return v161
end
local function v_u_170() -- name: tutorialState
	-- upvalues: (ref) v_u_5, (copy) v_u_29
	local function v162()
		-- upvalues: (ref) v_u_5
		return v_u_5.lib.MenuTutorialCard
	end
	local v163, v164 = pcall(v162)
	if v163 and type(v164) == "table" then
		local v165 = v164.state
		if type(v165) == "function" then
			local v166 = v164.state
			local v167 = v_u_29
			local v168, v169 = pcall(v166, v167)
			if v168 then
				return v169
			else
				return nil
			end
		end
	end
	return nil
end
function v_u_29.syncTutorial() -- name: syncTutorial
	-- upvalues: (ref) v_u_58, (copy) v_u_170, (copy) v_u_29, (ref) v_u_51, (copy) v_u_48, (ref) v_u_77, (ref) v_u_5, (copy) v_u_11
	local v171
	if v_u_58 then
		v171 = v_u_170()
	else
		v171 = nil
	end
	local v172 = v_u_58
	local v173, v174, v175, v176
	if v172 then
		if v171 == "offer" or v171 == "retry" then
			if v_u_29.tutorialCard == nil then
				if v_u_48.play == nil then
					v172 = not v_u_51
				else
					v172 = false
				end
			else
				local v177 = v_u_51
				if v177 then
					v177 = v_u_29.tutorialCardOff == true
				end
				v172 = not v177
				if v172 then
					if v172 ~= v_u_77 then
						v_u_77 = v172
						v173 = v_u_5.controllers.TutorialClient
						v174 = false
						if v173 then
							v175 = v173.claimMenuCard
							if type(v175) == "function" then
								v176 = v173.claimMenuCard
								v174 = pcall(v176, v172)
							end
						end
						if not v174 then
							v_u_11:SetAttribute("MenuTutorialCard", v172 and true or nil)
						end
					end
					if v_u_58 and v_u_29.changed then
						v_u_29.changed:Fire("tutorial")
					end
					return
				end
				if v_u_48.play == nil then
					v172 = not v_u_51
				else
					v172 = false
				end
			end
			if v172 ~= v_u_77 then
				v_u_77 = v172
				v173 = v_u_5.controllers.TutorialClient
				v174 = false
				if v173 then
					v175 = v173.claimMenuCard
					if type(v175) == "function" then
						v176 = v173.claimMenuCard
						v174 = pcall(v176, v172)
					end
				end
				if not v174 then
					v_u_11:SetAttribute("MenuTutorialCard", v172 and true or nil)
				end
			end
			if v_u_58 and v_u_29.changed then
				v_u_29.changed:Fire("tutorial")
			end
		else
			v172 = false
			if v172 ~= v_u_77 then
				v_u_77 = v172
				v173 = v_u_5.controllers.TutorialClient
				v174 = false
				if v173 then
					v175 = v173.claimMenuCard
					if type(v175) == "function" then
						v176 = v173.claimMenuCard
						v174 = pcall(v176, v172)
					end
				end
				if not v174 then
					v_u_11:SetAttribute("MenuTutorialCard", v172 and true or nil)
				end
			end
			if v_u_58 and v_u_29.changed then
				v_u_29.changed:Fire("tutorial")
			end
		end
	else
		if v172 ~= v_u_77 then
			v_u_77 = v172
			v173 = v_u_5.controllers.TutorialClient
			v174 = false
			if v173 then
				v175 = v173.claimMenuCard
				if type(v175) == "function" then
					v176 = v173.claimMenuCard
					v174 = pcall(v176, v172)
				end
			end
			if not v174 then
				v_u_11:SetAttribute("MenuTutorialCard", v172 and true or nil)
			end
		end
		if v_u_58 and v_u_29.changed then
			v_u_29.changed:Fire("tutorial")
		end
		return
	end
end
local function v_u_186() -- name: paintChrome
	-- upvalues: (ref) v_u_45, (ref) v_u_57, (ref) v_u_51, (ref) v_u_52, (ref) v_u_7, (ref) v_u_56, (copy) v_u_29, (ref) v_u_49
	local v178 = v_u_45
	if v178 then
		local v179 = v_u_57 ~= nil
		if v_u_51 then
			if v_u_52 then
				v_u_52.setVisible(not v179)
			end
			local v180 = v178:FindFirstChild("Footer")
			if v180 and v180:IsA("GuiObject") then
				local v181 = not v179
				if v181 then
					v181 = not v_u_7.isPhone()
				end
				v180.Visible = v181
			end
		else
			for _, v182 in { "TopBar", "TopRule", "Footer" } do
				local v183 = v178:FindFirstChild(v182)
				if not (v183 and v183:IsA("GuiObject")) then
					continue
				end
				v183.Visible = not v179
			end
			if v_u_56 and v_u_56.frame then
				local v184 = v_u_56.frame
				local v185 = not v179
				if v185 then
					v185 = not v_u_29.compact() or v_u_49 == "play"
				end
				v184.Visible = v185
			end
		end
	else
		return
	end
end
local function v_u_191() -- name: touchFloorX
	-- upvalues: (copy) v_u_3, (ref) v_u_7
	local function v188()
		-- upvalues: (ref) v_u_3
		local v187 = v_u_3.TouchEnabled
		if v187 then
			v187 = not v_u_3.MouseEnabled
		end
		return v187
	end
	local v189, v190 = pcall(v188)
	return not (v_u_7.isPhone() or v189 and v190) and 0 or v_u_7.refSize().X * v_u_7.uiScale() * 0.33 + 24
end
local function v_u_393(p192) -- name: buildTopBar
	-- upvalues: (copy) v_u_29, (ref) v_u_6, (ref) v_u_7, (ref) v_u_13, (copy) v_u_2, (copy) v_u_191, (ref) v_u_8, (copy) v_u_11, (ref) v_u_49, (copy) v_u_47, (copy) v_u_4, (copy) v_u_104, (ref) v_u_5, (ref) v_u_61, (ref) v_u_9
	local v_u_193 = v_u_29.compact()
	local v_u_194 = v_u_6.new("Frame", {
		["Name"] = "TopBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.new(1, 0, 0, 64)
	}, p192)
	local v_u_195 = v_u_7.touch(v_u_193 and 48 or 40)
	local v196 = v_u_193 and 16 or 17
	local v_u_197 = {}
	for v198, v199 in v_u_13 do
		local v200 = v196 * 0.42 * #v199.text
		v_u_197[v198] = math.ceil(v200) + 2
	end
	local v_u_201 = 0
	for v202 = 2, #v_u_13 do
		if v_u_13[v202].group == v_u_13[v202 - 1].group then
			continue
		end
		v_u_201 = v_u_201 + 1
	end
	local v203 = v_u_2.TopbarInset.Min.X
	local v204 = v203 <= 0 and 120 or v203
	if v_u_7.isPhone() then
		v204 = v204 + 120
	end
	local v205 = v_u_191()
	local v206 = math.max(v204, v205) / v_u_7.uiScale()
	local v_u_207 = math.ceil(v206) + 12
	local function v_u_210() -- name: barW
		-- upvalues: (copy) v_u_194, (ref) v_u_7
		local v208 = v_u_194.AbsoluteSize.Y <= 0 and 0 or v_u_194.AbsoluteSize.Y / 64
		if v_u_7.devViewport() or (v208 <= 0 or v_u_194.AbsoluteSize.X <= 0) then
			return v_u_7.safeRefSize().X
		end
		local v209 = v_u_194.AbsoluteSize.X / v208
		return math.floor(v209)
	end
	if v_u_193 and v_u_7.isPhone() then
		local v211 = v_u_210() - 72 - 17 - 128 - 32 - 168
		local v212 = v_u_2.TopbarInset.Min.X
		local v213 = v_u_191()
		local v214 = math.max(v212, v213, 0) / v_u_7.uiScale()
		local v215 = math.ceil(v214) + 12
		if v211 < v_u_207 then
			v_u_207 = math.max(v211, v215)
		end
	end
	local v216 = v_u_210()
	if not v_u_193 then
		local v217 = 0
		for v218 in v_u_13 do
			local v219 = v_u_197[v218] + 24
			v217 = v217 + math.max(v_u_195, v219)
		end
		local v_u_220
		if v217 + v_u_201 * 33 > v216 - (v_u_207 + 152 + 17) - 176 - 32 then
			v_u_220 = true
		else
			v_u_220 = false
		end
	end
	local v_u_221 = 33
	local v_u_222 = 152
	local v_u_223 = 176
	local v_u_224 = v_u_207 + v_u_222 + 17
	local v_u_225 = v_u_6.new("Frame", {
		["Name"] = "Wordmark",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_207, 8),
		["Size"] = UDim2.fromOffset(v_u_222, 48)
	}, v_u_194)
	local v_u_226 = v_u_6.label({
		["parent"] = nil,
		["text"] = "HUSH",
		["style"] = "h1",
		["textSize"] = 34,
		["size"] = nil,
		["track"] = true,
		["parent"] = v_u_225,
		["size"] = UDim2.new(1, 0, 0, 34)
	})
	local v_u_227 = v_u_6.new("Frame", {
		["Name"] = "Rule",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_8.accent,
		["Position"] = UDim2.fromOffset(0, 38),
		["Size"] = UDim2.fromOffset(24, 2)
	}, v_u_225)
	local v_u_228 = v_u_6.label({
		["parent"] = nil,
		["text"] = "STILLWATER QZ",
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_225,
		["color"] = v_u_8.text2,
		["position"] = UDim2.fromOffset(32, 32),
		["size"] = UDim2.fromOffset(120, 14)
	})
	local v_u_229 = v_u_6.new("Frame", {
		["Name"] = "Sep",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_8.line,
		["Position"] = UDim2.fromOffset(v_u_207 + v_u_222 + 8, 20),
		["Size"] = UDim2.fromOffset(1, 24)
	}, v_u_194)
	local v_u_230 = v_u_6.new("ScrollingFrame", {
		["Name"] = "Tabs",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 0,
		["ElasticBehavior"] = nil,
		["ClipsDescendants"] = true,
		["Position"] = UDim2.fromOffset(v_u_224, 0),
		["Size"] = UDim2.new(1, -v_u_224 - v_u_223 - 32, 1, 0),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
		["ScrollingDirection"] = Enum.ScrollingDirection.X,
		["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
	}, v_u_194)
	v_u_6.layout(v_u_230, "h", 0)
	local v_u_231 = v_u_7.safeRefSize().X - v_u_224 - v_u_223 - 32
	local v232
	if #v_u_13 > 0 then
		v232 = v_u_13[#v_u_13].group
	else
		v232 = nil
	end
	local v_u_233 = v_u_193 and 8 or 12
	local v_u_234 = v_u_221
	local v_u_235 = 0
	local function v_u_244(p236, p237) -- name: revealInStrip
		-- upvalues: (copy) v_u_230, (ref) v_u_7
		if v_u_230.Parent and p236.Parent then
			if p237 then
				v_u_230.CanvasPosition = Vector2.new(0, 0)
				return
			else
				local v238 = v_u_7.uiScale()
				local v239 = math.max(v238, 0.01)
				local v240 = (p236.AbsolutePosition.X - v_u_230.AbsolutePosition.X + v_u_230.CanvasPosition.X) / v239
				local v241 = p236.AbsoluteSize.X / v239
				local v242 = v_u_230.AbsoluteSize.X / v239
				if v242 >= 8 and v241 >= 1 then
					local v243 = v_u_230.CanvasPosition.X / v239
					if v240 < v243 + 56 then
						v243 = v240 - 60
					elseif v240 + v241 > v243 + v242 - 56 then
						v243 = v240 + v241 - v242 + 60
					end
					v_u_230.CanvasPosition = Vector2.new(math.max(0, v243) * v239, 0)
				end
			end
		else
			return
		end
	end
	local v_u_245 = {}
	local v_u_246 = {}
	local function v_u_255(p247) -- name: applyTight
		-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_222, (ref) v_u_223, (copy) v_u_193, (ref) v_u_224, (ref) v_u_207, (copy) v_u_225, (copy) v_u_226, (copy) v_u_227, (copy) v_u_228, (copy) v_u_229, (copy) v_u_230, (copy) v_u_246, (copy) v_u_194
		v_u_220 = p247
		v_u_221 = p247 and 21 or 33
		v_u_222 = p247 and 72 or 152
		v_u_223 = v_u_193 and 128 or (p247 and 140 or 176)
		v_u_224 = v_u_207 + v_u_222 + 17
		v_u_225.Position = UDim2.fromOffset(v_u_207, p247 and 12 or 8)
		v_u_225.Size = UDim2.fromOffset(v_u_222, 48)
		v_u_226.TextSize = p247 and 28 or 34
		v_u_226.Size = UDim2.new(1, 0, 0, p247 and 28 or 34)
		v_u_227.Position = UDim2.fromOffset(0, p247 and 32 or 38)
		v_u_227.Size = UDim2.fromOffset(p247 and 16 or 24, 2)
		v_u_228.Visible = not p247
		v_u_229.Position = UDim2.fromOffset(v_u_207 + v_u_222 + 8, 20)
		v_u_230.Position = UDim2.fromOffset(v_u_224, 0)
		v_u_230.Size = UDim2.new(1, -v_u_224 - v_u_223 - 32, 1, 0)
		for _, v248 in v_u_246 do
			local v249 = v248.line
			local v250 = UDim2.new
			local v251 = v_u_221 / 2
			v249.Position = v250(1, -math.floor(v251), 0, 22)
		end
		local v252 = v_u_194:FindFirstChild("MoreFade")
		if v252 then
			v252.Position = UDim2.new(1, -v_u_223 - 32, 0, 0)
		end
		local v253 = v_u_194:FindFirstChild("LessFade")
		if v253 then
			v253.Position = UDim2.fromOffset(v_u_224, 0)
		end
		local v254 = v_u_194:FindFirstChild("Cash")
		if v254 then
			v254.Size = UDim2.fromOffset(v_u_223, 40)
		end
	end
	v_u_255(v_u_220)
	local function v_u_282() -- name: relayout
		-- upvalues: (copy) v_u_210, (copy) v_u_193, (ref) v_u_13, (copy) v_u_195, (copy) v_u_197, (ref) v_u_201, (ref) v_u_207, (ref) v_u_220, (copy) v_u_255, (ref) v_u_231, (ref) v_u_224, (ref) v_u_223, (ref) v_u_233, (ref) v_u_221, (ref) v_u_234, (ref) v_u_235, (copy) v_u_245, (copy) v_u_246, (ref) v_u_11, (ref) v_u_49, (copy) v_u_230
		local v256 = v_u_210()
		local v257 = v_u_193
		if not v257 then
			local v258 = 0
			for v259 in v_u_13 do
				local v260 = v_u_195
				local v261 = v_u_197[v259] + 24
				v258 = v258 + math.max(v260, v261)
			end
			if v258 + v_u_201 * 33 > v256 - (v_u_207 + 152 + 17) - 176 - 32 then
				v257 = true
			else
				v257 = false
			end
		end
		if v257 ~= v_u_220 then
			v_u_255(v257)
		end
		v_u_231 = v256 - v_u_224 - v_u_223 - 32
		v_u_233 = v_u_193 and 8 or 12
		for _, v262 in v_u_193 and {
			16,
			14,
			12,
			10,
			8,
			6
		} or {
			26,
			24,
			22,
			20,
			18,
			16,
			14,
			12
		} do
			local v263 = 0
			for v264 in v_u_13 do
				local v265 = v_u_195
				local v266 = v_u_197[v264] + v262 * 2
				v263 = v263 + math.max(v265, v266)
			end
			if v263 + v_u_201 * v_u_221 > v_u_231 then
				break
			end
			v_u_233 = v262
		end
		local v267 = v_u_221
		local v268 = v_u_231
		local v269 = v_u_233
		local v270 = 0
		for v271 in v_u_13 do
			local v272 = v_u_195
			local v273 = v_u_197[v271] + v269 * 2
			v270 = v270 + math.max(v272, v273)
		end
		local v274 = v268 - v270 - (v_u_201 - 1) * v_u_221
		v_u_234 = math.max(v267, v274)
		v_u_235 = 0
		for _, v275 in v_u_245 do
			local v276 = v_u_195
			local v277 = v275.textW + v_u_233 * 2
			local v278 = math.max(v276, v277)
			v_u_235 = v_u_235 + v278
			if v275.btn.Size.X.Offset == v278 then
				continue
			end
			v275.btn.Size = UDim2.new(0, v278, 1, 0)
		end
		for _, v279 in v_u_246 do
			local v280
			if v279.last then
				v280 = v_u_234
			else
				v280 = v_u_221
			end
			v_u_235 = v_u_235 + v280
			if v279.frame.Size.X.Offset == v280 then
				continue
			end
			v279.frame.Size = UDim2.new(0, v280, 1, 0)
		end
		local v281 = v_u_220
		v_u_11:SetAttribute("MenuTopBar", ("pad=%d spacer=%d view=%d content=%d tight=%s bar=%d"):format(v_u_233, v_u_234, v_u_231, v_u_235, tostring(v281), v256))
		if v_u_49 ~= nil and (v_u_13[1] ~= nil and v_u_49 == v_u_13[1].id) then
			v_u_230.CanvasPosition = Vector2.new(0, 0)
		end
	end
	local v283 = v_u_233
	local v_u_284 = {}
	for v_u_285, v_u_286 in v_u_13 do
		if v_u_285 > 1 and v_u_286.group ~= v_u_13[v_u_285 - 1].group then
			local v287 = v_u_6.new
			local v288 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["LayoutOrder"] = nil,
				["Size"] = nil
			}
			local v289 = v_u_286.group
			v288.Name = "GroupGap_" .. tostring(v289)
			v288.LayoutOrder = v_u_285 * 10 - 5
			v288.Size = UDim2.new(0, v_u_221, 1, 0)
			local v290 = v287("Frame", v288, v_u_230)
			local v291 = v_u_6.new
			local v292 = {
				["Name"] = "Line",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_8.line,
				["AnchorPoint"] = Vector2.new(0.5, 0)
			}
			local v293 = UDim2.new
			local v294 = v_u_221 / 2
			v292.Position = v293(1, -math.floor(v294), 0, 22)
			v292.Size = UDim2.fromOffset(1, 20)
			local v295 = {
				["frame"] = v290,
				["line"] = v291("Frame", v292, v290),
				["last"] = v_u_286.group == v232
			}
			table.insert(v_u_246, v295)
		end
		local v296 = v_u_197[v_u_285]
		local v297 = v_u_6.new
		local v298 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["Name"] = "Tab_" .. v_u_286.id,
			["LayoutOrder"] = v_u_285 * 10
		}
		local v299 = UDim2.new
		local v300 = v296 + v283 * 2
		v298.Size = v299(0, math.max(v_u_195, v300), 1, 0)
		local v_u_301 = v297("TextButton", v298, v_u_230)
		table.insert(v_u_284, v_u_301)
		table.insert(v_u_245, {
			["btn"] = v_u_301,
			["textW"] = v296
		})
		local v_u_302 = v_u_6.new("TextLabel", {
			["Name"] = "Text",
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Text"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["FontFace"] = v_u_7.font.heading,
			["TextSize"] = v196,
			["TextColor3"] = v_u_8.text2,
			["Text"] = v_u_7.track(string.upper(v_u_286.text), 1),
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_301)
		local v303 = v_u_6.new
		local v304 = {
			["Name"] = "Line",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_8.accent,
			["AnchorPoint"] = Vector2.new(0, 1)
		}
		local v305 = UDim2.new
		local v306 = v296 / 2
		v304.Position = v305(0.5, -math.floor(v306), 1, -12)
		v304.Size = UDim2.new(0, 0, 0, 2)
		local v_u_307 = v303("Frame", v304, v_u_301)
		local v308 = v_u_6.new
		local v309 = {
			["Name"] = "Dot",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_8.accent
		}
		local v310 = UDim2.new
		local v311 = v296 / 2
		v309.Position = v310(0.5, math.ceil(v311) + 2, 0, 20)
		v309.Size = UDim2.fromOffset(6, 6)
		local v_u_312 = {
			["btn"] = nil,
			["lbl"] = nil,
			["line"] = nil,
			["dot"] = nil,
			["hover"] = false,
			["textW"] = nil,
			["btn"] = v_u_301,
			["lbl"] = v_u_302,
			["line"] = v_u_307,
			["dot"] = v308("Frame", v309, v_u_301),
			["textW"] = v296
		}
		v_u_47[v_u_286.id] = v_u_312
		local function v_u_322() -- name: paint
			-- upvalues: (ref) v_u_49, (copy) v_u_286, (copy) v_u_302, (ref) v_u_8, (copy) v_u_307, (copy) v_u_312, (ref) v_u_6, (copy) v_u_244, (copy) v_u_301, (copy) v_u_285
			local v313 = v_u_49 == v_u_286.id
			if v313 then
				v_u_302.TextColor3 = v_u_8.text
				v_u_307.BackgroundColor3 = v_u_8.accent
				v_u_307.Size = UDim2.fromOffset(v_u_312.textW, 2)
			elseif not v_u_312.hover then
				v_u_302.TextColor3 = v_u_8.text2
				v_u_307.Size = UDim2.fromOffset(0, 2)
			end
			local v314 = v_u_6.tween
			local v315 = v_u_302
			local v316 = {}
			local v317
			if v313 or v_u_312.hover then
				v317 = v_u_8.text
			else
				v317 = v_u_8.text2
			end
			v316.TextColor3 = v317
			v314(v315, v316, "fast")
			local v318 = v_u_6.tween
			local v319 = v_u_307
			local v320 = {
				["Size"] = UDim2.fromOffset(not (v313 or v_u_312.hover) and 0 or v_u_312.textW, 2)
			}
			local v321
			if v313 then
				v321 = v_u_8.accent
			else
				v321 = v_u_8.lineStrong
			end
			v320.BackgroundColor3 = v321
			v318(v319, v320, v_u_312.hover and not v313 and "slow" or "fast")
			if v313 then
				task.defer(function()
					-- upvalues: (ref) v_u_244, (ref) v_u_301, (ref) v_u_285
					v_u_244(v_u_301, v_u_285 == 1)
				end)
			end
		end
		v_u_312.paint = v_u_322
		v_u_301.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_312, (ref) v_u_49, (copy) v_u_286, (ref) v_u_6, (ref) v_u_7, (copy) v_u_322
			v_u_312.hover = true
			if v_u_49 ~= v_u_286.id then
				v_u_6.sound(v_u_7.sounds.hover)
			end
			v_u_322()
		end)
		v_u_301.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_312, (copy) v_u_322
			v_u_312.hover = false
			v_u_322()
		end)
		v_u_301.SelectionImageObject = v_u_6.selectionImage()
		v_u_301.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_312, (copy) v_u_322
			v_u_312.hover = true
			v_u_322()
		end)
		v_u_301.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_312, (copy) v_u_322
			v_u_312.hover = false
			v_u_322()
		end)
		v_u_301.Activated:Connect(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_286
			v_u_4.setTab(v_u_286.id)
		end)
		if v_u_286.id == "hideout" then
			v_u_6.tooltip(v_u_301, function()
				-- upvalues: (ref) v_u_104, (ref) v_u_11
				return {
					["title"] = "HIDEOUT",
					["body"] = nil,
					["body"] = v_u_104().hideoutTip(v_u_11:GetAttribute("MenuHideoutReady"))
				}
			end)
		else
			if v_u_286.id ~= "character" then
				continue
			end
			v_u_6.tooltip(v_u_301, function()
				-- upvalues: (ref) v_u_29, (ref) v_u_104
				local v323 = v_u_29.derived()
				local v324 = v_u_29.profile
				local v325 = v323.waiting
				local v326 = tonumber(v325)
				if not v326 then
					local v327
					if type(v324) == "table" then
						local v328 = v324.inv
						if type(v328) == "table" then
							local v329 = v324.inv.overflow
							v327 = tonumber(v329)
						else
							v327 = nil
						end
					else
						v327 = nil
					end
					v326 = v327 or 0
				end
				return {
					["title"] = "CHARACTER",
					["body"] = nil,
					["body"] = v_u_104().characterTip(v326)
				}
			end)
		end
	end
	for v330, v331 in v_u_284 do
		v331.NextSelectionLeft = v_u_284[v330 - 1]
		if v330 >= #v_u_284 then
			continue
		end
		v331.NextSelectionRight = v_u_284[v330 + 1]
	end
	local v_u_332 = v_u_6.new("Frame", {
		["Name"] = "MoreFade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_8.bgDeep,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -v_u_223 - 32, 0, 0),
		["Size"] = UDim2.new(0, 56, 1, 0)
	}, v_u_194)
	v_u_6.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.15) })
	}, v_u_332)
	v_u_6.label({
		["parent"] = nil,
		["name"] = "More",
		["text"] = "\226\128\186",
		["style"] = "h2",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_332,
		["color"] = v_u_8.text2,
		["position"] = UDim2.new(0, 0, 0, 0),
		["size"] = UDim2.new(1, -4, 1, -4)
	})
	local v_u_333 = v_u_6.new("Frame", {
		["Name"] = "LessFade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_8.bgDeep,
		["Position"] = UDim2.fromOffset(v_u_224, 0),
		["Size"] = UDim2.new(0, 56, 1, 0)
	}, v_u_194)
	v_u_6.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
	}, v_u_333)
	v_u_6.label({
		["parent"] = nil,
		["name"] = "Less",
		["text"] = "\226\128\185",
		["style"] = "h2",
		["color"] = nil,
		["align"] = "left",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_333,
		["color"] = v_u_8.text2,
		["position"] = UDim2.new(0, 4, 0, 0),
		["size"] = UDim2.new(1, -4, 1, -4)
	})
	local v_u_334 = {}
	for _, v335 in {
		{ v_u_332, 1 },
		{ v_u_333, -1 }
	} do
		local v336 = v_u_6.new("TextButton", {
			["Name"] = "Hit",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 7,
			["Selectable"] = false,
			["Size"] = UDim2.fromScale(1, 1)
		}, v335[1])
		local v_u_337 = v335[2]
		v_u_334[v_u_337] = v336
		v336.Activated:Connect(function()
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_337, (copy) v_u_230
			v_u_6.sound(v_u_7.sounds.click)
			local v338 = v_u_337
			local v339 = v_u_230.AbsoluteSize.X
			if v339 > 8 then
				local v340 = v_u_230.AbsoluteCanvasSize.X - v339
				local v341 = math.max(0, v340)
				local v342 = v_u_230.CanvasPosition.X + v338 * v339 * 0.7
				local v343 = math.clamp(v342, 0, v341)
				v_u_230.CanvasPosition = Vector2.new(v343, 0)
			end
		end)
	end
	local function v_u_358() -- name: updateHits
		-- upvalues: (ref) v_u_5, (copy) v_u_230, (copy) v_u_284, (ref) v_u_7, (copy) v_u_334, (ref) v_u_224, (ref) v_u_207
		local v_u_344 = "MenuTabFade"
		local function v345()
			-- upvalues: (ref) v_u_5, (copy) v_u_344
			return v_u_5.lib[v_u_344]
		end
		local v346, v347 = pcall(v345)
		if not v346 or type(v347) ~= "table" then
			warn("[Menu] lib missing:", "MenuTabFade", v347)
			v347 = nil
		end
		if v347 then
			local v348 = v347.areasFor
			if type(v348) == "function" then
				local v349 = v_u_230.AbsolutePosition.X
				local v350 = v349 + v_u_230.AbsoluteSize.X
				local v351 = {}
				for _, v352 in v_u_284 do
					if not v352.Visible or v352.Parent == nil then
						continue
					end
					local v353 = {
						["l"] = v352.AbsolutePosition.X,
						["r"] = v352.AbsolutePosition.X + v352.AbsoluteSize.X
					}
					table.insert(v351, v353)
				end
				local v354 = v_u_7.uiScale()
				local v355 = v_u_334[1]
				local v356 = v_u_334[-1]
				local v357 = v347.areasFor(v351, v349, v350, v354, v_u_224, v_u_207)
				if v355 then
					v355.AnchorPoint = Vector2.new(1, 0)
					v355.Position = UDim2.new(1, v357.right.out, 0, 0)
					v355.Size = UDim2.new(0, v357.right.w + v357.right.out, 1, 0)
				end
				if v356 then
					v356.AnchorPoint = Vector2.new(0, 0)
					v356.Position = UDim2.new(0, -v357.left.out, 0, 0)
					v356.Size = UDim2.new(0, v357.left.w + v357.left.out, 1, 0)
				end
				return
			end
		end
	end
	local function v366() -- name: updateFade
		-- upvalues: (copy) v_u_230, (copy) v_u_332, (copy) v_u_333, (copy) v_u_358
		local v359 = v_u_230.AbsoluteCanvasSize.X - v_u_230.AbsoluteSize.X
		local v360 = math.max(0, v359)
		local v361 = v_u_230.CanvasPosition.X
		local v362 = v_u_332
		local v363
		if v360 > 2 then
			v363 = v361 < v360 - 4
		else
			v363 = false
		end
		v362.Visible = v363
		local v364 = v_u_333
		local v365
		if v360 > 2 then
			v365 = v361 > 4
		else
			v365 = false
		end
		v364.Visible = v365
		v_u_358()
	end
	v_u_230:GetPropertyChangedSignal("CanvasPosition"):Connect(v366)
	v_u_230:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v366)
	v_u_230:GetPropertyChangedSignal("AbsoluteSize"):Connect(v366)
	v_u_282()
	v_u_194:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_282, (copy) v_u_230, (copy) v_u_332, (copy) v_u_333, (copy) v_u_358
		v_u_282()
		local v367 = v_u_230.AbsoluteCanvasSize.X - v_u_230.AbsoluteSize.X
		local v368 = math.max(0, v367)
		local v369 = v_u_230.CanvasPosition.X
		local v370 = v_u_332
		local v371
		if v368 > 2 then
			v371 = v369 < v368 - 4
		else
			v371 = false
		end
		v370.Visible = v371
		local v372 = v_u_333
		local v373
		if v368 > 2 then
			v373 = v369 > 4
		else
			v373 = false
		end
		v372.Visible = v373
		v_u_358()
	end)
	local v374 = v_u_230.AbsoluteCanvasSize.X - v_u_230.AbsoluteSize.X
	local v375 = math.max(0, v374)
	local v376 = v_u_230.CanvasPosition.X
	local v377
	if v375 > 2 then
		v377 = v376 < v375 - 4
	else
		v377 = false
	end
	v_u_332.Visible = v377
	local v378
	if v375 > 2 then
		v378 = v376 > 4
	else
		v378 = false
	end
	v_u_333.Visible = v378
	v_u_358()
	local v379 = v_u_6.new("Frame", {
		["Name"] = "Cash",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -24, 0, 12),
		["Size"] = UDim2.fromOffset(v_u_223, 40)
	}, v_u_194)
	v_u_6.label({
		["parent"] = nil,
		["text"] = "Cash",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["parent"] = v379,
		["color"] = v_u_8.text2,
		["size"] = UDim2.new(1, 0, 0, 14)
	})
	v_u_61 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = "$-",
		["style"] = "monoL",
		["textSize"] = 20,
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v379,
		["color"] = v_u_8.accent,
		["position"] = UDim2.fromOffset(0, 14),
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_6.tooltip(v379, function()
		-- upvalues: (ref) v_u_29, (ref) v_u_5, (ref) v_u_104, (ref) v_u_9
		local v380 = v_u_29.derived()
		local v381 = v_u_5.lib.InvUITile
		local v382 = v_u_29.profile
		if v382 then
			v382 = v_u_29.profile.inv
		end
		local v383 = v381.sellStash
		local v384, v385 = pcall(v383, v382)
		local v386 = v381.sellKit
		local v387, v388 = pcall(v386, v382)
		local v389 = v_u_29.profile and v_u_29.profile.cash or 0
		local v390 = (not v384 or type(v385) ~= "number") and (v380.stashValue or 0) or v385
		local v391 = (not v387 or type(v388) ~= "number") and 0 or v388
		local v392 = v_u_104().fundsLines(v389, v390, v391, v380.ordersHeld, v_u_9.money)
		if not v384 or (not v387 or (type(v385) ~= "number" or type(v388) ~= "number")) then
			v392[#v392].value = v_u_9.money(v380.netWorth or 0)
		end
		return {
			["title"] = "FUNDS",
			["lines"] = nil,
			["lines"] = v392
		}
	end)
end
local function v_u_399() -- name: updateCash
	-- upvalues: (copy) v_u_29, (ref) v_u_61, (ref) v_u_62, (ref) v_u_9, (ref) v_u_6, (ref) v_u_52
	local v394 = v_u_29.profile
	local v395
	if type(v394) == "table" then
		local v396 = v394.cash
		v395 = tonumber(v396)
	else
		v395 = nil
	end
	if v_u_61 and v395 then
		if v_u_62 == nil then
			v_u_61.Text = v_u_9.money(v395)
		elseif v395 ~= v_u_62 then
			local v398 = {
				["from"] = nil,
				["duration"] = 0.7,
				["format"] = nil,
				["from"] = v_u_62,
				["format"] = function(p397) -- name: format
					-- upvalues: (ref) v_u_9
					return v_u_9.money(p397)
				end
			}
			v_u_6.countUp(v_u_61, v395, v398)
		end
		v_u_62 = v395
		if v_u_52 then
			v_u_52.setCash(v_u_9.money(v395))
		end
	end
end
local function v_u_462() -- name: updateTabBadges
	-- upvalues: (copy) v_u_29, (ref) v_u_68, (copy) v_u_11, (ref) v_u_52, (copy) v_u_47, (ref) v_u_6, (ref) v_u_8, (ref) v_u_97, (ref) v_u_9
	local v400 = v_u_29.cache.tasks and v_u_29.cache.tasks.data or v_u_68
	local v401 = 0
	local v402 = 0
	if type(v400) == "table" then
		local v403 = v400.counts
		if type(v403) == "table" then
			local v404 = v400.counts.ready
			v401 = tonumber(v404) or 0
		end
	end
	if type(v400) == "table" then
		local v405 = v400.tasks
		if type(v405) == "table" then
			for _, v406 in v400.tasks do
				if type(v406) ~= "table" or v406.state ~= "available" then
					continue
				end
				v402 = v402 + 1
			end
		end
	end
	v_u_11:SetAttribute("MenuTasksBadge", ("%d/%d"):format(v402, v401))
	if v_u_52 then
		v_u_52.badges()
	end
	local v407 = v_u_47.tasks
	if v407 then
		local v408 = v401 + v402
		v407.dot.Visible = false
		local v409 = v407.btn:FindFirstChild("Count")
		if not v409 then
			local v410 = v_u_6.new
			local v411 = {
				["Name"] = "Count",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 6,
				["BackgroundColor3"] = v_u_8.accent,
				["AnchorPoint"] = Vector2.new(0, 0.5)
			}
			local v412 = UDim2.new
			local v413 = v407.textW / 2
			v411.Position = v412(0.5, math.ceil(v413) + 3, 0, 22)
			v411.Size = UDim2.fromOffset(16, 16)
			v409 = v410("Frame", v411, v407.btn)
			v_u_6.label({
				["parent"] = nil,
				["name"] = "N",
				["text"] = "",
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["zindex"] = 7,
				["parent"] = v409,
				["color"] = v_u_8.bgDeep,
				["size"] = UDim2.fromScale(1, 1)
			})
		end
		v409.Visible = v408 > 0
		local v414
		if v401 > 0 then
			v414 = v_u_8.success
		else
			v414 = v_u_8.accent
		end
		v409.BackgroundColor3 = v414
		local v415 = v409:FindFirstChild("N")
		if v415 then
			v415.Text = v408 > 9 and "9+" or tostring(v408)
		end
		v409.Size = UDim2.fromOffset(v408 > 9 and 22 or 16, 16)
	end
	local v416 = v_u_47.character
	if v416 then
		local v417 = v_u_29.profile
		local v418
		if type(v417) == "table" then
			local v419 = v417.inv
			if type(v419) == "table" then
				local v420 = v417.inv.overflow
				v418 = tonumber(v420) or 0
			else
				v418 = 0
			end
		else
			v418 = 0
		end
		v416.dot.Visible = (v418 or 0) > 0
	end
	local v421 = v_u_47.hideout
	if v421 then
		local v422 = 0
		local v423 = v_u_29.profile
		local v424 = os.time() + v_u_97
		if type(v423) == "table" then
			local v425 = v423.crafts
			if type(v425) == "table" then
				for _, v426 in v423.crafts do
					if type(v426) ~= "table" then
						continue
					end
					local v427 = v426.readyAt
					if type(v427) ~= "number" or v426.readyAt > v424 then
						continue
					end
					v422 = v422 + 1
				end
			end
		end
		v421.dot.Visible = v422 > 0
		local v428 = v_u_11
		local v429 = "MenuHideoutReady"
		if v422 <= 0 then
			v422 = nil
		end
		v428:SetAttribute(v429, v422)
	end
	local v430 = v_u_47.traders
	if v430 and (v_u_9 and v_u_9.newOffersTotal) then
		local v431 = v_u_9.newOffersTotal
		local v432, v433 = pcall(v431)
		local v434 = v432 and (tonumber(v433) or 0) or 0
		v430.dot.Visible = v434 > 0
		v_u_11:SetAttribute("MenuTradersNew", v434)
	end
	local v435 = v_u_47.pass
	if v435 then
		local v436 = v_u_11
		v435.dot.Visible = (tonumber(v436:GetAttribute("PassClaimable")) or 0) > 0
	end
	local v437 = v_u_47.store
	if v437 then
		local v438 = v_u_11:GetAttribute("StoreFeatured")
		local v439 = v437.dot
		local v440
		if type(v438) == "number" then
			v440 = v438 > 0
		else
			v440 = false
		end
		v439.Visible = v440
		local v441 = v437.dot
		local v442
		if v_u_11:GetAttribute("StoreFeaturedSale") == true then
			v442 = v_u_6.Theme.color.danger
		else
			v442 = v_u_6.Theme.color.accent
		end
		v441.BackgroundColor3 = v442
	end
	local v443 = v_u_47.starter
	if v443 then
		v443.dot.Visible = true
	end
	local v444 = v_u_47.market
	if v444 then
		local v445 = v_u_11
		local v446 = tonumber(v445:GetAttribute("BmBadge")) or 0
		local v447 = math.floor(v446)
		local v448 = v_u_11
		local v449 = tonumber(v448:GetAttribute("TradeReqCount")) or 0
		local v450 = v447 + math.floor(v449)
		local v451 = v_u_11
		local v452 = tonumber(v451:GetAttribute("BmPending")) or 0
		local v453 = math.floor(v452)
		local v454 = v444.btn:FindFirstChild("Count")
		if not v454 then
			local v455 = v_u_6.new
			local v456 = {
				["Name"] = "Count",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 6,
				["BackgroundColor3"] = v_u_8.success,
				["AnchorPoint"] = Vector2.new(0, 0.5)
			}
			local v457 = UDim2.new
			local v458 = v444.textW / 2
			v456.Position = v457(0.5, math.ceil(v458) + 3, 0, 22)
			v456.Size = UDim2.fromOffset(16, 16)
			v454 = v455("Frame", v456, v444.btn)
			v_u_6.label({
				["parent"] = nil,
				["name"] = "N",
				["text"] = "",
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["zindex"] = 7,
				["parent"] = v454,
				["color"] = v_u_8.bgDeep,
				["size"] = UDim2.fromScale(1, 1)
			})
		end
		v454.Visible = v450 > 0
		local v459 = v454:FindFirstChild("N")
		if v459 then
			v459.Text = v450 > 9 and "9+" or tostring(v450)
		end
		v454.Size = UDim2.fromOffset(v450 > 9 and 22 or 16, 16)
		local v460 = v444.dot
		local v461
		if v450 == 0 then
			v461 = v453 > 0 and true or v_u_11:GetAttribute("RsLive") == true
		else
			v461 = false
		end
		v460.Visible = v461
	end
end
local function v_u_479(p463) -- name: firstOpenTask
	-- upvalues: (copy) v_u_29, (ref) v_u_68, (ref) v_u_5
	local v464 = v_u_29.cache.tasks and v_u_29.cache.tasks.data or v_u_68
	if type(v464) == "table" then
		local v465 = v464.tasks
		if type(v465) == "table" then
			local v466 = v464.order
			if type(v466) == "table" then
				local v_u_467 = nil
				local function v468()
					-- upvalues: (ref) v_u_467, (ref) v_u_5
					v_u_467 = v_u_5.shared.Tasks
				end
				pcall(v468)
				local v469 = v_u_467
				local v470 = 99
				local v471 = false
				local v472 = {
					["ready"] = 1,
					["active"] = 2,
					["available"] = 3
				}
				local v473 = nil
				for _, v474 in v464.order do
					if v469 then
						local v475 = v469.get(v474)
					end
					local v476 = v472[(v464.tasks[v474] or {}).state or ""]
					local v477 = (v464.tasks[v474] or {}).lockLine
					local v478
					if type(v477) == "string" then
						v478 = (v464.tasks[v474] or {}).lockLine ~= ""
					else
						v478 = false
					end
					if not v476 or v476 >= v470 and (v476 ~= v470 or (not v471 or v478)) or p463 ~= nil and (not v475 or v475.giver ~= p463) then
						continue
					end
					v473 = v474
					v471 = v478
					v470 = v476
				end
				return v473
			end
		end
	end
	return nil
end
v_u_29.firstOpenTask = v_u_479
local function v_u_484(p_u_480) -- name: v2lib
	-- upvalues: (ref) v_u_5
	local function v481()
		-- upvalues: (ref) v_u_5, (copy) p_u_480
		return v_u_5.lib[p_u_480]
	end
	local v482, v483 = pcall(v481)
	if v482 and type(v483) == "table" then
		return v483
	else
		return nil
	end
end
local function v_u_497() -- name: v2Facts
	-- upvalues: (ref) v_u_5, (copy) v_u_11, (ref) v_u_14
	local v_u_485 = {}
	for _, v_u_486 in { "Blackmarket" } do
		local function v487()
			-- upvalues: (copy) v_u_485, (copy) v_u_486, (ref) v_u_5
			v_u_485[v_u_486] = v_u_5.config.flag(v_u_486)
		end
		pcall(v487)
	end
	local v488 = {}
	for _, v_u_489 in { "blackmarket", "seasonPass", "clans" } do
		local function v490()
			-- upvalues: (ref) v_u_5, (copy) v_u_489
			return v_u_5.shared.GameMode.rule(v_u_489)
		end
		local v491, v492 = pcall(v490)
		if not v491 then
			v492 = false
		end
		v488[v_u_489] = v492
	end
	local v493 = {
		["flags"] = nil,
		["rules"] = nil,
		["marketBlocked"] = nil,
		["openWorld"] = false,
		["hideoutV2"] = false,
		["hidden"] = nil,
		["starter"] = nil,
		["flags"] = v_u_485,
		["rules"] = v488
	}
	local v494 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
	local v495
	if v494 then
		v495 = v494:GetAttribute("BmRm")
	else
		v495 = nil
	end
	local v496
	if v495 == "block" then
		v496 = v_u_11:GetAttribute("PaidTrading") ~= true
	else
		v496 = false
	end
	v493.marketBlocked = v496
	v493.hidden = {
		["skills"] = true
	}
	v493.starter = v_u_14()
	return v493
end
local function v_u_508() -- name: v2Device
	-- upvalues: (ref) v_u_5, (copy) v_u_3, (copy) v_u_2, (copy) v_u_11
	local v_u_498 = "MenuShellRoute"
	local function v499()
		-- upvalues: (ref) v_u_5, (copy) v_u_498
		return v_u_5.lib[v_u_498]
	end
	local v500, v501 = pcall(v499)
	if not v500 or type(v501) ~= "table" then
		v501 = nil
	end
	if v501 == nil then
		return false
	end
	local v_u_502 = {
		["touch"] = false,
		["keyboard"] = false,
		["tenFoot"] = false,
		["onPc"] = false
	}
	local function v503()
		-- upvalues: (copy) v_u_502, (ref) v_u_3
		v_u_502.touch = v_u_3.TouchEnabled
		v_u_502.keyboard = v_u_3.KeyboardEnabled
	end
	pcall(v503)
	local function v504()
		-- upvalues: (copy) v_u_502, (ref) v_u_2
		v_u_502.tenFoot = v_u_2:IsTenFootInterface()
	end
	pcall(v504)
	local function v505()
		-- upvalues: (copy) v_u_502, (ref) v_u_5
		v_u_502.onPc = v_u_5.config.flag("MenuV2OnPc") == true
	end
	pcall(v505)
	local function v507()
		-- upvalues: (ref) v_u_5, (ref) v_u_11, (copy) v_u_502
		if v_u_5.config.flag("MenuStyle") ~= false then
			local v506 = v_u_11:GetAttribute("MenuStyle")
			if v506 == "v2" or v506 == "classic" then
				v_u_502.menuStyle = v506
			end
		end
	end
	pcall(v507)
	return v501.deviceWantsV2(v_u_502)
end
local function v_u_513() -- name: v2Visible
	-- upvalues: (ref) v_u_5, (copy) v_u_497
	local v_u_509 = "MenuCategories"
	local function v510()
		-- upvalues: (ref) v_u_5, (copy) v_u_509
		return v_u_5.lib[v_u_509]
	end
	local v511, v512 = pcall(v510)
	if not v511 or type(v512) ~= "table" then
		v512 = nil
	end
	return v512 == nil and {} or v512.visible(v512.HOME, (v_u_497()))
end
local v_u_564 = {
	["retryPending"] = false,
	["retries"] = nil,
	["retries"] = {},
	["focusHome"] = function() -- name: focusHome
		-- upvalues: (ref) v_u_5, (ref) v_u_51, (ref) v_u_58, (ref) v_u_52, (ref) v_u_6, (ref) v_u_45, (copy) v_u_2
		local v_u_514 = "MenuFlow"
		local function v515()
			-- upvalues: (ref) v_u_5, (copy) v_u_514
			return v_u_5.lib[v_u_514]
		end
		local v516, v517 = pcall(v515)
		if not v516 or type(v517) ~= "table" then
			v517 = nil
		end
		if v517 == nil or not (v_u_51 and (v_u_58 and v_u_52)) then
			return
		else
			local v518, v_u_519 = v517.homeFocus(v_u_52, v_u_6.device() == "Gamepad")
			if v518 == "shell" then
				local v520 = v_u_52.focusHome
				pcall(v520)
			elseif v518 == "direct" then
				task.defer(function()
					-- upvalues: (ref) v_u_58, (ref) v_u_51, (ref) v_u_52, (ref) v_u_45, (copy) v_u_519, (ref) v_u_2
					if v_u_58 and (v_u_51 and (v_u_52 and (v_u_45 ~= nil and v_u_52.category() == nil))) then
						local v521 = v_u_519
						if typeof(v521) == "Instance" and (v_u_519:IsA("GuiObject") and (v_u_519.Parent ~= nil and v_u_519:IsDescendantOf(v_u_45))) then
							v_u_2.SelectedObject = v_u_519
						end
					end
				end)
			end
		end
	end,
	["wanted"] = function() -- name: wanted
		-- upvalues: (ref) v_u_5, (copy) v_u_11, (copy) v_u_508
		local v_u_522 = false
		local function v524()
			-- upvalues: (ref) v_u_522, (ref) v_u_5, (ref) v_u_11, (ref) v_u_508
			local v523
			if v_u_5.config.flag("MenuV2") == true and v_u_11:GetAttribute("OverwatchTarget") == nil then
				v523 = v_u_508()
			else
				v523 = false
			end
			v_u_522 = v523
		end
		pcall(v524)
		return v_u_522
	end,
	["styleTip"] = function() -- name: styleTip
		-- upvalues: (ref) v_u_51, (ref) v_u_58, (ref) v_u_52, (ref) v_u_45, (ref) v_u_5, (copy) v_u_29, (ref) v_u_60
		if v_u_51 and (v_u_58 and (v_u_52 and v_u_45)) then
			local v_u_525 = "MenuTipOnce"
			local function v526()
				-- upvalues: (ref) v_u_5, (copy) v_u_525
				return v_u_5.lib[v_u_525]
			end
			local v527, v528 = pcall(v526)
			if not v527 or type(v528) ~= "table" then
				v528 = nil
			end
			local v_u_529 = "MenuShellRoute"
			local function v530()
				-- upvalues: (ref) v_u_5, (copy) v_u_529
				return v_u_5.lib[v_u_529]
			end
			local v531, v532 = pcall(v530)
			if not v531 or type(v532) ~= "table" then
				v532 = nil
			end
			if v528 == nil or (v532 == nil or v_u_5.config.flag("MenuStyle") == false) then
				return
			else
				local v533 = v_u_29.profile
				local v534
				if type(v533) == "table" then
					local v535 = v_u_29.profile.settings
					if type(v535) == "table" then
						v534 = v_u_29.profile.settings.menuStyle
					else
						v534 = nil
					end
				else
					v534 = nil
				end
				if v534 ~= "v2" and v534 ~= "classic" then
					local v536 = v_u_45
					local v_u_537 = v_u_60
					local v538 = v528.show
					local v539 = v_u_29
					local v541 = {
						["host"] = v536,
						["target"] = function() -- name: target
							-- upvalues: (ref) v_u_52
							if v_u_52 then
								return v_u_52.rowButton("settings")
							else
								return nil
							end
						end,
						["active"] = function() -- name: active
							-- upvalues: (ref) v_u_58, (copy) v_u_537, (ref) v_u_60, (ref) v_u_51, (ref) v_u_52
							local v540 = v_u_58 and (v_u_537 == v_u_60 and v_u_51)
							if v540 then
								if v_u_52 == nil then
									v540 = false
								else
									v540 = v_u_52.category() == nil
								end
							end
							return v540
						end,
						["sides"] = { "above", "below", "left" }
					}
					pcall(v538, v539, "menustyle", v541)
				end
			end
		else
			return
		end
	end,
	["postponeRebuild"] = function(p_u_542, p_u_543) -- name: postponeRebuild
		-- upvalues: (ref) v_u_5, (copy) v_u_564, (copy) v_u_55, (ref) v_u_58, (ref) v_u_44, (ref) v_u_52, (copy) v_u_4
		local v_u_544 = "MenuFlow"
		local function v545()
			-- upvalues: (ref) v_u_5, (copy) v_u_544
			return v_u_5.lib[v_u_544]
		end
		local v546, v547 = pcall(v545)
		if not v546 or type(v547) ~= "table" then
			v547 = nil
		end
		if v547 ~= nil and (not v_u_564.retryPending and p_u_542.rebuildAllowed(v_u_564.retries, os.clock(), 3, 60)) then
			v_u_564.retryPending = true
			task.delay(v547.retryDelay(v_u_55, os.clock(), 4, 10), function()
				-- upvalues: (ref) v_u_564, (ref) v_u_58, (ref) v_u_44, (ref) v_u_52, (copy) p_u_543, (copy) p_u_542, (ref) v_u_55, (ref) v_u_4
				v_u_564.retryPending = false
				if v_u_58 and (v_u_44 and (v_u_52 == p_u_543 and p_u_542.rebuildAllowed(v_u_55, os.clock(), 4, 10))) then
					task.defer(v_u_4.rebuild)
				end
			end)
		end
	end,
	["services"] = function() -- name: services
		-- upvalues: (ref) v_u_5, (copy) v_u_29
		local v_u_548 = "MenuFlow"
		local function v549()
			-- upvalues: (ref) v_u_5, (copy) v_u_548
			return v_u_5.lib[v_u_548]
		end
		local v550, v551 = pcall(v549)
		if not v550 or type(v551) ~= "table" then
			v551 = nil
		end
		if v551 ~= nil then
			local v552 = v551.startServices
			local v553 = v_u_29
			pcall(v552, v553)
		end
	end,
	["pass"] = function() -- name: pass
		-- upvalues: (ref) v_u_5, (ref) v_u_51, (ref) v_u_58, (ref) v_u_52, (copy) v_u_29, (copy) v_u_11
		local v_u_554 = "MenuFlow"
		local function v555()
			-- upvalues: (ref) v_u_5, (copy) v_u_554
			return v_u_5.lib[v_u_554]
		end
		local v556, v557 = pcall(v555)
		if not v556 or type(v557) ~= "table" then
			v557 = nil
		end
		if v557 ~= nil and (v_u_51 and (v_u_58 and v_u_52)) then
			local v558 = v557.refreshPass
			local v559 = v_u_29
			local v563 = {
				["spawn"] = task.spawn,
				["setAttr"] = function(p560, p561) -- name: setAttr
					-- upvalues: (ref) v_u_11
					v_u_11:SetAttribute(p560, p561)
				end,
				["alive"] = function() -- name: alive
					-- upvalues: (ref) v_u_58, (ref) v_u_51, (ref) v_u_52
					local v562 = v_u_58 and v_u_51
					if v562 then
						if v_u_52 == nil then
							v562 = false
						else
							v562 = v_u_52.category() == nil
						end
					end
					return v562
				end
			}
			pcall(v558, v559, v563)
		end
	end
}
local function v_u_579(p565, p566, p567, _) -- name: v2Changed
	-- upvalues: (ref) v_u_49, (copy) v_u_11, (ref) v_u_5, (ref) v_u_56, (ref) v_u_6, (ref) v_u_7, (ref) v_u_100, (ref) v_u_63, (copy) v_u_186, (copy) v_u_29, (copy) v_u_564
	v_u_49 = p567
	v_u_11:SetAttribute("MenuTab", p567 or "play")
	v_u_11:SetAttribute("MenuCategory", p565 or "home")
	local v_u_568 = "MenuShellRoute"
	local function v569()
		-- upvalues: (ref) v_u_5, (copy) v_u_568
		return v_u_5.lib[v_u_568]
	end
	local v570, v571 = pcall(v569)
	if not v570 or type(v571) ~= "table" then
		v571 = nil
	end
	local v572
	if v571 then
		v572 = v571.whereTab(p565, p566)
	else
		v572 = nil
	end
	if v572 then
		local v573 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
		if v573 then
			v573 = v573:FindFirstChild("party.op")
		end
		if not (v573 and v573:IsA("RemoteEvent")) then
			v573 = nil
		end
		if v573 then
			v573:FireServer({
				["op"] = "where",
				["tab"] = nil,
				["tab"] = v572
			})
		end
	end
	if v_u_56 then
		local v574 = v_u_56.refresh
		local v575 = v_u_56
		pcall(v574, v575)
	end
	v_u_6.sound(v_u_7.sounds.tab)
	local v576 = v_u_100
	pcall(v576)
	local v577
	if p565 == nil or p565 == "deploy" then
		v577 = false
	else
		v577 = p565 ~= "character"
	end
	if v577 ~= v_u_63 then
		v_u_63 = v577
		local v578 = v_u_6.blur
		pcall(v578, v577, 10)
	end
	v_u_186()
	v_u_29.syncTutorial()
	if p565 == nil then
		v_u_564.pass()
	end
end
local v_u_580 = {
	["play"] = { "MenuPlay" },
	["starter"] = { "MenuGroupStarter" },
	["character"] = { "MenuCharacter" },
	["traders"] = { "MenuTraders" },
	["market"] = { "MenuMarket" },
	["pass"] = { "MenuPass" },
	["clan"] = { "MenuClan" },
	["tasks"] = { "MenuTasks" },
	["collection"] = { "MenuBook", "collection" },
	["badges"] = { "MenuBadges" },
	["leaderboard"] = { "MenuBook", "leaderboard" },
	["store"] = { "MenuStore" },
	["settings"] = { "MenuSettings" },
	["skins"] = { "MenuCrates" }
}
local v_u_581 = {
	["skins"] = true
}
local function v_u_600(p582) -- name: pageFor
	-- upvalues: (copy) v_u_48, (ref) v_u_6, (ref) v_u_46, (copy) v_u_580, (ref) v_u_51, (ref) v_u_5, (copy) v_u_29, (copy) v_u_11, (ref) v_u_9, (copy) v_u_104
	local v583 = v_u_48[p582]
	if v583 then
		return v583
	end
	local v584 = v_u_6.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Name"] = "Page_" .. p582,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_46)
	local v585 = {
		["frame"] = nil,
		["tab"] = nil,
		["frame"] = v584
	}
	v_u_48[p582] = v585
	local v586 = v_u_580[p582]
	if not v586 then
		if v_u_51 then
			local v_u_587 = "MenuCategories"
			local function v588()
				-- upvalues: (ref) v_u_5, (copy) v_u_587
				return v_u_5.lib[v_u_587]
			end
			local v589, v590 = pcall(v588)
			if not v589 or type(v590) ~= "table" then
				v590 = nil
			end
			local v591
			if v590 then
				v591 = v590.byId(p582)
			else
				v591 = nil
			end
			if v591 then
				v586 = v591.page
			else
				v586 = nil
			end
		else
			v586 = nil
		end
	end
	local v592
	if v586 then
		local v_u_593 = v586[1]
		local function v594()
			-- upvalues: (ref) v_u_5, (copy) v_u_593
			return v_u_5.lib[v_u_593]
		end
		local v595
		v595, v592 = pcall(v594)
		if not v595 or type(v592) ~= "table" then
			warn("[Menu] lib missing:", v_u_593, v592)
			v592 = nil
		end
	else
		v592 = v586
	end
	if v592 then
		local v596
		if v586[2] then
			v596 = v592[v586[2]]
		else
			v596 = v592.new
		end
		if type(v596) == "function" then
			local v597 = v_u_29
			local v598, v599 = pcall(v596, v597, v584)
			if v598 then
				v585.tab = v599
				return v585
			end
			warn("[Menu] tab failed:", p582, v599)
			v_u_11:SetAttribute("ClientError", "menu tab " .. p582 .. ": " .. tostring(v599))
			v_u_9.empty(v584, v_u_104().PAGE_FAILED)
		end
	end
	return v585
end
local function v_u_607(p601, p602, ...) -- name: callTab
	-- upvalues: (copy) v_u_11
	if p601 then
		p601 = p601.tab
	end
	if p601 then
		local v603 = p601[p602]
		if type(v603) == "function" then
			local v604 = p601[p602]
			local v605, v606 = pcall(v604, ...)
			if not v605 then
				warn("[Menu] tab." .. p602 .. " failed:", v606)
				v_u_11:SetAttribute("ClientError", "menu " .. p602 .. ": " .. tostring(v606))
			end
		end
	end
end
local function v_u_610() -- name: paintHideoutTab
	-- upvalues: (ref) v_u_52, (ref) v_u_76, (copy) v_u_47, (ref) v_u_7, (ref) v_u_6
	if v_u_52 then
		v_u_52.setRowText("hideout", v_u_76 > 0 and "ENTERING..." or nil)
	end
	local v608 = v_u_47.hideout
	if v608 then
		v608 = v608.lbl
	end
	if v608 and v608.Parent then
		local v609 = v_u_76 > 0
		v608.Text = v_u_7.track(v609 and "ENTERING..." or "HIDEOUT", 1)
		if v609 and not v608:FindFirstChildOfClass("UITextSizeConstraint") then
			v_u_6.new("UITextSizeConstraint", {
				["MaxTextSize"] = nil,
				["MinTextSize"] = 8,
				["MaxTextSize"] = v608.TextSize
			}, v608)
		end
		v608.TextScaled = v609
	end
end
local function v_u_624() -- name: enterHideout
	-- upvalues: (ref) v_u_76, (copy) v_u_610, (ref) v_u_6, (ref) v_u_7, (ref) v_u_60, (ref) v_u_75, (ref) v_u_59, (ref) v_u_5, (copy) v_u_29, (ref) v_u_74, (copy) v_u_104
	local v_u_611 = os.clock()
	if v_u_76 <= 0 or v_u_611 - v_u_76 >= 10 then
		v_u_76 = v_u_611
		v_u_610()
		v_u_6.sound(v_u_7.sounds.confirm)
		local v_u_612 = v_u_60
		local v613 = v_u_75 + 4.4 - v_u_611
		local v614 = math.max(0, v613)
		task.delay(v614, function()
			-- upvalues: (copy) v_u_612, (ref) v_u_60, (ref) v_u_59, (ref) v_u_76, (copy) v_u_611, (ref) v_u_5, (ref) v_u_75, (ref) v_u_29, (ref) v_u_74, (ref) v_u_104, (ref) v_u_6, (ref) v_u_610
			if v_u_612 == v_u_60 and (v_u_59 == "Menu" and v_u_76 == v_u_611) then
				v_u_5.emit("transit.info", {
					["kind"] = "hideout"
				})
				local v_u_615 = os.clock()
				v_u_75 = v_u_615
				local v616 = v_u_5.controllers.HideoutWorld
				local v617 = false
				if v616 then
					local v618 = v616.enter
					if type(v618) == "function" and not v616._broken then
						local v619 = v616.enter
						v617 = pcall(v619)
					end
				end
				if not v617 then
					v_u_29.op({
						["op"] = "enterHideout"
					})
				end
				task.delay(4, function()
					-- upvalues: (ref) v_u_612, (ref) v_u_60, (ref) v_u_59, (ref) v_u_74, (copy) v_u_615, (ref) v_u_104, (ref) v_u_6, (ref) v_u_76, (ref) v_u_611, (ref) v_u_610
					if v_u_612 == v_u_60 and (v_u_59 == "Menu" and v_u_74 < v_u_615) then
						local v620 = v_u_104().TOAST.hideoutSlow
						local v621 = v620[1]
						local v622 = v620[2]
						local v623 = v_u_6.toast
						pcall(v623, v621, "warn", v622, nil)
						if v_u_76 == v_u_611 and v_u_76 > 0 then
							v_u_76 = 0
							v_u_610()
						end
					end
				end)
			end
		end)
	end
end
function v_u_4.openTraders(p_u_625, p_u_626, p_u_627) -- name: openTraders
	-- upvalues: (copy) v_u_4, (ref) v_u_58, (ref) v_u_46, (copy) v_u_600
	v_u_4.setTab("traders")
	task.defer(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_600, (copy) p_u_625, (copy) p_u_626, (copy) p_u_627
		local v628
		if v_u_58 and v_u_46 then
			v628 = v_u_600("traders")
		else
			v628 = nil
		end
		if v628 then
			v628 = v628.tab
		end
		local v629, v630, v631, v632, v633, v634, v635
		if v628 then
			local v636 = v628.showSub
			if type(v636) == "function" then
				local v637 = v628.showSub
				local v638 = p_u_625 or "sell"
				pcall(v637, v638)
				if p_u_626 and v628 then
					v629 = v628.gotoCard
					if type(v629) == "function" then
						v630 = v628.gotoCard
						v631 = p_u_626
						v632 = p_u_627
						pcall(v630, v631, v632)
					end
				end
			else
				if v628 and v628.subApi then
					v633 = v628.subApi.select
					if type(v633) == "function" then
						v634 = v628.subApi.select
						v635 = p_u_625 or "sell"
						pcall(v634, v635, true)
					end
				end
				if p_u_626 and v628 then
					v629 = v628.gotoCard
					if type(v629) == "function" then
						v630 = v628.gotoCard
						v631 = p_u_626
						v632 = p_u_627
						pcall(v630, v631, v632)
					end
				end
			end
		else
			if v628 and v628.subApi then
				v633 = v628.subApi.select
				if type(v633) == "function" then
					v634 = v628.subApi.select
					v635 = p_u_625 or "sell"
					pcall(v634, v635, true)
				end
			end
			if p_u_626 and v628 then
				v629 = v628.gotoCard
				if type(v629) == "function" then
					v630 = v628.gotoCard
					v631 = p_u_626
					v632 = p_u_627
					pcall(v630, v631, v632)
				end
			end
			return
		end
	end)
end
local v_u_639 = (-1 / 0)
function v_u_4.gunsmithKnow() -- name: gunsmithKnow
	-- upvalues: (ref) v_u_5, (copy) v_u_29, (ref) v_u_68, (ref) v_u_639
	local v640
	if v_u_5 and v_u_5.shared then
		v640 = v_u_5.shared.Gunsmith
	else
		v640 = nil
	end
	if type(v640) == "table" then
		local v641 = v640.know
		if type(v641) == "function" then
			local v642 = v_u_29.cache.tasks
			local v643 = v642 and v642.data or v_u_68
			local v_u_644
			if type(v643) == "table" then
				local v645 = v643.tasks
				if type(v645) == "table" then
					v_u_644 = v643.tasks
				else
					v_u_644 = nil
				end
			else
				v_u_644 = nil
			end
			if (v642 == nil or os.clock() - v642.at > 15) and os.clock() - v_u_639 > 10 then
				v_u_639 = os.clock()
				task.spawn(function()
					-- upvalues: (ref) v_u_29
					local v646 = v_u_29.fetch
					pcall(v646, "tasks", nil, 10)
				end)
			end
			if v_u_644 then
				local v647 = v640.know
				local v650, v651 = pcall(v647, function(p648)
					-- upvalues: (copy) v_u_644
					local v649 = v_u_644[p648]
					if type(v649) == "table" then
						return v649.state
					else
						return nil
					end
				end)
				if v650 then
					return v651
				else
					return nil
				end
			else
				return nil
			end
		end
	end
	return nil
end
function v_u_4.gunsmithHintState() -- name: gunsmithHintState
	-- upvalues: (ref) v_u_5, (copy) v_u_29
	local v_u_652 = "MenuTipOnce"
	local function v653()
		-- upvalues: (ref) v_u_5, (copy) v_u_652
		return v_u_5.lib[v_u_652]
	end
	local v654, v655 = pcall(v653)
	if not v654 or type(v655) ~= "table" then
		warn("[Menu] lib missing:", "MenuTipOnce", v655)
		v655 = nil
	end
	if not v655 then
		return "seen"
	end
	local v656 = v655.decide
	local v657 = v_u_29.profile
	local v658, v659 = pcall(v656, "gunparts", v657, nil, nil)
	return (not v658 or type(v659) ~= "string") and "wait" or (v659 == "none" and "seen" or v659)
end
function v_u_4.gunsmithHintMark() -- name: gunsmithHintMark
	-- upvalues: (ref) v_u_5, (copy) v_u_29
	local v_u_660 = "MenuTipOnce"
	local function v661()
		-- upvalues: (ref) v_u_5, (copy) v_u_660
		return v_u_5.lib[v_u_660]
	end
	local v662, v663 = pcall(v661)
	if not v662 or type(v663) ~= "table" then
		warn("[Menu] lib missing:", "MenuTipOnce", v663)
		v663 = nil
	end
	if v663 then
		local v664 = v663.markSeen
		local v665 = v_u_29
		pcall(v664, v665, "gunparts")
	end
end
function v_u_4.openStore(p_u_666) -- name: openStore
	-- upvalues: (copy) v_u_4, (ref) v_u_58, (ref) v_u_46, (copy) v_u_600
	v_u_4.setTab("store")
	task.defer(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_600, (copy) p_u_666
		local v667
		if v_u_58 and v_u_46 then
			v667 = v_u_600("store")
		else
			v667 = nil
		end
		if v667 then
			v667 = v667.tab
		end
		if v667 and v667.api then
			local v668 = v667.api.open
			if type(v668) == "function" then
				local v669 = v667.api.open
				local v670 = p_u_666 or "pass_secure"
				pcall(v669, v670)
			end
		end
	end)
end
function v_u_4.openCrates(p671) -- name: openCrates
	-- upvalues: (ref) v_u_58, (ref) v_u_5, (copy) v_u_29, (ref) v_u_49
	if not v_u_58 then
		return false
	end
	local v_u_672 = "CrateWindow"
	local function v673()
		-- upvalues: (ref) v_u_5, (copy) v_u_672
		return v_u_5.lib[v_u_672]
	end
	local v674, v675 = pcall(v673)
	if not v674 or type(v675) ~= "table" then
		warn("[Menu] lib missing:", "CrateWindow", v675)
		v675 = nil
	end
	if not v675 then
		return false
	end
	local v676 = v675.open
	local v677 = v_u_29
	local v678 = {
		["fromTab"] = v_u_49
	}
	local v679, v680 = pcall(v676, v677, p671, v678)
	if v679 then
		v679 = v680 == true
	end
	return v679
end
function v_u_4.openMail() -- name: openMail
	-- upvalues: (ref) v_u_58, (ref) v_u_5, (copy) v_u_29
	local v681
	if v_u_58 then
		v681 = v_u_5.lib.MenuMail
	else
		v681 = nil
	end
	if v681 then
		local v682 = v681.open
		if type(v682) == "function" then
			local v683 = v681.open
			local v684 = v_u_29
			return pcall(v683, v684, nil, {
				["view"] = "deliveries"
			})
		end
	end
	return false
end
function v_u_4.cratesListed() -- name: cratesListed
	-- upvalues: (ref) v_u_58, (ref) v_u_5
	if not v_u_58 then
		return false
	end
	local v_u_685 = true
	local function v686()
		-- upvalues: (ref) v_u_685, (ref) v_u_5
		v_u_685 = v_u_5.config.flag("CrateWindow") ~= false
	end
	pcall(v686)
	return v_u_685
end
function v_u_4.skinsListed() -- name: skinsListed
	-- upvalues: (ref) v_u_58, (ref) v_u_5, (ref) v_u_43
	if not v_u_58 then
		return false
	end
	local v_u_687 = true
	local function v688()
		-- upvalues: (ref) v_u_687, (ref) v_u_5
		v_u_687 = v_u_5.config.flag("SkinCrates") ~= false
	end
	pcall(v688)
	return v_u_687 or v_u_43()
end
function v_u_4.openSkins(p_u_689) -- name: openSkins
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_58, (ref) v_u_46, (ref) v_u_49, (copy) v_u_600
	if not v_u_4.skinsListed() then
		return false
	end
	local v_u_690 = true
	local function v691()
		-- upvalues: (ref) v_u_690, (ref) v_u_5
		v_u_690 = v_u_5.config.flag("SkinsGrid") ~= false
	end
	pcall(v691)
	if v_u_690 then
		for _, v692 in v_u_13 do
			if v692.id ~= "character" then
				continue
			end
			v693 = true
		end
		local v693 = false
		if v693 then
			v_u_4.setTab("character")
			task.defer(function()
				-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_49, (ref) v_u_600, (copy) p_u_689
				local v694
				if v_u_58 and (v_u_46 and v_u_49 == "character") then
					v694 = v_u_600("character")
				else
					v694 = nil
				end
				if v694 then
					v694 = v694.tab
				end
				if v694 then
					local v695 = v694.showSkins
					if type(v695) == "function" then
						local v696 = v694.showSkins
						local v697 = p_u_689
						pcall(v696, v697)
					end
				end
			end)
			return true
		end
	end
	v_u_4.setTab("skins")
	task.defer(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_49, (ref) v_u_600, (copy) p_u_689
		local v698
		if v_u_58 and (v_u_46 and v_u_49 == "skins") then
			v698 = v_u_600("skins")
		else
			v698 = nil
		end
		if v698 then
			v698 = v698.tab
		end
		if v698 and v698.api then
			local v699 = v698.api.showSkins
			if type(v699) == "function" then
				local v700 = v698.api.showSkins
				local v701 = p_u_689
				pcall(v700, v701)
			end
		end
	end)
	return true
end
function v_u_4.openMarket(p_u_702, p_u_703) -- name: openMarket
	-- upvalues: (copy) v_u_4, (ref) v_u_58, (ref) v_u_46, (ref) v_u_13, (copy) v_u_600
	v_u_4.setTab("market")
	task.defer(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_13, (ref) v_u_600, (copy) p_u_702, (copy) p_u_703
		local v704
		if v_u_58 and v_u_46 then
			for _, v705 in v_u_13 do
				if v705.id ~= "market" then
					continue
				end
				v706 = true
			end
			local v706 = false
			if v706 then
				v704 = v_u_600("market")
			else
				v704 = nil
			end
		else
			v704 = nil
		end
		if v704 then
			v704 = v704.tab
		end
		if v704 then
			local v707 = v704.showSub
			if type(v707) == "function" then
				local v708 = v704.showSub
				local v709 = p_u_702 or "browse"
				local v710 = p_u_703
				pcall(v708, v709, v710)
			end
		end
	end)
end
function v_u_4.openCategory(p711, p712) -- name: openCategory
	-- upvalues: (ref) v_u_51, (ref) v_u_58, (ref) v_u_52, (copy) v_u_624, (copy) v_u_11
	if v_u_51 and (v_u_58 and v_u_52) then
		if p711 == "hideout" then
			v_u_624()
		else
			local v713 = v_u_52.go
			local v714, v715 = pcall(v713, p711, p712)
			if not v714 then
				warn("[Menu] openCategory failed:", p711, v715)
				v_u_11:SetAttribute("ClientError", "menu category " .. p711 .. ": " .. tostring(v715))
			end
		end
	else
		return
	end
end
function v_u_4.back() -- name: back
	-- upvalues: (ref) v_u_51, (ref) v_u_58, (ref) v_u_52
	if not (v_u_51 and (v_u_58 and v_u_52)) then
		return false
	end
	local v716 = v_u_52.back
	local v717, v718 = pcall(v716)
	if v717 then
		v717 = v718 == true
	end
	return v717
end
function v_u_4.category() -- name: category
	-- upvalues: (ref) v_u_51, (ref) v_u_52
	if v_u_51 and v_u_52 then
		return v_u_52.category()
	else
		return nil
	end
end
function v_u_4.setTab(p_u_719) -- name: setTab
	-- upvalues: (copy) v_u_624, (ref) v_u_51, (ref) v_u_5, (copy) v_u_4, (ref) v_u_58, (ref) v_u_46, (copy) v_u_580, (ref) v_u_13, (copy) v_u_581, (ref) v_u_49, (copy) v_u_11, (ref) v_u_56, (ref) v_u_6, (ref) v_u_7, (ref) v_u_100, (copy) v_u_47, (copy) v_u_48, (copy) v_u_607, (copy) v_u_600, (copy) v_u_2, (ref) v_u_50, (copy) v_u_27, (ref) v_u_63, (copy) v_u_186, (copy) v_u_29
	if p_u_719 == "hideout" then
		v_u_624()
		return
	elseif v_u_51 then
		local v_u_720 = "MenuShellRoute"
		local function v721()
			-- upvalues: (ref) v_u_5, (copy) v_u_720
			return v_u_5.lib[v_u_720]
		end
		local v722, v723 = pcall(v721)
		if not v722 or type(v723) ~= "table" then
			v723 = nil
		end
		local v724, v725
		if v723 then
			v724, v725 = v723.resolve(p_u_719)
		else
			v724 = nil
			v725 = nil
		end
		if v724 ~= nil then
			v_u_4.openCategory(v724, v725)
		end
	elseif v_u_58 and (v_u_46 and v_u_580[p_u_719]) then
		for _, v726 in v_u_13 do
			if v726.id ~= p_u_719 then
				continue
			end
			v727 = true
		end
		local v727 = false
		if v727 or v_u_581[p_u_719] == true and v_u_4.skinsListed() then
			if v_u_49 ~= p_u_719 then
				local v_u_728 = v_u_49
				v_u_49 = p_u_719
				v_u_11:SetAttribute("MenuTab", p_u_719)
				local v729 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
				if v729 then
					v729 = v729:FindFirstChild("party.op")
				end
				if not (v729 and v729:IsA("RemoteEvent")) then
					v729 = nil
				end
				if v729 then
					v729:FireServer({
						["op"] = "where",
						["tab"] = nil,
						["tab"] = p_u_719
					})
				end
				if v_u_56 then
					local v730 = v_u_56.refresh
					local v731 = v_u_56
					pcall(v730, v731)
				end
				v_u_6.sound(v_u_7.sounds.tab)
				local v732 = v_u_100
				pcall(v732)
				for _, v733 in v_u_47 do
					if not v733.paint then
						continue
					end
					v733.paint()
				end
				if v_u_728 and v_u_48[v_u_728] then
					local v734 = v_u_48[v_u_728]
					local v_u_735 = v734.frame
					v_u_607(v734, "hide")
					v_u_6.tween(v_u_735, {
						["Position"] = UDim2.fromOffset(0, 6)
					}, "fast")
					local v736 = {
						["onDone"] = function() -- name: onDone
							-- upvalues: (ref) v_u_49, (copy) v_u_728, (copy) v_u_735
							if v_u_49 ~= v_u_728 then
								v_u_735.Visible = false
							end
						end
					}
					v_u_6.fade(v_u_735, 1, "fast", v736)
				end
				local v_u_737 = v_u_600(p_u_719)
				local v738 = v_u_737.frame
				v738.Visible = true
				v738.Position = UDim2.fromOffset(0, v_u_7.motion.slide)
				v_u_6.tween(v738, {
					["Position"] = UDim2.fromOffset(0, 0)
				}, "slow")
				v_u_607(v_u_737, "show")
				if v_u_6.device() == "Gamepad" and (v_u_47[p_u_719] and v_u_47[p_u_719].btn) then
					local v_u_739 = v_u_47[p_u_719].btn
					task.defer(function()
						-- upvalues: (ref) v_u_49, (copy) p_u_719, (copy) v_u_739, (copy) v_u_737, (ref) v_u_2
						if v_u_49 == p_u_719 and v_u_739.Parent then
							local v740 = nil
							local v741 = v_u_737.tab
							local v742
							if type(v741) == "table" then
								local v743 = v_u_737.tab.padFirst
								if type(v743) == "function" then
									local v744 = v_u_737.tab.padFirst
									local v745
									v745, v742 = pcall(v744)
									if v745 and (typeof(v742) == "Instance" and (v742:IsA("GuiObject") and (v742.Visible and v742.Parent ~= nil))) then
										if v742.Selectable ~= true then
											v742 = v740
										end
									else
										v742 = v740
									end
								else
									v742 = v740
								end
							else
								v742 = v740
							end
							v_u_2.SelectedObject = v742 or v_u_739
						end
					end)
				end
				v_u_6.fade(v738, 0, "slow", {
					["from"] = v_u_6.fadeAlpha(v738) <= 0 and 1 or nil
				})
				if v_u_50 then
					v_u_50:setShot(v_u_27[p_u_719] or "wide")
				end
				local v746 = v_u_27[p_u_719] == nil
				if v746 ~= v_u_63 then
					v_u_63 = v746
					local v747 = v_u_6.blur
					pcall(v747, v746, 10)
				end
				v_u_186()
				if p_u_719 == "play" then
					v_u_29.syncTutorial()
				end
			end
		end
	end
end
function v_u_4.tab() -- name: tab
	-- upvalues: (ref) v_u_49, (ref) v_u_51
	local v748 = v_u_49
	if not v748 then
		if v_u_51 then
			return "play"
		end
		v748 = nil
	end
	return v748
end
function v_u_4.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_58
	return v_u_58
end
local v_u_749 = nil
local v_u_750 = -100
local v_u_751 = nil
local v_u_752 = {}
local function v_u_769() -- name: flushNews
	-- upvalues: (ref) v_u_58, (ref) v_u_59, (ref) v_u_90, (ref) v_u_5, (copy) v_u_29, (copy) v_u_104, (ref) v_u_6, (copy) v_u_752
	if v_u_58 and v_u_59 == "Menu" then
		if v_u_90 then
			v_u_90 = false
			local v_u_753 = false
			local function v756()
				-- upvalues: (ref) v_u_5, (ref) v_u_753, (ref) v_u_29
				local v754 = v_u_5.lib.MenuTempProfile
				local v755
				if v754 == nil then
					v755 = false
				else
					v755 = v754.show(v_u_29) ~= nil
				end
				v_u_753 = v755
			end
			pcall(v756)
			if not v_u_753 then
				local v757 = v_u_104()
				local v758 = v757.TEMP_TITLE
				local v759 = v757.TEMP_BODY .. " " .. v757.TEMP_TIP
				local v760 = v_u_6.toast
				pcall(v760, v758, "danger", v759, 10)
			end
		end
		local v761 = 0
		for _, v_u_762 in v_u_752 do
			v761 = v761 + 1
			local v763 = (v761 - 1) * 1.2 + 0.4
			task.delay(v763, function()
				-- upvalues: (copy) v_u_762, (ref) v_u_6
				local v764 = v_u_762[1]
				local v765 = v_u_762[2]
				local v766 = v_u_762[3]
				local v767 = v_u_762[4]
				local v768 = v_u_6.toast
				pcall(v768, v764, v765, v766, v767)
			end)
		end
		table.clear(v_u_752)
	end
end
v_u_29.flushNews = v_u_769
local function v_u_827(p770) -- name: diffNews
	-- upvalues: (ref) v_u_5, (copy) v_u_104, (ref) v_u_91, (ref) v_u_89, (ref) v_u_90, (ref) v_u_92, (copy) v_u_752, (ref) v_u_94, (ref) v_u_749, (ref) v_u_751, (ref) v_u_750, (copy) v_u_769
	local v_u_771 = nil
	local v_u_772 = nil
	local function v773()
		-- upvalues: (ref) v_u_771, (ref) v_u_5, (ref) v_u_772
		v_u_771 = v_u_5.shared.Tasks
		v_u_772 = v_u_5.shared.Traders
	end
	pcall(v773)
	local v774 = p770.tasks
	local v775 = type(v774) == "table" and (p770.tasks or {}) or {}
	local v776 = v775.active
	local v777 = v_u_771
	local v778 = v_u_772
	local v779 = {}
	for v780 in type(v776) == "table" and (v775.active or {}) or {} do
		v779[v780] = true
	end
	local v781 = {}
	local v782 = p770.derived
	local v783 = type(v782) == "table" and (p770.derived or {}) or {}
	local v784 = v_u_104()
	local v785
	if v_u_91 == nil then
		if v783.temp == true then
			v785 = not game:GetService("RunService"):IsStudio()
		else
			v785 = false
		end
	else
		v785 = v_u_91
	end
	if v785 and not v_u_89 then
		v_u_89 = true
		v_u_90 = true
	end
	local v786 = v783.waiting
	local v787 = tonumber(v786)
	if not v787 then
		local v788 = p770.inv
		local v789
		if type(v788) == "table" then
			local v790 = p770.inv.overflow
			v789 = tonumber(v790)
		else
			v789 = nil
		end
		v787 = v789 or 0
	end
	local v791 = (v787 ~= v787 or v787 < 0) and 0 or math.floor(v787)
	if v791 > 0 and (v_u_92 == nil or v_u_92 < v791) then
		local v792, v793 = v784.waitingToast(v791)
		local v794 = v_u_752
		table.insert(v794, { v792, "warn", v793 })
	end
	v_u_92 = v791
	local v795 = {}
	local v796 = p770.hideout
	if type(v796) == "table" then
		for v797, v798 in p770.hideout do
			if type(v798) ~= "table" then
				continue
			end
			local v799 = v798.lvl
			v795[v797] = tonumber(v799) or 0
		end
	end
	if v_u_94 then
		local v_u_800 = nil
		local function v801()
			-- upvalues: (ref) v_u_800, (ref) v_u_5
			v_u_800 = v_u_5.shared.HideoutModules
		end
		pcall(v801)
		local v802 = v_u_800
		for v803, v804 in v795 do
			if (v_u_94[v803] or 0) >= v804 or v_u_94[v803] == nil and v804 <= 1 then
				continue
			end
			local v805
			if v802 and (v802.defs and v802.defs[v803]) then
				v805 = v802.defs[v803].name
			else
				v805 = nil
			end
			local v806 = v_u_752
			local v807 = { v784.hideoutBuilt(v805, v804), "success", "Open the HIDEOUT to use it." }
			table.insert(v806, v807)
		end
	end
	v_u_94 = v795
	local v808 = v783.traderLevels
	for v809, v810 in type(v808) == "table" and (v783.traderLevels or {}) or {} do
		v781[v809] = tonumber(v810) or 1
	end
	if v_u_749 and v_u_751 then
		for v811, v812 in v781 do
			local v813 = v_u_751[v811]
			if not v813 or (v813 >= v812 or os.clock() - v_u_750 <= 3) then
				continue
			end
			local v814 = v778 and (v778.defs and v778.defs[v811]) and v778.defs[v811].name or string.upper(v811)
			local v815 = 0
			local v816 = 0
			if v778 and (v778.defs and v778.defs[v811]) then
				for _, v817 in v778.defs[v811].offers do
					if v813 >= v817.lvl or v817.lvl > v812 then
						continue
					end
					if v817.task then
						v816 = v816 + 1
					else
						v815 = v815 + 1
					end
				end
				if v812 >= 5 and v813 < 5 then
					v815 = v815 + #(v778.defs[v811].offersL5 or {})
				end
			end
			local v818 = v_u_752
			local v819 = { ("%s is now LV %d"):format(v814, v812), "success", v784.levelNews(v815, v816) }
			table.insert(v818, v819)
		end
		for v820 in v779 do
			if v_u_749[v820] then
				continue
			end
			if v777 then
				local v821 = v777.get(v820)
			end
			if not v821 then
				continue
			end
			local v822 = v_u_752
			local v823 = { ("New task from %s: %s"):format(v778 and (v778.defs and v778.defs[v821.giver]) and v778.defs[v821.giver].name or string.upper(v821.giver), v821.title), "info", v821.side and "Side job, see TASKS" or "See TASKS" }
			table.insert(v822, v823)
		end
		while #v_u_752 > 6 do
			table.remove(v_u_752, 1)
		end
	end
	local v824 = table.clone(v779)
	local v825 = v775.done
	for v826 in type(v825) == "table" and (v775.done or {}) or {} do
		v824[v826] = true
	end
	v_u_749 = v824
	v_u_751 = v781
	v_u_769()
end
local function v_u_844(p828, p829) -- name: queueCard
	-- upvalues: (copy) v_u_86, (ref) v_u_87, (ref) v_u_5, (copy) v_u_29, (ref) v_u_58, (ref) v_u_6
	for _, v830 in v_u_86 do
		if v830[2] ~= p829 then
			continue
		end
		return
	end
	local v831 = v_u_86
	table.insert(v831, { p828, p829 })
	if not v_u_87 then
		v_u_87 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_86, (ref) v_u_5, (ref) v_u_29, (ref) v_u_58, (ref) v_u_6, (ref) v_u_87
			local v832 = 0
			while #v_u_86 > 0 and v832 < 180 do
				local v_u_833 = "MenuConnNotice"
				local function v834()
					-- upvalues: (ref) v_u_5, (copy) v_u_833
					return v_u_5.lib[v_u_833]
				end
				local v835, v_u_836 = pcall(v834)
				if not v835 or type(v_u_836) ~= "table" then
					warn("[Menu] lib missing:", "MenuConnNotice", v_u_836)
					v_u_836 = nil
				end
				local function v838()
					-- upvalues: (copy) v_u_836, (ref) v_u_29
					local v837
					if v_u_836 == nil then
						v837 = false
					else
						v837 = v_u_836.idle(v_u_29)
					end
					return v837
				end
				local v839, v840 = pcall(v838)
				if v_u_58 and (v839 and v840 == true) then
					local v841 = table.remove(v_u_86, 1)
					local v842 = v_u_6.modal
					local v843 = {
						["title"] = nil,
						["body"] = nil,
						["width"] = 520,
						["buttons"] = nil,
						["title"] = v841[1],
						["body"] = v841[2],
						["buttons"] = {
							{
								["text"] = "Got it",
								["kind"] = "primary"
							}
						}
					}
					pcall(v842, v843)
					task.wait(0.6)
				else
					task.wait(2)
					v832 = v832 + 2
				end
			end
			v_u_87 = false
		end)
	end
end
local v_u_845 = -100
local function v_u_878(p846) -- name: checkPartnerReady
	-- upvalues: (copy) v_u_93, (ref) v_u_845, (copy) v_u_29, (ref) v_u_5, (copy) v_u_104, (ref) v_u_58, (ref) v_u_6, (copy) v_u_752
	local v847 = p846.derived
	local v848 = type(v847) == "table" and p846.derived or {}
	local v849 = v848.traderLevels
	local v_u_850 = type(v849) ~= "table" and {} or v848.traderLevels
	local v851 = false
	for v852, v853 in v_u_850 do
		if tonumber(v853) ~= 4 or v_u_93[v852] then
			continue
		end
		v851 = true
	end
	if v851 and os.clock() - v_u_845 >= 30 then
		v_u_845 = os.clock()
		task.spawn(function()
			-- upvalues: (ref) v_u_29, (ref) v_u_5, (ref) v_u_93, (copy) v_u_850, (ref) v_u_104, (ref) v_u_58, (ref) v_u_6, (ref) v_u_752
			local v854 = v_u_29.fetch("traders", nil, 20)
			local v_u_855 = "MenuTraders"
			local function v856()
				-- upvalues: (ref) v_u_5, (copy) v_u_855
				return v_u_5.lib[v_u_855]
			end
			local v857, v858 = pcall(v856)
			if not v857 or type(v858) ~= "table" then
				warn("[Menu] lib missing:", "MenuTraders", v858)
				v858 = nil
			end
			local v_u_859 = nil
			local function v860()
				-- upvalues: (ref) v_u_859, (ref) v_u_5
				v_u_859 = v_u_5.shared.Traders
			end
			pcall(v860)
			if type(v854) == "table" then
				local v861 = v854.traders
				if type(v861) == "table" and v858 then
					local v862 = v858.partnerReady
					if type(v862) == "function" then
						local v_u_863 = false
						local function v864()
							-- upvalues: (ref) v_u_863, (ref) v_u_5
							v_u_863 = v_u_5.config.flag("Partners") == true
						end
						pcall(v864)
						local v865 = v_u_859
						local v866 = v_u_863
						for v873, v868 in v854.traders do
							if v_u_93[v873] then
								continue
							end
							local v869 = v_u_850[v873]
							if tonumber(v869) ~= 4 then
								continue
							end
							local v870 = v858.partnerReady
							local v871, v872 = pcall(v870, v868, v866)
							if not v871 or (type(v872) ~= "table" or v872.ready ~= true) then
								continue
							end
							v_u_93[v873] = true
							if v865 and (v865.defs and v865.defs[v873]) then
								local v873 = v865.defs[v873].name or v873
							end
							local v874, v875 = v_u_104().partnerReadyToast(v873)
							if v_u_58 then
								local v876 = v_u_6.toast
								pcall(v876, v874, "success", v875, nil)
							else
								local v877 = v_u_752
								table.insert(v877, { v874, "success", v875 })
							end
						end
						return
					end
				end
			end
		end)
	end
end
local function v_u_886() -- name: paintFoot
	-- upvalues: (ref) v_u_98, (copy) v_u_29, (ref) v_u_91, (ref) v_u_5, (copy) v_u_11, (copy) v_u_104, (ref) v_u_8
	local v879 = v_u_98
	if v879 and v879.Parent then
		local v880 = v_u_29.derived()
		local v881
		if v_u_91 == nil then
			if v880.temp == true then
				v881 = not game:GetService("RunService"):IsStudio()
			else
				v881 = false
			end
		else
			v881 = v_u_91
		end
		local function v882()
			-- upvalues: (ref) v_u_5
			return v_u_5.shared.GameMode.isPvpve()
		end
		local v883, v884 = pcall(v882)
		local v885 = ("HUSH %s  \194\183  %s EXTRACTION  \194\183  %s"):format(v_u_5.config.VERSION or "", v883 and v884 == true and "PVPVE" or "PVE", string.upper(v_u_11.DisplayName))
		v879.Text = v_u_104().footerSaving(v885, v881, "#" .. v_u_8.danger:ToHex())
	end
end
v_u_100 = function()
	-- upvalues: (ref) v_u_99, (copy) v_u_104, (ref) v_u_49, (ref) v_u_6
	local v887 = v_u_99
	if v887 and v887.Parent then
		v887.Text = v_u_104().hintFooter(v_u_49, v_u_6.device() == "Gamepad")
	end
end
local function v_u_923(p888, p889) -- name: onProfile
	-- upvalues: (copy) v_u_29, (ref) v_u_97, (ref) v_u_5, (copy) v_u_827, (copy) v_u_886, (copy) v_u_11, (ref) v_u_70, (ref) v_u_58, (ref) v_u_59, (ref) v_u_57, (ref) v_u_66, (copy) v_u_564, (ref) v_u_51, (copy) v_u_4, (copy) v_u_399, (ref) v_u_50, (copy) v_u_26, (ref) v_u_44, (copy) v_u_104, (ref) v_u_88, (copy) v_u_844, (copy) v_u_878, (ref) v_u_49, (copy) v_u_48, (copy) v_u_607, (copy) v_u_462, (ref) v_u_85
	if type(p888) == "table" then
		v_u_29.profile = p888
		local v890 = p888.derived
		local v891
		if type(v890) == "table" then
			local v892 = p888.derived.serverTime
			v891 = tonumber(v892)
		else
			v891 = nil
		end
		if v891 then
			v_u_97 = v891 - os.time()
			local v_u_893 = "ServerClock"
			local function v894()
				-- upvalues: (ref) v_u_5, (copy) v_u_893
				return v_u_5.lib[v_u_893]
			end
			local v895, v896 = pcall(v894)
			if not v895 or type(v896) ~= "table" then
				warn("[Menu] lib missing:", "ServerClock", v896)
				v896 = nil
			end
			if v896 then
				local v897 = v896.calibrate
				pcall(v897, v891)
			end
		end
		local v898 = v_u_827
		pcall(v898, p888)
		local v899 = v_u_886
		pcall(v899)
		v_u_11:SetAttribute("MenuProfile", true)
		if not v_u_70 then
			v_u_70 = true
			local v_u_900 = "MenuSettings"
			local function v901()
				-- upvalues: (ref) v_u_5, (copy) v_u_900
				return v_u_5.lib[v_u_900]
			end
			local v902, v903 = pcall(v901)
			if not v902 or type(v903) ~= "table" then
				warn("[Menu] lib missing:", "MenuSettings", v903)
				v903 = nil
			end
			if v903 and v903.apply then
				local v904 = v903.apply
				local v905 = v_u_29
				local v906 = p888.settings
				pcall(v904, v905, v906)
			end
			if v_u_58 and (v_u_59 == "Menu" and (v_u_57 == nil and (v_u_66 == nil and v_u_564.wanted() ~= v_u_51))) then
				task.defer(v_u_4.restyle)
			end
		end
		v_u_399()
		if v_u_50 then
			local v907 = v_u_50.setLoadout
			local v908 = v_u_50
			local v909 = v_u_29.slots
			local v910, v911 = pcall(v907, v908, v909())
			if not v910 then
				warn("[Menu] survivor loadout failed:", v911)
				v_u_11:SetAttribute("ClientError", "menu loadout: " .. tostring(v911))
			end
		end
		if p889 ~= nil and p889 ~= "load" then
			v_u_29.invalidate("tasks")
			v_u_29.invalidate("traders")
			v_u_29.invalidate("hideout")
			v_u_29.invalidate("collection")
			v_u_29.invalidate("store")
			v_u_29.invalidate("crates")
		end
		v_u_29.changed:Fire("profile", p889)
		if v_u_26() and (v_u_58 and v_u_44) then
			task.defer(v_u_4.rebuild)
		end
		if p888.notice ~= nil then
			local v_u_912 = "MenuConnNotice"
			local function v913()
				-- upvalues: (ref) v_u_5, (copy) v_u_912
				return v_u_5.lib[v_u_912]
			end
			local v914, v915 = pcall(v913)
			if not v914 or type(v915) ~= "table" then
				warn("[Menu] lib missing:", "MenuConnNotice", v915)
				v915 = nil
			end
			if v915 then
				local v916 = v915.maybe
				local v917 = v_u_29
				pcall(v916, v917, p888)
			end
		end
		if v_u_59 == "Menu" then
			local v918 = v_u_104()
			local v919 = v918.cutShortDue
			if type(v919) == "function" and v918.cutShortDue(p888.lastRaid, os.time() + v_u_97, v_u_88) then
				v_u_88 = p888.lastRaid.at
				local v920, v921 = v918.cutShort(p888.lastRaid.note)
				v_u_844(v920, v921)
			end
			local v922 = v_u_878
			pcall(v922, p888)
		end
		if v_u_49 and v_u_48[v_u_49] then
			v_u_607(v_u_48[v_u_49], "refresh", "profile")
		end
		v_u_462()
		v_u_29.syncTutorial()
		if v_u_58 and (p889 ~= nil and (p889 ~= "load" and os.clock() - v_u_85 > 2)) then
			v_u_85 = os.clock()
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_58, (ref) v_u_29, (ref) v_u_462
				if v_u_58 then
					v_u_29.fetch("tasks", nil, 1)
					v_u_462()
				end
			end)
		end
	end
end
local function v_u_957(p924) -- name: onResult
	-- upvalues: (ref) v_u_74, (ref) v_u_76, (copy) v_u_610, (ref) v_u_750, (copy) v_u_11, (ref) v_u_59, (ref) v_u_5, (copy) v_u_28, (ref) v_u_58, (copy) v_u_72, (ref) v_u_73, (copy) v_u_104, (ref) v_u_6, (ref) v_u_7, (copy) v_u_29, (copy) v_u_752, (ref) v_u_49, (copy) v_u_48, (copy) v_u_607
	if type(p924) ~= "table" then
		return
	end
	local v925 = p924.op or ""
	local v926 = tostring(v925)
	if v926 == "enterHideout" then
		v_u_74 = os.clock()
		if p924.ok == false and v_u_76 > 0 then
			v_u_76 = 0
			v_u_610()
		end
	end
	local v927 = p924.msg
	local v928
	if type(v927) == "string" and p924.msg ~= "" then
		v928 = p924.msg
	else
		v928 = nil
	end
	if v928 and string.find(v928, "is now LV", 1, true) then
		v_u_750 = os.clock()
	end
	local v929 = v_u_11:GetAttribute("Place") or v_u_59
	local v930 = v_u_5.controllers.HideoutWorld
	local v931
	if v929 == "Hideout" and (v_u_28[v926] == true and v930 ~= nil) then
		v931 = not v930._broken
	else
		v931 = false
	end
	local v932 = string.sub(v926, 1, 2) == "bm"
	local v933
	if v_u_58 and v929 == "Menu" then
		v933 = not v932
	elseif v929 == "Menu" then
		v933 = false
	else
		v933 = not v931
		if v933 then
			v933 = not v932
		end
	end
	if p924.ok == false and v933 then
		local v934 = p924.req or ""
		local v935 = v926 .. "/" .. tostring(v934) .. "/" .. tostring(v928 or "")
		local v936 = os.clock()
		local v937 = p924.req == nil and 1.5 or 10
		if not v_u_72[v935] or v936 - v_u_72[v935] >= v937 then
			v_u_72[v935] = v936
			v_u_73 = v_u_73 + 1
			local v938 = v928 or "That did not work"
			local v939
			if v928 then
				v939 = nil
			else
				v939 = v_u_104().REFUSED_SUB
			end
			local v940 = v_u_6.toast
			pcall(v940, v938, "danger", v939, nil)
			v_u_6.sound(v_u_7.sounds.error)
		end
		local v941 = {}
		for v942, v943 in v_u_72 do
			if v936 - v943 <= 30 then
				continue
			end
			table.insert(v941, v942)
		end
		for _, v944 in v941 do
			v_u_72[v944] = nil
		end
		if p924.ok and (v_u_58 and (v926 == "buy" or v926 == "sell")) then
			v_u_6.sound(v_u_7.sounds.purchase)
		end
		v_u_29.changed:Fire("result", p924)
		if v_u_49 and v_u_48[v_u_49] then
			v_u_607(v_u_48[v_u_49], "refresh", "result", p924)
		end
	else
		local v945, v946, v947
		if p924.ok and (v_u_58 and (v929 == "Menu" and v926 == "taskHandIn")) then
			local v948 = p924.data
			if type(v948) == "table" and p924.data.completed == true then
				local v_u_949 = "MenuTasks"
				local function v950()
					-- upvalues: (ref) v_u_5, (copy) v_u_949
					return v_u_5.lib[v_u_949]
				end
				local v951, v952 = pcall(v950)
				if not v951 or type(v952) ~= "table" then
					warn("[Menu] lib missing:", "MenuTasks", v952)
					v952 = nil
				end
				local v953 = v952 and v952.rewardModal
				if v953 then
					local v954 = v952.rewardModal
					local v955 = v_u_29
					v953 = pcall(v954, v955, p924)
				end
				if not v953 and v928 then
					local v956 = v_u_6.toast
					pcall(v956, v928, "success", nil, nil)
				end
				if p924.ok and (v_u_58 and (v926 == "buy" or v926 == "sell")) then
					v_u_6.sound(v_u_7.sounds.purchase)
				end
				v_u_29.changed:Fire("result", p924)
				if v_u_49 and v_u_48[v_u_49] then
					v_u_607(v_u_48[v_u_49], "refresh", "result", p924)
				end
				return
			end
			if p924.ok and (v928 and (v933 and not v932)) then
				v945 = (string.find(v928, "did not fit", 1, true) or string.find(v928, "is full", 1, true)) and "warn" or "success"
				v946 = v_u_6.toast
				pcall(v946, v928, v945, nil, nil)
			elseif p924.ok and (v928 and (v926 == "storeGrant" and (v929 == "Menu" and not v_u_58))) then
				v947 = v_u_752
				table.insert(v947, { v928, "success" })
			end
		elseif p924.ok and (v928 and (v933 and not v932)) then
			v945 = (string.find(v928, "did not fit", 1, true) or string.find(v928, "is full", 1, true)) and "warn" or "success"
			v946 = v_u_6.toast
			pcall(v946, v928, v945, nil, nil)
		elseif p924.ok and (v928 and (v926 == "storeGrant" and (v929 == "Menu" and not v_u_58))) then
			v947 = v_u_752
			table.insert(v947, { v928, "success" })
		end
		if p924.ok and (v_u_58 and (v926 == "buy" or v926 == "sell")) then
			v_u_6.sound(v_u_7.sounds.purchase)
		end
		v_u_29.changed:Fire("result", p924)
		if v_u_49 and v_u_48[v_u_49] then
			v_u_607(v_u_48[v_u_49], "refresh", "result", p924)
		end
	end
end
local function v_u_991(p958) -- name: onParty
	-- upvalues: (copy) v_u_29, (ref) v_u_95, (ref) v_u_96, (copy) v_u_104, (ref) v_u_59, (copy) v_u_844, (ref) v_u_58, (ref) v_u_6, (copy) v_u_752, (ref) v_u_71, (ref) v_u_5, (ref) v_u_56, (ref) v_u_49, (copy) v_u_48, (copy) v_u_607
	if type(p958) == "table" then
		v_u_29.party = p958
		local v959 = p958.notice
		if type(v959) == "table" then
			local v960 = p958.notice.text
			if type(v960) == "string" then
				local v961 = p958.notice
				local v962 = v961.text
				local v963 = v961.code
				local v964 = v962 .. "|" .. tostring(v963)
				if v964 ~= v_u_95 or os.clock() - v_u_96 > 1 then
					local v965 = os.clock()
					v_u_95 = v964
					v_u_96 = v965
					local v966 = v_u_104()
					local v967 = v966.isCardNotice
					if type(v967) == "function" and (v966.isCardNotice(v961.code) and v_u_59 == "Menu") then
						local v968, v969 = v966.noticeCard(v961)
						v_u_844(v968, v969)
					elseif v_u_58 then
						local v970 = v961.text
						local v971 = v961.kind or "info"
						local v972 = v_u_6.toast
						pcall(v972, v970, v971, nil, nil)
					elseif v_u_59 == "Menu" then
						local v973 = v_u_752
						local v974 = { v961.text, v961.kind or "info" }
						table.insert(v973, v974)
					elseif v_u_59 ~= "Raid" and v_u_59 ~= "Transit" then
						local v975 = v961.text
						local v976 = v961.kind or "info"
						local v977 = v_u_6.toast
						pcall(v977, v975, v976, nil, nil)
					end
				end
			end
		end
		local v978 = v_u_29.partyDeploying()
		if v978 and (not v_u_71 and (v_u_59 == "Menu" or v_u_59 == "Transit")) and not v_u_29.isLeader() then
			local v979 = v_u_29.myParty()
			local v980
			if v979 then
				local v981 = v979.settings
				v980 = type(v981) ~= "table" and {} or v979.settings
			else
				v980 = {}
			end
			local v982 = v980.difficulty
			local v983 = type(v982) ~= "string" and "Normal" or v980.difficulty
			local v984
			if v983 == "Nightmare" then
				v984 = "Night"
			else
				local v985 = v980.timeOfDay
				if type(v985) == "string" and (v980.timeOfDay ~= "" and v980.timeOfDay ~= "Any") then
					v984 = v980.timeOfDay
				else
					v984 = nil
				end
			end
			local v986 = v_u_5.emit
			local v987 = {
				["kind"] = "deploy",
				["map"] = nil,
				["difficulty"] = nil,
				["timeOfDay"] = nil
			}
			local v988 = v980.map
			v987.map = type(v988) ~= "string" and "Stillwater" or v980.map
			v987.difficulty = v983
			v987.timeOfDay = v984
			v986("transit.info", v987)
		end
		v_u_71 = v978
		if v_u_56 then
			local v989 = v_u_56.refresh
			local v990 = v_u_56
			pcall(v989, v990)
		end
		v_u_29.changed:Fire("party")
		if v_u_49 and v_u_48[v_u_49] then
			v_u_607(v_u_48[v_u_49], "refresh", "party")
		end
	end
end
local function v_u_1012(p992) -- name: showDebrief
	-- upvalues: (ref) v_u_5, (ref) v_u_45, (ref) v_u_57, (ref) v_u_50, (ref) v_u_51, (ref) v_u_53, (ref) v_u_63, (ref) v_u_6, (ref) v_u_78, (copy) v_u_29, (ref) v_u_67, (copy) v_u_186, (ref) v_u_58, (ref) v_u_49, (ref) v_u_83, (copy) v_u_479, (ref) v_u_52, (copy) v_u_579, (copy) v_u_564, (copy) v_u_4, (ref) v_u_46, (copy) v_u_48
	local v_u_993 = "MenuDebrief"
	local function v994()
		-- upvalues: (ref) v_u_5, (copy) v_u_993
		return v_u_5.lib[v_u_993]
	end
	local v995, v996 = pcall(v994)
	if not v995 or type(v996) ~= "table" then
		warn("[Menu] lib missing:", "MenuDebrief", v996)
		v996 = nil
	end
	if v996 and v_u_45 then
		if v_u_57 then
			local v997 = v_u_57.destroy
			local v998 = v_u_57
			pcall(v997, v998)
		end
		if v_u_50 then
			v_u_50:setShot("debrief")
		end
		if v_u_51 and v_u_53 then
			local v999 = v_u_53.go
			local v1000 = v_u_53
			pcall(v999, v1000, "street", "debrief")
		end
		if v_u_63 ~= false then
			v_u_63 = false
			local v1001 = v_u_6.blur
			pcall(v1001, false, 10)
		end
		v_u_78 = p992
		local v1002 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
		if v1002 then
			v1002 = v1002:FindFirstChild("party.op")
		end
		if not (v1002 and v1002:IsA("RemoteEvent")) then
			v1002 = nil
		end
		if v1002 then
			v1002:FireServer({
				["op"] = "where",
				["tab"] = "debrief"
			})
		end
		local v1003 = v996.new
		local v1004 = v_u_29
		local v1005 = v_u_45
		local v1006 = v_u_67
		local function v1009()
			-- upvalues: (ref) v_u_57, (ref) v_u_78, (ref) v_u_186, (ref) v_u_58, (ref) v_u_29, (ref) v_u_49, (ref) v_u_83, (ref) v_u_479, (ref) v_u_51, (ref) v_u_52, (ref) v_u_579, (ref) v_u_564, (ref) v_u_4, (ref) v_u_46, (ref) v_u_6
			v_u_57 = nil
			v_u_78 = nil
			v_u_186()
			task.delay(0.8, function()
				-- upvalues: (ref) v_u_58, (ref) v_u_57, (ref) v_u_29
				if v_u_58 and (v_u_57 == nil and v_u_29.maybeTour) then
					v_u_29.maybeTour()
				end
			end)
			local v1007 = v_u_49 or "play"
			if v_u_83 then
				v_u_83 = false
				v_u_29.focusTask = v_u_479("doc") or v_u_479(nil)
				v1007 = "tasks"
			end
			v_u_49 = nil
			if v_u_51 and (v_u_52 and v1007 ~= "tasks") then
				v_u_52.home()
				v_u_579(nil, nil, nil, nil)
				v_u_52.cam()
				v_u_564.focusHome()
			else
				if v_u_51 and (v_u_52 and v_u_52.category() ~= nil) then
					local v1008 = v_u_52.home
					pcall(v1008)
				end
				v_u_4.setTab(v1007)
			end
			if v_u_46 and not v_u_51 then
				v_u_6.tween(v_u_46, {
					["Position"] = UDim2.fromOffset(0, (v_u_29.compact() and 0 or 56) + 64)
				}, "slow")
			end
		end
		local v1010, v1011 = pcall(v1003, v1004, v1005, p992, v1006, v1009)
		if v1010 then
			v_u_57 = v1011
			v_u_186()
			if v_u_46 then
				v_u_46.Visible = true
			end
			if v_u_49 and v_u_48[v_u_49] then
				v_u_48[v_u_49].frame.Visible = false
				return
			end
		else
			warn("[Menu] debrief failed:", v1011)
		end
	end
end
local function v_u_1041(p1013) -- name: buildV2
	-- upvalues: (ref) v_u_5, (copy) v_u_29, (copy) v_u_484, (ref) v_u_53, (copy) v_u_513, (copy) v_u_600, (copy) v_u_607, (copy) v_u_624, (copy) v_u_2, (copy) v_u_191, (ref) v_u_7, (ref) v_u_97, (copy) v_u_579, (copy) v_u_55, (copy) v_u_4, (copy) v_u_564, (ref) v_u_52, (ref) v_u_57, (copy) v_u_11, (ref) v_u_46, (ref) v_u_61, (ref) v_u_56
	local v_u_1014 = {}
	for _, v_u_1015 in {
		"MenuShellV2",
		"MenuShellRoute",
		"MenuCategories",
		"MenuV2Layout",
		"MenuHomeV2"
	} do
		local function v1016()
			-- upvalues: (ref) v_u_5, (copy) v_u_1015
			return v_u_5.lib[v_u_1015]
		end
		local v1017, v1018 = pcall(v1016)
		if not v1017 or type(v1018) ~= "table" then
			v1018 = nil
		end
		v_u_1014[v_u_1015] = v1018
		if v_u_1014[v_u_1015] ~= nil then
			continue
		end
		warn("[Menu] MenuV2 off for this visit, lib missing:", v_u_1015)
		return false
	end
	local v_u_1019 = "ServerClock"
	local function v1020()
		-- upvalues: (ref) v_u_5, (copy) v_u_1019
		return v_u_5.lib[v_u_1019]
	end
	local v1021, v_u_1022 = pcall(v1020)
	if not v1021 or type(v_u_1022) ~= "table" then
		v_u_1022 = nil
	end
	local v1023 = v_u_1014.MenuShellV2.build
	local v1024 = v_u_29
	local v1038 = {
		["cctx"] = v_u_5,
		["lib"] = v_u_484,
		["has"] = function(p_u_1025) -- name: has
			-- upvalues: (ref) v_u_5
			local function v1026()
				-- upvalues: (ref) v_u_5, (copy) p_u_1025
				return v_u_5.lib[p_u_1025]
			end
			local v1027, v1028 = pcall(v1026)
			if not v1027 or type(v1028) ~= "table" then
				v1028 = nil
			end
			return v1028 ~= nil
		end,
		["route"] = v_u_1014.MenuShellRoute,
		["categories"] = v_u_1014.MenuCategories,
		["layout"] = v_u_1014.MenuV2Layout,
		["home"] = v_u_1014.MenuHomeV2,
		["director"] = v_u_53,
		["visible"] = v_u_513,
		["pageFor"] = v_u_600,
		["callTab"] = v_u_607,
		["enterHideout"] = v_u_624,
		["floorX"] = function() -- name: floorX
			-- upvalues: (ref) v_u_2, (ref) v_u_191, (ref) v_u_7
			local v_u_1029 = 0
			local function v1030()
				-- upvalues: (ref) v_u_1029, (ref) v_u_2
				v_u_1029 = v_u_2.TopbarInset.Min.X
			end
			pcall(v1030)
			v_u_1029 = v_u_1029 <= 0 and 120 or v_u_1029
			local v1031 = v_u_191()
			local v1032 = v_u_1029
			local v1033 = math.max(v1032, v1031) / v_u_7.uiScale()
			return math.ceil(v1033) + 12
		end,
		["now"] = function() -- name: now
			-- upvalues: (copy) v_u_1022, (ref) v_u_97
			if v_u_1022 then
				local v1034 = v_u_1022.now
				if type(v1034) == "function" then
					local v1035 = v_u_1022.now
					local v1036, v1037 = pcall(v1035)
					if v1036 and type(v1037) == "number" then
						return v1037
					end
				end
			end
			return os.time() + v_u_97
		end,
		["onChange"] = v_u_579,
		["onResize"] = function() -- name: onResize
			-- upvalues: (copy) v_u_1014, (ref) v_u_55, (ref) v_u_4, (ref) v_u_564, (ref) v_u_52
			if v_u_1014.MenuShellRoute.rebuildAllowed(v_u_55, os.clock(), 4, 10) then
				task.defer(v_u_4.rebuild)
			else
				v_u_564.postponeRebuild(v_u_1014.MenuShellRoute, v_u_52)
			end
		end,
		["blocked"] = function() -- name: blocked
			-- upvalues: (ref) v_u_57
			return v_u_57 ~= nil
		end,
		["fallback"] = {
			["skills"] = { "character", "skills" }
		}
	}
	local v1039, v1040 = pcall(v1023, v1024, p1013, v1038)
	if not v1039 or type(v1040) ~= "table" then
		warn("[Menu] shell failed:", v1040)
		v_u_11:SetAttribute("ClientError", "menu shell: " .. tostring(v1040))
		return false
	end
	v_u_52 = v1040
	v_u_46 = v1040.pagesFrame
	v_u_61 = v1040.cashLabel
	v_u_56 = v1040.party()
	v_u_564.services()
	return true
end
local function v_u_1088() -- name: build
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_44, (ref) v_u_45, (ref) v_u_8, (copy) v_u_26, (ref) v_u_51, (copy) v_u_1041, (ref) v_u_53, (copy) v_u_29, (copy) v_u_11, (copy) v_u_393, (ref) v_u_5, (ref) v_u_56, (ref) v_u_46, (ref) v_u_98, (ref) v_u_99, (copy) v_u_104, (copy) v_u_886, (ref) v_u_100, (ref) v_u_50, (ref) v_u_52
	local v1042, v1043 = v_u_6.screen("HushMenu", v_u_7.layer.menu)
	v_u_44 = v1042
	v_u_45 = v1043
	local v1044 = v_u_6.new("Frame", {
		["Name"] = "TopShade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 0,
		["BackgroundColor3"] = v_u_8.bgDeep,
		["Size"] = UDim2.new(1, 0, 0, 190)
	}, v1043)
	v_u_6.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.12), NumberSequenceKeypoint.new(0.55, 0.62), NumberSequenceKeypoint.new(1, 1) })
	}, v1044)
	local v1045 = v_u_6.new("Frame", {
		["Name"] = "BottomShade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["BackgroundColor3"] = v_u_8.bgDeep,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 170)
	}, v1043)
	v_u_6.new("UIGradient", {
		["Rotation"] = -90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
	}, v1045)
	local v1046 = v_u_6.new("Frame", {
		["Name"] = "RightShade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["BackgroundColor3"] = v_u_8.bgDeep,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(0.42, 0, 1, 0)
	}, v1043)
	v_u_6.new("UIGradient", {
		["Rotation"] = 180,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(1, 1) })
	}, v1046)
	v_u_26()
	if v_u_51 and not v_u_1041(v1043) then
		v_u_51 = false
		if v_u_53 then
			local v1047 = v_u_53.destroy
			local v1048 = v_u_53
			pcall(v1047, v1048)
			v_u_53 = nil
		end
		v_u_29.v2 = false
		v_u_29.director = nil
		v_u_11:SetAttribute("MenuV2", false)
	end
	if not v_u_51 then
		v_u_393(v1043)
		v_u_6.divider({
			["parent"] = nil,
			["name"] = "TopRule",
			["position"] = nil,
			["size"] = nil,
			["transparency"] = 0.4,
			["parent"] = v1043,
			["position"] = UDim2.fromOffset(0, 64),
			["size"] = UDim2.new(1, 0, 0, 1)
		})
		local v_u_1049 = "MenuParty"
		local function v1050()
			-- upvalues: (ref) v_u_5, (copy) v_u_1049
			return v_u_5.lib[v_u_1049]
		end
		local v1051, v1052 = pcall(v1050)
		if not v1051 or type(v1052) ~= "table" then
			warn("[Menu] lib missing:", "MenuParty", v1052)
			v1052 = nil
		end
		if v1052 then
			local v1053 = v1052.new
			local v1054 = v_u_29
			local v1055, v1056 = pcall(v1053, v1054, v1043, 64)
			if v1055 then
				v_u_56 = v1056
			else
				warn("[Menu] party bar failed:", v1056)
			end
		end
		v_u_46 = v_u_6.new("Frame", {
			["Name"] = "Pages",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, (v_u_29.compact() and 0 or 56) + 64),
			["Size"] = UDim2.new(1, 0, 1, -((v_u_29.compact() and 0 or 56) + 64) - 30)
		}, v1043)
	end
	local v1057 = v_u_7.uiScale()
	local v1058 = 11 / math.max(v1057, 0.1)
	local v1059 = math.ceil(v1058)
	local v1060 = math.max(11, v1059)
	local v1061 = v_u_6.new
	local v1062 = {
		["Name"] = "Footer",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 24, 1, -6)
	}
	local v1063 = UDim2.new
	local v1064 = v1060 + 6
	v1062.Size = v1063(1, -48, 0, (math.max(18, v1064)))
	local v1065 = v1061("Frame", v1062, v1043)
	v_u_98 = v_u_6.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "micro",
		["textSize"] = nil,
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v1065,
		["text"] = ("HUSH %s  \194\183  %s EXTRACTION  \194\183  %s"):format(v_u_5.config.VERSION or "", (v_u_5.shared.GameMode == nil or not v_u_5.shared.GameMode.isPvpve()) and "PVE" or "PVPVE", string.upper(v_u_11.DisplayName)),
		["textSize"] = v1060,
		["color"] = v_u_8.muted,
		["size"] = UDim2.fromScale(0.7, 1)
	})
	if v_u_98 then
		v_u_98.RichText = true
	end
	v_u_99 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Hint",
		["text"] = "",
		["style"] = "micro",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v1065,
		["textSize"] = v1060,
		["color"] = v_u_8.text2,
		["position"] = UDim2.fromScale(0.45, 0),
		["size"] = UDim2.fromScale(0.25, 1)
	})
	local v1066 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Clock",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v1065,
		["textSize"] = math.max(12, v1060),
		["color"] = v_u_8.muted,
		["position"] = UDim2.fromScale(0.7, 0),
		["size"] = UDim2.fromScale(0.3, 1)
	})
	v1066.Active = true
	v_u_6.tooltip(v1066, function()
		-- upvalues: (ref) v_u_104
		return {
			["title"] = "SERVER TIME",
			["body"] = nil,
			["body"] = v_u_104().CLOCK_TIP
		}
	end)
	local v1067 = v_u_886
	pcall(v1067)
	local v1068 = v_u_100
	pcall(v1068)
	local v1069 = v_u_6.grain
	pcall(v1069, v1043, 0.035)
	function v_u_29.applyUiScale() end
	if v_u_50 and (v_u_50.setStage and not v_u_51) then
		local v1070, v1071, v1072
		if v_u_7.isPhone() and v_u_29.compact() then
			local v1073 = v_u_7.uiScale()
			local v1074 = v_u_7.safeInsets().left
			v1070 = v1074 + (24 + v_u_7.touch(48) + 4) * v1073
			v1071 = v1074 + (v_u_7.safeRefSize().X - 24 - v_u_29.playColW() - 8) * v1073
			v1072 = (72 + v_u_7.touch(44)) * v1073
		else
			v1070 = nil
			v1071 = nil
			v1072 = nil
		end
		local v1075 = v_u_50.setStage
		local v1076 = v_u_50
		pcall(v1075, v1076, v1070, v1071, v1072)
	end
	if v_u_50 and (v_u_50.setStage and v_u_51) then
		local v1077 = nil
		local v1078 = nil
		local v1079 = nil
		local v1080
		if v_u_52 then
			local v1081 = v_u_52.homeApi
			if type(v1081) == "table" then
				v1080 = v_u_52.homeApi.layout
			else
				v1080 = nil
			end
		else
			v1080 = nil
		end
		if v_u_7.isPhone() and type(v1080) == "table" then
			local v1082 = v1080.stage
			if type(v1082) == "table" and v1080.stage.w > 0 then
				local v1083 = v1080.party
				if type(v1083) == "table" then
					local v1084 = v_u_7.uiScale()
					local v1085 = v_u_7.safeInsets().left
					v1077 = v1085 + v1080.stage.x * v1084
					v1078 = v1085 + (v1080.stage.x + v1080.stage.w) * v1084
					v1079 = (v1080.party.y + v1080.party.h) * v1084
				end
			end
		end
		local v1086 = v_u_50.setStage
		local v1087 = v_u_50
		pcall(v1086, v1087, v1077, v1078, v1079)
	end
end
local function v_u_1103() -- name: teardown
	-- upvalues: (ref) v_u_58, (ref) v_u_5, (copy) v_u_86, (ref) v_u_98, (ref) v_u_99, (ref) v_u_80, (copy) v_u_11, (ref) v_u_82, (copy) v_u_29, (ref) v_u_63, (ref) v_u_6, (copy) v_u_48, (copy) v_u_607, (copy) v_u_47, (ref) v_u_56, (ref) v_u_57, (ref) v_u_78, (ref) v_u_52, (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_61, (ref) v_u_62, (ref) v_u_49, (ref) v_u_53, (ref) v_u_51, (ref) v_u_50, (copy) v_u_65
	v_u_58 = false
	local function v1089()
		-- upvalues: (ref) v_u_5
		v_u_5.lib.CrateWindow.menuClosed()
	end
	pcall(v1089)
	table.clear(v_u_86)
	v_u_98 = nil
	v_u_99 = nil
	if v_u_80 then
		local v1090 = v_u_80.destroy
		pcall(v1090)
		v_u_80 = nil
		v_u_11:SetAttribute("MenuTour", nil)
	end
	v_u_82 = false
	v_u_11:SetAttribute("MenuOpen", false)
	v_u_29.syncTutorial()
	v_u_29.tutorialCard = nil
	if v_u_63 ~= false then
		v_u_63 = false
		local v1091 = v_u_6.blur
		pcall(v1091, false, 10)
	end
	for _, v1092 in v_u_48 do
		v_u_607(v1092, "destroy")
	end
	table.clear(v_u_48)
	table.clear(v_u_47)
	if v_u_56 then
		local v1093 = v_u_56.destroy
		local v1094 = v_u_56
		pcall(v1093, v1094)
		v_u_56 = nil
	end
	if v_u_57 then
		local v1095 = v_u_57.destroy
		local v1096 = v_u_57
		pcall(v1095, v1096)
		v_u_57 = nil
		v_u_78 = nil
	end
	if v_u_52 then
		local v1097 = v_u_52.destroy
		pcall(v1097)
		v_u_52 = nil
	end
	if v_u_44 then
		v_u_44:Destroy()
		v_u_44 = nil
	end
	v_u_45 = nil
	v_u_46 = nil
	v_u_29.applyUiScale = nil
	v_u_61 = nil
	v_u_62 = nil
	v_u_49 = nil
	if v_u_53 then
		local v1098 = v_u_53.destroy
		local v1099 = v_u_53
		pcall(v1098, v1099)
		v_u_53 = nil
	end
	if v_u_51 then
		v_u_51 = false
		v_u_29.v2 = false
		v_u_29.director = nil
		v_u_11:SetAttribute("MenuV2", false)
		v_u_11:SetAttribute("MenuCategory", nil)
	end
	if v_u_50 then
		local v1100 = v_u_50.destroy
		local v1101 = v_u_50
		pcall(v1100, v1101)
		v_u_50 = nil
	end
	for _, v1102 in v_u_65 do
		v1102:Disconnect()
	end
	table.clear(v_u_65)
end
function v_u_4.rebuild(p1104) -- name: rebuild
	-- upvalues: (ref) v_u_58, (ref) v_u_44, (ref) v_u_79, (copy) v_u_3, (copy) v_u_4, (ref) v_u_5, (ref) v_u_49, (ref) v_u_78, (ref) v_u_51, (ref) v_u_52, (ref) v_u_54, (copy) v_u_48, (copy) v_u_607, (copy) v_u_47, (ref) v_u_56, (ref) v_u_57, (copy) v_u_29, (ref) v_u_80, (ref) v_u_45, (ref) v_u_46, (ref) v_u_61, (ref) v_u_62, (copy) v_u_1088, (copy) v_u_11, (copy) v_u_399, (copy) v_u_462, (copy) v_u_1012, (copy) v_u_579, (copy) v_u_564, (ref) v_u_13, (ref) v_u_81
	if v_u_58 and (v_u_44 and not v_u_79) then
		local v_u_1105 = type(p1104) ~= "number" and 0 or p1104
		if v_u_1105 < 60 and v_u_3:GetFocusedTextBox() ~= nil then
			task.delay(1, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_1105
				v_u_4.rebuild(v_u_1105 + 1)
			end)
		else
			v_u_79 = true
			local function v1106()
				-- upvalues: (ref) v_u_5
				v_u_5.lib.CrateWindow.menuRebuilt()
			end
			pcall(v1106)
			local v1107 = v_u_49 or "play"
			local v1108 = v_u_78
			if v_u_51 and v_u_52 then
				v_u_54 = {
					["id"] = v_u_52.category(),
					["sub"] = v_u_52.sub()
				}
			end
			for _, v1109 in v_u_48 do
				v_u_607(v1109, "destroy")
			end
			table.clear(v_u_48)
			table.clear(v_u_47)
			if v_u_56 then
				local v1110 = v_u_56.destroy
				local v1111 = v_u_56
				pcall(v1110, v1111)
				v_u_56 = nil
			end
			if v_u_52 then
				local v1112 = v_u_52.destroy
				pcall(v1112)
				v_u_52 = nil
			end
			if v_u_57 then
				local v1113 = v_u_57.destroy
				local v1114 = v_u_57
				pcall(v1113, v1114)
				v_u_57 = nil
			end
			v_u_29.tutorialCard = nil
			local v_u_1115
			if v_u_80 and v_u_80.alive() then
				v_u_1115 = v_u_80.step()
			else
				v_u_1115 = nil
			end
			if v_u_80 then
				local v1116 = v_u_80.destroy
				pcall(v1116)
				v_u_80 = nil
			end
			if v_u_44 then
				v_u_44:Destroy()
				v_u_44 = nil
			end
			v_u_45 = nil
			v_u_46 = nil
			v_u_61 = nil
			v_u_62 = nil
			v_u_49 = nil
			local v1117 = v_u_1088
			local v1118, v1119 = pcall(v1117)
			if not v1118 then
				warn("[Menu] rebuild failed:", v1119)
				v_u_11:SetAttribute("ClientError", "menu rebuild: " .. tostring(v1119))
			end
			v_u_399()
			v_u_462()
			if v1108 then
				v_u_1012(v1108)
			elseif v_u_51 and v_u_52 then
				local v1120 = v_u_54
				v_u_54 = nil
				v_u_579(nil, nil, nil, nil)
				if v1120 and v1120.id then
					v_u_4.openCategory(v1120.id, v1120.sub)
				else
					v_u_52.cam()
					v_u_564.focusHome()
				end
			else
				local v1121 = v_u_4.setTab
				for _, v1122 in v_u_13 do
					if v1122.id ~= v1107 then
						continue
					end
					v1123 = true
				end
				local v1123 = false
				v1121(not v1123 and v1107 ~= "skins" and "play" or v1107)
			end
			v_u_29.syncTutorial()
			v_u_79 = false
			if v_u_1115 then
				v_u_81 = v_u_1115
				task.defer(function()
					-- upvalues: (ref) v_u_29, (copy) v_u_1115
					if v_u_29.startTour then
						v_u_29.startTour(v_u_1115, true)
					end
				end)
			end
		end
	else
		return
	end
end
local function v_u_1209() -- name: openMenu
	-- upvalues: (ref) v_u_58, (ref) v_u_60, (copy) v_u_11, (copy) v_u_769, (ref) v_u_5, (ref) v_u_50, (ref) v_u_66, (ref) v_u_51, (copy) v_u_564, (ref) v_u_53, (copy) v_u_29, (copy) v_u_1088, (copy) v_u_923, (copy) v_u_462, (copy) v_u_1012, (ref) v_u_52, (copy) v_u_579, (copy) v_u_4, (ref) v_u_49, (ref) v_u_64, (copy) v_u_65, (ref) v_u_57, (ref) v_u_6, (copy) v_u_497, (ref) v_u_13, (copy) v_u_3, (ref) v_u_100, (ref) v_u_56
	if not v_u_58 then
		v_u_58 = true
		v_u_60 = v_u_60 + 1
		local v_u_1124 = v_u_60
		v_u_11:SetAttribute("MenuOpen", true)
		task.delay(2.5, function()
			-- upvalues: (ref) v_u_58, (copy) v_u_1124, (ref) v_u_60, (ref) v_u_769
			if v_u_58 and v_u_1124 == v_u_60 then
				v_u_769()
			end
		end)
		local v_u_1125 = "MenuScene"
		local function v1126()
			-- upvalues: (ref) v_u_5, (copy) v_u_1125
			return v_u_5.lib[v_u_1125]
		end
		local v1127, v1128 = pcall(v1126)
		if not v1127 or type(v1128) ~= "table" then
			warn("[Menu] lib missing:", "MenuScene", v1128)
			v1128 = nil
		end
		if v1128 then
			local v1129 = v1128.new
			local v1130 = {
				["cctx"] = v_u_5,
				["origin"] = v_u_5.config.MENU_SCENE_ORIGIN or Vector3.new(-6000, 0, 0)
			}
			local v1131, v1132 = pcall(v1129, v1130)
			if v1131 then
				v_u_50 = v1132
				v_u_50:takeCamera()
				v_u_50:setShot(v_u_66 and "debrief" or "intro", true)
			else
				warn("[Menu] scene failed:", v1132)
				v_u_11:SetAttribute("ClientError", "menu scene: " .. tostring(v1132))
			end
		end
		v_u_51 = false
		v_u_51 = v_u_564.wanted()
		if v_u_51 then
			local v_u_1133 = "MenuDirector"
			local function v1134()
				-- upvalues: (ref) v_u_5, (copy) v_u_1133
				return v_u_5.lib[v_u_1133]
			end
			local v1135, v1136 = pcall(v1134)
			if not v1135 or type(v1136) ~= "table" then
				v1136 = nil
			end
			if v1136 == nil then
				warn("[Menu] MenuV2 off for this visit, lib missing: MenuDirector")
				v_u_51 = false
			elseif v_u_50 ~= nil then
				local v1137 = v1136.new
				local v1138 = {
					["cctx"] = v_u_5,
					["base"] = v_u_5.config.MENU_SCENE_ORIGIN or Vector3.new(-6000, 0, 0),
					["legacy"] = v_u_50
				}
				local v1139, v1140 = pcall(v1137, v1138)
				if v1139 and v1140 ~= nil then
					v_u_53 = v1140
				else
					warn("[Menu] director failed:", v1140)
					v_u_11:SetAttribute("ClientError", "menu director: " .. tostring(v1140))
				end
			end
		end
		v_u_29.v2 = v_u_51
		v_u_29.director = v_u_53
		v_u_11:SetAttribute("MenuV2", v_u_51)
		local v1141 = v_u_5.controllers.Audio
		if v1141 and v1141.setMusicState then
			local v1142 = v1141.setMusicState
			local v1143 = v_u_66 and "debrief" or "menu"
			pcall(v1142, v1143)
		end
		local v1144 = v_u_1088
		local v1145, v1146 = pcall(v1144)
		if not v1145 then
			warn("[Menu] build failed:", v1146)
			v_u_11:SetAttribute("ClientError", "menu build: " .. tostring(v1146))
		end
		for _, v1147 in {
			{ "MenuStoreFeaturedDot", "attach" },
			{ "MenuMarket", "prime" }
		} do
			local v_u_1148 = v1147[1]
			local function v1149()
				-- upvalues: (ref) v_u_5, (copy) v_u_1148
				return v_u_5.lib[v_u_1148]
			end
			local v1150, v1151 = pcall(v1149)
			if not v1150 or type(v1151) ~= "table" then
				v1151 = nil
			end
			if v1151 == nil then
				continue
			end
			local v1152 = v1151[v1147[2]]
			if type(v1152) ~= "function" then
				continue
			end
			local v1153 = v1151[v1147[2]]
			local v1154 = v_u_29
			pcall(v1153, v1154)
		end
		local function v1159()
			-- upvalues: (ref) v_u_5, (ref) v_u_29
			local v_u_1155 = "MenuWipeTimer"
			local function v1156()
				-- upvalues: (ref) v_u_5, (copy) v_u_1155
				return v_u_5.lib[v_u_1155]
			end
			local v1157, v1158 = pcall(v1156)
			if not v1157 or type(v1158) ~= "table" then
				warn("[Menu] lib missing:", "MenuWipeTimer", v1158)
				v1158 = nil
			end
			if v1158 and v1158.check then
				v1158.check(v_u_29)
			end
		end
		pcall(v1159)
		if v_u_29.profile then
			v_u_923(v_u_29.profile, "load")
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_29, (copy) v_u_1124, (ref) v_u_60, (ref) v_u_923, (ref) v_u_462, (ref) v_u_564
			local v1160 = v_u_29.fetch("profile", nil, 0)
			if v_u_1124 == v_u_60 and v1160 then
				v_u_923(v1160, "load")
			end
			v_u_29.partyOp({
				["op"] = "refresh"
			})
			v_u_29.fetch("tasks", nil, 0)
			if v_u_1124 == v_u_60 then
				v_u_462()
				v_u_564.pass()
			end
		end)
		v_u_29.syncTutorial()
		if v_u_66 then
			local v1161 = v_u_66
			v_u_66 = nil
			v_u_1012(v1161)
		elseif v_u_51 and v_u_52 then
			v_u_579(nil, nil, nil, nil)
			if v_u_53 then
				local v1162 = v_u_53.go
				local v1163 = v_u_53
				pcall(v1162, v1163, "street", "intro", {
					["instant"] = true
				})
			end
			v_u_564.focusHome()
			v_u_564.styleTip()
			task.delay(1.6, function()
				-- upvalues: (copy) v_u_1124, (ref) v_u_60, (ref) v_u_52
				if v_u_1124 == v_u_60 and (v_u_52 and v_u_52.category() == nil) then
					v_u_52.cam()
				end
			end)
		else
			v_u_4.setTab("play")
			task.delay(1.6, function()
				-- upvalues: (copy) v_u_1124, (ref) v_u_60, (ref) v_u_50, (ref) v_u_49
				if v_u_1124 == v_u_60 and (v_u_50 and v_u_49 == "play") then
					v_u_50:setShot("play")
				end
			end)
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_1124, (ref) v_u_60, (ref) v_u_29, (ref) v_u_11, (ref) v_u_64, (ref) v_u_5
			local v1164 = os.clock()
			while v_u_1124 == v_u_60 and (not v_u_29.profile and (os.clock() - v1164 < 6 or v_u_11:GetAttribute("ProfileStatus") == "loading" and os.clock() - v1164 < 215)) do
				task.wait(0.1)
			end
			if v_u_1124 == v_u_60 then
				v_u_64 = true
				v_u_5.emit("place.ready", "Menu")
				v_u_11:SetAttribute("MenuReady", true)
				local v_u_1165 = "MenuRestartNotice"
				local function v1166()
					-- upvalues: (ref) v_u_5, (copy) v_u_1165
					return v_u_5.lib[v_u_1165]
				end
				local v1167, v1168 = pcall(v1166)
				if not v1167 or type(v1168) ~= "table" then
					warn("[Menu] lib missing:", "MenuRestartNotice", v1168)
					v1168 = nil
				end
				if v1168 then
					local v1169 = v1168.start
					local v1170 = v_u_29
					pcall(v1169, v1170)
				end
				local v_u_1171 = "MenuSaleNotice"
				local function v1172()
					-- upvalues: (ref) v_u_5, (copy) v_u_1171
					return v_u_5.lib[v_u_1171]
				end
				local v1173, v1174 = pcall(v1172)
				if not v1173 or type(v1174) ~= "table" then
					warn("[Menu] lib missing:", "MenuSaleNotice", v1174)
					v1174 = nil
				end
				if v1174 then
					local v1175 = v1174.start
					local v1176 = v_u_29
					pcall(v1175, v1176)
				end
				task.wait(1.2)
				if v_u_1124 == v_u_60 and v_u_29.maybeTour then
					v_u_29.maybeTour()
				end
				if v_u_1124 == v_u_60 and v_u_29.afterTutorial then
					v_u_29.afterTutorial()
				end
			end
		end)
		local v1177 = v_u_65
		local v1178 = v_u_5.lib.VirtualPad.InputBegan
		local function v1202(p1179, p1180)
			-- upvalues: (ref) v_u_57, (ref) v_u_49, (ref) v_u_51, (ref) v_u_5, (ref) v_u_52, (ref) v_u_6, (ref) v_u_497, (ref) v_u_4, (ref) v_u_13
			if p1180 and (p1179.KeyCode ~= Enum.KeyCode.ButtonL1 and p1179.KeyCode ~= Enum.KeyCode.ButtonR1) then
				return
			elseif v_u_57 or not (v_u_49 or v_u_51) then
				return
			else
				local v1181 = v_u_5.controllers
				if v1181 then
					v1181 = v_u_5.controllers.HuntClient
				end
				if v1181 then
					local v1182 = v1181.isOpen
					if type(v1182) == "function" and v1181.isOpen() then
						return
					end
				end
				local v1183 = p1179.KeyCode == Enum.KeyCode.ButtonR1 and 1 or (p1179.KeyCode == Enum.KeyCode.ButtonL1 and -1 or 0)
				if v1183 == 0 then
					return
				elseif v_u_51 then
					local v_u_1184 = "MenuShellRoute"
					local function v1185()
						-- upvalues: (ref) v_u_5, (copy) v_u_1184
						return v_u_5.lib[v_u_1184]
					end
					local v1186, v1187 = pcall(v1185)
					if not v1186 or type(v1187) ~= "table" then
						v1187 = nil
					end
					if v1187 and (v_u_52 and v_u_6.modalCount() == 0) then
						local v1188 = {}
						local v_u_1189 = "MenuCategories"
						local function v1190()
							-- upvalues: (ref) v_u_5, (copy) v_u_1189
							return v_u_5.lib[v_u_1189]
						end
						local v1191, v1192 = pcall(v1190)
						if not v1191 or type(v1192) ~= "table" then
							v1192 = nil
						end
						local v1193, v1194, v1195
						if v1192 == nil then
							v1193 = {}
							v1194 = nil
							v1195 = nil
						else
							v1193, v1194, v1195 = v1192.visible(v1192.HOME, (v_u_497()))
						end
						for _, v1196 in v1193, v1194, v1195 do
							local v1197 = v1196.id
							table.insert(v1188, v1197)
						end
						local v1198 = v1187.cycle(v1188, v_u_52.category(), v1183, {
							["hideout"] = true
						})
						if v1198 then
							v_u_4.openCategory(v1198, nil)
						end
					end
				else
					local v1199 = 1
					for v1200, v1201 in v_u_13 do
						if v1201.id ~= v_u_49 then
							continue
						end
						v1199 = v1200
					end
					for _ = 1, #v_u_13 do
						v1199 = (v1199 - 1 + v1183) % #v_u_13 + 1
						if v_u_13[v1199].id == "hideout" then
							continue
						end
					end
					v_u_4.setTab(v_u_13[v1199].id)
				end
			end
		end
		table.insert(v1177, v1178:Connect(v1202))
		local v1203 = v_u_65
		local v1204 = v_u_3.LastInputTypeChanged
		local function v1208()
			-- upvalues: (ref) v_u_100, (ref) v_u_56
			local v1205 = v_u_100
			pcall(v1205)
			if v_u_56 then
				local v1206 = v_u_56.refresh
				local v1207 = v_u_56
				pcall(v1206, v1207)
			end
		end
		table.insert(v1203, v1204:Connect(v1208))
	end
end
local function v_u_1212(p1210, p1211) -- name: onPlace
	-- upvalues: (ref) v_u_59, (ref) v_u_76, (ref) v_u_58, (copy) v_u_1209, (ref) v_u_60, (copy) v_u_1103, (copy) v_u_11, (ref) v_u_67, (copy) v_u_29, (ref) v_u_68
	v_u_59 = p1210
	if p1210 == "Menu" then
		v_u_76 = 0
		if not v_u_58 then
			v_u_1209()
			return
		end
	else
		if v_u_58 then
			v_u_60 = v_u_60 + 1
			v_u_1103()
		end
		v_u_11:SetAttribute("MenuReady", false)
		if p1211 == "Menu" or p1210 == "Raid" then
			v_u_67 = v_u_29.cache.tasks and v_u_29.cache.tasks.data or (v_u_68 or v_u_67)
		end
	end
end
function v_u_4.restyle() -- name: restyle
	-- upvalues: (ref) v_u_58, (ref) v_u_59, (ref) v_u_57, (ref) v_u_51, (ref) v_u_52, (ref) v_u_49, (ref) v_u_60, (copy) v_u_1103, (copy) v_u_1209, (copy) v_u_4
	if v_u_58 and (v_u_59 == "Menu" and v_u_57 == nil) then
		local v_u_1213
		if v_u_51 and v_u_52 then
			v_u_1213 = v_u_52.category() ~= nil
		else
			v_u_1213 = v_u_49 == "settings"
		end
		v_u_60 = v_u_60 + 1
		v_u_1103()
		task.defer(function()
			-- upvalues: (ref) v_u_59, (ref) v_u_58, (ref) v_u_1209, (copy) v_u_1213, (ref) v_u_51, (ref) v_u_52, (ref) v_u_4
			if v_u_59 == "Menu" and not v_u_58 then
				v_u_1209()
				if v_u_1213 then
					local function v1214()
						-- upvalues: (ref) v_u_51, (ref) v_u_52, (ref) v_u_4
						if v_u_51 and v_u_52 then
							v_u_4.openCategory("settings")
						else
							v_u_4.setTab("settings")
						end
					end
					pcall(v1214)
				end
			end
		end)
	end
end
function v_u_4.init(p_u_1215) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (copy) v_u_29, (copy) v_u_4, (ref) v_u_9, (ref) v_u_50, (ref) v_u_58, (ref) v_u_44, (copy) v_u_26, (copy) v_u_11, (copy) v_u_923, (copy) v_u_957, (copy) v_u_991, (copy) v_u_462, (ref) v_u_66, (ref) v_u_59, (copy) v_u_1012, (ref) v_u_64, (copy) v_u_479, (ref) v_u_49, (copy) v_u_48, (copy) v_u_607, (copy) v_u_170, (ref) v_u_84, (ref) v_u_57, (ref) v_u_83, (copy) v_u_47, (ref) v_u_45, (ref) v_u_51, (ref) v_u_80, (ref) v_u_81, (ref) v_u_82, (ref) v_u_46, (copy) v_u_600, (copy) v_u_580, (ref) v_u_13, (ref) v_u_78, (ref) v_u_52, (ref) v_u_53, (copy) v_u_497, (ref) v_u_77, (ref) v_u_91, (ref) v_u_89, (copy) v_u_827, (copy) v_u_886, (copy) v_u_104, (copy) v_u_844, (ref) v_u_97, (ref) v_u_92, (copy) v_u_86, (ref) v_u_87, (ref) v_u_98, (ref) v_u_73, (copy) v_u_72
	v_u_5 = p_u_1215
	v_u_6 = p_u_1215.lib.HushUI
	v_u_6.bind(p_u_1215)
	v_u_7 = p_u_1215.shared.Theme
	v_u_8 = v_u_7.color
	v_u_10 = p_u_1215.shared.Signal
	v_u_29.cctx = p_u_1215
	v_u_29.v2 = false
	v_u_29.director = nil
	function v_u_29.go(p1216, p1217)
		-- upvalues: (ref) v_u_4
		v_u_4.openCategory(p1216, p1217)
	end
	function v_u_29.restyleMenu()
		-- upvalues: (ref) v_u_4
		task.defer(v_u_4.restyle)
	end
	function v_u_29.back()
		-- upvalues: (ref) v_u_4
		return v_u_4.back()
	end
	function v_u_29.openStore(p1218)
		-- upvalues: (ref) v_u_4
		v_u_4.openStore(p1218)
	end
	function v_u_29.openSkins(p1219)
		-- upvalues: (ref) v_u_4
		return v_u_4.openSkins(p1219)
	end
	function v_u_29.cratesListed()
		-- upvalues: (ref) v_u_4
		return v_u_4.cratesListed()
	end
	function v_u_29.skinsListed()
		-- upvalues: (ref) v_u_4
		return v_u_4.skinsListed()
	end
	function v_u_29.openCrates(p1220)
		-- upvalues: (ref) v_u_4
		return v_u_4.openCrates(p1220)
	end
	pcall(function()
		-- upvalues: (copy) p_u_1215
		p_u_1215.lib.CrateStage.init(p_u_1215)
	end)
	v_u_29.ui = v_u_6
	v_u_29.theme = v_u_7
	v_u_29.config = p_u_1215.config
	v_u_29.cache = {}
	v_u_29.lastError = {}
	v_u_29.changed = v_u_10.new()
	local function v1221()
		-- upvalues: (copy) p_u_1215, (ref) v_u_29
		p_u_1215.lib.CrateWindow.install(v_u_29)
	end
	pcall(v1221)
	local function v1222()
		-- upvalues: (copy) p_u_1215, (ref) v_u_29
		p_u_1215.lib.MenuCutscenes.watchUnlock(v_u_29)
	end
	pcall(v1222)
	v_u_29.profile = nil
	v_u_29.party = nil
	local v_u_1223 = "MenuKit"
	local function v1224()
		-- upvalues: (ref) v_u_5, (copy) v_u_1223
		return v_u_5.lib[v_u_1223]
	end
	local v1225, v1226 = pcall(v1224)
	if not v1225 or type(v1226) ~= "table" then
		warn("[Menu] lib missing:", "MenuKit", v1226)
		v1226 = nil
	end
	v_u_9 = v1226
	v_u_29.kit = v_u_9
	function v_u_29.scene()
		-- upvalues: (ref) v_u_50
		return v_u_50
	end
	if v_u_9 then
		v_u_9.bind(v_u_29)
	end
	p_u_1215.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
		if v_u_58 and v_u_44 then
			task.defer(v_u_4.rebuild)
		end
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_1215, (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
		local v1227 = p_u_1215.config.watchFlag
		local function v1228()
			-- upvalues: (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
			if v_u_26() and (v_u_58 and v_u_44) then
				task.defer(v_u_4.rebuild)
			end
		end
		pcall(v1227, "GroupStarter", v1228)
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_1215, (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
		local v1229 = p_u_1215.config.watchFlag
		local function v1230()
			-- upvalues: (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
			if v_u_26() and (v_u_58 and v_u_44) then
				task.defer(v_u_4.rebuild)
			end
		end
		pcall(v1229, "Blackmarket", v1230)
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_1215, (ref) v_u_29, (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
		local v1231 = p_u_1215.config.watchFlag
		local function v1232()
			-- upvalues: (ref) v_u_29, (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
			v_u_29.invalidate("crates")
			if v_u_26() and (v_u_58 and v_u_44) then
				task.defer(v_u_4.rebuild)
			end
		end
		pcall(v1231, "SkinCrates", v1232)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4, (ref) v_u_11
		local function v1233() -- name: recheck
			-- upvalues: (ref) v_u_26, (ref) v_u_58, (ref) v_u_44, (ref) v_u_4
			if v_u_26() and (v_u_58 and v_u_44) then
				task.defer(v_u_4.rebuild)
			end
		end
		v_u_11:GetAttributeChangedSignal("PaidTrading"):Connect(v1233)
		local v1234 = game:GetService("ReplicatedStorage"):WaitForChild("Config", 10)
		if v1234 then
			v1234:GetAttributeChangedSignal("BmRm"):Connect(v1233)
		end
	end)
	local function v_u_1236(p1235)
		-- upvalues: (ref) v_u_923
		if type(p1235) == "table" then
			v_u_923(p1235.profile, p1235.reason or "push")
		end
	end
	local v1237 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	local v1238 = v1237
	if v1238 then
		v1238 = v1237:FindFirstChild("menu.state")
	end
	if not (v1238 and v1238:IsA("RemoteEvent")) then
		v1238 = nil
	end
	if v1238 then
		v1238.OnClientEvent:Connect(v_u_1236)
	else
		local v_u_1239 = "menu.state"
		task.spawn(function()
			-- upvalues: (copy) v_u_1239, (copy) v_u_1236
			local v1240 = game:GetService("ReplicatedStorage"):WaitForChild("HushNet"):WaitForChild(v_u_1239, 60)
			if v1240 and v1240:IsA("RemoteEvent") then
				v1240.OnClientEvent:Connect(v_u_1236)
			else
				warn("[Menu] remote missing:", v_u_1239)
			end
		end)
	end
	local v_u_1241 = v_u_957
	local v1242 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	local v1243 = v1242
	if v1243 then
		v1243 = v1242:FindFirstChild("menu.result")
	end
	if not (v1243 and v1243:IsA("RemoteEvent")) then
		v1243 = nil
	end
	if v1243 then
		v1243.OnClientEvent:Connect(v_u_1241)
	else
		local v_u_1244 = "menu.result"
		task.spawn(function()
			-- upvalues: (copy) v_u_1244, (copy) v_u_1241
			local v1245 = game:GetService("ReplicatedStorage"):WaitForChild("HushNet"):WaitForChild(v_u_1244, 60)
			if v1245 and v1245:IsA("RemoteEvent") then
				v1245.OnClientEvent:Connect(v_u_1241)
			else
				warn("[Menu] remote missing:", v_u_1244)
			end
		end)
	end
	local function v1250()
		-- upvalues: (ref) v_u_5, (ref) v_u_29
		local v_u_1246 = "MenuFactions"
		local function v1247()
			-- upvalues: (ref) v_u_5, (copy) v_u_1246
			return v_u_5.lib[v_u_1246]
		end
		local v1248, v1249 = pcall(v1247)
		if not v1248 or type(v1249) ~= "table" then
			warn("[Menu] lib missing:", "MenuFactions", v1249)
			v1249 = nil
		end
		if v1249 and v1249.attach then
			v1249.attach(v_u_29)
		end
	end
	pcall(v1250)
	local v_u_1251 = v_u_991
	local v1252 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	local v1253 = v1252
	if v1253 then
		v1253 = v1252:FindFirstChild("party.state")
	end
	if not (v1253 and v1253:IsA("RemoteEvent")) then
		v1253 = nil
	end
	if v1253 then
		v1253.OnClientEvent:Connect(v_u_1251)
	else
		local v_u_1254 = "party.state"
		task.spawn(function()
			-- upvalues: (copy) v_u_1254, (copy) v_u_1251
			local v1255 = game:GetService("ReplicatedStorage"):WaitForChild("HushNet"):WaitForChild(v_u_1254, 60)
			if v1255 and v1255:IsA("RemoteEvent") then
				v1255.OnClientEvent:Connect(v_u_1251)
			else
				warn("[Menu] remote missing:", v_u_1254)
			end
		end)
	end
	for _, v1256 in {
		"BmBadge",
		"BmPending",
		"RsLive",
		"TradeReqCount",
		"PassClaimable",
		"StoreFeatured",
		"StoreFeaturedSale"
	} do
		v_u_11:GetAttributeChangedSignal(v1256):Connect(function()
			-- upvalues: (ref) v_u_58, (ref) v_u_462
			if v_u_58 then
				v_u_462()
			end
		end)
	end
	local v_u_1257 = nil
	local v_u_1258 = nil
	local v_u_1259 = nil
	local v_u_1260 = 0
	local function v_u_1272(p1261) -- name: handoffSkip
		-- upvalues: (ref) v_u_11, (ref) v_u_1259, (ref) v_u_1260, (ref) v_u_1257, (ref) v_u_1258
		if game:GetService("RunService"):IsStudio() and p1261.fallback ~= true then
			local v1262 = v_u_11:GetAttribute("HandoffDrop")
			if v1262 ~= v_u_1259 then
				v_u_1259 = v1262
				local v1263 = string.match
				local v1264 = tostring(v1262)
				v_u_1260 = tonumber(v1263(v1264, "^(%d+)")) or 0
			end
			if v_u_1260 > 0 then
				v_u_1260 = v_u_1260 - 1
				return true
			end
		end
		if p1261.resend ~= true and p1261.fallback ~= true or (v_u_1257 == nil or os.clock() - v_u_1257 >= 45) then
			return false
		end
		local v1265 = p1261.did
		if type(v1265) == "string" then
			local v1266 = v_u_1258
			if type(v1266) == "string" and p1261.did ~= v_u_1258 then
				return false
			end
		end
		local v_u_1267 = p1261.did
		local v_u_1268 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
		if v_u_1268 then
			v_u_1268 = v_u_1268:FindFirstChild("raid.debrief.ack")
		end
		if not (v_u_1268 and v_u_1268:IsA("RemoteEvent")) then
			v_u_1268 = nil
		end
		if v_u_1268 then
			pcall(function()
				-- upvalues: (copy) v_u_1268, (copy) v_u_1267
				local v1269 = v_u_1268
				local v1270 = v_u_1267
				local v1271
				if type(v1270) == "string" then
					v1271 = v_u_1267
				else
					v1271 = nil
				end
				v1269:FireServer(v1271)
			end)
		end
		return true
	end
	local function v_u_1280(p1273)
		-- upvalues: (copy) v_u_1272, (ref) v_u_66, (ref) v_u_58, (ref) v_u_59, (ref) v_u_1012, (ref) v_u_1257, (ref) v_u_1258
		if type(p1273) == "table" then
			if v_u_1272(p1273) then
				return
			end
			v_u_66 = p1273
			if v_u_58 and v_u_59 == "Menu" then
				local v1274 = v_u_66
				v_u_66 = nil
				v_u_1012(v1274)
			end
			v_u_1257 = os.clock()
			v_u_1258 = p1273.did
			local v_u_1275 = p1273.did
			local v_u_1276 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
			if v_u_1276 then
				v_u_1276 = v_u_1276:FindFirstChild("raid.debrief.ack")
			end
			if not (v_u_1276 and v_u_1276:IsA("RemoteEvent")) then
				v_u_1276 = nil
			end
			if v_u_1276 then
				pcall(function()
					-- upvalues: (copy) v_u_1276, (copy) v_u_1275
					local v1277 = v_u_1276
					local v1278 = v_u_1275
					local v1279
					if type(v1278) == "string" then
						v1279 = v_u_1275
					else
						v1279 = nil
					end
					v1277:FireServer(v1279)
				end)
			end
		end
	end
	local v1281 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
	if v1281 then
		v1281 = v1281:FindFirstChild("raid.debrief")
	end
	if not (v1281 and v1281:IsA("RemoteEvent")) then
		v1281 = nil
	end
	if v1281 then
		v1281.OnClientEvent:Connect(v_u_1280)
	else
		local v_u_1282 = "raid.debrief"
		task.spawn(function()
			-- upvalues: (copy) v_u_1282, (copy) v_u_1280
			local v1283 = game:GetService("ReplicatedStorage"):WaitForChild("HushNet"):WaitForChild(v_u_1282, 60)
			if v1283 and v1283:IsA("RemoteEvent") then
				v1283.OnClientEvent:Connect(v_u_1280)
			else
				warn("[Menu] remote missing:", v_u_1282)
			end
		end)
	end
	for _, v1284 in { "TutorialDone", "TutorialResult", "TutorialResultId" } do
		v_u_11:GetAttributeChangedSignal(v1284):Connect(function()
			-- upvalues: (ref) v_u_58, (ref) v_u_29
			if v_u_58 then
				v_u_29.syncTutorial()
			end
		end)
	end
	local v_u_1285 = v_u_11:GetAttribute("TutorialDone")
	v_u_11:GetAttributeChangedSignal("TutorialDone"):Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_1285, (ref) v_u_58, (ref) v_u_59, (ref) v_u_64, (ref) v_u_29, (ref) v_u_479
		local v1286 = v_u_11:GetAttribute("TutorialDone")
		if v_u_1285 == false and (v1286 == true and (v_u_58 and (v_u_59 == "Menu" and v_u_64))) then
			task.delay(0.6, function()
				-- upvalues: (ref) v_u_58, (ref) v_u_29, (ref) v_u_479
				if v_u_58 and v_u_29.openTask then
					v_u_29.invalidate("tasks")
					v_u_29.fetch("tasks", nil, 0)
					v_u_29.openTask(v_u_479("doc") or v_u_479(nil))
				end
			end)
		end
		v_u_1285 = v1286
	end)
	function v_u_29.openTask(p1287)
		-- upvalues: (ref) v_u_29, (ref) v_u_49, (ref) v_u_48, (ref) v_u_607, (ref) v_u_4
		v_u_29.focusTask = p1287
		if v_u_49 == "tasks" and v_u_48.tasks then
			v_u_607(v_u_48.tasks, "refresh", "focus")
		else
			v_u_4.setTab("tasks")
		end
	end
	function v_u_29.afterTutorial()
		-- upvalues: (ref) v_u_170, (ref) v_u_11, (ref) v_u_84, (ref) v_u_29, (ref) v_u_57, (ref) v_u_83, (ref) v_u_58, (ref) v_u_479
		if v_u_170() == "complete" then
			local v1288 = v_u_11:GetAttribute("TutorialResultId")
			if v1288 == nil or v1288 == v_u_84 then
				return
			else
				v_u_84 = v1288
				if v_u_29.fetch("tasks", nil, 5) == nil then
					return
				elseif v_u_57 then
					v_u_83 = true
				elseif v_u_58 then
					v_u_29.openTask(v_u_479("doc") or v_u_479(nil))
				end
			end
		else
			return
		end
	end
	local function v_u_1298(p1289) -- name: revealTab
		-- upvalues: (ref) v_u_47, (ref) v_u_7
		local v1290 = v_u_47[p1289]
		local v1291
		if v1290 then
			v1291 = v1290.btn.Parent
		else
			v1291 = v1290
		end
		if v1290 and (v1291 and v1291:IsA("ScrollingFrame")) then
			local v1292 = v_u_7.uiScale()
			local v1293 = math.max(v1292, 0.01)
			local v1294 = (v1290.btn.AbsolutePosition.X - v1291.AbsolutePosition.X + v1291.CanvasPosition.X) / v1293
			local v1295 = v1290.btn.AbsoluteSize.X / v1293
			local v1296 = v1291.AbsoluteSize.X / v1293
			if v1296 >= 8 and v1295 >= 1 then
				local v1297 = v1291.CanvasPosition.X / v1293
				if v1294 < v1297 + 56 then
					v1297 = v1294 - 60
				elseif v1294 + v1295 > v1297 + v1296 - 56 then
					v1297 = v1294 + v1295 - v1296 + 60
				end
				v1291.CanvasPosition = Vector2.new(math.max(0, v1297) * v1293, 0)
			end
		else
			return
		end
	end
	function v_u_29.startTour(p1299, p1300)
		-- upvalues: (ref) v_u_58, (ref) v_u_45, (ref) v_u_51, (ref) v_u_5, (ref) v_u_80, (ref) v_u_57, (ref) v_u_29, (ref) v_u_47, (copy) v_u_1298, (ref) v_u_81, (ref) v_u_11, (ref) v_u_49, (ref) v_u_6, (ref) v_u_7
		if v_u_58 and (v_u_45 and not v_u_51) then
			local v_u_1301 = "MenuCoach"
			local function v1302()
				-- upvalues: (ref) v_u_5, (copy) v_u_1301
				return v_u_5.lib[v_u_1301]
			end
			local v1303, v1304 = pcall(v1302)
			if not v1303 or type(v1304) ~= "table" then
				warn("[Menu] lib missing:", "MenuCoach", v1304)
				v1304 = nil
			end
			if v1304 then
				if v_u_80 then
					local v1305 = v_u_80.destroy
					pcall(v1305)
					v_u_80 = nil
				end
				if v_u_57 then
					return false
				else
					local v1306 = v1304.new
					local v1307 = v_u_29
					local v1308 = v_u_45
					local v1314 = {
						["step"] = p1299 or 1,
						["target"] = function(p1309) -- name: target
							-- upvalues: (ref) v_u_47
							local v1310 = v_u_47[p1309]
							if v1310 then
								v1310 = v1310.btn
							end
							return v1310
						end,
						["reveal"] = v_u_1298,
						["onStep"] = function(p1311) -- name: onStep
							-- upvalues: (ref) v_u_81, (ref) v_u_11
							v_u_81 = p1311
							v_u_11:SetAttribute("MenuTour", p1311)
						end,
						["onDone"] = function() -- name: onDone
							-- upvalues: (ref) v_u_80, (ref) v_u_81, (ref) v_u_11, (ref) v_u_1298, (ref) v_u_49, (ref) v_u_29
							v_u_80 = nil
							v_u_81 = nil
							v_u_11:SetAttribute("MenuTour", nil)
							v_u_1298(v_u_49 or "play")
							local v1312 = v_u_29.profile
							if type(v1312) == "table" then
								local v1313 = v1312.settings
								if type(v1313) ~= "table" or v1312.settings.menuTourSeen ~= true then
									v_u_29.op({
										["op"] = "setting",
										["key"] = "menuTourSeen",
										["value"] = true
									})
								end
							else
								v_u_29.op({
									["op"] = "setting",
									["key"] = "menuTourSeen",
									["value"] = true
								})
								return
							end
						end
					}
					local v1315, v1316 = pcall(v1306, v1307, v1308, v1314)
					if v1315 then
						v_u_80 = v1316
						if not p1300 then
							v_u_6.sound(v_u_7.sounds.open or v_u_7.sounds.click)
						end
						return true
					else
						warn("[Menu] tour failed:", v1316)
						v_u_11:SetAttribute("ClientError", "menu tour: " .. tostring(v1316))
						return false
					end
				end
			else
				return false
			end
		else
			return false
		end
	end
	function v_u_29.maybeTour()
		-- upvalues: (ref) v_u_82, (ref) v_u_58, (ref) v_u_80, (ref) v_u_29, (ref) v_u_57
		if v_u_82 or (not v_u_58 or v_u_80) then
			return
		else
			local v1317 = v_u_29.profile
			if type(v1317) == "table" then
				v_u_82 = true
				local v1318 = v1317.settings
				if type(v1318) == "table" and v1317.settings.menuTourSeen == true then
					return
				elseif v_u_57 then
					v_u_82 = false
				else
					v_u_29.startTour(1)
				end
			else
				return
			end
		end
	end
	p_u_1215.command("menu.store", function(p1319)
		-- upvalues: (ref) v_u_58, (ref) v_u_11, (ref) v_u_4
		if not v_u_58 then
			local v1320 = v_u_11
			return "menu is not open (Place=" .. tostring(v1320:GetAttribute("Place")) .. ")"
		end
		v_u_4.openStore(p1319[1])
		local v1321 = p1319[1] or "pass_secure"
		return "store " .. tostring(v1321)
	end)
	p_u_1215.command("menu.gift", function(p_u_1322)
		-- upvalues: (ref) v_u_58, (ref) v_u_11, (ref) v_u_4, (ref) v_u_46, (ref) v_u_600
		if not v_u_58 then
			local v1323 = v_u_11
			return "menu is not open (Place=" .. tostring(v1323:GetAttribute("Place")) .. ")"
		end
		v_u_4.setTab("store")
		task.defer(function()
			-- upvalues: (ref) v_u_58, (ref) v_u_46, (ref) v_u_600, (copy) p_u_1322
			local v1324
			if v_u_58 and v_u_46 then
				v1324 = v_u_600("store")
			else
				v1324 = nil
			end
			if v1324 then
				v1324 = v1324.tab
			end
			if v1324 and v1324.api then
				local v1325 = v1324.api.gift
				if type(v1325) == "function" then
					local v1326 = v1324.api.gift
					local v1327 = p_u_1322[1] or "pass_vip"
					pcall(v1326, v1327)
				end
			end
		end)
		local v1328 = p_u_1322[1] or "pass_vip"
		return "gift dialog " .. tostring(v1328)
	end)
	p_u_1215.command("menu.opentraders", function(p1329)
		-- upvalues: (ref) v_u_4
		v_u_4.openTraders(p1329[1])
		local v1330 = p1329[1] or "sell"
		return "openTraders " .. tostring(v1330)
	end)
	p_u_1215.command("menu.openmarket", function(p1331)
		-- upvalues: (ref) v_u_4
		v_u_4.openMarket(p1331[1], p1331[2])
		local v1332 = p1331[1] or "browse"
		return "openMarket " .. tostring(v1332)
	end)
	p_u_1215.command("menu.openskins", function(p1333)
		-- upvalues: (ref) v_u_4
		local v1334 = v_u_4.openSkins
		local v1335 = p1333[1]
		local v1336 = tostring(v1334(v1335))
		local v1337 = p1333[1] or ""
		return "openSkins " .. v1336 .. " " .. tostring(v1337)
	end)
	p_u_1215.command("menu.tab", function(p1338)
		-- upvalues: (ref) v_u_58, (ref) v_u_11, (ref) v_u_4, (ref) v_u_49, (ref) v_u_580, (ref) v_u_13, (ref) v_u_57, (ref) v_u_78
		local v1339 = string.lower(p1338[1] or "play")
		if not v_u_58 then
			local v1340 = v_u_11
			return "menu is not open (Place=" .. tostring(v1340:GetAttribute("Place")) .. ")"
		end
		if v1339 == "hideout" then
			v_u_4.setTab(v1339)
			local v1341 = v_u_11
			local v1342 = v_u_49
			return ("hideout is a place change, not a tab: transit requested (Place=%s, tab stays %s)"):format(tostring(v1341:GetAttribute("Place")), (tostring(v1342)))
		end
		if v_u_580[v1339] then
			for _, v1343 in v_u_13 do
				if v1343.id ~= v1339 then
					continue
				end
				v1344 = true
			end
			local v1344 = false
			if v1344 then
				if v_u_57 then
					local v1345 = v_u_57.destroy
					local v1346 = v_u_57
					pcall(v1345, v1346)
					v_u_57 = nil
					v_u_78 = nil
					v_u_49 = nil
				end
				v_u_4.setTab(v1339)
				if v_u_49 == v1339 then
					local v1347 = v_u_49
					return "tab " .. tostring(v1347)
				else
					local v1348 = v_u_49
					return "tab " .. v1339 .. " not shown (current " .. tostring(v1348) .. ")"
				end
			end
		end
		local v1349 = {}
		for _, v1350 in v_u_13 do
			if not v_u_580[v1350.id] then
				continue
			end
			local v1351 = v1350.id
			table.insert(v1349, v1351)
		end
		local v1352 = v_u_49
		return ("unknown tab \'%s\', nothing changed (tab stays %s; tabs: %s, or hideout)"):format(v1339, tostring(v1352), table.concat(v1349, "|"))
	end)
	p_u_1215.command("menu.v2", function(p1353)
		-- upvalues: (ref) v_u_58, (ref) v_u_11, (ref) v_u_51, (ref) v_u_52, (ref) v_u_4, (ref) v_u_53, (ref) v_u_5, (ref) v_u_497
		if not v_u_58 then
			local v1354 = v_u_11
			return "menu is not open (Place=" .. tostring(v1354:GetAttribute("Place")) .. ")"
		end
		if not (v_u_51 and v_u_52) then
			return "MenuV2 is off for this visit (the flag MenuV2 was not true when the menu opened)"
		end
		local v1355 = p1353[1] or "state"
		if v1355 == "go" then
			v_u_4.openCategory(p1353[2] or "deploy", p1353[3])
		else
			if v1355 == "back" then
				local v1356 = v_u_4.back
				local v1357 = tostring(v1356())
				local v1358 = v_u_52.category() or "home"
				return "back " .. v1357 .. " now " .. tostring(v1358)
			end
			if v1355 == "home" then
				v_u_52.home()
				v_u_52.cam()
			else
				if v1355 == "audit" then
					local v1359 = v_u_52.audit
					local v1360 = p1353[2]
					return v1359((tonumber(v1360)))
				end
				if v1355 == "press" then
					local v1361 = p1353[2]
					local v1362 = tostring(v1361)
					local v1363 = v_u_52.press
					local v1364 = p1353[2] or ""
					return "press " .. v1362 .. " " .. tostring(v1363(v1364))
				end
			end
		end
		local v1365, v1366
		if v_u_53 then
			local v1367, v1368 = v_u_53:current()
			v1365 = tostring(v1367)
			v1366 = tostring(v1368)
		else
			v1365 = "?"
			v1366 = "?"
		end
		local v1369 = "v2 category=%s sub=%s page=%s camera=%s/%s rows=%d tab=%s cam=%s"
		local v1370 = v_u_52.category() or "home"
		local v1371 = tostring(v1370)
		local v1372 = v_u_52.sub
		local v1373 = tostring(v1372())
		local v1374 = v_u_52.pageKey
		local v1375 = tostring(v1374())
		local v_u_1376 = "MenuCategories"
		local function v1377()
			-- upvalues: (ref) v_u_5, (copy) v_u_1376
			return v_u_5.lib[v_u_1376]
		end
		local v1378, v1379 = pcall(v1377)
		if not v1378 or type(v1379) ~= "table" then
			v1379 = nil
		end
		local v1380 = v_u_11
		local v1381 = v_u_11
		return v1369:format(v1371, v1373, v1375, v1365, v1366, #(v1379 == nil and {} or v1379.visible(v1379.HOME, (v_u_497()))), tostring(v1380:GetAttribute("MenuTab")), (tostring(v1381:GetAttribute("MenuCam"))))
	end)
	p_u_1215.command("menu.tutorial", function(p1382)
		-- upvalues: (ref) v_u_29, (ref) v_u_58, (ref) v_u_46, (ref) v_u_48, (ref) v_u_57, (ref) v_u_4, (ref) v_u_600, (ref) v_u_170, (ref) v_u_77, (ref) v_u_11
		local v1383 = v_u_29.tutorialCard
		local v1384 = p1382[1]
		local v1385
		if v1383 or (not v_u_58 or (not v_u_46 or v_u_48.play)) then
			v1385 = ""
		else
			if v_u_57 == nil then
				v_u_4.setTab("play")
			else
				v_u_600("play")
				v_u_29.syncTutorial()
			end
			v1383 = v_u_29.tutorialCard
			v1385 = " (built PLAY first)"
		end
		if v1384 == "start" or (v1384 == "skip" or v1384 == "dismiss") then
			if not v1383 then
				return "no tutorial card (" .. (v_u_58 and (v_u_48.play and "PLAY built, card failed" or "PLAY could not be built") or "menu not open") .. ")"
			end
			if v1384 == "start" then
				local v1386 = v1383.main
				pcall(v1386)
			else
				local v1387 = v1383.side
				pcall(v1387)
				if v1384 == "skip" then
					local v1388 = v1383.side
					pcall(v1388)
				end
			end
		end
		local v1389
		if v1383 then
			v1389 = v1383.frame
		else
			v1389 = v1383
		end
		local v1390 = true
		if v1389 then
			for _, v1391 in v1389:GetDescendants() do
				if not (v1391:IsA("TextLabel") or v1391:IsA("TextButton")) or (not v1391.Visible or (v1391.Text == "" or (v1391.TextFits or (v1391.TextTruncate ~= Enum.TextTruncate.None or v1391.TextScaled)))) then
					continue
				end
				v1390 = false
			end
		end
		local v1392 = "state=%s card=%s visible=%s size=%s fits=%s claimed=%s MenuTutorialCard=%s TutorialDone=%s result=%s/%s dismissed=%s%s"
		local v1393 = v_u_170()
		local v1394 = tostring(v1393)
		local v1395 = v1383 ~= nil
		local v1396 = tostring(v1395)
		local v1397
		if v1389 == nil then
			v1397 = false
		else
			v1397 = v1389.Visible
		end
		local v1398 = tostring(v1397)
		local v1399 = not v1389 and "-" or ("%dx%d"):format(v1389.AbsoluteSize.X, v1389.AbsoluteSize.Y)
		local v1400 = tostring(v1390)
		local v1401 = v_u_77
		local v1402 = tostring(v1401)
		local v1403 = v_u_11
		local v1404 = tostring(v1403:GetAttribute("MenuTutorialCard"))
		local v1405 = v_u_11
		local v1406 = tostring(v1405:GetAttribute("TutorialDone"))
		local v1407 = v_u_11
		local v1408 = tostring(v1407:GetAttribute("TutorialResult"))
		local v1409 = v_u_11
		local v1410 = tostring(v1409:GetAttribute("TutorialResultId"))
		local v1411 = v_u_29.tutorialDismissed
		return v1392:format(v1394, v1396, v1398, v1399, v1400, v1402, v1404, v1406, v1408, v1410, tostring(v1411), v1385)
	end)
	p_u_1215.command("menu.shot", function(p1412)
		-- upvalues: (ref) v_u_50
		if not v_u_50 then
			return "no scene"
		end
		v_u_50:setShot(p1412[1] or "play", p1412[2] == "instant")
		return "shot " .. (p1412[1] or "play")
	end)
	p_u_1215.command("menu.state", function()
		-- upvalues: (ref) v_u_29, (ref) v_u_58, (ref) v_u_49, (ref) v_u_50, (ref) v_u_64
		local v1413 = v_u_29.profile
		local v1414 = workspace.CurrentCamera
		local v1415 = "open=%s tab=%s profile=%s cash=%s party=%s deploying=%s scene=%s survivor=%s cam=%s ready=%s"
		local v1416 = v_u_58
		local v1417 = tostring(v1416)
		local v1418 = v_u_49
		local v1419 = tostring(v1418)
		local v1420 = v1413 ~= nil
		local v1421 = tostring(v1420)
		if v1413 then
			v1413 = v1413.cash
		end
		local v1422 = tostring(v1413)
		local v1423 = v_u_29.myParty() and #v_u_29.myParty().members or 0
		local v1424 = tostring(v1423)
		local v1425 = v_u_29.partyDeploying
		local v1426 = tostring(v1425())
		local v1427 = v_u_50 ~= nil
		local v1428 = tostring(v1427)
		local v1429 = v_u_50
		if v1429 then
			v1429 = v_u_50.survivor ~= nil
		end
		local v1430 = tostring(v1429)
		if v1414 then
			v1414 = v1414.CameraType.Name
		end
		local v1431 = v_u_64
		return v1415:format(v1417, v1419, v1421, v1422, v1424, v1426, v1428, v1430, tostring(v1414), (tostring(v1431)))
	end)
	p_u_1215.command("menu.debrief", function(p1432)
		-- upvalues: (ref) v_u_11, (ref) v_u_58, (ref) v_u_1012
		local v1433 = p1432[1] or "Extracted"
		local v1434 = {
			["freeRaid"] = nil,
			["outcome"] = nil,
			["extractName"] = nil,
			["durationSec"] = 734,
			["kills"] = nil,
			["lootValue"] = nil,
			["xp"] = nil,
			["taskEvents"] = nil,
			["foundIds"] = nil,
			["savedStrangers"] = 1,
			["difficulty"] = "Normal",
			["timeOfDay"] = "Dusk",
			["weather"] = "Rain",
			["extra"] = nil,
			["freeRaid"] = p1432[2] == "free",
			["outcome"] = v1433,
			["extractName"] = v1433 == "Extracted" and "Highway Roadblock" or nil,
			["kills"] = {
				["walker"] = 11,
				["runner"] = 3,
				["brute"] = 1
			},
			["lootValue"] = v1433 == "Extracted" and 48250 or 0,
			["xp"] = {
				["aim"] = 42,
				["looting"] = 30,
				["endurance"] = 12,
				["sneak"] = 18
			},
			["taskEvents"] = {},
			["foundIds"] = { "val_watch_gold", "med_bandage", "mat_wires" },
			["extra"] = {
				["countsLine"] = nil,
				["killsTotal"] = 15,
				["xpTotal"] = 102,
				["items"] = nil,
				["startValue"] = 12000,
				["lostValue"] = nil,
				["revives"] = 1,
				["downs"] = 0,
				["damageTaken"] = 64,
				["squad"] = nil,
				["countsLine"] = p1432[3] == "counts" and {
					["title"] = "Leaderboard and faction",
					["text"] = "Counts for you: $12,000 of $48,250. Only loot you found yourself counts.",
					["right"] = "+$12,000"
				} or nil,
				["items"] = {
					["val_watch_gold"] = 1,
					["med_bandage"] = 3,
					["mat_wires"] = 2
				},
				["lostValue"] = v1433 == "Extracted" and 0 or 12000,
				["squad"] = {
					{
						["userId"] = v_u_11.UserId,
						["name"] = v_u_11.Name,
						["displayName"] = v_u_11.DisplayName,
						["status"] = v1433 == "Extracted" and "Extracted" or "Dead"
					}
				}
			}
		}
		if not v_u_58 then
			return "menu is not open"
		end
		v_u_1012(v1434)
		return "debrief " .. v1433
	end)
	p_u_1215.command("menu.tour", function(p1435)
		-- upvalues: (ref) v_u_29, (ref) v_u_80
		local v1436 = p1435[1] or "state"
		if v1436 == "start" then
			local v1437 = v_u_29.startTour
			local v1438 = p1435[2]
			local v1439 = v1437(tonumber(v1438) or 1)
			return "tour start " .. tostring(v1439)
		end
		if v1436 == "next" and v_u_80 then
			v_u_80.next()
		elseif v1436 == "skip" and v_u_80 then
			v_u_80.skip()
		end
		local v1440 = v_u_80
		if v1440 then
			v1440 = v_u_80.frame()
		end
		local v1441 = "tour=%s step=%s callout=%s seen=%s"
		local v1442 = v_u_80 ~= nil
		local v1443 = tostring(v1442)
		local v1444 = v_u_80
		if v1444 then
			v1444 = v_u_80.step()
		end
		local v1445 = tostring(v1444)
		local v1446 = not v1440 and "-" or ("%dx%d @%d,%d"):format(v1440.AbsoluteSize.X, v1440.AbsoluteSize.Y, v1440.AbsolutePosition.X, v1440.AbsolutePosition.Y)
		local v1447 = v_u_29.profile
		local v1448
		if type(v1447) == "table" then
			local v1449 = v_u_29.profile.settings
			if type(v1449) == "table" then
				v1448 = v_u_29.profile.settings.menuTourSeen
			else
				v1448 = false
			end
		else
			v1448 = false
		end
		return v1441:format(v1443, v1445, v1446, (tostring(v1448)))
	end)
	p_u_1215.command("menu.badges", function()
		-- upvalues: (ref) v_u_462, (ref) v_u_47, (ref) v_u_11
		v_u_462()
		local v1450 = v_u_47.tasks
		if v1450 then
			v1450 = v1450.btn:FindFirstChild("Count")
		end
		local v1451
		if v1450 then
			v1451 = v1450:FindFirstChild("N")
		else
			v1451 = v1450
		end
		local v1452 = "MenuTasksBadge=%s chip=%s text=%s"
		local v1453 = v_u_11
		local v1454 = tostring(v1453:GetAttribute("MenuTasksBadge"))
		if v1450 then
			v1450 = v1450.Visible
		end
		local v1455 = tostring(v1450)
		if v1451 then
			v1451 = v1451.Text
		end
		return v1452:format(v1454, v1455, (tostring(v1451)))
	end)
	p_u_1215.command("menu.settings", function()
		-- upvalues: (ref) v_u_11
		local v1456 = {}
		for _, v1457 in {
			"GfxQuality",
			"TouchSize",
			"TouchStickSize",
			"TouchMoveFixed",
			"TouchOpacity",
			"HideHeadwear",
			"CameraZoomDefault",
			"UiScaleMul",
			"CameraShake",
			"Volume_Master",
			"Volume_Music",
			"Volume_SFX",
			"Volume_Ambience",
			"Volume_UI",
			"MenuUiMulFolded"
		} do
			local v1458 = v_u_11
			local v1459 = v1457 .. "=" .. tostring(v1458:GetAttribute(v1457))
			table.insert(v1456, v1459)
		end
		return table.concat(v1456, " ")
	end)
	p_u_1215.command("menu.sim", function(p1460)
		-- upvalues: (ref) v_u_91, (ref) v_u_89, (ref) v_u_29, (ref) v_u_827, (ref) v_u_886, (ref) v_u_104, (ref) v_u_844, (ref) v_u_991, (ref) v_u_97, (ref) v_u_462, (ref) v_u_11, (ref) v_u_92, (ref) v_u_86, (ref) v_u_87, (ref) v_u_98
		local v1461 = p1460[1]
		if v1461 == "temp" then
			local v1462
			if p1460[2] == "on" then
				v1462 = true
			elseif p1460[2] == "off" then
				v1462 = false
			else
				v1462 = nil
			end
			v_u_91 = v1462
			if p1460[2] == "on" then
				v_u_89 = false
				local v1463 = v_u_29.profile
				if type(v1463) == "table" then
					local v1464 = v_u_827
					local v1465 = v_u_29.profile
					pcall(v1464, v1465)
				end
			end
			local v1466 = v_u_886
			pcall(v1466)
			local v1467 = v_u_91
			return "tempSim " .. tostring(v1467)
		end
		if v1461 == "cut" then
			local v1468
			if p1460[2] then
				v1468 = table.concat(p1460, " ", 2)
			else
				v1468 = nil
			end
			local v1469, v1470 = v_u_104().cutShort(v1468)
			v_u_844(v1469, v1470)
			return "cut card queued: " .. v1470
		end
		if v1461 == "notice" then
			local v1471 = p1460[2] or "home_closed"
			v_u_991({
				["notice"] = {
					["text"] = nil,
					["kind"] = "warn",
					["code"] = nil,
					["text"] = table.concat(p1460, " ", 3),
					["code"] = v1471
				}
			})
			return "notice " .. v1471
		end
		if v1461 == "craft" then
			local v1472 = v_u_29.profile
			if type(v1472) == "table" then
				v_u_29.profile.crafts = p1460[2] == "off" and {} or {
					["workbench"] = {
						["readyAt"] = os.time() + v_u_97 - 5
					}
				}
				v_u_462()
			end
			local v1473 = v_u_11
			return "MenuHideoutReady=" .. tostring(v1473:GetAttribute("MenuHideoutReady"))
		end
		if v1461 ~= "waiting" then
			local v1474 = v_u_87
			local v1475 = v_u_91
			return ("cards=%d pump=%s temp=%s footer=%s"):format(#v_u_86, tostring(v1474), tostring(v1475), not v_u_98 and "-" or v_u_98.Text)
		end
		v_u_92 = 0
		local v1476 = v_u_29.profile
		local v1477 = type(v1476) ~= "table" and {} or table.clone(v_u_29.profile)
		local v1478 = v1477.derived
		v1477.derived = type(v1478) ~= "table" and {} or table.clone(v1477.derived)
		local v1479 = v1477.derived
		local v1480 = p1460[2]
		v1479.waiting = tonumber(v1480) or 2
		local v1481 = v_u_827
		pcall(v1481, v1477)
		local v1482 = v1477.derived.waiting
		return "waiting " .. tostring(v1482)
	end)
	p_u_1215.command("menu.failtest", function(p1483)
		-- upvalues: (ref) v_u_73, (ref) v_u_957, (ref) v_u_72
		local v1484 = v_u_73
		local v1485 = {
			["op"] = "test",
			["ok"] = false,
			["req"] = -1,
			["msg"] = nil
		}
		local v1486
		if p1483[1] then
			v1486 = table.concat(p1483, " ")
		else
			v1486 = nil
		end
		v1485.msg = v1486
		v_u_957(v1485)
		v_u_957(v1485)
		local v1487 = v_u_72
		local v1488 = v1485.msg or ""
		v1487["test/-1/" .. tostring(v1488)] = nil
		return ("toasts=%d (want 1 when the menu is open)"):format(v_u_73 - v1484)
	end)
	p_u_1215.command("menu.audit", function()
		-- upvalues: (ref) v_u_44
		if not v_u_44 then
			return "no gui"
		end
		local v1489 = 0
		local v1490 = {}
		for _, v1491 in v_u_44:GetDescendants() do
			if not (v1491:IsA("TextLabel") or v1491:IsA("TextButton")) then
				continue
			end
			v1489 = v1489 + 1
			local v1492 = v1491.Visible
			if v1492 then
				v1492 = v1491.AbsoluteSize.X > 0
			end
			if not v1492 or (v1491.Text == "" or (v1491.TextFits or (v1491.TextTruncate ~= Enum.TextTruncate.None or v1491.TextScaled))) then
				continue
			end
			local v1493 = v1491:GetFullName():sub(-60) .. " \'" .. v1491.Text:sub(1, 20) .. "\'"
			table.insert(v1490, v1493)
		end
		return ("%d texts, %d overflow: %s"):format(v1489, #v1490, table.concat(v1490, " | "):sub(1, 900))
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_5, (copy) v_u_11, (copy) v_u_1212
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_11
		local v_u_1494 = "DeployBanner"
		local function v1495()
			-- upvalues: (ref) v_u_5, (copy) v_u_1494
			return v_u_5.lib[v_u_1494]
		end
		local v1496, v1497 = pcall(v1495)
		if not v1496 or type(v1497) ~= "table" then
			warn("[Menu] lib missing:", "DeployBanner", v1497)
			v1497 = nil
		end
		if v1497 then
			local v1498 = v1497.mount
			local v1499 = v_u_5
			local v1500, v1501 = pcall(v1498, v1499)
			if not v1500 then
				warn("[Menu] deploy banner failed:", v1501)
				v_u_11:SetAttribute("ClientError", "deploy banner: " .. tostring(v1501))
			end
		end
	end)
	v_u_5.session.onPlaceChanged(function(p1502, p1503)
		-- upvalues: (ref) v_u_1212, (ref) v_u_11, (ref) v_u_5
		local v1504 = v_u_1212
		local v1505, v1506 = pcall(v1504, p1502, p1503)
		if not v1505 then
			warn("[Menu] place change failed:", v1506)
			v_u_11:SetAttribute("ClientError", "menu place: " .. tostring(v1506))
			if p1502 == "Menu" then
				v_u_5.emit("place.ready", "Menu")
			end
		end
	end)
end
local v_u_1507 = 0
function v_u_4.step(p1508) -- name: step
	-- upvalues: (ref) v_u_58, (ref) v_u_50, (ref) v_u_53, (ref) v_u_1507, (ref) v_u_45, (copy) v_u_104, (ref) v_u_49, (copy) v_u_47, (copy) v_u_462, (copy) v_u_48, (copy) v_u_607, (ref) v_u_52, (ref) v_u_56
	if v_u_58 then
		if v_u_50 then
			v_u_50:step(p1508)
		end
		if v_u_53 then
			local v1509 = v_u_53.step
			local v1510 = v_u_53
			pcall(v1509, v1510, p1508)
		end
		v_u_1507 = v_u_1507 + p1508
		if v_u_1507 >= 1 then
			v_u_1507 = 0
			local v1511 = v_u_45
			if v1511 then
				v1511 = v1511:FindFirstChild("Footer")
			end
			if v1511 then
				v1511 = v1511:FindFirstChild("Clock")
			end
			if v1511 then
				v1511.Text = v_u_104().clockText((os.date("!%H:%M UTC")))
				if v_u_49 and v_u_47.hideout then
					local v1512 = v_u_462
					pcall(v1512)
				end
			end
			if v_u_49 and v_u_48[v_u_49] then
				v_u_607(v_u_48[v_u_49], "tick")
			end
			if v_u_52 then
				v_u_52.tick()
			end
			if v_u_56 then
				local v1513 = v_u_56.tick
				local v1514 = v_u_56
				pcall(v1513, v1514)
			end
		end
	end
end
function v_u_4.isWished(p1515) -- name: isWished
	-- upvalues: (ref) v_u_9
	local v1516
	if v_u_9 == nil then
		v1516 = false
	else
		local v1517 = v_u_9.wished
		if type(v1517) == "function" then
			v1516 = v_u_9.wished(p1515) == true
		else
			v1516 = false
		end
	end
	return v1516
end
function v_u_4.setWish(p1518, p1519) -- name: setWish
	-- upvalues: (ref) v_u_9
	if v_u_9 then
		local v1520 = v_u_9.setWish
		if type(v1520) == "function" then
			v_u_9.setWish(p1518, p1519)
		end
	end
end
function v_u_4.refresh() -- name: refresh
	-- upvalues: (copy) v_u_29, (copy) v_u_923
	v_u_29.invalidate()
	task.spawn(function()
		-- upvalues: (ref) v_u_29, (ref) v_u_923
		local v1521 = v_u_29.fetch("profile", nil, 0)
		if v1521 then
			v_u_923(v1521, "refresh")
		end
	end)
end
return v_u_4