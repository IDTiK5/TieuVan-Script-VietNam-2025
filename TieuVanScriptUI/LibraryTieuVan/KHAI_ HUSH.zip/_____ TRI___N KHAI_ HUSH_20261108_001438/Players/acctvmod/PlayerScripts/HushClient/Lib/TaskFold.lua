-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TaskFold

local v_u_13 = {
	["LEVELS"] = { "full", "compact", "off" },
	["ATTR"] = "TaskFold",
	["SETTING_ATTR"] = "TaskTracker",
	["valid"] = function(p1) -- name: valid
		return (p1 == "full" or p1 == "compact") and true or p1 == "off"
	end,
	["setting"] = function(p2) -- name: setting
		-- upvalues: (copy) v_u_13
		return not v_u_13.valid(p2) and "full" or p2
	end,
	["effective"] = function(p3, p4, p5) -- name: effective
		-- upvalues: (copy) v_u_13
		if p5 == false then
			return "full"
		elseif v_u_13.valid(p3) then
			return p3
		else
			return v_u_13.setting(p4)
		end
	end,
	["tap"] = function(p6) -- name: tap
		-- upvalues: (copy) v_u_13
		return p6 == "full" and "compact" or (p6 == "compact" and "full" or v_u_13.setting(p6))
	end,
	["cycle"] = function(p7) -- name: cycle
		return p7 == "full" and "compact" or (p7 == "compact" and "off" or "full")
	end,
	["view"] = function(p8, p9, p10) -- name: view
		local v11 = (type(p9) ~= "number" or p9 <= 0) and 0 or math.floor(p9)
		return (v11 == 0 or p8 == "off") and {
			["kind"] = "none",
			["rows"] = 0
		} or (p8 == "compact" and (p10 == true and {
			["kind"] = "chip",
			["rows"] = 0
		} or {
			["kind"] = "rows",
			["rows"] = 1
		}) or {
			["kind"] = "rows",
			["rows"] = nil,
			["rows"] = p10 == true and 1 or v11
		})
	end,
	["chipText"] = function(p12) -- name: chipText
		return ("TASKS  \194\183  %d"):format((type(p12) ~= "number" or p12 <= 0) and 0 or math.floor(p12))
	end
}
return v_u_13