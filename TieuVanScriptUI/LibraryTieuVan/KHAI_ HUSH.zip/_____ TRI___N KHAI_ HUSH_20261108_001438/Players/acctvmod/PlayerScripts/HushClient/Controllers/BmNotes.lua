-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / BmNotes

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {
	["name"] = "BmNotes",
	["order"] = 92,
	["KEEP"] = 120,
	["MAX_HELD"] = 20,
	["QUIET"] = 8,
	["MSG_MAX"] = 200
}
local v_u_4 = {
	["listed"] = "success",
	["bought"] = "success",
	["sold"] = "success",
	["back"] = "success",
	["refund"] = "warn",
	["aborted"] = "warn",
	["paused"] = "warn",
	["closed"] = "warn",
	["working"] = "info",
	["review"] = "warn",
	["ordered"] = "success",
	["hitBid"] = "success",
	["hitBidPart"] = "success",
	["orderFilled"] = "success",
	["orderFilledMail"] = "success",
	["orderFilledFull"] = "warn",
	["orderEnded"] = "success",
	["rsSoon"] = "info",
	["rsLive"] = "success"
}
v_u_3.KINDS = v_u_4
v_u_3.EPHEMERAL = {
	["rsSoon"] = true,
	["rsLive"] = true
}
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
local v_u_7 = {}
local v_u_8 = 0
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {
	["shown"] = 0,
	["held"] = 0,
	["dropped"] = 0,
	["summaries"] = 0,
	["quiet"] = 0,
	["rejected"] = 0
}
local v_u_12 = ""
function v_u_3.clean(p13) -- name: clean
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	if type(p13) == "table" then
		local v14 = p13.k
		if type(v14) == "string" and v_u_4[p13.k] ~= nil then
			local v15 = p13.msg
			if type(v15) ~= "string" or v15 == "" then
				return nil
			end
			if #v15 > v_u_3.MSG_MAX then
				local v16 = v_u_3.MSG_MAX
				v15 = string.sub(v15, 1, v16)
			end
			local v17 = {
				["k"] = p13.k,
				["msg"] = v15
			}
			for _, v18 in { "n", "p", "net" } do
				local v19 = p13[v18]
				if type(v19) ~= "number" or (v19 ~= v19 or (v19 <= -1000000000000 or v19 >= 1000000000000)) then
					continue
				end
				v17[v18] = v19
			end
			for _, v20 in { "id", "ref" } do
				local v21 = p13[v20]
				if type(v21) ~= "string" or #v21 > 48 then
					continue
				end
				v17[v20] = v21
			end
			local v22 = p13.why
			if type(v22) == "string" and (#p13.why <= 24 and string.match(p13.why, "^[A-Z_]+$") ~= nil) then
				v17.why = p13.why
			end
			return v17
		end
	end
	return nil
end
function v_u_3.kindOf(p23, p24) -- name: kindOf
	-- upvalues: (copy) v_u_4
	return p23 == "orderEnded" and (type(p24) == "table" and p24.why ~= nil) and "warn" or (v_u_4[p23] or "info")
end
function v_u_3.holdPlace(p25) -- name: holdPlace
	return (p25 == nil or p25 == "Raid") and true or p25 == "Transit"
end
function v_u_3.fresh(p26, p27) -- name: fresh
	-- upvalues: (copy) v_u_3
	local v28 = {}
	for _, v29 in p26 do
		if p27 - v29.at > v_u_3.KEEP then
			continue
		end
		table.insert(v28, v29)
	end
	while #v28 > v_u_3.MAX_HELD do
		table.remove(v28, 1)
	end
	return v28
end
function v_u_3.summary(p30) -- name: summary
	if #p30 == 0 then
		return nil
	elseif #p30 == 1 then
		return p30[1].msg
	else
		local v31 = {}
		for _, v32 in p30 do
			v31[v32.k] = (v31[v32.k] or 0) + 1
		end
		local v33 = {}
		if v31.sold then
			local v34 = v31.sold
			table.insert(v33, ("%d %s"):format(v34, "sold"))
		end
		local v35 = (v31.hitBid or 0) + (v31.hitBidPart or 0)
		if v35 <= 0 then
			v35 = nil
		end
		v31.hitBid = v35
		v31.hitBidPart = nil
		local v36 = (v31.orderFilled or 0) + (v31.orderFilledMail or 0) + (v31.orderFilledFull or 0)
		if v36 <= 0 then
			v36 = nil
		end
		v31.orderFilled = v36
		v31.orderFilledMail = nil
		v31.orderFilledFull = nil
		if v31.hitBid then
			local v37 = v31.hitBid
			table.insert(v33, ("%d %s"):format(v37, "sold to orders"))
		end
		if v31.orderFilled then
			local v38 = v31.orderFilled
			table.insert(v33, ("%d %s"):format(v38, "orders filled"))
		end
		if v31.ordered then
			local v39 = v31.ordered
			table.insert(v33, ("%d %s"):format(v39, "orders placed"))
		end
		if v31.orderEnded then
			local v40 = v31.orderEnded
			table.insert(v33, ("%d %s"):format(v40, "orders ended"))
		end
		if v31.bought then
			local v41 = v31.bought
			table.insert(v33, ("%d %s"):format(v41, "bought"))
		end
		if v31.back then
			local v42 = v31.back
			table.insert(v33, ("%d %s"):format(v42, "returned"))
		end
		if v31.refund then
			local v43 = v31.refund
			table.insert(v33, ("%d %s"):format(v43, "refunded"))
		end
		if v31.aborted then
			local v44 = v31.aborted
			table.insert(v33, ("%d %s"):format(v44, "not listed"))
		end
		if v31.review then
			local v45 = v31.review
			table.insert(v33, ("%d %s"):format(v45, "need a check"))
		end
		if v31.listed then
			local v46 = v31.listed
			table.insert(v33, ("%d %s"):format(v46, "listed"))
		end
		if #v33 == 0 then
			return ("While you were away: %d updates."):format(#p30)
		else
			return "While you were away: " .. table.concat(v33, ", ") .. "."
		end
	end
end
local function v_u_51(p47) -- name: quietHit
	-- upvalues: (ref) v_u_10, (copy) v_u_3
	local v48 = os.clock()
	for v49 = #v_u_10, 1, -1 do
		local v50 = v_u_10[v49]
		if v48 - v50.at <= v_u_3.QUIET then
			if v50.k ~= p47.k or v50.id ~= nil and v50.id ~= p47.id then
				continue
			end
			table.remove(v_u_10, v49)
			return true
		end
		table.remove(v_u_10, v49)
	end
	return false
end
function v_u_3.quiet(p52, p53) -- name: quiet
	-- upvalues: (ref) v_u_10
	local v54 = v_u_10
	local v55 = {
		["k"] = p52,
		["id"] = p53,
		["at"] = os.clock()
	}
	table.insert(v54, v55)
	while #v_u_10 > 8 do
		table.remove(v_u_10, 1)
	end
end
function v_u_3.subscribe(p56) -- name: subscribe
	-- upvalues: (ref) v_u_8, (ref) v_u_7
	v_u_8 = v_u_8 + 1
	local v_u_57 = v_u_8
	v_u_7[v_u_57] = p56
	return function()
		-- upvalues: (ref) v_u_7, (copy) v_u_57
		v_u_7[v_u_57] = nil
	end
end
local function v_u_72(p58) -- name: handle
	-- upvalues: (copy) v_u_3, (copy) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (copy) v_u_51, (ref) v_u_12, (ref) v_u_6
	local v59 = v_u_3.clean(p58)
	if v59 then
		for _, v60 in v_u_7 do
			pcall(v60, v59)
		end
		if v_u_3.holdPlace(v_u_5:GetAttribute("Place")) then
			if v_u_3.EPHEMERAL[v59.k] == true then
				local v61 = v_u_11
				v61.dropped = v61.dropped + 1
			else
				local v62 = v_u_11
				v62.held = v62.held + 1
				local v63 = v_u_9
				local v64 = {
					["note"] = v59,
					["at"] = os.clock()
				}
				table.insert(v63, v64)
				v_u_9 = v_u_3.fresh(v_u_9, os.clock())
			end
		elseif v_u_51(v59) then
			local v65 = v_u_11
			v65.quiet = v65.quiet + 1
		else
			local v66 = v_u_11
			v66.shown = v66.shown + 1
			v_u_12 = v59.msg
			local v67 = v_u_6.lib.HushUI.toast
			local v68 = v59.msg
			local v69 = v_u_3.kindOf
			local v70 = v59.k
			pcall(v67, v68, v69(v70, v59))
		end
	else
		local v71 = v_u_11
		v71.rejected = v71.rejected + 1
		return
	end
end
function v_u_3.inject(p73) -- name: inject
	-- upvalues: (copy) v_u_72
	v_u_72(p73)
end
local function v_u_88() -- name: flush
	-- upvalues: (copy) v_u_3, (ref) v_u_5, (ref) v_u_9, (copy) v_u_11, (ref) v_u_12, (ref) v_u_6
	if not v_u_3.holdPlace(v_u_5:GetAttribute("Place")) and #v_u_9 ~= 0 then
		local v74 = v_u_3.fresh(v_u_9, os.clock())
		local v75 = #v_u_9 - #v74
		local v76 = v_u_11
		v76.dropped = v76.dropped + v75
		v_u_9 = {}
		local v77 = {}
		for _, v78 in v74 do
			local v79 = v78.note
			table.insert(v77, v79)
		end
		local v80 = v_u_3.summary(v77)
		if v80 then
			local v81 = v_u_11
			v81.summaries = v81.summaries + 1
			local v82
			if #v77 == 1 then
				v82 = v77[1]
			else
				v82 = {
					["k"] = "sold",
					["msg"] = nil,
					["msg"] = v80
				}
			end
			local v83 = v_u_11
			v83.shown = v83.shown + 1
			v_u_12 = v82.msg
			local v84 = v_u_6.lib.HushUI.toast
			local v85 = v82.msg
			local v86 = v_u_3.kindOf
			local v87 = v82.k
			pcall(v84, v85, v86(v87, v82))
		end
	end
end
function v_u_3.heldCount() -- name: heldCount
	-- upvalues: (ref) v_u_9
	return #v_u_9
end
v_u_3._test = {
	["setPlayer"] = function(p89) -- name: setPlayer
		-- upvalues: (ref) v_u_5
		v_u_5 = p89
	end,
	["setContext"] = function(p90) -- name: setContext
		-- upvalues: (ref) v_u_6
		v_u_6 = p90
	end,
	["flush"] = function() -- name: flush
		-- upvalues: (copy) v_u_88
		v_u_88()
	end,
	["age"] = function(p91) -- name: age
		-- upvalues: (ref) v_u_9
		for _, v92 in v_u_9 do
			v92.at = v92.at - p91
		end
	end,
	["reset"] = function() -- name: reset
		-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (copy) v_u_11, (ref) v_u_12
		v_u_9 = {}
		v_u_10 = {}
		v_u_7 = {}
		for v93 in v_u_11 do
			v_u_11[v93] = 0
		end
		v_u_12 = ""
	end,
	["held"] = function() -- name: held
		-- upvalues: (ref) v_u_9
		return v_u_9
	end
}
function v_u_3.counters() -- name: counters
	-- upvalues: (copy) v_u_11
	return table.clone(v_u_11)
end
function v_u_3.init(p_u_94) -- name: init
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (copy) v_u_72, (ref) v_u_5, (ref) v_u_9, (copy) v_u_11, (ref) v_u_12
	v_u_6 = p_u_94
	p_u_94.lib.HushUI.bind(p_u_94)
	p_u_94.command("bm.note", function(p95)
		-- upvalues: (ref) v_u_4, (ref) v_u_72, (ref) v_u_5, (ref) v_u_9
		local v96 = p95[1] or "sold"
		if v_u_4[v96] == nil then
			return "unknown kind; kinds: listed bought sold back refund aborted paused closed working review ordered hitBid hitBidPart orderFilled orderFilledMail orderFilledFull orderEnded rsSoon rsLive"
		end
		local v97 = p95[2]
		local v98 = p95[3]
		local v99 = tonumber(v98) or 1
		local v100 = p95[4]
		local v101 = tonumber(v100) or 1200
		local v102 = v97 or "item"
		local v103 = {
			["listed"] = nil,
			["bought"] = nil,
			["sold"] = nil,
			["back"] = nil,
			["refund"] = nil,
			["aborted"] = nil,
			["paused"] = "The Blackmarket is paused. Your items and Cash are safe.",
			["closed"] = "The Blackmarket is closed right now.",
			["working"] = "Working on it. Your Cash is held safely.",
			["review"] = "A transaction needs a check. Your items and Cash are safe.",
			["ordered"] = nil,
			["hitBid"] = nil,
			["hitBidPart"] = nil,
			["orderFilled"] = nil,
			["orderFilledMail"] = nil,
			["orderFilledFull"] = nil,
			["orderEnded"] = nil,
			["rsSoon"] = "MARKET RESTOCK starts in 1 minute.",
			["rsLive"] = "MARKET RESTOCK is live in the MARKET.",
			["listed"] = ("Listed: %d x %s for $%d."):format(v99, v102, v101),
			["bought"] = ("Bought: %d x %s for $%d. It is in your stash."):format(v99, v102, v101),
			["sold"] = ("Sold: %d x %s. $%d added to your Cash."):format(v99, v102, v101),
			["back"] = ("Your listing ended. %s is back in your stash."):format(v102),
			["refund"] = ("The listing was gone. $%d is back in your Cash."):format(v101),
			["aborted"] = ("The listing could not be made. %s is back in your stash."):format(v102),
			["ordered"] = ("Order placed: %d x %s at $%d each. $%d is set aside."):format(v99, v102, v101, v101 * v99)
		}
		local v104 = v101 * v99 * 0.95
		v103.hitBid = ("Sold: %d x %s at $%d each. $%d added to your Cash."):format(v99, v102, v101, (math.floor(v104)))
		local v105 = v99 - 1
		local v106 = math.max(1, v105)
		local v107 = v99 - 1
		local v108 = v101 * math.max(1, v107) * 0.95
		v103.hitBidPart = ("Sold %d of %d x %s at $%d each. $%d added to your Cash."):format(v106, v99, v102, v101, (math.floor(v108)))
		v103.orderFilled = ("Your order was filled: %d x %s at $%d each. It is waiting in your mail."):format(v99, v102, v101)
		v103.orderFilledMail = ("Your order was filled: %d x %s at $%d each. It is waiting in your mail."):format(v99, v102, v101)
		v103.orderFilledFull = ("Your order was filled: %d x %s. Your mail is full, so it waits in the order until you collect some deliveries."):format(v99, v102)
		v103.orderEnded = ("Your order for %s ended. $%d is back in your Cash."):format(v102, v101)
		local v109 = v_u_72
		local v110 = {
			["k"] = v96,
			["id"] = v97,
			["n"] = v99,
			["p"] = v101
		}
		local v111 = v101 * 0.95
		v110.net = math.floor(v111)
		v110.msg = v103[v96]
		v109(v110)
		local v112 = v_u_5
		return ("note %s place=%s held=%d"):format(v96, tostring(v112:GetAttribute("Place")), #v_u_9)
	end)
	p_u_94.command("bm.notes", function()
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12
		local v113 = v_u_5
		return ("place=%s held=%d shown=%d dropped=%d summaries=%d quiet=%d rejected=%d last=%q"):format(tostring(v113:GetAttribute("Place")), #v_u_9, v_u_11.shown, v_u_11.dropped, v_u_11.summaries, v_u_11.quiet, v_u_11.rejected, v_u_12)
	end)
	for _, v_u_114 in {
		"fake",
		"scenario",
		"advance",
		"sub",
		"item",
		"sell",
		"state",
		"page",
		"audit"
	} do
		p_u_94.command("market." .. v_u_114, function(p115)
			-- upvalues: (copy) p_u_94, (copy) v_u_114
			local function v116()
				-- upvalues: (ref) p_u_94
				return p_u_94.lib.MenuMarket
			end
			local v117, v118 = pcall(v116)
			return (not v117 or type(v118) ~= "table") and "MenuMarket is not synced" or v118.command(p_u_94, v_u_114, p115)
		end)
	end
end
function v_u_3.start() -- name: start
	-- upvalues: (copy) v_u_72, (copy) v_u_2, (ref) v_u_5, (copy) v_u_88, (ref) v_u_9, (copy) v_u_3
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_72
		local v119 = v_u_2:WaitForChild("HushNet", 60)
		if v119 then
			local v120 = v119:FindFirstChild("bm.note")
			if v120 and v120:IsA("RemoteEvent") then
				v120.OnClientEvent:Connect(v_u_72)
			end
			v119.ChildAdded:Connect(function(p121)
				-- upvalues: (ref) v_u_72
				if p121.Name == "bm.note" and p121:IsA("RemoteEvent") then
					p121.OnClientEvent:Connect(v_u_72)
				end
			end)
		end
	end)
	v_u_5:GetAttributeChangedSignal("Place"):Connect(function()
		-- upvalues: (ref) v_u_88
		task.delay(1.2, v_u_88)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_88, (ref) v_u_9, (ref) v_u_3
		while true do
			repeat
				task.wait(5)
				v_u_88()
			until #v_u_9 > 0
			v_u_9 = v_u_3.fresh(v_u_9, os.clock())
		end
	end)
end
return v_u_3