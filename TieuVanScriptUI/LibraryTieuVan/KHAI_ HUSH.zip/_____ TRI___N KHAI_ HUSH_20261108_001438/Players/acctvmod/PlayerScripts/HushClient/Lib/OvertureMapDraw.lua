-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / OvertureMapDraw

local v_u_1 = game:GetService("TextService")
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v3, v_u_4 = pcall(function()
	return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapTagPlace", 5)))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v_u_5 = {}
local v6, v_u_7 = pcall(function()
	return require((script.Parent:WaitForChild("OvertureMapData", 5)))
end)
if not v6 or type(v_u_7) ~= "table" then
	v_u_7 = nil
end
local v8, v9 = pcall(function()
	return require((script.Parent:WaitForChild("MapDraw", 5)))
end)
local v10 = nil
if v8 and type(v9) == "table" then
	local v11 = v9.INK
	if type(v11) == "table" then
		v10 = v9.INK
	end
end
local v_u_12 = {
	["paper"] = Color3.fromHex("D8CDB2"),
	["paperLight"] = Color3.fromHex("E6DCC4"),
	["paperEdge"] = Color3.fromHex("A99C7E"),
	["crease"] = Color3.fromHex("BDB091"),
	["grid"] = Color3.fromHex("C3B697"),
	["ink"] = Color3.fromHex("372F26"),
	["inkSoft"] = Color3.fromHex("6A5E4C"),
	["field"] = Color3.fromHex("CFC598"),
	["park"] = Color3.fromHex("B9BE92"),
	["forest"] = Color3.fromHex("B4B98F"),
	["tree"] = Color3.fromHex("7C8758"),
	["water"] = Color3.fromHex("8DA4AE"),
	["waterInk"] = Color3.fromHex("44606E"),
	["bank"] = Color3.fromHex("BDC0A6"),
	["lot"] = Color3.fromHex("C6BCA5"),
	["road"] = Color3.fromHex("F0E8D4"),
	["roadCase"] = Color3.fromHex("5D5345"),
	["highway"] = Color3.fromHex("F2DFA9"),
	["build"] = Color3.fromHex("8C806D"),
	["buildEdge"] = Color3.fromHex("4A4136"),
	["landmark"] = Color3.fromHex("9C4B39"),
	["landmarkEdge"] = Color3.fromHex("5E2A1F"),
	["red"] = Color3.fromHex("B0322A"),
	["redDeep"] = Color3.fromHex("7E2019"),
	["green"] = Color3.fromHex("3E6E4A")
}
if v10 then
	for v13, v14 in v10 do
		v_u_12[v13] = v14
	end
end
v_u_12.granite = Color3.fromHex("CBC1AB")
v_u_12.graniteJoint = Color3.fromHex("B5AA92")
v_u_12.sand = Color3.fromHex("DDD0A8")
v_u_12.sandWet = Color3.fromHex("C9C3A4")
v_u_12.deck = Color3.fromHex("B79F78")
v_u_12.wall = Color3.fromHex("5D5345")
v_u_12.rail = Color3.fromHex("4A4136")
v_u_5.INK = v_u_12
v_u_5.KEY = {
	{ "landmark", "Landmark" },
	{ "build", "Building" },
	{ "forest", "Woods" },
	{ "water", "Water" },
	{ "road", "Road" }
}
function v_u_5.available() -- name: available
	-- upvalues: (ref) v_u_7
	local v15
	if v_u_7 == nil then
		v15 = false
	else
		local v16 = v_u_7.LOTS
		if type(v16) == "table" and #v_u_7.LOTS > 0 then
			local v17 = v_u_7.HALF
			v15 = type(v17) == "number"
		else
			v15 = false
		end
	end
	return v15
end
function v_u_5.data() -- name: data
	-- upvalues: (ref) v_u_7
	return v_u_7
end
function v_u_5.placeOf(p18) -- name: placeOf
	-- upvalues: (ref) v_u_7
	if v_u_7 then
		local v19 = v_u_7.PLACES
		if type(v19) == "table" and type(p18) == "string" then
			local v20 = v_u_7.PLACES[string.lower(p18)]
			if type(v20) == "table" then
				return v20[1], v20[2], v20[3]
			else
				return nil, nil, nil
			end
		end
	end
	return nil, nil, nil
end
local function v_u_33(p21, p22, p23, p24, p25, p26, p27) -- name: text
	-- upvalues: (ref) v_u_12
	local v28 = Instance.new("TextLabel")
	v28.Name = "Txt"
	v28.BackgroundTransparency = 1
	v28.AnchorPoint = Vector2.new(0.5, 0.5)
	v28.Position = UDim2.fromOffset(p23.X, p23.Y)
	local v29 = UDim2.fromOffset
	local v30 = (utf8.len(p22) or #p22) * p24 * 0.62 + 8
	v28.Size = v29(math.max(20, v30), p24 + 4)
	v28.FontFace = p25
	v28.TextSize = p24
	v28.TextColor3 = p26
	v28.TextStrokeColor3 = v_u_12.paper
	v28.TextStrokeTransparency = 0.25
	v28.Text = p22
	v28.TextTruncate = Enum.TextTruncate.AtEnd
	if p27 then
		for v31, v32 in p27 do
			v28[v31] = v32
		end
	end
	v28.Parent = p21
	return v28
end
local function v_u_39(p34) -- name: spaced
	local v35 = utf8.char(8202)
	local v36 = {}
	for _, v37 in utf8.codes(string.upper(p34)) do
		local v38 = utf8.char
		table.insert(v36, v38(v37))
	end
	return table.concat(v36, v35)
end
local v_u_40 = {
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G"
}
function v_u_5.gridRef(p41, p42) -- name: gridRef
	-- upvalues: (ref) v_u_7, (copy) v_u_40
	local v43 = not v_u_7 and 560 or v_u_7.HALF
	local v44 = v43 * 2 / 160 + 0.5
	local v45 = math.floor(v44)
	local v46 = (p41 + v43) / 160
	local v47 = math.floor(v46) + 1
	local v48 = math.clamp(v47, 1, v45)
	local v49 = (p42 + v43) / 160
	local v50 = math.floor(v49) + 1
	local v51 = math.clamp(v50, 1, v45)
	return (v_u_40[v48] or "?") .. tostring(v51)
end
function v_u_5.build(p52, p53, p54, p55, p_u_56) -- name: build
	-- upvalues: (ref) v_u_7, (copy) v_u_33, (copy) v_u_2, (ref) v_u_12, (copy) v_u_39, (copy) v_u_1, (ref) v_u_4, (copy) v_u_40, (copy) v_u_5
	local v57 = v_u_7
	assert(v57, "OvertureMapData missing")
	local v_u_58 = v_u_33
	local v59
	if p_u_56 then
		v59 = p_u_56.phone
	else
		v59 = v_u_2.isPhone()
	end
	local v_u_60 = v_u_7.HALF
	local v61 = v_u_7.RING
	local v62 = v_u_7.SHORE
	local v63 = p53 * 0.035
	local v64 = math.floor(v63)
	local v_u_65 = p53 - v64 * 2
	local v_u_66 = v_u_65 / (v_u_60 * 2)
	local v67 = p53 / 880
	local v68 = p55 and p55.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
	local v69 = p55 and p55.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v70 = p55 and p55.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v71 = p55 and p55.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v72 = {
		["Name"] = "Sheet",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_12.paper,
		["Size"] = UDim2.fromOffset(p53, p53)
	}
	local v73 = Instance.new("Frame")
	v73.BorderSizePixel = 0
	local v_u_74 = 0
	local v_u_75 = 0
	for v76, v77 in v72 do
		v73[v76] = v77
	end
	v73.Parent = p52
	local v78 = v_u_12.paperEdge
	local v79 = Instance.new("UIStroke")
	v79.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v79.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v79.Color = v78
	v79.Thickness = 2
	v79.Transparency = 0
	v79.Parent = v73
	local v80 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v_u_12.paperLight,
		["Position"] = UDim2.fromOffset(v64, v64),
		["Size"] = UDim2.fromOffset(v_u_65, v_u_65)
	}
	local v81 = Instance.new("Frame")
	v81.BorderSizePixel = 0
	for v82, v83 in v80 do
		v81[v82] = v83
	end
	v81.Parent = v73
	local v84 = v_u_12.ink
	local v85 = Instance.new("UIStroke")
	v85.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v85.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v85.Color = v84
	v85.Thickness = 1
	v85.Transparency = 0
	v85.Parent = v81
	local function v_u_100(p86, p87, p88, p89, p90, p91) -- name: seg
		-- upvalues: (ref) v_u_74
		local v92 = p88 - p87
		v_u_74 = v_u_74 + 1
		local v93 = {
			["Name"] = "Seg",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = p90,
			["BackgroundTransparency"] = p91 or 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset((p87.X + p88.X) / 2, (p87.Y + p88.Y) / 2),
			["Size"] = UDim2.fromOffset(v92.Magnitude + p89 * 0.5, p89)
		}
		local v94 = v92.Y
		local v95 = v92.X
		local v96 = math.atan2(v94, v95)
		v93.Rotation = math.deg(v96)
		local v97 = Instance.new("Frame")
		v97.BorderSizePixel = 0
		for v98, v99 in v93 do
			v97[v98] = v99
		end
		v97.Parent = p86
		return v97
	end
	local v101 = {
		["Name"] = "Ground",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v102 = Instance.new("Frame")
	v102.BorderSizePixel = 0
	local function v130(p103, p104, p105, p106, p107, p108, p109) -- name: rect
		-- upvalues: (copy) v_u_60, (copy) v_u_66, (ref) v_u_74
		local v110 = math.min(p104, p106)
		local v111 = math.min(p105, p107)
		local v112 = Vector2.new((v110 + v_u_60) * v_u_66, (v111 + v_u_60) * v_u_66)
		local v113 = math.max(p104, p106)
		local v114 = math.max(p105, p107)
		local v115 = Vector2.new((v113 + v_u_60) * v_u_66, (v114 + v_u_60) * v_u_66)
		v_u_74 = v_u_74 + 1
		local v116 = {
			["BackgroundColor3"] = p108,
			["BackgroundTransparency"] = p109 or 0
		}
		local v117 = UDim2.fromOffset
		local v118 = v112.X
		local v119 = math.floor(v118)
		local v120 = v112.Y
		v116.Position = v117(v119, (math.floor(v120)))
		local v121 = UDim2.fromOffset
		local v122 = v115.X - v112.X
		local v123 = math.ceil(v122)
		local v124 = math.max(1, v123)
		local v125 = v115.Y - v112.Y
		local v126 = math.ceil(v125)
		v116.Size = v121(v124, (math.max(1, v126)))
		local v127 = Instance.new("Frame")
		v127.BorderSizePixel = 0
		for v128, v129 in v116 do
			v127[v128] = v129
		end
		v127.Parent = p103
		return v127
	end
	local function v153(p131, p132, p133, p134, p135, p136, p137, p138) -- name: box
		-- upvalues: (copy) v_u_60, (copy) v_u_66, (ref) v_u_74
		local v139 = Vector2.new((p132 + v_u_60) * v_u_66, (p133 + v_u_60) * v_u_66)
		local v140 = p136 % 180
		local v141 = -p136
		local v142 = v140 - 90
		if math.abs(v142) < 1 then
			local v143 = p135
			p135 = p134
			p134 = v143
			v141 = 0
		elseif v140 < 1 or v140 > 179 then
			v141 = 0
		end
		local v144 = p138 or 2
		v_u_74 = v_u_74 + 1
		local v145 = {
			["BackgroundColor3"] = p137,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v139.X, v139.Y)
		}
		local v146 = UDim2.fromOffset
		local v147 = p134 * v_u_66
		local v148 = math.max(v144, v147)
		local v149 = p135 * v_u_66
		v145.Size = v146(v148, (math.max(v144, v149)))
		v145.Rotation = v141
		local v150 = Instance.new("Frame")
		v150.BorderSizePixel = 0
		for v151, v152 in v145 do
			v150[v151] = v152
		end
		v150.Parent = p131
		return v150
	end
	local function v168(p154, p155, p156, p157, p158, p159, p160, p161) -- name: dashed
		-- upvalues: (copy) v_u_100
		local v162 = p156 - p155
		local v163 = v162.Magnitude
		if v163 >= 1 then
			local v164 = v162 / v163
			local v165 = 0
			while v165 < v163 do
				local v166 = v165 + p157
				local v167 = math.min(v163, v166)
				if v167 - v165 > 1 then
					v_u_100(p154, p155 + v164 * v165, p155 + v164 * v167, p159, p160, p161)
				end
				v165 = v167 + p158
			end
		end
	end
	local function v171(p169, p170) -- name: toPx
		-- upvalues: (copy) v_u_60, (copy) v_u_66
		return Vector2.new((p169 + v_u_60) * v_u_66, (p170 + v_u_60) * v_u_66)
	end
	for v172, v173 in v101 do
		v102[v172] = v173
	end
	v102.Parent = v81
	local v174 = v_u_7.FIELD
	v130(v102, v174[1], v174[2], v174[3], v174[4], v_u_12.field, 0.55).Name = "Field"
	for _, v175 in v_u_7.WOODS do
		v130(v102, v175[1], v175[2], v175[3], v175[4], v_u_12.forest, 0.1).Name = "Forest"
	end
	local v176 = v_u_7.BEACH
	v130(v102, v176[1], v176[2], v176[3], v176[4], v_u_12.sand, 0.05).Name = "Beach"
	local v177 = v_u_7.WATER
	v130(v102, v177[1], v177[2], v177[3], v177[4], v_u_12.water, 0).Name = "Lake"
	v130(v102, v177[1], v177[2], v177[3], v177[2] + 1.2 / v_u_66, v_u_12.waterInk, 0.35).Name = "ShoreLine"
	local v178 = v177[2] + 12
	local v179 = 0
	while v178 < v177[4] - 4 do
		local v180 = v179 % 2 == 0 and 0 or 36
		local v181 = v177[1] + 14 + v180
		while v181 < v177[3] - 30 do
			local v182 = Vector2.new((v181 + v_u_60) * v_u_66, (v178 + v_u_60) * v_u_66)
			local v183 = v181 + 18
			local v184 = Vector2.new((v183 + v_u_60) * v_u_66, (v178 + v_u_60) * v_u_66)
			local v185 = v67 * 1.2 + 0.5
			local v186 = math.floor(v185)
			v_u_100(v102, v182, v184, math.max(1, v186), v_u_12.waterInk, 0.55)
			v181 = v181 + 72
		end
		v178 = v178 + 16
		v179 = v179 + 1
	end
	local v187 = v_u_60 * 2 / 160 + 0.5
	local v188 = math.floor(v187)
	for v189 = 1, v188 - 1 do
		local v190 = v189 / v188
		v458 = v_u_74 + 2
		local v191 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.grid,
			["Position"] = UDim2.new(v190, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v192 = Instance.new("Frame")
		v192.BorderSizePixel = 0
		v_u_74 = v458
		for v193, v194 in v191 do
			v192[v193] = v194
		end
		v192.Parent = v102
		local v195 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.grid,
			["Position"] = UDim2.new(0, 0, v190, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v196 = Instance.new("Frame")
		v196.BorderSizePixel = 0
		for v197, v198 in v195 do
			v196[v197] = v198
		end
		v196.Parent = v102
	end
	for _, v199 in v_u_7.TREES do
		local v200 = v199[1]
		local v201 = v199[2]
		local v202 = Vector2.new((v200 + v_u_60) * v_u_66, (v201 + v_u_60) * v_u_66)
		local v203 = v199[3] * v_u_66
		local v204 = math.max(3, v203)
		v458 = v_u_74 + 1
		local v205 = {
			["Name"] = "T",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.18,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.tree,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v202.X, v202.Y),
			["Size"] = UDim2.fromOffset(v204, v204)
		}
		local v206 = Instance.new("Frame")
		v206.BorderSizePixel = 0
		v_u_74 = v458
		for v207, v208 in v205 do
			v206[v207] = v208
		end
		v206.Parent = v102
		local v209 = UDim.new(0.5, 0)
		local v210 = Instance.new("UICorner")
		v210.CornerRadius = v209
		v210.Parent = v206
	end
	local v211 = {
		["Name"] = "Pads",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v212 = Instance.new("Frame")
	v212.BorderSizePixel = 0
	for v213, v214 in v211 do
		v212[v213] = v214
	end
	v212.Parent = v81
	local v215 = v_u_7.PLAZA
	local v216 = v130(v212, v215[1], v215[2], v215[3], v215[4], v_u_12.granite, 0)
	v216.Name = "Plaza"
	local v217 = v_u_12.inkSoft
	local v218 = Instance.new("UIStroke")
	v218.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v218.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v218.Color = v217
	v218.Thickness = 1
	v218.Transparency = 0.45
	v218.Parent = v216
	local v219 = v215[1] + 32
	while v219 < v215[3] do
		v130(v212, v219, v215[2], v219 + 0.5 / v_u_66, v215[4], v_u_12.graniteJoint, 0.5).Name = "Joint"
		v219 = v219 + 32
	end
	local v220 = v215[2] + 32
	while v220 < v215[4] do
		v130(v212, v215[1], v220, v215[3], v220 + 0.5 / v_u_66, v_u_12.graniteJoint, 0.5).Name = "Joint"
		v220 = v220 + 32
	end
	for _, v221 in v_u_7.PIERS do
		local v222 = v130(v212, v221[3], v221[4], v221[5], v221[6], v_u_12.deck, 0)
		v222.Name = "Pier_" .. v221[1]
		local v223 = v_u_12.buildEdge
		local v224 = Instance.new("UIStroke")
		v224.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v224.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v224.Color = v223
		v224.Thickness = 1
		v224.Transparency = 0.3
		v224.Parent = v222
	end
	local v225 = {
		["Name"] = "RoadCase",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v226 = Instance.new("Frame")
	v226.BorderSizePixel = 0
	for v227, v228 in v225 do
		v226[v227] = v228
	end
	v226.Parent = v81
	local v229 = {
		["Name"] = "RoadFill",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v230 = Instance.new("Frame")
	v230.BorderSizePixel = 0
	for v231, v232 in v229 do
		v230[v231] = v232
	end
	v230.Parent = v81
	local v233 = v67 * 1.6 + 0.5
	local v234 = math.floor(v233)
	local v235 = math.max(1, v234)
	for _, v236 in v_u_7.ROADS do
		local v237 = v236[1]
		local v238 = v236[2]
		local v239 = Vector2.new((v237 + v_u_60) * v_u_66, (v238 + v_u_60) * v_u_66)
		local v240 = v236[3]
		local v241 = v236[4]
		local v242 = Vector2.new((v240 + v_u_60) * v_u_66, (v241 + v_u_60) * v_u_66)
		v458 = v_u_74 + 2
		local v243 = {
			["Name"] = "Case",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.roadCase
		}
		local v244 = UDim2.fromOffset
		local v245 = v239.X
		local v246 = math.floor(v245) - v235
		local v247 = v239.Y
		v243.Position = v244(v246, math.floor(v247) - v235)
		local v248 = UDim2.fromOffset
		local v249 = v242.X - v239.X
		local v250 = math.ceil(v249) + v235 * 2
		local v251 = v242.Y - v239.Y
		v243.Size = v248(v250, math.ceil(v251) + v235 * 2)
		local v252 = Instance.new("Frame")
		v252.BorderSizePixel = 0
		v_u_74 = v458
		for v253, v254 in v243 do
			v252[v253] = v254
		end
		v252.Parent = v226
		v252:SetAttribute("Road", v236[5])
		if v236[6] == "service" then
			v252.BackgroundTransparency = 0.35
		end
		local v255 = {
			["Name"] = "Road",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil
		}
		local v256
		if v236[6] == "main" then
			v256 = v_u_12.highway
		else
			v256 = v_u_12.road
		end
		v255.BackgroundColor3 = v256
		local v257 = UDim2.fromOffset
		local v258 = v239.X
		local v259 = math.floor(v258)
		local v260 = v239.Y
		v255.Position = v257(v259, (math.floor(v260)))
		local v261 = UDim2.fromOffset
		local v262 = v242.X - v239.X
		local v263 = math.ceil(v262)
		local v264 = math.max(1, v263)
		local v265 = v242.Y - v239.Y
		local v266 = math.ceil(v265)
		v255.Size = v261(v264, (math.max(1, v266)))
		local v267 = Instance.new("Frame")
		v267.BorderSizePixel = 0
		for v268, v269 in v255 do
			v267[v268] = v269
		end
		v267.Parent = v230
		v267:SetAttribute("Road", v236[5])
	end
	local v270 = {
		["Name"] = "Rails",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v271 = Instance.new("Frame")
	v271.BorderSizePixel = 0
	for v272, v273 in v270 do
		v271[v272] = v273
	end
	v271.Parent = v81
	for _, v274 in v_u_7.RAIL do
		local v275 = v274[6] == "z"
		local v276 = (v274[1] + v274[3]) / 2
		local v277 = (v274[2] + v274[4]) / 2
		local v278
		if v275 then
			v278 = v274[4] - v274[2]
		else
			v278 = v274[3] - v274[1]
		end
		local v279 = v67 * 1.3 + 0.5
		local v280 = math.floor(v279)
		local v281 = math.max(1, v280)
		if v275 then
			local v282 = v276 - 2.2
			local v283 = v274[2]
			local v284 = Vector2.new((v282 + v_u_60) * v_u_66, (v283 + v_u_60) * v_u_66)
			local v285 = v276 - 2.2
			local v286 = v274[4]
			v_u_100(v271, v284, Vector2.new((v285 + v_u_60) * v_u_66, (v286 + v_u_60) * v_u_66), v281, v_u_12.rail, 0.05)
			local v287 = v276 + 2.2
			local v288 = v274[2]
			local v289 = Vector2.new((v287 + v_u_60) * v_u_66, (v288 + v_u_60) * v_u_66)
			local v290 = v276 + 2.2
			local v291 = v274[4]
			v_u_100(v271, v289, Vector2.new((v290 + v_u_60) * v_u_66, (v291 + v_u_60) * v_u_66), v281, v_u_12.rail, 0.05)
		else
			local v292 = v274[1]
			local v293 = v277 - 2.2
			local v294 = Vector2.new((v292 + v_u_60) * v_u_66, (v293 + v_u_60) * v_u_66)
			local v295 = v274[3]
			local v296 = v277 - 2.2
			v_u_100(v271, v294, Vector2.new((v295 + v_u_60) * v_u_66, (v296 + v_u_60) * v_u_66), v281, v_u_12.rail, 0.05)
			local v297 = v274[1]
			local v298 = v277 + 2.2
			local v299 = Vector2.new((v297 + v_u_60) * v_u_66, (v298 + v_u_60) * v_u_66)
			local v300 = v274[3]
			local v301 = v277 + 2.2
			v_u_100(v271, v299, Vector2.new((v300 + v_u_60) * v_u_66, (v301 + v_u_60) * v_u_66), v281, v_u_12.rail, 0.05)
		end
		local v302 = v278 / 14
		for v303 = 0, math.floor(v302) do
			local v304
			if v275 then
				v304 = v274[2]
			else
				v304 = v274[1]
			end
			local v305 = v304 + v303 * 14 + 4
			if v275 then
				v130(v271, v276 - 3.4, v305, v276 + 3.4, v305 + 1 / v_u_66, v_u_12.rail, 0.35)
			else
				v130(v271, v305, v277 - 3.4, v305 + 1 / v_u_66, v277 + 3.4, v_u_12.rail, 0.35)
			end
		end
	end
	local v306 = {
		["Name"] = "Buildings",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v307 = Instance.new("Frame")
	v307.BorderSizePixel = 0
	for v308, v309 in v306 do
		v307[v308] = v309
	end
	v307.Parent = v81
	local v310 = {
		["Name"] = "Props",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v311 = Instance.new("Frame")
	v311.BorderSizePixel = 0
	for v312, v313 in v310 do
		v311[v312] = v313
	end
	v311.Parent = v81
	local v314 = {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_315 = Instance.new("Frame")
	v_u_315.BorderSizePixel = 0
	for v316, v317 in v314 do
		v_u_315[v316] = v317
	end
	v_u_315.Parent = v81
	local v_u_318 = {}
	local v_u_319 = {}
	local v_u_320 = {}
	local v_u_321 = false
	local v_u_322 = {}
	local function v_u_329(p323, p324, p325, p326, p327) -- name: overlaps
		for _, v328 in p327 do
			if p323 >= v328[3] or (v328[1] >= p325 or (p324 >= v328[4] or v328[2] >= p326)) then
				continue
			end
			return true
		end
		return false
	end
	local function v_u_335(p330, p331, p332, p333, p334) -- name: free
		-- upvalues: (copy) v_u_65, (copy) v_u_329, (copy) v_u_318, (copy) v_u_322
		if p330 < 3 or (p331 < 3 or (v_u_65 - 3 < p332 or v_u_65 - 3 < p333)) then
			return false
		end
		if v_u_329(p330, p331, p332, p333, v_u_318) then
			return false
		end
		if p334 then
			p334 = v_u_329(p330, p331, p332, p333, v_u_322)
		end
		return not p334
	end
	local function v377(p336, p337, p338, p339, p340, p341, p342, p343) -- name: label
		-- upvalues: (ref) v_u_2, (copy) p_u_56, (copy) v_u_335, (copy) v_u_65, (copy) v_u_318, (copy) v_u_319, (ref) v_u_75, (ref) v_u_74, (copy) v_u_315, (copy) v_u_58, (ref) v_u_321, (copy) v_u_320
		local v344 = v_u_2.phoneText
		local v345 = "caption"
		local v346
		if p_u_56 then
			v346 = p_u_56.scale
		else
			v346 = nil
		end
		local v347
		if p_u_56 then
			v347 = p_u_56.phone
		else
			v347 = nil
		end
		local v348 = v344(p338, v345, v346, v347)
		local v349 = (utf8.len(p336) or #p336) * v348 * 0.56 + 6
		local v350 = v348 + 2
		local v351
		if p341 then
			v351 = p341.Rotation
		else
			v351 = p341
		end
		if v351 then
			if math.abs(v351) ~= 90 then
				local v352 = v349
				v349 = v350
				v350 = v352
			end
		else
			local v353 = v349
			v349 = v350
			v350 = v353
		end
		if not (p342 or v_u_335(p337.X - v350 / 2, p337.Y - v349 / 2, p337.X + v350 / 2, p337.Y + v349 / 2, p343)) then
			return nil
		end
		if p342 then
			local v354 = Vector2.new
			local v355 = p337.X
			local v356 = v350 / 2 + 3
			local v357 = v350 / 2 + 3
			local v358 = v_u_65 - v350 / 2 - 3
			local v359 = math.max(v357, v358)
			local v360 = math.clamp(v355, v356, v359)
			local v361 = p337.Y
			local v362 = v349 / 2 + 3
			local v363 = v349 / 2 + 3
			local v364 = v_u_65 - v349 / 2 - 3
			local v365 = math.max(v363, v364)
			p337 = v354(v360, (math.clamp(v361, v362, v365)))
		end
		local v366 = {
			p337.X - v350 / 2,
			p337.Y - v349 / 2,
			p337.X + v350 / 2,
			p337.Y + v349 / 2
		}
		local v367 = v_u_318
		table.insert(v367, v366)
		v_u_319[v366] = true
		v_u_75 = v_u_75 + 1
		v_u_74 = v_u_74 + 1
		local v368 = v_u_315
		local v369 = v_u_58
		local v370 = v_u_2.phoneText
		local v371 = "caption"
		local v372
		if p_u_56 then
			v372 = p_u_56.scale
		else
			v372 = nil
		end
		local v373
		if p_u_56 then
			v373 = p_u_56.phone
		else
			v373 = nil
		end
		local v374 = v369(v368, p336, p337, v370(v348, v371, v372, v373), p339, p340, p341)
		if v_u_321 then
			local v375 = v_u_320
			local v376 = {
				["id"] = "",
				["kind"] = "name",
				["rect"] = nil,
				["obj"] = nil,
				["rect"] = v_u_318[#v_u_318],
				["obj"] = v374
			}
			table.insert(v375, v376)
		end
		return v374
	end
	local v378 = {}
	if p54 then
		local v379 = p54.buildings
		if type(v379) == "table" and #p54.buildings >= 8 then
			for _, v380 in p54.buildings do
				local v381 = v380.cf
				if typeof(v381) ~= "CFrame" then
					continue
				end
				local v382 = v380.size
				if typeof(v382) ~= "Vector3" then
					continue
				end
				local _, v383, _ = v380.cf:ToOrientation()
				local v384 = {
					["kind"] = v380.kind
				}
				local v385 = string.lower
				local v386 = v380.id
				v384.id = v385((tostring(v386)))
				v384.x = v380.cf.X
				v384.z = v380.cf.Z
				v384.w = v380.size.X
				v384.d = v380.size.Z
				v384.yaw = math.deg(v383)
				v384.name = v380.name
				table.insert(v378, v384)
			end
		end
	end
	if #v378 == 0 then
		for _, v387 in v_u_7.LOTS do
			local v388 = {
				["kind"] = nil,
				["id"] = nil,
				["x"] = nil,
				["z"] = nil,
				["w"] = nil,
				["d"] = nil,
				["yaw"] = 0,
				["name"] = nil,
				["kind"] = v387[2],
				["id"] = v387[1],
				["x"] = v387[4],
				["z"] = v387[5],
				["w"] = v387[6],
				["d"] = v387[7],
				["name"] = v387[9]
			}
			table.insert(v378, v388)
		end
	end
	local v389 = {}
	for _, v390 in v_u_7.PLATES do
		v389[v390[1]] = v390[2]
	end
	local v391 = {}
	for _, v392 in v_u_7.PLATE_LINKS do
		v391[v392[1]] = true
	end
	local v_u_393 = {}
	local v394 = {}
	local v395 = {}
	local v396 = {}
	for _, v397 in v378 do
		local v398 = v_u_7.LANDMARKS[v397.id]
		local v399 = v398 ~= nil
		v396[v397.id] = Vector2.new(v397.x, v397.z)
		local v400
		if v391[v397.id] == true then
			v400 = v397.id ~= "svc_tunnel"
		else
			v400 = false
		end
		local v401 = v397.x
		local v402 = v397.z
		local v403 = v397.w
		local v404 = v397.d
		local v405 = v397.yaw
		local v406
		if v399 then
			v406 = v_u_12.landmark
		elseif v400 then
			v406 = v_u_12.paperLight
		else
			v406 = v_u_12.build
		end
		local v407 = v153(v307, v401, v402, v403, v404, v405, v406)
		local v408 = v397.id
		v407.Name = "B_" .. tostring(v408)
		local v409
		if v399 then
			v409 = v_u_12.landmarkEdge
		else
			v409 = v_u_12.buildEdge
		end
		local v410 = Instance.new("UIStroke")
		v410.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v410.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v410.Color = v409
		v410.Thickness = 1
		v410.Transparency = 0.1
		v410.Parent = v407
		local v411 = v397.id
		local v412 = {}
		local v413 = v397.x
		local v414 = v397.z
		local v415 = v398 or v_u_7.NAMES[v397.id]
		if not v415 then
			local v416 = v397.name or v397.id
			v415 = tostring(v416)
		end
		__set_list(v412, 1, {v413, v414, v415})
		v_u_393[v411] = v412
		local v417 = v397.x
		local v418 = v397.z
		local v419 = Vector2.new((v417 + v_u_60) * v_u_66, (v418 + v_u_60) * v_u_66)
		local v420 = v397.yaw % 180
		local v421 = v397.w
		local v422 = v397.d
		local v423 = v420 - 90
		if math.abs(v423) >= 45 then
			local v424 = v421
			v421 = v422
			v422 = v424
		end
		local v425 = {
			v419.X - v422 * v_u_66 / 2 - 1,
			v419.Y - v421 * v_u_66 / 2 - 1,
			v419.X + v422 * v_u_66 / 2 + 1,
			v419.Y + v421 * v_u_66 / 2 + 1
		}
		table.insert(v_u_322, v425)
		if v399 then
			local v426 = {
				["text"] = v398,
				["b"] = v397,
				["px"] = v419,
				["wpx"] = v422 * v_u_66,
				["hpx"] = v421 * v_u_66
			}
			table.insert(v394, v426)
		end
		if not v389[v397.id] then
			continue
		end
		local v427 = {
			["tag"] = v389[v397.id],
			["px"] = v419,
			["wpx"] = v422 * v_u_66,
			["hpx"] = v421 * v_u_66
		}
		table.insert(v395, v427)
	end
	local v428 = v_u_7.WALL
	local v429 = {}
	for _, v430 in v_u_7.WALL_GAPS do
		local v431 = { v430[2] - v430[3] / 2, v430[2] + v430[3] / 2, v430[1] }
		table.insert(v429, v431)
	end
	table.sort(v429, function(p432, p433)
		return p432[1] < p433[1]
	end)
	local v434 = v67 * 2.4 + 0.5
	local v435 = math.floor(v434)
	local v436 = math.max(2, v435)
	local v437 = v428[1]
	for _, v438 in v429 do
		local v439 = v438[1]
		if v439 - v437 >= 1 then
			v130(v311, v437, v428[2], v439, v428[4], v_u_12.wall, 0.05).Name = "Wall"
		end
		v437 = v438[2]
		if v438[3] == "bluff_stairs" then
			local v440 = v428[2]
			while v440 <= v428[4] do
				local v441 = v438[1]
				local v442 = Vector2.new((v441 + v_u_60) * v_u_66, (v440 + v_u_60) * v_u_66)
				local v443 = v438[2]
				v_u_100(v311, v442, Vector2.new((v443 + v_u_60) * v_u_66, (v440 + v_u_60) * v_u_66), 1, v_u_12.ink, 0.15)
				v440 = v440 + 2.5
			end
		else
			for _, v444 in { v438[1], v438[2] } do
				local v445 = (v428[2] + v428[4]) / 2
				local v446 = Vector2.new((v444 + v_u_60) * v_u_66, (v445 + v_u_60) * v_u_66)
				v458 = v_u_74 + 1
				local v447 = {
					["Name"] = "Post",
					["BackgroundColor3"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_12.ink,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v446.X, v446.Y),
					["Size"] = UDim2.fromOffset(v436 + 1, v436 + 1)
				}
				local v448 = Instance.new("Frame")
				v448.BorderSizePixel = 0
				v_u_74 = v458
				for v449, v450 in v447 do
					v448[v449] = v450
				end
				v448.Parent = v311
			end
		end
	end
	local v451 = v428[3]
	if v451 - v437 >= 1 then
		v130(v311, v437, v428[2], v451, v428[4], v_u_12.wall, 0.05).Name = "Wall"
	end
	local v452 = v_u_7.FOUNTAIN
	local v453 = v452[1]
	local v454 = v452[2]
	local v455 = Vector2.new((v453 + v_u_60) * v_u_66, (v454 + v_u_60) * v_u_66)
	local v456 = v452[3] * 2 * v_u_66
	local v457 = math.max(6, v456)
	local v458 = v_u_74 + 1
	local v459 = {
		["Name"] = "Fountain",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_12.water,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v455.X, v455.Y),
		["Size"] = UDim2.fromOffset(v457, v457)
	}
	local v460 = Instance.new("Frame")
	v460.BorderSizePixel = 0
	local v461 = v458
	for v462, v463 in v459 do
		v460[v462] = v463
	end
	v460.Parent = v311
	local v464 = UDim.new(0.5, 0)
	local v465 = Instance.new("UICorner")
	v465.CornerRadius = v464
	v465.Parent = v460
	local v466 = v_u_12.waterInk
	local v467 = Instance.new("UIStroke")
	v467.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v467.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v467.Color = v466
	v467.Thickness = 1.5
	v467.Transparency = 0
	v467.Parent = v460
	v458 = v461 + 1
	local v468 = {
		["Name"] = "Basin",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_12.paperLight,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.34, 0.34)
	}
	local v469 = Instance.new("Frame")
	v469.BorderSizePixel = 0
	local v470 = v458
	for v471, v472 in v468 do
		v469[v471] = v472
	end
	v469.Parent = v460
	local v473 = UDim.new(0.5, 0)
	local v474 = Instance.new("UICorner")
	v474.CornerRadius = v473
	v474.Parent = v469
	local v475 = v_u_7.STAGE
	local v476 = v153(v311, v475[1], v475[2], v475[3], v475[4], 0, v_u_12.build, 4)
	v476.Name = "Stage"
	v476.BackgroundTransparency = 0.25
	local v477 = v_u_12.buildEdge
	local v478 = Instance.new("UIStroke")
	v478.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v478.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v478.Color = v477
	v478.Thickness = 1
	v478.Transparency = 0.2
	v478.Parent = v476
	local v479 = v_u_66 * 12
	local v480 = math.max(4, v479)
	local v481 = v_u_66 * 9
	local v482 = math.max(3, v481)
	local v483 = {
		["N"] = {},
		["W"] = {},
		["E"] = {}
	}
	for _, v484 in v_u_7.RING_GAPS do
		local v485 = v483[v484[1]]
		if not v485 then
			continue
		end
		local v486 = { v484[2] - v484[3] / 2, v484[2] + v484[3] / 2, v484[4] }
		table.insert(v485, v486)
	end
	for v487, v488 in v483 do
		table.sort(v488, function(p489, p490)
			return p489[1] < p490[1]
		end)
		local v491 = -v61
		local v492
		if v487 == "N" then
			v492 = v61
		else
			v492 = v62
		end
		for _, v493 in v488 do
			local v494 = v493[1]
			if v494 - v491 >= 2 then
				local v495
				if v487 == "N" then
					local v496 = -v61
					v495 = Vector2.new((v491 + v_u_60) * v_u_66, (v496 + v_u_60) * v_u_66)
				elseif v487 == "W" then
					local v497 = -v61
					v495 = Vector2.new((v497 + v_u_60) * v_u_66, (v491 + v_u_60) * v_u_66)
				else
					v495 = Vector2.new((v61 + v_u_60) * v_u_66, (v491 + v_u_60) * v_u_66)
				end
				local v498
				if v487 == "N" then
					local v499 = -v61
					v498 = Vector2.new((v494 + v_u_60) * v_u_66, (v499 + v_u_60) * v_u_66)
				elseif v487 == "W" then
					local v500 = -v61
					v498 = Vector2.new((v500 + v_u_60) * v_u_66, (v494 + v_u_60) * v_u_66)
				else
					v498 = Vector2.new((v61 + v_u_60) * v_u_66, (v494 + v_u_60) * v_u_66)
				end
				local v501 = v67 * 1.5 + 0.5
				local v502 = math.floor(v501)
				v168(v311, v495, v498, v480, v482, math.max(1, v502), v_u_12.ink, 0.1)
			end
			v491 = v493[2]
			local v503 = v493[3]
			if v503 ~= "cut" then
				for _, v504 in { v493[1], v493[2] } do
					local v505
					if v487 == "N" then
						local v506 = -v61
						v505 = Vector2.new((v504 + v_u_60) * v_u_66, (v506 + v_u_60) * v_u_66)
					elseif v487 == "W" then
						local v507 = -v61
						v505 = Vector2.new((v507 + v_u_60) * v_u_66, (v504 + v_u_60) * v_u_66)
					else
						v505 = Vector2.new((v61 + v_u_60) * v_u_66, (v504 + v_u_60) * v_u_66)
					end
					local v508 = v67 * 4 + 0.5
					local v509 = math.floor(v508)
					local v510 = math.max(3, v509)
					v458 = v470 + 1
					local v511 = {
						["Name"] = "Post",
						["BackgroundColor3"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_12.ink,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromOffset(v505.X, v505.Y),
						["Size"] = UDim2.fromOffset(v510, v510)
					}
					local v512 = Instance.new("Frame")
					v512.BorderSizePixel = 0
					v470 = v458
					for v513, v514 in v511 do
						v512[v513] = v514
					end
					v512.Parent = v311
				end
			end
			if v503 ~= "locked" then
				continue
			end
			local v515 = v493[1]
			local v516
			if v487 == "N" then
				local v517 = -v61
				v516 = Vector2.new((v515 + v_u_60) * v_u_66, (v517 + v_u_60) * v_u_66)
			elseif v487 == "W" then
				local v518 = -v61
				v516 = Vector2.new((v518 + v_u_60) * v_u_66, (v515 + v_u_60) * v_u_66)
			else
				v516 = Vector2.new((v61 + v_u_60) * v_u_66, (v515 + v_u_60) * v_u_66)
			end
			local v519 = v493[2]
			local v520
			if v487 == "N" then
				local v521 = -v61
				v520 = Vector2.new((v519 + v_u_60) * v_u_66, (v521 + v_u_60) * v_u_66)
			elseif v487 == "W" then
				local v522 = -v61
				v520 = Vector2.new((v522 + v_u_60) * v_u_66, (v519 + v_u_60) * v_u_66)
			else
				v520 = Vector2.new((v61 + v_u_60) * v_u_66, (v519 + v_u_60) * v_u_66)
			end
			local v523 = v67 * 2.5 + 0.5
			local v524 = math.floor(v523)
			v_u_100(v311, v516, v520, math.max(2, v524), v_u_12.redDeep, 0.1)
		end
		if v492 - v491 < 2 then
			break
		end
		local v525
		if v487 == "N" then
			local v526 = -v61
			v525 = Vector2.new((v491 + v_u_60) * v_u_66, (v526 + v_u_60) * v_u_66)
		elseif v487 == "W" then
			local v527 = -v61
			v525 = Vector2.new((v527 + v_u_60) * v_u_66, (v491 + v_u_60) * v_u_66)
		else
			v525 = Vector2.new((v61 + v_u_60) * v_u_66, (v491 + v_u_60) * v_u_66)
		end
		local v528
		if v487 == "N" then
			local v529 = -v61
			v528 = Vector2.new((v492 + v_u_60) * v_u_66, (v529 + v_u_60) * v_u_66)
		elseif v487 == "W" then
			local v530 = -v61
			v528 = Vector2.new((v530 + v_u_60) * v_u_66, (v492 + v_u_60) * v_u_66)
		else
			v528 = Vector2.new((v61 + v_u_60) * v_u_66, (v492 + v_u_60) * v_u_66)
		end
		local v531 = v67 * 1.5 + 0.5
		local v532 = math.floor(v531)
		v168(v311, v525, v528, v480, v482, math.max(1, v532), v_u_12.ink, 0.1)
	end
	for _, v533 in v_u_7.PLATE_LINKS do
		local v534 = v396[v533[2]]
		local v535 = v396[v533[3]]
		if not (v534 and v535) then
			continue
		end
		local v536 = v534.X
		local v537 = v534.Y
		local v538 = Vector2.new((v536 + v_u_60) * v_u_66, (v537 + v_u_60) * v_u_66)
		local v539 = v535.X
		local v540 = v535.Y
		local v541 = Vector2.new((v539 + v_u_60) * v_u_66, (v540 + v_u_60) * v_u_66)
		local v542 = v_u_66 * 8
		local v543 = math.max(3, v542)
		local v544 = v_u_66 * 6
		local v545 = math.max(2, v544)
		local v546 = v67 * 1.2 + 0.5
		local v547 = math.floor(v546)
		v168(v311, v538, v541, v543, v545, math.max(1, v547), v_u_12.redDeep, 0.2)
		local v548 = v538:Lerp(v541, 0.62)
		local v549 = v67 * 5 + 0.5
		local v550 = math.floor(v549)
		local v551 = math.max(4, v550)
		v458 = v470 + 1
		local v552 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["Name"] = "Arrow_" .. v533[1],
			["BackgroundColor3"] = v_u_12.redDeep,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v548.X, v548.Y),
			["Size"] = UDim2.fromOffset(v551, v551)
		}
		local v553 = Instance.new("Frame")
		v553.BorderSizePixel = 0
		v470 = v458
		for v554, v555 in v552 do
			v553[v554] = v555
		end
		v553.Parent = v311
	end
	local v556 = 196 * v67
	local v557 = math.floor(v556)
	local v558 = 52 * v67
	local v559 = math.floor(v558)
	local v_u_560 = v_u_39("Overture Plaza")
	local v561 = 19 * v67
	local v562 = math.floor(v561)
	local v563 = math.max(13, v562)
	local v564 = v_u_2.phoneText
	local v565 = "text"
	local v566
	if p_u_56 then
		v566 = p_u_56.scale
	else
		v566 = nil
	end
	local v567
	if p_u_56 then
		v567 = p_u_56.phone
	else
		v567 = nil
	end
	local v_u_568 = v564(v563, v565, v566, v567)
	if v59 then
		local function v569()
			-- upvalues: (ref) v_u_1, (copy) v_u_560, (copy) v_u_568
			return v_u_1:GetTextSize(v_u_560, v_u_568, Enum.Font.GothamBold, Vector2.new(1000, 100))
		end
		local v570, v571 = pcall(v569)
		local v572
		if v570 then
			v572 = v571.X
		else
			v572 = #v_u_560 * v_u_568 * 0.7
		end
		local v573 = v572 + 14
		local v574 = math.ceil(v573)
		v557 = math.max(v557, v574)
		local v575 = 34 * v67
		local v576 = math.floor(v575)
		local v577 = v_u_568 + 10
		v559 = math.max(v576, v577)
	end
	local v578 = {}
	local v579 = {}
	local v580 = 10 * v67
	local v581 = math.floor(v580)
	local v582 = 10 * v67
	local v583 = math.floor(v582)
	local v584 = 10 * v67
	local v585 = math.floor(v584) + v557
	local v586 = 10 * v67
	__set_list(v579, 1, {v581, v583, v585, math.floor(v586) + v559})
	local v587 = {}
	local v588 = v_u_65 - 34 * v67 - 19 * v67
	local v589 = 40 * v67 - 22 * v67
	local v590 = 15 * v67
	local v591 = math.floor(v590)
	__set_list(v587, 1, {v588, v589 - math.max(11, v591), v_u_65 - 34 * v67 + 19 * v67, 40 * v67 + 19 * v67})
	local v592 = {}
	local v593 = v67 * 14 - 8
	local v594 = v_u_65 - 26 * v67 - v67 * 9 - 9
	local v595 = v67 * 14 + 100 / v_u_7.STUDS_TO_M * v_u_66 + 34
	local v596 = v_u_65 - 26 * v67
	local v597 = v67 * 5
	__set_list(v592, 1, {v593, v594, v595, v596 + math.max(3, v597) + 3})
	__set_list(v578, 1, {v579, v587, v592})
	local v598 = 13 * v67 + 0.5
	local v599 = math.floor(v598)
	local v600 = math.max(10, v599)
	local v601 = v_u_2.phoneText
	local v602 = "text"
	local v603
	if p_u_56 then
		v603 = p_u_56.scale
	else
		v603 = nil
	end
	local v604
	if p_u_56 then
		v604 = p_u_56.phone
	else
		v604 = nil
	end
	local v605 = v601(v600, v602, v603, v604)
	table.sort(v394, function(p606, p607)
		return p606.b.w * p606.b.d > p607.b.w * p607.b.d
	end)
	for v608, v609 in v394 do
		local v610 = string.upper(v609.text)
		local v611 = (utf8.len(v610) or #v610) * v605 * 0.56 + 6
		local v612 = v605 + 2
		local v613 = v609.px
		local v614 = false
		for _, v615 in {
			Vector2.new(v613.X, v613.Y + v609.hpx / 2 + v612 / 2 + 3),
			Vector2.new(v613.X, v613.Y - v609.hpx / 2 - v612 / 2 - 3),
			Vector2.new(v613.X + v609.wpx / 2 + v611 / 2 + 3, v613.Y),
			Vector2.new(v613.X - v609.wpx / 2 - v611 / 2 - 3, v613.Y)
		} do
			if not v377(v610, v615, v605, v69, v_u_12.redDeep) then
				continue
			end
			v614 = true
		end
		if v614 or v608 > 14 then
			break
		end
		v377(v610, v613, v605, v69, v_u_12.redDeep, nil, true)
	end
	local v616 = 13 * v67 + 0.5
	local v617 = math.floor(v616)
	local v618 = math.max(10, v617)
	local v619 = v_u_2.phoneText
	local v620 = "caption"
	local v621
	if p_u_56 then
		v621 = p_u_56.scale
	else
		v621 = nil
	end
	local v622
	if p_u_56 then
		v622 = p_u_56.phone
	else
		v622 = nil
	end
	local v623 = v619(v618, v620, v621, v622)
	local v624 = #v_u_318
	for _, v625 in v578 do
		local v626 = {}
		local v627 = v625[1]
		local v628 = math.max(0, v627)
		local v629 = v625[2]
		local v630 = math.max(0, v629)
		local v631 = v625[3]
		local v632 = math.min(v_u_65, v631)
		local v633 = v625[4]
		__set_list(v626, 1, {v628, v630, v632, (math.min(v_u_65, v633))})
		table.insert(v_u_318, v626)
	end
	local v634
	if v_u_4 == nil then
		v634 = false
	else
		v634 = v_u_4.clean()
	end
	v_u_321 = v634
	local v635 = 11 * v67 + 0.5
	local v636 = math.floor(v635)
	local v637 = math.max(9, v636)
	for _, v638 in v395 do
		local v639 = v638.px
		local v640 = v_u_2.phoneText
		local v641 = "caption"
		local v642
		if p_u_56 then
			v642 = p_u_56.scale
		else
			v642 = nil
		end
		local v643
		if p_u_56 then
			v643 = p_u_56.phone
		else
			v643 = nil
		end
		local v644 = v640(v637, v641, v642, v643)
		local v645 = v644 + 6
		local v646 = (utf8.len(v638.tag) or #v638.tag) * v644 * 0.62 + 8
		local v647 = math.max(v645, v646)
		local v648 = v644 + 4
		local v649 = Vector2.new(v639.X - v638.wpx / 2 + v647 / 2 + 1, v639.Y - v638.hpx / 2 + v648 / 2 + 1)
		local v650 = v377(v638.tag, v649, v637, v69, v_u_12.ink, {
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = nil,
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_12.paperLight,
			["Size"] = UDim2.fromOffset(v647, v648)
		}, true)
		if not v650 then
			continue
		end
		v650.Name = "Plate_" .. v638.tag
		local v651 = v_u_12.ink
		local v652 = Instance.new("UIStroke")
		v652.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v652.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v652.Color = v651
		v652.Thickness = 1
		v652.Transparency = 0.1
		v652.Parent = v650
	end
	local v653 = {
		{ 0.5, 0.5 },
		{ 0.5, 0.1 },
		{ 0.5, 0.9 },
		{ 0.25, 0.5 },
		{ 0.75, 0.5 },
		{ 0.25, 0.14 },
		{ 0.75, 0.14 },
		{ 0.25, 0.86 },
		{ 0.75, 0.86 }
	}
	for _, v654 in v_u_7.AREAS do
		if not v654[6] then
			continue
		end
		local v655 = v654[5]
		local v656 = v_u_39(v654[2])
		for _, v657 in v653 do
			local v658 = v655[1] + (v655[3] - v655[1]) * v657[1]
			local v659 = v655[2] + (v655[4] - v655[2]) * v657[2]
			if not v377(v656, Vector2.new((v658 + v_u_60) * v_u_66, (v659 + v_u_60) * v_u_66), v623, v68, v_u_12.inkSoft, {
				["TextStrokeTransparency"] = 0.45
			}, false, true) then
				continue
			end
			break
			break
		end
	end
	local v660 = 11 * v67 + 0.5
	local v661 = math.floor(v660)
	local v662 = math.max(9, v661)
	local v663 = v_u_2.phoneText
	local v664 = "caption"
	local v665
	if p_u_56 then
		v665 = p_u_56.scale
	else
		v665 = nil
	end
	local v666
	if p_u_56 then
		v666 = p_u_56.phone
	else
		v666 = nil
	end
	local v667 = v663(v662, v664, v665, v666)
	local v668 = v_u_7.WATER
	local v669 = false
	for _, v670 in {
		150,
		330,
		-330,
		240,
		-250
	} do
		local v671 = v_u_39("Lake Erie")
		local v672 = (v668[2] + v668[4]) / 2 + 8
		if not v377(v671, Vector2.new((v670 + v_u_60) * v_u_66, (v672 + v_u_60) * v_u_66), v623, v68, v_u_12.waterInk, {
			["TextStrokeColor3"] = nil,
			["TextStrokeTransparency"] = 0.3,
			["TextStrokeColor3"] = v_u_12.water
		}) then
			continue
		end
		v669 = true
	end
	if not v669 then
		local v673 = v_u_39("Lake Erie")
		local v674 = (v668[2] + v668[4]) / 2 + 8
		v377(v673, Vector2.new((150 + v_u_60) * v_u_66, (v674 + v_u_60) * v_u_66), v623, v68, v_u_12.waterInk, {
			["TextStrokeColor3"] = nil,
			["TextStrokeTransparency"] = 0.3,
			["TextStrokeColor3"] = v_u_12.water
		}, true)
	end
	local v675 = {}
	for _, v676 in v_u_7.ROADS do
		local v677 = v676[5]
		local v678 = v676[3] - v676[1] > v676[4] - v676[2]
		local v679
		if v678 then
			v679 = v676[3] - v676[1]
		else
			v679 = v676[4] - v676[2]
		end
		local v680 = v675[v677] or 0
		if v677 == "" or v680 >= 1 or v679 * v_u_66 <= (utf8.len(v677) or #v677) * v667 * 0.5 then
			continue
		end
		for _, v681 in {
			0.5,
			0.3,
			0.7,
			0.15,
			0.85
		} do
			local v682
			if v678 then
				v682 = v676[1] + (v676[3] - v676[1]) * v681
			else
				v682 = (v676[1] + v676[3]) / 2
			end
			local v683
			if v678 then
				v683 = (v676[2] + v676[4]) / 2
			else
				v683 = v676[2] + (v676[4] - v676[2]) * v681
			end
			if not v377(string.upper(v677), Vector2.new((v682 + v_u_60) * v_u_66, (v683 + v_u_60) * v_u_66), v667, v71, v_u_12.inkSoft, {
				["Rotation"] = nil,
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.1,
				["Rotation"] = v678 and 0 or 90,
				["TextStrokeColor3"] = v_u_12.road
			}) then
				continue
			end
			v675[v677] = v680 + 1
		end
	end
	for _, v684 in v_u_7.RAIL do
		if v684[5] ~= "Freight Line" then
			continue
		end
		for _, v685 in { 0.62, 0.4, 0.8 } do
			local v686 = string.upper(v684[5])
			local v687 = (v684[1] + v684[3]) / 2
			local v688 = v684[2] + (v684[4] - v684[2]) * v685
			if not v377(v686, Vector2.new((v687 + v_u_60) * v_u_66, (v688 + v_u_60) * v_u_66), v667, v71, v_u_12.rail, {
				["Rotation"] = 90,
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.2,
				["TextStrokeColor3"] = v_u_12.field
			}) then
				continue
			end
			break
			break
		end
	end
	for _, v689 in { 0.3333333333333333, 0.6666666666666666 } do
		local v690 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_12.paperLight,
			["Position"] = UDim2.new(v689, 0, 0, 0),
			["Size"] = UDim2.new(0, 2, 1, 0)
		}
		local v691 = Instance.new("Frame")
		v691.BorderSizePixel = 0
		for v692, v693 in v690 do
			v691[v692] = v693
		end
		v691.Parent = v73
		local v694 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_12.crease,
			["Position"] = UDim2.new(v689, 2, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v695 = Instance.new("Frame")
		v695.BorderSizePixel = 0
		for v696, v697 in v694 do
			v695[v696] = v697
		end
		v695.Parent = v73
	end
	local v698 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_12.paperLight,
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v699 = Instance.new("Frame")
	v699.BorderSizePixel = 0
	for v700, v701 in v698 do
		v699[v700] = v701
	end
	v699.Parent = v73
	local v702 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_12.crease,
		["Position"] = UDim2.new(0, 0, 0.5, 2),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v703 = Instance.new("Frame")
	v703.BorderSizePixel = 0
	for v704, v705 in v702 do
		v703[v704] = v705
	end
	v703.Parent = v73
	local v706 = v67 * 12 + 0.5
	local v707 = math.floor(v706)
	local v708 = math.max(9, v707)
	local v709 = v_u_2.phoneText
	local v710 = "caption"
	local v711
	if p_u_56 then
		v711 = p_u_56.scale
	else
		v711 = nil
	end
	local v712
	if p_u_56 then
		v712 = p_u_56.phone
	else
		v712 = nil
	end
	local v713 = v709(v708, v710, v711, v712)
	for v714 = 1, v188 do
		local v715 = v64 + v_u_65 * (v714 - 0.5) / v188
		for _, v716 in { v64 / 2, p53 - v64 / 2 } do
			local v717 = v_u_40[v714] or "?"
			local v718 = Vector2.new(v715, v716)
			local v719 = v_u_12.inkSoft
			local v720 = v_u_2.phoneText
			local v721 = "caption"
			local v722
			if p_u_56 then
				v722 = p_u_56.scale
			else
				v722 = nil
			end
			local v723
			if p_u_56 then
				v723 = p_u_56.phone
			else
				v723 = nil
			end
			local v724 = v_u_58(v73, v717, v718, v720(v713, v721, v722, v723), v68, v719, nil)
			v724.ZIndex = 21
			v724.TextStrokeTransparency = 1
		end
		for _, v725 in { v64 / 2, p53 - v64 / 2 } do
			local v726 = tostring(v714)
			local v727 = Vector2.new(v725, v715)
			local v728 = v_u_12.inkSoft
			local v729 = v_u_2.phoneText
			local v730 = "caption"
			local v731
			if p_u_56 then
				v731 = p_u_56.scale
			else
				v731 = nil
			end
			local v732
			if p_u_56 then
				v732 = p_u_56.phone
			else
				v732 = nil
			end
			local v733 = v_u_58(v73, v726, v727, v729(v713, v730, v731, v732), v68, v728, nil)
			v733.ZIndex = 21
			v733.TextStrokeTransparency = 1
		end
	end
	local v734 = {
		["Name"] = "Cartouche",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.paperLight
	}
	local v735 = UDim2.fromOffset
	local v736 = 10 * v67
	local v737 = math.floor(v736)
	local v738 = 10 * v67
	v734.Position = v735(v737, (math.floor(v738)))
	v734.Size = UDim2.fromOffset(v557, v559)
	local v739 = Instance.new("Frame")
	v739.BorderSizePixel = 0
	for v740, v741 in v734 do
		v739[v740] = v741
	end
	v739.Parent = v81
	local v742 = v_u_12.ink
	local v743 = Instance.new("UIStroke")
	v743.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v743.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v743.Color = v742
	v743.Thickness = 1
	v743.Transparency = 0
	v743.Parent = v739
	local v744 = Vector2.new
	local v745
	if v59 then
		v745 = v557 / 2
	else
		v745 = 98 * v67
	end
	local v746
	if v59 then
		v746 = v559 / 2
	else
		v746 = 19 * v67
	end
	local v747 = v744(v745, v746)
	local v748 = v_u_12.ink
	local v749 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil
	}
	local v750 = UDim2.fromOffset
	local v751
	if v59 then
		v751 = v557 - 4
	else
		v751 = 190 * v67
	end
	local v752
	if v59 then
		v752 = v559 - 4
	else
		v752 = 24 * v67
	end
	v749.Size = v750(v751, v752)
	local v753 = v_u_2.phoneText
	local v754 = "caption"
	local v755
	if p_u_56 then
		v755 = p_u_56.scale
	else
		v755 = nil
	end
	local v756
	if p_u_56 then
		v756 = p_u_56.phone
	else
		v756 = nil
	end
	v_u_58(v739, v_u_560, v747, v753(v_u_568, v754, v755, v756), v69, v748, v749).ZIndex = 11
	if not v59 then
		local v757 = Vector2.new(98 * v67, 39 * v67)
		local v758 = 11 * v67
		local v759 = math.floor(v758)
		local v760 = math.max(9, v759)
		local v761 = v_u_12.inkSoft
		local v762 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(190 * v67, v67 * 14)
		}
		local v763 = "Tacet headquarters, Port Vesper"
		local v764 = v_u_2.phoneText
		local v765 = "caption"
		local v766
		if p_u_56 then
			v766 = p_u_56.scale
		else
			v766 = nil
		end
		local v767
		if p_u_56 then
			v767 = p_u_56.phone
		else
			v767 = nil
		end
		v_u_58(v739, v763, v757, v764(v760, v765, v766, v767), v70, v761, v762).ZIndex = 11
	end
	local v768
	if v_u_4 == nil then
		v768 = false
	else
		v768 = v_u_4.clean()
	end
	local v769 = {}
	local v770 = 15 * v67
	local v771 = math.floor(v770)
	local v772 = math.max(11, v771)
	local v773 = v_u_65 - 34 * v67
	local v774 = 40 * v67
	if v768 then
		local v775 = 17 * v67 + v772 + 4
		v774 = math.max(v774, v775)
		local v776 = {
			v773 - 17 * v67 - 2,
			v774 - 17 * v67 - v772 - 4,
			v773 + 17 * v67 + 2,
			v774 + 17 * v67 + 2
		}
		table.insert(v769, v776)
		local v777 = {}
		local v778 = 10 * v67
		local v779 = math.floor(v778)
		local v780 = 10 * v67
		local v781 = math.floor(v780)
		local v782 = 10 * v67
		local v783 = math.floor(v782) + v557
		local v784 = 10 * v67
		__set_list(v777, 1, {v779, v781, v783, math.floor(v784) + v559})
		table.insert(v769, v777)
	end
	local v785 = Vector2.new
	local v786
	if v768 then
		v786 = 17 * v67 + v772 * 0.5 + 3
	else
		v786 = 22 * v67
	end
	local v787 = v785(v773, v774 - v786)
	local v788 = v_u_12.ink
	local v789 = {
		["TextStrokeTransparency"] = 1
	}
	local v790 = "N"
	local v791 = v_u_2.phoneText
	local v792 = "caption"
	local v793
	if p_u_56 then
		v793 = p_u_56.scale
	else
		v793 = nil
	end
	local v794
	if p_u_56 then
		v794 = p_u_56.phone
	else
		v794 = nil
	end
	v_u_58(v81, v790, v787, v791(v772, v792, v793, v794), v69, v788, v789).ZIndex = 10
	local v795 = {
		["Name"] = "Needle",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v773, v774),
		["Size"] = UDim2.fromOffset(2, 28 * v67)
	}
	local v796 = Instance.new("Frame")
	v796.BorderSizePixel = 0
	for v797, v798 in v795 do
		v796[v797] = v798
	end
	v796.Parent = v81
	local v799 = {
		["Name"] = "NeedleTip",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.red,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v773, v774 - v67 * 9),
		["Size"] = UDim2.fromOffset(v67 * 7, v67 * 7)
	}
	local v800 = Instance.new("Frame")
	v800.BorderSizePixel = 0
	for v801, v802 in v799 do
		v800[v801] = v802
	end
	v800.Parent = v81
	local v803 = {
		["Name"] = "Cross",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v773, v774),
		["Size"] = UDim2.fromOffset(v67 * 16, 1)
	}
	local v804 = Instance.new("Frame")
	v804.BorderSizePixel = 0
	for v805, v806 in v803 do
		v804[v805] = v806
	end
	v804.Parent = v81
	local v807 = {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v773, v774),
		["Size"] = UDim2.fromOffset(34 * v67, 34 * v67)
	}
	local v808 = Instance.new("Frame")
	v808.BorderSizePixel = 0
	for v809, v810 in v807 do
		v808[v809] = v810
	end
	v808.Parent = v81
	local v811 = UDim.new(0.5, 0)
	local v812 = Instance.new("UICorner")
	v812.CornerRadius = v811
	v812.Parent = v808
	local v813 = v_u_12.ink
	local v814 = Instance.new("UIStroke")
	v814.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v814.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v814.Color = v813
	v814.Thickness = 1
	v814.Transparency = 0.3
	v814.Parent = v808
	local v815 = 100 / v_u_7.STUDS_TO_M * v_u_66
	local v816 = v67 * 14
	local v817 = v_u_65 - 26 * v67
	for v818 = 0, 3 do
		local v819 = {
			["Name"] = "Scale",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 10
		}
		local v820
		if v818 % 2 == 0 then
			v820 = v_u_12.ink
		else
			v820 = v_u_12.paperLight
		end
		v819.BackgroundColor3 = v820
		v819.Position = UDim2.fromOffset(v816 + v818 * v815 / 4, v817)
		local v821 = UDim2.fromOffset
		local v822 = v815 / 4
		local v823 = v67 * 5
		v819.Size = v821(v822, (math.max(3, v823)))
		local v824 = Instance.new("Frame")
		v824.BorderSizePixel = 0
		for v825, v826 in v819 do
			v824[v825] = v826
		end
		v824.Parent = v81
		local v827 = v_u_12.ink
		local v828 = Instance.new("UIStroke")
		v828.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v828.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v828.Color = v827
		v828.Thickness = 1
		v828.Transparency = 0
		v828.Parent = v824
	end
	local v829
	if v768 then
		v829 = v67 * 9 + 3
	else
		v829 = v67 * 9
	end
	local v830 = Vector2.new(v816, v817 - v829)
	local v831 = 11 * v67
	local v832 = math.floor(v831)
	local v833 = math.max(9, v832)
	local v834 = v_u_12.ink
	local v835 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v836 = "0"
	local v837 = v_u_2.phoneText
	local v838 = "caption"
	local v839
	if p_u_56 then
		v839 = p_u_56.scale
	else
		v839 = nil
	end
	local v840
	if p_u_56 then
		v840 = p_u_56.phone
	else
		v840 = nil
	end
	v_u_58(v81, v836, v830, v837(v833, v838, v839, v840), v71, v834, v835).ZIndex = 10
	local v841 = Vector2.new(v816 + v815, v817 - v829)
	local v842 = 11 * v67
	local v843 = math.floor(v842)
	local v844 = math.max(9, v843)
	local v845 = v_u_12.ink
	local v846 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v847 = "100 m"
	local v848 = v_u_2.phoneText
	local v849 = "caption"
	local v850
	if p_u_56 then
		v850 = p_u_56.scale
	else
		v850 = nil
	end
	local v851
	if p_u_56 then
		v851 = p_u_56.phone
	else
		v851 = nil
	end
	v_u_58(v81, v847, v841, v848(v844, v849, v850, v851), v71, v845, v846).ZIndex = 10
	if v768 then
		local v852 = {}
		local v853 = v816 - 8
		local v854 = v817 - v829 - 9
		local v855 = v816 + v815 + 34
		local v856 = v67 * 5
		__set_list(v852, 1, {v853, v854, v855, v817 + math.max(3, v856) + 3})
		table.insert(v769, v852)
	end
	local v857 = {}
	for _, v858 in v_u_7.AREAS do
		local v859 = {
			["id"] = v858[1],
			["name"] = v858[2],
			["ref"] = v_u_5.gridRef(v858[3], v858[4])
		}
		table.insert(v857, v859)
	end
	local function v863(p860) -- name: placeOf
		-- upvalues: (copy) v_u_393, (ref) v_u_5
		local v861 = string.lower(p860)
		local v862 = v_u_393[v861]
		if v862 then
			return v862[1], v862[2], v862[3]
		else
			return v_u_5.placeOf(v861)
		end
	end
	local v864 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v865 = Instance.new("Frame")
	v865.BorderSizePixel = 0
	for v866, v867 in v864 do
		v865[v866] = v867
	end
	v865.Parent = v81
	v73:SetAttribute("Frames", v470)
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["labelLayer"] = nil,
		["nameRects"] = nil,
		["removable"] = nil,
		["reserved"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["field"] = true,
		["positions"] = true,
		["placeOf"] = nil,
		["places"] = nil,
		["stats"] = nil,
		["frame"] = v73,
		["area"] = v81,
		["marks"] = v865,
		["toPx"] = v171,
		["toWorld"] = function(p868, p869) -- name: toWorld
			-- upvalues: (copy) v_u_66, (copy) v_u_60
			return Vector2.new(p868 / v_u_66 - v_u_60, p869 / v_u_66 - v_u_60)
		end,
		["inside"] = function(p870, p871) -- name: inside
			-- upvalues: (copy) v_u_60
			local v872
			if math.abs(p870) <= v_u_60 then
				v872 = math.abs(p871) <= v_u_60
			else
				v872 = false
			end
			return v872
		end,
		["placed"] = v_u_318,
		["labelLayer"] = v_u_315,
		["nameRects"] = v_u_319,
		["removable"] = v_u_320,
		["reserved"] = v769,
		["nLandmarks"] = v624,
		["scale"] = v_u_66,
		["k"] = v67,
		["ink"] = v_u_12,
		["inner"] = v_u_65,
		["innerW"] = v_u_65,
		["innerH"] = v_u_65,
		["placeOf"] = v863,
		["places"] = v857,
		["stats"] = {
			["frames"] = v470,
			["labels"] = v_u_75,
			["lots"] = #v378,
			["trees"] = #v_u_7.TREES
		}
	}
end
return v_u_5