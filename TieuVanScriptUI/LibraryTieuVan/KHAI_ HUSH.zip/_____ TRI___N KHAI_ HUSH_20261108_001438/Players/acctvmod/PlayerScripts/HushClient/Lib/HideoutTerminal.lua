-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutTerminal

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v3 = {}
local v_u_4 = {
	{
		["id"] = "traders",
		["text"] = "Traders"
	},
	{
		["id"] = "tasks",
		["text"] = "Tasks"
	}
}
local v_u_5 = {
	["traders"] = "MenuTraders",
	["tasks"] = "MenuTasks"
}
local function v_u_15(p6, p7, p8, p9, p10, p11, p12) -- name: part
	local v13 = p12 or {}
	local v14 = Instance.new("Part")
	v14.Name = p11 or "Part"
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanTouch = false
	v14.CanQuery = false
	v14.CastShadow = v13.shadow ~= false
	v14.Size = p7
	v14.CFrame = p8
	v14.Color = p9
	v14.Material = p10
	v14.TopSurface = Enum.SurfaceType.Smooth
	v14.BottomSurface = Enum.SurfaceType.Smooth
	if v13.t then
		v14.Transparency = v13.t
	end
	if v13.shape then
		v14.Shape = v13.shape
	end
	v14.Parent = p6
	return v14
end
function v3.buildProp(p16, p17) -- name: buildProp
	-- upvalues: (copy) v_u_15
	local v18 = Instance.new("Model")
	v18.Name = "Terminal"
	local v19 = Color3.fromHex
	local v20 = v19("4A4F55")
	local v21 = v19("2E3237")
	local v22 = v19("6A503A")
	local v23 = v19("3A3C37")
	v19("1E2A22")
	local v24 = Enum.Material
	local v25 = v_u_15(v18, Vector3.new(5.2, 0.25, 2.6), p17 * CFrame.new(0, 3.05, 0.2), v22, v24.WoodPlanks, "DeskTop")
	for _, v26 in { -2.4, 2.4 } do
		for _, v27 in { -0.9, 1.3 } do
			v_u_15(v18, Vector3.new(0.22, 2.95, 0.22), p17 * CFrame.new(v26, 1.47, v27), v21, v24.Metal, "Leg")
		end
	end
	v_u_15(v18, Vector3.new(4.9, 0.12, 2.2), p17 * CFrame.new(0, 0.9, 0.35), v20, v24.Metal, "Shelf")
	local v28 = v_u_15(v18, Vector3.new(1.6, 1.15, 0.06), v_u_15(v18, Vector3.new(2.1, 1.75, 1.7), p17 * CFrame.new(-0.6, 4.055, 0.55), v23, v24.SmoothPlastic, "TerminalBody").CFrame * CFrame.new(0, 0.12, -0.86), v19("3A2A12"), v24.Neon, "Screen", {
		["shadow"] = false
	})
	v28.Transparency = 0.15
	local v29 = Instance.new("SurfaceLight")
	v29.Face = Enum.NormalId.Front
	v29.Color = v19("E8A33D")
	v29.Brightness = 0.8
	v29.Range = 9
	v29.Angle = 90
	v29.Shadows = false
	v29.Parent = v28
	for v30 = 0, 3 do
		local v31 = v_u_15
		local v32 = 1.3 - v30 * 0.18
		v31(v18, Vector3.new(v32, 0.05, 0.02), v28.CFrame * CFrame.new(v30 * 0.05 + -0.12, 0.32 - v30 * 0.2, -0.04), v19("E8A33D"), v24.Neon, "Line", {
			["shadow"] = false
		})
	end
	v_u_15(v18, Vector3.new(1.8, 0.1, 0.65), p17 * CFrame.new(-0.6, 3.23, -0.65), v21, v24.SmoothPlastic, "Keyboard")
	local v33 = v_u_15(v18, Vector3.new(0.9, 0.55, 1.1), p17 * CFrame.new(1.45, 3.4499999999999997, 0.3), v19("4B5234"), v24.Metal, "FieldPhone")
	v_u_15(v18, Vector3.new(0.25, 0.25, 1.15), v33.CFrame * CFrame.new(0, 0.38, 0), v21, v24.SmoothPlastic, "Handset")
	v_u_15(v18, Vector3.new(0.18, 0.18, 0.18), v33.CFrame * CFrame.new(0.3, 0.1, -0.56), v19("A33A32"), v24.Neon, "Lamp", {
		["shadow"] = false
	})
	v_u_15(v18, Vector3.new(0.9, 0.04, 1.2), p17 * CFrame.new(1.6, 3.1999999999999997, -0.75) * CFrame.Angles(0, 0.25, 0), v19("8E7454"), v24.Wood, "Clipboard", {
		["shadow"] = false
	})
	v_u_15(v18, Vector3.new(0.75, 0.03, 1), p17 * CFrame.new(1.6, 3.23, -0.75) * CFrame.Angles(0, 0.25, 0), v19("D9D4C5"), v24.Fabric, "Sheet", {
		["shadow"] = false
	})
	v_u_15(v18, Vector3.new(0.5, 0.4, 0.4), p17 * CFrame.new(-2.1, 3.38, -0.6) * CFrame.Angles(0, 0, 1.5707963267948966), v19("3E5F6B"), v24.Metal, "Mug", {
		["shape"] = nil,
		["shadow"] = false,
		["shape"] = Enum.PartType.Cylinder
	})
	for v34, v35 in {
		{ -1.6, 6.1, 0.08 },
		{ -0.4, 6.4, -0.05 },
		{ 0.8, 6, 0.06 }
	} do
		local v36 = v_u_15
		local v37 = Vector3.new(0.95, 1.25, 0.04)
		local v38 = p17 * CFrame.new(v35[1], v35[2], 1.48) * CFrame.Angles(0, 0, v35[3])
		local v39
		if v34 == 2 then
			v39 = v19("CFC6AE")
		else
			v39 = v19("D9D4C5")
		end
		v36(v18, v37, v38, v39, v24.Fabric, "Note", {
			["shadow"] = false
		})
	end
	v_u_15(v18, Vector3.new(0.14, 3.1, 0.14), p17 * CFrame.new(-1.9, 1.55, 1.25), v19("1B1C1E"), v24.Rubber, "Cable", {
		["shadow"] = false
	})
	v18.PrimaryPart = v25
	v18.Parent = p16
	return v18, Vector3.new(5.4, 4.4, 3)
end
function v3.new(p_u_40, p41) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
	local v_u_42 = p41 or {}
	local v_u_43 = v_u_2.LocalPlayer
	local function v45()
		-- upvalues: (copy) p_u_40, (ref) v_u_5, (ref) v_u_4
		if p_u_40.shared.GameMode.rule("clans") == true and v_u_5.clan == nil then
			local v44 = v_u_4
			table.insert(v44, {
				["id"] = "clan",
				["text"] = "Clan"
			})
			v_u_5.clan = "MenuClan"
		end
	end
	pcall(v45)
	local v_u_46 = p_u_40.lib.HushUI
	local v_u_47 = p_u_40.shared.Theme
	local v_u_48 = v_u_47.color
	local v_u_49 = p_u_40.lib.MenuKit
	local v50 = p_u_40.shared.Signal
	local v51 = p_u_40.lib.VirtualPad
	local v_u_52 = {}
	local v_u_53 = nil
	local v_u_54 = nil
	local v_u_55 = nil
	local v_u_56 = nil
	local v_u_57 = nil
	local v_u_58 = {}
	local v_u_59 = nil
	local v_u_60 = false
	local v_u_61 = {}
	local v_u_62 = {}
	local v_u_63 = 0
	local v_u_64 = false
	local v_u_65 = {
		["cctx"] = nil,
		["ui"] = nil,
		["theme"] = nil,
		["config"] = nil,
		["kit"] = nil,
		["cache"] = nil,
		["changed"] = nil,
		["profile"] = nil,
		["party"] = nil,
		["focusTask"] = nil,
		["terminal"] = true,
		["cctx"] = p_u_40,
		["ui"] = v_u_46,
		["theme"] = v_u_47,
		["config"] = p_u_40.config,
		["kit"] = v_u_49,
		["cache"] = {},
		["changed"] = v50.new()
	}
	local v_u_66 = {}
	local v_u_67 = 0
	local function v_u_74(p68, p69) -- name: cacheKey
		if type(p69) == "table" then
			local v70 = {}
			for v71, v72 in p69 do
				if type(v72) ~= "string" and (type(v72) ~= "number" and type(v72) ~= "boolean") then
					continue
				end
				local v73 = tostring(v71) .. "=" .. tostring(v72)
				table.insert(v70, v73)
			end
			table.sort(v70)
			if #v70 > 0 then
				return p68 .. "/" .. table.concat(v70, ",")
			else
				return p68
			end
		else
			return p68
		end
	end
	function v_u_65.fetch(p75, p76, p77) -- name: fetch
		-- upvalues: (copy) v_u_74, (copy) v_u_65, (copy) v_u_66, (copy) p_u_40
		local v78 = v_u_74(p75, p76)
		local v79 = v_u_65.cache[v78]
		if v79 and os.clock() - v79.at < (p77 or 20) then
			return v79.data
		end
		if v_u_66[v78] then
			local v80 = v_u_66[v78]
			local v81 = coroutine.running
			table.insert(v80, v81())
			return coroutine.yield()
		end
		v_u_66[v78] = {}
		local v82 = {
			["what"] = p75
		}
		if type(p76) == "table" then
			for v83, v84 in p76 do
				v82[v83] = v84
			end
		end
		local v85 = p_u_40.net.invoke
		local v86, v87 = pcall(v85, "menu.get", v82)
		if v86 and (type(v87) == "table" and v87.error == nil) then
			v_u_65.cache[v78] = {
				["data"] = v87,
				["at"] = os.clock()
			}
			if p75 == "profile" then
				v_u_65.profile = v87
			end
		else
			v87 = nil
		end
		local v88 = v_u_66[v78]
		v_u_66[v78] = nil
		for _, v89 in v88 do
			task.spawn(v89, v87)
		end
		return v87
	end
	function v_u_65.invalidate(p90) -- name: invalidate
		-- upvalues: (copy) v_u_65
		if p90 then
			for v91 in v_u_65.cache do
				if v91 ~= p90 then
					local v92 = #p90 + 1
					if string.sub(v91, 1, v92) ~= p90 .. "/" then
						continue
					end
				end
				v_u_65.cache[v91] = nil
			end
		else
			table.clear(v_u_65.cache)
		end
	end
	function v_u_65.op(p93) -- name: op
		-- upvalues: (ref) v_u_67, (copy) p_u_40, (copy) v_u_46
		v_u_67 = v_u_67 + 1
		local v94 = v_u_67
		p93.req = "terminal_" .. tostring(v94)
		local v95 = p_u_40.net.fire
		local v96, v97 = pcall(v95, "menu.op", p93)
		if not v96 then
			warn("[HideoutTerminal] menu.op failed:", v97)
			v_u_46.toast("Not connected", "danger", "The profile service is not available yet. Wait a few seconds and try again. If it stays, rejoin HUSH.")
		end
		return v_u_67
	end
	function v_u_65.partyOp(_) -- name: partyOp end
	function v_u_65.compact() -- name: compact
		-- upvalues: (copy) v_u_47
		local v98 = v_u_47.refSize()
		return v98.X < 1320 and true or v98.Y < 640
	end
	function v_u_65.derived() -- name: derived
		-- upvalues: (copy) v_u_65
		local v99 = v_u_65.profile
		local v100
		if type(v99) == "table" then
			local v101 = v99.derived
			v100 = type(v101) == "table" and v99.derived or {}
		else
			v100 = {}
		end
		return v100
	end
	function v_u_65.slots() -- name: slots
		-- upvalues: (copy) v_u_65
		local v102 = v_u_65.profile
		local v103
		if type(v102) == "table" then
			v103 = v102.inv
		else
			v103 = false
		end
		local v104
		if type(v103) == "table" then
			v104 = v103.kit
		else
			v104 = false
		end
		local v105
		if type(v104) == "table" then
			local v106 = v104.slots
			v105 = type(v106) == "table" and v104.slots or {}
		else
			v105 = {}
		end
		return v105
	end
	function v_u_65.myParty() -- name: myParty
		return nil
	end
	function v_u_65.isLeader() -- name: isLeader
		return true
	end
	function v_u_65.partyDeploying() -- name: partyDeploying
		return false
	end
	local function v_u_114(p107, p108, ...) -- name: callPage
		-- upvalues: (copy) v_u_58, (copy) v_u_43
		local v109
		if p107 then
			v109 = v_u_58[p107]
		else
			v109 = p107
		end
		if v109 then
			v109 = v109.tab
		end
		if v109 then
			local v110 = v109[p108]
			if type(v110) == "function" then
				local v111 = v109[p108]
				local v112, v113 = pcall(v111, ...)
				if not v112 then
					warn("[HideoutTerminal] page." .. p108 .. " failed:", v113)
					v_u_43:SetAttribute("ClientError", "terminal " .. tostring(p107) .. "." .. p108 .. ": " .. tostring(v113))
				end
			end
		end
	end
	function v_u_65.openTask(p115) -- name: openTask
		-- upvalues: (copy) v_u_65, (ref) v_u_59, (copy) v_u_58, (copy) v_u_114, (copy) v_u_52
		v_u_65.focusTask = p115
		if v_u_59 == "tasks" and v_u_58.tasks then
			v_u_114("tasks", "refresh", "focus")
		else
			v_u_52.open("tasks")
		end
	end
	function v_u_65.setTab(p116) -- name: setTab
		-- upvalues: (ref) v_u_5, (copy) v_u_52
		if v_u_5[p116] then
			v_u_52.open(p116)
		end
	end
	function v_u_65.firstOpenTask(_) -- name: firstOpenTask
		return nil
	end
	local v_u_124 = p_u_40.net.listen("menu.state", function(p117)
		-- upvalues: (ref) v_u_64, (copy) v_u_65, (ref) v_u_56, (copy) v_u_49, (ref) v_u_60, (copy) v_u_114, (ref) v_u_59
		if not v_u_64 and type(p117) == "table" then
			local v118 = p117.profile
			if type(v118) == "table" then
				v_u_65.profile = p117.profile
				local v119 = p117.reason or "push"
				if v119 ~= "load" then
					v_u_65.invalidate("tasks")
					v_u_65.invalidate("traders")
				end
				v_u_65.changed:Fire("profile", v119)
				local v120 = v_u_56
				if v120 and v120.Parent then
					local v121 = v_u_65.profile
					local v122
					if type(v121) == "table" then
						v122 = v_u_65.profile.cash
					else
						v122 = false
					end
					local v123 = tonumber(v122) or 0
					v120.Text = v_u_49.money(v123)
				end
				if v_u_60 then
					v_u_114(v_u_59, "refresh", "profile")
				end
				return
			end
		end
	end)
	table.insert(v_u_62, function()
		-- upvalues: (copy) v_u_124
		local v125 = v_u_124
		if typeof(v125) == "RBXScriptConnection" then
			v_u_124:Disconnect()
		else
			local v126 = v_u_124
			if type(v126) == "function" then
				local v127 = v_u_124
				pcall(v127)
			end
		end
	end)
	local v_u_128 = {
		["buy"] = true,
		["sell"] = true,
		["taskAccept"] = true,
		["taskHandIn"] = true,
		["gsCraft"] = true,
		["gsSwap"] = true,
		["gsStrip"] = true,
		["traderPartner"] = true,
		["traderStamm"] = true
	}
	local v_u_139 = p_u_40.net.listen("menu.result", function(p129)
		-- upvalues: (ref) v_u_64, (copy) v_u_128, (ref) v_u_60, (ref) v_u_5, (copy) v_u_65, (copy) v_u_114, (ref) v_u_59, (copy) p_u_40, (copy) v_u_46, (copy) v_u_47
		if v_u_64 or type(p129) ~= "table" then
			return
		end
		local v130 = p129.op or ""
		local v131 = tostring(v130)
		if not v_u_128[v131] then
			if string.sub(v131, 1, 4) == "clan" and (v_u_60 and v_u_5.clan ~= nil) then
				v_u_65.changed:Fire("result", p129)
				v_u_114(v_u_59, "refresh", "result", p129)
			end
			return
		end
		v_u_65.invalidate("traders")
		v_u_65.invalidate("tasks")
		if not v_u_60 then
			return
		end
		if p129.ok then
			local v132 = p129.msg
			local v133
			if type(v132) == "string" and p129.msg ~= "" then
				v133 = p129.msg
			else
				v133 = nil
			end
			if v131 == "taskHandIn" then
				local v134 = p129.data
				if type(v134) == "table" and p129.data.completed == true then
					local v135 = p_u_40.lib.MenuTasks
					local v136 = v135 and v135.rewardModal
					if v136 then
						local v137 = v135.rewardModal
						local v138 = v_u_65
						v136 = pcall(v137, v138, p129)
					end
					if not v136 and v133 then
						v_u_46.toast(v133, "success")
					end
					if v131 == "buy" or v131 == "sell" then
						v_u_46.sound(v_u_47.sounds.purchase)
					end
				else
					if v133 then
						v_u_46.toast(v133, "success")
					end
					if v131 == "buy" or v131 == "sell" then
						v_u_46.sound(v_u_47.sounds.purchase)
					end
				end
			else
				if v133 then
					v_u_46.toast(v133, "success")
				end
				if v131 == "buy" or v131 == "sell" then
					v_u_46.sound(v_u_47.sounds.purchase)
				end
			end
			v_u_65.changed:Fire("result", p129)
			v_u_114(v_u_59, "refresh", "result", p129)
		else
			v_u_65.changed:Fire("result", p129)
			v_u_114(v_u_59, "refresh", "result", p129)
		end
	end)
	table.insert(v_u_62, function()
		-- upvalues: (copy) v_u_139
		local v140 = v_u_139
		if typeof(v140) == "RBXScriptConnection" then
			v_u_139:Disconnect()
		else
			local v141 = v_u_139
			if type(v141) == "function" then
				local v142 = v_u_139
				pcall(v142)
			end
		end
	end)
	local function v_u_154(p143) -- name: pageFor
		-- upvalues: (copy) v_u_58, (ref) v_u_57, (copy) v_u_46, (copy) p_u_40, (ref) v_u_5, (copy) v_u_65, (copy) v_u_43, (copy) v_u_49
		local v144 = v_u_58[p143]
		if v144 then
			return v144
		end
		local v145 = v_u_57
		if not v145 then
			return nil
		end
		local v146 = v_u_46.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Name"] = "Page_" .. p143,
			["Position"] = UDim2.fromOffset(-12, -2),
			["Size"] = UDim2.new(1, 24, 1, -6)
		}, v145)
		local v147 = {
			["frame"] = nil,
			["tab"] = nil,
			["frame"] = v146
		}
		v_u_58[p143] = v147
		local v148 = p_u_40.lib[v_u_5[p143]]
		if type(v148) == "table" then
			local v149 = v148.new
			if type(v149) == "function" then
				local v150 = v148.new
				local v151 = v_u_65
				local v152, v153 = pcall(v150, v151, v146)
				if v152 then
					v147.tab = v153
					return v147
				end
				warn("[HideoutTerminal] page failed:", p143, v153)
				v_u_43:SetAttribute("ClientError", "terminal page " .. p143 .. ": " .. tostring(v153))
				v_u_49.empty(v146, "This screen failed to load. " .. tostring(v153))
			end
		end
		return v147
	end
	local function v_u_175() -- name: build
		-- upvalues: (copy) v_u_46, (copy) v_u_47, (ref) v_u_53, (copy) v_u_48, (ref) v_u_4, (ref) v_u_59, (copy) v_u_52, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57, (ref) v_u_54, (copy) v_u_65, (copy) v_u_49
		local v155, v156 = v_u_46.screen("HushHideoutTerminal", v_u_47.layer.inventory)
		v_u_53 = v155
		local v157 = v_u_46.topInset()
		local v158 = v_u_46.new
		local v159 = {
			["Name"] = "Terminal",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		}
		local v160 = UDim2.new
		local v161 = v157 / 2
		v159.Position = v160(0.5, 0, 0.5, (math.floor(v161)))
		v159.Size = UDim2.new(1, -32, 1, -(v157 + 32))
		v159.BackgroundColor3 = v_u_48.bg
		v159.BackgroundTransparency = v_u_47.alpha.panel
		local v162 = v158("Frame", v159, v156)
		v_u_46.stroke(v162, v_u_48.line)
		v_u_46.new("UISizeConstraint", {
			["MaxSize"] = Vector2.new(1760, 980)
		}, v162)
		v_u_46.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_48.accent,
			["Size"] = UDim2.fromOffset(48, 2)
		}, v162)
		local v163 = v_u_46.new("Frame", {
			["Name"] = "Header",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 60)
		}, v162)
		v_u_46.label({
			["parent"] = nil,
			["text"] = "Terminal",
			["style"] = "h2",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v163,
			["position"] = UDim2.fromOffset(20, 8),
			["size"] = UDim2.fromOffset(170, 28)
		})
		local v164 = v_u_46.hint("menu")
		v_u_46.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v163,
			["text"] = v164 == "" and "HIDEOUT  /  TRADER LINE" or "HIDEOUT  /  TRADER LINE  /  CLOSE " .. v164,
			["color"] = v_u_48.text2,
			["position"] = UDim2.fromOffset(20, 36),
			["size"] = UDim2.fromOffset(300, 14)
		})
		local v165 = v_u_46.tabs
		local v166 = {
			["parent"] = nil,
			["name"] = "Tabs",
			["position"] = nil,
			["size"] = nil,
			["tabs"] = nil,
			["selected"] = nil,
			["onChange"] = nil,
			["parent"] = v163,
			["position"] = UDim2.fromOffset(340, 8)
		}
		local v167
		if #v_u_4 > 2 then
			v167 = UDim2.new(1, -610, 0, v_u_47.touch(44))
		else
			v167 = UDim2.new(0, 300, 0, v_u_47.touch(44))
		end
		v166.size = v167
		v166.tabs = v_u_4
		v166.selected = v_u_59 or "traders"
		function v166.onChange(p168) -- name: onChange
			-- upvalues: (ref) v_u_52
			v_u_52.open(p168)
		end
		local _, v169 = v165(v166)
		v_u_55 = v169
		v_u_46.closeIcon({
			["parent"] = nil,
			["size"] = 40,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v163,
			["position"] = UDim2.new(1, -10, 0, 10),
			["anchor"] = Vector2.new(1, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_52
				v_u_52.close()
			end
		}).Name = "Close"
		local v170 = v_u_46.new("Frame", {
			["Name"] = "Cash",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -64, 0, 8),
			["Size"] = UDim2.fromOffset(200, 44)
		}, v163)
		v_u_46.label({
			["parent"] = nil,
			["text"] = "Cash",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "right",
			["size"] = nil,
			["parent"] = v170,
			["color"] = v_u_48.text2,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v_u_56 = v_u_46.label({
			["parent"] = nil,
			["name"] = "Value",
			["text"] = "",
			["style"] = "monoL",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v170,
			["color"] = v_u_48.accent,
			["position"] = UDim2.fromOffset(0, 14),
			["size"] = UDim2.new(1, 0, 0, 28)
		})
		v_u_46.divider({
			["parent"] = v162,
			["position"] = UDim2.fromOffset(0, 60),
			["size"] = UDim2.new(1, 0, 0, 1)
		})
		v_u_57 = v_u_46.new("Frame", {
			["Name"] = "Body",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, 61),
			["Size"] = UDim2.new(1, 0, 1, -61)
		}, v162)
		v_u_54 = v162
		local v171 = v_u_56
		if v171 and v171.Parent then
			local v172 = v_u_65.profile
			local v173
			if type(v172) == "table" then
				v173 = v_u_65.profile.cash
			else
				v173 = false
			end
			local v174 = tonumber(v173) or 0
			v171.Text = v_u_49.money(v174)
		end
	end
	local function v_u_179() -- name: teardownUi
		-- upvalues: (copy) v_u_58, (ref) v_u_53, (ref) v_u_54, (ref) v_u_57, (ref) v_u_55, (ref) v_u_56
		for _, v176 in v_u_58 do
			if not v176.tab then
				continue
			end
			local v177 = v176.tab.destroy
			if type(v177) ~= "function" then
				continue
			end
			local v178 = v176.tab.destroy
			pcall(v178)
		end
		table.clear(v_u_58)
		if v_u_53 then
			v_u_53:Destroy()
		end
		v_u_53 = nil
		v_u_54 = nil
		v_u_57 = nil
		v_u_55 = nil
		v_u_56 = nil
	end
	function v_u_52.open(p180) -- name: open
		-- upvalues: (ref) v_u_64, (ref) v_u_5, (ref) v_u_59, (ref) v_u_60, (ref) v_u_54, (copy) v_u_179, (copy) v_u_175, (copy) v_u_46, (copy) v_u_47, (copy) v_u_65, (ref) v_u_56, (copy) v_u_49, (copy) v_u_114, (copy) v_u_58, (copy) v_u_154, (ref) v_u_55, (copy) v_u_43, (ref) v_u_1, (copy) v_u_42
		if not v_u_64 then
			local v181 = not (p180 and v_u_5[p180]) and (v_u_59 or "traders") or p180
			local v182 = v_u_60
			if not (v_u_54 and v_u_54.Parent) then
				v_u_179()
				v_u_175()
			end
			v_u_60 = true
			local v183 = v_u_54
			if not v182 then
				v183.Visible = true
				v_u_46.sound(v_u_47.sounds.open)
				local v184 = UDim2.new
				local v185 = v_u_46.topInset() / 2
				v183.Position = v184(0.5, 0, 0.5, math.floor(v185) + (v_u_47.motion and v_u_47.motion.slide or 12))
				local v186 = v_u_46.tween
				local v187 = {}
				local v188 = UDim2.new
				local v189 = v_u_46.topInset() / 2
				v187.Position = v188(0.5, 0, 0.5, (math.floor(v189)))
				v186(v183, v187, "slow")
				v_u_46.fade(v183, 0, "slow", {
					["from"] = 1
				})
				local v_u_190 = v_u_65.profile ~= nil
				task.spawn(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_60, (ref) v_u_56, (ref) v_u_49, (copy) v_u_190, (ref) v_u_114, (ref) v_u_59
					if v_u_65.fetch("profile", nil, 0) and v_u_60 then
						v_u_65.changed:Fire("profile", "load")
						local v191 = v_u_56
						if v191 and v191.Parent then
							local v192 = v_u_65.profile
							local v193
							if type(v192) == "table" then
								v193 = v_u_65.profile.cash
							else
								v193 = false
							end
							local v194 = tonumber(v193) or 0
							v191.Text = v_u_49.money(v194)
						end
						if not v_u_190 then
							v_u_114(v_u_59, "refresh", "profile")
						end
					end
				end)
			end
			if v_u_59 ~= v181 or not v182 then
				if v_u_59 and (v_u_59 ~= v181 and v_u_58[v_u_59]) then
					v_u_114(v_u_59, "hide")
					v_u_58[v_u_59].frame.Visible = false
				end
				v_u_59 = v181
				local v195 = v_u_154(v181)
				if v195 then
					v195.frame.Visible = true
					v_u_114(v181, "show")
				end
			end
			if v_u_55 then
				v_u_55.select(v181, true)
			end
			v_u_43:SetAttribute("HideoutTerminal", v181)
			if not v182 then
				if v_u_46.device() == "Gamepad" then
					task.defer(function()
						-- upvalues: (ref) v_u_54, (ref) v_u_60, (ref) v_u_59, (ref) v_u_1
						local v196 = v_u_54
						if v196 and v_u_60 then
							local v197 = v196:FindFirstChild("Tabs", true)
							if v197 then
								local v198 = v_u_59
								v197 = v197:FindFirstChild("Tab_" .. tostring(v198), true)
							end
							if v197 and v197:IsA("GuiObject") then
								v_u_1.SelectedObject = v197
							end
						end
					end)
				end
				if v_u_42.onOpened then
					task.spawn(v_u_42.onOpened)
				end
			end
		end
	end
	function v_u_52.close() -- name: close
		-- upvalues: (ref) v_u_60, (copy) v_u_114, (ref) v_u_59, (ref) v_u_54, (ref) v_u_1, (copy) v_u_46, (copy) v_u_47, (copy) v_u_43, (copy) v_u_42
		if v_u_60 then
			v_u_60 = false
			v_u_114(v_u_59, "hide")
			local v199 = v_u_54
			if v199 then
				if v_u_1.SelectedObject and v_u_1.SelectedObject:IsDescendantOf(v199) then
					v_u_1.SelectedObject = nil
				end
				v_u_46.hideTooltip()
				v_u_46.sound(v_u_47.sounds.close)
				v199.Visible = false
			end
			v_u_43:SetAttribute("HideoutTerminal", "")
			if v_u_42.onClosed then
				task.spawn(v_u_42.onClosed)
			end
		end
	end
	function v_u_52.isOpen() -- name: isOpen
		-- upvalues: (ref) v_u_60
		return v_u_60
	end
	function v_u_52.tab() -- name: tab
		-- upvalues: (ref) v_u_60, (ref) v_u_59
		if v_u_60 then
			return v_u_59
		else
			return nil
		end
	end
	function v_u_52.rebuild() -- name: rebuild
		-- upvalues: (ref) v_u_64, (ref) v_u_60, (ref) v_u_59, (copy) v_u_179, (copy) v_u_52
		if not v_u_64 then
			local v200 = v_u_60
			local v201 = v_u_59
			v_u_179()
			v_u_60 = false
			v_u_59 = nil
			if v200 then
				v_u_52.open(v201)
			end
		end
	end
	function v_u_52.step(p202) -- name: step
		-- upvalues: (ref) v_u_60, (ref) v_u_63, (copy) v_u_114, (ref) v_u_59
		if v_u_60 then
			v_u_63 = v_u_63 + p202
			if v_u_63 >= 0.25 then
				v_u_63 = 0
				v_u_114(v_u_59, "tick")
			end
		end
	end
	function v_u_52.destroy() -- name: destroy
		-- upvalues: (ref) v_u_64, (copy) v_u_52, (copy) v_u_179, (copy) v_u_61, (copy) v_u_62, (copy) v_u_43
		if not v_u_64 then
			v_u_52.close()
			v_u_64 = true
			v_u_179()
			for _, v203 in v_u_61 do
				v203:Disconnect()
			end
			table.clear(v_u_61)
			for _, v204 in v_u_62 do
				pcall(v204)
			end
			table.clear(v_u_62)
			v_u_43:SetAttribute("HideoutTerminal", "")
		end
	end
	local v205 = v51.InputBegan
	local function v216(p206)
		-- upvalues: (ref) v_u_60, (ref) v_u_64, (copy) v_u_43, (copy) v_u_52, (ref) v_u_4, (ref) v_u_59, (copy) v_u_46, (ref) v_u_54, (ref) v_u_1
		if v_u_60 and not v_u_64 then
			local v207 = v_u_43:FindFirstChildOfClass("PlayerGui")
			if v207 then
				v207 = v207:FindFirstChild("HushModal")
			end
			local v208
			if v207 == nil then
				v208 = false
			else
				v208 = v207:FindFirstChild("Modal", true) ~= nil
			end
			if v208 then
				return
			elseif p206.KeyCode == Enum.KeyCode.ButtonB then
				v_u_52.close()
			elseif p206.KeyCode == Enum.KeyCode.ButtonL1 or p206.KeyCode == Enum.KeyCode.ButtonR1 then
				local v209 = 1
				for v210, v211 in v_u_4 do
					if v211.id ~= v_u_59 then
						continue
					end
					v209 = v210
				end
				local v212 = p206.KeyCode == Enum.KeyCode.ButtonL1 and -1 or 1
				v_u_52.open(v_u_4[(v209 - 1 + v212) % #v_u_4 + 1].id)
				if v_u_46.device() ~= "Gamepad" then
					return
				end
				task.defer(function()
					-- upvalues: (ref) v_u_54, (ref) v_u_60, (ref) v_u_59, (ref) v_u_1
					local v213 = v_u_54
					if v213 and v_u_60 then
						local v214 = v213:FindFirstChild("Tabs", true)
						if v214 then
							local v215 = v_u_59
							v214 = v214:FindFirstChild("Tab_" .. tostring(v215), true)
						end
						if v214 and v214:IsA("GuiObject") then
							v_u_1.SelectedObject = v214
						end
					end
				end)
			end
		else
			return
		end
	end
	table.insert(v_u_61, v205:Connect(v216))
	v_u_43:SetAttribute("HideoutTerminal", "")
	v_u_52.context = v_u_65
	return v_u_52
end
return v3