-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GlobeBench

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("Theme"))
local v5 = require(v3:WaitForChild("GlobeMath"))
local v_u_6 = require(script.Parent:WaitForChild("GlobeDots"))
local v_u_7 = require(script.Parent:WaitForChild("GlobeView"))
local v_u_8 = v1.LocalPlayer
local v_u_9 = v5.CONST
local v_u_10 = os.clock
local v_u_11 = {
	["TUNING"] = {
		["RUN_S"] = 6,
		["IDLE_FRAMES"] = 120,
		["REST_FRAMES"] = 120,
		["TIER_D"] = nil,
		["SLOW_DELAY"] = 0.3,
		["FLICK_ZOOMS"] = nil,
		["GATE_ALLOC_PHONE"] = 1200,
		["GATE_P99_PC"] = 25,
		["P99_ABOVE_MEDIAN"] = 8,
		["GATE_OVER_BASE"] = 0.05,
		["GATE_HOLES_PC"] = 0.02,
		["GATE_HOLES_PHONE"] = 0.1,
		["GATE_CONTOUR_PX"] = 28,
		["BURN_MAX_MS"] = 100,
		["BURN_MAX_S"] = 300,
		["GATE_REST_MS"] = 1.5,
		["GATE_REST_REL"] = 0.1,
		["ABS_P95"] = nil,
		["ZOOM_FACTOR"] = 1.25,
		["INSTANCE_LIMIT"] = nil,
		["TIER_D"] = {
			["high"] = 772,
			["mid"] = 600,
			["low"] = 340
		},
		["FLICK_ZOOMS"] = { 8, 16, 32 },
		["ABS_P95"] = {
			["high"] = 5,
			["mid"] = 4,
			["low"] = 1.33
		},
		["INSTANCE_LIMIT"] = {
			["high"] = 720,
			["mid"] = 460,
			["low"] = 320
		}
	}
}
local v_u_12 = v_u_11.TUNING
local function v_u_14(p13) -- name: fmt
	return ("%.2f"):format(p13)
end
local function v_u_17(p15) -- name: wait
	-- upvalues: (copy) v_u_10, (copy) v_u_2
	local v16 = v_u_10()
	while v_u_10() - v16 < p15 do
		v_u_2.Heartbeat:Wait()
	end
end
local function v_u_21(p18, p19) -- name: settle
	-- upvalues: (copy) v_u_10, (copy) v_u_17, (copy) v_u_2
	local v20 = v_u_10()
	v_u_17(0.35)
	while v_u_10() - v20 < p19 and (p18.conns() ~= 0 or p18.d.pending()) do
		v_u_2.Heartbeat:Wait()
	end
	return v_u_10() - v20
end
local function v_u_38(p22) -- name: refOnce
	-- upvalues: (copy) v_u_8, (copy) v_u_10
	local v23, v24
	if p22 then
		v23 = Instance.new("ScreenGui")
		v23.Name = "GlobeBenchRef"
		v23.Parent = v_u_8:WaitForChild("PlayerGui")
		v24 = Instance.new("Frame")
		v24.BackgroundTransparency = 1
		v24.Size = UDim2.fromOffset(1000, 1000)
		v24.Parent = v23
	else
		v24 = nil
		v23 = nil
	end
	local v25 = {}
	for v26 = 1, 2800 do
		local v27 = Instance.new("Frame")
		if p22 then
			v27.BackgroundTransparency = p22 == "opaque" and 0 or 1
			v27.Size = UDim2.fromOffset(3, 3)
			v27.Parent = v24
		end
		v25[v26] = v27
	end
	local v28 = {}
	for v29 = 1, 12 do
		local v30 = v_u_10()
		for v31 = 1, 2800 do
			v25[v31].Position = UDim2.fromOffset(v29 * 3 + v31 % 7, v29 * 5 + v31 % 11)
		end
		v28[v29] = (v_u_10() - v30) * 1000
	end
	if v23 then
		v23:Destroy()
	else
		for v32 = 1, 2800 do
			v25[v32]:Destroy()
		end
	end
	if #v28 == 0 then
		return 0
	end
	local v33 = table.clone(v28)
	table.sort(v33)
	local v34 = #v33
	local v35 = 0.5 * #v33 + 0.5
	local v36 = math.floor(v35)
	local v37 = math.min(v34, v36)
	return v33[math.max(1, v37)]
end
function v_u_11.ref() -- name: ref
	-- upvalues: (copy) v_u_38
	return {
		["opaque"] = v_u_38("opaque"),
		["tree"] = v_u_38("clear"),
		["burst"] = v_u_38(nil)
	}
end
local function v_u_53(p39) -- name: contourSpacing
	-- upvalues: (copy) v_u_4
	local v40 = p39.sample(100000)
	local v41 = v_u_4.uiScale()
	local v42 = {}
	for _, v43 in v40 do
		if v43.kind ~= 2 then
			continue
		end
		local v44 = v43.frame.AbsolutePosition
		v42[#v42 + 1] = { v44.X / v41, v44.Y / v41 }
		if #v42 < 500 then
			continue
		end
	end
	if #v42 < 8 then
		return nil, #v42
	end
	local v45 = 0
	for v46 = 1, #v42 do
		local v47 = v42[v46]
		local v48 = (1 / 0)
		for v49 = 1, #v42 do
			if v49 == v46 then
				continue
			end
			local v50 = v42[v49][1] - v47[1]
			local v51 = v42[v49][2] - v47[2]
			local v52 = v50 * v50 + v51 * v51
			if v52 >= v48 then
				continue
			end
			v48 = v52
		end
		v45 = v45 + math.sqrt(v48)
	end
	return v45 / #v42, #v42
end
local function v_u_81(p54, p55, p56, p57) -- name: runFrames
	-- upvalues: (copy) v_u_10, (copy) v_u_2
	local v58 = p54.d
	local v59 = v_u_10()
	local v60 = v58._self.steps
	local v61 = collectgarbage("count")
	local v62 = v58.stats()
	local v63 = v59
	local v64 = {}
	local v65 = {}
	local v66 = 0
	local v67 = 0
	local v68 = 0
	local v69 = 0
	while true do
		v_u_2.Heartbeat:Wait()
		local v70 = v_u_10()
		local v71 = v70 - v59
		if p55 <= v71 then
			break
		end
		local v72 = (v70 - v63) * 1000
		v66 = v66 + 1
		v65[v66] = v72
		if v72 > 25 then
			v67 = v67 + 1
		end
		if v72 > 50 then
			v68 = v68 + 1
		end
		local v73, v74, v75 = p56(v71)
		p54.setView(v73, v74, v75)
		local v76 = v58._self.steps
		if v76 == v60 then
			v76 = v60
		else
			v64[#v64 + 1] = v58._self.lastMs
		end
		local v77 = collectgarbage("count")
		if v61 < v77 then
			v69 = v69 + (v77 - v61)
		end
		if p57 then
			p57(v66)
			v61 = v77
			v63 = v70
			v60 = v76
		else
			v61 = v77
			v63 = v70
			v60 = v76
		end
	end
	local v78 = v58.stats()
	local v79 = v78.drawFrames - v62.drawFrames
	local v80 = v78.holeFrames - v62.holeFrames
	return {
		["ms"] = v64,
		["dts"] = v65,
		["frames"] = v66,
		["over25"] = v67,
		["over50"] = v68,
		["allocKBs"] = v69 / p55,
		["heapKB"] = v78.heapKB,
		["instances"] = v78.pool,
		["holes"] = v79 <= 0 and 0 or v80 / v79,
		["draws"] = v79,
		["visible"] = v78.visible,
		["capMove"] = v78.capMove,
		["capRest"] = v78.capRest,
		["calC"] = v78.calC,
		["thin"] = v78.thin,
		["swaps"] = v78.swaps - v62.swaps
	}
end
local v_u_99 = {
	["rotate"] = function(p82, p83) -- name: rotate
		-- upvalues: (copy) v_u_81, (copy) v_u_12, (copy) v_u_9
		local v84 = v_u_81
		local v85 = v_u_12.RUN_S
		local v_u_86 = 400 / (v_u_9.R1 * (p82.D / 2) * 1 * 0.017453292519943295)
		local v_u_87 = 30
		local v_u_88 = -85
		local v_u_89 = 1
		return v84(p82, v85, function(p90)
			-- upvalues: (copy) v_u_87, (copy) v_u_88, (copy) v_u_86, (copy) v_u_89
			return v_u_87, v_u_88 + v_u_86 * p90, v_u_89
		end, p83)
	end,
	["zoom"] = function(p91, p92) -- name: zoom
		-- upvalues: (copy) v_u_81, (copy) v_u_12
		return v_u_81(p91, v_u_12.RUN_S, function(p93)
			-- upvalues: (ref) v_u_12
			local v94 = 2 * p93 / v_u_12.RUN_S - 1
			local v95 = (1 - math.abs(v94)) * 3.4657359027997265
			return 40.8, -85, math.exp(v95)
		end, p92)
	end,
	["pan"] = function(p96, p97) -- name: pan
		-- upvalues: (copy) v_u_81, (copy) v_u_12
		return v_u_81(p96, v_u_12.RUN_S, function(p98)
			-- upvalues: (ref) v_u_12
			return 40, -100 + 30 * p98 / v_u_12.RUN_S, 4
		end, p97)
	end
}
local v_u_100 = {
	["rotate"] = { 30, -85, 1 },
	["zoom"] = { 40.8, -85, 1 },
	["pan"] = { 40, -100, 4 }
}
local function v_u_112(_, p101) -- name: idle
	-- upvalues: (copy) v_u_10, (copy) v_u_2
	local v102 = v_u_10()
	local v103 = {}
	for v104 = 1, p101 do
		v_u_2.Heartbeat:Wait()
		local v105 = v_u_10()
		v103[v104] = (v105 - v102) * 1000
		v102 = v105
	end
	local v106
	if #v103 == 0 then
		v106 = 0
	else
		local v107 = table.clone(v103)
		table.sort(v107)
		local v108 = #v107
		local v109 = 0.5 * #v107 + 0.5
		local v110 = math.floor(v109)
		local v111 = math.min(v108, v110)
		v106 = v107[math.max(1, v111)]
	end
	return v106, v103
end
function v_u_11.bench(p113) -- name: bench
	-- upvalues: (copy) v_u_11, (copy) v_u_14, (copy) v_u_6, (copy) v_u_12, (copy) v_u_21, (copy) v_u_17, (copy) v_u_112, (copy) v_u_9, (copy) v_u_10, (copy) v_u_81, (copy) v_u_100, (copy) v_u_99, (copy) v_u_8
	local v114 = p113 or {}
	local v115 = v114.tiers or { "high", "mid", "low" }
	local v116 = v114.runs or 3
	local v117 = v114.programs or {
		"rotate",
		"zoom",
		"pan",
		"flick"
	}
	local v_u_118 = {
		["rows"] = {},
		["lines"] = {},
		["fails"] = {},
		["tiers"] = {}
	}
	local v_u_119 = v_u_11.ref()
	v_u_118.ref = v_u_119
	local v120 = ("REF 2800 Position sets, median of 12: opaque frames in a ScreenGui %s ms (the gate), transparent in tree %s, detached %s"):format(("%.2f"):format(v_u_119.opaque), ("%.2f"):format(v_u_119.tree), v_u_14(v_u_119.burst))
	local v121 = v_u_118.lines
	table.insert(v121, v120)
	print("[globe.bench] " .. v120)
	local v122 = v_u_6.TUNING.buildDelay
	for _, v123 in v115 do
		local v124 = v114.slow == true
		local v125 = v_u_6.TUNING
		local v126
		if v124 then
			v126 = v_u_12.SLOW_DELAY
		else
			v126 = v122
		end
		v125.buildDelay = v126
		local v127 = v_u_12.TIER_D[v123] or 772
		local v128 = {
			["tier"] = v123,
			["programs"] = {}
		}
		v_u_118.tiers[v123] = v128
		local v129 = v_u_6.probe({
			["tier"] = v123,
			["D"] = v127 or (v_u_12.TIER_D[v123] or 772)
		})
		v129.place(30, -85, 1)
		v_u_21(v129, 6)
		v_u_17(1)
		local v130 = v_u_112(v129, v_u_12.IDLE_FRAMES)
		local v131 = v129.d.stats()
		v128.base = v130
		v129.destroy()
		local v132 = ("%.2f"):format(v130)
		local v133 = v131.capMove
		local v134 = tostring(v133)
		local v135 = v131.capRest
		local v136 = tostring(v135)
		local v137 = v131.calC and ("%.2f"):format(v131.calC) or "n/a"
		local v138 = ("%s: baseline (idle frames, dots at rest) median %s ms; caps move %s rest %s; calC %s us; slow build %s"):format(v123, v132, v134, v136, tostring(v137), (tostring(v124)))
		local v139 = v_u_118.lines
		table.insert(v139, v138)
		print("[globe.bench] " .. v138)
		for _, v140 in v117 do
			local v141 = {}
			for _, v_u_142 in v140 ~= "flick" and { 0 } or v_u_12.FLICK_ZOOMS do
				local v143 = (1 / 0)
				local v144 = nil
				for _ = 1, v116 do
					local v145 = v_u_6.probe({
						["tier"] = v123,
						["D"] = v127 or (v_u_12.TIER_D[v123] or 772)
					})
					local v146
					if v140 == "flick" then
						v145.place(55, 30, v_u_142)
						v_u_21(v145, 6)
						v_u_17(0.5)
						local v_u_147 = 1800 / (v_u_9.R1 * (v145.D / 2) * v_u_142 * 0.017453292519943295)
						local v_u_148 = 30
						local v_u_149 = v_u_10()
						v146 = v_u_81(v145, 1.5, function(p150)
							-- upvalues: (ref) v_u_10, (ref) v_u_148, (copy) v_u_147, (ref) v_u_149, (copy) v_u_142
							local v151 = v_u_10()
							local v152
							if p150 < 0.8 then
								v152 = 1
							else
								local v153 = 1 - (p150 - 0.8) / 0.7
								v152 = math.max(0, v153)
							end
							v_u_148 = v_u_148 + v_u_147 * (v151 - v_u_149) * v152
							v_u_149 = v151
							return 55, v_u_148, v_u_142
						end)
					else
						local v154 = v_u_100[v140]
						v145.place(v154[1], v154[2], v154[3])
						v_u_21(v145, 6)
						v_u_17(1)
						v146 = v_u_99[v140](v145)
					end
					local v155 = v146.ms
					local v156
					if #v155 == 0 then
						v156 = 0
					else
						local v157 = table.clone(v155)
						table.sort(v157)
						local v158 = #v157
						local v159 = 0.5 * #v157 + 0.5
						local v160 = math.floor(v159)
						local v161 = math.min(v158, v160)
						v156 = v157[math.max(1, v161)]
					end
					v146.p50 = v156
					local v162 = v146.ms
					local v163
					if #v162 == 0 then
						v163 = 0
					else
						local v164 = table.clone(v162)
						table.sort(v164)
						local v165 = #v164
						local v166 = 0.95 * #v164 + 0.5
						local v167 = math.floor(v166)
						local v168 = math.min(v165, v167)
						v163 = v164[math.max(1, v168)]
					end
					v146.p95 = v163
					local v169 = 0
					for _, v170 in v146.ms do
						v169 = math.max(v169, v170)
					end
					v146.max = v169
					local v171 = v146.dts
					local v172
					if #v171 == 0 then
						v172 = 0
					else
						local v173 = table.clone(v171)
						table.sort(v173)
						local v174 = #v173
						local v175 = 0.5 * #v173 + 0.5
						local v176 = math.floor(v175)
						local v177 = math.min(v174, v176)
						v172 = v173[math.max(1, v177)]
					end
					local v178 = v146.dts
					local v179
					if #v178 == 0 then
						v179 = 0
					else
						local v180 = table.clone(v178)
						table.sort(v180)
						local v181 = #v180
						local v182 = 0.95 * #v180 + 0.5
						local v183 = math.floor(v182)
						local v184 = math.min(v181, v183)
						v179 = v180[math.max(1, v184)]
					end
					local v185 = v146.dts
					local v186
					if #v185 == 0 then
						v186 = 0
					else
						local v187 = table.clone(v185)
						table.sort(v187)
						local v188 = #v187
						local v189 = 0.99 * #v187 + 0.5
						local v190 = math.floor(v189)
						local v191 = math.min(v188, v190)
						v186 = v187[math.max(1, v191)]
					end
					local v192 = 0
					for _, v193 in v146.dts do
						v192 = math.max(v192, v193)
					end
					v146.hbP50 = v172
					v146.hbP95 = v179
					v146.hbP99 = v186
					v146.hbMax = v192
					local v194 = 0
					for _, v195 in v146.dts do
						if 1.5 * v130 >= v195 then
							continue
						end
						v194 = v194 + 1
					end
					v146.overBase = v146.frames <= 0 and 0 or v194 / v146.frames
					local v196 = 0
					for _, v197 in v146.dts do
						if 1.5 * v146.hbP50 >= v197 then
							continue
						end
						v196 = v196 + 1
					end
					v146.overOwn = v146.frames <= 0 and 0 or v196 / v146.frames
					v146.dts = nil
					v146.ms = nil
					table.insert(v141, v146)
					if v146.p95 < v143 then
						v143 = v146.p95
					else
						v146 = v144
					end
					v145.destroy()
					v_u_17(0.3)
					v144 = v146
				end
				local v198
				if v140 == "flick" then
					v198 = ("flick z%d"):format(v_u_142)
				else
					v198 = v140
				end
				v144.name = v198
				v144.runs = v141
				local v199 = v128.programs
				table.insert(v199, v144)
				local v200 = ("%.2f"):format(v144.p50)
				local v201 = ("%.2f"):format(v144.p95)
				local v202 = ("%.2f"):format(v144.max)
				local v203 = ("%.2f"):format(v144.hbP50)
				local v204 = ("%.2f"):format(v144.hbP95)
				local v205 = ("%.2f"):format(v144.hbP99)
				local v206 = ("%.2f"):format(v144.hbMax)
				local v207 = v144.frames
				local v208 = v144.over25
				local v209 = v144.over50
				local v210 = v144.overBase * 100
				local v211 = v144.overOwn * 100
				local v212 = v144.allocKBs
				local v213 = math.floor(v212)
				local v214 = v144.holes * 100
				local v215 = v144.visible
				local v216 = v144.instances
				local v217 = v144.heapKB
				local v218 = ("%s %s: step p50 %s p95 %s max %s ms (best of %d); heartbeat p50 %s p95 %s p99 %s max %s; frames %d, >25 ms %d, >50 ms %d, >1.5 base %.1f%%, >1.5 own median %.1f%%; allocKBs %d; holes %.1f%%; visible %d; pool %d; heap %d KB; caps move %d rest %d; swaps %d"):format(v123, v198, v200, v201, v202, v116, v203, v204, v205, v206, v207, v208, v209, v210, v211, v213, v214, v215, v216, math.floor(v217), v144.capMove, v144.capRest, v144.swaps)
				local v219 = v_u_118.lines
				table.insert(v219, v218)
				print("[globe.bench] " .. v218)
				local v220 = v144.capMove <= 0 and 0 or v144.p50 * 1000 / v144.capMove
				local v221 = v144.calC and (("%.2f"):format(v144.calC) or "n/a") or "n/a"
				local v222 = tostring(v221)
				local v223 = v144.calC and (("%.2f"):format(v220 / v144.calC) or "n/a") or "n/a"
				local v224 = ("%s %s: measured cost per wanted dot %.2f us (p50 of the step over the move cap), calibrated c %s us, ratio %s"):format(v123, v198, v220, v222, (tostring(v223)))
				local v225 = v_u_118.lines
				table.insert(v225, v224)
				print("[globe.bench] " .. v224)
				local v226 = v_u_12.ABS_P95[v123] * (v140 ~= "zoom" and 1 or v_u_12.ZOOM_FACTOR)
				local v227 = ("%s %s: step p95 within the absolute gate"):format(v123, v198)
				local v228 = v144.p95 <= v226
				local v229 = ("p95 %s, gate %s"):format(("%.2f"):format(v144.p95), v_u_14(v226))
				local v230 = ("%s %s%s"):format(v228 and "PASS" or "FAIL", v227, v229 == nil and "" or " (" .. tostring(v229) .. ")")
				local v231 = v_u_118.lines
				table.insert(v231, v230)
				print("[globe.bench] " .. v230)
				if not v228 then
					local v232 = v_u_118.fails
					table.insert(v232, v227)
				end
				local v233 = 1.6 * v_u_119.opaque * v144.capMove / 2800 + 0.6
				local v234 = ("%s %s: ratio reference (information, not a gate): p95 %s, ratio gate %s, REF %s, cap %d, %s"):format(v123, v198, ("%.2f"):format(v144.p95), ("%.2f"):format(v233), ("%.2f"):format(v_u_119.opaque), v144.capMove, v144.p95 <= v233 and "inside" or "outside")
				local v235 = v_u_118.lines
				table.insert(v235, v234)
				print("[globe.bench] " .. v234)
				if v140 == "flick" then
					local v236
					if v123 == "low" and v124 then
						v236 = v_u_12.GATE_HOLES_PHONE
					else
						v236 = v_u_12.GATE_HOLES_PC
					end
					local v237 = ("%s %s: hole share under %d percent"):format(v123, v198, v236 * 100)
					local v238 = v144.holes < v236
					local v239 = ("%.1f%%"):format(v144.holes * 100)
					local v240 = ("%s %s%s"):format(v238 and "PASS" or "FAIL", v237, v239 == nil and "" or " (" .. tostring(v239) .. ")")
					local v241 = v_u_118.lines
					table.insert(v241, v240)
					print("[globe.bench] " .. v240)
					if v238 then
						break
					end
					local v242 = v_u_118.fails
					table.insert(v242, v237)
				else
					local v243 = ("%s %s: no step over 25 ms"):format(v123, v198)
					local v244 = v144.max <= 25
					local v245 = ("%.2f"):format(v144.max)
					local v246 = ("%s %s%s"):format(v244 and "PASS" or "FAIL", v243, v245 == nil and "" or " (" .. tostring(v245) .. ")")
					local v247 = v_u_118.lines
					table.insert(v247, v246)
					print("[globe.bench] " .. v246)
					if not v244 then
						local v248 = v_u_118.fails
						table.insert(v248, v243)
					end
					local v249 = ("%s %s: share of frames over 1.5 * base at most 5 percent"):format(v123, v198)
					local v250 = v144.overBase <= v_u_12.GATE_OVER_BASE
					local v251 = ("%.1f%%"):format(v144.overBase * 100)
					local v252 = ("%s %s%s"):format(v250 and "PASS" or "FAIL", v249, v251 == nil and "" or " (" .. tostring(v251) .. ")")
					local v253 = v_u_118.lines
					table.insert(v253, v252)
					print("[globe.bench] " .. v252)
					if not v250 then
						local v254 = v_u_118.fails
						table.insert(v254, v249)
					end
					if v123 == "high" or v123 == "mid" then
						local v255 = v_u_12.GATE_P99_PC
						local v256 = v144.hbP50 + v_u_12.P99_ABOVE_MEDIAN
						local v257 = math.max(v255, v256)
						local v258 = ("%s %s: heartbeat p99 at most 25 ms (or %d ms above the run\'s own median when the Studio window itself runs under 40 FPS)"):format(v123, v198, v_u_12.P99_ABOVE_MEDIAN)
						local v259 = v144.hbP99 <= v257
						local v260 = ("p99 %s, median %s, gate %s"):format(("%.2f"):format(v144.hbP99), ("%.2f"):format(v144.hbP50), v_u_14(v257))
						local v261 = ("%s %s%s"):format(v259 and "PASS" or "FAIL", v258, v260 == nil and "" or " (" .. tostring(v260) .. ")")
						local v262 = v_u_118.lines
						table.insert(v262, v261)
						print("[globe.bench] " .. v261)
						if not v259 then
							local v263 = v_u_118.fails
							table.insert(v263, v258)
						end
					end
					local v264 = ("%s %s: heartbeat max under 50 ms"):format(v123, v198)
					local v265 = v144.hbMax <= 50
					local v266 = ("%.2f"):format(v144.hbMax)
					local v267 = ("%s %s%s"):format(v265 and "PASS" or "FAIL", v264, v266 == nil and "" or " (" .. tostring(v266) .. ")")
					local v268 = v_u_118.lines
					table.insert(v268, v267)
					print("[globe.bench] " .. v267)
					if not v265 then
						local v269 = v_u_118.fails
						table.insert(v269, v264)
					end
					if v123 ~= "low" then
						break
					end
					local v270 = ("low %s: allocKBs at most %d"):format(v198, v_u_12.GATE_ALLOC_PHONE)
					local v271 = v144.allocKBs <= v_u_12.GATE_ALLOC_PHONE
					local v272 = v144.allocKBs
					local v273 = math.floor(v272)
					local v274 = ("%s %s%s"):format(v271 and "PASS" or "FAIL", v270, v273 == nil and "" or " (" .. tostring(v273) .. ")")
					local v275 = v_u_118.lines
					table.insert(v275, v274)
					print("[globe.bench] " .. v274)
					if v271 then
						break
					end
					local v276 = v_u_118.fails
					table.insert(v276, v270)
				end
			end
		end
	end
	v_u_6.TUNING.buildDelay = v122
	v_u_118.pass = #v_u_118.fails == 0
	local v277 = v_u_118.pass and "ALL GATES PASS" or ("FAILED GATES: %d"):format(#v_u_118.fails)
	local v278 = v_u_118.lines
	table.insert(v278, v277)
	print("[globe.bench] " .. v277)
	v_u_118.text = table.concat(v_u_118.lines, "\n")
	local function v281()
		-- upvalues: (ref) v_u_8, (copy) v_u_118, (ref) v_u_14, (copy) v_u_119
		local v279 = v_u_8
		local v280 = ("%s; fails=%d; ref=%s"):format(v_u_118.pass and "PASS" or "FAIL", #v_u_118.fails, v_u_14(v_u_119.opaque))
		v279:SetAttribute("GlobeBench", (string.sub(v280, 1, 900)))
	end
	pcall(v281)
	return v_u_118
end
local function v_u_286(p_u_282, p283) -- name: viewRig
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	return v_u_7.probe({
		["tier"] = p_u_282,
		["D"] = p283,
		["kind"] = p_u_282 == "high" and "pc" or (p_u_282 == "mid" and "tablet" or "phone"),
		["makeDots"] = function(p284, p285) -- name: makeDots
			-- upvalues: (ref) v_u_6, (copy) p_u_282
			return v_u_6.new(p284, {
				["lensR"] = p285.lensR,
				["cx"] = p285.cx,
				["cy"] = p285.cy,
				["tier"] = p_u_282
			})
		end
	})
end
function v_u_11.rest(p287) -- name: rest
	-- upvalues: (copy) v_u_12, (copy) v_u_286, (copy) v_u_17, (copy) v_u_112, (copy) v_u_8
	local v_u_288 = {
		["lines"] = {},
		["tiers"] = {}
	}
	for _, v289 in (p287 or {}).tiers or { "high", "mid", "low" } do
		local v_u_290 = v_u_286(v289, v_u_12.TIER_D[v289] or 772)
		v_u_290.show({
			["noIntro"] = true
		})
		v_u_17(0.5)
		local v291 = v_u_290.dotsLayer
		pcall(function()
			-- upvalues: (copy) v_u_290
			v_u_290.setView(30, -85, 1)
		end)
		v_u_17(3)
		local v292 = {}
		for _, v293 in v_u_290.root:GetDescendants() do
			if not v293:IsA("UIGradient") or (not v293.Parent or v293.Parent.Name ~= "Body") then
				continue
			end
			table.insert(v292, v293)
		end
		v291.Visible = false
		v_u_17(0.3)
		local v294, v295 = v_u_112(nil, v_u_12.REST_FRAMES)
		v291.Visible = true
		v_u_17(0.3)
		local v296, v297 = v_u_112(nil, v_u_12.REST_FRAMES)
		for _, v298 in v292 do
			v298.Enabled = false
		end
		v_u_17(0.3)
		local v299 = v_u_112(nil, v_u_12.REST_FRAMES)
		v291.Visible = false
		v_u_17(0.3)
		local v300 = v_u_112(nil, v_u_12.REST_FRAMES)
		for _, v301 in v292 do
			v301.Enabled = true
		end
		v291.Visible = true
		local v302 = true
		for _, v303 in { v295, v297 } do
			for _, v304 in v303 do
				local v305 = v304 - 16.667
				if math.abs(v305) <= 1 then
					continue
				end
				v302 = false
			end
		end
		local v306 = v296 - v294
		local v307 = v_u_12.GATE_REST_MS
		local v308 = v_u_12.GATE_REST_REL * v294
		local v309 = math.max(v307, v308)
		local v310 = v296 - v299
		local v311 = 0
		for _, v312 in v291:GetDescendants() do
			if not v312:IsA("Frame") or (not v312.Visible or v312.BackgroundTransparency >= 1) then
				continue
			end
			v311 = v311 + 1
		end
		local v313 = {
			["tier"] = v289,
			["off"] = v294,
			["on"] = v296,
			["diff"] = v306,
			["gate"] = v309,
			["vsync"] = v302,
			["grad"] = v310,
			["offNoGrad"] = v300,
			["onNoGrad"] = v299,
			["dots"] = v311
		}
		v_u_288.tiers[v289] = v313
		local v314 = ("%.2f"):format(v294)
		local v315 = ("%.2f"):format(v296)
		local v316 = ("%.2f"):format(v306)
		local v317 = ("%.2f"):format(v309)
		local v318 = v302 and "IN STUDIO NOT MEASURABLE (VSync bound, every frame within 1 ms of 16.7 ms)" or (v306 <= v309 and "PASS" or "FAIL")
		local v319 = ("%.2f"):format(v300)
		local v320 = ("%.2f"):format(v299)
		local v321 = ("%.2f"):format(v310)
		local v322 = #v292
		local v323 = v313.dots
		local v324 = ("%s: median heartbeat dots hidden %s ms, dots shown %s ms (difference %s, gate %s) %s; without the body gradient: hidden %s, shown %s (gradient costs %s ms, gate 0.5 ms); %d gradient(s) on the body; visible dots %s"):format(v289, v314, v315, v316, v317, v318, v319, v320, v321, v322, (tostring(v323)))
		local v325 = v_u_288.lines
		table.insert(v325, v324)
		print("[globe.rest] " .. v324)
		v_u_290.destroy()
		v_u_17(0.3)
	end
	v_u_288.text = table.concat(v_u_288.lines, "\n")
	local function v328()
		-- upvalues: (ref) v_u_8, (copy) v_u_288
		local v326 = v_u_8
		local v327 = "rest: " .. v_u_288.text
		v326:SetAttribute("GlobeBench", (string.sub(v327, 1, 900)))
	end
	pcall(v328)
	return v_u_288
end
local function v_u_335(p329, p330) -- name: countBelow
	local v331 = 0
	for _, v334 in p329:GetDescendants() do
		local v333 = false
		if p330 then
			while v334 and v334 ~= p329 do
				if v334 == p330 then
					v333 = true
					break
				end
				local v334 = v334.Parent
			end
		end
		if v333 then
			continue
		end
		v331 = v331 + 1
	end
	return v331
end
function v_u_11.instances(p336) -- name: instances
	-- upvalues: (copy) v_u_12, (copy) v_u_286, (copy) v_u_17, (copy) v_u_335, (copy) v_u_8
	local v_u_337 = {
		["lines"] = {},
		["tiers"] = {}
	}
	for _, v338 in (p336 or {}).tiers or { "high", "mid", "low" } do
		local v_u_339 = v_u_286(v338, v_u_12.TIER_D[v338] or 772)
		v_u_339.show({
			["noIntro"] = true
		})
		v_u_17(0.4)
		local v340 = v_u_335(v_u_339.root, v_u_339.dotsLayer)
		pcall(function()
			-- upvalues: (copy) v_u_339
			v_u_339.setFake(40)
		end)
		v_u_17(0.6)
		local v341 = v_u_335(v_u_339.root, v_u_339.dotsLayer)
		pcall(function()
			-- upvalues: (copy) v_u_339
			v_u_339.setFake(0)
		end)
		v_u_17(0.3)
		local v342 = v_u_335(v_u_339.gui, v_u_339.dotsLayer)
		for _ = 1, 20 do
			v_u_339.hide()
			v_u_17(0.06)
			v_u_339.show({
				["noIntro"] = true
			})
			v_u_17(0.06)
		end
		v_u_17(1)
		local v343 = v_u_335(v_u_339.gui, v_u_339.dotsLayer)
		v_u_337.tiers[v338] = {
			["scaffold"] = v340,
			["fake40"] = v341,
			["switchBefore"] = v342,
			["switchAfter"] = v343
		}
		local v344 = ("%s: scaffold instances (without the dot pool) %d with the five places, %d with globe.fake 40 (limit %d: %s); 20 tab switches: %d before, %d after (leak %d: %s)"):format(v338, v340, v341, v_u_12.INSTANCE_LIMIT[v338], v341 <= v_u_12.INSTANCE_LIMIT[v338] and "PASS" or "FAIL", v342, v343, v343 - v342, v343 <= v342 and "PASS" or "FAIL")
		local v345 = v_u_337.lines
		table.insert(v345, v344)
		print("[globe.inst] " .. v344)
		v_u_339.destroy()
		v_u_17(0.3)
	end
	v_u_337.text = table.concat(v_u_337.lines, "\n")
	local function v348()
		-- upvalues: (ref) v_u_8, (copy) v_u_337
		local v346 = v_u_8
		local v347 = "inst: " .. v_u_337.text
		v346:SetAttribute("GlobeBench", (string.sub(v347, 1, 900)))
	end
	pcall(v348)
	return v_u_337
end
function v_u_11.drag(p349) -- name: drag
	-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_21, (copy) v_u_17, (copy) v_u_53, (copy) v_u_81, (copy) v_u_9, (copy) v_u_8
	local v350 = (p349 or {}).tiers or { "low" }
	local v351 = v_u_6.TUNING.buildDelay
	local v_u_352 = {
		["lines"] = {},
		["tiers"] = {}
	}
	for _, v353 in v350 do
		local v354 = v_u_12.TIER_D[v353] or 340
		local v_u_355 = v_u_6.probe({
			["tier"] = v353,
			["D"] = v354 or (v_u_12.TIER_D[v353] or 772)
		})
		v_u_355.place(30, -85, 1)
		v_u_21(v_u_355, 6)
		v_u_17(1)
		local v356 = v_u_53(v_u_355.d)
		local v_u_357 = {}
		local function v360(p358)
			-- upvalues: (ref) v_u_53, (copy) v_u_355, (copy) v_u_357
			local v359 = p358 % 30 == 0 and v_u_53(v_u_355.d)
			if v359 then
				v_u_357[#v_u_357 + 1] = v359
			end
		end
		local v361 = v_u_81
		local v362 = v_u_12.RUN_S
		local v_u_363 = 400 / (v_u_9.R1 * (v_u_355.D / 2) * 1 * 0.017453292519943295)
		local v_u_364 = 30
		local v_u_365 = -85
		local v_u_366 = 1
		v361(v_u_355, v362, function(p367)
			-- upvalues: (copy) v_u_364, (copy) v_u_365, (copy) v_u_363, (copy) v_u_366
			return v_u_364, v_u_365 + v_u_363 * p367, v_u_366
		end, v360)
		local v368 = 0
		for _, v369 in v_u_357 do
			v368 = v368 + v369
		end
		local v370 = #v_u_357 <= 0 and 0 or v368 / #v_u_357
		local v371 = 0
		for _, v372 in v_u_357 do
			v371 = math.max(v371, v372)
		end
		v_u_352.tiers[v353] = {
			["still"] = v356,
			["mean"] = v370,
			["worst"] = v371,
			["n"] = #v_u_357
		}
		local v373 = v356 and ("%.2f"):format(v356) or "n/a"
		local v374 = ("%s: mean contour spacing at rest %s px, while dragging at 400 px/s %s px (worst sample %s, %d samples), gate %d design px: %s"):format(v353, tostring(v373), ("%.2f"):format(v370), ("%.2f"):format(v371), #v_u_357, v_u_12.GATE_CONTOUR_PX, v370 <= v_u_12.GATE_CONTOUR_PX and #v_u_357 > 0 and "PASS" or "FAIL")
		local v375 = v_u_352.lines
		table.insert(v375, v374)
		print("[globe.drag] " .. v374)
		v_u_355.destroy()
		v_u_17(0.3)
	end
	v_u_6.TUNING.buildDelay = v351
	v_u_352.text = table.concat(v_u_352.lines, "\n")
	local function v378()
		-- upvalues: (ref) v_u_8, (copy) v_u_352
		local v376 = v_u_8
		local v377 = "drag: " .. v_u_352.text
		v376:SetAttribute("GlobeBench", (string.sub(v377, 1, 900)))
	end
	pcall(v378)
	return v_u_352
end
function v_u_11.command(p379) -- name: command
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_12, (copy) v_u_10, (copy) v_u_2
	local v_u_380 = false
	local function v_u_384(p381) -- name: tiersOf
		local v382 = {}
		for _, v383 in p381 do
			if v383 ~= "high" and (v383 ~= "mid" and v383 ~= "low") then
				continue
			end
			table.insert(v382, v383)
		end
		if #v382 > 0 then
			return v382
		else
			return nil
		end
	end
	local function v397(p_u_385)
		-- upvalues: (ref) v_u_11, (copy) v_u_384, (ref) v_u_380, (ref) v_u_8
		local v_u_386 = false
		for _, v387 in p_u_385 do
			if v387 ~= "quick" then
				continue
			end
			v_u_386 = true
		end
		local function v_u_388()
			-- upvalues: (ref) v_u_11, (ref) v_u_384, (copy) p_u_385, (ref) v_u_386
			v_u_11.bench({
				["tiers"] = nil,
				["runs"] = nil,
				["slow"] = nil,
				["tiers"] = v_u_384(p_u_385),
				["runs"] = v_u_386 and 1 or 3
			})
		end
		local v389
		if v_u_380 then
			v389 = "a globe bench is running already"
		else
			v_u_380 = true
			task.spawn(function()
				-- upvalues: (copy) v_u_388, (ref) v_u_380, (ref) v_u_8
				local v390 = v_u_388
				local v391, v_u_392 = pcall(v390)
				v_u_380 = false
				if not v391 then
					local function v396()
						-- upvalues: (ref) v_u_8, (copy) v_u_392
						local v393 = v_u_8
						local v394 = v_u_392
						local v395 = "error: " .. tostring(v394)
						v393:SetAttribute("GlobeBench", (string.sub(v395, 1, 900)))
					end
					pcall(v396)
					warn("[globe] bench error: " .. tostring(v_u_392))
				end
			end)
			v389 = "globe.bench started; the result stands in the attribute GlobeBench of the LocalPlayer and in the output"
		end
		return v389
	end
	pcall(p379, "globe.bench", v397)
	local function v407(p_u_398)
		-- upvalues: (ref) v_u_11, (copy) v_u_384, (ref) v_u_380, (ref) v_u_8
		local function v_u_399()
			-- upvalues: (ref) v_u_11, (ref) v_u_384, (copy) p_u_398
			v_u_11.rest({
				["tiers"] = v_u_384(p_u_398)
			})
		end
		if v_u_380 then
			return "a globe bench is running already"
		end
		v_u_380 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_399, (ref) v_u_380, (ref) v_u_8
			local v400 = v_u_399
			local v401, v_u_402 = pcall(v400)
			v_u_380 = false
			if not v401 then
				local function v406()
					-- upvalues: (ref) v_u_8, (copy) v_u_402
					local v403 = v_u_8
					local v404 = v_u_402
					local v405 = "error: " .. tostring(v404)
					v403:SetAttribute("GlobeBench", (string.sub(v405, 1, 900)))
				end
				pcall(v406)
				warn("[globe] bench error: " .. tostring(v_u_402))
			end
		end)
		return "globe.rest started; the result stands in the attribute GlobeBench of the LocalPlayer and in the output"
	end
	pcall(p379, "globe.rest", v407)
	local function v417(p_u_408)
		-- upvalues: (ref) v_u_11, (copy) v_u_384, (ref) v_u_380, (ref) v_u_8
		local function v_u_409()
			-- upvalues: (ref) v_u_11, (ref) v_u_384, (copy) p_u_408
			v_u_11.instances({
				["tiers"] = v_u_384(p_u_408)
			})
		end
		if v_u_380 then
			return "a globe bench is running already"
		end
		v_u_380 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_409, (ref) v_u_380, (ref) v_u_8
			local v410 = v_u_409
			local v411, v_u_412 = pcall(v410)
			v_u_380 = false
			if not v411 then
				local function v416()
					-- upvalues: (ref) v_u_8, (copy) v_u_412
					local v413 = v_u_8
					local v414 = v_u_412
					local v415 = "error: " .. tostring(v414)
					v413:SetAttribute("GlobeBench", (string.sub(v415, 1, 900)))
				end
				pcall(v416)
				warn("[globe] bench error: " .. tostring(v_u_412))
			end
		end)
		return "globe.inst started; the result stands in the attribute GlobeBench of the LocalPlayer and in the output"
	end
	pcall(p379, "globe.inst", v417)
	local function v427(p_u_418)
		-- upvalues: (ref) v_u_11, (copy) v_u_384, (ref) v_u_380, (ref) v_u_8
		local function v_u_419()
			-- upvalues: (ref) v_u_11, (ref) v_u_384, (copy) p_u_418
			v_u_11.drag({
				["tiers"] = v_u_384(p_u_418)
			})
		end
		if v_u_380 then
			return "a globe bench is running already"
		end
		v_u_380 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_419, (ref) v_u_380, (ref) v_u_8
			local v420 = v_u_419
			local v421, v_u_422 = pcall(v420)
			v_u_380 = false
			if not v421 then
				local function v426()
					-- upvalues: (ref) v_u_8, (copy) v_u_422
					local v423 = v_u_8
					local v424 = v_u_422
					local v425 = "error: " .. tostring(v424)
					v423:SetAttribute("GlobeBench", (string.sub(v425, 1, 900)))
				end
				pcall(v426)
				warn("[globe] bench error: " .. tostring(v_u_422))
			end
		end)
		return "globe.drag started; the result stands in the attribute GlobeBench of the LocalPlayer and in the output"
	end
	pcall(p379, "globe.drag", v427)
	local v_u_428 = nil
	local function v434(p429)
		-- upvalues: (ref) v_u_428, (ref) v_u_12, (ref) v_u_10, (ref) v_u_2
		local v430 = p429[1]
		if v430 == nil or (v430 == "off" or v430 == "0") then
			if v_u_428 then
				v_u_428:Disconnect()
				v_u_428 = nil
			end
			return "globe.burn: off"
		end
		local v_u_431 = tonumber(v430)
		if v_u_431 == nil or (v_u_431 ~= v_u_431 or (v_u_431 < 0 or v_u_12.BURN_MAX_MS < v_u_431)) then
			return ("usage: globe.burn <0 to %d ms per frame> | off"):format(v_u_12.BURN_MAX_MS)
		end
		if v_u_428 then
			v_u_428:Disconnect()
			v_u_428 = nil
		end
		local v_u_432 = v_u_10()
		v_u_428 = v_u_2.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_10, (copy) v_u_432, (ref) v_u_12, (ref) v_u_428, (copy) v_u_431
			local v433 = v_u_10()
			if v433 - v_u_432 > v_u_12.BURN_MAX_S then
				if v_u_428 then
					v_u_428:Disconnect()
					v_u_428 = nil
				end
			else
				while (v_u_10() - v433) * 1000 < v_u_431 do

				end
			end
		end)
		return ("globe.burn: %s ms per frame, stops by itself after %d s; globe.burn off ends it"):format(v430, v_u_12.BURN_MAX_S)
	end
	pcall(p379, "globe.burn", v434)
end
return v_u_11