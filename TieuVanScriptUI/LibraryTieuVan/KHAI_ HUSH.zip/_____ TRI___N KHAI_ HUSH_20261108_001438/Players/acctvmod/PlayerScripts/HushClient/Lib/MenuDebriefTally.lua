-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuDebriefTally

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v2:WaitForChild("Skins"))
v_u_1.TEXT = {
	["section"] = "Tally",
	["line"] = "TALLY +%s in this raid",
	["total"] = "%s in all"
}
v_u_1.MAX_ROWS = 8
local v_u_4 = nil
local function v6()
	-- upvalues: (ref) v_u_4
	local v5 = script.Parent:FindFirstChild("TallyMark")
	if v5 then
		v_u_4 = require(v5)
	end
end
pcall(v6)
local function v_u_10(p7) -- name: commas
	-- upvalues: (ref) v_u_4
	if v_u_4 then
		return v_u_4.commas(p7)
	end
	local v8 = tonumber(p7) or 0
	local v9 = math.floor(v8)
	return tostring(v9)
end
function v_u_1.lineText(p11) -- name: lineText
	-- upvalues: (copy) v_u_1, (copy) v_u_10
	return v_u_1.TEXT.line:format(v_u_10(p11))
end
function v_u_1.rows(p12, p13, p14) -- name: rows
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_10, (ref) v_u_4
	if type(p12) == "table" then
		local v15 = p12.tally
		if type(v15) == "table" then
			local v16 = tonumber(p14) or 900
			if type(p13) == "number" then
				local v17 = p12.at
				if type(v17) == "number" and v16 < p13 - p12.at then
					return nil
				end
			end
			local v18 = {}
			for _, v19 in p12.tally do
				if type(v19) ~= "table" then
					continue
				end
				local v20 = v19.n
				if type(v20) ~= "number" or (v19.n ~= v19.n or v19.n <= 0) then
					continue
				end
				local v21 = v19.k
				if type(v21) ~= "number" or v19.k ~= v19.k then
					continue
				end
				local v22 = v19.s
				local v23
				if type(v22) == "string" then
					v23 = v_u_3.get(v19.s)
				else
					v23 = nil
				end
				local v24 = v19.w
				local v25
				if type(v24) == "string" then
					v25 = v_u_3.weaponName(v19.w)
				else
					v25 = nil
				end
				if not v25 then
					local v26 = v19.w
					v25 = type(v26) ~= "string" and "" or v19.w
				end
				local v27 = { v25 }
				if v23 then
					local v28 = v23.name
					table.insert(v27, v28)
				end
				local v29 = v_u_1.TEXT.total
				local v30 = v_u_10
				local v31 = v19.k
				table.insert(v27, v29:format(v30(v31)))
				local v32 = {
					["text"] = v_u_1.lineText(v19.n),
					["sub"] = table.concat(v27, "  \194\183  ")
				}
				local v33 = v19.n
				v32.n = math.floor(v33)
				local v34 = v19.k
				v32.k = math.floor(v34)
				v32.level = not v_u_4 and 0 or v_u_4.level(v19.k)
				v32.weapon = v19.w
				v32.skin = v19.s
				table.insert(v18, v32)
				if #v18 < v_u_1.MAX_ROWS then
					continue
				end
			end
			if #v18 == 0 then
				return nil
			else
				return v18
			end
		end
	end
	return nil
end
function v_u_1.attach(p_u_35, p36, p37) -- name: attach
	-- upvalues: (copy) v_u_1, (ref) v_u_4
	local v_u_38 = type(p37) ~= "table" and {} or p37
	local v_u_39 = p_u_35.ui
	local v_u_40 = p_u_35.theme
	local v_u_41 = v_u_40.color
	local v_u_42 = p_u_35.kit
	local v_u_43 = v_u_39.new("Frame", {
		["Name"] = "Tally",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v_u_38.order or 15
	}, p36)
	v_u_39.layout(v_u_43, "v", 4)
	local v_u_44 = false
	local v_u_45 = nil
	local v46 = {}
	local function v_u_57() -- name: apply
		-- upvalues: (ref) v_u_44, (copy) v_u_38, (copy) p_u_35, (ref) v_u_1, (copy) v_u_42, (copy) v_u_43, (copy) v_u_39, (ref) v_u_4, (copy) v_u_40, (copy) v_u_41, (ref) v_u_45
		if v_u_44 then
			return
		else
			local v47 = v_u_38.alive
			if type(v47) == "function" and not v_u_38.alive() then
				return
			else
				local v48 = p_u_35.profile
				local v49
				if type(v48) == "table" then
					v49 = p_u_35.profile.lastRaid
				else
					v49 = nil
				end
				local v50 = v_u_1.rows(v49, os.time(), v_u_38.maxAge)
				if v50 ~= nil then
					v_u_44 = true
					v_u_42.section(v_u_43, v_u_1.TEXT.section, 0)
					for v51, v52 in v50 do
						local v53 = v_u_39.new("Frame", {
							["Name"] = nil,
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Name"] = "Row" .. v51,
							["Size"] = UDim2.new(1, 0, 0, 40),
							["LayoutOrder"] = v51
						}, v_u_43)
						local v54
						if v_u_4 then
							v54 = v_u_4.colorOf(v52.level, v_u_40)
						else
							v54 = v_u_41.text
						end
						if v_u_4 then
							local v55 = v_u_4.new(v53, {
								["size"] = 24,
								["level"] = nil,
								["name"] = "Sign",
								["level"] = v52.level
							})
							v55.frame.AnchorPoint = Vector2.new(0, 0.5)
							v55.frame.Position = UDim2.new(0, 2, 0.5, 0)
						end
						v_u_39.label({
							["parent"] = nil,
							["name"] = "Line",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v53,
							["text"] = v52.text,
							["color"] = v54,
							["position"] = UDim2.fromOffset(40, 2),
							["size"] = UDim2.new(1, -44, 0, 20)
						})
						v_u_39.label({
							["parent"] = nil,
							["name"] = "Sub",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v53,
							["text"] = v52.sub,
							["color"] = v_u_41.text2,
							["position"] = UDim2.fromOffset(40, 22),
							["size"] = UDim2.new(1, -44, 0, 16)
						})
					end
					if v_u_45 then
						local function v56()
							-- upvalues: (ref) v_u_45
							v_u_45:Disconnect()
						end
						pcall(v56)
						v_u_45 = nil
					end
				end
			end
		end
	end
	function v46.refresh() -- name: refresh
		-- upvalues: (copy) v_u_57
		local v58 = v_u_57
		pcall(v58)
	end
	function v46.destroy() -- name: destroy
		-- upvalues: (ref) v_u_44, (ref) v_u_45, (copy) v_u_43
		v_u_44 = true
		if v_u_45 then
			local function v59()
				-- upvalues: (ref) v_u_45
				v_u_45:Disconnect()
			end
			pcall(v59)
			v_u_45 = nil
		end
		v_u_43:Destroy()
	end
	pcall(v_u_57)
	if not v_u_44 then
		local function v62()
			-- upvalues: (copy) p_u_35, (ref) v_u_45, (copy) v_u_57
			if p_u_35.changed and p_u_35.changed.Connect then
				v_u_45 = p_u_35.changed:Connect(function(p60)
					-- upvalues: (ref) v_u_57
					if p60 == "profile" then
						local v61 = v_u_57
						pcall(v61)
					end
				end)
			end
		end
		pcall(v62)
	end
	v_u_43.Destroying:Connect(function()
		-- upvalues: (ref) v_u_45
		if v_u_45 then
			local function v63()
				-- upvalues: (ref) v_u_45
				v_u_45:Disconnect()
			end
			pcall(v63)
			v_u_45 = nil
		end
	end)
	return v46
end
return v_u_1