-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmGive

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(script.Parent:WaitForChild("HushUI"))
local v_u_6 = v_u_5.Theme
local v_u_7 = v_u_6.color
local v8 = {}
local v_u_9 = v1.LocalPlayer
local v_u_10 = {
	["PASSES"] = "Passes",
	["KITS"] = "Kits and bundles",
	["CASH"] = "Cash",
	["HIDEOUT"] = "Hideout",
	["GUARD"] = "Connection Guard"
}
function v8.build(p_u_11) -- name: build
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_2, (copy) v_u_4
	if v_u_9:GetAttribute("FilmAllowed") ~= true then
		return nil
	end
	local v_u_12 = p_u_11.body
	local v_u_13 = p_u_11.api
	local v14 = p_u_11.inner
	local v_u_15 = true
	p_u_11.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_15
		v_u_15 = false
	end)
	local function v16()
		-- upvalues: (ref) v_u_3
		return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("OwnerGiveRules", 5)))
	end
	local v17, v_u_18 = pcall(v16)
	if not v17 then
		v_u_18 = nil
	end
	if not v_u_18 then
		warn("[FilmGive] OwnerGiveRules missing")
		return nil
	end
	local v_u_19 = 0
	local function v22(p20) -- name: section
		-- upvalues: (ref) v_u_5, (copy) v_u_12, (ref) v_u_7, (ref) v_u_19
		local v21 = v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_12,
			["text"] = p20,
			["color"] = v_u_7.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_19 = v_u_19 + 1
		v21.LayoutOrder = v_u_19
		return v21
	end
	local function v26(p23, p24) -- name: note
		-- upvalues: (ref) v_u_5, (copy) v_u_12, (ref) v_u_7, (ref) v_u_19
		local v25 = v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_12,
			["text"] = p23,
			["color"] = p24 or v_u_7.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_19 = v_u_19 + 1
		v25.LayoutOrder = v_u_19
		return v25
	end
	local v_u_27 = nil
	local v_u_28 = {}
	local v_u_29 = {}
	local v_u_30 = {}
	local v_u_31 = {}
	local v_u_32 = ""
	local v_u_33 = false
	local v_u_34 = nil
	local v_u_35 = nil
	local v_u_36 = {}
	local v_u_37 = false
	local v_u_38 = "idle"
	local function v_u_39() end
	local function v_u_40(_) end
	local function v_u_41() end
	local function v_u_42() end
	local function v_u_43() end
	local function v_u_44() end
	local function v_u_48() -- name: selectedIds
		-- upvalues: (ref) v_u_28, (copy) v_u_29
		local v45 = {}
		for _, v46 in v_u_28 do
			if not v_u_29[v46.id] then
				continue
			end
			local v47 = v46.id
			table.insert(v45, v47)
		end
		return v45
	end
	v22("Give  \194\183  owner only")
	v26("Type a username, press LOOK UP, tick what to give and press GIVE. The player gets it for free: at once when he is on this server, otherwise at his next menu visit. Every gift is logged.")
	local v49 = v_u_5.new("Frame", {
		["Name"] = "GiveNameRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(36))
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v49.LayoutOrder = v_u_19
	v_u_5.layout(v49, "h", 6)
	local v50, v_u_51 = v_u_5.input({
		["parent"] = nil,
		["name"] = "GiveName",
		["size"] = nil,
		["placeholder"] = "Roblox username",
		["parent"] = v49,
		["size"] = UDim2.fromOffset(v14 - 126, v_u_6.touch(36))
	})
	v50.LayoutOrder = 1
	local function v52()
		-- upvalues: (ref) v_u_39
		v_u_39()
	end
	local v53, v_u_54 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Look up",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 120,
		["onClick"] = nil,
		["maxTextWidth"] = 108,
		["parent"] = v49,
		["height"] = v_u_6.touch(32),
		["onClick"] = v52
	})
	v53.Name = "GiveLookup"
	v53.LayoutOrder = 2
	local v_u_55 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_12,
		["color"] = v_u_7.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_19 = v_u_19 + 1
	v_u_55.LayoutOrder = v_u_19
	v_u_55.Visible = false
	local v_u_56 = v_u_5.new("Frame", {
		["Name"] = "GiveTarget",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_7.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v_u_56.LayoutOrder = v_u_19
	v_u_56.Visible = false
	v_u_5.stroke(v_u_56, v_u_7.accentDim)
	v_u_5.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_7.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v_u_56)
	local v57 = v_u_5.new("Frame", {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_56)
	v_u_5.pad(v57, {
		16,
		10,
		8,
		8
	})
	v_u_5.layout(v57, "v", 2)
	local v_u_58 = v_u_5.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = "",
		["style"] = "bodyStrong",
		["track"] = false,
		["size"] = nil,
		["parent"] = v57,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	v_u_58.LayoutOrder = 1
	local v_u_59 = v_u_5.label({
		["parent"] = nil,
		["name"] = "Info",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v57,
		["color"] = v_u_7.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_59.LayoutOrder = 2
	v22("What to give")
	local v60, v_u_61 = v_u_5.input({
		["parent"] = nil,
		["name"] = "GiveSearch",
		["size"] = nil,
		["placeholder"] = "Search the list",
		["parent"] = v_u_12,
		["size"] = UDim2.new(1, 0, 0, v_u_6.touch(34))
	})
	v_u_19 = v_u_19 + 1
	v60.LayoutOrder = v_u_19
	local v_u_62 = v_u_5.new("Frame", {
		["Name"] = "GiveList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v_u_62.LayoutOrder = v_u_19
	v_u_5.layout(v_u_62, "v", 4)
	local v_u_63 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveListNote",
		["text"] = "Loading the list ...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_62,
		["color"] = v_u_7.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_63.LayoutOrder = 0
	local v_u_64 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveCount",
		["text"] = "Nothing selected.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_12,
		["color"] = v_u_7.text2,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	v_u_19 = v_u_19 + 1
	v_u_64.LayoutOrder = v_u_19
	local v65 = v_u_5.new("Frame", {
		["Name"] = "GiveActions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(32))
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v65.LayoutOrder = v_u_19
	v_u_5.layout(v65, "h", 6)
	local v66 = (v14 - 12) / 3
	local v67 = math.floor(v66)
	local function v68()
		-- upvalues: (ref) v_u_40
		v_u_40("selected")
	end
	local v69, v_u_70 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Give selected",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v65,
		["height"] = v_u_6.touch(32),
		["width"] = v67,
		["onClick"] = v68,
		["maxTextWidth"] = (v67 or 160) - 12
	})
	v69.Name = "GiveSelected"
	v69.LayoutOrder = 1
	local function v71()
		-- upvalues: (ref) v_u_40
		v_u_40("passes")
	end
	local v72, v73 = v_u_5.button({
		["parent"] = nil,
		["text"] = "All passes",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v65,
		["height"] = v_u_6.touch(32),
		["width"] = v67,
		["onClick"] = v71,
		["maxTextWidth"] = (v67 or 160) - 12
	})
	v72.Name = "GiveAllPasses"
	v72.LayoutOrder = 2
	local function v74()
		-- upvalues: (ref) v_u_40
		v_u_40("everything")
	end
	local v75, v76 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Everything",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v65,
		["height"] = v_u_6.touch(32),
		["width"] = v67,
		["onClick"] = v74,
		["maxTextWidth"] = (v67 or 160) - 12
	})
	v75.Name = "GiveEverything"
	v75.LayoutOrder = 3
	local v_u_77 = { v_u_70, v73, v76 }
	local function v78()
		-- upvalues: (ref) v_u_41
		v_u_41()
	end
	local v79, _ = v_u_5.button({
		["parent"] = nil,
		["text"] = "Clear the ticks",
		["kind"] = "ghost",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_12,
		["height"] = v_u_6.touch(32),
		["width"] = v14,
		["onClick"] = v78,
		["maxTextWidth"] = (v14 or 160) - 12
	})
	v79.Name = "GiveClear"
	v_u_19 = v_u_19 + 1
	v79.LayoutOrder = v_u_19
	local v_u_80 = v_u_5.new("Frame", {
		["Name"] = "GiveConfirm",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_7.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v_u_80.LayoutOrder = v_u_19
	v_u_80.Visible = false
	v_u_5.stroke(v_u_80, v_u_7.accent)
	v_u_5.pad(v_u_80, {
		12,
		12,
		10,
		10
	})
	v_u_5.layout(v_u_80, "v", 8)
	local v_u_81 = v_u_5.label({
		["parent"] = nil,
		["name"] = "Question",
		["text"] = "",
		["style"] = "bodyStrong",
		["track"] = false,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_80,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_81.LayoutOrder = 1
	local v82 = v_u_5.new("Frame", {
		["Name"] = "Buttons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(32))
	}, v_u_80)
	v_u_5.layout(v82, "h", 6)
	local v83 = (v14 - 24 - 6) / 2
	local v84 = math.floor(v83)
	local function v85()
		-- upvalues: (ref) v_u_42
		v_u_42()
	end
	local v86, v_u_87 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Yes, give",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v82,
		["height"] = v_u_6.touch(32),
		["width"] = v84,
		["onClick"] = v85,
		["maxTextWidth"] = (v84 or 160) - 12
	})
	v86.Name = "GiveYes"
	v86.LayoutOrder = 1
	local function v88()
		-- upvalues: (ref) v_u_43
		v_u_43()
	end
	local v89, _ = v_u_5.button({
		["parent"] = nil,
		["text"] = "Cancel",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v82,
		["height"] = v_u_6.touch(32),
		["width"] = v84,
		["onClick"] = v88,
		["maxTextWidth"] = (v84 or 160) - 12
	})
	v89.Name = "GiveCancel"
	v89.LayoutOrder = 2
	local v_u_90 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveOk",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_12,
		["color"] = v_u_7.success,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_19 = v_u_19 + 1
	v_u_90.LayoutOrder = v_u_19
	v_u_90.Visible = false
	local v_u_91 = v_u_5.new("Frame", {
		["Name"] = "GiveLines",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v_u_91.LayoutOrder = v_u_19
	v_u_5.layout(v_u_91, "v", 2)
	v22("Last gifts  \194\183  newest first")
	local v92 = v_u_5.new("Frame", {
		["Name"] = "GiveHistoryHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(30))
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v92.LayoutOrder = v_u_19
	v_u_5.layout(v92, "h", 6)
	local v_u_93 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveHistoryCount",
		["text"] = "...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v92,
		["color"] = v_u_7.text2,
		["size"] = UDim2.fromOffset(v14 - 126, v_u_6.touch(30))
	})
	v_u_93.LayoutOrder = 1
	local function v94()
		-- upvalues: (ref) v_u_44
		v_u_44()
	end
	local v95, _ = v_u_5.button({
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = nil,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v92,
		["height"] = v_u_6.touch(32),
		["onClick"] = v94
	})
	v95.Name = "GiveRefresh"
	v95.LayoutOrder = 2
	local v_u_96 = v_u_5.new("Frame", {
		["Name"] = "GiveHistory",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_12)
	v_u_19 = v_u_19 + 1
	v_u_96.LayoutOrder = v_u_19
	v_u_5.layout(v_u_96, "v", 6)
	local v_u_97 = v_u_5.label({
		["parent"] = nil,
		["name"] = "GiveHistoryEmpty",
		["text"] = "Nothing given yet.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_96,
		["color"] = v_u_7.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_97.LayoutOrder = 0
	local function v_u_112() -- name: paintRows
		-- upvalues: (ref) v_u_32, (ref) v_u_28, (copy) v_u_30, (copy) v_u_29, (ref) v_u_7, (ref) v_u_27, (copy) v_u_31, (copy) v_u_48, (copy) v_u_64, (copy) v_u_70
		local v98 = string.lower(v_u_32)
		local v99 = {}
		for _, v100 in v_u_28 do
			local v101 = v_u_30[v100.id]
			if not v101 then
				continue
			end
			local v102 = string.lower(v100.name .. " " .. v100.what .. " " .. v100.id .. " " .. v100.category)
			local v103 = v98 == "" and true or string.find(v102, v98, 1, true) ~= nil
			v101.frame.Visible = v103
			if v103 then
				v99[v100.category] = true
			end
			local v104 = v_u_29[v100.id] == true
			v101.fill.Visible = v104
			local v105 = v101.stroke
			local v106
			if v104 then
				v106 = v_u_7.accent
			else
				v106 = v_u_7.line
			end
			v105.Color = v106
			local v107
			if v_u_27 == nil then
				v107 = false
			else
				local v108 = v_u_27.owned
				if type(v108) == "table" and v100.pass ~= nil then
					v107 = v_u_27.owned[v100.pass] == true
				else
					v107 = false
				end
			end
			if v107 then
				v101.tag.Text = "OWNED"
				v101.tag.TextColor3 = v_u_7.success
			elseif v100.limited then
				v101.tag.Text = "LIMITED"
				v101.tag.TextColor3 = v_u_7.accent
			elseif v100.soon then
				v101.tag.Text = "NO ROBLOX ID YET"
				v101.tag.TextColor3 = v_u_7.muted
			else
				v101.tag.Text = ""
			end
		end
		for v109, v110 in v_u_31 do
			v110.Visible = v99[v109] == true
		end
		local v111 = #v_u_48()
		v_u_64.Text = v111 == 0 and "Nothing selected." or ("%d selected."):format(v111)
		v_u_70.setText(v111 <= 0 and "Give selected" or ("Give selected (%d)"):format(v111))
	end
	local function v_u_115() -- name: paintButtons
		-- upvalues: (ref) v_u_27, (ref) v_u_33, (ref) v_u_34, (ref) v_u_37, (ref) v_u_77, (copy) v_u_87, (copy) v_u_54, (ref) v_u_9, (copy) v_u_48, (ref) v_u_28, (ref) v_u_38
		local v113 = v_u_27 ~= nil and not v_u_33
		if v113 then
			if v_u_34 == nil then
				v113 = v_u_37
			else
				v113 = false
			end
		end
		for _, v114 in v_u_77 do
			v114.setEnabled(v113)
		end
		v_u_87.setEnabled(not v_u_33)
		v_u_54.setEnabled(not v_u_33)
		v_u_9:SetAttribute("FilmGive", ("target=%d|sel=%d|busy=%d|confirm=%d|rows=%d|state=%s"):format(not v_u_27 and 0 or v_u_27.userId, #v_u_48(), v_u_33 and 1 or 0, v_u_34 and 1 or 0, #v_u_28, v_u_38))
	end
	local function v_u_117() -- name: clearLines
		-- upvalues: (copy) v_u_91, (copy) v_u_90, (ref) v_u_9
		for _, v116 in v_u_91:GetChildren() do
			if not v116:IsA("GuiObject") then
				continue
			end
			v116:Destroy()
		end
		v_u_90.Visible = false
		v_u_9:SetAttribute("FilmGiveResult", "")
	end
	local function v_u_133(p118) -- name: paintLines
		-- upvalues: (copy) v_u_91, (ref) v_u_7, (ref) v_u_5
		for _, v119 in v_u_91:GetChildren() do
			if not v119:IsA("GuiObject") then
				continue
			end
			v119:Destroy()
		end
		if type(p118) == "table" then
			for v120, v121 in p118 do
				local v122 = v121.status
				local v123 = tostring(v122)
				local v124 = v123 == "given" and "GIVEN" or (v123 == "owned" and "ALREADY OWNED" or (v123 == "failed" and "FAILED" or "WAITING"))
				local v125
				if v123 == "given" then
					v125 = v_u_7.success
				elseif v123 == "failed" then
					v125 = v_u_7.danger
				elseif v123 == "owned" then
					v125 = v_u_7.text2
				else
					v125 = v_u_7.accent
				end
				local v126 = v121.name
				local v127 = ("%s  \194\183  %s"):format(v124, (tostring(v126)))
				local v128 = v121.note
				if type(v128) == "string" and v121.note ~= "" then
					v127 = v127 .. "  \194\183  " .. v121.note
				end
				local v129 = v_u_5.label
				local v130 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v_u_91
				}
				local v131 = v121.id
				v130.name = "GiveLine_" .. tostring(v131)
				v130.text = v127
				v130.color = v125
				v130.size = UDim2.new(1, 0, 0, 0)
				local v132 = v129(v130)
				v132.LayoutOrder = v120
				v132.RichText = false
			end
		end
	end
	local function v_u_166() -- name: paintHistory
		-- upvalues: (copy) v_u_96, (copy) v_u_97, (ref) v_u_36, (copy) v_u_93, (copy) v_u_18, (ref) v_u_5, (ref) v_u_7, (ref) v_u_28
		for _, v134 in v_u_96:GetChildren() do
			if not v134:IsA("GuiObject") or v134 == v_u_97 then
				continue
			end
			v134:Destroy()
		end
		v_u_97.Visible = #v_u_36 == 0
		v_u_93.Text = ("%d of the last %d gifts"):format(#v_u_36, v_u_18.TUNE.showGifts)
		for v135, v136 in v_u_36 do
			local v137 = v_u_5.new
			local v138 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil
			}
			local v139 = v136.id
			v138.Name = "Gift_" .. tostring(v139)
			v138.BackgroundColor3 = v_u_7.raised
			v138.Size = UDim2.new(1, 0, 0, 0)
			v138.AutomaticSize = Enum.AutomaticSize.Y
			v138.LayoutOrder = v135
			local v140 = v137("Frame", v138, v_u_96)
			local v141 = v_u_5.stroke
			local v142
			if v136.state == "failed" then
				v142 = v_u_7.danger
			else
				v142 = v_u_7.line
			end
			v141(v140, v142)
			v_u_5.pad(v140, {
				10,
				10,
				8,
				8
			})
			v_u_5.layout(v140, "v", 3)
			local v143
			if v136.state == "delivered" then
				v143 = v_u_7.success
			elseif v136.state == "failed" then
				v143 = v_u_7.danger
			else
				v143 = v_u_7.accent
			end
			local v144 = v_u_5.label
			local v145 = {
				["parent"] = nil,
				["name"] = "Head",
				["text"] = nil,
				["style"] = "bodyStrong",
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v140
			}
			local v146 = v136.toName
			local v147 = tostring(v146)
			local v148 = v136.n
			local v149 = tonumber(v148) or 0
			local v150 = v136.n
			local v151 = tonumber(v150) == 1 and "thing" or "things"
			local v152 = v_u_18.ago
			local v153 = os.time()
			local v154 = v136.t
			v145.text = ("%s  \194\183  %d %s  \194\183  %s"):format(v147, v149, v151, v152(v153 - (tonumber(v154) or 0)))
			v145.size = UDim2.new(1, 0, 0, 0)
			local v155 = v144(v145)
			v155.LayoutOrder = 1
			v155.RichText = false
			local v156 = {}
			local v157 = v136.ids
			if type(v157) == "table" then
				for _, v158 in v136.ids do
					local v159 = tostring(v158)
					for _, v160 in v_u_28 do
						if v160.id ~= v159 then
							continue
						end
						v159 = v160.name
					end
					table.insert(v156, v159)
				end
			end
			local v161 = v_u_5.label({
				["parent"] = nil,
				["name"] = "What",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v140,
				["text"] = v_u_18.summaryText(v156, 4),
				["color"] = v_u_7.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v161.LayoutOrder = 2
			v161.RichText = false
			local v162 = v136.state == "delivered" and "DELIVERED" or (v136.state == "failed" and "FAILED" or "PENDING")
			local v163
			if v136.state == "delivered" then
				local v164 = v136.res
				if type(v164) == "string" and v136.res ~= "" then
					v162 = v162 .. "  \194\183  " .. v136.res
					v163 = v_u_5.label({
						["parent"] = nil,
						["name"] = "State",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v140,
						["text"] = v162,
						["color"] = v143,
						["size"] = UDim2.new(1, 0, 0, 0)
					})
					v163.LayoutOrder = 3
					v163.RichText = false
				elseif v136.state == "failed" then
					::l42::
					local v165 = v136.why
					if type(v165) == "string" and v136.why ~= "" then
						v162 = v162 .. "  \194\183  " .. v136.why
						v163 = v_u_5.label({
							["parent"] = nil,
							["name"] = "State",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["size"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v140,
							["text"] = v162,
							["color"] = v143,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v163.LayoutOrder = 3
						v163.RichText = false
					else
						if v136.state == "pending" then
							v162 = v162 .. "  \194\183  applied when the player is next in the menu"
						end
						v163 = v_u_5.label({
							["parent"] = nil,
							["name"] = "State",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["size"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v140,
							["text"] = v162,
							["color"] = v143,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v163.LayoutOrder = 3
						v163.RichText = false
					end
				else
					if v136.state == "pending" then
						v162 = v162 .. "  \194\183  applied when the player is next in the menu"
					end
					v163 = v_u_5.label({
						["parent"] = nil,
						["name"] = "State",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v140,
						["text"] = v162,
						["color"] = v143,
						["size"] = UDim2.new(1, 0, 0, 0)
					})
					v163.LayoutOrder = 3
					v163.RichText = false
				end
			else
				if v136.state == "failed" then
					goto l42
				end
				if v136.state == "pending" then
					v162 = v162 .. "  \194\183  applied when the player is next in the menu"
				end
				v163 = v_u_5.label({
					["parent"] = nil,
					["name"] = "State",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v140,
					["text"] = v162,
					["color"] = v143,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
				v163.LayoutOrder = 3
				v163.RichText = false
			end
		end
	end
	local function v_u_167()
		-- upvalues: (copy) v_u_56, (ref) v_u_27, (copy) v_u_58, (copy) v_u_59, (copy) v_u_112, (copy) v_u_115, (copy) v_u_166
		v_u_56.Visible = v_u_27 ~= nil
		if v_u_27 then
			v_u_58.Text = ("%s  (@%s)"):format(v_u_27.display, v_u_27.name)
			v_u_59.Text = ("user id %d  \194\183  %s"):format(v_u_27.userId, v_u_27.online and "on this server, the gift is applied at once" or "not on this server, the gift waits for his next menu visit")
		end
		v_u_112()
		v_u_115()
		v_u_166()
	end
	local function v_u_169(p168)
		-- upvalues: (ref) v_u_33, (copy) v_u_115
		v_u_33 = p168
		v_u_115()
	end
	local function v_u_181() -- name: buildList
		-- upvalues: (copy) v_u_62, (copy) v_u_63, (copy) v_u_30, (copy) v_u_31, (ref) v_u_28, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (copy) v_u_29, (ref) v_u_35, (ref) v_u_34, (copy) v_u_80, (copy) v_u_112, (copy) v_u_115
		for _, v170 in v_u_62:GetChildren() do
			if not v170:IsA("GuiObject") or v170 == v_u_63 then
				continue
			end
			v170:Destroy()
		end
		table.clear(v_u_30)
		table.clear(v_u_31)
		v_u_63.Visible = #v_u_28 == 0
		local v171 = ""
		local v172 = 0
		for _, v_u_173 in v_u_28 do
			if v_u_173.category ~= v171 then
				v171 = v_u_173.category
				v172 = v172 + 1
				local v174 = v_u_5.label({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["size"] = nil,
					["parent"] = v_u_62,
					["name"] = "GiveHeader_" .. v_u_173.category,
					["text"] = v_u_10[v_u_173.category] or v_u_173.category,
					["color"] = v_u_7.muted,
					["size"] = UDim2.new(1, 0, 0, 20)
				})
				v174.LayoutOrder = v172
				v_u_31[v_u_173.category] = v174
			end
			v172 = v172 + 1
			local v175 = v_u_5.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Selectable"] = true,
				["Name"] = "Give_" .. v_u_173.id,
				["BackgroundColor3"] = v_u_7.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(44)),
				["LayoutOrder"] = v172
			}, v_u_62)
			local v176 = v_u_5.stroke(v175, v_u_7.line)
			local v177 = v_u_5.new("Frame", {
				["Name"] = "Check",
				["Size"] = nil,
				["Position"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = UDim2.fromOffset(18, 18),
				["Position"] = UDim2.new(0, 10, 0.5, -9),
				["BackgroundColor3"] = v_u_7.bg
			}, v175)
			v_u_5.stroke(v177, v_u_7.lineStrong)
			local v178 = v_u_5.new("Frame", {
				["Name"] = "Fill",
				["Size"] = nil,
				["Position"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Visible"] = false,
				["Size"] = UDim2.fromOffset(10, 10),
				["Position"] = UDim2.fromOffset(4, 4),
				["BackgroundColor3"] = v_u_7.accent
			}, v177)
			v_u_5.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v175,
				["text"] = v_u_173.name,
				["position"] = UDim2.fromOffset(38, 4),
				["size"] = UDim2.new(1, -170, 0, 20)
			}).RichText = false
			v_u_5.label({
				["parent"] = nil,
				["name"] = "What",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v175,
				["text"] = v_u_173.what,
				["color"] = v_u_7.text2,
				["position"] = UDim2.fromOffset(38, 24),
				["size"] = UDim2.new(1, -50, 0, 16)
			}).RichText = false
			local v179 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Tag",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["align"] = "right",
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v175,
				["color"] = v_u_7.muted,
				["position"] = UDim2.new(1, -132, 0, 7),
				["size"] = UDim2.fromOffset(124, 14)
			})
			v179.RichText = false
			v175.Activated:Connect(function()
				-- upvalues: (copy) v_u_173, (ref) v_u_30, (ref) v_u_29, (ref) v_u_35, (ref) v_u_34, (ref) v_u_80, (ref) v_u_112, (ref) v_u_115
				local v180 = v_u_173.id
				if v_u_30[v180] ~= nil then
					v_u_29[v180] = not v_u_29[v180] and true or nil
					v_u_35 = nil
					if v_u_34 then
						v_u_34 = nil
						v_u_80.Visible = false
					end
					v_u_112()
					v_u_115()
				end
			end)
			v_u_30[v_u_173.id] = {
				["frame"] = v175,
				["fill"] = v178,
				["stroke"] = v176,
				["tag"] = v179
			}
		end
		v_u_112()
	end
	local function v_u_189(p182) -- name: lookup
		-- upvalues: (ref) v_u_33, (copy) v_u_18, (copy) v_u_55, (ref) v_u_9, (copy) v_u_117, (ref) v_u_34, (copy) v_u_80, (ref) v_u_35, (ref) v_u_38, (ref) v_u_169, (copy) v_u_13, (ref) v_u_15, (ref) v_u_27, (ref) v_u_167
		if v_u_33 then
			return
		else
			local v183 = v_u_18.cleanName(p182)
			if v183 then
				v_u_55.Text = ""
				v_u_55.Visible = false
				v_u_9:SetAttribute("FilmGiveError", "")
				v_u_117()
				v_u_34 = nil
				v_u_80.Visible = false
				v_u_35 = nil
				v_u_38 = "lookup"
				v_u_169(true)
				v_u_13.call("give.lookup", {
					["name"] = v183
				}, function(p184)
					-- upvalues: (ref) v_u_15, (ref) v_u_27, (ref) v_u_38, (ref) v_u_55, (ref) v_u_9, (ref) v_u_169, (ref) v_u_167
					if not v_u_15 then
						return
					end
					local v185, v186
					if p184 and p184.ok then
						local v187 = p184.data
						if type(v187) == "table" then
							v_u_27 = p184.data
							v_u_38 = "found"
							v_u_55.Text = ""
							v_u_55.Visible = false
							v_u_9:SetAttribute("FilmGiveError", "")
							v_u_169(false)
							v_u_167()
						else
							v_u_27 = nil
							v_u_38 = "notfound"
							v185 = p184 and p184.msg or "The server did not answer."
							v186 = tostring(v185) or ""
							v_u_55.Text = v186
							v_u_55.Visible = v186 ~= ""
							v_u_9:SetAttribute("FilmGiveError", v186)
							v_u_169(false)
							v_u_167()
						end
					else
						v_u_27 = nil
						v_u_38 = "notfound"
						v185 = p184 and p184.msg or "The server did not answer."
						v186 = tostring(v185) or ""
						v_u_55.Text = v186
						v_u_55.Visible = v186 ~= ""
						v_u_9:SetAttribute("FilmGiveError", v186)
						v_u_169(false)
						v_u_167()
						return
					end
				end)
			else
				local v188 = v_u_18.REASON.name or ""
				v_u_55.Text = v188
				v_u_55.Visible = v188 ~= ""
				v_u_9:SetAttribute("FilmGiveError", v188)
			end
		end
	end
	local function v_u_194(p190) -- name: startGive
		-- upvalues: (ref) v_u_33, (ref) v_u_27, (ref) v_u_37, (copy) v_u_48, (ref) v_u_28, (copy) v_u_55, (ref) v_u_9, (copy) v_u_117, (ref) v_u_34, (copy) v_u_81, (copy) v_u_80, (ref) v_u_38, (copy) v_u_115
		if v_u_33 or (v_u_27 == nil or not v_u_37) then
			return
		else
			local v191 = 0
			local v192 = nil
			if p190 == "selected" then
				v192 = v_u_48()
				v191 = #v192
			elseif p190 == "passes" then
				for _, v193 in v_u_28 do
					if v193.kind ~= "pass" then
						continue
					end
					v191 = v191 + 1
				end
			else
				v191 = #v_u_28
			end
			if v191 == 0 then
				v_u_55.Text = "Tick at least one thing in the list first."
				v_u_55.Visible = true
				v_u_9:SetAttribute("FilmGiveError", "Tick at least one thing in the list first.")
			else
				v_u_55.Text = ""
				v_u_55.Visible = false
				v_u_9:SetAttribute("FilmGiveError", "")
				v_u_117()
				v_u_34 = {
					["mode"] = p190,
					["ids"] = v192,
					["n"] = v191
				}
				v_u_81.Text = ("Give %d %s to %s?"):format(v191, v191 == 1 and "thing" or "things", v_u_27.display)
				v_u_80.Visible = true
				v_u_38 = "confirm"
				v_u_115()
			end
		end
	end
	local function v195() -- name: cancel
		-- upvalues: (ref) v_u_34, (copy) v_u_80, (ref) v_u_38, (copy) v_u_115
		v_u_34 = nil
		v_u_80.Visible = false
		v_u_38 = "ready"
		v_u_115()
	end
	local function v_u_212() -- name: confirm
		-- upvalues: (ref) v_u_33, (ref) v_u_34, (ref) v_u_27, (copy) v_u_80, (ref) v_u_35, (ref) v_u_2, (ref) v_u_38, (ref) v_u_169, (copy) v_u_13, (ref) v_u_15, (copy) v_u_55, (ref) v_u_9, (copy) v_u_90, (copy) v_u_133, (ref) v_u_36, (copy) v_u_29, (ref) v_u_167
		if not v_u_33 and (v_u_34 ~= nil and v_u_27 ~= nil) then
			local v196 = v_u_34
			v_u_34 = nil
			v_u_80.Visible = false
			v_u_35 = v_u_35 or v_u_2:GenerateGUID(false)
			local v197 = {
				["userId"] = v_u_27.userId,
				["name"] = v_u_27.name,
				["expect"] = v196.n,
				["nonce"] = v_u_35
			}
			if v196.mode == "selected" then
				v197.ids = v196.ids
			else
				v197.scope = v196.mode == "passes" and "passes" or "everything"
			end
			v_u_38 = "sending"
			v_u_169(true)
			v_u_13.call("give.send", v197, function(p198)
				-- upvalues: (ref) v_u_15, (ref) v_u_35, (ref) v_u_38, (ref) v_u_55, (ref) v_u_9, (ref) v_u_90, (ref) v_u_133, (ref) v_u_36, (ref) v_u_29, (ref) v_u_27, (ref) v_u_13, (ref) v_u_167, (ref) v_u_169
				if not v_u_15 then
					return
				end
				local v199, v200
				if p198 and p198.ok then
					local v201 = p198.data
					if type(v201) == "table" then
						v_u_35 = nil
						local v202 = p198.data.state or "done"
						v_u_38 = tostring(v202)
						v_u_55.Text = ""
						v_u_55.Visible = false
						v_u_9:SetAttribute("FilmGiveError", "")
						local v203 = v_u_90
						local v204 = p198.msg or "Done."
						v203.Text = tostring(v204)
						v_u_90.Visible = true
						local v205 = v_u_9
						local v206 = p198.msg or ""
						v205:SetAttribute("FilmGiveResult", (tostring(v206)))
						v_u_133(p198.data.lines)
						local v207 = p198.data.rows
						if type(v207) == "table" then
							v_u_36 = p198.data.rows
						end
						table.clear(v_u_29)
						local v208 = v_u_27
						if type(v208) == "table" and v_u_27.online then
							local v209 = v_u_27
							v_u_13.callQuiet("give.lookup", {
								["name"] = v209.name
							}, function(p210)
								-- upvalues: (ref) v_u_15, (ref) v_u_27, (ref) v_u_167
								if v_u_15 and (p210 and p210.ok) then
									local v211 = p210.data
									if type(v211) == "table" and (v_u_27 and v_u_27.userId == p210.data.userId) then
										v_u_27 = p210.data
										v_u_167()
									end
								end
							end)
						end
						v_u_169(false)
						v_u_167()
					else
						v_u_38 = "refused"
						v199 = p198 and p198.msg or "The server did not answer."
						v200 = tostring(v199) or ""
						v_u_55.Text = v200
						v_u_55.Visible = v200 ~= ""
						v_u_9:SetAttribute("FilmGiveError", v200)
						v_u_169(false)
						v_u_167()
					end
				else
					v_u_38 = "refused"
					v199 = p198 and p198.msg or "The server did not answer."
					v200 = tostring(v199) or ""
					v_u_55.Text = v200
					v_u_55.Visible = v200 ~= ""
					v_u_9:SetAttribute("FilmGiveError", v200)
					v_u_169(false)
					v_u_167()
					return
				end
			end)
		end
	end
	v_u_39 = function()
		-- upvalues: (copy) v_u_189, (copy) v_u_51
		v_u_189(v_u_51.Text)
	end
	v_u_40 = v_u_194
	v_u_41 = function()
		-- upvalues: (copy) v_u_29, (ref) v_u_35, (copy) v_u_112, (copy) v_u_115
		table.clear(v_u_29)
		v_u_35 = nil
		v_u_112()
		v_u_115()
	end
	v_u_42 = v_u_212
	v_u_43 = v195
	v_u_44 = function()
		-- upvalues: (ref) v_u_15, (ref) v_u_36, (copy) v_u_166, (copy) v_u_55, (ref) v_u_9, (copy) v_u_13
		local v_u_213 = false
		local function v219(p214) -- name: done
			-- upvalues: (ref) v_u_15, (ref) v_u_36, (ref) v_u_166, (copy) v_u_213, (ref) v_u_55, (ref) v_u_9
			if v_u_15 then
				if p214 and p214.ok then
					local v215 = p214.data
					if type(v215) == "table" then
						local v216 = p214.data.rows
						if type(v216) == "table" then
							v_u_36 = p214.data.rows
							v_u_166()
							return
						end
					end
				end
				if not v_u_213 then
					local v217 = p214 and p214.msg or "The server did not answer."
					local v218 = tostring(v217) or ""
					v_u_55.Text = v218
					v_u_55.Visible = v218 ~= ""
					v_u_9:SetAttribute("FilmGiveError", v218)
				end
			end
		end
		v_u_13.call("give.log", {}, v219)
	end
	v_u_51.FocusLost:Connect(function(p220)
		-- upvalues: (copy) v_u_189, (copy) v_u_51
		if p220 then
			v_u_189(v_u_51.Text)
		end
	end)
	v_u_51:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_51
		local v221 = v_u_51.Text
		if #v221 > 24 then
			v_u_51.Text = string.sub(v221, 1, 24)
		end
	end)
	v_u_61:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_32, (copy) v_u_61, (copy) v_u_112
		v_u_32 = v_u_61.Text
		v_u_112()
	end)
	if v_u_4:IsStudio() then
		local v_u_233 = v_u_9:GetAttributeChangedSignal("FilmGiveCmd"):Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_51, (copy) v_u_189, (copy) v_u_30, (copy) v_u_29, (ref) v_u_35, (ref) v_u_34, (copy) v_u_80, (copy) v_u_112, (copy) v_u_115, (ref) v_u_28, (copy) v_u_61, (copy) v_u_194, (copy) v_u_212, (ref) v_u_38, (ref) v_u_15, (ref) v_u_36, (copy) v_u_166, (copy) v_u_55, (copy) v_u_13
			local v222 = v_u_9:GetAttribute("FilmGiveCmd")
			if type(v222) == "string" and v222 ~= "" then
				v_u_9:SetAttribute("FilmGiveCmd", nil)
				local v223, v224 = string.match(v222, "^(%a+)%s*(.*)$")
				if v223 == "name" then
					v_u_51.Text = v224
					return
				elseif v223 == "lookup" then
					v_u_189(v_u_51.Text)
					return
				elseif v223 == "toggle" then
					if v_u_30[v224] ~= nil then
						v_u_29[v224] = not v_u_29[v224] and true or nil
						v_u_35 = nil
						if v_u_34 then
							v_u_34 = nil
							v_u_80.Visible = false
						end
						v_u_112()
						v_u_115()
					end
				elseif v223 == "select" then
					table.clear(v_u_29)
					for _, v225 in v_u_28 do
						if v224 ~= "everything" and (v224 ~= "passes" or v225.kind ~= "pass") then
							continue
						end
						v_u_29[v225.id] = true
					end
					v_u_35 = nil
					v_u_112()
					v_u_115()
					return
				elseif v223 == "search" then
					v_u_61.Text = v224
					return
				elseif v223 == "give" then
					v_u_194(v224)
					return
				elseif v223 == "yes" then
					v_u_212()
					return
				elseif v223 == "cancel" then
					v_u_34 = nil
					v_u_80.Visible = false
					v_u_38 = "ready"
					v_u_115()
				elseif v223 == "refresh" then
					local v_u_226 = false
					local function v232(p227) -- name: done
						-- upvalues: (ref) v_u_15, (ref) v_u_36, (ref) v_u_166, (copy) v_u_226, (ref) v_u_55, (ref) v_u_9
						if v_u_15 then
							if p227 and p227.ok then
								local v228 = p227.data
								if type(v228) == "table" then
									local v229 = p227.data.rows
									if type(v229) == "table" then
										v_u_36 = p227.data.rows
										v_u_166()
										return
									end
								end
							end
							if not v_u_226 then
								local v230 = p227 and p227.msg or "The server did not answer."
								local v231 = tostring(v230) or ""
								v_u_55.Text = v231
								v_u_55.Visible = v231 ~= ""
								v_u_9:SetAttribute("FilmGiveError", v231)
							end
						end
					end
					v_u_13.call("give.log", {}, v232)
				end
			else
				return
			end
		end)
		p_u_11.gui.Destroying:Connect(function()
			-- upvalues: (copy) v_u_233
			v_u_233:Disconnect()
		end)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_15, (copy) p_u_11, (copy) v_u_12, (ref) v_u_37, (copy) v_u_13, (ref) v_u_28, (ref) v_u_38, (copy) v_u_181, (copy) v_u_115, (copy) v_u_63, (ref) v_u_7, (ref) v_u_33, (ref) v_u_36, (copy) v_u_166, (copy) v_u_55, (ref) v_u_9
		local v234 = false
		local v235 = (-1 / 0)
		while v_u_15 do
			local v236 = p_u_11.gui.Enabled
			if v236 then
				v236 = v_u_12.Visible
			end
			if v236 and (not v234 and p_u_11.handle) then
				local v237 = p_u_11.handle.status
				if type(v237) == "function" then
					local v238 = p_u_11.handle.status
					pcall(v238, "Give to a player (owner only).")
				end
			end
			if v236 and (not v_u_37 and (not v234 or os.clock() - v235 >= 8)) then
				v235 = os.clock()
				v_u_13.callQuiet("give.catalog", {}, function(p239)
					-- upvalues: (ref) v_u_15, (ref) v_u_28, (ref) v_u_37, (ref) v_u_38, (ref) v_u_181, (ref) v_u_115, (ref) v_u_63, (ref) v_u_7
					if v_u_15 then
						if p239 and p239.ok then
							local v240 = p239.data
							if type(v240) == "table" then
								local v241 = p239.data.entries
								if type(v241) == "table" then
									v_u_28 = p239.data.entries
									v_u_37 = true
									v_u_38 = "ready"
									v_u_181()
									v_u_115()
									return
								end
							end
						end
						local v242 = v_u_63
						local v243 = p239 and p239.msg or "The server did not answer."
						v242.Text = tostring(v243)
						v_u_63.TextColor3 = v_u_7.danger
						v_u_63.Visible = true
					end
				end)
			end
			if v236 and (not v234 or os.clock() - v235 >= 20) and not v_u_33 then
				v235 = os.clock()
				local v_u_244 = true
				local function v250(p245) -- name: done
					-- upvalues: (ref) v_u_15, (ref) v_u_36, (ref) v_u_166, (copy) v_u_244, (ref) v_u_55, (ref) v_u_9
					if v_u_15 then
						if p245 and p245.ok then
							local v246 = p245.data
							if type(v246) == "table" then
								local v247 = p245.data.rows
								if type(v247) == "table" then
									v_u_36 = p245.data.rows
									v_u_166()
									return
								end
							end
						end
						if not v_u_244 then
							local v248 = p245 and p245.msg or "The server did not answer."
							local v249 = tostring(v248) or ""
							v_u_55.Text = v249
							v_u_55.Visible = v249 ~= ""
							v_u_9:SetAttribute("FilmGiveError", v249)
						end
					end
				end
				v_u_13.callQuiet("give.log", {}, v250)
			end
			task.wait(0.4)
			v234 = v236
		end
	end)
	v_u_167()
	return {
		["lookup"] = function(p251) -- name: lookup
			-- upvalues: (copy) v_u_189
			v_u_189(p251)
		end,
		["toggle"] = function(p252) -- name: toggle
			-- upvalues: (copy) v_u_30, (copy) v_u_29, (ref) v_u_35, (ref) v_u_34, (copy) v_u_80, (copy) v_u_112, (copy) v_u_115
			if v_u_30[p252] ~= nil then
				v_u_29[p252] = not v_u_29[p252] and true or nil
				v_u_35 = nil
				if v_u_34 then
					v_u_34 = nil
					v_u_80.Visible = false
				end
				v_u_112()
				v_u_115()
			end
		end,
		["give"] = function(p253) -- name: give
			-- upvalues: (copy) v_u_194
			v_u_194(p253)
		end,
		["confirm"] = function() -- name: confirm
			-- upvalues: (copy) v_u_212
			v_u_212()
		end,
		["cancel"] = function() -- name: cancel
			-- upvalues: (ref) v_u_34, (copy) v_u_80, (ref) v_u_38, (copy) v_u_115
			v_u_34 = nil
			v_u_80.Visible = false
			v_u_38 = "ready"
			v_u_115()
		end,
		["refresh"] = function() -- name: refresh
			-- upvalues: (ref) v_u_15, (ref) v_u_36, (copy) v_u_166, (copy) v_u_55, (ref) v_u_9, (copy) v_u_13
			local v_u_254 = false
			local function v260(p255) -- name: done
				-- upvalues: (ref) v_u_15, (ref) v_u_36, (ref) v_u_166, (copy) v_u_254, (ref) v_u_55, (ref) v_u_9
				if v_u_15 then
					if p255 and p255.ok then
						local v256 = p255.data
						if type(v256) == "table" then
							local v257 = p255.data.rows
							if type(v257) == "table" then
								v_u_36 = p255.data.rows
								v_u_166()
								return
							end
						end
					end
					if not v_u_254 then
						local v258 = p255 and p255.msg or "The server did not answer."
						local v259 = tostring(v258) or ""
						v_u_55.Text = v259
						v_u_55.Visible = v259 ~= ""
						v_u_9:SetAttribute("FilmGiveError", v259)
					end
				end
			end
			v_u_13.call("give.log", {}, v260)
		end,
		["rows"] = function() -- name: rows
			-- upvalues: (ref) v_u_28
			return v_u_28
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_27, (copy) v_u_48, (ref) v_u_33, (ref) v_u_34, (ref) v_u_28, (copy) v_u_55, (copy) v_u_90, (ref) v_u_36, (ref) v_u_38
			return {
				["target"] = v_u_27,
				["selected"] = v_u_48(),
				["busy"] = v_u_33,
				["confirming"] = v_u_34,
				["rows"] = #v_u_28,
				["error"] = v_u_55.Text,
				["ok"] = v_u_90.Text,
				["history"] = #v_u_36,
				["stateText"] = v_u_38
			}
		end
	}
end
return v8