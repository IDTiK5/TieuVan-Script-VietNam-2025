-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClan

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {}
local v_u_4 = {}
v_u_3.TRANSITS = v_u_4
v_u_3.VIEWS = {
	["browse"] = { "MenuClanBrowse", "browse" },
	["invites"] = { "MenuClanBrowse", "invites" },
	["found"] = { "MenuClanForm", "found" },
	["overview"] = { "MenuClanOverview", "mount" },
	["members"] = { "MenuClanHome", "members" },
	["log"] = { "MenuClanHome", "log" },
	["stash"] = { "MenuClanStash", "mount" },
	["shop"] = { "MenuClanShop", "mount" },
	["board"] = { "MenuClanBoard", "mount" },
	["manage"] = { "MenuClanManage", "mount" }
}
function v_u_3.shopOn(p_u_5) -- name: shopOn
	local v_u_6 = true
	local function v7()
		-- upvalues: (ref) v_u_6, (copy) p_u_5
		v_u_6 = p_u_5.config.flag("ClanShop") ~= false
	end
	pcall(v7)
	local v_u_8 = false
	local function v9()
		-- upvalues: (ref) v_u_8, (copy) p_u_5
		v_u_8 = p_u_5.shared.GameMode.rule("clanShop") == true
	end
	pcall(v9)
	return v_u_6 and v_u_8
end
function v_u_3.new(p_u_10, p11) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v_u_12 = p_u_10.ui
	local v_u_13 = p_u_10.theme
	local v14 = v_u_13.color
	local v_u_15 = p_u_10.kit
	local v_u_16 = p_u_10.cctx
	local v_u_17 = p_u_10.player or v_u_1.LocalPlayer
	local v18 = {}
	local v_u_19 = true
	local v_u_20 = false
	local function v25(p_u_21) -- name: lib
		-- upvalues: (copy) v_u_16
		local function v22()
			-- upvalues: (ref) v_u_16, (copy) p_u_21
			return v_u_16.lib[p_u_21]
		end
		local v23, v24 = pcall(v22)
		if v23 and type(v24) == "table" then
			return v24
		else
			return nil
		end
	end
	local v_u_26 = "MenuClanModel"
	local v27, v_u_28 = pcall(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_26
		return v_u_16.lib[v_u_26]
	end)
	if not v27 or type(v_u_28) ~= "table" then
		v_u_28 = nil
	end
	local v_u_29 = "MenuClanLayout"
	local v30, v_u_31 = pcall(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_29
		return v_u_16.lib[v_u_29]
	end)
	if not v30 or type(v_u_31) ~= "table" then
		v_u_31 = nil
	end
	local v_u_32 = "MenuClanUi"
	local v33, v34 = pcall(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_32
		return v_u_16.lib[v_u_32]
	end)
	if not v33 or type(v34) ~= "table" then
		v34 = nil
	end
	local v_u_35 = "ClanTransit"
	local v36, v_u_37 = pcall(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_35
		return v_u_16.lib[v_u_35]
	end)
	if not v36 or type(v_u_37) ~= "table" then
		v_u_37 = nil
	end
	local v38 = v_u_13.safeRefSize()
	local v39 = 16
	if v_u_31 then
		local v40 = v_u_31.kindOf
		if type(v40) == "function" and v_u_31.kindOf(v38.X - (p_u_10.terminal == true and 8 or 0), v38.Y) == "phone" then
			v39 = v_u_31.PAD_PHONE
		end
	end
	local _, v41 = v_u_12.panel({
		["parent"] = nil,
		["name"] = "Clan",
		["position"] = nil,
		["size"] = nil,
		["padding"] = nil,
		["parent"] = p11,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8),
		["padding"] = v39
	})
	if not (v_u_28 and (v_u_31 and v34)) then
		v_u_15.empty(v41, "This screen failed to load. Please reopen the menu.")
		function v18.show() -- name: show end
		function v18.hide() -- name: hide end
		function v18.refresh() -- name: refresh end
		function v18.tick() -- name: tick end
		function v18.draw() -- name: draw end
		function v18.destroy() -- name: destroy end
		return v18
	end
	local v_u_42 = true
	local function v43()
		-- upvalues: (ref) v_u_42, (copy) v_u_16
		v_u_42 = v_u_16.shared.GameMode.rule("clans") == true
	end
	pcall(v43)
	if not v_u_42 then
		v_u_15.empty(v41, "Clans are not part of this game.")
		function v18.show() -- name: show end
		function v18.hide() -- name: hide end
		function v18.refresh() -- name: refresh end
		function v18.tick() -- name: tick end
		function v18.draw() -- name: draw end
		function v18.destroy() -- name: destroy end
		return v18
	end
	pcall(function()
		-- upvalues: (copy) v_u_28, (copy) v_u_16
		v_u_28.rules = v_u_16.shared.ClanRules
	end)
	local v_u_44 = v_u_3.shopOn(v_u_16)
	local v45 = v_u_13.safeRefSize()
	local v_u_46 = v_u_31.metrics(v45.X - (p_u_10.terminal == true and 8 or 0), v45.Y, v_u_13.touch(v_u_31.TOUCH))
	local v47 = v_u_31.chipW
	if type(v47) == "function" then
		local v48 = v_u_13.isTouch
		if type(v48) == "function" then
			local v49 = v_u_13.uiScale
			if type(v49) == "function" then
				local v50 = v_u_31.chipW
				local v51 = v_u_46.kind
				local v52 = v_u_13.isTouch()
				local v53 = v_u_13.uiScale()
				local v54 = v_u_46.refX
				local v55, v56, v57 = pcall(v50, v51, v52, v53, v54)
				if v55 then
					v_u_46.chipW = v56
					v_u_46.chipText = v57
				end
			end
		end
	end
	local v_u_58 = v34.new(p_u_10)
	local v59 = v_u_17.UserId
	local v_u_60 = tostring(v59)
	local v_u_61 = {
		["has"] = false
	}
	local v_u_62 = false
	local v_u_63 = 0
	local v_u_64 = "loading"
	local v_u_65 = false
	local v_u_66 = 0
	local v_u_67 = ""
	local v_u_68 = "info"
	local v_u_69 = 0
	local v_u_70 = {}
	local v_u_71 = nil
	local v_u_72 = {}
	local v_u_73 = {}
	local v_u_74 = {}
	local v_u_75 = -1
	local v_u_76 = false
	local v_u_77 = nil
	local v_u_78 = nil
	local v_u_79 = nil
	local v_u_80 = nil
	local v_u_81 = 0
	local v_u_82 = false
	local v_u_83 = false
	local v_u_84 = nil
	local v_u_85 = ""
	local v_u_86 = v_u_12.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_46.headH)
	}, v41)
	local v87 = v_u_46.phoneRow == true
	local v88 = v_u_12.label
	local v89 = {
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Clans",
		["style"] = nil,
		["size"] = nil,
		["parent"] = v_u_86,
		["style"] = v87 and "bodyStrong" or (v_u_46.kind == "phone" and "h3" or "h2")
	}
	local v90
	if v87 then
		v90 = UDim2.new(1, 0, 0.55, 0)
	else
		v90 = UDim2.new(0.62, 0, 1, 0)
	end
	v89.size = v90
	local v_u_91 = v88(v89)
	local v92 = v_u_12.label
	local v93 = {
		["parent"] = nil,
		["name"] = "Info",
		["text"] = "",
		["style"] = "monoS",
		["align"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_86,
		["align"] = v87 and "left" or "right"
	}
	local v94
	if v87 then
		v94 = UDim2.fromScale(0, 0.55)
	else
		v94 = UDim2.fromScale(0.62, 0)
	end
	v93.position = v94
	local v95
	if v87 then
		v95 = UDim2.new(1, 0, 0.45, 0)
	else
		v95 = UDim2.new(0.38, 0, 1, 0)
	end
	v93.size = v95
	local v_u_96 = v92(v93)
	if v87 then
		v_u_91.TextTruncate = Enum.TextTruncate.AtEnd
		v_u_96.TextTruncate = Enum.TextTruncate.AtEnd
	end
	local v_u_97 = v_u_58.status(v41, {
		["name"] = "Notice",
		["text"] = "",
		["style"] = "small",
		["size"] = nil,
		["visible"] = false,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	local v_u_98 = v_u_58.frame(v41, "TabsHolder", UDim2.new(1, 0, 0, v_u_13.touch(v_u_46.subTabH)))
	local v_u_99 = v_u_58.frame(v41, "Body", UDim2.new(1, 0, 1, 0))
	local v_u_100 = nil
	local v_u_101 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Loading",
		["text"] = "",
		["style"] = "body",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["visible"] = false,
		["parent"] = v41,
		["color"] = v14.text2,
		["size"] = UDim2.new(1, 0, 0, 28)
	})
	local v_u_102 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Transit",
		["text"] = "",
		["style"] = "bodyStrong",
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["visible"] = false,
		["track"] = false,
		["parent"] = v41,
		["position"] = UDim2.new(0, 0, 0.5, -14),
		["size"] = UDim2.new(1, 0, 0, 28)
	})
	local v_u_103 = v_u_12.label({
		["parent"] = nil,
		["name"] = "TransitSlow",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["visible"] = false,
		["track"] = false,
		["parent"] = v41,
		["color"] = v14.text2,
		["position"] = UDim2.new(0, 0, 0.5, 18),
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v_u_104 = nil
	local function v_u_105() end
	local function v_u_119() -- name: paintLoading
		-- upvalues: (ref) v_u_62, (ref) v_u_79, (copy) v_u_101, (copy) v_u_98, (copy) v_u_99, (copy) v_u_102, (copy) v_u_103, (ref) v_u_82, (ref) v_u_64, (copy) v_u_28, (ref) v_u_104
		local v106 = not v_u_62
		local v107 = v_u_79 ~= nil
		local v108 = v_u_101
		local v109
		if v106 then
			v109 = not v107
		else
			v109 = v106
		end
		v108.Visible = v109
		local v110 = v_u_98
		local v111 = not v106
		if v111 then
			v111 = not v107
		end
		v110.Visible = v111
		local v112 = v_u_99
		local v113 = not v106
		if v113 then
			v113 = not v107
		end
		v112.Visible = v113
		v_u_102.Visible = v107
		local v114 = v_u_103
		local v115
		if v107 then
			v115 = v_u_82
		else
			v115 = v107
		end
		v114.Visible = v115
		if v106 then
			local v116 = v_u_101
			local v117
			if v_u_64 == "retry" then
				v117 = v_u_28.UI.LOAD_RETRY
			elseif v_u_64 == "gave_up" then
				v117 = v_u_28.UI.LOAD_FAIL
			else
				v117 = v_u_28.UI.LOADING
			end
			v116.Text = v117
		end
		if v_u_104 then
			local v118 = v_u_104
			if v106 then
				if v_u_64 == "gave_up" then
					v106 = not v107
				else
					v106 = false
				end
			end
			v118.Visible = v106
		end
	end
	local function v_u_124() -- name: relayout
		-- upvalues: (copy) v_u_119, (copy) v_u_31, (copy) v_u_46, (copy) v_u_13, (copy) v_u_97, (copy) v_u_86, (copy) v_u_98, (copy) v_u_99, (copy) v_u_101
		v_u_119()
		local v120 = v_u_31.shell(v_u_46, v_u_13.touch(v_u_46.subTabH), v_u_97.lbl.Visible, 24)
		v_u_86.Position = UDim2.fromOffset(v120.head.x, v120.head.y)
		local v121 = v_u_86
		local v122
		if v120.oneRow then
			v122 = UDim2.fromOffset(v120.head.w, v120.head.h)
		else
			v122 = UDim2.new(1, 0, 0, v120.head.h)
		end
		v121.Size = v122
		if v120.notice then
			v_u_97.lbl.Position = UDim2.fromOffset(v120.notice.x, v120.notice.y)
		else
			v_u_97.lbl.Position = UDim2.fromOffset(0, v120.head.h)
		end
		v_u_98.Position = UDim2.fromOffset(v120.tabs.x, v120.tabs.y)
		v_u_98.Size = UDim2.new(1, -v120.tabs.x, 0, v120.tabs.h)
		local v123 = v120.bodyY
		v_u_99.Position = UDim2.fromOffset(0, v123)
		v_u_99.Size = UDim2.new(1, 0, 1, -v123)
		v_u_101.Position = UDim2.new(0, 0, 0, v123 + 24)
	end
	local v125 = v_u_58.btn({
		["parent"] = nil,
		["text"] = "RETRY",
		["kind"] = "secondary",
		["width"] = 140,
		["name"] = "LoadRetry",
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v41,
		["position"] = UDim2.new(0.5, -70, 0, 120),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_63, (ref) v_u_64, (copy) v_u_124, (ref) v_u_105
			v_u_63 = 0
			v_u_64 = "loading"
			v_u_124()
			v_u_105(true)
		end
	})
	v125.Visible = false
	v_u_104 = v125
	local function v_u_128(p126) -- name: setWorking
		-- upvalues: (ref) v_u_83, (ref) v_u_84, (copy) v_u_58, (copy) v_u_96, (copy) v_u_28, (ref) v_u_85
		if p126 == v_u_83 then
			return
		else
			v_u_83 = p126
			if v_u_84 ~= nil then
				local v127 = v_u_84
				pcall(v127)
				v_u_84 = nil
			end
			if p126 then
				if v_u_58.busyDots == nil then
					v_u_96.Text = v_u_28.UI.WORKING .. "..."
				else
					v_u_84 = v_u_58.busyDots.animate(v_u_96, v_u_58.busyDots.strip(v_u_28.UI.WORKING))
				end
			else
				v_u_96.Text = v_u_85
				return
			end
		end
	end
	local function v_u_133() -- name: updateWorking
		-- upvalues: (ref) v_u_19, (copy) v_u_37, (ref) v_u_79, (copy) v_u_70, (copy) v_u_128
		if v_u_19 then
			local v129
			if v_u_37 == nil or v_u_79 ~= nil then
				v129 = false
			else
				local v130 = {}
				for _, v131 in v_u_70 do
					local v132 = v131.at
					table.insert(v130, v132)
				end
				v129 = v_u_37.workingDue(v130, os.clock())
			end
			v_u_128(v129)
		end
	end
	local v_u_148 = {
		["mc"] = p_u_10,
		["UI"] = v_u_12,
		["Theme"] = v_u_13,
		["C"] = v14,
		["Kit"] = v_u_15,
		["U"] = v_u_58,
		["M"] = v_u_28,
		["m"] = v_u_46,
		["cctx"] = v_u_16,
		["selfUid"] = v_u_60,
		["lib"] = v25,
		["shopOn"] = v_u_44,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_61
			return v_u_61
		end,
		["clan"] = function() -- name: clan
			-- upvalues: (ref) v_u_61
			if v_u_61.has == true then
				local v134 = v_u_61.clan
				if type(v134) == "table" then
					return v_u_61.clan
				end
			end
			return nil
		end,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_19
			return v_u_19
		end,
		["shown"] = function() -- name: shown
			-- upvalues: (ref) v_u_20
			return v_u_20
		end,
		["notice"] = function(p135, p136, p137) -- name: notice
			-- upvalues: (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_97, (copy) v_u_124
			v_u_67 = p135 or ""
			v_u_68 = p136 or "info"
			v_u_69 = v_u_67 == "" and 0 or os.clock() + (p137 or 12)
			v_u_97.set(v_u_67, v_u_68)
			v_u_124()
		end,
		["fetch"] = function(p138, p139, p140) -- name: fetch
			-- upvalues: (copy) p_u_10
			local v141 = p_u_10.fetch
			local v142, v143 = pcall(v141, p138, p139, p140)
			if v142 then
				return v143
			else
				return nil
			end
		end,
		["goStore"] = function() -- name: goStore
			-- upvalues: (copy) p_u_10, (copy) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_97, (copy) v_u_124
			if p_u_10.terminal ~= true then
				local v144 = p_u_10.setTab
				if type(v144) == "function" then
					p_u_10.setTab("store")
					return
				end
			end
			v_u_67 = v_u_28.UI.OPEN_STORE or ""
			v_u_68 = "info"
			v_u_69 = v_u_67 == "" and 0 or os.clock() + 8
			v_u_97.set(v_u_67, v_u_68)
			v_u_124()
		end,
		["canStore"] = function() -- name: canStore
			-- upvalues: (copy) p_u_10
			local v145
			if p_u_10.terminal == true then
				v145 = false
			else
				local v146 = p_u_10.setTab
				v145 = type(v146) == "function"
			end
			return v145
		end,
		["profile"] = function() -- name: profile
			-- upvalues: (copy) p_u_10
			local v147 = p_u_10.profile
			return type(v147) ~= "table" and {} or p_u_10.profile
		end
	}
	local function v_u_151() -- name: invalidateAll
		-- upvalues: (copy) p_u_10
		for _, v149 in {
			"clanState",
			"clanList",
			"clanBoard",
			"clanLog",
			"clanStash",
			"clanRequests"
		} do
			local v150 = p_u_10.invalidate
			pcall(v150, v149)
		end
	end
	v_u_148.invalidateAll = v_u_151
	local function v_u_161(p152) -- name: normalize
		-- upvalues: (ref) v_u_61
		if type(p152) ~= "table" then
			return nil
		end
		if p152.has == nil then
			local v153 = p152.clan
			if type(v153) ~= "table" then
				local v154 = p152.id
				if type(v154) == "string" then
					local v155 = {
						["has"] = true,
						["clan"] = nil,
						["clan"] = p152
					}
					local v156 = v_u_61
					if type(v156) == "table" then
						v155.tx = v_u_61.tx
						v155.review = v_u_61.review
					end
					return v155
				end
			end
		end
		if p152.has == nil then
			local v157 = p152.clan
			if type(v157) == "table" and p152.clan.id then
				local v158 = {
					["has"] = true,
					["clan"] = nil,
					["clan"] = p152.clan
				}
				local v159 = v_u_61
				if type(v159) == "table" then
					v158.tx = v_u_61.tx
					v158.review = v_u_61.review
				end
				return v158
			end
		end
		if p152.has == true then
			local v160 = p152.clan
			if type(v160) ~= "table" then
				return nil
			end
		end
		return p152
	end
	local function v_u_162() end
	local function v_u_169(p163, p164, ...) -- name: call
		-- upvalues: (copy) v_u_17
		if p163 then
			local v165 = p163[p164]
			if type(v165) == "function" then
				local v166 = p163[p164]
				local v167, v168 = pcall(v166, ...)
				if not v167 then
					warn("[MenuClan] view." .. p164 .. " failed:", v168)
					v_u_17:SetAttribute("ClientError", "MenuClan " .. p164 .. ": " .. tostring(v168))
				end
			end
		end
	end
	local function v_u_172() -- name: destroyViews
		-- upvalues: (ref) v_u_73, (copy) v_u_169, (ref) v_u_74
		for v170, v171 in v_u_73 do
			v_u_169(v171, "destroy")
			if not v_u_74[v170] then
				continue
			end
			v_u_74[v170]:Destroy()
		end
		v_u_73 = {}
		v_u_74 = {}
	end
	local function v_u_177(p_u_173) -- name: onScreen
		while p_u_173 ~= nil and p_u_173 ~= game do
			local v174, v175 = pcall(function()
				-- upvalues: (ref) p_u_173
				if p_u_173:IsA("GuiObject") then
					return p_u_173.Visible
				else
					return not p_u_173:IsA("LayerCollector") and true or p_u_173.Enabled
				end
			end)
			if not v174 or v175 == false then
				return false
			end
			local v176 = p_u_173.Parent
			p_u_173 = v176
		end
		return p_u_173 == game
	end
	local function v_u_180() -- name: paintTransitSlow
		-- upvalues: (ref) v_u_79, (copy) v_u_37, (ref) v_u_82, (copy) v_u_103, (copy) v_u_28
		local v178
		if v_u_79 == nil or v_u_37 == nil then
			v178 = false
		else
			v178 = v_u_37.slowDue(v_u_79, os.clock())
		end
		if v178 ~= v_u_82 then
			v_u_82 = v178
			v_u_103.Text = not v178 and "" or v_u_37.slowText(v_u_28.UI)
			local v179 = v_u_103
			if v_u_79 == nil then
				v178 = false
			end
			v179.Visible = v178
		end
	end
	local function v_u_181() end
	local function v_u_229(p182) -- name: applyState
		-- upvalues: (copy) v_u_161, (ref) v_u_79, (copy) v_u_37, (ref) v_u_62, (ref) v_u_4, (copy) v_u_60, (ref) v_u_76, (ref) v_u_181, (ref) v_u_77, (ref) v_u_81, (ref) v_u_80, (copy) v_u_102, (ref) v_u_82, (copy) v_u_103, (ref) v_u_61, (ref) v_u_64, (ref) v_u_63, (ref) v_u_66, (copy) v_u_119, (copy) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_97, (copy) v_u_124, (copy) v_u_172, (ref) v_u_72, (ref) v_u_71, (copy) v_u_148, (copy) v_u_91, (copy) v_u_58, (ref) v_u_85, (ref) v_u_83, (copy) v_u_96, (ref) v_u_162, (ref) v_u_73, (ref) v_u_75, (copy) v_u_16, (copy) v_u_17, (copy) v_u_12, (copy) v_u_177, (copy) v_u_98
		local v183 = v_u_161(p182)
		if v183 == nil then
			return
		else
			if v_u_79 == nil and (v_u_37 ~= nil and not v_u_62) then
				local v184 = v_u_4[v_u_60]
				if v184 ~= nil then
					if v_u_37.resumeOk(v184, v183, os.clock()) then
						v_u_76 = true
						v_u_181(v184)
						return
					end
					v_u_4[v_u_60] = nil
				end
			end
			local v185 = nil
			if v_u_79 ~= nil or (v_u_37 == nil or not v_u_37.staleAfterLeft(v_u_77, v183, os.clock())) then
				if v_u_79 ~= nil and v_u_37 ~= nil then
					if not v_u_37.accept(v_u_79, v183) then
						return
					end
					v185 = v_u_79.kind
					local v186 = v_u_79.cid
					if v_u_79 ~= nil then
						if v_u_4[v_u_60] == v_u_79 then
							v_u_4[v_u_60] = nil
						end
						v_u_79 = nil
						v_u_81 = v_u_81 + 1
						if v_u_80 ~= nil then
							local v187 = v_u_80
							pcall(v187)
							v_u_80 = nil
						end
						v_u_102.Visible = false
						v_u_102.Text = ""
						v_u_82 = false
						v_u_103.Visible = false
						v_u_103.Text = ""
					end
					if v183.has ~= true and v186 ~= nil then
						v_u_77 = {
							["cid"] = v186,
							["at"] = os.clock()
						}
					end
				end
				local v188 = v_u_61
				v_u_61 = v183
				v_u_62 = true
				v_u_64 = "ok"
				v_u_63 = 0
				v_u_66 = os.clock()
				v_u_119()
				if v188.has == true and v_u_61.has ~= true then
					local v189 = v188.clan
					local v190
					if type(v189) == "table" then
						v190 = v188.clan.tag
					else
						v190 = nil
					end
					if not v_u_76 and type(v190) == "string" then
						local v191 = v188.clan
						local v192
						if type(v191) == "table" then
							v192 = v188.clan.st == "closing"
						else
							v192 = false
						end
						v_u_67 = v_u_28.UI[v192 and "GOT_DISBANDED" or "GOT_KICKED"]:format(v190) or ""
						v_u_68 = "warn"
						v_u_69 = v_u_67 == "" and 0 or os.clock() + 20
						v_u_97.set(v_u_67, v_u_68)
						v_u_124()
					end
					v_u_76 = false
				end
				if v185 ~= nil then
					v_u_76 = false
				end
				if v185 ~= nil and v_u_61.has == true then
					v_u_172()
					v_u_72 = {}
					v_u_71 = nil
				end
				local v193 = v_u_148.clan()
				if v193 then
					local v194 = v_u_91
					local v195 = v_u_58.label
					local v196 = v193.tag
					local v197 = v193.name or ""
					v194.Text = v195(v196, (tostring(v197)))
					local v198 = v193.count
					local v199 = tonumber(v198) or 0
					local v200 = v193.cap
					local v201 = tonumber(v200) or 30
					local v202 = string.upper
					local v203 = v193.rankName or v_u_28.rankName(v193, v193.rank)
					local v204 = ("%d/%d  %s"):format(v199, v201, v202((tostring(v203))))
					v_u_85 = v204
					if not v_u_83 then
						v_u_96.Text = v204
					end
				else
					v_u_91.Text = "Clans"
					v_u_85 = ""
					if not v_u_83 then
						v_u_96.Text = ""
					end
				end
				v_u_162()
				for _, v205 in v_u_73 do
					local v206 = v205.refresh
					if type(v206) ~= "function" then
						continue
					end
					local v207 = v205.refresh
					pcall(v207, "state")
				end
				local v208
				if v193 then
					v208 = v193.res
				else
					v208 = nil
				end
				if type(v208) == "table" and v208.seen == false then
					local v209 = v208.week
					if tonumber(v209) and v208.week ~= v_u_75 then
						v_u_75 = v208.week
						local v_u_210 = "MenuClanBoard"
						local function v211()
							-- upvalues: (ref) v_u_16, (copy) v_u_210
							return v_u_16.lib[v_u_210]
						end
						local v212, v213 = pcall(v211)
						if not v212 or type(v213) ~= "table" then
							v213 = nil
						end
						if v213 then
							local v214 = v213.resultModal
							if type(v214) == "function" then
								local v215 = v213.resultModal
								local v216 = v_u_148
								pcall(v215, v216, v208)
							end
						end
					end
				end
				local v217 = v_u_17
				local v218 = v_u_71
				local v219 = tostring(v218)
				local v220 = v_u_64
				local v221 = v_u_61.has == true
				v217:SetAttribute("MenuClanView", ("%s %s %s"):format(v219, v220, (tostring(v221))))
				if v185 ~= nil and v_u_37 ~= nil then
					v_u_67 = v_u_37.doneText(v185, v_u_28.UI) or ""
					v_u_68 = "success"
					v_u_69 = v_u_67 == "" and 0 or os.clock() + 6
					v_u_97.set(v_u_67, v_u_68)
					v_u_124()
					local function v228()
						-- upvalues: (ref) v_u_12, (ref) v_u_177, (ref) v_u_72, (ref) v_u_98
						if v_u_12.device() == "Gamepad" then
							local v222 = game:GetService("GuiService")
							local v223 = v222.SelectedObject
							if v223 == nil or not v_u_177(v223) then
								local v224 = v_u_72[1]
								local v225 = v_u_98:FindFirstChild("SubTabs")
								local v226
								if v224 == nil or v225 == nil then
									v226 = nil
								else
									local v227 = v224.id
									v226 = v225:FindFirstChild("Tab_" .. tostring(v227), true)
								end
								if v226 ~= nil and (v226:IsA("GuiButton") and v_u_177(v226)) then
									v222.SelectedObject = v226
								end
							end
						else
							return
						end
					end
					pcall(v228)
				end
			end
		end
	end
	v_u_148.apply = v_u_229
	local function v_u_235() -- name: devState
		-- upvalues: (copy) v_u_17, (ref) v_u_2
		local function v230()
			-- upvalues: (ref) v_u_17
			return v_u_17:GetAttribute("DevClanState")
		end
		local v231, v_u_232 = pcall(v230)
		if v231 and (type(v_u_232) == "string" and (v_u_232 ~= "" and v_u_2:IsStudio())) then
			local v233, v234 = pcall(function()
				-- upvalues: (copy) v_u_232
				return game:GetService("HttpService"):JSONDecode(v_u_232)
			end)
			if v233 and type(v234) == "table" then
				return v234
			end
		end
		return nil
	end
	local function v_u_239(p236) -- name: askState
		-- upvalues: (copy) v_u_17, (ref) v_u_2, (copy) v_u_235, (copy) v_u_148
		local v_u_237 = nil
		local function v238()
			-- upvalues: (ref) v_u_237, (ref) v_u_17
			v_u_237 = v_u_17:GetAttribute("DevClanFail")
		end
		pcall(v238)
		if v_u_2:IsStudio() and (v_u_237 == "busy" or v_u_237 == "throttle") then
			return nil
		else
			return v_u_235() or v_u_148.fetch("clanState", nil, p236 and 0 or 20)
		end
	end
	local function v_u_251(p_u_240) -- name: fetchState
		-- upvalues: (ref) v_u_65, (ref) v_u_19, (ref) v_u_81, (copy) v_u_239, (copy) v_u_37, (ref) v_u_79, (ref) v_u_251, (ref) v_u_63, (ref) v_u_62, (ref) v_u_64, (copy) v_u_124, (copy) v_u_17, (ref) v_u_71, (ref) v_u_61, (ref) v_u_20, (ref) v_u_73, (copy) v_u_229
		if not v_u_65 and v_u_19 then
			v_u_65 = true
			local v_u_241 = v_u_81
			task.spawn(function()
				-- upvalues: (ref) v_u_239, (copy) p_u_240, (ref) v_u_65, (ref) v_u_19, (ref) v_u_37, (copy) v_u_241, (ref) v_u_81, (ref) v_u_79, (ref) v_u_251, (ref) v_u_63, (ref) v_u_62, (ref) v_u_64, (ref) v_u_124, (ref) v_u_17, (ref) v_u_71, (ref) v_u_61, (ref) v_u_20, (ref) v_u_73, (ref) v_u_229
				local v242 = v_u_239(p_u_240)
				v_u_65 = false
				if v_u_19 then
					if v_u_37 == nil or not v_u_37.epochChanged(v_u_241, v_u_81) then
						if v242 == nil then
							v_u_63 = v_u_63 + 1
							if not v_u_62 then
								v_u_64 = v_u_63 >= 5 and "gave_up" or "retry"
								v_u_124()
							end
							local v243 = v_u_17
							local v244 = v_u_71
							local v245 = tostring(v244)
							local v246 = v_u_64
							local v247 = tostring(v246)
							local v248 = v_u_61.has == true
							v243:SetAttribute("MenuClanView", ("%s %s %s"):format(v245, v247, (tostring(v248))))
							if v_u_63 < 5 then
								task.delay(2 ^ (v_u_63 - 1) * 3, function()
									-- upvalues: (ref) v_u_19, (ref) v_u_20, (ref) v_u_62, (ref) v_u_251
									if v_u_19 and (v_u_20 and not v_u_62) then
										v_u_251(true)
									end
								end)
							end
							if v_u_73[v_u_71 or ""] then
								local v249 = v_u_73[v_u_71].refresh
								if type(v249) == "function" then
									local v250 = v_u_73[v_u_71].refresh
									pcall(v250, "state")
								end
							end
						else
							v_u_229(v242)
						end
					else
						if v_u_79 == nil and v_u_19 then
							task.defer(v_u_251, true)
						end
						return
					end
				else
					return
				end
			end)
		end
	end
	function v_u_148.reload(_) -- name: reload
		-- upvalues: (copy) v_u_151, (ref) v_u_251
		v_u_151()
		v_u_251(true)
	end
	v_u_105 = v_u_251
	function v_u_148.send(p252, p253, p254, p255) -- name: send
		-- upvalues: (copy) p_u_10, (copy) v_u_28, (copy) v_u_70, (copy) v_u_37, (ref) v_u_133
		local v256 = {}
		for v257, v258 in p253 or {} do
			v256[v257] = v258
		end
		v256.op = p252
		local v259 = p_u_10.op
		local v260, v261 = pcall(v259, v256)
		if v256.req ~= nil then
			v261 = v256.req
		end
		local v262 = tostring(v261)
		if not v260 then
			if p254 then
				task.defer(p254, false, v_u_28.text("TRY_AGAIN"), {
					["code"] = "TRY_AGAIN"
				}, nil)
			end
			return v262
		end
		v_u_70[v262] = {
			["cb"] = p254,
			["op"] = p252,
			["at"] = os.clock(),
			["timeout"] = p255 or v_u_28.REQ_TIMEOUT
		}
		if v_u_37 ~= nil then
			task.delay(v_u_37.WORKING_AFTER_SEC + 0.05, v_u_133)
		end
		return v262
	end
	local function v_u_272() -- name: transitTimeout
		-- upvalues: (ref) v_u_79, (ref) v_u_4, (copy) v_u_60, (ref) v_u_81, (ref) v_u_80, (copy) v_u_102, (ref) v_u_82, (copy) v_u_103, (copy) v_u_124, (copy) v_u_37, (copy) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_97, (ref) v_u_105, (ref) v_u_20, (ref) v_u_71, (ref) v_u_73, (copy) v_u_169, (copy) v_u_12, (copy) v_u_177, (ref) v_u_72, (copy) v_u_98
		if v_u_79 ~= nil then
			if v_u_79 ~= nil then
				if v_u_4[v_u_60] == v_u_79 then
					v_u_4[v_u_60] = nil
				end
				v_u_79 = nil
				v_u_81 = v_u_81 + 1
				if v_u_80 ~= nil then
					local v263 = v_u_80
					pcall(v263)
					v_u_80 = nil
				end
				v_u_102.Visible = false
				v_u_102.Text = ""
				v_u_82 = false
				v_u_103.Visible = false
				v_u_103.Text = ""
			end
			v_u_124()
			local v264
			if v_u_37 == nil then
				v264 = v_u_28.UI.TRANSIT_SLOW
			else
				v264 = v_u_37.slowText(v_u_28.UI)
			end
			v_u_67 = v264 or ""
			v_u_68 = "warn"
			v_u_69 = v_u_67 == "" and 0 or os.clock() + 12
			v_u_97.set(v_u_67, v_u_68)
			v_u_124()
			v_u_105(true)
			if v_u_20 and (v_u_71 ~= nil and v_u_73[v_u_71] ~= nil) then
				v_u_169(v_u_73[v_u_71], "show")
			end
			local function v271()
				-- upvalues: (ref) v_u_12, (ref) v_u_177, (ref) v_u_72, (ref) v_u_98
				if v_u_12.device() == "Gamepad" then
					local v265 = game:GetService("GuiService")
					local v266 = v265.SelectedObject
					if v266 == nil or not v_u_177(v266) then
						local v267 = v_u_72[1]
						local v268 = v_u_98:FindFirstChild("SubTabs")
						local v269
						if v267 == nil or v268 == nil then
							v269 = nil
						else
							local v270 = v267.id
							v269 = v268:FindFirstChild("Tab_" .. tostring(v270), true)
						end
						if v269 ~= nil and (v269:IsA("GuiButton") and v_u_177(v269)) then
							v265.SelectedObject = v269
						end
					end
				else
					return
				end
			end
			pcall(v271)
		end
	end
	local v_u_275 = {
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_19
			return v_u_19
		end,
		["current"] = function() -- name: current
			-- upvalues: (ref) v_u_79
			return v_u_79
		end,
		["before"] = function() -- name: before
			-- upvalues: (copy) v_u_151, (copy) v_u_180
			v_u_151()
			v_u_180()
		end,
		["ask"] = function() -- name: ask
			-- upvalues: (copy) v_u_239
			return v_u_239(true)
		end,
		["normalize"] = v_u_161,
		["now"] = function() -- name: now
			return os.clock()
		end,
		["wait"] = function(p273) -- name: wait
			task.wait(p273)
		end,
		["done"] = function(p274) -- name: done
			-- upvalues: (copy) v_u_229
			v_u_229(p274)
		end,
		["timeout"] = v_u_272
	}
	v_u_181 = function(p_u_276) -- name: beginTransit
		-- upvalues: (ref) v_u_79, (ref) v_u_4, (copy) v_u_60, (ref) v_u_81, (ref) v_u_80, (copy) v_u_102, (ref) v_u_82, (copy) v_u_103, (copy) v_u_91, (ref) v_u_85, (ref) v_u_83, (copy) v_u_96, (ref) v_u_133, (copy) v_u_37, (copy) v_u_28, (copy) v_u_58, (copy) v_u_180, (copy) v_u_124, (copy) v_u_275, (copy) v_u_17, (copy) v_u_272
		if v_u_79 ~= nil then
			if v_u_4[v_u_60] == v_u_79 then
				v_u_4[v_u_60] = nil
			end
			v_u_79 = nil
			v_u_81 = v_u_81 + 1
			if v_u_80 ~= nil then
				local v277 = v_u_80
				pcall(v277)
				v_u_80 = nil
			end
			v_u_102.Visible = false
			v_u_102.Text = ""
			v_u_82 = false
			v_u_103.Visible = false
			v_u_103.Text = ""
		end
		v_u_79 = p_u_276
		v_u_4[v_u_60] = p_u_276
		v_u_81 = v_u_81 + 1
		v_u_91.Text = "Clans"
		v_u_85 = ""
		if not v_u_83 then
			v_u_96.Text = ""
		end
		v_u_133()
		local v278 = v_u_37.text(p_u_276.kind, v_u_28.UI)
		if v_u_58.busyDots == nil then
			v_u_102.Text = v278 .. "..."
		else
			v_u_80 = v_u_58.busyDots.animate(v_u_102, v_u_58.busyDots.strip(v278))
		end
		v_u_180()
		v_u_124()
		task.spawn(function()
			-- upvalues: (ref) v_u_37, (copy) p_u_276, (ref) v_u_275, (ref) v_u_17, (ref) v_u_79, (ref) v_u_272
			local v279 = v_u_37.run
			local v280 = p_u_276
			local v281 = v_u_275
			local v282, v283 = pcall(v279, v280, v281)
			if not v282 then
				warn("[MenuClan] transit failed:", v283)
				v_u_17:SetAttribute("ClientError", "MenuClan transit: " .. tostring(v283))
				if v_u_79 == p_u_276 then
					v_u_272()
				end
			end
		end)
	end
	local function v_u_288(p284) -- name: startTransit
		-- upvalues: (copy) v_u_37, (copy) v_u_148, (ref) v_u_181
		if v_u_37 == nil then
			return false
		end
		local v285 = v_u_148.clan()
		local v286
		if v285 == nil then
			v286 = nil
		else
			local v287 = v285.id
			if type(v287) == "string" then
				v286 = v285.id
			else
				v286 = nil
			end
		end
		if v286 == nil then
			return false
		end
		v_u_181(v_u_37.new(p284, v286, os.clock()))
		return true
	end
	local function v_u_301(p289, p290, p291, p292, p293) -- name: finish
		-- upvalues: (copy) v_u_70, (ref) v_u_133, (ref) v_u_76, (ref) v_u_79, (copy) v_u_288, (copy) v_u_229, (copy) v_u_151, (ref) v_u_251, (copy) v_u_17
		local v294 = v_u_70[p289]
		if v294 then
			v_u_70[p289] = nil
			v_u_133()
			if p290 then
				local v295 = v294.op == "clanLeave" and true or v294.op == "clanDisband"
				if v295 then
					v_u_76 = true
				end
				if v295 then
					local v296 = v294.op
					if v_u_79 == nil then
						if v_u_288(v296 == "clanDisband" and "disband" or "leave") then
							v_u_76 = true
							v295 = true
						else
							v295 = false
						end
					else
						v_u_76 = true
						v295 = true
					end
				end
				if not v295 then
					local v297
					if type(p292) == "table" then
						v297 = p292.clan
					else
						v297 = nil
					end
					if v297 ~= nil then
						v_u_229(v297)
					end
					v_u_151()
					task.delay(0.6, v_u_251, true)
				end
			end
			if v294.cb then
				local v298 = v294.cb
				local v299, v300 = pcall(v298, p290, p291, p292, p293)
				if not v299 then
					warn("[MenuClan] callback failed:", v300)
					v_u_17:SetAttribute("ClientError", "MenuClan cb: " .. tostring(v300))
				end
			end
		end
	end
	local function v_u_312(p302) -- name: mountView
		-- upvalues: (ref) v_u_73, (ref) v_u_3, (copy) v_u_58, (copy) v_u_99, (ref) v_u_74, (copy) v_u_16, (copy) v_u_15, (copy) v_u_148, (copy) v_u_17
		if v_u_73[p302] then
			return v_u_73[p302]
		end
		local v303 = v_u_3.VIEWS[p302]
		local v304 = v_u_58.frame(v_u_99, "View_" .. p302, UDim2.fromScale(1, 1))
		v304.Visible = false
		v_u_74[p302] = v304
		local v305
		if v303 then
			local v_u_306 = v303[1]
			local function v307()
				-- upvalues: (ref) v_u_16, (copy) v_u_306
				return v_u_16.lib[v_u_306]
			end
			local v308
			v308, v305 = pcall(v307)
			if not v308 or type(v305) ~= "table" then
				v305 = nil
			end
		else
			v305 = v303
		end
		if v305 then
			v305 = v305[v303[2]]
		end
		if type(v305) ~= "function" then
			v_u_15.empty(v304, "This screen failed to load. Please reopen the menu.")
			v_u_73[p302] = {}
			return v_u_73[p302]
		end
		local v309 = v_u_148
		local v310, v311 = pcall(v305, v309, v304)
		if v310 and type(v311) == "table" then
			v_u_73[p302] = v311
			return v311
		end
		warn("[MenuClan] view failed:", p302, v311)
		v_u_17:SetAttribute("ClientError", "MenuClan view " .. p302 .. ": " .. tostring(v311))
		v_u_15.empty(v304, "This screen failed to load. Please reopen the menu.")
		v_u_73[p302] = {}
		return v_u_73[p302]
	end
	local function v_u_319(p313, _) -- name: selectView
		-- upvalues: (ref) v_u_71, (ref) v_u_73, (copy) v_u_169, (ref) v_u_74, (copy) v_u_312, (ref) v_u_20, (ref) v_u_100, (copy) v_u_17, (ref) v_u_64, (ref) v_u_61
		if v_u_71 and (v_u_71 ~= p313 and v_u_73[v_u_71]) then
			v_u_169(v_u_73[v_u_71], "hide")
			if v_u_74[v_u_71] then
				v_u_74[v_u_71].Visible = false
			end
		end
		v_u_71 = p313
		local v314 = v_u_312(p313)
		if v_u_74[p313] then
			v_u_74[p313].Visible = true
		end
		if v_u_20 then
			v_u_169(v314, "show")
		end
		if v_u_100 and v_u_100.get() ~= p313 then
			v_u_100.select(p313, true)
		end
		local v315 = v_u_17
		local v316 = v_u_64
		local v317 = tostring(v316)
		local v318 = v_u_61.has == true
		v315:SetAttribute("MenuClanView", ("%s %s %s"):format(p313, v317, (tostring(v318))))
	end
	function v_u_148.setTab(p320)
		-- upvalues: (ref) v_u_72, (ref) v_u_319
		for _, v321 in v_u_72 do
			if v321.id ~= p320 then
				continue
			end
			v_u_319(p320)
			return
		end
	end
	v_u_162 = function() -- name: drawTabs
		-- upvalues: (ref) v_u_62, (copy) v_u_124, (ref) v_u_61, (copy) v_u_28, (copy) v_u_44, (ref) v_u_72, (copy) v_u_98, (ref) v_u_71, (copy) v_u_172, (copy) v_u_12, (ref) v_u_319, (ref) v_u_100
		if v_u_62 then
			local v322 = v_u_61.invites
			local v323 = type(v322) == "table" and #v_u_61.invites or 0
			local v324 = v_u_28.subTabs(v_u_61, v323, v_u_44)
			if not v_u_28.sameTabs(v324, v_u_72) then
				v_u_72 = v324
				if v_u_98:FindFirstChild("SubTabs") then
					v_u_98.SubTabs:Destroy()
				end
				local v325 = v_u_71
				local v326 = false
				for _, v327 in v324 do
					if v327.id ~= v325 then
						continue
					end
					v326 = true
				end
				if not v326 then
					v_u_172()
					v325 = v324[1].id
				end
				local _, v329 = v_u_12.tabs({
					["parent"] = nil,
					["name"] = "SubTabs",
					["tabs"] = nil,
					["selected"] = nil,
					["size"] = nil,
					["onChange"] = nil,
					["parent"] = v_u_98,
					["tabs"] = v324,
					["selected"] = v325,
					["size"] = UDim2.fromScale(1, 1),
					["onChange"] = function(p328) -- name: onChange
						-- upvalues: (ref) v_u_319
						v_u_319(p328)
					end
				})
				v_u_100 = v329
				v_u_319(v325)
			end
			v_u_124()
		else
			v_u_124()
		end
	end
	function v18.draw() -- name: draw
		-- upvalues: (ref) v_u_162
		v_u_162()
	end
	function v18.show() -- name: show
		-- upvalues: (ref) v_u_20, (ref) v_u_162, (ref) v_u_62, (ref) v_u_71, (ref) v_u_73, (ref) v_u_79, (copy) v_u_169, (ref) v_u_64, (ref) v_u_63, (copy) v_u_124, (ref) v_u_251
		v_u_20 = true
		v_u_162()
		if v_u_62 and (v_u_71 and (v_u_73[v_u_71] and v_u_79 == nil)) then
			v_u_169(v_u_73[v_u_71], "show")
		end
		if not v_u_62 and v_u_64 == "gave_up" then
			v_u_63 = 0
			v_u_64 = "loading"
			v_u_124()
		end
		v_u_251(true)
	end
	function v18.hide() -- name: hide
		-- upvalues: (ref) v_u_20, (ref) v_u_71, (ref) v_u_73, (copy) v_u_169, (copy) v_u_70, (copy) v_u_28, (ref) v_u_133
		v_u_20 = false
		if v_u_71 and v_u_73[v_u_71] then
			v_u_169(v_u_73[v_u_71], "hide")
		end
		for v330, v331 in v_u_70 do
			v_u_70[v330] = nil
			if not v331.cb then
				continue
			end
			local v332 = v331.cb
			local v333 = v_u_28.text("TRY_AGAIN")
			pcall(v332, false, v333, {
				["code"] = "TRY_AGAIN",
				["lost"] = true
			}, nil)
		end
		v_u_133()
	end
	function v18.refresh(p334, p335) -- name: refresh
		-- upvalues: (copy) v_u_70, (copy) v_u_301, (copy) v_u_151, (ref) v_u_79, (ref) v_u_76, (copy) v_u_288, (ref) v_u_251, (copy) v_u_148, (ref) v_u_62, (ref) v_u_66, (ref) v_u_71, (ref) v_u_73, (copy) v_u_169
		if p334 == "result" and type(p335) == "table" then
			local v336 = p335.req
			local v337 = tostring(v336)
			if v_u_70[v337] then
				local v338 = p335.data
				local v339
				if type(v338) == "table" then
					v339 = p335.data
				else
					v339 = nil
				end
				v_u_301(v337, p335.ok == true, p335.msg, v339, p335)
				if v_u_71 and v_u_73[v_u_71] then
					v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
				end
				return
			else
				local v340 = p335.op
				if type(v340) == "string" then
					local v341 = p335.op
					if string.sub(v341, 1, 4) == "clan" and p335.ok == true then
						v_u_151()
						if p335.op == "clanLeave" or p335.op == "clanDisband" then
							local v342 = p335.op
							local v343
							if v_u_79 == nil then
								if v_u_288(v342 == "clanDisband" and "disband" or "leave") then
									v_u_76 = true
									v343 = true
								else
									v343 = false
								end
							else
								v_u_76 = true
								v343 = true
							end
							if v343 then
								if v_u_71 and v_u_73[v_u_71] then
									v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
								end
								return
							end
							v_u_251(true)
						else
							v_u_251(true)
						end
						if v_u_71 and v_u_73[v_u_71] then
							v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
						end
					elseif v_u_71 and v_u_73[v_u_71] then
						v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
					end
				else
					if v_u_71 and v_u_73[v_u_71] then
						v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
					end
					return
				end
			end
		else
			if p334 == "profile" then
				local v344 = v_u_148.profile()
				local v345 = v344.clan
				local v346
				if type(v345) == "table" then
					v346 = v344.clan.id
				else
					v346 = nil
				end
				local v347
				if v_u_148.clan() then
					v347 = v_u_148.clan().id
				else
					v347 = nil
				end
				if v_u_62 and (v_u_79 == nil and (v346 ~= v347 and os.clock() - v_u_66 > 2)) then
					v_u_251(true)
				end
			end
			if v_u_71 and v_u_73[v_u_71] then
				v_u_169(v_u_73[v_u_71], "refresh", p334, p335)
			end
			return
		end
	end
	function v18.tick(_) -- name: tick
		-- upvalues: (copy) v_u_70, (copy) v_u_28, (ref) v_u_69, (ref) v_u_67, (ref) v_u_68, (copy) v_u_97, (copy) v_u_124, (ref) v_u_133, (ref) v_u_79, (copy) v_u_37, (copy) v_u_272, (copy) v_u_180, (ref) v_u_20, (ref) v_u_62, (ref) v_u_66, (ref) v_u_251, (ref) v_u_71, (ref) v_u_73, (copy) v_u_169
		local v348 = os.clock()
		for v349, v350 in v_u_70 do
			if v348 - v350.at <= v350.timeout then
				continue
			end
			v_u_70[v349] = nil
			if not v350.cb then
				continue
			end
			local v351 = v350.cb
			local v352 = v_u_28.text("TRY_AGAIN")
			pcall(v351, false, v352, {
				["code"] = "TRY_AGAIN",
				["timeout"] = true
			}, nil)
		end
		if v_u_69 > 0 and v_u_69 < v348 then
			v_u_67 = ""
			v_u_68 = "info"
			v_u_69 = v_u_67 == "" and 0 or os.clock() + 12
			v_u_97.set(v_u_67, v_u_68)
			v_u_124()
		end
		v_u_133()
		if v_u_79 == nil then
			if v_u_20 and (v_u_62 and v348 - v_u_66 > 30) then
				v_u_251(false)
			end
			if v_u_71 and v_u_73[v_u_71] then
				v_u_169(v_u_73[v_u_71], "tick")
			end
		elseif v_u_37 ~= nil then
			if v_u_37.step(v_u_79, nil, v348) == "timeout" then
				v_u_272()
				return
			end
			v_u_180()
		end
	end
	function v18.destroy() -- name: destroy
		-- upvalues: (ref) v_u_19, (ref) v_u_80, (ref) v_u_84, (ref) v_u_78, (ref) v_u_73, (copy) v_u_169
		v_u_19 = false
		if v_u_80 ~= nil then
			local v353 = v_u_80
			pcall(v353)
			v_u_80 = nil
		end
		if v_u_84 ~= nil then
			local v354 = v_u_84
			pcall(v354)
			v_u_84 = nil
		end
		if v_u_78 ~= nil then
			local function v355()
				-- upvalues: (ref) v_u_78
				v_u_78:Disconnect()
			end
			pcall(v355)
			v_u_78 = nil
		end
		for _, v356 in v_u_73 do
			v_u_169(v356, "destroy")
		end
		v_u_73 = {}
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_16, (ref) v_u_19, (copy) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_97, (copy) v_u_124, (copy) v_u_12, (ref) v_u_105, (ref) v_u_78
		local function v362()
			-- upvalues: (ref) v_u_16, (ref) v_u_19, (ref) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (ref) v_u_97, (ref) v_u_124, (ref) v_u_12, (ref) v_u_105
			return v_u_16.net.listen("clan.note", function(p357)
				-- upvalues: (ref) v_u_19, (ref) v_u_28, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (ref) v_u_97, (ref) v_u_124, (ref) v_u_12, (ref) v_u_105
				if v_u_19 and type(p357) == "table" then
					local v358 = p357.tag
					if type(v358) == "string" and string.find(v358, "^[A-Z0-9][A-Z0-9][A-Z0-9][A-Z0-9]?$") ~= nil then
						local v359 = p357.k == "disbanded" and "GOT_DISBANDED" or (p357.k == "removed" and "GOT_KICKED" or nil)
						if v359 ~= nil then
							local v360 = v_u_28.UI[v359]:format(v358)
							v_u_67 = v360 or ""
							v_u_68 = "warn"
							v_u_69 = v_u_67 == "" and 0 or os.clock() + 20
							v_u_97.set(v_u_67, v_u_68)
							v_u_124()
							local v361 = v_u_12.toast
							pcall(v361, v360, "warn")
							v_u_105(true)
						end
					else
						return
					end
				else
					return
				end
			end)
		end
		local v363, v_u_364 = pcall(v362)
		if v363 and v_u_364 ~= nil then
			if v_u_19 then
				v_u_78 = v_u_364
				return
			end
			pcall(function()
				-- upvalues: (copy) v_u_364
				v_u_364:Disconnect()
			end)
		end
	end)
	v_u_162()
	return v18
end
return v_u_3