-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuActs

local v_u_111 = {
	["plan"] = function(p1, p2) -- name: plan
		local v3 = {}
		local v4 = {}
		local v5 = {}
		local v6 = {}
		local v7 = 0
		local v8
		if type(p2) == "table" then
			local v9 = p2.ACTS
			if type(v9) == "table" then
				v8 = p2.ACTS
			else
				v8 = nil
			end
		else
			v8 = nil
		end
		local v10 = {}
		local v11 = {}
		local v12
		if v8 then
			v12 = v7
			for _, v13 in v8 do
				local v14 = {}
				for _, v15 in p1 do
					if type(v15) ~= "table" then
						continue
					end
					local v16
					if type(p2) == "table" then
						local v17 = p2.actOf
						if type(v17) == "function" then
							local v18 = p2.actOf(v15)
							v16 = type(v18) ~= "number" and 1 or v18
						else
							v16 = 1
						end
					else
						v16 = 1
					end
					if v16 ~= v13.id then
						continue
					end
					table.insert(v14, v15)
				end
				if #v14 > 0 then
					local v19 = v13.id
					v7 = v12 + 1
					local v20 = {
						["kind"] = "header",
						["act"] = nil,
						["id"] = nil,
						["order"] = nil,
						["act"] = v13,
						["order"] = v7
					}
					table.insert(v3, v20)
					v5[v19] = v7
					v12 = v7
					for _, v21 in v14 do
						local v22 = v21.id
						local v23 = v21.id
						v7 = v12 + 1
						local v24 = {
							["kind"] = "map",
							["act"] = nil,
							["id"] = nil,
							["order"] = nil,
							["act"] = v13,
							["id"] = v23,
							["order"] = v7
						}
						table.insert(v3, v24)
						v4[v22] = v7
						v10[v21.id] = true
						v12 = v7
					end
				else
					if v13.soon ~= true then
						break
					end
					table.insert(v11, v13)
				end
			end
		else
			v12 = v7
		end
		for _, v25 in p1 do
			if type(v25) ~= "table" or v10[v25.id] then
				continue
			end
			local v26 = v25.id
			local v27 = v25.id
			v7 = v12 + 1
			local v28 = {
				["kind"] = "map",
				["act"] = nil,
				["id"] = nil,
				["order"] = nil,
				["id"] = v27,
				["order"] = v7
			}
			table.insert(v3, v28)
			v4[v26] = v7
			v12 = v7
		end
		v7 = v12 + 1
		local v29 = {
			["kind"] = "hint",
			["act"] = nil,
			["id"] = nil,
			["order"] = nil,
			["order"] = v7
		}
		table.insert(v3, v29)
		local v30 = v7
		local v31 = v7
		for _, v32 in v11 do
			local v33 = v32.id
			v7 = v31 + 1
			local v34 = {
				["kind"] = "teaser",
				["act"] = nil,
				["id"] = nil,
				["order"] = nil,
				["act"] = v32,
				["order"] = v7
			}
			table.insert(v3, v34)
			v6[v33] = v7
			v31 = v7
		end
		return {
			["entries"] = v3,
			["order"] = v4,
			["hintOrder"] = v30,
			["headers"] = v5,
			["teasers"] = v6
		}
	end,
	["WARN_MAX"] = 120,
	["warnText"] = function(p35) -- name: warnText
		-- upvalues: (copy) v_u_111
		if type(p35) ~= "table" then
			return nil
		end
		local v36 = p35.warn
		if type(v36) ~= "string" then
			return nil
		end
		local v37 = string.gsub(v36, "^%s+", "")
		local v38 = string.gsub(v37, "%s+$", "")
		if v38 == "" then
			return nil
		end
		if #v38 > v_u_111.WARN_MAX then
			local v39 = v_u_111.WARN_MAX
			v38 = string.sub(v38, 1, v39)
		end
		return v38
	end,
	["attach"] = function(p_u_40, p_u_41) -- name: attach
		-- upvalues: (copy) v_u_111
		local v_u_42 = p_u_40.ui
		local v_u_43 = p_u_40.theme
		local v_u_44 = v_u_43.color
		local v_u_45 = p_u_41.maps
		local v46 = p_u_41.plan
		local v_u_47 = p_u_41.host
		local v_u_48 = p_u_41.compact == true
		local v_u_49 = {
			["headers"] = nil,
			["teasers"] = nil,
			["tag"] = nil,
			["headers"] = {},
			["teasers"] = {}
		}
		local v_u_50 = nil
		local function v51()
			-- upvalues: (ref) v_u_50, (copy) p_u_40
			v_u_50 = p_u_40.cctx.shared.MapReveal
		end
		pcall(v51)
		local v_u_52
		if type(v_u_45) == "table" then
			local v53 = v_u_45.actDef
			if type(v53) == "function" then
				local v54 = v_u_45.actSubtitle
				v_u_52 = type(v54) == "function"
			else
				v_u_52 = false
			end
		else
			v_u_52 = false
		end
		local function v60(p55, p56) -- name: buildHeader
			-- upvalues: (copy) v_u_45, (copy) v_u_42, (copy) v_u_48, (copy) v_u_47, (copy) v_u_44, (copy) v_u_49
			local v57 = v_u_45.actDef(p55)
			if v57 then
				local v58 = v_u_42.new("Frame", {
					["Name"] = nil,
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Active"] = false,
					["Name"] = "ActHeader_" .. tostring(p55),
					["Size"] = UDim2.new(1, 0, 0, v_u_48 and 26 or 30),
					["LayoutOrder"] = p56
				}, v_u_47)
				v_u_42.new("Frame", {
					["Name"] = "Tick",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_44.accent,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 0, 0.5, 0),
					["Size"] = UDim2.fromOffset(3, 14)
				}, v58)
				v_u_42.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "caps",
					["textSize"] = 15,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v58,
					["text"] = v57.name,
					["color"] = v_u_44.accent,
					["position"] = UDim2.fromOffset(12, 0),
					["size"] = UDim2.new(0, 64, 1, 0)
				})
				local v59 = v_u_42.label({
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = "",
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v58,
					["color"] = v_u_44.text2,
					["position"] = UDim2.fromOffset(80, 0),
					["size"] = UDim2.new(1, -80, 1, 0)
				})
				v_u_42.new("Frame", {
					["Name"] = "Rule",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_44.line,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, 1)
				}, v58)
				v_u_49.headers[p55] = {
					["row"] = nil,
					["sub"] = nil,
					["last"] = "",
					["row"] = v58,
					["sub"] = v59
				}
			end
		end
		local function v72(p61, p62) -- name: buildTeaser
			-- upvalues: (copy) v_u_45, (copy) v_u_43, (copy) v_u_48, (copy) v_u_42, (copy) v_u_44, (copy) v_u_47, (copy) p_u_41, (copy) v_u_49
			local v63 = v_u_45.actDef(p61)
			if v63 then
				local v64 = v_u_43.touch(v_u_48 and 52 or 58)
				local v65 = v_u_42.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.5,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Active"] = false,
					["Selectable"] = false,
					["Name"] = "ActTeaser_" .. tostring(p61),
					["BackgroundColor3"] = v_u_44.raised,
					["Size"] = UDim2.new(1, 0, 0, v64),
					["LayoutOrder"] = p62
				}, v_u_47)
				v_u_42.stroke(v65, v_u_44.line)
				v_u_42.new("Frame", {
					["Name"] = "Edge",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_44.line,
					["Size"] = UDim2.new(0, 3, 1, 0)
				}, v65)
				v_u_42.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "h3",
					["textSize"] = 17,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v65,
					["text"] = v63.name,
					["color"] = v_u_44.text2,
					["position"] = UDim2.fromOffset(14, 7),
					["size"] = UDim2.new(0.5, -14, 0, 22)
				})
				v_u_42.label({
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v65,
					["text"] = v63.subtitle,
					["color"] = v_u_44.muted,
					["position"] = UDim2.new(0, 14, 1, -24),
					["size"] = UDim2.new(0.5, -14, 0, 18)
				})
				local v66 = p_u_41.soonW
				local v67 = tonumber(v66) or (v_u_48 and 104 or 118)
				local v68 = v_u_42.new("Frame", {
					["Name"] = "Soon",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_44.accentDeep,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -12, 0.5, 0),
					["Size"] = UDim2.fromOffset(v67, 24)
				}, v65)
				v_u_42.stroke(v68, v_u_44.accentDim)
				local v69 = v_u_42.label
				local v70 = {
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "center",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v68
				}
				local v71 = p_u_41.soonText or "Coming soon"
				v70.text = tostring(v71)
				v70.color = v_u_44.accent
				v70.position = UDim2.fromOffset(22, 0)
				v70.size = UDim2.new(1, -28, 1, 0)
				v69(v70)
				v_u_42.icon("lock", {
					["parent"] = nil,
					["size"] = 12,
					["thickness"] = 1.5,
					["color"] = nil,
					["position"] = nil,
					["parent"] = v68,
					["color"] = v_u_44.accent,
					["position"] = UDim2.fromOffset(8, 6)
				})
				v_u_49.teasers[p61] = {
					["row"] = v65,
					["tag"] = v68
				}
			end
		end
		local v_u_73 = nil
		local function v82() -- name: buildTag
			-- upvalues: (copy) p_u_41, (copy) v_u_48, (copy) v_u_42, (copy) v_u_44, (ref) v_u_73, (copy) v_u_49
			local v74 = p_u_41.head
			if typeof(v74) == "Instance" then
				local v75 = v_u_48 and 44 or 48
				local v76 = v_u_42.new("Frame", {
					["Name"] = "ActTag",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["BackgroundColor3"] = v_u_44.accentDeep,
					["Position"] = UDim2.fromOffset(0, 0),
					["Size"] = UDim2.fromOffset(v75, 16)
				}, v74)
				v_u_42.stroke(v76, v_u_44.accentDim)
				v_u_73 = v_u_42.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = "",
					["style"] = "micro",
					["color"] = nil,
					["align"] = "center",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v76,
					["color"] = v_u_44.accent,
					["position"] = UDim2.fromOffset(2, 0),
					["size"] = UDim2.new(1, -4, 1, 0)
				})
				local v77 = v74:FindFirstChild("Title")
				if v77 ~= nil and v77:IsA("TextLabel") then
					local v78 = v77.TextSize
					v77.Position = UDim2.fromOffset(v75 + 8, 0)
					v77.Size = UDim2.new(0.5, -(v75 + 8), 1, 0)
					if not v77:FindFirstChildOfClass("UITextSizeConstraint") then
						local v79 = Instance.new("UITextSizeConstraint")
						v79.MaxTextSize = v78
						local v80 = v78 * 0.6
						local v81 = math.floor(v80)
						v79.MinTextSize = math.max(8, v81)
						v79.Parent = v77
					end
					v77.TextScaled = true
				end
				v_u_49.tag = v76
			end
		end
		local v_u_83 = nil
		local function v87() -- name: buildWarn
			-- upvalues: (copy) p_u_41, (copy) v_u_42, (copy) v_u_44, (ref) v_u_83, (copy) v_u_49
			local v84 = p_u_41.head
			if typeof(v84) == "Instance" then
				local v85 = v84.Parent
				if typeof(v85) == "Instance" and v85:IsA("GuiObject") then
					local v86 = v_u_42.label({
						["parent"] = nil,
						["name"] = "FlashWarn",
						["text"] = "",
						["style"] = "micro",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 4,
						["track"] = false,
						["parent"] = v85,
						["color"] = v_u_44.accent
					})
					v86.Visible = false
					v_u_83 = v86
					v_u_49.warn = v86
				end
			else
				return
			end
		end
		if v_u_52 and type(v46) == "table" then
			for v88, v89 in v46.headers do
				v60(v88, v89)
			end
			for v90, v91 in v46.teasers do
				v72(v90, v91)
			end
			v82()
		end
		v87()
		local v_u_92 = ""
		local v_u_93 = ""
		function v_u_49.paint(p94) -- name: paint
			-- upvalues: (ref) v_u_83, (ref) v_u_111, (ref) v_u_93, (copy) v_u_42, (copy) v_u_52, (copy) v_u_45, (copy) v_u_49, (ref) v_u_92, (ref) v_u_73, (ref) v_u_50
			if v_u_83 ~= nil then
				local v95 = v_u_111.warnText(p94) or ""
				if v95 ~= v_u_93 then
					v_u_93 = v95
					v_u_83.Visible = v95 ~= ""
					v_u_42.setText(v_u_83, v95)
				end
			end
			if v_u_52 then
				local v96 = v_u_45.actName(p94) or ""
				if v_u_49.tag and v96 ~= v_u_92 then
					v_u_92 = v96
					v_u_49.tag.Visible = v96 ~= ""
					if v_u_73 then
						v_u_42.setText(v_u_73, v96)
					end
				end
				local v97
				if v_u_50 == nil then
					v97 = false
				else
					local v98 = v_u_50.clientRevealed
					if type(v98) == "function" then
						v97 = v_u_50.clientRevealed() == true
					else
						v97 = false
					end
				end
				for v99, v100 in v_u_49.headers do
					local v101 = v_u_45.actSubtitle(v99, v97)
					if v101 == v100.last then
						continue
					end
					v100.last = v101
					v_u_42.setText(v100.sub, v101)
				end
			end
		end
		function v_u_49.state() -- name: state
			-- upvalues: (ref) v_u_92, (ref) v_u_83, (ref) v_u_93, (copy) v_u_49
			local v102 = { "tag=" .. v_u_92 }
			if v_u_83 ~= nil then
				local v103 = "warn=" .. (v_u_93 == "" and "0" or "1")
				table.insert(v102, v103)
			end
			local v104 = {}
			for v105 in v_u_49.headers do
				table.insert(v104, v105)
			end
			table.sort(v104)
			for _, v106 in v104 do
				local v107 = v_u_49.headers[v106].last
				table.insert(v102, ("header%d=%s"):format(v106, v107))
			end
			local v108 = {}
			for v109 in v_u_49.teasers do
				table.insert(v108, v109)
			end
			table.sort(v108)
			for _, v110 in v108 do
				table.insert(v102, ("teaser%d"):format(v110))
			end
			return table.concat(v102, " ")
		end
		return v_u_49
	end
}
return v_u_111