-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntTrackView

local v_u_143 = {
	["MAX_PRINTS"] = 900,
	["MAX_PARTS"] = 420,
	["RADIUS"] = 120,
	["SIZE"] = Vector3.new(1, 0.06, 1.8),
	["FOOT"] = 0.45,
	["EVERY"] = 0.2,
	["ALPHA_NEW"] = 0.08,
	["ALPHA_OLD"] = 0.9,
	["VIS_EVERY"] = 0.05,
	["shownAlpha"] = function(p1, p2) -- name: shownAlpha
		local v3 = (type(p2) ~= "number" or p2 ~= p2) and 1 or math.clamp(p2, 0, 1)
		return 1 - (1 - p1) * v3
	end,
	["alpha"] = function(p4, p5) -- name: alpha
		-- upvalues: (copy) v_u_143
		local v6 = (type(p5) ~= "number" or p5 <= 0) and 30 or p5
		local v7
		if type(p4) == "number" and p4 == p4 then
			local v8 = p4 / v6
			v7 = math.clamp(v8, 0, 1)
		else
			v7 = 1
		end
		return v_u_143.ALPHA_NEW + (v_u_143.ALPHA_OLD - v_u_143.ALPHA_NEW) * v7
	end,
	["place"] = function(p9) -- name: place
		-- upvalues: (copy) v_u_143
		local v10 = p9.a
		local v11 = type(v10) ~= "number" and 0 or p9.a
		local v12 = p9.s == -1 and -1 or 1
		return p9.x + math.cos(v11) * v_u_143.FOOT * v12, p9.z - math.sin(v11) * v_u_143.FOOT * v12, v11
	end,
	["keep"] = function(p13, p14, p15, p16) -- name: keep
		if #p13 <= p14 then
			return p13
		end
		local v17 = {}
		for v18, v19 in p13 do
			local v20 = v19.x - (p15 or 0)
			local v21 = v19.z - (p16 or 0)
			local v22 = {
				["i"] = v18,
				["d"] = v20 * v20 + v21 * v21
			}
			table.insert(v17, v22)
		end
		table.sort(v17, function(p23, p24)
			if p23.d == p24.d then
				return p23.i < p24.i
			else
				return p23.d < p24.d
			end
		end)
		local v25 = {}
		for v26 = 1, p14 do
			v25[v17[v26].i] = true
		end
		local v27 = {}
		for v28, v29 in p13 do
			if not v25[v28] then
				continue
			end
			table.insert(v27, v29)
		end
		return v27
	end,
	["new"] = function(p_u_30) -- name: new
		-- upvalues: (copy) v_u_143
		local v_u_31 = {}
		local v_u_32 = p_u_30.rules
		local v_u_33 = v_u_32 and (v_u_32.FP_LIFE or 30) or 30
		local v_u_34 = p_u_30.now or os.clock
		local v35 = p_u_30.decalL
		local v_u_36
		if type(v35) == "string" and p_u_30.decalL ~= "" then
			v_u_36 = p_u_30.decalL
		else
			v_u_36 = nil
		end
		local v37 = p_u_30.decalR
		local v_u_38
		if type(v37) == "string" and p_u_30.decalR ~= "" then
			v_u_38 = p_u_30.decalR
		else
			v_u_38 = nil
		end
		local v_u_39 = Instance.new("Folder")
		v_u_39.Name = "HuntTracksLocal"
		v_u_39.Parent = p_u_30.parent or workspace
		local v_u_40 = {}
		local v_u_41 = {}
		local v_u_42 = true
		local v_u_43 = 0
		local v_u_44 = 0
		function v_u_31.add(p45) -- name: add
			-- upvalues: (ref) v_u_42, (copy) v_u_34, (copy) v_u_41, (ref) v_u_40, (copy) v_u_33, (ref) v_u_143
			if v_u_42 and type(p45) == "table" then
				local v46 = p45.list
				if type(v46) == "table" then
					local v47 = p45.y
					local v48 = type(v47) ~= "number" and 0 or p45.y
					local v49 = v_u_34()
					for _, v50 in p45.list do
						if type(v50) ~= "table" then
							continue
						end
						local v51 = v50.x
						if type(v51) ~= "number" then
							continue
						end
						local v52 = v50.z
						if type(v52) ~= "number" or (v50.x ~= v50.x or v50.z ~= v50.z) then
							continue
						end
						v_u_41[v50.c or 1] = true
						local v53 = v_u_40
						local v54 = {}
						local v55 = v50.c
						v54.c = type(v55) ~= "number" and 1 or v50.c
						v54.x = v50.x
						v54.z = v50.z
						v54.y = v48
						local v56 = v50.a
						v54.a = type(v56) ~= "number" and 0 or v50.a
						v54.s = v50.s == -1 and -1 or 1
						local v57 = v50.d
						local v58
						if type(v57) == "number" then
							local v59 = v50.d
							local v60 = v_u_33
							v58 = math.clamp(v59, 0, v60)
						else
							v58 = 0
						end
						v54.born = v49 - v58
						table.insert(v53, v54)
					end
					while #v_u_40 > v_u_143.MAX_PRINTS do
						local v61 = table.remove(v_u_40, 1)
						v61.decal = nil
						if v61.part == nil then
							continue
						end
						v61.part:Destroy()
						v61.part = nil
					end
					return
				end
			end
		end
		local function v_u_94(p62) -- name: build
			-- upvalues: (ref) v_u_143, (copy) v_u_32, (copy) v_u_36, (copy) v_u_38, (copy) v_u_34, (copy) v_u_33, (copy) p_u_30, (copy) v_u_39
			local v63 = Instance.new("Part")
			v63.Name = "Print"
			v63.Shape = Enum.PartType.Block
			v63.Size = v_u_143.SIZE
			v63.Material = Enum.Material.Neon
			local v64 = p62.c
			local v65
			if v_u_32 and v_u_32.fpColor then
				local v66, v67, v68 = v_u_32.fpColor(v64)
				v65 = Color3.fromRGB(v66, v67, v68)
			else
				v65 = Color3.fromRGB(255, 255, 255)
			end
			v63.Color = v65
			v63.Anchored = true
			v63.CanCollide = false
			v63.CanQuery = false
			v63.CanTouch = false
			v63.CastShadow = false
			local v69, v70, v71 = v_u_143.place(p62)
			v63.CFrame = CFrame.new(v69, p62.y + 0.05, v70) * CFrame.Angles(0, v71, 0)
			local v72
			if v_u_36 and v_u_38 then
				local v73 = p62.s
				if (tonumber(v73) or 1) < 0 then
					v72 = v_u_36
				else
					v72 = v_u_38
				end
			else
				v72 = nil
			end
			if v72 then
				v63.Transparency = 1
				local v74 = Instance.new("Decal")
				v74.Name = "Boot"
				v74.Face = Enum.NormalId.Top
				v74.Texture = v72
				local v75 = p62.c
				local v76
				if v_u_32 and v_u_32.fpColor then
					local v77, v78, v79 = v_u_32.fpColor(v75)
					v76 = Color3.fromRGB(v77, v78, v79)
				else
					v76 = Color3.fromRGB(255, 255, 255)
				end
				v74.Color3 = v76
				v74.Transparency = v_u_143.alpha(v_u_34() - p62.born, v_u_33)
				v74.Parent = v63
				p62.decal = v74
			else
				v63.Transparency = v_u_143.alpha(v_u_34() - p62.born, v_u_33)
				local v80 = Instance.new("SpecialMesh")
				v80.MeshType = Enum.MeshType.Sphere
				v80.Scale = Vector3.new(1, 1, 1)
				v80.Parent = v63
			end
			p62.part = v63
			local v81 = v_u_34()
			local v82 = v_u_143.shownAlpha
			local v83 = v_u_143.alpha(v81 - p62.born, v_u_33)
			local v84 = p_u_30.vis
			local v85
			if type(v84) == "function" then
				local v86 = p_u_30.vis
				local v87 = p62.x
				local v88 = p62.y + 0.1
				local v89 = p62.z
				local v90 = Vector3.new(v87, v88, v89)
				local v91, v92 = pcall(v86, v90)
				v85 = (not v91 or type(v92) ~= "number") and 1 or v92
			else
				v85 = 1
			end
			local v93 = v82(v83, v85)
			if p62.decal == nil then
				if p62.part ~= nil then
					p62.part.Transparency = v93
				end
			else
				p62.decal.Transparency = v93
			end
			v63.Parent = v_u_39
		end
		function v_u_31.step(p95) -- name: step
			-- upvalues: (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_143, (copy) v_u_34, (ref) v_u_40, (copy) v_u_33, (copy) p_u_30, (copy) v_u_94
			if v_u_42 then
				v_u_43 = v_u_43 + p95
				v_u_44 = v_u_44 + p95
				if v_u_43 < v_u_143.EVERY then
					if v_u_44 >= v_u_143.VIS_EVERY then
						v_u_44 = 0
						local v96 = v_u_34()
						for _, v97 in v_u_40 do
							if v97.part == nil then
								continue
							end
							local v98 = v_u_143.shownAlpha
							local v99 = v_u_143.alpha(v96 - v97.born, v_u_33)
							local v100 = p_u_30.vis
							local v101
							if type(v100) == "function" then
								local v102 = p_u_30.vis
								local v103 = v97.x
								local v104 = v97.y + 0.1
								local v105 = v97.z
								local v106 = Vector3.new(v103, v104, v105)
								local v107, v108 = pcall(v102, v106)
								v101 = (not v107 or type(v108) ~= "number") and 1 or v108
							else
								v101 = 1
							end
							local v109 = v98(v99, v101)
							if v97.decal == nil then
								if v97.part == nil then
									continue
								end
								v97.part.Transparency = v109
							else
								v97.decal.Transparency = v109
							end
						end
					end
				else
					v_u_43 = 0
					v_u_44 = 0
					local v110 = v_u_34()
					local v111 = {}
					for _, v112 in v_u_40 do
						if v_u_33 < v110 - v112.born then
							v112.decal = nil
							if v112.part == nil then
								continue
							end
							v112.part:Destroy()
							v112.part = nil
						else
							table.insert(v111, v112)
						end
					end
					if #v111 ~= #v_u_40 then
						v_u_40 = v111
					end
					local v113 = nil
					local v114 = nil
					local v115 = p_u_30.focus
					if type(v115) == "function" then
						local v116 = p_u_30.focus
						local v117, v118 = pcall(v116)
						if v117 and typeof(v118) == "Vector3" then
							v113 = v118.X
							v114 = v118.Z
						end
					end
					local v119 = {}
					for _, v120 in v_u_40 do
						if v113 == nil or (v120.x - v113) ^ 2 + (v120.z - v114) ^ 2 <= v_u_143.RADIUS ^ 2 then
							table.insert(v119, v120)
						else
							v120.decal = nil
							if v120.part == nil then
								continue
							end
							v120.part:Destroy()
							v120.part = nil
						end
					end
					local v121 = v_u_143.keep(v119, v_u_143.MAX_PARTS, v113, v114)
					local v122 = {}
					for _, v123 in v121 do
						v122[v123] = true
					end
					for _, v124 in v119 do
						if v122[v124] then
							continue
						end
						v124.decal = nil
						if v124.part == nil then
							continue
						end
						v124.part:Destroy()
						v124.part = nil
					end
					for _, v125 in v121 do
						if v125.part == nil then
							v_u_94(v125)
						else
							local v126 = v_u_143.shownAlpha
							local v127 = v_u_143.alpha(v110 - v125.born, v_u_33)
							local v128 = p_u_30.vis
							local v129
							if type(v128) == "function" then
								local v130 = p_u_30.vis
								local v131 = v125.x
								local v132 = v125.y + 0.1
								local v133 = v125.z
								local v134 = Vector3.new(v131, v132, v133)
								local v135, v136 = pcall(v130, v134)
								v129 = (not v135 or type(v136) ~= "number") and 1 or v136
							else
								v129 = 1
							end
							local v137 = v126(v127, v129)
							if v125.decal == nil then
								if v125.part == nil then
									continue
								end
								v125.part.Transparency = v137
							else
								v125.decal.Transparency = v137
							end
						end
					end
				end
			else
				return
			end
		end
		function v_u_31.count() -- name: count
			-- upvalues: (ref) v_u_40
			return #v_u_40
		end
		function v_u_31.shown() -- name: shown
			-- upvalues: (ref) v_u_40
			local v138 = 0
			for _, v139 in v_u_40 do
				if v139.part == nil then
					continue
				end
				v138 = v138 + 1
			end
			return v138
		end
		function v_u_31.colors() -- name: colors
			-- upvalues: (copy) v_u_41
			local v140 = {}
			for v141 in v_u_41 do
				table.insert(v140, v141)
			end
			table.sort(v140)
			return v140
		end
		function v_u_31.clear() -- name: clear
			-- upvalues: (ref) v_u_40, (copy) v_u_41
			for _, v142 in v_u_40 do
				v142.decal = nil
				if v142.part == nil then
					continue
				end
				v142.part:Destroy()
				v142.part = nil
			end
			table.clear(v_u_40)
			table.clear(v_u_41)
		end
		function v_u_31.destroy() -- name: destroy
			-- upvalues: (ref) v_u_42, (copy) v_u_31, (copy) v_u_39
			v_u_42 = false
			v_u_31.clear()
			v_u_39:Destroy()
		end
		v_u_31.folder = v_u_39
		return v_u_31
	end
}
return v_u_143