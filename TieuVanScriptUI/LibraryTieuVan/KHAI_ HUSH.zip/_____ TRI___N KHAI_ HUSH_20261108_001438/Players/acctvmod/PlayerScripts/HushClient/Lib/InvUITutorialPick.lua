-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITutorialPick

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = require(v5:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v_u_7 = require(script.Parent:WaitForChild("HushUI"))
local v_u_8 = require(script.Parent:WaitForChild("InvUITile"))
local v_u_9 = require(script.Parent:WaitForChild("InvUITutorialPickLayout"))
local v_u_10 = v_u_6.color
local v_u_11 = v1.LocalPlayer
local v_u_17 = {
	["drawMouse"] = function(p12) -- name: drawMouse
		-- upvalues: (copy) v_u_7, (copy) v_u_10
		local v13 = v_u_7.new("Frame", {
			["Name"] = "Mouse",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.bg,
			["Size"] = UDim2.fromOffset(34, 50)
		}, p12)
		v_u_7.corner(v13, 14)
		v_u_7.stroke(v13, v_u_10.text, 2)
		local v14 = v_u_7.new("Frame", {
			["Name"] = "Left",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.accent,
			["Position"] = UDim2.fromOffset(3, 3),
			["Size"] = UDim2.fromOffset(13, 18)
		}, v13)
		v_u_7.corner(v14, 11)
		local v15 = v_u_7.new("Frame", {
			["Name"] = "PatchR",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.accent,
			["Position"] = UDim2.fromOffset(6, 0),
			["Size"] = UDim2.fromOffset(7, 18)
		}, v14)
		local v16 = v_u_7.new("Frame", {
			["Name"] = "PatchB",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.accent,
			["Position"] = UDim2.fromOffset(0, 9),
			["Size"] = UDim2.fromOffset(13, 9)
		}, v14)
		v_u_7.new("Frame", {
			["Name"] = "SeamV",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.text,
			["Position"] = UDim2.fromOffset(16, 2),
			["Size"] = UDim2.fromOffset(2, 20)
		}, v13)
		v_u_7.new("Frame", {
			["Name"] = "SeamH",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.text,
			["Position"] = UDim2.fromOffset(2, 21),
			["Size"] = UDim2.fromOffset(30, 2)
		}, v13)
		v_u_7.new("Frame", {
			["Name"] = "Wheel",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.text,
			["Position"] = UDim2.fromOffset(15, 7),
			["Size"] = UDim2.fromOffset(4, 8)
		}, v13)
		return v13, { v14, v15, v16 }
	end
}
local function v_u_21() -- name: parseIds
	-- upvalues: (copy) v_u_11
	local v18 = {}
	local v19 = v_u_11:GetAttribute("TutorialPick")
	if type(v19) ~= "string" or v19 == "" then
		return v18
	end
	for v20 in string.gmatch(v19, "[^,]+") do
		v18[v20] = true
	end
	return v18
end
function v_u_17.ids() -- name: ids
	-- upvalues: (copy) v_u_21
	return v_u_21()
end
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = 0
local v_u_26 = nil
local v_u_27 = false
local v_u_28 = false
local function v_u_40() -- name: build
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_9
	local v29 = v_u_7.screen
	local v30 = v_u_6.layer.inventory + 2
	local v31, v32, v33 = pcall(v29, "HushTutorialPick", v30)
	if not (v31 and v32) then
		return nil
	end
	local v34 = v_u_7.new("Frame", {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.06,
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Visible"] = false,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_10.bgDeep,
		["Size"] = UDim2.fromOffset(300, v_u_9.HEIGHT)
	}, v33)
	v_u_7.corner(v34, 6)
	local v35 = v_u_7.stroke(v34, v_u_10.accent, 2)
	local v36 = v_u_7.new("Frame", {
		["Name"] = "Picture",
		["BackgroundTransparency"] = 1,
		["Active"] = false,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromOffset(32, 32)
	}, v34)
	local v37 = v_u_7.new("UIScale", {
		["Name"] = "Pulse",
		["Scale"] = 1
	}, v36)
	local v38 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "bodyStrong",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v34,
		["color"] = v_u_10.text,
		["size"] = UDim2.fromOffset(100, 18)
	})
	v38.ZIndex = 3
	local v39 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v34,
		["color"] = v_u_10.text2,
		["size"] = UDim2.fromOffset(100, 14)
	})
	v39.ZIndex = 3
	return {
		["gui"] = nil,
		["root"] = nil,
		["bar"] = nil,
		["holder"] = nil,
		["main"] = nil,
		["sub"] = nil,
		["scale"] = nil,
		["chip"] = nil,
		["chipDevice"] = "",
		["iconDevice"] = "",
		["pulse"] = nil,
		["stroke"] = nil,
		["gui"] = v32,
		["root"] = v33,
		["bar"] = v34,
		["holder"] = v36,
		["main"] = v38,
		["sub"] = v39,
		["scale"] = v37,
		["stroke"] = v35
	}
end
local function v_u_47(p41, p42) -- name: paintPicture
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_10, (copy) v_u_17
	if p41.iconDevice == p42 then
		return
	else
		p41.iconDevice = p42
		for _, v43 in p41.holder:GetChildren() do
			if v43:IsA("UIScale") then
				continue
			end
			v43:Destroy()
		end
		local v44 = p42 == "Touch" and "quickTakeTouch" or (p42 == "Gamepad" and "quickTakePad" or "quickTakePc")
		local v45 = v_u_6.icons[v44]
		if type(v45) ~= "string" or v45 == "" then
			v45 = nil
		end
		if v45 then
			v_u_7.new("ImageLabel", {
				["Name"] = "Img",
				["BackgroundTransparency"] = 1,
				["Image"] = nil,
				["ScaleType"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Image"] = v45,
				["ScaleType"] = Enum.ScaleType.Fit,
				["Size"] = UDim2.fromScale(1, 1)
			}, p41.holder)
			return
		elseif p42 == "Touch" then
			v_u_7.icon("hand", {
				["parent"] = nil,
				["size"] = nil,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 3,
				["parent"] = p41.holder,
				["size"] = UDim2.fromScale(1, 1),
				["color"] = v_u_10.accent,
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			})
		elseif p42 ~= "Gamepad" then
			local v46 = v_u_17.drawMouse(p41.holder)
			v46.AnchorPoint = Vector2.new(0.5, 0.5)
			v46.Position = UDim2.fromScale(0.5, 0.5)
			v_u_7.new("UIScale", {
				["Name"] = "Fit",
				["Scale"] = 0.62
			}, v46)
		end
	end
end
local function v_u_53(p48, p49, p50, p51) -- name: paintChip
	-- upvalues: (copy) v_u_7, (copy) v_u_9
	if p48.chip and (not p50 or p48.chipDevice ~= p49) then
		p48.chip:Destroy()
		p48.chip = nil
	end
	if p50 and not p48.chip then
		local v52 = v_u_7.keyHint("quickTake", {
			["size"] = nil,
			["name"] = "Chip",
			["zindex"] = 3,
			["size"] = v_u_9.HEIGHT_TOUCH <= p51 and 28 or 22
		})
		v52.Parent = p48.bar
		p48.chip = v52
		p48.chipDevice = p49
	end
end
local function v_u_87(p_u_54) -- name: layoutBar
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (ref) v_u_22, (copy) v_u_9, (copy) v_u_47, (copy) v_u_53, (copy) v_u_4
	local v55 = v_u_7.device()
	local v56 = v55 == "Touch"
	local v57 = v_u_6.uiScale()
	local v58 = p_u_54.root.AbsolutePosition
	local v59 = p_u_54.root.AbsoluteSize / math.max(v57, 0.01)
	local v60 = v_u_22.lootRect
	local v61, v62, v63 = pcall(v60)
	local v64, v65
	if v61 and (typeof(v62) == "Vector2" and (typeof(v63) == "Vector2" and (v63.X > 0 and v63.Y > 0))) then
		v64 = (v62 - v58) / v57
		v65 = v63 / v57
	else
		v64 = nil
		v65 = nil
	end
	local v66 = v_u_9.rect(v59, v_u_7.topInset(), v56, v64, v65)
	local v67 = v_u_9.rows(v55)
	local v68 = p_u_54.bar
	local v69 = UDim2.fromOffset
	local v70 = v66.x + 0.5
	local v71 = math.floor(v70)
	local v72 = v66.y + 0.5
	v68.Position = v69(v71, (math.floor(v72)))
	local v73 = p_u_54.bar
	local v74 = UDim2.fromOffset
	local v75 = v66.w + 0.5
	v73.Size = v74(math.floor(v75), v66.h)
	v_u_47(p_u_54, v55)
	local v76 = #p_u_54.holder:GetChildren() > 1
	v_u_53(p_u_54, v55, v67.chip, v66.h)
	local v77 = not p_u_54.chip and 0 or p_u_54.chip.Size.X.Offset
	local v78 = v_u_9.content(v66.w, v66.h, v55, v77, v76)
	p_u_54.holder.Visible = v78.icon ~= nil
	if v78.icon then
		p_u_54.holder.Position = UDim2.fromOffset(v78.icon.x, v78.icon.y)
		p_u_54.holder.Size = UDim2.fromOffset(v78.icon.w, v78.icon.h)
		p_u_54.holder.AnchorPoint = Vector2.zero
	end
	if p_u_54.chip and v78.chip then
		p_u_54.chip.Position = UDim2.fromOffset(v78.chip.x, v78.chip.y)
	end
	local v79 = v_u_6.phoneText(15, "text")
	local v80 = v_u_6.phoneText(13, "text")
	local v81 = v_u_9.fit(v67.text, v78.text.w, v79, v80, v56 and 2 or 1)
	p_u_54.main.Text = v67.text
	p_u_54.main.TextSize = v81
	p_u_54.main.TextWrapped = v56
	local v82 = p_u_54.main
	local v83
	if v56 then
		v83 = Enum.TextTruncate.None
	else
		v83 = Enum.TextTruncate.AtEnd
	end
	v82.TextTruncate = v83
	p_u_54.main.Position = UDim2.fromOffset(v78.text.x, v78.text.y)
	p_u_54.main.Size = UDim2.fromOffset(v78.text.w, v78.text.h)
	p_u_54.sub.Visible = v78.sub ~= nil
	if v78.sub and v67.sub then
		p_u_54.sub.Text = v67.sub
		p_u_54.sub.TextSize = v_u_9.fit(v67.sub, v78.sub.w, v_u_6.phoneText(12, "caption"), v_u_6.phoneText(10, "caption"), 1)
		p_u_54.sub.Position = UDim2.fromOffset(v78.sub.x, v78.sub.y)
		p_u_54.sub.Size = UDim2.fromOffset(v78.sub.w, v78.sub.h)
	end
	if not p_u_54.pulse then
		local function v84()
			-- upvalues: (ref) v_u_4, (copy) p_u_54
			return v_u_4:Create(p_u_54.scale, TweenInfo.new(0.55, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
				["Scale"] = 1.06
			})
		end
		local v85, v86 = pcall(v84)
		if v85 and v86 then
			v86:Play()
			p_u_54.pulse = v86
		end
	end
	p_u_54.bar.Visible = true
end
local function v_u_91() -- name: padFocus
	-- upvalues: (copy) v_u_7, (ref) v_u_27, (copy) v_u_8, (copy) v_u_2, (ref) v_u_26
	if v_u_7.device() == "Gamepad" and not v_u_27 then
		local v_u_88 = v_u_8.focusFrame()
		if v_u_88 then
			local v89 = v_u_2.SelectedObject
			if v89 == nil or (v89 == v_u_26 or not v89:IsDescendantOf(v_u_88.Parent or v_u_88)) then
				local function v90()
					-- upvalues: (ref) v_u_2, (copy) v_u_88
					v_u_2.SelectedObject = v_u_88
				end
				pcall(v90)
			end
			v_u_27 = true
		end
	else
		return
	end
end
local function v_u_102() -- name: update
	-- upvalues: (copy) v_u_21, (ref) v_u_22, (ref) v_u_28, (ref) v_u_26, (copy) v_u_2, (ref) v_u_27, (ref) v_u_23, (copy) v_u_40, (copy) v_u_87, (copy) v_u_91
	local v92 = v_u_21()
	local v93
	if next(v92) == nil then
		v93 = false
	else
		v93 = v_u_22.isOpen() == true
	end
	if v93 and not v_u_28 then
		v_u_26 = v_u_2.SelectedObject
		v_u_27 = false
	end
	v_u_28 = v93
	if v93 then
		local v94
		if v_u_23 and v_u_23.gui.Parent then
			v94 = v_u_23
		else
			v_u_23 = v_u_40()
			v94 = v_u_23
		end
		if v94 then
			local v95 = v_u_87
			local v96, v97 = pcall(v95, v94)
			if v96 then
				v_u_91()
			else
				warn("[InvUITutorialPick] layout failed:", v97)
				if v_u_23 then
					local v98 = v_u_23
					if v98.pulse then
						local v_u_99 = v98.pulse
						if v_u_99 then
							pcall(function()
								-- upvalues: (copy) v_u_99
								v_u_99:Cancel()
							end)
						end
						v98.pulse = nil
						v98.scale.Scale = 1
					end
					v_u_23.bar.Visible = false
				end
			end
		else
			return
		end
	else
		if v_u_23 then
			local v100 = v_u_23
			if v100.pulse then
				local v_u_101 = v100.pulse
				if v_u_101 then
					pcall(function()
						-- upvalues: (copy) v_u_101
						v_u_101:Cancel()
					end)
				end
				v100.pulse = nil
				v100.scale.Scale = 1
			end
			v_u_23.bar.Visible = false
		end
		return
	end
end
local function v_u_107() -- name: onPick
	-- upvalues: (copy) v_u_21, (copy) v_u_8, (ref) v_u_27, (ref) v_u_26, (copy) v_u_2, (ref) v_u_24, (ref) v_u_25, (copy) v_u_3, (copy) v_u_102, (ref) v_u_23, (ref) v_u_28
	local v103 = v_u_21()
	v_u_8.setFocus(v103)
	if next(v103) == nil then
		if v_u_24 then
			v_u_24:Disconnect()
			v_u_24 = nil
		end
		if v_u_23 then
			local v104 = v_u_23
			if v104.pulse then
				local v_u_105 = v104.pulse
				if v_u_105 then
					pcall(function()
						-- upvalues: (copy) v_u_105
						v_u_105:Cancel()
					end)
				end
				v104.pulse = nil
				v104.scale.Scale = 1
			end
			v_u_23.bar.Visible = false
		end
		v_u_28 = false
		return
	else
		v_u_27 = false
		v_u_26 = v_u_2.SelectedObject
		if not v_u_24 then
			v_u_25 = 1
			v_u_24 = v_u_3.Heartbeat:Connect(function(p106)
				-- upvalues: (ref) v_u_25, (ref) v_u_102
				v_u_25 = v_u_25 + p106
				if v_u_25 >= 0.1 then
					v_u_25 = 0
					v_u_102()
				end
			end)
		end
	end
end
local v_u_108 = false
function v_u_17.bind(p109) -- name: bind
	-- upvalues: (ref) v_u_22, (ref) v_u_108, (copy) v_u_11, (copy) v_u_107, (copy) v_u_7, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (copy) v_u_21, (copy) v_u_8, (ref) v_u_27, (ref) v_u_26, (copy) v_u_2, (copy) v_u_3, (copy) v_u_102, (ref) v_u_28
	v_u_22 = p109
	if v_u_108 then
		return
	else
		v_u_108 = true
		v_u_11:GetAttributeChangedSignal("TutorialPick"):Connect(v_u_107)
		v_u_7.onDevice(function()
			-- upvalues: (ref) v_u_23, (ref) v_u_24, (ref) v_u_25
			if v_u_23 then
				v_u_23.iconDevice = ""
			end
			if v_u_24 then
				v_u_25 = 1
			end
		end)
		local v110 = v_u_21()
		v_u_8.setFocus(v110)
		if next(v110) == nil then
			if v_u_24 then
				v_u_24:Disconnect()
				v_u_24 = nil
			end
			if v_u_23 then
				local v111 = v_u_23
				if v111.pulse then
					local v_u_112 = v111.pulse
					if v_u_112 then
						pcall(function()
							-- upvalues: (copy) v_u_112
							v_u_112:Cancel()
						end)
					end
					v111.pulse = nil
					v111.scale.Scale = 1
				end
				v_u_23.bar.Visible = false
			end
			v_u_28 = false
			return
		else
			v_u_27 = false
			v_u_26 = v_u_2.SelectedObject
			if not v_u_24 then
				v_u_25 = 1
				v_u_24 = v_u_3.Heartbeat:Connect(function(p113)
					-- upvalues: (ref) v_u_25, (ref) v_u_102
					v_u_25 = v_u_25 + p113
					if v_u_25 >= 0.1 then
						v_u_25 = 0
						v_u_102()
					end
				end)
			end
		end
	end
end
function v_u_17.shown() -- name: shown
	-- upvalues: (ref) v_u_23
	local v114
	if v_u_23 == nil then
		v114 = false
	else
		v114 = v_u_23.bar.Visible
	end
	return v114
end
return v_u_17