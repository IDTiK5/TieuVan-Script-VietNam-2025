-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmWave

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.lines(p6) -- name: lines
	local v7 = {}
	if type(p6) ~= "table" then
		table.insert(v7, {
			["name"] = "State",
			["text"] = "Reading the switch ...",
			["kind"] = "muted"
		})
		return v7
	end
	local v8 = p6.on == true
	local v9 = p6.brand
	local v10 = (type(v9) ~= "string" or p6.brand == "") and "?" or p6.brand
	local v11 = {
		["name"] = "State",
		["text"] = nil,
		["kind"] = nil,
		["text"] = ("Ban wave feed is %s  \194\183  switch %s  \194\183  name %s"):format(v8 and "ON" or "OFF", p6.rawOn == true and "on" or "off", v10),
		["kind"] = v8 and "ok" or "muted"
	}
	table.insert(v7, v11)
	if p6.flag == false then
		table.insert(v7, {
			["name"] = "Flag",
			["text"] = "The build flag Config.FLAGS.BanWave is OFF: no server shows a wave whatever the switch says.",
			["kind"] = "warn"
		})
	end
	if p6.bad == true then
		table.insert(v7, {
			["name"] = "Bad",
			["text"] = "The switch document is damaged: it reads as OFF. Press ON to write it again.",
			["kind"] = "warn"
		})
	end
	local v12 = {
		["name"] = "Topic",
		["text"] = nil,
		["kind"] = nil
	}
	local v13 = p6.topic or "?"
	v12.text = ("Topic %s  \194\183  %s"):format(tostring(v13), p6.subscribed == true and "this server listens" or "this server does not listen yet")
	v12.kind = p6.subscribed == true and "text" or "warn"
	table.insert(v7, v12)
	local v14 = p6.last
	local v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34, v35, v36, v37
	if type(v14) ~= "table" then
		table.insert(v7, {
			["name"] = "Last",
			["text"] = "No wave shown on this server yet.",
			["kind"] = "muted"
		})
		v56 = {
			["name"] = "Used",
			["text"] = nil,
			["kind"] = "text"
		}
		v57 = "Waves this hour on this server: %d of %d  \194\183  messages %d  \194\183  shown %d  \194\183  dropped %d"
		v58 = p6.used
		v59 = tonumber(v58)
		if v59 == nil or v59 ~= v59 then
			v15 = 0
		else
			v16 = v59 + 0.5
			v15 = math.floor(v16)
		end
		v60 = p6.max
		v61 = tonumber(v60)
		if v61 == nil or v61 ~= v61 then
			v17 = 0
		else
			v18 = v61 + 0.5
			v17 = math.floor(v18)
		end
		v62 = p6.received
		v63 = tonumber(v62)
		if v63 == nil or v63 ~= v63 then
			v19 = 0
		else
			v20 = v63 + 0.5
			v19 = math.floor(v20)
		end
		v64 = p6.shown
		v65 = tonumber(v64)
		if v65 == nil or v65 ~= v65 then
			v21 = 0
		else
			v22 = v65 + 0.5
			v21 = math.floor(v22)
		end
		v66 = p6.dropped
		v67 = tonumber(v66)
		if v67 == nil or v67 ~= v67 then
			v23 = 0
		else
			v24 = v67 + 0.5
			v23 = math.floor(v24)
		end
		v56.text = v57:format(v15, v17, v19, v21, v23)
		table.insert(v7, v56)
		if p6.rawOn ~= true and p6.by ~= nil then
			v25 = p6.v
			if tonumber(v25) then
				v26 = p6.v
				v27 = tonumber(v26)
				if v27 == nil or v27 ~= v27 then
					v28 = 0
				else
					v29 = v27 + 0.5
					v28 = math.floor(v29)
				end
				if v28 > 0 then
					v30 = p6.byName
					v31 = (type(v30) ~= "string" or p6.byName == "") and "" or " by " .. p6.byName
					v32 = {
						["name"] = "Who",
						["text"] = nil,
						["kind"] = "muted"
					}
					v33 = "Switch version %d%s"
					v34 = p6.v
					v35 = tonumber(v34)
					if v35 == nil or v35 ~= v35 then
						v36 = 0
					else
						v37 = v35 + 0.5
						v36 = math.floor(v37)
					end
					v32.text = v33:format(v36, v31)
					table.insert(v7, v32)
				end
			end
		end
		return v7
	end
	local v38 = v14.wave
	if type(v38) ~= "string" then
		table.insert(v7, {
			["name"] = "Last",
			["text"] = "No wave shown on this server yet.",
			["kind"] = "muted"
		})
		v56 = {
			["name"] = "Used",
			["text"] = nil,
			["kind"] = "text"
		}
		v57 = "Waves this hour on this server: %d of %d  \194\183  messages %d  \194\183  shown %d  \194\183  dropped %d"
		v58 = p6.used
		v59 = tonumber(v58)
		if v59 == nil or v59 ~= v59 then
			v15 = 0
		else
			v16 = v59 + 0.5
			v15 = math.floor(v16)
		end
		v60 = p6.max
		v61 = tonumber(v60)
		if v61 == nil or v61 ~= v61 then
			v17 = 0
		else
			v18 = v61 + 0.5
			v17 = math.floor(v18)
		end
		v62 = p6.received
		v63 = tonumber(v62)
		if v63 == nil or v63 ~= v63 then
			v19 = 0
		else
			v20 = v63 + 0.5
			v19 = math.floor(v20)
		end
		v64 = p6.shown
		v65 = tonumber(v64)
		if v65 == nil or v65 ~= v65 then
			v21 = 0
		else
			v22 = v65 + 0.5
			v21 = math.floor(v22)
		end
		v66 = p6.dropped
		v67 = tonumber(v66)
		if v67 == nil or v67 ~= v67 then
			v23 = 0
		else
			v24 = v67 + 0.5
			v23 = math.floor(v24)
		end
		v56.text = v57:format(v15, v17, v19, v21, v23)
		table.insert(v7, v56)
		if p6.rawOn ~= true and p6.by ~= nil then
			v25 = p6.v
			if tonumber(v25) then
				v26 = p6.v
				v27 = tonumber(v26)
				if v27 == nil or v27 ~= v27 then
					v28 = 0
				else
					v29 = v27 + 0.5
					v28 = math.floor(v29)
				end
				if v28 > 0 then
					v30 = p6.byName
					v31 = (type(v30) ~= "string" or p6.byName == "") and "" or " by " .. p6.byName
					v32 = {
						["name"] = "Who",
						["text"] = nil,
						["kind"] = "muted"
					}
					v33 = "Switch version %d%s"
					v34 = p6.v
					v35 = tonumber(v34)
					if v35 == nil or v35 ~= v35 then
						v36 = 0
					else
						v37 = v35 + 0.5
						v36 = math.floor(v37)
					end
					v32.text = v33:format(v36, v31)
					table.insert(v7, v32)
				end
			end
		end
		return v7
	end
	local v39 = p6.now
	local v40
	if type(v39) == "number" then
		local v41 = v14.at
		if type(v41) == "number" then
			local v42 = p6.now - v14.at
			local v43 = v42 < 0 and 0 or v42
			if v43 < 90 then
				v40 = ("%d s ago"):format(v43)
			elseif v43 < 5400 then
				local v44 = v43 / 60 + 0.5
				v40 = ("%d min ago"):format((math.floor(v44)))
			else
				v40 = ("%.1f h ago"):format(v43 / 3600)
			end
		else
			v40 = "?"
		end
	else
		v40 = "?"
	end
	local v45 = {
		["name"] = "Last",
		["text"] = nil,
		["kind"] = "text"
	}
	local v46 = "Last wave shown here: %s  \194\183  %d names in %d messages  \194\183  %s"
	local v47 = v14.wave
	local v48 = v14.names
	local v49 = tonumber(v48)
	local v50
	if v49 == nil or v49 ~= v49 then
		v50 = 0
	else
		local v51 = v49 + 0.5
		v50 = math.floor(v51)
	end
	local v52 = v14.msgs
	local v53 = tonumber(v52)
	local v54
	if v53 == nil or v53 ~= v53 then
		v54 = 0
	else
		local v55 = v53 + 0.5
		v54 = math.floor(v55)
	end
	v45.text = v46:format(v47, v50, v54, v40)
	table.insert(v7, v45)
	local v56 = {
		["name"] = "Used",
		["text"] = nil,
		["kind"] = "text"
	}
	local v57 = "Waves this hour on this server: %d of %d  \194\183  messages %d  \194\183  shown %d  \194\183  dropped %d"
	local v58 = p6.used
	local v59 = tonumber(v58)
	if v59 == nil or v59 ~= v59 then
		v15 = 0
	else
		v16 = v59 + 0.5
		v15 = math.floor(v16)
	end
	local v60 = p6.max
	local v61 = tonumber(v60)
	if v61 == nil or v61 ~= v61 then
		v17 = 0
	else
		v18 = v61 + 0.5
		v17 = math.floor(v18)
	end
	local v62 = p6.received
	local v63 = tonumber(v62)
	if v63 == nil or v63 ~= v63 then
		v19 = 0
	else
		v20 = v63 + 0.5
		v19 = math.floor(v20)
	end
	local v64 = p6.shown
	local v65 = tonumber(v64)
	if v65 == nil or v65 ~= v65 then
		v21 = 0
	else
		v22 = v65 + 0.5
		v21 = math.floor(v22)
	end
	local v66 = p6.dropped
	local v67 = tonumber(v66)
	if v67 == nil or v67 ~= v67 then
		v23 = 0
	else
		v24 = v67 + 0.5
		v23 = math.floor(v24)
	end
	v56.text = v57:format(v15, v17, v19, v21, v23)
	table.insert(v7, v56)
	if p6.rawOn ~= true and p6.by ~= nil then
		v25 = p6.v
		if tonumber(v25) then
			v26 = p6.v
			v27 = tonumber(v26)
			if v27 == nil or v27 ~= v27 then
				v28 = 0
			else
				v29 = v27 + 0.5
				v28 = math.floor(v29)
			end
			if v28 > 0 then
				v30 = p6.byName
				v31 = (type(v30) ~= "string" or p6.byName == "") and "" or " by " .. p6.byName
				v32 = {
					["name"] = "Who",
					["text"] = nil,
					["kind"] = "muted"
				}
				v33 = "Switch version %d%s"
				v34 = p6.v
				v35 = tonumber(v34)
				if v35 == nil or v35 ~= v35 then
					v36 = 0
				else
					v37 = v35 + 0.5
					v36 = math.floor(v37)
				end
				v32.text = v33:format(v36, v31)
				table.insert(v7, v32)
			end
		end
	end
	return v7
end
function v_u_4.mount(p_u_68, p_u_69, p_u_70, p71) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2
	local v_u_72 = type(p71) ~= "table" and {} or p71
	if type(p_u_70) == "table" then
		local v73 = p_u_70.color
		if type(v73) ~= "table" then
			p_u_70 = v_u_3.Theme
		end
	else
		p_u_70 = v_u_3.Theme
	end
	local v_u_74 = p_u_70.color
	local v75 = v_u_72.inner
	local v76 = type(v75) ~= "number" and 438 or v_u_72.inner
	local v_u_77 = v_u_72.gui
	local v_u_78
	if v_u_72.player == nil then
		v_u_78 = v_u_5
	else
		v_u_78 = v_u_72.player
	end
	local v_u_79 = 0
	local v_u_80 = true
	if v_u_77 then
		v_u_77.Destroying:Connect(function()
			-- upvalues: (ref) v_u_80
			v_u_80 = false
		end)
	end
	local v81 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Ban wave feed  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_68,
		["color"] = v_u_74.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v82 = v_u_72.order
	local v83
	if type(v82) == "function" then
		v83 = v_u_72.order()
	else
		v_u_79 = v_u_79 + 1
		v83 = v_u_79
	end
	v81.LayoutOrder = v83
	local v_u_84 = v_u_3.new("Frame", {
		["Name"] = "WaveList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_68)
	v_u_3.layout(v_u_84, "v", 2)
	local v85 = v_u_72.order
	local v86
	if type(v85) == "function" then
		v86 = v_u_72.order()
	else
		v_u_79 = v_u_79 + 1
		v86 = v_u_79
	end
	v_u_84.LayoutOrder = v86
	local function v93(p87, p88, p89) -- name: small
		-- upvalues: (ref) v_u_3, (copy) p_u_68, (copy) v_u_74, (copy) v_u_72, (ref) v_u_79
		local v90 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_68,
			["name"] = p87,
			["text"] = p88,
			["color"] = p89 or v_u_74.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v91 = v_u_72.order
		local v92
		if type(v91) == "function" then
			v92 = v_u_72.order()
		else
			v_u_79 = v_u_79 + 1
			v92 = v_u_79
		end
		v90.LayoutOrder = v92
		return v90
	end
	local function v107(p94, p95) -- name: row
		-- upvalues: (ref) v_u_3, (copy) p_u_70, (copy) p_u_68, (copy) v_u_72, (ref) v_u_79
		local v96 = v_u_3.new
		local v97 = "Frame"
		local v98 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = p95 or "WaveRow"
		}
		local v99 = UDim2.new
		local v100 = 1
		local v101 = 0
		local v102 = 0
		if not p94 then
			local v103 = p_u_70.touch
			p94 = type(v103) ~= "function" and 32 or p_u_70.touch(32)
		end
		v98.Size = v99(v100, v101, v102, p94)
		local v104 = v96(v97, v98, p_u_68)
		v_u_3.layout(v104, "h", 6)
		local v105 = v_u_72.order
		local v106
		if type(v105) == "function" then
			v106 = v_u_72.order()
		else
			v_u_79 = v_u_79 + 1
			v106 = v_u_79
		end
		v104.LayoutOrder = v106
		return v104
	end
	local v_u_108 = nil
	local v_u_109 = false
	local v_u_110 = nil
	local v_u_111 = (-1 / 0)
	local v_u_112 = nil
	local v_u_113 = nil
	local function v_u_128(p114, p_u_115) -- name: act
		-- upvalues: (copy) p_u_69, (ref) v_u_109, (ref) v_u_110, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74, (ref) v_u_80, (ref) v_u_111, (ref) v_u_108, (copy) v_u_128, (ref) v_u_113, (copy) v_u_72
		local v116 = p_u_69
		if type(v116) ~= "function" then
			return
		end
		if v_u_109 then
			if not p_u_115 then
				v_u_110 = p114
			end
			return
		end
		v_u_109 = true
		if not p_u_115 then
			v_u_3.setText(v_u_112, "Working ...")
			v_u_112.TextColor3 = v_u_74.text2
		end
		local function v125(p117) -- name: done
			-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) p_u_115, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
			v_u_109 = false
			if v_u_80 then
				v_u_111 = os.clock()
				if type(p117) == "table" then
					local v118 = p117.data
					if type(v118) == "table" then
						v_u_108 = p117.data
					end
					if not p_u_115 then
						local v119 = p117.msg or (p117.ok and "Done." or "Refused.")
						local v120 = tostring(v119)
						local v121 = p117.ok ~= true
						v_u_3.setText(v_u_112, v120)
						local v122 = v_u_112
						local v123
						if v121 then
							v123 = v_u_74.danger
						else
							v123 = v_u_74.text2
						end
						v122.TextColor3 = v123
					end
				elseif not p_u_115 then
					v_u_3.setText(v_u_112, "The server did not answer.")
					v_u_112.TextColor3 = v_u_74.danger
				end
				local v124 = v_u_110
				v_u_110 = nil
				if v124 == nil then
					v_u_113(v_u_108)
				else
					v_u_128(v124, false)
				end
			else
				v_u_110 = nil
				return
			end
		end
		local v126
		if p_u_115 then
			local v127 = v_u_72.sendQuiet
			if type(v127) == "function" then
				v126 = v_u_72.sendQuiet
				v126("server.ac", p114, v125)
			else
				v126 = p_u_69
				v126("server.ac", p114, v125)
			end
		else
			v126 = p_u_69
			v126("server.ac", p114, v125)
			return
		end
	end
	local function v143() -- name: refresh
		-- upvalues: (copy) p_u_69, (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74, (copy) v_u_128, (ref) v_u_113, (copy) v_u_72
		local v129 = {
			["cmd"] = "wave",
			["sub"] = "status"
		}
		local v130 = p_u_69
		if type(v130) == "function" then
			if not v_u_109 then
				v_u_109 = true
				local v_u_131 = true
				local function v140(p132) -- name: done
					-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) v_u_131, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
					v_u_109 = false
					if v_u_80 then
						v_u_111 = os.clock()
						if type(p132) == "table" then
							local v133 = p132.data
							if type(v133) == "table" then
								v_u_108 = p132.data
							end
							if not v_u_131 then
								local v134 = p132.msg or (p132.ok and "Done." or "Refused.")
								local v135 = tostring(v134)
								local v136 = p132.ok ~= true
								v_u_3.setText(v_u_112, v135)
								local v137 = v_u_112
								local v138
								if v136 then
									v138 = v_u_74.danger
								else
									v138 = v_u_74.text2
								end
								v137.TextColor3 = v138
							end
						elseif not v_u_131 then
							v_u_3.setText(v_u_112, "The server did not answer.")
							v_u_112.TextColor3 = v_u_74.danger
						end
						local v139 = v_u_110
						v_u_110 = nil
						if v139 == nil then
							v_u_113(v_u_108)
						else
							v_u_128(v139, false)
						end
					else
						v_u_110 = nil
						return
					end
				end
				local v141 = v_u_72.sendQuiet
				local v142
				if type(v141) == "function" then
					v142 = v_u_72.sendQuiet
				else
					v142 = p_u_69
				end
				v142("server.ac", v129, v140)
			end
		else
			return
		end
	end
	local v156 = {
		["parent"] = nil,
		["name"] = "WaveToggle",
		["label"] = "Ban wave feed",
		["value"] = true,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = p_u_68,
		["width"] = v76,
		["onChange"] = function(p144) -- name: onChange
			-- upvalues: (copy) p_u_69, (ref) v_u_109, (ref) v_u_110, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74, (ref) v_u_80, (ref) v_u_111, (ref) v_u_108, (copy) v_u_128, (ref) v_u_113
			local v145 = {
				["cmd"] = "wave",
				["sub"] = "set",
				["on"] = nil,
				["on"] = p144
			}
			local v146 = p_u_69
			if type(v146) == "function" then
				if v_u_109 then
					v_u_110 = v145
				else
					v_u_109 = true
					v_u_3.setText(v_u_112, "Working ...")
					v_u_112.TextColor3 = v_u_74.text2
					local v_u_147 = nil
					p_u_69("server.ac", v145, function(p148) -- name: done
						-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) v_u_147, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
						v_u_109 = false
						if v_u_80 then
							v_u_111 = os.clock()
							if type(p148) == "table" then
								local v149 = p148.data
								if type(v149) == "table" then
									v_u_108 = p148.data
								end
								if not v_u_147 then
									local v150 = p148.msg or (p148.ok and "Done." or "Refused.")
									local v151 = tostring(v150)
									local v152 = p148.ok ~= true
									v_u_3.setText(v_u_112, v151)
									local v153 = v_u_112
									local v154
									if v152 then
										v154 = v_u_74.danger
									else
										v154 = v_u_74.text2
									end
									v153.TextColor3 = v154
								end
							elseif not v_u_147 then
								v_u_3.setText(v_u_112, "The server did not answer.")
								v_u_112.TextColor3 = v_u_74.danger
							end
							local v155 = v_u_110
							v_u_110 = nil
							if v155 == nil then
								v_u_113(v_u_108)
							else
								v_u_128(v155, false)
							end
						else
							v_u_110 = nil
							return
						end
					end)
				end
			else
				return
			end
		end
	}
	local v157, v158 = v_u_3.toggle(v156)
	local v159 = v_u_72.order
	local v160
	if type(v159) == "function" then
		v160 = v_u_72.order()
	else
		v_u_79 = v_u_79 + 1
		v160 = v_u_79
	end
	v157.LayoutOrder = v160
	local v_u_161 = v158
	local v162 = p_u_70.touch
	local v163 = v107(type(v162) ~= "function" and 32 or p_u_70.touch(32), "WaveTestRow")
	local function v168() -- name: doTest
		-- upvalues: (copy) v_u_78, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74
		if v_u_78 then
			v_u_78:SetAttribute("BanWaveTest", 12)
		end
		local v164, v165 = ("Playing %d invented names on this screen only. Nobody else sees them."):format(12)
		v_u_3.setText(v_u_112, v164)
		local v166 = v_u_112
		local v167
		if v165 then
			v167 = v_u_74.danger
		else
			v167 = v_u_74.text2
		end
		v166.TextColor3 = v167
	end
	local v169 = v_u_3.button
	local v170 = {
		["parent"] = nil,
		["text"] = "Test (only me)",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v163
	}
	local v171 = p_u_70.touch
	v170.height = type(v171) ~= "function" and 32 or p_u_70.touch(32)
	local v172 = (v76 - 6) / 2
	v170.width = math.floor(v172)
	local v173 = (v76 - 6) / 2
	v170.maxTextWidth = math.floor(v173) - 12
	v170.onClick = v168
	v169(v170).Name = "WaveTest"
	local v174 = v_u_3.button
	local v175 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v163
	}
	local v176 = p_u_70.touch
	v175.height = type(v176) ~= "function" and 32 or p_u_70.touch(32)
	local v177 = (v76 - 6) / 2
	v175.width = math.floor(v177)
	local v178 = (v76 - 6) / 2
	v175.maxTextWidth = math.floor(v178) - 12
	v175.onClick = v143
	v174(v175).Name = "WaveRefresh"
	v_u_112 = v_u_3.label({
		["parent"] = nil,
		["name"] = "WaveStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_68,
		["color"] = v_u_74.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v179 = v_u_72.order
	local v180
	if type(v179) == "function" then
		v180 = v_u_72.order()
	else
		v_u_79 = v_u_79 + 1
		v180 = v_u_79
	end
	v_u_112.LayoutOrder = v180
	v93("WaveNote", "When the owner runs a wave on the moderator, every server shows a quick burst of red lines with the names that were banned. This switch only shows or hides those lines. It never bans or unbans anybody. TEST plays invented names on your own screen.", v_u_74.muted)
	v_u_113 = function(p181)
		-- upvalues: (copy) v_u_84, (ref) v_u_4, (copy) v_u_74, (ref) v_u_3, (ref) v_u_161, (copy) v_u_78
		for _, v182 in v_u_84:GetChildren() do
			if not v182:IsA("GuiObject") then
				continue
			end
			v182:Destroy()
		end
		for v183, v184 in v_u_4.lines(p181) do
			local v185
			if v184.kind == "ok" then
				v185 = v_u_74.success
			elseif v184.kind == "warn" then
				v185 = v_u_74.danger
			elseif v184.kind == "muted" then
				v185 = v_u_74.muted
			else
				v185 = v_u_74.text2
			end
			local v186 = v_u_3.label
			local v187 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_84
			}
			local v188 = v184.name
			v187.name = "WaveInfo_" .. tostring(v188)
			local v189 = v184.text
			v187.text = tostring(v189)
			v187.color = v185
			v187.size = UDim2.new(1, 0, 0, 0)
			v186(v187).LayoutOrder = v183
		end
		if v_u_161 then
			local v190 = v_u_161.set
			if type(v190) == "function" then
				v_u_161.set(type(p181) ~= "table" and true or p181.rawOn ~= false)
			end
		end
		if v_u_78 then
			local v191 = type(p181) ~= "table" and {} or p181
			local v192 = v191.last
			local v193
			if type(v192) == "table" then
				local v194 = v191.last.wave
				v193 = tostring(v194)
			else
				v193 = "none"
			end
			local v195 = v_u_78
			local v196 = "FilmWave"
			local v197 = "on=%d|raw=%d|flag=%d|sub=%d|last=%s|used=%d"
			local v198 = v191.on == true and 1 or 0
			local v199 = v191.rawOn == true and 1 or 0
			local v200 = v191.flag == false and 0 or 1
			local v201 = v191.subscribed == true and 1 or 0
			local v202 = v191.used
			local v203 = tonumber(v202)
			local v204
			if v203 == nil or v203 ~= v203 then
				v204 = 0
			else
				local v205 = v203 + 0.5
				v204 = math.floor(v205)
			end
			v195:SetAttribute(v196, v197:format(v198, v199, v200, v201, v193, v204))
		end
	end
	v_u_113(nil)
	if v_u_2:IsStudio() and v_u_78 then
		local v_u_239 = v_u_78:GetAttributeChangedSignal("FilmWaveCmd"):Connect(function()
			-- upvalues: (copy) v_u_78, (ref) v_u_108, (copy) p_u_69, (ref) v_u_109, (ref) v_u_110, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74, (ref) v_u_80, (ref) v_u_111, (copy) v_u_128, (ref) v_u_113, (copy) v_u_72
			local v206 = v_u_78:GetAttribute("FilmWaveCmd")
			if type(v206) == "string" and v206 ~= "" then
				v_u_78:SetAttribute("FilmWaveCmd", nil)
				local v207 = string.match(v206, "^(%a+)")
				if v207 == "toggle" then
					local v208 = v_u_108
					local v209
					if type(v208) == "table" then
						v209 = v_u_108.rawOn ~= false
					else
						v209 = false
					end
					local v210 = {
						["cmd"] = "wave",
						["sub"] = "set",
						["on"] = nil,
						["on"] = not v209
					}
					local v211 = p_u_69
					if type(v211) == "function" then
						if v_u_109 then
							v_u_110 = v210
						else
							v_u_109 = true
							v_u_3.setText(v_u_112, "Working ...")
							v_u_112.TextColor3 = v_u_74.text2
							local v_u_212 = nil
							p_u_69("server.ac", v210, function(p213) -- name: done
								-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) v_u_212, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
								v_u_109 = false
								if v_u_80 then
									v_u_111 = os.clock()
									if type(p213) == "table" then
										local v214 = p213.data
										if type(v214) == "table" then
											v_u_108 = p213.data
										end
										if not v_u_212 then
											local v215 = p213.msg or (p213.ok and "Done." or "Refused.")
											local v216 = tostring(v215)
											local v217 = p213.ok ~= true
											v_u_3.setText(v_u_112, v216)
											local v218 = v_u_112
											local v219
											if v217 then
												v219 = v_u_74.danger
											else
												v219 = v_u_74.text2
											end
											v218.TextColor3 = v219
										end
									elseif not v_u_212 then
										v_u_3.setText(v_u_112, "The server did not answer.")
										v_u_112.TextColor3 = v_u_74.danger
									end
									local v220 = v_u_110
									v_u_110 = nil
									if v220 == nil then
										v_u_113(v_u_108)
									else
										v_u_128(v220, false)
									end
								else
									v_u_110 = nil
									return
								end
							end)
						end
					else
						return
					end
				elseif v207 == "test" then
					if v_u_78 then
						v_u_78:SetAttribute("BanWaveTest", 12)
					end
					local v221, v222 = ("Playing %d invented names on this screen only. Nobody else sees them."):format(12)
					v_u_3.setText(v_u_112, v221)
					local v223 = v_u_112
					local v224
					if v222 then
						v224 = v_u_74.danger
					else
						v224 = v_u_74.text2
					end
					v223.TextColor3 = v224
				elseif v207 == "refresh" then
					local v225 = {
						["cmd"] = "wave",
						["sub"] = "status"
					}
					local v226 = p_u_69
					if type(v226) ~= "function" then
						return
					end
					if v_u_109 then
						return
					end
					v_u_109 = true
					local v_u_227 = true
					local function v236(p228) -- name: done
						-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) v_u_227, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
						v_u_109 = false
						if v_u_80 then
							v_u_111 = os.clock()
							if type(p228) == "table" then
								local v229 = p228.data
								if type(v229) == "table" then
									v_u_108 = p228.data
								end
								if not v_u_227 then
									local v230 = p228.msg or (p228.ok and "Done." or "Refused.")
									local v231 = tostring(v230)
									local v232 = p228.ok ~= true
									v_u_3.setText(v_u_112, v231)
									local v233 = v_u_112
									local v234
									if v232 then
										v234 = v_u_74.danger
									else
										v234 = v_u_74.text2
									end
									v233.TextColor3 = v234
								end
							elseif not v_u_227 then
								v_u_3.setText(v_u_112, "The server did not answer.")
								v_u_112.TextColor3 = v_u_74.danger
							end
							local v235 = v_u_110
							v_u_110 = nil
							if v235 == nil then
								v_u_113(v_u_108)
							else
								v_u_128(v235, false)
							end
						else
							v_u_110 = nil
							return
						end
					end
					local v237 = v_u_72.sendQuiet
					local v238
					if type(v237) == "function" then
						v238 = v_u_72.sendQuiet
					else
						v238 = p_u_69
					end
					v238("server.ac", v225, v236)
				end
			else
				return
			end
		end)
		if v_u_77 then
			v_u_77.Destroying:Connect(function()
				-- upvalues: (copy) v_u_239
				v_u_239:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_80, (copy) v_u_77, (copy) p_u_68, (ref) v_u_109, (ref) v_u_111, (copy) p_u_69, (ref) v_u_110, (ref) v_u_108, (ref) v_u_3, (ref) v_u_112, (copy) v_u_74, (copy) v_u_128, (ref) v_u_113, (copy) v_u_72
		local v240 = false
		while v_u_80 do
			local v241 = v_u_77 == nil or v_u_77.Enabled
			if v241 then
				v241 = p_u_68.Visible
			end
			if v241 and (not v_u_109 and (not v240 or os.clock() - v_u_111 >= 5)) then
				v_u_111 = os.clock()
				local v242 = {
					["cmd"] = "wave",
					["sub"] = "status"
				}
				local v243 = p_u_69
				if type(v243) == "function" and not v_u_109 then
					v_u_109 = true
					local v_u_244 = true
					local function v253(p245) -- name: done
						-- upvalues: (ref) v_u_109, (ref) v_u_80, (ref) v_u_110, (ref) v_u_111, (ref) v_u_108, (copy) v_u_244, (ref) v_u_3, (ref) v_u_112, (ref) v_u_74, (ref) v_u_128, (ref) v_u_113
						v_u_109 = false
						if v_u_80 then
							v_u_111 = os.clock()
							if type(p245) == "table" then
								local v246 = p245.data
								if type(v246) == "table" then
									v_u_108 = p245.data
								end
								if not v_u_244 then
									local v247 = p245.msg or (p245.ok and "Done." or "Refused.")
									local v248 = tostring(v247)
									local v249 = p245.ok ~= true
									v_u_3.setText(v_u_112, v248)
									local v250 = v_u_112
									local v251
									if v249 then
										v251 = v_u_74.danger
									else
										v251 = v_u_74.text2
									end
									v250.TextColor3 = v251
								end
							elseif not v_u_244 then
								v_u_3.setText(v_u_112, "The server did not answer.")
								v_u_112.TextColor3 = v_u_74.danger
							end
							local v252 = v_u_110
							v_u_110 = nil
							if v252 == nil then
								v_u_113(v_u_108)
							else
								v_u_128(v252, false)
							end
						else
							v_u_110 = nil
							return
						end
					end
					local v254 = v_u_72.sendQuiet
					local v255
					if type(v254) == "function" then
						v255 = v_u_72.sendQuiet
					else
						v255 = p_u_69
					end
					v255("server.ac", v242, v253)
				end
			end
			task.wait(0.5)
			v240 = v241
		end
	end)
	return {
		["refresh"] = v143,
		["paint"] = function(p256) -- name: paint
			-- upvalues: (ref) v_u_108, (ref) v_u_113
			v_u_108 = p256
			v_u_113(p256)
		end
	}
end
return v_u_4