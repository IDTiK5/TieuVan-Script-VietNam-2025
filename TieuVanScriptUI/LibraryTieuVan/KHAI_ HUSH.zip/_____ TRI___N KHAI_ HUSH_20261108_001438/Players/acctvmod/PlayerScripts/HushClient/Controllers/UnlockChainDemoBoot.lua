-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / UnlockChainDemoBoot

return {
	["name"] = "UnlockChainDemoBoot",
	["order"] = 97,
	["init"] = function(p_u_1) -- name: init
		local v5, v6 = pcall(function()
			-- upvalues: (copy) p_u_1
			local v_u_2 = p_u_1.lib.UnlockChainDemo
			p_u_1.command("unlock.demo", function(p3)
				-- upvalues: (copy) v_u_2, (ref) p_u_1
				local v4 = p3[1] or "tokyo"
				if v4 == "off" then
					v_u_2.hide()
					return "unlock demo off"
				elseif v4 == "confirm" then
					return v_u_2.confirm(p_u_1, p3[2] or "tokyo")
				elseif v4 == "phone" then
					return v_u_2.show(p_u_1, p3[2] or "tokyo", true)
				else
					return v_u_2.show(p_u_1, v4, false)
				end
			end)
		end)
		if not v5 then
			warn("[UnlockChainDemoBoot] the command failed to register:", v6)
		end
	end
}