-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPvpveDoor

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_217 = {
	["facts"] = function(p_u_4, p5) -- name: facts
		-- upvalues: (copy) v_u_3, (copy) v_u_1
		local v_u_6 = p5 or {}
		local v_u_7 = {
			["rule"] = false,
			["flag"] = nil,
			["env"] = "studio",
			["studio"] = nil,
			["preview"] = false,
			["envs"] = nil,
			["mode"] = "pve",
			["dest"] = "pvp",
			["openAt"] = nil,
			["wall"] = nil,
			["paused"] = false,
			["pauseMsg"] = nil,
			["studio"] = v_u_3:IsStudio()
		}
		pcall(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_6, (copy) v_u_7
			local v8 = p_u_4.cctx.shared.GameMode
			local v9
			if v_u_6.doorTarget == nil then
				v9 = v8.rule("doorTarget")
			else
				v9 = v_u_6.doorTarget
			end
			local v10
			if v_u_6.pvpveDoor == nil then
				v10 = v8.rule("pvpveDoor")
			else
				v10 = v_u_6.pvpveDoor
			end
			v_u_7.rule = p_u_4.cctx.shared.PvpveDoorRules.ruleOn(v9, v10) == true
			v_u_7.dest = p_u_4.cctx.shared.PvpveDoorRules.destOf(v9) or "pvp"
		end)
		pcall(function()
			-- upvalues: (copy) v_u_7, (copy) p_u_4
			v_u_7.flag = p_u_4.cctx.shared.Config.flag("PvpveTeleport")
			v_u_7.env = p_u_4.cctx.shared.Config.ENV
			v_u_7.envs = p_u_4.cctx.shared.Config.ENVS
			v_u_7.mode = p_u_4.cctx.shared.Config.GAME_MODE
			v_u_7.openAt = p_u_4.cctx.shared.Config.PVP_OPEN_AT_LIVE
		end)
		pcall(function()
			-- upvalues: (copy) v_u_7
			v_u_7.preview = workspace:GetAttribute("PvpveDoorPreview") == true
		end)
		local function v11()
			-- upvalues: (copy) v_u_7, (ref) v_u_1
			v_u_7.wall = v_u_1.now() - 1
		end
		pcall(v11)
		pcall(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_7
			local v12 = p_u_4.cctx.shared.PvpveDoorRules
			v_u_7.paused = workspace:GetAttribute(v12.PAUSE_ATTR) == true
			v_u_7.pauseMsg = workspace:GetAttribute(v12.PAUSE_MSG_ATTR)
		end)
		for v13, v14 in v_u_6 do
			if v13 ~= "flag" and (v13 ~= "rule" and (v13 ~= "env" and (v13 ~= "studio" and (v13 ~= "preview" and (v13 ~= "envs" and (v13 ~= "mode" and (v13 ~= "dest" and (v13 ~= "openAt" and (v13 ~= "wall" and (v13 ~= "paused" and v13 ~= "pauseMsg")))))))))) then
				continue
			end
			v_u_7[v13] = v14
		end
		if v_u_6.flagNil == true then
			v_u_7.flag = nil
		end
		return v_u_7
	end,
	["openFor"] = function(p_u_15, p16) -- name: openFor
		-- upvalues: (copy) v_u_217
		local v17, v18 = pcall(function()
			-- upvalues: (copy) p_u_15
			return p_u_15.shared.PvpveDoorRules
		end)
		if not v17 or type(v18) ~= "table" then
			v18 = nil
		end
		if v18 == nil then
			return false
		else
			return v18.visible(v_u_217.facts({
				["cctx"] = p_u_15
			}, p16)) == true
		end
	end,
	["new"] = function(p_u_19, p20, p21, p22) -- name: new
		-- upvalues: (copy) v_u_217, (copy) v_u_2, (copy) v_u_3
		local v_u_23 = p_u_19.ui
		local v_u_24 = p_u_19.theme
		local v_u_25 = v_u_24.color
		local v_u_26 = p_u_19.cctx
		local v27, v_u_28 = pcall(function()
			-- upvalues: (copy) v_u_26
			return v_u_26.shared.PvpveDoorRules
		end)
		if not v27 or type(v_u_28) ~= "table" then
			v_u_28 = nil
		end
		local v29 = v_u_28 ~= nil
		assert(v29, "PvpveDoorRules missing")
		local v_u_30 = type(p22) ~= "table" and {} or p22
		local v31 = v_u_30.mode
		local v_u_32 = type(v31) ~= "string" and "full" or v_u_30.mode
		local v33 = v_u_30.onSize
		local v_u_34
		if type(v33) == "function" then
			v_u_34 = v_u_30.onSize
		else
			v_u_34 = nil
		end
		local v_u_35 = {
			["sent"] = {},
			["toasts"] = {},
			["ov"] = {},
			["mode"] = v_u_32
		}
		local v_u_36 = true
		local v_u_37 = false
		local v_u_38 = false
		local v_u_39 = false
		local v_u_40 = false
		local v_u_41 = nil
		local v_u_42 = nil
		local v_u_43 = nil
		local v_u_44 = nil
		local v_u_45 = v_u_217.facts(p_u_19, nil).dest
		local v_u_46 = v_u_28.textsFor(v_u_45)
		local v_u_47 = nil
		local v_u_48 = "idle"
		local v_u_49 = ""
		local v_u_50 = 0
		local v_u_51 = 0
		local v_u_52 = {}
		local v_u_53 = nil
		local function v_u_55() -- name: nowS
			-- upvalues: (copy) v_u_35
			local v54 = v_u_35.ov.now
			if type(v54) == "number" then
				return v_u_35.ov.now
			else
				return os.clock()
			end
		end
		local function v_u_57(p56) -- name: touchH
			-- upvalues: (copy) v_u_24
			return v_u_24.touch(p56 == "mini" and 32 or 36)
		end
		local v58 = v_u_32
		local v59 = v_u_28.layout
		local v60 = v_u_30.cardH
		local v61
		if type(v60) == "number" then
			v61 = v_u_30.cardH
		else
			v61 = v_u_24.touch(48)
		end
		local v_u_62 = v59(v58, v61, v_u_57(v58))
		local v_u_63 = v_u_23.new("Frame", {
			["Name"] = "PvpveDoorTile",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_25.raised,
			["Size"] = UDim2.fromOffset(v_u_62.w, v_u_62.h),
			["LayoutOrder"] = p21
		}, p20)
		v_u_35.frame = v_u_63
		local v64 = v_u_23.new("Frame", {
			["Name"] = "Glow",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v_u_25.dangerDeep,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_63)
		v_u_23.new("UIGradient", {
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.7), NumberSequenceKeypoint.new(1, 1) })
		}, v64)
		local v65 = v_u_23.new("Frame", {
			["Name"] = "Rim",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Active"] = false,
			["Size"] = nil,
			["ZIndex"] = 9,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_63)
		local v_u_66 = v_u_23.stroke(v65, v_u_25.line, 1)
		local v_u_67 = v_u_23.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v_u_25.danger,
			["Size"] = UDim2.fromOffset(4, v_u_62.h)
		}, v_u_63)
		local v_u_68 = v_u_23.new("Frame", {
			["Name"] = "Chip",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 6,
			["BackgroundColor3"] = v_u_25.accentDeep,
			["Size"] = UDim2.fromOffset(74, 18)
		}, v_u_63)
		local v_u_69 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["textSize"] = 11,
			["align"] = "center",
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["zindex"] = 7,
			["parent"] = v_u_68,
			["text"] = v_u_46.tag,
			["color"] = v_u_25.accent,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_70 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "h3",
			["color"] = nil,
			["textSize"] = 18,
			["size"] = nil,
			["zindex"] = 6,
			["track"] = false,
			["parent"] = v_u_63,
			["text"] = v_u_46.name,
			["color"] = v_u_25.text,
			["size"] = UDim2.fromOffset(100, 22)
		})
		local v_u_71 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Line",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["textSize"] = 13,
			["wrap"] = true,
			["valign"] = "top",
			["size"] = nil,
			["zindex"] = 6,
			["track"] = false,
			["parent"] = v_u_63,
			["text"] = v_u_46.line,
			["color"] = v_u_25.text2,
			["size"] = UDim2.fromOffset(124, 32)
		})
		local v_u_72 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Caption",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["textSize"] = 13,
			["size"] = nil,
			["zindex"] = 6,
			["track"] = false,
			["fit"] = true,
			["parent"] = v_u_63,
			["color"] = v_u_25.text2,
			["size"] = UDim2.fromOffset(100, 16)
		})
		local v_u_73 = v_u_23.icon(v_u_45 == "pve" and "door" or "skull", {
			["parent"] = nil,
			["size"] = 22,
			["color"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_63,
			["color"] = v_u_25.danger
		})
		local v_u_74, v_u_75 = v_u_23.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "primary",
			["size"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_63,
			["text"] = v_u_46.button,
			["size"] = UDim2.fromOffset(96, 36),
			["position"] = UDim2.fromOffset(0, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_35
				v_u_35.press()
			end
		})
		v_u_74.Name = "Travel"
		v_u_74.ZIndex = 8
		local v76 = v_u_74:FindFirstChild("Inner")
		local v77
		if v76 then
			v77 = v76:FindFirstChildOfClass("UIPadding")
		else
			v77 = nil
		end
		if v77 then
			v77.PaddingLeft = UDim.new(0, 6)
			v77.PaddingRight = UDim.new(0, 6)
		end
		local v_u_78 = v_u_23.new("TextButton", {
			["Name"] = "Tap",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 10,
			["Selectable"] = true,
			["Visible"] = false,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_63)
		v_u_78.SelectionImageObject = v_u_23.selectionImage()
		local v79 = v_u_78.Activated
		table.insert(v_u_52, v79:Connect(function()
			-- upvalues: (copy) v_u_35
			v_u_35.press()
		end))
		local v80 = v_u_78.MouseEnter
		table.insert(v_u_52, v80:Connect(function()
			-- upvalues: (copy) v_u_66, (copy) v_u_25
			v_u_66.Color = v_u_25.danger
		end))
		local v81 = v_u_78.MouseLeave
		table.insert(v_u_52, v81:Connect(function()
			-- upvalues: (copy) v_u_66, (copy) v_u_25
			v_u_66.Color = v_u_25.line
		end))
		local v_u_82 = v_u_23.new("Frame", {
			["Name"] = "Pill",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 7,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_25.accent,
			["Size"] = UDim2.fromOffset(72, 24)
		}, v_u_63)
		local v_u_83 = v_u_23.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "h3",
			["color"] = nil,
			["textSize"] = 13,
			["align"] = "center",
			["size"] = nil,
			["track"] = false,
			["zindex"] = 8,
			["fit"] = true,
			["parent"] = v_u_82,
			["text"] = v_u_46.button,
			["color"] = v_u_25.ink,
			["size"] = UDim2.fromScale(1, 1)
		})
		local function v_u_88() -- name: view
			-- upvalues: (copy) v_u_28, (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (ref) v_u_49, (copy) v_u_45, (ref) v_u_41, (ref) v_u_42, (ref) v_u_44, (ref) v_u_43
			local v84 = v_u_28.view
			local v85 = {}
			local v86, v87
			if v_u_48 == "idle" then
				if v_u_39 then
					v86 = "soon"
					v85.phase = v86
					v85.code = v_u_49
					v85.dest = v_u_45
					v85.openAt = v_u_41
					v85.wall = v_u_42
					if v_u_48 == "error" then
						v87 = v_u_44
					else
						v87 = v_u_43
					end
					v85.msg = v87
					return v84(v85)
				elseif v_u_40 then
					v86 = "paused"
					v85.phase = v86
					v85.code = v_u_49
					v85.dest = v_u_45
					v85.openAt = v_u_41
					v85.wall = v_u_42
					if v_u_48 == "error" then
						v87 = v_u_44
					else
						v87 = v_u_43
					end
					v85.msg = v87
					return v84(v85)
				else
					v86 = v_u_48
					v85.phase = v86
					v85.code = v_u_49
					v85.dest = v_u_45
					v85.openAt = v_u_41
					v85.wall = v_u_42
					if v_u_48 == "error" then
						v87 = v_u_44
					else
						v87 = v_u_43
					end
					v85.msg = v87
					return v84(v85)
				end
			else
				v86 = v_u_48
				v85.phase = v86
				v85.code = v_u_49
				v85.dest = v_u_45
				v85.openAt = v_u_41
				v85.wall = v_u_42
				if v_u_48 == "error" then
					v87 = v_u_44
				else
					v87 = v_u_43
				end
				v85.msg = v87
				return v84(v85)
			end
		end
		local function v_u_107() -- name: applyLayout
			-- upvalues: (ref) v_u_62, (ref) v_u_32, (copy) v_u_28, (copy) v_u_30, (copy) v_u_24, (copy) v_u_57, (copy) v_u_63, (copy) v_u_67, (copy) v_u_68, (copy) v_u_70, (copy) v_u_71, (copy) v_u_72, (copy) v_u_73, (copy) v_u_74, (copy) v_u_82, (copy) v_u_78, (copy) v_u_46, (copy) v_u_69
			local v89 = v_u_32
			local v90 = v_u_28.layout
			local v91 = v_u_30.cardH
			local v92
			if type(v91) == "number" then
				v92 = v_u_30.cardH
			else
				v92 = v_u_24.touch(48)
			end
			v_u_62 = v90(v89, v92, v_u_57(v89))
			v_u_63.Size = UDim2.fromOffset(v_u_62.w, v_u_62.h)
			v_u_67.Size = UDim2.fromOffset(4, v_u_62.h)
			local v93 = v_u_68
			local v94 = v_u_62.chip
			if v94 == nil then
				v93.Visible = false
			else
				v93.Position = UDim2.fromOffset(v94.x, v94.y)
				v93.Size = UDim2.fromOffset(v94.w, v94.h)
				v93.Visible = true
			end
			local v95 = v_u_70
			local v96 = v_u_62.title
			if v96 == nil then
				v95.Visible = false
			else
				v95.Position = UDim2.fromOffset(v96.x, v96.y)
				v95.Size = UDim2.fromOffset(v96.w, v96.h)
				v95.Visible = true
			end
			local v97 = v_u_71
			local v98
			if v_u_62.hasLine then
				v98 = v_u_62.line
			else
				v98 = nil
			end
			if v98 == nil then
				v97.Visible = false
			else
				v97.Position = UDim2.fromOffset(v98.x, v98.y)
				v97.Size = UDim2.fromOffset(v98.w, v98.h)
				v97.Visible = true
			end
			local v99 = v_u_72
			local v100 = v_u_62.caption
			if v100 == nil then
				v99.Visible = false
			else
				v99.Position = UDim2.fromOffset(v100.x, v100.y)
				v99.Size = UDim2.fromOffset(v100.w, v100.h)
				v99.Visible = true
			end
			local v101 = v_u_73
			local v102 = v_u_62.icon
			if v102 == nil then
				v101.Visible = false
			else
				v101.Position = UDim2.fromOffset(v102.x, v102.y)
				v101.Size = UDim2.fromOffset(v102.w, v102.h)
				v101.Visible = true
			end
			local v103 = v_u_74
			local v104
			if v_u_62.buttonKind == "button" then
				v104 = v_u_62.button
			else
				v104 = nil
			end
			if v104 == nil then
				v103.Visible = false
			else
				v103.Position = UDim2.fromOffset(v104.x, v104.y)
				v103.Size = UDim2.fromOffset(v104.w, v104.h)
				v103.Visible = true
			end
			local v105 = v_u_82
			local v106
			if v_u_62.buttonKind == "pill" then
				v106 = v_u_62.pill
			else
				v106 = nil
			end
			if v106 == nil then
				v105.Visible = false
			else
				v105.Position = UDim2.fromOffset(v106.x, v106.y)
				v105.Size = UDim2.fromOffset(v106.w, v106.h)
				v105.Visible = true
			end
			v_u_78.Visible = v_u_62.buttonKind ~= "button"
			v_u_78.Selectable = v_u_62.buttonKind ~= "button"
			if v_u_62.titleSize then
				v_u_70.TextSize = v_u_24.phoneText(v_u_62.titleSize, "text")
			end
			if v_u_32 == "phone" then
				v_u_70.Text = v_u_46.phoneTitle
				v_u_72.Text = v_u_46.tag
			elseif v_u_32 == "square" then
				v_u_72.Text = v_u_46.phoneTitle
			end
			v_u_70.Visible = v_u_32 ~= "square"
			v_u_68.Visible = v_u_62.chip ~= nil
			v_u_69.Text = v_u_46.tag
		end
		local v_u_108 = v_u_71.TextSize
		local v_u_109 = nil
		local function v110()
			-- upvalues: (ref) v_u_109
			v_u_109 = require((script.Parent:WaitForChild("TextFitting", 5)))
		end
		pcall(v110)
		local function v_u_122(p111) -- name: fitLine
			-- upvalues: (copy) v_u_71, (ref) v_u_109, (ref) v_u_62, (copy) v_u_108
			v_u_71.TextWrapped = true
			if p111 and (v_u_109 ~= nil and v_u_62.line ~= nil) then
				local v_u_112 = v_u_62.line.w
				local v113 = v_u_62.line.h
				local v_u_114 = v_u_71.Text
				v_u_71.TextTruncate = Enum.TextTruncate.None
				local function v119(p115) -- name: heightAt
					-- upvalues: (ref) v_u_71, (ref) v_u_109, (copy) v_u_114, (copy) v_u_112
					v_u_71.TextSize = p115
					local v116 = v_u_71.TextBounds.Y
					if v116 > 0 then
						return v116
					end
					local v117 = v_u_109.estimate(v_u_114, p115) / v_u_112
					local v118 = math.ceil(v117)
					return math.max(1, v118) * p115 * 1.2
				end
				local v120, v121 = v_u_109.pickSize(v119, v113, v_u_108, 10)
				v_u_71.TextSize = v120
				if not v121 then
					v_u_71.TextTruncate = Enum.TextTruncate.AtEnd
				end
			else
				v_u_71.TextSize = v_u_108
				v_u_71.TextTruncate = Enum.TextTruncate.None
			end
		end
		local function v_u_141() -- name: paintText
			-- upvalues: (copy) v_u_28, (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (ref) v_u_49, (copy) v_u_45, (ref) v_u_41, (ref) v_u_42, (ref) v_u_44, (ref) v_u_43, (copy) v_u_75, (copy) v_u_83, (copy) v_u_82, (copy) v_u_78, (copy) v_u_25, (ref) v_u_62, (copy) v_u_71, (copy) v_u_122, (ref) v_u_32, (copy) v_u_72, (copy) v_u_46, (copy) v_u_70
			local v123 = v_u_28.view
			local v124 = {}
			local v125
			if v_u_48 == "idle" then
				if v_u_39 then
					v125 = "soon"
				elseif v_u_40 then
					v125 = "paused"
				else
					v125 = v_u_48
				end
			else
				v125 = v_u_48
			end
			v124.phase = v125
			v124.code = v_u_49
			v124.dest = v_u_45
			v124.openAt = v_u_41
			v124.wall = v_u_42
			local v126
			if v_u_48 == "error" then
				v126 = v_u_44
			else
				v126 = v_u_43
			end
			v124.msg = v126
			local v127 = v123(v124)
			local v128, v129, v130, v131, v132, v133, v134, v135, v136, v137, v138, v139, v140
			if v_u_48 == "idle" then
				if v_u_39 then
					v128 = "soon"
					v129 = v128 == "soon" and true or v128 == "paused"
					v_u_75.setText(v127.button)
					v_u_83.Text = v127.button
					v_u_75.setEnabled(v127.enabled)
					v_u_82.BackgroundTransparency = v127.enabled and 0 or 0.55
					v_u_78.Active = v127.enabled
					if v127.tone == "danger" then
						v130 = v_u_25.danger
					elseif v127.tone == "accent" then
						v130 = v_u_25.accent
					else
						v130 = v_u_25.text2
					end
					if v_u_62.hasLine then
						v_u_71.Text = v127.line
						v_u_71.TextColor3 = v130
						v_u_122(v129)
					end
					if v_u_32 == "phone" then
						v131 = v_u_72
						if v129 then
							v132 = v127.button
						else
							v132 = v_u_46.tag
						end
						v131.Text = v132
						v133 = v_u_72
						if v129 and v127.tone == "danger" then
							v134 = v_u_25.danger
						else
							v134 = v_u_25.text2
						end
						v133.TextColor3 = v134
					elseif v_u_32 == "square" then
						v135 = v_u_72
						if v129 then
							v136 = v127.button
						else
							v136 = v_u_46.phoneTitle
						end
						v135.Text = v136
						v137 = v_u_72
						if v129 and v127.tone == "danger" then
							v138 = v_u_25.danger
						else
							v138 = v_u_25.text2
						end
						v137.TextColor3 = v138
					end
					if v_u_32 == "slim" and v_u_48 ~= "idle" then
						v139 = v_u_70
						if v_u_48 == "travelling" then
							v140 = v_u_46.travelling
						else
							v140 = v_u_46.name
						end
						v139.Text = v140
					elseif v_u_32 == "slim" then
						v_u_70.Text = v_u_46.name
					end
				elseif v_u_40 then
					v128 = "paused"
					v129 = v128 == "soon" and true or v128 == "paused"
					v_u_75.setText(v127.button)
					v_u_83.Text = v127.button
					v_u_75.setEnabled(v127.enabled)
					v_u_82.BackgroundTransparency = v127.enabled and 0 or 0.55
					v_u_78.Active = v127.enabled
					if v127.tone == "danger" then
						v130 = v_u_25.danger
					elseif v127.tone == "accent" then
						v130 = v_u_25.accent
					else
						v130 = v_u_25.text2
					end
					if v_u_62.hasLine then
						v_u_71.Text = v127.line
						v_u_71.TextColor3 = v130
						v_u_122(v129)
					end
					if v_u_32 == "phone" then
						v131 = v_u_72
						if v129 then
							v132 = v127.button
						else
							v132 = v_u_46.tag
						end
						v131.Text = v132
						v133 = v_u_72
						if v129 and v127.tone == "danger" then
							v134 = v_u_25.danger
						else
							v134 = v_u_25.text2
						end
						v133.TextColor3 = v134
					elseif v_u_32 == "square" then
						v135 = v_u_72
						if v129 then
							v136 = v127.button
						else
							v136 = v_u_46.phoneTitle
						end
						v135.Text = v136
						v137 = v_u_72
						if v129 and v127.tone == "danger" then
							v138 = v_u_25.danger
						else
							v138 = v_u_25.text2
						end
						v137.TextColor3 = v138
					end
					if v_u_32 == "slim" and v_u_48 ~= "idle" then
						v139 = v_u_70
						if v_u_48 == "travelling" then
							v140 = v_u_46.travelling
						else
							v140 = v_u_46.name
						end
						v139.Text = v140
					elseif v_u_32 == "slim" then
						v_u_70.Text = v_u_46.name
					end
				else
					v128 = v_u_48
					v129 = v128 == "soon" and true or v128 == "paused"
					v_u_75.setText(v127.button)
					v_u_83.Text = v127.button
					v_u_75.setEnabled(v127.enabled)
					v_u_82.BackgroundTransparency = v127.enabled and 0 or 0.55
					v_u_78.Active = v127.enabled
					if v127.tone == "danger" then
						v130 = v_u_25.danger
					elseif v127.tone == "accent" then
						v130 = v_u_25.accent
					else
						v130 = v_u_25.text2
					end
					if v_u_62.hasLine then
						v_u_71.Text = v127.line
						v_u_71.TextColor3 = v130
						v_u_122(v129)
					end
					if v_u_32 == "phone" then
						v131 = v_u_72
						if v129 then
							v132 = v127.button
						else
							v132 = v_u_46.tag
						end
						v131.Text = v132
						v133 = v_u_72
						if v129 and v127.tone == "danger" then
							v134 = v_u_25.danger
						else
							v134 = v_u_25.text2
						end
						v133.TextColor3 = v134
					elseif v_u_32 == "square" then
						v135 = v_u_72
						if v129 then
							v136 = v127.button
						else
							v136 = v_u_46.phoneTitle
						end
						v135.Text = v136
						v137 = v_u_72
						if v129 and v127.tone == "danger" then
							v138 = v_u_25.danger
						else
							v138 = v_u_25.text2
						end
						v137.TextColor3 = v138
					end
					if v_u_32 == "slim" and v_u_48 ~= "idle" then
						v139 = v_u_70
						if v_u_48 == "travelling" then
							v140 = v_u_46.travelling
						else
							v140 = v_u_46.name
						end
						v139.Text = v140
					elseif v_u_32 == "slim" then
						v_u_70.Text = v_u_46.name
					end
				end
			else
				v128 = v_u_48
				v129 = v128 == "soon" and true or v128 == "paused"
				v_u_75.setText(v127.button)
				v_u_83.Text = v127.button
				v_u_75.setEnabled(v127.enabled)
				v_u_82.BackgroundTransparency = v127.enabled and 0 or 0.55
				v_u_78.Active = v127.enabled
				if v127.tone == "danger" then
					v130 = v_u_25.danger
				elseif v127.tone == "accent" then
					v130 = v_u_25.accent
				else
					v130 = v_u_25.text2
				end
				if v_u_62.hasLine then
					v_u_71.Text = v127.line
					v_u_71.TextColor3 = v130
					v_u_122(v129)
				end
				if v_u_32 == "phone" then
					v131 = v_u_72
					if v129 then
						v132 = v127.button
					else
						v132 = v_u_46.tag
					end
					v131.Text = v132
					v133 = v_u_72
					if v129 and v127.tone == "danger" then
						v134 = v_u_25.danger
					else
						v134 = v_u_25.text2
					end
					v133.TextColor3 = v134
				elseif v_u_32 == "square" then
					v135 = v_u_72
					if v129 then
						v136 = v127.button
					else
						v136 = v_u_46.phoneTitle
					end
					v135.Text = v136
					v137 = v_u_72
					if v129 and v127.tone == "danger" then
						v138 = v_u_25.danger
					else
						v138 = v_u_25.text2
					end
					v137.TextColor3 = v138
				end
				if v_u_32 == "slim" and v_u_48 ~= "idle" then
					v139 = v_u_70
					if v_u_48 == "travelling" then
						v140 = v_u_46.travelling
					else
						v140 = v_u_46.name
					end
					v139.Text = v140
				elseif v_u_32 == "slim" then
					v_u_70.Text = v_u_46.name
				end
			end
		end
		function v_u_35.view() -- name: view
			-- upvalues: (copy) v_u_88
			return v_u_88()
		end
		function v_u_35.state() -- name: state
			-- upvalues: (ref) v_u_48, (ref) v_u_39, (ref) v_u_40
			if v_u_48 == "idle" then
				if v_u_39 then
					return "soon"
				end
				if v_u_40 then
					return "paused"
				end
			end
			return v_u_48
		end
		function v_u_35.dest() -- name: dest
			-- upvalues: (copy) v_u_45
			return v_u_45
		end
		function v_u_35.loader() -- name: loader
			-- upvalues: (ref) v_u_47
			return v_u_47
		end
		function v_u_35.kind() -- name: kind
			-- upvalues: (ref) v_u_32
			return v_u_32
		end
		function v_u_35.isOpen() -- name: isOpen
			-- upvalues: (ref) v_u_38
			return v_u_38
		end
		function v_u_35.speaksSentence() -- name: speaksSentence
			-- upvalues: (ref) v_u_48
			return v_u_48 == "error"
		end
		function v_u_35.heightFor(p142) -- name: heightFor
			-- upvalues: (copy) v_u_28, (copy) v_u_30, (copy) v_u_24, (copy) v_u_57
			local v143 = v_u_28.layout
			local v144 = v_u_30.cardH
			local v145
			if type(v144) == "number" then
				v145 = v_u_30.cardH
			else
				v145 = v_u_24.touch(48)
			end
			return v143(p142, v145, v_u_57(p142)).h
		end
		function v_u_35.height() -- name: height
			-- upvalues: (ref) v_u_62
			return v_u_62.h
		end
		function v_u_35.setKind(p146) -- name: setKind
			-- upvalues: (ref) v_u_32, (copy) v_u_28, (copy) v_u_35, (copy) v_u_107, (copy) v_u_141, (copy) v_u_34, (ref) v_u_62
			if p146 ~= v_u_32 and v_u_28.layout(p146).kind == p146 then
				v_u_32 = p146
				v_u_35.mode = p146
				v_u_107()
				v_u_141()
				if v_u_34 then
					v_u_34(v_u_62.h)
				end
			end
		end
		local function v_u_155(p147, p148, p149) -- name: fail
			-- upvalues: (ref) v_u_48, (ref) v_u_49, (copy) v_u_28, (ref) v_u_44, (ref) v_u_50, (copy) v_u_35, (ref) v_u_47, (copy) v_u_141, (copy) v_u_45, (copy) v_u_23, (copy) v_u_34, (ref) v_u_62
			v_u_48 = "error"
			v_u_49 = v_u_28.codeOf(p147)
			if type(p149) ~= "string" or p149 == "" then
				p149 = nil
			end
			v_u_44 = p149
			local v150 = v_u_35.ov.now
			local v151
			if type(v150) == "number" then
				v151 = v_u_35.ov.now
			else
				v151 = os.clock()
			end
			v_u_50 = v151 + v_u_28.ERROR_HOLD
			if v_u_47 ~= nil then
				v_u_47.hide()
			end
			v_u_141()
			if p148 ~= true then
				local v_u_152 = v_u_28.errorText(v_u_49, v_u_45)
				local v153 = v_u_35.toasts
				table.insert(v153, v_u_152)
				if v_u_35.ov.noToast ~= true then
					local function v154()
						-- upvalues: (ref) v_u_23, (copy) v_u_152
						v_u_23.toast(v_u_152, "warn")
					end
					pcall(v154)
				end
			end
			if v_u_34 then
				v_u_34(v_u_62.h)
			end
		end
		function v_u_35.paint() -- name: paint
			-- upvalues: (ref) v_u_36, (ref) v_u_217, (copy) p_u_19, (copy) v_u_35, (copy) v_u_28, (ref) v_u_39, (ref) v_u_40, (ref) v_u_42, (ref) v_u_43, (ref) v_u_41, (ref) v_u_47, (ref) v_u_38, (copy) v_u_63, (copy) v_u_34, (ref) v_u_62, (ref) v_u_48, (ref) v_u_49, (ref) v_u_50, (ref) v_u_51, (copy) v_u_155, (copy) v_u_141
			if not v_u_36 then
				return
			end
			local v156 = v_u_217.facts(p_u_19, v_u_35.ov)
			local v157, v158 = v_u_28.visible(v156)
			local v159
			if v157 then
				v159 = v158 == "soon"
			else
				v159 = v157
			end
			v_u_39 = v159
			local v160
			if v157 then
				v160 = v158 == "paused"
			else
				v160 = v157
			end
			v_u_40 = v160
			local v161 = v156.wall
			local v162
			if type(v161) == "number" then
				v162 = v156.wall
			else
				v162 = nil
			end
			v_u_42 = v162
			local v163 = v156.pauseMsg
			local v164
			if type(v163) == "string" then
				v164 = v156.pauseMsg
			else
				v164 = nil
			end
			v_u_43 = v164
			local v165
			if v_u_39 and v_u_28.target(v156.env, v156.envs, v156.mode) ~= 0 then
				v165 = v_u_28.lockedUntil(v156.env, v156.openAt, v156.wall, v156.studio)
			else
				v165 = nil
			end
			v_u_41 = v165
			if not v157 and v_u_47 ~= nil then
				v_u_47.hide()
			end
			if v157 ~= v_u_38 then
				v_u_38 = v157
				v_u_63.Visible = v157
				if v_u_34 then
					v_u_34(not v157 and 0 or v_u_62.h)
				end
			end
			if v_u_48 == "error" and (v_u_39 or v_u_40) and (v_u_49 == "paused" or v_u_49 == "notyet") then
				v_u_48 = "idle"
				v_u_141()
			else
				local v166, v167
				if v_u_48 == "error" then
					local v168 = v_u_35.ov.now
					local v169
					if type(v168) == "number" then
						v169 = v_u_35.ov.now
					else
						v169 = os.clock()
					end
					if v_u_50 <= v169 then
						v_u_48 = "idle"
						v_u_141()
						return
					end
					if v_u_48 == "travelling" then
						v166 = v_u_35.ov.now
						if type(v166) == "number" then
							v167 = v_u_35.ov.now
						else
							v167 = os.clock()
						end
						if v167 - v_u_51 >= v_u_28.TRAVEL_TIMEOUT then
							v_u_155("failed")
							return
						end
					end
				elseif v_u_48 == "travelling" then
					v166 = v_u_35.ov.now
					if type(v166) == "number" then
						v167 = v_u_35.ov.now
					else
						v167 = os.clock()
					end
					if v167 - v_u_51 >= v_u_28.TRAVEL_TIMEOUT then
						v_u_155("failed")
						return
					end
				end
				v_u_141()
			end
		end
		local function v_u_182(p170) -- name: go
			-- upvalues: (ref) v_u_48, (ref) v_u_51, (copy) v_u_35, (ref) v_u_47, (copy) v_u_63, (copy) v_u_23, (copy) v_u_24, (copy) v_u_45, (copy) v_u_55, (copy) v_u_141, (copy) v_u_34, (ref) v_u_62, (copy) p_u_19
			v_u_48 = "travelling"
			local v171 = v_u_35.ov.now
			local v172
			if type(v171) == "number" then
				v172 = v_u_35.ov.now
			else
				v172 = os.clock()
			end
			v_u_51 = v172
			local v_u_173 = p170 == true
			if v_u_35.ov.noLoader ~= true then
				local function v180()
					-- upvalues: (ref) v_u_47, (ref) v_u_63, (ref) v_u_23, (ref) v_u_24, (ref) v_u_45, (copy) v_u_173, (ref) v_u_55, (ref) v_u_48, (ref) v_u_141, (ref) v_u_34, (ref) v_u_62, (ref) v_u_35
					if v_u_47 == nil then
						local v174 = require(script.Parent.TravelCard)
						local v175 = v_u_63:FindFirstAncestorWhichIsA("ScreenGui") or v_u_63
						local v176 = {
							["dest"] = v_u_45,
							["inSquad"] = v_u_173,
							["clock"] = v_u_55,
							["onAbort"] = function() -- name: onAbort
								-- upvalues: (ref) v_u_48, (ref) v_u_141, (ref) v_u_34, (ref) v_u_62
								v_u_48 = "idle"
								v_u_141()
								if v_u_34 then
									v_u_34(v_u_62.h)
								end
							end
						}
						v_u_47 = v174.newLoader(v_u_23, v_u_24, v175, v176)
					end
					local v177 = v_u_47.show
					local v178 = v_u_35.ov.now
					local v179
					if type(v178) == "number" then
						v179 = v_u_35.ov.now
					else
						v179 = os.clock()
					end
					v177(v179)
				end
				pcall(v180)
			end
			v_u_141()
			local v181 = v_u_35.sent
			table.insert(v181, {
				["op"] = "pvpveDoor"
			})
			p_u_19.op({
				["op"] = "pvpveDoor"
			})
		end
		function v_u_35.press() -- name: press
			-- upvalues: (ref) v_u_36, (ref) v_u_38, (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (ref) v_u_217, (copy) p_u_19, (copy) v_u_35, (copy) v_u_155, (copy) v_u_182, (ref) v_u_53, (copy) v_u_23, (copy) v_u_46, (copy) v_u_28, (copy) v_u_45
			if v_u_36 and (v_u_38 and (v_u_48 ~= "travelling" and not (v_u_39 or v_u_40))) then
				if v_u_217.facts(p_u_19, v_u_35.ov).studio == true then
					v_u_155("studio")
					return
				else
					local v_u_183 = false
					local function v187()
						-- upvalues: (ref) p_u_19, (ref) v_u_183
						local v184 = p_u_19.myParty()
						local v185
						if type(v184) == "table" then
							local v186 = v184.members
							if type(v186) == "table" then
								v185 = #v184.members > 1
							else
								v185 = false
							end
						else
							v185 = false
						end
						v_u_183 = v185
					end
					pcall(v187)
					if v_u_35.ov.autoConfirm == true then
						v_u_182(v_u_183)
						return
					elseif v_u_53 == nil then
						local v188 = v_u_23.modal
						local v189 = {
							["title"] = nil,
							["body"] = nil,
							["width"] = 480,
							["buttons"] = nil,
							["onClose"] = nil,
							["title"] = v_u_46.confirmTitle,
							["body"] = v_u_28.confirmBody(v_u_183, v_u_45),
							["buttons"] = {
								{
									["text"] = nil,
									["kind"] = "ghost",
									["text"] = v_u_46.confirmStay
								},
								{
									["text"] = nil,
									["kind"] = "primary",
									["onClick"] = nil,
									["text"] = v_u_46.confirmGo,
									["onClick"] = function() -- name: onClick
										-- upvalues: (ref) v_u_53, (ref) v_u_182, (ref) v_u_183
										v_u_53 = nil
										v_u_182(v_u_183)
									end
								}
							},
							["onClose"] = function() -- name: onClose
								-- upvalues: (ref) v_u_53
								v_u_53 = nil
							end
						}
						v_u_53 = v188(v189)
					end
				end
			else
				return
			end
		end
		function v_u_35.feed(p190) -- name: feed
			-- upvalues: (ref) v_u_48, (ref) v_u_49, (copy) v_u_28, (ref) v_u_44, (ref) v_u_50, (copy) v_u_35, (ref) v_u_47, (copy) v_u_141, (copy) v_u_34, (ref) v_u_62
			if type(p190) == "table" and p190.op == "pvpveDoor" then
				if p190.ok == false then
					local v191 = p190.data
					local v192
					if type(v191) == "table" then
						local v193 = p190.data.code
						v192 = type(v193) ~= "string" and "failed" or p190.data.code
					else
						v192 = "failed"
					end
					local v194 = p190.msg
					v_u_48 = "error"
					v_u_49 = v_u_28.codeOf(v192)
					if type(v194) ~= "string" or v194 == "" then
						v194 = nil
					end
					v_u_44 = v194
					local v195 = v_u_35.ov.now
					local v196
					if type(v195) == "number" then
						v196 = v_u_35.ov.now
					else
						v196 = os.clock()
					end
					v_u_50 = v196 + v_u_28.ERROR_HOLD
					if v_u_47 ~= nil then
						v_u_47.hide()
					end
					v_u_141()
					if v_u_34 then
						v_u_34(v_u_62.h)
					end
				end
			end
		end
		if p_u_19.changed ~= nil then
			local v197 = p_u_19.changed
			table.insert(v_u_52, v197:Connect(function(p198, p199)
				-- upvalues: (copy) v_u_35
				if p198 == "result" then
					v_u_35.feed(p199)
				end
			end))
		end
		local function v207()
			-- upvalues: (copy) v_u_52, (ref) v_u_2, (ref) v_u_48, (copy) v_u_155
			local v200 = v_u_52
			local v201 = game:GetService("TeleportService").TeleportInitFailed
			local function v206(p202, p203, _, _)
				-- upvalues: (ref) v_u_2, (ref) v_u_48, (ref) v_u_155
				if p202 == v_u_2.LocalPlayer and v_u_48 == "travelling" then
					local v204 = v_u_155
					local v205
					if typeof(p203) == "EnumItem" then
						v205 = p203.Name
					else
						v205 = tostring(p203)
					end
					v204(v205)
				end
			end
			table.insert(v200, v201:Connect(v206))
		end
		pcall(v207)
		function v_u_35.setActive(p208) -- name: setActive
			-- upvalues: (ref) v_u_37, (copy) v_u_35
			v_u_37 = p208
			if p208 then
				v_u_35.paint()
			end
		end
		local v_u_209 = 0
		local v210 = v_u_3.Heartbeat
		local function v212(p211)
			-- upvalues: (ref) v_u_36, (ref) v_u_37, (ref) v_u_209, (copy) v_u_35
			if v_u_36 and v_u_37 then
				v_u_209 = v_u_209 + p211
				if v_u_209 >= 0.5 then
					v_u_209 = 0
					v_u_35.paint()
				end
			end
		end
		table.insert(v_u_52, v210:Connect(v212))
		pcall(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_63, (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (copy) v_u_46, (copy) v_u_28, (ref) v_u_43, (ref) v_u_41, (ref) v_u_42
			v_u_23.tooltip(v_u_63, function()
				-- upvalues: (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (ref) v_u_46, (ref) v_u_28, (ref) v_u_43, (ref) v_u_41, (ref) v_u_42
				local v213
				if v_u_48 == "idle" then
					if v_u_39 then
						v213 = "soon"
						return v213 == "paused" and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.pauseLine(v_u_43)
						} or (v213 == "soon" and v_u_41 ~= nil and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.notYetText(v_u_41, v_u_42) .. " " .. v_u_46.tipBody
						} or {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_46.tipBody
						})
					elseif v_u_40 then
						v213 = "paused"
						return v213 == "paused" and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.pauseLine(v_u_43)
						} or (v213 == "soon" and v_u_41 ~= nil and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.notYetText(v_u_41, v_u_42) .. " " .. v_u_46.tipBody
						} or {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_46.tipBody
						})
					else
						v213 = v_u_48
						return v213 == "paused" and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.pauseLine(v_u_43)
						} or (v213 == "soon" and v_u_41 ~= nil and {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_28.notYetText(v_u_41, v_u_42) .. " " .. v_u_46.tipBody
						} or {
							["title"] = v_u_46.tipTitle,
							["body"] = v_u_46.tipBody
						})
					end
				else
					v213 = v_u_48
					return v213 == "paused" and {
						["title"] = v_u_46.tipTitle,
						["body"] = v_u_28.pauseLine(v_u_43)
					} or (v213 == "soon" and v_u_41 ~= nil and {
						["title"] = v_u_46.tipTitle,
						["body"] = v_u_28.notYetText(v_u_41, v_u_42) .. " " .. v_u_46.tipBody
					} or {
						["title"] = v_u_46.tipTitle,
						["body"] = v_u_46.tipBody
					})
				end
			end)
		end)
		function v_u_35.destroy() -- name: destroy
			-- upvalues: (ref) v_u_36, (ref) v_u_47, (copy) v_u_52, (ref) v_u_53, (copy) v_u_63
			v_u_36 = false
			if v_u_47 ~= nil then
				local function v214()
					-- upvalues: (ref) v_u_47
					v_u_47.destroy()
				end
				pcall(v214)
				v_u_47 = nil
			end
			for _, v215 in v_u_52 do
				v215:Disconnect()
			end
			if v_u_53 ~= nil then
				local function v216()
					-- upvalues: (ref) v_u_53
					v_u_53.close()
				end
				pcall(v216)
				v_u_53 = nil
			end
			v_u_63:Destroy()
		end
		v_u_107()
		v_u_141()
		return v_u_35
	end
}
return v_u_217