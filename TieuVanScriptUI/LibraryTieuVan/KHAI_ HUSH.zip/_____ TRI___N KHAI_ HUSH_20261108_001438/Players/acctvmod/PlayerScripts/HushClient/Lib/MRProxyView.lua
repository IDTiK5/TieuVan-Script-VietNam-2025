-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MRProxyView

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MRProxy"))
local v_u_4 = {
	["SCAN_BATCH"] = 2000,
	["SWEEP_EVERY"] = 0.1,
	["SWEEP_BATCH"] = 256,
	["forced"] = {},
	["light"] = {}
}
local v_u_5 = v_u_4.forced
local v_u_6 = v_u_4.light
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = 1
local v_u_13 = true
local v_u_14 = false
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = {}
local v_u_21 = 1
local v_u_22 = 0
local v_u_23 = nil
local function v_u_26(p_u_24) -- name: toLight
	-- upvalues: (copy) v_u_6, (ref) v_u_16, (ref) v_u_13, (copy) v_u_9
	v_u_6[p_u_24] = p_u_24.Transparency
	v_u_16 = v_u_16 + 1
	if v_u_13 and p_u_24.Transparency ~= 1 then
		p_u_24.Transparency = 1
	end
	v_u_9[p_u_24] = p_u_24:GetPropertyChangedSignal("Transparency"):Connect(function()
		-- upvalues: (copy) p_u_24, (ref) v_u_6, (copy) p_u_24, (ref) v_u_13
		local v25 = p_u_24.Transparency
		if v25 ~= 1 then
			v_u_6[p_u_24] = v25
			if v_u_13 then
				p_u_24.Transparency = 1
			end
		end
	end)
end
local function v_u_31(p27) -- name: register
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_8, (copy) v_u_10, (copy) v_u_11, (copy) v_u_1, (copy) v_u_26, (copy) v_u_5, (ref) v_u_15, (ref) v_u_13
	if v_u_7[p27] == nil then
		v_u_7[p27] = v_u_3.liveTransparency(p27)
		v_u_8[p27] = p27.LocalTransparencyModifier
		local v28 = v_u_10
		table.insert(v28, p27)
		v_u_11[p27] = #v_u_10
		local v29 = p27:FindFirstChildWhichIsA("Light", true) ~= nil
		if v_u_3.wantsLightMode(v29, v_u_1:HasTag(p27, "HushLight")) then
			v_u_26(p27)
		else
			v_u_5[p27] = true
			v_u_15 = v_u_15 + 1
			if v_u_13 then
				local v30 = v_u_3.HIDE_LTM
				if p27.LocalTransparencyModifier ~= v30 then
					p27.LocalTransparencyModifier = v30
				end
			end
		end
	else
		return
	end
end
local function v_u_39(p32) -- name: unregister
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_6, (ref) v_u_15, (ref) v_u_16, (copy) v_u_7, (copy) v_u_10, (ref) v_u_19
	local v33 = v_u_11[p32]
	if v33 ~= nil then
		local v34 = v_u_9[p32]
		if v34 then
			v34:Disconnect()
			v_u_9[p32] = nil
		end
		if v_u_5[p32] == nil then
			if v_u_6[p32] ~= nil then
				local v35 = v_u_6[p32]
				if p32.Transparency ~= v35 then
					p32.Transparency = v35
				end
			end
		else
			local v36 = v_u_8[p32] or 0
			if p32.LocalTransparencyModifier ~= v36 then
				p32.LocalTransparencyModifier = v36
			end
		end
		if v_u_5[p32] ~= nil then
			v_u_5[p32] = nil
			v_u_15 = v_u_15 - 1
		end
		if v_u_6[p32] ~= nil then
			v_u_6[p32] = nil
			v_u_16 = v_u_16 - 1
		end
		v_u_7[p32] = nil
		v_u_8[p32] = nil
		local v37 = #v_u_10
		local v38 = v_u_10[v37]
		v_u_10[v33] = v38
		v_u_11[v38] = v33
		v_u_10[v37] = nil
		v_u_11[p32] = nil
		v_u_19 = v_u_19 + 1
	end
end
local function v_u_43(p40) -- name: consider
	-- upvalues: (ref) v_u_18, (copy) v_u_3, (copy) v_u_31, (copy) v_u_5, (ref) v_u_15, (copy) v_u_8, (copy) v_u_26
	v_u_18 = v_u_18 + 1
	if v_u_3.isProxy(p40) then
		v_u_31(p40)
	elseif p40:IsA("Light") then
		local v41 = p40:FindFirstAncestorWhichIsA("BasePart")
		if v41 ~= nil and v_u_5[v41] ~= nil then
			if v_u_5[v41] == nil then
				return
			end
			v_u_5[v41] = nil
			v_u_15 = v_u_15 - 1
			local v42 = v_u_8[v41] or 0
			if v41.LocalTransparencyModifier ~= v42 then
				v41.LocalTransparencyModifier = v42
			end
			v_u_26(v41)
		end
	end
end
local function v_u_50(p44) -- name: sweepPortion
	-- upvalues: (copy) v_u_10, (ref) v_u_12, (copy) v_u_39, (ref) v_u_13, (copy) v_u_5, (copy) v_u_3, (copy) v_u_8, (ref) v_u_17, (copy) v_u_6
	local v45 = #v_u_10
	if v45 == 0 then
		v_u_12 = 1
	else
		if v45 >= p44 then
			v45 = p44
		end
		for _ = 1, v45 do
			if v_u_12 > #v_u_10 then
				v_u_12 = 1
			end
			local v46 = v_u_10[v_u_12]
			local v47
			if v46.Parent == nil then
				v_u_39(v46)
				v47 = true
			elseif v_u_13 then
				if v_u_5[v46] == nil then
					if v_u_6[v46] == nil then
						v47 = false
					else
						local v48 = v46.Transparency
						if v48 == 1 then
							v47 = false
						else
							v_u_6[v46] = v48
							v46.Transparency = 1
							v47 = false
						end
					end
				else
					local v49 = v46.LocalTransparencyModifier
					if v49 == v_u_3.HIDE_LTM then
						v47 = false
					else
						v_u_8[v46] = v49
						v46.LocalTransparencyModifier = v_u_3.HIDE_LTM
						v_u_17 = v_u_17 + 1
						v47 = false
					end
				end
			else
				v47 = false
			end
			if not v47 then
				v_u_12 = v_u_12 + 1
			end
			if #v_u_10 ~= 0 then
				continue
			end
			return
		end
	end
end
local function v52() -- name: reset
	-- upvalues: (ref) v_u_23, (copy) v_u_9, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	if v_u_23 then
		v_u_23:Disconnect()
		v_u_23 = nil
	end
	for _, v51 in v_u_9 do
		v51:Disconnect()
	end
	table.clear(v_u_9)
	table.clear(v_u_5)
	table.clear(v_u_6)
	table.clear(v_u_7)
	table.clear(v_u_8)
	table.clear(v_u_11)
	table.clear(v_u_10)
	v_u_12 = 1
	v_u_13 = true
	v_u_14 = false
	v_u_15 = 0
	v_u_16 = 0
	v_u_17 = 0
	v_u_18 = 0
	v_u_19 = 0
	v_u_20 = {}
	v_u_21 = 1
	v_u_22 = 0
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_14, (ref) v_u_23, (copy) v_u_43, (ref) v_u_20, (ref) v_u_21
	if not v_u_14 then
		v_u_14 = true
		v_u_23 = workspace.DescendantAdded:Connect(v_u_43)
		v_u_20 = workspace:GetDescendants()
		v_u_21 = 1
	end
end
function v_u_4.step(p53) -- name: step
	-- upvalues: (ref) v_u_20, (ref) v_u_21, (copy) v_u_4, (copy) v_u_43, (ref) v_u_22, (copy) v_u_50
	local v54 = #v_u_20
	if v_u_21 <= v54 then
		local v55 = v_u_21 + v_u_4.SCAN_BATCH - 1
		local v56 = math.min(v54, v55)
		for v57 = v_u_21, v56 do
			local v58 = v_u_20[v57]
			if v58.Parent == nil then
				continue
			end
			v_u_43(v58)
		end
		v_u_21 = v56 + 1
		if v54 < v_u_21 then
			v_u_20 = {}
			v_u_21 = 1
		end
	end
	v_u_22 = v_u_22 + p53
	if v_u_22 >= v_u_4.SWEEP_EVERY then
		v_u_22 = v_u_22 - v_u_4.SWEEP_EVERY
		if v_u_22 > v_u_4.SWEEP_EVERY then
			v_u_22 = 0
		end
		v_u_50(v_u_4.SWEEP_BATCH)
	end
end
function v_u_4.clampLtm(p59, p60) -- name: clampLtm
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_3, (ref) v_u_13, (copy) v_u_5
	if v_u_7[p59] == nil then
		return p60
	end
	v_u_8[p59] = p60
	local v61 = v_u_3.clampLtm
	local v62 = v_u_13
	if v62 then
		v62 = v_u_5[p59] ~= nil
	end
	return v61(p60, v62)
end
function v_u_4.drawnTransparency(p63) -- name: drawnTransparency
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_8
	local v64 = v_u_7[p63]
	if v64 == nil then
		return nil
	else
		return v_u_3.drawn(v64, v_u_8[p63] or 0)
	end
end
function v_u_4.setEnabled(p65) -- name: setEnabled
	-- upvalues: (ref) v_u_13, (copy) v_u_5, (copy) v_u_3, (copy) v_u_8, (copy) v_u_6
	if p65 ~= v_u_13 then
		v_u_13 = p65
		for v66 in v_u_5 do
			local v67
			if p65 then
				v67 = v_u_3.HIDE_LTM
			else
				v67 = v_u_8[v66] or 0
			end
			if v66.LocalTransparencyModifier == v67 then
				continue
			end
			v66.LocalTransparencyModifier = v67
		end
		for v68, v69 in v_u_6 do
			local v70 = p65 and 1 or v69
			if v68.Transparency == v70 then
				continue
			end
			v68.Transparency = v70
		end
	end
end
function v_u_4.isEnabled() -- name: isEnabled
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_4.stats() -- name: stats
	-- upvalues: (copy) v_u_10, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_13
	local v71 = {
		["proxies"] = #v_u_10,
		["ltm"] = v_u_15,
		["light"] = v_u_16,
		["reasserted"] = v_u_17,
		["scanned"] = v_u_18,
		["swept"] = v_u_19
	}
	local v72 = #v_u_20 - v_u_21 + 1
	v71.queued = math.max(0, v72)
	v71.enabled = v_u_13
	return v71
end
v_u_4._test = {
	["consider"] = v_u_43,
	["sweepAll"] = function() -- name: sweepAll
		-- upvalues: (copy) v_u_50, (copy) v_u_10
		v_u_50(#v_u_10)
	end,
	["reset"] = v52
}
return v_u_4