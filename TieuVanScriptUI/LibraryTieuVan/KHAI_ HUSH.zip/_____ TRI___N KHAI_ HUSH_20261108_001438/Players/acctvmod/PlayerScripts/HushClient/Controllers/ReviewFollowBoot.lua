-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / ReviewFollowBoot

return {
	["name"] = "ReviewFollowBoot",
	["order"] = 79,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.ReviewFollowBar.init(p_u_1)
		end)
		if not v2 then
			warn("[ReviewFollowBoot] ReviewFollowBar failed to start: " .. tostring(v3))
		end
	end
}