-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUICaseOpen

local v_u_50 = {
	["TEXT"] = {
		["entry"] = "Open",
		["inspect"] = "Open case"
	},
	["ID"] = "case_open",
	["PREFIX"] = "skin_crate_",
	["isCase"] = function(p1) -- name: isCase
		-- upvalues: (copy) v_u_50
		local v2
		if type(p1) == "string" and #p1 > #v_u_50.PREFIX then
			local v3 = #v_u_50.PREFIX
			v2 = string.sub(p1, 1, v3) == v_u_50.PREFIX
		else
			v2 = false
		end
		return v2
	end,
	["entry"] = function(p4, p5, p6) -- name: entry
		-- upvalues: (copy) v_u_50
		return p5 == true and (p6 == true and v_u_50.isCase(p4)) and {
			["id"] = v_u_50.ID,
			["text"] = v_u_50.TEXT.entry,
			["crate"] = p4
		} or nil
	end,
	["acts"] = function(p_u_7, p8, p9, _, p10) -- name: acts
		-- upvalues: (copy) v_u_50
		if type(p9) == "table" then
			local v11 = p9.item
			if type(v11) == "table" then
				local v12 = v_u_50.entry
				local v13 = p9.item.id
				local v14 = p8.mode ~= "raid"
				local v15, v16 = pcall(function()
					-- upvalues: (copy) p_u_7
					return p_u_7.controllers.Menu.cratesListed()
				end)
				if v15 then
					v15 = v16 == true
				end
				local v17 = v12(v13, v14, v15)
				if v17 then
					local v18 = {
						["id"] = v17.id,
						["text"] = v17.text
					}
					table.insert(p10, v18)
				end
				return
			end
		end
	end,
	["strip"] = function(p_u_19, p20, p21, _, p22) -- name: strip
		-- upvalues: (copy) v_u_50
		if type(p21) == "table" then
			local v23 = p21.item
			if type(v23) == "table" then
				local v24 = v_u_50.entry
				local v25 = p21.item.id
				local v26 = p20.mode ~= "raid"
				local v27, v28 = pcall(function()
					-- upvalues: (copy) p_u_19
					return p_u_19.controllers.Menu.cratesListed()
				end)
				if v27 then
					v27 = v28 == true
				end
				local v29 = v24(v25, v26, v27)
				if v29 then
					local v30 = {
						["id"] = nil,
						["text"] = nil,
						["icon"] = "openbag",
						["id"] = v29.id,
						["text"] = v29.text
					}
					table.insert(p22, v30)
				end
				return
			end
		end
	end,
	["run"] = function(p_u_31, p32, p33) -- name: run
		-- upvalues: (copy) v_u_50
		if p33 ~= v_u_50.ID then
			return false
		end
		local v_u_34
		if type(p32) == "table" then
			local v35 = p32.item
			if type(v35) == "table" and v_u_50.isCase(p32.item.id) then
				v_u_34 = p32.item.id
			else
				v_u_34 = nil
			end
		else
			v_u_34 = nil
		end
		if v_u_34 then
			pcall(function()
				-- upvalues: (copy) p_u_31, (copy) v_u_34
				p_u_31.controllers.Menu.openCrates(v_u_34)
			end)
		end
		return true
	end,
	["inspect"] = function(p_u_36, p37, p_u_38, p39, p_u_40) -- name: inspect
		-- upvalues: (copy) v_u_50
		if type(p37) ~= "table" or (type(p_u_38) ~= "table" or p39 == nil) then
			return nil
		end
		local v41 = v_u_50.entry
		local v42 = p_u_38.id
		local v43 = p37.mode ~= "raid"
		local v44, v45 = pcall(function()
			-- upvalues: (copy) p_u_36
			return p_u_36.controllers.Menu.cratesListed()
		end)
		if v44 then
			v44 = v45 == true
		end
		if not v41(v42, v43, v44) then
			return nil
		end
		local v46 = require(script.Parent:WaitForChild("HushUI"))
		local v47 = p39:FindFirstChild("Stats")
		if v47 then
			v47.Size = UDim2.new(1, 0, 1, -200)
		end
		return v46.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "primary",
			["height"] = 44,
			["width"] = 220,
			["name"] = "OpenCase",
			["zindex"] = 66,
			["anchor"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = p39,
			["text"] = v_u_50.TEXT.inspect,
			["anchor"] = Vector2.new(0, 1),
			["position"] = UDim2.new(0, 0, 1, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_40, (ref) v_u_50, (copy) p_u_36, (copy) p_u_38
				if p_u_40 then
					local v48 = p_u_40
					pcall(v48)
				end
				local v49 = {
					["item"] = p_u_38
				}
				v_u_50.run(p_u_36, v49, v_u_50.ID)
			end
		})
	end
}
return v_u_50