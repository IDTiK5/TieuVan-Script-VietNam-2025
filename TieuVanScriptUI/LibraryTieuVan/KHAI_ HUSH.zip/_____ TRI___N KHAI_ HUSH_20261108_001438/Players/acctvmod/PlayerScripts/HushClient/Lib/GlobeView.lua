-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GlobeView

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("TextService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_8 = require(v_u_7:WaitForChild("Theme"))
local v_u_9 = require(v_u_7:WaitForChild("GlobeMath"))
local v_u_10 = require(v_u_7:WaitForChild("GlobePins"))
local v_u_11 = require(v_u_7:WaitForChild("GlobeText"))
local v_u_12 = require(script.Parent:WaitForChild("HushUI"))
local v_u_13 = v1.LocalPlayer
local v_u_14 = v_u_9.CONST
local v_u_15 = v_u_8.color
local v_u_16 = math.min
local v_u_17 = math.max
local v_u_18 = math.floor
local v_u_19 = math.sqrt
local v_u_20 = math.abs
local v_u_21 = math.exp
local v_u_22 = math.log
local v_u_23 = math.sin
local v_u_24 = math.cos
local v_u_25 = math.atan2
local v_u_26 = {
	["TUNING"] = {
		["PIN_SHAPE"] = "diamond",
		["MIN_STEP_MS"] = {
			["high"] = 0,
			["mid"] = 0,
			["low"] = 25,
			["mini"] = 0
		},
		["REST_S"] = 0.25,
		["COORD_HZ"] = v_u_14.COORD_HZ,
		["CARD_W"] = 236,
		["LIST_W"] = 300,
		["LIST_W_PHONE"] = 288,
		["LIST_MAX_ROWS"] = 5,
		["SHAKE_PX"] = 4,
		["SHAKE_S"] = 0.18,
		["REVEAL_S"] = 0.4,
		["BREATH_S"] = 1.6,
		["HALO"] = {
			["high"] = 0,
			["mid"] = 0,
			["low"] = 0,
			["mini"] = 0
		},
		["VIGNETTE_RINGS"] = {
			["high"] = 0,
			["mid"] = 0,
			["low"] = 0,
			["mini"] = 0
		},
		["VIGNETTE_PX"] = 6,
		["VIGNETTE_MODE"] = "rings",
		["PLATE_ALPHA"] = 0.12,
		["AREA_ALPHA"] = 0.05,
		["HINT_MAX_PX"] = 320,
		["HINT_MIN_H"] = 28,
		["HINT_MAX_H"] = 46,
		["DRIFT_DEG_S"] = 0.8,
		["DRIFT_MAX_S"] = 6,
		["DRIFT_FADE_S"] = 1.5,
		["DRIFT_FRAME_MAX_S"] = 0.025,
		["CROSS_FADE"] = { 5, 6.5 },
		["CROSS_MAX"] = 36,
		["CROSS_MAX_PHONE"] = 16,
		["TICK_MAX"] = 24,
		["TICK_MAX_PHONE"] = 12,
		["TICK_ON"] = true,
		["GUARD_ERRORS"] = 3,
		["GUARD_WINDOW_S"] = 10,
		["POOL_SETS"] = 16,
		["POOL_GUIDES"] = 8,
		["POOL_PLAQUES"] = 12,
		["HINT_REDUCED_S"] = 8,
		["TERM_END"] = 0.75,
		["HOVER_S"] = 0.16,
		["HOVER_PX"] = { 16, 26 },
		["INTRO_S_TOUCH"] = 1.8,
		["INTRO_PEAK_MAX"] = 1.6,
		["LOCK_PX"] = 8,
		["AREA_ZOOM_MIN_OTHER"] = 2.5
	}
}
local v_u_27 = v_u_26.TUNING
local v_u_28 = {}
v_u_26.Motion = v_u_28
function v_u_28.reduced() -- name: reduced
	-- upvalues: (copy) v_u_5, (copy) v_u_13, (copy) v_u_2
	local function v29()
		-- upvalues: (ref) v_u_5
		return v_u_5.ReducedMotionEnabled
	end
	local v30, v31 = pcall(v29)
	return v30 and v31 == true and true or (v_u_13 and (v_u_13:GetAttribute("ReduceMotion") == true or v_u_13:GetAttribute("GlobeReduceMotion") == true) and true or (v_u_2:IsStudio() and workspace:GetAttribute("GlobeReduceMotion") == true and true or false))
end
function v_u_28.probe() -- name: probe
	-- upvalues: (copy) v_u_5
	local function v32()
		-- upvalues: (ref) v_u_5
		return v_u_5.ReducedMotionEnabled
	end
	return pcall(v32)
end
local function v_u_47(p33, p34, p35, p36) -- name: circle
	local v37 = {
		["Name"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Name"] = p34,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p35, p35)
	}
	local v38 = Instance.new("Frame")
	for v39, v40 in v37 do
		v38[v39] = v40
	end
	if p33 then
		v38.Parent = p33
	end
	local v41 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v42 = Instance.new("UICorner")
	for v43, v44 in v41 do
		v42[v43] = v44
	end
	if v38 then
		v42.Parent = v38
	end
	if p36 then
		for v45, v46 in p36 do
			v38[v45] = v46
		end
	end
	return v38
end
local function v_u_54(p48, p49) -- name: btn
	local v50 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Name"] = p49,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5)
	}
	local v51 = Instance.new("TextButton")
	for v52, v53 in v50 do
		v51[v52] = v53
	end
	if p48 then
		v51.Parent = p48
	end
	return v51
end
local v_u_55 = {}
local v_u_56 = {}
local function v_u_71(p_u_57, p_u_58, p_u_59, p_u_60) -- name: textH
	-- upvalues: (copy) v_u_56, (copy) v_u_4, (copy) v_u_18
	local v61 = tostring(p_u_59)
	local v62 = tostring(p_u_60)
	local v63 = p_u_58.Family
	local v64 = p_u_57 .. "|" .. v61 .. "|" .. v62 .. "|" .. tostring(v63)
	local v65 = v_u_56[v64]
	if v65 then
		return v65
	end
	local function v67()
		-- upvalues: (copy) p_u_57, (copy) p_u_58, (copy) p_u_59, (copy) p_u_60, (ref) v_u_4
		local v66 = Instance.new("GetTextBoundsParams")
		v66.Text = p_u_57
		v66.Font = p_u_58
		v66.Size = p_u_59
		v66.Width = p_u_60
		return v_u_4:GetTextBoundsAsync(v66)
	end
	local v68, v69 = pcall(v67)
	if not v68 then
		v69 = nil
	end
	local v70
	if v69 then
		v70 = v69.Y
	else
		v70 = p_u_59 * 1.2 * (v_u_18(#p_u_57 * p_u_59 * 0.6 / p_u_60) + 1)
	end
	v_u_56[v64] = v70
	return v70
end
function v_u_26._textW(p_u_72, p_u_73, p_u_74) -- name: textW
	-- upvalues: (copy) v_u_55, (copy) v_u_4
	local v75 = tostring(p_u_74)
	local v76 = p_u_73.Family
	local v77 = p_u_72 .. "|" .. v75 .. "|" .. tostring(v76)
	local v78 = v_u_55[v77]
	if v78 then
		return v78
	end
	local v_u_79 = 100000
	local function v81()
		-- upvalues: (copy) p_u_72, (copy) p_u_73, (copy) p_u_74, (copy) v_u_79, (ref) v_u_4
		local v80 = Instance.new("GetTextBoundsParams")
		v80.Text = p_u_72
		v80.Font = p_u_73
		v80.Size = p_u_74
		v80.Width = v_u_79
		return v_u_4:GetTextBoundsAsync(v80)
	end
	local v82, v83 = pcall(v81)
	if not v82 then
		v83 = nil
	end
	local v84
	if v83 then
		v84 = v83.X
	else
		v84 = #p_u_72 * p_u_74 * 0.6
	end
	v_u_55[v77] = v84
	return v84
end
v_u_26._textH = v_u_71
local function v_u_93(p85, p86, p87, p88, p89) -- name: lineFrame
	-- upvalues: (copy) v_u_19, (copy) v_u_25
	local v90 = p88 - p86
	local v91 = p89 - p87
	local v92 = v_u_19(v90 * v90 + v91 * v91)
	p85.AnchorPoint = Vector2.new(0.5, 0.5)
	p85.Position = UDim2.fromOffset((p86 + p88) / 2, (p87 + p89) / 2)
	p85.Size = UDim2.fromOffset(v92, 1)
	p85.Rotation = v_u_25(v91, v90) / 0.017453292519943295
end
local function v_u_98(p94) -- name: chipText
	-- upvalues: (copy) v_u_11
	local v95 = p94.chip
	if type(v95) == "string" and p94.chip ~= "" then
		return p94.chip
	elseif p94.deploy then
		return v_u_11.CHIPS.selected
	else
		local v96
		if p94.hidden then
			v96 = "hidden"
		else
			local v97 = p94.state
			v96 = v97 == "test" and "test" or ((v97 == "raids" or (v97 == "locked" or v97 == "quest")) and "locked" or (v97 == "soon" and "soon" or "open"))
		end
		if v96 == "test" then
			return v_u_11.CHIPS.testAccess
		elseif v96 == "locked" then
			return v_u_11.CHIPS.locked
		elseif v96 == "soon" then
			return v_u_11.CHIPS.comingSoon
		else
			return v_u_11.CHIPS.open
		end
	end
end
v_u_26.pv = {
	["stateKind"] = function(p99) -- name: stateKind
		if p99.hidden then
			return "hidden"
		end
		local v100 = p99.state
		return v100 == "test" and "test" or ((v100 == "raids" or (v100 == "locked" or v100 == "quest")) and "locked" or (v100 == "soon" and "soon" or "open"))
	end,
	["chipText"] = v_u_98,
	["chipColor"] = function(p101) -- name: chipColor
		-- upvalues: (copy) v_u_15
		if p101.deploy then
			return v_u_15.accent
		else
			local v102
			if p101.hidden then
				v102 = "hidden"
			else
				local v103 = p101.state
				v102 = v103 == "test" and "test" or ((v103 == "raids" or (v103 == "locked" or v103 == "quest")) and "locked" or (v103 == "soon" and "soon" or "open"))
			end
			if v102 == "test" then
				return v_u_15.info
			elseif v102 == "open" then
				return v_u_15.text
			else
				return v_u_15.text2
			end
		end
	end,
	["displayName"] = function(p104) -- name: displayName
		-- upvalues: (copy) v_u_11
		if p104.hidden then
			return v_u_11.UNKNOWN
		end
		local v105 = p104.name or p104.id
		return tostring(v105)
	end
}
local v_u_106 = false
local v_u_107 = false
function v_u_26.resetSession() -- name: resetSession
	-- upvalues: (ref) v_u_106, (ref) v_u_107
	v_u_106 = false
	v_u_107 = false
end
function v_u_26.new(p108, p109) -- name: new
	-- upvalues: (copy) v_u_28, (copy) v_u_10, (copy) v_u_8, (copy) v_u_14, (copy) v_u_27, (copy) v_u_47, (copy) v_u_15, (copy) v_u_17, (copy) v_u_12, (copy) v_u_11, (copy) v_u_18, (copy) v_u_23, (copy) v_u_24, (copy) v_u_55, (copy) v_u_4, (copy) v_u_2, (copy) v_u_54, (copy) v_u_3, (copy) v_u_71, (copy) v_u_16, (copy) v_u_98, (copy) v_u_93, (copy) v_u_19, (ref) v_u_107, (copy) v_u_6, (copy) v_u_9, (copy) v_u_20, (copy) v_u_22, (copy) v_u_21, (ref) v_u_106
	local v_u_110 = p109 or {}
	local v_u_111 = v_u_110.kind or "pc"
	local v_u_112 = v_u_110.tier or (v_u_111 == "phone" and "low" or (v_u_111 == "tablet" and "mid" or "high"))
	local v_u_113 = v_u_110.D or 772
	local v_u_114 = v_u_110.reduced or v_u_28.reduced
	local v_u_115 = v_u_110.clock or os.clock
	local v_u_116 = {}
	local v_u_117 = {}
	local v118 = 0
	local v_u_119 = 0
	local v_u_120 = 0
	local v_u_121 = true
	local v_u_122 = v_u_10.geometry(v_u_111, v_u_113, v_u_8.touch(40))
	local v_u_123 = {
		["lat0"] = 20,
		["lon0"] = -85,
		["z"] = nil,
		["z"] = v_u_14.Z_MIN
	}
	local v124 = v_u_110.state
	if type(v124) == "table" then
		local v125 = v_u_110.state.lat0
		v_u_123 = type(v125) == "number" and {
			["lat0"] = v_u_110.state.lat0,
			["lon0"] = v_u_110.state.lon0,
			["z"] = v_u_110.state.z or v_u_14.Z_MIN
		} or v_u_123
	end
	v_u_116.view = v_u_123
	local v126 = {
		["Name"] = "GlobeStage",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = v_u_110.position or UDim2.fromOffset(0, 0),
		["Size"] = UDim2.fromOffset(v_u_113, v_u_113)
	}
	local v_u_127 = Instance.new("Frame")
	local v_u_128 = v118
	for v129, v130 in v126 do
		v_u_127[v129] = v130
	end
	if p108 then
		v_u_127.Parent = p108
	end
	local v131 = {
		["Name"] = "Lens",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_132 = Instance.new("Frame")
	for v133, v134 in v131 do
		v_u_132[v133] = v134
	end
	if v_u_127 then
		v_u_132.Parent = v_u_127
	end
	v_u_116.root = v_u_127
	v_u_116.lens = v_u_132
	local v135 = {
		["Name"] = "Halo",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v136 = Instance.new("Frame")
	for v137, v138 in v135 do
		v136[v137] = v138
	end
	if v_u_132 then
		v136.Parent = v_u_132
	end
	local v139 = v_u_27.HALO[v_u_112] or 0
	local v_u_140 = {}
	for v141 = 1, v139 do
		local v142 = v_u_47(v136, "H" .. v141, v_u_113)
		local v143 = v_u_15.info
		local v144 = 0.9 + (v141 - 1) * 0.08499999999999996 / v_u_17(1, v139 - 1)
		v_u_12.stroke(v142, v143, 3, v144 or 0)
		v_u_140[v141] = v142
	end
	local v_u_145 = v_u_47(v_u_132, "Body", v_u_113, {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_15.bgDeep:Lerp(v_u_15.info, 0.05)
	})
	local v146 = {
		["Rotation"] = 135,
		["Color"] = nil,
		["Color"] = ColorSequence.new(v_u_15.bgDeep:Lerp(v_u_15.info, 0.05), v_u_15.bgDeep)
	}
	local v147 = Instance.new("UIGradient")
	for v148, v149 in v146 do
		v147[v148] = v149
	end
	if v_u_145 then
		v147.Parent = v_u_145
	end
	local v150 = v_u_15.lineStrong
	local v151 = v_u_12.stroke(v_u_145, v150, 1.5, 0)
	local v152 = {
		["Rotation"] = 135,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.85) })
	}
	local v153 = Instance.new("UIGradient")
	for v154, v155 in v152 do
		v153[v154] = v155
	end
	if v151 then
		v153.Parent = v151
	end
	local v156 = {
		["Name"] = "Dots",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_157 = Instance.new("Frame")
	for v158, v159 in v156 do
		v_u_157[v158] = v159
	end
	if v_u_132 then
		v_u_157.Parent = v_u_132
	end
	v_u_157:SetAttribute("HushNoFade", true)
	local function v160()
		-- upvalues: (ref) v_u_12, (copy) v_u_157
		if v_u_12.noFade then
			v_u_12.noFade[v_u_157] = true
		end
	end
	pcall(v160)
	v_u_116.dotsLayer = v_u_157
	local v_u_161 = v_u_47(v_u_132, "Terminator", v_u_113, {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_15.bgDeep
	})
	local v162 = {
		["Rotation"] = 135,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, v_u_27.TERM_END) })
	}
	local v163 = Instance.new("UIGradient")
	for v164, v165 in v162 do
		v163[v164] = v165
	end
	if v_u_161 then
		v163.Parent = v_u_161
	end
	local v166 = {
		["Name"] = "Vignette",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v167 = Instance.new("Frame")
	for v168, v169 in v166 do
		v167[v168] = v169
	end
	if v_u_132 then
		v167.Parent = v_u_132
	end
	local v_u_170 = {}
	local v171 = v_u_27.VIGNETTE_RINGS[v_u_112] or 0
	if v171 > 0 and v_u_27.VIGNETTE_MODE == "single" then
		local v172 = v_u_47(v167, "V1", v_u_113)
		local v173 = v_u_15.bgDeep
		local v174 = v_u_27.VIGNETTE_PX * v171
		local v175 = v_u_12.stroke(v172, v173, v174, 0.6)
		local v176 = {
			["Rotation"] = 135,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.9), NumberSequenceKeypoint.new(1, 0.45) })
		}
		local v177 = Instance.new("UIGradient")
		for v178, v179 in v176 do
			v177[v178] = v179
		end
		if v175 then
			v177.Parent = v175
		end
		v_u_170[1] = v172
	elseif v171 > 0 then
		for v180 = 1, v171 do
			local v181 = v_u_47(v167, "V" .. v180, v_u_113)
			local v182 = v_u_15.bgDeep
			local v183 = v_u_27.VIGNETTE_PX
			local v184 = (v180 - 1) * 0.45 / v_u_17(1, v171 - 1) + 0.45
			v_u_12.stroke(v181, v182, v183, v184 or 0)
			v_u_170[v180] = v181
		end
	end
	local v185 = {
		["Name"] = "Rim",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v186 = Instance.new("Frame")
	for v187, v188 in v185 do
		v186[v187] = v188
	end
	if v_u_132 then
		v186.Parent = v_u_132
	end
	local v_u_189 = v_u_47(v186, "Ring", v_u_113)
	local v190 = v_u_15.lineStrong
	v_u_12.stroke(v_u_189, v190, 2, 0)
	local v_u_191 = {}
	if v_u_112 ~= "mini" then
		for v192 = 0, 35 do
			local v193 = v192 + 1
			local v194 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Name"] = "T" .. v192,
				["BackgroundColor3"] = v_u_15.line,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(1, 6)
			}
			local v195 = Instance.new("Frame")
			for v196, v197 in v194 do
				v195[v196] = v197
			end
			if v186 then
				v195.Parent = v186
			end
			v_u_191[v193] = v195
		end
	end
	local v198 = {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v199 = Instance.new("Frame")
	local v_u_200 = {
		["layer"] = nil,
		["pool"] = nil,
		["shown"] = 0,
		["tpool"] = nil,
		["tshown"] = 0
	}
	for v201, v202 in v198 do
		v199[v201] = v202
	end
	if v_u_132 then
		v199.Parent = v_u_132
	end
	v_u_200.layer = v199
	v_u_200.pool = {}
	v_u_200.tpool = {}
	local v203 = {
		["Name"] = "Areas",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_204 = Instance.new("Frame")
	for v205, v206 in v203 do
		v_u_204[v205] = v206
	end
	if v_u_132 then
		v_u_204.Parent = v_u_132
	end
	local v_u_207 = v_u_47(v_u_132, "GlobeFocus", v_u_113, {
		["ZIndex"] = 8,
		["Active"] = false,
		["Selectable"] = false
	})
	v_u_207:SetAttribute("PadDefault", true)
	local v208 = {
		["Name"] = "GlobeSelection",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v209 = Instance.new("Frame")
	for v210, v211 in v208 do
		v209[v210] = v211
	end
	local v212 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v213 = Instance.new("UICorner")
	for v214, v215 in v212 do
		v213[v214] = v215
	end
	if v209 then
		v213.Parent = v209
	end
	local v216 = v_u_15.accent
	v_u_12.stroke(v209, v216, 2, 0)
	v_u_207.SelectionImageObject = v209
	v_u_116.selectionTemplate = v209
	v_u_116.focus = v_u_207
	local v217 = {
		["Name"] = "Pins",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v218 = Instance.new("Frame")
	for v219, v220 in v217 do
		v218[v219] = v220
	end
	if v_u_132 then
		v218.Parent = v_u_132
	end
	local v221 = {
		["Name"] = "Guides",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_222 = Instance.new("Frame")
	for v223, v224 in v221 do
		v_u_222[v223] = v224
	end
	if v218 then
		v_u_222.Parent = v218
	end
	local v225 = {
		["Name"] = "Fuzz",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_226 = Instance.new("Frame")
	for v227, v228 in v225 do
		v_u_226[v227] = v228
	end
	if v218 then
		v_u_226.Parent = v218
	end
	local v229 = {
		["Name"] = "Sets",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_230 = Instance.new("Frame")
	for v231, v232 in v229 do
		v_u_230[v231] = v232
	end
	if v218 then
		v_u_230.Parent = v218
	end
	local v233 = {
		["Name"] = "Plaques",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_234 = Instance.new("Frame")
	for v235, v236 in v233 do
		v_u_234[v235] = v236
	end
	if v218 then
		v_u_234.Parent = v218
	end
	local v237 = {
		["Name"] = "Cards",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_238 = Instance.new("Frame")
	for v239, v240 in v237 do
		v_u_238[v239] = v240
	end
	if v218 then
		v_u_238.Parent = v218
	end
	local v241 = {
		["Name"] = "Chrome",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 10,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_242 = Instance.new("Frame")
	for v243, v244 in v241 do
		v_u_242[v243] = v244
	end
	if v_u_132 then
		v_u_242.Parent = v_u_132
	end
	local v245 = {
		["Name"] = "Cross",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v246 = Instance.new("Frame")
	for v247, v248 in v245 do
		v246[v247] = v248
	end
	if v_u_242 then
		v246.Parent = v_u_242
	end
	local function v262(p249, p250, p251) -- name: plate
		-- upvalues: (ref) v_u_15, (ref) v_u_27, (copy) v_u_242, (ref) v_u_12
		local v252 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Name"] = p249,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["BackgroundTransparency"] = v_u_27.PLATE_ALPHA,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 28),
			["ZIndex"] = p250 or 1
		}
		local v253 = v_u_242
		local v254 = Instance.new("Frame")
		for v255, v256 in v252 do
			v254[v255] = v256
		end
		if v253 then
			v254.Parent = v253
		end
		local v257 = v_u_15.line
		v_u_12.stroke(v254, v257, 1, 0)
		local v258 = {
			["PaddingLeft"] = UDim.new(0, p251 or 6),
			["PaddingRight"] = UDim.new(0, p251 or 6)
		}
		local v259 = Instance.new("UIPadding")
		for v260, v261 in v258 do
			v259[v260] = v261
		end
		if v254 then
			v259.Parent = v254
		end
		return v254
	end
	local v_u_263 = {}
	for v264 = 1, 4 do
		local v265 = (v264 == 2 and true or v264 == 4) and 1 or 0
		local v266 = (v264 == 3 and true or v264 == 4) and 1 or 0
		for v267 = 1, 2 do
			local v268 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Name"] = "B" .. v264 .. v267,
				["BackgroundColor3"] = v_u_15.lineStrong,
				["AnchorPoint"] = Vector2.new(v265, v266)
			}
			local v269
			if v267 == 1 then
				v269 = UDim2.fromOffset(14, 1)
			else
				v269 = UDim2.fromOffset(1, 14)
			end
			v268.Size = v269
			local v270 = Instance.new("Frame")
			for v271, v272 in v268 do
				v270[v271] = v272
			end
			if v_u_242 then
				v270.Parent = v_u_242
			end
			v_u_263[#v_u_263 + 1] = {
				["f"] = v270,
				["ax"] = v265,
				["ay"] = v266
			}
		end
	end
	local v_u_273 = v262("TitlePlate")
	local v274 = v_u_11.TITLE
	local v275 = {
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["color"] = v_u_15.text2,
		["size"] = UDim2.fromOffset(0, 28)
	}
	local v276 = {
		["parent"] = nil,
		["text"] = nil,
		["style"] = "caps",
		["track"] = true,
		["parent"] = v_u_273,
		["text"] = v274
	}
	if v275 then
		for v277, v278 in v275 do
			v276[v277] = v278
		end
	end
	v_u_12.label(v276)
	local v_u_279 = v262("CoordPlate")
	local v280 = {
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["color"] = v_u_15.text2,
		["size"] = UDim2.fromOffset(0, 28)
	}
	local v281 = {
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["track"] = false,
		["parent"] = v_u_279
	}
	if v280 then
		for v282, v283 in v280 do
			v281[v282] = v283
		end
	end
	local v_u_284 = v_u_12.label(v281)
	local v_u_285 = v262("ScalePlate")
	local v286 = {
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["color"] = v_u_15.text2,
		["size"] = UDim2.fromOffset(0, 28)
	}
	local v287 = {
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["track"] = false,
		["parent"] = v_u_285
	}
	if v286 then
		for v288, v289 in v286 do
			v287[v288] = v289
		end
	end
	local v_u_290 = v_u_12.label(v287)
	local v291 = {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["BackgroundColor3"] = v_u_15.text2,
		["Size"] = UDim2.fromOffset(60, 1),
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}
	local v_u_292 = Instance.new("Frame")
	for v293, v294 in v291 do
		v_u_292[v293] = v294
	end
	if v_u_285 then
		v_u_292.Parent = v_u_285
	end
	local v295 = {
		["Name"] = "TickA",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["BackgroundColor3"] = v_u_15.text2,
		["Size"] = UDim2.fromOffset(1, 7),
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}
	local v_u_296 = Instance.new("Frame")
	for v297, v298 in v295 do
		v_u_296[v297] = v298
	end
	if v_u_285 then
		v_u_296.Parent = v_u_285
	end
	local v299 = {
		["Name"] = "TickB",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["BackgroundColor3"] = v_u_15.text2,
		["Size"] = UDim2.fromOffset(1, 7),
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}
	local v_u_300 = Instance.new("Frame")
	for v301, v302 in v299 do
		v_u_300[v301] = v302
	end
	if v_u_285 then
		v_u_300.Parent = v_u_285
	end
	local v_u_303 = v262("HintPlate", nil, 3)
	v_u_303.AutomaticSize = Enum.AutomaticSize.XY
	v_u_303.Size = UDim2.fromOffset(0, 0)
	local v304 = v_u_303:FindFirstChildOfClass("UIPadding")
	if v304 then
		local v305 = UDim.new(0, 5)
		local v306 = UDim.new(0, 5)
		v304.PaddingTop = v305
		v304.PaddingBottom = v306
	end
	local v307 = {
		["MinSize"] = Vector2.new(0, v_u_27.HINT_MIN_H),
		["MaxSize"] = Vector2.new(v_u_27.HINT_MAX_PX, v_u_27.HINT_MAX_H)
	}
	local v308 = Instance.new("UISizeConstraint")
	for v309, v310 in v307 do
		v308[v309] = v310
	end
	if v_u_303 then
		v308.Parent = v_u_303
	end
	local function v_u_311() end
	local v312 = {
		["color"] = nil,
		["wrap"] = true,
		["autoX"] = true,
		["autoY"] = true,
		["fitWrap"] = false,
		["align"] = "center",
		["color"] = v_u_15.text2
	}
	local v313 = {
		["parent"] = nil,
		["text"] = "",
		["style"] = "small",
		["track"] = false,
		["parent"] = v_u_303
	}
	if v312 then
		for v314, v315 in v312 do
			v313[v314] = v315
		end
	end
	local v_u_316 = v_u_12.label(v313)
	v_u_316.TextTruncate = Enum.TextTruncate.None
	local v317 = {
		["Name"] = "HintLimit",
		["MaxSize"] = nil
	}
	local v318 = Vector2.new
	local v319 = v_u_27.HINT_MAX_PX - 6
	local v320 = v_u_316.TextSize * 1.25
	v317.MaxSize = v318(v319, math.ceil(v320) * 2 + 2)
	local v321 = Instance.new("UISizeConstraint")
	for v322, v323 in v317 do
		v321[v322] = v323
	end
	if v_u_316 then
		v321.Parent = v_u_316
	end
	local v_u_324 = v_u_47(v246, "Crosshair", 28, {
		["Visible"] = false
	})
	local v325 = v_u_15.text
	v_u_12.stroke(v_u_324, v325, 1, 0.2)
	local v326 = {
		["Name"] = "TouchCross",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(12, 12)
	}
	local v_u_327 = Instance.new("Frame")
	for v328, v329 in v326 do
		v_u_327[v328] = v329
	end
	if v246 then
		v_u_327.Parent = v246
	end
	local v330 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_15.text2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(12, 1)
	}
	local v331 = Instance.new("Frame")
	for v332, v333 in v330 do
		v331[v332] = v333
	end
	if v_u_327 then
		v331.Parent = v_u_327
	end
	local v334 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_15.text2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(1, 12)
	}
	local v335 = Instance.new("Frame")
	for v336, v337 in v334 do
		v335[v336] = v337
	end
	if v_u_327 then
		v335.Parent = v_u_327
	end
	local v_u_338 = {}
	v_u_116.buttons = v_u_338
	local v_u_339 = v_u_8.touch(40)
	local v_u_340 = {}
	local function v362(p341, p342, p343, p_u_344) -- name: chromeButton
		-- upvalues: (ref) v_u_15, (ref) v_u_27, (ref) v_u_339, (copy) v_u_242, (ref) v_u_12, (copy) v_u_340
		local v345 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["ZIndex"] = 3,
			["Name"] = p341,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["BackgroundTransparency"] = v_u_27.PLATE_ALPHA,
			["Size"] = UDim2.fromOffset(v_u_339, v_u_339),
			["AnchorPoint"] = Vector2.new(0, 0)
		}
		local v346 = v_u_242
		local v347 = Instance.new("TextButton")
		for v348, v349 in v345 do
			v347[v348] = v349
		end
		if v346 then
			v347.Parent = v346
		end
		local v350 = v_u_15.line
		local v_u_351 = v_u_12.stroke(v347, v350, 1, 0)
		local v352
		if p342 then
			local v353 = v_u_12.icon
			local v354 = {}
			local v355 = v_u_339 * 0.45
			v354.size = math.floor(v355)
			v354.color = v_u_15.text
			v354.position = UDim2.fromScale(0.5, 0.5)
			v354.anchor = Vector2.new(0.5, 0.5)
			v352 = v353(p342, v354)
			v352.Parent = v347
		else
			local v356 = {
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["fit"] = true,
				["color"] = v_u_15.text,
				["size"] = UDim2.fromScale(1, 1)
			}
			local v357 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["track"] = true,
				["parent"] = v347,
				["text"] = p343 or ""
			}
			if v356 then
				for v358, v359 in v356 do
					v357[v358] = v359
				end
			end
			v352 = v_u_12.label(v357)
		end
		v_u_340[v347] = v352
		v347.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_351, (ref) v_u_15
			v_u_351.Color = v_u_15.accent
		end)
		v347.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_351, (ref) v_u_15
			v_u_351.Color = v_u_15.line
		end)
		local v360 = v_u_12.tooltip
		pcall(v360, v347, function()
			-- upvalues: (copy) p_u_344
			local v361 = p_u_344
			if type(v361) == "function" then
				return p_u_344()
			else
				return p_u_344
			end
		end)
		return v347
	end
	v_u_338.zoomIn = v362("ZoomIn", "plus", nil, v_u_11.TOOLTIPS.zoomIn)
	v_u_338.zoomOut = v362("ZoomOut", "minus", nil, v_u_11.TOOLTIPS.zoomOut)
	v_u_338.home = v362("Home", "map", nil, function()
		-- upvalues: (copy) v_u_116
		return v_u_116.homeTip()
	end)
	v_u_338.list = v362("List", nil, v_u_11.LIST, v_u_11.TOOLTIPS.list)
	local v_u_363 = {}
	local v364 = v_u_338.home:FindFirstChild("Icon_map")
	if v364 then
		v364:Destroy()
	end
	local function v371(p365) -- name: holder
		-- upvalues: (copy) v_u_338
		local v366 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Visible"] = false,
			["Name"] = "Icon_" .. p365,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5)
		}
		local v367 = v_u_338.home
		local v368 = Instance.new("Frame")
		for v369, v370 in v366 do
			v368[v369] = v370
		end
		if v367 then
			v368.Parent = v367
		end
		v368:SetAttribute("HushIcon", p365)
		return v368
	end
	local v372 = v371("pin")
	local v373 = v_u_47(v372, "Ring", 100, {
		["Size"] = UDim2.fromScale(1, 1)
	})
	local v374 = v_u_15.text
	v_u_12.stroke(v373, v374, 1.5, 0)
	local v375 = {
		["Name"] = "Diamond",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = v_u_15.text,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.36, 0.36)
	}
	local v376 = Instance.new("Frame")
	local v_u_377 = v_u_339
	for v378, v379 in v375 do
		v376[v378] = v379
	end
	if v372 then
		v376.Parent = v372
	end
	local v380 = v371("globe")
	local v381 = v_u_47(v380, "Ring", 100, {
		["Size"] = UDim2.fromScale(1, 1)
	})
	local v382 = v_u_15.text
	v_u_12.stroke(v381, v382, 1.5, 0)
	local v383 = v_u_47(v380, "Meridian", 100, {
		["Size"] = UDim2.fromScale(0.45, 1)
	})
	local v384 = v_u_15.text
	v_u_12.stroke(v383, v384, 1, 0)
	local v385 = {
		["Name"] = "Equator",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_15.text,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v386 = Instance.new("Frame")
	for v387, v388 in v385 do
		v386[v387] = v388
	end
	if v380 then
		v386.Parent = v380
	end
	v_u_363.pin = v372
	v_u_363.globe = v380
	v_u_363.shown = ""
	v_u_340[v_u_338.home] = v372
	local v_u_389 = {}
	function v_u_116.sizeButtons() -- name: sizeButtons
		-- upvalues: (ref) v_u_377, (ref) v_u_8, (ref) v_u_18, (copy) v_u_338, (copy) v_u_340, (copy) v_u_363
		v_u_377 = v_u_8.touch(40)
		local v390 = v_u_18(v_u_377 * 0.45)
		for _, v391 in {
			v_u_338.zoomIn,
			v_u_338.zoomOut,
			v_u_338.home,
			v_u_338.list
		} do
			v391.Size = UDim2.fromOffset(v_u_377, v_u_377)
		end
		for _, v392 in { v_u_338.zoomIn, v_u_338.zoomOut } do
			local v393 = v_u_340[v392]
			if not v393 then
				continue
			end
			v393.Size = UDim2.fromOffset(v390, v390)
		end
		v_u_363.pin.Size = UDim2.fromOffset(v390, v390)
		v_u_363.globe.Size = UDim2.fromOffset(v390, v390)
	end
	local function v_u_415() -- name: layoutStatic
		-- upvalues: (copy) v_u_116, (copy) v_u_127, (ref) v_u_113, (ref) v_u_128, (copy) v_u_140, (copy) v_u_170, (ref) v_u_27, (ref) v_u_17, (copy) v_u_189, (copy) v_u_191, (ref) v_u_23, (ref) v_u_24, (copy) v_u_207, (copy) v_u_263, (copy) v_u_273, (copy) v_u_279, (copy) v_u_285, (ref) v_u_311, (ref) v_u_377, (copy) v_u_338, (ref) v_u_389, (ref) v_u_122, (ref) v_u_10, (ref) v_u_111, (ref) v_u_8
		v_u_116.sizeButtons()
		local v394 = v_u_127
		local v395 = UDim2.fromOffset(v_u_113, v_u_113)
		if v394.Size ~= v395 then
			v394.Size = v395
			v_u_128 = v_u_128 + 1
		end
		for v396, v397 in v_u_140 do
			local v398 = UDim2.fromOffset(v_u_113 + 6 * v396, v_u_113 + 6 * v396)
			if v397.Size == v398 then
				continue
			end
			v397.Size = v398
			v_u_128 = v_u_128 + 1
		end
		for v399, v400 in v_u_170 do
			local v401 = v_u_113 - 2 * v_u_27.VIGNETTE_PX * (v399 - 1)
			local v402 = UDim2.fromOffset(v_u_17(v401, 1), (v_u_17(v401, 1)))
			if v400.Size == v402 then
				continue
			end
			v400.Size = v402
			v_u_128 = v_u_128 + 1
		end
		local v403 = v_u_189
		local v404 = UDim2.fromOffset(v_u_113, v_u_113)
		if v403.Size ~= v404 then
			v403.Size = v404
			v_u_128 = v_u_128 + 1
		end
		for v405, v406 in v_u_191 do
			local v407 = (v405 - 1) * 10 * 0.017453292519943295
			local v408 = v_u_113 / 2 + 6
			v406.Position = UDim2.fromOffset(v_u_113 / 2 + v_u_23(v407) * v408, v_u_113 / 2 - v_u_24(v407) * v408)
			v406.Rotation = (v405 - 1) * 10
		end
		local v409 = v_u_207
		local v410 = UDim2.fromOffset(v_u_113, v_u_113)
		if v409.Size ~= v410 then
			v409.Size = v410
			v_u_128 = v_u_128 + 1
		end
		for _, v411 in v_u_263 do
			v411.f.Position = UDim2.fromOffset(v411.ax * v_u_113, v411.ay * v_u_113)
		end
		v_u_273.Position = UDim2.fromOffset(6, 6)
		v_u_279.AnchorPoint = Vector2.new(0, 1)
		v_u_279.Position = UDim2.fromOffset(6, v_u_113 - 6)
		v_u_285.AnchorPoint = Vector2.new(1, 1)
		v_u_285.Position = UDim2.fromOffset(v_u_113 - 6, v_u_113 - 6)
		v_u_311()
		local v412 = v_u_377 + 6 + 3 * v_u_377 + 12 + 6
		local v413 = v_u_17(4, v_u_113 / 2 - v412 / 2)
		local v414 = v_u_113 - v_u_377 * 0.7
		v_u_338.list.Position = UDim2.fromOffset(v414, v413)
		v_u_338.zoomIn.Position = UDim2.fromOffset(v414, v413 + v_u_377 + 12)
		v_u_338.zoomOut.Position = UDim2.fromOffset(v414, v413 + v_u_377 + 12 + v_u_377 + 6)
		v_u_338.home.Position = UDim2.fromOffset(v414, v413 + v_u_377 + 12 + 2 * (v_u_377 + 6))
		v_u_389 = {
			{
				["x"] = v414 - 6,
				["y"] = v413 - 4,
				["w"] = v_u_377 + 12,
				["h"] = v412 + 8
			}
		}
		v_u_122 = v_u_10.geometry(v_u_111, v_u_113, v_u_8.touch(40))
	end
	v_u_415()
	local v_u_416
	if v_u_110.labels == nil then
		v_u_416 = v_u_111 ~= "phone" and true or v_u_11.LABELS_ON_PHONE
	else
		v_u_416 = v_u_110.labels == true
	end
	local v_u_417 = {}
	local v_u_418 = {}
	local function v_u_448() -- name: buildAreas
		-- upvalues: (copy) v_u_416, (copy) v_u_417, (ref) v_u_11, (ref) v_u_15, (ref) v_u_27, (copy) v_u_204, (ref) v_u_12, (ref) v_u_55, (ref) v_u_4
		if v_u_416 and #v_u_417 <= 0 then
			for v419, v420 in v_u_11.LABELS do
				local v421 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Visible"] = false,
					["AutomaticSize"] = nil,
					["Size"] = nil,
					["Name"] = "A" .. v419,
					["BackgroundColor3"] = v_u_15.bgDeep,
					["BackgroundTransparency"] = v_u_27.AREA_ALPHA,
					["AutomaticSize"] = Enum.AutomaticSize.XY,
					["Size"] = UDim2.fromOffset(0, 0)
				}
				local v422 = v_u_204
				local v423 = Instance.new("Frame")
				for v424, v425 in v421 do
					v423[v424] = v425
				end
				if v422 then
					v423.Parent = v422
				end
				local v426 = {
					["PaddingLeft"] = UDim.new(0, 4),
					["PaddingRight"] = UDim.new(0, 4),
					["PaddingTop"] = UDim.new(0, 4),
					["PaddingBottom"] = UDim.new(0, 4)
				}
				local v427 = Instance.new("UIPadding")
				for v428, v429 in v426 do
					v427[v428] = v429
				end
				if v423 then
					v427.Parent = v423
				end
				local v430 = v420.text
				local v431 = {
					["color"] = nil,
					["transparency"] = 0.1,
					["autoX"] = true,
					["autoY"] = true,
					["color"] = v_u_15.text
				}
				local v432 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["track"] = true,
					["parent"] = v423,
					["text"] = v430
				}
				if v431 then
					for v433, v434 in v431 do
						v432[v433] = v434
					end
				end
				local v435 = v_u_12.label(v432)
				v435.AutomaticSize = Enum.AutomaticSize.XY
				v435.Size = UDim2.fromOffset(0, 0)
				v435.TextTruncate = Enum.TextTruncate.None
				local v_u_436 = v435.Text
				local v_u_437 = v435.FontFace
				local v_u_438 = v435.TextSize
				local v439 = tostring(v_u_438)
				local v440 = v_u_437.Family
				local v441 = v_u_436 .. "|" .. v439 .. "|" .. tostring(v440)
				local v442 = v_u_55[v441]
				if not v442 then
					local v_u_443 = 100000
					local function v445()
						-- upvalues: (copy) v_u_436, (copy) v_u_437, (copy) v_u_438, (copy) v_u_443, (ref) v_u_4
						local v444 = Instance.new("GetTextBoundsParams")
						v444.Text = v_u_436
						v444.Font = v_u_437
						v444.Size = v_u_438
						v444.Width = v_u_443
						return v_u_4:GetTextBoundsAsync(v444)
					end
					local v446, v447 = pcall(v445)
					if not v446 then
						v447 = nil
					end
					if v447 then
						v442 = v447.X
					else
						v442 = #v_u_436 * v_u_438 * 0.6
					end
					v_u_55[v441] = v442
				end
				v_u_417[v419] = {
					["def"] = v420,
					["plate"] = v423,
					["lbl"] = v435,
					["w"] = v442 + 8,
					["h"] = v435.TextSize + 8
				}
			end
		end
	end
	local v_u_449 = {}
	local v_u_450 = {}
	local v_u_451 = {}
	local v_u_452 = {}
	local v_u_453 = {}
	local v_u_454 = nil
	local v_u_455 = v_u_10.newState()
	local v_u_456 = {
		["items"] = {},
		["guides"] = {},
		["memberOf"] = {},
		["byKey"] = {}
	}
	local v_u_457 = {}
	local v_u_458 = {}
	local v_u_459 = nil
	local v_u_460 = nil
	local v_u_461 = nil
	local v_u_462 = false
	local v_u_463 = nil
	local v_u_464 = v_u_27.PIN_SHAPE
	local v_u_465 = {}
	local v_u_466 = {
		["shake"] = 0,
		["other"] = 0
	}
	local function v_u_481(p_u_467, p_u_468, p_u_469) -- name: shake
		-- upvalues: (copy) v_u_114, (copy) v_u_465, (ref) v_u_27, (copy) v_u_466, (ref) v_u_2, (ref) v_u_17, (ref) v_u_18, (ref) v_u_24
		if not v_u_114() and p_u_467.Parent then
			local v_u_470 = (v_u_465[p_u_467] or 0) + 1
			v_u_465[p_u_467] = v_u_470
			local v471 = v_u_27.SHAKE_PX
			local v_u_472 = v_u_27.SHAKE_S / 6
			local v_u_473 = {
				0,
				v471,
				-v471,
				v471,
				-v471,
				v471,
				0
			}
			local v_u_474 = os.clock()
			local v_u_475 = nil
			local v476 = v_u_466
			v476.shake = v476.shake + 1
			v_u_475 = v_u_2.Heartbeat:Connect(function()
				-- upvalues: (copy) v_u_474, (ref) v_u_465, (copy) p_u_467, (copy) v_u_470, (ref) v_u_466, (ref) v_u_17, (ref) v_u_475, (copy) v_u_472, (copy) p_u_468, (copy) p_u_469, (ref) v_u_18, (ref) v_u_24, (copy) v_u_473
				local v477 = os.clock() - v_u_474
				if v_u_465[p_u_467] == v_u_470 and p_u_467.Parent then
					local v478 = v477 / v_u_472
					if v478 >= 6 then
						p_u_467.Position = UDim2.fromOffset(p_u_468, p_u_469)
						v_u_466.shake = v_u_17(0, v_u_466.shake - 1)
						if v_u_475 then
							v_u_475:Disconnect()
						end
					else
						local v479 = v_u_18(v478)
						local v480 = (1 - v_u_24((v478 - v479) * 3.141592653589793)) / 2
						p_u_467.Position = UDim2.fromOffset(p_u_468 + v_u_473[v479 + 1] + (v_u_473[v479 + 2] - v_u_473[v479 + 1]) * v480, p_u_469)
					end
				else
					v_u_466.shake = v_u_17(0, v_u_466.shake - 1)
					if v_u_475 then
						v_u_475:Disconnect()
					end
					return
				end
			end)
		end
	end
	local function v_u_527(p482) -- name: makeSet
		-- upvalues: (copy) v_u_230, (ref) v_u_47, (ref) v_u_15, (ref) v_u_12, (ref) v_u_27, (ref) v_u_54, (copy) v_u_110, (copy) v_u_116, (ref) v_u_461
		local v483 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 2,
			["Name"] = "Set" .. p482,
			["Size"] = UDim2.fromOffset(0, 0)
		}
		local v484 = v_u_230
		local v485 = Instance.new("Frame")
		for v486, v487 in v483 do
			v485[v486] = v487
		end
		if v484 then
			v485.Parent = v484
		end
		local v488 = {
			["Name"] = "Body",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Position"] = nil,
			["ZIndex"] = 1,
			["Size"] = UDim2.fromOffset(0, 0),
			["Position"] = UDim2.fromOffset(0, 0)
		}
		local v489 = Instance.new("Frame")
		for v490, v491 in v488 do
			v489[v490] = v491
		end
		if v485 then
			v489.Parent = v485
		end
		local v492 = v_u_47(v489, "Under", 28, {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v_u_15.bgDeep
		})
		local v493 = v_u_15.line
		v_u_12.stroke(v492, v493, 1, 0)
		local v494 = v_u_47(v489, "Ring2", 38, {
			["Visible"] = false,
			["ZIndex"] = 2
		})
		local v495 = v_u_15.accent
		local v496 = v_u_12.stroke(v494, v495, 1.5, 0.6)
		local v497 = v_u_47(v489, "Ring1", 26, {
			["Visible"] = false,
			["ZIndex"] = 2
		})
		local v498 = v_u_15.accent
		local v499 = v_u_12.stroke(v497, v498, 1.5, 0.6)
		local v500 = v_u_47(v489, "InfoRing", 22, {
			["Visible"] = false,
			["ZIndex"] = 2
		})
		local v501 = v_u_15.info
		local v502 = v_u_12.stroke(v500, v501, 1.5, 0)
		local v503 = v_u_47(v489, "ViewRing", 24, {
			["Visible"] = false,
			["ZIndex"] = 2
		})
		local v504 = v_u_15.text
		v_u_12.stroke(v503, v504, 1, 0)
		local v505 = v_u_47(v489, "HoverRing", v_u_27.HOVER_PX[1], {
			["Visible"] = false,
			["ZIndex"] = 2
		})
		local v506 = v_u_15.text
		local v507 = v_u_12.stroke(v505, v506, 1.5, 1)
		local v508 = {
			["Name"] = "Shape",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 3,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(16, 16)
		}
		local v509 = Instance.new("Frame")
		for v510, v511 in v508 do
			v509[v510] = v511
		end
		if v489 then
			v509.Parent = v489
		end
		local v512 = {
			["CornerRadius"] = UDim.new(0, 0)
		}
		local v513 = Instance.new("UICorner")
		for v514, v515 in v512 do
			v513[v514] = v515
		end
		if v509 then
			v513.Parent = v509
		end
		local v516 = v_u_15.text
		local v517 = v_u_12.stroke(v509, v516, 1.5, 0)
		v517.Enabled = false
		local v518 = {
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["valign"] = "center",
			["color"] = v_u_15.text,
			["size"] = UDim2.fromOffset(28, 28)
		}
		local v519 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["track"] = true,
			["parent"] = v489
		}
		if v518 then
			for v520, v521 in v518 do
				v519[v520] = v521
			end
		end
		local v522 = v_u_12.label(v519)
		v522.AnchorPoint = Vector2.new(0.5, 0.5)
		v522.Position = UDim2.fromScale(0.5, 0.5)
		v522.ZIndex = 4
		v522.Visible = false
		local v523 = v_u_12.icon("chevronDown", {
			["size"] = 8,
			["color"] = nil,
			["color"] = v_u_15.text
		})
		v523.AnchorPoint = Vector2.new(0.5, 0)
		v523.Position = UDim2.fromOffset(0, 11)
		v523.Visible = false
		v523.Parent = v489
		local v524 = v_u_12.icon("lock", {
			["size"] = nil,
			["color"] = nil,
			["zindex"] = 4,
			["size"] = v_u_27.LOCK_PX,
			["color"] = v_u_15.accent
		})
		v524.Name = "PinLock"
		v524.AnchorPoint = Vector2.new(0, 0)
		v524.Position = UDim2.fromOffset(6, 6)
		v524.Visible = false
		v524.Parent = v489
		local v525 = v_u_54(v485, "Hit")
		v525.ZIndex = 6
		local v_u_526 = {
			["frame"] = nil,
			["body"] = nil,
			["under"] = nil,
			["r1"] = nil,
			["r1s"] = nil,
			["r2"] = nil,
			["r2s"] = nil,
			["info"] = nil,
			["infos"] = nil,
			["vring"] = nil,
			["shape"] = nil,
			["shapeCorner"] = nil,
			["shapeStroke"] = nil,
			["num"] = nil,
			["arrow"] = nil,
			["hit"] = nil,
			["sig"] = "",
			["key"] = nil,
			["item"] = nil,
			["breath"] = nil,
			["hov"] = nil,
			["hovs"] = nil,
			["hovOn"] = false,
			["hovTw"] = nil,
			["hovFin"] = nil,
			["lockI"] = nil,
			["frame"] = v485,
			["body"] = v489,
			["under"] = v492,
			["r1"] = v497,
			["r1s"] = v499,
			["r2"] = v494,
			["r2s"] = v496,
			["info"] = v500,
			["infos"] = v502,
			["vring"] = v503,
			["shape"] = v509,
			["shapeCorner"] = v513,
			["shapeStroke"] = v517,
			["num"] = v522,
			["arrow"] = v523,
			["hit"] = v525,
			["breath"] = {},
			["hov"] = v505,
			["hovs"] = v507,
			["hovTw"] = {},
			["hovFin"] = {},
			["lockI"] = v524
		}
		v525.Activated:Connect(function()
			-- upvalues: (ref) v_u_110, (copy) v_u_526, (ref) v_u_116
			if not (v_u_110.justDragged and v_u_110.justDragged()) then
				if v_u_526.item then
					v_u_116.activate(v_u_526.item, v_u_526)
				end
			end
		end)
		v525.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_526, (ref) v_u_461, (ref) v_u_116
			if v_u_526.key and v_u_461 ~= v_u_526.key then
				v_u_461 = v_u_526.key
				v_u_116.dirty = true
				v_u_116.wake()
			end
		end)
		v525.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_461, (copy) v_u_526, (ref) v_u_116
			if v_u_461 == v_u_526.key then
				v_u_461 = nil
				v_u_116.dirty = true
				v_u_116.wake()
			end
		end)
		return v_u_526
	end
	function v_u_116.stopHover(p528) -- name: stopHover
		for _, v529 in p528.hovTw do
			v529:Cancel()
		end
		for _, v530 in p528.hovFin do
			v530()
		end
		p528.hovTw = {}
		p528.hovFin = {}
	end
	function v_u_116.hoverPaint(p531, p532) -- name: hoverPaint
		-- upvalues: (ref) v_u_461, (copy) v_u_116, (ref) v_u_128, (ref) v_u_27, (copy) v_u_114, (ref) v_u_3, (copy) v_u_466, (ref) v_u_17
		local v533
		if v_u_461 == nil or p531.key ~= v_u_461 then
			v533 = false
		else
			v533 = p532.kind == "pin"
		end
		if p531.hovOn == v533 then
			return
		else
			p531.hovOn = v533
			v_u_116.stopHover(p531)
			if v533 then
				local v534 = v_u_27.HOVER_PX[2] + (p532.deploy and 6 or 0)
				local v535 = p531.hov
				if v535.Visible ~= true then
					v535.Visible = true
					v_u_128 = v_u_128 + 1
				end
				if v_u_114() then
					p531.hov.Size = UDim2.fromOffset(v534, v534)
					p531.hovs.Transparency = 0.3
				else
					p531.hov.Size = UDim2.fromOffset(v_u_27.HOVER_PX[1], v_u_27.HOVER_PX[1])
					p531.hovs.Transparency = 1
					local v536 = TweenInfo.new(v_u_27.HOVER_S, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					for _, v537 in {
						{
							p531.hov,
							{
								["Size"] = UDim2.fromOffset(v534, v534)
							}
						},
						{
							p531.hovs,
							{
								["Transparency"] = 0.3
							}
						}
					} do
						local v538 = v_u_3:Create(v537[1], v536, v537[2])
						local v_u_539 = false
						local function v540() -- name: fin
							-- upvalues: (ref) v_u_539, (ref) v_u_466, (ref) v_u_17
							if not v_u_539 then
								v_u_539 = true
								v_u_466.other = v_u_17(0, v_u_466.other - 1)
							end
						end
						local v541 = v_u_466
						v541.other = v541.other + 1
						local v542 = p531.hovTw
						table.insert(v542, v538)
						local v543 = p531.hovFin
						table.insert(v543, v540)
						v538.Completed:Once(v540)
						v538:Play()
					end
				end
			else
				local v544 = p531.hov
				if v544.Visible ~= false then
					v544.Visible = false
					v_u_128 = v_u_128 + 1
				end
				return
			end
		end
	end
	local function v_u_553(p545) -- name: breathe
		-- upvalues: (copy) v_u_114, (ref) v_u_27, (ref) v_u_3
		for _, v546 in p545.breath do
			v546:Cancel()
		end
		p545.breath = {}
		if not v_u_114() then
			local v547 = TweenInfo.new(v_u_27.BREATH_S, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
			for _, v548 in {
				{ p545.r1, p545.r1s, 26 },
				{ p545.r2, p545.r2s, 38 }
			} do
				v548[1].Size = UDim2.fromOffset(v548[3], v548[3])
				local v549 = v_u_3:Create(v548[1], v547, {
					["Size"] = UDim2.fromOffset(v548[3] * 1.12, v548[3] * 1.12)
				})
				local v550 = v_u_3:Create(v548[2], v547, {
					["Transparency"] = 0.8
				})
				v549:Play()
				v550:Play()
				local v551 = p545.breath
				table.insert(v551, v549)
				local v552 = p545.breath
				table.insert(v552, v550)
			end
		end
	end
	local function v_u_627(p554, p555) -- name: paintSet
		-- upvalues: (copy) v_u_464, (ref) v_u_122, (ref) v_u_17, (ref) v_u_128, (ref) v_u_15, (ref) v_u_12, (copy) v_u_553
		local v556 = p555.pin
		local v557
		if v556 then
			if v556.hidden then
				v557 = "hidden"
			else
				local v558 = v556.state
				v557 = v558 == "test" and "test" or ((v558 == "raids" or (v558 == "locked" or v558 == "quest")) and "locked" or (v558 == "soon" and "soon" or "open"))
			end
		else
			v557 = "open"
		end
		local v559
		if v556 == nil then
			v559 = false
		else
			v559 = v556.frozen == true
		end
		local v560 = table.concat
		local v561 = {}
		local v562 = p555.kind
		local v563 = p555.deploy
		local v564 = tostring(v563)
		local v565 = p555.viewing
		local v566 = tostring(v565)
		local v567 = tostring(v559)
		local v568 = p555.count
		local v569 = tostring(v568)
		local v570 = v_u_464
		local v571 = tostring(v570)
		local v572
		if v556 then
			v572 = v556.underground
		else
			v572 = v556
		end
		local v573 = tostring(v572)
		local v574 = v_u_122.hit
		local v575 = tostring(v574)
		local v576 = p555.spread
		local v577 = tostring(v576)
		local v578
		if v556 then
			v578 = v556.deploy
		else
			v578 = v556
		end
		__set_list(v561, 1, {v562, v557, v564, v566, v567, v569, v571, v573, v575, v577, (tostring(v578))})
		local v579 = v560(v561, "|")
		if p554.sig == v579 then
			return
		else
			p554.sig = v579
			local v580 = v559 and 0.35 or 0
			local v581 = v_u_464 == "circle"
			for _, v582 in p554.breath do
				v582:Cancel()
			end
			p554.breath = {}
			local v583 = p554.hit
			local v584 = UDim2.fromOffset
			local v585
			if p555.kind == "cluster" then
				v585 = v_u_17(v_u_122.merge, v_u_122.hit)
			else
				v585 = v_u_122.hit
			end
			local v586
			if p555.kind == "cluster" then
				v586 = v_u_17(v_u_122.merge, v_u_122.hit)
			else
				v586 = v_u_122.hit
			end
			local v587 = v584(v585, v586)
			if v583.Size ~= v587 then
				v583.Size = v587
				v_u_128 = v_u_128 + 1
			end
			local v588 = p554.vring
			local v589
			if p555.viewing == true then
				v589 = not p555.deploy
			else
				v589 = false
			end
			if v588.Visible ~= v589 then
				v588.Visible = v589
				v_u_128 = v_u_128 + 1
			end
			local v590 = p554.arrow
			if v590.Visible ~= false then
				v590.Visible = false
				v_u_128 = v_u_128 + 1
			end
			local v591 = p554.lockI
			local v592
			if p555.kind == "cluster" then
				v592 = false
			else
				v592 = v557 == "locked"
			end
			if v591.Visible ~= v592 then
				v591.Visible = v592
				v_u_128 = v_u_128 + 1
			end
			if p555.kind == "cluster" then
				local v593 = p554.under
				if v593.Visible ~= true then
					v593.Visible = true
					v_u_128 = v_u_128 + 1
				end
				local v594 = p554.shape
				if v594.Visible ~= false then
					v594.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v595 = p554.info
				if v595.Visible ~= false then
					v595.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v596 = p554.r1
				if v596.Visible ~= false then
					v596.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v597 = p554.r2
				if v597.Visible ~= true then
					v597.Visible = true
					v_u_128 = v_u_128 + 1
				end
				local v598 = p554.r2
				local v599 = UDim2.fromOffset(38, 38)
				if v598.Size ~= v599 then
					v598.Size = v599
					v_u_128 = v_u_128 + 1
				end
				local v600 = p554.r2s
				local v601
				if p555.deploy then
					v601 = v_u_15.accent
				else
					v601 = v_u_15.text2
				end
				v600.Color = v601
				p554.r2s.Transparency = 0
				local v602 = p554.num
				if v602.Visible ~= true then
					v602.Visible = true
					v_u_128 = v_u_128 + 1
				end
				local v603 = p554.num
				local v604
				if p555.deploy then
					v604 = v_u_15.accent
				else
					v604 = v_u_15.text
				end
				v603.TextColor3 = v604
				local v605 = v_u_12.setText
				local v606 = p554.num
				local v607 = p555.count
				v605(v606, (tostring(v607)))
			else
				local v608 = p554.num
				if v608.Visible ~= false then
					v608.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v609 = p554.under
				if v609.Visible ~= true then
					v609.Visible = true
					v_u_128 = v_u_128 + 1
				end
				local v610 = p554.shape
				if v610.Visible ~= true then
					v610.Visible = true
					v_u_128 = v_u_128 + 1
				end
				p554.shapeCorner.CornerRadius = UDim.new((v581 or v557 == "soon") and 1 or 0, 0)
				v610.Rotation = (v581 or v557 == "soon") and 0 or 45
				local v611 = 12
				local v612 = v_u_15.text
				local v613 = false
				local v614 = v_u_15.text
				local v615 = p554.r1
				if v615.Visible ~= false then
					v615.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v616 = p554.r2
				if v616.Visible ~= false then
					v616.Visible = false
					v_u_128 = v_u_128 + 1
				end
				local v617 = p554.info
				if v617.Visible ~= false then
					v617.Visible = false
					v_u_128 = v_u_128 + 1
				end
				if v557 == "hidden" then
					v612 = v_u_15.text2
					v611 = 10
				elseif v557 == "locked" then
					v611 = 14
					v613 = true
				elseif v557 == "soon" then
					v614 = v_u_15.text2
					v611 = 14
					v613 = true
				elseif v557 == "test" then
					v611 = 12
					local v618 = p554.info
					if v618.Visible ~= true then
						v618.Visible = true
						v_u_128 = v_u_128 + 1
					end
					p554.infos.Transparency = v580
				end
				if p555.deploy then
					v611 = 16
					v612 = v_u_15.accent
					v613 = false
					local v619 = p554.r1
					if v619.Visible ~= true then
						v619.Visible = true
						v_u_128 = v_u_128 + 1
					end
					local v620 = p554.r2
					if v620.Visible ~= true then
						v620.Visible = true
						v_u_128 = v_u_128 + 1
					end
					local v621 = p554.r1s
					local v622 = p554.r2s
					local v623 = v_u_15.accent
					local v624 = v_u_15.accent
					v621.Color = v623
					v622.Color = v624
					v_u_553(p554)
				end
				local v625 = UDim2.fromOffset(v611, v611)
				if v610.Size ~= v625 then
					v610.Size = v625
					v_u_128 = v_u_128 + 1
				end
				if v613 then
					v610.BackgroundTransparency = 1
					p554.shapeStroke.Enabled = true
					p554.shapeStroke.Color = v614
					p554.shapeStroke.Transparency = v580
				else
					v610.BackgroundColor3 = v612
					v610.BackgroundTransparency = v580
					p554.shapeStroke.Enabled = false
				end
				if v556 and v556.underground then
					local v626 = p554.arrow
					if v626.Visible ~= true then
						v626.Visible = true
						v_u_128 = v_u_128 + 1
					end
				end
			end
		end
	end
	local function v_u_649(p628) -- name: makePlaque
		-- upvalues: (ref) v_u_15, (ref) v_u_27, (copy) v_u_234, (ref) v_u_12, (ref) v_u_10
		local v629 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["Name"] = "P" .. p628,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["BackgroundTransparency"] = v_u_27.PLATE_ALPHA
		}
		local v630 = v_u_234
		local v631 = Instance.new("Frame")
		for v632, v633 in v629 do
			v631[v632] = v633
		end
		if v630 then
			v631.Parent = v630
		end
		local v634 = v_u_15.line
		v_u_12.stroke(v631, v634, 1, 0)
		local v635 = {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.lineStrong,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}
		local v636 = Instance.new("Frame")
		for v637, v638 in v635 do
			v636[v637] = v638
		end
		if v631 then
			v636.Parent = v631
		end
		local v639 = {
			["color"] = v_u_15.text,
			["size"] = UDim2.new(1, -16, 1, 0)
		}
		local v640 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["track"] = true,
			["parent"] = v631
		}
		if v639 then
			for v641, v642 in v639 do
				v640[v641] = v642
			end
		end
		local v643 = v_u_12.label(v640)
		v643.Position = UDim2.fromOffset(9, 0)
		local v644 = v_u_12.icon("lock", {
			["size"] = 12,
			["color"] = nil,
			["color"] = v_u_15.accent
		})
		v644.AnchorPoint = Vector2.new(1, 0.5)
		v644.Position = UDim2.new(1, -6, 0.5, 0)
		v644.Visible = false
		v644.Parent = v631
		local v645 = {
			["Name"] = "Redact",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.45,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_15.text2,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(v_u_10.TUNING.BAR_W, v_u_10.TUNING.BAR_H)
		}
		local v646 = Instance.new("Frame")
		for v647, v648 in v645 do
			v646[v647] = v648
		end
		if v631 then
			v646.Parent = v631
		end
		return {
			["frame"] = nil,
			["edge"] = nil,
			["lbl"] = nil,
			["lock"] = nil,
			["bar"] = nil,
			["sig"] = "",
			["frame"] = v631,
			["edge"] = v636,
			["lbl"] = v643,
			["lock"] = v644,
			["bar"] = v646
		}
	end
	local function v_u_693(p650, p651) -- name: paintPlaque
		-- upvalues: (ref) v_u_11, (ref) v_u_113, (ref) v_u_128, (ref) v_u_12, (ref) v_u_15
		local v652 = p651.pin
		local v653 = p651.label
		local v654 = v652.frozen == true
		local v655 = table.concat
		local v656 = {}
		local v657
		if v652.hidden then
			v657 = v_u_11.UNKNOWN
		else
			local v658 = v652.name or v652.id
			v657 = tostring(v658)
		end
		local v659 = v653.bar
		local v660 = tostring(v659)
		local v661 = p651.viewing
		local v662 = tostring(v661)
		local v663 = p651.deploy
		local v664 = tostring(v663)
		local v665
		if v652.hidden then
			v665 = "hidden"
		else
			local v666 = v652.state
			v665 = v666 == "test" and "test" or ((v666 == "raids" or (v666 == "locked" or v666 == "quest")) and "locked" or (v666 == "soon" and "soon" or "open"))
		end
		local v667 = v665 == "locked"
		__set_list(v656, 1, {v657, v660, v662, v664, tostring(v667), (tostring(v654))})
		local v668 = v655(v656, "|")
		local v669 = p650.frame
		local v670 = v653.x
		local v671 = v653.y
		local v672 = UDim2.new(v670 / v_u_113, 0, v671 / v_u_113, 0)
		if v669.Position ~= v672 then
			v669.Position = v672
			v_u_128 = v_u_128 + 1
		end
		local v673 = UDim2.fromOffset(v653.w, v653.h)
		if v669.Size ~= v673 then
			v669.Size = v673
			v_u_128 = v_u_128 + 1
		end
		if p650.sig ~= v668 then
			p650.sig = v668
			local v674 = p650.bar
			local v675 = v653.bar == true
			if v674.Visible ~= v675 then
				v674.Visible = v675
				v_u_128 = v_u_128 + 1
			end
			local v676 = p650.lbl
			local v677 = v653.bar ~= true
			if v676.Visible ~= v677 then
				v676.Visible = v677
				v_u_128 = v_u_128 + 1
			end
			if v653.bar ~= true then
				local v678 = v_u_12.setText
				local v679 = p650.lbl
				local v680
				if v652.hidden then
					v680 = v_u_11.UNKNOWN
				else
					local v681 = v652.name or v652.id
					v680 = tostring(v681)
				end
				v678(v679, v680)
			end
			local v682 = p650.edge
			local v683
			if p651.deploy or p651.viewing then
				v683 = v_u_15.accent
			else
				v683 = v_u_15.lineStrong
			end
			v682.BackgroundColor3 = v683
			local v684 = p650.lock
			local v685
			if v652.hidden then
				v685 = "hidden"
			else
				local v686 = v652.state
				v685 = v686 == "test" and "test" or ((v686 == "raids" or (v686 == "locked" or v686 == "quest")) and "locked" or (v686 == "soon" and "soon" or "open"))
			end
			local v687 = v685 == "locked"
			if v687 then
				v687 = v653.bar ~= true
			end
			if v684.Visible ~= v687 then
				v684.Visible = v687
				v_u_128 = v_u_128 + 1
			end
			local v688 = p650.lbl
			local v689 = UDim2.new
			local v690 = 1
			local v691
			if v652.hidden then
				v691 = "hidden"
			else
				local v692 = v652.state
				v691 = v692 == "test" and "test" or ((v692 == "raids" or (v692 == "locked" or v692 == "quest")) and "locked" or (v692 == "soon" and "soon" or "open"))
			end
			v688.Size = v689(v690, v691 == "locked" and -34 or -16, 1, 0)
			p650.lbl.TextTransparency = v654 and 0.35 or 0
		end
		if v669.Visible ~= true then
			v669.Visible = true
			v_u_128 = v_u_128 + 1
		end
	end
	local v_u_694 = nil
	local function v_u_760() -- name: buildCard
		-- upvalues: (ref) v_u_15, (ref) v_u_27, (copy) v_u_238, (ref) v_u_12, (ref) v_u_694
		local v695 = {
			["Name"] = "Card",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["BackgroundTransparency"] = v_u_27.PLATE_ALPHA,
			["Size"] = UDim2.fromOffset(v_u_27.CARD_W, 90)
		}
		local v696 = v_u_238
		local v697 = Instance.new("Frame")
		for v698, v699 in v695 do
			v697[v698] = v699
		end
		if v696 then
			v697.Parent = v696
		end
		local v700 = v_u_15.line
		v_u_12.stroke(v697, v700, 1, 0)
		local v701 = {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}
		local v702 = Instance.new("Frame")
		for v703, v704 in v701 do
			v702[v703] = v704
		end
		if v697 then
			v702.Parent = v697
		end
		local v705 = {
			["Name"] = "Inner",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(12, 8),
			["Size"] = UDim2.new(1, -20, 1, -16)
		}
		local v706 = Instance.new("Frame")
		for v707, v708 in v705 do
			v706[v707] = v708
		end
		if v697 then
			v706.Parent = v697
		end
		local v709 = {
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 6)
		}
		local v710 = Instance.new("UIListLayout")
		for v711, v712 in v709 do
			v710[v711] = v712
		end
		if v706 then
			v710.Parent = v706
		end
		local v713 = {
			["color"] = v_u_15.text,
			["size"] = UDim2.new(1, 0, 0, 22)
		}
		local v714 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "h3",
			["track"] = true,
			["parent"] = v706
		}
		if v713 then
			for v715, v716 in v713 do
				v714[v715] = v716
			end
		end
		local v717 = v_u_12.label(v714)
		v717.LayoutOrder = 1
		local v718 = {
			["color"] = v_u_15.text2,
			["size"] = UDim2.new(1, 0, 0, 16)
		}
		local v719 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "small",
			["track"] = false,
			["parent"] = v706
		}
		if v718 then
			for v720, v721 in v718 do
				v719[v720] = v721
			end
		end
		local v722 = v_u_12.label(v719)
		v722.LayoutOrder = 2
		local v723 = {
			["Name"] = "Chips",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 3,
			["Size"] = UDim2.new(1, 0, 0, 20)
		}
		local v724 = Instance.new("Frame")
		for v725, v726 in v723 do
			v724[v725] = v726
		end
		if v706 then
			v724.Parent = v706
		end
		local v727 = {
			["Name"] = "Chip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 20)
		}
		local v728 = Instance.new("Frame")
		for v729, v730 in v727 do
			v728[v729] = v730
		end
		if v724 then
			v728.Parent = v724
		end
		local v731 = v_u_15.text2
		local v732 = v_u_12.stroke(v728, v731, 1, 0.35)
		local v733 = {
			["PaddingLeft"] = UDim.new(0, 6),
			["PaddingRight"] = UDim.new(0, 6)
		}
		local v734 = Instance.new("UIPadding")
		for v735, v736 in v733 do
			v734[v735] = v736
		end
		if v728 then
			v734.Parent = v728
		end
		local v737 = {
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["color"] = v_u_15.text2,
			["size"] = UDim2.fromOffset(0, 20)
		}
		local v738 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "micro",
			["track"] = true,
			["parent"] = v728
		}
		if v737 then
			for v739, v740 in v737 do
				v738[v739] = v740
			end
		end
		local v741 = v_u_12.label(v738)
		local v742 = {
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["color"] = v_u_15.accent
		}
		local v743 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["track"] = false,
			["parent"] = v706
		}
		if v742 then
			for v744, v745 in v742 do
				v743[v744] = v745
			end
		end
		local v746 = v_u_12.label(v743)
		v746.LayoutOrder = 4
		v746.TextTruncate = Enum.TextTruncate.None
		local v747 = {
			["Name"] = "BarBack",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = 5,
			["BackgroundColor3"] = v_u_15.raised,
			["Size"] = UDim2.new(1, 0, 0, 6)
		}
		local v748 = Instance.new("Frame")
		for v749, v750 in v747 do
			v748[v749] = v750
		end
		if v706 then
			v748.Parent = v706
		end
		local v751 = {
			["Name"] = "BarFill",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.accent,
			["Size"] = UDim2.new(0, 0, 1, 0)
		}
		local v752 = Instance.new("Frame")
		for v753, v754 in v751 do
			v752[v753] = v754
		end
		if v748 then
			v752.Parent = v748
		end
		local v755 = {
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["color"] = v_u_15.text2
		}
		local v756 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["track"] = false,
			["parent"] = v706
		}
		if v755 then
			for v757, v758 in v755 do
				v756[v757] = v758
			end
		end
		local v759 = v_u_12.label(v756)
		v759.LayoutOrder = 6
		v759.TextTruncate = Enum.TextTruncate.None
		v_u_694 = {
			["frame"] = nil,
			["name"] = nil,
			["place"] = nil,
			["chip"] = nil,
			["chipLbl"] = nil,
			["chipStroke"] = nil,
			["line"] = nil,
			["barBack"] = nil,
			["barFill"] = nil,
			["prog"] = nil,
			["sig"] = "",
			["edge"] = nil,
			["frame"] = v697,
			["name"] = v717,
			["place"] = v722,
			["chip"] = v728,
			["chipLbl"] = v741,
			["chipStroke"] = v732,
			["line"] = v746,
			["barBack"] = v748,
			["barFill"] = v752,
			["prog"] = v759,
			["edge"] = v697:FindFirstChild("Edge")
		}
	end
	local function v_u_774(p761) -- name: cardHeight
		-- upvalues: (copy) v_u_110, (ref) v_u_8, (ref) v_u_27, (ref) v_u_71, (ref) v_u_16
		local v762 = p761.pin
		local v763 = 86
		local v764
		if v_u_110.detail == true then
			local v765 = v762.line
			if type(v765) == "string" and v762.line ~= "" then
				v764 = true
			else
				local v766 = v762.progressText
				if type(v766) == "string" then
					v764 = v762.progressText ~= ""
				else
					v764 = false
				end
			end
		else
			v764 = false
		end
		if v764 then
			local v767 = v_u_8.styles.monoS
			local v768 = v_u_8.phoneText(v767.size, "caption")
			local v769 = v_u_27.CARD_W - 20
			local v770 = 3 * v768 * 1.25
			local v771 = v762.line
			if type(v771) == "string" and v762.line ~= "" then
				v763 = v763 + (v_u_16(v_u_71(v762.line, v767.font, v768, v769), v770) + 6 + 2)
			end
			local v772 = v762.progress
			if type(v772) == "number" then
				v763 = v763 + 12
			end
			local v773 = v762.progressText
			if type(v773) == "string" and v762.progressText ~= "" then
				v763 = v763 + (v_u_16(v_u_71(v762.progressText, v767.font, v768, v769), v770) + 6 + 2)
			end
		end
		return v763
	end
	local function v_u_832(p775) -- name: paintCard
		-- upvalues: (ref) v_u_694, (copy) v_u_760, (copy) v_u_110, (ref) v_u_98, (ref) v_u_11, (ref) v_u_18, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_113, (ref) v_u_128, (copy) v_u_116
		if not v_u_694 then
			v_u_760()
		end
		local v776 = p775.pin
		local v777 = p775.label
		local v778
		if v_u_110.detail == true then
			local v779 = v776.line
			if type(v779) == "string" and v776.line ~= "" then
				v778 = true
			else
				local v780 = v776.progressText
				if type(v780) == "string" then
					v778 = v776.progressText ~= ""
				else
					v778 = false
				end
			end
		else
			v778 = false
		end
		local v781 = v_u_98(v776)
		local v782 = table.concat
		local v783 = {}
		local v784
		if v776.hidden then
			v784 = v_u_11.UNKNOWN
		else
			local v785 = v776.name or v776.id
			v784 = tostring(v785)
		end
		local v786 = v776.place
		local v787 = tostring(v786)
		local v788
		if v776.hidden then
			v788 = "hidden"
		else
			local v789 = v776.state
			v788 = v789 == "test" and "test" or ((v789 == "raids" or (v789 == "locked" or v789 == "quest")) and "locked" or (v789 == "soon" and "soon" or "open"))
		end
		local v790 = v776.deploy
		local v791 = tostring(v790)
		local v792 = tostring(v778)
		local v793 = v776.line
		local v794 = tostring(v793)
		local v795 = v776.progressText
		local v796 = tostring(v795)
		local v797 = v_u_18((v776.progress or 0) * 100)
		__set_list(v783, 1, {v784, v787, v781, v788, v791, v792, v794, v796, (tostring(v797))})
		local v798 = v782(v783, "|")
		if v_u_694.sig ~= v798 then
			v_u_694.sig = v798
			local v799 = v_u_12.setText
			local v800 = v_u_694.name
			local v801
			if v776.hidden then
				v801 = v_u_11.UNKNOWN
			else
				local v802 = v776.name or v776.id
				v801 = tostring(v802)
			end
			v799(v800, v801)
			local v803 = v_u_12.setText
			local v804 = v_u_694.place
			local v805 = v776.place or ""
			v803(v804, (tostring(v805)))
			v_u_12.setText(v_u_694.chipLbl, v781)
			local v806
			if v776.deploy then
				v806 = v_u_15.accent
			else
				local v807
				if v776.hidden then
					v807 = "hidden"
				else
					local v808 = v776.state
					v807 = v808 == "test" and "test" or ((v808 == "raids" or (v808 == "locked" or v808 == "quest")) and "locked" or (v808 == "soon" and "soon" or "open"))
				end
				if v807 == "test" then
					v806 = v_u_15.info
				elseif v807 == "open" then
					v806 = v_u_15.text
				else
					v806 = v_u_15.text2
				end
			end
			v_u_694.chipLbl.TextColor3 = v806
			v_u_694.chipStroke.Color = v806
			local v809 = v_u_694.line
			local v810
			if v778 then
				local v811 = v776.line
				if type(v811) == "string" then
					v810 = v776.line ~= ""
				else
					v810 = false
				end
			else
				v810 = v778
			end
			v809.Visible = v810
			local v812 = v_u_694.line
			local v813 = v776.line or ""
			v812.Text = tostring(v813)
			local v814 = v_u_694.barBack
			local v815
			if v778 then
				local v816 = v776.progress
				v815 = type(v816) == "number"
			else
				v815 = v778
			end
			v814.Visible = v815
			v_u_694.barFill.Size = UDim2.new(v_u_17(0, (v_u_16(1, v776.progress or 0))), 0, 1, 0)
			local v817 = v_u_694.prog
			if v778 then
				local v818 = v776.progressText
				if type(v818) == "string" then
					v778 = v776.progressText ~= ""
				else
					v778 = false
				end
			end
			v817.Visible = v778
			local v819 = v_u_694.prog
			local v820 = v776.progressText or ""
			v819.Text = tostring(v820)
		end
		local v821 = v777.h
		local v822 = v_u_694.frame
		local v823 = v777.x
		local v824 = v777.y
		local v825 = UDim2.new(v823 / v_u_113, 0, v824 / v_u_113, 0)
		if v822.Position ~= v825 then
			v822.Position = v825
			v_u_128 = v_u_128 + 1
		end
		local v826 = v_u_694.frame
		local v827 = UDim2.fromOffset(v777.w, v821)
		if v826.Size ~= v827 then
			v826.Size = v827
			v_u_128 = v_u_128 + 1
		end
		local v828 = v_u_694.edge
		local v829
		if p775.deploy then
			v829 = v_u_15.accent
		else
			v829 = v_u_15.lineStrong
		end
		v828.BackgroundColor3 = v829
		local v830 = v_u_694.frame
		local v831 = not v_u_116.moving
		if v830.Visible ~= v831 then
			v830.Visible = v831
			v_u_128 = v_u_128 + 1
		end
	end
	local v_u_833 = nil
	local v_u_834 = nil
	local function v_u_877() -- name: buildList
		-- upvalues: (ref) v_u_111, (ref) v_u_27, (ref) v_u_15, (copy) v_u_238, (ref) v_u_12, (copy) v_u_116, (ref) v_u_8, (ref) v_u_833
		local v835
		if v_u_111 == "phone" then
			v835 = v_u_27.LIST_W_PHONE
		else
			v835 = v_u_27.LIST_W
		end
		local v836 = {
			["Name"] = "ListCard",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["Size"] = UDim2.fromOffset(v835, 100)
		}
		local v837 = v_u_238
		local v838 = Instance.new("Frame")
		for v839, v840 in v836 do
			v838[v839] = v840
		end
		if v837 then
			v838.Parent = v837
		end
		local v841 = v_u_15.lineStrong
		v_u_12.stroke(v838, v841, 1, 0)
		local v842 = {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 30)
		}
		local v843 = Instance.new("Frame")
		for v844, v845 in v842 do
			v843[v844] = v845
		end
		if v838 then
			v843.Parent = v838
		end
		local v846 = {
			["color"] = v_u_15.text2,
			["size"] = UDim2.new(1, -90, 1, 0)
		}
		local v847 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["track"] = true,
			["parent"] = v843
		}
		if v846 then
			for v848, v849 in v846 do
				v847[v848] = v849
			end
		end
		local v850 = v_u_12.label(v847)
		v850.Position = UDim2.fromOffset(12, 0)
		local v851 = {
			["color"] = nil,
			["align"] = "right",
			["size"] = nil,
			["color"] = v_u_15.text2,
			["size"] = UDim2.new(0, 80, 1, 0)
		}
		local v852 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["track"] = false,
			["parent"] = v843
		}
		if v851 then
			for v853, v854 in v851 do
				v852[v853] = v854
			end
		end
		local v855 = v_u_12.label(v852)
		v855.Position = UDim2.new(1, -92, 0, 0)
		local v856 = {
			["Name"] = "Rule",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.line,
			["Position"] = UDim2.fromOffset(0, 29),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v857 = Instance.new("Frame")
		for v858, v859 in v856 do
			v857[v858] = v859
		end
		if v843 then
			v857.Parent = v843
		end
		local v860 = {
			["Name"] = "Close",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = false,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.fromScale(1, 0),
			["Size"] = UDim2.fromOffset(28, 30)
		}
		local v861 = Instance.new("TextButton")
		for v862, v863 in v860 do
			v861[v862] = v863
		end
		if v843 then
			v861.Parent = v843
		end
		v_u_12.icon("close", {
			["size"] = 14,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["color"] = v_u_15.text2,
			["position"] = UDim2.fromScale(0.5, 0.5),
			["anchor"] = Vector2.new(0.5, 0.5)
		}).Parent = v861
		v861.Activated:Connect(function()
			-- upvalues: (ref) v_u_116
			v_u_116.closeList()
		end)
		local v864 = {
			["Name"] = "Rows",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["ScrollingDirection"] = nil,
			["Selectable"] = false,
			["Position"] = UDim2.fromOffset(0, 30),
			["Size"] = UDim2.new(1, 0, 0, 44),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
			["ScrollBarThickness"] = v_u_8.scrollBar,
			["ScrollBarImageColor3"] = v_u_15.lineStrong,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y
		}
		local v865 = Instance.new("ScrollingFrame")
		for v866, v867 in v864 do
			v865[v866] = v867
		end
		if v838 then
			v865.Parent = v838
		end
		local v868 = {
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}
		local v869 = Instance.new("UIListLayout")
		for v870, v871 in v868 do
			v869[v870] = v871
		end
		if v865 then
			v869.Parent = v865
		end
		local v872 = {
			["Name"] = "Guide",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_15.line
		}
		local v873 = v_u_238
		local v874 = Instance.new("Frame")
		for v875, v876 in v872 do
			v874[v875] = v876
		end
		if v873 then
			v874.Parent = v873
		end
		v_u_833 = {
			["frame"] = nil,
			["head"] = nil,
			["hl"] = nil,
			["hr"] = nil,
			["scroll"] = nil,
			["guide"] = nil,
			["w"] = nil,
			["rows"] = nil,
			["closeB"] = nil,
			["rule"] = nil,
			["headH"] = 30,
			["frame"] = v838,
			["head"] = v843,
			["hl"] = v850,
			["hr"] = v855,
			["scroll"] = v865,
			["guide"] = v874,
			["w"] = v835,
			["rows"] = {},
			["closeB"] = v861,
			["rule"] = v843:FindFirstChild("Rule")
		}
	end
	local function v_u_927(p878) -- name: makeRow
		-- upvalues: (ref) v_u_8, (ref) v_u_15, (ref) v_u_833, (ref) v_u_12, (copy) v_u_116
		local v879 = v_u_8.touch(44)
		local v880 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = true,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Row" .. p878,
			["BackgroundColor3"] = v_u_15.raised,
			["Size"] = UDim2.new(1, 0, 0, v879),
			["LayoutOrder"] = p878
		}
		local v881 = v_u_833.scroll
		local v882 = Instance.new("TextButton")
		for v883, v884 in v880 do
			v882[v883] = v884
		end
		if v881 then
			v882.Parent = v881
		end
		local v885 = {
			["Name"] = "RowSel",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v886 = Instance.new("Frame")
		for v887, v888 in v885 do
			v886[v887] = v888
		end
		local v889 = v_u_15.accent
		v_u_12.stroke(v886, v889, 2, 0)
		v882.SelectionImageObject = v886
		local v890 = {
			["Name"] = "Inner",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v891 = Instance.new("Frame")
		for v892, v893 in v890 do
			v891[v892] = v893
		end
		if v882 then
			v891.Parent = v882
		end
		local v894 = {
			["Name"] = "Dot",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0, 16, 0.5, 0),
			["Size"] = UDim2.fromOffset(9, 9),
			["BackgroundColor3"] = v_u_15.text
		}
		local v895 = Instance.new("Frame")
		for v896, v897 in v894 do
			v895[v896] = v897
		end
		if v891 then
			v895.Parent = v891
		end
		local v898 = v_u_15.text
		local v899 = v_u_12.stroke(v895, v898, 1.5, 0)
		local v900 = {
			["color"] = v_u_15.text,
			["size"] = UDim2.new(1, -150, 0, 20)
		}
		local v901 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "h3",
			["track"] = true,
			["parent"] = v891
		}
		if v900 then
			for v902, v903 in v900 do
				v901[v902] = v903
			end
		end
		local v904 = v_u_12.label(v901)
		v904.Position = UDim2.fromOffset(32, 4)
		local v905 = {
			["color"] = v_u_15.text2,
			["size"] = UDim2.new(1, -150, 0, 16)
		}
		local v906 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "small",
			["track"] = false,
			["parent"] = v891
		}
		if v905 then
			for v907, v908 in v905 do
				v906[v907] = v908
			end
		end
		local v909 = v_u_12.label(v906)
		v909.Position = UDim2.fromOffset(32, 24)
		local v910 = {
			["Name"] = "Chip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.bgDeep,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 18)
		}
		local v911 = Instance.new("Frame")
		for v912, v913 in v910 do
			v911[v912] = v913
		end
		if v891 then
			v911.Parent = v891
		end
		local v914 = v_u_15.text2
		local v915 = v_u_12.stroke(v911, v914, 1, 0.35)
		local v916 = {
			["PaddingLeft"] = UDim.new(0, 6),
			["PaddingRight"] = UDim.new(0, 6)
		}
		local v917 = Instance.new("UIPadding")
		for v918, v919 in v916 do
			v917[v918] = v919
		end
		if v911 then
			v917.Parent = v911
		end
		local v920 = {
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["color"] = v_u_15.text2,
			["size"] = UDim2.fromOffset(0, 18)
		}
		local v921 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "micro",
			["track"] = true,
			["parent"] = v911
		}
		if v920 then
			for v922, v923 in v920 do
				v921[v922] = v923
			end
		end
		local v924 = v_u_12.label(v921)
		local v925 = v_u_12.icon("lock", {
			["size"] = 12,
			["color"] = nil,
			["color"] = v_u_15.accent
		})
		v925.AnchorPoint = Vector2.new(1, 0.5)
		v925.Visible = false
		v925.Parent = v891
		local v_u_926 = {
			["btn"] = nil,
			["inner"] = nil,
			["dot"] = nil,
			["dotStroke"] = nil,
			["name"] = nil,
			["sub"] = nil,
			["chip"] = nil,
			["chipStroke"] = nil,
			["chipLbl"] = nil,
			["lock"] = nil,
			["id"] = nil,
			["btn"] = v882,
			["inner"] = v891,
			["dot"] = v895,
			["dotStroke"] = v899,
			["name"] = v904,
			["sub"] = v909,
			["chip"] = v911,
			["chipStroke"] = v915,
			["chipLbl"] = v924,
			["lock"] = v925
		}
		v882.Activated:Connect(function()
			-- upvalues: (copy) v_u_926, (ref) v_u_116
			if v_u_926.id ~= nil then
				v_u_116.activateId(v_u_926.id, v_u_926)
			end
		end)
		return v_u_926
	end
	local function v_u_968(p928, p929, p930) -- name: paintRow
		-- upvalues: (ref) v_u_98, (ref) v_u_12, (ref) v_u_11, (ref) v_u_15, (ref) v_u_55, (ref) v_u_4
		p928.id = p929.id
		local v931
		if p929.hidden then
			v931 = "hidden"
		else
			local v932 = p929.state
			v931 = v932 == "test" and "test" or ((v932 == "raids" or (v932 == "locked" or v932 == "quest")) and "locked" or (v932 == "soon" and "soon" or "open"))
		end
		local v933 = v_u_98(p929)
		local v934 = v_u_12.setText
		local v935 = p928.name
		local v936
		if p929.hidden then
			v936 = v_u_11.UNKNOWN
		else
			local v937 = p929.name or p929.id
			v936 = tostring(v937)
		end
		v934(v935, v936)
		local v938 = v_u_12.setText
		local v939 = p928.sub
		local v940 = p929.place or (p929.tagline or "")
		v938(v939, (tostring(v940)))
		local v941
		if p929.deploy then
			v941 = v_u_15.accent
		else
			local v942
			if p929.hidden then
				v942 = "hidden"
			else
				local v943 = p929.state
				v942 = v943 == "test" and "test" or ((v943 == "raids" or (v943 == "locked" or v943 == "quest")) and "locked" or (v943 == "soon" and "soon" or "open"))
			end
			if v942 == "test" then
				v941 = v_u_15.info
			elseif v942 == "open" then
				v941 = v_u_15.text
			else
				v941 = v_u_15.text2
			end
		end
		v_u_12.setText(p928.chipLbl, v933)
		local v944 = p928.chipLbl
		local v945 = p928.chipStroke
		v944.TextColor3 = v941
		v945.Color = v941
		local v946 = v931 == "locked" and true or v931 == "soon"
		p928.dot.BackgroundTransparency = v946 and 1 or 0
		local v947 = p928.dot
		local v948
		if p929.deploy then
			v948 = v_u_15.accent
		else
			v948 = v_u_15.text
		end
		v947.BackgroundColor3 = v948
		local v949 = p928.dotStroke
		local v950
		if p929.deploy then
			v950 = v_u_15.accent
		elseif v931 == "soon" then
			v950 = v_u_15.text2
		else
			v950 = v_u_15.text
		end
		v949.Color = v950
		p928.dotStroke.Enabled = v946
		p928.btn.BackgroundTransparency = p930 and 0.4 or 1
		local v951 = p928.btn
		local v952
		if p930 then
			v952 = v_u_15.accentDeep
		else
			v952 = v_u_15.raised
		end
		v951.BackgroundColor3 = v952
		p928.lock.Visible = v931 == "locked"
		local v953 = p928.lock
		local v954 = UDim2.new
		local v955 = 1
		local v_u_956 = p928.chipLbl.Text
		local v_u_957 = p928.chipLbl.FontFace
		local v_u_958 = p928.chipLbl.TextSize
		local v959 = tostring(v_u_958)
		local v960 = v_u_957.Family
		local v961 = v_u_956 .. "|" .. v959 .. "|" .. tostring(v960)
		local v962 = v_u_55[v961]
		if not v962 then
			local v_u_963 = 100000
			local function v965()
				-- upvalues: (copy) v_u_956, (copy) v_u_957, (copy) v_u_958, (copy) v_u_963, (ref) v_u_4
				local v964 = Instance.new("GetTextBoundsParams")
				v964.Text = v_u_956
				v964.Font = v_u_957
				v964.Size = v_u_958
				v964.Width = v_u_963
				return v_u_4:GetTextBoundsAsync(v964)
			end
			local v966, v967 = pcall(v965)
			if not v966 then
				v967 = nil
			end
			if v967 then
				v962 = v967.X
			else
				v962 = #v_u_956 * v_u_958 * 0.6
			end
			v_u_55[v961] = v962
		end
		v953.Position = v954(v955, -(v962 + 12 + 10 + 8), 0.5, 0)
		p928.btn.Visible = true
	end
	local function v_u_1014(p969) -- name: placeList
		-- upvalues: (ref) v_u_834, (ref) v_u_833, (copy) v_u_116, (ref) v_u_8, (ref) v_u_27, (ref) v_u_16, (ref) v_u_111, (copy) v_u_110, (ref) v_u_17, (ref) v_u_128, (ref) v_u_113, (ref) v_u_93, (copy) v_u_450, (copy) v_u_453, (ref) v_u_694
		if v_u_834 and v_u_833 then
			local v970 = nil
			for _, v971 in p969.items do
				if v971.kind ~= "cluster" or v971.ids[1] ~= v_u_834.ids[1] then
					continue
				end
				v970 = v971
			end
			if v970 then
				local v972 = v_u_833.frame
				local v973 = v_u_8.touch(44)
				local v974 = v_u_16(#v_u_834.ids, v_u_27.LIST_MAX_ROWS)
				local v975
				if v_u_111 == "phone" then
					v975 = true
				elseif v_u_110.inputKind == nil then
					v975 = false
				else
					v975 = v_u_110.inputKind() == "touch"
				end
				local v976 = not v975 and 28 or v_u_8.touch(44)
				local v977 = v_u_17(30, v976)
				v_u_833.headH = v977
				local v978 = v_u_833.head
				local v979 = UDim2.new(1, 0, 0, v977)
				if v978.Size ~= v979 then
					v978.Size = v979
					v_u_128 = v_u_128 + 1
				end
				local v980 = v_u_833.closeB
				local v981 = UDim2.fromOffset(v976, v977)
				if v980.Size ~= v981 then
					v980.Size = v981
					v_u_128 = v_u_128 + 1
				end
				local v982 = v_u_833.hl
				local v983 = UDim2.new(1, -(v976 + 90), 1, 0)
				if v982.Size ~= v983 then
					v982.Size = v983
					v_u_128 = v_u_128 + 1
				end
				local v984 = v_u_833.hr
				local v985 = UDim2.new(1, -(v976 + 86), 0, 0)
				if v984.Position ~= v985 then
					v984.Position = v985
					v_u_128 = v_u_128 + 1
				end
				local v986 = v_u_833.rule
				local v987 = UDim2.fromOffset(0, v977 - 1)
				if v986.Position ~= v987 then
					v986.Position = v987
					v_u_128 = v_u_128 + 1
				end
				local v988 = v_u_833.scroll
				local v989 = UDim2.fromOffset(0, v977)
				if v988.Position ~= v989 then
					v988.Position = v989
					v_u_128 = v_u_128 + 1
				end
				local v990 = v977 + v974 * v973
				local v991 = v_u_833.w
				local v992 = UDim2.fromOffset(v991, v990)
				if v972.Size ~= v992 then
					v972.Size = v992
					v_u_128 = v_u_128 + 1
				end
				local v993 = v_u_833.scroll
				local v994 = UDim2.new(1, 0, 0, v974 * v973)
				if v993.Size ~= v994 then
					v993.Size = v994
					v_u_128 = v_u_128 + 1
				end
				local v995 = v970.x + 34
				if v995 + v991 > v_u_113 - 4 then
					v995 = v970.x - 34 - v991
				end
				local v996 = v_u_17(4, (v_u_16(v_u_113 - v991 - 4, v995)))
				local v997 = v_u_17(4, (v_u_16(v_u_113 - v990 - 4, v970.y - v977)))
				local v998 = UDim2.new(v996 / v_u_113, 0, v997 / v_u_113, 0)
				if v972.Position ~= v998 then
					v972.Position = v998
					v_u_128 = v_u_128 + 1
				end
				if v972.Visible ~= true then
					v972.Visible = true
					v_u_128 = v_u_128 + 1
				end
				local v999
				if v970.x < v996 then
					v999 = v996
				else
					v999 = v996 + v991
				end
				v_u_93(v_u_833.guide, v970.x, v970.y, v999, v997 + v977 / 2)
				v_u_833.guide.Visible = true
				for _, v1000 in v_u_450 do
					local v1001 = v1000.item
					if not v1001 or v1001.key == v970.key then
						continue
					end
					local v1002 = v1001.x - 12
					local v1003 = v1001.y - 12
					local v1004
					if v1002 < v996 + v991 + 10 and (v1002 + 24 > v996 - 10 and v1003 < v997 + v990 + 10) then
						v1004 = v1003 + 24 > v997 - 10
					else
						v1004 = false
					end
					if not v1004 then
						continue
					end
					local v1005 = v1000.frame
					if v1005.Visible == false then
						continue
					end
					v1005.Visible = false
					v_u_128 = v_u_128 + 1
				end
				for _, v1006 in v_u_453 do
					local v1007 = v1006.frame
					local v1008 = v1007.Position.X.Scale * v_u_113
					local v1009 = v1007.Position.Y.Scale * v_u_113
					local v1010 = v1007.Size.X.Offset
					local v1011 = v1007.Size.Y.Offset
					local v1012
					if v1008 < v996 + v991 + 10 and (v1008 + v1010 > v996 - 10 and v1009 < v997 + v990 + 10) then
						v1012 = v1009 + v1011 > v997 - 10
					else
						v1012 = false
					end
					if not v1012 or v1007.Visible == false then
						continue
					end
					v1007.Visible = false
					v_u_128 = v_u_128 + 1
				end
				if v_u_694 and v_u_694.frame.Visible then
					local v1013 = v_u_694.frame
					if v1013.Visible ~= false then
						v1013.Visible = false
						v_u_128 = v_u_128 + 1
					end
				end
			else
				v_u_116.closeList()
			end
		else
			return
		end
	end
	function v_u_116.openList(p1015, p1016) -- name: openList
		-- upvalues: (ref) v_u_833, (copy) v_u_877, (ref) v_u_834, (ref) v_u_457, (ref) v_u_12, (ref) v_u_11, (copy) v_u_927, (copy) v_u_968, (copy) v_u_116
		if not v_u_833 then
			v_u_877()
		end
		v_u_834 = {
			["ids"] = p1015,
			["anchor"] = p1016
		}
		local v1017 = {}
		for _, v1018 in v_u_457 do
			v1017[v1018.id] = v1018
		end
		local v1019 = nil
		local v1020 = true
		for _, v1021 in p1015 do
			local v1022 = v1017[v1021]
			if not (v1022 and v1022.place) then
				continue
			end
			if v1019 == nil then
				v1019 = v1022.place
			else
				if v1019 == v1022.place then
					continue
				end
				v1020 = false
			end
		end
		local v1023 = v_u_12.setText
		local v1024 = v_u_833.hl
		local v1025 = v_u_11.listHead
		if not v1020 then
			v1019 = nil
		end
		v1023(v1024, v1025(v1019))
		v_u_12.setText(v_u_833.hr, v_u_11.areaCount(#p1015))
		for v1026, v1027 in p1015 do
			local v1028 = v_u_833.rows[v1026]
			if not v1028 then
				v1028 = v_u_927(v1026)
				v_u_833.rows[v1026] = v1028
			end
			local v1029 = v1017[v1027]
			if not v1029 then
				continue
			end
			v_u_968(v1028, v1029, v1029.viewing == true)
		end
		for v1030 = #p1015 + 1, #v_u_833.rows do
			v_u_833.rows[v1030].btn.Visible = false
		end
		v_u_116.dirty = true
		if v_u_116.isShown and v_u_116.isShown() then
			v_u_116.drawNow()
		end
		v_u_116.wake()
	end
	function v_u_116.closeList() -- name: closeList
		-- upvalues: (ref) v_u_834, (ref) v_u_833
		if v_u_834 then
			v_u_834 = nil
			if v_u_833 then
				v_u_833.frame.Visible = false
				v_u_833.guide.Visible = false
			end
		end
	end
	function v_u_116.listOpen() -- name: listOpen
		-- upvalues: (ref) v_u_834
		return v_u_834 ~= nil
	end
	function v_u_116.listParts() -- name: listParts
		-- upvalues: (ref) v_u_833, (ref) v_u_834
		if not (v_u_833 and v_u_834) then
			return nil
		end
		local v1031 = {}
		for v1032 = 1, #v_u_834.ids do
			local v1033 = v_u_833.rows[v1032]
			if not v1033 then
				continue
			end
			local v1034 = v1033.btn
			table.insert(v1031, v1034)
		end
		return {
			["frame"] = v_u_833.frame,
			["scroll"] = v_u_833.scroll,
			["rows"] = v1031
		}
	end
	local function v_u_1049(p1035) -- name: paintFuzz
		-- upvalues: (ref) v_u_454, (ref) v_u_47, (copy) v_u_226, (ref) v_u_15, (ref) v_u_12, (ref) v_u_113, (ref) v_u_16, (ref) v_u_17, (ref) v_u_128, (ref) v_u_19
		if not v_u_454 then
			v_u_454 = v_u_47(v_u_226, "FuzzCircle", 10, {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.93,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_15.accent
			})
			v_u_454:SetAttribute("Fuzz", true)
			local v1036 = v_u_454
			local v1037 = v_u_15.text2
			v_u_12.stroke(v1036, v1037, 1, 0.6)
		end
		local v1038 = v_u_17(4, (v_u_16(p1035.r * 2, v_u_113 * 4)))
		local v1039 = v_u_454
		local v1040 = p1035.x
		local v1041 = p1035.y
		local v1042 = UDim2.new(v1040 / v_u_113, 0, v1041 / v_u_113, 0)
		if v1039.Position ~= v1042 then
			v1039.Position = v1042
			v_u_128 = v_u_128 + 1
		end
		local v1043 = v_u_454
		local v1044 = UDim2.fromOffset(v1038, v1038)
		if v1043.Size ~= v1044 then
			v1043.Size = v1044
			v_u_128 = v_u_128 + 1
		end
		local v1045 = p1035.x - v_u_113 / 2
		local v1046 = p1035.y - v_u_113 / 2
		local v1047 = v_u_454
		local v1048 = v_u_19(v1045 * v1045 + v1046 * v1046) + v1038 / 2 <= v_u_113 / 2 - 4
		if v1047.Visible ~= v1048 then
			v1047.Visible = v1048
			v_u_128 = v_u_128 + 1
		end
	end
	local v_u_1050 = v_u_110.dots
	local v_u_1051 = nil
	local v_u_1052 = 0
	local v_u_1053 = nil
	local v_u_1054 = nil
	local v_u_1055 = 0
	local v_u_1056 = 0
	local v_u_1057 = 0
	local v_u_1058 = {
		["lat0"] = -999,
		["lon0"] = -999,
		["z"] = -1
	}
	local v_u_1059 = {
		["lat0"] = v_u_123.lat0,
		["lon0"] = v_u_123.lon0,
		["z"] = v_u_123.z
	}
	local v_u_1060 = nil
	local v_u_1061 = false
	local v_u_1062 = ""
	local v_u_1063 = -10
	local v_u_1064 = false
	local v_u_1065 = 0
	local v_u_1066 = false
	local v_u_1067 = false
	v_u_116.moving = false
	v_u_116.dirty = true
	v_u_116.pinsDirty = true
	local v_u_1068 = {
		["on"] = false,
		["t"] = 0,
		["total"] = 0,
		["conns"] = nil,
		["dotsMoving"] = false,
		["lastEnd"] = "",
		["checks"] = 0,
		["started"] = 0,
		["conns"] = {}
	}
	local v_u_1069 = {
		["f"] = nil,
		["tw"] = nil
	}
	local v_u_1070 = {
		["id"] = nil,
		["t"] = -10
	}
	local v_u_1071 = {
		["errs"] = nil,
		["warned"] = nil,
		["fatal"] = false,
		["errs"] = {},
		["warned"] = {}
	}
	local v_u_1072 = v_u_115()
	local function v_u_1076() -- name: driftBlocked
		-- upvalues: (ref) v_u_27, (copy) v_u_112, (copy) v_u_114, (ref) v_u_1066, (copy) v_u_110, (ref) v_u_1050
		if v_u_27.DRIFT_DEG_S <= 0 then
			return "off"
		end
		if v_u_112 ~= "high" then
			return "tier"
		end
		if v_u_114() then
			return "reduced"
		end
		if not v_u_1066 then
			return "hidden"
		end
		if v_u_110.modal and v_u_110.modal() then
			return "modal"
		end
		if v_u_110.switchOn and v_u_110.switchOn() == false then
			return "switch"
		end
		if v_u_110.govTripped and v_u_110.govTripped() then
			return "governor"
		end
		if v_u_1050 and v_u_1050.stats then
			local v1073 = v_u_1050.stats
			local v1074, v1075 = pcall(v1073)
			if v1074 and (type(v1075) == "table" and (v1075.thin or 0) ~= 0) then
				return "thin"
			end
		end
		return nil
	end
	function v_u_116.endDrift(p1077) -- name: endDrift
		-- upvalues: (copy) v_u_1068, (ref) v_u_1050, (copy) v_u_116
		if v_u_1068.on then
			v_u_1068.on = false
			v_u_1068.lastEnd = p1077 or "end"
			for _, v1078 in v_u_1068.conns do
				v1078:Disconnect()
			end
			table.clear(v_u_1068.conns)
			if v_u_1068.dotsMoving then
				v_u_1068.dotsMoving = false
				if v_u_1050 and (v_u_1050.setMoving and not v_u_116.moving) then
					v_u_1050.setMoving(false)
				end
			end
			v_u_116.dirty = true
			v_u_116.wake()
		end
	end
	function v_u_116.startDrift() -- name: startDrift
		-- upvalues: (copy) v_u_1068, (copy) v_u_110, (ref) v_u_107, (copy) v_u_1076, (ref) v_u_6, (copy) v_u_116
		if v_u_1068.on then
			return true
		end
		local v1079
		if v_u_110.session then
			v1079 = v_u_110.session.driftDone == true
		else
			v1079 = v_u_107
		end
		if v1079 then
			v_u_1068.lastEnd = "seen"
			return false
		end
		local v1080 = v_u_1076()
		if v1080 then
			v_u_1068.lastEnd = v1080
			return false
		end
		if v_u_110.session then
			v_u_110.session.driftDone = true
		else
			v_u_107 = true
		end
		local v1081 = v_u_1068
		local v1082 = v_u_1068
		local v1083 = v_u_1068
		v_u_1068.on = true
		v1081.t = 0
		v1082.total = 0
		v1083.lastEnd = "running"
		local v1084 = v_u_1068
		v1084.started = v1084.started + 1
		local v1085 = v_u_1068.conns
		local v1086 = v_u_6.InputBegan
		local function v1087()
			-- upvalues: (ref) v_u_116
			v_u_116.endDrift("input")
		end
		table.insert(v1085, v1086:Connect(v1087))
		local v1088 = v_u_1068.conns
		local v1089 = v_u_6.InputChanged
		local function v1092(p1090)
			-- upvalues: (ref) v_u_116
			local v1091 = p1090.UserInputType
			if v1091 == Enum.UserInputType.MouseWheel or v1091 == Enum.UserInputType.Gamepad1 and p1090.Position.Magnitude > 0.2 then
				v_u_116.endDrift("input")
			end
		end
		table.insert(v1088, v1089:Connect(v1092))
		local v1093 = v_u_1068.conns
		local v1094 = v_u_6.WindowFocusReleased
		local function v1095()
			-- upvalues: (ref) v_u_116
			v_u_116.endDrift("focus")
		end
		table.insert(v1093, v1094:Connect(v1095))
		v_u_116.wake()
		return true
	end
	local function v_u_1102() -- name: hintText
		-- upvalues: (copy) v_u_110, (ref) v_u_11, (copy) v_u_114, (copy) v_u_115, (ref) v_u_1065
		if v_u_110.frozenWhy then
			local v1096 = v_u_110.frozenWhy
			local v1097, v1098 = pcall(v1096)
			if v1097 then
				if v1098 == "search" then
					return v_u_11.SEARCH
				end
				if v1098 == "member" then
					return v_u_11.MEMBER
				end
			end
		end
		local v1099 = not v_u_110.inputKind and "mouse" or v_u_110.inputKind()
		local v1100
		if v_u_110.keyName then
			v1100 = v_u_110.keyName("interact")
		else
			v1100 = nil
		end
		local v1101
		if v_u_110.keyName then
			v1101 = v_u_110.keyName("back")
		else
			v1101 = nil
		end
		if v1099 == "pad" then
			if v_u_110.padOwns and not v_u_110.padOwns() then
				return v_u_11.padAwayHint(v1101)
			else
				return v_u_11.padHint(v1100)
			end
		elseif v_u_114() and v_u_115() < v_u_1065 then
			return v_u_11.HINT.reduced
		else
			return v_u_11.hint(v1099, false, v1100)
		end
	end
	function v_u_116.refreshHint() -- name: paintHint
		-- upvalues: (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_113, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1066, (ref) v_u_311
		local v1103 = v_u_1102()
		local v1104 = v_u_316
		if v1104.Text ~= v1103 then
			v1104.Text = v1103
			v_u_128 = v_u_128 + 1
		end
		local v1105 = v_u_1064
		if v1105 then
			v1105 = v_u_113 < 600 and true or v_u_111 == "phone"
		end
		local v1106 = v_u_303
		local v1107 = not v1105
		if v1107 then
			v1107 = v_u_1066
		end
		if v1106.Visible ~= v1107 then
			v1106.Visible = v1107
			v_u_128 = v_u_128 + 1
		end
		v_u_311()
	end
	local function v_u_1140()
		-- upvalues: (copy) v_u_110, (copy) v_u_303, (ref) v_u_113, (ref) v_u_128, (ref) v_u_55, (ref) v_u_4, (copy) v_u_279, (copy) v_u_284, (copy) v_u_285, (ref) v_u_16, (ref) v_u_27, (copy) v_u_316
		if (v_u_110.hintRoom or 0) >= 34 then
			v_u_303.AnchorPoint = Vector2.new(0.5, 0)
			local v1108 = v_u_303
			local v1109 = UDim2.fromOffset(v_u_113 / 2, v_u_113 + 4)
			if v1108.Position ~= v1109 then
				v1108.Position = v1109
				v_u_128 = v_u_128 + 1
			end
		else
			local v1110 = v_u_284
			local v1111 = v_u_279.AbsoluteSize.X
			if v1111 <= 1 then
				local v1112
				if v1110 then
					local v_u_1113 = v1110.Text
					local v_u_1114 = v1110.FontFace
					local v_u_1115 = v1110.TextSize
					local v1116 = tostring(v_u_1115)
					local v1117 = v_u_1114.Family
					local v1118 = v_u_1113 .. "|" .. v1116 .. "|" .. tostring(v1117)
					v1112 = v_u_55[v1118]
					if not v1112 then
						local v_u_1119 = 100000
						local function v1121()
							-- upvalues: (copy) v_u_1113, (copy) v_u_1114, (copy) v_u_1115, (copy) v_u_1119, (ref) v_u_4
							local v1120 = Instance.new("GetTextBoundsParams")
							v1120.Text = v_u_1113
							v1120.Font = v_u_1114
							v1120.Size = v_u_1115
							v1120.Width = v_u_1119
							return v_u_4:GetTextBoundsAsync(v1120)
						end
						local v1122, v1123 = pcall(v1121)
						if not v1122 then
							v1123 = nil
						end
						if v1123 then
							v1112 = v1123.X
						else
							v1112 = #v_u_1113 * v_u_1115 * 0.6
						end
						v_u_55[v1118] = v1112
					end
				else
					v1112 = 0
				end
				v1111 = v1112 + 14
			end
			local v1124 = v_u_285.Size.X.Offset
			local v1125 = v1124 <= 1 and 150 or v1124
			local v1126 = v_u_16(v_u_113 / 2 - 6 - v1111 - 6, v_u_113 / 2 - 6 - v1125 - 6) * 2
			local v1127 = v1126 < 150
			local v1128 = v_u_27.HINT_MAX_PX
			if v1127 then
				v1126 = v_u_113 - 12
			end
			local v1129 = v_u_16(v1128, v1126)
			if v_u_303:GetAttribute("MaxW") ~= v1129 then
				v_u_303:SetAttribute("MaxW", v1129)
				local v1130 = v_u_303:FindFirstChildOfClass("UISizeConstraint")
				if v1130 then
					v1130.MaxSize = Vector2.new(v1129, v_u_27.HINT_MAX_H)
				end
				local v1131 = v_u_316:FindFirstChild("HintLimit")
				if v1131 then
					local v1132 = Vector2.new
					local v1133 = v1129 - 6
					local v1134 = v_u_316.TextSize * 1.25
					v1131.MaxSize = v1132(v1133, math.ceil(v1134) * 2 + 2)
				end
			end
			v_u_303.AnchorPoint = Vector2.new(0.5, 1)
			local v1135 = v_u_303
			local v1136 = UDim2.fromOffset
			local v1137 = v_u_113 / 2
			local v1138
			if v1127 then
				v1138 = v_u_113 - 6 - 28 - 4
			else
				v1138 = v_u_113 - 6
			end
			local v1139 = v1136(v1137, v1138)
			if v1135.Position ~= v1139 then
				v1135.Position = v1139
				v_u_128 = v_u_128 + 1
			end
		end
	end
	local function v_u_1179() -- name: paintChrome
		-- upvalues: (ref) v_u_14, (ref) v_u_113, (ref) v_u_123, (ref) v_u_9, (copy) v_u_290, (ref) v_u_11, (ref) v_u_128, (ref) v_u_55, (ref) v_u_4, (ref) v_u_18, (ref) v_u_17, (copy) v_u_292, (copy) v_u_296, (copy) v_u_300, (copy) v_u_285, (ref) v_u_1140, (copy) v_u_338, (ref) v_u_27, (copy) v_u_116, (copy) v_u_363, (copy) v_u_110, (copy) v_u_327, (copy) v_u_115, (ref) v_u_1063, (ref) v_u_1066, (copy) v_u_324
		local v1141 = v_u_14.R1 * (v_u_113 / 2) * v_u_123.z
		local v1142 = v_u_9.scaleBar(v1141, 70, 150)
		local v1143 = v_u_290
		local v1144 = v_u_11.scaleText(v1142.km)
		if v1143.Text ~= v1144 then
			v1143.Text = v1144
			v_u_128 = v_u_128 + 1
		end
		local v_u_1145 = v_u_290.Text
		local v_u_1146 = v_u_290.FontFace
		local v_u_1147 = v_u_290.TextSize
		local v1148 = tostring(v_u_1147)
		local v1149 = v_u_1146.Family
		local v1150 = v_u_1145 .. "|" .. v1148 .. "|" .. tostring(v1149)
		local v1151 = v_u_55[v1150]
		if not v1151 then
			local v_u_1152 = 100000
			local function v1154()
				-- upvalues: (copy) v_u_1145, (copy) v_u_1146, (copy) v_u_1147, (copy) v_u_1152, (ref) v_u_4
				local v1153 = Instance.new("GetTextBoundsParams")
				v1153.Text = v_u_1145
				v1153.Font = v_u_1146
				v1153.Size = v_u_1147
				v1153.Width = v_u_1152
				return v_u_4:GetTextBoundsAsync(v1153)
			end
			local v1155, v1156 = pcall(v1154)
			if not v1155 then
				v1156 = nil
			end
			if v1156 then
				v1151 = v1156.X
			else
				v1151 = #v_u_1145 * v_u_1147 * 0.6
			end
			v_u_55[v1150] = v1151
		end
		local v1157 = v_u_17(2, (v_u_18(v1142.px + 0.5)))
		v_u_290.Position = UDim2.fromOffset(0, 0)
		v_u_292.Position = UDim2.fromOffset(v1151 + 10, 14)
		local v1158 = v_u_292
		local v1159 = UDim2.fromOffset(v1157, 1)
		if v1158.Size ~= v1159 then
			v1158.Size = v1159
			v_u_128 = v_u_128 + 1
		end
		v_u_296.Position = UDim2.fromOffset(v1151 + 10, 14)
		v_u_300.Position = UDim2.fromOffset(v1151 + 10 + v1157 - 1, 14)
		v_u_285.Size = UDim2.fromOffset(v1151 + 10 + v1157 + 12 - 12, 28)
		v_u_285.AutomaticSize = Enum.AutomaticSize.None
		v_u_285.Size = UDim2.fromOffset(v1151 + v1157 + 10 + 12, 28)
		v_u_1140()
		local v1160 = v_u_123.z >= v_u_14.Z_MAX - 0.001
		local v1161 = v_u_123.z <= v_u_14.Z_MIN + 0.001
		for _, v1162 in {
			{ v_u_338.zoomIn, v1160 },
			{ v_u_338.zoomOut, v1161 }
		} do
			local v1163 = v1162[1]
			local v1164 = v1162[2]
			local v1165 = v1164 and 0.5 or v_u_27.PLATE_ALPHA
			if v1163.BackgroundTransparency ~= v1165 then
				v1163.BackgroundTransparency = v1165
				v_u_128 = v_u_128 + 1
			end
			for _, v1166 in v1163:GetChildren() do
				if not v1166:IsA("Frame") then
					continue
				end
				for _, v1167 in v1166:GetDescendants() do
					if not v1167:IsA("Frame") then
						continue
					end
					local v1168 = v1164 and 0.5 or 0
					if v1167.BackgroundTransparency == v1168 then
						continue
					end
					v1167.BackgroundTransparency = v1168
					v_u_128 = v_u_128 + 1
				end
			end
		end
		local v1169 = not v_u_116.homeNext and "home" or v_u_116.homeNext()
		if v_u_363.shown ~= v1169 then
			v_u_363.shown = v1169
			local v1170 = v_u_363.pin
			local v1171 = v1169 == "home"
			if v1170.Visible ~= v1171 then
				v1170.Visible = v1171
				v_u_128 = v_u_128 + 1
			end
			local v1172 = v_u_363.globe
			local v1173 = v1169 == "world"
			if v1172.Visible ~= v1173 then
				v1172.Visible = v1173
				v_u_128 = v_u_128 + 1
			end
		end
		local v1174 = not v_u_110.inputKind and "mouse" or v_u_110.inputKind()
		local v1175 = v_u_327
		local v1176
		if v1174 == "touch" and v_u_115() - v_u_1063 < 1 then
			v1176 = v_u_1066
		else
			v1176 = false
		end
		if v1175.Visible ~= v1176 then
			v1175.Visible = v1176
			v_u_128 = v_u_128 + 1
		end
		local v1177 = v_u_324
		local v1178 = v1174 == "pad" and (not v_u_110.padOwns or v_u_110.padOwns())
		if v1178 then
			v1178 = v_u_1066
		end
		if v1177.Visible ~= v1178 then
			v1177.Visible = v1178
			v_u_128 = v_u_128 + 1
		end
	end
	function v_u_116.refreshChrome() -- name: refreshChrome
		-- upvalues: (ref) v_u_8, (ref) v_u_377, (copy) v_u_415, (copy) v_u_1179, (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_113, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1066, (ref) v_u_1140
		if v_u_8.touch(40) ~= v_u_377 then
			v_u_415()
		end
		v_u_1179()
		local v1180 = v_u_1102()
		local v1181 = v_u_316
		if v1181.Text ~= v1180 then
			v1181.Text = v1180
			v_u_128 = v_u_128 + 1
		end
		local v1182 = v_u_1064
		if v1182 then
			v1182 = v_u_113 < 600 and true or v_u_111 == "phone"
		end
		local v1183 = v_u_303
		local v1184 = not v1182
		if v1184 then
			v1184 = v_u_1066
		end
		if v1183.Visible ~= v1184 then
			v1183.Visible = v1184
			v_u_128 = v_u_128 + 1
		end
		v_u_1140()
	end
	local function v_u_1194(p1185, p1186) -- name: coordUpdate
		-- upvalues: (copy) v_u_110, (ref) v_u_1060, (ref) v_u_9, (ref) v_u_123, (ref) v_u_113, (ref) v_u_14, (ref) v_u_11, (ref) v_u_1062, (ref) v_u_1057, (ref) v_u_27, (ref) v_u_119, (copy) v_u_284, (ref) v_u_128, (ref) v_u_1140, (ref) v_u_1061
		local v1187 = nil
		local v1188 = nil
		local v1189, v1190
		if (not v_u_110.inputKind and "mouse" or v_u_110.inputKind()) == "mouse" and v_u_1060 then
			local v1191
			v1189, v1190, v1191 = v_u_9.fromLens(v_u_123, v_u_113 / 2, v_u_113 / 2, v_u_113 / 2, v_u_1060.x, v_u_1060.y)
			if v_u_14.DEPTH_MIN > v1191 then
				v1190 = v1188
				v1189 = v1187
			end
		else
			v1190 = v1188
			v1189 = v1187
		end
		if v1189 == nil then
			v1189 = v_u_123.lat0
			v1190 = v_u_123.lon0
		end
		local v1192 = v_u_9.fmtCoord(v1189, v1190) .. "   " .. v_u_11.zoomText(v_u_123.z)
		if v1192 ~= v_u_1062 and (p1186 or p1185 - v_u_1057 >= 1 / v_u_27.COORD_HZ) then
			v_u_1062 = v1192
			v_u_1057 = p1185
			v_u_119 = v_u_119 + 1
			local v1193 = v_u_284
			if v1193.Text ~= v1192 then
				v1193.Text = v1192
				v_u_128 = v_u_128 + 1
			end
			v_u_1140()
		end
		v_u_1061 = v1192 ~= v_u_1062
	end
	local function v_u_1229() -- name: placeAreas
		-- upvalues: (copy) v_u_416, (ref) v_u_418, (copy) v_u_448, (ref) v_u_14, (ref) v_u_113, (ref) v_u_123, (ref) v_u_9, (copy) v_u_417, (ref) v_u_27, (ref) v_u_19, (ref) v_u_128, (ref) v_u_18
		if v_u_416 then
			v_u_448()
			local v1195 = v_u_14.R1 * (v_u_113 / 2) * v_u_123.z
			local v1196, v1197, v1198, v1199, v1200, v1201, v1202, v1203 = v_u_9.matrix(v_u_123.lat0 * 0.017453292519943295, v_u_123.lon0 * 0.017453292519943295)
			local v1204 = v_u_113 / 2 - 6
			local v1205 = {}
			for _, v1206 in v_u_417 do
				local v1207 = v1206.def
				local v1208
				if v_u_123.z >= v1207.zmin and v_u_123.z <= v1207.zmax then
					v1208 = (v1207.kind == "continent" or v1207.kind == "ocean") and true or v_u_123.z >= v_u_27.AREA_ZOOM_MIN_OTHER
				else
					v1208 = false
				end
				local v1209, v1210, v1211
				if v1208 then
					v1209, v1210, v1211 = v_u_9.project(v1196, v1197, v1198, v1199, v1200, v1201, v1202, v1203, v1195, v_u_113 / 2, v_u_113 / 2, v1207.lat * 0.017453292519943295, v1207.lon * 0.017453292519943295)
					local v1212 = v1209 - v_u_113 / 2
					local v1213 = v1210 - v_u_113 / 2
					local v1214 = v_u_19(v1212 * v1212 + v1213 * v1213)
					if v1211 >= 0.35 then
						v1208 = v1214 + v_u_19((v1206.w / 2) ^ 2 + (v1206.h / 2) ^ 2) <= v1204
					else
						v1208 = false
					end
				else
					v1211 = 0
					v1209 = 0
					v1210 = 0
				end
				if v1208 then
					local v1215 = v_u_9.smoothstep(0.35, 0.55, v1211)
					local v1216 = v1206.plate
					local v1217 = Vector2.new(0.5, 0.5)
					if v1216.AnchorPoint ~= v1217 then
						v1216.AnchorPoint = v1217
						v_u_128 = v_u_128 + 1
					end
					local v1218 = v1206.plate
					local v1219 = UDim2.fromOffset(v_u_18(v1209 + 0.5), (v_u_18(v1210 + 0.5)))
					if v1218.Position ~= v1219 then
						v1218.Position = v1219
						v_u_128 = v_u_128 + 1
					end
					local v1220 = v1206.plate
					local v1221 = v_u_27.AREA_ALPHA
					local v1222 = 1 - v1215
					local v1223 = v1221 + (1 - v1221) * v1222
					if v1220.BackgroundTransparency ~= v1223 then
						v1220.BackgroundTransparency = v1223
						v_u_128 = v_u_128 + 1
					end
					local v1224 = v1206.lbl
					local v1225 = (1 - v1215) * 0.9 + 0.1
					if v1224.TextTransparency ~= v1225 then
						v1224.TextTransparency = v1225
						v_u_128 = v_u_128 + 1
					end
					local v1226 = v1206.plate
					if v1226.Visible ~= true then
						v1226.Visible = true
						v_u_128 = v_u_128 + 1
					end
					local v1227 = {
						["x"] = v1209 - v1206.w / 2,
						["y"] = v1210 - v1206.h / 2,
						["w"] = v1206.w,
						["h"] = v1206.h
					}
					table.insert(v1205, v1227)
				else
					local v1228 = v1206.plate
					if v1228.Visible == false then
						continue
					end
					v1228.Visible = false
					v_u_128 = v_u_128 + 1
				end
			end
			v_u_418 = v1205
		else
			v_u_418 = {}
		end
	end
	local function v_u_1253(p1230) -- name: measureItem
		-- upvalues: (ref) v_u_8, (ref) v_u_11, (ref) v_u_55, (ref) v_u_4, (ref) v_u_10, (ref) v_u_18, (ref) v_u_16
		local v1231 = p1230.pin
		local v1232 = v_u_8.styles.caps
		local v_u_1233 = v_u_8.phoneText(v1232.size, "caption")
		local v1234 = v_u_8.track
		local v1235 = string.upper
		local v1236
		if v1231.hidden then
			v1236 = v_u_11.UNKNOWN
		else
			local v1237 = v1231.name or v1231.id
			v1236 = tostring(v1237)
		end
		local v_u_1238 = v1234(v1235(v1236), v1232.track)
		local v_u_1239 = v1232.font
		local v1240 = tostring(v_u_1233)
		local v1241 = v_u_1239.Family
		local v1242 = v_u_1238 .. "|" .. v1240 .. "|" .. tostring(v1241)
		local v1243 = v_u_55[v1242]
		if not v1243 then
			local v_u_1244 = 100000
			local function v1246()
				-- upvalues: (copy) v_u_1238, (copy) v_u_1239, (copy) v_u_1233, (copy) v_u_1244, (ref) v_u_4
				local v1245 = Instance.new("GetTextBoundsParams")
				v1245.Text = v_u_1238
				v1245.Font = v_u_1239
				v1245.Size = v_u_1233
				v1245.Width = v_u_1244
				return v_u_4:GetTextBoundsAsync(v1245)
			end
			local v1247, v1248 = pcall(v1246)
			if not v1247 then
				v1248 = nil
			end
			if v1248 then
				v1243 = v1248.X
			else
				v1243 = #v_u_1238 * v_u_1233 * 0.6
			end
			v_u_55[v1242] = v1243
		end
		local v1249 = v1243 + 18
		local v1250
		if v1231.hidden then
			v1250 = "hidden"
		else
			local v1251 = v1231.state
			v1250 = v1251 == "test" and "test" or ((v1251 == "raids" or (v1251 == "locked" or v1251 == "quest")) and "locked" or (v1251 == "soon" and "soon" or "open"))
		end
		local v1252 = v1249 + (v1250 == "locked" and 18 or 0)
		return v_u_16(v_u_10.TUNING.LABEL_W_MAX, (v_u_18(v1252 + 0.5))), v_u_10.TUNING.LABEL_H
	end
	function v_u_200.placeTicks(p1254, p1255, p1256, p1257) -- name: placeTicks
		-- upvalues: (ref) v_u_113, (ref) v_u_9, (ref) v_u_123, (ref) v_u_24, (ref) v_u_23, (ref) v_u_18, (ref) v_u_17, (ref) v_u_111, (ref) v_u_27, (copy) v_u_200, (ref) v_u_15, (ref) v_u_128
		local v1258 = {}
		local v1259
		if p1257 then
			local v1260 = v_u_113 / 2 - 3
			local v1261 = nil
			local v1262 = nil
			local v1263 = nil
			for v1264 = 0, 120 do
				local v1265 = v1264 % 120 * 2 * 3.141592653589793 / 120
				local v1266, v1267 = v_u_9.unproject(v_u_123.lat0, v_u_123.lon0, v1260 * v_u_24(v1265) / p1254, -(v1260 * v_u_23(v1265)) / p1254)
				if v1261 then
					local v1268 = v_u_18(v1261 / p1255)
					local v1269 = v_u_18(v1266 / p1255)
					if v1268 ~= v1269 then
						local v1270 = (v_u_17(v1268, v1269) * p1255 - v1261) / (v1266 - v1261)
						v1258[#v1258 + 1] = v1262 + v1270 * ((v1264 == 120 and 6.283185307179586 or v1265) - v1262)
					end
					local v1271 = v1263 + (v1267 - v1263 + 540) % 360 - 180
					local v1272 = v_u_18(v1263 / p1255)
					local v1273 = v_u_18(v1271 / p1255)
					if v1272 ~= v1273 then
						local v1274 = (v_u_17(v1272, v1273) * p1255 - v1263) / (v1271 - v1263)
						v1258[#v1258 + 1] = v1262 + v1274 * ((v1264 == 120 and 6.283185307179586 or v1265) - v1262)
					end
				end
				v1263 = v1267
				v1262 = v1265
				v1261 = v1266
			end
			local v1275
			if v_u_111 == "phone" then
				v1275 = v_u_27.TICK_MAX_PHONE
			else
				v1275 = v_u_27.TICK_MAX
			end
			if v1275 < #v1258 then
				table.sort(v1258)
				v1259 = {}
				for v1276 = 1, v1275 do
					v1259[v1276] = v1258[v_u_18((v1276 - 1) * #v1258 / v1275) + 1]
				end
			else
				v1259 = v1258
			end
		else
			v1259 = v1258
		end
		for v1277, v1278 in v1259 do
			local v1279 = v_u_200.tpool[v1277]
			if not v1279 then
				local v1280 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["Name"] = "Tk" .. v1277,
					["BackgroundColor3"] = v_u_15.text2,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Size"] = UDim2.fromOffset(1, 8)
				}
				local v1281 = v_u_200.layer
				v1279 = Instance.new("Frame")
				for v1282, v1283 in v1280 do
					v1279[v1282] = v1283
				end
				if v1281 then
					v1279.Parent = v1281
				end
				v_u_200.tpool[v1277] = v1279
			end
			local v1284 = v_u_113 / 2 - 3 - 4
			local v1285 = UDim2.fromOffset(v_u_113 / 2 + v_u_18(v1284 * v_u_24(v1278) + 0.5), v_u_113 / 2 + v_u_18(v1284 * v_u_23(v1278) + 0.5))
			if v1279.Position ~= v1285 then
				v1279.Position = v1285
				v_u_128 = v_u_128 + 1
			end
			local v1286 = math.deg(v1278) + 90
			if v1279.Rotation ~= v1286 then
				v1279.Rotation = v1286
				v_u_128 = v_u_128 + 1
			end
			local v1287 = v_u_17(0.2, p1256 - 0.25)
			if v1279.BackgroundTransparency ~= v1287 then
				v1279.BackgroundTransparency = v1287
				v_u_128 = v_u_128 + 1
			end
			if v1279.Visible == true then
				continue
			end
			v1279.Visible = true
			v_u_128 = v_u_128 + 1
		end
		for v1288 = #v1259 + 1, v_u_200.tshown do
			local v1289 = v_u_200.tpool[v1288]
			if v1289.Visible == false then
				continue
			end
			v1289.Visible = false
			v_u_128 = v_u_128 + 1
		end
		v_u_200.tshown = #v1259
	end
	local function v_u_1365() -- name: placeRef
		-- upvalues: (copy) v_u_200, (ref) v_u_27, (ref) v_u_123, (ref) v_u_9, (ref) v_u_111, (ref) v_u_14, (ref) v_u_113, (ref) v_u_16, (ref) v_u_20, (ref) v_u_24, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (ref) v_u_15, (ref) v_u_128
		local v1290 = v_u_200.pool
		local v1291 = v_u_27.CROSS_FADE[1]
		local v1292 = v_u_27.CROSS_FADE[2]
		local v1293 = v_u_123.z
		local v1294 = {}
		local v1295, v1296, v1297
		if v1291 <= v1293 then
			v1295 = 1 - 0.55 * v_u_9.smoothstep(v1291, v1292, v1293)
			local v1298
			if v_u_111 == "phone" then
				v1298 = v_u_27.CROSS_MAX_PHONE
			else
				v1298 = v_u_27.CROSS_MAX
			end
			local v1299 = v_u_14.R1 * (v_u_113 / 2) * v1293
			local v1300 = v_u_113 / 2 - 6
			local v1301 = v1293 < 12 and 2 or (v1293 < 24 and 1 or 0.5)
			local v1302 = v_u_16(1, v1300 / v1299)
			local v1303 = math.asin(v1302)
			local v1304 = math.deg(v1303)
			local v1305 = v1299 * v1301 * 0.017453292519943295
			local v1306 = 1
			while v1306 < 16 and 3.141592653589793 * v1300 * v1300 / (v1305 * v1306) ^ 2 > v1298 * 0.85 do
				v1306 = v1306 + 1
			end
			local v1307 = v1301 * v1306
			local v1308, v1309, v1310, v1311, v1312, v1313, v1314, v1315 = v_u_9.matrix(v_u_123.lat0 * 0.017453292519943295, v_u_123.lon0 * 0.017453292519943295)
			local v1316 = v1304 / v_u_17(0.15, (v_u_24(v_u_16(85, v_u_20(v_u_123.lat0) + v1304) * 0.017453292519943295)))
			local v1317 = (v_u_123.lat0 - v1304) / v1307
			local v1318 = math.ceil(v1317)
			local v1319 = v_u_18((v_u_123.lat0 + v1304) / v1307)
			local v1320 = (v_u_123.lon0 - v1316) / v1307
			local v1321 = math.ceil(v1320)
			local v1322 = v_u_18((v_u_123.lon0 + v1316) / v1307)
			if v1319 - v1318 <= 40 and v1322 - v1321 <= 80 then
				v1296 = v1307
				v1297 = v1299
				for v1323 = v1318, v1319 do
					local v1324 = v1323 * v1307
					if v_u_20(v1324) > 84 then
						continue
					end
					for v1325 = v1321, v1322 do
						local v1326, v1327, v1328 = v_u_9.project(v1308, v1309, v1310, v1311, v1312, v1313, v1314, v1315, v1299, v_u_113 / 2, v_u_113 / 2, v1324 * 0.017453292519943295, v1325 * v1307 * 0.017453292519943295)
						local v1329 = v1326 - v_u_113 / 2
						local v1330 = v1327 - v_u_113 / 2
						local v1331 = v_u_19(v1329 * v1329 + v1330 * v1330)
						if v1328 <= 0.1 or v1331 > v1300 - 10 then
							continue
						end
						v1294[#v1294 + 1] = {
							["x"] = v1326,
							["y"] = v1327,
							["r"] = v1331
						}
					end
				end
			else
				v1296 = v1307
				v1297 = v1299
			end
			if v1298 < #v1294 then
				table.sort(v1294, function(p1332, p1333)
					return p1332.r < p1333.r
				end)
				for v1334 = #v1294, v1298 + 1, -1 do
					v1294[v1334] = nil
				end
			end
		else
			v1295 = 1
			v1297 = nil
			v1296 = nil
		end
		for v1335, v1336 in v1294 do
			local v1337 = v1290[v1335]
			if not v1337 then
				local v1338 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Visible"] = false,
					["Name"] = "Ch" .. v1335,
					["BackgroundColor3"] = v_u_15.text2,
					["Size"] = UDim2.fromOffset(9, 1)
				}
				local v1339 = v_u_200.layer
				local v1340 = Instance.new("Frame")
				v1337 = {}
				for v1341, v1342 in v1338 do
					v1340[v1341] = v1342
				end
				if v1339 then
					v1340.Parent = v1339
				end
				v1337.h = v1340
				local v1343 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Visible"] = false,
					["Name"] = "Cv" .. v1335,
					["BackgroundColor3"] = v_u_15.text2,
					["Size"] = UDim2.fromOffset(1, 9)
				}
				local v1344 = v_u_200.layer
				local v1345 = Instance.new("Frame")
				for v1346, v1347 in v1343 do
					v1345[v1346] = v1347
				end
				if v1344 then
					v1345.Parent = v1344
				end
				v1337.v = v1345
				v1290[v1335] = v1337
			end
			local v1348 = v_u_18(v1336.x + 0.5)
			local v1349 = v_u_18(v1336.y + 0.5)
			local v1350 = v1337.h
			local v1351 = UDim2.fromOffset(v1348 - 4, v1349)
			if v1350.Position ~= v1351 then
				v1350.Position = v1351
				v_u_128 = v_u_128 + 1
			end
			local v1352 = v1337.v
			local v1353 = UDim2.fromOffset(v1348, v1349 - 4)
			if v1352.Position ~= v1353 then
				v1352.Position = v1353
				v_u_128 = v_u_128 + 1
			end
			local v1354 = v1337.h
			if v1354.BackgroundTransparency ~= v1295 then
				v1354.BackgroundTransparency = v1295
				v_u_128 = v_u_128 + 1
			end
			local v1355 = v1337.v
			if v1355.BackgroundTransparency ~= v1295 then
				v1355.BackgroundTransparency = v1295
				v_u_128 = v_u_128 + 1
			end
			local v1356 = v1337.h
			if v1356.Visible ~= true then
				v1356.Visible = true
				v_u_128 = v_u_128 + 1
			end
			local v1357 = v1337.v
			if v1357.Visible == true then
				continue
			end
			v1357.Visible = true
			v_u_128 = v_u_128 + 1
		end
		for v1358 = #v1294 + 1, v_u_200.shown do
			local v1359 = v1290[v1358].h
			if v1359.Visible ~= false then
				v1359.Visible = false
				v_u_128 = v_u_128 + 1
			end
			local v1360 = v1290[v1358].v
			if v1360.Visible == false then
				continue
			end
			v1360.Visible = false
			v_u_128 = v_u_128 + 1
		end
		v_u_200.shown = #v1294
		local v1361 = v_u_200.placeTicks
		local v1362 = v1297 or 1
		local v1363 = v1296 or 1
		local v1364 = v_u_27.TICK_ON
		if v1364 then
			v1364 = v1296 ~= nil
		end
		v1361(v1362, v1363, v1295, v1364)
	end
	local function v_u_1418(p1366) -- name: render
		-- upvalues: (ref) v_u_456, (ref) v_u_10, (ref) v_u_457, (ref) v_u_123, (ref) v_u_122, (copy) v_u_455, (copy) v_u_1229, (copy) v_u_1365, (ref) v_u_463, (ref) v_u_462, (ref) v_u_14, (ref) v_u_113, (ref) v_u_418, (ref) v_u_389, (ref) v_u_461, (ref) v_u_111, (copy) v_u_1253, (copy) v_u_774, (copy) v_u_110, (copy) v_u_450, (copy) v_u_116, (copy) v_u_449, (ref) v_u_27, (copy) v_u_527, (copy) v_u_627, (ref) v_u_128, (copy) v_u_1049, (copy) v_u_832, (copy) v_u_453, (copy) v_u_452, (copy) v_u_649, (copy) v_u_693, (copy) v_u_451, (ref) v_u_15, (copy) v_u_222, (ref) v_u_93, (ref) v_u_16, (ref) v_u_454, (ref) v_u_694, (copy) v_u_1014
		if debug.profilebegin then
			debug.profilebegin("Globe.pins")
		end
		v_u_456 = v_u_10.layout(v_u_457, v_u_123, v_u_122, v_u_455)
		v_u_1229()
		v_u_1365()
		v_u_463 = nil
		if v_u_462 then
			local v1367 = (v_u_14.CATCH_PX or 56) ^ 2
			for _, v1368 in v_u_456.items do
				local v1369 = v1368.x - v_u_113 / 2
				local v1370 = v1368.y - v_u_113 / 2
				if v1369 * v1369 + v1370 * v1370 > v1367 then
					continue
				end
				v1367 = v1369 * v1369 + v1370 * v1370
				v_u_463 = v1368.key
			end
		end
		local v1371 = v_u_418
		if #v_u_389 > 0 then
			v1371 = table.clone(v_u_418)
			for _, v1372 in v_u_389 do
				table.insert(v1371, v1372)
			end
		end
		v_u_10.placeLabels(v_u_456.items, v_u_123, v_u_122, {
			["plates"] = v1371,
			["hovered"] = v_u_461,
			["focus"] = v_u_463,
			["phone"] = v_u_111 == "phone",
			["now"] = p1366,
			["state"] = v_u_455,
			["measure"] = v_u_1253,
			["cardH"] = v_u_774,
			["noCard"] = v_u_110.noCard == true
		})
		local v1373 = {}
		local v1374 = {}
		local v1375 = 0
		for _, v1376 in v_u_456.items do
			v1373[v1376.key] = true
		end
		for v1377, v1378 in v_u_450 do
			if v1373[v1377] then
				continue
			end
			v_u_450[v1377] = nil
			v1378.key = nil
			v1378.item = nil
			for _, v1379 in v1378.breath do
				v1379:Cancel()
			end
			v1378.breath = {}
			v_u_116.stopHover(v1378)
			v1378.hovOn = false
			v1378.hov.Visible = false
			v1378.frame.Visible = false
		end
		for _, v1380 in v_u_449 do
			if v1380.key then
				continue
			end
			table.insert(v1374, v1380)
		end
		local v1381 = 0
		local v1382 = {}
		local v1383 = false
		local v1384 = false
		for _, v1385 in v_u_456.items do
			local v1386 = v_u_450[v1385.key]
			if not v1386 then
				v1386 = table.remove(v1374)
				if not v1386 and #v_u_449 < v_u_27.POOL_SETS then
					v1386 = v_u_527(#v_u_449 + 1)
					local v1387 = v_u_449
					table.insert(v1387, v1386)
				end
				if v1386 then
					v_u_450[v1385.key] = v1386
					v1386.key = v1385.key
				end
			end
			if v1386 then
				v1375 = v1375 + 1
				v1386.item = v1385
				v_u_627(v1386, v1385)
				v_u_116.hoverPaint(v1386, v1385)
				local v1388 = v1386.frame
				local v1389 = v1385.x
				local v1390 = v1385.y
				local v1391 = UDim2.new(v1389 / v_u_113, 0, v1390 / v_u_113, 0)
				if v1388.Position ~= v1391 then
					v1388.Position = v1391
					v_u_128 = v_u_128 + 1
				end
				local v1392 = v1386.frame
				if v1392.Visible ~= true then
					v1392.Visible = true
					v_u_128 = v_u_128 + 1
				end
				v1386.shapeLabel = nil
				if v1385.kind == "fuzz" then
					v_u_1049(v1385)
					v1383 = true
				end
			end
			local v1393 = v1385.label
			if v1393 then
				if v1393.card then
					v_u_832(v1385)
					v1384 = true
				else
					local v1394 = v_u_453[v1385.key]
					if not v1394 then
						for _, v1395 in v_u_452 do
							if v1395.key then
								continue
							end
							v1394 = v1395
						end
						if not v1394 and #v_u_452 < v_u_27.POOL_PLAQUES then
							v1394 = v_u_649(#v_u_452 + 1)
							local v1396 = v_u_452
							table.insert(v1396, v1394)
						end
						if v1394 then
							v1394.key = v1385.key
							v_u_453[v1385.key] = v1394
							v1394.sig = ""
						end
					end
					if v1394 then
						v_u_693(v1394, v1385)
						v1382[v1385.key] = true
					end
				end
				if v1393.card or v1393.bar then
					v1381 = v1381 + 1
					if v1381 <= v_u_27.POOL_GUIDES then
						local v1397
						if v1393.x > v1385.x then
							v1397 = v1393.x
						else
							v1397 = v1393.x + v1393.w
						end
						local v1398 = v_u_451[v1381]
						if not v1398 then
							local v1399 = {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Visible"] = false,
								["Name"] = "G" .. v1381,
								["BackgroundColor3"] = v_u_15.line
							}
							local v1400 = v_u_222
							v1398 = Instance.new("Frame")
							for v1401, v1402 in v1399 do
								v1398[v1401] = v1402
							end
							if v1400 then
								v1398.Parent = v1400
							end
							v_u_451[v1381] = v1398
						end
						v_u_93(v1398, v1385.x, v1385.y, v1397, v1393.y + v_u_16(v1393.h / 2, 15))
						local v1403
						if v1393.card == true then
							v1403 = not v_u_116.moving
						else
							v1403 = false
						end
						if v1398.Visible ~= v1403 then
							v1398.Visible = v1403
							v_u_128 = v_u_128 + 1
						end
					end
				end
			end
			if v1385.kind ~= "pin" then
				continue
			end
			local _ = v1385.spread
		end
		for v1404, v1405 in v_u_453 do
			if v1382[v1404] then
				continue
			end
			v_u_453[v1404] = nil
			v1405.key = nil
			v1405.frame.Visible = false
		end
		if not v1383 and v_u_454 then
			v_u_454.Visible = false
		end
		if not v1384 and v_u_694 then
			v_u_694.frame.Visible = false
		end
		for _, v1406 in v_u_456.guides do
			v1381 = v1381 + 1
			if v1381 > v_u_27.POOL_GUIDES then
				continue
			end
			local v1407 = v_u_451[v1381]
			if not v1407 then
				local v1408 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Visible"] = false,
					["Name"] = "G" .. v1381,
					["BackgroundColor3"] = v_u_15.line
				}
				local v1409 = v_u_222
				v1407 = Instance.new("Frame")
				for v1410, v1411 in v1408 do
					v1407[v1410] = v1411
				end
				if v1409 then
					v1407.Parent = v1409
				end
				v_u_451[v1381] = v1407
			end
			v_u_93(v1407, v1406.x1, v1406.y1, v1406.x2, v1406.y2)
			if v1407.Visible == true then
				continue
			end
			v1407.Visible = true
			v_u_128 = v_u_128 + 1
		end
		for v1412 = v1381 + 1, #v_u_451 do
			local v1413 = v_u_451[v1412]
			if v1413.Visible == false then
				continue
			end
			v1413.Visible = false
			v_u_128 = v_u_128 + 1
		end
		v_u_1014(v_u_456)
		for _, v1414 in v_u_449 do
			local v1415
			if v1414.key == nil then
				v1415 = false
			else
				v1415 = v1414.key == v_u_463
			end
			local v1416 = v1414.vring
			local v1417 = v1415 or v1414.item and (v1414.item.viewing == true and not v1414.item.deploy)
			if v1417 then
				v1417 = v1414.key ~= nil
			end
			if v1416.Visible == v1417 then
				continue
			end
			v1416.Visible = v1417
			v_u_128 = v_u_128 + 1
		end
		if debug.profileend then
			debug.profileend()
		end
	end
	local function v_u_1426() -- name: applyBody
		-- upvalues: (ref) v_u_14, (ref) v_u_113, (ref) v_u_123, (ref) v_u_16, (copy) v_u_145, (ref) v_u_128, (copy) v_u_161, (copy) v_u_1069
		local v1419 = v_u_16(v_u_113, 2 * (v_u_14.R1 * (v_u_113 / 2) * v_u_123.z))
		local v1420 = v_u_145
		local v1421 = UDim2.fromOffset(v1419, v1419)
		if v1420.Size ~= v1421 then
			v1420.Size = v1421
			v_u_128 = v_u_128 + 1
		end
		local v1422 = v_u_161
		local v1423 = UDim2.fromOffset(v1419, v1419)
		if v1422.Size ~= v1423 then
			v1422.Size = v1423
			v_u_128 = v_u_128 + 1
		end
		if v_u_1069.f then
			local v1424 = v_u_1069.f
			local v1425 = UDim2.fromOffset(v1419, v1419)
			if v1424.Size ~= v1425 then
				v1424.Size = v1425
				v_u_128 = v_u_128 + 1
			end
		end
	end
	function v_u_116.setView(p1427, p1428, p1429) -- name: setView
		-- upvalues: (copy) v_u_116, (ref) v_u_1051, (ref) v_u_1053, (ref) v_u_14, (ref) v_u_123, (ref) v_u_16, (ref) v_u_17, (ref) v_u_9
		v_u_116.endDrift("view")
		v_u_1051 = nil
		v_u_1053 = nil
		local v1430 = -v_u_14.PITCH_MAX
		local v1431 = v_u_14.PITCH_MAX
		local v1432 = v_u_123.lat0
		if type(p1427) == "number" and (p1427 == p1427 and (p1427 ~= (1 / 0) and p1427 ~= (-1 / 0))) then
			v1432 = p1427
		end
		local v1433 = v_u_17(v1430, (v_u_16(v1431, v1432)))
		local v1434 = v_u_123.lon0
		if type(p1428) == "number" and (p1428 == p1428 and (p1428 ~= (1 / 0) and p1428 ~= (-1 / 0))) then
			v1434 = p1428
		end
		local v1435 = v_u_14.Z_MIN
		local v1436 = v_u_14.Z_MAX
		local v1437 = v_u_123.z
		if type(p1429) == "number" and (p1429 == p1429 and (p1429 ~= (1 / 0) and p1429 ~= (-1 / 0))) then
			v1437 = p1429
		end
		local v1438 = v_u_17(v1435, (v_u_16(v1436, v1437)))
		local v1439 = v_u_123
		local v1440 = v_u_123
		local v1441 = v_u_123
		local v1442 = v_u_9.wrapLon(v1434)
		v1439.lat0 = v1433
		v1440.lon0 = v1442
		v1441.z = v1438
		v_u_116.dirty = true
		v_u_116.wake()
	end
	function v_u_116.getView() -- name: getView
		-- upvalues: (ref) v_u_123
		return {
			["lat0"] = v_u_123.lat0,
			["lon0"] = v_u_123.lon0,
			["z"] = v_u_123.z
		}
	end
	function v_u_116.cancelFlight() -- name: cancelFlight
		-- upvalues: (ref) v_u_1051, (ref) v_u_1053
		v_u_1051 = nil
		v_u_1053 = nil
	end
	function v_u_116.setViewRaw(p1443, p1444, p1445) -- name: setViewRaw
		-- upvalues: (copy) v_u_116, (ref) v_u_123, (ref) v_u_9
		v_u_116.endDrift("input")
		local v1446 = v_u_123
		local v1447 = v_u_123
		local v1448 = v_u_123
		local v1449 = v_u_9.wrapLon(p1444)
		v1446.lat0 = p1443
		v1447.lon0 = v1449
		v1448.z = p1445
		v_u_116.dirty = true
		v_u_116.wake()
	end
	function v_u_116.flying() -- name: flying
		-- upvalues: (ref) v_u_1051, (ref) v_u_1053
		return v_u_1051 ~= nil and true or v_u_1053 ~= nil
	end
	function v_u_116.flyTo(p1450, _) -- name: flyTo
		-- upvalues: (copy) v_u_116, (ref) v_u_14, (ref) v_u_113, (ref) v_u_1053, (copy) v_u_114, (ref) v_u_1051, (ref) v_u_123, (ref) v_u_9, (ref) v_u_1052, (copy) v_u_115
		v_u_116.endDrift("fly")
		local v1451 = v_u_14.R1 * (v_u_113 / 2)
		v_u_1053 = nil
		if v_u_114() then
			v_u_1051 = nil
			local v1452 = p1450.lat0
			local v1453 = p1450.lon0
			local v1454 = p1450.z
			local v1455 = v_u_123
			local v1456 = v_u_123
			local v1457 = v_u_123
			local v1458 = v_u_9.wrapLon(v1453)
			v1455.lat0 = v1452
			v1456.lon0 = v1458
			v1457.z = v1454
			v_u_116.dirty = true
			v_u_116.wake()
		else
			v_u_1051 = v_u_9.flightPlan({
				["lat0"] = v_u_123.lat0,
				["lon0"] = v_u_123.lon0,
				["z"] = v_u_123.z
			}, {
				["lat0"] = p1450.lat0,
				["lon0"] = p1450.lon0,
				["z"] = p1450.z
			}, v1451)
			v_u_1052 = v_u_115()
			v_u_116.wake()
		end
	end
	function v_u_116.homeView() -- name: homeView
		-- upvalues: (ref) v_u_457, (ref) v_u_10, (ref) v_u_122, (ref) v_u_123, (ref) v_u_14
		for _, v1460 in v_u_457 do
			if not v1460.deploy then
				continue
			end
		end
		local v1460 = v_u_457[1]
		local v1461 = v_u_10.homeZoom
		local v1462 = v_u_457
		local v1463
		if v1460 then
			v1463 = v1460.id
		else
			v1463 = v1460
		end
		local v1464 = v1461(v1462, v1463, v_u_122)
		if not v1460 then
			return {
				["lat0"] = 20,
				["lon0"] = nil,
				["z"] = nil,
				["lon0"] = v_u_123.lon0,
				["z"] = v_u_14.Z_MIN
			}
		end
		local v1465, v1466
		if v1460.hidden and v1460.fuzz then
			v1465 = v1460.fuzz.lat
			v1466 = v1460.fuzz.lon
		else
			v1465 = v1460.geo.lat
			v1466 = v1460.geo.lon
		end
		return {
			["lat0"] = v1465,
			["lon0"] = v1466,
			["z"] = v1464
		}
	end
	function v_u_116.worldView() -- name: worldView
		-- upvalues: (ref) v_u_457, (ref) v_u_123, (ref) v_u_14
		for _, v1468 in v_u_457 do
			if not v1468.deploy then
				continue
			end
		end
		local v1468 = v_u_457[1]
		local v1469 = v_u_123.lon0
		if v1468 then
			if v1468.hidden and v1468.fuzz then
				local _ = v1468.fuzz.lat
				v1469 = v1468.fuzz.lon
			else
				local _ = v1468.geo.lat
				v1469 = v1468.geo.lon
			end
		end
		return {
			["lat0"] = 20,
			["lon0"] = nil,
			["z"] = nil,
			["lon0"] = v1469,
			["z"] = v_u_14.Z_MIN
		}
	end
	local function v_u_1473(p1470, p1471) -- name: near
		-- upvalues: (ref) v_u_9, (ref) v_u_17, (ref) v_u_22, (ref) v_u_20
		local v1472
		if v_u_9.angleBetween({
			["lat"] = p1470.lat0,
			["lon"] = p1470.lon0
		}, {
			["lat"] = p1471.lat0,
			["lon"] = p1471.lon0
		}) / 0.017453292519943295 < 0.6 then
			v1472 = v_u_20((v_u_22(v_u_17(p1470.z, 1e-6) / v_u_17(p1471.z, 1e-6)))) < 0.04
		else
			v1472 = false
		end
		return v1472
	end
	function v_u_116.homeNext() -- name: homeNext
		-- upvalues: (copy) v_u_116, (ref) v_u_1051, (copy) v_u_1473, (ref) v_u_123
		local v1474 = v_u_116.homeView()
		return v_u_1051 and v_u_1473(v_u_1051.to, v1474) and "world" or (v_u_1473({
			["lat0"] = v_u_123.lat0,
			["lon0"] = v_u_123.lon0,
			["z"] = v_u_123.z
		}, v1474) and "world" or "home")
	end
	function v_u_116.homeTip() -- name: homeTip
		-- upvalues: (copy) v_u_116, (ref) v_u_11
		if v_u_116.homeNext() == "home" then
			return v_u_11.TOOLTIPS.home
		else
			return v_u_11.TOOLTIPS.world
		end
	end
	function v_u_116.setHover(p1475) -- name: setHover
		-- upvalues: (ref) v_u_456, (ref) v_u_461, (copy) v_u_116
		local v1476 = nil
		if p1475 ~= nil then
			for _, v1477 in v_u_456.items do
				if v1477.kind ~= "pin" or v1477.id ~= p1475 then
					continue
				end
				v1476 = v1477.key
			end
		end
		if v_u_461 ~= v1476 then
			v_u_461 = v1476
			v_u_116.dirty = true
			v_u_116.wake()
		end
	end
	function v_u_116.hintNow() -- name: hintNow
		-- upvalues: (copy) v_u_1102
		return v_u_1102()
	end
	function v_u_116.homeStep() -- name: homeStep
		-- upvalues: (copy) v_u_116
		local v1478 = v_u_116.homeNext()
		local v1479 = v_u_116.flyTo
		local v1480
		if v1478 == "world" then
			v1480 = v_u_116.worldView()
		else
			v1480 = v_u_116.homeView()
		end
		v1479(v1480)
		return v1478
	end
	function v_u_116.zoomStep(p1481) -- name: zoomStep
		-- upvalues: (copy) v_u_116, (ref) v_u_1053, (ref) v_u_123, (ref) v_u_14, (ref) v_u_16, (ref) v_u_17, (copy) v_u_114, (ref) v_u_1051, (ref) v_u_9
		v_u_116.endDrift("input")
		local v1482 = v_u_1053 or v_u_123.z
		local v1483 = v_u_14.Z_MIN
		local v1484 = v_u_14.Z_MAX
		local v1485
		if p1481 > 0 then
			v1485 = v_u_14.STEP
		else
			v1485 = 1 / v_u_14.STEP
		end
		local v1486 = v_u_17(v1483, (v_u_16(v1484, v1482 * v1485)))
		if v_u_114() then
			v_u_1051 = nil
			v_u_1053 = nil
			local v1487 = v_u_123.lat0
			local v1488 = v_u_123.lon0
			local v1489 = v_u_123
			local v1490 = v_u_123
			local v1491 = v_u_123
			local v1492 = v_u_9.wrapLon(v1488)
			v1489.lat0 = v1487
			v1490.lon0 = v1492
			v1491.z = v1486
			v_u_116.dirty = true
		else
			v_u_1051 = nil
			v_u_1053 = v1486
		end
		v_u_116.wake()
	end
	function v_u_116.intro() -- name: intro
		-- upvalues: (copy) v_u_116, (ref) v_u_457, (copy) v_u_110, (ref) v_u_10, (ref) v_u_122, (ref) v_u_9, (ref) v_u_14, (ref) v_u_113, (copy) v_u_114, (ref) v_u_1051, (ref) v_u_123, (ref) v_u_1065, (copy) v_u_115, (ref) v_u_27, (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1066, (ref) v_u_1140, (ref) v_u_121, (ref) v_u_17, (ref) v_u_22, (ref) v_u_1052
		v_u_116.endDrift("intro")
		for _, v1494 in v_u_457 do
			if not v1494.deploy then
				continue
			end
		end
		local v1494 = v_u_457[1]
		local v1495 = {
			["lat"] = 40.8,
			["lon"] = -85.8
		}
		if v_u_110.deployGeo then
			v1495 = v_u_110.deployGeo
		elseif v1494 then
			local v1496, v1497
			if v1494.hidden and v1494.fuzz then
				v1496 = v1494.fuzz.lat
				v1497 = v1494.fuzz.lon
			else
				v1496 = v1494.geo.lat
				v1497 = v1494.geo.lon
			end
			v1495.lat = v1496
			v1495.lon = v1497
		end
		local v1498 = v_u_10.homeZoom
		local v1499 = v_u_457
		if v1494 then
			v1494 = v1494.id
		end
		local v1500 = v1498(v1499, v1494, v_u_122)
		local v1501 = v_u_9.introPlan(v1495, v1500, v_u_14.R1 * (v_u_113 / 2))
		if v_u_114() then
			v_u_1051 = nil
			local v1502 = v1501.to.lat0
			local v1503 = v1501.to.lon0
			local v1504 = v1501.to.z
			local v1505 = v_u_123
			local v1506 = v_u_123
			local v1507 = v_u_123
			local v1508 = v_u_9.wrapLon(v1503)
			v1505.lat0 = v1502
			v1506.lon0 = v1508
			v1507.z = v1504
			v_u_116.dirty = true
			v_u_1065 = v_u_115() + v_u_27.HINT_REDUCED_S
			local v1509 = v_u_1102()
			local v1510 = v_u_316
			if v1510.Text ~= v1509 then
				v1510.Text = v1509
				v_u_128 = v_u_128 + 1
			end
			local v1511 = v_u_1064
			if v1511 then
				v1511 = v_u_113 < 600 and true or v_u_111 == "phone"
			end
			local v1512 = v_u_303
			local v1513 = not v1511
			if v1513 then
				v1513 = v_u_1066
			end
			if v1512.Visible ~= v1513 then
				v1512.Visible = v1513
				v_u_128 = v_u_128 + 1
			end
			v_u_1140()
			task.delay(v_u_27.HINT_REDUCED_S + 0.05, function()
				-- upvalues: (ref) v_u_121, (ref) v_u_1102, (ref) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_113, (ref) v_u_111, (ref) v_u_303, (ref) v_u_1066, (ref) v_u_1140
				if v_u_121 then
					local v1514 = v_u_1102()
					local v1515 = v_u_316
					if v1515.Text ~= v1514 then
						v1515.Text = v1514
						v_u_128 = v_u_128 + 1
					end
					local v1516 = v_u_1064
					if v1516 then
						v1516 = v_u_113 < 600 and true or v_u_111 == "phone"
					end
					local v1517 = v_u_303
					local v1518 = not v1516
					if v1518 then
						v1518 = v_u_1066
					end
					if v1517.Visible ~= v1518 then
						v1517.Visible = v1518
						v_u_128 = v_u_128 + 1
					end
					v_u_1140()
				end
			end)
		else
			local v1519
			if v_u_111 == "phone" then
				v1519 = true
			elseif v_u_110.inputKind == nil then
				v1519 = false
			else
				v1519 = v_u_110.inputKind() == "touch"
			end
			local v1520
			if v1519 then
				v1520 = v_u_17(v1501.dur, v_u_27.INTRO_S_TOUCH)
			else
				v1520 = v1501.dur
			end
			if v1501.to.z > v1501.from.z then
				v1520 = v_u_17(v1520, 1.5707963267948966 * (v_u_22(v1501.to.z) - v_u_22(v1501.from.z)) / v_u_27.INTRO_PEAK_MAX)
			end
			v1501.dur = v1520
			v_u_1051 = v1501
			v_u_1052 = v_u_115()
			local v1521 = v1501.from.lat0
			local v1522 = v1501.from.lon0
			local v1523 = v1501.from.z
			local v1524 = v_u_123
			local v1525 = v_u_123
			local v1526 = v_u_123
			local v1527 = v_u_9.wrapLon(v1522)
			v1524.lat0 = v1521
			v1525.lon0 = v1527
			v1526.z = v1523
			v_u_116.dirty = true
		end
		v_u_116.wake()
	end
	function v_u_116.gesture() -- name: gesture
		-- upvalues: (copy) v_u_116, (ref) v_u_1063, (copy) v_u_115, (ref) v_u_1064, (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_113, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1066, (ref) v_u_1140
		v_u_116.endDrift("input")
		v_u_1063 = v_u_115()
		if not v_u_1064 then
			v_u_1064 = true
			local v1528 = v_u_1102()
			local v1529 = v_u_316
			if v1529.Text ~= v1528 then
				v1529.Text = v1528
				v_u_128 = v_u_128 + 1
			end
			local v1530 = v_u_1064
			if v1530 then
				v1530 = v_u_113 < 600 and true or v_u_111 == "phone"
			end
			local v1531 = v_u_303
			local v1532 = not v1530
			if v1532 then
				v1532 = v_u_1066
			end
			if v1531.Visible ~= v1532 then
				v1531.Visible = v1532
				v_u_128 = v_u_128 + 1
			end
			v_u_1140()
		end
		v_u_116.wake()
	end
	function v_u_116.setPointer(p1533, p1534) -- name: setPointer
		-- upvalues: (ref) v_u_1060, (ref) v_u_1061, (copy) v_u_116
		if p1533 == nil or p1534 == nil then
			v_u_1060 = nil
		else
			v_u_1060 = {
				["x"] = p1533,
				["y"] = p1534
			}
		end
		v_u_1061 = true
		v_u_116.wake()
	end
	function v_u_116.setPadActive(p1535) -- name: setPadActive
		-- upvalues: (ref) v_u_462, (copy) v_u_116
		if v_u_462 ~= p1535 then
			v_u_462 = p1535
			v_u_116.dirty = true
			v_u_116.wake()
		end
	end
	function v_u_116.pulseCross() -- name: pulseCross
		-- upvalues: (copy) v_u_114, (copy) v_u_324, (ref) v_u_3
		if v_u_114() or not v_u_324.Visible then
			return false
		end
		local function v1536()
			-- upvalues: (ref) v_u_3, (ref) v_u_324
			v_u_3:Create(v_u_324, TweenInfo.new(0.09, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
				["Size"] = UDim2.fromOffset(36, 36)
			}):Play()
		end
		return pcall(v1536)
	end
	function v_u_116.focusItem() -- name: focusItem
		-- upvalues: (ref) v_u_463, (ref) v_u_456
		if v_u_463 then
			return v_u_456.byKey[v_u_463]
		else
			return nil
		end
	end
	function v_u_116.items() -- name: items
		-- upvalues: (ref) v_u_456
		return v_u_456
	end
	function v_u_116.pickAt(p1537, p1538, p1539) -- name: pickAt
		-- upvalues: (ref) v_u_10, (ref) v_u_456, (ref) v_u_122
		return v_u_10.pick(v_u_456, p1537, p1538, v_u_122, p1539)
	end
	function v_u_116.pins() -- name: pins
		-- upvalues: (ref) v_u_457
		return v_u_457
	end
	local function v_u_1548(p1540) -- name: flyToPin
		-- upvalues: (ref) v_u_10, (ref) v_u_457, (ref) v_u_122, (copy) v_u_116, (ref) v_u_123, (ref) v_u_17
		local v1541, v1542
		if p1540.hidden and p1540.fuzz then
			v1541 = p1540.fuzz.lat
			v1542 = p1540.fuzz.lon
		else
			v1541 = p1540.geo.lat
			v1542 = p1540.geo.lon
		end
		local v1543 = v_u_10.homeZoom
		local v1544 = v_u_457
		for _, v1546 in v_u_457 do
			if not v1546.deploy then
				continue
			end
		end
		local v1546 = v_u_457[1]
		local v1547 = v1543(v1544, (v1546 or p1540).id, v_u_122)
		v_u_116.flyTo({
			["lat0"] = v1541,
			["lon0"] = v1542,
			["z"] = v_u_17(v_u_123.z, v1547)
		})
	end
	function v_u_116.activateId(p1549, p1550) -- name: activateId
		-- upvalues: (ref) v_u_458, (copy) v_u_110, (copy) v_u_481, (copy) v_u_1070, (copy) v_u_115, (copy) v_u_1548, (ref) v_u_834, (copy) v_u_116
		local v1551 = true
		if v_u_458[p1549] == nil then
			v1551 = false
		elseif v_u_110.pick then
			v1551 = v_u_110.pick(p1549) ~= false
		end
		if not v1551 then
			if p1550 and p1550.inner then
				v_u_481(p1550.inner, 0, 0)
			elseif p1550 and p1550.body then
				v_u_481(p1550.body, 0, 0)
			end
			return false
		end
		local v1552 = v_u_458[p1549]
		if v1552 then
			local v1553 = v_u_1070
			local v1554 = v_u_1070
			local v1555 = v_u_115()
			v1553.id = p1549
			v1554.t = v1555
			v_u_1548(v1552)
		end
		if v_u_834 then
			v_u_116.openList(v_u_834.ids, v_u_834.anchor)
		end
		return true
	end
	function v_u_116.activate(p1556, p1557) -- name: activate
		-- upvalues: (copy) v_u_116, (ref) v_u_834, (ref) v_u_10, (ref) v_u_123, (ref) v_u_122
		v_u_116.endDrift("pick")
		if p1556.kind ~= "cluster" then
			v_u_116.closeList()
			return v_u_116.activateId(p1556.id, p1557)
		end
		if v_u_834 and v_u_834.anchor == p1556.key then
			v_u_116.closeList()
			return true
		end
		local v1558 = v_u_10.tapAction(p1556, {
			["lat0"] = v_u_123.lat0,
			["lon0"] = v_u_123.lon0,
			["z"] = v_u_123.z
		}, v_u_122)
		if v1558.action == "fly" then
			v_u_116.closeList()
			v_u_116.flyTo({
				["lat0"] = v1558.lat,
				["lon0"] = v1558.lon,
				["z"] = v1558.z
			})
		else
			v_u_116.openList(v1558.ids, p1556.key)
		end
		return true
	end
	v_u_338.zoomIn.Activated:Connect(function()
		-- upvalues: (copy) v_u_116
		v_u_116.gesture()
		v_u_116.zoomStep(1)
	end)
	v_u_338.zoomOut.Activated:Connect(function()
		-- upvalues: (copy) v_u_116
		v_u_116.gesture()
		v_u_116.zoomStep(-1)
	end)
	v_u_338.home.Activated:Connect(function()
		-- upvalues: (copy) v_u_116, (copy) v_u_1179
		v_u_116.gesture()
		v_u_116.homeStep()
		v_u_1179()
	end)
	v_u_338.list.Activated:Connect(function()
		-- upvalues: (copy) v_u_116, (copy) v_u_110
		v_u_116.gesture()
		if v_u_110.list then
			v_u_110.list()
		end
	end)
	local function v_u_1632(p1559) -- name: frame
		-- upvalues: (ref) v_u_121, (ref) v_u_120, (copy) v_u_115, (copy) v_u_110, (ref) v_u_1072, (ref) v_u_16, (ref) v_u_1050, (copy) v_u_1068, (copy) v_u_116, (ref) v_u_1051, (ref) v_u_1052, (ref) v_u_9, (ref) v_u_22, (ref) v_u_17, (ref) v_u_23, (ref) v_u_21, (ref) v_u_123, (ref) v_u_1053, (ref) v_u_20, (ref) v_u_14, (ref) v_u_27, (copy) v_u_1076, (copy) v_u_1058, (ref) v_u_1055, (ref) v_u_694, (ref) v_u_1056, (copy) v_u_112, (ref) v_u_1067, (copy) v_u_1426, (copy) v_u_1179, (copy) v_u_1059, (ref) v_u_113, (copy) v_u_1418, (ref) v_u_1061, (copy) v_u_1194, (ref) v_u_1063
		if v_u_121 then
			v_u_120 = v_u_120 + 1
			local v1560 = v_u_115()
			if v_u_110.clock then
				p1559 = v1560 - v_u_1072
			end
			v_u_1072 = v1560
			local v1561 = v_u_16(p1559, 0.05)
			local v1562
			if v_u_1050 == nil then
				v1562 = false
			else
				v1562 = v_u_1050.feed ~= nil
			end
			if v1562 then
				v_u_1050.feed(p1559, v_u_1068.on)
			end
			local v1563 = false
			if v_u_116.inputStep then
				local v1564 = v_u_116.inputStep
				local v1565, v1566 = pcall(v1564, v1561)
				v1563 = v1565 and v1566 and true or v1563
			end
			if v_u_1051 then
				local v1567 = v1560 - v_u_1052
				local v1568 = v_u_9.flightAt(v_u_1051, v1567)
				if v_u_1051.intro and (v1567 < v_u_1051.dur and v_u_1051.to.z > v_u_1051.from.z * 1.0001) then
					local v1569 = v_u_22(v_u_1051.from.z)
					local v1570 = v_u_22(v_u_1051.to.z)
					local v1571 = v_u_23(1.5707963267948966 * v_u_17(0, (v_u_16(1, v1567 / v_u_1051.dur))))
					v1568.z = v_u_21(v1569 + (v1570 - v1569) * v1571 * v1571)
				end
				local v1572 = v1568.lat0
				local v1573 = v1568.lon0
				local v1574 = v1568.z
				local v1575 = v_u_123
				local v1576 = v_u_123
				local v1577 = v_u_123
				local v1578 = v_u_9.wrapLon(v1573)
				v1575.lat0 = v1572
				v1576.lon0 = v1578
				v1577.z = v1574
				v_u_116.dirty = true
				if v_u_1051.dur <= v1567 then
					local v1579 = v_u_1051.intro == true
					v_u_1051 = nil
					if v1579 then
						v_u_116.startDrift()
					end
				else
					v1563 = true
				end
			end
			if v_u_1053 then
				local v1580 = v_u_22(v_u_123.z)
				local v1581 = v_u_22(v_u_1053)
				if v_u_20(v1581 - v1580) < 0.0008 then
					local v1582 = v_u_123.lat0
					local v1583 = v_u_123.lon0
					local v1584 = v_u_1053
					local v1585 = v_u_123
					local v1586 = v_u_123
					local v1587 = v_u_123
					local v1588 = v_u_9.wrapLon(v1583)
					v1585.lat0 = v1582
					v1586.lon0 = v1588
					v1587.z = v1584
					v_u_116.dirty = true
					v_u_1053 = nil
				else
					local v1589 = v1580 + (v1581 - v1580) * (1 - v_u_21(-v_u_14.ZOOM_SMOOTH * v1561))
					local v1590 = v_u_123.lat0
					local v1591 = v_u_123.lon0
					local v1592 = v_u_21(v1589)
					local v1593 = v_u_123
					local v1594 = v_u_123
					local v1595 = v_u_123
					local v1596 = v_u_9.wrapLon(v1591)
					v1593.lat0 = v1590
					v1594.lon0 = v1596
					v1595.z = v1592
					v_u_116.dirty = true
					v1563 = true
				end
			end
			local v1597 = false
			if v_u_1068.on then
				local v1598 = nil
				if v_u_27.DRIFT_FRAME_MAX_S < p1559 then
					v1598 = "slow"
				elseif v_u_1051 or v_u_1053 then
					v1598 = "busy"
				else
					local v1599 = v_u_1068
					v1599.checks = v1599.checks + 1
					if v_u_1068.checks % 8 == 0 then
						v1598 = v_u_1076()
					end
				end
				if v1598 then
					v_u_116.endDrift(v1598)
				else
					local v1600 = v_u_1068
					v1600.t = v1600.t + p1559
					if v_u_1068.t >= v_u_27.DRIFT_MAX_S then
						v_u_116.endDrift("done")
					else
						local v1601 = v_u_27.DRIFT_DEG_S * v_u_27.DRIFT_MAX_S / (v_u_27.DRIFT_MAX_S - v_u_27.DRIFT_FADE_S / 2)
						local v1602 = v_u_27.DRIFT_MAX_S - v_u_27.DRIFT_FADE_S
						if v1602 < v_u_1068.t then
							v1601 = v1601 * (1 - v_u_9.smoothstep(v1602, v_u_27.DRIFT_MAX_S, v_u_1068.t))
						end
						local v1603 = v1601 * p1559
						if v1603 > 0 then
							local v1604 = v_u_123.lat0
							local v1605 = v_u_123.lon0 - v1603
							local v1606 = v_u_123.z
							local v1607 = v_u_123
							local v1608 = v_u_123
							local v1609 = v_u_123
							local v1610 = v_u_9.wrapLon(v1605)
							v1607.lat0 = v1604
							v1608.lon0 = v1610
							v1609.z = v1606
							v_u_116.dirty = true
							local v1611 = v_u_1068
							v1611.total = v1611.total + v1603
							v1597 = true
						end
						v1563 = true
					end
				end
			end
			local v1612 = (v_u_20(v_u_123.lat0 - v_u_1058.lat0) > 1e-7 or v_u_20(v_u_123.lon0 - v_u_1058.lon0) > 1e-7) and true or v_u_20(v_u_123.z - v_u_1058.z) > 1e-7
			local v1613
			if v1612 then
				v1613 = not v1597
			else
				v1613 = v1612
			end
			if v1612 then
				if v1613 then
					v_u_1055 = v1560
					if not v_u_116.moving then
						v_u_116.moving = true
						if v_u_1050 and v_u_1050.setMoving then
							v_u_1050.setMoving(true)
						end
						if v_u_694 then
							v_u_694.frame.Visible = false
						end
					end
				elseif not v_u_1068.dotsMoving then
					v_u_1068.dotsMoving = true
					if v_u_1050 and v_u_1050.setMoving then
						v_u_1050.setMoving(true)
					end
				end
				v_u_116.dirty = true
			end
			local v1614 = (v1560 - v_u_1056) * 1000
			local v1615 = v_u_27.MIN_STEP_MS[v_u_112] or 0
			if v_u_1050 and v_u_1050.stepMs then
				v1615 = v_u_17(v1615, v_u_1050.stepMs())
			end
			local v1616 = v1615 <= v1614
			if (v_u_116.dirty or (v_u_116.pinsDirty or v_u_1067)) and v1616 then
				v_u_1056 = v1560
				if debug.profilebegin then
					debug.profilebegin("Globe.step")
				end
				if v1612 or v_u_116.firstDraw ~= true then
					v_u_1426()
					if v_u_1050 and v_u_1050.setView then
						v_u_1050.setView(v_u_123.lat0, v_u_123.lon0, v_u_123.z)
					end
					local v1617 = v_u_1058
					local v1618 = v_u_1058
					local v1619 = v_u_1058
					local v1620 = v_u_123.lat0
					local v1621 = v_u_123.lon0
					local v1622 = v_u_123.z
					v1617.lat0 = v1620
					v1618.lon0 = v1621
					v1619.z = v1622
					v_u_1179()
				end
				v_u_116.firstDraw = true
				local v1623 = v_u_9.angleBetween({
					["lat"] = v_u_1059.lat0,
					["lon"] = v_u_1059.lon0
				}, {
					["lat"] = v_u_123.lat0,
					["lon"] = v_u_123.lon0
				}) * v_u_14.R1 * (v_u_113 / 2) * v_u_123.z / v_u_17(v1561, 0.001)
				local v1624 = v_u_1059
				local v1625 = v_u_1059
				local v1626 = v_u_1059
				local v1627 = v_u_123.lat0
				local v1628 = v_u_123.lon0
				local v1629 = v_u_123.z
				v1624.lat0 = v1627
				v1625.lon0 = v1628
				v1626.z = v1629
				v_u_1067 = false
				if v_u_1050 and (v_u_1050.step and v_u_1050.step(v1561, v1623, v_u_1068.on or v1562)) then
					v1563 = true
					v_u_1067 = true
				end
				if v_u_116.dirty or v_u_116.pinsDirty then
					v_u_1418(v1560)
				end
				v_u_116.dirty = false
				v_u_116.pinsDirty = false
				if debug.profileend then
					debug.profileend()
				end
			else
				v1563 = (v_u_116.dirty or (v_u_116.pinsDirty or v_u_1067)) and true or v1563
			end
			if v_u_116.moving and (not v1613 and v1560 - v_u_1055 >= v_u_27.REST_S) then
				v_u_116.moving = false
				if v_u_1050 and (v_u_1050.setMoving and not v_u_1068.on) then
					v_u_1050.setMoving(false)
				end
				v_u_116.dirty = true
				v1563 = true
				if v_u_110.onState then
					local v1630 = v_u_110.onState
					local v1631 = v_u_116.getView
					pcall(v1630, v1631())
				end
			end
			if v_u_1061 or v1612 then
				v_u_1194(v1560)
				v1563 = v_u_1061 and true or v1563
			end
			if v1560 - v_u_1063 < 1.05 and (v_u_110.inputKind and v_u_110.inputKind() == "touch") then
				v1563 = true
				if v1560 - v_u_1063 >= 1 then
					v_u_1179()
				end
			end
			if not (v_u_116.moving or v1563) then
				v_u_116.sleep()
			end
		end
	end
	local function v_u_1642(p1633) -- name: guarded
		-- upvalues: (copy) v_u_1632, (copy) v_u_115, (copy) v_u_1071, (ref) v_u_27, (copy) v_u_116, (copy) v_u_110
		local v1634 = v_u_1632
		local v1635, v1636 = pcall(v1634, p1633)
		if not v1635 then
			local v1637 = v_u_115()
			local v1638 = tostring(v1636)
			local v1639 = string.match(v1638, "^[^\n]*") or v1638
			if not v_u_1071.warned[v1639] then
				v_u_1071.warned[v1639] = true
				warn("[globe] frame error: " .. v1638)
			end
			local v1640 = v_u_1071.errs
			table.insert(v1640, v1637)
			while #v_u_1071.errs > 0 and v1637 - v_u_1071.errs[1] > v_u_27.GUARD_WINDOW_S do
				table.remove(v_u_1071.errs, 1)
			end
			if #v_u_1071.errs >= v_u_27.GUARD_ERRORS then
				v_u_1071.fatal = true
				v_u_116.sleep()
				if v_u_110.onFatal then
					local v1641 = v_u_110.onFatal
					pcall(v1641, "step", v1636)
				end
			end
		end
	end
	v_u_116.tick = v_u_1642
	function v_u_116.clearFatal() -- name: clearFatal
		-- upvalues: (copy) v_u_1071, (copy) v_u_116
		v_u_1071.fatal = false
		table.clear(v_u_1071.errs)
		v_u_116.wake()
	end
	function v_u_116.wake() -- name: wake
		-- upvalues: (ref) v_u_1054, (ref) v_u_121, (ref) v_u_1066, (copy) v_u_1071, (ref) v_u_2, (copy) v_u_1642
		if not v_u_1054 and (v_u_121 and (v_u_1066 and not v_u_1071.fatal)) then
			v_u_1054 = v_u_2.Heartbeat:Connect(v_u_1642)
		end
	end
	function v_u_116.sleep() -- name: sleep
		-- upvalues: (ref) v_u_1054
		if v_u_1054 then
			v_u_1054:Disconnect()
			v_u_1054 = nil
		end
	end
	function v_u_116.connCount() -- name: connCount
		-- upvalues: (ref) v_u_1054
		return v_u_1054 and 1 or 0
	end
	function v_u_116.sync(p1643) -- name: sync
		-- upvalues: (ref) v_u_459, (copy) v_u_110, (ref) v_u_10, (ref) v_u_460, (ref) v_u_458, (ref) v_u_454, (copy) v_u_114, (copy) v_u_226, (ref) v_u_3, (ref) v_u_27, (copy) v_u_466, (ref) v_u_457, (ref) v_u_8, (ref) v_u_11, (ref) v_u_55, (ref) v_u_4, (copy) v_u_116, (ref) v_u_1066, (copy) v_u_1070, (copy) v_u_115, (ref) v_u_1063, (copy) v_u_1548, (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_113, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1140
		if p1643 == nil then
			p1643 = v_u_459 or (not v_u_110.pins and {} or v_u_110.pins())
		end
		local v1644 = true
		for _, v1645 in p1643 do
			if type(v1645) == "table" then
				continue
			end
			v1644 = false
		end
		if not v1644 then
			p1643 = {}
			for _, v1646 in p1643 do
				if type(v1646) ~= "table" then
					continue
				end
				table.insert(p1643, v1646)
			end
		end
		local v1647 = v_u_10.hash(p1643)
		if v_u_460 == v1647 then
			return false
		end
		for _, v1648 in p1643 do
			local v1649 = v_u_458[v1648.id]
			if not v1649 or (not v1649.hidden or (v1648.hidden or (not v_u_454 or (not v_u_454.Visible or v_u_114())))) then
				continue
			end
			local v_u_1650 = v_u_454:Clone()
			v_u_1650.Parent = v_u_226
			local v1651 = v_u_3:Create(v_u_1650, TweenInfo.new(v_u_27.REVEAL_S, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
				["Size"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = UDim2.fromOffset(4, 4)
			})
			local v1652 = v_u_466
			v1652.other = v1652.other + 1
			v1651.Completed:Once(function()
				-- upvalues: (ref) v_u_466, (copy) v_u_1650
				local v1653 = v_u_466
				v1653.other = v1653.other - 1
				v_u_1650:Destroy()
			end)
			v1651:Play()
		end
		v_u_460 = v1647
		v_u_457 = p1643
		v_u_458 = {}
		local v1654 = v_u_8.styles.caps
		for _, v1655 in v_u_457 do
			v_u_458[v1655.id] = v1655
			local v1656 = v_u_8.track
			local v1657 = string.upper
			local v1658
			if v1655.hidden then
				v1658 = v_u_11.UNKNOWN
			else
				local v1659 = v1655.name or v1655.id
				v1658 = tostring(v1659)
			end
			local v_u_1660 = v1656(v1657(v1658), v1654.track)
			local v_u_1661 = v1654.font
			local v_u_1662 = v_u_8.phoneText(v1654.size, "caption")
			local v1663 = tostring(v_u_1662)
			local v1664 = v_u_1661.Family
			local v1665 = v_u_1660 .. "|" .. v1663 .. "|" .. tostring(v1664)
			if v_u_55[v1665] then
				continue
			end
			local v_u_1666 = 100000
			local function v1668()
				-- upvalues: (copy) v_u_1660, (copy) v_u_1661, (copy) v_u_1662, (copy) v_u_1666, (ref) v_u_4
				local v1667 = Instance.new("GetTextBoundsParams")
				v1667.Text = v_u_1660
				v1667.Font = v_u_1661
				v1667.Size = v_u_1662
				v1667.Width = v_u_1666
				return v_u_4:GetTextBoundsAsync(v1667)
			end
			local v1669, v1670 = pcall(v1668)
			if not v1669 then
				v1670 = nil
			end
			local v1671
			if v1670 then
				v1671 = v1670.X
			else
				v1671 = #v_u_1660 * v_u_1662 * 0.6
			end
			v_u_55[v1665] = v1671
		end
		for _, v1673 in v_u_457 do
			if not v1673.deploy then
				continue
			end
		end
		local v1673 = v_u_457[1]
		if v1673 and (v_u_116.lastDeploy and (v_u_116.lastDeploy ~= v1673.id and v_u_1066)) then
			local v1674
			if v_u_1070.id == nil or v_u_1070.id == v1673.id then
				v1674 = false
			else
				v1674 = v_u_115() - v_u_1070.t < 30
			end
			local v1675 = v_u_115() - v_u_1063 > 3
			if v1675 or v1674 then
				v_u_1548(v1673)
			end
			if v1674 or v1675 then
				v_u_1070.id = nil
			end
		end
		local v1676 = v_u_116
		if v1673 then
			v1673 = v1673.id
		end
		v1676.lastDeploy = v1673
		local v1677 = v_u_1102()
		local v1678 = v_u_316
		if v1678.Text ~= v1677 then
			v1678.Text = v1677
			v_u_128 = v_u_128 + 1
		end
		local v1679 = v_u_1064
		if v1679 then
			v1679 = v_u_113 < 600 and true or v_u_111 == "phone"
		end
		local v1680 = v_u_303
		local v1681 = not v1679
		if v1681 then
			v1681 = v_u_1066
		end
		if v1680.Visible ~= v1681 then
			v1680.Visible = v1681
			v_u_128 = v_u_128 + 1
		end
		v_u_1140()
		v_u_116.pinsDirty = true
		v_u_116.wake()
		return true
	end
	function v_u_116.setFake(p1682) -- name: setFake
		-- upvalues: (ref) v_u_10, (ref) v_u_459, (ref) v_u_460, (copy) v_u_116
		if p1682 and p1682 > 0 then
			v_u_459 = v_u_10.fake(p1682)
		else
			v_u_459 = nil
		end
		v_u_460 = nil
		v_u_116.sync()
	end
	function v_u_116.setSize(p1683, p1684) -- name: setSize
		-- upvalues: (ref) v_u_113, (ref) v_u_111, (copy) v_u_415, (ref) v_u_1050, (copy) v_u_449, (copy) v_u_116
		v_u_113 = p1683
		if p1684 then
			v_u_111 = p1684
		end
		v_u_415()
		if v_u_1050 and v_u_1050.setGeometry then
			v_u_1050.setGeometry(v_u_113 / 2, v_u_113 / 2, v_u_113 / 2)
		end
		for _, v1685 in v_u_449 do
			v1685.sig = ""
		end
		v_u_116.dirty = true
		v_u_116.firstDraw = false
		v_u_116.wake()
	end
	function v_u_116.isShown() -- name: isShown
		-- upvalues: (ref) v_u_1066
		return v_u_1066
	end
	function v_u_116.drawNow() -- name: drawNow
		-- upvalues: (copy) v_u_1426, (copy) v_u_1179, (copy) v_u_1418, (copy) v_u_115, (copy) v_u_116
		v_u_1426()
		v_u_1179()
		v_u_1418(v_u_115())
		v_u_116.dirty = true
	end
	function v_u_116.show(p1686) -- name: show
		-- upvalues: (ref) v_u_1066, (copy) v_u_127, (copy) v_u_448, (ref) v_u_1050, (copy) v_u_114, (ref) v_u_460, (copy) v_u_116, (copy) v_u_449, (copy) v_u_1102, (copy) v_u_316, (ref) v_u_128, (ref) v_u_1064, (ref) v_u_113, (ref) v_u_111, (copy) v_u_303, (ref) v_u_1140, (copy) v_u_1194, (copy) v_u_115, (copy) v_u_110, (ref) v_u_106, (ref) v_u_457
		v_u_1066 = true
		v_u_127.Visible = true
		v_u_448()
		if v_u_1050 and v_u_1050.setReduceMotion then
			v_u_1050.setReduceMotion(v_u_114())
		end
		if not v_u_460 then
			v_u_116.sync()
		end
		for _, v1687 in v_u_449 do
			v1687.sig = ""
		end
		local v1688 = v_u_1102()
		local v1689 = v_u_316
		if v1689.Text ~= v1688 then
			v1689.Text = v1688
			v_u_128 = v_u_128 + 1
		end
		local v1690 = v_u_1064
		if v1690 then
			v1690 = v_u_113 < 600 and true or v_u_111 == "phone"
		end
		local v1691 = v_u_303
		local v1692 = not v1690
		if v1692 then
			v1692 = v_u_1066
		end
		if v1691.Visible ~= v1692 then
			v1691.Visible = v1692
			v_u_128 = v_u_128 + 1
		end
		v_u_1140()
		local v1693 = v_u_116
		v_u_116.dirty = true
		v1693.firstDraw = false
		v_u_1194(v_u_115(), true)
		v_u_116.drawNow()
		local v1694
		if v_u_110.noIntro == true then
			v1694 = true
		elseif p1686 == nil then
			v1694 = false
		else
			v1694 = p1686.noIntro == true
		end
		if not v1694 and (v_u_110.introOnce ~= false and (not v_u_106 and (#v_u_457 > 0 and not v_u_110.state))) then
			v_u_106 = true
			v_u_116.intro()
		end
		if p1686 and p1686.veil then
			v_u_116.veilIn(p1686.page)
		end
		v_u_116.wake()
	end
	function v_u_116.veilIn(p1695) -- name: veilIn
		-- upvalues: (copy) v_u_1069, (ref) v_u_47, (copy) v_u_132, (ref) v_u_113, (ref) v_u_15, (ref) v_u_12, (copy) v_u_1426, (copy) v_u_114, (ref) v_u_3, (copy) v_u_466
		if not v_u_1069.f then
			v_u_1069.f = v_u_47(v_u_132, "Veil", v_u_113, {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 4,
				["BackgroundColor3"] = v_u_15.bgDeep:Lerp(v_u_15.info, 0.05)
			})
			v_u_1069.f:SetAttribute("HushNoFade", true)
			local function v1696()
				-- upvalues: (ref) v_u_12, (ref) v_u_1069
				if v_u_12.noFade then
					v_u_12.noFade[v_u_1069.f] = true
				end
			end
			pcall(v1696)
			v_u_1426()
		end
		if v_u_1069.tw then
			v_u_1069.tw:Cancel()
			v_u_1069.tw = nil
		end
		local v1697 = 0
		local v1698
		if p1695 and v_u_12.fadeAlpha then
			local v1699 = v_u_12.fadeAlpha
			local v1700
			v1700, v1698 = pcall(v1699, p1695)
			if v1700 then
				if type(v1698) ~= "number" then
					v1698 = v1697
				end
			else
				v1698 = v1697
			end
		else
			v1698 = v1697
		end
		v_u_1069.f.BackgroundTransparency = v1698
		if v_u_114() then
			v_u_1069.f.BackgroundTransparency = 1
		else
			local v_u_1701 = v_u_3:Create(v_u_1069.f, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["BackgroundTransparency"] = 1
			})
			v_u_1069.tw = v_u_1701
			local v1702 = v_u_466
			v1702.other = v1702.other + 1
			v_u_1701.Completed:Once(function()
				-- upvalues: (ref) v_u_466, (ref) v_u_1069, (copy) v_u_1701
				local v1703 = v_u_466
				v1703.other = v1703.other - 1
				if v_u_1069.tw == v_u_1701 then
					v_u_1069.tw = nil
				end
			end)
			v_u_1701:Play()
		end
	end
	function v_u_116.hide() -- name: hide
		-- upvalues: (ref) v_u_1066, (copy) v_u_116, (ref) v_u_1051, (ref) v_u_1053, (ref) v_u_1050, (copy) v_u_449, (copy) v_u_465, (copy) v_u_466, (ref) v_u_833, (copy) v_u_1069, (ref) v_u_17, (copy) v_u_127
		v_u_1066 = false
		v_u_116.endDrift("hide")
		v_u_116.closeList()
		v_u_1051 = nil
		v_u_1053 = nil
		if v_u_1050 and v_u_1050.setMoving then
			v_u_1050.setMoving(false)
		end
		for _, v1704 in v_u_449 do
			for _, v1705 in v1704.breath do
				v1705:Cancel()
			end
			v1704.breath = {}
			v_u_116.stopHover(v1704)
			v1704.hovOn = false
			v1704.hov.Visible = false
			v1704.sig = ""
			v1704.body.Position = UDim2.fromOffset(0, 0)
		end
		table.clear(v_u_465)
		v_u_466.shake = 0
		if v_u_833 then
			for _, v1706 in v_u_833.rows do
				v1706.inner.Position = UDim2.fromOffset(0, 0)
			end
		end
		if v_u_1069.tw then
			v_u_1069.tw:Cancel()
			v_u_1069.tw = nil
			v_u_466.other = v_u_17(0, v_u_466.other - 1)
		end
		v_u_127.Visible = false
		v_u_116.sleep()
	end
	function v_u_116.destroy() -- name: destroy
		-- upvalues: (ref) v_u_121, (copy) v_u_116, (copy) v_u_117, (copy) v_u_449, (ref) v_u_1050, (copy) v_u_127
		v_u_121 = false
		v_u_116.endDrift("destroy")
		v_u_116.sleep()
		for _, v1707 in v_u_117 do
			v1707:Disconnect()
		end
		for _, v1708 in v_u_449 do
			for _, v1709 in v1708.breath do
				v1709:Cancel()
			end
			v1708.breath = {}
			v_u_116.stopHover(v1708)
		end
		if v_u_1050 and v_u_1050.destroy then
			local v1710 = v_u_1050.destroy
			pcall(v1710)
		end
		v_u_127:Destroy()
	end
	function v_u_116.stats() -- name: stats
		-- upvalues: (copy) v_u_127, (copy) v_u_157, (copy) v_u_449, (copy) v_u_466, (ref) v_u_128, (ref) v_u_119, (ref) v_u_120, (ref) v_u_456, (copy) v_u_116, (copy) v_u_112, (ref) v_u_111, (ref) v_u_113, (copy) v_u_1068, (copy) v_u_1071, (copy) v_u_200
		local v1711 = 0
		for _, v1712 in v_u_127:GetDescendants() do
			if v1712:IsDescendantOf(v_u_157) then
				continue
			end
			v1711 = v1711 + 1
		end
		local v1713 = 0
		for _, v1714 in v_u_449 do
			if not v1714.key then
				continue
			end
			v1713 = v1713 + 1
		end
		local v1715 = v_u_466.shake + v_u_466.other
		for _, v1716 in v_u_449 do
			for _, v1717 in v1716.breath do
				if v1717.PlaybackState ~= Enum.PlaybackState.Playing then
					continue
				end
				v1715 = v1715 + 1
			end
		end
		local v1718 = {
			["writes"] = v_u_128,
			["coordWrites"] = v_u_119,
			["frames"] = v_u_120,
			["instances"] = v1711,
			["sets"] = v1713,
			["items"] = #v_u_456.items,
			["conns"] = v_u_116.connCount(),
			["tier"] = v_u_112,
			["kind"] = v_u_111,
			["D"] = v_u_113,
			["moving"] = v_u_116.moving,
			["tweens"] = v1715,
			["drift"] = {
				["on"] = v_u_1068.on,
				["t"] = v_u_1068.t,
				["deg"] = v_u_1068.total,
				["ended"] = v_u_1068.lastEnd,
				["started"] = v_u_1068.started,
				["uis"] = #v_u_1068.conns
			},
			["errors"] = #v_u_1071.errs,
			["fatal"] = v_u_1071.fatal,
			["grid"] = v_u_200.shown
		}
		return v1718
	end
	function v_u_116.stateText() -- name: stateText
		-- upvalues: (ref) v_u_456, (ref) v_u_123, (ref) v_u_834
		local v1719 = 0
		local v1720 = 0
		for _, v1721 in v_u_456.items do
			if v1721.kind == "cluster" then
				v1720 = v1720 + 1
			else
				v1719 = v1719 + 1
			end
		end
		local v1722 = string.format
		local v1723 = v_u_123.lat0
		local v1724 = v_u_123.lon0
		local v1725 = v_u_123.z
		local v1726 = v_u_834 ~= nil
		return v1722("lat=%.1f lon=%.1f z=%.2f pins=%d clusters=%d list=%s", v1723, v1724, v1725, v1719, v1720, (tostring(v1726)))
	end
	function v_u_116.commands(p1727) -- name: commands
		-- upvalues: (copy) v_u_116
		local function v1728()
			-- upvalues: (ref) v_u_116
			return v_u_116.stateText()
		end
		pcall(p1727, "globe.state", v1728)
		local function v1736(p1729)
			-- upvalues: (ref) v_u_116
			local v1730 = p1729[1]
			local v1731 = tonumber(v1730)
			local v1732 = p1729[2]
			local v1733 = tonumber(v1732)
			local v1734 = p1729[3]
			local v1735 = tonumber(v1734)
			if v1731 and (v1733 and v1735) then
				v_u_116.setView(v1731, v1733, v1735)
			end
			return v_u_116.stateText()
		end
		pcall(p1727, "globe.view", v1736)
		local function v1740(p1737)
			-- upvalues: (ref) v_u_116
			local v1738 = v_u_116.setFake
			local v1739 = p1737[1]
			v1738(tonumber(v1739) or 0)
			return v_u_116.stateText()
		end
		pcall(p1727, "globe.fake", v1740)
		local function v1741()
			-- upvalues: (ref) v_u_116
			v_u_116.closeList()
			v_u_116.intro()
			return "intro"
		end
		pcall(p1727, "globe.intro", v1741)
	end
	local v1742 = v_u_8.scaleChanged
	table.insert(v_u_117, v1742:Connect(function()
		-- upvalues: (copy) v_u_415, (copy) v_u_116
		v_u_415()
		v_u_116.dirty = true
		v_u_116.wake()
	end))
	if v_u_1050 or not v_u_110.makeDots then
		if v_u_1050 and v_u_1050.layer then
			local v1743 = v_u_1050.layer
			if typeof(v1743) == "Instance" and v_u_1050.layer ~= v_u_157 then
				v_u_1050.layer.Parent = v_u_157
			end
		end
	else
		local v1744 = v_u_110.makeDots
		local v1745, v1746 = pcall(v1744, v_u_157, v_u_122)
		if v1745 then
			v_u_1050 = v1746
		end
	end
	if v_u_1050 and v_u_1050.setGeometry then
		v_u_1050.setGeometry(v_u_113 / 2, v_u_113 / 2, v_u_113 / 2)
	end
	v_u_1426()
	v_u_127.Visible = false
	return v_u_116
end
function v_u_26.probePins() -- name: probePins
	-- upvalues: (copy) v_u_7
	local v1747 = require(v_u_7:WaitForChild("Maps"))
	local v1748 = {}
	for _, v1749 in {
		{
			["id"] = "stillwater",
			["state"] = "open",
			["deploy"] = true,
			["viewing"] = false,
			["chip"] = "SELECTED",
			["place"] = "Wabash County",
			["order"] = 1
		},
		{
			["id"] = "hollow",
			["state"] = "open",
			["deploy"] = false,
			["viewing"] = false,
			["chip"] = "OPEN",
			["place"] = "Wabash County",
			["order"] = 2,
			["underground"] = true
		},
		{
			["id"] = "kestrel",
			["state"] = "raids",
			["deploy"] = false,
			["viewing"] = false,
			["chip"] = "LOCKED",
			["place"] = "Marlow County",
			["order"] = 3,
			["line"] = "FINISH 3 RAIDS TO UNLOCK",
			["progressText"] = "1 / 3 RAIDS",
			["progress"] = 0.33
		},
		{
			["id"] = "overture",
			["state"] = "raids",
			["deploy"] = false,
			["viewing"] = false,
			["chip"] = "LOCKED",
			["place"] = "Port Vesper, Ohio",
			["order"] = 4,
			["line"] = "FINISH MANIFEST AND PAGE TWO TO UNLOCK",
			["progressText"] = "Get them from Doc and Gunner in the TASKS tab",
			["progress"] = 0.5
		},
		{
			["id"] = "unknown5",
			["state"] = "locked",
			["deploy"] = false,
			["viewing"] = false,
			["chip"] = "LOCKED",
			["place"] = "Ridge County",
			["order"] = 5,
			["hidden"] = true,
			["line"] = "FINISH THE NEXT AREA TO UNLOCK",
			["progressText"] = "Find it in the TASKS tab",
			["progress"] = 0
		}
	} do
		local v1750 = v1747.get(v1749.id)
		if not (v1750 and v1750.geo) then
			continue
		end
		v1749.name = v1750.name
		v1749.county = v1750.county
		v1749.geo = {
			["lat"] = v1750.geo.lat,
			["lon"] = v1750.geo.lon
		}
		v1749.fuzz = v1750.fuzz and v1749.hidden and {
			["lat"] = v1750.fuzz.lat,
			["lon"] = v1750.fuzz.lon,
			["km"] = v1750.fuzz.km
		} or nil
		v1749.frozen = false
		table.insert(v1748, v1749)
	end
	return v1748
end
function v_u_26.probe(p1751) -- name: probe
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_26, (copy) v_u_18
	local v1752 = p1751 or {}
	local v_u_1753, v1754 = v_u_12.screen("GlobeProbe", v_u_8.layer.menu + 5, {})
	local v1755 = Instance.new("Frame")
	v1755.Name = "ProbeBack"
	v1755.BackgroundColor3 = v1752.back or Color3.fromRGB(120, 100, 70)
	v1755.BackgroundTransparency = v1752.back == false and 1 or 0
	v1755.Size = UDim2.fromScale(1, 1)
	v1755.ZIndex = 0
	v1755.Parent = v1754
	local v_u_1756 = v1752.pins or v_u_26.probePins()
	local v1757 = v1752.D or 772
	local v1758 = v_u_8.refSize()
	local v1761 = {
		["kind"] = v1752.kind or "pc",
		["D"] = v1757,
		["tier"] = v1752.tier,
		["detail"] = v1752.detail,
		["position"] = UDim2.fromOffset(v_u_18((v1758.X - v1757) / 2), (v_u_18((v1758.Y - v1757) / 2))),
		["hintRoom"] = v1752.hintRoom,
		["pins"] = function() -- name: pins
			-- upvalues: (copy) v_u_1756
			return v_u_1756
		end,
		["pick"] = v1752.pick or function(p1759)
			-- upvalues: (copy) v_u_1756
			for _, v1760 in v_u_1756 do
				v1760.viewing = v1760.id == p1759
			end
			return true
		end,
		["makeDots"] = v1752.makeDots,
		["dots"] = v1752.dots,
		["inputKind"] = v1752.inputKind,
		["padOwns"] = v1752.padOwns,
		["noIntro"] = v1752.noIntro ~= false,
		["labels"] = v1752.labels,
		["state"] = v1752.state,
		["reduced"] = v1752.reduced,
		["justDragged"] = v1752.justDragged,
		["list"] = v1752.list,
		["keyName"] = v1752.keyName,
		["frozenWhy"] = v1752.frozenWhy,
		["clock"] = v1752.clock,
		["session"] = v1752.session,
		["modal"] = v1752.modal,
		["govTripped"] = v1752.govTripped,
		["switchOn"] = v1752.switchOn,
		["onFatal"] = v1752.onFatal
	}
	local v1762 = v_u_26.new(v1754, v1761)
	v1762.gui = v_u_1753
	v1762.panel = v1755
	local v_u_1763 = v1762.destroy
	function v1762.destroy() -- name: destroy
		-- upvalues: (copy) v_u_1763, (copy) v_u_1753
		v_u_1763()
		v_u_1753:Destroy()
	end
	v1762.show()
	if not (v1752.state or v1762.flying()) then
		local v1764 = v1762.homeView()
		v1762.setView(v1764.lat0, v1764.lon0, v1764.z)
	end
	return v1762
end
return v_u_26