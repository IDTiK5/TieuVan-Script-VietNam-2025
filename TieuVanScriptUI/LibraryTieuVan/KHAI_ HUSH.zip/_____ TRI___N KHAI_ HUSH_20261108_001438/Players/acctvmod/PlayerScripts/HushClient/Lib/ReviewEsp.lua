-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewEsp

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = {}
local v_u_5 = {}
function v4.use(p6) -- name: use
	-- upvalues: (ref) v_u_5
	v_u_5 = type(p6) ~= "table" and {} or p6
end
local v_u_7 = {
	["zombie"] = Color3.fromRGB(226, 72, 60),
	["player"] = Color3.fromRGB(240, 240, 240),
	["target"] = Color3.fromRGB(255, 196, 64),
	["full"] = Color3.fromRGB(255, 176, 48),
	["empty"] = Color3.fromRGB(130, 130, 130),
	["unknown"] = Color3.fromRGB(180, 160, 120),
	["item"] = Color3.fromRGB(120, 210, 255),
	["door"] = Color3.fromRGB(150, 170, 200),
	["extract"] = Color3.fromRGB(96, 220, 120),
	["thrown"] = Color3.fromRGB(255, 120, 40),
	["aim"] = Color3.fromRGB(255, 80, 80)
}
local v_u_8 = {
	Color3.fromRGB(86, 180, 233),
	Color3.fromRGB(230, 159, 0),
	Color3.fromRGB(0, 158, 115),
	Color3.fromRGB(240, 228, 66),
	Color3.fromRGB(204, 121, 167),
	Color3.fromRGB(213, 94, 0),
	Color3.fromRGB(150, 150, 255),
	Color3.fromRGB(160, 220, 90)
}
local v_u_9 = nil
local v_u_10 = v_u_2.LocalPlayer
local v_u_11 = nil
local v_u_12 = false
local v_u_13 = true
local v_u_14 = nil
local v_u_15 = {}
local v_u_16 = 0
local v_u_17 = nil
local v_u_18 = 0
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = 0
local v_u_26 = {
	["x"] = table.create(80, 0),
	["z"] = table.create(80, 0),
	["age"] = table.create(80, 0)
}
local function v_u_30() -- name: newEntry
	local v27 = Instance.new("BillboardGui")
	v27.Name = "E"
	v27.AlwaysOnTop = true
	v27.Size = UDim2.fromOffset(84, 22)
	v27.StudsOffset = Vector3.new(0, 3, 0)
	v27.LightInfluence = 0
	v27.ResetOnSpawn = false
	v27.Enabled = false
	local v28 = Instance.new("Frame")
	v28.Name = "Dot"
	v28.AnchorPoint = Vector2.new(0.5, 0)
	v28.Position = UDim2.new(0.5, 0, 0, 0)
	v28.Size = UDim2.fromOffset(8, 8)
	v28.BorderSizePixel = 0
	v28.BackgroundTransparency = 0.1
	v28.Parent = v27
	local v29 = Instance.new("TextLabel")
	v29.Name = "Label"
	v29.BackgroundTransparency = 1
	v29.Position = UDim2.fromOffset(0, 9)
	v29.Size = UDim2.fromOffset(84, 13)
	v29.Font = Enum.Font.GothamBold
	v29.TextSize = 11
	v29.TextStrokeTransparency = 0.4
	v29.TextTruncate = Enum.TextTruncate.AtEnd
	v29.TextColor3 = Color3.new(1, 1, 1)
	v29.Text = ""
	v29.Parent = v27
	return {
		["gui"] = nil,
		["dot"] = nil,
		["label"] = nil,
		["text"] = "",
		["color"] = nil,
		["adornee"] = nil,
		["gui"] = v27,
		["dot"] = v28,
		["label"] = v29
	}
end
local function v_u_36(_, p31, p32, p33, p34) -- name: put
	-- upvalues: (ref) v_u_16, (copy) v_u_15, (copy) v_u_30, (ref) v_u_14
	v_u_16 = v_u_16 + 1
	local v35 = v_u_15[v_u_16]
	if v35 == nil then
		v35 = v_u_30()
		v35.gui.Parent = v_u_14
		v_u_15[v_u_16] = v35
	end
	if v35.adornee ~= p31 then
		v35.gui.Adornee = p31
		v35.adornee = p31
	end
	if v35.color ~= p32 then
		v35.dot.BackgroundColor3 = p32
		v35.label.TextColor3 = p32
		v35.color = p32
	end
	if v35.text ~= p33 then
		v35.label.Text = p33
		v35.text = p33
	end
	if v35.offsetY ~= p34 then
		v35.gui.StudsOffset = Vector3.new(0, p34, 0)
		v35.offsetY = p34
	end
	if not v35.gui.Enabled then
		v35.gui.Enabled = true
	end
end
local function v_u_39() -- name: releaseRest
	-- upvalues: (ref) v_u_16, (copy) v_u_15
	for v37 = v_u_16 + 1, #v_u_15 do
		local v38 = v_u_15[v37]
		if not v38.gui.Enabled then
			continue
		end
		v38.gui.Enabled = false
		v38.gui.Adornee = nil
		v38.adornee = nil
	end
end
local function v_u_43(p40) -- name: bodyPart
	if p40:IsA("BasePart") then
		return p40
	elseif p40:IsA("Model") then
		local v41 = p40.PrimaryPart
		if v41 then
			return v41
		else
			local v42 = p40:FindFirstChild("HumanoidRootPart")
			if v42 and v42:IsA("BasePart") then
				return v42
			else
				return p40:FindFirstChildWhichIsA("BasePart", true)
			end
		end
	else
		return nil
	end
end
local function v_u_82(p44) -- name: scan
	-- upvalues: (ref) v_u_5, (copy) v_u_3, (ref) v_u_17, (ref) v_u_16, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11, (copy) v_u_7, (copy) v_u_8, (copy) v_u_36, (copy) v_u_43, (copy) v_u_1, (copy) v_u_39
	local v45
	if v_u_5.rules == nil then
		v45 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v45 = v_u_5.rules
	end
	v45.espReset(v_u_17)
	v_u_16 = 0
	for _, v46 in v_u_2:GetPlayers() do
		if v46 == v_u_10 then
			continue
		end
		local v47 = v46.Character
		local v48
		if v47 then
			v48 = v47:FindFirstChild("HumanoidRootPart")
		else
			v48 = v47
		end
		if not (v48 and v48:IsA("BasePart")) then
			continue
		end
		local v49 = (v48.Position - p44).Magnitude
		if not v45.espKeep(v_u_17, "player", v49) then
			continue
		end
		local v50 = v46.UserId == v_u_11
		local v51 = v45.squadHue(v47:GetAttribute("SquadId"))
		local v52
		if v50 then
			v52 = v_u_7.target
		elseif v51 > 0 then
			v52 = v_u_8[v51]
		else
			v52 = v_u_7.player
		end
		local v53 = v_u_36
		local v54 = "player"
		local v55
		if v50 then
			v55 = "TARGET " .. v46.Name
		else
			v55 = v45.espLabel("player", v46.Name, nil, v49)
		end
		v53(v54, v48, v52, v55, 4)
	end
	local v56 = workspace:FindFirstChild("HushLocal")
	local v57
	if v56 then
		v57 = v56:FindFirstChild("Zombies")
	else
		v57 = v56
	end
	if v57 then
		for _, v58 in v57:GetChildren() do
			if v58:GetAttribute("Dead") == true then
				continue
			end
			local v59 = v_u_43(v58)
			if not v59 then
				continue
			end
			local v60 = (v59.Position - p44).Magnitude
			if not v45.espKeep(v_u_17, "zombie", v60) then
				continue
			end
			v_u_36("zombie", v59, v_u_7.zombie, v45.espLabel("zombie", nil, nil, v60), 3.5)
		end
	end
	for _, v61 in v_u_1:GetTagged("HushContainer") do
		local v62 = v_u_43(v61)
		if not v62 then
			continue
		end
		local v63 = (v62.Position - p44).Magnitude
		if not v45.espKeep(v_u_17, "container", v63) then
			continue
		end
		local v64 = v61:GetAttribute("Looted")
		local v65 = v64 == true and "empty" or (v64 == false and "full" or nil)
		local v66 = v_u_36
		local v67 = "container"
		local v68
		if v65 == "empty" then
			v68 = v_u_7.empty
		elseif v65 == "full" then
			v68 = v_u_7.full
		else
			v68 = v_u_7.unknown
		end
		v66(v67, v62, v68, v45.espLabel("container", nil, v65, v63), 2.5)
	end
	for _, v69 in v_u_1:GetTagged("HushItem") do
		local v70 = v_u_43(v69)
		if not v70 then
			continue
		end
		local v71 = (v70.Position - p44).Magnitude
		if not v45.espKeep(v_u_17, "item", v71) then
			continue
		end
		v_u_36("item", v70, v_u_7.item, v45.espLabel("item", nil, nil, v71), 2)
	end
	for _, v72 in v_u_1:GetTagged("HushDoor") do
		local v73 = v_u_43(v72)
		if not v73 then
			continue
		end
		local v74 = (v73.Position - p44).Magnitude
		if not v45.espKeep(v_u_17, "door", v74) then
			continue
		end
		v_u_36("door", v73, v_u_7.door, v45.espLabel("door", nil, v72:GetAttribute("Open") == true and "open" or nil, v74), 3)
	end
	local v75 = v_u_3:FindFirstChild("HushRuntime") or workspace:FindFirstChild("HushRuntime")
	if v75 then
		v75 = v75:FindFirstChild("Raid")
	end
	if v75 then
		v75 = v75:FindFirstChild("Extracts")
	end
	if v75 then
		for _, v76 in v75:GetChildren() do
			local v77 = v_u_43(v76)
			if not v77 then
				continue
			end
			local v78 = (v77.Position - p44).Magnitude
			if not v45.espKeep(v_u_17, "extract", v78) then
				continue
			end
			v_u_36("extract", v77, v_u_7.extract, v45.espLabel("extract", nil, nil, v78), 4)
		end
	end
	if v56 then
		v56 = v56:FindFirstChild("GrenadeFx")
	end
	if v56 then
		for _, v79 in v56:GetChildren() do
			if not string.find(v79.Name, "Thrown", 1, true) then
				continue
			end
			local v80 = v_u_43(v79)
			if not v80 then
				continue
			end
			local v81 = (v80.Position - p44).Magnitude
			if not v45.espKeep(v_u_17, "thrown", v81) then
				continue
			end
			v_u_36("thrown", v80, v_u_7.thrown, v45.espLabel("thrown", nil, nil, v81), 2)
		end
	end
	v_u_39()
end
local function v_u_91() -- name: ensureOverlay
	-- upvalues: (ref) v_u_14, (ref) v_u_19, (copy) v_u_7, (ref) v_u_5, (copy) v_u_3, (ref) v_u_20, (copy) v_u_21
	if v_u_14 ~= nil then
		if v_u_19 == nil then
			local v83 = Instance.new("Part")
			v83.Name = "ReviewEspAnchor"
			v83.Anchored = true
			v83.CanCollide = false
			v83.CanQuery = false
			v83.CanTouch = false
			v83.Transparency = 1
			v83.Size = Vector3.new(0.2, 0.2, 0.2)
			v83.CFrame = CFrame.new(0, 0, 0)
			v83.Parent = v_u_14
			v_u_19 = v83
			local v84 = Instance.new("BoxHandleAdornment")
			v84.Name = "AimLine"
			v84.Adornee = v83
			v84.AlwaysOnTop = true
			v84.ZIndex = 2
			v84.Color3 = v_u_7.aim
			v84.Transparency = 0.25
			local v85 = 0.18
			local v86 = 0.18
			local v87
			if v_u_5.rules == nil then
				v87 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
			else
				v87 = v_u_5.rules
			end
			local v88 = v87.TUNE.AIM_LINE
			v84.Size = Vector3.new(v85, v86, v88)
			v84.Visible = false
			v84.Parent = v83
			v_u_20 = v84
			for v89 = 1, 25 do
				local v90 = Instance.new("BoxHandleAdornment")
				v90.Name = "Dot" .. v89
				v90.Adornee = v83
				v90.AlwaysOnTop = true
				v90.ZIndex = 1
				v90.Color3 = v_u_7.aim
				v90.Size = Vector3.new(0.7, 0.7, 0.7)
				v90.Transparency = 1
				v90.Visible = false
				v90.Parent = v83
				v_u_21[v89] = v90
			end
		end
	end
end
local function v_u_98() -- name: placeLine
	-- upvalues: (ref) v_u_20, (ref) v_u_23, (ref) v_u_24, (ref) v_u_5, (copy) v_u_3
	local v92 = v_u_20
	if v92 == nil or (v_u_23 == nil or v_u_24 == nil) then
		if v92 then
			v92.Visible = false
		end
	else
		local v93
		if v_u_5.rules == nil then
			v93 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v93 = v_u_5.rules
		end
		local v94, v95 = v93.aimDir(v_u_23)
		local v96 = v93.TUNE.AIM_LINE
		local v97 = v_u_24 + Vector3.new(v94, 0, v95) * (v96 / 2)
		v92.CFrame = CFrame.lookAt(v97, v97 + Vector3.new(v94, 0, v95))
		v92.Visible = true
	end
end
local function v_u_111(p99) -- name: placeDots
	-- upvalues: (ref) v_u_5, (copy) v_u_3, (ref) v_u_22, (copy) v_u_26, (ref) v_u_24, (copy) v_u_21
	local v100
	if v_u_5.rules == nil then
		v100 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v100 = v_u_5.rules
	end
	local v101 = v100.trailTips(v_u_22, p99, v100.TUNE.TRAIL_SECONDS, v100.TUNE.AIM_LINE, v_u_26)
	local v102 = not v_u_24 and 0 or v_u_24.Y
	for v103 = 1, 25 do
		local v104 = v_u_21[v103]
		local v105 = p99 - (v103 - 1) * 0.2
		local v106 = 0.2
		local v107 = 0
		for v108 = 1, v101 do
			local v109 = p99 - v_u_26.age[v108] - v105
			local v110 = math.abs(v109)
			if v110 >= v106 then
				continue
			end
			v107 = v108
			v106 = v110
		end
		if v107 > 0 then
			v104.CFrame = CFrame.new(v_u_26.x[v107], v102, v_u_26.z[v107])
			v104.Transparency = 0.15 + 0.8 * (v_u_26.age[v107] / v100.TUNE.TRAIL_SECONDS)
			v104.Visible = true
		else
			v104.Visible = false
		end
	end
end
function v4.pushAim(p112, p113, p114) -- name: pushAim
	-- upvalues: (ref) v_u_12, (ref) v_u_22, (ref) v_u_5, (copy) v_u_3, (ref) v_u_23, (ref) v_u_24, (copy) v_u_98, (ref) v_u_25, (copy) v_u_111
	if v_u_12 and v_u_22 ~= nil then
		local v115
		if v_u_5.rules == nil then
			v115 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v115 = v_u_5.rules
		end
		v115.trailPush(v_u_22, p112, p113, p114.X, p114.Z)
		v_u_23 = p113
		v_u_24 = p114
		v_u_98()
		v_u_25 = v_u_25 + 1
		if v_u_25 >= 2 then
			v_u_25 = 0
			v_u_111(p112)
		end
	end
end
function v4.setOn(p116) -- name: setOn
	-- upvalues: (ref) v_u_13, (ref) v_u_16, (copy) v_u_39
	v_u_13 = p116 == true
	if not v_u_13 then
		v_u_16 = 0
		v_u_39()
	end
end
function v4.isOn() -- name: isOn
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v4.count() -- name: count
	-- upvalues: (ref) v_u_16
	return v_u_16
end
function v4.state() -- name: state
	-- upvalues: (ref) v_u_13, (ref) v_u_12, (ref) v_u_16, (copy) v_u_15
	return ("on=%d running=%d used=%d pool=%d"):format(v_u_13 and 1 or 0, v_u_12 and 1 or 0, v_u_16, #v_u_15)
end
function v4.init(p117) -- name: init
	-- upvalues: (ref) v_u_9
	v_u_9 = p117
end
function v4.start(p118) -- name: start
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) v_u_3, (ref) v_u_17, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_14, (copy) v_u_91
	v_u_11 = p118
	if not v_u_12 then
		v_u_12 = true
		local v119
		if v_u_5.rules == nil then
			v119 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v119 = v_u_5.rules
		end
		v_u_17 = v119.espNewCounts()
		v_u_22 = v119.trailNew()
		v_u_23 = nil
		v_u_24 = nil
		local v120 = workspace:FindFirstChild("HushLocal") or workspace
		local v121 = Instance.new("Folder")
		v121.Name = "ReviewEsp"
		v121.Parent = v120
		v_u_14 = v121
		v_u_91()
	end
end
function v4.stop() -- name: stop
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_14, (ref) v_u_19, (ref) v_u_20, (copy) v_u_15, (copy) v_u_21, (ref) v_u_16, (ref) v_u_23, (ref) v_u_24
	if v_u_12 then
		v_u_12 = false
		v_u_11 = nil
		if v_u_14 then
			v_u_14:Destroy()
		end
		v_u_14 = nil
		v_u_19 = nil
		v_u_20 = nil
		table.clear(v_u_15)
		table.clear(v_u_21)
		v_u_16 = 0
		v_u_23 = nil
		v_u_24 = nil
	end
end
function v4.step(p122, p123) -- name: step
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (copy) v_u_2, (ref) v_u_24, (ref) v_u_20, (copy) v_u_98, (ref) v_u_18, (ref) v_u_13, (copy) v_u_82
	if v_u_12 then
		local v124
		if v_u_11 then
			v124 = v_u_2:GetPlayerByUserId(v_u_11)
		else
			v124 = nil
		end
		if v124 then
			v124 = v124.Character
		end
		if v124 then
			v124 = v124:FindFirstChild("HumanoidRootPart")
		end
		local v125 = nil
		if v124 and v124:IsA("BasePart") then
			p123 = v124.Position
		elseif p123 == nil then
			p123 = v125
		end
		if p123 ~= nil then
			v_u_24 = p123
			if v_u_20 and v_u_20.Visible then
				v_u_98()
			end
			v_u_18 = v_u_18 + p122
			if v_u_13 and v_u_18 >= 0.2 then
				v_u_18 = 0
				v_u_82(p123)
			end
		end
	end
end
return v4