-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmBm

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.lines(p6) -- name: lines
	local v7 = {}
	if type(p6) ~= "table" then
		table.insert(v7, {
			["name"] = "State",
			["text"] = "Reading the market ...",
			["kind"] = "muted"
		})
		return v7
	end
	local v8 = p6.sw
	if p6.enabled == false then
		local v9 = {
			["name"] = "State",
			["text"] = nil,
			["kind"] = "warn"
		}
		local v10 = p6.reason or "disabled"
		v9.text = "MARKET MODULE OFF: " .. tostring(v10)
		table.insert(v7, v9)
	end
	if type(v8) == "table" then
		local v11 = v8.list == true and true or v8.buy == true
		local v12 = v8.freeze == true and "PAUSED (freeze)" or (v11 and "OPEN" or "CLOSED")
		local v13 = {
			["name"] = "State",
			["text"] = nil,
			["kind"] = nil,
			["text"] = ("%s%s  \194\183  listings %s  \194\183  buying %s  \194\183  freeze %s"):format(p6.enabled == true and "MARKET MODULE ON  \194\183  " or "", v12, v8.list == true and "on" or "off", v8.buy == true and "on" or "off", v8.freeze == true and "on" or "off"),
			["kind"] = v8.freeze == true and "warn" or (v11 and "ok" or "muted")
		}
		table.insert(v7, v13)
		local v14 = {
			["name"] = "Scope",
			["text"] = nil,
			["kind"] = "text"
		}
		local v15 = v8.scope
		local v16 = tostring(v15)
		local v17 = v8.rm == "block" and "market blocked" or "paid listings hidden"
		local v18 = v8.srv
		v14.text = ("scope %s  \194\183  restricted accounts: %s  \194\183  servers assumed %s"):format(v16, v17, (tostring(v18)))
		table.insert(v7, v14)
		if v8.book ~= nil or v8.drain ~= nil then
			local v19 = {
				["name"] = "Orders",
				["text"] = nil,
				["kind"] = nil,
				["text"] = ("buy orders %s  \194\183  drain %s"):format(v8.book == true and "on" or "off", v8.drain == true and "on" or "off"),
				["kind"] = v8.drain == true and "warn" or (v8.book == true and "ok" or "muted")
			}
			table.insert(v7, v19)
		end
		local v20 = {
			["name"] = "Cases",
			["text"] = nil,
			["kind"] = nil,
			["text"] = ("trading cases %s  \194\183  cash opening for restricted accounts %s"):format(v8.crates ~= false == true and "on" or "off", v8.cashForRestricted == true == true and "on" or "off"),
			["kind"] = v8.crates == false and "warn" or "muted"
		}
		table.insert(v7, v20)
		local v21 = {
			["name"] = "Restock",
			["text"] = nil,
			["kind"] = nil,
			["text"] = ("restock sales %s  \194\183  planned in the tab RESTOCK"):format(v8.rs ~= false == true and "on" or "off"),
			["kind"] = v8.rs == false and "warn" or "muted"
		}
		table.insert(v7, v21)
		local v22 = p6.sim
		if type(v22) == "table" and v22.can == true then
			local v23 = {
				["name"] = "Sim",
				["text"] = nil,
				["kind"] = "text"
			}
			local v24 = v22.tradeResolved
			local v25 = v22.tradeFailed
			local v26 = v22.trade
			local v27 = v24 == true and (v25 == true and "check failed" or (v26 == true and "allowed" or "restricted")) or "not known yet"
			local v28 = v22.randomResolved
			local v29 = v22.randomFailed
			local v30 = v22.random
			local v31 = v28 == true and (v29 == true and "check failed" or (v30 == true and "allowed" or "restricted")) or "not known yet"
			local v32 = v22.state or "?"
			v23.text = ("your account: trading %s  \194\183  paid random items %s  \194\183  state %s"):format(v27, v31, (tostring(v32)))
			table.insert(v7, v23)
		end
		local v33 = p6.servers
		if type(v33) == "table" then
			local v34 = v33.measured
			local v35
			if type(v34) == "number" and v33.measured >= 1 then
				v35 = v33.measured
			else
				v35 = nil
			end
			local v36 = not v35 and "not measured yet" or (v33.partial == true and "at least " or "") .. tostring(v35)
			local v37 = v33.effective
			local v38 = tonumber(v37)
			if not v38 then
				local v39 = v8.srv
				v38 = tonumber(v39) or 0
			end
			local v40
			if v35 == nil then
				v40 = false
			else
				local v41 = v8.srv
				v40 = (tonumber(v41) or 0) < v35
			end
			local v42 = {
				["name"] = "Servers",
				["text"] = nil,
				["kind"] = nil
			}
			local v43 = v8.srv
			v42.text = ("servers: assumed %s  \194\183  measured %s  \194\183  in use %d%s"):format(tostring(v43), v36, v38, v40 and "  \194\183  press SET TO to follow the measurement" or "")
			local v44
			if v35 == nil then
				v44 = "muted"
			else
				local v45 = v8.srv
				v44 = (tonumber(v45) or 0) < v35 and "warn" or "muted"
			end
			v42.kind = v44
			table.insert(v7, v42)
		end
		local v46 = {
			["name"] = "Store",
			["text"] = nil,
			["kind"] = nil
		}
		local v47 = v8.v or 0
		local v48 = tostring(v47)
		local v49 = v8.byName or "nobody yet"
		local v50 = tostring(v49)
		local v51 = v8.backend or "?"
		v46.text = ("switch v%s by %s  \194\183  store %s  \194\183  read %s"):format(v48, v50, tostring(v51), v8.good == true and "OK" or "NOT YET (closed for safety)")
		v46.kind = v8.good == true and "muted" or "warn"
		table.insert(v7, v46)
	elseif p6.enabled ~= false then
		table.insert(v7, {
			["name"] = "State",
			["text"] = "No switch information on this server.",
			["kind"] = "muted"
		})
	end
	local v52 = p6.counts
	if type(v52) == "table" then
		local v53 = v52.quarantined
		local v54 = tonumber(v53) or 0
		local v55 = {
			["name"] = "Counts",
			["text"] = nil,
			["kind"] = nil
		}
		local v56 = v52.running
		local v57 = tonumber(v56) or 0
		local v58 = v52.sick
		local v59 = tonumber(v58) or 0
		local v60 = v52.pending
		v55.text = ("sagas running %d  \194\183  quarantined %d  \194\183  sick keys %d  \194\183  pending %d"):format(v57, v54, v59, tonumber(v60) or 0)
		v55.kind = v54 > 0 and "warn" or "muted"
		table.insert(v7, v55)
	end
	local v61 = p6.me
	if type(v61) == "table" then
		local v62 = v61.resetIn
		local v63 = tonumber(v62) or 0
		local v64 = {
			["name"] = "Mine",
			["text"] = nil,
			["kind"] = nil
		}
		local v65 = v61.used
		local v66 = tonumber(v65) or 0
		local v67 = v61.limit
		local v68 = tonumber(v67) or 0
		local v69 = v61.tier or "?"
		local v70 = tostring(v69)
		local v71 = v61.left
		local v72 = tonumber(v71) or 0
		local v73 = v63 / 3600
		local v74 = math.floor(v73)
		local v75 = v63 % 3600 / 60
		v64.text = ("my listings today: %d of %d (%s tier)  \194\183  %d left  \194\183  resets in %d h %d min"):format(v66, v68, v70, v72, v74, (math.floor(v75)))
		local v76 = v61.left
		v64.kind = (tonumber(v76) or 0) <= 0 and "warn" or "text"
		table.insert(v7, v64)
	end
	local v77 = p6.hot
	if type(v77) == "table" and #v77 > 0 then
		local v78 = {}
		for v79, v80 in v77 do
			if v79 > 3 then
				break
			end
			local v81 = v80.interval
			local v82
			if type(v81) == "number" then
				local v83 = v80.interval + 0.5
				v82 = ("%d s"):format((math.floor(v83)))
			else
				v82 = "off"
			end
			local v84 = v80.id
			local v85 = tostring(v84)
			local v86 = v80.heat
			local v87 = tonumber(v86) or 0
			local v88 = v80.ttl
			local v89 = (tonumber(v88) or 0) + 0.5
			local v90 = math.floor(v89)
			table.insert(v78, ("%s %d sales in 2 min, TTL %d s, sheet every %s"):format(v85, v87, v90, v82))
		end
		local v91 = {
			["name"] = "Hot",
			["text"] = nil,
			["kind"] = "ok",
			["text"] = "hot items: " .. table.concat(v78, "  \194\183  ")
		}
		table.insert(v7, v91)
	end
	local v92 = p6.seed
	if type(v92) == "table" then
		local v93
		if v92.running then
			local v94 = v92.running
			v93 = "working: " .. tostring(v94) .. " ..."
		else
			local v95 = v92.last or ""
			v93 = tostring(v95)
		end
		if v93 ~= "" then
			local v96 = {
				["name"] = "Seed",
				["text"] = nil,
				["kind"] = nil,
				["text"] = "seed: " .. v93,
				["kind"] = v92.running and "ok" or "muted"
			}
			table.insert(v7, v96)
		end
	end
	return v7
end
function v_u_4.mount(p_u_97, p_u_98, p_u_99, p100) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_101 = type(p100) ~= "table" and {} or p100
	if type(p_u_99) == "table" then
		local v102 = p_u_99.color
		if type(v102) ~= "table" then
			p_u_99 = v_u_3.Theme
		end
	else
		p_u_99 = v_u_3.Theme
	end
	local v_u_103 = p_u_99.color
	local v104 = v_u_101.inner
	local v_u_105 = type(v104) ~= "number" and 438 or v_u_101.inner
	local v_u_106 = v_u_101.gui
	local v_u_107 = 0
	local v_u_108 = true
	if v_u_106 then
		v_u_106.Destroying:Connect(function()
			-- upvalues: (ref) v_u_108
			v_u_108 = false
		end)
	end
	local v109 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Blackmarket  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_97,
		["color"] = v_u_103.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v110 = v_u_101.order
	local v111
	if type(v110) == "function" then
		v111 = v_u_101.order()
	else
		v_u_107 = v_u_107 + 1
		v111 = v_u_107
	end
	v109.LayoutOrder = v111
	local v_u_112 = v_u_3.new("Frame", {
		["Name"] = "BmList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_97)
	v_u_3.layout(v_u_112, "v", 2)
	local v113 = v_u_101.order
	local v114
	if type(v113) == "function" then
		v114 = v_u_101.order()
	else
		v_u_107 = v_u_107 + 1
		v114 = v_u_107
	end
	v_u_112.LayoutOrder = v114
	local function v_u_121(p115, p116, p117) -- name: small
		-- upvalues: (ref) v_u_3, (copy) p_u_97, (copy) v_u_103, (copy) v_u_101, (ref) v_u_107
		local v118 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_97,
			["name"] = p115,
			["text"] = p116,
			["color"] = p117 or v_u_103.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v119 = v_u_101.order
		local v120
		if type(v119) == "function" then
			v120 = v_u_101.order()
		else
			v_u_107 = v_u_107 + 1
			v120 = v_u_107
		end
		v118.LayoutOrder = v120
		return v118
	end
	local function v_u_135(p122, p123) -- name: row
		-- upvalues: (ref) v_u_3, (copy) p_u_99, (copy) p_u_97, (copy) v_u_101, (ref) v_u_107
		local v124 = v_u_3.new
		local v125 = "Frame"
		local v126 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = p123 or "BmRow"
		}
		local v127 = UDim2.new
		local v128 = 1
		local v129 = 0
		local v130 = 0
		if not p122 then
			local v131 = p_u_99.touch
			p122 = type(v131) ~= "function" and 32 or p_u_99.touch(32)
		end
		v126.Size = v127(v128, v129, v130, p122)
		local v132 = v124(v125, v126, p_u_97)
		v_u_3.layout(v132, "h", 6)
		local v133 = v_u_101.order
		local v134
		if type(v133) == "function" then
			v134 = v_u_101.order()
		else
			v_u_107 = v_u_107 + 1
			v134 = v_u_107
		end
		v132.LayoutOrder = v134
		return v132
	end
	local v_u_136 = nil
	local v_u_137 = false
	local v_u_138 = (-1 / 0)
	local v_u_139 = nil
	local v_u_140 = nil
	local v_u_141 = 0
	local v_u_142 = {}
	local v_u_143 = {}
	local v_u_144 = {}
	local v_u_145 = nil
	local function v159() -- name: refresh
		-- upvalues: (ref) v_u_137, (copy) p_u_98, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (ref) v_u_3, (ref) v_u_139, (copy) v_u_103, (ref) v_u_145, (copy) v_u_101
		local v146 = {
			["cmd"] = "status"
		}
		if not v_u_137 then
			local v147 = p_u_98
			if type(v147) ~= "function" then
				return
			end
			v_u_137 = true
			local v_u_148 = true
			local function v156(p149) -- name: done
				-- upvalues: (ref) v_u_137, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (copy) v_u_148, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
				v_u_137 = false
				if v_u_108 then
					v_u_138 = os.clock()
					if type(p149) == "table" then
						local v150 = p149.data
						if type(v150) == "table" then
							v_u_136 = p149.data
						end
						if not v_u_148 then
							local v151 = p149.msg or (p149.ok and "Done." or "Refused.")
							local v152 = tostring(v151)
							local v153 = p149.ok ~= true
							v_u_3.setText(v_u_139, v152)
							local v154 = v_u_139
							local v155
							if v153 then
								v155 = v_u_103.danger
							else
								v155 = v_u_103.text2
							end
							v154.TextColor3 = v155
						end
					elseif not v_u_148 then
						v_u_3.setText(v_u_139, "The server did not answer.")
						v_u_139.TextColor3 = v_u_103.danger
					end
					v_u_145(v_u_136)
				end
			end
			local v157 = v_u_101.sendQuiet
			local v158
			if type(v157) == "function" then
				v158 = v_u_101.sendQuiet
			else
				v158 = p_u_98
			end
			v158("server.bm", v146, v156)
		end
	end
	local function v177(p_u_160, p161) -- name: addToggle
		-- upvalues: (ref) v_u_3, (copy) p_u_97, (copy) v_u_105, (ref) v_u_137, (copy) p_u_98, (ref) v_u_139, (copy) v_u_103, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (ref) v_u_145, (copy) v_u_101, (ref) v_u_107, (copy) v_u_142
		local v173, v174 = v_u_3.toggle({
			["parent"] = nil,
			["name"] = nil,
			["label"] = nil,
			["value"] = false,
			["width"] = nil,
			["onChange"] = nil,
			["parent"] = p_u_97,
			["name"] = "BmToggle_" .. p_u_160,
			["label"] = p161,
			["width"] = v_u_105,
			["onChange"] = function(p162) -- name: onChange
				-- upvalues: (copy) p_u_160, (ref) v_u_137, (ref) p_u_98, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (ref) v_u_145
				local v163 = {
					["cmd"] = "set",
					[p_u_160] = p162
				}
				if not v_u_137 then
					local v164 = p_u_98
					if type(v164) ~= "function" then
						return
					end
					v_u_137 = true
					v_u_3.setText(v_u_139, "Working ...")
					v_u_139.TextColor3 = v_u_103.text2
					local v_u_165 = nil
					p_u_98("server.bm", v163, function(p166) -- name: done
						-- upvalues: (ref) v_u_137, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (copy) v_u_165, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
						v_u_137 = false
						if v_u_108 then
							v_u_138 = os.clock()
							if type(p166) == "table" then
								local v167 = p166.data
								if type(v167) == "table" then
									v_u_136 = p166.data
								end
								if not v_u_165 then
									local v168 = p166.msg or (p166.ok and "Done." or "Refused.")
									local v169 = tostring(v168)
									local v170 = p166.ok ~= true
									v_u_3.setText(v_u_139, v169)
									local v171 = v_u_139
									local v172
									if v170 then
										v172 = v_u_103.danger
									else
										v172 = v_u_103.text2
									end
									v171.TextColor3 = v172
								end
							elseif not v_u_165 then
								v_u_3.setText(v_u_139, "The server did not answer.")
								v_u_139.TextColor3 = v_u_103.danger
							end
							v_u_145(v_u_136)
						end
					end)
				end
			end
		})
		local v175 = v_u_101.order
		local v176
		if type(v175) == "function" then
			v176 = v_u_101.order()
		else
			v_u_107 = v_u_107 + 1
			v176 = v_u_107
		end
		v173.LayoutOrder = v176
		v_u_142[p_u_160] = {
			["frame"] = v173,
			["api"] = v174
		}
	end
	v177("list", "Listings open")
	v177("buy", "Buying open")
	v177("freeze", "Freeze everything")
	v177("book", "Buy orders open")
	v177("drain", "End all buy orders (drain)")
	v177("crates", "Trading cases (skin cases in the market)")
	v177("cashForRestricted", "Cash opening for restricted accounts")
	v177("rs", "Restock sales (MARKET RESTOCK)")
	v_u_121("BmScopeLabel", "Who may list and buy (browsing is always open)", v_u_103.muted)
	local v178 = p_u_99.touch
	local v179 = v_u_135(type(v178) ~= "function" and 32 or p_u_99.touch(32), "BmScopeRow")
	local function v_u_205(p180) -- name: setScope
		-- upvalues: (ref) v_u_136, (ref) v_u_140, (ref) v_u_141, (ref) v_u_137, (copy) p_u_98, (ref) v_u_3, (ref) v_u_139, (copy) v_u_103, (ref) v_u_108, (ref) v_u_138, (ref) v_u_145
		if p180 == "all" then
			local v181 = v_u_136
			local v182
			if type(v181) == "table" then
				v182 = v_u_136.canSeed == true
			else
				v182 = false
			end
			if not v182 then
				local v183 = os.clock()
				if v_u_140 == "scope:all" and v183 - v_u_141 <= 6 then
					v_u_140 = nil
					local v184 = {
						["cmd"] = "set",
						["scope"] = "all"
					}
					if not v_u_137 then
						local v185 = p_u_98
						if type(v185) ~= "function" then
							return
						end
						v_u_137 = true
						v_u_3.setText(v_u_139, "Working ...")
						v_u_139.TextColor3 = v_u_103.text2
						local v_u_186 = nil
						p_u_98("server.bm", v184, function(p187) -- name: done
							-- upvalues: (ref) v_u_137, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (copy) v_u_186, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
							v_u_137 = false
							if v_u_108 then
								v_u_138 = os.clock()
								if type(p187) == "table" then
									local v188 = p187.data
									if type(v188) == "table" then
										v_u_136 = p187.data
									end
									if not v_u_186 then
										local v189 = p187.msg or (p187.ok and "Done." or "Refused.")
										local v190 = tostring(v189)
										local v191 = p187.ok ~= true
										v_u_3.setText(v_u_139, v190)
										local v192 = v_u_139
										local v193
										if v191 then
											v193 = v_u_103.danger
										else
											v193 = v_u_103.text2
										end
										v192.TextColor3 = v193
									end
								elseif not v_u_186 then
									v_u_3.setText(v_u_139, "The server did not answer.")
									v_u_139.TextColor3 = v_u_103.danger
								end
								v_u_145(v_u_136)
							end
						end)
					end
				else
					v_u_140 = "scope:all"
					v_u_141 = v183
					local v194 = ("Everyone can list and buy in the live game. Press EVERYONE again within %d seconds to confirm."):format(6)
					v_u_3.setText(v_u_139, v194)
					v_u_139.TextColor3 = v_u_103.danger
				end
			end
		end
		v_u_140 = nil
		local v195 = {
			["cmd"] = "set",
			["scope"] = nil,
			["scope"] = p180
		}
		if not v_u_137 then
			local v196 = p_u_98
			if type(v196) ~= "function" then
				return
			end
			v_u_137 = true
			v_u_3.setText(v_u_139, "Working ...")
			v_u_139.TextColor3 = v_u_103.text2
			local v_u_197 = nil
			p_u_98("server.bm", v195, function(p198) -- name: done
				-- upvalues: (ref) v_u_137, (ref) v_u_108, (ref) v_u_138, (ref) v_u_136, (copy) v_u_197, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
				v_u_137 = false
				if v_u_108 then
					v_u_138 = os.clock()
					if type(p198) == "table" then
						local v199 = p198.data
						if type(v199) == "table" then
							v_u_136 = p198.data
						end
						if not v_u_197 then
							local v200 = p198.msg or (p198.ok and "Done." or "Refused.")
							local v201 = tostring(v200)
							local v202 = p198.ok ~= true
							v_u_3.setText(v_u_139, v201)
							local v203 = v_u_139
							local v204
							if v202 then
								v204 = v_u_103.danger
							else
								v204 = v_u_103.text2
							end
							v203.TextColor3 = v204
						end
					elseif not v_u_197 then
						v_u_3.setText(v_u_139, "The server did not answer.")
						v_u_139.TextColor3 = v_u_103.danger
					end
					v_u_145(v_u_136)
				end
			end)
		end
	end
	local v206 = (v_u_105 - 12) / 3
	local v207 = math.floor(v206)
	local v_u_208 = v_u_145
	local v_u_209 = v_u_136
	local v_u_210 = v_u_138
	local v_u_211 = v_u_139
	local v_u_212 = v_u_137
	for _, v213 in {
		{ "owner", "Owner" },
		{ "testers", "Testers" },
		{ "all", "Everyone" }
	} do
		local v_u_214 = v213[1]
		local v215 = v_u_3.button
		local v216 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v179,
			["text"] = v213[2]
		}
		local v217 = p_u_99.touch
		v216.height = type(v217) ~= "function" and 32 or p_u_99.touch(32)
		v216.width = v207
		v216.maxTextWidth = v207 - 12
		function v216.onClick() -- name: onClick
			-- upvalues: (copy) v_u_205, (copy) v_u_214
			v_u_205(v_u_214)
		end
		local v218, v219 = v215(v216)
		v218.Name = "BmScope_" .. v_u_214
		v_u_143[v_u_214] = {
			["btn"] = v218,
			["api"] = v219,
			["press"] = function() -- name: press
				-- upvalues: (copy) v_u_205, (copy) v_u_214
				v_u_205(v_u_214)
			end
		}
	end
	v_u_121("BmModeLabel", "Restricted accounts (no paid item trading)", v_u_103.muted)
	local v220 = p_u_99.touch
	local v221 = v_u_135(type(v220) ~= "function" and 32 or p_u_99.touch(32), "BmModeRow")
	local v222 = (v_u_105 - 6) / 2
	local v223 = math.floor(v222)
	for _, v224 in {
		{ "hide", "Hide paid" },
		{ "block", "Block all" }
	} do
		local v_u_225 = v224[1]
		local v226 = v_u_3.button
		local v227 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v221,
			["text"] = v224[2]
		}
		local v228 = p_u_99.touch
		v227.height = type(v228) ~= "function" and 32 or p_u_99.touch(32)
		v227.width = v223
		v227.maxTextWidth = v223 - 12
		function v227.onClick() -- name: onClick
			-- upvalues: (copy) v_u_225, (ref) v_u_140, (ref) v_u_212, (copy) p_u_98, (ref) v_u_3, (ref) v_u_211, (copy) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
			local v229 = v_u_225
			v_u_140 = nil
			local v230 = {
				["cmd"] = "set",
				["rm"] = nil,
				["rm"] = v229
			}
			if not v_u_212 then
				local v231 = p_u_98
				if type(v231) ~= "function" then
					return
				end
				v_u_212 = true
				v_u_3.setText(v_u_211, "Working ...")
				v_u_211.TextColor3 = v_u_103.text2
				local v_u_232 = nil
				p_u_98("server.bm", v230, function(p233) -- name: done
					-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_232, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
					v_u_212 = false
					if v_u_108 then
						v_u_210 = os.clock()
						if type(p233) == "table" then
							local v234 = p233.data
							if type(v234) == "table" then
								v_u_209 = p233.data
							end
							if not v_u_232 then
								local v235 = p233.msg or (p233.ok and "Done." or "Refused.")
								local v236 = tostring(v235)
								local v237 = p233.ok ~= true
								v_u_3.setText(v_u_211, v236)
								local v238 = v_u_211
								local v239
								if v237 then
									v239 = v_u_103.danger
								else
									v239 = v_u_103.text2
								end
								v238.TextColor3 = v239
							end
						elseif not v_u_232 then
							v_u_3.setText(v_u_211, "The server did not answer.")
							v_u_211.TextColor3 = v_u_103.danger
						end
						v_u_208(v_u_209)
					end
				end)
			end
		end
		local v240, v241 = v226(v227)
		v240.Name = "BmMode_" .. v_u_225
		v_u_144[v_u_225] = {
			["btn"] = v240,
			["api"] = v241,
			["press"] = function() -- name: press
				-- upvalues: (copy) v_u_225, (ref) v_u_140, (ref) v_u_212, (copy) p_u_98, (ref) v_u_3, (ref) v_u_211, (copy) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
				local v242 = v_u_225
				v_u_140 = nil
				local v243 = {
					["cmd"] = "set",
					["rm"] = nil,
					["rm"] = v242
				}
				if not v_u_212 then
					local v244 = p_u_98
					if type(v244) ~= "function" then
						return
					end
					v_u_212 = true
					v_u_3.setText(v_u_211, "Working ...")
					v_u_211.TextColor3 = v_u_103.text2
					local v_u_245 = nil
					p_u_98("server.bm", v243, function(p246) -- name: done
						-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_245, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
						v_u_212 = false
						if v_u_108 then
							v_u_210 = os.clock()
							if type(p246) == "table" then
								local v247 = p246.data
								if type(v247) == "table" then
									v_u_209 = p246.data
								end
								if not v_u_245 then
									local v248 = p246.msg or (p246.ok and "Done." or "Refused.")
									local v249 = tostring(v248)
									local v250 = p246.ok ~= true
									v_u_3.setText(v_u_211, v249)
									local v251 = v_u_211
									local v252
									if v250 then
										v252 = v_u_103.danger
									else
										v252 = v_u_103.text2
									end
									v251.TextColor3 = v252
								end
							elseif not v_u_245 then
								v_u_3.setText(v_u_211, "The server did not answer.")
								v_u_211.TextColor3 = v_u_103.danger
							end
							v_u_208(v_u_209)
						end
					end)
				end
			end
		}
	end
	v_u_121("BmSrvLabel", "Servers assumed (sizes the caches and hints)", v_u_103.muted)
	local v253 = p_u_99.touch
	local v254 = v_u_135(type(v253) ~= "function" and 34 or p_u_99.touch(34), "BmSrvRow")
	local function v_u_267(p255) -- name: setSrv
		-- upvalues: (ref) v_u_3, (ref) v_u_211, (copy) v_u_103, (ref) v_u_212, (copy) p_u_98, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
		local v256 = tonumber(p255)
		if v256 == nil or (v256 ~= math.floor(v256) or (v256 < 1 or v256 > 1000)) then
			v_u_3.setText(v_u_211, "Servers assumed must be a whole number from 1 to 1000.")
			v_u_211.TextColor3 = v_u_103.danger
		else
			local v257 = {
				["cmd"] = "set",
				["srv"] = nil,
				["srv"] = v256
			}
			if not v_u_212 then
				local v258 = p_u_98
				if type(v258) ~= "function" then
					return
				end
				v_u_212 = true
				v_u_3.setText(v_u_211, "Working ...")
				v_u_211.TextColor3 = v_u_103.text2
				local v_u_259 = nil
				p_u_98("server.bm", v257, function(p260) -- name: done
					-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_259, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
					v_u_212 = false
					if v_u_108 then
						v_u_210 = os.clock()
						if type(p260) == "table" then
							local v261 = p260.data
							if type(v261) == "table" then
								v_u_209 = p260.data
							end
							if not v_u_259 then
								local v262 = p260.msg or (p260.ok and "Done." or "Refused.")
								local v263 = tostring(v262)
								local v264 = p260.ok ~= true
								v_u_3.setText(v_u_211, v263)
								local v265 = v_u_211
								local v266
								if v264 then
									v266 = v_u_103.danger
								else
									v266 = v_u_103.text2
								end
								v265.TextColor3 = v266
							end
						elseif not v_u_259 then
							v_u_3.setText(v_u_211, "The server did not answer.")
							v_u_211.TextColor3 = v_u_103.danger
						end
						v_u_208(v_u_209)
					end
				end)
			end
		end
	end
	local v_u_268 = nil
	local v269, v_u_270 = v_u_3.input({
		["parent"] = nil,
		["name"] = "BmSrvInput",
		["placeholder"] = "40",
		["width"] = 120,
		["text"] = "",
		["parent"] = v254
	})
	v269.LayoutOrder = 1
	local v_u_271 = v_u_270
	v_u_270.FocusLost:Connect(function(p272)
		-- upvalues: (copy) v_u_267, (copy) v_u_270
		if p272 then
			v_u_267(v_u_270.Text)
		end
	end)
	local v273 = v_u_3.button
	local v274 = {
		["parent"] = nil,
		["text"] = "Set",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 90,
		["maxTextWidth"] = 78,
		["onClick"] = nil,
		["parent"] = v254
	}
	local v275 = p_u_99.touch
	v274.height = type(v275) ~= "function" and 34 or p_u_99.touch(34)
	function v274.onClick() -- name: onClick
		-- upvalues: (copy) v_u_267, (copy) v_u_270
		v_u_267(v_u_270.Text)
	end
	local v276 = v273(v274)
	v276.Name = "BmSrvSet"
	v276.LayoutOrder = 2
	local v277 = v_u_3.button
	local v278 = {
		["parent"] = nil,
		["text"] = "Set to ?",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 130,
		["maxTextWidth"] = 118,
		["onClick"] = nil,
		["parent"] = v254
	}
	local v279 = p_u_99.touch
	v278.height = type(v279) ~= "function" and 34 or p_u_99.touch(34)
	function v278.onClick() -- name: onClick
		-- upvalues: (ref) v_u_268, (copy) v_u_267
		if v_u_268 then
			local v280 = v_u_268
			v_u_267((tostring(v280)))
		end
	end
	local v281, v282 = v277(v278)
	v281.Name = "BmSrvMeasured"
	v281.LayoutOrder = 3
	v281.Visible = false
	local v_u_283 = v281
	local v_u_284 = v282
	v_u_121("BmMineLabel", "My daily listings (only your own counter)", v_u_103.muted)
	local v285 = p_u_99.touch
	local v286 = v_u_135(type(v285) ~= "function" and 34 or p_u_99.touch(34), "BmMineRow")
	local function v_u_299(p287) -- name: giveMore
		-- upvalues: (ref) v_u_3, (ref) v_u_211, (copy) v_u_103, (ref) v_u_212, (copy) p_u_98, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
		local v288 = tonumber(p287)
		if v288 == nil or (v288 ~= math.floor(v288) or (v288 < 1 or v288 > 1000)) then
			v_u_3.setText(v_u_211, "Give me more must be a whole number from 1 to 1000.")
			v_u_211.TextColor3 = v_u_103.danger
		else
			local v289 = {
				["cmd"] = "usage",
				["give"] = nil,
				["give"] = v288
			}
			if not v_u_212 then
				local v290 = p_u_98
				if type(v290) ~= "function" then
					return
				end
				v_u_212 = true
				v_u_3.setText(v_u_211, "Working ...")
				v_u_211.TextColor3 = v_u_103.text2
				local v_u_291 = nil
				p_u_98("server.bm", v289, function(p292) -- name: done
					-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_291, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
					v_u_212 = false
					if v_u_108 then
						v_u_210 = os.clock()
						if type(p292) == "table" then
							local v293 = p292.data
							if type(v293) == "table" then
								v_u_209 = p292.data
							end
							if not v_u_291 then
								local v294 = p292.msg or (p292.ok and "Done." or "Refused.")
								local v295 = tostring(v294)
								local v296 = p292.ok ~= true
								v_u_3.setText(v_u_211, v295)
								local v297 = v_u_211
								local v298
								if v296 then
									v298 = v_u_103.danger
								else
									v298 = v_u_103.text2
								end
								v297.TextColor3 = v298
							end
						elseif not v_u_291 then
							v_u_3.setText(v_u_211, "The server did not answer.")
							v_u_211.TextColor3 = v_u_103.danger
						end
						v_u_208(v_u_209)
					end
				end)
			end
		end
	end
	local v300 = v_u_3.button
	local v301 = {
		["parent"] = nil,
		["text"] = "Reset my usage",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 160,
		["maxTextWidth"] = 148,
		["onClick"] = nil,
		["parent"] = v286
	}
	local v302 = p_u_99.touch
	v301.height = type(v302) ~= "function" and 34 or p_u_99.touch(34)
	function v301.onClick() -- name: onClick
		-- upvalues: (ref) v_u_212, (copy) p_u_98, (ref) v_u_3, (ref) v_u_211, (copy) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
		local v303 = {
			["cmd"] = "usage",
			["set"] = 0
		}
		if not v_u_212 then
			local v304 = p_u_98
			if type(v304) ~= "function" then
				return
			end
			v_u_212 = true
			v_u_3.setText(v_u_211, "Working ...")
			v_u_211.TextColor3 = v_u_103.text2
			local v_u_305 = nil
			p_u_98("server.bm", v303, function(p306) -- name: done
				-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_305, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
				v_u_212 = false
				if v_u_108 then
					v_u_210 = os.clock()
					if type(p306) == "table" then
						local v307 = p306.data
						if type(v307) == "table" then
							v_u_209 = p306.data
						end
						if not v_u_305 then
							local v308 = p306.msg or (p306.ok and "Done." or "Refused.")
							local v309 = tostring(v308)
							local v310 = p306.ok ~= true
							v_u_3.setText(v_u_211, v309)
							local v311 = v_u_211
							local v312
							if v310 then
								v312 = v_u_103.danger
							else
								v312 = v_u_103.text2
							end
							v311.TextColor3 = v312
						end
					elseif not v_u_305 then
						v_u_3.setText(v_u_211, "The server did not answer.")
						v_u_211.TextColor3 = v_u_103.danger
					end
					v_u_208(v_u_209)
				end
			end)
		end
	end
	local v313 = v300(v301)
	v313.Name = "BmUsageReset"
	v313.LayoutOrder = 1
	local v314, v_u_315 = v_u_3.input({
		["parent"] = nil,
		["name"] = "BmGiveInput",
		["placeholder"] = "50",
		["width"] = 80,
		["text"] = "",
		["parent"] = v286
	})
	v314.LayoutOrder = 2
	local v_u_316 = v_u_315
	v_u_315.FocusLost:Connect(function(p317)
		-- upvalues: (copy) v_u_299, (copy) v_u_315
		if p317 then
			v_u_299(v_u_315.Text)
		end
	end)
	local v318 = v_u_3.button
	local v319 = {
		["parent"] = nil,
		["text"] = "Give me more",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 160,
		["maxTextWidth"] = 148,
		["onClick"] = nil,
		["parent"] = v286
	}
	local v320 = p_u_99.touch
	v319.height = type(v320) ~= "function" and 34 or p_u_99.touch(34)
	function v319.onClick() -- name: onClick
		-- upvalues: (copy) v_u_299, (ref) v_u_316
		v_u_299((not v_u_316 or v_u_316.Text == "") and "50" or v_u_316.Text)
	end
	local v321 = v318(v319)
	v321.Name = "BmUsageGive"
	v321.LayoutOrder = 3
	v_u_121("BmTestLabel", "Test tools (test game and Studio only)", v_u_103.muted)
	local v322 = p_u_99.touch
	local v_u_323 = v_u_135(type(v322) ~= "function" and 32 or p_u_99.touch(32), "BmTestRow")
	local v324 = (v_u_105 - 18) / 4
	local v_u_325 = math.floor(v324)
	local function v355(p326, p327, p328, p_u_329) -- name: addTest
		-- upvalues: (ref) v_u_3, (ref) v_u_323, (copy) p_u_99, (copy) v_u_325, (ref) v_u_212, (copy) p_u_98, (ref) v_u_211, (copy) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
		local v330 = v_u_3.button
		local v331 = {
			["parent"] = v_u_323,
			["text"] = p327,
			["kind"] = p328
		}
		local v332 = p_u_99.touch
		v331.height = type(v332) ~= "function" and 32 or p_u_99.touch(32)
		v331.width = v_u_325
		v331.maxTextWidth = v_u_325 - 12
		function v331.onClick() -- name: onClick
			-- upvalues: (copy) p_u_329, (ref) v_u_212, (ref) p_u_98, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
			local v333 = p_u_329
			if not v_u_212 then
				local v334 = p_u_98
				if type(v334) ~= "function" then
					return
				end
				v_u_212 = true
				v_u_3.setText(v_u_211, "Working ...")
				v_u_211.TextColor3 = v_u_103.text2
				local v_u_335 = nil
				p_u_98("server.bm", v333, function(p336) -- name: done
					-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_335, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
					v_u_212 = false
					if v_u_108 then
						v_u_210 = os.clock()
						if type(p336) == "table" then
							local v337 = p336.data
							if type(v337) == "table" then
								v_u_209 = p336.data
							end
							if not v_u_335 then
								local v338 = p336.msg or (p336.ok and "Done." or "Refused.")
								local v339 = tostring(v338)
								local v340 = p336.ok ~= true
								v_u_3.setText(v_u_211, v339)
								local v341 = v_u_211
								local v342
								if v340 then
									v342 = v_u_103.danger
								else
									v342 = v_u_103.text2
								end
								v341.TextColor3 = v342
							end
						elseif not v_u_335 then
							v_u_3.setText(v_u_211, "The server did not answer.")
							v_u_211.TextColor3 = v_u_103.danger
						end
						v_u_208(v_u_209)
					end
				end)
			end
		end
		local v343, v344 = v330(v331)
		v343.Name = p326
		return {
			["btn"] = v343,
			["api"] = v344,
			["press"] = function() -- name: press
				-- upvalues: (copy) p_u_329, (ref) v_u_212, (ref) p_u_98, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
				local v345 = p_u_329
				if not v_u_212 then
					local v346 = p_u_98
					if type(v346) ~= "function" then
						return
					end
					v_u_212 = true
					v_u_3.setText(v_u_211, "Working ...")
					v_u_211.TextColor3 = v_u_103.text2
					local v_u_347 = nil
					p_u_98("server.bm", v345, function(p348) -- name: done
						-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_347, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
						v_u_212 = false
						if v_u_108 then
							v_u_210 = os.clock()
							if type(p348) == "table" then
								local v349 = p348.data
								if type(v349) == "table" then
									v_u_209 = p348.data
								end
								if not v_u_347 then
									local v350 = p348.msg or (p348.ok and "Done." or "Refused.")
									local v351 = tostring(v350)
									local v352 = p348.ok ~= true
									v_u_3.setText(v_u_211, v351)
									local v353 = v_u_211
									local v354
									if v352 then
										v354 = v_u_103.danger
									else
										v354 = v_u_103.text2
									end
									v353.TextColor3 = v354
								end
							elseif not v_u_347 then
								v_u_3.setText(v_u_211, "The server did not answer.")
								v_u_211.TextColor3 = v_u_103.danger
							end
							v_u_208(v_u_209)
						end
					end)
				end
			end
		}
	end
	local v_u_356 = {
		["seed"] = v355("BmSeed", "Seed 40", "secondary", {
			["cmd"] = "seed",
			["n"] = 40
		}),
		["reset"] = v355("BmReset", "Clear seed", "secondary", {
			["cmd"] = "reset"
		}),
		["passOn"] = v355("BmPassOn", "Grant FIXER", "secondary", {
			["cmd"] = "pass",
			["on"] = true
		}),
		["passOff"] = v355("BmPassOff", "Remove FIXER", "ghost", {
			["cmd"] = "pass",
			["on"] = false
		})
	}
	local v_u_357 = v_u_121("BmSimLabel", "SIMULATE for your own account (test game and Studio only)", v_u_103.muted)
	local v_u_358 = {}
	local v_u_359 = {}
	local function v399(p_u_360, p361, p362) -- name: addSim
		-- upvalues: (copy) v_u_121, (copy) v_u_103, (copy) v_u_358, (copy) v_u_135, (copy) p_u_99, (copy) v_u_105, (ref) v_u_3, (ref) v_u_212, (copy) p_u_98, (ref) v_u_211, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208, (copy) v_u_359
		local v363 = v_u_121("BmSimText_" .. p_u_360, p361, v_u_103.text2)
		local v364 = v_u_358
		table.insert(v364, v363)
		local v365 = v_u_135
		local v366 = p_u_99.touch
		local v367 = v365(type(v366) ~= "function" and 32 or p_u_99.touch(32), "BmSim_" .. p_u_360)
		local v368 = v_u_358
		table.insert(v368, v367)
		local v369 = (v_u_105 - (#p362 - 1) * 6) / #p362
		local v370 = math.floor(v369)
		for _, v371 in p362 do
			local v_u_372 = v371[1]
			local v373 = v_u_3.button
			local v374 = {
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["maxTextWidth"] = nil,
				["onClick"] = nil,
				["parent"] = v367,
				["text"] = v371[2]
			}
			local v375 = p_u_99.touch
			v374.height = type(v375) ~= "function" and 32 or p_u_99.touch(32)
			v374.width = v370
			v374.maxTextWidth = v370 - 12
			function v374.onClick() -- name: onClick
				-- upvalues: (copy) p_u_360, (copy) v_u_372, (ref) v_u_212, (ref) p_u_98, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
				local v376 = {
					["cmd"] = "policy",
					["which"] = nil,
					["mode"] = nil,
					["which"] = p_u_360,
					["mode"] = v_u_372
				}
				if not v_u_212 then
					local v377 = p_u_98
					if type(v377) ~= "function" then
						return
					end
					v_u_212 = true
					v_u_3.setText(v_u_211, "Working ...")
					v_u_211.TextColor3 = v_u_103.text2
					local v_u_378 = nil
					p_u_98("server.bm", v376, function(p379) -- name: done
						-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_378, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
						v_u_212 = false
						if v_u_108 then
							v_u_210 = os.clock()
							if type(p379) == "table" then
								local v380 = p379.data
								if type(v380) == "table" then
									v_u_209 = p379.data
								end
								if not v_u_378 then
									local v381 = p379.msg or (p379.ok and "Done." or "Refused.")
									local v382 = tostring(v381)
									local v383 = p379.ok ~= true
									v_u_3.setText(v_u_211, v382)
									local v384 = v_u_211
									local v385
									if v383 then
										v385 = v_u_103.danger
									else
										v385 = v_u_103.text2
									end
									v384.TextColor3 = v385
								end
							elseif not v_u_378 then
								v_u_3.setText(v_u_211, "The server did not answer.")
								v_u_211.TextColor3 = v_u_103.danger
							end
							v_u_208(v_u_209)
						end
					end)
				end
			end
			local v386, v387 = v373(v374)
			v386.Name = ("BmSim_%s_%s"):format(p_u_360, v_u_372)
			local v398 = {
				["btn"] = v386,
				["api"] = v387,
				["press"] = function() -- name: press
					-- upvalues: (copy) p_u_360, (copy) v_u_372, (ref) v_u_212, (ref) p_u_98, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (ref) v_u_208
					local v388 = {
						["cmd"] = "policy",
						["which"] = nil,
						["mode"] = nil,
						["which"] = p_u_360,
						["mode"] = v_u_372
					}
					if not v_u_212 then
						local v389 = p_u_98
						if type(v389) ~= "function" then
							return
						end
						v_u_212 = true
						v_u_3.setText(v_u_211, "Working ...")
						v_u_211.TextColor3 = v_u_103.text2
						local v_u_390 = nil
						p_u_98("server.bm", v388, function(p391) -- name: done
							-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_390, (ref) v_u_3, (ref) v_u_211, (ref) v_u_103, (ref) v_u_208
							v_u_212 = false
							if v_u_108 then
								v_u_210 = os.clock()
								if type(p391) == "table" then
									local v392 = p391.data
									if type(v392) == "table" then
										v_u_209 = p391.data
									end
									if not v_u_390 then
										local v393 = p391.msg or (p391.ok and "Done." or "Refused.")
										local v394 = tostring(v393)
										local v395 = p391.ok ~= true
										v_u_3.setText(v_u_211, v394)
										local v396 = v_u_211
										local v397
										if v395 then
											v397 = v_u_103.danger
										else
											v397 = v_u_103.text2
										end
										v396.TextColor3 = v397
									end
								elseif not v_u_390 then
									v_u_3.setText(v_u_211, "The server did not answer.")
									v_u_211.TextColor3 = v_u_103.danger
								end
								v_u_208(v_u_209)
							end
						end)
					end
				end
			}
			v_u_359[p_u_360 .. ":" .. v_u_372] = v398
		end
	end
	v399("random", "SIMULATE: paid random items restricted", {
		{ "restricted", "Restricted" },
		{ "allowed", "Allowed" },
		{ "auto", "Auto" }
	})
	v399("trade", "SIMULATE: trading restricted (Korea)", {
		{ "restricted", "Restricted" },
		{ "allowed", "Allowed" },
		{ "auto", "Auto" }
	})
	v399("fail", "SIMULATE: account check fails", {
		{ "on", "Fails" },
		{ "off", "Works" }
	})
	v_u_139 = v_u_3.label({
		["parent"] = nil,
		["name"] = "BmStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_97,
		["color"] = v_u_103.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v400 = v_u_101.order
	local v401
	if type(v400) == "function" then
		v401 = v_u_101.order()
	else
		v_u_107 = v_u_107 + 1
		v401 = v_u_107
	end
	v_u_139.LayoutOrder = v401
	v_u_121("BmNote", "Switches reach every server within a minute. Closing listings or buying lets running ones finish, cancel and claim always work, freeze pauses every write. In the live game the market starts closed and for the owner only. Seed, clear and the FIXER grant exist in the test game and Studio only.", v_u_103.muted)
	v_u_145 = function(p402)
		-- upvalues: (copy) v_u_112, (ref) v_u_4, (copy) v_u_103, (ref) v_u_3, (copy) v_u_142, (copy) v_u_143, (copy) v_u_144, (ref) v_u_271, (ref) v_u_283, (ref) v_u_268, (ref) v_u_284, (ref) v_u_323, (copy) v_u_357, (copy) v_u_358, (copy) p_u_97, (copy) v_u_356, (ref) v_u_5
		for _, v403 in v_u_112:GetChildren() do
			if not v403:IsA("GuiObject") then
				continue
			end
			v403:Destroy()
		end
		for v404, v405 in v_u_4.lines(p402) do
			local v406
			if v405.kind == "ok" then
				v406 = v_u_103.success
			elseif v405.kind == "warn" then
				v406 = v_u_103.danger
			elseif v405.kind == "muted" then
				v406 = v_u_103.muted
			else
				v406 = v_u_103.text2
			end
			v_u_3.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_112,
				["name"] = "Bm" .. v405.name,
				["text"] = v405.text,
				["color"] = v406,
				["size"] = UDim2.new(1, 0, 0, 0)
			}).LayoutOrder = v404
		end
		local v407
		if type(p402) == "table" then
			v407 = p402.sw
		else
			v407 = nil
		end
		for v408, v409 in v_u_142 do
			if v408 == "crates" or v408 == "rs" then
				local v410 = v409.api.set
				local v411
				if type(v407) == "table" then
					v411 = v407[v408] ~= false
				else
					v411 = false
				end
				v410(v411)
			else
				local v412 = v409.api.set
				local v413
				if type(v407) == "table" then
					v413 = v407[v408] == true
				else
					v413 = false
				end
				v412(v413)
			end
		end
		for v414, v415 in v_u_143 do
			v415.api.setKind(type(v407) == "table" and v407.scope == v414 and "primary" or "secondary")
		end
		for v416, v417 in v_u_144 do
			v417.api.setKind(type(v407) == "table" and (v407.rm or "hide") == v416 and "primary" or "secondary")
		end
		if v_u_271 and (type(v407) == "table" and not v_u_271:IsFocused()) then
			local v418 = v_u_271
			local v419 = v407.srv or ""
			v418.Text = tostring(v419)
		end
		if v_u_283 then
			local v420
			if type(p402) == "table" then
				v420 = p402.servers
			else
				v420 = nil
			end
			local v421
			if type(v420) == "table" then
				local v422 = v420.measured
				if type(v422) == "number" and (v420.measured >= 1 and v420.measured <= 1000) then
					local v423 = v420.measured
					v421 = math.floor(v423)
				else
					v421 = nil
				end
			else
				v421 = nil
			end
			v_u_268 = v421
			local v424
			if v421 == nil or type(v407) ~= "table" then
				v424 = false
			else
				local v425 = v407.srv
				v424 = (tonumber(v425) or 0) < v421
			end
			v_u_283.Visible = v424
			if v424 then
				v_u_284.setText(("Set to %d"):format(v421))
			end
		end
		local v426
		if type(p402) == "table" then
			v426 = p402.canSeed == true
		else
			v426 = false
		end
		v_u_323.Visible = v426
		local v427
		if type(p402) == "table" then
			local v428 = p402.sim
			if type(v428) == "table" then
				v427 = p402.sim.can == true
			else
				v427 = false
			end
		else
			v427 = false
		end
		v_u_357.Visible = v427
		for _, v429 in v_u_358 do
			v429.Visible = v427
		end
		local v430 = p_u_97:FindFirstChild("BmTestLabel")
		if v430 then
			v430.Visible = v426
		end
		local v431
		if type(p402) == "table" then
			local v432 = p402.seed
			if type(v432) == "table" then
				v431 = p402.seed.running or nil
			else
				v431 = nil
			end
		else
			v431 = nil
		end
		for _, v433 in v_u_356 do
			v433.api.setEnabled(v431 == nil)
		end
		if v_u_5 then
			local v434 = type(v407) == "table" and v407 and v407 or {}
			local v435 = v_u_5
			local v436 = v434.list == true and 1 or 0
			local v437 = v434.buy == true and 1 or 0
			local v438 = v434.freeze == true and 1 or 0
			local v439 = v434.scope or "?"
			local v440 = tostring(v439)
			local v441 = v434.rm or "?"
			local v442 = tostring(v441)
			local v443 = v434.srv or "?"
			v435:SetAttribute("FilmBm", ("list=%d|buy=%d|freeze=%d|scope=%s|rm=%s|srv=%s|seed=%s|test=%d|crates=%d|cashr=%d|sim=%d"):format(v436, v437, v438, v440, v442, tostring(v443), tostring(v431 or "idle"), v426 and 1 or 0, v434.crates == false and 0 or 1, v434.cashForRestricted == true and 1 or 0, v427 and 1 or 0))
		end
	end
	v_u_145(nil)
	if v_u_2:IsStudio() and v_u_5 then
		local v_u_494 = v_u_5:GetAttributeChangedSignal("FilmBmCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_142, (ref) v_u_209, (ref) v_u_212, (copy) p_u_98, (ref) v_u_3, (ref) v_u_139, (copy) v_u_103, (ref) v_u_108, (ref) v_u_210, (ref) v_u_145, (copy) v_u_359, (copy) v_u_143, (copy) v_u_144, (copy) v_u_267, (ref) v_u_268, (copy) v_u_299, (copy) v_u_356, (copy) v_u_101
			local v444 = v_u_5:GetAttribute("FilmBmCmd")
			if type(v444) == "string" and v444 ~= "" then
				v_u_5:SetAttribute("FilmBmCmd", nil)
				local v445, v446 = string.match(v444, "^(%a+)%s*(%S*)$")
				if v445 == "toggle" and v_u_142[v446] then
					local v447 = v_u_209
					local v448
					if type(v447) == "table" then
						local v449 = v_u_209.sw
						if type(v449) == "table" then
							if v446 == "crates" or v446 == "rs" then
								v448 = v_u_209.sw[v446] ~= false
							else
								v448 = v_u_209.sw[v446] == true
							end
						else
							v448 = false
						end
					else
						v448 = false
					end
					local v450 = {
						["cmd"] = "set",
						[v446] = not v448
					}
					if not v_u_212 then
						local v451 = p_u_98
						if type(v451) == "function" then
							v_u_212 = true
							v_u_3.setText(v_u_139, "Working ...")
							v_u_139.TextColor3 = v_u_103.text2
							local v_u_452 = nil
							p_u_98("server.bm", v450, function(p453) -- name: done
								-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_452, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
								v_u_212 = false
								if v_u_108 then
									v_u_210 = os.clock()
									if type(p453) == "table" then
										local v454 = p453.data
										if type(v454) == "table" then
											v_u_209 = p453.data
										end
										if not v_u_452 then
											local v455 = p453.msg or (p453.ok and "Done." or "Refused.")
											local v456 = tostring(v455)
											local v457 = p453.ok ~= true
											v_u_3.setText(v_u_139, v456)
											local v458 = v_u_139
											local v459
											if v457 then
												v459 = v_u_103.danger
											else
												v459 = v_u_103.text2
											end
											v458.TextColor3 = v459
										end
									elseif not v_u_452 then
										v_u_3.setText(v_u_139, "The server did not answer.")
										v_u_139.TextColor3 = v_u_103.danger
									end
									v_u_145(v_u_209)
								end
							end)
						end
					end
				else
					if v445 == "sim" and v_u_359[v446] then
						v_u_359[v446].press()
						return
					end
					if v445 == "scope" and v_u_143[v446] then
						v_u_143[v446].press()
						return
					end
					if v445 == "mode" and v_u_144[v446] then
						v_u_144[v446].press()
						return
					end
					if v445 == "srv" then
						v_u_267(v446)
						return
					end
					if v445 == "srvmeasured" then
						if v_u_268 then
							local v460 = v_u_268
							v_u_267((tostring(v460)))
							return
						end
					elseif v445 == "usage" then
						if v446 ~= "reset" and v446 ~= "" then
							v_u_299(v446)
							return
						end
						local v461 = {
							["cmd"] = "usage",
							["set"] = 0
						}
						if not v_u_212 then
							local v462 = p_u_98
							if type(v462) == "function" then
								v_u_212 = true
								v_u_3.setText(v_u_139, "Working ...")
								v_u_139.TextColor3 = v_u_103.text2
								local v_u_463 = nil
								p_u_98("server.bm", v461, function(p464) -- name: done
									-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_463, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
									v_u_212 = false
									if v_u_108 then
										v_u_210 = os.clock()
										if type(p464) == "table" then
											local v465 = p464.data
											if type(v465) == "table" then
												v_u_209 = p464.data
											end
											if not v_u_463 then
												local v466 = p464.msg or (p464.ok and "Done." or "Refused.")
												local v467 = tostring(v466)
												local v468 = p464.ok ~= true
												v_u_3.setText(v_u_139, v467)
												local v469 = v_u_139
												local v470
												if v468 then
													v470 = v_u_103.danger
												else
													v470 = v_u_103.text2
												end
												v469.TextColor3 = v470
											end
										elseif not v_u_463 then
											v_u_3.setText(v_u_139, "The server did not answer.")
											v_u_139.TextColor3 = v_u_103.danger
										end
										v_u_145(v_u_209)
									end
								end)
							end
						end
					else
						if v445 == "seed" then
							v_u_356.seed.press()
							return
						end
						if v445 == "reset" then
							v_u_356.reset.press()
							return
						end
						if v445 == "pass" then
							local v471 = {
								["cmd"] = "pass",
								["on"] = nil,
								["on"] = v446 ~= "off"
							}
							if not v_u_212 then
								local v472 = p_u_98
								if type(v472) == "function" then
									v_u_212 = true
									v_u_3.setText(v_u_139, "Working ...")
									v_u_139.TextColor3 = v_u_103.text2
									local v_u_473 = nil
									p_u_98("server.bm", v471, function(p474) -- name: done
										-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_473, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
										v_u_212 = false
										if v_u_108 then
											v_u_210 = os.clock()
											if type(p474) == "table" then
												local v475 = p474.data
												if type(v475) == "table" then
													v_u_209 = p474.data
												end
												if not v_u_473 then
													local v476 = p474.msg or (p474.ok and "Done." or "Refused.")
													local v477 = tostring(v476)
													local v478 = p474.ok ~= true
													v_u_3.setText(v_u_139, v477)
													local v479 = v_u_139
													local v480
													if v478 then
														v480 = v_u_103.danger
													else
														v480 = v_u_103.text2
													end
													v479.TextColor3 = v480
												end
											elseif not v_u_473 then
												v_u_3.setText(v_u_139, "The server did not answer.")
												v_u_139.TextColor3 = v_u_103.danger
											end
											v_u_145(v_u_209)
										end
									end)
								end
							end
						elseif v445 == "refresh" then
							local v481 = {
								["cmd"] = "status"
							}
							if not v_u_212 then
								local v482 = p_u_98
								if type(v482) ~= "function" then
									return
								end
								v_u_212 = true
								local v_u_483 = true
								local function v491(p484) -- name: done
									-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_483, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
									v_u_212 = false
									if v_u_108 then
										v_u_210 = os.clock()
										if type(p484) == "table" then
											local v485 = p484.data
											if type(v485) == "table" then
												v_u_209 = p484.data
											end
											if not v_u_483 then
												local v486 = p484.msg or (p484.ok and "Done." or "Refused.")
												local v487 = tostring(v486)
												local v488 = p484.ok ~= true
												v_u_3.setText(v_u_139, v487)
												local v489 = v_u_139
												local v490
												if v488 then
													v490 = v_u_103.danger
												else
													v490 = v_u_103.text2
												end
												v489.TextColor3 = v490
											end
										elseif not v_u_483 then
											v_u_3.setText(v_u_139, "The server did not answer.")
											v_u_139.TextColor3 = v_u_103.danger
										end
										v_u_145(v_u_209)
									end
								end
								local v492 = v_u_101.sendQuiet
								local v493
								if type(v492) == "function" then
									v493 = v_u_101.sendQuiet
								else
									v493 = p_u_98
								end
								v493("server.bm", v481, v491)
							end
						end
					end
				end
			end
		end)
		if v_u_106 then
			v_u_106.Destroying:Connect(function()
				-- upvalues: (copy) v_u_494
				v_u_494:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_108, (copy) v_u_106, (copy) p_u_97, (ref) v_u_209, (ref) v_u_212, (ref) v_u_210, (copy) p_u_98, (ref) v_u_3, (ref) v_u_139, (copy) v_u_103, (ref) v_u_145, (copy) v_u_101
		local v495 = false
		while v_u_108 do
			local v496 = v_u_106 == nil or v_u_106.Enabled
			if v496 then
				v496 = p_u_97.Visible
			end
			local v497 = v_u_209
			local v498
			if type(v497) == "table" then
				local v499 = v_u_209.seed
				if type(v499) == "table" then
					v498 = v_u_209.seed.running ~= nil
				else
					v498 = false
				end
			else
				v498 = false
			end
			if v496 and (not v_u_212 and (not v495 or (v498 and 1 or 5) <= os.clock() - v_u_210)) then
				v_u_210 = os.clock()
				local v500 = {
					["cmd"] = "status"
				}
				if not v_u_212 then
					local v501 = p_u_98
					if type(v501) == "function" then
						v_u_212 = true
						local v_u_502 = true
						local function v510(p503) -- name: done
							-- upvalues: (ref) v_u_212, (ref) v_u_108, (ref) v_u_210, (ref) v_u_209, (copy) v_u_502, (ref) v_u_3, (ref) v_u_139, (ref) v_u_103, (ref) v_u_145
							v_u_212 = false
							if v_u_108 then
								v_u_210 = os.clock()
								if type(p503) == "table" then
									local v504 = p503.data
									if type(v504) == "table" then
										v_u_209 = p503.data
									end
									if not v_u_502 then
										local v505 = p503.msg or (p503.ok and "Done." or "Refused.")
										local v506 = tostring(v505)
										local v507 = p503.ok ~= true
										v_u_3.setText(v_u_139, v506)
										local v508 = v_u_139
										local v509
										if v507 then
											v509 = v_u_103.danger
										else
											v509 = v_u_103.text2
										end
										v508.TextColor3 = v509
									end
								elseif not v_u_502 then
									v_u_3.setText(v_u_139, "The server did not answer.")
									v_u_139.TextColor3 = v_u_103.danger
								end
								v_u_145(v_u_209)
							end
						end
						local v511 = v_u_101.sendQuiet
						local v512
						if type(v511) == "function" then
							v512 = v_u_101.sendQuiet
						else
							v512 = p_u_98
						end
						v512("server.bm", v500, v510)
					end
				end
			end
			task.wait(0.5)
			v495 = v496
		end
	end)
	return {
		["refresh"] = v159,
		["paint"] = function(p513) -- name: paint
			-- upvalues: (ref) v_u_209, (ref) v_u_145
			v_u_209 = p513
			v_u_145(p513)
		end
	}
end
return v_u_4