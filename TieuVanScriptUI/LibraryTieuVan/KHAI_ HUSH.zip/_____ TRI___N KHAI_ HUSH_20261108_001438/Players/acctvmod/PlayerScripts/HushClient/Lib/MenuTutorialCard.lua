-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTutorialCard

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v_u_1.state(p3) -- name: state
	-- upvalues: (copy) v_u_2
	local v4 = v_u_2:GetAttribute("TutorialDone")
	if v4 == nil then
		local v5 = p3.profile
		if type(v5) == "table" and v5.tutorialDone == false then
			v4 = false
		end
	end
	local v6 = v_u_2:GetAttribute("TutorialResult")
	local v7 = v_u_2:GetAttribute("TutorialResultId")
	return v6 == "complete" and (type(v7) == "number" and v7 ~= p3.tutorialDismissed) and "complete" or (v4 == false and (v6 == "failed" and "retry" or "offer") or (v4 == true and (v_u_2:GetAttribute("TutorialOfferNew") == true and p3.tutorialAgainGone ~= true) and "again" or nil))
end
function v_u_1.firstRaid(p8) -- name: firstRaid
	-- upvalues: (copy) v_u_1
	local v9
	if v_u_1.state(p8) == "offer" then
		local v10 = p8.profile
		local v11
		if type(v10) == "table" then
			local v12 = v10.stats
			v11 = type(v12) == "table" and v10.stats or nil
		else
			v11 = nil
		end
		local v13
		if v11 then
			local v14 = v11.raids
			v13 = tonumber(v14)
		else
			v13 = nil
		end
		v9 = v13 == 0
	else
		v9 = false
	end
	return v9
end
function v_u_1.gateDeploy(p_u_15, p_u_16) -- name: gateDeploy
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if p_u_15.firstRaidGateOpen then
		return true
	end
	local v17 = p_u_15.gateForce == true
	p_u_15.gateForce = nil
	if not v17 then
		if p_u_15.firstRaidGateDeclined or not v_u_1.firstRaid(p_u_15) then
			return false
		end
		local v18 = p_u_15.myParty
		local v19
		if type(v18) == "function" then
			v19 = p_u_15.myParty() or nil
		else
			v19 = nil
		end
		if v19 ~= nil then
			local v20 = v19.members
			if type(v20) == "table" and #v19.members > 1 then
				return false
			end
		end
	end
	local v21 = p_u_15.ui
	if type(v21) == "table" then
		local v22 = v21.modal
		if type(v22) == "function" then
			p_u_15.firstRaidGateOpen = true
			local v23 = v21.modal
			local v26, v27 = pcall(v23, {
				["title"] = "First raid?",
				["body"] = "The tutorial is a five minute solo night raid with nothing of yours at stake. It shows how to search, fight quietly and, above all, how to get out: loot only counts once you extract.",
				["width"] = 560,
				["buttons"] = nil,
				["onClose"] = nil,
				["buttons"] = {
					{
						["text"] = "Deploy anyway",
						["kind"] = "secondary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) p_u_15, (copy) p_u_16
							p_u_15.firstRaidGateOpen = nil
							p_u_15.firstRaidGateDeclined = true
							task.defer(p_u_16)
						end
					},
					{
						["text"] = "Play tutorial",
						["kind"] = "primary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) p_u_15
							p_u_15.firstRaidGateOpen = nil
							local v24 = p_u_15.tutorialCard
							if type(v24) == "table" then
								local v25 = v24.main
								if type(v25) == "function" then
									task.defer(v24.main)
									return
								end
							end
							p_u_15.op({
								["op"] = "tutorialStart"
							})
						end
					}
				},
				["onClose"] = function() -- name: onClose
					-- upvalues: (copy) p_u_15
					p_u_15.firstRaidGateOpen = nil
				end
			})
			if not v26 or type(v27) ~= "table" then
				p_u_15.firstRaidGateOpen = nil
				return false
			end
			local v28 = v_u_2
			v_u_2:SetAttribute("FirstRaidGateShown", (tonumber(v28:GetAttribute("FirstRaidGateShown")) or 0) + 1)
			return true
		end
	end
	return false
end
function v_u_1.startBlock(p29) -- name: startBlock
	-- upvalues: (copy) v_u_2
	local v30 = v_u_2:GetAttribute("Place")
	if v30 ~= nil and (v30 ~= "Menu" and v30 ~= "Hideout") or v_u_2:GetAttribute("Tutorial") == true then
		return "Finish your current raid first."
	end
	local v31 = p29.myParty
	local v32
	if type(v31) == "function" then
		v32 = p29.myParty() or nil
	else
		v32 = nil
	end
	if type(v32) == "table" then
		local v33 = v32.members
		if type(v33) == "table" and #v32.members > 1 then
			return "Leave your squad first. The tutorial is a solo raid."
		end
	end
	if type(v32) == "table" then
		local v34 = v32.searching
		if type(v34) == "table" then
			return "Stop the raid search first."
		end
	end
	local v35 = p29.party
	local v36
	if type(v32) == "table" and v32.deploying ~= nil then
		v36 = v32.deploying
	elseif type(v35) == "table" then
		v36 = v35.deploying
	else
		v36 = nil
	end
	if v36 == true or (type(v36) == "table" or type(v36) == "number" and v36 > 0) then
		return "A deploy is already under way."
	end
	local v37 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
	return v37 and v37:GetAttribute("DeployClosed") == true and "Deployments are closed right now." or nil
end
local function v_u_46(p_u_38) -- name: rewardMoney
	local v_u_39 = 750
	local function v41()
		-- upvalues: (copy) p_u_38, (ref) v_u_39
		local v40 = p_u_38.cctx.shared.TutorialSteps.REWARD.cash
		v_u_39 = tonumber(v40) or v_u_39
	end
	pcall(v41)
	local function v42()
		-- upvalues: (copy) p_u_38, (ref) v_u_39
		return p_u_38.kit.money(v_u_39)
	end
	local v43, v44 = pcall(v42)
	if not v43 or type(v44) ~= "string" then
		local v45 = v_u_39
		v44 = "$" .. tostring(v45)
	end
	return v44
end
v_u_1.rewardMoney = v_u_46
function v_u_1.rewardOpen() -- name: rewardOpen
	-- upvalues: (copy) v_u_2
	local v47
	if v_u_2:GetAttribute("TutorialDone") == true then
		v47 = v_u_2:GetAttribute("TutorialRewardOpen") == true
	else
		v47 = false
	end
	return v47
end
local function v_u_61(p_u_48) -- name: rewardText
	-- upvalues: (copy) v_u_2
	local v49 = v_u_2
	local v50 = tonumber(v49:GetAttribute("TutorialRewardCash")) or 0
	if v50 <= 0 then
		return "Everything you carried out is in your stash."
	end
	local v51 = {}
	local v_u_52 = nil
	local function v53()
		-- upvalues: (ref) v_u_52, (copy) p_u_48
		v_u_52 = p_u_48.cctx.shared.TutorialSteps
	end
	pcall(v53)
	local v54
	if v_u_52 then
		local v55 = v_u_52.REWARD
		if type(v55) == "table" then
			v54 = v_u_52.REWARD.items or nil
		else
			v54 = nil
		end
	else
		v54 = nil
	end
	if type(v54) == "table" then
		for _, v56 in v54 do
			if type(v56) ~= "table" or not v56.id then
				continue
			end
			local v57 = v56.n
			local v58 = tonumber(v57) or 1
			local v59 = p_u_48.kit.itemName
			local v60 = v56.id
			table.insert(v51, ("%d x %s"):format(v58, v59(v60)))
		end
	end
	return ("%s%s went into your stash, next to everything you carried out."):format(p_u_48.kit.money(v50), #v51 <= 0 and "" or " and " .. table.concat(v51, ", "))
end
function v_u_1.new(p_u_62, p63, p64, p65) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_61, (copy) v_u_46, (copy) v_u_2
	local v_u_66 = p_u_62.ui
	local v_u_67 = p_u_62.theme
	local v_u_68 = v_u_67.color
	local v69 = p_u_62.kit
	local v_u_70 = p_u_62.compact()
	v_u_1.lastMc = p_u_62
	local v_u_71 = v_u_70
	local function v73()
		-- upvalues: (copy) v_u_67, (ref) v_u_71
		local v72 = v_u_67.viewport()
		if typeof(v72) == "Vector2" and (v72.X > 1 and v72.X <= 844) then
			v_u_71 = true
		end
	end
	pcall(v73)
	local v_u_74
	if type(p65) == "table" and p65.form == "row" then
		v_u_71 = true
		v_u_74 = v_u_71
	elseif type(p65) == "table" and p65.form == "card" then
		v_u_71 = false
		v_u_74 = v_u_71
	else
		v_u_74 = v_u_71
	end
	local v_u_75 = {}
	local v_u_76 = true
	local v_u_77 = {}
	local v_u_78 = 0
	local v_u_79 = 0
	local v_u_80 = nil
	local v_u_81, v_u_82 = v69.card(p63, {
		["name"] = "Tutorial",
		["order"] = nil,
		["accent"] = true,
		["gap"] = 4,
		["order"] = p64
	})
	v_u_81.Visible = false
	v_u_75.frame = v_u_81
	local v_u_83 = v_u_66.label({
		["parent"] = nil,
		["name"] = "Kicker",
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["order"] = 1,
		["size"] = nil,
		["parent"] = v_u_82,
		["color"] = v_u_68.accent,
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v_u_84 = v_u_66.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "h2",
		["order"] = 2,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_82,
		["size"] = UDim2.new(1, 0, 0, v_u_70 and 26 or 30)
	})
	local v_u_85 = v_u_66.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = "",
		["style"] = "small",
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v_u_82
	})
	local v_u_86 = v_u_66.label({
		["parent"] = nil,
		["name"] = "Note",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 4,
		["visible"] = false,
		["parent"] = v_u_82,
		["color"] = v_u_68.accent
	})
	local v_u_87 = v_u_67.touch(v_u_70 and 40 or 44)
	local v_u_88 = v_u_66.new("Frame", {
		["Name"] = "Buttons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 5,
		["Size"] = UDim2.new(1, 0, 0, v_u_87 + (v_u_74 and 0 or 8))
	}, v_u_82)
	if not v_u_74 then
		v_u_66.pad(v_u_88, {
			0,
			0,
			8,
			0
		})
	end
	local v_u_89 = 140
	local v_u_90 = 112
	if v_u_74 then
		local v91 = p_u_62.playColW
		if type(v91) == "function" and p_u_62.playColW() < 440 then
			v_u_89 = 120
			v_u_90 = 96
		end
	end
	local v92 = v_u_66.button
	local v93 = {
		["parent"] = nil,
		["text"] = "Start tutorial",
		["kind"] = "primary",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_88
	}
	local v94
	if v_u_74 then
		v94 = UDim2.new(0, v_u_89, 1, 0)
	else
		v94 = UDim2.new(0.6, -4, 1, 0)
	end
	v93.size = v94
	local v95
	if v_u_74 then
		v95 = UDim2.new(1, -v_u_90 - 8, 0, 0)
	else
		v95 = nil
	end
	v93.position = v95
	local v96
	if v_u_74 then
		v96 = Vector2.new(1, 0)
	else
		v96 = nil
	end
	v93.anchor = v96
	function v93.onClick() -- name: onClick
		-- upvalues: (copy) v_u_75
		v_u_75.main()
	end
	local v_u_97, v_u_98 = v92(v93)
	v_u_97.Name = "Main"
	local v99 = v_u_66.button
	local v100 = {
		["parent"] = nil,
		["text"] = "Skip",
		["kind"] = "close",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_88
	}
	local v101
	if v_u_74 then
		v101 = UDim2.new(0, v_u_90, 1, 0)
	else
		v101 = UDim2.new(0.4, -4, 1, 0)
	end
	v100.size = v101
	v100.position = UDim2.fromScale(1, 0)
	v100.anchor = Vector2.new(1, 0)
	function v100.onClick() -- name: onClick
		-- upvalues: (copy) v_u_75
		v_u_75.side()
	end
	local v_u_102, v_u_103 = v99(v100)
	v_u_102.Name = "Side"
	if v_u_74 then
		v_u_83.Visible = false
		v_u_85.Visible = false
		v_u_84.Parent = v_u_88
		v_u_84.AnchorPoint = Vector2.new(0, 0.5)
		v_u_84.Position = UDim2.fromScale(0, 0.5)
		v_u_84.Size = UDim2.new(1, -(v_u_89 + v_u_90 + 16 + 8), 0, 24)
		v_u_84.TextSize = 18
		v_u_84.TextTruncate = Enum.TextTruncate.AtEnd
	end
	local v_u_104 = v_u_84.TextSize
	local function v_u_117(p105) -- name: applyForm
		-- upvalues: (ref) v_u_74, (copy) v_u_82, (copy) v_u_67, (copy) v_u_88, (copy) v_u_87, (copy) v_u_66, (copy) v_u_97, (ref) v_u_89, (ref) v_u_90, (copy) v_u_102, (copy) v_u_83, (copy) v_u_85, (copy) v_u_84, (copy) v_u_70, (copy) v_u_104, (copy) v_u_75
		v_u_74 = p105
		local v106 = v_u_82:FindFirstChildOfClass("UIPadding")
		if v106 then
			local v107 = UDim.new(0, p105 and 8 or v_u_67.space.m)
			v106.PaddingLeft = v107
			v106.PaddingRight = v107
			v106.PaddingTop = v107
			v106.PaddingBottom = v107
		end
		v_u_88.Size = UDim2.new(1, 0, 0, v_u_87 + (p105 and 0 or 8))
		local v108 = v_u_88:FindFirstChildOfClass("UIPadding")
		if p105 then
			if v108 then
				v108:Destroy()
			end
		elseif not v108 then
			v_u_66.pad(v_u_88, {
				0,
				0,
				8,
				0
			})
		end
		local v109 = v_u_97
		local v110
		if p105 then
			v110 = UDim2.new(0, v_u_89, 1, 0)
		else
			v110 = UDim2.new(0.6, -4, 1, 0)
		end
		v109.Size = v110
		local v111 = v_u_97
		local v112
		if p105 then
			v112 = UDim2.new(1, -v_u_90 - 8, 0, 0)
		else
			v112 = UDim2.fromOffset(0, 0)
		end
		v111.Position = v112
		local v113 = v_u_97
		local v114
		if p105 then
			v114 = Vector2.new(1, 0)
		else
			v114 = Vector2.zero
		end
		v113.AnchorPoint = v114
		local v115 = v_u_102
		local v116
		if p105 then
			v116 = UDim2.new(0, v_u_90, 1, 0)
		else
			v116 = UDim2.new(0.4, -4, 1, 0)
		end
		v115.Size = v116
		v_u_83.Visible = not p105
		v_u_85.Visible = not p105
		if p105 then
			v_u_84.Parent = v_u_88
			v_u_84.AnchorPoint = Vector2.new(0, 0.5)
			v_u_84.Position = UDim2.fromScale(0, 0.5)
			v_u_84.Size = UDim2.new(1, -(v_u_89 + v_u_90 + 16 + 8), 0, 24)
			v_u_84.TextSize = 18
			v_u_84.TextTruncate = Enum.TextTruncate.AtEnd
		else
			v_u_84.Parent = v_u_82
			v_u_84.AnchorPoint = Vector2.zero
			v_u_84.Position = UDim2.fromOffset(0, 0)
			v_u_84.Size = UDim2.new(1, 0, 0, v_u_70 and 26 or 30)
			v_u_84.TextSize = v_u_104
		end
		v_u_75.paint()
	end
	function v_u_75.form() -- name: form
		-- upvalues: (ref) v_u_74
		return v_u_74 and "row" or "card"
	end
	function v_u_75.setForm(p118) -- name: setForm
		-- upvalues: (ref) v_u_74, (copy) v_u_117
		local v119 = p118 == "row"
		if v119 ~= v_u_74 then
			v_u_117(v119)
		end
	end
	function v_u_75.heightFor(p120, p121) -- name: heightFor
		-- upvalues: (copy) p_u_62, (copy) v_u_86, (copy) v_u_87, (copy) v_u_67, (copy) v_u_85, (copy) v_u_70
		local v_u_122 = nil
		local function v123()
			-- upvalues: (ref) v_u_122, (ref) p_u_62
			v_u_122 = p_u_62.cctx.lib.TutorialCardLayout
		end
		pcall(v123)
		local v124 = v_u_86.Visible and #v_u_86.Text or 0
		if p120 == "row" then
			if type(v_u_122) == "table" then
				return v_u_122.rowHeight({
					["w"] = p121 or 400,
					["scale"] = v_u_67.uiScale(),
					["touch"] = v_u_87,
					["noteChars"] = v124
				})
			else
				return v_u_87 + 16
			end
		else
			return type(v_u_122) ~= "table" and 156 or v_u_122.cardHeight({
				["w"] = p121 or 400,
				["scale"] = v_u_67.uiScale(),
				["touch"] = v_u_87,
				["bodyChars"] = #v_u_85.Text,
				["noteChars"] = v124,
				["compact"] = v_u_70
			})
		end
	end
	function v_u_75.state() -- name: state
		-- upvalues: (ref) v_u_1, (copy) p_u_62
		return v_u_1.state(p_u_62)
	end
	local v_u_125 = ""
	local v_u_126 = false
	local v_u_127 = nil
	function v_u_75.paint() -- name: paint
		-- upvalues: (ref) v_u_127, (ref) v_u_76, (ref) v_u_80, (copy) v_u_81, (copy) v_u_86, (copy) v_u_85, (ref) v_u_125, (copy) v_u_75, (ref) v_u_126
		v_u_127()
		if v_u_76 then
			local v128 = table.concat
			local v129 = {}
			local v130 = v_u_80
			local v131 = tostring(v130)
			local v132 = v_u_81.Visible
			local v133 = tostring(v132)
			local v134 = v_u_86.Visible
			__set_list(v129, 1, {v131, v133, tostring(v134), v_u_86.Text, v_u_85.Text})
			local v135 = v128(v129, "\1")
			if v135 ~= v_u_125 then
				v_u_125 = v135
				local v136 = v_u_75.onChange
				if type(v136) == "function" and not v_u_126 then
					v_u_126 = true
					pcall(v136)
					v_u_126 = false
				end
			end
		end
	end
	v_u_127 = function() -- name: paintBody
		-- upvalues: (ref) v_u_76, (ref) v_u_1, (copy) p_u_62, (copy) v_u_81, (ref) v_u_80, (ref) v_u_78, (copy) v_u_83, (copy) v_u_68, (copy) v_u_66, (copy) v_u_84, (ref) v_u_74, (copy) v_u_85, (ref) v_u_61, (copy) v_u_86, (copy) v_u_98, (copy) v_u_103, (ref) v_u_46, (ref) v_u_79
		if v_u_76 then
			local v137 = v_u_1.state(p_u_62)
			v_u_81.Visible = v137 ~= nil
			if v137 ~= v_u_80 then
				v_u_78 = 0
			end
			v_u_80 = v137
			if v137 == nil then
				return
			else
				local v138 = os.clock()
				if v137 == "complete" then
					v_u_83.TextColor3 = v_u_68.success
					v_u_66.setText(v_u_83, "Tutorial complete")
					v_u_66.setText(v_u_84, v_u_74 and "Tutorial complete" or "Back at base")
					v_u_85.Text = v_u_61(p_u_62) .. " Doc has your first job under TASKS."
					v_u_86.Visible = false
					v_u_98.setText(v_u_74 and "Tasks" or "Open tasks")
					v_u_98.setKind("primary")
					v_u_98.setEnabled(true)
					v_u_103.setText("Dismiss")
					v_u_103.setKind("close")
					v_u_103.setEnabled(true)
					return
				else
					v_u_83.TextColor3 = v_u_68.accent
					if v137 == "again" then
						if v_u_1.rewardOpen() then
							local v139 = v_u_46(p_u_62)
							v_u_66.setText(v_u_83, "Tutorial  \194\183  " .. v139 .. " waiting")
							v_u_66.setText(v_u_84, not v_u_74 and "Finish the tutorial" or "Tutorial: " .. v139)
							v_u_85.Text = ("You skipped it before. Finish it once and get %s. A short solo night raid, nothing of yours is at stake."):format(v139)
						else
							v_u_66.setText(v_u_83, "Tutorial  \194\183  practice run")
							v_u_66.setText(v_u_84, v_u_74 and "Tutorial got better" or "The tutorial got better")
							v_u_85.Text = "Want to give it a try? Practice run, no reward. Nothing you find or carry is kept, and nothing of yours is at stake."
						end
						local v140 = v_u_1.startBlock
						local v141 = p_u_62
						local v142, v143 = pcall(v140, v141)
						if not v142 then
							v143 = nil
						end
						local v144 = v138 < v_u_79
						v_u_86.Text = v143 or ""
						local v145 = v_u_86
						local v146
						if v143 == nil then
							v146 = false
						else
							v146 = not v144
						end
						v145.Visible = v146
						if v_u_74 then
							v_u_98.setText(v144 and "Starting" or "Play")
						else
							v_u_98.setText(v144 and "Starting..." or "Play tutorial")
						end
						v_u_98.setKind("primary")
						local v147 = v_u_98.setEnabled
						local v148
						if v143 == nil then
							v148 = not v144
						else
							v148 = false
						end
						v147(v148)
						v_u_103.setText(v_u_74 and "Dismiss" or "No thanks")
						v_u_103.setKind("close")
						v_u_103.setEnabled(not v144)
					else
						if v137 == "retry" then
							v_u_66.setText(v_u_83, "Tutorial not finished")
							v_u_66.setText(v_u_84, v_u_74 and "Tutorial unfinished" or "Try it again")
							v_u_85.Text = "Nothing was lost: the tutorial raid never puts your own gear at risk. Run it again, or skip it and deploy for real."
						else
							local v149 = v_u_1.firstRaid(p_u_62)
							v_u_66.setText(v_u_83, v149 and "Start here  \194\183  5 min" or "Tutorial  \194\183  5 min")
							v_u_66.setText(v_u_84, v_u_74 and "Tutorial \194\183 5 min" or "First time in Stillwater?")
							v_u_85.Text = "A short night raid at the edge of town teaches searching, quiet kills, noise and how to extract. Loot only counts once you get out. Nothing of yours is at stake."
						end
						local v150 = v_u_1.startBlock
						local v151 = p_u_62
						local v152, v153 = pcall(v150, v151)
						if not v152 then
							v153 = nil
						end
						local v154 = v138 < v_u_79
						if v138 < v_u_78 then
							v_u_86.Text = ("Skipping marks the tutorial as done. Finish it later in SETTINGS to still get %s."):format((v_u_46(p_u_62)))
						elseif v153 and not v154 then
							v_u_86.Text = v153
						end
						local v155 = v_u_86
						local v156
						if v138 < v_u_78 then
							v156 = true
						elseif v153 == nil then
							v156 = false
						else
							v156 = not v154
						end
						v155.Visible = v156
						if v_u_74 then
							v_u_98.setText(v154 and "Starting" or (v137 == "retry" and "Retry" or "Start"))
						else
							v_u_98.setText(v154 and "Starting..." or (v137 == "retry" and "Try again" or "Start tutorial"))
						end
						v_u_98.setKind("primary")
						local v157 = v_u_98.setEnabled
						local v158
						if v153 == nil then
							v158 = not v154
						else
							v158 = false
						end
						v157(v158)
						if v138 < v_u_78 then
							v_u_103.setText(v_u_74 and "Confirm" or "Confirm skip")
							v_u_103.setKind("danger")
						else
							v_u_103.setText("Skip")
							v_u_103.setKind("close")
						end
						v_u_103.setEnabled(not v154)
					end
				end
			end
		else
			return
		end
	end
	function v_u_75.main() -- name: main
		-- upvalues: (ref) v_u_1, (copy) p_u_62, (ref) v_u_2, (ref) v_u_79, (copy) v_u_66, (ref) v_u_76, (copy) v_u_75
		local v159 = v_u_1.state(p_u_62)
		if v159 == "complete" then
			p_u_62.tutorialDismissed = v_u_2:GetAttribute("TutorialResultId")
			p_u_62.setTab("tasks")
			if p_u_62.syncTutorial then
				p_u_62.syncTutorial()
			end
			return
		end
		if v159 == nil or os.clock() < v_u_79 then
			return
		end
		local v160 = v_u_1.startBlock
		local v161 = p_u_62
		local v162, v163 = pcall(v160, v161)
		if not v162 then
			v163 = nil
		end
		if v163 then
			v_u_66.toast(v163, "warn")
			return
		end
		local v_u_164 = p_u_62
		local v165, v166 = pcall(function()
			-- upvalues: (copy) v_u_164
			return v_u_164.cctx.controllers.TutorialClient
		end)
		if not v165 or type(v166) ~= "table" then
			v166 = nil
		end
		local v167 = false
		if v159 == "again" then
			local v168
			if v166 then
				local v169 = v166.replay
				if type(v169) == "function" then
					local v170 = v166.replay
					local v171
					v168, v171 = pcall(v170)
					if v168 then
						v168 = v171 ~= false
					end
				else
					p_u_62.cctx.emit("transit.info", {
						["kind"] = "deploy",
						["map"] = "Stillwater",
						["difficulty"] = "Normal",
						["timeOfDay"] = "Night",
						["tutorial"] = true,
						["practice"] = nil,
						["practice"] = not v_u_1.rewardOpen()
					})
					p_u_62.op({
						["op"] = "tutorialReplay"
					})
					v168 = true
				end
			else
				p_u_62.cctx.emit("transit.info", {
					["kind"] = "deploy",
					["map"] = "Stillwater",
					["difficulty"] = "Normal",
					["timeOfDay"] = "Night",
					["tutorial"] = true,
					["practice"] = nil,
					["practice"] = not v_u_1.rewardOpen()
				})
				p_u_62.op({
					["op"] = "tutorialReplay"
				})
				v168 = true
			end
			if v168 then
				v_u_79 = os.clock() + 6
				v_u_66.sound("deploy")
				task.delay(6.05, function()
					-- upvalues: (ref) v_u_76, (ref) v_u_75
					if v_u_76 then
						v_u_75.paint()
					end
				end)
			end
			v_u_75.paint()
		else
			if v166 then
				local v172 = v166.begin
				if type(v172) == "function" then
					local v173 = v166.begin
					local v174, v175 = pcall(v173)
					if v174 then
						v167 = v175 ~= false
					else
						v167 = v174
					end
					if not v174 then
						warn("[MenuTutorialCard] TutorialClient.begin failed:", v175)
					end
				end
			end
			if not v167 then
				if v166 then
					local v176 = v166.begin
					if type(v176) ~= "function" then
						p_u_62.cctx.emit("transit.info", {
							["kind"] = "deploy",
							["map"] = "Stillwater",
							["difficulty"] = "Normal",
							["timeOfDay"] = "Night",
							["tutorial"] = true
						})
						p_u_62.op({
							["op"] = "tutorialStart"
						})
						v167 = true
					end
				else
					p_u_62.cctx.emit("transit.info", {
						["kind"] = "deploy",
						["map"] = "Stillwater",
						["difficulty"] = "Normal",
						["timeOfDay"] = "Night",
						["tutorial"] = true
					})
					p_u_62.op({
						["op"] = "tutorialStart"
					})
					v167 = true
				end
			end
			if v167 then
				v_u_79 = os.clock() + 6
				v_u_66.sound("deploy")
				task.delay(6.05, function()
					-- upvalues: (ref) v_u_76, (ref) v_u_75
					if v_u_76 then
						v_u_75.paint()
					end
				end)
			end
			v_u_75.paint()
		end
	end
	function v_u_75.side() -- name: side
		-- upvalues: (ref) v_u_1, (copy) p_u_62, (ref) v_u_2, (copy) v_u_75, (copy) v_u_66, (copy) v_u_67, (ref) v_u_78, (ref) v_u_76
		local v177 = v_u_1.state(p_u_62)
		if v177 == "complete" then
			p_u_62.tutorialDismissed = v_u_2:GetAttribute("TutorialResultId")
			if p_u_62.syncTutorial then
				p_u_62.syncTutorial()
			end
			v_u_75.paint()
			return
		end
		if v177 == nil then
			return
		end
		if v177 == "again" then
			p_u_62.tutorialAgainGone = true
			local v_u_178 = p_u_62
			local v179, v180 = pcall(function()
				-- upvalues: (copy) v_u_178
				return v_u_178.cctx.controllers.TutorialClient
			end)
			if not v179 or type(v180) ~= "table" then
				v180 = nil
			end
			if v180 then
				local v181 = v180.dismissOffer
				if type(v181) == "function" then
					local v182 = v180.dismissOffer
					pcall(v182)
					v_u_66.sound(v_u_67.sounds.click)
					v_u_75.paint()
				else
					p_u_62.op({
						["op"] = "tutorialOfferDismiss"
					})
					v_u_66.sound(v_u_67.sounds.click)
					v_u_75.paint()
				end
			else
				p_u_62.op({
					["op"] = "tutorialOfferDismiss"
				})
				v_u_66.sound(v_u_67.sounds.click)
				v_u_75.paint()
				return
			end
		else
			local v183 = os.clock()
			if v_u_78 <= v183 then
				v_u_78 = v183 + 3
				v_u_66.sound(v_u_67.sounds.click)
				task.delay(3.05, function()
					-- upvalues: (ref) v_u_76, (ref) v_u_75
					if v_u_76 then
						v_u_75.paint()
					end
				end)
				v_u_75.paint()
				return
			end
			v_u_78 = 0
			local v_u_184 = p_u_62
			local v185, v186 = pcall(function()
				-- upvalues: (copy) v_u_184
				return v_u_184.cctx.controllers.TutorialClient
			end)
			if not v185 or type(v186) ~= "table" then
				v186 = nil
			end
			if v186 then
				local v187 = v186.skip
				if type(v187) == "function" then
					local v188 = v186.skip
					local v189, v190 = pcall(v188)
					if not v189 then
						warn("[MenuTutorialCard] TutorialClient.skip failed:", v190)
						p_u_62.op({
							["op"] = "tutorialSkip"
						})
					end
					v_u_66.sound(v_u_67.sounds.confirm)
					v_u_75.paint()
				else
					p_u_62.op({
						["op"] = "tutorialSkip"
					})
					v_u_66.sound(v_u_67.sounds.confirm)
					v_u_75.paint()
				end
			else
				p_u_62.op({
					["op"] = "tutorialSkip"
				})
				v_u_66.sound(v_u_67.sounds.confirm)
				v_u_75.paint()
				return
			end
		end
	end
	local v191 = p_u_62.changed
	table.insert(v_u_77, v191:Connect(function(p192)
		-- upvalues: (copy) v_u_75
		if p192 == "profile" or (p192 == "party" or p192 == "tutorial") then
			v_u_75.paint()
		end
	end))
	local v193 = v_u_2:GetAttributeChangedSignal("TutorialRewardOpen")
	table.insert(v_u_77, v193:Connect(function()
		-- upvalues: (copy) v_u_75
		v_u_75.paint()
	end))
	local v194 = v_u_2:GetAttributeChangedSignal("TutorialOfferNew")
	local function v195()
		-- upvalues: (ref) v_u_2, (copy) p_u_62, (copy) v_u_75
		if v_u_2:GetAttribute("TutorialOfferNew") == true then
			p_u_62.tutorialAgainGone = nil
		end
		v_u_75.paint()
	end
	table.insert(v_u_77, v194:Connect(v195))
	pcall(function()
		-- upvalues: (ref) v_u_76, (copy) v_u_77, (copy) v_u_75
		local v196 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
		if v196 and v_u_76 then
			local v197 = v_u_77
			local v198 = v196:GetAttributeChangedSignal("DeployClosed")
			local function v199()
				-- upvalues: (ref) v_u_75
				v_u_75.paint()
			end
			table.insert(v197, v198:Connect(v199))
		end
	end)
	function v_u_75.destroy() -- name: destroy
		-- upvalues: (ref) v_u_76, (copy) v_u_77
		v_u_76 = false
		for _, v200 in v_u_77 do
			v200:Disconnect()
		end
		table.clear(v_u_77)
	end
	if type(p65) == "table" and p65.form ~= nil then
		v_u_117(v_u_74)
	else
		v_u_75.paint()
	end
	return v_u_75
end
return v_u_1