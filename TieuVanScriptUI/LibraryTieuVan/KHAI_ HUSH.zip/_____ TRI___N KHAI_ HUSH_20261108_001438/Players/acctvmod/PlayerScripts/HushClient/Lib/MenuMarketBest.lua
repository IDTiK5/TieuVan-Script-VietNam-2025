-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketBest

return {
	["new"] = function(p_u_1, p_u_2) -- name: new
		local v_u_3 = p_u_1.ui
		local v_u_4 = p_u_1.theme
		local v_u_5 = p_u_1.C
		local v_u_6 = p_u_1.Data
		local v_u_7 = p_u_1.data
		local v_u_8 = p_u_1.h
		local v_u_9 = {}
		local v_u_10 = nil
		local v_u_11 = nil
		local function v12()
			-- upvalues: (ref) v_u_11, (copy) p_u_1
			v_u_11 = p_u_1.mc.cctx.shared.Items
		end
		pcall(v12)
		local function v_u_13(_) -- name: noPress
			return false
		end
		local function v_u_14(_) -- name: noSet end
		local function v_u_15() -- name: noGet
			return 0
		end
		local function v_u_16() -- name: noRefresh end
		v_u_9.press = v_u_13
		v_u_9.setLimit = v_u_14
		v_u_9.getLimit = v_u_15
		v_u_9.refresh = v_u_16
		function v_u_9.isOpen() -- name: isOpen
			-- upvalues: (ref) v_u_10
			return v_u_10 ~= nil
		end
		function v_u_9.panel() -- name: panel
			-- upvalues: (ref) v_u_10
			return v_u_10
		end
		function v_u_9.close() -- name: close
			-- upvalues: (ref) v_u_10
			if v_u_10 then
				local v17 = v_u_10.close
				pcall(v17)
			end
		end
		function v_u_9.open(p18) -- name: open
			-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) p_u_2, (copy) p_u_1, (copy) v_u_9, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (ref) v_u_11, (copy) v_u_7, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16
			if v_u_10 then
				return
			else
				local v_u_19 = v_u_6.buy
				local v20 = p_u_2.rows()
				local v_u_21 = v_u_6.cheapestRow(v20)
				if v_u_21 == nil or (v_u_19 == nil or v_u_6.comfort == nil) then
					return
				else
					local v_u_22 = v_u_6.comfort
					local v_u_23
					if p_u_1.rules and p_u_1.rules.TUNE then
						local v24 = p_u_1.rules.TUNE.maxPrice
						v_u_23 = type(v24) ~= "number" and 99999999 or p_u_1.rules.TUNE.maxPrice
					else
						v_u_23 = 99999999
					end
					local v_u_25 = p_u_2.entry()
					local v_u_26 = p_u_2.itemId()
					local v_u_27 = v_u_6.isCrateItem(v_u_26)
					local v_u_28 = nil
					local function v29()
						-- upvalues: (ref) v_u_28, (ref) p_u_1
						v_u_28 = p_u_1.mc.cctx.lib.MenuMarketCrateKit
					end
					pcall(v29)
					if not v_u_27 or v_u_28 ~= nil then
						local v_u_30 = v_u_21.p / v_u_21.n
						local v31 = v_u_30 * 0.01 + 0.5
						local v32 = math.floor(v31)
						local v_u_33 = math.max(1, v32)
						local v_u_34 = p18 or v_u_19.limitFor(v_u_30, v_u_22.bestPct)
						local v_u_35 = p18 ~= nil
						local v_u_36 = false
						local v_u_37 = nil
						local v_u_38 = nil
						local v_u_39 = nil
						local v_u_40 = nil
						local v_u_41 = nil
						local v_u_42 = nil
						local v_u_43 = nil
						local v_u_44 = nil
						local v_u_45 = nil
						local v_u_46 = {}
						local v_u_47 = nil
						local function v_u_49() -- name: clear
							-- upvalues: (ref) v_u_37, (ref) v_u_39, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (copy) v_u_46
							if v_u_37 then
								for _, v48 in v_u_37:GetChildren() do
									if v48:IsA("UIListLayout") then
										continue
									end
									v48:Destroy()
								end
							end
							v_u_39 = nil
							v_u_40 = nil
							v_u_41 = nil
							v_u_42 = nil
							v_u_43 = nil
							v_u_44 = nil
							v_u_45 = nil
							table.clear(v_u_46)
						end
						local function v_u_50() -- name: close
							-- upvalues: (ref) v_u_38, (ref) v_u_36
							if v_u_38 and not v_u_36 then
								v_u_38.close()
							end
						end
						local function v_u_59(p51) -- name: buttons
							-- upvalues: (ref) v_u_9, (ref) v_u_38, (ref) v_u_3, (ref) v_u_4, (ref) v_u_37, (ref) v_u_8
							v_u_9.buttons = {}
							for _, v52 in p51 do
								v_u_9.buttons[v52.text] = v52.onClick
							end
							local v53
							if v_u_38 then
								v53 = v_u_38.frame
							else
								v53 = nil
							end
							local v54
							if v53 then
								v54 = v53:FindFirstChild("Footer", true)
							else
								v54 = nil
							end
							if v54 and v54:IsA("GuiObject") then
								v54.Visible = false
							end
							local v55 = v_u_3.new("Frame", {
								["Name"] = "Buttons",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 90,
								["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(v_u_4.control))
							}, v_u_37)
							v_u_3.layout(v55, "h", 8, "right")
							for v56, v57 in p51 do
								local v58 = v_u_8.button(v55, v57.text, v57.kind, v57.onClick, {
									["order"] = v56
								})
								if v56 ~= #p51 then
									continue
								end
								v58:SetAttribute("PadDefault", true)
							end
							v_u_3.new("Frame", {
								["Name"] = "FooterPad",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 91,
								["Size"] = UDim2.new(1, 0, 0, v_u_4.space.l - 3)
							}, v_u_37)
						end
						local function v_u_67(p60, p61, p62, p63, p64) -- name: result
							-- upvalues: (copy) v_u_49, (ref) v_u_3, (ref) v_u_37, (ref) v_u_5, (copy) v_u_59, (copy) v_u_50
							v_u_49()
							local v65 = v_u_3.new("Frame", {
								["Name"] = "Result",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["LayoutOrder"] = 1,
								["Size"] = UDim2.new(1, 0, 0, 0),
								["AutomaticSize"] = Enum.AutomaticSize.Y
							}, v_u_37)
							v_u_3.layout(v65, "v", 8)
							local v66 = v_u_3.new("Frame", {
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 1,
								["Size"] = UDim2.new(1, 0, 0, 28)
							}, v65)
							v_u_3.icon(p60, {
								["parent"] = nil,
								["size"] = 22,
								["color"] = nil,
								["position"] = nil,
								["parent"] = v66,
								["color"] = p62,
								["position"] = UDim2.fromOffset(0, 3)
							})
							v_u_3.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["track"] = false,
								["parent"] = v66,
								["text"] = p61,
								["color"] = v_u_5.text,
								["position"] = UDim2.fromOffset(32, 0),
								["size"] = UDim2.new(1, -32, 1, 0)
							})
							if p63 then
								v_u_3.label({
									["parent"] = nil,
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = 2,
									["parent"] = v65,
									["text"] = p63,
									["color"] = v_u_5.text2
								})
							end
							v_u_59(p64 or {
								{
									["text"] = "Close",
									["kind"] = "primary",
									["onClick"] = nil,
									["onClick"] = v_u_50
								}
							})
						end
						local function v_u_74(p68) -- name: progress
							-- upvalues: (copy) v_u_49, (ref) v_u_38, (ref) v_u_3, (ref) v_u_37, (ref) v_u_5, (ref) v_u_36
							v_u_49()
							local v69
							if v_u_38 then
								v69 = v_u_38.frame
							else
								v69 = nil
							end
							local v70
							if v69 then
								v70 = v69:FindFirstChild("Footer", true)
							else
								v70 = nil
							end
							if v70 and v70:IsA("GuiObject") then
								v70.Visible = false
							end
							local v_u_71 = v_u_3.new("Frame", {
								["Name"] = "Progress",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 1,
								["Size"] = UDim2.new(1, 0, 0, 56)
							}, v_u_37)
							v_u_3.label({
								["parent"] = nil,
								["name"] = "Text",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["track"] = false,
								["fit"] = true,
								["parent"] = v_u_71,
								["text"] = p68,
								["color"] = v_u_5.text,
								["size"] = UDim2.new(1, 0, 0, 24)
							})
							local v_u_72 = v_u_3.progress({
								["parent"] = nil,
								["size"] = nil,
								["position"] = nil,
								["value"] = 0.2,
								["color"] = nil,
								["parent"] = v_u_71,
								["size"] = UDim2.new(0.6, 0, 0, 4),
								["position"] = UDim2.new(0.2, 0, 0, 36),
								["color"] = v_u_5.accent
							})
							task.spawn(function()
								-- upvalues: (copy) v_u_71, (ref) v_u_36, (copy) v_u_72
								local v73 = 0.1
								while v_u_71.Parent and not v_u_36 do
									v73 = (v73 + 0.12) % 1
									v_u_72.set(v73)
									task.wait(0.25)
								end
							end)
						end
						local function v_u_77(p75) -- name: firstText
							-- upvalues: (ref) v_u_6, (ref) v_u_11, (copy) v_u_26, (copy) v_u_25
							local v76 = v_u_6.lotText(v_u_11, v_u_26, v_u_25.name, p75.n, p75.d)
							if p75.n > 1 then
								return v_u_6.fill(v_u_6.TEXT.bestFirst, {
									["desc"] = v76,
									["unit"] = v_u_6.unitMoney(p75.p / p75.n),
									["total"] = v_u_6.money(p75.p)
								})
							else
								return v_u_6.fill(v_u_6.TEXT.bestFirstOne, {
									["desc"] = v76,
									["total"] = v_u_6.money(p75.p)
								})
							end
						end
						local function v_u_90() -- name: paintLimit
							-- upvalues: (ref) v_u_41, (ref) v_u_45, (ref) v_u_6, (ref) v_u_30, (copy) v_u_46, (ref) p_u_2, (ref) v_u_34, (ref) v_u_39, (ref) v_u_40, (ref) v_u_42, (ref) v_u_5, (copy) v_u_77, (ref) v_u_43, (ref) p_u_1, (ref) v_u_44
							if v_u_41 ~= nil then
								if v_u_45 then
									v_u_45.Text = v_u_6.fill(v_u_6.TEXT.bestNow, {
										["unit"] = v_u_6.unitMoney(v_u_30)
									})
								end
								if v_u_46[1] then
									for v78, v79 in v_u_6.limitQuick(v_u_30).quick do
										local v80 = v_u_46[v78]
										if not v80 then
											continue
										end
										v80:SetAttribute("Value", v79.value)
									end
								end
								local v81 = p_u_2.good() == true
								local v82 = v_u_6.bestPreview(p_u_2.rows(), v_u_34, v81)
								if v_u_39 then
									v_u_39.Text = v_u_6.money(v_u_34)
								end
								if v_u_40 and not v_u_40:IsFocused() then
									local v83 = v_u_34
									v_u_40.Text = tostring(v83)
								end
								if v_u_41 then
									local v84
									if v82.within == 0 then
										if v81 then
											v84 = v_u_6.TEXT.bestNoneGood
										else
											v84 = v_u_6.TEXT.bestNone
										end
										if v_u_42 == nil then
											v84 = v84 .. " " .. v_u_6.fill(v_u_6.TEXT.bestNow, {
												["unit"] = v_u_6.unitMoney(v_u_30)
											})
										end
										v_u_41.TextColor3 = v_u_5.accent
									else
										if v81 then
											if v82.within == 1 then
												v84 = v_u_6.TEXT.bestWithinGoodOne
											else
												v84 = v_u_6.fill(v_u_6.TEXT.bestWithinGood, {
													["n"] = v82.within
												})
											end
										elseif v82.within == 1 then
											v84 = v_u_6.TEXT.bestWithinOne
										else
											v84 = v_u_6.fill(v_u_6.TEXT.bestWithin, {
												["n"] = v82.within
											})
										end
										if v_u_42 == nil and v82.first then
											v84 = v84 .. " " .. v_u_77(v82.first)
										end
										v_u_41.TextColor3 = v_u_5.text2
									end
									local v85
									if p_u_2.age then
										v85 = p_u_2.age()
									else
										v85 = nil
									end
									if type(v85) == "number" and v85 >= 30 then
										v84 = v84 .. " " .. v_u_6.fill(v_u_6.TEXT.bestAge, {
											["age"] = v_u_6.duration(v85)
										})
									end
									v_u_41.Text = v84
								end
								if v_u_42 then
									local v86 = v82.first
									if v86 then
										v_u_42.Text = v_u_77(v86)
									else
										v_u_42.Text = ""
									end
								end
								if v_u_43 then
									if v82.first and (v82.most and v82.most > v82.firstTotal) then
										local v87 = v_u_43
										local v88 = v_u_6.fill
										local v89
										if p_u_1.compact == true then
											v89 = v_u_6.TEXT.bestMostShort
										else
											v89 = v_u_6.TEXT.bestMost
										end
										v87.Text = v88(v89, {
											["total"] = v_u_6.money(v82.most)
										})
										v_u_43.Visible = true
									else
										v_u_43.Text = ""
										v_u_43.Visible = false
									end
								end
								if v_u_44 then
									v_u_44.Text = ""
									v_u_44.Visible = false
								end
							end
						end
						local function v_u_128() -- name: go
							-- upvalues: (copy) v_u_19, (ref) v_u_34, (ref) v_u_44, (ref) v_u_3, (ref) v_u_4, (ref) p_u_2, (ref) v_u_6, (ref) p_u_1, (ref) v_u_21, (ref) v_u_7, (copy) v_u_27, (copy) v_u_26, (copy) v_u_74, (ref) v_u_36, (ref) v_u_9, (copy) v_u_67, (ref) v_u_5, (copy) v_u_50, (ref) v_u_11, (copy) v_u_25, (ref) v_u_30, (ref) v_u_33, (ref) v_u_47, (copy) v_u_22, (ref) v_u_35
							local v_u_91 = v_u_19.clampLimit(v_u_34)
							if v_u_91 == nil then
								if v_u_44 then
									v_u_44.Text = "Enter a limit of at least $1."
									v_u_44.Visible = true
								end
								v_u_3.sound(v_u_4.sounds.error)
								return
							else
								local v_u_92 = p_u_2.good() == true
								local v_u_93 = v_u_6.bestPreview(p_u_2.rows(), v_u_91, v_u_92).most
								if v_u_93 == nil then
									if v_u_44 then
										local v94 = v_u_44
										local v95
										if v_u_92 then
											v95 = v_u_6.TEXT.bestNoneGood
										else
											v95 = v_u_6.TEXT.bestNone
										end
										v94.Text = v95
										v_u_44.Visible = true
									end
									v_u_3.sound(v_u_4.sounds.error)
									return
								else
									local v96 = v_u_6.buyButton
									local v97 = p_u_1.state
									local v98 = v_u_21
									local v99 = v_u_7:cash()
									local v100 = v_u_7:remaining(p_u_1.state or {}, "buyIn")
									local v101 = p_u_1.rules
									local v102
									if v_u_27 then
										v102 = v_u_26
									else
										v102 = nil
									end
									local v103 = v96(v97, v98, v99, v100, v101, v102)
									if v103.enabled then
										v_u_74(v_u_6.TEXT.bestLooking)
										task.spawn(function()
											-- upvalues: (ref) v_u_7, (ref) v_u_26, (copy) v_u_91, (copy) v_u_93, (copy) v_u_92, (ref) v_u_36, (ref) v_u_9, (ref) v_u_67, (ref) v_u_6, (ref) v_u_5, (ref) v_u_50, (ref) p_u_2, (ref) p_u_1, (ref) v_u_11, (ref) v_u_25, (ref) v_u_21, (ref) v_u_30, (ref) v_u_33, (ref) v_u_47, (ref) v_u_34, (ref) v_u_19, (ref) v_u_22, (ref) v_u_35
											local v104 = v_u_7:buyBest({
												["id"] = v_u_26,
												["maxUnit"] = v_u_91,
												["maxTotal"] = v_u_93,
												["good"] = v_u_92 and true or nil
											})
											if v_u_36 then
												return
											else
												v_u_9.lastResult = v104
												local v105 = v104.data
												local v106 = type(v105) ~= "table" and {} or v104.data
												if v104.ok and v104.state == "processing" then
													v_u_67("clock", v_u_6.TEXT.working, v_u_5.info, nil)
													task.delay(1.8, v_u_50)
													task.defer(p_u_2.afterBuy, nil)
													return
												elseif v104.ok then
													local function v107()
														-- upvalues: (ref) p_u_1
														return p_u_1.mc.cctx.controllers.BmNotes
													end
													local v108, v109 = pcall(v107)
													if v108 and (v109 and v109.quiet) then
														v109.quiet("bought", v_u_26)
													end
													local v110 = v104.text
													local v111 = v106.p
													if type(v111) == "number" then
														local v112 = v106.n
														if type(v112) == "number" and v106.n > 0 then
															local v113 = v_u_6.lotText(v_u_11, v_u_26, v_u_25.name, v106.n, v106.d)
															local v114 = v_u_6.fill(v_u_6.TEXT.bestPaid, {
																["total"] = v_u_6.money(v106.p)
															})
															if v106.n > 1 then
																v110 = ("%s for %s each. %s"):format(v113, v_u_6.unitMoney(v106.p / v106.n), v114)
															else
																v110 = ("%s. %s"):format(v113, v114)
															end
														end
													end
													v_u_67("check", v_u_6.TEXT.bought, v_u_5.success, v110)
													task.defer(p_u_2.afterBuy, v106.lid)
													return
												elseif v104.code == "TOTAL_MOVED" then
													local v115 = v_u_6.applyNext(v106.next, v_u_92)
													if v115 then
														p_u_2.repaint(v115)
													end
													if v115 then
														local v116 = v_u_6.cheapestRow(p_u_2.rows())
														if v116 then
															v_u_21 = v116
															v_u_30 = v116.p / v116.n
															local v117 = v_u_30 * 0.01 + 0.5
															local v118 = math.floor(v117)
															v_u_33 = math.max(1, v118)
														end
														if v116 then
															v_u_47(v_u_6.TEXT.bestMoved)
															return
														end
													end
													if v115 then
														v_u_67("warning", v_u_6.text(p_u_1.rules, "NOBODY"), v_u_5.accent, nil)
													else
														v_u_67("warning", v_u_6.TEXT.bestMoved, v_u_5.accent, nil)
														task.defer(p_u_2.afterBuy, nil)
													end
												else
													local v119 = v_u_6.applyNext(v106.next, v_u_92)
													if v119 then
														p_u_2.repaint(v119)
													end
													local v_u_120 = v104.code
													if v_u_120 == "RANGE_TAKEN" or (v_u_120 == "NO_RANGE" or v_u_120 == "RANGE_RACE") then
														local v_u_121 = v106.unit
														v_u_67("warning", v104.text, v_u_5.accent, nil, {
															{
																["text"] = "Close",
																["kind"] = "secondary",
																["onClick"] = nil,
																["onClick"] = v_u_50
															},
															{
																["text"] = nil,
																["kind"] = "primary",
																["onClick"] = nil,
																["text"] = v_u_6.TEXT.bestChange,
																["onClick"] = function() -- name: onClick
																	-- upvalues: (ref) v_u_6, (ref) p_u_2, (ref) v_u_21, (ref) v_u_30, (ref) v_u_33, (copy) v_u_120, (ref) v_u_34, (ref) v_u_19, (copy) v_u_121, (ref) v_u_22, (ref) v_u_35, (ref) v_u_47
																	local v122 = v_u_6.cheapestRow(p_u_2.rows())
																	if v122 then
																		v_u_21 = v122
																		v_u_30 = v122.p / v122.n
																		local v123 = v_u_30 * 0.01 + 0.5
																		local v124 = math.floor(v123)
																		v_u_33 = math.max(1, v124)
																	end
																	if v_u_120 ~= "RANGE_RACE" then
																		local v125 = v_u_19.limitFor
																		local v126 = v_u_121
																		local v127
																		if type(v126) == "number" then
																			v127 = v_u_121
																		else
																			v127 = v_u_30
																		end
																		v_u_34 = v125(v127, v_u_22.bestPct)
																		v_u_35 = false
																	end
																	v_u_47(nil)
																end
															}
														})
													elseif v_u_120 == "NOBODY" or v_u_120 == "RANGE_GONE" then
														v_u_67("warning", v104.text, v_u_5.accent, nil)
													else
														v_u_67("warning", v104.text, v_u_5.danger, nil)
													end
													task.defer(p_u_2.afterBuy, nil)
													return
												end
											end
										end)
									else
										if v_u_44 then
											v_u_44.Text = v103.reason or ""
											v_u_44.Visible = v_u_44.Text ~= ""
										end
										v_u_3.sound(v_u_4.sounds.error)
									end
								end
							end
						end
						v_u_47 = function(p129)
							-- upvalues: (copy) v_u_49, (ref) v_u_38, (ref) v_u_9, (copy) v_u_50, (ref) v_u_6, (copy) v_u_128, (ref) p_u_1, (ref) v_u_3, (ref) v_u_37, (ref) v_u_5, (copy) v_u_27, (ref) v_u_28, (copy) v_u_26, (ref) v_u_45, (ref) v_u_30, (ref) v_u_4, (ref) v_u_34, (ref) v_u_33, (copy) v_u_23, (ref) v_u_35, (copy) v_u_90, (ref) v_u_40, (ref) v_u_39, (ref) v_u_8, (copy) v_u_46, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44
							v_u_49()
							local v130
							if v_u_38 then
								v130 = v_u_38.frame
							else
								v130 = nil
							end
							local v131
							if v130 then
								v131 = v130:FindFirstChild("Footer", true)
							else
								v131 = nil
							end
							if v131 and v131:IsA("GuiObject") then
								v131.Visible = true
							end
							v_u_9.buttons = {
								["Cancel"] = v_u_50,
								[v_u_6.TEXT.bestBuy] = v_u_128
							}
							local v_u_132 = 0
							local v_u_133 = p_u_1.compact == true
							local function v137(p134) -- name: gap
								-- upvalues: (copy) v_u_133, (ref) v_u_3, (ref) v_u_132, (ref) v_u_37
								if not v_u_133 then
									local v135 = v_u_3.new
									local v136 = {
										["Name"] = "Gap",
										["BackgroundTransparency"] = 1,
										["Size"] = nil,
										["LayoutOrder"] = nil,
										["Size"] = UDim2.new(1, 0, 0, p134)
									}
									v_u_132 = v_u_132 + 1
									v136.LayoutOrder = v_u_132
									v135("Frame", v136, v_u_37)
								end
							end
							if p129 then
								local v138 = v_u_3.label
								local v139 = {
									["parent"] = nil,
									["name"] = "Notice",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["text"] = p129,
									["color"] = v_u_5.accent
								}
								v_u_132 = v_u_132 + 1
								v139.order = v_u_132
								v138(v139):SetAttribute("Kind", "warn")
							end
							if v_u_27 then
								local v140 = v_u_28.block
								local v141 = p_u_1
								local v142 = v_u_37
								local v143 = v_u_26
								local v144 = {}
								v_u_132 = v_u_132 + 1
								v144.order = v_u_132
								v144.tight = v_u_133
								v140(v141, v142, v143, v144)
							end
							if not v_u_133 then
								local v145 = v_u_3.label
								local v146 = {
									["parent"] = nil,
									["name"] = "Now",
									["text"] = nil,
									["style"] = "body",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["text"] = v_u_6.fill(v_u_6.TEXT.bestNow, {
										["unit"] = v_u_6.unitMoney(v_u_30)
									}),
									["color"] = v_u_5.text
								}
								v_u_132 = v_u_132 + 1
								v146.order = v_u_132
								v_u_45 = v145(v146)
								v137(10)
							end
							local v147 = v_u_3.label
							local v148 = {
								["parent"] = nil,
								["name"] = "LimitCaption",
								["text"] = nil,
								["style"] = "caps",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_37,
								["text"] = string.upper(v_u_6.TEXT.bestLimit),
								["color"] = v_u_5.text2
							}
							v_u_132 = v_u_132 + 1
							v148.order = v_u_132
							v147(v148)
							v137(4)
							local v149 = v_u_4.touch(44)
							local v150 = v_u_3.new
							local v151 = {
								["Name"] = "LimitRow",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.new(1, 0, 0, v149)
							}
							v_u_132 = v_u_132 + 1
							v151.LayoutOrder = v_u_132
							local v152 = v150("Frame", v151, v_u_37)
							v_u_3.iconButton({
								["parent"] = nil,
								["icon"] = "minus",
								["size"] = nil,
								["kind"] = "secondary",
								["name"] = "Less",
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = v152,
								["size"] = v149,
								["position"] = UDim2.fromOffset(0, 0),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_34, (ref) v_u_33, (ref) v_u_23, (ref) v_u_35, (ref) v_u_90, (ref) v_u_3, (ref) v_u_4
									local v153 = v_u_34 - v_u_33 + 0.5
									local v154 = math.floor(v153)
									local v155 = v_u_23
									v_u_34 = math.clamp(v154, 1, v155)
									v_u_35 = true
									v_u_90()
									v_u_3.sound(v_u_4.sounds.click)
								end
							})
							local v156 = v_u_3.new("Frame", {
								["Name"] = "LimitValue",
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_5.raised,
								["Position"] = UDim2.fromOffset(v149 + 6, 0),
								["Size"] = UDim2.new(1, -(2 * v149 + 12), 0, v149)
							}, v152)
							v_u_3.stroke(v156, v_u_5.lineStrong)
							if v_u_3.device() == "Keyboard" then
								local _, v_u_157 = v_u_3.input({
									["parent"] = nil,
									["name"] = "LimitInput",
									["placeholder"] = "Highest price",
									["size"] = nil,
									["maxLength"] = 12,
									["parent"] = v156,
									["size"] = UDim2.fromScale(1, 1)
								})
								local v158 = v_u_34
								v_u_157.Text = tostring(v158)
								v_u_157.FocusLost:Connect(function()
									-- upvalues: (ref) v_u_6, (copy) v_u_157, (ref) v_u_23, (ref) v_u_34, (ref) v_u_35, (ref) v_u_90, (ref) v_u_3, (ref) v_u_4
									local v159 = v_u_6.parseLimit(v_u_157.Text, v_u_23)
									if v159 then
										local v160 = v159 + 0.5
										local v161 = math.floor(v160)
										local v162 = v_u_23
										v_u_34 = math.clamp(v161, 1, v162)
										v_u_35 = true
										v_u_90()
										v_u_3.sound(v_u_4.sounds.click)
									else
										v_u_90()
									end
								end)
								v_u_40 = v_u_157
							else
								v_u_39 = v_u_3.label({
									["parent"] = nil,
									["name"] = "Limit",
									["text"] = "",
									["style"] = "monoL",
									["textSize"] = 24,
									["color"] = nil,
									["align"] = "center",
									["size"] = nil,
									["track"] = false,
									["fit"] = true,
									["parent"] = v156,
									["color"] = v_u_5.accent,
									["size"] = UDim2.fromScale(1, 1)
								})
							end
							v_u_3.iconButton({
								["parent"] = nil,
								["icon"] = "plus",
								["size"] = nil,
								["kind"] = "secondary",
								["name"] = "More",
								["anchor"] = nil,
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = v152,
								["size"] = v149,
								["anchor"] = Vector2.new(1, 0),
								["position"] = UDim2.new(1, 0, 0, 0),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_34, (ref) v_u_33, (ref) v_u_23, (ref) v_u_35, (ref) v_u_90, (ref) v_u_3, (ref) v_u_4
									local v163 = v_u_34 + v_u_33 + 0.5
									local v164 = math.floor(v163)
									local v165 = v_u_23
									v_u_34 = math.clamp(v164, 1, v165)
									v_u_35 = true
									v_u_90()
									v_u_3.sound(v_u_4.sounds.click)
								end
							})
							local v166 = v_u_3.new
							local v167 = {
								["Name"] = "Quick",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.new(1, 0, 0, v149)
							}
							v_u_132 = v_u_132 + 1
							v167.LayoutOrder = v_u_132
							local v168 = v166("Frame", v167, v_u_37)
							v_u_3.new("UIGridLayout", {
								["CellSize"] = UDim2.new(0.3333333333333333, -6, 0, v149),
								["CellPadding"] = UDim2.fromOffset(8, 0),
								["SortOrder"] = Enum.SortOrder.LayoutOrder
							}, v168)
							for v_u_169, v_u_170 in v_u_6.limitQuick(v_u_30).quick do
								local v176 = v_u_8.button(v168, ("+%d%%"):format(v_u_170.pct), "secondary", function()
									-- upvalues: (ref) v_u_6, (ref) v_u_30, (copy) v_u_169, (copy) v_u_170, (ref) v_u_23, (ref) v_u_34, (ref) v_u_35, (ref) v_u_90, (ref) v_u_3, (ref) v_u_4
									local v171 = v_u_6.limitQuick(v_u_30).quick[v_u_169]
									local v172
									if v171 then
										v172 = v171.value
									else
										v172 = v_u_170.value
									end
									local v173 = v172 + 0.5
									local v174 = math.floor(v173)
									local v175 = v_u_23
									v_u_34 = math.clamp(v174, 1, v175)
									v_u_35 = true
									v_u_90()
									v_u_3.sound(v_u_4.sounds.click)
								end, {
									["order"] = nil,
									["name"] = nil,
									["height"] = 44,
									["order"] = v_u_169,
									["name"] = "Quick" .. v_u_170.pct
								})
								v176:SetAttribute("Value", v_u_170.value)
								v_u_46[v_u_169] = v176
							end
							local v177 = v_u_3.label
							local v178 = {
								["parent"] = nil,
								["name"] = "QuickCaption",
								["text"] = "Percent above the cheapest price",
								["style"] = "micro",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_37,
								["color"] = v_u_5.muted
							}
							v_u_132 = v_u_132 + 1
							v178.order = v_u_132
							v177(v178)
							v137(8)
							local v179 = v_u_3.label
							local v180 = {
								["parent"] = nil,
								["name"] = "Preview",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_37,
								["color"] = v_u_5.text2
							}
							v_u_132 = v_u_132 + 1
							v180.order = v_u_132
							v_u_41 = v179(v180)
							if not v_u_133 then
								local v181 = v_u_3.label
								local v182 = {
									["parent"] = nil,
									["name"] = "First",
									["text"] = "",
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["color"] = v_u_5.text
								}
								v_u_132 = v_u_132 + 1
								v182.order = v_u_132
								v_u_42 = v181(v182)
							end
							local v183 = v_u_3.label
							local v184 = {
								["parent"] = nil,
								["name"] = "Most",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_37,
								["color"] = v_u_5.accent
							}
							v_u_132 = v_u_132 + 1
							v184.order = v_u_132
							v_u_43 = v183(v184)
							v_u_43.Visible = false
							v137(8)
							if v_u_133 then
								local v185 = v_u_3.label
								local v186 = {
									["parent"] = nil,
									["name"] = "Pays",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["text"] = v_u_6.TEXT.bestPaysShort .. " " .. v_u_6.TEXT.bestTriesShort,
									["color"] = v_u_5.info
								}
								v_u_132 = v_u_132 + 1
								v186.order = v_u_132
								v185(v186)
							else
								local v187 = v_u_3.label
								local v188 = {
									["parent"] = nil,
									["name"] = "Pays",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["text"] = v_u_6.TEXT.bestPays,
									["color"] = v_u_5.info
								}
								v_u_132 = v_u_132 + 1
								v188.order = v_u_132
								v187(v188)
								local v189 = v_u_3.label
								local v190 = {
									["parent"] = nil,
									["name"] = "Tries",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_37,
									["text"] = v_u_6.TEXT.bestTries,
									["color"] = v_u_5.text2
								}
								v_u_132 = v_u_132 + 1
								v190.order = v_u_132
								v189(v190)
							end
							local v191 = v_u_3.label
							local v192 = {
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_37,
								["color"] = v_u_5.accent
							}
							v_u_132 = v_u_132 + 1
							v192.order = v_u_132
							v_u_44 = v191(v192)
							v_u_44.Visible = false
							v_u_90()
						end
						v_u_38 = v_u_3.modal({
							["title"] = nil,
							["width"] = 480,
							["buttons"] = nil,
							["build"] = nil,
							["onClose"] = nil,
							["title"] = v_u_6.TEXT.bestTitle,
							["buttons"] = {
								{
									["text"] = "Cancel",
									["kind"] = "secondary",
									["onClick"] = nil,
									["onClick"] = function() -- name: onClick end
								},
								{
									["text"] = nil,
									["kind"] = "primary",
									["onClick"] = nil,
									["text"] = v_u_6.TEXT.bestBuy,
									["onClick"] = function() -- name: onClick
										-- upvalues: (copy) v_u_128
										v_u_128()
										return true
									end
								}
							},
							["build"] = function(p193) -- name: build
								-- upvalues: (ref) v_u_37, (ref) v_u_47
								v_u_37 = p193
								v_u_47(nil)
							end,
							["onClose"] = function() -- name: onClose
								-- upvalues: (ref) v_u_36, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) p_u_2
								v_u_36 = true
								v_u_10 = nil
								local v194 = v_u_9
								local v195 = v_u_9
								local v196 = v_u_9
								local v197 = v_u_14
								local v198 = v_u_15
								local v199 = v_u_16
								v_u_9.press = v_u_13
								v194.setLimit = v197
								v195.getLimit = v198
								v196.refresh = v199
								if p_u_2.focusBack then
									task.defer(p_u_2.focusBack)
								end
							end
						})
						v_u_10 = v_u_38
						function v_u_9.refresh()
							-- upvalues: (ref) v_u_36, (ref) v_u_41, (ref) v_u_6, (ref) p_u_2, (ref) v_u_21, (ref) v_u_30, (ref) v_u_33, (ref) v_u_35, (ref) v_u_34, (copy) v_u_19, (copy) v_u_22, (copy) v_u_90
							if not v_u_36 and v_u_41 ~= nil then
								local v200 = v_u_6.cheapestRow(p_u_2.rows())
								if v200 then
									v_u_21 = v200
									v_u_30 = v200.p / v200.n
									local v201 = v_u_30 * 0.01 + 0.5
									local v202 = math.floor(v201)
									v_u_33 = math.max(1, v202)
								end
								if v200 and not v_u_35 then
									v_u_34 = v_u_19.limitFor(v_u_30, v_u_22.bestPct)
								end
								v_u_90()
							end
						end
						function v_u_9.setLimit(p203)
							-- upvalues: (copy) v_u_23, (ref) v_u_34, (copy) v_u_90
							local v204 = p203 + 0.5
							local v205 = math.floor(v204)
							local v206 = v_u_23
							v_u_34 = math.clamp(v205, 1, v206)
							v_u_90()
						end
						function v_u_9.getLimit()
							-- upvalues: (ref) v_u_34
							return v_u_34
						end
						function v_u_9.press(p207)
							-- upvalues: (ref) v_u_9
							local v208
							if v_u_9.buttons then
								v208 = v_u_9.buttons[p207]
							else
								v208 = nil
							end
							if not v208 then
								return false
							end
							task.spawn(v208)
							return true
						end
					end
				end
			end
		end
		return v_u_9
	end
}