-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardBgFx

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = {
	["MAX_PARTICLES"] = 40,
	["TAU"] = 6.283185307179586
}
local v_u_4 = Vector2.new
local v_u_5 = UDim2.new
local v_u_6 = math.sin
local v_u_7 = math.cos
local v_u_8 = math.floor
local v_u_9 = math.max
local v_u_10 = v_u_3.TAU
function v_u_3.reducedMotion() -- name: reducedMotion
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local function v11()
		-- upvalues: (ref) v_u_1
		return v_u_1.ReducedMotionEnabled
	end
	local v12, v13 = pcall(v11)
	if v12 and v13 == true then
		return true
	end
	local v_u_14 = v_u_2.LocalPlayer
	if v_u_14 == nil then
		return false
	end
	local v15, v16 = pcall(function()
		-- upvalues: (copy) v_u_14
		return v_u_14:GetAttribute("ReduceMotion")
	end)
	if v15 then
		v15 = v16 == true
	end
	return v15
end
function v_u_3.particleCount(p17) -- name: particleCount
	-- upvalues: (copy) v_u_8, (copy) v_u_3
	local v18
	if type(p17) == "table" then
		local v19 = p17.recipe
		v18 = type(v19) ~= "table" and {} or p17.recipe
	else
		v18 = {}
	end
	local v20 = v18.particles
	if type(v20) == "table" then
		local v21 = v20.n
		if type(v21) == "number" then
			local v22 = v_u_8(v20.n)
			local v23 = v_u_3.MAX_PARTICLES
			return math.clamp(v22, 0, v23)
		end
	end
	return 0
end
function v_u_3.under(p24, p25) -- name: under
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6
	if type(p25) == "table" then
		local v26 = p25.base
		if type(v26) == "string" and p25.base ~= "" then
			local v27
			if type(p25) == "table" then
				local v28 = p25.recipe
				v27 = type(v28) ~= "table" and {} or p25.recipe
			else
				v27 = {}
			end
			local v_u_29 = v27.pan and (v27.pan.amp or 0) or 0
			local v_u_30
			if v27.pan then
				local v31 = v27.pan.period or 20
				v_u_30 = math.max(4, v31)
			else
				v_u_30 = 20
			end
			local v_u_32 = v27.zoom and (v27.zoom.amp or 0) or 0
			local v_u_33
			if v27.zoom then
				local v34 = v27.zoom.period or 24
				v_u_33 = math.max(4, v34)
			else
				v_u_33 = 24
			end
			local v_u_35 = 1 + 2 * (v_u_29 + 0.01)
			local v36 = {
				["Name"] = "Base",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Image"] = nil,
				["ImageTransparency"] = 0,
				["ScaleType"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = p25.base,
				["ScaleType"] = Enum.ScaleType.Crop,
				["AnchorPoint"] = v_u_4(0.5, 0.5),
				["Position"] = v_u_5(0.5, 0, 0.5, 0),
				["Size"] = v_u_5(v_u_35, 0, v_u_35, 0)
			}
			local v37 = p24.host
			local v_u_38 = Instance.new("ImageLabel")
			for v39, v40 in v36 do
				v_u_38[v39] = v40
			end
			if v37 then
				v_u_38.Parent = v37
			end
			if v_u_29 > 0 or v_u_32 > 0 then
				local function v43(p41)
					-- upvalues: (copy) v_u_35, (copy) v_u_32, (ref) v_u_10, (copy) v_u_33, (ref) v_u_6, (copy) v_u_38, (ref) v_u_5, (copy) v_u_29, (copy) v_u_30
					local v42 = v_u_35 + v_u_32 * (v_u_6(v_u_10 * p41 / v_u_33 + 1) * 0.5 + 0.5)
					v_u_38.Size = v_u_5(v42, 0, v42, 0)
					v_u_38.Position = v_u_5(0.5 + v_u_29 * v_u_6(v_u_10 * p41 / v_u_30), 0, 0.5, 0)
				end
				if p24.reduced then
					v43(1)
				else
					p24.add(v43)
				end
			end
			p24.baseImage = v_u_38
			return
		end
	end
end
local function v_u_77(p_u_44, p45) -- name: foreground
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6
	local v46 = p45.fore
	if type(v46) == "string" and p45.fore ~= "" then
		local v47
		if type(p45) == "table" then
			local v48 = p45.recipe
			v47 = type(v48) ~= "table" and {} or p45.recipe
		else
			v47 = {}
		end
		local v49 = v47.foreSpeed
		local v50 = type(v49) ~= "number" and 1.6 or v47.foreSpeed
		local v51 = v47.pan and (v47.pan.amp or 0) or 0.02
		local v_u_52
		if v47.pan then
			local v53 = v47.pan.period or 20
			v_u_52 = math.max(4, v53)
		else
			v_u_52 = 24
		end
		local v54 = v51 * v50
		local v_u_55 = math.max(0.01, v54)
		local v_u_56 = (v_u_55 + 0.01) * 2 + 1
		local v_u_57 = v47.foreAnchor == "top" and 0 or 1
		local v58 = {
			["Name"] = "Fore",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Image"] = nil,
			["ImageTransparency"] = 0,
			["ScaleType"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Image"] = p45.fore,
			["ScaleType"] = Enum.ScaleType.Fit,
			["AnchorPoint"] = v_u_4(0.5, v_u_57),
			["Position"] = v_u_5(0.5, 0, v_u_57, 0),
			["Size"] = v_u_5(v_u_56, 0, 0, 100)
		}
		local v59 = p_u_44.host
		local v_u_60 = Instance.new("ImageLabel")
		for v61, v62 in v58 do
			v_u_60[v61] = v62
		end
		if v59 then
			v_u_60.Parent = v59
		end
		local v_u_63 = -1
		local function v_u_72(p64) -- name: place
			-- upvalues: (copy) p_u_44, (copy) v_u_60, (ref) v_u_5, (copy) v_u_56, (ref) v_u_63, (copy) v_u_55, (ref) v_u_10, (copy) v_u_52, (ref) v_u_6, (copy) v_u_57
			local v65 = p_u_44.host.AbsoluteSize.X
			local v66 = v65 <= 0 and 200 or v65
			local v67 = v_u_60
			local v68 = v_u_5
			local v69 = v66 * v_u_56 + 0.5
			local v70 = math.floor(v69)
			local v71 = v66 * v_u_56 + 0.5
			v67.Size = v68(0, v70, 0, (math.floor(v71)))
			v_u_63 = v66
			v_u_60.Position = v_u_5(v_u_55 * v_u_6(v_u_10 * p64 / v_u_52 + 0.6) + 0.5, 0, v_u_57, 0)
		end
		v_u_72(1)
		local function v75(p73)
			-- upvalues: (copy) p_u_44, (ref) v_u_63, (copy) v_u_72, (copy) v_u_60, (ref) v_u_5, (copy) v_u_55, (ref) v_u_10, (copy) v_u_52, (ref) v_u_6, (copy) v_u_57
			local v74 = p_u_44.host.AbsoluteSize.X
			if v74 == v_u_63 or v74 <= 0 then
				v_u_60.Position = v_u_5(v_u_55 * v_u_6(v_u_10 * p73 / v_u_52 + 0.6) + 0.5, 0, v_u_57, 0)
			else
				v_u_72(p73)
			end
		end
		if p_u_44.reduced then
			local v76 = p_u_44.host.AbsoluteSize.X
			if v76 == v_u_63 or v76 <= 0 then
				v_u_60.Position = v_u_5(v_u_55 * v_u_6(v_u_10 * 1 / v_u_52 + 0.6) + 0.5, 0, v_u_57, 0)
			else
				v_u_72(1)
			end
		else
			p_u_44.add(v75)
		end
		p_u_44.foreImage = v_u_60
	end
end
local function v_u_99(p78, p79) -- name: aurora
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	local v80 = p79.colors or {
		{ 60, 255, 170 }
	}
	local v_u_81 = p79.speed or 0.4
	local v82 = p79.bands or 1
	for v_u_83 = 1, math.clamp(v82, 1, 3) do
		local v84 = v80[(v_u_83 - 1) % #v80 + 1]
		local v85
		if type(v84) == "table" then
			v85 = Color3.fromRGB(v84[1] or 255, v84[2] or 255, v84[3] or 255)
		else
			v85 = Color3.new(1, 1, 1)
		end
		local v86 = p78.host
		local v87 = {
			["Name"] = "Aurora" .. v_u_83,
			["AnchorPoint"] = v_u_4(0.5, 0.5),
			["Position"] = v_u_5(0.5, 0, v_u_83 * 0.07 + 0.26, 0),
			["Size"] = v_u_5(1.5, 0, 0.26, 0),
			["BackgroundColor3"] = v85,
			["BorderSizePixel"] = 0
		}
		if v87.BackgroundTransparency == nil then
			v87.BackgroundTransparency = 0
		end
		local v_u_88 = Instance.new("Frame")
		for v89, v90 in v87 do
			v_u_88[v89] = v90
		end
		if v86 then
			v_u_88.Parent = v86
		end
		local v91 = {
			["Rotation"] = 90,
			["Color"] = nil,
			["Color"] = ColorSequence.new(v85, v85:Lerp(Color3.new(1, 1, 1), 0.35))
		}
		local v_u_92 = Instance.new("UIGradient")
		for v93, v94 in v91 do
			v_u_92[v93] = v94
		end
		if v_u_88 then
			v_u_92.Parent = v_u_88
		end
		local function v98(p95)
			-- upvalues: (copy) v_u_81, (copy) v_u_83, (ref) v_u_6, (copy) v_u_92, (ref) v_u_4, (copy) v_u_88, (ref) v_u_5
			local v96 = p95 * v_u_81
			local v97 = v_u_6(v96 * 1.3 + v_u_83 * 1.9) * 0.22 + 0.55
			v_u_92.Offset = v_u_4(0, v_u_6(v96 + v_u_83) * 0.14)
			v_u_92.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, v97), NumberSequenceKeypoint.new(1, 1) })
			v_u_88.Position = v_u_5(v_u_6(v96 * 0.7 + v_u_83) * 0.05 + 0.5, 0, v_u_83 * 0.07 + 0.26 + v_u_6(v96 * 0.5 + v_u_83 * 2) * 0.03, 0)
			v_u_88.Rotation = v_u_6(v96 * 0.6 + v_u_83) * 5 + -8
		end
		if p78.reduced then
			v98(1)
		else
			p78.add(v98)
		end
	end
end
local function v_u_122(p100, p101) -- name: fog
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6
	local v102 = p101.color
	local v103 = Color3.fromRGB(225, 235, 245)
	local v104
	if type(v102) == "table" then
		v104 = Color3.fromRGB(v102[1] or 255, v102[2] or 255, v102[3] or 255)
	else
		v104 = v103 or Color3.new(1, 1, 1)
	end
	local v105 = p101.alpha or 0.8
	local v106 = math.clamp(v105, 0.3, 1)
	local v_u_107 = p101.speed or 0.02
	local v108 = p101.bands or 1
	for v_u_109 = 1, math.clamp(v108, 1, 3) do
		local v110 = p100.host
		local v111 = {
			["Name"] = "Fog" .. v_u_109,
			["AnchorPoint"] = v_u_4(0.5, 0.5),
			["Position"] = v_u_5(0.5, 0, 0.62 - (v_u_109 - 1) * 0.18, 0),
			["Size"] = v_u_5(1.8, 0, 0.3, 0),
			["BackgroundColor3"] = v104,
			["BorderSizePixel"] = 0
		}
		if v111.BackgroundTransparency == nil then
			v111.BackgroundTransparency = 0
		end
		local v_u_112 = Instance.new("Frame")
		for v113, v114 in v111 do
			v_u_112[v113] = v114
		end
		if v110 then
			v_u_112.Parent = v110
		end
		local v115 = {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, v106), NumberSequenceKeypoint.new(1, 1) })
		}
		local v116 = Instance.new("UIGradient")
		for v117, v118 in v115 do
			v116[v117] = v118
		end
		if v_u_112 then
			v116.Parent = v_u_112
		end
		local v_u_119 = 0.62 - (v_u_109 - 1) * 0.18
		local function v121(p120)
			-- upvalues: (copy) v_u_112, (ref) v_u_5, (ref) v_u_10, (copy) v_u_107, (copy) v_u_109, (ref) v_u_6, (copy) v_u_119
			v_u_112.Position = v_u_5(v_u_6(v_u_10 * v_u_107 * p120 + v_u_109 * 2.1) * 0.22 + 0.5, 0, v_u_119 + v_u_6(p120 * 0.4 + v_u_109) * 0.015, 0)
		end
		if p100.reduced then
			v_u_112.Position = v_u_5(v_u_6(v_u_10 * v_u_107 * 1 + v_u_109 * 2.1) * 0.22 + 0.5, 0, v_u_119 + v_u_6(v_u_109 + 0.4) * 0.015, 0)
		else
			p100.add(v121)
		end
	end
end
local function v_u_144(p123, p124) -- name: pulse
	-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9
	local v125 = p124.color
	local v126
	if type(v125) == "table" then
		v126 = Color3.fromRGB(v125[1] or 255, v125[2] or 255, v125[3] or 255)
	else
		v126 = Color3.new(1, 1, 1)
	end
	local v_u_127 = p124.rate or 1
	local v128 = p124.depth or 0.2
	local v_u_129 = math.clamp(v128, 0, 0.6)
	local v130 = p123.host
	local v131 = {
		["Name"] = "Pulse",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = v_u_5(1, 0, 1, 0),
		["BackgroundColor3"] = v126,
		["BorderSizePixel"] = 0
	}
	if v131.BackgroundTransparency == nil then
		v131.BackgroundTransparency = 0
	end
	local v_u_132 = Instance.new("Frame")
	for v133, v134 in v131 do
		v_u_132[v133] = v134
	end
	if v130 then
		v_u_132.Parent = v130
	end
	local v135 = {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.65), NumberSequenceKeypoint.new(1, 1) })
	}
	local v136 = Instance.new("UIGradient")
	for v137, v138 in v135 do
		v136[v137] = v138
	end
	if v_u_132 then
		v136.Parent = v_u_132
	end
	local v_u_139 = p124.kind
	local function v143(p140)
		-- upvalues: (copy) v_u_139, (ref) v_u_10, (copy) v_u_127, (ref) v_u_6, (ref) v_u_9, (copy) v_u_132, (copy) v_u_129
		local v141
		if v_u_139 == "beacon" then
			v141 = v_u_9(0, (v_u_6(v_u_10 * v_u_127 * p140))) ^ 4
		elseif v_u_139 == "flicker" then
			local v142 = v_u_6(v_u_10 * v_u_127 * p140) * 0.28 + 0.5 + v_u_6(v_u_10 * v_u_127 * 2.37 * p140 + 1.3) * 0.22
			v141 = math.clamp(v142, 0, 1)
		else
			v141 = v_u_6(v_u_10 * v_u_127 * p140) * 0.5 + 0.5
		end
		v_u_132.BackgroundTransparency = 1 - v_u_129 * v141
	end
	if p123.reduced then
		v143(1)
	else
		p123.add(v143)
	end
end
local v_u_145 = {}
local function v_u_164(p146, p147, p148, p149) -- name: dot
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_4
	local v150 = p147.size[1]
	local v151 = p147.size[2]
	local v152 = v150 + v_u_8(p146.rnd() * (v151 - v150 + 1))
	local v153 = p146.host
	local v154 = {
		["Name"] = p148,
		["Size"] = v_u_5(0, v152, 0, v152),
		["AnchorPoint"] = v_u_4(0.5, 0.5)
	}
	local v155 = p147.color
	local v156
	if type(v155) == "table" then
		v156 = Color3.fromRGB(v155[1] or 255, v155[2] or 255, v155[3] or 255)
	else
		v156 = Color3.new(1, 1, 1)
	end
	v154.BackgroundColor3 = v156
	v154.BackgroundTransparency = 1 - p147.alpha
	v154.BorderSizePixel = 0
	if v154.BackgroundTransparency == nil then
		v154.BackgroundTransparency = 0
	end
	local v157 = Instance.new("Frame")
	for v158, v159 in v154 do
		v157[v158] = v159
	end
	if v153 then
		v157.Parent = v153
	end
	if p149 then
		local v160 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v161 = Instance.new("UICorner")
		for v162, v163 in v160 do
			v161[v162] = v163
		end
		if v157 then
			v161.Parent = v157
		end
	end
	return v157, v152
end
function v_u_145.snow(p165, p_u_166, p167) -- name: snow
	-- upvalues: (copy) v_u_164, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6
	local v_u_168 = v_u_164(p165, p_u_166, "P" .. p167, true)
	local v_u_169 = p165.rnd()
	local v_u_170 = p165.rnd()
	local v_u_171 = p_u_166.speed * (0.6 + p165.rnd() * 0.8)
	local function v173(p172)
		-- upvalues: (copy) v_u_168, (ref) v_u_5, (copy) v_u_169, (copy) v_u_170, (ref) v_u_10, (ref) v_u_6, (copy) p_u_166, (copy) v_u_171
		v_u_168.Position = v_u_5((v_u_169 + v_u_6(p172 * 0.9 + v_u_170 * v_u_10) * p_u_166.drift) % 1, 0, (p172 * v_u_171 + v_u_170) % 1, 0)
	end
	if p165.reduced then
		v_u_168.Position = v_u_5((v_u_169 + v_u_6(0.9 + v_u_170 * v_u_10) * p_u_166.drift) % 1, 0, (1 * v_u_171 + v_u_170) % 1, 0)
	else
		p165.add(v173)
	end
end
function v_u_145.ash(p174, p_u_175, p176) -- name: ash
	-- upvalues: (copy) v_u_164, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6
	local v_u_177 = v_u_164(p174, p_u_175, "P" .. p176, true)
	local v_u_178 = p174.rnd()
	local v_u_179 = p174.rnd()
	local v_u_180 = p_u_175.speed * (0.6 + p174.rnd() * 0.8)
	local function v182(p181)
		-- upvalues: (copy) v_u_177, (ref) v_u_5, (copy) v_u_178, (copy) v_u_179, (ref) v_u_10, (ref) v_u_6, (copy) p_u_175, (copy) v_u_180
		v_u_177.Position = v_u_5((v_u_178 + v_u_6(p181 * 0.5 + v_u_179 * v_u_10) * p_u_175.drift) % 1, 0, (p181 * v_u_180 + v_u_179) % 1, 0)
		v_u_177.BackgroundTransparency = 1 - p_u_175.alpha * (v_u_6(p181 * 1.1 + v_u_179 * 9) * 0.45 + 0.55)
	end
	if p174.reduced then
		v_u_177.Position = v_u_5((v_u_178 + v_u_6(0.5 + v_u_179 * v_u_10) * p_u_175.drift) % 1, 0, (1 * v_u_180 + v_u_179) % 1, 0)
		v_u_177.BackgroundTransparency = 1 - p_u_175.alpha * (v_u_6(1.1 + v_u_179 * 9) * 0.45 + 0.55)
	else
		p174.add(v182)
	end
end
function v_u_145.ember(p183, p_u_184, p185) -- name: ember
	-- upvalues: (copy) v_u_164, (copy) v_u_5, (copy) v_u_6
	local v_u_186 = v_u_164(p183, p_u_184, "P" .. p185, true)
	local v_u_187 = p183.rnd()
	local v_u_188 = p183.rnd()
	local v_u_189 = p_u_184.speed * (0.6 + p183.rnd() * 0.8)
	local function v194(p190)
		-- upvalues: (copy) v_u_189, (copy) v_u_188, (copy) v_u_186, (ref) v_u_5, (copy) v_u_187, (ref) v_u_6, (copy) p_u_184
		local v191 = (p190 * v_u_189 + v_u_188) % 1
		v_u_186.Position = v_u_5((v_u_187 + v_u_6(p190 * 1.3 + v_u_188 * 9) * p_u_184.drift) % 1, 0, 1 - v191, 0)
		local v192 = v_u_186
		local v193 = 1 - p_u_184.alpha + p_u_184.alpha * v191 * 0.9
		v192.BackgroundTransparency = math.clamp(v193, 0, 1)
	end
	if p183.reduced then
		local v195 = (1 * v_u_189 + v_u_188) % 1
		v_u_186.Position = v_u_5((v_u_187 + v_u_6(1.3 + v_u_188 * 9) * p_u_184.drift) % 1, 0, 1 - v195, 0)
		local v196 = 1 - p_u_184.alpha + p_u_184.alpha * v195 * 0.9
		v_u_186.BackgroundTransparency = math.clamp(v196, 0, 1)
	else
		p183.add(v194)
	end
end
function v_u_145.streak(p197, p198, p199) -- name: streak
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_4
	local v200 = p198.size[1]
	local v201 = p197.host
	local v202 = {
		["Name"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Rotation"] = 28,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["Name"] = "P" .. p199,
		["Size"] = v_u_5(0, v200 + v_u_8(p197.rnd() * (p198.size[2] - v200 + 1)), 0, 1),
		["AnchorPoint"] = v_u_4(0.5, 0.5)
	}
	local v203 = p198.color
	local v204
	if type(v203) == "table" then
		v204 = Color3.fromRGB(v203[1] or 255, v203[2] or 255, v203[3] or 255)
	else
		v204 = Color3.new(1, 1, 1)
	end
	v202.BackgroundColor3 = v204
	v202.BackgroundTransparency = 1 - p198.alpha
	v202.BorderSizePixel = 0
	if v202.BackgroundTransparency == nil then
		v202.BackgroundTransparency = 0
	end
	local v_u_205 = Instance.new("Frame")
	for v206, v207 in v202 do
		v_u_205[v206] = v207
	end
	if v201 then
		v_u_205.Parent = v201
	end
	local v_u_208 = p197.rnd()
	local v_u_209 = p197.rnd()
	local v_u_210 = p198.speed * (0.7 + p197.rnd() * 0.6)
	local function v213(p211)
		-- upvalues: (copy) v_u_210, (copy) v_u_209, (copy) v_u_205, (ref) v_u_5, (copy) v_u_208
		local v212 = (p211 * v_u_210 + v_u_209) % 1
		v_u_205.Position = v_u_5((v_u_208 + v212 * 0.5) % 1, 0, v212, 0)
	end
	if p197.reduced then
		local v214 = (1 * v_u_210 + v_u_209) % 1
		v_u_205.Position = v_u_5((v_u_208 + v214 * 0.5) % 1, 0, v214, 0)
	else
		p197.add(v213)
	end
end
function v_u_145.dust(p215, p_u_216, p217) -- name: dust
	-- upvalues: (copy) v_u_164, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6, (copy) v_u_7
	local v_u_218 = v_u_164(p215, p_u_216, "P" .. p217, true)
	local v_u_219 = p215.rnd()
	local v_u_220 = p215.rnd()
	local v_u_221 = p215.rnd()
	local v_u_222 = p_u_216.speed * 10
	local function v224(p223)
		-- upvalues: (copy) v_u_218, (ref) v_u_5, (copy) v_u_219, (copy) v_u_222, (copy) v_u_221, (ref) v_u_10, (ref) v_u_6, (copy) p_u_216, (copy) v_u_220, (ref) v_u_7
		v_u_218.Position = v_u_5(v_u_219 + v_u_6(p223 * v_u_222 * 0.3 + v_u_221 * v_u_10) * (p_u_216.drift + 0.02), 0, v_u_220 + v_u_7(p223 * v_u_222 * 0.25 + v_u_221 * 5) * (p_u_216.drift + 0.03), 0)
		v_u_218.BackgroundTransparency = 1 - p_u_216.alpha * (v_u_6(p223 * 0.8 + v_u_221 * 7) * 0.5 + 0.5)
	end
	if p215.reduced then
		v224(1)
	else
		p215.add(v224)
	end
end
function v_u_145.sparkle(p225, p_u_226, p227) -- name: sparkle
	-- upvalues: (copy) v_u_164, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7
	local v_u_228 = v_u_164(p225, p_u_226, "P" .. p227, false)
	v_u_228.Rotation = 45
	local v_u_229 = p225.rnd()
	local v_u_230 = p225.rnd() * 0.9
	local v_u_231 = p225.rnd()
	local v_u_232 = 0.6 + p225.rnd() * 0.9
	local function v235(p233)
		-- upvalues: (copy) v_u_232, (copy) v_u_231, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (copy) v_u_228, (ref) v_u_5, (copy) v_u_229, (copy) p_u_226, (copy) v_u_230, (ref) v_u_7
		local v234 = v_u_9(0, (v_u_6(p233 * v_u_232 * 2 + v_u_231 * v_u_10))) ^ 3
		v_u_228.Position = v_u_5(v_u_229 + v_u_6(p233 * p_u_226.speed * 6 + v_u_231 * 5) * p_u_226.drift, 0, v_u_230 + v_u_7(p233 * p_u_226.speed * 5 + v_u_231 * 3) * p_u_226.drift, 0)
		v_u_228.BackgroundTransparency = 1 - p_u_226.alpha * v234
	end
	if p225.reduced then
		v235(1)
	else
		p225.add(v235)
	end
end
local function v_u_242(p236, p237) -- name: particles
	-- upvalues: (copy) v_u_145, (copy) v_u_8, (copy) v_u_3
	local v238 = v_u_145[p237.kind]
	if v238 ~= nil then
		local v239 = v_u_8(p237.n or 0)
		local v240 = v_u_3.MAX_PARTICLES
		for v241 = 1, math.clamp(v239, 0, v240) do
			v238(p236, p237, v241)
		end
	end
end
function v_u_3.over(p243, p244) -- name: over
	-- upvalues: (copy) v_u_99, (copy) v_u_122, (copy) v_u_144, (copy) v_u_77, (copy) v_u_242
	local v245
	if type(p244) == "table" then
		local v246 = p244.recipe
		v245 = type(v246) ~= "table" and {} or p244.recipe
	else
		v245 = {}
	end
	if v245.aurora then
		v_u_99(p243, v245.aurora)
	end
	if v245.fog then
		v_u_122(p243, v245.fog)
	end
	if v245.pulse then
		v_u_144(p243, v245.pulse)
	end
	if type(p244) == "table" then
		v_u_77(p243, p244)
	end
	if v245.particles and not p243.reduced then
		v_u_242(p243, v245.particles)
	end
end
return v_u_3