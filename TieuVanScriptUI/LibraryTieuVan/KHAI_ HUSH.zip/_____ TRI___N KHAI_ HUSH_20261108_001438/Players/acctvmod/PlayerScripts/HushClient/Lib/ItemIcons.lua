-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ItemIcons

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Players")
local v_u_4 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v5 = {}
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local function v_u_21() -- name: deps
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (ref) v_u_6, (ref) v_u_7
	if not v_u_8 then
		local v9 = require
		local v10 = v_u_4
		local v11, v12 = pcall(v9, v10:WaitForChild("WeaponDress"))
		if not v11 then
			v12 = false
		end
		v_u_8 = v12
	end
	if not v_u_6 then
		local v13 = require
		local v14 = v_u_4
		local v15, v16 = pcall(v13, v14:WaitForChild("Assets"))
		if not v15 then
			v16 = false
		end
		v_u_6 = v16
	end
	if not v_u_7 then
		local v17 = require
		local v18 = v_u_4
		local v19, v20 = pcall(v17, v18:WaitForChild("Items"))
		if not v19 then
			v20 = false
		end
		v_u_7 = v20
	end
end
local v_u_22 = nil
local function v_u_35(p23, p24) -- name: resolveSkin
	-- upvalues: (copy) v_u_21, (ref) v_u_7, (ref) v_u_22, (copy) v_u_4, (copy) v_u_3
	if p24 == nil or p24 == false then
		return nil
	else
		v_u_21()
		if v_u_7 then
			local v25 = v_u_7.get(p23)
			if v25 and (v25.category == "firearm" or v25.category == "melee") and v25.gold ~= true then
				if v_u_22 == nil then
					local v26 = require
					local v27 = v_u_4
					local v28, v29 = pcall(v26, v27:WaitForChild("SkinApply"))
					if not v28 then
						v29 = false
					end
					v_u_22 = v29
				end
				if v_u_22 then
					local v30 = v25.weaponId or v25.id
					if p24 == true then
						local v31 = v_u_3.LocalPlayer
						if v31 then
							local function v32()
								-- upvalues: (ref) v_u_4
								return require(v_u_4:WaitForChild("SkinVisibility"))
							end
							local v33, v34 = pcall(v32)
							if v33 and (type(v34) == "table" and v34.enabled() == false) then
								return nil
							else
								return v_u_22.equippedFor(v31, v30)
							end
						else
							return nil
						end
					elseif type(p24) == "string" and v_u_22.fits(p24, v30) then
						return p24
					else
						return nil
					end
				else
					return nil
				end
			else
				return nil
			end
		else
			return nil
		end
	end
end
v5.resolveSkin = v_u_35
local v_u_36 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_37 = {}
local v_u_38 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_39 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_40 = {}
local v_u_41 = nil
local function v_u_48(p42, p43) -- name: baseKey
	-- upvalues: (copy) v_u_21, (ref) v_u_8, (ref) v_u_7
	if type(p43) == "table" and next(p43) ~= nil then
		v_u_21()
		if v_u_8 and v_u_7 then
			local v44 = v_u_7.get(p42)
			if v44 and v44.category == "firearm" then
				local v45 = v_u_8.modsKey
				local v46, v47 = pcall(v45, p43)
				if v46 and (type(v47) == "string" and v47 ~= "") then
					return p42 .. "|" .. v47
				else
					return p42
				end
			else
				return p42
			end
		else
			return p42
		end
	else
		return p42
	end
end
function v5.keyOf(p49, p50, p51) -- name: keyOf
	-- upvalues: (copy) v_u_48
	local v52 = v_u_48(p49, p50)
	if type(p51) == "string" and p51 ~= "" then
		return v52 .. "|s:" .. p51
	else
		return v52
	end
end
local function v_u_55(p53) -- name: strip
	for _, v54 in p53:GetDescendants() do
		if v54:IsA("Script") or (v54:IsA("LocalScript") or (v54:IsA("ProximityPrompt") or (v54:IsA("ParticleEmitter") or (v54:IsA("Light") or v54:IsA("Sound"))))) then
			v54:Destroy()
		else
			if not v54:IsA("BasePart") then
				continue
			end
			v54.Anchored = true
			v54.CastShadow = false
		end
	end
end
local v_u_56 = {}
local v_u_57 = CFrame.fromMatrix(Vector3.new(0, 0, 0), (Vector3.new(0, 0, -1)):Cross(Vector3.new(-1, -0, -0)), Vector3.new(0, 0, -1), Vector3.new(-1, -0, -0))
local function v_u_61(p58) -- name: gripRot
	local v59 = p58.PrimaryPart or p58:FindFirstChild("Handle", true)
	local v60
	if v59 then
		v60 = v59:FindFirstChild("Grip")
	else
		v60 = v59
	end
	if v59 and (v59:IsA("BasePart") and (v60 and v60:IsA("Attachment"))) then
		return (v59.CFrame * v60.CFrame).Rotation
	else
		return nil
	end
end
local function v_u_88(p62) -- name: worldBox
	local v63 = Vector3.new(inf, inf, inf)
	local v64 = -v63
	local v65 = false
	for _, v66 in p62:GetDescendants() do
		if not v66:IsA("BasePart") or v66:GetAttribute("SkinPlate") == true then
			continue
		end
		local v67 = v66.CFrame
		local v68 = v66.Size / 2
		local v69 = v67.XVector.X
		local v70 = math.abs(v69) * v68.X
		local v71 = v67.YVector.X
		local v72 = v70 + math.abs(v71) * v68.Y
		local v73 = v67.ZVector.X
		local v74 = v72 + math.abs(v73) * v68.Z
		local v75 = v67.XVector.Y
		local v76 = math.abs(v75) * v68.X
		local v77 = v67.YVector.Y
		local v78 = v76 + math.abs(v77) * v68.Y
		local v79 = v67.ZVector.Y
		local v80 = v78 + math.abs(v79) * v68.Z
		local v81 = v67.XVector.Z
		local v82 = math.abs(v81) * v68.X
		local v83 = v67.YVector.Z
		local v84 = v82 + math.abs(v83) * v68.Y
		local v85 = v67.ZVector.Z
		local v86 = v84 + math.abs(v85) * v68.Z
		local v87 = Vector3.new(v74, v80, v86)
		v63 = v63:Min(v67.Position - v87)
		v64 = v64:Max(v67.Position + v87)
		v65 = true
	end
	if v65 then
		return (v63 + v64) / 2, v64 - v63
	else
		return Vector3.new(0, 0, 0), Vector3.new(1, 0.4, 1)
	end
end
local function v_u_100(p89) -- name: plainGripRot
	-- upvalues: (copy) v_u_56, (ref) v_u_6, (ref) v_u_7, (copy) v_u_61, (copy) v_u_57
	local v90 = v_u_56[p89]
	if v90 == nil then
		local v91 = false
		if v_u_6 then
			local v92 = v_u_7
			if v92 then
				v92 = v_u_7.get(p89)
			end
			local v93
			if v92 then
				local v94 = v92.model
				if type(v94) == "string" and v92.model ~= "" then
					v93 = v92.model
				else
					v93 = p89
				end
			else
				v93 = p89
			end
			local v95 = v_u_6.template
			local v96, v97 = pcall(v95, "Item", v93)
			if v96 and (typeof(v97) == "Instance" and v97:IsA("Model")) then
				local v98 = v97:Clone()
				v98:PivotTo(CFrame.new())
				v90 = v_u_61(v98)
				if v90 then
					local v99 = v90.LookVector.Y
					if math.abs(v99) >= 0.05 then
						v90 = v91
					end
				else
					v90 = v91
				end
				v98:Destroy()
			else
				v90 = v91
			end
		else
			v90 = v91
		end
		v_u_56[p89] = v90
	end
	return v90 or v_u_57
end
local function v_u_109(p101, p102) -- name: levelByGrip
	-- upvalues: (copy) v_u_61, (copy) v_u_100, (copy) v_u_88
	local v103 = v_u_61(p101)
	if v103 then
		local v104 = v_u_100(p102)
		if v103.LookVector:Dot(v104.LookVector) <= 0.999 or v103.UpVector:Dot(v104.UpVector) <= 0.999 then
			local v105 = v_u_88(p101)
			local v106 = v104 * v103:Inverse()
			p101:PivotTo(CFrame.new(v105) * v106 * CFrame.new(-v105) * p101:GetPivot())
			local v107 = v_u_88(p101)
			local v108 = p101.PrimaryPart
			if v108 then
				v108.PivotOffset = v108.CFrame:ToObjectSpace(CFrame.new(v107))
			else
				p101.WorldPivot = CFrame.new(v107)
			end
			p101:SetAttribute("IconLevelled", true)
		end
	else
		return
	end
end
local v_u_110 = nil
local v_u_111 = nil
local function v_u_124(p112, p113) -- name: flattenTexGloss
	-- upvalues: (ref) v_u_110, (copy) v_u_4, (ref) v_u_111
	if type(p113) == "string" then
		if v_u_110 == nil then
			local v114 = require
			local v115 = v_u_4
			local v116, v117 = pcall(v114, v115:WaitForChild("Skins"))
			if not v116 then
				v117 = false
			end
			v_u_110 = v117
			local v118 = require
			local v119 = v_u_4
			local v120, v121 = pcall(v118, v119:WaitForChild("SkinFinishes"))
			if not v120 then
				v121 = false
			end
			v_u_111 = v121
		end
		if v_u_110 and v_u_111 then
			local v122 = v_u_110.get(p113)
			if v122 then
				v122 = v_u_111.get(v122.finish)
			end
			if v122 and v122.tex == true then
				for _, v123 in p112:GetDescendants() do
					if not v123:IsA("BasePart") or (v123:GetAttribute("SkinClass") == nil or v123:GetAttribute("SkinPlate") == true) then
						continue
					end
					v123.Reflectance = 0
				end
			end
		else
			return
		end
	else
		return
	end
end
v5.flattenTexGloss = v_u_124
local function v_u_138(p125, p126, p127) -- name: modelFor
	-- upvalues: (copy) v_u_21, (ref) v_u_6, (ref) v_u_8, (copy) v_u_55, (copy) v_u_124, (copy) v_u_109, (ref) v_u_7
	v_u_21()
	if not v_u_6 then
		return nil
	end
	if p126 ~= nil and v_u_8 then
		local v128 = v_u_8.itemModel
		local v129, v130 = pcall(v128, p125, p126, p127)
		if v129 and (typeof(v130) == "Instance" and v130:IsA("Model")) then
			v_u_55(v130)
			v_u_124(v130, p127)
			v_u_109(v130, p125)
			return v130
		end
	end
	if v_u_7 then
		local v131 = v_u_7.get(p125)
		if v131 then
			local v132 = v131.model
			if type(v132) == "string" and v131.model ~= "" then
				p125 = v131.model
			end
		end
	end
	local v133 = v_u_6.template
	local v134, v135 = pcall(v133, "Item", p125)
	if not (v134 and v135) then
		return nil
	end
	local v136 = v135:Clone()
	local v137
	if v136:IsA("BasePart") then
		v137 = Instance.new("Model")
		v136.Parent = v137
		v137.PrimaryPart = v136
	else
		v137 = v136
	end
	if not v137:IsA("Model") then
		return nil
	end
	if p127 and (v_u_8 and v_u_8.paintSkin) then
		v_u_8.paintSkin(v137, p127)
		v_u_124(v137, p127)
	end
	v_u_55(v137)
	return v137
end
local function v_u_155(p139, p140, p141, p142) -- name: fitDistance
	local v143
	if p140 then
		v143 = p139.Z
	else
		v143 = p139.X
	end
	local v144
	if p140 then
		v144 = p139.X
	else
		v144 = p139.Z
	end
	if p141 then
		local v145 = p139.X * p139.X + p139.Z * p139.Z
		v143 = math.sqrt(v145)
		v144 = v143
	end
	local v146 = v143 * 0.5
	local v147 = (v144 * 0.848048096156426 + p139.Y * 0.5299192642332049) * 0.5
	local v148 = p142 * 0.21255656167002213
	local v149 = v147 / 0.21255656167002213
	local v150 = v146 / v148
	local v151 = math.max(v149, v150) * 1.12
	local v152 = p139.X
	local v153 = p139.Y
	local v154 = p139.Z
	return v151 + math.max(v152, v153, v154) * 0.5
end
local function v_u_169(p156, p157) -- name: aim
	-- upvalues: (copy) v_u_155
	local v158 = p157.ext
	local v159 = p156.AbsoluteSize
	local v160
	if v159.X > 1 and v159.Y > 1 then
		v160 = v159.X / v159.Y
	else
		local v161
		if p157.rotated then
			v161 = v158.Z
		else
			v161 = v158.X
		end
		local v162 = math.max(v161, 0.1)
		local v163
		if p157.rotated then
			v163 = v158.X
		else
			v163 = v158.Z
		end
		v160 = v162 / math.max(v163, 0.1)
	end
	local v164 = v_u_155(v158, p157.rotated, p157.spin ~= nil, v160)
	local v165 = (p157.rotated and 1.5707963267948966 or 0) + (p157.spin or 0)
	local v166 = math.sin(v165) * 0.5299192642332049
	local v167 = math.cos(v165) * 0.5299192642332049
	local v168 = Vector3.new(v166, 0.848048096156426, v167)
	p157.cam.FieldOfView = 24
	p157.cam.CFrame = CFrame.lookAt(p157.center + v168 * v164, p157.center)
end
local function v_u_189(p170, p_u_171, p172, p173) -- name: build
	-- upvalues: (copy) v_u_138, (copy) v_u_88, (copy) v_u_4, (copy) v_u_36, (copy) v_u_39, (copy) v_u_40, (copy) v_u_38, (ref) v_u_37, (copy) v_u_169
	local v_u_174 = Instance.new("ViewportFrame")
	v_u_174.Name = "Icon"
	v_u_174.BackgroundTransparency = 1
	v_u_174.BorderSizePixel = 0
	v_u_174.Ambient = Color3.fromRGB(128, 132, 140)
	v_u_174.LightColor = Color3.fromRGB(255, 244, 226)
	v_u_174.LightDirection = Vector3.new(-0.6, -1, -0.35)
	v_u_174.ImageTransparency = 0
	local v175 = Instance.new("Camera")
	v175.Parent = v_u_174
	v_u_174.CurrentCamera = v175
	local v176 = v_u_138
	if p_u_171 == p170 then
		p172 = nil
	end
	local v177 = v176(p170, p172, p173)
	local v178, v179
	if v177 then
		v177:PivotTo(CFrame.new())
		if p_u_171 == p170 then
			local v180
			v180, v178 = v177:GetBoundingBox()
			v179 = v180.Position
		else
			v179, v178 = v_u_88(v177)
		end
		v177.Parent = v_u_174
	else
		v178 = Vector3.new(1, 0.4, 1)
		v179 = Vector3.new(0, 0, 0)
	end
	if not v177 then
		local function v181()
			-- upvalues: (ref) v_u_4
			return require(v_u_4:WaitForChild("ItemTileArt", 2))
		end
		local v182, v183 = pcall(v181)
		local v184
		if v182 and type(v183) == "table" then
			v184 = v183.image(p170)
		else
			v184 = nil
		end
		if v184 then
			local v185 = Instance.new("ImageLabel")
			v185.Name = "TileArt"
			v185.BackgroundTransparency = 1
			v185.BorderSizePixel = 0
			v185.Size = UDim2.fromScale(1, 1)
			v185.Image = v184
			v185.ScaleType = Enum.ScaleType.Fit
			v185.Parent = v_u_174
		end
	end
	v_u_36[v_u_174] = {
		["id"] = nil,
		["key"] = nil,
		["rotated"] = false,
		["model"] = nil,
		["cam"] = nil,
		["ext"] = nil,
		["center"] = nil,
		["id"] = p170,
		["key"] = p_u_171,
		["model"] = v177,
		["cam"] = v175,
		["ext"] = v178,
		["center"] = v179
	}
	v_u_174.Destroying:Connect(function()
		-- upvalues: (ref) v_u_39, (copy) v_u_174, (ref) v_u_36, (ref) v_u_40, (ref) v_u_38, (ref) v_u_37, (copy) p_u_171
		v_u_39[v_u_174] = true
		v_u_36[v_u_174] = nil
		v_u_40[v_u_174] = nil
		if v_u_38[v_u_174] then
			v_u_38[v_u_174] = nil
			local v186 = v_u_37[p_u_171]
			local v187
			if v186 then
				v187 = table.find(v186, v_u_174)
			else
				v187 = v186
			end
			if v186 and v187 then
				table.remove(v186, v187)
			end
		end
	end)
	v_u_174:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (ref) v_u_36, (copy) v_u_174, (ref) v_u_169
		local v188 = v_u_36[v_u_174]
		if v188 then
			v_u_169(v_u_174, v188)
		end
	end)
	return v_u_174
end
local v_u_190 = Instance.new("Folder")
v_u_190.Name = "ItemIconsProbe"
function v5.fitDistance(p191, p192, p193, p194) -- name: fitDistance
	-- upvalues: (copy) v_u_155
	return v_u_155(p191, p192, p193, p194)
end
function v5.alive(p195) -- name: alive
	-- upvalues: (copy) v_u_39, (copy) v_u_36
	if typeof(p195) == "Instance" and not v_u_39[p195] then
		return v_u_36[p195] ~= nil
	else
		return false
	end
end
local function v_u_201(p196) -- name: popPool
	-- upvalues: (ref) v_u_37, (copy) v_u_38, (copy) v_u_36, (copy) v_u_39, (copy) v_u_190, (copy) v_u_40
	local v197 = v_u_37[p196]
	if not v197 or #v197 <= 0 then
		return nil
	end
	local v_u_198 = table.remove(v197)
	v_u_38[v_u_198] = nil
	if not v_u_36[v_u_198] or (v_u_39[v_u_198] or v_u_198.Parent ~= nil) then
		continue
	end
	local v199
	if v_u_39[v_u_198] then
		v199 = false
	else
		local function v200()
			-- upvalues: (copy) v_u_198, (ref) v_u_190
			v_u_198.Parent = v_u_190
			v_u_198.Parent = nil
		end
		v199 = pcall(v200)
		if not v199 then
			v_u_39[v_u_198] = true
			v_u_36[v_u_198] = nil
			v_u_40[v_u_198] = nil
		end
	end
	if not v199 then
		continue
	end
	return v_u_198
end
function v5.get(p202, p203, p204) -- name: get
	-- upvalues: (copy) v_u_35, (copy) v_u_48, (copy) v_u_201, (copy) v_u_189, (copy) v_u_36, (copy) v_u_39, (copy) v_u_169
	local v205
	if p204 then
		v205 = p204.mods
	else
		v205 = p204
	end
	local v206 = v_u_35
	local v207
	if p204 then
		v207 = p204.skin
	else
		v207 = nil
	end
	local v208 = v206(p202, v207)
	local v209 = v_u_48(p202, v205)
	if type(v208) == "string" and v208 ~= "" then
		v209 = v209 .. "|s:" .. v208
	end
	local v_u_210 = v_u_201(v209) or v_u_189(p202, v209, v205, v208)
	local v211 = v_u_36[v_u_210]
	if v211 then
		v211.rotated = p203 == true
		v211.spin = nil
	end
	local v_u_212 = p204 or {}
	v_u_210.Size = v_u_212.size or UDim2.fromScale(1, 1)
	v_u_210.Position = v_u_212.position or UDim2.new()
	v_u_210.AnchorPoint = v_u_212.anchor or Vector2.zero
	v_u_210.ZIndex = v_u_212.zindex or 1
	v_u_210.Name = v_u_212.name or "Icon"
	v_u_210.Visible = true
	v_u_210.ImageTransparency = 0
	if v_u_212.parent and not pcall(function()
		-- upvalues: (ref) v_u_210, (copy) v_u_212
		v_u_210.Parent = v_u_212.parent
	end) then
		v_u_39[v_u_210] = true
		v_u_36[v_u_210] = nil
		local v213 = v_u_210.Destroy
		pcall(v213, v_u_210)
		local v214 = v_u_189(p202, v209, v205, v208)
		v211 = v_u_36[v214]
		if v211 then
			v211.rotated = p203 == true
		end
		v214.Size = v_u_212.size or UDim2.fromScale(1, 1)
		v214.Position = v_u_212.position or UDim2.new()
		v214.AnchorPoint = v_u_212.anchor or Vector2.zero
		v214.ZIndex = v_u_212.zindex or 1
		v214.Name = v_u_212.name or "Icon"
		v214.Parent = v_u_212.parent
		v_u_210 = v214
	end
	if v211 then
		v_u_169(v_u_210, v211)
	end
	return v_u_210
end
function v5.setRotated(p215, p216) -- name: setRotated
	-- upvalues: (copy) v_u_36, (copy) v_u_169
	local v217 = v_u_36[p215]
	if v217 and v217.rotated ~= p216 then
		v217.rotated = p216
		v_u_169(p215, v217)
	end
end
function v5.spin(p218, p219) -- name: spin
	-- upvalues: (copy) v_u_36, (copy) v_u_40, (ref) v_u_41, (copy) v_u_2, (copy) v_u_169
	local v220 = v_u_36[p218]
	if v220 then
		if p219 then
			v_u_40[p218] = true
			v220.spin = v220.spin or 0
			if not v_u_41 then
				v_u_41 = v_u_2.Heartbeat:Connect(function(p221)
					-- upvalues: (ref) v_u_40, (ref) v_u_36, (ref) v_u_169, (ref) v_u_41
					local v222 = false
					for v223 in v_u_40 do
						local v224 = v_u_36[v223]
						if not (v224 and v223.Parent) then
							continue
						end
						v224.spin = ((v224.spin or 0) + p221 * 0.6) % 6.283185307179586
						v_u_169(v223, v224)
						v222 = true
					end
					if not v222 and v_u_41 then
						v_u_41:Disconnect()
						v_u_41 = nil
					end
				end)
				return
			end
		else
			v_u_40[p218] = nil
			v220.spin = nil
			v_u_169(p218, v220)
		end
	end
end
function v5.turn(p225, p226) -- name: turn
	-- upvalues: (copy) v_u_36, (copy) v_u_169
	local v227 = v_u_36[p225]
	if v227 and (type(p226) == "number" and p226 == p226) then
		v227.spin = p226 % 6.283185307179586
		v_u_169(p225, v227)
	end
end
function v5.release(p_u_228) -- name: release
	-- upvalues: (copy) v_u_40, (copy) v_u_38, (copy) v_u_36, (copy) v_u_39, (ref) v_u_37, (copy) v_u_190
	if typeof(p_u_228) == "Instance" then
		v_u_40[p_u_228] = nil
		if v_u_38[p_u_228] then
			return
		else
			local v229 = v_u_36[p_u_228]
			if v229 and not v_u_39[p_u_228] then
				v229.spin = nil
				local v230 = v_u_37[v229.key]
				if not v230 then
					v230 = {}
					v_u_37[v229.key] = v230
				end
				if #v230 >= 24 then
					v_u_36[p_u_228] = nil
					local v231 = p_u_228.Destroy
					pcall(v231, p_u_228)
					return
				else
					local v232
					if v_u_39[p_u_228] then
						v232 = false
					else
						local function v233()
							-- upvalues: (copy) p_u_228, (ref) v_u_190
							p_u_228.Parent = v_u_190
							p_u_228.Parent = nil
						end
						v232 = pcall(v233)
						if not v232 then
							v_u_39[p_u_228] = true
							v_u_36[p_u_228] = nil
							v_u_40[p_u_228] = nil
						end
					end
					if v232 then
						v_u_38[p_u_228] = true
						table.insert(v230, p_u_228)
					else
						local v234 = p_u_228.Destroy
						pcall(v234, p_u_228)
					end
				end
			else
				v_u_36[p_u_228] = nil
				local v235 = p_u_228.Destroy
				pcall(v235, p_u_228)
				return
			end
		end
	else
		return
	end
end
function v5.flush() -- name: flush
	-- upvalues: (ref) v_u_37, (copy) v_u_38, (copy) v_u_36
	for _, v236 in v_u_37 do
		for _, v237 in v236 do
			v_u_38[v237] = nil
			v_u_36[v237] = nil
			local v238 = v237.Destroy
			pcall(v238, v237)
		end
	end
	v_u_37 = {}
end
function v5.stats() -- name: stats
	-- upvalues: (ref) v_u_37, (copy) v_u_39, (copy) v_u_36, (copy) v_u_38
	local v239 = 0
	local v240 = 0
	local v241 = 0
	for _, v242 in v_u_37 do
		for v243 = #v242, 1, -1 do
			local v244 = v242[v243]
			if v244.Parent == nil or (v_u_39[v244] or not v_u_36[v244]) then
				continue
			end
			v_u_38[v244] = nil
			table.remove(v242, v243)
		end
		v239 = v239 + 1
		for _, v245 in v242 do
			v240 = v240 + 1
			if not v_u_39[v245] and (v_u_36[v245] and v245.Parent == nil) then
				continue
			end
			v241 = v241 + 1
		end
	end
	return {
		["pooled"] = v240,
		["bad"] = v241,
		["ids"] = v239
	}
end
return v5