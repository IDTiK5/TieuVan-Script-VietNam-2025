-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardRig

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {
	["FOV"] = 30,
	["VIEW_H"] = 7.2,
	["CENTER_Y"] = 3.2,
	["NEED_W"] = 6.4,
	["STEP"] = 0.03333333333333333,
	["PROP_ITEM"] = {
		["g17"] = "pistol_g17",
		["knife"] = "melee_knife",
		["rifle"] = "rifle_ar15"
	},
	["INSTANCE_MAX"] = 320,
	["GRIP_DEFAULT"] = Vector3.new(0, -0.15, 0),
	["GRIP_ROT"] = CFrame.Angles(-1.5707963267948966, 0, 0),
	["AMBIENT"] = Color3.fromRGB(110, 116, 128),
	["KEY"] = Color3.fromRGB(255, 238, 212),
	["KEY_DIR"] = Vector3.new(-0.55, -1, 0.65)
}
local v_u_4 = math.rad
function v_u_3.cameraCF(p5, p6, p7) -- name: cameraCF
	-- upvalues: (copy) v_u_4
	if type(p7) ~= "table" then
		return CFrame.lookAt(p5, p6)
	end
	local v8 = p7.pos[1]
	local v9 = p7.pos[2]
	local v10 = p7.pos[3]
	local v11 = p5 + Vector3.new(v8, v9, v10)
	local v12 = p7.look[1]
	local v13 = p7.look[2]
	local v14 = p7.look[3]
	local v15 = p6 + Vector3.new(v12, v13, v14)
	if (v15 - v11).Magnitude < 0.01 then
		v15 = v11 + Vector3.new(0, 0, 1)
	end
	return CFrame.lookAt(v11, v15) * CFrame.Angles(0, 0, (v_u_4(p7.roll)))
end
function v_u_3.cleanClone(p16) -- name: cleanClone
	for _, v17 in p16:GetDescendants() do
		if v17:IsA("LuaSourceContainer") or (v17:IsA("Animator") or (v17:IsA("Sound") or (v17:IsA("ForceField") or (v17:IsA("BillboardGui") or v17:IsA("Highlight"))))) then
			v17:Destroy()
		else
			if not (v17:IsA("ValueBase") or (v17:IsA("NoCollisionConstraint") or v17:IsA("HumanoidDescription"))) then
				continue
			end
			v17:Destroy()
		end
	end
	for _, v18 in p16:GetDescendants() do
		for v19 in v18:GetAttributes() do
			if string.sub(v19, 1, 3) == "RBX" then
				continue
			end
			v18:SetAttribute(v19, nil)
		end
		for _, v20 in v18:GetTags() do
			v18:RemoveTag(v20)
		end
	end
	for v21 in p16:GetAttributes() do
		if string.sub(v21, 1, 3) == "RBX" then
			continue
		end
		p16:SetAttribute(v21, nil)
	end
	for _, v22 in p16:GetTags() do
		p16:RemoveTag(v22)
	end
end
function v_u_3.sourceFor(p23, p24) -- name: sourceFor
	if type(p23) == "table" and type(p24) == "number" then
		local v25
		if p23.players then
			v25 = p23.players:GetPlayerByUserId(p24)
		else
			v25 = nil
		end
		if v25 then
			v25 = v25.Character
		end
		if v25 and v25:GetAttribute("LookCode") == "blockrig" then
			local v26 = p23.block
			local v27
			if type(v26) == "function" then
				local v28 = p23.block
				local v29
				v29, v27 = pcall(v28, p24)
				if not v29 or (typeof(v27) ~= "Instance" or not v27:IsA("Model")) then
					v27 = nil
				end
			else
				v27 = nil
			end
			if v27 then
				return "block", v27
			end
		end
		local v_u_30 = p23.avatars
		if v_u_30 then
			v_u_30 = v_u_30:FindFirstChild((tostring(p24)))
		end
		if v_u_30 and v_u_30:IsA("Model") then
			local v31 = p23.ready
			local v32, v33 = pcall(v31, v_u_30)
			if v32 and v33 == true then
				local v34, v35 = pcall(function()
					-- upvalues: (copy) v_u_30
					return v_u_30:Clone()
				end)
				if v34 and v35 then
					return "avatar", v35
				end
			end
		end
		local v36 = p23.block
		local v37
		if type(v36) == "function" then
			local v38 = p23.block
			local v39
			v39, v37 = pcall(v38, p24)
			if not v39 or (typeof(v37) ~= "Instance" or not v37:IsA("Model")) then
				v37 = nil
			end
		else
			v37 = nil
		end
		if v37 then
			return "block", v37
		else
			return "thumb", nil
		end
	else
		return "thumb", nil
	end
end
function v_u_3.depsOf(p_u_40) -- name: depsOf
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
	local v_u_41 = p_u_40.shared
	return {
		["players"] = v_u_1,
		["avatars"] = v_u_2:FindFirstChild("HushAvatars"),
		["ready"] = function(p42) -- name: ready
			-- upvalues: (copy) v_u_41
			local v43 = v_u_41.AvatarTemplate.ready
			local v44, v45 = pcall(v43, p42)
			if v44 then
				v44 = v45 == true
			end
			return v44
		end,
		["block"] = function(p46) -- name: block
			-- upvalues: (copy) v_u_41
			return v_u_41.BlockRig.survivor(v_u_41.BlockRigSpec.variantFor(p46), {
				["faceless"] = true
			})
		end,
		["propModel"] = function(p47, p48) -- name: propModel
			-- upvalues: (ref) v_u_3, (copy) v_u_41
			local v49 = v_u_3.PROP_ITEM[p47]
			if v49 == nil or v_u_41.WeaponDress == nil then
				return nil
			else
				local v50 = nil
				if type(p48) == "string" and v_u_41.SkinApply ~= nil then
					local v51 = v_u_41.SkinApply.fits
					local v52, v53 = pcall(v51, p48, v49)
					if v52 then
						if v53 ~= true then
							p48 = v50
						end
					else
						p48 = v50
					end
				else
					p48 = v50
				end
				local v54 = v_u_41.WeaponDress.build
				local v55, v56 = pcall(v54, v49, nil, false, p48)
				if v55 and (typeof(v56) == "Instance" and v56:IsA("Model")) then
					return v56
				else
					return nil
				end
			end
		end,
		["zombieRig"] = function() -- name: zombieRig
			-- upvalues: (copy) p_u_40, (ref) v_u_3
			local v57 = p_u_40.controllers
			local v58
			if v57 == nil then
				v58 = nil
			else
				v58 = v57.ZombieRender
			end
			if v58 then
				local v59 = v58.previewRig
				if type(v59) == "function" then
					local v60 = v58.previewRig
					local v61, v62 = pcall(v60, "walker")
					if v61 and type(v62) == "table" then
						local v63 = v62.model
						if typeof(v63) == "Instance" and v62.model:IsA("Model") then
							v_u_3.cleanClone(v62.model)
							return v62
						end
					end
					return nil
				end
			end
			return nil
		end,
		["localGunSkin"] = function() -- name: localGunSkin
			-- upvalues: (ref) v_u_1, (copy) v_u_41
			local v64 = v_u_1.LocalPlayer
			if v64 == nil or v_u_41.SkinApply == nil then
				return nil
			else
				local v65 = v_u_41.SkinApply.equippedFor
				local v66, v67 = pcall(v65, v64, "pistol_g17")
				if v66 and type(v67) == "string" then
					return v67
				else
					return nil
				end
			end
		end
	}
end
function v_u_3.frameFor(p68) -- name: frameFor
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v69 = (type(p68) ~= "number" or (p68 ~= p68 or p68 <= 0.05)) and 1 or p68
	local v70 = v_u_3.VIEW_H
	local v71 = v_u_3.NEED_W / v69
	local v72 = math.max(v70, v71)
	local v73 = v72 / 2
	local v74 = v_u_4(v_u_3.FOV / 2)
	return v73 / math.tan(v74), v_u_3.CENTER_Y, v72
end
local v_u_75 = nil
function v_u_3.new(p_u_76) -- name: new
	-- upvalues: (copy) v_u_3, (ref) v_u_75, (copy) v_u_1, (copy) v_u_4
	local v_u_77 = p_u_76.Anim
	local v_u_78 = p_u_76.Poses
	local v_u_79 = p_u_76.AnimRig
	local v80 = {}
	local v_u_81 = true
	local v_u_82 = nil
	local v_u_83 = nil
	local v_u_84 = nil
	local v_u_85 = "thumb"
	local v_u_86 = 3
	local v_u_87 = 1
	local v_u_88 = "ka_stand"
	local v_u_89 = 0
	local v_u_90 = -1
	local v_u_91 = false
	local v_u_92 = false
	local v_u_93 = 0
	local v_u_94 = false
	local v_u_95 = 0
	local v_u_96 = 0
	local v_u_97 = 0
	local v_u_98 = nil
	local v_u_99 = nil
	local v_u_100 = false
	local v_u_101 = nil
	local v_u_102 = nil
	local v_u_103 = nil
	local v_u_104 = p_u_76.origin or CFrame.identity
	local v_u_105 = nil
	local v_u_106 = false
	local v_u_107 = nil
	local v_u_108 = false
	local v_u_109 = {}
	local v_u_110 = nil
	local v_u_111 = v_u_104
	local v112 = v_u_3.CENTER_Y
	local v_u_113 = Vector3.new(0, v112, -13)
	local v114 = v_u_3.CENTER_Y
	local v_u_115 = Vector3.new(0, v114, 0)
	local v_u_116 = nil
	local v_u_117 = nil
	local v_u_118
	if p_u_76.container == nil then
		v_u_116 = Instance.new("ViewportFrame")
		v_u_116.Name = "KillCardFigure"
		v_u_116.BackgroundTransparency = 1
		v_u_116.BorderSizePixel = 0
		v_u_116.Size = UDim2.fromScale(1, 1)
		v_u_116.ZIndex = p_u_76.zindex or 3
		v_u_116.Ambient = v_u_3.AMBIENT
		v_u_116.LightColor = v_u_3.KEY
		v_u_116.LightDirection = v_u_3.KEY_DIR
		v_u_116.Visible = false
		v_u_117 = Instance.new("Camera")
		v_u_117.FieldOfView = v_u_3.FOV
		v_u_117.Parent = v_u_116
		v_u_116.CurrentCamera = v_u_117
		v_u_118 = Instance.new("WorldModel")
		v_u_118.Name = "World"
		v_u_118.Parent = v_u_116
		v_u_116.Parent = p_u_76.parent
	else
		v_u_118 = p_u_76.container
	end
	function v80.cameraFor(p119, p120) -- name: cameraFor
		-- upvalues: (copy) v_u_77, (ref) v_u_3, (ref) v_u_113, (ref) v_u_115
		local v121 = not v_u_77.has(p119) and "ka_stand" or p119
		return v_u_3.cameraCF(v_u_113, v_u_115, v_u_77.camera(v121, p120))
	end
	function v80.reframe() -- name: reframe
		-- upvalues: (ref) v_u_81, (ref) v_u_116, (ref) v_u_117, (ref) v_u_3, (ref) v_u_113, (ref) v_u_115, (ref) v_u_88, (ref) v_u_91, (ref) v_u_97, (copy) v_u_77
		if v_u_81 and (v_u_116 ~= nil and v_u_117 ~= nil) then
			local v122 = v_u_116.AbsoluteSize
			local v123 = v122.Y <= 1 and 1 or v122.X / v122.Y
			local v124, v125 = v_u_3.frameFor(v123)
			local v126 = -v124
			local v127 = Vector3.new(0, v125, v126)
			local v128 = Vector3.new(0, v125, 0)
			v_u_113 = v127
			v_u_115 = v128
			local v129 = v_u_88
			local v130 = v_u_91 and 1000000000 or v_u_97
			if v_u_117 ~= nil then
				v_u_117.CFrame = v_u_3.cameraCF(v_u_113, v_u_115, v_u_77.camera(v129, v130))
			end
		else
			return
		end
	end
	if v_u_116 ~= nil then
		v80.reframe()
		v_u_98 = v_u_116:GetPropertyChangedSignal("AbsoluteSize"):Connect(v80.reframe)
	end
	function v80.setGunSkin(p131) -- name: setGunSkin
		-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) v_u_103
		if type(p131) ~= "string" or (#p131 <= 0 or #p131 > 60) then
			p131 = nil
		end
		v_u_99 = p131
		v_u_100 = true
		v_u_103 = nil
	end
	function v80.load(p132) -- name: load
		-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_85, (ref) v_u_101, (ref) v_u_3, (copy) p_u_76, (copy) v_u_79, (ref) v_u_86, (ref) v_u_87, (ref) v_u_96, (ref) v_u_118, (ref) v_u_83, (ref) v_u_84
		if not v_u_81 or v_u_82 ~= nil then
			return v_u_85
		end
		v_u_101 = p132
		local v133, v134 = v_u_3.sourceFor(p_u_76.deps, p132)
		if v134 ~= nil and v133 == "avatar" then
			v_u_3.cleanClone(v134)
			if #v134:GetDescendants() > v_u_3.INSTANCE_MAX then
				v134:Destroy()
				v133, v134 = v_u_3.sourceFor({
					["players"] = nil,
					["avatars"] = nil,
					["ready"] = nil,
					["block"] = nil,
					["ready"] = p_u_76.deps.ready,
					["block"] = p_u_76.deps.block
				}, p132)
			end
		end
		if v134 == nil then
			v_u_85 = "thumb"
			return v_u_85
		end
		if v133 ~= "avatar" then
			v_u_3.cleanClone(v134)
		end
		local v135 = v134:FindFirstChild("HumanoidRootPart")
		if not (v135 and v135:IsA("BasePart")) then
			v134:Destroy()
			v_u_85 = "thumb"
			return v_u_85
		end
		for _, v_u_136 in v134:GetDescendants() do
			if v_u_136:IsA("Humanoid") then
				v_u_136.AutomaticScalingEnabled = false
				v_u_136.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				v_u_136.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
				v_u_136.BreakJointsOnDeath = false
				v_u_136.RequiresNeck = false
				pcall(function()
					-- upvalues: (copy) v_u_136
					v_u_136.EvaluateStateMachine = false
				end)
			else
				if not v_u_136:IsA("BasePart") then
					continue
				end
				v_u_136.CanCollide = false
				v_u_136.CanQuery = false
				v_u_136.CanTouch = false
				v_u_136.Anchored = v_u_136 == v135
				v_u_136.LocalTransparencyModifier = 0
			end
		end
		v135.Transparency = 1
		local v137 = v_u_79.new(v134)
		if not v137 then
			v134:Destroy()
			v_u_85 = "thumb"
			return v_u_85
		end
		local v138 = v134:FindFirstChildOfClass("Humanoid")
		v_u_86 = (not v138 and 2 or v138.HipHeight) + v135.Size.Y / 2
		v_u_87 = ((v137.bone.LeftHip or 1.35) + (v137.bone.LeftKnee or 1.25)) / 2.6
		v_u_96 = #v134:GetDescendants()
		v134.Name = "KillCardFigure"
		v134.Parent = v_u_118
		v_u_82 = v134
		v_u_83 = v137
		v_u_84 = v135
		v_u_85 = v133
		return v_u_85
	end
	local function v_u_155(p139) -- name: ensureProps
		-- upvalues: (ref) v_u_103, (ref) v_u_102, (copy) v_u_77, (ref) v_u_75, (ref) v_u_99, (ref) v_u_100, (copy) p_u_76, (ref) v_u_1, (ref) v_u_101, (ref) v_u_118
		if v_u_103 == p139 then
			return
		else
			v_u_103 = p139
			if v_u_102 ~= nil then
				local v140 = v_u_102.destroy
				pcall(v140)
				v_u_102 = nil
			end
			local v141 = v_u_77.props(p139, 0)
			if #v141 == 0 then
				return
			else
				if v_u_75 == nil then
					local v142, v143 = pcall(function()
						return require(script.Parent:WaitForChild("KillCardProps", 5))
					end)
					if not v142 or type(v143) ~= "table" then
						v143 = false
					end
					v_u_75 = v143
				end
				local v144 = v_u_75
				if v144 then
					local v145 = v_u_99
					if not v_u_100 and p_u_76.deps then
						local v146 = p_u_76.deps.localGunSkin
						if type(v146) == "function" then
							local v147 = v_u_1.LocalPlayer
							if v147 ~= nil and v_u_101 == v147.UserId then
								local v148 = p_u_76.deps.localGunSkin
								local v149
								v149, v145 = pcall(v148)
								if not v149 or type(v145) ~= "string" then
									v145 = nil
								end
							end
						end
					end
					local v150 = v144.new
					local v151 = {
						["parent"] = v_u_118,
						["deps"] = p_u_76.deps,
						["skin"] = v145,
						["Grips"] = p_u_76.Grips
					}
					local v152, v153 = pcall(v150, v151)
					if v152 and v153 then
						v_u_102 = v153
						local v154 = v153.build
						pcall(v154, v141)
					end
				end
			end
		end
	end
	local function v_u_163(p156) -- name: handFrames
		-- upvalues: (copy) v_u_104, (ref) v_u_83, (ref) v_u_82, (ref) v_u_3
		local v157 = {
			["World"] = v_u_104
		}
		if v_u_83 == nil or v_u_82 == nil then
			return v157
		end
		for _, v158 in { "Right", "Left" } do
			local v159 = v_u_83.part[v158 .. "Hand"]
			if not v159 then
				continue
			end
			local v160 = v_u_82:FindFirstChild(v158 .. "Hand")
			if v160 then
				v160 = v160:FindFirstChild(v158 .. "GripAttachment")
			end
			local v161
			if v160 and v160:IsA("Attachment") then
				v161 = v160.CFrame.Position
			else
				v161 = v_u_3.GRIP_DEFAULT
			end
			local v162 = p156 * v159 * CFrame.new(v161) * v_u_3.GRIP_ROT
			v157[v158 .. "Hand"] = v162
			v157[v158 .. "HandPos"] = CFrame.new(v162.Position) * v_u_104.Rotation
		end
		return v157
	end
	local function v_u_188(p164, p165, p166, p167, p168) -- name: sendOverlay
		-- upvalues: (ref) v_u_110, (copy) p_u_76, (ref) v_u_116, (ref) v_u_105, (ref) v_u_106, (ref) v_u_107, (ref) v_u_108
		v_u_110 = {
			["kind"] = p164,
			["strength"] = p165,
			["seed"] = p166,
			["age"] = p167
		}
		local v169 = p_u_76.onOverlay
		if type(v169) == "function" then
			local v170 = p_u_76.onOverlay
			pcall(v170, p164, p165, p166, p167, p168)
		elseif v_u_116 == nil or p164 ~= "shatter" then
			if v_u_116 ~= nil and (p164 == "snow" or p164 == "blizzard") then
				if v_u_107 == nil and (p165 > 0 and not v_u_108) then
					v_u_108 = true
					local v171, v172 = pcall(function()
						return require(script.Parent:WaitForChild("KillCardSnow", 5))
					end)
					if v171 and type(v172) == "table" then
						local v173 = v172.new
						local v174 = p_u_76.parent
						local v175 = (p_u_76.zindex or 3) + 2
						local v176 = {
							["reduced"] = p_u_76.reduced
						}
						local v177, v178 = pcall(v173, v174, v175, v176)
						if v177 then
							v_u_107 = v178
							v_u_108 = false
						end
					end
				end
				if v_u_107 ~= nil then
					local v179 = v_u_107.set
					pcall(v179, p164, p165, p166, p167, p168)
				end
			end
		else
			if v_u_105 == nil and (p165 > 0 and not v_u_106) then
				v_u_106 = true
				local v180, v181 = pcall(function()
					return require(script.Parent:WaitForChild("KillCardShatter", 5))
				end)
				if v180 and type(v181) == "table" then
					local v182 = v181.new
					local v183 = p_u_76.parent
					local v184 = (p_u_76.zindex or 3) + 2
					local v185, v186 = pcall(v182, v183, v184)
					if v185 then
						v_u_105 = v186
						v_u_106 = false
					end
				end
			end
			if v_u_105 ~= nil then
				local v187 = v_u_105.set
				pcall(v187, p165, p166, p167)
				return
			end
		end
	end
	local function v_u_197(p189, p190, p191) -- name: reportOverlays
		-- upvalues: (copy) v_u_77, (copy) v_u_109, (copy) v_u_188
		local v192 = not v_u_77.hasOverlay(p189) and {} or v_u_77.overlays(p189, p190)
		local v193 = {}
		for _, v194 in v192 do
			v193[v194.kind] = true
		end
		for v195 in v_u_109 do
			if v193[v195] then
				continue
			end
			v_u_109[v195] = nil
			v_u_188(v195, 0, 0, 0)
		end
		for _, v196 in v192 do
			v_u_109[v196.kind] = true
			v_u_188(v196.kind, v196.strength, v196.seed, v196.age, {
				["yaw"] = p191
			})
		end
	end
	local function v_u_217(p198, p199) -- name: write
		-- upvalues: (ref) v_u_82, (ref) v_u_83, (ref) v_u_84, (copy) v_u_77, (ref) v_u_95, (copy) v_u_78, (ref) v_u_87, (copy) v_u_104, (ref) v_u_86, (ref) v_u_4, (ref) v_u_111, (copy) v_u_155, (ref) v_u_102, (copy) v_u_163, (ref) v_u_117, (ref) v_u_3, (ref) v_u_113, (ref) v_u_115, (copy) v_u_197
		if v_u_82 ~= nil and (v_u_83 ~= nil and v_u_84 ~= nil) then
			local v200 = v_u_77.duration(p198)
			local v201 = v200 <= p199
			local v202
			if v201 then
				v202 = v_u_77.endPose(p198)
			else
				v202 = v_u_77.pose(p198, p199)
			end
			v_u_95 = v_u_95 + 1
			local v203 = v_u_78.actorPose
			local v204 = v_u_83
			local v205 = v_u_77.spec(v202)
			local v206 = v_u_87
			if not pcall(v203, v204, v205, v206) then
				local v207 = v_u_78.actorPose
				local v208 = v_u_83
				local v209 = v_u_87
				pcall(v207, v208, "idle", v209)
			end
			local v210 = v_u_104 * CFrame.new((v202.root.x or 0) * v_u_87, v_u_86 + v202.root.y * v_u_87, (v202.root.z or 0) * v_u_87) * CFrame.Angles(v_u_4(v202.root.pitch), v_u_4(v202.root.yaw), 0)
			v_u_82:PivotTo(v210 * v_u_84.CFrame:Inverse() * v_u_82:GetPivot())
			v_u_111 = v210
			v_u_155(p198)
			local v211
			if v201 then
				v211 = v200
			else
				v211 = p199
			end
			if v_u_102 ~= nil and (v_u_83 ~= nil and v_u_82 ~= nil) then
				local v212 = v_u_102.update
				local v213 = v_u_77.props(p198, v211)
				local v214 = v_u_163(v210)
				pcall(v212, v213, v214)
			end
			local v215
			if v201 then
				v215 = v200
			else
				v215 = p199
			end
			if v_u_117 ~= nil then
				v_u_117.CFrame = v_u_3.cameraCF(v_u_113, v_u_115, v_u_77.camera(p198, v215))
			end
			local v216 = v_u_197
			if v201 then
				p199 = v200
			end
			v216(p198, p199, v202.root.yaw)
		end
	end
	function v80.play(p218, p219) -- name: play
		-- upvalues: (ref) v_u_81, (ref) v_u_88, (copy) v_u_77, (ref) v_u_89, (ref) v_u_97, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_117, (ref) v_u_113, (ref) v_u_115, (ref) v_u_82, (copy) v_u_217
		if v_u_81 then
			v_u_88 = not v_u_77.has(p218) and "ka_stand" or p218
			v_u_89 = p219
			v_u_97 = 0
			v_u_90 = -1
			v_u_91 = false
			v_u_92 = true
			if v_u_117 ~= nil then
				v_u_117.CFrame = CFrame.lookAt(v_u_113, v_u_115)
			end
			if v_u_82 ~= nil then
				v_u_217(v_u_88, 0)
			end
		end
	end
	function v80.showEnd(p220) -- name: showEnd
		-- upvalues: (ref) v_u_81, (ref) v_u_88, (copy) v_u_77, (ref) v_u_91, (ref) v_u_92, (ref) v_u_82, (copy) v_u_217
		if v_u_81 then
			v_u_88 = not v_u_77.has(p220) and "ka_stand" or p220
			v_u_91 = true
			v_u_92 = true
			if v_u_82 ~= nil then
				v_u_217(v_u_88, (1 / 0))
			end
		end
	end
	function v80.poseAt(p221, p222) -- name: poseAt
		-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_88, (copy) v_u_77, (copy) v_u_217
		if v_u_81 and v_u_82 ~= nil then
			v_u_88 = not v_u_77.has(p221) and "ka_stand" or p221
			v_u_217(v_u_88, p222)
		end
	end
	function v80.step(p223) -- name: step
		-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_92, (ref) v_u_93, (ref) v_u_94, (ref) v_u_116, (ref) v_u_91, (ref) v_u_89, (copy) v_u_77, (ref) v_u_88, (copy) v_u_217, (ref) v_u_97, (ref) v_u_90, (ref) v_u_3
		if v_u_81 and (v_u_82 ~= nil and v_u_92) then
			v_u_93 = v_u_93 + 1
			if not v_u_94 and v_u_93 >= 2 then
				v_u_94 = true
				if v_u_116 ~= nil then
					v_u_116.Visible = true
				end
			end
			if v_u_91 then
				return
			else
				local v224 = p223 - v_u_89
				local v225 = v_u_77.duration(v_u_88)
				if v225 <= v224 then
					v_u_91 = true
					v_u_217(v_u_88, v225)
					v_u_97 = v225
				elseif v224 - v_u_90 >= v_u_3.STEP or v_u_90 < 0 then
					v_u_90 = v224
					v_u_97 = v224
					v_u_217(v_u_88, v224)
				end
			end
		else
			return
		end
	end
	function v80.state() -- name: state
		-- upvalues: (ref) v_u_85, (ref) v_u_82, (ref) v_u_94, (ref) v_u_88, (ref) v_u_97, (ref) v_u_91, (ref) v_u_95, (ref) v_u_96, (ref) v_u_92, (ref) v_u_102, (ref) v_u_110, (copy) v_u_109, (ref) v_u_105, (ref) v_u_107
		return {
			["kind"] = v_u_85,
			["ready"] = v_u_82 ~= nil,
			["shown"] = v_u_94,
			["animId"] = v_u_88,
			["t"] = v_u_97,
			["held"] = v_u_91,
			["writes"] = v_u_95,
			["instances"] = v_u_96,
			["playing"] = v_u_92,
			["props"] = v_u_102 == nil and 0 or v_u_102.count(),
			["overlay"] = v_u_110,
			["overlayOn"] = next(v_u_109) ~= nil,
			["shatter"] = v_u_105 ~= nil,
			["snow"] = v_u_107 ~= nil
		}
	end
	function v80.viewport() -- name: viewport
		-- upvalues: (ref) v_u_116
		return v_u_116
	end
	function v80.model() -- name: model
		-- upvalues: (ref) v_u_82
		return v_u_82
	end
	function v80.propsManager() -- name: propsManager
		-- upvalues: (ref) v_u_102
		return v_u_102
	end
	function v80.gripFrame(p226) -- name: gripFrame
		-- upvalues: (ref) v_u_82, (ref) v_u_83, (copy) v_u_163, (ref) v_u_111
		if v_u_82 == nil or v_u_83 == nil then
			return nil
		else
			return v_u_163(v_u_111)[p226 .. "Hand"]
		end
	end
	function v80.snapshot() -- name: snapshot
		-- upvalues: (ref) v_u_82, (ref) v_u_83, (ref) v_u_84, (ref) v_u_111, (ref) v_u_87
		return v_u_82 ~= nil and (v_u_83 ~= nil and v_u_84 ~= nil) and {
			["root"] = v_u_111,
			["parts"] = v_u_83.part,
			["scale"] = v_u_87,
			["arig"] = v_u_83
		} or nil
	end
	function v80.destroy() -- name: destroy
		-- upvalues: (ref) v_u_81, (ref) v_u_98, (ref) v_u_102, (ref) v_u_105, (ref) v_u_107, (ref) v_u_116, (ref) v_u_82, (ref) v_u_83, (ref) v_u_84
		v_u_81 = false
		if v_u_98 then
			v_u_98:Disconnect()
			v_u_98 = nil
		end
		if v_u_102 ~= nil then
			local v227 = v_u_102.destroy
			pcall(v227)
			v_u_102 = nil
		end
		if v_u_105 ~= nil then
			local v228 = v_u_105.destroy
			pcall(v228)
			v_u_105 = nil
		end
		if v_u_107 ~= nil then
			local v229 = v_u_107.destroy
			pcall(v229)
			v_u_107 = nil
		end
		local function v230()
			-- upvalues: (ref) v_u_116
			if v_u_116 ~= nil then
				v_u_116:Destroy()
			end
		end
		pcall(v230)
		local function v231()
			-- upvalues: (ref) v_u_82, (ref) v_u_116
			if v_u_82 ~= nil and v_u_116 == nil then
				v_u_82:Destroy()
			end
		end
		pcall(v231)
		v_u_82 = nil
		v_u_83 = nil
		v_u_84 = nil
	end
	return v80
end
return v_u_3