-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketBook

local v_u_18 = {
	["SIDE"] = 6,
	["PHONE_SIDE"] = 5,
	["MORE_PAGES"] = 3,
	["MORE_GAP"] = 4,
	["EVERY"] = 30,
	["HEADERS"] = {
		["sale"] = "SALE QUANTITY",
		["price"] = "PRICE",
		["buy"] = "PURCHASE QUANTITY"
	},
	["TEXT"] = {
		["noAsks"] = "Nobody is selling this right now.",
		["noBids"] = "Nobody wants this right now.",
		["empty"] = "The book is empty. Be the first to place an order.",
		["crossed"] = "A listing is at or below the best buy order. Buy or sell to settle it.",
		["bidsBusy"] = "Buy orders could not be read right now. The listings are shown.",
		["loading"] = "Reading the order book",
		["cutAsks"] = "More listings are under LISTINGS.",
		["none"] = "You have none of these.",
		["own"] = "That is your own listing.",
		["yours"] = "YOURS",
		["place"] = "Place order",
		["more"] = "More levels",
		["moreBusy"] = "Wait a moment",
		["closed"] = "Buy orders are closed right now.",
		["feeLine"] = "The seller pays a {fee} percent fee. A buyer pays exactly the price.",
		["bandLine"] = "You can offer between {lo} and {hi} each."
	},
	["countText"] = function(p1, p2, p3) -- name: countText
		local v4 = p1 == "ask" and "listing" or "order"
		if p3 == true then
			return ("%d+ %ss"):format(p2, v4)
		elseif p2 == 1 then
			return ("1 %s"):format(v4)
		else
			return ("%d %ss"):format(p2, v4)
		end
	end,
	["mergeLevels"] = function(p5, p_u_6) -- name: mergeLevels
		local v7 = {}
		if type(p5) ~= "table" then
			return v7
		end
		local v8 = {}
		for _, v9 in p5 do
			if type(v9) ~= "table" then
				continue
			end
			local v10 = v9.u
			if type(v10) ~= "number" or (v10 ~= v10 or (v10 <= -1000000000000000 or v10 >= 1000000000000000)) then
				v10 = nil
			end
			local v11 = v9.q
			if type(v11) ~= "number" or (v11 ~= v11 or (v11 <= -1000000000000000 or v11 >= 1000000000000000)) then
				v11 = nil
			end
			local v12 = v9.c
			if type(v12) ~= "number" or (v12 ~= v12 or (v12 <= -1000000000000000 or v12 >= 1000000000000000)) then
				v12 = nil
			end
			if v10 == nil or (v11 == nil or (v12 == nil or (v10 <= 0 or (v11 <= 0 or v12 <= 0)))) then
				continue
			end
			local v13 = string.format("%.4f", v10)
			local v14 = v8[v13]
			if v14 then
				v14.q = v14.q + math.floor(v11)
				v14.c = v14.c + math.floor(v12)
				v14.own = v14.own or v9.own == true
				v14.plus = v14.plus or v9.plus == true
			else
				local v15 = {
					["u"] = v10,
					["q"] = math.floor(v11),
					["c"] = math.floor(v12),
					["own"] = v9.own == true,
					["plus"] = v9.plus == true
				}
				v8[v13] = v15
				table.insert(v7, v15)
			end
		end
		table.sort(v7, function(p16, p17)
			-- upvalues: (copy) p_u_6
			if p_u_6 == "ask" then
				return p16.u < p17.u
			else
				return p16.u > p17.u
			end
		end)
		return v7
	end
}
local function v_u_22(p19, p20, p21) -- name: rowOf
	-- upvalues: (copy) v_u_18
	return {
		["side"] = p20,
		["u"] = p19.u,
		["price"] = p21.unitMoney(p19.u),
		["q"] = p19.q,
		["qty"] = p21.commas(p19.q),
		["c"] = p19.c,
		["count"] = v_u_18.countText(p20, p19.c, p19.plus),
		["own"] = p19.own == true,
		["plus"] = p19.plus == true
	}
end
function v_u_18.model(p23, p24, p25) -- name: model
	-- upvalues: (copy) v_u_18, (copy) v_u_22
	local v26 = p25 or {}
	local v27 = v26.side or v_u_18.SIDE
	local v28 = {
		["ok"] = false,
		["state"] = "error",
		["asks"] = nil,
		["bids"] = nil,
		["crossed"] = false,
		["emptyAsks"] = true,
		["emptyBids"] = true,
		["bidsBusy"] = false,
		["more"] = false,
		["cut"] = false,
		["fee"] = 5,
		["spreadText"] = "",
		["asks"] = {},
		["bids"] = {}
	}
	if type(p23) == "table" then
		if p23.ok == true then
			v28.ok = true
			v28.state = "ok"
			local v29 = v_u_18.mergeLevels(p23.asks, "ask")
			local v30 = {}
			local v31 = p23.bids
			if type(v31) == "table" then
				for _, v32 in p23.bids do
					table.insert(v30, v32)
				end
			end
			local v33 = v26.extraBids
			if type(v33) == "table" then
				for _, v34 in v26.extraBids do
					table.insert(v30, v34)
				end
			end
			local v35 = v_u_18.mergeLevels(v30, "bid")
			local v36 = v26.bidLimit
			if not v36 then
				local v37 = v26.extraBids
				v36 = v27 + (type(v37) == "table" and #v26.extraBids or 0)
			end
			v28.bidsBusy = p23.bidsBusy == true
			v28.cut = p23.cut == true
			v28.more = p23.more == true
			local v38 = p23.fee
			if type(v38) ~= "number" or (v38 ~= v38 or (v38 <= -1000000000000000 or v38 >= 1000000000000000)) then
				v38 = nil
			end
			v28.fee = v38 or 5
			local v39 = p23.age
			if type(v39) ~= "number" or (v39 ~= v39 or (v39 <= -1000000000000000 or v39 >= 1000000000000000)) then
				v39 = nil
			end
			v28.age = v39
			local v40 = p23.band
			if type(v40) == "table" then
				local v41 = p23.band.lo
				if type(v41) ~= "number" or (v41 ~= v41 or (v41 <= -1000000000000000 or v41 >= 1000000000000000)) then
					v41 = nil
				end
				if v41 ~= nil then
					local v42 = p23.band.hi
					if type(v42) ~= "number" or (v42 ~= v42 or (v42 <= -1000000000000000 or v42 >= 1000000000000000)) then
						v42 = nil
					end
					if v42 ~= nil then
						v28.band = {
							["lo"] = p23.band.lo,
							["hi"] = p23.band.hi
						}
					end
				end
			end
			local v43 = #v29
			local v44 = {}
			for v45 = 1, math.min(v27, v43) do
				v44[v45] = v29[v45]
			end
			if v27 < #v29 then
				v28.cut = true
			end
			for v46 = #v44, 1, -1 do
				local v47 = v28.asks
				local v48 = v_u_22(v44[v46], "ask", p24)
				table.insert(v47, v48)
			end
			local v49 = #v35
			for v50 = 1, math.min(v36, v49) do
				local v51 = v28.bids
				local v52 = v_u_22(v35[v50], "bid", p24)
				table.insert(v51, v52)
			end
			if v36 < #v35 then
				v28.more = true
			end
			v28.emptyAsks = #v29 == 0
			v28.emptyBids = #v35 == 0
			local v53 = v29[1]
			local v54 = v35[1]
			local v55
			if v53 then
				v55 = v53.u
			else
				v55 = nil
			end
			v28.bestAsk = v55
			local v56
			if v54 then
				v56 = v54.u
			else
				v56 = nil
			end
			v28.bestBid = v56
			if v53 and v54 then
				if v53.u > v54.u then
					local v57 = (v53.u - v54.u) * 100 + 0.5
					v28.spread = math.floor(v57) / 100
					v28.spreadText = "Spread " .. p24.unitMoney(v28.spread)
				else
					v28.crossed = true
					v28.spreadText = v_u_18.TEXT.crossed
				end
			elseif v53 then
				v28.spreadText = v28.bidsBusy and "" or v_u_18.TEXT.noBids
			elseif v54 then
				v28.spreadText = v_u_18.TEXT.noAsks
			else
				local v58
				if v28.bidsBusy then
					v58 = v_u_18.TEXT.noAsks
				else
					v58 = v_u_18.TEXT.empty
				end
				v28.spreadText = v58
			end
			if v28.bidsBusy then
				v28.notice = v_u_18.TEXT.bidsBusy
				return v28
			else
				if v28.age ~= nil and v28.age >= 60 then
					v28.notice = p24.fill(p24.TEXT.bestAge, {
						["age"] = p24.duration(v28.age)
					})
				end
				return v28
			end
		else
			local v59 = p23.code
			v28.code = v59
			local v60 = p23.text
			local v61
			if type(v60) == "string" and p23.text ~= "" then
				v61 = p23.text
			elseif v59 == nil then
				v61 = p24.CODES.STORE
			else
				v61 = p24.CODES[v59] or p24.CODES.STORE
			end
			v28.text = v61
			if v59 == "BUSY" or v59 == "BOOK_BUSY" then
				v28.state = "busy"
				local v62 = p23.retryIn
				if type(v62) ~= "number" or (v62 ~= v62 or (v62 <= -1000000000000000 or v62 >= 1000000000000000)) then
					v62 = nil
				end
				v28.retryIn = v62
				return v28
			elseif v59 == "STORE" or p23.ds == "down" then
				v28.state = "down"
				return v28
			else
				if v59 == "DRAIN" or (v59 == "OFF_BOOK" or (v59 == "DISABLED" or (v59 == "FREEZE" or (v59 == "SCOPE" or v59 == "REVIEW")))) then
					v28.state = "closed"
				end
				return v28
			end
		end
	else
		v28.text = p24.CODES.STORE
		return v28
	end
end
function v_u_18.tapAsk(p63, p64) -- name: tapAsk
	if type(p63) == "table" and type(p64) == "table" then
		local v65 = p64.u
		if type(v65) == "number" then
			local v66 = false
			for _, v67 in p63 do
				local v68 = v67.u
				if not v68 then
					local v69 = v67.p
					if type(v69) == "number" then
						local v70 = v67.n
						if type(v70) == "number" and v67.n > 0 then
							v68 = v67.p / v67.n
						else
							v68 = nil
						end
					else
						v68 = nil
					end
				end
				if type(v68) ~= "number" then
					continue
				end
				local v71 = v68 - p64.u
				if math.abs(v71) >= 0.005 then
					continue
				end
				if v67.own ~= true then
					return v67, nil
				end
				v66 = true
			end
			local v72 = nil
			if v66 then
				return v72, "OWN"
			else
				return v72, nil
			end
		end
	end
	return nil, nil
end
function v_u_18.sellHint(p73) -- name: sellHint
	-- upvalues: (copy) v_u_18
	if p73 then
		return nil
	else
		return v_u_18.TEXT.none
	end
end
function v_u_18.new(p74, p75, p_u_76) -- name: new
	-- upvalues: (copy) v_u_18
	local v_u_77 = p74.ui
	local v_u_78 = p74.theme
	local v_u_79 = p74.C
	local v_u_80 = p74.Data
	local v_u_81 = p74.data
	local v_u_82 = p74.h
	local v_u_83 = p74.compact
	local v_u_84 = {}
	local v_u_85 = true
	local v_u_86 = false
	local v_u_87 = false
	local v_u_88 = nil
	local v_u_89 = nil
	local v_u_90 = {}
	local v_u_91 = 0
	local v_u_92 = false
	local v_u_93 = "loading"
	local v_u_94 = nil
	local v_u_95 = 0
	local v_u_96 = 0
	local v_u_97 = (-1 / 0)
	local v_u_98 = (-1 / 0)
	local v_u_99 = {}
	local v_u_100 = {}
	local v_u_101
	if v_u_83 then
		v_u_101 = v_u_18.PHONE_SIDE
	else
		v_u_101 = v_u_18.SIDE
	end
	local v_u_102 = v_u_78.touch(v_u_83 and 30 or 34)
	local v_u_103 = v_u_77.new("Frame", {
		["Name"] = "BookPage",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, p75)
	v_u_84.frame = v_u_103
	local v_u_104 = v_u_77.list({
		["parent"] = nil,
		["name"] = "Book",
		["size"] = nil,
		["gap"] = 6,
		["padding"] = nil,
		["parent"] = v_u_103,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			0,
			8,
			0,
			10
		}
	})
	local function v_u_106() -- name: clear
		-- upvalues: (copy) v_u_104, (copy) v_u_99
		for _, v105 in v_u_104:GetChildren() do
			if v105:IsA("UIListLayout") or v105:IsA("UIPadding") then
				continue
			end
			v105:Destroy()
		end
		table.clear(v_u_99)
	end
	local function v_u_111(p107, p108) -- name: message
		-- upvalues: (copy) v_u_77, (copy) v_u_104, (copy) v_u_83, (copy) v_u_79, (copy) v_u_82, (ref) v_u_96, (copy) v_u_84
		local v109 = v_u_77.new("Frame", {
			["Name"] = "Message",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_104)
		v_u_77.layout(v109, "v", 10, "center")
		local v110 = {
			8,
			8,
			v_u_83 and 6 or 20,
			10
		}
		v_u_77.pad(v109, v110)
		v_u_77.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["align"] = "center",
			["order"] = 1,
			["parent"] = v109,
			["text"] = p107,
			["color"] = v_u_79.text2
		})
		if p108 then
			v_u_82.button(v109, "Retry", "primary", function()
				-- upvalues: (ref) v_u_96, (ref) v_u_84
				v_u_96 = 0
				v_u_84.reload(true)
			end, {
				["order"] = 2,
				["name"] = "Retry"
			})
		end
	end
	local function v_u_114() -- name: skeleton
		-- upvalues: (copy) v_u_77, (copy) v_u_79, (copy) v_u_102, (copy) v_u_104
		for v112 = 1, 4 do
			local v113 = v_u_77.new("Frame", {
				["Name"] = "Skeleton",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.5,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_79.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_102),
				["LayoutOrder"] = v112
			}, v_u_104)
			v_u_77.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.6,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_79.lineStrong,
				["Position"] = UDim2.fromOffset(12, 10),
				["Size"] = UDim2.fromOffset(110, 12)
			}, v113)
			v_u_77.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.6,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_79.lineStrong,
				["Position"] = UDim2.new(0.5, -40, 0, 10),
				["Size"] = UDim2.fromOffset(80, 12)
			}, v113)
		end
	end
	local function v_u_116(p115) -- name: onRow
		-- upvalues: (copy) v_u_77, (copy) v_u_78, (copy) p_u_76
		v_u_77.sound(v_u_78.sounds.click)
		if p115.side == "ask" then
			if p_u_76.onAsk then
				p_u_76.onAsk(p115)
				return
			end
		elseif p_u_76.onBid then
			p_u_76.onBid(p115)
		end
	end
	local function v_u_137(p117, p_u_118, p119, p120) -- name: makeRow
		-- upvalues: (copy) v_u_79, (copy) v_u_77, (copy) v_u_102, (copy) v_u_83, (copy) v_u_82, (ref) v_u_18, (copy) v_u_78, (copy) p_u_76
		local v121
		if p_u_118.side == "ask" then
			v121 = v_u_79.info
		else
			v121 = v_u_79.danger
		end
		local v122 = v_u_77.new("TextButton", {
			["Name"] = "BookRow",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_79.raised,
			["Size"] = UDim2.new(1, 0, 0, v_u_102),
			["LayoutOrder"] = p119
		}, p117)
		v122.SelectionImageObject = v_u_77.selectionImage()
		local v123 = v_u_77.stroke
		local v124
		if p_u_118.own then
			v124 = v_u_79.info
		else
			v124 = v_u_79.line
		end
		v123(v122, v124)
		v122:SetAttribute("Side", p_u_118.side)
		v122:SetAttribute("Price", p_u_118.u)
		v122:SetAttribute("Qty", p_u_118.q)
		v122:SetAttribute("Own", p_u_118.own)
		local v125
		if v_u_102 >= 40 and not v_u_83 then
			v125 = p_u_118.count
		else
			v125 = nil
		end
		if p120 then
			local v126 = p_u_118.side == "ask"
			local v127 = v_u_77.label
			local v128 = {
				["parent"] = nil,
				["name"] = "Qty",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = 15,
				["color"] = nil,
				["align"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v122,
				["text"] = p_u_118.qty,
				["color"] = v121,
				["align"] = v126 and "left" or "right"
			}
			local v129
			if v126 then
				v129 = UDim2.fromOffset(8, 0)
			else
				v129 = UDim2.new(0.5, 0, 0, 0)
			end
			v128.position = v129
			v128.size = UDim2.new(0.5, -10, 1, 0)
			v127(v128)
			local v130 = v_u_77.label
			local v131 = {
				["parent"] = nil,
				["name"] = "Price",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = 15,
				["color"] = nil,
				["align"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v122,
				["text"] = p_u_118.price,
				["color"] = v_u_79.text,
				["align"] = v126 and "right" or "left"
			}
			local v132
			if v126 then
				v132 = UDim2.new(0.5, 0, 0, 0)
			else
				v132 = UDim2.fromOffset(8, 0)
			end
			v131.position = v132
			v131.size = UDim2.new(0.5, -10, 1, 0)
			v130(v131)
		else
			v_u_77.label({
				["parent"] = nil,
				["name"] = "Price",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = 18,
				["color"] = nil,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v122,
				["text"] = p_u_118.price,
				["color"] = v_u_79.text,
				["position"] = UDim2.new(0.32999999999999996, 0, 0, 0),
				["size"] = UDim2.new(0.34, 0, 1, 0)
			})
			if p_u_118.side == "ask" then
				v_u_77.label({
					["parent"] = nil,
					["name"] = "Qty",
					["text"] = nil,
					["style"] = "monoL",
					["textSize"] = 18,
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v122,
					["text"] = p_u_118.qty,
					["color"] = v121,
					["position"] = UDim2.fromOffset(12, 0),
					["size"] = UDim2.new(0.32999999999999996, -20, 1, v125 and -10 or 0)
				})
				if v125 then
					v_u_77.label({
						["parent"] = nil,
						["name"] = "Count",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v122,
						["text"] = v125,
						["color"] = v_u_79.muted,
						["position"] = UDim2.new(0, 12, 1, -16),
						["size"] = UDim2.new(0.32999999999999996, -20, 0, 14)
					})
				end
			else
				v_u_77.label({
					["parent"] = nil,
					["name"] = "Qty",
					["text"] = nil,
					["style"] = "monoL",
					["textSize"] = 18,
					["color"] = nil,
					["align"] = "left",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v122,
					["text"] = p_u_118.qty,
					["color"] = v121,
					["position"] = UDim2.new(0.67, 8, 0, 0),
					["size"] = UDim2.new(0.32999999999999996, -20, 1, v125 and -10 or 0)
				})
				if v125 then
					v_u_77.label({
						["parent"] = nil,
						["name"] = "Count",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["align"] = "left",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v122,
						["text"] = v125,
						["color"] = v_u_79.muted,
						["position"] = UDim2.new(0.67, 8, 1, -16),
						["size"] = UDim2.new(0.32999999999999996, -20, 0, 14)
					})
				end
			end
		end
		if p_u_118.own then
			local v133 = v_u_82.pill(v122, v_u_18.TEXT.yours, v_u_79.info, {
				["name"] = "Yours",
				["h"] = 16
			})
			v133.AnchorPoint = Vector2.new(0.5, 0.5)
			if p120 then
				local v134
				if p_u_118.side == "ask" then
					v134 = UDim2.new(0.5, 0, 0.5, 0)
				else
					v134 = UDim2.new(1, -30, 0.5, 0)
				end
				v133.Position = v134
			else
				local v135
				if p_u_118.side == "ask" then
					v135 = UDim2.new(0.73, 0, 0.5, 0)
				else
					v135 = UDim2.new(0.26999999999999996, 0, 0.5, 0)
				end
				v133.Position = v135
			end
		end
		v122.Activated:Connect(function()
			-- upvalues: (copy) p_u_118, (ref) v_u_77, (ref) v_u_78, (ref) p_u_76
			local v136 = p_u_118
			v_u_77.sound(v_u_78.sounds.click)
			if v136.side == "ask" then
				if p_u_76.onAsk then
					p_u_76.onAsk(v136)
					return
				end
			elseif p_u_76.onBid then
				p_u_76.onBid(v136)
			end
		end)
		return v122
	end
	local function v_u_141(p138, p139) -- name: sectionHeader
		-- upvalues: (copy) v_u_77, (ref) v_u_18, (copy) v_u_79
		local v140 = v_u_77.new("Frame", {
			["Name"] = "BookHeader",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 20),
			["LayoutOrder"] = p139
		}, p138)
		v_u_77.label({
			["parent"] = nil,
			["name"] = "Sale",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["align"] = "left",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v140,
			["text"] = v_u_18.HEADERS.sale,
			["color"] = v_u_79.info,
			["position"] = UDim2.fromOffset(12, 0),
			["size"] = UDim2.new(0.33, 0, 1, 0)
		})
		v_u_77.label({
			["parent"] = nil,
			["name"] = "PriceHead",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v140,
			["text"] = v_u_18.HEADERS.price,
			["color"] = v_u_79.text2,
			["position"] = UDim2.new(0.5, -50, 0, 0),
			["size"] = UDim2.fromOffset(100, 20)
		})
		v_u_77.label({
			["parent"] = nil,
			["name"] = "Buy",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v140,
			["text"] = v_u_18.HEADERS.buy,
			["color"] = v_u_79.danger,
			["position"] = UDim2.new(0.67, -12, 0, 0),
			["size"] = UDim2.new(0.33, 0, 1, 0)
		})
		return v140
	end
	local function v_u_151(p142, p143, p144) -- name: spreadRow
		-- upvalues: (copy) v_u_77, (copy) v_u_79, (copy) v_u_78, (copy) v_u_83, (ref) v_u_94
		local v145 = v_u_77.new("Frame", {
			["Name"] = "Spread",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_79.bgDeep,
			["Size"] = UDim2.new(1, 0, 0, v_u_78.touch(v_u_83 and 26 or 30)),
			["LayoutOrder"] = p144
		}, p142)
		v_u_77.stroke(v145, v_u_79.line)
		local v146 = v_u_77.label
		local v147 = {
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v145,
			["text"] = p143
		}
		local v148
		if v_u_94 and v_u_94.crossed then
			v148 = v_u_79.accent
		else
			v148 = v_u_79.text2
		end
		v147.color = v148
		v147.size = UDim2.fromScale(1, 1)
		v146(v147)
		local v149 = "Crossed"
		local v150
		if v_u_94 == nil then
			v150 = false
		else
			v150 = v_u_94.crossed == true
		end
		v145:SetAttribute(v149, v150)
		return v145
	end
	local function v_u_191() -- name: draw
		-- upvalues: (copy) v_u_106, (ref) v_u_93, (copy) v_u_114, (copy) v_u_111, (ref) v_u_94, (copy) v_u_80, (ref) v_u_96, (ref) v_u_18, (ref) v_u_89, (copy) v_u_77, (copy) v_u_104, (copy) v_u_83, (copy) v_u_79, (copy) v_u_99, (copy) v_u_137, (copy) v_u_151, (copy) v_u_141, (copy) v_u_78, (copy) v_u_101, (copy) p_u_76, (copy) v_u_82, (copy) v_u_84, (ref) v_u_91
		v_u_106()
		if v_u_93 == "loading" then
			v_u_114()
			return
		elseif v_u_93 == "busy" then
			v_u_111(v_u_94 and v_u_94.text or v_u_80.BOOK.BOOK_BUSY, v_u_96 >= v_u_80.RETRY_MAX)
			return
		elseif v_u_93 == "down" then
			v_u_111(v_u_94 and v_u_94.text or v_u_80.TEXT.storeDown, true)
			return
		elseif v_u_93 == "closed" then
			v_u_111(v_u_94 and v_u_94.text or v_u_18.TEXT.closed, false)
			return
		elseif v_u_93 == "ok" and v_u_94 ~= nil then
			local v152 = 1
			local v153 = v_u_80.rsBookLine
			local v154
			if type(v153) == "function" then
				local v155 = v_u_89
				if type(v155) == "table" then
					v154 = v_u_80.rsBookLine(v_u_89.rk)
				else
					v154 = nil
				end
			else
				v154 = nil
			end
			if v154 ~= nil then
				v_u_77.label({
					["parent"] = nil,
					["name"] = "RestockLine",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["order"] = 0,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_104,
					["text"] = v154,
					["color"] = Color3.fromHex("#3FD0C9")
				})
			end
			local v156 = v_u_77.new("Frame", {
				["Name"] = "Table",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = v152
			}, v_u_104)
			v_u_77.layout(v156, "v", 3)
			if v_u_83 then
				local v157 = v_u_77.new("Frame", {
					["Name"] = "BookHeader",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 18)
				}, v156)
				v_u_77.label({
					["parent"] = nil,
					["name"] = "Sale",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "left",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v157,
					["text"] = v_u_18.HEADERS.sale,
					["color"] = v_u_79.info,
					["position"] = UDim2.fromOffset(8, 0),
					["size"] = UDim2.new(0.5, -12, 1, 0)
				})
				v_u_77.label({
					["parent"] = nil,
					["name"] = "Buy",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "left",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v157,
					["text"] = v_u_18.HEADERS.buy,
					["color"] = v_u_79.danger,
					["position"] = UDim2.new(0.5, 8, 0, 0),
					["size"] = UDim2.new(0.5, -12, 1, 0)
				})
				local v158 = v_u_77.new("Frame", {
					["Name"] = "Columns",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v156)
				local v159 = v_u_77.new("Frame", {
					["Name"] = "Asks",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Size"] = UDim2.new(0.5, -3, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v158)
				v_u_77.layout(v159, "v", 3)
				local v160 = v_u_77.new("Frame", {
					["Name"] = "Bids",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Position"] = UDim2.new(0.5, 3, 0, 0),
					["Size"] = UDim2.new(0.5, -3, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v158)
				v_u_77.layout(v160, "v", 3)
				local v161 = {}
				for v162 = #v_u_94.asks, 1, -1 do
					local v163 = v_u_94.asks[v162]
					table.insert(v161, v163)
				end
				for v164, v165 in v161 do
					local v166 = v_u_99
					local v167 = {
						["row"] = v165,
						["btn"] = v_u_137(v159, v165, v164, true)
					}
					table.insert(v166, v167)
				end
				for v168, v169 in v_u_94.bids do
					local v170 = v_u_99
					local v171 = {
						["row"] = v169,
						["btn"] = v_u_137(v160, v169, v168, true)
					}
					table.insert(v170, v171)
				end
				if #v161 == 0 then
					v_u_77.label({
						["parent"] = nil,
						["name"] = "None",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = v159,
						["text"] = v_u_18.TEXT.noAsks,
						["color"] = v_u_79.muted
					})
				end
				if #v_u_94.bids == 0 then
					v_u_77.label({
						["parent"] = nil,
						["name"] = "None",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = v160,
						["text"] = v_u_94.bidsBusy and "" or v_u_18.TEXT.noBids,
						["color"] = v_u_79.muted
					})
				end
				v_u_151(v156, v_u_94.spreadText, 3)
			else
				v_u_141(v156, 1)
				local v172 = 1
				for _, v173 in v_u_94.asks do
					v172 = v172 + 1
					local v174 = v_u_99
					local v175 = {
						["row"] = v173,
						["btn"] = v_u_137(v156, v173, v172, false)
					}
					table.insert(v174, v175)
				end
				if #v_u_94.asks == 0 then
					v172 = v172 + 1
					local v176 = v_u_77.new("Frame", {
						["Name"] = "NoAsks",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_78.touch(26)),
						["LayoutOrder"] = v172
					}, v156)
					v_u_77.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v176,
						["text"] = v_u_18.TEXT.noAsks,
						["color"] = v_u_79.muted,
						["size"] = UDim2.fromScale(1, 1)
					})
				end
				local v177 = v172 + 1
				v_u_151(v156, v_u_94.spreadText, v177)
				for _, v178 in v_u_94.bids do
					v177 = v177 + 1
					local v179 = v_u_99
					local v180 = {
						["row"] = v178,
						["btn"] = v_u_137(v156, v178, v177, false)
					}
					table.insert(v179, v180)
				end
				if #v_u_94.bids == 0 and not v_u_94.bidsBusy then
					local v181 = v177 + 1
					local v182 = v_u_77.new("Frame", {
						["Name"] = "NoBids",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_78.touch(26)),
						["LayoutOrder"] = v181
					}, v156)
					v_u_77.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v182,
						["text"] = v_u_18.TEXT.noBids,
						["color"] = v_u_79.muted,
						["size"] = UDim2.fromScale(1, 1)
					})
				end
			end
			local v183 = 2
			if v_u_94.notice then
				v_u_77.label({
					["parent"] = nil,
					["name"] = "Notice",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_104,
					["text"] = v_u_94.notice,
					["color"] = v_u_79.accent,
					["order"] = v183
				})
				v183 = v183 + 1
			end
			if v_u_94.cut and v_u_101 <= #v_u_94.asks then
				v_u_77.label({
					["parent"] = nil,
					["name"] = "CutAsks",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_104,
					["text"] = v_u_18.TEXT.cutAsks,
					["color"] = v_u_79.muted,
					["order"] = v183
				})
				v183 = v183 + 1
			end
			local v184 = v_u_77.new("Frame", {
				["Name"] = "Buttons",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, v_u_78.touch(v_u_78.control)),
				["LayoutOrder"] = v183
			}, v_u_104)
			v_u_77.layout(v184, "h", 8)
			local v185, v186
			if p_u_76.canPlace then
				v185, v186 = p_u_76.canPlace()
			else
				v185 = true
				v186 = nil
			end
			local v187, v188 = v_u_82.button(v184, v_u_18.TEXT.place, "primary", function()
				-- upvalues: (ref) p_u_76
				if p_u_76.onPlace then
					p_u_76.onPlace()
				end
			end, {
				["name"] = "PlaceOrder",
				["order"] = 1,
				["maxTextWidth"] = 180
			})
			v188.setEnabled(v185 == true)
			v187:SetAttribute("Reason", v186 or "")
			v_u_84.placeBtn = v187
			if v_u_94.more and v_u_91 < v_u_18.MORE_PAGES then
				v_u_84.moreBtn = v_u_82.button(v184, v_u_18.TEXT.more, "secondary", function()
					-- upvalues: (ref) v_u_84
					v_u_84.moreLevels()
				end, {
					["name"] = "MoreLevels",
					["order"] = 2,
					["maxTextWidth"] = 160
				})
			else
				v_u_84.moreBtn = nil
			end
			local v189 = v183 + 1
			if v185 ~= true and v186 then
				v_u_77.label({
					["parent"] = nil,
					["name"] = "PlaceWhy",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_104,
					["text"] = v186,
					["color"] = v_u_79.accent,
					["order"] = v189
				})
				v189 = v189 + 1
			end
			local v190 = v_u_80.fill(v_u_18.TEXT.feeLine, {
				["fee"] = v_u_94.fee
			})
			if v_u_94.band then
				v190 = v190 .. " " .. v_u_80.fill(v_u_18.TEXT.bandLine, {
					["lo"] = v_u_80.money(v_u_94.band.lo),
					["hi"] = v_u_80.money(v_u_94.band.hi)
				})
			end
			v_u_77.label({
				["parent"] = nil,
				["name"] = "Info",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v_u_104,
				["text"] = v190,
				["color"] = v_u_79.muted,
				["order"] = v189
			})
			v_u_104:SetAttribute("Rows", #v_u_99)
		else
			v_u_111(v_u_94 and v_u_94.text or v_u_80.CODES.STORE, true)
		end
	end
	local function v_u_201(p192, p193) -- name: load
		-- upvalues: (ref) v_u_86, (ref) v_u_87, (ref) v_u_88, (ref) v_u_95, (copy) v_u_81, (ref) v_u_93, (copy) v_u_191, (ref) v_u_85, (ref) v_u_97, (ref) v_u_89, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_18, (copy) v_u_80, (copy) v_u_101, (ref) v_u_94, (ref) v_u_96, (copy) v_u_201, (copy) p_u_76
		if (v_u_86 or v_u_87) and v_u_88 ~= nil then
			v_u_95 = v_u_95 + 1
			local v_u_194 = v_u_95
			local v_u_195 = v_u_88
			if p192 then
				v_u_81:invalidate("book/" .. v_u_195)
			end
			if not p193 or v_u_93 ~= "ok" then
				v_u_93 = "loading"
				if v_u_86 then
					v_u_191()
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_81, (copy) v_u_195, (copy) v_u_194, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_97, (ref) v_u_89, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_18, (ref) v_u_80, (ref) v_u_101, (ref) v_u_94, (ref) v_u_93, (ref) v_u_96, (ref) v_u_191, (ref) v_u_201, (ref) p_u_76
				local v196 = v_u_81:book(v_u_195, nil)
				if v_u_194 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
					v_u_97 = v_u_81:clock()
					v_u_89 = v196
					v_u_90 = {}
					v_u_91 = 0
					v_u_92 = true
					local v197 = {
						["side"] = v_u_101
					}
					local v198 = v_u_18.model(v196, v_u_80, v197)
					v_u_94 = v198
					if v198.state == "ok" then
						v_u_93 = "ok"
						v_u_96 = 0
						local v199 = {
							["side"] = v_u_101,
							["extraBids"] = v_u_90
						}
						v_u_94 = v_u_18.model(v_u_89, v_u_80, v199)
						if v_u_94.more and (v_u_92 == false and v_u_91 > 0) then
							v_u_94.more = false
						end
						if v_u_86 then
							v_u_191()
						end
					elseif v198.state == "busy" then
						v_u_96 = v_u_96 + 1
						v_u_93 = "busy"
						if v_u_86 then
							v_u_191()
						end
						if v_u_96 < v_u_80.RETRY_MAX then
							local v200 = v_u_80.retryDelay(v198.retryIn, v_u_96, 0.9 + math.random() * 0.2)
							task.delay(v200, function()
								-- upvalues: (ref) v_u_194, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_201
								if v_u_194 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
									v_u_201(true)
								end
							end)
						end
					elseif v198.state == "down" then
						v_u_93 = "down"
						if v_u_86 then
							v_u_191()
						end
					elseif v198.state == "closed" then
						v_u_93 = "closed"
						if v_u_86 then
							v_u_191()
						end
					else
						v_u_93 = "error"
						if v_u_86 then
							v_u_191()
						end
					end
					if p_u_76.onModel then
						p_u_76.onModel(v_u_94)
					end
				end
			end)
		end
	end
	function v_u_84.reload(p202, p203) -- name: reload
		-- upvalues: (copy) v_u_201
		v_u_201(p202 == true, p203)
	end
	function v_u_84.moreLevels() -- name: moreLevels
		-- upvalues: (ref) v_u_93, (ref) v_u_94, (ref) v_u_91, (ref) v_u_18, (ref) v_u_88, (copy) v_u_81, (ref) v_u_98, (copy) v_u_77, (copy) v_u_78, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (copy) v_u_80, (copy) v_u_101, (ref) v_u_90, (ref) v_u_92, (ref) v_u_89, (copy) v_u_191
		if v_u_93 ~= "ok" or (v_u_94 == nil or (not v_u_94.more or (v_u_91 >= v_u_18.MORE_PAGES or v_u_88 == nil))) then
			return false
		end
		if v_u_81:clock() - v_u_98 < v_u_18.MORE_GAP then
			v_u_77.sound(v_u_78.sounds.error)
			return false
		end
		v_u_98 = v_u_81:clock()
		local v204 = v_u_94.bids[#v_u_94.bids]
		if v204 == nil then
			return false
		end
		local v205 = v204.u
		local v_u_206 = math.floor(v205)
		local v_u_207 = v_u_88
		local v_u_208 = v_u_95
		task.spawn(function()
			-- upvalues: (ref) v_u_81, (copy) v_u_207, (copy) v_u_206, (copy) v_u_208, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_18, (ref) v_u_80, (ref) v_u_101, (ref) v_u_91, (ref) v_u_90, (ref) v_u_92, (ref) v_u_94, (ref) v_u_89, (ref) v_u_191
			local v209 = v_u_81:book(v_u_207, v_u_206)
			if v_u_208 == v_u_95 and (v_u_85 and v_u_86) then
				local v210 = {
					["side"] = v_u_101
				}
				if v_u_18.model(v209, v_u_80, v210).state == "ok" then
					v_u_91 = v_u_91 + 1
					local v211 = v209.bids
					for _, v212 in type(v211) ~= "table" and {} or v209.bids do
						local v213 = v_u_90
						table.insert(v213, v212)
					end
					v_u_92 = v209.more == true
					local v214 = {
						["side"] = v_u_101,
						["extraBids"] = v_u_90
					}
					v_u_94 = v_u_18.model(v_u_89, v_u_80, v214)
					if v_u_94.more and (v_u_92 == false and v_u_91 > 0) then
						v_u_94.more = false
					end
					if v_u_92 == false then
						v_u_94.more = false
					end
					v_u_191()
				end
			else
				return
			end
		end)
		return true
	end
	function v_u_84.show(p215) -- name: show
		-- upvalues: (ref) v_u_88, (ref) v_u_86, (copy) v_u_103, (ref) v_u_89, (ref) v_u_94, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_93, (ref) v_u_96, (ref) v_u_87, (ref) v_u_95, (copy) v_u_191, (copy) v_u_81, (ref) v_u_85, (ref) v_u_97, (ref) v_u_18, (copy) v_u_80, (copy) v_u_101, (copy) v_u_201, (copy) p_u_76
		v_u_88 = p215
		v_u_86 = true
		v_u_103.Visible = true
		v_u_89 = nil
		v_u_94 = nil
		v_u_90 = {}
		v_u_91 = 0
		v_u_92 = true
		v_u_93 = "loading"
		v_u_96 = 0
		if v_u_86 or v_u_87 then
			if v_u_88 == nil then
				return
			end
			v_u_95 = v_u_95 + 1
			local v_u_216 = v_u_95
			local v_u_217 = v_u_88
			v_u_93 = "loading"
			if v_u_86 then
				v_u_191()
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_81, (copy) v_u_217, (copy) v_u_216, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_97, (ref) v_u_89, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_18, (ref) v_u_80, (ref) v_u_101, (ref) v_u_94, (ref) v_u_93, (ref) v_u_96, (ref) v_u_191, (ref) v_u_201, (ref) p_u_76
				local v218 = v_u_81:book(v_u_217, nil)
				if v_u_216 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
					v_u_97 = v_u_81:clock()
					v_u_89 = v218
					v_u_90 = {}
					v_u_91 = 0
					v_u_92 = true
					local v219 = {
						["side"] = v_u_101
					}
					local v220 = v_u_18.model(v218, v_u_80, v219)
					v_u_94 = v220
					if v220.state == "ok" then
						v_u_93 = "ok"
						v_u_96 = 0
						local v221 = {
							["side"] = v_u_101,
							["extraBids"] = v_u_90
						}
						v_u_94 = v_u_18.model(v_u_89, v_u_80, v221)
						if v_u_94.more and (v_u_92 == false and v_u_91 > 0) then
							v_u_94.more = false
						end
						if v_u_86 then
							v_u_191()
						end
					elseif v220.state == "busy" then
						v_u_96 = v_u_96 + 1
						v_u_93 = "busy"
						if v_u_86 then
							v_u_191()
						end
						if v_u_96 < v_u_80.RETRY_MAX then
							local v222 = v_u_80.retryDelay(v220.retryIn, v_u_96, 0.9 + math.random() * 0.2)
							task.delay(v222, function()
								-- upvalues: (ref) v_u_216, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_201
								if v_u_216 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
									v_u_201(true)
								end
							end)
						end
					elseif v220.state == "down" then
						v_u_93 = "down"
						if v_u_86 then
							v_u_191()
						end
					elseif v220.state == "closed" then
						v_u_93 = "closed"
						if v_u_86 then
							v_u_191()
						end
					else
						v_u_93 = "error"
						if v_u_86 then
							v_u_191()
						end
					end
					if p_u_76.onModel then
						p_u_76.onModel(v_u_94)
					end
				end
			end)
		end
	end
	function v_u_84.prefetch(p223) -- name: prefetch
		-- upvalues: (ref) v_u_87, (ref) v_u_88, (ref) v_u_89, (ref) v_u_94, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_93, (copy) v_u_81, (ref) v_u_97, (ref) v_u_18, (ref) v_u_96, (ref) v_u_86, (ref) v_u_95, (copy) v_u_191, (ref) v_u_85, (copy) v_u_80, (copy) v_u_101, (copy) v_u_201, (copy) p_u_76
		v_u_87 = true
		if v_u_88 ~= p223 then
			v_u_88 = p223
			v_u_89 = nil
			v_u_94 = nil
			v_u_90 = {}
			v_u_91 = 0
			v_u_92 = true
			v_u_93 = "loading"
		end
		if v_u_93 ~= "ok" or (v_u_94 == nil or v_u_81:clock() - v_u_97 >= v_u_18.EVERY) then
			v_u_96 = 0
			if v_u_86 or v_u_87 then
				if v_u_88 == nil then
					return
				end
				v_u_95 = v_u_95 + 1
				local v_u_224 = v_u_95
				local v_u_225 = v_u_88
				if v_u_93 ~= "ok" then
					v_u_93 = "loading"
					if v_u_86 then
						v_u_191()
					end
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_81, (copy) v_u_225, (copy) v_u_224, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_97, (ref) v_u_89, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_18, (ref) v_u_80, (ref) v_u_101, (ref) v_u_94, (ref) v_u_93, (ref) v_u_96, (ref) v_u_191, (ref) v_u_201, (ref) p_u_76
					local v226 = v_u_81:book(v_u_225, nil)
					if v_u_224 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
						v_u_97 = v_u_81:clock()
						v_u_89 = v226
						v_u_90 = {}
						v_u_91 = 0
						v_u_92 = true
						local v227 = {
							["side"] = v_u_101
						}
						local v228 = v_u_18.model(v226, v_u_80, v227)
						v_u_94 = v228
						if v228.state == "ok" then
							v_u_93 = "ok"
							v_u_96 = 0
							local v229 = {
								["side"] = v_u_101,
								["extraBids"] = v_u_90
							}
							v_u_94 = v_u_18.model(v_u_89, v_u_80, v229)
							if v_u_94.more and (v_u_92 == false and v_u_91 > 0) then
								v_u_94.more = false
							end
							if v_u_86 then
								v_u_191()
							end
						elseif v228.state == "busy" then
							v_u_96 = v_u_96 + 1
							v_u_93 = "busy"
							if v_u_86 then
								v_u_191()
							end
							if v_u_96 < v_u_80.RETRY_MAX then
								local v230 = v_u_80.retryDelay(v228.retryIn, v_u_96, 0.9 + math.random() * 0.2)
								task.delay(v230, function()
									-- upvalues: (ref) v_u_224, (ref) v_u_95, (ref) v_u_85, (ref) v_u_86, (ref) v_u_87, (ref) v_u_201
									if v_u_224 == v_u_95 and (v_u_85 and (v_u_86 or v_u_87)) then
										v_u_201(true)
									end
								end)
							end
						elseif v228.state == "down" then
							v_u_93 = "down"
							if v_u_86 then
								v_u_191()
							end
						elseif v228.state == "closed" then
							v_u_93 = "closed"
							if v_u_86 then
								v_u_191()
							end
						else
							v_u_93 = "error"
							if v_u_86 then
								v_u_191()
							end
						end
						if p_u_76.onModel then
							p_u_76.onModel(v_u_94)
						end
					end
				end)
			end
		end
	end
	function v_u_84.hide() -- name: hide
		-- upvalues: (ref) v_u_86, (ref) v_u_87, (ref) v_u_95, (copy) v_u_103, (copy) v_u_106
		v_u_86 = false
		v_u_87 = false
		v_u_95 = v_u_95 + 1
		v_u_103.Visible = false
		v_u_106()
	end
	function v_u_84.isShown() -- name: isShown
		-- upvalues: (ref) v_u_86
		return v_u_86
	end
	function v_u_84.onNote(_) -- name: onNote
		-- upvalues: (ref) v_u_86, (ref) v_u_87, (ref) v_u_93, (copy) v_u_201
		if (v_u_86 or v_u_87) and v_u_93 == "ok" then
			v_u_201(true, true)
		end
	end
	function v_u_84.repaint() -- name: repaint
		-- upvalues: (ref) v_u_86, (ref) v_u_93, (ref) v_u_94, (copy) v_u_191
		if v_u_86 and (v_u_93 == "ok" and v_u_94 ~= nil) then
			v_u_191()
		end
	end
	function v_u_84.layout() -- name: layout end
	function v_u_84.model() -- name: model
		-- upvalues: (ref) v_u_94
		return v_u_94
	end
	function v_u_84.status() -- name: status
		-- upvalues: (ref) v_u_93
		return v_u_93
	end
	function v_u_84.rows() -- name: rows
		-- upvalues: (copy) v_u_99
		local v231 = {}
		for _, v232 in v_u_99 do
			local v233 = {
				["side"] = v232.row.side,
				["u"] = v232.row.u,
				["q"] = v232.row.q,
				["own"] = v232.row.own,
				["btn"] = v232.btn
			}
			table.insert(v231, v233)
		end
		return v231
	end
	function v_u_84.press(p234, p235) -- name: press
		-- upvalues: (copy) v_u_99, (copy) v_u_116
		local v236 = 0
		for _, v237 in v_u_99 do
			if v237.row.side ~= p234 then
				continue
			end
			v236 = v236 + 1
			if v236 ~= p235 then
				continue
			end
			task.spawn(v_u_116, v237.row)
			return true
		end
		return false
	end
	function v_u_84.state() -- name: state
		-- upvalues: (ref) v_u_88, (ref) v_u_93, (ref) v_u_91, (ref) v_u_94, (copy) v_u_99, (ref) v_u_86, (copy) v_u_103, (copy) v_u_104
		local v238 = {
			["id"] = v_u_88,
			["status"] = v_u_93,
			["extraPages"] = v_u_91
		}
		local v239
		if v_u_94 == nil then
			v239 = false
		else
			v239 = v_u_94.more == true
		end
		v238.more = v239
		v238.rows = #v_u_99
		v238.shown = v_u_86
		v238.root = v_u_103
		v238.scroll = v_u_104
		return v238
	end
	local v240 = {
		["Disconnect"] = p74.onTick(function()
			-- upvalues: (ref) v_u_86, (ref) v_u_87, (ref) v_u_93, (copy) v_u_81, (ref) v_u_97, (ref) v_u_18, (copy) v_u_201
			if (v_u_86 or v_u_87) and (v_u_93 == "ok" and v_u_81:clock() - v_u_97 >= v_u_18.EVERY) then
				v_u_201(true, true)
			end
		end)
	}
	table.insert(v_u_100, v240)
	function v_u_84.destroy() -- name: destroy
		-- upvalues: (ref) v_u_85, (ref) v_u_86, (copy) v_u_100, (copy) v_u_103
		v_u_85 = false
		v_u_86 = false
		for _, v_u_241 in v_u_100 do
			pcall(function()
				-- upvalues: (copy) v_u_241
				v_u_241:Disconnect()
			end)
		end
		v_u_103:Destroy()
	end
	return v_u_84
end
return v_u_18