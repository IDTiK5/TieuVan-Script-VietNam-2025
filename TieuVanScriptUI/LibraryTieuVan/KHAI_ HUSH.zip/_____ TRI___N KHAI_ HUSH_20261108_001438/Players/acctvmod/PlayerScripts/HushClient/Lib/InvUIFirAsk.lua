-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIFirAsk

local v1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage")
local v4 = script.Parent
local v_u_5 = require(v4:WaitForChild("HushUI"))
local v_u_6 = v3:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_7 = require(v_u_6:WaitForChild("Items"))
local v_u_8 = require(v_u_6:WaitForChild("Grid"))
local v_u_9 = {}
local v_u_10 = v1.LocalPlayer
local v_u_11 = nil
v_u_9.CARRY = { "lo_pockets", "lo_vest", "lo_bag" }
v_u_9.NO_ASK_ATTR = "AmmoStackNoAsk"
v_u_9.lastState = ""
local function v_u_19(p12, p13, p14) -- name: find
	if p12 then
		p12 = p12.work
	end
	local v15
	if type(p12) == "table" then
		v15 = p12.containers or nil
	else
		v15 = nil
	end
	if type(v15) ~= "table" or type(p14) ~= "string" then
		return nil
	end
	if p13 then
		p13 = v15[p13]
	end
	for _, v16 in type(p13) == "table" and { p13 } or v15 do
		if type(v16) ~= "table" then
			continue
		end
		local v17 = v16.items
		if type(v17) ~= "table" then
			continue
		end
		for _, v18 in v16.items do
			if type(v18) ~= "table" or v18.uid ~= p14 then
				continue
			end
			return v18
		end
	end
	return nil
end
function v_u_9.readFlag()
	return nil
end
local v_u_20 = nil
local function v_u_28() -- name: allOn
	-- upvalues: (copy) v_u_9, (ref) v_u_20, (copy) v_u_6
	local v21 = v_u_9.readFlag()
	if v21 ~= nil then
		return v21 ~= false
	end
	if v_u_20 == nil then
		local function v22()
			-- upvalues: (ref) v_u_6
			return require(v_u_6:WaitForChild("Config", 5))
		end
		local v23, v24 = pcall(v22)
		if not v23 or type(v24) ~= "table" then
			v24 = false
		end
		v_u_20 = v24
	end
	if v_u_20 then
		local v25 = v_u_20.flag
		local v26, v27 = pcall(v25, "FirStackAll")
		if v26 and v27 == false then
			return false
		end
	end
	return true
end
function v_u_9.stackOk(p29) -- name: stackOk
	-- upvalues: (copy) v_u_7, (copy) v_u_28
	local v30
	if type(p29) == "string" then
		v30 = v_u_7.get(p29)
	else
		v30 = nil
	end
	local v31
	if v30 == nil then
		v31 = false
	else
		v31 = v30.category == "ammo"
	end
	if v31 then
		return true
	end
	local v32
	if type(p29) == "string" then
		v32 = v_u_7.get(p29)
	else
		v32 = nil
	end
	local v33
	if v32 == nil or (v32.stack or 1) <= 1 then
		v33 = false
	else
		v33 = v_u_28()
	end
	return v33
end
function v_u_9.text(p34, p35) -- name: text
	-- upvalues: (copy) v_u_7
	local v36
	if type(p35) == "string" then
		v36 = v_u_7.get(p35)
	else
		v36 = nil
	end
	local v37
	if v36 == nil then
		v37 = false
	else
		v37 = v36.category == "ammo"
	end
	local v38
	if v37 then
		v38 = p34 == 1 and "round" or "rounds"
	else
		v38 = p34 == 1 and "item" or "items"
	end
	return string.format("%d found in raid %s %s not found in raid.", p34, v38, p34 == 1 and "becomes" or "become")
end
function v_u_9.mixable(p39, p40, p41) -- name: mixable
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	local v42
	if type(p39) == "table" and p39.mode ~= "raid" then
		v42 = not p39.fake
	else
		v42 = false
	end
	if not v42 or (type(p40) ~= "table" or (type(p41) ~= "table" or (p40.uid == p41.uid or p40.id ~= p41.id))) then
		return nil
	end
	if p40.fir == true and (p41.fir ~= true and (v_u_9.stackOk(p40.id) and not (p40.mods or (p41.mods or (p40.items or p41.items))))) then
		local v43 = p40.paid == true
		local v44
		if v43 == (p41.paid == true) and (p40.bound == true == (p41.bound == true) and p40.gift == p41.gift) then
			v44 = not v43 or p40.buyer == p41.buyer
		else
			v44 = false
		end
		if v44 then
			if p40.lk == true or p41.lk == true then
				return nil
			end
			local v45 = v_u_8.stackMax(p41) - (p41.n or 1)
			if v45 <= 0 then
				return nil
			end
			local v46 = p40.n or 1
			return math.min(v45, v46)
		end
	end
	return nil
end
function v_u_9.noAsk()
	-- upvalues: (copy) v_u_10, (copy) v_u_9
	local function v47()
		-- upvalues: (ref) v_u_10, (ref) v_u_9
		return v_u_10:GetAttribute(v_u_9.NO_ASK_ATTR)
	end
	local v48, v49 = pcall(v47)
	if v48 then
		v48 = v49 == true
	end
	return v48
end
function v_u_9.ask(p50, p51, p52, p_u_53, p54)
	-- upvalues: (ref) v_u_11, (copy) v_u_9, (copy) v_u_10, (copy) v_u_5
	if v_u_11 then
		local v55 = v_u_11.api.close
		pcall(v55)
		v_u_11 = nil
	end
	local v_u_56 = false
	local v_u_67 = {
		["stack"] = function()
			-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) p_u_53, (ref) v_u_56
			v_u_9.lastState = "stack"
			local v_u_57 = "stack"
			local function v58()
				-- upvalues: (ref) v_u_10, (copy) v_u_57
				v_u_10:SetAttribute("InvFirAsk", v_u_57)
			end
			pcall(v58)
			p_u_53(v_u_56)
			if v_u_56 then
				local function v59()
					-- upvalues: (ref) v_u_10, (ref) v_u_9
					v_u_10:SetAttribute(v_u_9.NO_ASK_ATTR, true)
				end
				pcall(v59)
			end
		end,
		["cancel"] = function()
			-- upvalues: (ref) v_u_9, (ref) v_u_10
			v_u_9.lastState = "cancel"
			local v_u_60 = "cancel"
			local function v61()
				-- upvalues: (ref) v_u_10, (copy) v_u_60
				v_u_10:SetAttribute("InvFirAsk", v_u_60)
			end
			pcall(v61)
		end,
		["tick"] = function()
			-- upvalues: (ref) v_u_56, (copy) v_u_67, (ref) v_u_9, (ref) v_u_10
			v_u_56 = not v_u_56
			if v_u_67.tickApi then
				local v62 = v_u_67.tickApi.set
				local v63 = v_u_56
				pcall(v62, v63)
			end
			local v64 = v_u_56
			local v_u_65 = "tick " .. tostring(v64)
			v_u_9.lastState = v_u_65
			local function v66()
				-- upvalues: (ref) v_u_10, (copy) v_u_65
				v_u_10:SetAttribute("InvFirAsk", v_u_65)
			end
			pcall(v66)
		end
	}
	local v68 = v_u_5.modal
	local v73 = {
		["title"] = "Stack anyway?",
		["body"] = nil,
		["width"] = 440,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["body"] = v_u_9.text(p52, p54),
		["build"] = function(p69) -- name: build
			-- upvalues: (ref) v_u_5, (ref) v_u_56, (copy) v_u_67
			local v71 = {
				["parent"] = nil,
				["name"] = "DontAsk",
				["label"] = "Don\'t ask again",
				["value"] = false,
				["width"] = 392,
				["onChange"] = nil,
				["parent"] = p69,
				["onChange"] = function(p70) -- name: onChange
					-- upvalues: (ref) v_u_56
					v_u_56 = p70 == true
				end
			}
			local _, v72 = v_u_5.toggle(v71)
			v_u_67.tickApi = v72
		end,
		["buttons"] = {
			{
				["text"] = "Stack",
				["kind"] = "primary",
				["onClick"] = nil,
				["onClick"] = v_u_67.stack
			},
			{
				["text"] = "Cancel",
				["kind"] = "ghost",
				["onClick"] = nil,
				["onClick"] = v_u_67.cancel
			}
		},
		["onClose"] = function() -- name: onClose
			-- upvalues: (ref) v_u_11, (copy) v_u_67
			if v_u_11 == v_u_67 then
				v_u_11 = nil
			end
		end
	}
	local v74, v75 = pcall(v68, v73)
	if not v74 or type(v75) ~= "table" then
		return false
	end
	v_u_67.api = v75
	v_u_11 = v_u_67
	local v_u_76 = "open " .. tostring(p50) .. " " .. tostring(p51) .. " " .. tostring(p52)
	v_u_9.lastState = v_u_76
	local function v77()
		-- upvalues: (ref) v_u_10, (copy) v_u_76
		v_u_10:SetAttribute("InvFirAsk", v_u_76)
	end
	pcall(v77)
	local function v79()
		-- upvalues: (ref) v_u_10
		local v78 = v_u_10
		v_u_10:SetAttribute("InvFirAskN", (tonumber(v78:GetAttribute("InvFirAskN")) or 0) + 1)
	end
	pcall(v79)
	return true
end
function v_u_9.intercept(p_u_80, p81, p82, p_u_83) -- name: intercept
	-- upvalues: (copy) v_u_19, (copy) v_u_9, (copy) v_u_10
	local v84
	if type(p_u_80) == "table" and p_u_80.mode ~= "raid" then
		v84 = not p_u_80.fake
	else
		v84 = false
	end
	if v84 and type(p82) == "table" then
		local v85 = p82.merge
		if type(v85) == "string" and type(p81) == "table" then
			local v86 = v_u_19(p_u_80, nil, p81.uid) or p81.inst
			local v87 = v_u_19(p_u_80, p82.container, p82.merge)
			local v88 = v_u_9.mixable(p_u_80, v86, v87)
			if v88 == nil then
				return false
			end
			local v_u_89 = p81.uid
			local v_u_90 = p82.merge
			if not v_u_9.noAsk() then
				local v91 = v_u_9.ask
				local function v93(p92)
					-- upvalues: (copy) p_u_83, (copy) p_u_80, (copy) v_u_89, (copy) v_u_90
					p_u_83(p_u_80, {
						["op"] = "stackFir",
						["uid"] = nil,
						["onto"] = nil,
						["confirm"] = true,
						["remember"] = nil,
						["uid"] = v_u_89,
						["onto"] = v_u_90,
						["remember"] = p92 and true or nil
					})
				end
				local v94
				if type(v86) == "table" then
					v94 = v86.id
				else
					v94 = nil
				end
				return v91(v_u_89, v_u_90, v88, v93, v94)
			end
			local v_u_95 = "auto " .. tostring(v_u_89)
			v_u_9.lastState = v_u_95
			local function v96()
				-- upvalues: (ref) v_u_10, (copy) v_u_95
				v_u_10:SetAttribute("InvFirAsk", v_u_95)
			end
			pcall(v96)
			p_u_83(p_u_80, {
				["op"] = "stackFir",
				["uid"] = nil,
				["onto"] = nil,
				["confirm"] = true,
				["auto"] = true,
				["uid"] = v_u_89,
				["onto"] = v_u_90
			})
			return true
		end
	end
	return false
end
local function v_u_115(p97, p98, p99) -- name: quickPlan
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	local v100 = p97.work
	if v100 then
		v100 = p97.work.containers
	end
	if type(v100) ~= "table" then
		return nil, nil
	end
	local v101
	if p99 == "stash" or string.sub(p99, 1, 3) == "in:" then
		v101 = v_u_9.CARRY
	else
		v101 = (p99 == "lo_pockets" or (p99 == "lo_vest" or p99 == "lo_bag")) and { "stash" } or nil
	end
	if v101 == nil then
		return nil, nil
	end
	local v102 = {}
	for _, v103 in v101 do
		local v104 = v100[v103]
		if type(v104) ~= "table" then
			continue
		end
		local v105 = v100[v103].items
		if type(v105) ~= "table" then
			continue
		end
		local v106 = v100[v103]
		table.insert(v102, v106)
	end
	local v107 = v_u_8.stackMax(p98)
	for _, v108 in v102 do
		for _, v109 in v108.items do
			if v109.uid == p98.uid or (v109.id ~= p98.id or (v109.fir ~= true or v109.lk == true)) then
				continue
			end
			local v110 = v109.paid == true
			local v111
			if v110 == (p98.paid == true) and (v109.bound == true == (p98.bound == true) and v109.gift == p98.gift) then
				v111 = not v110 or v109.buyer == p98.buyer
			else
				v111 = false
			end
			if not v111 or (v109.n or 1) >= v107 then
				continue
			end
			return nil, nil
		end
		if v_u_8.findSpot(v108, p98) == nil then
			continue
		end
		return nil, nil
	end
	for _, v112 in v102 do
		for _, v113 in v112.items do
			local v114 = v_u_9.mixable(p97, p98, v113)
			if v114 == nil then
				continue
			end
			return v113, v114
		end
	end
	return nil, nil
end
function v_u_9.quick(p_u_116, p_u_117, p_u_118) -- name: quick
	-- upvalues: (copy) v_u_19, (copy) v_u_9, (copy) v_u_115, (copy) v_u_10
	local v119
	if type(p_u_116) == "table" and p_u_116.mode ~= "raid" then
		v119 = not p_u_116.fake
	else
		v119 = false
	end
	if not v119 or type(p_u_117) ~= "string" then
		return false
	end
	local v120 = v_u_19(p_u_116, nil, p_u_117)
	if v120 == nil or (v120.fir ~= true or not v_u_9.stackOk(v120.id)) then
		return false
	end
	local v121 = nil
	for v122, v123 in p_u_116.work and (p_u_116.work.containers or {}) or {} do
		if type(v123) ~= "table" then
			continue
		end
		local v124 = v123.items
		if type(v124) ~= "table" then
			continue
		end
		for _, v125 in v123.items do
			if v125 ~= v120 then
				continue
			end
			v121 = v122
		end
	end
	if v121 == nil then
		return false
	end
	local v126, v127 = v_u_115(p_u_116, v120, v121)
	if v126 == nil or v127 == nil then
		return false
	end
	if not v_u_9.noAsk() then
		return v_u_9.ask(p_u_117, v126.uid, v127, function(p128)
			-- upvalues: (copy) p_u_118, (copy) p_u_116, (copy) p_u_117
			p_u_118(p_u_116, {
				["op"] = "quick",
				["uid"] = nil,
				["confirm"] = true,
				["remember"] = nil,
				["uid"] = p_u_117,
				["remember"] = p128 and true or nil
			})
		end, v120.id)
	end
	local v_u_129 = "auto " .. tostring(p_u_117)
	v_u_9.lastState = v_u_129
	local function v130()
		-- upvalues: (ref) v_u_10, (copy) v_u_129
		v_u_10:SetAttribute("InvFirAsk", v_u_129)
	end
	pcall(v130)
	p_u_118(p_u_116, {
		["op"] = "quick",
		["uid"] = nil,
		["confirm"] = true,
		["auto"] = true,
		["uid"] = p_u_117
	})
	return true
end
if v2:IsStudio() and v_u_10 ~= nil then
	v_u_10:GetAttributeChangedSignal("InvFirAskCmd"):Connect(function()
		-- upvalues: (copy) v_u_10, (ref) v_u_11, (copy) v_u_9
		local v131 = v_u_10:GetAttribute("InvFirAskCmd")
		if v131 == nil or v131 == "" then
			return
		else
			v_u_10:SetAttribute("InvFirAskCmd", nil)
			local v132 = v_u_11
			if v132 then
				if v131 == "tick" then
					v132.tick()
				else
					if v131 == "stack" then
						v132.stack()
					else
						v132.cancel()
					end
					local v133 = v132.api.close
					pcall(v133)
				end
			else
				v_u_9.lastState = "none open"
				local v_u_134 = "none open"
				local function v135()
					-- upvalues: (ref) v_u_10, (copy) v_u_134
					v_u_10:SetAttribute("InvFirAsk", v_u_134)
				end
				pcall(v135)
				return
			end
		end
	end)
end
return v_u_9