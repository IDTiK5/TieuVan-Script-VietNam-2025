-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUILock

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["ID"] = "lock",
	["TEXT"] = {
		["lock"] = "Lock",
		["unlock"] = "Unlock"
	},
	["env"] = nil
}
local v_u_3 = nil
v_u_2.readFlag = nil
function v_u_2.flagOn() -- name: flagOn
	-- upvalues: (copy) v_u_2, (ref) v_u_3, (copy) v_u_1
	local v4 = v_u_2.readFlag
	if type(v4) == "function" then
		return v_u_2.readFlag() ~= false
	end
	if v_u_3 == nil then
		local function v5()
			-- upvalues: (ref) v_u_1
			return require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Config", 5))
		end
		local v6, v7 = pcall(v5)
		if not v6 or type(v7) ~= "table" then
			v7 = false
		end
		v_u_3 = v7
	end
	local v8 = v_u_3
	if v8 then
		local v9 = v8.flag
		local v10, v11 = pcall(v9, "ItemLock")
		if v10 and v11 == false then
			return false
		end
	end
	return true
end
function v_u_2.shown(p12) -- name: shown
	-- upvalues: (copy) v_u_2
	local v13
	if type(p12) == "table" and p12.lk == true then
		v13 = v_u_2.flagOn()
	else
		v13 = false
	end
	return v13
end
function v_u_2.canLock(p14, p15) -- name: canLock
	-- upvalues: (copy) v_u_2
	if type(p14) ~= "table" or (p14.mode == "raid" or p14.fake) then
		return false
	end
	if type(p15) == "table" then
		local v16 = p15.item
		if type(v16) == "table" and (p15.kind == "grid" and p15.container == "stash") then
			return v_u_2.flagOn()
		end
	end
	return false
end
function v_u_2.entry(p17, p18) -- name: entry
	-- upvalues: (copy) v_u_2
	if not v_u_2.canLock(p17, p18) then
		return nil
	end
	local v19 = {
		["id"] = v_u_2.ID
	}
	local v20
	if p18.item.lk == true then
		v20 = v_u_2.TEXT.unlock
	else
		v20 = v_u_2.TEXT.lock
	end
	v19.text = v20
	return v19
end
function v_u_2.acts(p21, p22, p23) -- name: acts
	-- upvalues: (copy) v_u_2
	local v24 = v_u_2.entry(p21, p22)
	if v24 then
		table.insert(p23, v24)
	end
end
function v_u_2.strip(p25, p26, p27) -- name: strip
	-- upvalues: (copy) v_u_2
	local v28 = v_u_2.entry(p25, p26)
	if v28 then
		local v29 = {
			["id"] = nil,
			["text"] = nil,
			["icon"] = "lock",
			["id"] = v28.id,
			["text"] = v28.text
		}
		table.insert(p27, v29)
	end
end
function v_u_2.op(p30, p31) -- name: op
	return {
		["op"] = "lock",
		["uid"] = nil,
		["on"] = nil,
		["uid"] = p30,
		["on"] = not p31
	}
end
function v_u_2.run(p32, p33, p34) -- name: run
	-- upvalues: (copy) v_u_2
	if p34 ~= v_u_2.ID then
		return false
	end
	local v35 = nil
	local v36
	if p32 then
		v36 = p32.work
	else
		v36 = p32
	end
	local v37
	if type(v36) == "table" then
		v37 = v36.containers or nil
	else
		v37 = nil
	end
	local v38
	if type(v37) == "table" then
		v38 = v37.stash
	else
		v38 = nil
	end
	if type(v38) == "table" then
		local v39 = v38.items
		if type(v39) == "table" then
			for _, v40 in v38.items do
				if type(v40) ~= "table" or v40.uid ~= p33 then
					continue
				end
				v35 = {
					["kind"] = "grid",
					["container"] = "stash",
					["item"] = nil,
					["item"] = v40
				}
			end
		end
	end
	if v35 == nil or not v_u_2.canLock(p32, v35) then
		return true
	end
	local v41 = v35.item.lk == true
	local v42 = v_u_2.env
	if v42 then
		v42 = v_u_2.env.send
	end
	if type(v42) == "function" then
		v42(p32, v_u_2.op(p33, v41))
	end
	v35.item.lk = not v41 and true or nil
	local v43 = v_u_2.env
	if v43 then
		v43 = v_u_2.env.render
	end
	if type(v43) == "function" then
		pcall(v43, p32)
	end
	return true
end
return v_u_2