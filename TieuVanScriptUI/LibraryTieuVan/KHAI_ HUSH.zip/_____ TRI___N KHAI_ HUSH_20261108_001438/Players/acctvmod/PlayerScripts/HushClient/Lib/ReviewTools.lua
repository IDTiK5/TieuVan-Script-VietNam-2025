-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewTools

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = {}
local v_u_7 = {}
function v_u_6.use(p8) -- name: use
	-- upvalues: (ref) v_u_7
	v_u_7 = type(p8) ~= "table" and {} or p8
end
local v_u_9 = nil
local v_u_10 = false
local function v_u_15() -- name: switchRules
	-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_10, (copy) v_u_2
	if v_u_7.switchRules ~= nil then
		return v_u_7.switchRules
	end
	if v_u_9 == nil and not v_u_10 then
		v_u_10 = true
		local function v12()
			-- upvalues: (ref) v_u_2
			local v11 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewSwitchRules", 5)
			if v11 == nil then
				return nil
			else
				return require(v11)
			end
		end
		local v13, v14 = pcall(v12)
		if v13 and type(v14) == "table" then
			v_u_9 = v14
		else
			warn("[ReviewTools] the module ReviewSwitchRules is missing (tools/make_manifest.py after adding files): the observer works without the player switch")
		end
	end
	return v_u_9
end
local v_u_16 = v_u_1.LocalPlayer
local v_u_17 = nil
local v_u_18 = false
local v_u_19 = false
local v_u_20 = nil
local v_u_21 = nil
local function v22() -- name: noop end
local v_u_23 = {
	["start"] = v22,
	["stop"] = v22,
	["setOn"] = v22,
	["push"] = v22,
	["step"] = v22,
	["count"] = function() -- name: count
		return 0
	end
}
local v_u_24 = {
	["init"] = v22,
	["start"] = v22,
	["stop"] = v22,
	["cycleLevel"] = function() -- name: cycleLevel
		return "NORMAL"
	end,
	["cycleTime"] = function() -- name: cycleTime
		return "RAID"
	end,
	["cycleTorch"] = function() -- name: cycleTorch
		return "OFF"
	end,
	["words"] = function() -- name: words
		return {
			["level"] = "NORMAL",
			["time"] = "RAID",
			["torch"] = "OFF"
		}
	end,
	["state"] = function() -- name: state
		return "light=missing"
	end
}
local v_u_25 = {
	["sightCode"] = function() -- name: sightCode
		return nil
	end,
	["hudFacts"] = function() -- name: hudFacts
		return nil, nil
	end,
	["weaponName"] = function() -- name: weaponName
		return nil
	end
}
local function v_u_32() -- name: modules
	-- upvalues: (ref) v_u_21, (copy) v_u_23, (copy) v_u_24, (copy) v_u_25
	if v_u_21 == nil then
		local v26 = {}
		local v27 = script.Parent:WaitForChild("HushUI", 15)
		if v27 == nil then
			error("ReviewTools: the module HushUI is missing in the client lib folder (tools/make_manifest.py after adding files)")
		end
		v26.HushUI = require(v27)
		local v28 = script.Parent:WaitForChild("ReviewToolsLayout", 15)
		if v28 == nil then
			error("ReviewTools: the module ReviewToolsLayout is missing in the client lib folder (tools/make_manifest.py after adding files)")
		end
		v26.Layout = require(v28)
		local v29 = script.Parent:WaitForChild("ReviewCamera", 15)
		if v29 == nil then
			error("ReviewTools: the module ReviewCamera is missing in the client lib folder (tools/make_manifest.py after adding files)")
		end
		v26.Camera = require(v29)
		local v30 = script.Parent:WaitForChild("ReviewEsp", 15)
		if v30 == nil then
			error("ReviewTools: the module ReviewEsp is missing in the client lib folder (tools/make_manifest.py after adding files)")
		end
		v26.Esp = require(v30)
		v26.Trail = v_u_23
		v26.Light = v_u_24
		v26.Cone = v_u_25
		local v31 = script.Parent:WaitForChild("ReviewVerdictPanel", 15)
		if v31 == nil then
			error("ReviewTools: the module ReviewVerdictPanel is missing in the client lib folder (tools/make_manifest.py after adding files)")
		end
		v26.Panel = require(v31)
		v_u_21 = v26
	end
	return v_u_21
end
local v_u_33 = false
local function v_u_43() -- name: observerLibs
	-- upvalues: (ref) v_u_33, (copy) v_u_32, (ref) v_u_17
	if not v_u_33 then
		v_u_33 = true
		local v34 = v_u_32()
		for v35, v36 in {
			["Trail"] = "ReviewTrail",
			["Light"] = "ReviewLight",
			["Cone"] = "ReviewVisionCone"
		} do
			local v37 = script.Parent:FindFirstChild(v36)
			if v37 == nil then
				warn("[ReviewTools] the module " .. v36 .. " is missing in the client lib folder (tools/make_manifest.py after adding files): the observer works without it")
			else
				local v38 = require
				local v39, v40 = pcall(v38, v37)
				if v39 and type(v40) == "table" then
					v34[v35] = v40
				else
					warn("[ReviewTools] the module " .. v36 .. " failed to load: " .. tostring(v40))
				end
			end
		end
		local v41 = v34.Light.init
		local v42 = v_u_17
		pcall(v41, v42)
	end
end
local function v_u_46(p44) -- name: newState
	-- upvalues: (ref) v_u_7, (copy) v_u_2
	local v45
	if v_u_7.rules == nil then
		v45 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v45 = v_u_7.rules
	end
	return {
		["userId"] = p44,
		["name"] = "?",
		["info"] = nil,
		["moments"] = {},
		["watch"] = v45.watchNew(),
		["espOn"] = true,
		["visionOn"] = true,
		["toast"] = "",
		["toastUntil"] = 0,
		["minWatch"] = 180,
		["sig"] = "",
		["hudAcc"] = 0,
		["pubAcc"] = 0,
		["conns"] = {},
		["unbinds"] = {},
		["topPx"] = 0,
		["verdictHost"] = nil,
		["momentsBy"] = {},
		["watchBy"] = {},
		["listed"] = nil,
		["streams"] = nil,
		["rosterOpen"] = false,
		["rosterY"] = 0,
		["roster"] = nil,
		["swSig"] = "",
		["rosterSigDrawn"] = nil,
		["pressAt"] = nil,
		["folView"] = nil,
		["switching"] = false,
		["gui"] = nil,
		["root"] = nil,
		["holder"] = nil,
		["refs"] = {},
		["leaving"] = false
	}
end
local function v_u_48() -- name: raidId
	-- upvalues: (copy) v_u_2
	local v47 = v_u_2:FindFirstChild("HushRuntime") or workspace:FindFirstChild("HushRuntime")
	if v47 then
		v47 = v47:FindFirstChild("Raid")
	end
	if v47 then
		v47 = v47:GetAttribute("RaidId")
	end
	return type(v47) ~= "string" and "" or string.sub(v47, 1, 64)
end
local function v_u_52(p49, p50) -- name: getRemote
	-- upvalues: (copy) v_u_2
	local v51 = v_u_2:FindFirstChild("HushNet") or v_u_2:WaitForChild("HushNet", 10)
	if v51 then
		v51 = v51:FindFirstChild(p49) or v51:WaitForChild(p49, 10)
	end
	if v51 and v51:IsA(p50) then
		return v51
	else
		return nil
	end
end
local function v_u_61(p53, p54) -- name: callGet
	-- upvalues: (copy) v_u_52
	local v_u_55 = v_u_52("menu.get", "RemoteFunction")
	if not v_u_55 then
		return {
			["ok"] = false,
			["msg"] = "No answer from the server."
		}
	end
	local v_u_56 = {
		["what"] = p53
	}
	if type(p54) == "table" then
		for v57, v58 in p54 do
			v_u_56[v57] = v58
		end
	end
	local v59, v60 = pcall(function()
		-- upvalues: (copy) v_u_55, (copy) v_u_56
		return v_u_55:InvokeServer(v_u_56)
	end)
	return (not v59 or type(v60) ~= "table") and {
		["ok"] = false,
		["msg"] = "No answer from the server."
	} or (v60.error ~= nil and {
		["ok"] = false,
		["msg"] = "Too fast. Wait a moment."
	} or v60)
end
local v_u_62 = nil
local v_u_63 = nil
local v_u_64 = nil
local v_u_65 = nil
local v_u_66 = nil
local v_u_67 = nil
local function v_u_75(p68) -- name: hintFor
	-- upvalues: (ref) v_u_17
	local v_u_69 = v_u_17 and v_u_17.controllers
	if v_u_69 then
		v_u_69 = v_u_17.controllers.Input
	end
	if v_u_69 == nil or v_u_69.hint == nil then
		return nil
	else
		local v70, v71 = pcall(function()
			-- upvalues: (copy) v_u_69
			if v_u_69.device == nil then
				return nil
			else
				return v_u_69.device()
			end
		end)
		if v70 and v71 == "Touch" then
			return nil
		else
			local v72 = v_u_69.hint
			local v73, v74 = pcall(v72, p68)
			if v73 and (type(v74) == "string" and v74 ~= "") then
				return v74
			else
				return nil
			end
		end
	end
end
local v_u_76 = {
	["NORMAL"] = "Light as in the raid.",
	["BRIGHT"] = "Brighter view.",
	["DAY"] = "Daylight view."
}
local v_u_77 = {
	["RAID"] = "Time of day as in the raid.",
	["DAY"] = "Day for you only.",
	["DUSK"] = "Dusk for you only.",
	["NIGHT"] = "Night for you only."
}
local v_u_78 = {
	["OFF"] = "Camera light off.",
	["NARROW"] = "Camera light: narrow beam.",
	["WIDE"] = "Camera light: wide beam.",
	["FLOOD"] = "Camera light: flood."
}
local function v_u_96(p79) -- name: buttonAction
	-- upvalues: (copy) v_u_32, (ref) v_u_7, (copy) v_u_2, (ref) v_u_20, (ref) v_u_17, (copy) v_u_75, (copy) v_u_76, (copy) v_u_77, (copy) v_u_78, (ref) v_u_63, (ref) v_u_64, (ref) v_u_62
	local v80 = v_u_32()
	local v81
	if v_u_7.rules == nil then
		v81 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v81 = v_u_7.rules
	end
	local v82 = v81.BUTTONS[p79]
	if v82 == "CAMERA" then
		if v_u_20.streams == false and v80.Camera.mode() == "FREE" then
			if v_u_20 then
				v_u_20.toast = "NO CAMERA STREAM FROM HIM, FREE CAMERA ONLY"
				v_u_20.toastUntil = os.clock() + 4
				v_u_20.sig = ""
			end
		else
			local v83 = v80.Camera.toggle() == "FREE" and "Free camera. Turn and zoom round him." or "Following his camera."
			if v_u_20 then
				v_u_20.toast = v83
				v_u_20.toastUntil = os.clock() + 3
				v_u_20.sig = ""
			end
		end
	elseif v82 == "ESP" then
		v_u_20.espOn = not v_u_20.espOn
		v80.Esp.setOn(v_u_20.espOn)
		v80.Trail.setOn(v_u_20.espOn)
		local v84 = v_u_20.espOn and "ESP and trail on." or "ESP and trail off."
		if v_u_20 then
			v_u_20.toast = v84
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
	elseif v82 == "VISION" then
		v_u_20.visionOn = not v_u_20.visionOn
		local v85 = v_u_17 and v_u_17.controllers
		if v85 then
			v85 = v_u_17.controllers.Vision
		end
		if v85 and v85.setEnabled then
			local v86 = v85.setEnabled
			local v87 = v_u_20.visionOn
			pcall(v86, v87)
		end
		local v88 = v_u_20.visionOn and "You see what he sees." or "You see the whole world."
		if v_u_20 then
			v_u_20.toast = v88
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
	elseif v82 == "LIGHT" then
		local v89 = v80.Light.cycleLevel()
		local v90 = v_u_75("nightVision")
		local v91 = (v_u_76[v89] or "Light changed.") .. (not v90 and "" or " " .. v90 .. " changes it.")
		if v_u_20 then
			v_u_20.toast = v91
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
	elseif v82 == "TIME" then
		local v92 = v_u_77[v80.Light.cycleTime()] or "Time of day changed."
		if v_u_20 then
			v_u_20.toast = v92
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
	elseif v82 == "TORCH" then
		local v93 = v80.Light.cycleTorch()
		local v94 = v_u_75("flashlight")
		local v95 = (v_u_78[v93] or "Camera light changed.") .. (not v94 and "" or " " .. v94 .. " changes it.")
		if v_u_20 then
			v_u_20.toast = v95
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
	elseif v82 == "MARK" then
		v_u_63()
	elseif v82 == "VERDICT" then
		v_u_64()
	elseif v82 == "LEAVE" then
		v_u_62()
	end
	v_u_20.sig = ""
end
local function v_u_99(p97) -- name: padAction
	-- upvalues: (copy) v_u_32
	local v98 = v_u_32()
	if p97 == "left" then
		v98.Camera.turn(-1)
		return
	elseif p97 == "right" then
		v98.Camera.turn(1)
		return
	elseif p97 == "closer" then
		v98.Camera.zoom(-1)
	elseif p97 == "farther" then
		v98.Camera.zoom(1)
	end
end
local function v_u_101() -- name: clearHud
	-- upvalues: (ref) v_u_20
	if v_u_20 and v_u_20.holder then
		for _, v100 in v_u_20.holder:GetChildren() do
			if v100.Name == "Roster" then
				continue
			end
			v100:Destroy()
		end
	end
	if v_u_20 then
		v_u_20.refs = {}
	end
end
local function v_u_107(p102) -- name: trackPress
	-- upvalues: (ref) v_u_20
	p102.InputBegan:Connect(function(p103)
		-- upvalues: (ref) v_u_20
		local v104 = p103.UserInputType
		if v_u_20 ~= nil and (v104 == Enum.UserInputType.Touch or v104 == Enum.UserInputType.MouseButton1) then
			v_u_20.pressAt = os.clock()
		end
	end)
	p102.InputEnded:Connect(function(p105)
		-- upvalues: (ref) v_u_20
		local v106 = p105.UserInputType
		if v_u_20 ~= nil and (v106 == Enum.UserInputType.Touch or v106 == Enum.UserInputType.MouseButton1) then
			v_u_20.pressAt = nil
		end
	end)
end
local function v_u_279(p108) -- name: draw
	-- upvalues: (copy) v_u_32, (ref) v_u_20, (copy) v_u_4, (copy) v_u_101, (copy) v_u_107, (copy) v_u_96, (copy) v_u_99, (copy) v_u_15, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67
	local v109 = v_u_32()
	local v_u_110 = v109.HushUI
	local v111 = v109.Layout
	local v_u_112 = v_u_110.Theme
	local v_u_113 = v_u_112.color
	local v114 = v_u_112.uiScale()
	local v_u_115 = math.max(v114, 0.1)
	local v116 = v_u_20.root.AbsoluteSize.X / v_u_115
	local v_u_117 = math.floor(v116)
	local v118 = v_u_20.root.AbsoluteSize.Y / v_u_115
	local v119 = math.floor(v118)
	local v_u_120 = v_u_110.safeInsets()
	local v121 = v_u_120.l / v_u_115
	local v_u_122 = math.floor(v121)
	local v123 = v_u_120.t / v_u_115
	local v_u_124 = math.floor(v123)
	local v125 = v_u_120.r / v_u_115
	local v_u_126 = math.floor(v125)
	local v127 = v_u_120.b / v_u_115
	local v128 = math.floor(v127)
	local v_u_129 = 0
	local v_u_130 = 0
	local v_u_131 = 0
	local v_u_132 = 0
	local function v143()
		-- upvalues: (ref) v_u_131, (copy) v_u_110, (copy) v_u_120, (ref) v_u_129, (copy) v_u_124, (ref) v_u_4, (ref) v_u_130, (copy) v_u_115, (copy) v_u_122, (ref) v_u_20, (copy) v_u_117, (copy) v_u_126, (ref) v_u_132
		local v133 = v_u_110.topInset() - v_u_120.t
		v_u_131 = math.max(0, v133)
		local v134 = v_u_131 - v_u_124
		v_u_129 = math.max(0, v134)
		local v135 = v_u_4.TopbarInset
		local v136 = ((v135.Width <= 0 or v135.Min.X <= 0) and 120 or v135.Min.X) / v_u_115
		local v137 = math.ceil(v136) - v_u_120.l - v_u_122
		v_u_130 = math.max(0, v137)
		if v135.Width > 0 and v135.Max.X > v135.Min.X then
			local v138 = v_u_20.root.AbsolutePosition.X
			local v139 = v_u_122
			local v140 = v_u_117 - v_u_122 - v_u_126
			local v141 = (v138 + (v139 + math.max(v140, 200)) * v_u_115 - v135.Max.X) / v_u_115
			local v142 = math.ceil(v141)
			v_u_132 = math.max(0, v142)
		end
	end
	pcall(v143)
	v_u_20.topPx = v_u_131
	if v_u_20.verdictHost ~= nil then
		v_u_20.verdictHost.Position = UDim2.fromOffset(0, v_u_131)
		v_u_20.verdictHost.Size = UDim2.new(1, 0, 1, -v_u_131)
	end
	local v144 = v111.opts(v_u_115, v_u_112.isTouch(), v_u_112.isPhone(), v_u_129, v_u_130, v_u_132)
	local v145 = v111.hud
	local v146 = v_u_117 - v_u_122 - v_u_126
	local v147 = math.max(v146, 200)
	local v148 = v119 - v_u_124 - v128
	local v149 = v145(v147, math.max(v148, 160), v144, p108)
	v_u_20.parts = v149
	v_u_101()
	local v_u_150 = v_u_20.holder
	v_u_150.Position = UDim2.fromOffset(v_u_122, v_u_124)
	local v151 = UDim2.fromOffset
	local v152 = v_u_117 - v_u_122 - v_u_126
	local v153 = math.max(v152, 200)
	local v154 = v119 - v_u_124 - v128
	v_u_150.Size = v151(v153, (math.max(v154, 160)))
	local v155 = v_u_110.new
	local v156 = {
		["Name"] = "Info",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_113.bg
	}
	local v157 = v149.info.rect
	v156.Position = UDim2.fromOffset(v157.x, v157.y)
	local v158 = v149.info.rect
	v156.Size = UDim2.fromOffset(v158.w, v158.h)
	local v159 = v155("Frame", v156, v_u_150)
	v_u_110.stroke(v159, v_u_113.line, 1, 0)
	local function v_u_168(p160, p161, p162, p163, p164, p165, p166, p167) -- name: label
		-- upvalues: (copy) v_u_110, (copy) v_u_112
		return v_u_110.new("TextLabel", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Text"] = nil,
			["TextTruncate"] = nil,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["ZIndex"] = 3,
			["Name"] = p161,
			["FontFace"] = p166 or v_u_112.font.body,
			["TextSize"] = p164,
			["TextColor3"] = p165,
			["Text"] = p163,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["TextXAlignment"] = p167 or Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Center,
			["Position"] = UDim2.fromOffset(p162.x, p162.y),
			["Size"] = UDim2.fromOffset(p162.w, p162.h)
		}, p160)
	end
	for _, v169 in v149.info.rows do
		if v169.key == "link" then
			local v170 = v_u_110.new
			local v171 = "Frame"
			local v172 = {
				["Name"] = "Light",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3
			}
			local v173 = p108.light
			local v174 = v_u_112.color
			local v175
			if v173 == "green" then
				v175 = v174.success
			elseif v173 == "red" then
				v175 = v174.danger
			else
				v175 = v174.accent
			end
			v172.BackgroundColor3 = v175
			local v176 = v169.dot
			v172.Position = UDim2.fromOffset(v176.x, v176.y)
			local v177 = v169.dot
			v172.Size = UDim2.fromOffset(v177.w, v177.h)
			v170(v171, v172, v159).Name = "Light"
		end
		local v178
		if v169.key == "name" then
			v178 = v_u_113.accent
		elseif v169.key == "link" then
			local v179 = p108.light
			local v180 = v_u_112.color
			if v179 == "green" then
				v178 = v180.success
			elseif v179 == "red" then
				v178 = v180.danger
			else
				v178 = v180.accent
			end
		elseif v169.key == "weapon" or v169.key == "hp" then
			v178 = v_u_113.text
		else
			v178 = v_u_113.text2
		end
		local v181
		if v169.key == "name" then
			v181 = v_u_112.font.headingBold
		else
			v181 = v_u_112.font.body
		end
		local v182 = v_u_168(v159, "Row_" .. v169.key, v169.rect, v169.text, v169.size, v178, v181)
		if v169.key ~= "shots" then
			continue
		end
		v182.TextWrapped = true
		v182.TextTruncate = Enum.TextTruncate.None
		v182.TextYAlignment = Enum.TextYAlignment.Top
	end
	if v149.events then
		local v183 = v_u_110.new
		local v184 = {
			["Name"] = "Events",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_113.bg
		}
		local v185 = v149.events.rect
		v184.Position = UDim2.fromOffset(v185.x, v185.y)
		local v186 = v149.events.rect
		v184.Size = UDim2.fromOffset(v186.w, v186.h)
		local v187 = v183("Frame", v184, v_u_150)
		v_u_110.stroke(v187, v_u_113.line, 1, 0)
		v_u_168(v187, "Header", v149.events.header, "ANTI CHEAT EVENTS", v149.events.size, v_u_113.accent, v_u_112.font.heading)
		for v188, v189 in v149.events.lines do
			v_u_168(v187, "Line" .. v188, v189.rect, v189.text, v149.events.size, v_u_113.text2)
		end
	end
	local v190 = v_u_110.new
	local v191 = {
		["Name"] = "Strip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_113.bg
	}
	local v192 = v149.strip.rect
	v191.Position = UDim2.fromOffset(v192.x, v192.y)
	local v193 = v149.strip.rect
	v191.Size = UDim2.fromOffset(v193.w, v193.h)
	local v194 = v190("Frame", v191, v_u_150)
	v_u_110.stroke(v194, v_u_113.line, 1, 0)
	local v195
	if string.find(p108.status, "NO SIGNAL", 1, true) then
		v195 = v_u_113.danger
	elseif string.find(p108.status, "LAGGING", 1, true) then
		v195 = v_u_113.accent
	else
		v195 = v_u_113.text
	end
	v_u_168(v194, "Text", {
		["x"] = 8,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["w"] = v149.strip.rect.w - 16,
		["h"] = v149.strip.rect.h
	}, v149.strip.text, v149.strip.size, v195, v_u_112.font.heading, Enum.TextXAlignment.Center)
	for v_u_196, v197 in v149.bar.rects do
		local v198 = p108.keys[v_u_196]
		local v199 = v198 == "VERDICT"
		local v200 = p108.on[v198] == true
		local v201
		if v199 then
			v201 = v_u_113.accent
		elseif v200 then
			v201 = v_u_113.accentDeep
		else
			v201 = v_u_113.raised
		end
		local v202
		if v199 then
			v202 = v_u_113.ink
		else
			v202 = v_u_113.text
		end
		local v203 = v_u_110.new("TextButton", {
			["Name"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Text"] = "",
			["Position"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["ZIndex"] = 3,
			["Name"] = "Btn" .. v_u_196,
			["BackgroundColor3"] = v201,
			["Position"] = UDim2.fromOffset(v197.x, v197.y),
			["Size"] = UDim2.fromOffset(v197.w, v197.h)
		}, v_u_150)
		local v204 = v_u_110.stroke
		local v205
		if v199 or v200 then
			v205 = v_u_113.accent
		else
			v205 = v_u_113.line
		end
		v204(v203, v205, 1, 0)
		v_u_168(v203, "Text", {
			["x"] = 6,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v197.w - 12,
			["h"] = v197.h
		}, v149.bar.labels[v_u_196], v149.bar.size, v202, v_u_112.font.heading, Enum.TextXAlignment.Center).ZIndex = 4
		v_u_107(v203)
		v203.Activated:Connect(function()
			-- upvalues: (ref) v_u_96, (copy) v_u_196
			v_u_96(v_u_196)
		end)
	end
	if v149.pad then
		local v206 = {
			["left"] = "<",
			["right"] = ">",
			["closer"] = "IN",
			["farther"] = "OUT"
		}
		for v207, v208 in v149.pad.buttons do
			local v_u_209 = v149.pad.names[v207]
			local v210 = v_u_110.new("TextButton", {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Name"] = "Pad_" .. v_u_209,
				["BackgroundColor3"] = v_u_113.raised,
				["Position"] = UDim2.fromOffset(v208.x, v208.y),
				["Size"] = UDim2.fromOffset(v208.w, v208.h)
			}, v_u_150)
			v210.Position = UDim2.fromOffset(v149.pad.rect.x + v208.x, v149.pad.rect.y + v208.y)
			v_u_110.stroke(v210, v_u_113.line, 1, 0)
			v_u_168(v210, "Text", {
				["x"] = 2,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v208.w - 4,
				["h"] = v208.h
			}, v206[v_u_209], v149.small + 2, v_u_113.text, v_u_112.font.headingBold, Enum.TextXAlignment.Center).ZIndex = 4
			v_u_107(v210)
			v210.Activated:Connect(function()
				-- upvalues: (ref) v_u_99, (copy) v_u_209
				v_u_99(v_u_209)
			end)
		end
	end
	local v211 = v_u_15()
	if v149.sw then
		local v_u_212 = v149.sw
		local function v230(p213, p214, p215, p216, p217) -- name: swButton
			-- upvalues: (copy) v_u_110, (copy) v_u_113, (copy) v_u_150, (copy) v_u_168, (copy) v_u_212, (copy) v_u_112, (ref) v_u_107
			local v218 = v_u_110.new
			local v219 = "TextButton"
			local v220 = {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["Position"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["ZIndex"] = 3,
				["Name"] = p213
			}
			local v221
			if p216 then
				v221 = v_u_113.raised
			else
				v221 = v_u_113.bg
			end
			v220.BackgroundColor3 = v221
			v220.Position = UDim2.fromOffset(p214.x, p214.y)
			v220.Size = UDim2.fromOffset(p214.w, p214.h)
			local v222 = v218(v219, v220, v_u_150)
			local v223 = v_u_110.stroke
			local v224
			if p216 then
				v224 = v_u_113.accent
			else
				v224 = v_u_113.line
			end
			v223(v222, v224, 1, 0)
			local v225 = v_u_168
			local v226 = "Text"
			local v227 = {
				["x"] = 2,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p214.w - 4,
				["h"] = p214.h
			}
			local v228 = v_u_212.size + 2
			local v229
			if p216 then
				v229 = v_u_113.text
			else
				v229 = v_u_113.text2
			end
			v225(v222, v226, v227, p215, v228, v229, v_u_112.font.headingBold, Enum.TextXAlignment.Center).ZIndex = 4
			v_u_107(v222)
			v222.Activated:Connect(p217)
		end
		v230("SwPrev", v_u_212.prev, v_u_212.labels.prev, v_u_212.canPrev, function()
			-- upvalues: (ref) v_u_65
			v_u_65(-1)
		end)
		v230("SwNext", v_u_212.next, v_u_212.labels.next, v_u_212.canNext, function()
			-- upvalues: (ref) v_u_65
			v_u_65(1)
		end)
		v230("SwList", v_u_212.list, v_u_212.labels.list, true, v_u_66)
	end
	local v231 = v_u_150:FindFirstChild("Roster")
	local v232
	if v149.roster == nil then
		v232 = nil
	else
		v232 = v111.rosterSig(v149.roster)
	end
	if v149.roster == nil or (v231 == nil or v232 ~= v_u_20.rosterSigDrawn) then
		if v149.roster then
			local v233 = v149.roster
			if v231 ~= nil then
				local v234 = v231:FindFirstChild("RosterView")
				if v234 ~= nil then
					v_u_20.rosterY = v234.CanvasPosition.Y
				end
				v231:Destroy()
			end
			v_u_20.rosterSigDrawn = v232
			local v235 = v_u_110.new
			local v236 = {
				["Name"] = "Roster",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.04,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 10,
				["BackgroundColor3"] = v_u_113.bg
			}
			local v237 = v233.rect
			v236.Position = UDim2.fromOffset(v237.x, v237.y)
			local v238 = v233.rect
			v236.Size = UDim2.fromOffset(v238.w, v238.h)
			local v239 = v235("Frame", v236, v_u_150)
			v_u_110.stroke(v239, v_u_113.accent, 1, 0)
			v_u_168(v239, "Title", v233.title, v233.titleText, v233.size, v_u_113.accent, v_u_112.font.heading).ZIndex = 11
			local v240 = v_u_110.new
			local v241 = {
				["Name"] = "RosterClose",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["Position"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["ZIndex"] = 11,
				["BackgroundColor3"] = v_u_113.raised
			}
			local v242 = v233.close
			v241.Position = UDim2.fromOffset(v242.x, v242.y)
			local v243 = v233.close
			v241.Size = UDim2.fromOffset(v243.w, v243.h)
			local v244 = v240("TextButton", v241, v239)
			v_u_110.stroke(v244, v_u_113.line, 1, 0)
			v_u_168(v244, "Text", {
				["x"] = 4,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v233.close.w - 8,
				["h"] = v233.close.h
			}, v233.closeText, v233.small, v_u_113.text, v_u_112.font.heading, Enum.TextXAlignment.Center).ZIndex = 12
			v244.Activated:Connect(v_u_66)
			local v245 = v_u_110.new
			local v246 = {
				["Name"] = "RosterView",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["ScrollBarThickness"] = 4,
				["ScrollingDirection"] = nil,
				["ElasticBehavior"] = nil,
				["ZIndex"] = 11
			}
			local v247 = v233.view
			v246.Position = UDim2.fromOffset(v247.x, v247.y)
			local v248 = v233.view
			v246.Size = UDim2.fromOffset(v248.w, v248.h)
			v246.CanvasSize = UDim2.fromOffset(0, v233.canvasH)
			v246.ScrollingDirection = Enum.ScrollingDirection.Y
			v246.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
			local v249 = v245("ScrollingFrame", v246, v239)
			v249.CanvasPosition = Vector2.new(0, v_u_20.rosterY or 0)
			for v250, v_u_251 in v233.items do
				local v252 = v_u_110.new
				local v253 = "TextButton"
				local v254 = {
					["Name"] = nil,
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Text"] = "",
					["Position"] = nil,
					["Size"] = nil,
					["Selectable"] = true,
					["ZIndex"] = 12,
					["Name"] = "Player" .. v250
				}
				local v255
				if v_u_251.current then
					v255 = v_u_113.accentDeep
				else
					v255 = v_u_113.raised
				end
				v254.BackgroundColor3 = v255
				local v256 = v_u_251.rect
				v254.Position = UDim2.fromOffset(v256.x, v256.y)
				local v257 = v_u_251.rect
				v254.Size = UDim2.fromOffset(v257.w, v257.h)
				local v258 = v252(v253, v254, v249)
				local v259 = v_u_110.stroke
				local v260
				if v_u_251.current then
					v260 = v_u_113.accent
				else
					v260 = v_u_113.line
				end
				v259(v258, v260, 1, 0)
				local v261 = v_u_110.new
				local v262 = "Frame"
				local v263 = {
					["Name"] = "Chip",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 13
				}
				local v264 = v_u_251.hue
				local v265 = v211.PALETTE[v264]
				local v266
				if v265 then
					v266 = Color3.fromRGB(v265[1], v265[2], v265[3])
				else
					v266 = v_u_113.text2
				end
				v263.BackgroundColor3 = v266
				v263.BackgroundTransparency = v_u_251.targetable and 0 or 0.6
				local v267 = v_u_251.chip
				v263.Position = UDim2.fromOffset(v267.x, v267.y)
				local v268 = v_u_251.chip
				v263.Size = UDim2.fromOffset(v268.w, v268.h)
				v261(v262, v263, v258).Name = "Chip"
				local v269 = "Name"
				local v270 = v_u_251.name
				local v271 = v_u_251.text
				local v272 = v233.size
				local v273
				if v_u_251.targetable then
					v273 = v_u_113.text
				else
					v273 = v_u_113.text2
				end
				v_u_168(v258, v269, v270, v271, v272, v273, v_u_112.font.body).ZIndex = 13
				local v274 = "Word"
				local v275 = v_u_251.word
				local v276 = v_u_251.wordText
				local v277 = v233.small
				local v278
				if v_u_251.targetable then
					v278 = v_u_113.success
				else
					v278 = v_u_113.text2
				end
				v_u_168(v258, v274, v275, v276, v277, v278, v_u_112.font.heading, Enum.TextXAlignment.Right).ZIndex = 13
				v258.Activated:Connect(function()
					-- upvalues: (ref) v_u_67, (copy) v_u_251
					v_u_67(v_u_251.userId)
				end)
			end
		else
			if v231 ~= nil then
				v231:Destroy()
			end
			v_u_20.rosterSigDrawn = nil
		end
	end
end
local function v_u_288() -- name: collectRoster
	-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_16, (ref) v_u_20
	local v280 = v_u_15()
	if v280 == nil then
		return nil
	end
	local v281 = {}
	for _, v282 in v_u_1:GetPlayers() do
		if v282 == v_u_16 then
			continue
		end
		local v283 = v282:GetAttribute("SquadId")
		if type(v283) ~= "string" and v282.Character ~= nil then
			v283 = v282.Character:GetAttribute("SquadId")
		end
		local v284 = v280.entry
		local v285 = {
			["userId"] = v282.UserId
		}
		local v286
		if v282.DisplayName == "" then
			v286 = v282.Name
		else
			v286 = v282.DisplayName
		end
		v285.name = v286
		v285.squad = v283
		v285.status = v282:GetAttribute("RaidStatus")
		v285.place = v282:GetAttribute("Place")
		local v287 = v284(v285)
		if v287 == nil then
			continue
		end
		table.insert(v281, v287)
	end
	return v280.roster(v281, v_u_20.userId)
end
local function v_u_340(p289) -- name: refreshHud
	-- upvalues: (ref) v_u_20, (copy) v_u_32, (ref) v_u_7, (copy) v_u_2, (copy) v_u_15, (copy) v_u_288, (copy) v_u_4, (copy) v_u_279
	if v_u_20 and v_u_20.holder then
		local v290 = v_u_32()
		local v291
		if v_u_7.rules == nil then
			v291 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v291 = v_u_7.rules
		end
		local v292 = os.clock()
		if v_u_20.toast ~= "" and v_u_20.toastUntil <= v292 then
			v_u_20.toast = ""
		end
		local v293 = v_u_15()
		local v294 = v_u_288()
		v_u_20.roster = v294
		local v295, v296
		if v293 == nil or v294 == nil then
			v295 = nil
			v296 = 0
		else
			v295 = v293.lost(v294, v_u_20.userId)
			v296 = v294.targetable - ((v294.current == nil or not v294.current.targetable) and 0 or 1)
		end
		local v297 = v290.Camera.follow()
		if v297 ~= nil then
			local v298, v299 = v290.Cone.hudFacts()
			local v300 = v_u_20.folView
			if v300 == nil then
				v300 = {}
				v_u_20.folView = v300
			end
			v297 = v291.hudFollow(v300, v297, v298, v299)
		end
		local v301 = v291.hudSpec({
			["name"] = v_u_20.name,
			["info"] = v_u_20.info,
			["follow"] = v297,
			["status"] = v290.Camera.status(),
			["mode"] = v290.Camera.mode(),
			["espOn"] = v_u_20.espOn,
			["visionOn"] = v_u_20.visionOn,
			["light"] = v290.Light.words(),
			["toast"] = v_u_20.toast,
			["watched"] = v291.watchSeconds(v_u_20.watch, v292)
		})
		if v_u_20.toast == "" then
			local v302
			if v293 == nil then
				v302 = nil
			else
				v302 = v293.lostText(v295, v296)
			end
			if v302 == nil then
				if v_u_20.listed == false then
					v301.status = v301.status .. "   NOT ON THE WATCH LIST"
				end
			else
				v301.status = v302
			end
		end
		local v303 = {}
		local v304 = v_u_20.listed
		__set_list(v303, 1, {(tostring(v304))})
		if v293 ~= nil and v294 ~= nil then
			local v305 = v293.step(v294, v_u_20.userId, -1) ~= nil
			local v306 = v293.step(v294, v_u_20.userId, 1) ~= nil
			v301.sw = {
				["prev"] = "<",
				["next"] = ">",
				["list"] = "LIST",
				["canPrev"] = nil,
				["canNext"] = nil,
				["canPrev"] = v305,
				["canNext"] = v306
			}
			local v307 = v_u_20.rosterOpen
			local v308 = tostring(v307)
			table.insert(v303, v308)
			local v309 = tostring(v305)
			table.insert(v303, v309)
			local v310 = tostring(v306)
			table.insert(v303, v310)
			local v311 = tostring(v295)
			table.insert(v303, v311)
			for _, v312 in v294.list do
				local v313 = v312.userId .. v312.status .. v312.squad .. v312.name .. (v312.current and "*" or "")
				table.insert(v303, v313)
			end
			if v_u_20.rosterOpen then
				local v314 = {}
				for _, v315 in v294.list do
					local v316 = {
						["userId"] = v315.userId,
						["name"] = v315.name,
						["hue"] = v315.hue,
						["word"] = v315.word,
						["current"] = v315.current,
						["targetable"] = v315.targetable
					}
					table.insert(v314, v316)
				end
				v301.roster = {
					["title"] = nil,
					["close"] = "CLOSE",
					["rows"] = nil,
					["title"] = "PLAYERS " .. v293.countText(v294, v_u_20.userId),
					["rows"] = v314
				}
			end
		end
		v_u_20.swSig = table.concat(v303, ",")
		local v317 = table.concat
		local v318 = {}
		local v319 = v301.name
		local v320 = v301.link
		local v321 = v301.light
		local v322 = v301.weapon
		local v323 = v301.hp
		local v324 = v301.speed
		local v325 = v301.shots
		local v326 = table.concat(v301.events, "|")
		local v327 = table.concat(v301.buttons, "|")
		local v328 = v301.status
		local v329 = v301.pad
		local v330 = tostring(v329)
		local v331 = v_u_20.root.AbsoluteSize.X
		local v332 = tostring(v331)
		local v333 = v_u_20.root.AbsoluteSize.Y
		local v334 = tostring(v333)
		local v_u_335 = 0
		local function v337()
			-- upvalues: (ref) v_u_4, (ref) v_u_335
			local v336 = v_u_4.TopbarInset
			v_u_335 = v336.Max.Y * 1000 + v336.Min.X
		end
		pcall(v337)
		local v338 = v_u_335
		__set_list(v318, 1, {v319, v320, v321, v322, v323, v324, v325, v326, v327, v328, v330, v332, v334, tostring(v338), v_u_20.swSig})
		local v339 = v317(v318, "\n")
		if p289 or v339 ~= v_u_20.sig then
			if v_u_20.pressAt ~= nil and os.clock() - v_u_20.pressAt < 1.2 then
				return
			end
			v_u_20.sig = v339
			v_u_279(v301)
		end
	end
end
v_u_63 = function()
	-- upvalues: (ref) v_u_7, (copy) v_u_2, (ref) v_u_20
	local v341
	if v_u_7.rules == nil then
		v341 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v341 = v_u_7.rules
	end
	local v342
	if v_u_7.rules == nil then
		v342 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v342 = v_u_7.rules
	end
	local v343
	if v_u_20.info and v_u_20.info.rt then
		v343 = v_u_20.info.rt
	else
		v343 = v342.watchSeconds(v_u_20.watch, os.clock())
	end
	local v344 = ""
	local v345 = v_u_20.info and v_u_20.info.ev
	if v345 then
		v345 = v_u_20.info.ev[#v_u_20.info.ev]
	end
	if v345 then
		local v346 = v345.t
		if type(v346) == "number" and v343 - v345.t <= 10 then
			v344 = v341.sentence(v345.c)
		end
	end
	local _, v347 = v341.addMoment(v_u_20.moments, v343, v344)
	if v_u_20 then
		v_u_20.toast = v347
		v_u_20.toastUntil = os.clock() + 3
		v_u_20.sig = ""
	end
end
v_u_64 = function()
	-- upvalues: (copy) v_u_32, (ref) v_u_20, (ref) v_u_7, (copy) v_u_2, (ref) v_u_17, (copy) v_u_48
	local v348 = v_u_32()
	if v348.Panel.isOpen() then
		return
	elseif v_u_20.listed == false then
		if v_u_20 then
			v_u_20.toast = "HE IS NOT ON THE WATCH LIST, NO VERDICT"
			v_u_20.toastUntil = os.clock() + 4
			v_u_20.sig = ""
		end
	else
		local v_u_349
		if v_u_7.rules == nil then
			v_u_349 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v_u_349 = v_u_7.rules
		end
		local v350 = v_u_20.topPx or 0
		local v351 = v_u_20.verdictHost
		if v351 == nil or v351.Parent == nil then
			v351 = v348.HushUI.new("Frame", {
				["Name"] = "VerdictHost",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 59,
				["Position"] = UDim2.fromOffset(0, v350),
				["Size"] = UDim2.new(1, 0, 1, -v350)
			}, v_u_20.root)
			v_u_20.verdictHost = v351
		else
			v351.Position = UDim2.fromOffset(0, v350)
			v351.Size = UDim2.new(1, 0, 1, -v350)
		end
		v348.Panel.open({
			["root"] = v351,
			["cctx"] = v_u_17,
			["target"] = {
				["userId"] = v_u_20.userId,
				["name"] = v_u_20.name
			},
			["watchSeconds"] = function() -- name: watchSeconds
				-- upvalues: (copy) v_u_349, (ref) v_u_20
				return v_u_349.watchSeconds(v_u_20.watch, os.clock())
			end,
			["raidId"] = v_u_48,
			["moments"] = v_u_20.moments,
			["minWatch"] = v_u_20.minWatch,
			["onSent"] = function(p352) -- name: onSent
				-- upvalues: (ref) v_u_20
				v_u_20.moments = {}
				local v353 = p352.msg or "Verdict saved."
				local v354 = tostring(v353)
				if v_u_20 then
					v_u_20.toast = v354
					v_u_20.toastUntil = os.clock() + 4
					v_u_20.sig = ""
				end
			end
		})
	end
end
v_u_62 = function()
	-- upvalues: (ref) v_u_20, (copy) v_u_61
	if not v_u_20.leaving then
		v_u_20.leaving = true
		if v_u_20 then
			v_u_20.toast = "Leaving ..."
			v_u_20.toastUntil = os.clock() + 6
			v_u_20.sig = ""
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_61, (ref) v_u_20
			local v355 = v_u_61("reviewLeave", {
				["target"] = v_u_20.userId
			})
			if v_u_20 ~= nil then
				v_u_20.leaving = false
				if v355.ok == true then
					local v356 = v355.msg or "Left."
					local v357 = tostring(v356)
					if v_u_20 then
						v_u_20.toast = v357
						v_u_20.toastUntil = os.clock() + 3
						v_u_20.sig = ""
						return
					end
				else
					local v358 = v355.msg or "Leaving is not available on this server yet."
					local v359 = tostring(v358)
					if v_u_20 then
						v_u_20.toast = v359
						v_u_20.toastUntil = os.clock() + 5
						v_u_20.sig = ""
					end
				end
			end
		end)
	end
end
v_u_67 = function(p_u_360)
	-- upvalues: (ref) v_u_20, (copy) v_u_32, (copy) v_u_61, (copy) v_u_75
	if v_u_20 == nil or v_u_20.switching then
		return
	elseif v_u_32().Panel.isOpen() then
		if v_u_20 then
			v_u_20.toast = "Close the verdict window first."
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
		return
	elseif p_u_360 == v_u_20.userId and (v_u_20.roster ~= nil and (v_u_20.roster.current ~= nil and v_u_20.roster.current.targetable)) then
		if v_u_20 then
			v_u_20.toast = "You are watching him already."
			v_u_20.toastUntil = os.clock() + 3
			v_u_20.sig = ""
		end
		v_u_20.rosterOpen = false
		v_u_20.sig = ""
	else
		local v_u_361 = v_u_20
		v_u_361.switching = true
		task.spawn(function()
			-- upvalues: (ref) v_u_61, (copy) p_u_360, (ref) v_u_20, (copy) v_u_361, (ref) v_u_75
			local v362 = v_u_61("reviewSwitch", {
				["target"] = p_u_360
			})
			if v_u_20 == v_u_361 then
				v_u_361.switching = false
				v_u_361.rosterOpen = false
				local v363 = v_u_75("inventory")
				local v364 = v362.msg or "Could not switch."
				local v365 = tostring(v364) .. ((v362.ok ~= true or not v363) and "" or " " .. v363 .. " for the next player.")
				if v_u_20 then
					v_u_20.toast = v365
					v_u_20.toastUntil = os.clock() + 4
					v_u_20.sig = ""
				end
			end
		end)
	end
end
v_u_65 = function(p366)
	-- upvalues: (ref) v_u_20, (copy) v_u_15, (copy) v_u_288, (ref) v_u_67
	if v_u_20 == nil then
		return
	else
		local v367 = v_u_15()
		local v368 = v_u_20.roster or v_u_288()
		if v367 == nil or v368 == nil then
			if v_u_20 then
				v_u_20.toast = "The player switch is not available here."
				v_u_20.toastUntil = os.clock() + 3
				v_u_20.sig = ""
			end
			return
		else
			local v369 = v367.step(v368, v_u_20.userId, p366)
			if v369 == nil then
				if v_u_20 then
					v_u_20.toast = "NOBODY ELSE TO WATCH"
					v_u_20.toastUntil = os.clock() + 3
					v_u_20.sig = ""
				end
			else
				v_u_67(v369)
			end
		end
	end
end
v_u_66 = function()
	-- upvalues: (ref) v_u_20
	if v_u_20 ~= nil then
		v_u_20.rosterOpen = not v_u_20.rosterOpen
		v_u_20.sig = ""
	end
end
local function v_u_373(p370) -- name: onInfo
	-- upvalues: (ref) v_u_20, (ref) v_u_7, (copy) v_u_2, (copy) v_u_32
	if v_u_20 then
		local v371
		if v_u_7.rules == nil then
			v371 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v371 = v_u_7.rules
		end
		local v372 = v371.cleanInfo(p370)
		if v372 then
			if v372.t ~= nil and v372.t ~= v_u_20.userId then
				return
			end
			if v372.ls ~= nil then
				v_u_20.listed = v372.ls == 1
			end
			if v372.sx ~= nil then
				v_u_20.streams = v372.sx == 1
			end
			v_u_20.info = v372
			if v372.px ~= nil then
				v_u_32().Camera.noteInfoRoot(v372.px, v372.py, v372.pz)
			end
		end
	end
end
local function v_u_394() -- name: publish
	-- upvalues: (copy) v_u_3, (copy) v_u_16, (copy) v_u_32, (ref) v_u_19, (ref) v_u_20
	if v_u_3:IsStudio() and v_u_16 then
		local v374 = v_u_32()
		local v375 = v_u_16
		local v376 = "ReviewTools"
		local v377 = "on=%d|mode=%s|esp=%d|vision=%d|status=%s|moments=%d|panel=%d|used=%d|src=%s|trail=%d|light=%s|top=%d|tgt=%d|listed=%s|streams=%s|list=%d"
		local v378 = v_u_19 and 1 or 0
		local v379 = v374.Camera.mode()
		local v380 = v_u_20 and v_u_20.espOn and 1 or 0
		local v381 = v_u_20 and v_u_20.visionOn and 1 or 0
		local v382 = v374.Camera.status()
		local v383 = v_u_20 and #v_u_20.moments or 0
		local v384 = v374.Panel.isOpen() and 1 or 0
		local v385 = v374.Esp.count()
		local v386 = v374.Camera.source()
		local v387 = v374.Trail.count()
		local v388 = v374.Light.state()
		local v389 = not v_u_20 and 0 or v_u_20.topPx
		local v390 = not v_u_20 and 0 or v_u_20.userId
		local v391
		if v_u_20 then
			v391 = v_u_20.listed
		else
			v391 = nil
		end
		local v392 = tostring(v391)
		local v393
		if v_u_20 then
			v393 = v_u_20.streams
		else
			v393 = nil
		end
		v375:SetAttribute(v376, v377:format(v378, v379, v380, v381, v382, v383, v384, v385, v386, v387, v388, v389, v390, v392, tostring(v393), v_u_20 and v_u_20.rosterOpen and 1 or 0))
	end
end
function v_u_6.active() -- name: active
	-- upvalues: (ref) v_u_19
	return v_u_19
end
function v_u_6.state() -- name: state
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_32
	if not (v_u_19 and v_u_20) then
		return "off"
	end
	local v395 = v_u_32()
	local v396 = v_u_20.userId
	local v397 = v395.Camera.mode()
	local v398 = v395.Camera.status()
	local v399 = v_u_20.espOn
	return ("target=%d mode=%s status=%s esp=%s moments=%d src=%s trail=%d %s"):format(v396, v397, v398, tostring(v399), #v_u_20.moments, v395.Camera.source(), v395.Trail.count(), v395.Light.state())
end
local v_u_400 = false
local function v_u_418(p401) -- name: retarget
	-- upvalues: (copy) v_u_32, (ref) v_u_7, (copy) v_u_2, (ref) v_u_20, (copy) v_u_1, (copy) v_u_340, (copy) v_u_394
	local v402 = v_u_32()
	local v403
	if v_u_7.rules == nil then
		v403 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v403 = v_u_7.rules
	end
	local v404 = os.clock()
	v_u_20.momentsBy[v_u_20.userId] = v_u_20.moments
	v_u_20.watchBy[v_u_20.userId] = v_u_20.watch
	v403.watchOff(v_u_20.watch, v404)
	v_u_20.userId = p401
	local v405 = v_u_20
	local v406 = v_u_1:GetPlayerByUserId(v_u_20.userId)
	local v407
	if v406 then
		v407 = v406.DisplayName ~= "" and v406.DisplayName or v406.Name
	else
		local v408 = v_u_20.userId
		v407 = "PLAYER " .. tostring(v408)
	end
	v405.name = v407
	v_u_20.info = nil
	local v409 = v_u_20
	v_u_20.listed = nil
	v409.streams = nil
	v_u_20.moments = v_u_20.momentsBy[p401] or {}
	v_u_20.watch = v_u_20.watchBy[p401] or v403.watchNew()
	v_u_20.rosterOpen = false
	v_u_20.switching = false
	local v410 = v402.Camera.retarget
	pcall(v410, p401)
	local v411 = v402.Esp.stop
	pcall(v411)
	local v412 = v402.Esp.start
	pcall(v412, p401)
	local v413 = v402.Trail.stop
	pcall(v413)
	local v414 = v402.Trail.start
	pcall(v414)
	local v415 = v402.Trail.setOn
	local v416 = v_u_20.espOn
	pcall(v415, v416)
	v_u_20.sig = ""
	local v417 = v_u_340
	pcall(v417, true)
	v_u_394()
end
local function v_u_496(p_u_419) -- name: begin
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_418, (ref) v_u_400, (copy) v_u_2, (copy) v_u_373, (copy) v_u_6, (copy) v_u_43, (copy) v_u_32, (copy) v_u_46, (copy) v_u_1, (ref) v_u_17, (ref) v_u_7, (copy) v_u_96, (copy) v_u_5, (ref) v_u_65, (copy) v_u_4, (copy) v_u_3, (copy) v_u_340, (copy) v_u_16, (copy) v_u_48, (copy) v_u_394, (ref) v_u_66, (ref) v_u_67, (copy) v_u_61
	if v_u_19 and (v_u_20 and v_u_20.userId == p_u_419) then
		return
	elseif v_u_19 and v_u_20 ~= nil then
		v_u_418(p_u_419)
	else
		if not v_u_400 then
			v_u_400 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_373
				local v420 = v_u_2:WaitForChild("HushNet", 30)
				if v420 then
					v420 = v420:WaitForChild("rv.info", 60)
				end
				if v420 and v420:IsA("RemoteEvent") then
					v420.OnClientEvent:Connect(v_u_373)
				end
			end)
		end
		v_u_6.stop()
		v_u_43()
		local v_u_421 = v_u_32()
		local v422 = v_u_421.HushUI
		v_u_20 = v_u_46(p_u_419)
		local v423 = v_u_20
		local v424 = v_u_1:GetPlayerByUserId(v_u_20.userId)
		local v425
		if v424 then
			v425 = v424.DisplayName ~= "" and v424.DisplayName or v424.Name
		else
			local v426 = v_u_20.userId
			v425 = "PLAYER " .. tostring(v426)
		end
		v423.name = v425
		v_u_19 = true
		local v427 = v_u_20
		local v428 = v_u_20
		local v429, v430 = v422.screen("ReviewTools", 45)
		v427.gui = v429
		v428.root = v430
		v_u_20.holder = v422.new("Frame", {
			["Name"] = "Holder",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_20.root)
		v_u_20.verdictHost = v422.new("Frame", {
			["Name"] = "VerdictHost",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 59,
			["Position"] = UDim2.fromOffset(0, 0),
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_20.root)
		v_u_421.Camera.begin(p_u_419)
		v_u_421.Esp.start(p_u_419)
		v_u_421.Trail.start()
		v_u_421.Trail.setOn(v_u_20.espOn)
		v_u_421.Light.start(function()
			-- upvalues: (copy) v_u_421
			return v_u_421.Camera.focusPoint()
		end)
		v_u_421.Camera.onPacket(function(p431, p432)
			-- upvalues: (copy) v_u_421
			local v433
			if p431.px == nil then
				local v434 = v_u_421.Camera.targetRoot()
				if v434 then
					v433 = v434.Position
				else
					v433 = v_u_421.Camera.rootPosition()
				end
			else
				local v435 = p431.px
				local v436 = p431.py
				local v437 = p431.pz
				v433 = Vector3.new(v435, v436, v437)
			end
			if v433 ~= nil then
				v_u_421.Trail.push(p432, v433)
				if p431.m ~= nil then
					v_u_421.Esp.pushAim(p432, p431.m, v433)
				end
			end
		end)
		local v438 = v_u_17 and v_u_17.controllers
		if v438 then
			v438 = v_u_17.controllers.Input
		end
		if v438 ~= nil and v438.bind ~= nil then
			local v_u_439 = {}
			local v440
			if v_u_7.rules == nil then
				v440 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
			else
				v440 = v_u_7.rules
			end
			for v441, v442 in v440.BUTTONS do
				v_u_439[v442] = v441
			end
			for v443, v_u_444 in {
				["flashlight"] = "TORCH",
				["nightVision"] = "LIGHT"
			} do
				local v445 = v438.bind
				local function v446()
					-- upvalues: (ref) v_u_20, (ref) v_u_19, (copy) v_u_421, (ref) v_u_96, (copy) v_u_439, (copy) v_u_444
					if v_u_20 ~= nil and (v_u_19 and not v_u_421.Panel.isOpen()) then
						v_u_96(v_u_439[v_u_444])
					end
				end
				local v447, v448 = pcall(v445, v443, v446)
				if not v447 or type(v448) ~= "function" then
					continue
				end
				local v449 = v_u_20.unbinds
				table.insert(v449, v448)
			end
			for v_u_450, v_u_451 in {
				["inventory"] = 1,
				["melee"] = -1
			} do
				local v452 = v438.bind
				local function v454()
					-- upvalues: (ref) v_u_20, (ref) v_u_19, (copy) v_u_421, (copy) v_u_451, (copy) v_u_450, (ref) v_u_5, (ref) v_u_65
					if v_u_20 ~= nil and (v_u_19 and not v_u_421.Panel.isOpen()) then
						local v453 = v_u_451
						v_u_65(v_u_450 == "inventory" and v_u_5:IsKeyDown(Enum.KeyCode.LeftShift) and -1 or v453)
					end
				end
				local v455, v456 = pcall(v452, v_u_450, v454)
				if not v455 or type(v456) ~= "function" then
					continue
				end
				local v457 = v_u_20.unbinds
				table.insert(v457, v456)
			end
		end
		local v458 = v_u_20.conns
		local v459 = v_u_5.InputBegan
		local function v462(p460, p461)
			-- upvalues: (ref) v_u_20, (ref) v_u_19, (copy) v_u_421, (ref) v_u_65
			if p461 or (v_u_20 == nil or (not v_u_19 or v_u_421.Panel.isOpen())) then
				return
			elseif p460.KeyCode == Enum.KeyCode.Left then
				v_u_65(-1)
			elseif p460.KeyCode == Enum.KeyCode.Right then
				v_u_65(1)
			end
		end
		table.insert(v458, v459:Connect(v462))
		local v463 = v_u_20.conns
		local v464 = v_u_4:GetPropertyChangedSignal("TopbarInset")
		local function v465()
			-- upvalues: (ref) v_u_20
			v_u_20.sig = ""
		end
		table.insert(v463, v464:Connect(v465))
		local v466 = v_u_20.conns
		local v467 = v_u_20.root:GetPropertyChangedSignal("AbsoluteSize")
		local function v468()
			-- upvalues: (ref) v_u_20
			v_u_20.sig = ""
		end
		table.insert(v466, v467:Connect(v468))
		local v469 = v_u_20.conns
		local v470 = v422.Theme.scaleChanged
		local function v471()
			-- upvalues: (ref) v_u_20
			v_u_20.sig = ""
		end
		table.insert(v469, v470:Connect(v471))
		local v_u_472
		if v_u_7.rules == nil then
			v_u_472 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v_u_472 = v_u_7.rules
		end
		local v473 = v_u_20.conns
		local v474 = v_u_3.Heartbeat
		local function v486(p475)
			-- upvalues: (ref) v_u_20, (copy) v_u_421, (copy) v_u_472, (ref) v_u_1, (ref) v_u_340, (ref) v_u_16, (ref) v_u_48, (ref) v_u_394
			if v_u_20 then
				local v_u_476 = os.clock()
				if v_u_421.Camera.targetRoot() == nil then
					v_u_472.watchOff(v_u_20.watch, v_u_476)
				else
					v_u_472.watchOn(v_u_20.watch, v_u_476)
				end
				v_u_421.Esp.step(p475, v_u_421.Camera.rootPosition())
				v_u_421.Trail.step(p475)
				local v477 = v_u_20
				v477.hudAcc = v477.hudAcc + p475
				if v_u_20.hudAcc >= 0.25 then
					v_u_20.hudAcc = 0
					local v478 = v_u_20
					local v479 = v_u_1:GetPlayerByUserId(v_u_20.userId)
					local v480
					if v479 then
						v480 = v479.DisplayName ~= "" and v479.DisplayName or v479.Name
					else
						local v481 = v_u_20.userId
						v480 = "PLAYER " .. tostring(v481)
					end
					v478.name = v480
					if v_u_20.streams == false and v_u_421.Camera.mode() == "FOLLOW" then
						v_u_421.Camera.setMode("FREE")
						if v_u_20 then
							v_u_20.toast = "NO CAMERA STREAM FROM HIM, FREE CAMERA ONLY"
							v_u_20.toastUntil = os.clock() + 4
							v_u_20.sig = ""
						end
					end
					local v482 = v_u_340
					pcall(v482, false)
				end
				local v483 = v_u_20
				v483.pubAcc = v483.pubAcc + p475
				if v_u_20.pubAcc >= 1 then
					v_u_20.pubAcc = 0
					local function v485()
						-- upvalues: (ref) v_u_16, (ref) v_u_472, (ref) v_u_20, (copy) v_u_476, (ref) v_u_48
						v_u_16:SetAttribute("OverwatchWatchSeconds", v_u_472.watchSeconds(v_u_20.watch, v_u_476))
						local v484 = v_u_48()
						if v484 ~= "" then
							v_u_16:SetAttribute("OverwatchRaidId", v484)
						end
					end
					pcall(v485)
					v_u_394()
				end
			end
		end
		table.insert(v473, v474:Connect(v486))
		if v_u_3:IsStudio() then
			local v487 = v_u_20.conns
			local v488 = v_u_16:GetAttributeChangedSignal("ReviewToolsCmd")
			local function v493()
				-- upvalues: (ref) v_u_16, (ref) v_u_96, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (copy) v_u_421, (ref) v_u_394
				local v489 = v_u_16:GetAttribute("ReviewToolsCmd")
				if type(v489) == "string" and v489 ~= "" then
					v_u_16:SetAttribute("ReviewToolsCmd", nil)
					local v490, v491 = string.match(v489, "^(%a+)%s*(.-)$")
					local v492 = {
						["camera"] = 1,
						["esp"] = 2,
						["vision"] = 3,
						["light"] = 4,
						["time"] = 5,
						["torch"] = 6,
						["mark"] = 7,
						["verdict"] = 8,
						["leave"] = 9
					}
					if v492[v490] then
						v_u_96(v492[v490])
					elseif v490 == "next" then
						v_u_65(1)
					elseif v490 == "prev" then
						v_u_65(-1)
					elseif v490 == "list" then
						v_u_66()
					elseif v490 == "switch" then
						v_u_67(tonumber(v491) or 0)
					elseif v490 == "pick" then
						v_u_421.Panel.pick(v491)
					elseif v490 == "note" then
						v_u_421.Panel.note(v491)
					elseif v490 == "send" then
						v_u_421.Panel.send()
					elseif v490 == "cancel" then
						v_u_421.Panel.close()
					end
					v_u_394()
				end
			end
			table.insert(v487, v488:Connect(v493))
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_61, (ref) v_u_20, (copy) p_u_419
			local v494 = v_u_61("reviewList", {})
			if v_u_20 and (v_u_20.userId == p_u_419 and v494.ok == true) then
				local v495 = v494.minWatchSec
				if type(v495) == "number" then
					v_u_20.minWatch = v494.minWatchSec
				end
			end
		end)
		v_u_340(true)
		v_u_394()
	end
end
function v_u_6.stop() -- name: stop
	-- upvalues: (ref) v_u_19, (copy) v_u_32, (ref) v_u_20, (ref) v_u_17, (copy) v_u_16, (copy) v_u_394
	if v_u_19 then
		v_u_19 = false
		local v497 = v_u_32()
		local v498 = v497.Panel.close
		pcall(v498)
		local v499 = v497.Camera.finish
		pcall(v499)
		local v500 = v497.Camera.onPacket
		pcall(v500, nil)
		local v501 = v497.Esp.stop
		pcall(v501)
		local v502 = v497.Trail.stop
		pcall(v502)
		local v503 = v497.Light.stop
		pcall(v503)
		if v_u_20 then
			for _, v504 in v_u_20.conns do
				v504:Disconnect()
			end
			for _, v505 in v_u_20.unbinds do
				pcall(v505)
			end
			if not v_u_20.visionOn then
				local v506 = v_u_17 and v_u_17.controllers
				if v506 then
					v506 = v_u_17.controllers.Vision
				end
				if v506 and v506.setEnabled then
					local v507 = v506.setEnabled
					pcall(v507, true)
				end
			end
			if v_u_20.gui then
				v_u_20.gui:Destroy()
			end
		end
		local function v508()
			-- upvalues: (ref) v_u_16
			v_u_16:SetAttribute("OverwatchWatchSeconds", nil)
			v_u_16:SetAttribute("OverwatchRaidId", nil)
		end
		pcall(v508)
		v_u_20 = nil
		v_u_394()
	end
end
local function v_u_510() -- name: evaluate
	-- upvalues: (copy) v_u_16, (copy) v_u_496, (copy) v_u_6
	local v509 = v_u_16:GetAttribute("OverwatchTarget")
	if type(v509) == "number" and (v509 > 0 and v_u_16:GetAttribute("OverwatchReviewer") == true) then
		v_u_496(v509)
	else
		v_u_6.stop()
	end
end
function v_u_6.init(p511) -- name: init
	-- upvalues: (ref) v_u_18, (ref) v_u_17, (copy) v_u_32, (ref) v_u_400, (copy) v_u_2, (copy) v_u_373, (copy) v_u_16, (copy) v_u_510
	if not v_u_18 then
		v_u_18 = true
		v_u_17 = p511
		local v512 = v_u_32()
		v512.Camera.init(p511)
		v512.Esp.init(p511)
		if not v_u_400 then
			v_u_400 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_373
				local v513 = v_u_2:WaitForChild("HushNet", 30)
				if v513 then
					v513 = v513:WaitForChild("rv.info", 60)
				end
				if v513 and v513:IsA("RemoteEvent") then
					v513.OnClientEvent:Connect(v_u_373)
				end
			end)
		end
		v_u_16:GetAttributeChangedSignal("OverwatchTarget"):Connect(v_u_510)
		v_u_16:GetAttributeChangedSignal("OverwatchReviewer"):Connect(v_u_510)
		task.defer(v_u_510)
	end
end
return v_u_6