-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDSquad

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_145 = {
	["COLORS"] = {
		Color3.fromHex("#6FA8DC"),
		Color3.fromHex("#5FBF7A"),
		Color3.fromHex("#C98BD9"),
		Color3.fromHex("#E8D36A")
	},
	["colorFor"] = function(p3, p4) -- name: colorFor
		-- upvalues: (copy) v_u_145
		local v5 = table.clone(p4)
		table.sort(v5)
		local v6 = table.find(v5, p3) or 1
		return v_u_145.COLORS[(v6 - 1) % #v_u_145.COLORS + 1]
	end,
	["new"] = function(p_u_7) -- name: new
		-- upvalues: (copy) v_u_145, (copy) v_u_2, (copy) v_u_1
		local v_u_8 = p_u_7.UI
		local v_u_9 = p_u_7.Theme
		local v_u_10 = v_u_9.color
		local v11 = {}
		local v_u_12 = nil
		local v_u_13 = false
		local v14, v15 = pcall(function()
			-- upvalues: (copy) p_u_7
			return p_u_7.cctx.lib.HudLayout
		end)
		local v_u_16 = (not v14 or type(v15) ~= "table") and {
			["SQUAD_ROW_H"] = 18,
			["SQUAD_MARGIN_L"] = 8,
			["SQUAD_MARGIN_B"] = 6,
			["SQUAD_W"] = 176,
			["SQUAD_GAP"] = 3
		} or v15.K
		local v_u_17 = v_u_8.new("Frame", {
			["Name"] = "Squad",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Position"] = UDim2.fromOffset(40, v_u_8.topInset() + 4),
			["Size"] = UDim2.fromOffset(240, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p_u_7.root)
		local v_u_18 = v_u_8.layout(v_u_17, "v", 4)
		local v_u_19 = v_u_8.label({
			["parent"] = nil,
			["text"] = "Squad",
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["order"] = 0,
			["parent"] = v_u_17,
			["color"] = v_u_10.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		local v_u_20 = {}
		local v_u_21 = false
		local v_u_22 = false
		local function v_u_25(p_u_23) -- name: lock
			for _, v_u_24 in p_u_23:GetDescendants() do
				if not v_u_24:IsA("GuiObject") then
					continue
				end
				v_u_24.Active = false
				v_u_24.Selectable = false
				pcall(function()
					-- upvalues: (copy) v_u_24
					v_u_24.Interactable = false
				end)
			end
			if p_u_23:IsA("GuiObject") then
				p_u_23.Active = false
				p_u_23.Selectable = false
				pcall(function()
					-- upvalues: (copy) p_u_23
					p_u_23.Interactable = false
				end)
			end
		end
		local function v_u_31(p26) -- name: styleRow
			-- upvalues: (ref) v_u_22, (copy) v_u_9, (copy) v_u_16, (copy) v_u_25, (ref) v_u_21
			if v_u_22 then
				local v27 = v_u_9.phoneText(13, "text")
				p26.frame.Size = UDim2.new(1, 0, 0, v_u_16.SQUAD_ROW_H)
				p26.frame.BackgroundTransparency = 0.5
				p26.name.Position = UDim2.fromOffset(8, 0)
				p26.name.Size = UDim2.new(1, -78, 0, 16)
				p26.name.TextSize = v27
				p26.state.Position = UDim2.new(1, -6, 0, 0)
				p26.state.Size = UDim2.fromOffset(66, 16)
				p26.state.TextSize = v27
				local v28 = p26.hp.frame
				v28.Position = UDim2.fromOffset(8, 16)
				v28.Size = UDim2.new(1, -14, 0, 2)
				v_u_25(p26.frame)
			else
				local v29 = v_u_21 and 22 or 30
				p26.frame.Size = UDim2.new(1, 0, 0, v29)
				p26.frame.BackgroundTransparency = 0.35
				p26.name.Position = UDim2.fromOffset(10, v_u_21 and 0 or 2)
				p26.name.Size = UDim2.new(1, -86, 0, 16)
				p26.state.Position = UDim2.new(1, -8, 0, v_u_21 and 0 or 2)
				p26.state.Size = UDim2.fromOffset(74, 16)
				local v30 = p26.hp.frame
				v30.Position = UDim2.fromOffset(10, v_u_21 and 18 or 22)
				v30.Size = UDim2.new(1, -18, 0, 2)
			end
		end
		local function v_u_36(p32) -- name: row
			-- upvalues: (copy) v_u_20, (copy) v_u_8, (copy) v_u_10, (copy) v_u_17, (ref) v_u_21, (ref) v_u_22, (copy) v_u_31
			local v33 = v_u_20[p32]
			if v33 then
				return v33
			end
			local v34 = v_u_8.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.35,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Name"] = "M" .. p32,
				["BackgroundColor3"] = v_u_10.bg,
				["Size"] = UDim2.new(1, 0, 0, 30)
			}, v_u_17)
			local v35 = {
				["frame"] = v34,
				["tick"] = v_u_8.new("Frame", {
					["Name"] = "Tick",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_10.info,
					["Size"] = UDim2.new(0, 2, 1, 0)
				}, v34),
				["name"] = v_u_8.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v34,
					["color"] = v_u_10.text,
					["position"] = UDim2.fromOffset(10, 2),
					["size"] = UDim2.new(1, -86, 0, 16)
				}),
				["state"] = v_u_8.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["parent"] = v34,
					["color"] = v_u_10.text2,
					["position"] = UDim2.new(1, -8, 0, 2),
					["anchor"] = Vector2.new(1, 0),
					["size"] = UDim2.fromOffset(74, 16)
				}),
				["hp"] = v_u_8.progress({
					["parent"] = nil,
					["size"] = nil,
					["position"] = nil,
					["value"] = 1,
					["color"] = nil,
					["bgTransparency"] = 0.5,
					["parent"] = v34,
					["size"] = UDim2.new(1, -18, 0, 2),
					["position"] = UDim2.fromOffset(10, 22),
					["color"] = v_u_10.text2
				})
			}
			v_u_20[p32] = v35
			if v_u_21 or v_u_22 then
				v_u_31(v35)
			end
			return v35
		end
		local function v_u_45() -- name: placeTouch
			-- upvalues: (ref) v_u_13, (copy) p_u_7, (copy) v_u_17
			local v37
			if v_u_13 and p_u_7.touchFrame then
				v37 = p_u_7.touchFrame()
			else
				v37 = nil
			end
			if not v37 then
				return false
			end
			local v38 = p_u_7.bandOffset
			local v39 = type(v38) ~= "function" and 0 or p_u_7.bandOffset("Squad")
			local v40 = v_u_17
			local v41 = UDim2.fromOffset
			local v42 = v37.bandLeft or v37.left
			local v43 = v37.listY
			local v44
			if type(v43) == "number" then
				v44 = v37.listY
			else
				v44 = v37.top + 96
			end
			v40.Position = v41(v42, v44 + v39)
			return true
		end
		function v11.setCharacter(p46) -- name: setCharacter
			-- upvalues: (ref) v_u_12
			v_u_12 = p46
		end
		function v11.layout(p47) -- name: layout
			-- upvalues: (ref) v_u_13, (copy) p_u_7, (ref) v_u_21, (ref) v_u_22, (copy) v_u_17, (copy) v_u_16, (copy) v_u_18, (copy) v_u_19, (copy) v_u_25, (copy) v_u_45, (copy) v_u_8, (copy) v_u_20, (copy) v_u_31
			v_u_13 = p47
			local v48
			if v_u_13 and p_u_7.touchFrame then
				v48 = p_u_7.touchFrame()
			else
				v48 = nil
			end
			local v49 = v_u_21
			local v50 = v_u_22
			local v51
			if v48 == nil then
				v51 = false
			else
				local v52 = v48.listY
				if type(v52) == "number" then
					local v53 = v48.listBottom
					if type(v53) == "number" then
						v51 = v48.listBottom - v48.listY < 260
					else
						v51 = false
					end
				else
					v51 = false
				end
			end
			v_u_21 = v51
			local v54
			if v48 == nil then
				v54 = false
			else
				local v55 = p_u_7.phoneHud
				if type(v55) == "function" then
					v54 = p_u_7.phoneHud() == true
				else
					v54 = false
				end
			end
			v_u_22 = v54
			if v_u_22 then
				v_u_17.AnchorPoint = Vector2.new(0, 1)
				v_u_17.Position = p_u_7.cctx.lib.HudLayout.position("Squad", UDim2.new(0, v_u_16.SQUAD_MARGIN_L, 1, -v_u_16.SQUAD_MARGIN_B))
				v_u_17.Size = UDim2.fromOffset(v_u_16.SQUAD_W, 0)
				v_u_18.Padding = UDim.new(0, v_u_16.SQUAD_GAP)
				v_u_19.Visible = false
				v_u_25(v_u_17)
			elseif v48 then
				v_u_17.AnchorPoint = Vector2.new(0, 0)
				v_u_17.Size = UDim2.fromOffset(240, 0)
				v_u_18.Padding = UDim.new(0, 4)
				v_u_45()
			else
				v_u_17.AnchorPoint = Vector2.new(0, 0)
				v_u_17.Size = UDim2.fromOffset(240, 0)
				v_u_18.Padding = UDim.new(0, 4)
				v_u_17.Position = UDim2.fromOffset(40, v_u_8.topInset() + 4)
			end
			if v49 ~= v_u_21 or v50 ~= v_u_22 then
				for _, v56 in v_u_20 do
					v_u_31(v56)
				end
			end
		end
		local v_u_57 = nil
		local function v_u_59(p58) -- name: esc
			return string.gsub(string.gsub(string.gsub(string.gsub(p58, "&", "&amp;"), "<", "&lt;"), ">", "&gt;"), "\"", "&quot;")
		end
		local v_u_60 = nil
		local function v_u_73(p61, p62) -- name: clanPrefix
			-- upvalues: (ref) v_u_60, (copy) p_u_7
			if v_u_60 == nil then
				local function v63()
					-- upvalues: (ref) p_u_7
					return p_u_7.cctx.lib.ClanTagText
				end
				local v64, v65 = pcall(v63)
				if not v64 or type(v65) ~= "table" then
					v65 = false
				end
				v_u_60 = v65
			end
			local v66
			if v_u_60 then
				v66 = v_u_60
			else
				v66 = nil
			end
			if not v66 then
				return ""
			end
			local v67 = v66.tagOf(p61)
			if not v67 then
				return ""
			end
			if not (v66.styleOf and v66.richFor) then
				local v68 = v66.prefixRich
				local v69 = p62 - 3
				return v68(v67, (math.max(10, v69)))
			end
			local v70 = v66.richFor
			local v71 = v66.styleOf(p61)
			local v72 = p62 - 3
			return v70(v67, v71, (math.max(10, v72)))
		end
		local v_u_74 = { "BLKO", "A1B", "XY12" }
		local function v_u_81(p75, p76) -- name: baseNameText
			-- upvalues: (ref) v_u_13, (ref) v_u_57, (copy) p_u_7, (copy) v_u_59
			if v_u_13 then
				return p75.DisplayName, false
			else
				if v_u_57 == nil then
					local function v77()
						-- upvalues: (ref) p_u_7
						return p_u_7.cctx.lib.TallyMark
					end
					local v78, v79 = pcall(v77)
					v_u_57 = v78 and v79 and v79 or false
				end
				local v80
				if v_u_57 then
					v80 = v_u_57.mateText(p75:GetAttribute("SkinsTally"), p76:GetAttribute("Weapon"))
				else
					v80 = nil
				end
				if v80 == nil then
					return p75.DisplayName, false
				else
					return v_u_59(p75.DisplayName) .. "  <font size=\"10\" color=\"#E8A33D\">" .. v_u_59(v80) .. "</font>", true
				end
			end
		end
		local v_u_82 = 1
		local v_u_83 = 0
		local v_u_84 = {
			{ "Anna", "34 m", 0.9 },
			{ "Bartholomew Longname", "DOWN 21", 0.3 },
			{ "Chris", "DEAD", 0 }
		}
		function v11.fake(p85) -- name: fake
			-- upvalues: (ref) v_u_83, (copy) v_u_84, (ref) v_u_82
			local v86 = math.floor(p85)
			local v87 = #v_u_84
			v_u_83 = math.clamp(v86, 0, v87)
			v_u_82 = 1
		end
		function v11.update(p88) -- name: update
			-- upvalues: (ref) v_u_82, (ref) v_u_13, (ref) v_u_22, (copy) v_u_45, (copy) p_u_7, (copy) v_u_9, (copy) v_u_17, (ref) v_u_83, (copy) v_u_84, (copy) v_u_36, (copy) v_u_74, (ref) v_u_60, (copy) v_u_59, (ref) v_u_145, (copy) v_u_20, (copy) v_u_19, (ref) v_u_21, (ref) v_u_12, (ref) v_u_2, (copy) v_u_81, (copy) v_u_73, (copy) v_u_10, (ref) v_u_1
			v_u_82 = v_u_82 + p88
			if v_u_82 < 0.2 then
				return
			else
				v_u_82 = 0
				if v_u_13 and not v_u_22 then
					v_u_45()
					local v89
					if v_u_22 then
						v89 = false
					else
						local v90 = p_u_7.mods
						if v90 then
							v90 = p_u_7.mods.HUDClock
						end
						local v91
						if v90 then
							v91 = v90.bandBusy or v90.isShown
						else
							v91 = nil
						end
						v89 = v_u_13 and v_u_9.isPhone()
						if v89 then
							if type(v91) == "function" then
								v89 = v91() == true
							else
								v89 = false
							end
						end
					end
					if v89 then
						v_u_17.Visible = false
						return
					end
				end
				if v_u_83 > 0 then
					local v92 = {}
					for v93 = 1, v_u_83 do
						local v94 = v_u_84[v93]
						local v95 = v_u_36(-v93)
						v92[-v93] = true
						v95.frame.LayoutOrder = v93
						local v96
						if p_u_7.cctx.player:GetAttribute("HudFakeClanTags") == true then
							v96 = v_u_74[v93]
						else
							v96 = nil
						end
						local v97
						if v96 then
							if v_u_60 == nil then
								local function v98()
									-- upvalues: (ref) p_u_7
									return p_u_7.cctx.lib.ClanTagText
								end
								local v99, v100 = pcall(v98)
								if not v99 or type(v100) ~= "table" then
									v100 = false
								end
								v_u_60 = v100
							end
							if v_u_60 then
								v97 = v_u_60
							else
								v97 = nil
							end
						else
							v97 = nil
						end
						if v97 then
							v95.name.RichText = true
							local v101 = v95.name
							local v102 = v97.prefixRich
							local v103 = v95.name.TextSize - 3
							v101.Text = v102(v96, (math.max(10, v103))) .. v_u_59(v94[1])
						else
							if v95.name.RichText then
								v95.name.RichText = false
							end
							v95.name.Text = v94[1]
						end
						v95.tick.BackgroundColor3 = v_u_145.COLORS[v93]
						v95.state.Text = v94[2]
						v95.hp.set(v94[3], true)
					end
					for v104, v105 in v_u_20 do
						if v92[v104] then
							continue
						end
						v105.frame:Destroy()
						v_u_20[v104] = nil
					end
					v_u_17.Visible = true
					v_u_19.Visible = not v_u_21
					return
				else
					local v106 = v_u_12
					local v107
					if v106 then
						v107 = v106:GetAttribute("SquadId")
					else
						v107 = v106
					end
					if v106 and (type(v107) == "string" and v107 ~= "") then
						local v108 = v106:FindFirstChild("HumanoidRootPart")
						local v109 = { p_u_7.cctx.player.UserId }
						local v110 = {}
						for _, v111 in v_u_2:GetPlayers() do
							if v111 == p_u_7.cctx.player then
								continue
							end
							local v112 = v111.Character
							if not v112 or v112:GetAttribute("SquadId") ~= v107 then
								continue
							end
							local v113 = v111.UserId
							table.insert(v109, v113)
							table.insert(v110, {
								["p"] = v111,
								["c"] = v112
							})
						end
						local v114 = {}
						for v115, v116 in v110 do
							local v117 = v_u_36(v116.p.UserId)
							v114[v116.p.UserId] = true
							v117.frame.LayoutOrder = v115
							local v118 = v116.p
							local v119 = v116.c
							local v120 = v117.name.TextSize
							local v121, v122 = v_u_81(v118, v119)
							local v123 = v_u_73(v118, v120)
							if v123 ~= "" then
								if not v122 then
									v121 = v_u_59(v121)
								end
								v121 = v123 .. v121
								v122 = true
							end
							if v117.name.RichText ~= v122 then
								v117.name.RichText = v122
							end
							v117.name.Text = v121
							local v124 = v_u_145.colorFor(v116.p.UserId, v109)
							v117.tick.BackgroundColor3 = v124
							local v125 = v116.c:GetAttribute("Hp")
							local v126 = type(v125) ~= "number" and 100 or v125
							local v127 = v116.c:GetAttribute("MaxHp")
							local v128 = type(v127) ~= "number" and 100 or v127
							local v129 = v126 / math.max(1, v128)
							v117.hp.set(math.clamp(v129, 0, 1), true)
							local v130 = v116.c:GetAttribute("Dead") == true
							local v131 = v116.c:GetAttribute("Downed") == true
							if v130 then
								v117.state.Text = "DEAD"
								v117.state.TextColor3 = v_u_10.muted
								v117.name.TextColor3 = v_u_10.muted
								v117.hp.setColor(v_u_10.muted)
							elseif v131 then
								local v132 = v116.c:GetAttribute("DownedUntil")
								local v133 = (type(v132) ~= "number" and 0 or v132) - v_u_1.now()
								local v134 = math.max(0, v133)
								v117.state.Text = "DOWN " .. math.ceil(v134)
								v117.state.TextColor3 = v_u_10.danger
								v117.name.TextColor3 = v_u_10.danger
								v117.hp.setColor(v_u_10.danger)
							else
								local v135 = v116.c:FindFirstChild("HumanoidRootPart")
								if v135 and v108 then
									local v136 = v117.state
									local v137 = (v135.Position - v108.Position).Magnitude * 0.28 + 0.5
									local v138 = math.floor(v137)
									v136.Text = tostring(v138) .. " m"
								else
									v117.state.Text = "-"
								end
								v117.state.TextColor3 = v_u_10.text2
								v117.name.TextColor3 = v_u_10.text
								local v139 = v117.hp.setColor
								local v140
								if v129 < 0.35 then
									v140 = v_u_10.accent
								else
									v140 = v_u_10.text2
								end
								v139(v140)
							end
						end
						for v141, v142 in v_u_20 do
							if v114[v141] then
								continue
							end
							v142.frame:Destroy()
							v_u_20[v141] = nil
						end
						v_u_17.Visible = #v110 > 0
						local v143 = v_u_19
						local v144
						if #v110 > 0 then
							v144 = not v_u_21
						else
							v144 = false
						end
						v143.Visible = v144
					else
						v_u_17.Visible = false
					end
				end
			end
		end
		function v11.destroy() -- name: destroy
			-- upvalues: (copy) v_u_17
			v_u_17:Destroy()
		end
		return v11
	end
}
return v_u_145