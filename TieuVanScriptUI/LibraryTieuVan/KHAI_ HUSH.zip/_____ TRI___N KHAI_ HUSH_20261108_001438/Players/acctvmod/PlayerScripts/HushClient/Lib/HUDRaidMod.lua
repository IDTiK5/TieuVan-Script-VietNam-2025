-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDRaidMod

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("RaidMods"))
local v4 = {}
local v_u_5 = {
	["desk"] = {
		["h"] = 40,
		["padV"] = 6,
		["title"] = 12,
		["titleH"] = 14,
		["line"] = 11,
		["lineH"] = 14
	},
	["touch"] = {
		["h"] = 44,
		["padV"] = 7,
		["title"] = 14,
		["titleH"] = 16,
		["line"] = 12,
		["lineH"] = 14
	},
	["phone"] = {
		["h"] = 36,
		["padV"] = 3,
		["title"] = 14,
		["titleH"] = 16,
		["line"] = 12,
		["lineH"] = 14
	}
}
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = false
function v4.new(p_u_9) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_3, (copy) v_u_6, (ref) v_u_7, (ref) v_u_8
	local v_u_10 = p_u_9.UI
	local v_u_11 = p_u_9.Theme
	local v_u_12 = v_u_11.color
	local v_u_13 = p_u_9.cctx
	local v_u_14 = v_u_1.LocalPlayer
	local v_u_15 = {}
	local v_u_16 = false
	local v_u_17 = nil
	local v_u_18 = false
	local v_u_19 = 0.25
	local v_u_20 = nil
	local v_u_21 = ""
	local v_u_22 = ""
	local v_u_23 = 0
	local v_u_24 = 0
	local v_u_25 = os.clock() + 12
	local v_u_26 = 0
	local v_u_27 = 0
	local v_u_28 = false
	local v_u_29 = ""
	local v_u_30 = v_u_5.desk
	local v_u_31 = v_u_10.new("Frame", {
		["Name"] = "RaidModTag",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_12.bg,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -172, 0, v_u_10.topInset() + 4),
		["Size"] = UDim2.fromOffset(0, v_u_30.h),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, p_u_9.root)
	local v_u_32 = v_u_10.stroke(v_u_31, v_u_12.danger, 1, 0.25)
	local v_u_33 = v_u_10.pad(v_u_31, {
		12,
		12,
		v_u_30.padV,
		v_u_30.padV
	})
	v_u_10.layout(v_u_31, "h", 8)
	local v_u_34 = v_u_10.new("Frame", {
		["Name"] = "IconSlot",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.fromOffset(16, 16)
	}, v_u_31)
	local v_u_35 = v_u_10.new("Frame", {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.fromOffset(0, v_u_30.titleH + v_u_30.lineH),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v_u_31)
	v_u_10.layout(v_u_35, "v", 0)
	local v_u_36 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "caps",
		["textSize"] = nil,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 1,
		["parent"] = v_u_35,
		["textSize"] = v_u_30.title,
		["color"] = v_u_12.danger,
		["size"] = UDim2.fromOffset(0, v_u_30.titleH)
	})
	local v_u_37 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = "",
		["style"] = "small",
		["textSize"] = nil,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 2,
		["track"] = false,
		["parent"] = v_u_35,
		["textSize"] = v_u_30.line,
		["color"] = v_u_12.text2,
		["size"] = UDim2.fromOffset(0, v_u_30.lineH)
	})
	local function v_u_46() -- name: applyFit
		-- upvalues: (ref) v_u_30, (ref) v_u_16, (copy) p_u_9, (ref) v_u_5, (copy) v_u_31, (copy) v_u_33, (copy) v_u_35, (copy) v_u_36, (copy) v_u_11, (copy) v_u_37
		local v38
		if v_u_16 and p_u_9.touchFrame then
			local v39 = p_u_9.touchFrame
			local v40
			v38, v40 = pcall(v39)
			if v38 then
				if type(v40) == "table" then
					v38 = v40.corner ~= nil
				else
					v38 = false
				end
			end
		else
			v38 = false
		end
		local v41
		if v38 then
			v41 = v_u_5.phone
		elseif v_u_16 then
			v41 = v_u_5.touch
		else
			v41 = v_u_5.desk
		end
		v_u_30 = v41
		v_u_31.Size = UDim2.fromOffset(0, v_u_30.h)
		v_u_33.PaddingTop = UDim.new(0, v_u_30.padV)
		v_u_33.PaddingBottom = UDim.new(0, v_u_30.padV)
		v_u_35.Size = UDim2.fromOffset(0, v_u_30.titleH + v_u_30.lineH)
		local v42 = v_u_36
		local v43
		if v_u_16 and v_u_11.isPhone() then
			v43 = v_u_11.phoneText(v_u_30.title, "text")
		else
			v43 = v_u_30.title
		end
		v42.TextSize = v43
		v_u_36.Size = UDim2.fromOffset(0, v_u_30.titleH)
		local v44 = v_u_37
		local v45
		if v_u_16 and v_u_11.isPhone() then
			v45 = v_u_11.phoneText(v_u_30.line, "caption")
		else
			v45 = v_u_30.line
		end
		v44.TextSize = v45
		v_u_37.Size = UDim2.fromOffset(0, v_u_30.lineH)
	end
	local function v_u_50() -- name: wanted
		-- upvalues: (copy) v_u_14, (copy) p_u_9, (copy) v_u_13, (ref) v_u_3
		if v_u_14:GetAttribute("Tutorial") == true or v_u_14:GetAttribute("TutorialPractice") == true then
			return nil
		else
			local v47 = p_u_9.raid
			local v48 = not (v47 and v47.Parent) and v_u_13.runtime
			if v48 then
				v48 = v48:FindFirstChild("Raid")
			end
			if v48 then
				local v49 = v48:GetAttribute("RaidMod")
				if type(v49) == "string" then
					return v_u_3.get(v49)
				else
					return nil
				end
			else
				return nil
			end
		end
	end
	local function v_u_55(p51) -- name: paint
		-- upvalues: (copy) v_u_12, (copy) v_u_32, (copy) v_u_36, (copy) v_u_10, (copy) v_u_37, (copy) v_u_34
		local v52
		if p51.risky then
			v52 = v_u_12.danger
		else
			v52 = v_u_12.success
		end
		v_u_32.Color = v52
		v_u_36.TextColor3 = v52
		v_u_10.setText(v_u_36, p51.short)
		v_u_10.setText(v_u_37, p51.line)
		for _, v53 in v_u_34:GetChildren() do
			v53:Destroy()
		end
		local v54 = {
			["parent"] = nil,
			["size"] = 16,
			["color"] = nil,
			["parent"] = v_u_34,
			["color"] = v52
		}
		v_u_10.icon(p51.icon, v54)
	end
	local function v_u_64(p56) -- name: clockEdge
		-- upvalues: (copy) p_u_9, (copy) v_u_11
		local v57 = 116
		local v58 = p_u_9.root:FindFirstChild("Clock")
		local v59
		if v58 then
			v59 = v58:FindFirstChild("Siren")
		else
			v59 = nil
		end
		if v59 and (v59:IsA("GuiObject") and v59.Visible) then
			local v60 = v59.AbsoluteSize.X
			local v61 = v_u_11.uiScale
			local v62 = v60 / math.max(0.01, v61())
			local v63 = 128 + (v62 <= 1 and 52 or v62)
			v57 = math.max(v57, v63)
		end
		return p56 + v57
	end
	local function v_u_72() -- name: plateEdge
		-- upvalues: (copy) p_u_9, (copy) v_u_11
		local v65 = p_u_9.root:FindFirstChild("LevelPlate")
		if not (v65 and (v65:IsA("GuiObject") and v65.Visible)) then
			return nil
		end
		local v66 = v_u_11.uiScale
		local v67 = math.max(0.01, v66())
		local v68 = 0
		for _, v69 in { "Level", "Zone" } do
			local v70 = v65:FindFirstChild(v69)
			if not v70 or (not v70:IsA("TextLabel") or (not v70.Visible or v70.Text == "")) then
				continue
			end
			local v71 = v70.TextBounds.X / v67
			v68 = math.max(v68, v71)
		end
		return v68 + 296
	end
	local function v_u_123() -- name: place
		-- upvalues: (copy) v_u_31, (ref) v_u_16, (copy) p_u_9, (ref) v_u_26, (copy) v_u_64, (ref) v_u_30, (copy) v_u_11, (ref) v_u_27, (copy) v_u_14, (copy) v_u_72, (copy) v_u_10
		if v_u_31.Parent then
			v_u_31.AnchorPoint = Vector2.new(1, 0)
			local v73
			if v_u_16 and p_u_9.touchFrame then
				v73 = p_u_9.touchFrame()
			else
				v73 = nil
			end
			if v73 then
				local v74 = v_u_64(v73.right) + 16
				v_u_26 = math.floor(v74)
				local v75 = p_u_9.mods
				local v76
				if type(v75) == "table" then
					v76 = p_u_9.mods.HUDClock
				else
					v76 = nil
				end
				local v77
				if v73.corner then
					local v78
					if v76 then
						local v79 = v76.corner
						if type(v79) == "function" then
							v78 = v76.corner()
						else
							v78 = nil
						end
					else
						v78 = nil
					end
					local v80
					if v78 then
						local v81 = v76.extent
						v80 = type(v81) ~= "function" and 106 or v76.extent()
					else
						v80 = 106
					end
					local v82
					if v78 then
						v82 = v78.right
					else
						v82 = v73.right
					end
					local v83
					if v78 then
						v83 = v78.top
					else
						v83 = v73.corner.clockTop
					end
					local v84 = v82 + v80 + 16
					v_u_26 = math.floor(v84)
					local v85 = v83 + v73.corner.clockH / 2 - v_u_30.h / 2
					local v86 = math.floor(v85)
					v77 = math.max(2, v86)
				else
					v77 = nil
				end
				if v_u_11.isPhone() then
					local v87 = v_u_11.uiScale
					local v_u_88 = math.max(0.01, v87())
					local v_u_89 = p_u_9.root.AbsoluteSize.X / v_u_88
					local v_u_90 = v_u_27 <= 0 and 200 or v_u_27 / v_u_88
					local v91 = v73.left
					local v92 = v73.vitalsW
					local v93 = v91 + math.min(288, v92)
					local v_u_94 = false
					local function v101()
						-- upvalues: (ref) v_u_14, (ref) p_u_9, (copy) v_u_88, (copy) v_u_89, (ref) v_u_26, (ref) v_u_94, (copy) v_u_90
						local v95 = v_u_14:FindFirstChildOfClass("PlayerGui")
						if v95 then
							v95 = v95:FindFirstChild("HushTestTag")
						end
						local v96
						if v95 then
							v96 = v95:FindFirstChild("TestTag", true)
						else
							v96 = nil
						end
						if v95 and (v95.Enabled and (v96 and (v96:IsA("GuiObject") and (v96.Visible and v96.AbsoluteSize.X > 4)))) then
							local v97 = (v96.AbsolutePosition.X - p_u_9.root.AbsolutePosition.X) / v_u_88
							local v98 = v97 + v96.AbsoluteSize.X / v_u_88
							local v99 = v_u_89 - v_u_26
							local v100
							if v97 < v99 then
								v100 = v99 - v_u_90 < v98
							else
								v100 = false
							end
							v_u_94 = v100
						end
					end
					pcall(v101)
					if v_u_94 or v_u_89 - v_u_26 - v_u_90 < v93 + 10 then
						v_u_31:SetAttribute("TopRow", false)
						v_u_31.AnchorPoint = Vector2.new(0, 0)
						local v102 = v_u_31
						local v103 = UDim2.fromOffset
						local v104 = v73.bandLeft or v73.left
						local v105 = math.floor(v104)
						local v106 = v73.listY
						local v107
						if type(v106) == "number" then
							v107 = v73.listY
						else
							v107 = v73.top + 96
						end
						v102.Position = v103(v105, (math.floor(v107)))
						return
					end
				end
				v_u_31:SetAttribute("TopRow", true)
				local v108 = v_u_31
				local v109 = UDim2.new
				local v110 = 1
				local v111 = -v_u_26
				local v112 = 0
				if not v77 then
					local v113 = v73.top + 16 - v_u_30.h / 2
					local v114 = math.floor(v113)
					v77 = math.max(2, v114)
				end
				v108.Position = v109(v110, v111, v112, v77)
			else
				v_u_31:SetAttribute("TopRow", true)
				local v115 = v_u_64(40) + 16
				local v116 = v_u_72()
				if v116 then
					local v117 = v116 + 16
					v115 = math.max(v115, v117)
				end
				v_u_26 = math.floor(v115)
				local v118 = v_u_31
				local v119 = UDim2.new
				local v120 = -v_u_26
				local v121 = v_u_10.topInset()
				local v122 = 24 - v_u_30.h / 2
				v118.Position = v119(1, v120, 0, v121 + math.floor(v122))
			end
		else
			return
		end
	end
	local function v_u_129() -- name: covered
		-- upvalues: (ref) v_u_16, (copy) v_u_11, (copy) p_u_9, (ref) v_u_27, (ref) v_u_26
		if v_u_16 and v_u_11.isPhone() then
			return false
		end
		local v124 = v_u_11.uiScale
		local v125 = math.max(0.01, v124())
		local v126 = p_u_9.root.AbsolutePosition.X
		local v127 = p_u_9.root.AbsoluteSize.X
		local v128
		if v_u_27 > 0 then
			v128 = v_u_27
		else
			v128 = v125 * 200
		end
		return v126 + v127 - v_u_26 * v125 - v128 < v126 + v127 / 2 + (v_u_16 and 160 or 230) * v125 + v125 * 12
	end
	local function v_u_142(p130) -- name: announce
		-- upvalues: (ref) v_u_3, (copy) p_u_9, (copy) v_u_13, (ref) v_u_29, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (copy) v_u_10
		local v131 = v_u_3.cardTexts
		local v132 = p_u_9.raid
		local v133 = not (v132 and v132.Parent) and v_u_13.runtime
		if v133 then
			v133 = v133:FindFirstChild("Raid")
		end
		local v134
		if v133 then
			v134 = v133:GetAttribute("Difficulty")
		else
			v134 = nil
		end
		if type(v134) ~= "string" then
			v134 = nil
		end
		local v135, v136 = v131(p130, v134)
		v_u_29 = v136
		local v137 = {
			["text"] = nil,
			["sub"] = nil,
			["kind"] = nil,
			["icon"] = nil,
			["event"] = nil,
			["category"] = "Raid condition",
			["dur"] = 9,
			["sting"] = "land",
			["text"] = v135,
			["sub"] = v136,
			["kind"] = p130.risky and "danger" or "success",
			["icon"] = p130.icon,
			["event"] = "raidmod_" .. p130.id
		}
		local v138 = p_u_9.mods
		local v139
		if type(v138) == "table" then
			v139 = p_u_9.mods.HUDEvents
		else
			v139 = nil
		end
		if v139 then
			local v140 = v139.announce
			if type(v140) == "function" then
				local v141 = v139.announce
				if pcall(v141, v137) then
					v_u_22 = v135
					v_u_23 = 1
					v_u_24 = os.clock()
					v_u_25 = v_u_24 + 30
					return true
				end
			end
		end
		v_u_10.toast(v135, v137.kind, v136)
		return true
	end
	local function v_u_149() -- name: cardUp
		-- upvalues: (copy) p_u_9, (ref) v_u_22
		local v143 = p_u_9.mods
		local v144
		if type(v143) == "table" then
			v144 = p_u_9.mods.HUDEvents
		else
			v144 = nil
		end
		if v144 then
			local v145 = v144.state
			if type(v145) == "function" and v_u_22 ~= "" then
				local v146 = v144.state
				local v147, v148 = pcall(v146)
				if v147 then
					if type(v148) == "string" then
						v147 = string.find(v148, "card=" .. v_u_22, 1, true) ~= nil
					else
						v147 = false
					end
				end
				return v147
			end
		end
		return false
	end
	local function v_u_162() -- name: refresh
		-- upvalues: (copy) v_u_50, (ref) v_u_17, (ref) v_u_23, (ref) v_u_25, (ref) v_u_22, (ref) v_u_3, (copy) v_u_55, (copy) v_u_123, (copy) p_u_9, (copy) v_u_13, (ref) v_u_21, (ref) v_u_6, (ref) v_u_20, (ref) v_u_28, (copy) v_u_129, (ref) v_u_16, (copy) v_u_31, (ref) v_u_18, (copy) v_u_10
		local v150 = v_u_50()
		local v151
		if v150 then
			v151 = v150.id
		else
			v151 = nil
		end
		if v151 ~= v_u_17 then
			v_u_17 = v151
			v_u_23 = 0
			v_u_25 = os.clock() + 12
			if v150 then
				v_u_22 = v_u_3.cardTexts(v150)
				v_u_55(v150)
				v_u_123()
				local v152 = p_u_9.raid
				local v153 = not (v152 and v152.Parent) and v_u_13.runtime
				if v153 then
					v153 = v153:FindFirstChild("Raid")
				end
				local v154
				if v153 then
					local v155 = v153:GetAttribute("RaidId") or v153:GetAttribute("StartedAt") or ""
					v154 = tostring(v155)
				else
					v154 = ""
				end
				v_u_21 = v154 .. "|" .. v150.id
				if not v_u_6[v_u_21] then
					v_u_20 = os.clock() + 3
				end
			else
				v_u_20 = nil
				v_u_22 = ""
			end
		end
		local v156
		if v150 == nil or (v_u_17 == nil or v_u_20 == nil and v_u_23 == 0) then
			v156 = false
		else
			v156 = v_u_129()
		end
		v_u_28 = v156
		local v157
		if v_u_16 and v_u_31:GetAttribute("TopRow") == false then
			local v158 = p_u_9.mods
			local v159
			if type(v158) == "table" then
				v159 = p_u_9.mods.HUDClock
			else
				v159 = nil
			end
			local v160
			if v159 then
				v160 = v159.bandBusy
			else
				v160 = nil
			end
			if type(v160) == "function" then
				v157 = v160() == true
			else
				v157 = false
			end
		else
			v157 = false
		end
		local v161 = v150 ~= nil and not v_u_28
		if v161 then
			v161 = not v157
		end
		if v161 == v_u_18 then
			return
		else
			v_u_18 = v161
			if v161 then
				v_u_31.Visible = true
				v_u_10.fade(v_u_31, 0, "fast", {
					["from"] = 1
				})
			else
				v_u_31.Visible = false
			end
		end
	end
	function v_u_15.layout(p163) -- name: layout
		-- upvalues: (ref) v_u_16, (copy) v_u_46, (copy) v_u_123, (copy) v_u_162
		v_u_16 = p163
		v_u_46()
		v_u_123()
		v_u_162()
	end
	function v_u_15.setCharacter(_) -- name: setCharacter end
	function v_u_15.update(p164) -- name: update
		-- upvalues: (ref) v_u_19, (ref) v_u_17, (ref) v_u_23, (ref) v_u_25, (copy) v_u_149, (ref) v_u_24, (ref) v_u_18, (copy) v_u_31, (ref) v_u_27, (copy) v_u_123, (copy) v_u_162, (ref) v_u_20, (copy) v_u_14, (ref) v_u_6, (ref) v_u_21, (ref) v_u_3, (copy) v_u_142, (ref) v_u_28
		v_u_19 = v_u_19 + p164
		if v_u_19 >= 0.25 then
			v_u_19 = 0
			if v_u_17 == nil then
				v_u_23 = 0
			else
				local v165 = os.clock()
				if v_u_23 ~= 0 or v165 < v_u_25 then
					if v_u_149() then
						v_u_23 = 2
					elseif v_u_23 == 2 or v_u_23 == 1 and v165 - v_u_24 > 20 then
						v_u_23 = 0
					end
				end
				if v_u_18 and v_u_31.AbsoluteSize.X > 0 then
					v_u_27 = v_u_31.AbsoluteSize.X
				end
			end
			if v_u_18 then
				v_u_123()
			end
			v_u_162()
			local v166 = v_u_20
			if v166 and (v_u_17 and v166 <= os.clock()) then
				if v_u_14:GetAttribute("LoadingVisible") == true then
					v_u_20 = os.clock() + 0.5
				elseif v_u_6[v_u_21] then
					v_u_20 = nil
				else
					local v167 = v_u_3.get(v_u_17)
					v_u_20 = nil
					v_u_6[v_u_21] = true
					if v167 then
						v_u_142(v167)
						v_u_162()
					end
				end
			end
			local v168 = v_u_17
			v_u_14:SetAttribute("HudRaidMod", ("%s|%s|%s%s"):format(tostring(v168), v_u_18 and "shown" or "hidden", v_u_6[v_u_21] and "card" or "nocard", v_u_28 and "|held" or ""))
		end
	end
	function v_u_15.state() -- name: state
		-- upvalues: (copy) v_u_31, (ref) v_u_17, (ref) v_u_18, (ref) v_u_28, (ref) v_u_23, (ref) v_u_6, (ref) v_u_21, (copy) v_u_36, (copy) v_u_37, (ref) v_u_26, (ref) v_u_29
		local v169 = v_u_31.AbsolutePosition
		local v170 = v_u_31.AbsoluteSize
		return {
			["id"] = v_u_17,
			["shown"] = v_u_18,
			["held"] = v_u_28,
			["phase"] = v_u_23,
			["card"] = v_u_6[v_u_21] == true,
			["x"] = v169.X,
			["y"] = v169.Y,
			["w"] = v170.X,
			["h"] = v170.Y,
			["title"] = v_u_36.Text,
			["line"] = v_u_37.Text,
			["rightOff"] = v_u_26,
			["cardSub"] = v_u_29
		}
	end
	function v_u_15.fit() -- name: fit
		-- upvalues: (copy) v_u_11, (copy) v_u_31, (copy) v_u_36, (copy) v_u_37
		local v171 = v_u_11.uiScale
		local v172 = math.max(0.01, v171())
		local v173 = v_u_31.AbsolutePosition
		local v174 = v_u_31.AbsoluteSize
		local v175 = v_u_36.AbsolutePosition
		local v176 = v_u_36.AbsoluteSize
		local v177 = v_u_37.AbsolutePosition
		local v178 = v_u_37.AbsoluteSize
		local v179 = (v175.Y - v173.Y) / v172
		local v180 = (v173.Y + v174.Y - (v177.Y + v178.Y)) / v172
		return ("tag %.1fx%.1f | title box h %.1f size %d bounds %.1fx%.1f width %.1f | line box h %.1f size %d bounds %.1fx%.1f width %.1f | margin top %.1f bottom %.1f | hs %.3f"):format(v174.X / v172, v174.Y / v172, v176.Y / v172, v_u_36.TextSize, v_u_36.TextBounds.X, v_u_36.TextBounds.Y, v176.X / v172, v178.Y / v172, v_u_37.TextSize, v_u_37.TextBounds.X, v_u_37.TextBounds.Y, v178.X / v172, v179, v180, v172)
	end
	function v_u_15.destroy() -- name: destroy
		-- upvalues: (ref) v_u_7, (copy) v_u_15, (copy) v_u_14, (copy) v_u_31
		if v_u_7 == v_u_15 then
			v_u_7 = nil
			v_u_14:SetAttribute("HudRaidMod", nil)
		end
		v_u_31:Destroy()
	end
	v_u_7 = v_u_15
	v_u_162()
	v_u_123()
	if not v_u_8 then
		v_u_8 = true
		v_u_13.command("mods.hud", function(p181)
			-- upvalues: (ref) v_u_7, (ref) v_u_6
			local v182 = v_u_7
			if not v182 then
				return "no HUD"
			end
			if p181[1] == "reset" then
				table.clear(v_u_6)
				return "cards forgotten"
			end
			if p181[1] == "fit" then
				return v182.fit()
			end
			local v183 = v182.state()
			local v184 = v183.id
			local v185 = tostring(v184)
			local v186 = v183.shown
			local v187 = tostring(v186)
			local v188 = v183.held
			local v189 = tostring(v188)
			local v190 = v183.phase
			local v191 = v183.card
			local v192 = tostring(v191)
			local v193 = v183.x
			local v194 = v183.y
			local v195 = v183.w
			local v196 = v183.h
			local v197 = v183.rightOff
			local v198 = v183.title
			local v199 = tostring(v198)
			local v200 = v183.line
			local v201 = tostring(v200)
			local v202 = v183.cardSub
			return ("id=%s shown=%s held=%s phase=%d card=%s pos=%.0f,%.0f size=%.0fx%.0f rightOff=%d title=%q line=%q cardSub=%q"):format(v185, v187, v189, v190, v192, v193, v194, v195, v196, v197, v199, v201, (tostring(v202)))
		end)
		v_u_13.command("mods.lamps", function(p203)
			-- upvalues: (copy) v_u_13, (copy) v_u_14
			local v204 = p203[1]
			local v205 = tonumber(v204) or 40
			local v206 = math.clamp(v205, 1, 200)
			local v207 = v_u_13.lib.WeatherLamps
			local v208 = v_u_13.shared.LampRule
			local v209 = v_u_14.Character
			if v209 then
				v209 = v209:FindFirstChild("HumanoidRootPart")
			end
			local v_u_210 = not v209 and Vector3.new(0, 0, 0) or v209.Position
			local v211 = v_u_13.runtime
			if v211 then
				v211 = v211:FindFirstChild("Raid")
			end
			local v212 = v208.readPower(v211)
			local v213 = {}
			for _, v214 in game:GetService("CollectionService"):GetTagged("HushLight") do
				if not (v214:IsA("BasePart") and v214:IsDescendantOf(workspace)) then
					continue
				end
				table.insert(v213, v214)
			end
			table.sort(v213, function(p215, p216)
				-- upvalues: (copy) v_u_210
				return (p215.Position - v_u_210).Magnitude < (p216.Position - v_u_210).Magnitude
			end)
			local v217 = v207.nearest(v_u_210, v206)
			local v218 = #v213
			local v219 = #v217
			local v220 = 0
			local v221 = 0
			local v222 = 0
			local v223 = {}
			for v224 = 1, math.min(v206, v218, v219) do
				local v225 = v213[v224]
				local v226 = v208.state(v225, v212)
				local v227 = v217[v224].dead == true and true or v217[v224].powered == false
				v220 = v220 + 1
				if v227 then
					v221 = v221 + 1
				end
				if v226 == v227 then
					v222 = v222 + 1
				else
					if #v223 >= 5 then
						continue
					end
					local v228 = string.format
					local v229 = v217[v224].kind
					local v230 = v217[v224].dist
					local v231 = tostring(v227)
					local v232 = tostring(v226)
					table.insert(v223, v228("%s d=%d wl=%s lr=%s", v229, v230, v231, v232))
				end
			end
			local v233 = v207.stats()
			local v234 = string.format
			local v235 = "BlackoutOn=%s snapshot=%s: LampRule parity %d / %d (%d dark on this client) | unpowered %d, active %d %s"
			if v211 then
				v211 = v211:GetAttribute("BlackoutOn")
			end
			return v234(v235, tostring(v211), not v212 and "nil" or v212.sig, v222, v220, v221, v233.unpowered, v233.active, table.concat(v223, "; "))
		end)
	end
	return v_u_15
end
return v4