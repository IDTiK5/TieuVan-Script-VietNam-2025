-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewListener

local v_u_45 = {
	["EAR_UP"] = 1.5,
	["OFF_GRACE"] = 0.6,
	["TARGET_MAX"] = 1000000000000000,
	["validTarget"] = function(p1) -- name: validTarget
		-- upvalues: (copy) v_u_45
		local v2
		if type(p1) == "number" and (p1 == p1 and (p1 >= 1 and p1 <= v_u_45.TARGET_MAX)) then
			v2 = p1 == math.floor(p1)
		else
			v2 = false
		end
		return v2
	end,
	["observing"] = function(p3, p4, p5) -- name: observing
		-- upvalues: (copy) v_u_45
		local v6 = v_u_45.validTarget(p3)
		if v6 then
			if p4 == true then
				v6 = p5 == false
			else
				v6 = false
			end
		end
		return v6
	end,
	["settle"] = function(p7, p8, p9) -- name: settle
		-- upvalues: (copy) v_u_45
		if p8 then
			p7.offAt = nil
			return true
		elseif p7.on == true then
			if p7.offAt == nil then
				p7.offAt = p9
			end
			return p9 - p7.offAt < v_u_45.OFF_GRACE
		else
			p7.offAt = nil
			return false
		end
	end,
	["audioPlace"] = function(p10, p11) -- name: audioPlace
		local v12 = (type(p10) ~= "string" or p10 == "") and "Menu" or p10
		return p11 and (v12 == "Transit" or v12 == "Menu") and "Raid" or v12
	end,
	["earPoint"] = function(p13, p14, p15, p16, p17, p18) -- name: earPoint
		-- upvalues: (copy) v_u_45
		local v19
		if type(p13) == "number" and (p13 == p13 and p13 > -1000000000000000) then
			v19 = p13 < 1000000000000000
		else
			v19 = false
		end
		if v19 then
			local v20
			if type(p14) == "number" and (p14 == p14 and p14 > -1000000000000000) then
				v20 = p14 < 1000000000000000
			else
				v20 = false
			end
			if v20 then
				local v21
				if type(p15) == "number" and (p15 == p15 and p15 > -1000000000000000) then
					v21 = p15 < 1000000000000000
				else
					v21 = false
				end
				if v21 then
					return p13, p14, p15
				end
			end
		end
		local v22
		if type(p16) == "number" and (p16 == p16 and p16 > -1000000000000000) then
			v22 = p16 < 1000000000000000
		else
			v22 = false
		end
		if v22 then
			local v23
			if type(p17) == "number" and (p17 == p17 and p17 > -1000000000000000) then
				v23 = p17 < 1000000000000000
			else
				v23 = false
			end
			if v23 then
				local v24
				if type(p18) == "number" and (p18 == p18 and p18 > -1000000000000000) then
					v24 = p18 < 1000000000000000
				else
					v24 = false
				end
				if v24 then
					return p16, p17 + v_u_45.EAR_UP, p18
				end
			end
		end
		return nil, nil, nil
	end,
	["decide"] = function(p25, p26, p27, p28, p29, p30) -- name: decide
		-- upvalues: (copy) v_u_45
		local v31 = v_u_45.observing(p26, p27, p28)
		local v32 = v_u_45.settle(p25, v31, p30)
		return v32, v_u_45.audioPlace(p29, v32), v31
	end,
	["why"] = function(p33, p34, p35) -- name: why
		-- upvalues: (copy) v_u_45
		return v_u_45.validTarget(p33) and (p34 == true and (p35 == false and "ok" or "body") or "reviewer") or "target"
	end,
	["status"] = function(p36, p37, p38) -- name: status
		return p36 and (p37 and "head" or "camera") or (p38 ~= "reviewer" and p38 ~= "body" and "off" or "off:" .. p38)
	end,
	["ownChar"] = function(p39, p40, p41, p42) -- name: ownChar
		if p39 == nil then
			if p41 == true and (p42 == true and p40 ~= nil) then
				return p40
			else
				return nil
			end
		else
			return p39
		end
	end,
	["fxRoute"] = function(p43) -- name: fxRoute
		if type(p43) ~= "table" then
			return nil
		end
		local v44 = p43.k
		return v44 == "shot" and "shot" or (v44 == "explode" and (p43.g == "frag" and "frag" or "blast") or (v44 == "flashbang" and "flash" or (v44 == "smokepop" and "smoke" or (v44 == "gland" and "bounce" or nil))))
	end
}
return v_u_45