-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AimPullFeed

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent.AimPull)
local v_u_4 = {
	["LOS_EVERY"] = 0.1,
	["MAX_LOS"] = 6,
	["LIST_RADIUS"] = v_u_3.RANGE_END + 2,
	["AXIS_SHARE"] = 0.33,
	["GAP_RESET"] = 0.25,
	["forceTouch"] = false
}
local v_u_5 = v_u_3.new()
local v_u_6 = -1000000000
local v_u_7 = {}
local v_u_8 = 0
local v_u_9 = {}
local v_u_10 = {
	["why"] = "off",
	["frames"] = 0,
	["pulled"] = 0,
	["cands"] = 0,
	["lastDeg"] = 0
}
local v_u_11 = -1000000000
local function v_u_23(p_u_12, p13) -- name: enabled
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_4
	local v14
	if p13 == "Touch" then
		v14 = true
	elseif v_u_2:IsStudio() then
		local v15 = v_u_1.LocalPlayer
		if v_u_4.forceTouch == true then
			v14 = true
		elseif v15 == nil then
			v14 = false
		else
			v14 = v15:GetAttribute("AimPullTest") == true
		end
	else
		v14 = false
	end
	if not v14 then
		return false, "device"
	end
	local v16 = v_u_1.LocalPlayer
	if v16 == nil or v16:GetAttribute("AimAssist") == false then
		return false, "setting"
	end
	if p_u_12 == nil then
		return false, "context"
	end
	local v_u_17 = "FpAim"
	local v18, v19 = pcall(function()
		-- upvalues: (copy) p_u_12, (copy) v_u_17
		return p_u_12.lib[v_u_17]
	end)
	if not v18 or type(v19) ~= "table" then
		v19 = nil
	end
	if v19 ~= nil then
		local v20 = v19.isActive
		if type(v20) == "function" and v19.isActive() == true then
			local v21, v22 = pcall(function()
				-- upvalues: (copy) p_u_12
				return p_u_12.shared.GameMode.rule("viewModes")
			end)
			if v21 and v22 == false then
				return false, "game"
			else
				return true, "on"
			end
		end
	end
	return false, "mode"
end
local function v_u_34(p_u_24, p25) -- name: bodyOf
	-- upvalues: (copy) v_u_9, (copy) v_u_4
	local v_u_26 = type(p25) ~= "string" and "?" or p25
	local v27 = v_u_9[v_u_26]
	if v27 == nil then
		local v28 = 1.2
		local v29 = 5.9
		local v30, v31 = pcall(function()
			-- upvalues: (copy) p_u_24, (copy) v_u_26
			return p_u_24.shared.ZombieTypes.get(v_u_26)
		end)
		if v30 and type(v31) == "table" then
			local v32 = v31.radius
			if type(v32) == "number" and v31.radius > 0 then
				v28 = v31.radius
			end
			local v33 = v31.height
			if type(v33) == "number" and v31.height > 0 then
				v29 = v31.height
			end
		end
		v27 = {
			["r"] = v28,
			["h"] = v29 * v_u_4.AXIS_SHARE
		}
		v_u_9[v_u_26] = v27
	end
	return v27.r, v27.h
end
function v_u_4.step(p35, p36, p37, p38, p39, p40, p41, p42, p_u_43) -- name: step
	-- upvalues: (copy) v_u_23, (copy) v_u_10, (copy) v_u_5, (copy) v_u_3, (ref) v_u_11, (copy) v_u_2, (copy) v_u_1, (copy) v_u_4, (ref) v_u_6, (copy) v_u_7, (ref) v_u_8, (copy) v_u_34
	local v44, v45 = v_u_23(p_u_43, p42)
	v_u_10.why = v45
	if not v44 then
		if v_u_5.id ~= nil or v_u_5.w ~= 0 then
			v_u_3.reset(v_u_5)
		end
		if v45 ~= "device" and p36 - v_u_11 > 0.25 then
			local v46
			if v_u_2:IsStudio() then
				local v47 = v_u_1.LocalPlayer
				if v_u_4.forceTouch == true then
					v46 = true
				elseif v47 == nil then
					v46 = false
				else
					v46 = v47:GetAttribute("AimPullTest") == true
				end
			else
				v46 = false
			end
			if v46 then
				v_u_11 = p36
				v_u_1.LocalPlayer:SetAttribute("AimPullState", v_u_4.debugState())
			end
		end
		return 0, 0
	end
	if p36 - v_u_6 > v_u_4.GAP_RESET then
		v_u_3.reset(v_u_5)
		table.clear(v_u_7)
		v_u_8 = 0
	end
	v_u_6 = p36
	if typeof(p37) ~= "CFrame" then
		v_u_10.why = "camera"
		return 0, 0
	end
	local v_u_48 = "ZombieRender"
	local v49, v50 = pcall(function()
		-- upvalues: (copy) p_u_43, (copy) v_u_48
		return p_u_43.controllers[v_u_48]
	end)
	if not v49 or (type(v50) ~= "table" or v50._broken) then
		v50 = nil
	end
	local v_u_51 = "FpAim"
	local v52, v_u_53 = pcall(function()
		-- upvalues: (copy) p_u_43, (copy) v_u_51
		return p_u_43.lib[v_u_51]
	end)
	if not v52 or type(v_u_53) ~= "table" then
		v_u_53 = nil
	end
	if v50 ~= nil then
		local v54 = v50.targets
		if type(v54) == "function" and v_u_53 ~= nil then
			local v55 = v_u_53.lineClear
			if type(v55) == "function" then
				local v_u_56 = p37.Position
				local v57 = v50.targets
				local v58 = v_u_4.LIST_RADIUS
				local v59, v60 = pcall(v57, v_u_56, v58)
				if not v59 or type(v60) ~= "table" then
					v_u_10.why = "targets"
					return 0, 0
				end
				if v_u_8 > 200 then
					table.clear(v_u_7)
					v_u_8 = 0
				end
				local v61 = {}
				for _, v62 in v60 do
					if type(v62) ~= "table" then
						continue
					end
					local v63 = v62.position
					if typeof(v63) ~= "Vector3" or (v62.visible == false or v62.dead == true) then
						continue
					end
					local v64 = v62.position
					local v65 = v64 - v_u_56
					local v66 = v65.Magnitude
					if v66 < v_u_3.MIN_DIST or v_u_3.RANGE_END < v66 then
						continue
					end
					local v67, v68 = v_u_34(p_u_43, v62.typeId)
					local v69, v70 = v_u_3.dirAngles(v65.X, v65.Y, v65.Z)
					local v71 = math.atan2(v68, v66)
					local v72 = math.deg(v71)
					if v_u_3.angleDeg(p38, p39, v69, v70) > v_u_3.CONE_END + v72 then
						continue
					end
					local v73 = {
						["id"] = nil,
						["x"] = nil,
						["y"] = nil,
						["z"] = nil,
						["r"] = nil,
						["h"] = nil,
						["alive"] = true,
						["los"] = false,
						["pos"] = nil,
						["id"] = v62.id,
						["x"] = v64.X,
						["y"] = v64.Y,
						["z"] = v64.Z,
						["r"] = v67,
						["h"] = v68,
						["pos"] = v64
					}
					table.insert(v61, v73)
				end
				local _, v75 = v_u_3.sightLines(v61, v_u_5.id, v_u_7, p36, v_u_4.LOS_EVERY, v_u_4.MAX_LOS, function(p74)
					-- upvalues: (copy) v_u_53, (copy) v_u_56
					return v_u_53.lineClear(v_u_56, p74.pos) == true
				end)
				v_u_8 = v_u_8 + v75
				v_u_10.cands = #v61
				local v76 = v_u_10
				v76.frames = v76.frames + 1
				local v77 = v_u_3.step
				local v78 = v_u_5
				local v79 = {
					["dt"] = p35,
					["camX"] = v_u_56.X,
					["camY"] = v_u_56.Y,
					["camZ"] = v_u_56.Z,
					["yaw"] = p38,
					["pitch"] = p39,
					["lookYaw"] = p40,
					["lookPitch"] = p41
				}
				local v_u_80 = "Input"
				local v81, v82 = pcall(function()
					-- upvalues: (copy) p_u_43, (copy) v_u_80
					return p_u_43.controllers[v_u_80]
				end)
				if not v81 or (type(v82) ~= "table" or v82._broken) then
					v82 = nil
				end
				local v83
				if v82 then
					local v84 = v82.isAiming
					if type(v84) == "function" then
						local v85 = v82.isAiming
						local v86
						v83, v86 = pcall(v85)
						if v83 then
							v83 = v86 == true
						end
					else
						v83 = false
					end
				else
					v83 = false
				end
				v79.aiming = v83
				local v_u_87 = "Input"
				local v88, v89 = pcall(function()
					-- upvalues: (copy) p_u_43, (copy) v_u_87
					return p_u_43.controllers[v_u_87]
				end)
				if not v88 or (type(v89) ~= "table" or v89._broken) then
					v89 = nil
				end
				local v90
				if v89 then
					local v91 = v89.isFiring
					if type(v91) == "function" then
						local v92 = v89.isFiring
						local v93
						v90, v93 = pcall(v92)
						if v90 then
							v90 = v93 == true
						end
					else
						v90 = false
					end
				else
					v90 = false
				end
				v79.firing = v90
				v79.targets = v61
				local v94, v95 = v77(v78, v79)
				v_u_10.lastDeg = v_u_5.lastDeg
				if v94 ~= 0 or v95 ~= 0 then
					local v96 = v_u_10
					v96.pulled = v96.pulled + 1
				end
				if p36 - v_u_11 > 0.25 then
					local v97
					if v_u_2:IsStudio() then
						local v98 = v_u_1.LocalPlayer
						if v_u_4.forceTouch == true then
							v97 = true
						elseif v98 == nil then
							v97 = false
						else
							v97 = v98:GetAttribute("AimPullTest") == true
						end
					else
						v97 = false
					end
					if v97 then
						v_u_11 = p36
						local v99 = v_u_1.LocalPlayer
						if v99 ~= nil then
							v99:SetAttribute("AimPullState", v_u_4.debugState())
						end
					end
				end
				return v94, v95
			end
		end
	end
	v_u_10.why = "modules"
	return 0, 0
end
function v_u_4.debugState() -- name: debugState
	-- upvalues: (copy) v_u_10, (copy) v_u_5
	local v100 = string.format
	local v101 = v_u_10.why
	local v102 = v_u_5.id
	return v100("aimpull %s target=%s w=%.2f err=%.2f deg step=%.3f deg cands=%d frames=%d pulled=%d", v101, tostring(v102), v_u_5.w, v_u_5.lastErr, v_u_10.lastDeg, v_u_10.cands, v_u_10.frames, v_u_10.pulled)
end
return v_u_4