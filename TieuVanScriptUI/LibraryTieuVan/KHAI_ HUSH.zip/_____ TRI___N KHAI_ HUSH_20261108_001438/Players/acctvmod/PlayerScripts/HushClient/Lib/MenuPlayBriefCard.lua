-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayBriefCard

local v1 = {}
local v_u_2 = {
	["difficulty"] = "skull",
	["time"] = "clock",
	["kit"] = "backpack",
	["raid"] = "squad",
	["mode"] = "eye"
}
local v_u_3 = {
	["full"] = "wide",
	["compact"] = "compact",
	["strip"] = "phone",
	["mini"] = "phone"
}
function v1.new(p4, p5, p_u_6) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v_u_7 = p4.ui
	local v_u_8 = p4.theme
	local v_u_9 = v_u_8.color
	local v_u_10 = p4.cctx.lib
	local v_u_11 = v_u_10.PlayBriefLayout
	local v12 = v_u_10.PlayBriefModel
	local v_u_13 = {
		["tiles"] = nil,
		["density"] = "hidden",
		["tiles"] = {}
	}
	local v_u_14 = v_u_7.new("Frame", {
		["Name"] = "BriefCard",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_9.raised
	}, p5)
	v_u_7.stroke(v_u_14, v_u_9.line)
	v_u_7.new("Frame", {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 6,
		["BackgroundColor3"] = v_u_9.accent,
		["Size"] = UDim2.new(1, 0, 0, 2)
	}, v_u_14)
	v_u_13.frame = v_u_14
	local v_u_15 = v_u_7.label({
		["parent"] = nil,
		["name"] = "HeaderLeft",
		["text"] = nil,
		["style"] = "caps",
		["textSize"] = 13,
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["zindex"] = 3,
		["parent"] = v_u_14,
		["text"] = v12.T.brief,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 18)
	})
	local v_u_16 = v_u_7.label({
		["parent"] = nil,
		["name"] = "HeaderRight",
		["text"] = "",
		["style"] = "caps",
		["textSize"] = 12,
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["track"] = false,
		["zindex"] = 3,
		["parent"] = v_u_14,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 18)
	})
	local v_u_17 = v_u_7.icon("lock", {
		["parent"] = nil,
		["name"] = "HeaderLock",
		["size"] = 12,
		["thickness"] = 1.5,
		["color"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_14,
		["color"] = v_u_9.accent
	})
	local v_u_18 = {}
	local v_u_19 = {}
	for v20 = 1, 4 do
		local v21 = v_u_7.new("ImageLabel", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["ScaleType"] = nil,
			["Name"] = "Head" .. v20,
			["BackgroundColor3"] = v_u_9.raised2,
			["Size"] = UDim2.fromOffset(24, 24),
			["ScaleType"] = Enum.ScaleType.Crop
		}, v_u_14)
		v_u_7.new("UICorner", {
			["CornerRadius"] = UDim.new(0.5, 0)
		}, v21)
		v_u_7.stroke(v21, v_u_9.line)
		table.insert(v_u_18, v21)
	end
	local v_u_22 = v_u_7.new("TextButton", {
		["Name"] = "BriefMap",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Selectable"] = true,
		["ClipsDescendants"] = true,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_9.bgDeep
	}, v_u_14)
	v_u_22.SelectionImageObject = v_u_7.selectionImage()
	local v_u_23 = v_u_7.stroke(v_u_22, v_u_9.line)
	local v_u_24 = v_u_7.new("Frame", {
		["Name"] = "Pic",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["Active"] = false,
		["BackgroundColor3"] = v_u_9.bgDeep
	}, v_u_22)
	local v_u_25 = nil
	local function v29()
		-- upvalues: (copy) v_u_10, (ref) v_u_25, (copy) v_u_24, (copy) v_u_8
		local v26 = v_u_10.MapPicture
		if type(v26) == "table" then
			local v27 = v26.new
			if type(v27) == "function" then
				local v28 = {
					["height"] = 176,
					["theme"] = nil,
					["theme"] = v_u_8
				}
				v_u_25 = v26.new(v_u_24, v28)
			end
		end
	end
	pcall(v29)
	local v_u_30 = v_u_7.new("Frame", {
		["Name"] = "Shade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Active"] = false,
		["BackgroundColor3"] = v_u_9.bgDeep,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_22)
	v_u_7.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.4, 0.85), NumberSequenceKeypoint.new(1, 0.1) })
	}, v_u_30)
	local function v33(p31) -- name: chip
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_22
		local v32 = v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Active"] = false,
			["Visible"] = false,
			["Name"] = p31,
			["BackgroundColor3"] = v_u_9.accentDeep,
			["Size"] = UDim2.fromOffset(60, 22)
		}, v_u_22)
		v_u_7.stroke(v32, v_u_9.accentDim)
		return v32, v_u_7.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["zindex"] = 5,
			["parent"] = v32,
			["color"] = v_u_9.accent,
			["position"] = UDim2.fromOffset(4, 0),
			["size"] = UDim2.new(1, -8, 1, 0)
		})
	end
	local v_u_34, v_u_35 = v33("ActChip")
	local v_u_36, v_u_37 = v33("StateChip")
	local v_u_38 = v_u_7.label({
		["parent"] = nil,
		["name"] = "MapName",
		["text"] = "",
		["style"] = "h1",
		["textSize"] = 38,
		["size"] = nil,
		["fit"] = true,
		["zindex"] = 4,
		["track"] = false,
		["parent"] = v_u_22,
		["size"] = UDim2.fromOffset(100, 40)
	})
	local v_u_39 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Tagline",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["track"] = false,
		["parent"] = v_u_22,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 18)
	})
	local v_u_40 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Stats",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["track"] = false,
		["parent"] = v_u_22,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 16)
	})
	local v_u_41 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Meta",
		["text"] = "",
		["style"] = "micro",
		["textSize"] = 13,
		["color"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["track"] = false,
		["fit"] = true,
		["parent"] = v_u_22,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 16)
	})
	local v_u_42 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Values",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["track"] = false,
		["parent"] = v_u_22,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(100, 18)
	})
	local v_u_43 = v_u_7.label({
		["parent"] = nil,
		["name"] = "SetupWord",
		["text"] = nil,
		["style"] = "caps",
		["textSize"] = 13,
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["zindex"] = 4,
		["track"] = false,
		["parent"] = v_u_22,
		["text"] = string.upper(v12.T.setup),
		["color"] = v_u_9.accent,
		["size"] = UDim2.fromOffset(60, 18)
	})
	local v_u_44 = v_u_7.new("Frame", {
		["Name"] = "Chevron",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Active"] = false,
		["BackgroundColor3"] = v_u_9.raised,
		["Size"] = UDim2.fromOffset(36, 36)
	}, v_u_22)
	v_u_7.stroke(v_u_44, v_u_9.line)
	v_u_7.icon("chevronRight", {
		["parent"] = nil,
		["size"] = 16,
		["thickness"] = 2,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["zindex"] = 5,
		["parent"] = v_u_44,
		["color"] = v_u_9.text2,
		["position"] = UDim2.fromScale(0.5, 0.5),
		["anchor"] = Vector2.new(0.5, 0.5)
	})
	v_u_13.mapBtn = v_u_22
	local v45 = v_u_22.MouseEnter
	table.insert(v_u_19, v45:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8
		v_u_23.Color = v_u_9.accent
		v_u_7.sound(v_u_8.sounds.hover)
	end))
	local v46 = v_u_22.MouseLeave
	table.insert(v_u_19, v46:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_9
		v_u_23.Color = v_u_9.line
	end))
	local v47 = v_u_22.SelectionGained
	table.insert(v_u_19, v47:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_9
		v_u_23.Color = v_u_9.accent
	end))
	local v48 = v_u_22.SelectionLost
	table.insert(v_u_19, v48:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_9
		v_u_23.Color = v_u_9.line
	end))
	local v49 = v_u_22.Activated
	table.insert(v_u_19, v49:Connect(function()
		-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) p_u_6, (copy) v_u_22
		v_u_7.sound(v_u_8.sounds.click)
		if p_u_6.onMap then
			p_u_6.onMap(v_u_22)
		end
	end))
	local v_u_50 = v_u_7.new("TextButton", {
		["Name"] = "BriefSetupHit",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Selectable"] = false,
		["ZIndex"] = 2,
		["Visible"] = false
	}, v_u_14)
	local v51 = v_u_50.Activated
	table.insert(v_u_19, v51:Connect(function()
		-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) p_u_6, (copy) v_u_22
		v_u_7.sound(v_u_8.sounds.click)
		if p_u_6.onMap then
			p_u_6.onMap(v_u_22)
		end
	end))
	local function v71(p_u_52) -- name: mkTile
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_14, (ref) v_u_2, (copy) v_u_19, (copy) v_u_8, (copy) p_u_6
		local v_u_53 = v_u_7.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Selectable"] = true,
			["ClipsDescendants"] = true,
			["ZIndex"] = 2,
			["Name"] = "BriefTile_" .. p_u_52,
			["BackgroundColor3"] = v_u_9.raised
		}, v_u_14)
		v_u_53.SelectionImageObject = v_u_7.selectionImage()
		local v_u_54 = v_u_7.stroke(v_u_53, v_u_9.line)
		local v_u_55 = {
			["id"] = nil,
			["btn"] = nil,
			["stroke"] = nil,
			["flash"] = nil,
			["icon"] = nil,
			["label"] = nil,
			["value"] = nil,
			["sub"] = nil,
			["chev"] = nil,
			["lock"] = nil,
			["why"] = nil,
			["shown"] = "",
			["id"] = p_u_52,
			["btn"] = v_u_53,
			["stroke"] = v_u_54,
			["flash"] = v_u_7.new("Frame", {
				["Name"] = "Flash",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 4,
				["Active"] = false,
				["BackgroundColor3"] = v_u_9.accent,
				["Size"] = UDim2.new(1, 0, 0, 2)
			}, v_u_53),
			["icon"] = v_u_7.icon(v_u_2[p_u_52], {
				["parent"] = nil,
				["name"] = "Icon",
				["size"] = 20,
				["thickness"] = 2,
				["color"] = nil,
				["zindex"] = 3,
				["parent"] = v_u_53,
				["color"] = v_u_9.text2
			}),
			["label"] = v_u_7.label({
				["parent"] = nil,
				["name"] = "Label",
				["text"] = "",
				["style"] = "caps",
				["textSize"] = 13,
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["zindex"] = 3,
				["fit"] = true,
				["parent"] = v_u_53,
				["color"] = v_u_9.text2,
				["size"] = UDim2.fromOffset(60, 16)
			}),
			["value"] = v_u_7.label({
				["parent"] = nil,
				["name"] = "Value",
				["text"] = "",
				["style"] = "h3",
				["textSize"] = 20,
				["size"] = nil,
				["track"] = false,
				["zindex"] = 3,
				["fit"] = true,
				["parent"] = v_u_53,
				["size"] = UDim2.fromOffset(60, 26)
			}),
			["sub"] = v_u_7.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = "",
				["style"] = "small",
				["textSize"] = 12,
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["zindex"] = 3,
				["fit"] = true,
				["parent"] = v_u_53,
				["color"] = v_u_9.text2,
				["size"] = UDim2.fromOffset(60, 16)
			}),
			["chev"] = v_u_7.icon("chevronRight", {
				["parent"] = nil,
				["name"] = "Chevron",
				["size"] = 14,
				["thickness"] = 2,
				["color"] = nil,
				["zindex"] = 3,
				["parent"] = v_u_53,
				["color"] = v_u_9.text2
			}),
			["lock"] = v_u_7.icon("lock", {
				["parent"] = nil,
				["name"] = "Lock",
				["size"] = 12,
				["thickness"] = 1.5,
				["color"] = nil,
				["zindex"] = 3,
				["parent"] = v_u_53,
				["color"] = v_u_9.muted
			})
		}
		local v56 = v_u_19
		local v57 = v_u_53.MouseEnter
		local function v58()
			-- upvalues: (copy) v_u_54, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8
			v_u_54.Color = v_u_9.accent
			v_u_7.sound(v_u_8.sounds.hover)
		end
		table.insert(v56, v57:Connect(v58))
		local v59 = v_u_19
		local v60 = v_u_53.MouseLeave
		local function v61()
			-- upvalues: (copy) v_u_54, (ref) v_u_9
			v_u_54.Color = v_u_9.line
		end
		table.insert(v59, v60:Connect(v61))
		local v62 = v_u_19
		local v63 = v_u_53.SelectionGained
		local function v64()
			-- upvalues: (copy) v_u_54, (ref) v_u_9
			v_u_54.Color = v_u_9.accent
		end
		table.insert(v62, v63:Connect(v64))
		local v65 = v_u_19
		local v66 = v_u_53.SelectionLost
		local function v67()
			-- upvalues: (copy) v_u_54, (ref) v_u_9
			v_u_54.Color = v_u_9.line
		end
		table.insert(v65, v66:Connect(v67))
		local v68 = v_u_19
		local v69 = v_u_53.Activated
		local function v70()
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) p_u_6, (copy) p_u_52, (copy) v_u_53
			v_u_7.sound(v_u_8.sounds.click)
			if p_u_6.onTile then
				p_u_6.onTile(p_u_52, v_u_53)
			end
		end
		table.insert(v68, v69:Connect(v70))
		v_u_7.tooltip(v_u_53, function()
			-- upvalues: (copy) p_u_52, (copy) v_u_55
			return {
				["title"] = string.upper(p_u_52),
				["body"] = v_u_55.why or ""
			}
		end)
		return v_u_55
	end
	local v_u_72 = v_u_25
	for _, v73 in v_u_11.TILE_IDS_PVE do
		v_u_13.tiles[v73] = v71(v73)
	end
	local v_u_74 = v_u_7.button({
		["parent"] = nil,
		["name"] = "BriefSetup",
		["text"] = nil,
		["kind"] = "secondary",
		["icon"] = "settings",
		["size"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_14,
		["text"] = v12.T.raidSetup,
		["size"] = UDim2.fromOffset(100, 48),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_6, (copy) v_u_13
			if p_u_6.onSetup then
				p_u_6.onSetup(v_u_13.setupBtn)
			end
		end
	})
	v_u_74.ZIndex = 2
	v_u_13.setupBtn = v_u_74
	local v_u_75 = v_u_7.label({
		["parent"] = nil,
		["name"] = "PadGlyph",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["zindex"] = 4,
		["visible"] = false,
		["parent"] = v_u_74,
		["color"] = v_u_9.accent,
		["anchor"] = Vector2.new(1, 0.5),
		["position"] = UDim2.new(1, -10, 0.5, 0),
		["size"] = UDim2.fromOffset(28, 22)
	})
	function v_u_13.padGlyph(p76) -- name: padGlyph
		-- upvalues: (copy) v_u_7, (copy) v_u_75
		local v77 = not p76 and "" or v_u_7.hint("reload")
		v_u_75.Text = v77
		local v78 = v_u_75
		if p76 then
			p76 = v77 ~= ""
		end
		v78.Visible = p76
	end
	pcall(function()
		-- upvalues: (copy) v_u_13, (copy) v_u_7, (copy) v_u_19
		v_u_13.padGlyph(v_u_7.device() == "Gamepad")
		local v79 = v_u_19
		local v81 = {
			["Disconnect"] = v_u_7.onDevice(function(p80)
				-- upvalues: (ref) v_u_13
				v_u_13.padGlyph(p80 == "Gamepad")
			end)
		}
		table.insert(v79, v81)
	end)
	function v_u_13.apply(p82, p83, p84, p85) -- name: apply
		-- upvalues: (copy) v_u_13, (copy) v_u_14, (ref) v_u_3, (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_22, (copy) v_u_30, (copy) v_u_24, (copy) v_u_34, (copy) v_u_36, (copy) v_u_38, (copy) v_u_39, (copy) v_u_40, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_50, (copy) v_u_8, (ref) v_u_72, (copy) v_u_11, (copy) v_u_74
		v_u_13.density = p82
		v_u_14.Visible = p82 ~= "hidden"
		v_u_14.Size = UDim2.fromOffset(p84, p85)
		v_u_13.inner = p83
		if p82 ~= "hidden" then
			local v86 = v_u_3[p82]
			local v87 = p82 == "full" and true or p82 == "compact"
			for _, v88 in { v_u_15, v_u_16, v_u_17 } do
				v88.Visible = v87
			end
			if v87 then
				local v89 = p83.header
				local v90 = v_u_15
				local v91 = v_u_15
				local v92 = UDim2.fromOffset(v89.x, v89.y)
				local v93 = UDim2.fromOffset(v89.w * 0.4, v89.h)
				v90.Position = v92
				v91.Size = v93
			end
			local v94 = p83.art or p83.mapHit or (p83.header or p83.row)
			local v95 = v_u_22
			if v94 == nil then
				v95.Visible = false
			else
				v95.Position = UDim2.fromOffset(v94.x, v94.y)
				v95.Size = UDim2.fromOffset(v94.w, v94.h)
				v95.Visible = true
			end
			local v96 = v94.w
			local v97 = v94.h
			local v98 = p83.art ~= nil
			v_u_30.Visible = v98
			v_u_24.Visible = true
			for _, v99 in {
				v_u_34,
				v_u_36,
				v_u_38,
				v_u_39,
				v_u_40,
				v_u_41,
				v_u_42,
				v_u_43,
				v_u_44
			} do
				v99.Visible = false
			end
			local v100 = v_u_44
			local v101 = v_u_22
			v_u_43.Parent = v_u_22
			v100.Parent = v101
			v_u_50.Visible = false
			if v98 then
				local v102 = v_u_24
				local v103 = v_u_24
				local v104 = UDim2.fromOffset(0, 0)
				local v105 = UDim2.fromScale(1, 1)
				v102.Position = v104
				v103.Size = v105
				local v106 = p82 == "full"
				local v107 = v106 and 44 or 30
				v_u_38.TextSize = v_u_8.phoneText(v106 and 38 or 28, "text")
				local v108 = v97 - 8 - 16
				local v109 = v108 - 2 - 18
				local v110 = v109 - 2 - v107
				local v111 = v96 - 14 - 60
				local v112 = v_u_38
				local v113 = v_u_38
				local v114 = v_u_38
				local v115 = UDim2.fromOffset(14, v110)
				local v116 = UDim2.fromOffset(v111, v107)
				v112.Position = v115
				v113.Size = v116
				v114.Visible = true
				local v117 = v_u_39
				local v118 = v_u_39
				local v119 = v_u_39
				local v120 = UDim2.fromOffset(14, v109)
				local v121 = UDim2.fromOffset(v111, 18)
				v117.Position = v120
				v118.Size = v121
				v119.Visible = true
				local v122 = v_u_40
				local v123 = v_u_40
				local v124 = v_u_40
				local v125 = UDim2.fromOffset(14, v108)
				local v126 = UDim2.fromOffset(v111, 16)
				v122.Position = v125
				v123.Size = v126
				v124.Visible = true
				local v127 = v_u_44
				local v128 = v_u_44
				local v129 = v_u_44
				local v130 = UDim2.fromOffset(v96 - 10 - 36, (v97 - 36) // 2)
				local v131 = UDim2.fromOffset(36, 36)
				v127.Position = v130
				v128.Size = v131
				v129.Visible = true
				local v132 = v_u_34
				local v133 = v_u_34
				local v134 = UDim2.fromOffset(10, 10)
				local v135 = UDim2.fromOffset(64, 22)
				v132.Position = v134
				v133.Size = v135
				v_u_36.Size = UDim2.fromOffset(132, 22)
				v_u_36.Position = UDim2.fromOffset(v96 - 10 - 132, 10)
			elseif p82 == "strip" then
				local v136 = v_u_24
				local v137 = v_u_24
				local v138 = UDim2.fromOffset(0, 0)
				local v139 = UDim2.fromOffset(88, v97)
				v136.Position = v138
				v137.Size = v139
				local v140 = v96 - 88 - 10 - 84
				if p83.text ~= nil then
					v140 = p83.text.w
				end
				v_u_38.TextSize = v_u_8.phoneText(18, "text")
				local v141 = v_u_38
				local v142 = v_u_38
				local v143 = v_u_38
				local v144 = UDim2.fromOffset(98, 4)
				local v145 = UDim2.fromOffset(v140, 24)
				v141.Position = v144
				v142.Size = v145
				v143.Visible = true
				local v146 = v_u_41
				local v147 = v_u_41
				local v148 = v_u_41
				local v149 = UDim2.fromOffset(98, 30)
				local v150 = UDim2.fromOffset(v140, 18)
				v146.Position = v149
				v147.Size = v150
				v148.Visible = true
				if p83.mapHit == nil then
					local v151 = v_u_44
					local v152 = v_u_22
					v_u_43.Parent = v_u_22
					v151.Parent = v152
					local v153 = v_u_43
					local v154 = v_u_43
					local v155 = v_u_43
					local v156 = UDim2.fromOffset(v96 - 84, (v97 - 18) // 2)
					local v157 = UDim2.fromOffset(62, 18)
					v153.Position = v156
					v154.Size = v157
					v155.Visible = true
					v_u_44.Size = UDim2.fromOffset(18, 18)
					local v158 = v_u_44
					v_u_44.Position = UDim2.fromOffset(v96 - 20, (v97 - 18) // 2)
					v158.Visible = true
				else
					local v159 = p83.setup
					local v160 = v_u_44
					local v161 = v_u_14
					v_u_43.Parent = v_u_14
					v160.Parent = v161
					local v162 = v_u_43
					local v163 = v_u_43
					local v164 = v_u_43
					local v165 = UDim2.fromOffset(v159.x, v159.y + (v97 - 18) // 2)
					local v166 = UDim2.fromOffset(62, 18)
					v162.Position = v165
					v163.Size = v166
					v164.Visible = true
					v_u_44.Size = UDim2.fromOffset(18, 18)
					local v167 = v_u_44
					v_u_44.Position = UDim2.fromOffset(v159.x + 84 - 20, v159.y + (v97 - 18) // 2)
					v167.Visible = true
					local v168 = v_u_50
					if v159 == nil then
						v168.Visible = false
					else
						v168.Position = UDim2.fromOffset(v159.x, v159.y)
						v168.Size = UDim2.fromOffset(v159.w, v159.h)
						v168.Visible = true
					end
				end
			else
				local v169 = v_u_24
				local v170 = v_u_24
				local v171 = UDim2.fromOffset(0, 0)
				local v172 = UDim2.fromOffset(72, v97)
				v169.Position = v171
				v170.Size = v172
				local v173 = v96 - 72 - 8 - 28
				v_u_38.TextSize = v_u_8.phoneText(18, "text")
				local v174 = v_u_38
				local v175 = v_u_38
				local v176 = v_u_38
				local v177 = UDim2.fromOffset(80, 4)
				local v178 = UDim2.fromOffset(v173, 24)
				v174.Position = v177
				v175.Size = v178
				v176.Visible = true
				local v179 = v_u_42
				local v180 = v_u_42
				local v181 = v_u_42
				local v182 = UDim2.fromOffset(80, 30)
				local v183 = UDim2.fromOffset(v173, 18)
				v179.Position = v182
				v180.Size = v183
				v181.Visible = true
				v_u_44.Size = UDim2.fromOffset(18, 18)
				local v184 = v_u_44
				v_u_44.Position = UDim2.fromOffset(v96 - 22, (v97 - 18) // 2)
				v184.Visible = true
			end
			if v_u_72 and v_u_13.def then
				local v185 = v_u_72.set
				local v186 = v_u_13.def
				pcall(v185, v186)
			end
			for _, v187 in v_u_13.tiles do
				v187.btn.Visible = false
			end
			local v188 = p83.tiles
			if p83.modeChip ~= nil then
				v188 = {}
				for _, v189 in p83.tiles do
					table.insert(v188, v189)
				end
				local v190 = {
					["id"] = "mode",
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["dense"] = true,
					["x"] = p83.modeChip.x,
					["y"] = p83.modeChip.y,
					["w"] = p83.modeChip.w,
					["h"] = p83.modeChip.h
				}
				table.insert(v188, v190)
			end
			for _, v191 in v188 do
				local v192 = v_u_13.tiles[v191.id]
				local v193 = v192.btn
				if v191 == nil then
					v193.Visible = false
				else
					v193.Position = UDim2.fromOffset(v191.x, v191.y)
					v193.Size = UDim2.fromOffset(v191.w, v191.h)
					v193.Visible = true
				end
				local v194 = v_u_11.tileParts(v86, v191.w, v191.h, v191.dense == true)
				v192.icon.Visible = v194.icon ~= nil
				if v194.icon then
					v192.icon.Position = UDim2.fromOffset(v194.icon.x, v194.icon.y)
				end
				local v195 = v192.label
				local v196 = v194.label
				if v196 == nil then
					v195.Visible = false
				else
					v195.Position = UDim2.fromOffset(v196.x, v196.y)
					v195.Size = UDim2.fromOffset(v196.w, v196.h)
					v195.Visible = true
				end
				local v197 = v192.value
				local v198 = v194.value
				if v198 == nil then
					v197.Visible = false
				else
					v197.Position = UDim2.fromOffset(v198.x, v198.y)
					v197.Size = UDim2.fromOffset(v198.w, v198.h)
					v197.Visible = true
				end
				v192.label.TextSize = v_u_8.phoneText(v194.sizes.label, "caption")
				v192.value.TextSize = v_u_8.phoneText(v194.sizes.value, "text")
				v192.sub.Visible = v194.sub ~= nil
				if v194.sub then
					local v199 = v192.sub
					local v200 = v194.sub
					if v200 == nil then
						v199.Visible = false
					else
						v199.Position = UDim2.fromOffset(v200.x, v200.y)
						v199.Size = UDim2.fromOffset(v200.w, v200.h)
						v199.Visible = true
					end
					v192.sub.TextSize = v_u_8.phoneText(v194.sizes.sub, "caption")
				end
				v192.chev.Position = UDim2.fromOffset(v194.chevron and (v194.chevron.x or 0) or 0, v194.chevron and (v194.chevron.y or 0) or 0)
				v192.lock.Position = UDim2.fromOffset((v194.chevron and (v194.chevron.x or 0) or 0) + 1, (v194.chevron and (v194.chevron.y or 0) or 0) + 1)
				v192.hasChev = v194.chevron ~= nil
			end
			local v201 = v_u_74
			local v202
			if v87 then
				v202 = p83.setup
			else
				v202 = nil
			end
			if v202 == nil then
				v201.Visible = false
			else
				v201.Position = UDim2.fromOffset(v202.x, v202.y)
				v201.Size = UDim2.fromOffset(v202.w, v202.h)
				v201.Visible = true
			end
			v_u_13.last = nil
			if v_u_13.view then
				v_u_13.paint(v_u_13.view, v_u_13.st)
			end
		end
	end
	function v_u_13.paint(p203, p204) -- name: paint
		-- upvalues: (copy) v_u_13, (copy) v_u_16, (copy) v_u_7, (copy) v_u_9, (copy) v_u_17, (copy) v_u_18, (copy) v_u_38, (copy) v_u_39, (copy) v_u_40, (copy) v_u_34, (copy) v_u_35, (copy) v_u_36, (copy) v_u_37, (copy) v_u_41, (copy) v_u_42, (copy) v_u_22, (copy) v_u_8
		local v205 = v_u_13
		v_u_13.view = p203
		v205.st = p204
		if v_u_13.density ~= "hidden" then
			local v206 = v_u_13.density
			local v207 = v206 == "strip" and true or v206 == "mini"
			local v208 = p203.map
			if type(p204) == "table" and (p204.mapDef ~= nil and p204.mapDef ~= v_u_13.def) then
				v_u_13.setMap(p204.mapDef)
			end
			local v209 = v_u_16
			local v210 = string.upper(p203.header.right)
			if v209.Text ~= v210 then
				v_u_7.setText(v209, v210)
			end
			local v211 = v_u_16
			local v212
			if p203.header.tone == "accent" then
				v212 = v_u_9.accent
			else
				v212 = v_u_9.text2
			end
			v211.TextColor3 = v212
			local v213
			if type(p204) == "table" then
				local v214 = p204.memberIds
				v213 = type(v214) ~= "table" and {} or p204.memberIds
			else
				v213 = {}
			end
			local v215 = v_u_13.inner
			if v215 then
				v215 = v_u_13.inner.header
			end
			local v216
			if #v213 > 1 then
				v216 = v206 == "full" and true or v206 == "compact"
			else
				v216 = false
			end
			if v215 ~= nil and (v206 == "full" or v206 == "compact") then
				local v217 = v215.x + v215.w - (v216 and 116 or 0)
				local v218 = v217 - (p203.header.lock and 18 or 0)
				local v219 = v_u_16
				local v220 = v_u_16
				local v221 = UDim2.fromOffset(v218 - 150, v215.y)
				local v222 = UDim2.fromOffset(150, v215.h)
				v219.Position = v221
				v220.Size = v222
				v_u_17.Position = UDim2.fromOffset(v217 - 12, v215.y + 3)
				v_u_17.Visible = p203.header.lock
			end
			for v223, v224 in v_u_18 do
				local v225 = v213[v223]
				local v226
				if v225 == nil or (#v213 <= 1 or v206 ~= "full" and v206 ~= "compact") then
					v226 = false
				else
					v226 = v215 ~= nil
				end
				v224.Visible = v226
				if not v226 then
					continue
				end
				v224.Position = UDim2.fromOffset(v215.x + v215.w - (5 - v223) * 28 + 4, v215.y - 3)
				local v227 = ("rbxthumb://type=AvatarHeadShot&id=%d&w=48&h=48"):format(tonumber(v225) or 0)
				if v224.Image == v227 then
					continue
				end
				v224.Image = v227
			end
			local v228 = v_u_38
			local v229 = v208.name
			if v228.Text ~= v229 then
				v_u_7.setText(v228, v229)
			end
			local v230 = v_u_39
			local v231 = v208.tagline or ""
			if v230.Text ~= v231 then
				v_u_7.setText(v230, v231)
			end
			local v232 = v_u_40
			local v233 = v208.stats or ""
			if v232.Text ~= v233 then
				v_u_7.setText(v232, v233)
			end
			local v234 = v_u_38
			local v235
			if v208.tag ~= nil then
				v235 = v_u_9.text2
			else
				v235 = v_u_9.text
			end
			v234.TextColor3 = v235
			v_u_34.Visible = v206 == "full" and true or v206 == "compact"
			local v236 = v_u_34
			local v237 = v_u_34.Visible
			if v237 then
				v237 = v208.act ~= nil
			end
			v236.Visible = v237
			local v238 = v_u_35
			local v239 = string.upper(v208.act or "")
			if v238.Text ~= v239 then
				v_u_7.setText(v238, v239)
			end
			local v240 = v_u_36
			local v241
			if v206 == "full" or v206 == "compact" then
				v241 = v208.tag ~= nil
			else
				v241 = false
			end
			v240.Visible = v241
			local v242 = v_u_37
			local v243 = string.upper(v208.tag or "")
			if v242.Text ~= v243 then
				v_u_7.setText(v242, v243)
			end
			local v244 = {}
			if v208.act then
				local v245 = string.upper
				local v246 = v208.act
				table.insert(v244, v245(v246))
			end
			if v208.minutes then
				local v247 = v208.minutes
				table.insert(v244, ("%d MIN"):format(v247))
			end
			if v208.tag then
				local v248 = string.upper
				local v249 = v208.tag
				table.insert(v244, v248(v249))
			end
			local v250 = v_u_41
			local v251 = table.concat(v244, "  \194\183  ")
			if v250.Text ~= v251 then
				v_u_7.setText(v250, v251)
			end
			local v252 = v_u_42
			local v253 = p203.values
			if v252.Text ~= v253 then
				v_u_7.setText(v252, v253)
			end
			v_u_22:SetAttribute("Values", p203.values)
			for _, v254 in p203.tiles do
				local v255 = v_u_13.tiles[v254.id]
				if not v255 then
					continue
				end
				local v256
				if v207 then
					v256 = v254.short
				else
					v256 = v254.label
				end
				local v257 = v255.label
				local v258 = string.upper(v256)
				if v257.Text ~= v258 then
					v_u_7.setText(v257, v258)
				end
				local v259 = string.upper
				local v260
				if v207 then
					v260 = v254.shortValue
				else
					v260 = v254.value
				end
				local v261 = v259(v260)
				if v255.shown ~= "" and (v255.shown ~= v261 and not v_u_8.reduced()) then
					v255.flash.BackgroundTransparency = 0
					v_u_7.tween(v255.flash, {
						["BackgroundTransparency"] = 1
					}, 0.4)
				end
				v255.shown = v261
				local v262 = v255.value
				if v262.Text ~= v261 then
					v_u_7.setText(v262, v261)
				end
				local v263 = v255.value
				local v264 = v254.tone
				local v265 = v254.id
				local v266
				if v264 == "accent" then
					v266 = v_u_9.accent
				elseif v264 == "info" then
					v266 = v_u_9.info
				elseif v264 == "time" then
					v266 = v_u_8.cond.time
				elseif v264 == "text2" then
					v266 = v_u_9.text2
				elseif v_u_8.cond[v264 or ""] == nil or v265 ~= "difficulty" then
					v266 = v_u_9.text
				else
					v266 = v_u_8.cond[v264]
				end
				v263.TextColor3 = v266
				local v267 = v255.sub
				local v268 = v254.sub or ""
				if v267.Text ~= v268 then
					v_u_7.setText(v267, v268)
				end
				v255.why = v254.why
				local v269 = v255.lock
				local v270 = v254.fixed
				if v270 then
					v270 = v255.hasChev ~= false
				end
				v269.Visible = v270
				local v271 = v255.chev
				local v272 = not v254.fixed
				if v272 then
					v272 = v255.hasChev ~= false
				end
				v271.Visible = v272
				v255.btn:SetAttribute("Value", v261)
			end
		end
	end
	function v_u_13.tile(p273) -- name: tile
		-- upvalues: (copy) v_u_13
		local v274 = v_u_13.tiles[p273]
		if v274 and v274.btn.Visible then
			return v274.btn
		else
			return nil
		end
	end
	function v_u_13.setMap(p275) -- name: setMap
		-- upvalues: (copy) v_u_13, (ref) v_u_72
		v_u_13.def = p275
		if v_u_72 and v_u_13.density ~= "hidden" then
			local v276 = v_u_72.set
			pcall(v276, p275)
		end
	end
	function v_u_13.destroy() -- name: destroy
		-- upvalues: (copy) v_u_19, (ref) v_u_72, (copy) v_u_14
		for _, v_u_277 in v_u_19 do
			pcall(function()
				-- upvalues: (copy) v_u_277
				v_u_277:Disconnect()
			end)
		end
		table.clear(v_u_19)
		if v_u_72 then
			local v278 = v_u_72.destroy
			pcall(v278)
		end
		local function v279()
			-- upvalues: (ref) v_u_14
			v_u_14:Destroy()
		end
		pcall(v279)
	end
	return v_u_13
end
return v1