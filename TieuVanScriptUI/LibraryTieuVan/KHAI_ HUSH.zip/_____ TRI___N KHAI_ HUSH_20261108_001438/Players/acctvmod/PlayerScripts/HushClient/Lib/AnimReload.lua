-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimReload

local v_u_1 = {}
local v_u_2 = {
	["mag"] = {
		{
			["u0"] = 0,
			["u1"] = 0.16,
			["a"] = "support",
			["b"] = "mag",
			["label"] = "reach"
		},
		{
			["u0"] = 0.16,
			["u1"] = 0.22,
			["a"] = "mag",
			["b"] = "mag",
			["label"] = "grab"
		},
		{
			["u0"] = 0.22,
			["u1"] = 0.42,
			["a"] = "mag",
			["b"] = "pouch",
			["label"] = "pull"
		},
		{
			["u0"] = 0.42,
			["u1"] = 0.54,
			["a"] = "pouch",
			["b"] = "pouch",
			["label"] = "swap"
		},
		{
			["u0"] = 0.54,
			["u1"] = 0.74,
			["a"] = "pouch",
			["b"] = "mag",
			["label"] = "bring"
		},
		{
			["u0"] = 0.74,
			["u1"] = 0.84,
			["a"] = "mag",
			["b"] = "mag",
			["label"] = "seat"
		},
		{
			["u0"] = 0.84,
			["u1"] = 1,
			["a"] = "mag",
			["b"] = "support",
			["label"] = "return"
		}
	},
	["rotary"] = {
		{
			["u0"] = 0,
			["u1"] = 0.2,
			["a"] = "support",
			["b"] = "support",
			["label"] = "reach"
		},
		{
			["u0"] = 0.2,
			["u1"] = 0.8,
			["a"] = "support",
			["b"] = "support",
			["label"] = "swap"
		},
		{
			["u0"] = 0.8,
			["u1"] = 1,
			["a"] = "support",
			["b"] = "support",
			["label"] = "return"
		}
	},
	["single"] = {
		{
			["u0"] = 0,
			["u1"] = 0.42,
			["a"] = "pouch",
			["b"] = "port",
			["label"] = "take"
		},
		{
			["u0"] = 0.42,
			["u1"] = 0.66,
			["a"] = "port",
			["b"] = "port",
			["label"] = "push"
		},
		{
			["u0"] = 0.66,
			["u1"] = 1,
			["a"] = "port",
			["b"] = "pouch",
			["label"] = "back"
		}
	}
}
v_u_1.TIMELINES = v_u_2
function v_u_1.timeline(p3) -- name: timeline
	-- upvalues: (copy) v_u_2
	return v_u_2[p3] or v_u_2.mag
end
function v_u_1.at(p4, p5) -- name: at
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1.timeline(p4)
	local v7 = math.clamp(p5, 0, 1)
	local v8 = v6[#v6]
	for _, v9 in v6 do
		if v7 > v9.u1 then
			continue
		end
		v8 = v9
	end
	local v10
	if v8.u1 > v8.u0 then
		local v11 = (v7 - v8.u0) / (v8.u1 - v8.u0)
		local v12 = math.clamp(v11, 0, 1)
		v10 = v12 * v12 * (3 - v12 * 2)
	else
		v10 = 1
	end
	local v13
	if p4 == "mag" and v7 > 0.22 then
		v13 = v7 < 0.8
	else
		v13 = false
	end
	local v14 = {
		["from"] = v8.a,
		["to"] = v8.b,
		["t"] = v10
	}
	local v15
	if p4 == "single" then
		v15 = 1
	elseif v7 < 0.14 then
		local v16 = v7 / 0.14
		local v17 = math.clamp(v16, 0, 1)
		v15 = v17 * v17 * (3 - v17 * 2)
	elseif v7 > 0.88 then
		local v18 = (1 - v7) / 0.12
		local v19 = math.clamp(v18, 0, 1)
		v15 = v19 * v19 * (3 - v19 * 2)
	else
		v15 = 1
	end
	v14.tilt = v15
	v14.magInHand = v13
	v14.label = v8.label
	return v14
end
return v_u_1