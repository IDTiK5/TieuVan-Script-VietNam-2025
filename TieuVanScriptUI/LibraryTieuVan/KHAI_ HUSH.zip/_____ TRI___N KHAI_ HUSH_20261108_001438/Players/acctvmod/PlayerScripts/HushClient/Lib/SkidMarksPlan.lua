-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SkidMarksPlan

local v1 = {
	["VERSION"] = 1,
	["TUNE"] = {
		["POOL"] = 120,
		["POOL_TOUCH"] = 80,
		["FADE_S"] = 20,
		["HOLD_FRAC"] = 0.35,
		["TRANS0"] = 0.2,
		["TRANS0_WEAK"] = 0.5,
		["WIDTH"] = 0.42,
		["THICK"] = 0.02,
		["LIFT"] = 0.05,
		["LAYER_EPS"] = 0.001,
		["LAYERS"] = 8,
		["STEP"] = 0.9,
		["RESET_DIST"] = 7,
		["OVERLAP"] = 0.02,
		["MAX_PER_FRAME"] = 4,
		["DRIFT_LAT"] = 4.5,
		["DRIFT_SPEED"] = 9,
		["HANDBRAKE_SPEED"] = 7,
		["BRAKE_SPEED"] = 18,
		["BRAKE_THROTTLE"] = -0.5,
		["MIN_GROUNDED"] = 2,
		["FULL_LAT"] = 16
	}
}
local v_u_2 = v1.TUNE
function v1.mode(p3) -- name: mode
	-- upvalues: (copy) v_u_2
	if type(p3) ~= "table" then
		return nil, 0
	end
	local v4 = p3.speed
	local v5 = (type(v4) ~= "number" or (v4 ~= v4 or (v4 == (1 / 0) or v4 == (-1 / 0)))) and 0 or v4
	local v6 = math.max(0, v5)
	local v7 = p3.fwd
	local v8 = (type(v7) ~= "number" or (v7 ~= v7 or (v7 == (1 / 0) or v7 == (-1 / 0)))) and 0 or v7
	local v9 = p3.latRear
	local v10 = (type(v9) ~= "number" or (v9 ~= v9 or (v9 == (1 / 0) or v9 == (-1 / 0)))) and 0 or v9
	local v11 = math.abs(v10)
	local v12 = p3.grounded
	if ((type(v12) ~= "number" or (v12 ~= v12 or (v12 == (1 / 0) or v12 == (-1 / 0)))) and 0 or v12) < v_u_2.MIN_GROUNDED then
		return nil, 0
	end
	if v_u_2.DRIFT_LAT <= v11 and v_u_2.DRIFT_SPEED <= v6 then
		local v13 = v11 / v_u_2.FULL_LAT
		local v14 = math.min(1, v13)
		return "drift", math.max(0, v14)
	end
	if p3.handbrake == true and v_u_2.HANDBRAKE_SPEED <= v6 then
		local v15 = 0.45 + v11 / v_u_2.FULL_LAT
		local v16 = math.min(1, v15)
		return "handbrake", math.max(0, v16)
	end
	local v17 = p3.throttle
	if ((type(v17) ~= "number" or (v17 ~= v17 or (v17 == (1 / 0) or v17 == (-1 / 0)))) and 0 or v17) > v_u_2.BRAKE_THROTTLE or v_u_2.BRAKE_SPEED > v8 then
		return nil, 0
	end
	local v18 = 0.3 + (v8 - v_u_2.BRAKE_SPEED) / 60
	local v19 = math.min(0.8, v18)
	return "brake", math.max(0, v19)
end
local v_u_20 = { "RL", "RR" }
local v_u_21 = {
	"FL",
	"FR",
	"RL",
	"RR"
}
function v1.wheelsFor(p22) -- name: wheelsFor
	-- upvalues: (copy) v_u_21, (copy) v_u_20
	if p22 == "brake" then
		return v_u_21
	else
		return p22 ~= "drift" and p22 ~= "handbrake" and {} or v_u_20
	end
end
function v1.gate(p23) -- name: gate
	-- upvalues: (copy) v_u_2
	local v24 = (type(p23) ~= "number" or (p23 ~= p23 or (p23 == (1 / 0) or p23 == (-1 / 0)))) and 0 or p23
	if v24 < 0 then
		v24 = -v24
	end
	return v_u_2.RESET_DIST < v24 and "reset" or (v24 < v_u_2.STEP and "wait" or "draw")
end
function v1.segment(p25, p26, p27, p28, p29, p30) -- name: segment
	local v31 = p28 - p25
	local v32 = p29 - p26
	local v33 = p30 - p27
	local v34 = v31 * v31 + v32 * v32 + v33 * v33
	local v35 = math.sqrt(v34)
	if v35 < 1e-6 then
		return (p25 + p28) / 2, (p26 + p29) / 2, (p27 + p30) / 2, 0, 0, 0, -1
	else
		return (p25 + p28) / 2, (p26 + p29) / 2, (p27 + p30) / 2, v35, v31 / v35, v32 / v35, v33 / v35
	end
end
function v1.layerLift(p36) -- name: layerLift
	-- upvalues: (copy) v_u_2
	local v37 = (type(p36) ~= "number" or (p36 ~= p36 or (p36 == (1 / 0) or p36 == (-1 / 0)))) and 0 or p36
	local v38 = math.floor(v37)
	return v_u_2.LIFT + v_u_2.LAYER_EPS * (v38 % v_u_2.LAYERS)
end
function v1.alpha(p39, p40) -- name: alpha
	-- upvalues: (copy) v_u_2
	local v41 = (type(p40) ~= "number" or (p40 ~= p40 or (p40 == (1 / 0) or p40 == (-1 / 0)))) and 1 or p40
	local v42 = math.min(1, v41)
	local v43 = math.max(0, v42)
	local v44 = v_u_2.TRANS0_WEAK + (v_u_2.TRANS0 - v_u_2.TRANS0_WEAK) * v43
	local v45 = (type(p39) ~= "number" or (p39 ~= p39 or (p39 == (1 / 0) or p39 == (-1 / 0)))) and 0 or p39
	local v46 = math.max(0, v45)
	local v47 = v_u_2.FADE_S * v_u_2.HOLD_FRAC
	if v46 <= v47 then
		return v44
	end
	if v_u_2.FADE_S <= v46 then
		return 1
	end
	local v48 = (v46 - v47) / (v_u_2.FADE_S - v47)
	return v44 + (1 - v44) * v48
end
function v1.ring(p49) -- name: ring
	-- upvalues: (copy) v_u_2
	local v50 = {
		["size"] = nil,
		["nextSlot"] = 0
	}
	local v51 = 1
	local v52 = v_u_2.POOL
	if type(p49) == "number" and (p49 == p49 and (p49 ~= (1 / 0) and p49 ~= (-1 / 0))) then
		v52 = p49
	end
	local v53 = math.floor(v52)
	v50.size = math.max(v51, v53)
	return v50
end
function v1.take(p54) -- name: take
	local v55 = p54.nextSlot % p54.size + 1
	p54.nextSlot = p54.nextSlot + 1
	return v55
end
function v1.budget(p56) -- name: budget
	-- upvalues: (copy) v_u_2
	if p56 == true then
		return v_u_2.POOL_TOUCH
	else
		return v_u_2.POOL
	end
end
return v1