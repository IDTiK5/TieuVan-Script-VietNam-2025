-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ClanTransit

local v_u_1 = {
	["POLL_SEC"] = 2,
	["TIMEOUT_SEC"] = 90,
	["WORKING_AFTER_SEC"] = 1.2,
	["DISBAND_MAX_SEC"] = 240,
	["SLOW_AFTER_SEC"] = 30,
	["RUN_FRESH_SEC"] = 10,
	["AFTER_SEC"] = 20
}
local v_u_2 = {
	["LEAVING_CLAN"] = "Leaving the clan",
	["DISBANDING_CLAN"] = "Disbanding the clan",
	["TRANSIT_DONE_LEFT"] = "You left the clan.",
	["TRANSIT_DONE_DISBANDED"] = "The clan is disbanded.",
	["TRANSIT_SLOW"] = "This takes a little longer than usual."
}
v_u_1.WORDS = v_u_2
function v_u_1.kindOf(p3) -- name: kindOf
	return p3 == "disband" and "disband" or "leave"
end
function v_u_1.new(p4, p5, p6) -- name: new
	-- upvalues: (copy) v_u_1
	local v7 = {
		["kind"] = v_u_1.kindOf(p4)
	}
	if type(p5) ~= "string" or p5 == "" then
		p5 = nil
	end
	v7.cid = p5
	if type(p6) ~= "number" or p6 ~= p6 then
		p6 = nil
	end
	v7.at = p6 or 0
	return v7
end
function v_u_1.text(p8, p9) -- name: text
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v10 = v_u_1.kindOf(p8) == "disband" and "DISBANDING_CLAN" or "LEAVING_CLAN"
	if type(p9) == "table" then
		local v11 = p9[v10]
		if type(v11) == "string" and p9[v10] ~= "" then
			return p9[v10]
		end
	end
	return v_u_2[v10]
end
function v_u_1.doneText(p12, p13) -- name: doneText
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v14 = v_u_1.kindOf(p12) == "disband" and "TRANSIT_DONE_DISBANDED" or "TRANSIT_DONE_LEFT"
	if type(p13) == "table" then
		local v15 = p13[v14]
		if type(v15) == "string" and p13[v14] ~= "" then
			return p13[v14]
		end
	end
	return v_u_2[v14]
end
function v_u_1.slowText(p16) -- name: slowText
	-- upvalues: (copy) v_u_2
	if type(p16) == "table" then
		local v17 = p16.TRANSIT_SLOW
		if type(v17) == "string" and p16.TRANSIT_SLOW ~= "" then
			return p16.TRANSIT_SLOW
		end
	end
	return v_u_2.TRANSIT_SLOW
end
function v_u_1.accept(p18, p19) -- name: accept
	if type(p19) == "table" then
		if p19.has == false then
			return true
		elseif p19.has == true then
			if type(p18) == "table" and p18.cid ~= nil then
				local v20 = p19.clan
				local v21
				if type(v20) == "table" then
					local v22 = v20.id
					if type(v22) == "string" and v20.id ~= "" then
						v21 = v20.id
					else
						v21 = nil
					end
				else
					v21 = nil
				end
				if v21 == nil then
					return false
				else
					return v21 ~= p18.cid
				end
			else
				return true
			end
		else
			return false
		end
	else
		return false
	end
end
function v_u_1.staleAfterLeft(p23, p24, p25) -- name: staleAfterLeft
	-- upvalues: (copy) v_u_1
	if type(p23) ~= "table" or (p23.cid == nil or (type(p24) ~= "table" or p24.has ~= true)) then
		return false
	end
	local v26 = tonumber(p25)
	local v27 = p23.at
	local v28 = tonumber(v27)
	if v26 == nil or (v28 == nil or (v26 ~= v26 or v28 ~= v28)) then
		return false
	end
	local v29 = v26 - v28
	if v29 < 0 or v_u_1.AFTER_SEC < v29 then
		return false
	end
	local v30 = p24.clan
	local v31
	if type(v30) == "table" then
		local v32 = v30.id
		if type(v32) == "string" and v30.id ~= "" then
			v31 = v30.id
		else
			v31 = nil
		end
	else
		v31 = nil
	end
	return v31 == p23.cid
end
local function v_u_39(p33, p34) -- name: disbandRunning
	-- upvalues: (copy) v_u_1
	if type(p33) ~= "table" or (v_u_1.kindOf(p33.kind) ~= "disband" or (p33.cid == nil or type(p34) ~= "table")) then
		return false
	end
	if p34.has == true then
		local v35 = p34.tx
		if type(v35) == "table" and p34.tx.kind == "disband" then
			local v36 = p34.clan
			local v37
			if type(v36) == "table" then
				local v38 = v36.id
				if type(v38) == "string" and v36.id ~= "" then
					v37 = v36.id
				else
					v37 = nil
				end
			else
				v37 = nil
			end
			return v37 == p33.cid
		end
	end
	return false
end
function v_u_1.step(p40, p41, p42) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_39
	if type(p40) ~= "table" then
		return "done"
	end
	if type(p42) ~= "number" or p42 ~= p42 then
		p42 = nil
	end
	if p42 ~= nil then
		local v43 = p40.at
		if type(v43) ~= "number" or v43 ~= v43 then
			v43 = nil
		end
		if v43 == nil or p42 < p40.at then
			p40.at = p42
		end
	end
	if v_u_1.accept(p40, p41) then
		return "done"
	end
	if p42 == nil then
		return "wait"
	end
	local v44 = v_u_39(p40, p41)
	if v44 then
		p40.runAt = p42
	else
		local v45 = p40.runAt
		if type(v45) ~= "number" or v45 ~= v45 then
			v45 = nil
		end
		if v45 ~= nil and p42 < p40.runAt then
			p40.runAt = p42
		end
	end
	local v46 = p42 - p40.at
	if v46 < v_u_1.TIMEOUT_SEC then
		return "wait"
	end
	if v46 < v_u_1.DISBAND_MAX_SEC and v_u_1.kindOf(p40.kind) == "disband" then
		if v44 then
			return "wait"
		end
		if p41 == nil then
			local v47 = p40.runAt
			if type(v47) ~= "number" or v47 ~= v47 then
				v47 = nil
			end
			if v47 ~= nil and p42 - p40.runAt <= v_u_1.RUN_FRESH_SEC then
				return "wait"
			end
		end
	end
	return "timeout"
end
function v_u_1.slowDue(p48, p49) -- name: slowDue
	-- upvalues: (copy) v_u_1
	if type(p49) ~= "number" or p49 ~= p49 then
		p49 = nil
	end
	if type(p48) == "table" and p49 ~= nil then
		local v50 = p48.at
		if type(v50) ~= "number" or v50 ~= v50 then
			v50 = nil
		end
		if v50 ~= nil then
			return p49 - p48.at >= v_u_1.SLOW_AFTER_SEC
		end
	end
	return false
end
function v_u_1.resumeOk(p51, p52, p53) -- name: resumeOk
	-- upvalues: (copy) v_u_1, (copy) v_u_39
	if type(p51) ~= "table" or (type(p52) ~= "table" or p52.has ~= true) then
		return false
	end
	if type(p53) ~= "number" or p53 ~= p53 then
		p53 = nil
	end
	local v54 = p51.at
	if type(v54) ~= "number" or v54 ~= v54 then
		v54 = nil
	end
	if p53 ~= nil and v54 ~= nil then
		local v55 = p51.cid
		if type(v55) == "string" and p51.cid ~= "" then
			local v56 = p52.clan
			local v57
			if type(v56) == "table" then
				local v58 = v56.id
				if type(v58) == "string" and v56.id ~= "" then
					v57 = v56.id
				else
					v57 = nil
				end
			else
				v57 = nil
			end
			if v57 == p51.cid then
				local v59 = p53 - v54
				local v60 = math.max(0, v59)
				if v60 < v_u_1.TIMEOUT_SEC then
					return true
				end
				local v61
				if v60 < v_u_1.DISBAND_MAX_SEC then
					v61 = v_u_39(p51, p52)
				else
					v61 = false
				end
				return v61
			end
		end
	end
	return false
end
function v_u_1.epochChanged(p62, p63) -- name: epochChanged
	return (type(p62) ~= "number" or (type(p63) ~= "number" or (p62 ~= p62 or p63 ~= p63))) and true or p62 ~= p63
end
function v_u_1.run(p64, p65) -- name: run
	-- upvalues: (copy) v_u_1
	if type(p64) ~= "table" or type(p65) ~= "table" then
		return "gone"
	end
	while p65.alive() and p65.current() == p64 do
		p65.before()
		local v66 = p65.ask
		local v67, v68 = pcall(v66)
		if not v67 then
			v68 = nil
		end
		if not p65.alive() or p65.current() ~= p64 then
			return "gone"
		end
		local v69 = nil
		local v70
		if v68 == nil then
			v70 = v69
		else
			local v71 = p65.normalize
			local v72
			v72, v70 = pcall(v71, v68)
			if not v72 then
				v70 = v69
			end
		end
		local v73 = v_u_1.step(p64, v70, p65.now())
		if v73 == "done" then
			p65.done(v68)
			return "done"
		end
		if v73 == "timeout" then
			p65.timeout()
			return "timeout"
		end
		p65.wait(v_u_1.POLL_SEC)
	end
	return "gone"
end
function v_u_1.workingDue(p74, p75) -- name: workingDue
	-- upvalues: (copy) v_u_1
	if type(p75) ~= "number" or p75 ~= p75 then
		p75 = nil
	end
	if type(p74) ~= "table" or p75 == nil then
		return false
	end
	for _, v77 in p74 do
		if type(v77) ~= "number" or v77 ~= v77 then
			local v77 = nil
		end
		if v77 == nil or p75 - v77 <= v_u_1.WORKING_AFTER_SEC then
			continue
		end
		return true
	end
	return false
end
return v_u_1