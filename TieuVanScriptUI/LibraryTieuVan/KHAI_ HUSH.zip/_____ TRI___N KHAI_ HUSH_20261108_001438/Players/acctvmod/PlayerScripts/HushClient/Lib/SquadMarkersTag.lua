-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadMarkersTag

return {
	["new"] = function(p_u_1, p2, p3, p4) -- name: new
		local v_u_5 = p2.color
		local v6 = {
			["active"] = nil,
			["scale"] = 1,
			["active"] = {}
		}
		local v_u_7 = Instance.new("BillboardGui")
		v_u_7.Name = "HushSquadTag_" .. tostring(p3)
		v_u_7.AlwaysOnTop = true
		v_u_7.LightInfluence = 0
		v_u_7.ResetOnSpawn = false
		v_u_7.ClipsDescendants = false
		v_u_7.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v_u_7.MaxDistance = 600
		v_u_7.SizeOffset = Vector2.new(0, 0.5)
		v_u_7.Size = UDim2.fromOffset(240, 74)
		v_u_7.Enabled = false
		v6.gui = v_u_7
		local v8 = p_u_1.new("Frame", {
			["Name"] = "Canvas",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(240, 74)
		}, v_u_7)
		local v_u_9 = p_u_1.new("UIScale", {
			["Scale"] = 1
		}, v8)
		local v_u_10 = p_u_1.new("Frame", {
			["Name"] = "Plate",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.18,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_5.bg,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, 0),
			["Size"] = UDim2.fromOffset(60, 22)
		}, v8)
		local v_u_11 = p_u_1.stroke(v_u_10, v_u_5.line, 1, 0.1)
		local v_u_12 = p_u_1.new("Frame", {
			["Name"] = "Row",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.fromOffset(0, 22),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v_u_10)
		p_u_1.layout(v_u_12, "h", 0)
		local v_u_13 = p_u_1.new("Frame", {
			["Name"] = "Tick",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["BackgroundColor3"] = v_u_5.info,
			["Size"] = UDim2.fromOffset(3, 22)
		}, v_u_12)
		p_u_1.new("Frame", {
			["Name"] = "GapL",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.fromOffset(7, 22)
		}, v_u_12)
		local v_u_14 = p_u_1.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["color"] = nil,
			["autoX"] = true,
			["rich"] = true,
			["textSize"] = 12,
			["size"] = nil,
			["maxSize"] = nil,
			["parent"] = v_u_12,
			["color"] = v_u_5.text,
			["size"] = UDim2.fromOffset(0, 20),
			["maxSize"] = Vector2.new(74, 20)
		})
		v_u_14.Name = "Clan"
		v_u_14.LayoutOrder = 3
		v_u_14.Visible = false
		local v_u_15 = p_u_1.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["color"] = nil,
			["autoX"] = true,
			["textSize"] = 14,
			["size"] = nil,
			["maxSize"] = nil,
			["parent"] = v_u_12,
			["color"] = v_u_5.text,
			["size"] = UDim2.fromOffset(0, 20),
			["maxSize"] = Vector2.new(170, 20)
		})
		v_u_15.Name = "Name"
		v_u_15.LayoutOrder = 4
		local v_u_16 = v_u_15:FindFirstChildOfClass("UISizeConstraint")
		p_u_1.new("Frame", {
			["Name"] = "GapR",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 5,
			["Size"] = UDim2.fromOffset(8, 22)
		}, v_u_12)
		local v_u_17 = p_u_1.label({
			["parent"] = nil,
			["name"] = "Tally",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "center",
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v8,
			["color"] = v_u_5.accent,
			["anchor"] = Vector2.new(0.5, 0),
			["position"] = UDim2.new(0.5, 0, 1, 2),
			["size"] = UDim2.fromOffset(170, 14)
		})
		v_u_17.Visible = false
		local v18 = p_u_1.new("Frame", {
			["Name"] = "HpBack",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_5.line,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v_u_10)
		local v_u_19 = p_u_1.new("Frame", {
			["Name"] = "Hp",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_5.text2,
			["Size"] = UDim2.fromScale(1, 1)
		}, v18)
		local v_u_20 = p_u_1.new("Frame", {
			["Name"] = "Status",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -27),
			["Size"] = UDim2.fromOffset(0, 32),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v8)
		local v_u_21 = p_u_1.layout(v_u_20, "h", 3)
		pcall(function()
			-- upvalues: (copy) v_u_21
			v_u_21.VerticalAlignment = Enum.VerticalAlignment.Bottom
			v_u_21.HorizontalAlignment = Enum.HorizontalAlignment.Center
		end)
		local v_u_22 = {}
		local function v33(p23, p24, p25, p26, p27, p28) -- name: chip
			-- upvalues: (copy) p_u_1, (copy) v_u_5, (copy) v_u_20, (copy) v_u_22
			local v29 = p_u_1.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Name"] = "Chip_" .. p23,
				["BackgroundColor3"] = v_u_5.bg,
				["Size"] = UDim2.fromOffset(p25, p26),
				["LayoutOrder"] = p24
			}, v_u_20)
			local v30 = p_u_1.stroke(v29, p28, 1, 0.15)
			local v31
			if p27 then
				v31 = p_u_1.icon(p27, {
					["parent"] = nil,
					["size"] = 14,
					["color"] = nil,
					["position"] = nil,
					["parent"] = v29,
					["color"] = p28,
					["position"] = UDim2.fromOffset(4, (p26 - 14) / 2)
				})
			else
				v31 = nil
			end
			local v32 = {
				["frame"] = v29,
				["stroke"] = v30,
				["icon"] = v31,
				["extra"] = {}
			}
			v_u_22[p23] = v32
			return v32
		end
		local v_u_34 = v33("downed", 1, 32, 32, nil, v_u_5.danger)
		v_u_34.stroke.Transparency = 1
		v_u_34.frame.BackgroundTransparency = 0.05
		p_u_1.corner(v_u_34.frame, 16)
		local v_u_35 = p_u_1.ring({
			["parent"] = nil,
			["size"] = 32,
			["segments"] = 24,
			["thickness"] = 2,
			["color"] = nil,
			["bgColor"] = nil,
			["value"] = 1,
			["parent"] = v_u_34.frame,
			["color"] = v_u_5.danger,
			["bgColor"] = v_u_5.line
		})
		v_u_34.extra.ring = v_u_35
		v_u_34.extra.secs = p_u_1.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "center",
			["textSize"] = 12,
			["size"] = nil,
			["parent"] = v_u_34.frame,
			["color"] = v_u_5.danger,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_36 = v33("bleeding", 2, 29, 22, "bleeding", v_u_5.danger)
		local v_u_37 = {}
		for v38 = 1, 3 do
			v_u_37[v38] = p_u_1.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Name"] = "Pip" .. v38,
				["BackgroundColor3"] = v_u_5.danger,
				["Position"] = UDim2.fromOffset(21, 18 - (v38 - 1) * 6),
				["Size"] = UDim2.fromOffset(3, 4)
			}, v_u_36.frame)
		end
		v_u_36.extra.pips = v_u_37
		v33("fracture", 3, 22, 22, "fracture", v_u_5.accent)
		local v_u_39 = v33("infected", 4, 22, 22, "infection", v_u_5.infection)
		local v_u_40 = p_u_1.new("Frame", {
			["Name"] = "Left",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_5.infection,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 2, 1, -2),
			["Size"] = UDim2.new(1, -4, 0, 2)
		}, v_u_39.frame)
		v_u_39.extra.bar = v_u_40
		v33("exhausted", 5, 22, 22, "stamina", v_u_5.text2)
		v33("lowhp", 6, 22, 22, "heart", v_u_5.danger)
		function v6.setAdornee(_, p41) -- name: setAdornee
			-- upvalues: (copy) v_u_7
			if v_u_7.Adornee ~= p41 then
				v_u_7.Adornee = p41
			end
			if p41 then
				local v42 = p41.Name ~= "Head" and 3.6 or p41.Size.Y * 0.5 + 1.1
				local v43 = Vector3.new(0, v42, 0)
				if v_u_7.StudsOffsetWorldSpace ~= v43 then
					v_u_7.StudsOffsetWorldSpace = v43
				end
			end
		end
		function v6.setScale(p44, p45) -- name: setScale
			-- upvalues: (copy) v_u_9, (copy) v_u_7
			local v46 = p45 - p44.scale
			if math.abs(v46) >= 0.001 then
				p44.scale = p45
				v_u_9.Scale = p45
				local v47 = v_u_7
				local v48 = UDim2.fromOffset
				local v49 = p45 * 240
				local v50 = math.ceil(v49)
				local v51 = p45 * 74
				v47.Size = v48(v50, (math.ceil(v51)))
			end
		end
		v6.shift = Vector2.zero
		function v6.clamp(p52, p53, p54) -- name: clamp
			-- upvalues: (copy) v_u_10, (copy) v_u_20, (copy) v_u_7
			local v55 = 0
			local v56 = 0
			local v57 = p52.scale
			if p53 and p54 then
				local v58 = v_u_10.Size.X.Offset * v57
				local v59
				if v_u_20.Visible then
					v59 = v_u_20.AbsoluteSize.X
					if v59 < 4 then
						v59 = #p52.active * 32 * v57
					end
				else
					v59 = 0
				end
				local v60 = 40 * v57
				local v61 = math.max(v58, v59, v60) / 2 + 2
				local v62 = (v_u_20.Visible and 59 or 22) * v57 + 2
				local v63 = p54[1]
				local v64 = p54[2]
				local v65 = p54[3]
				local v66 = p54[4]
				if p53.X - v61 < v63 then
					v55 = v63 - (p53.X - v61)
				elseif v65 < p53.X + v61 then
					v55 = v65 - (p53.X + v61)
				end
				if p53.Y - v62 < v64 then
					v56 = v64 - (p53.Y - v62)
				elseif v66 < p53.Y then
					v56 = v66 - p53.Y
				end
			end
			local v67 = v_u_7.Size.X.Offset
			local v68 = math.max(1, v67)
			local v69 = v_u_7.Size.Y.Offset
			local v70 = math.max(1, v69)
			local v71 = Vector2.new(v55 / v68, 0.5 - v56 / v70)
			if (v_u_7.SizeOffset - v71).Magnitude > 0.0001 then
				v_u_7.SizeOffset = v71
			end
			p52.shift = Vector2.new(v55, v56)
			return p52.shift
		end
		local v_u_72 = false
		function v6.setShown(_, p73) -- name: setShown
			-- upvalues: (copy) v_u_7, (ref) v_u_72
			if p73 then
				p73 = v_u_7.Adornee ~= nil
			end
			if p73 ~= v_u_72 then
				v_u_72 = p73
				v_u_7.Enabled = p73
			end
		end
		local v_u_74 = ""
		local v_u_75 = nil
		local v_u_76 = nil
		function v6.update(p77, p78, p79) -- name: update
			-- upvalues: (ref) v_u_76, (copy) v_u_17, (copy) p_u_1, (ref) v_u_74, (copy) v_u_15, (ref) v_u_75, (copy) v_u_14, (copy) v_u_16, (copy) v_u_13, (copy) v_u_12, (copy) v_u_10, (copy) v_u_19, (copy) v_u_5, (copy) v_u_22, (copy) v_u_35, (copy) v_u_34, (copy) v_u_11, (copy) v_u_37, (copy) v_u_36, (copy) v_u_39, (copy) v_u_40, (copy) v_u_20
			local v80 = p79.now
			local v81 = p79.t
			if p79.tally ~= v_u_76 then
				v_u_76 = p79.tally
				v_u_17.Visible = v_u_76 ~= nil
				if v_u_76 ~= nil then
					p_u_1.setText(v_u_17, v_u_76)
				end
			end
			if p79.name ~= v_u_74 then
				v_u_74 = p79.name
				p_u_1.setText(v_u_15, string.upper(p79.name))
			end
			local v82 = p79.clanRich
			local v83
			if type(v82) == "string" and p79.clanRich ~= "" then
				v83 = p79.clanRich
			else
				v83 = nil
			end
			if v83 ~= v_u_75 then
				v_u_75 = v83
				v_u_14.Visible = v83 ~= nil
				if v83 ~= nil then
					v_u_14.Text = v83
				end
				if v_u_16 ~= nil then
					v_u_16.MaxSize = Vector2.new(v83 == nil and 170 or 96, 20)
				end
			end
			if v83 ~= nil then
				local v84 = p79.clanAlpha
				local v85 = (type(v84) ~= "number" or v84 ~= v84) and 0 or v84
				if v_u_14.TextTransparency ~= v85 then
					v_u_14.TextTransparency = v85
				end
				local v86 = p79.clanStroke
				local v87 = type(v86) ~= "number" and 1 or p79.clanStroke
				if v_u_14.TextStrokeTransparency ~= v87 then
					v_u_14.TextStrokeTransparency = v87
				end
			end
			v_u_13.BackgroundColor3 = p79.color
			local v88 = v_u_12.AbsoluteSize.X
			local v89 = p77.scale
			local v90 = v88 / math.max(0.05, v89)
			local v91 = math.ceil(v90)
			if v91 > 0 and v_u_10.Size.X.Offset ~= v91 then
				v_u_10.Size = UDim2.fromOffset(v91, 22)
			end
			local v92 = p78:GetAttribute("Hp")
			local v93 = (type(v92) ~= "number" or v92 ~= v92) and 100 or v92
			local v94 = p78:GetAttribute("MaxHp")
			local v95 = (type(v94) ~= "number" or v94 ~= v94) and 100 or v94
			local v96 = v93 / math.max(1, v95)
			local v97 = math.clamp(v96, 0, 1)
			local v98 = p78:GetAttribute("Downed") == true
			v_u_19.Size = UDim2.fromScale(v97, 1)
			local v99 = v_u_19
			local v100
			if v98 or v97 < 0.35 then
				v100 = v_u_5.danger
			elseif v97 < 0.6 then
				v100 = v_u_5.accent
			else
				v100 = v_u_5.text2
			end
			v99.BackgroundColor3 = v100
			local v101 = {}
			local v102 = v_u_22.downed
			if v102 and v102.frame.Visible ~= v98 then
				v102.frame.Visible = v98
			end
			if v98 then
				table.insert(v101, "downed")
				local v103 = p78:GetAttribute("DownedUntil")
				local v104 = (type(v103) ~= "number" or v103 ~= v103) and 0 or v103
				local v105 = p78:GetAttribute("DownedAt")
				if type(v105) ~= "number" or v105 ~= v105 then
					v105 = v80
				end
				local v106 = v104 - v105
				local v107 = math.max(1, v106)
				local v108 = v104 - v80
				local v109 = math.max(0, v108)
				local v110 = p78:GetAttribute("RevivingBy")
				local v111 = ((type(v110) ~= "number" or v110 ~= v110) and 0 or v110) ~= 0 and true or p78:GetAttribute("Action") == "Revive"
				local v112
				if v111 then
					v112 = v_u_5.success
				else
					v112 = v_u_5.danger
				end
				v_u_35.setColor(v112)
				v_u_35.set(v104 <= 0 and 1 or v109 / v107)
				local v113
				if v104 > 0 then
					local v114 = math.ceil(v109)
					v113 = tostring(v114)
				else
					v113 = ""
				end
				if v_u_34.extra.secs.Text ~= v113 then
					v_u_34.extra.secs.Text = v113
				end
				v_u_34.extra.secs.TextColor3 = v112
				local v115
				if v111 then
					v115 = 0
				else
					local v116 = v81 * 6
					v115 = math.sin(v116) * 0.5 + 0.5
				end
				v_u_34.frame.BackgroundColor3 = v_u_5.bg:Lerp(v_u_5.dangerDeep, v115)
				v_u_11.Color = v112
				v_u_11.Transparency = 0.1
			else
				v_u_11.Color = v_u_5.line
				v_u_11.Transparency = 0.1
			end
			local v117 = p78:GetAttribute("Bleeding")
			local v118 = (type(v117) ~= "number" or v117 ~= v117) and 0 or v117
			local v119 = math.floor(v118)
			local v120 = math.clamp(v119, 0, 3)
			local v121 = v120 > 0
			local v122 = v_u_22.bleeding
			if v122 and v122.frame.Visible ~= v121 then
				v122.frame.Visible = v121
			end
			if v120 > 0 then
				local v123 = "bleeding" .. v120
				table.insert(v101, v123)
				for v124, v125 in v_u_37 do
					v125.BackgroundTransparency = v124 <= v120 and 0 or 0.78
				end
				local v126 = v81 * (v120 * 2 + 3)
				local v127 = math.sin(v126) * 0.5 + 0.5
				local v128 = v_u_36
				local v129 = v_u_5.danger:Lerp(v_u_5.text, v127 * 0.35)
				v128.stroke.Color = v129
				if v128.icon then
					p_u_1.setIconColor(v128.icon, v129)
				end
			end
			local v130 = p78:GetAttribute("Fracture") == true
			local v131 = v_u_22.fracture
			if v131 and v131.frame.Visible ~= v130 then
				v131.frame.Visible = v130
			end
			if v130 then
				table.insert(v101, "fracture")
			end
			local v132 = p78:GetAttribute("Infected") == true
			local v133 = v_u_22.infected
			if v133 and v133.frame.Visible ~= v132 then
				v133.frame.Visible = v132
			end
			if v132 then
				table.insert(v101, "infected")
				local v134 = p78:GetAttribute("InfectionEndsAt")
				local v135 = (type(v134) ~= "number" or v134 ~= v134) and 0 or v134
				local v136 = p78:GetAttribute("InfectedAt")
				if type(v136) ~= "number" or v136 ~= v136 then
					v136 = v80
				end
				local v137
				if v135 > 0 then
					local v138 = v135 - v80
					local v139 = v135 - v136
					local v140 = v138 / math.max(1, v139)
					v137 = math.clamp(v140, 0, 1)
				else
					v137 = 1
				end
				local v141
				if v137 > 0.5 then
					v141 = v_u_5.infection:Lerp(v_u_5.accent, (1 - v137) * 2)
				else
					v141 = v_u_5.accent:Lerp(v_u_5.danger, (0.5 - v137) * 2)
				end
				local v142 = v_u_39
				v142.stroke.Color = v141
				if v142.icon then
					p_u_1.setIconColor(v142.icon, v141)
				end
				v_u_40.BackgroundColor3 = v141
				v_u_40.Size = UDim2.new(v137, v137 * -4, 0, 2)
				if v137 < 0.25 then
					local v143 = v81 * 7
					local v144 = math.sin(v143) * 0.5 + 0.5
					v_u_39.frame.BackgroundColor3 = v_u_5.bg:Lerp(v_u_5.dangerDeep, v144)
				else
					v_u_39.frame.BackgroundColor3 = v_u_5.bg
				end
			end
			local v145
			if p78:GetAttribute("Exhausted") == true then
				v145 = not v98
			else
				v145 = false
			end
			local v146 = v_u_22.exhausted
			if v146 and v146.frame.Visible ~= v145 then
				v146.frame.Visible = v145
			end
			if v145 then
				table.insert(v101, "exhausted")
			end
			local v147
			if v97 < 0.35 then
				v147 = not v98
			else
				v147 = false
			end
			local v148 = v_u_22.lowhp
			if v148 and v148.frame.Visible ~= v147 then
				v148.frame.Visible = v147
			end
			if v147 then
				table.insert(v101, "lowhp")
				local v149 = v81 * 4
				local v150 = math.sin(v149) * 0.5 + 0.5
				v_u_22.lowhp.frame.BackgroundColor3 = v_u_5.bg:Lerp(v_u_5.dangerDeep, v150 * 0.8)
			end
			p77.active = v101
			v_u_20.Visible = #v101 > 0
		end
		function v6.destroy(_) -- name: destroy
			-- upvalues: (copy) v_u_7
			v_u_7:Destroy()
		end
		v_u_7.Parent = p4
		return v6
	end
}