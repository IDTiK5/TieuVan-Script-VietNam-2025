-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIPouchRule

local v_u_6 = {
	["COLORS"] = {
		["S"] = {
			{ 34, 40, 46 },
			{ 40, 47, 54 }
		},
		["L"] = {
			{ 54, 48, 38 },
			{ 62, 56, 45 }
		},
		["X"] = {
			{ 46, 38, 52 },
			{ 54, 45, 60 }
		}
	},
	["TICK_MIN"] = 3,
	["TICK_MAX"] = 9,
	["class"] = function(p1, p2) -- name: class
		local v3 = p1 * p2
		return v3 <= 1 and "S" or (v3 == 2 and "L" or "X")
	end,
	["color"] = function(p4, p5) -- name: color
		-- upvalues: (copy) v_u_6
		return (v_u_6.COLORS[p4] or v_u_6.COLORS.S)[p5 == 1 and 2 or 1]
	end
}
local function v_u_25(p7, p8) -- name: shared
	if p7.x + p7.w == p8.x or p8.x + p8.w == p7.x then
		local v9 = p7.y
		local v10 = p8.y
		local v11 = math.max(v9, v10)
		local v12 = p7.y + p7.h
		local v13 = p8.y + p8.h
		local v14 = math.min(v12, v13)
		if v11 < v14 then
			local v15 = "v"
			local v16
			if p7.x + p7.w == p8.x then
				v16 = p8.x
			else
				v16 = p7.x
			end
			return v15, v16, v11, v14
		end
	end
	if p7.y + p7.h == p8.y or p8.y + p8.h == p7.y then
		local v17 = p7.x
		local v18 = p8.x
		local v19 = math.max(v17, v18)
		local v20 = p7.x + p7.w
		local v21 = p8.x + p8.w
		local v22 = math.min(v20, v21)
		if v19 < v22 then
			local v23 = "h"
			local v24
			if p7.y + p7.h == p8.y then
				v24 = p8.y
			else
				v24 = p7.y
			end
			return v23, v24, v19, v22
		end
	end
	return nil, nil, nil, nil
end
local function v_u_33(p_u_26) -- name: reading
	local v27 = {}
	for v28 = 1, #p_u_26 do
		v27[v28] = v28
	end
	table.sort(v27, function(p29, p30)
		-- upvalues: (copy) p_u_26
		local v31 = p_u_26[p29]
		local v32 = p_u_26[p30]
		if v31.y == v32.y then
			if v31.x == v32.x then
				return p29 < p30
			else
				return v31.x < v32.x
			end
		else
			return v31.y < v32.y
		end
	end)
	return v27
end
function v_u_6.variant(p34) -- name: variant
	-- upvalues: (copy) v_u_33, (copy) v_u_6, (copy) v_u_25
	local v35 = v_u_33(p34)
	local v36 = {}
	for _, v37 in v35 do
		if v36[v37] ~= nil then
			continue
		end
		v36[v37] = 0
		local v38 = { v37 }
		local v39 = 1
		while v39 <= #v38 do
			local v40 = v38[v39]
			v39 = v39 + 1
			local v41 = p34[v40]
			local v42 = v_u_6.class(v41.w, v41.h)
			for _, v43 in v35 do
				if v36[v43] ~= nil then
					continue
				end
				local v44 = p34[v43]
				if v_u_6.class(v44.w, v44.h) ~= v42 or v_u_25(v41, v44) == nil then
					continue
				end
				v36[v43] = 1 - v36[v40]
				table.insert(v38, v43)
			end
		end
	end
	return v36
end
function v_u_6.separators(p45) -- name: separators
	-- upvalues: (copy) v_u_25
	local v46 = {}
	for v47 = 1, #p45 do
		for v48 = v47 + 1, #p45 do
			local v49, v50, v51, v52 = v_u_25(p45[v47], p45[v48])
			if not v49 then
				continue
			end
			table.insert(v46, {
				["axis"] = v49,
				["k"] = v50,
				["a"] = v51,
				["b"] = v52
			})
		end
	end
	table.sort(v46, function(p53, p54)
		if p53.axis == p54.axis then
			if p53.k == p54.k then
				return p53.a < p54.a
			else
				return p53.k < p54.k
			end
		else
			return p53.axis < p54.axis
		end
	end)
	return v46
end
function v_u_6.tickLen(p55, p56) -- name: tickLen
	-- upvalues: (copy) v_u_6
	local v57 = p55 * 0.2 + 0.5
	local v58 = math.floor(v57)
	local v59 = v_u_6.TICK_MIN
	local v60 = v_u_6.TICK_MAX
	local v61 = math.clamp(v58, v59, v60)
	if p56 then
		local v62 = (p56 - 2) / 3
		local v63 = math.floor(v62)
		local v64 = math.max(1, v63)
		v61 = math.min(v61, v64)
	end
	return v61
end
function v_u_6.ticks(p65, p66) -- name: ticks
	-- upvalues: (copy) v_u_6
	local v67 = {}
	for v68, v69 in p65 do
		if v_u_6.class(v69.w, v69.h) == "S" then
			continue
		end
		for v70 = v69.x + 1, v69.x + v69.w - 1 do
			table.insert(v67, {
				["pouch"] = nil,
				["axis"] = "v",
				["k"] = nil,
				["side"] = 1,
				["pouch"] = v68,
				["k"] = v70
			})
			table.insert(v67, {
				["pouch"] = nil,
				["axis"] = "v",
				["k"] = nil,
				["side"] = 2,
				["pouch"] = v68,
				["k"] = v70
			})
		end
		for v71 = v69.y + 1, v69.y + v69.h - 1 do
			table.insert(v67, {
				["pouch"] = nil,
				["axis"] = "h",
				["k"] = nil,
				["side"] = 1,
				["pouch"] = v68,
				["k"] = v71
			})
			table.insert(v67, {
				["pouch"] = nil,
				["axis"] = "h",
				["k"] = nil,
				["side"] = 2,
				["pouch"] = v68,
				["k"] = v71
			})
		end
	end
	return {
		["len"] = v_u_6.tickLen(p66),
		["list"] = v67
	}
end
function v_u_6.pouchAt(p72, p73, p74) -- name: pouchAt
	for v75, v76 in p72 do
		if v76.x > p73 or (p73 >= v76.x + v76.w or (v76.y > p74 or p74 >= v76.y + v76.h)) then
			continue
		end
		return v75
	end
	return nil
end
function v_u_6.summary(p77) -- name: summary
	if type(p77) ~= "table" or #p77 == 0 then
		return ""
	end
	local v_u_78 = {}
	local v79 = {}
	for _, v80 in p77 do
		local v81 = v80.w .. "x" .. v80.h
		if not v_u_78[v81] then
			v_u_78[v81] = {
				["n"] = 0,
				["area"] = nil,
				["area"] = v80.w * v80.h
			}
			table.insert(v79, v81)
		end
		local v82 = v_u_78[v81]
		v82.n = v82.n + 1
	end
	table.sort(v79, function(p83, p84)
		-- upvalues: (copy) v_u_78
		if v_u_78[p83].area == v_u_78[p84].area then
			return p83 < p84
		else
			return v_u_78[p83].area > v_u_78[p84].area
		end
	end)
	local v85 = {}
	for _, v86 in v79 do
		local v87 = v_u_78[v86].n .. " x " .. v86
		table.insert(v85, v87)
	end
	return table.concat(v85, ", ")
end
local function v_u_101(p88) -- name: lab
	local v89 = p88[1] / 255
	local v90
	if v89 <= 0.04045 then
		v90 = v89 / 12.92
	else
		v90 = ((v89 + 0.055) / 1.055) ^ 2.4
	end
	local v91 = p88[2] / 255
	local v92
	if v91 <= 0.04045 then
		v92 = v91 / 12.92
	else
		v92 = ((v91 + 0.055) / 1.055) ^ 2.4
	end
	local v93 = p88[3] / 255
	local v94
	if v93 <= 0.04045 then
		v94 = v93 / 12.92
	else
		v94 = ((v93 + 0.055) / 1.055) ^ 2.4
	end
	local v95 = (v90 * 0.4124 + v92 * 0.3576 + v94 * 0.1805) / 0.95047
	local v96 = v90 * 0.2126 + v92 * 0.7152 + v94 * 0.0722
	local v97 = (v90 * 0.0193 + v92 * 0.1192 + v94 * 0.9505) / 1.08883
	local v98
	if v95 > 0.008856 then
		v98 = v95 ^ 0.3333333333333333
	else
		v98 = v95 * 7.787 + 0.13793103448275862
	end
	local v99
	if v96 > 0.008856 then
		v99 = v96 ^ 0.3333333333333333
	else
		v99 = v96 * 7.787 + 0.13793103448275862
	end
	local v100
	if v97 > 0.008856 then
		v100 = v97 ^ 0.3333333333333333
	else
		v100 = v97 * 7.787 + 0.13793103448275862
	end
	return { v99 * 116 - 16, (v98 - v99) * 500, (v99 - v100) * 200 }
end
function v_u_6.deltaE(p102, p103) -- name: deltaE
	-- upvalues: (copy) v_u_101
	local v104 = v_u_101(p102)
	local v105 = v_u_101(p103)
	local v106 = (v104[1] - v105[1]) ^ 2 + (v104[2] - v105[2]) ^ 2 + (v104[3] - v105[3]) ^ 2
	return math.sqrt(v106)
end
return v_u_6