-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreLayout

local v_u_160 = {
	["PAD"] = 12,
	["TOP"] = 12,
	["NAME_H"] = 22,
	["BLURB_H"] = 34,
	["BLURB_LINE_H"] = 16,
	["CHAR_W"] = 6.2,
	["BLURB_H_NARROW"] = 20,
	["NOTE_H"] = 16,
	["GAP"] = 6,
	["BOTTOM"] = 10,
	["ART_MIN"] = 40,
	["BUY_W"] = 168,
	["BUY_W_PHONE"] = 220,
	["GIFT_W"] = 100,
	["giftFits"] = function(p1) -- name: giftFits
		-- upvalues: (copy) v_u_160
		return p1 - 2 * v_u_160.PAD - v_u_160.GIFT_W - 8 >= 110
	end,
	["grid"] = function(p2, p3, p4, p5) -- name: grid
		local v6 = p2 - 48 - 32 - 14
		local v7 = (v6 + 12) / ((p3 and 250 or 300) + 12)
		local v8 = math.floor(v7)
		local v9 = math.max(2, v8)
		if p4 then
			local v10 = (v6 + 12) / ((p5 or 236) + 12)
			local v11 = math.floor(v10)
			local v12 = math.min(4, v11)
			v9 = math.max(v9, v12)
		end
		local v13 = (v6 + 12) / v9
		return {
			["listW"] = v6,
			["cols"] = v9,
			["cardW"] = math.floor(v13) - 12,
			["cardH"] = p3 and 230 or 258
		}
	end,
	["blurbLines"] = function(p14, p15, p16) -- name: blurbLines
		-- upvalues: (copy) v_u_160
		local v17 = type(p14) == "string" and #p14 or 0
		local v18 = (type(p16) ~= "number" or p16 <= 13) and 1 or p16 / 13
		local v19 = v17 * v_u_160.CHAR_W * v18
		local v20 = p15 * 0.92
		local v21 = v19 / math.max(40, v20)
		local v22 = math.ceil(v21)
		return math.max(1, v22)
	end,
	["lineH"] = function(p23) -- name: lineH
		-- upvalues: (copy) v_u_160
		if type(p23) ~= "number" or p23 <= 13 then
			return v_u_160.BLURB_LINE_H
		end
		local v24 = p23 * 1.25
		return math.ceil(v24)
	end,
	["cardH"] = function(p25, p26) -- name: cardH
		-- upvalues: (copy) v_u_160
		local v27 = p26.btnH or 40
		local v28 = p26.gift and (p26.giftH or 30) or 0
		local v29 = math.max(v27, v28)
		local v30 = v_u_160.TOP + v_u_160.ART_MIN + v_u_160.GAP
		local v31
		if p26.narrowCash then
			v31 = v_u_160.BLURB_H_NARROW
		else
			local v32 = p26.blurbLines or 2
			local v33 = math.floor(v32)
			local v34 = math.min(3, v33)
			local v35 = math.max(2, v34)
			local v36 = v_u_160.lineH(p26.fs)
			if v35 <= 2 then
				local v37 = v_u_160.BLURB_H
				local v38 = 2 * v36 + 2
				v31 = math.max(v37, v38)
			else
				v31 = v35 * v36 + 2
			end
		end
		local v39 = v31 + 24
		if p26.cash then
			local v40 = v_u_160.NOTE_H
			local v41 = v_u_160.lineH
			local v42 = p26.fs
			v39 = v39 + (math.max(v40, v41(v42)) + 2)
		end
		local v43 = v30 + v39 + v_u_160.GAP + v29 + v_u_160.BOTTOM
		return math.max(p25, v43)
	end,
	["card"] = function(p44, p45, p46) -- name: card
		-- upvalues: (copy) v_u_160
		local v47 = p46.btnH or 40
		local v48
		if p46.phone or p46.wideBuy then
			v48 = v_u_160.BUY_W_PHONE
		else
			v48 = v_u_160.BUY_W
		end
		local v49 = p44 - 2 * v_u_160.PAD
		local v50 = p46.giftH or 30
		local v51 = nil
		if p46.gift then
			local v52 = v49 - v_u_160.GIFT_W - 8
			local v53 = math.max(110, v52)
			v48 = math.min(v48, v53)
		end
		local v54 = math.min(v48, v49)
		local v55 = {
			["x"] = p44 - v_u_160.PAD - v54,
			["y"] = p45 - v_u_160.BOTTOM - v47,
			["w"] = v54,
			["h"] = v47
		}
		local v56 = p46.gift and {
			["x"] = v_u_160.PAD,
			["y"] = p45 - v_u_160.BOTTOM - v50,
			["w"] = v_u_160.GIFT_W,
			["h"] = v50
		} or v51
		local v57
		if p46.narrowCash then
			v57 = v_u_160.BLURB_H_NARROW
		else
			local v58 = p46.blurbLines or 2
			local v59 = math.floor(v58)
			local v60 = math.min(3, v59)
			local v61 = math.max(2, v60)
			local v62 = v_u_160.lineH(p46.fs)
			if v61 <= 2 then
				local v63 = v_u_160.BLURB_H
				local v64 = 2 * v62 + 2
				v57 = math.max(v63, v64)
			else
				v57 = v61 * v62 + 2
			end
		end
		local v65 = v57 + 24
		if p46.cash then
			local v66 = v_u_160.NOTE_H
			local v67 = v_u_160.lineH
			local v68 = p46.fs
			v65 = v65 + (math.max(v66, v67(v68)) + 2)
		end
		local v69 = v55.y - v_u_160.GAP - v65
		local v70 = p45 * 0.46
		local v71 = math.floor(v70)
		local v72 = v69 - v_u_160.GAP - v_u_160.TOP
		local v73 = math.min(v71, v72)
		local v74 = math.max(0, v73)
		local v75 = {
			["x"] = v_u_160.PAD,
			["y"] = v_u_160.TOP,
			["w"] = v49,
			["h"] = v74
		}
		if v71 <= v74 then
			v69 = v_u_160.TOP + v74 + v_u_160.GAP
		end
		local v76
		if p46.narrowCash then
			v76 = v_u_160.BLURB_H_NARROW
		else
			local v77 = p46.blurbLines or 2
			local v78 = math.floor(v77)
			local v79 = math.min(3, v78)
			local v80 = math.max(2, v79)
			local v81 = v_u_160.lineH(p46.fs)
			if v80 <= 2 then
				local v82 = v_u_160.BLURB_H
				local v83 = 2 * v81 + 2
				v76 = math.max(v82, v83)
			else
				v76 = v80 * v81 + 2
			end
		end
		local v84 = {
			["art"] = v75,
			["name"] = {
				["x"] = v_u_160.PAD,
				["y"] = v69,
				["w"] = v49,
				["h"] = v_u_160.NAME_H
			},
			["blurb"] = {
				["x"] = v_u_160.PAD,
				["y"] = v69 + 24,
				["w"] = v49,
				["h"] = v76
			},
			["buy"] = v55,
			["gift"] = v56
		}
		if p46.cash then
			local v85 = v_u_160.PAD
			local v86 = v69 + 24 + v76 + 2
			local v87 = v_u_160.NOTE_H
			local v88 = v_u_160.lineH
			local v89 = p46.fs
			v84.note = {
				["x"] = v85,
				["y"] = v86,
				["w"] = v49,
				["h"] = math.max(v87, v88(v89))
			}
		end
		return v84
	end,
	["HERO_BUY_H"] = 52,
	["HERO_BUY_MIN"] = 110,
	["HERO_GIFT_MIN"] = 70,
	["hero"] = function(p90, p91, p92) -- name: hero
		-- upvalues: (copy) v_u_160
		local v93 = p90 * 0.69
		local v94 = math.floor(v93)
		local v95 = p90 - v94 - 20
		local v96
		if p92.phone then
			v96 = v95
		else
			v96 = math.min(260, v95)
		end
		local v97 = nil
		if p92.gift then
			local v98 = p92.giftH or 30
			local v99 = v_u_160.GIFT_W
			local v100 = v95 - 8 - v_u_160.HERO_BUY_MIN
			local v101 = math.min(v99, v100)
			if v_u_160.HERO_GIFT_MIN <= v101 then
				local v102 = v95 - 8 - v101
				v96 = math.min(v96, v102)
				v97 = {
					["x"] = v94 + v96 + 8,
					["y"] = p91 - 70 + v_u_160.HERO_BUY_H - v98,
					["w"] = v101,
					["h"] = v98
				}
			end
		end
		local v103 = {}
		if not p92.compact then
			local v104 = p92.bullets or 0
			for v105 = 1, math.floor(v104) do
				local v106 = {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 18,
					["x"] = v94,
					["y"] = (v105 - 1) * 22 + 138,
					["w"] = v95
				}
				table.insert(v103, v106)
			end
		end
		local v107 = {
			["tag"] = {
				["x"] = nil,
				["y"] = 18,
				["w"] = nil,
				["h"] = 18,
				["x"] = v94,
				["w"] = v95
			},
			["title"] = {
				["x"] = nil,
				["y"] = 42,
				["w"] = nil,
				["h"] = 40,
				["x"] = v94,
				["w"] = v95
			},
			["blurb"] = {
				["x"] = nil,
				["y"] = 88,
				["w"] = nil,
				["h"] = 44,
				["x"] = v94,
				["w"] = v95
			},
			["bullets"] = v103,
			["buy"] = {
				["x"] = v94,
				["y"] = p91 - 70,
				["w"] = v96,
				["h"] = v_u_160.HERO_BUY_H
			},
			["gift"] = v97
		}
		return v107
	end,
	["BUYBOX_H"] = 92,
	["BUYBOX_H_GIFT"] = 142,
	["BUYBOX_PAD"] = 16,
	["BUYBOX_BTN_W"] = 260,
	["BUYBOX_BUY_Y"] = 14,
	["BUYBOX_GIFT_Y"] = 82,
	["buyBox"] = function(p108) -- name: buyBox
		-- upvalues: (copy) v_u_160
		local v109
		if p108.gift then
			v109 = v_u_160.BUYBOX_H_GIFT
		else
			v109 = v_u_160.BUYBOX_H
		end
		local v110 = p108.buyH or v_u_160.HERO_BUY_H
		local v111 = v_u_160.BUYBOX_BTN_W
		local v112 = p108.w
		if type(v112) == "number" and p108.w > 0 then
			local v113 = p108.w - 2 * v_u_160.BUYBOX_PAD
			local v114 = math.max(60, v113)
			v111 = math.min(v111, v114)
		end
		local v115 = {
			["box"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p108.w or 0,
				["h"] = v109
			}
		}
		local v116
		if p108.gift then
			v116 = {
				["x"] = v_u_160.BUYBOX_PAD,
				["y"] = v_u_160.BUYBOX_BUY_Y,
				["w"] = v111,
				["h"] = v110
			}
		else
			local v117 = v_u_160.BUYBOX_PAD
			local v118 = (v109 - v110) / 2
			v116 = {
				["x"] = v117,
				["y"] = math.floor(v118),
				["w"] = v111,
				["h"] = v110
			}
		end
		v115.buy = v116
		if p108.gift then
			v115.gift = {
				["x"] = v_u_160.BUYBOX_PAD,
				["y"] = v_u_160.BUYBOX_GIFT_Y,
				["w"] = v111,
				["h"] = p108.giftH or 40
			}
		end
		return v115
	end,
	["UP_GAP"] = 4,
	["UP_PAD"] = 4,
	["UP_BTN_MIN"] = 150,
	["UP_MIN_INFO"] = 100,
	["UP_GIFT_W"] = 170,
	["UP_GRID_MIN"] = 160,
	["UP_SIDE_W"] = 190,
	["UP_SIDE_MIN_INFO_W"] = 280,
	["UP_SIDE_GAP"] = 4,
	["unlockPage"] = function(p119) -- name: unlockPage
		-- upvalues: (copy) v_u_160
		local v120 = p119.W
		local v121 = p119.H
		local v122 = v_u_160.UP_GAP
		local v123 = v_u_160.UP_PAD
		local v124 = p119.gift == true
		local v125
		if v124 then
			v125 = v120 - 2 * v123 - 8 >= 2 * v_u_160.UP_BTN_MIN
		else
			v125 = v124
		end
		local v126 = p119.buyH
		if v124 then
			if v125 then
				local v127 = p119.buyH
				local v128 = p119.giftH
				v126 = math.max(v127, v128)
			else
				v126 = p119.buyH + 8 + p119.giftH
			end
		end
		local v129 = v126 + 2 * v123
		local v130 = {
			["sideBySide"] = v125,
			["title"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v120,
				["h"] = p119.titleH
			},
			["box"] = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v121 - v129,
				["w"] = v120,
				["h"] = v129
			}
		}
		v130.target = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v130.box.y - v122 - p119.targetH,
			["w"] = v120,
			["h"] = p119.targetH
		}
		local v131 = p119.titleH + v122
		v130.info = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v131,
			["w"] = v120,
			["h"] = v130.target.y - v122 - v131
		}
		local v132 = p119.gridMin
		if type(v132) == "number" and (p119.gridMin > 0 and v130.info.h < p119.gridMin) then
			local v133 = p119.targetHFor
			if type(v133) == "function" then
				local v134 = v_u_160.UP_SIDE_W
				local v135 = v_u_160.UP_SIDE_GAP
				local v136 = v134 - 2 * v135
				local v137 = p119.targetHFor(v136 - 16)
				local v138 = v135 + v137 + v135 + p119.buyH + (not v124 and 0 or v135 + p119.giftH) + v135
				local v139 = v120 - v134 - 8
				if v138 <= v121 and (v_u_160.UP_SIDE_MIN_INFO_W <= v139 and v130.info.h < v121) then
					local v140 = {
						["sideBySide"] = false,
						["short"] = true,
						["side"] = true,
						["titleInScroll"] = true,
						["targetInBox"] = true,
						["title"] = {
							["x"] = 0,
							["y"] = 0,
							["w"] = nil,
							["h"] = nil,
							["w"] = v139,
							["h"] = p119.titleH
						},
						["info"] = {
							["x"] = 0,
							["y"] = 0,
							["w"] = nil,
							["h"] = nil,
							["w"] = v139,
							["h"] = v121
						},
						["box"] = {
							["x"] = v120 - v134,
							["y"] = v121 - v138,
							["w"] = v134,
							["h"] = v138
						},
						["target"] = {
							["x"] = v135,
							["y"] = v135,
							["w"] = v136,
							["h"] = v137
						},
						["buy"] = {
							["x"] = v135,
							["y"] = v135 + v137 + v135,
							["w"] = v136,
							["h"] = p119.buyH
						}
					}
					if v124 then
						v140.gift = {
							["x"] = v135,
							["y"] = v140.buy.y + p119.buyH + v135,
							["w"] = v136,
							["h"] = p119.giftH
						}
					end
					return v140
				end
			end
		end
		local v141 = p119.minInfo
		if type(v141) == "number" and (p119.minInfo > 0 and v130.info.h < p119.minInfo) then
			local v142 = p119.targetHFor
			if type(v142) == "function" then
				local v143 = v_u_160.UP_BTN_MIN
				local v144 = v_u_160.UP_GIFT_W
				local v145 = v120 - 2 * v123 - 8 - v143 - (not v124 and 0 or 8 + v144)
				if v145 >= 120 then
					local v146 = p119.targetHFor(v145 - 16)
					local v147 = p119.buyH
					local v148 = not v124 and 0 or p119.giftH
					local v149 = math.max(v147, v148, v146)
					local v150 = v149 + 2 * v123
					local v151 = {
						["sideBySide"] = true,
						["short"] = true,
						["titleInScroll"] = true,
						["targetInBox"] = true,
						["title"] = {
							["x"] = 0,
							["y"] = 0,
							["w"] = nil,
							["h"] = nil,
							["w"] = v120,
							["h"] = p119.titleH
						},
						["box"] = {
							["x"] = 0,
							["y"] = nil,
							["w"] = nil,
							["h"] = nil,
							["y"] = v121 - v150,
							["w"] = v120,
							["h"] = v150
						},
						["target"] = {
							["x"] = v123,
							["y"] = v123,
							["w"] = v145,
							["h"] = v149
						}
					}
					v151.info = {
						["x"] = 0,
						["y"] = 0,
						["w"] = nil,
						["h"] = nil,
						["w"] = v120,
						["h"] = v151.box.y - v122
					}
					local v152 = v123 + v145 + 8
					local v153 = (v149 - p119.buyH) / 2
					v151.buy = {
						["x"] = v152,
						["y"] = v123 + math.floor(v153),
						["w"] = v143,
						["h"] = p119.buyH
					}
					if v124 then
						local v154 = v151.buy.x + v143 + 8
						local v155 = (v149 - p119.giftH) / 2
						v151.gift = {
							["x"] = v154,
							["y"] = v123 + math.floor(v155),
							["w"] = v144,
							["h"] = p119.giftH
						}
					end
					if v151.info.h > v130.info.h then
						return v151
					end
				end
			end
		end
		local v156
		if v124 and v125 then
			local v157 = (v120 - 2 * v123 - 8) / 2
			v156 = math.floor(v157)
		else
			local v158 = v120 - 2 * v123
			v156 = math.min(260, v158)
		end
		v130.buy = {
			["x"] = v123,
			["y"] = v123,
			["w"] = v156,
			["h"] = p119.buyH
		}
		if v124 then
			local v159
			if v125 then
				v159 = {
					["x"] = v123 + v156 + 8,
					["y"] = v123,
					["w"] = v156,
					["h"] = p119.giftH
				}
			else
				v159 = {
					["x"] = v123,
					["y"] = v123 + p119.buyH + 8,
					["w"] = v156,
					["h"] = p119.giftH
				}
			end
			v130.gift = v159
		end
		return v130
	end
}
return v_u_160