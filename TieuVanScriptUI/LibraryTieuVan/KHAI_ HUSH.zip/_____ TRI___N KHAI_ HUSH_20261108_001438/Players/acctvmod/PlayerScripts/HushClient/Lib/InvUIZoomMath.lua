-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIZoomMath

local v_u_112 = {
	["STEPS"] = {
		0.6,
		0.7,
		0.8,
		0.9,
		1,
		1.15,
		1.3
	},
	["FIT_STEPS"] = {
		0.6,
		0.7,
		0.8,
		0.9,
		1
	},
	["DEFAULT"] = {
		["P"] = 1,
		["T"] = 1,
		["K"] = 1
	},
	["FIT"] = 0,
	["MAX_CELL"] = 96,
	["MIN_REAL_TOUCH"] = 28,
	["MIN_REAL_MOUSE"] = 24,
	["FIT_BELOW"] = 0.3,
	["snap"] = function(p1) -- name: snap
		-- upvalues: (copy) v_u_112
		if p1 == "fit" then
			return "fit"
		end
		local v2
		if type(p1) == "number" and (p1 == p1 and p1 ~= (1 / 0)) then
			v2 = p1 ~= (-1 / 0)
		else
			v2 = false
		end
		if not v2 then
			return (type(p1) ~= "number" or p1 ~= (1 / 0)) and 1 or v_u_112.STEPS[#v_u_112.STEPS]
		end
		if p1 < 0 then
			return 1
		end
		if p1 < v_u_112.FIT_BELOW then
			return "fit"
		end
		local v3 = v_u_112.STEPS
		local v4 = (1 / 0)
		local v5 = 1
		for v6, v7 in v_u_112.STEPS do
			local v8 = v7 - p1
			local v9 = math.abs(v8)
			if v9 >= v4 - 1e-9 then
				continue
			end
			v5 = v6
			v4 = v9
		end
		return v3[v5]
	end,
	["resolve"] = function(p10, p11) -- name: resolve
		-- upvalues: (copy) v_u_112
		if p10 ~= nil then
			return v_u_112.snap(p10)
		end
		local v12 = v_u_112.DEFAULT[p11]
		return v12 == nil and 1 or v_u_112.snap(v12)
	end,
	["encode"] = function(p13) -- name: encode
		-- upvalues: (copy) v_u_112
		if p13 == "fit" then
			return v_u_112.FIT
		end
		local v14
		if type(p13) == "number" and (p13 == p13 and p13 ~= (1 / 0)) then
			v14 = p13 ~= (-1 / 0)
		else
			v14 = false
		end
		if not v14 then
			return 1
		end
		local v15 = v_u_112.STEPS
		local v16 = (1 / 0)
		local v17 = 1
		for v18, v19 in v_u_112.STEPS do
			local v20 = v19 - p13
			local v21 = math.abs(v20)
			if v21 >= v16 - 1e-9 then
				continue
			end
			v17 = v18
			v16 = v21
		end
		return v15[v17]
	end,
	["label"] = function(p22) -- name: label
		if p22 == "fit" then
			return "Fit"
		end
		local v23
		if type(p22) == "number" and (p22 == p22 and p22 ~= (1 / 0)) then
			v23 = p22 ~= (-1 / 0)
		else
			v23 = false
		end
		local v24 = not v23 and 1 or p22
		local v25 = string.format
		local v26 = v24 * 100 + 0.5
		return v25("%d%%", (math.floor(v26)))
	end,
	["step"] = function(p27, p28, p29) -- name: step
		-- upvalues: (copy) v_u_112
		local v30
		if p27 == "fit" then
			v30 = p29 or 1
		else
			local v31
			if type(p27) == "number" and (p27 == p27 and p27 ~= (1 / 0)) then
				v31 = p27 ~= (-1 / 0)
			else
				v31 = false
			end
			v30 = not v31 and (p29 or 1) or p27
		end
		local v32 = (1 / 0)
		local v33 = 1
		for v34, v35 in v_u_112.STEPS do
			local v36 = v35 - v30
			local v37 = math.abs(v36)
			if v37 >= v32 - 1e-9 then
				continue
			end
			v33 = v34
			v32 = v37
		end
		if p28 > 0 then
			local v38 = #v_u_112.STEPS
			local v39 = v33 + 1
			v33 = math.min(v38, v39)
		elseif p28 < 0 then
			local v40 = v33 - 1
			v33 = math.max(1, v40)
		end
		return v_u_112.STEPS[v33]
	end,
	["canIn"] = function(p41) -- name: canIn
		-- upvalues: (copy) v_u_112
		if p41 ~= "fit" then
			local v42
			if type(p41) == "number" and (p41 == p41 and p41 ~= (1 / 0)) then
				v42 = p41 ~= (-1 / 0)
			else
				v42 = false
			end
			if v42 then
				local v43 = (1 / 0)
				local v44 = 1
				for v45, v46 in v_u_112.STEPS do
					local v47 = v46 - p41
					local v48 = math.abs(v47)
					if v48 >= v43 - 1e-9 then
						continue
					end
					v44 = v45
					v43 = v48
				end
				return v44 < #v_u_112.STEPS
			end
		end
		return true
	end,
	["canOut"] = function(p49) -- name: canOut
		-- upvalues: (copy) v_u_112
		if p49 ~= "fit" then
			local v50
			if type(p49) == "number" and (p49 == p49 and p49 ~= (1 / 0)) then
				v50 = p49 ~= (-1 / 0)
			else
				v50 = false
			end
			if v50 then
				local v51 = (1 / 0)
				local v52 = 1
				for v53, v54 in v_u_112.STEPS do
					local v55 = v54 - p49
					local v56 = math.abs(v55)
					if v56 >= v51 - 1e-9 then
						continue
					end
					v52 = v53
					v51 = v56
				end
				return v52 > 1
			end
		end
		return true
	end,
	["floorZ"] = function(p57, p58) -- name: floorZ
		-- upvalues: (copy) v_u_112
		local v59
		if p58 then
			v59 = v_u_112.MIN_REAL_TOUCH
		else
			v59 = v_u_112.MIN_REAL_MOUSE
		end
		local v60 = v59 / math.max(p57, 0.1)
		return math.ceil(v60)
	end,
	["limits"] = function(p61, p62, p63, p64, p65) -- name: limits
		-- upvalues: (copy) v_u_112
		local v66
		if type(p63) == "number" and (p63 == p63 and p63 ~= (1 / 0)) then
			v66 = p63 ~= (-1 / 0)
		else
			v66 = false
		end
		local v67 = (not v66 or p63 <= 0) and 1 or p63
		local v68 = p61 * v67 + 1e-6
		local v69 = math.floor(v68)
		if v67 < 1 then
			local v70 = v_u_112.floorZ(p64, p65)
			local v71 = math.max(v70, v69)
			p61 = math.min(p61, v71)
		elseif v67 ~= 1 then
			p61 = v69
		end
		local v72 = p62 * v67 + 1e-6
		local v73 = math.floor(v72)
		local v74 = math.max(p61, v73)
		if v67 == 1 then
			v74 = math.max(p61, p62)
		end
		local v75 = v_u_112.MAX_CELL
		local v76 = math.min(v74, v75)
		return p61, math.max(p61, v76)
	end,
	["fit"] = function(p77, p78) -- name: fit
		-- upvalues: (copy) v_u_112
		local v79 = p78 or v_u_112.FIT_STEPS
		for v80 = #v79, 1, -1 do
			local v81 = p77(v79[v80])
			if not v81 or (v81.overflowX or v81.overflowGear) then
				continue
			end
			return v79[v80], 1
		end
		for v82 = #v79, 1, -1 do
			local v83 = p77(v79[v82])
			if not v83 or v83.overflowX then
				continue
			end
			return v79[v82], 2
		end
		return v79[1], 3
	end,
	["maxIn"] = function(p84, p85, p86) -- name: maxIn
		-- upvalues: (copy) v_u_112
		local v87 = 1
		for _, v88 in p86 or v_u_112.STEPS do
			if v88 <= 1.000000001 then
				continue
			end
			local v89 = p84(v88)
			if not (v89 and p85(v89)) then
				break
			end
			v87 = v88
		end
		return v87
	end,
	["shown"] = function(p90, p91) -- name: shown
		if p90 ~= "fit" then
			local v92
			if type(p90) == "number" and (p90 == p90 and p90 ~= (1 / 0)) then
				v92 = p90 ~= (-1 / 0)
			else
				v92 = false
			end
			if v92 then
				if p91 == nil or p91 + 1e-9 >= p90 then
					return p90
				else
					return p91
				end
			end
		end
		return p90
	end,
	["stepTo"] = function(p93, p94, p95, p96) -- name: stepTo
		-- upvalues: (copy) v_u_112
		local v97 = v_u_112.step(v_u_112.shown(p93, p96), p94, p95)
		if p94 > 0 and (p96 ~= nil and p96 + 1e-9 < v97) then
			return nil
		else
			return v97
		end
	end,
	["canMore"] = function(p98, p99) -- name: canMore
		-- upvalues: (copy) v_u_112
		if not v_u_112.canIn(p98) then
			return false
		end
		local v100
		if p99 == nil then
			v100 = true
		else
			local v101
			if type(p98) == "number" and (p98 == p98 and p98 ~= (1 / 0)) then
				v101 = p98 ~= (-1 / 0)
			else
				v101 = false
			end
			v100 = not v101 or p98 < p99 - 1e-9
		end
		return v100
	end,
	["fitsAt100"] = function(p102) -- name: fitsAt100
		local v103, v104 = pcall(p102, 1)
		local v105 = v103 and (type(v104) == "table" and not v104.overflowX)
		if v105 then
			v105 = not v104.overflowGear
		end
		return v105
	end,
	["hideBlock"] = function(p106, p107) -- name: hideBlock
		-- upvalues: (copy) v_u_112
		if p106 then
			return false
		else
			return v_u_112.fitsAt100(p107)
		end
	end,
	["class"] = function(p108, p109) -- name: class
		return p109 and (p108 and "P" or "T") or "K"
	end,
	["key"] = function(p110) -- name: key
		return "invZoom" .. (p110 ~= "P" and p110 ~= "T" and "K" or p110)
	end,
	["attr"] = function(p111) -- name: attr
		return "InvZoom" .. (p111 ~= "P" and p111 ~= "T" and "K" or p111)
	end
}
return v_u_112