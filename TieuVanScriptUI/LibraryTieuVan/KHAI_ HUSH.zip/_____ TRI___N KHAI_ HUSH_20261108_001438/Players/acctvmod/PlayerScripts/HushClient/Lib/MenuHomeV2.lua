-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuHomeV2

local v1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v1.build(p_u_3, p_u_4, p_u_5) -- name: build
	-- upvalues: (copy) v_u_2
	local v_u_6 = p_u_3.ui
	local v_u_7 = p_u_3.theme
	local v_u_8 = v_u_7.color
	local v_u_9 = p_u_3.kit
	local v_u_10 = p_u_5.route
	local v11 = p_u_5.layout
	local v12 = p_u_5.slab
	local v13 = p_u_5.ref
	local v_u_14 = p_u_5.touch
	local v_u_15 = p_u_5.phone
	local v_u_16 = p_u_5.visible()
	local v_u_17 = {}
	local v_u_18 = true
	local v_u_19 = {}
	local v_u_20 = {}
	local v_u_21
	if p_u_5.has("MenuRail") then
		v_u_21 = p_u_5.lib("MenuRail")
	else
		v_u_21 = nil
	end
	local v22 = {}
	if v_u_21 ~= nil and p_u_5.has("MenuMail") then
		table.insert(v22, {
			["id"] = "mail",
			["text"] = "MAIL"
		})
	end
	if v_u_21 ~= nil and p_u_5.has("MenuInsure") then
		local v23 = p_u_5.lib("MenuInsure")
		if type(v23) == "table" then
			local v24 = v23.open
			if type(v24) == "function" then
				table.insert(v22, {
					["id"] = "insure",
					["text"] = "INSURANCE"
				})
			end
		end
	end
	if v_u_21 ~= nil and p_u_5.has("MenuVotes") then
		table.insert(v22, {
			["id"] = "votes",
			["text"] = "VOTES"
		})
	end
	local v25 = {
		["touch"] = nil,
		["phone"] = nil,
		["count"] = nil,
		["partySlots"] = 4,
		["cards"] = true,
		["notes"] = nil,
		["touch"] = v_u_14,
		["phone"] = v_u_15,
		["count"] = #v_u_16,
		["notes"] = #v22
	}
	local v_u_26 = v11.home(v13, v25)
	if (p_u_5.floorX or 0) > v_u_26.list.x and not v_u_26.portrait then
		local v27, v28 = pcall(function()
			-- upvalues: (copy) v_u_6
			return v_u_6.topInset()
		end)
		if v27 and type(v28) == "number" then
			v25.topClear = v28
			v_u_26 = v11.home(v13, v25)
		end
	end
	v_u_17.layout = v_u_26
	local v29 = v_u_15 and 8 or 12
	local v30 = v_u_15 and 150 or 200
	local v31 = v_u_10.fitParty(v_u_26, v_u_10.partyLeftMin(v_u_26, p_u_5.floorX, v30, v29), v29, v_u_15 and 380 or 520)
	local v32 = v_u_10.homeCash(v_u_26, p_u_5.floorX, v30, v31, v29)
	local v33 = v_u_6.new("ScrollingFrame", {
		["Name"] = "List",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["CanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ElasticBehavior"] = nil,
		["ClipsDescendants"] = true,
		["CanvasSize"] = UDim2.new(),
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ScrollBarThickness"] = v_u_26.listScroll and 3 or 0,
		["ScrollBarImageColor3"] = v_u_8.lineStrong,
		["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
	}, p_u_4)
	local v34 = v_u_26.list
	v33.Position = UDim2.fromOffset(v34.x, v34.y)
	v33.Size = UDim2.fromOffset(v34.w, v34.h)
	local v35 = v11.ROW_GAP
	local v_u_36 = {}
	local v_u_37 = {}
	local v_u_38 = nil
	for v39, v_u_40 in v_u_16 do
		local v41 = v12(p_u_3, {
			["parent"] = nil,
			["name"] = nil,
			["rect"] = nil,
			["text"] = nil,
			["kind"] = "row",
			["onClick"] = nil,
			["parent"] = v33,
			["name"] = "Row_" .. v_u_40.id,
			["rect"] = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = (v39 - 1) * (v_u_26.rowH + v35),
				["w"] = v_u_26.list.w - (v_u_26.listScroll and 6 or 0),
				["h"] = v_u_26.rowH
			},
			["text"] = v_u_40.text,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_5, (copy) v_u_40
				p_u_5.activate(v_u_40)
			end
		})
		v_u_36[v_u_40.id] = v41
		v_u_37[v_u_40.id] = v_u_40.text
		if v_u_38 ~= nil then
			continue
		end
		v_u_38 = v41.btn
	end
	local v42 = UDim2.fromOffset
	local v43 = #v_u_16 * (v_u_26.rowH + v35) - v35
	v33.CanvasSize = v42(0, (math.max(0, v43)))
	function v_u_17.rowButton(p44) -- name: rowButton
		-- upvalues: (copy) v_u_36
		local v45 = v_u_36[p44]
		if v45 then
			return v45.btn
		else
			return nil
		end
	end
	function v_u_17.padFirst() -- name: padFirst
		-- upvalues: (ref) v_u_38
		return v_u_38
	end
	function v_u_17.setRowText(p46, p47) -- name: setRowText
		-- upvalues: (copy) v_u_36, (copy) v_u_37
		local v48 = v_u_36[p46]
		if v48 then
			v48.setText(p47 or v_u_37[p46])
		end
	end
	local v49 = v_u_6.new("Frame", {
		["Name"] = "Cash",
		["BackgroundTransparency"] = 1
	}, p_u_4)
	v49.Position = UDim2.fromOffset(v32.x, v32.y)
	v49.Size = UDim2.fromOffset(v32.w, v32.h)
	v_u_6.label({
		["parent"] = nil,
		["text"] = "Cash",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v49,
		["color"] = v_u_8.text2,
		["size"] = UDim2.new(1, 0, 0, 12),
		["position"] = UDim2.fromOffset(0, 0)
	})
	local v_u_50 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = "$-",
		["style"] = "monoL",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v49,
		["textSize"] = v_u_15 and 18 or 20,
		["color"] = v_u_8.accent,
		["position"] = UDim2.fromOffset(0, 12),
		["size"] = UDim2.new(1, 0, 1, -12)
	})
	function v_u_17.setCash(p51) -- name: setCash
		-- upvalues: (copy) v_u_50
		if v_u_50.Text ~= p51 then
			v_u_50.Text = p51
		end
	end
	local function v_u_55() -- name: openWorld
		-- upvalues: (copy) p_u_3
		local v_u_52 = false
		local function v53()
			-- upvalues: (ref) v_u_52, (ref) p_u_3
			v_u_52 = p_u_3.cctx.shared.Config.OPEN_WORLD == true
		end
		pcall(v53)
		if not v_u_52 then
			local function v54()
				-- upvalues: (ref) v_u_52
				v_u_52 = workspace:GetAttribute("WorldOpen") == true
			end
			pcall(v54)
		end
		return v_u_52
	end
	local v_u_56
	if p_u_5.has("PlayModeSel") then
		v_u_56 = p_u_5.lib("PlayModeSel")
	else
		v_u_56 = nil
	end
	local v_u_57 = {}
	local function v_u_82() -- name: stepView
		-- upvalues: (copy) v_u_56, (copy) v_u_57, (copy) p_u_3, (copy) p_u_5
		if v_u_56 ~= nil then
			local v58 = v_u_56.step
			if type(v58) == "function" then
				local v59 = v_u_56.step
				local v60 = v_u_57
				local v61 = {
					["shown"] = true,
					["inParty"] = nil,
					["leader"] = nil,
					["partyMode"] = nil,
					["profileMode"] = nil
				}
				local function v65()
					-- upvalues: (ref) p_u_3
					local v62 = p_u_3.myParty()
					local v63
					if type(v62) == "table" then
						local v64 = v62.members
						if type(v64) == "table" then
							v63 = #v62.members > 1
						else
							v63 = false
						end
					else
						v63 = false
					end
					return v63
				end
				local v66, v67 = pcall(v65)
				local v68 = v66
				if v68 then
					v68 = v67 == true
				end
				v61.inParty = v68
				local function v69()
					-- upvalues: (ref) p_u_3
					return p_u_3.isLeader() ~= false
				end
				local v70, v71 = pcall(v69)
				v61.leader = not v70 or v71 == true
				local v_u_72 = nil
				local function v73()
					-- upvalues: (ref) v_u_72, (ref) p_u_3
					v_u_72 = p_u_3.myParty().settings.viewMode
				end
				pcall(v73)
				v61.partyMode = v_u_72
				local v_u_74 = nil
				local function v75()
					-- upvalues: (ref) v_u_74, (ref) p_u_3
					v_u_74 = p_u_3.profile.settings.raidView
				end
				pcall(v75)
				v61.profileMode = v_u_74
				local v76 = p_u_5.now
				local v77, v78 = pcall(v76)
				if not v77 or type(v78) ~= "number" then
					v78 = os.clock()
				end
				local v79, v80, v81 = pcall(v59, v60, v61, v78)
				if v79 and type(v80) == "string" then
					return v80, v81 == true
				else
					return nil, false
				end
			end
		end
		return nil, false
	end
	local function v_u_107() -- name: currentView
		-- upvalues: (copy) p_u_3, (copy) v_u_55, (copy) v_u_82
		local function v83()
			-- upvalues: (ref) p_u_3
			return p_u_3.cctx.shared.GameMode.isPvpve()
		end
		local v84, v85 = pcall(v83)
		local v86 = v84
		if v86 then
			v86 = v85 == true
		end
		if v86 and v_u_55() then
			local v_u_87 = nil
			local function v88()
				-- upvalues: (ref) v_u_87, (ref) p_u_3
				v_u_87 = p_u_3.cctx.shared.Config.WORLD_VIEW
			end
			pcall(v88)
			return v_u_87 == "fptp" and "fptp" or "classic"
		end
		local v89 = v_u_82()
		if v89 ~= nil then
			return v89 == "fptp" and "fptp" or "classic"
		end
		local function v93()
			-- upvalues: (ref) p_u_3
			local v90 = p_u_3.myParty()
			local v91
			if type(v90) == "table" then
				local v92 = v90.members
				if type(v92) == "table" then
					v91 = #v90.members > 1
				else
					v91 = false
				end
			else
				v91 = false
			end
			return v91
		end
		local v94, v95 = pcall(v93)
		local v96 = v94
		if v96 then
			v96 = v95 == true
		end
		if not v96 then
			local v_u_97 = nil
			local function v98()
				-- upvalues: (ref) v_u_97, (ref) p_u_3
				v_u_97 = p_u_3.profile.settings.raidView
			end
			pcall(v98)
			return v_u_97 == "fptp" and "fptp" or "classic"
		end
		local v_u_99 = nil
		local function v100()
			-- upvalues: (ref) v_u_99, (ref) p_u_3
			v_u_99 = p_u_3.myParty().settings.viewMode
		end
		pcall(v100)
		local v101 = v_u_99
		if v101 == "fptp" or v101 == "classic" then
			return v101
		end
		local function v102()
			-- upvalues: (ref) p_u_3
			return p_u_3.isLeader() ~= false
		end
		local v103, v104 = pcall(v102)
		if v103 and v104 ~= true then
			return "classic"
		end
		local v_u_105 = nil
		local function v106()
			-- upvalues: (ref) v_u_105, (ref) p_u_3
			v_u_105 = p_u_3.profile.settings.raidView
		end
		pcall(v106)
		return v_u_105 == "fptp" and "fptp" or "classic"
	end
	local v108 = v_u_6.new("Frame", {
		["Name"] = "PartyHost",
		["BackgroundTransparency"] = 1,
		["ZIndex"] = 6
	}, p_u_4)
	v108.Position = UDim2.fromOffset(v31.x, v31.y)
	v108.Size = UDim2.fromOffset(v31.w, v31.h)
	local v_u_109 = nil
	local v110
	if p_u_5.has("MenuParty") then
		v110 = p_u_5.lib("MenuParty")
	else
		v110 = nil
	end
	if v110 ~= nil and v31.w > 0 then
		local v111 = v110.new
		local v112 = {
			["fit"] = v31.w
		}
		local v113, v114 = pcall(v111, p_u_3, v108, 0, v112)
		if v113 and v114 ~= nil then
			local v115 = v114.frame
			v115.AnchorPoint = Vector2.new(1, 0)
			v115.Position = UDim2.new(1, 0, 0, 0)
			v115.Size = UDim2.new(0, v31.w, 0, v115.Size.Y.Offset)
			v_u_109 = v114
		else
			warn("[MenuHomeV2] party bar failed:", v114)
		end
	end
	v_u_17.party = v_u_109
	v12(p_u_3, {
		["parent"] = nil,
		["name"] = "Invite",
		["rect"] = nil,
		["text"] = "INVITE",
		["kind"] = "chip",
		["onClick"] = nil,
		["tip"] = nil,
		["parent"] = p_u_4,
		["rect"] = v_u_26.invite,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_5, (copy) p_u_3
			local v116
			if p_u_5.has("MenuSquads") then
				v116 = p_u_5.lib("MenuSquads")
			else
				v116 = nil
			end
			if v116 then
				local v117 = v116.openInvite
				if type(v117) == "function" then
					v116.openInvite(p_u_3)
				end
			end
		end,
		["tip"] = function() -- name: tip
			return {
				["title"] = "INVITE",
				["body"] = "Ask a friend or another survivor to join your squad."
			}
		end
	}).btn.ZIndex = 7
	local v_u_118 = nil
	local v_u_119 = nil
	local v_u_120 = nil
	local function v_u_139() -- name: fallbackDoor
		-- upvalues: (copy) p_u_5, (copy) p_u_3, (copy) v_u_6
		local v_u_121 = true
		local function v124()
			-- upvalues: (ref) p_u_5, (ref) v_u_121, (ref) p_u_3
			local v122
			if p_u_5.has("MenuPvpveDoor") then
				v122 = p_u_5.lib("MenuPvpveDoor")
			else
				v122 = nil
			end
			if v122 then
				local v123 = v122.openFor
				if type(v123) == "function" then
					v_u_121 = v122.openFor(p_u_3.cctx) == true
				end
			end
		end
		pcall(v124)
		if v_u_121 then
			p_u_3.op({
				["op"] = "pvpveDoor"
			})
		else
			local function v125()
				-- upvalues: (ref) p_u_3
				return p_u_3.cctx.shared.GameMode.isPvpve()
			end
			local v126, v127 = pcall(v125)
			local v128 = v126
			if v128 then
				v128 = v127 == true
			end
			local v_u_129 = nil
			local function v130()
				-- upvalues: (ref) v_u_129, (ref) p_u_3
				v_u_129 = p_u_3.cctx.shared.PvpveDoorRules
			end
			pcall(v130)
			local v131 = v_u_129
			local v132 = "Travel is not available right now."
			if v131 then
				local v133 = v131.errorText
				if type(v133) == "function" then
					local v134 = v131.errorText
					local v135 = "closed"
					local function v136()
						-- upvalues: (ref) p_u_3
						return p_u_3.cctx.shared.GameMode.isPvpve()
					end
					local v137, v138 = pcall(v136)
					if v137 then
						v137 = v138 == true
					end
					v132 = v134(v135, v137 and "pve" or "pvp")
				end
			end
			v_u_6.toast(v132, "warn")
		end
	end
	local function v_u_170(p140, p141, p_u_142) -- name: sendSwitch
		-- upvalues: (ref) v_u_120, (copy) v_u_10, (copy) p_u_3, (copy) v_u_55, (copy) v_u_139, (ref) v_u_118, (ref) v_u_119, (copy) v_u_17, (ref) v_u_18, (copy) v_u_6
		if v_u_120 == nil then
			if p_u_142 == "pvp" then
				local v143 = v_u_10.pvpPlan
				local function v144()
					-- upvalues: (ref) p_u_3
					return p_u_3.cctx.shared.GameMode.isPvpve()
				end
				local v145, v146 = pcall(v144)
				if v145 then
					v145 = v146 == true
				end
				local v147 = v_u_55()
				local v_u_148 = true
				local function v149()
					-- upvalues: (ref) v_u_148, (ref) p_u_3
					v_u_148 = p_u_3.cctx.shared.Config.flag("WorldRoute")
				end
				pcall(v149)
				if v143(v145, v147, v_u_148 ~= false) ~= "worldSwitch" then
					v_u_139()
					return
				end
			end
			local v_u_150 = p_u_3.op({
				["op"] = "worldSwitch",
				["pvp"] = nil,
				["view"] = nil,
				["pvp"] = p140,
				["view"] = p141
			})
			v_u_120 = {
				["at"] = os.clock(),
				["req"] = v_u_150,
				["kind"] = p_u_142
			}
			if v_u_118 ~= nil then
				local v151 = v_u_118.setEnabled
				if type(v151) == "function" then
					v_u_118.setEnabled(false)
				end
			end
			if v_u_119 ~= nil then
				local v152 = v_u_119.setEnabled
				if type(v152) == "function" then
					v_u_119.setEnabled(false)
				end
			end
			v_u_17.paintChips()
			task.delay(15, function()
				-- upvalues: (ref) v_u_120, (ref) v_u_18, (copy) v_u_150, (ref) v_u_118, (ref) v_u_119, (ref) p_u_3, (ref) v_u_55, (ref) v_u_17, (ref) v_u_6, (copy) p_u_142
				local v153 = v_u_120
				if v_u_18 and (v153 ~= nil and v153.req == v_u_150) then
					v_u_120 = nil
					if v_u_118 ~= nil then
						local v154 = v_u_118.setEnabled
						if type(v154) == "function" then
							v_u_118.setEnabled(true)
						end
					end
					if v_u_119 ~= nil then
						local v155 = v_u_119.setEnabled
						if type(v155) == "function" then
							local v156 = v_u_119.setEnabled
							local function v157()
								-- upvalues: (ref) p_u_3
								return p_u_3.cctx.shared.GameMode.isPvpve()
							end
							local v158, v159 = pcall(v157)
							if v158 then
								v158 = v159 == true
							end
							if v158 then
								v158 = v_u_55()
							end
							local v160 = not v158
							if v160 then
								local function v164()
									-- upvalues: (ref) p_u_3
									local v161 = p_u_3.myParty()
									local v162
									if type(v161) == "table" then
										local v163 = v161.members
										if type(v163) == "table" then
											v162 = #v161.members > 1
										else
											v162 = false
										end
									else
										v162 = false
									end
									return v162
								end
								local v165
								v160, v165 = pcall(v164)
								if v160 then
									v160 = v165 == true
								end
								if v160 then
									local function v166()
										-- upvalues: (ref) p_u_3
										return p_u_3.isLeader() ~= false
									end
									local v167, v168 = pcall(v166)
									local v169 = not v167 or v168 == true
									v160 = not v169
								end
							end
							v156(not v160)
						end
					end
					if v_u_17.paintChips then
						v_u_17.paintChips()
					end
					v_u_6.toast(p_u_142 == "view" and "Switching the view is not available yet." or "The travel did not start. Try again in a moment.", "warn")
				end
			end)
		end
	end
	local function v_u_191(p_u_171, p_u_172, p_u_173) -- name: confirmSwitch
		-- upvalues: (copy) p_u_3, (copy) v_u_6, (copy) v_u_170
		local v174 = p_u_171 and "pvp" or "pve"
		local v_u_175 = nil
		local function v176()
			-- upvalues: (ref) v_u_175, (ref) p_u_3
			v_u_175 = p_u_3.cctx.shared.PvpveDoorRules
		end
		pcall(v176)
		local v177 = v_u_175
		local v178
		if v177 then
			local v179 = v177.textsFor
			if type(v179) == "function" then
				v178 = v177.textsFor(v174)
			else
				v178 = nil
			end
		else
			v178 = nil
		end
		local function v183()
			-- upvalues: (ref) p_u_3
			local v180 = p_u_3.myParty()
			local v181
			if type(v180) == "table" then
				local v182 = v180.members
				if type(v182) == "table" then
					v181 = #v180.members > 1
				else
					v181 = false
				end
			else
				v181 = false
			end
			return v181
		end
		local v184, v185 = pcall(v183)
		if v184 then
			v184 = v185 == true
		end
		local v186 = "Switch to the " .. (p_u_172 == "fptp" and "FP / TP" or "Classic") .. " world?"
		local v187 = v184 and "Your squad travels with you." or "You travel alone."
		local v188 = v_u_6.modal
		local v189 = {
			["title"] = nil,
			["body"] = nil,
			["width"] = 480,
			["buttons"] = nil
		}
		if p_u_173 ~= "view" then
			if v178 then
				v186 = v178.confirmTitle
			else
				v186 = p_u_171 and "Travel to HUSH PVP?" or "Travel to HUSH PVE?"
			end
		end
		v189.title = v186
		if p_u_173 ~= "view" then
			if v177 then
				local v190 = v177.confirmBody
				v187 = type(v190) ~= "function" and "You travel to the other lobby." or v177.confirmBody(v184, v174)
			else
				v187 = "You travel to the other lobby."
			end
		end
		v189.body = v187
		v189.buttons = {
			{
				["text"] = nil,
				["kind"] = "ghost",
				["text"] = not v178 and "Stay" or v178.confirmStay
			},
			{
				["text"] = nil,
				["kind"] = "primary",
				["onClick"] = nil,
				["text"] = not v178 and "Travel" or v178.confirmGo,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_170, (copy) p_u_171, (copy) p_u_172, (copy) p_u_173
					v_u_170(p_u_171, p_u_172, p_u_173)
				end
			}
		}
		v188(v189)
	end
	local v192 = {
		["parent"] = nil,
		["name"] = "PvpChip",
		["rect"] = nil,
		["text"] = nil,
		["kind"] = "chip",
		["onClick"] = nil,
		["tip"] = nil,
		["parent"] = p_u_4,
		["rect"] = v_u_26.chips.pvp
	}
	local v193 = v_u_10.pvpChipText
	local v194, v195 = pcall(function()
		-- upvalues: (copy) p_u_3
		return p_u_3.cctx.shared.GameMode.isPvpve()
	end)
	local v196 = v194
	if v196 then
		v196 = v195 == true
	end
	v192.text = v193(v196)
	function v192.onClick() -- name: onClick
		-- upvalues: (ref) v_u_120, (copy) v_u_191, (copy) p_u_3, (copy) v_u_107
		if v_u_120 == nil then
			local v197 = v_u_191
			local function v198()
				-- upvalues: (ref) p_u_3
				return p_u_3.cctx.shared.GameMode.isPvpve()
			end
			local v199, v200 = pcall(v198)
			if v199 then
				v199 = v200 == true
			end
			v197(not v199, v_u_107(), "pvp")
		end
	end
	function v192.tip() -- name: tip
		-- upvalues: (copy) p_u_3
		local v201 = {
			["title"] = "PVP",
			["body"] = nil
		}
		local function v202()
			-- upvalues: (ref) p_u_3
			return p_u_3.cctx.shared.GameMode.isPvpve()
		end
		local v203, v204 = pcall(v202)
		if v203 then
			v203 = v204 == true
		end
		v201.body = v203 and "Squads fight squads and the infected. Switch off to play in a PVE server with your PVE stash." or "A PVE server: the infected and your squad. Switch on to join the PVP world, where other squads can shoot you."
		return v201
	end
	v_u_118 = v12(p_u_3, v192)
	v_u_119 = v12(p_u_3, {
		["parent"] = nil,
		["name"] = "ViewChip",
		["rect"] = nil,
		["text"] = nil,
		["kind"] = "chip",
		["onClick"] = nil,
		["tip"] = nil,
		["parent"] = p_u_4,
		["rect"] = v_u_26.chips.view,
		["text"] = v_u_10.viewChipText((v_u_107())),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_120, (copy) v_u_107, (copy) v_u_10, (copy) p_u_3, (copy) v_u_55, (copy) v_u_191, (copy) v_u_17
			if v_u_120 == nil then
				local v205 = v_u_107() == "fptp" and "classic" or "fptp"
				local v206 = v_u_10.viewPlan
				local function v207()
					-- upvalues: (ref) p_u_3
					return p_u_3.cctx.shared.GameMode.isPvpve()
				end
				local v208, v209 = pcall(v207)
				if v208 then
					v208 = v209 == true
				end
				local v210 = v_u_55()
				if v210 then
					local v_u_211 = true
					local function v212()
						-- upvalues: (ref) v_u_211, (ref) p_u_3
						v_u_211 = p_u_3.cctx.shared.Config.flag("WorldRoute")
					end
					pcall(v212)
					v210 = v_u_211 ~= false
				end
				local v213 = v206(v208, v210, v205)
				if v213.kind == "worldSwitch" then
					v_u_191(true, v213.view, "view")
				else
					v_u_17.pickView(v213.view)
				end
			else
				return
			end
		end,
		["tip"] = function() -- name: tip
			-- upvalues: (copy) p_u_3, (copy) v_u_55
			local function v214()
				-- upvalues: (ref) p_u_3
				return p_u_3.cctx.shared.GameMode.isPvpve()
			end
			local v215, v216 = pcall(v214)
			if v215 then
				v215 = v216 == true
			end
			if v215 then
				v215 = v_u_55()
			end
			local v217 = not v215
			if v217 then
				local function v221()
					-- upvalues: (ref) p_u_3
					local v218 = p_u_3.myParty()
					local v219
					if type(v218) == "table" then
						local v220 = v218.members
						if type(v220) == "table" then
							v219 = #v218.members > 1
						else
							v219 = false
						end
					else
						v219 = false
					end
					return v219
				end
				local v222
				v217, v222 = pcall(v221)
				if v217 then
					v217 = v222 == true
				end
				if v217 then
					local function v223()
						-- upvalues: (ref) p_u_3
						return p_u_3.isLeader() ~= false
					end
					local v224, v225 = pcall(v223)
					local v226 = not v224 or v225 == true
					v217 = not v226
				end
			end
			return v217 and {
				["title"] = "VIEW",
				["body"] = "The squad leader picks the view for the whole squad."
			} or {
				["title"] = "VIEW",
				["body"] = "CLASSIC is the top down view. FP / TP puts the camera on your shoulder and lets you look through your sights."
			}
		end
	})
	function v_u_17.pickView(p_u_227) -- name: pickView
		-- upvalues: (copy) p_u_3, (copy) v_u_6, (copy) v_u_17, (copy) v_u_82, (copy) v_u_57, (copy) v_u_56
		local function v231()
			-- upvalues: (ref) p_u_3
			local v228 = p_u_3.myParty()
			local v229
			if type(v228) == "table" then
				local v230 = v228.members
				if type(v230) == "table" then
					v229 = #v228.members > 1
				else
					v229 = false
				end
			else
				v229 = false
			end
			return v229
		end
		local v232, v233 = pcall(v231)
		if v232 then
			v232 = v233 == true
		end
		if v232 then
			local function v234()
				-- upvalues: (ref) p_u_3
				return p_u_3.isLeader() ~= false
			end
			local v235, v236 = pcall(v234)
			if v235 and v236 ~= true then
				v_u_6.toast("Only the squad leader can change this", "warn")
				v_u_17.paintChips()
				return
			end
		end
		local v237 = p_u_3.myParty()
		if type(v237) == "table" then
			local v238 = v237.searching
			if type(v238) == "table" then
				v_u_6.toast("Locked while searching", "warn", "Stop the search to change the conditions.")
				v_u_17.paintChips()
				return
			end
		end
		v_u_82()
		v_u_57.viewMode = p_u_227
		v_u_82()
		local function v240()
			-- upvalues: (ref) p_u_3, (copy) p_u_227
			local v239 = p_u_3.profile
			if type(v239) == "table" then
				p_u_3.profile.settings = p_u_3.profile.settings or {}
				p_u_3.profile.settings.raidView = p_u_227
			end
		end
		pcall(v240)
		p_u_3.op({
			["op"] = "setting",
			["key"] = "raidView",
			["value"] = nil,
			["value"] = p_u_227
		})
		if type(v237) == "table" then
			local v241 = {
				["op"] = "settings"
			}
			local v242 = nil
			if v_u_56 ~= nil then
				local v243 = v_u_56.payload
				if type(v243) == "function" then
					local v244 = v_u_56.payload
					local v245 = v_u_57
					local v246
					v246, v242 = pcall(v244, v245)
					if not v246 then
						v242 = nil
					end
				end
			end
			if type(v242) == "table" and v242.viewMode ~= nil then
				p_u_227 = v242.viewMode
			end
			v241.viewMode = p_u_227
			p_u_3.partyOp(v241)
		end
		v_u_17.paintChips()
	end
	function v_u_17.paintChips() -- name: paintChips
		-- upvalues: (ref) v_u_120, (ref) v_u_118, (copy) v_u_10, (copy) p_u_3, (copy) v_u_55, (copy) v_u_56, (ref) v_u_119, (copy) v_u_107
		local v247 = v_u_120 ~= nil
		local v248 = v_u_118.setText
		local v249
		if v247 and v_u_120.kind == "pvp" then
			v249 = "TRAVEL..."
		else
			local v250 = v_u_10.pvpChipText
			local function v251()
				-- upvalues: (ref) p_u_3
				return p_u_3.cctx.shared.GameMode.isPvpve()
			end
			local v252, v253 = pcall(v251)
			if v252 then
				v252 = v253 == true
			end
			v249 = v250(v252)
		end
		v248(v249)
		local v254 = v_u_118.setSelected
		local function v255()
			-- upvalues: (ref) p_u_3
			return p_u_3.cctx.shared.GameMode.isPvpve()
		end
		local v256, v257 = pcall(v255)
		local v258 = v256
		if v258 then
			v258 = v257 == true
		end
		v254(v258)
		local function v259()
			-- upvalues: (ref) p_u_3
			return p_u_3.cctx.shared.GameMode.isPvpve()
		end
		local v260, v261 = pcall(v259)
		local v262 = v260
		if v262 then
			v262 = v261 == true
		end
		local v263
		if v262 then
			v263 = v_u_55()
			if v263 then
				local v_u_264 = true
				local function v265()
					-- upvalues: (ref) v_u_264, (ref) p_u_3
					v_u_264 = p_u_3.cctx.shared.Config.flag("WorldRoute")
				end
				pcall(v265)
				v263 = v_u_264 ~= false
			end
		elseif v_u_56 == nil then
			v263 = false
		else
			v263 = v_u_56.liveShown(p_u_3.cctx) == true
		end
		v_u_119.btn.Visible = v263
		if v263 then
			v_u_119.setText(v247 and v_u_120.kind == "view" and "TRAVEL..." or v_u_10.viewChipText((v_u_107())))
			local v266 = v_u_119.setEnabled
			local v267 = not v247
			if v267 then
				local function v268()
					-- upvalues: (ref) p_u_3
					return p_u_3.cctx.shared.GameMode.isPvpve()
				end
				local v269, v270 = pcall(v268)
				if v269 then
					v269 = v270 == true
				end
				if v269 then
					v269 = v_u_55()
				end
				local v271 = not v269
				if v271 then
					local function v275()
						-- upvalues: (ref) p_u_3
						local v272 = p_u_3.myParty()
						local v273
						if type(v272) == "table" then
							local v274 = v272.members
							if type(v274) == "table" then
								v273 = #v272.members > 1
							else
								v273 = false
							end
						else
							v273 = false
						end
						return v273
					end
					local v276
					v271, v276 = pcall(v275)
					if v271 then
						v271 = v276 == true
					end
					if v271 then
						local function v277()
							-- upvalues: (ref) p_u_3
							return p_u_3.isLeader() ~= false
						end
						local v278, v279 = pcall(v277)
						local v280 = not v278 or v279 == true
						v271 = not v280
					end
				end
				v267 = not v271
			end
			v266(v267)
		end
	end
	local v_u_281 = v_u_119
	local v_u_282 = v_u_118
	local v_u_283 = v_u_120
	local v284 = { "mail", "insure", "votes" }
	local v_u_285 = {}
	for v286, v_u_287 in v22 do
		local v288 = v_u_26.notes[v284[v286]]
		if v288 == nil then
			continue
		end
		v_u_285[v_u_287.id] = v12(p_u_3, {
			["parent"] = nil,
			["name"] = nil,
			["rect"] = nil,
			["text"] = nil,
			["kind"] = "chip",
			["textSize"] = nil,
			["onClick"] = nil,
			["tip"] = nil,
			["parent"] = p_u_4,
			["name"] = "Note_" .. v_u_287.id,
			["rect"] = v288,
			["text"] = v_u_287.text,
			["textSize"] = v_u_15 and 12 or 13,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_285, (copy) v_u_287, (copy) p_u_5, (copy) v_u_21, (copy) p_u_3
				local v289 = v_u_285[v_u_287.id]
				if v289 then
					v289 = v_u_285[v_u_287.id].btn
				end
				local v290 = v_u_287.id == "mail" and "MenuMail" or (v_u_287.id == "votes" and "MenuVotes" or "MenuInsure")
				local v291
				if p_u_5.has(v290) then
					v291 = p_u_5.lib(v290)
				else
					v291 = nil
				end
				if v291 then
					local v292 = v291.open
					if type(v292) == "function" then
						if v_u_287.id == "votes" and (v_u_21 and v_u_21.failed("votes")) then
							v_u_21.fetch(p_u_3, "votes", {
								["force"] = true
							})
						end
						v291.open(p_u_3, v289)
					end
				end
			end,
			["tip"] = function() -- name: tip
				-- upvalues: (copy) v_u_287
				return v_u_287.id == "mail" and {
					["title"] = "MAIL",
					["body"] = "Letters from the HUSH team, and insured items that were lost in a raid."
				} or (v_u_287.id == "votes" and {
					["title"] = "VOTES",
					["body"] = "Tell us what to build next. One vote per poll."
				} or {
					["title"] = "INSURANCE",
					["body"] = "Insure the gear you take into a raid."
				})
			end
		})
	end
	local function v_u_302() -- name: paintNotes
		-- upvalues: (copy) v_u_21, (ref) v_u_2, (copy) v_u_285
		if v_u_21 ~= nil then
			local v_u_293 = 0
			local v_u_294 = 0
			local function v301()
				-- upvalues: (ref) v_u_21, (ref) v_u_2, (ref) v_u_293, (ref) v_u_294
				local v295 = v_u_21.mailLive()
				local v296 = v_u_2
				local v297 = tonumber(v296:GetAttribute("MailUnread")) or 0
				if v295 then
					v_u_293 = (v295.ready or 0) + (v295.waiting or 0)
				end
				local v298 = v_u_293
				local v299 = math.floor(v297)
				v_u_293 = v298 + math.max(0, v299)
				local v300 = v_u_21.votesLive()
				if v300 then
					v_u_294 = v300.openUnvoted or 0
				end
			end
			pcall(v301)
			if v_u_285.mail then
				v_u_285.mail.setBadge(v_u_293)
			end
			if v_u_285.votes then
				v_u_285.votes.setBadge(v_u_294)
			end
		end
	end
	local v_u_303 = 0
	local function v_u_306(p304) -- name: pollNotes
		-- upvalues: (copy) v_u_21, (copy) v_u_285, (ref) v_u_303, (copy) p_u_3
		if v_u_21 == nil or v_u_285.mail == nil and v_u_285.votes == nil then
			return
		else
			local v305 = os.clock()
			if p304 or v305 >= v_u_303 then
				v_u_303 = v305 + 60
				if v_u_285.mail then
					v_u_21.fetch(p_u_3, "mail", {
						["maxAge"] = 30
					})
				end
				if v_u_285.votes then
					v_u_21.fetch(p_u_3, "votes", {
						["maxAge"] = 30
					})
				end
			end
		end
	end
	if v_u_21 ~= nil then
		local v307 = v_u_21.listen
		if type(v307) == "function" then
			local v308 = v_u_21.listen(function()
				-- upvalues: (ref) v_u_18, (copy) v_u_302
				if v_u_18 then
					v_u_302()
				end
			end)
			table.insert(v_u_20, v308)
		end
	end
	local v_u_309 = nil
	local v_u_310 = nil
	local v_u_311 = nil
	local v_u_312 = ""
	local v_u_313 = nil
	local v_u_314 = false
	local v_u_315 = false
	local v_u_316 = nil
	local v_u_317 = true
	local v_u_318
	if p_u_5.has("MenuHunt") then
		v_u_318 = p_u_5.lib("MenuHunt")
	else
		v_u_318 = nil
	end
	local v_u_319 = nil
	local v_u_320 = nil
	local v_u_321 = false
	local v_u_322 = v_u_10.cardsPlan(v_u_26.cards, {
		["touch"] = v_u_14,
		["phone"] = v_u_15
	})
	function v_u_17.cardsPlan()
		-- upvalues: (ref) v_u_322
		return v_u_322
	end
	local v_u_323 = nil
	local function v_u_331() -- name: onScreen
		-- upvalues: (copy) p_u_4
		local v_u_324 = p_u_4
		local v325 = 0
		while v_u_324 ~= nil and v325 < 16 do
			v325 = v325 + 1
			local v326, v327 = pcall(function()
				-- upvalues: (ref) v_u_324
				return v_u_324:IsA("GuiObject")
			end)
			if v326 and (v327 and v_u_324.Visible == false) then
				return false
			end
			local v328, v329 = pcall(function()
				-- upvalues: (ref) v_u_324
				return v_u_324:IsA("ScreenGui")
			end)
			if v328 and (v329 and v_u_324.Enabled == false) then
				return false
			end
			local v330 = v_u_324.Parent
			v_u_324 = v330
		end
		return true
	end
	local function v_u_341() -- name: huntWanted
		-- upvalues: (copy) v_u_318, (ref) v_u_321, (ref) v_u_26, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15, (copy) p_u_3, (ref) v_u_319, (ref) v_u_317
		if v_u_318 ~= nil and not v_u_321 then
			local v332 = v_u_318.new
			if type(v332) == "function" then
				local v333 = v_u_318.openFor
				if type(v333) == "function" then
					if v_u_26.cards.h < v_u_10.taskH(v_u_14, v_u_15) + v_u_10.CARDS_GAP + v_u_10.HUNT_MIN_H then
						return false
					end
					local v334 = v_u_318.openFor
					local v335 = p_u_3.cctx
					local v336, v337 = pcall(v334, v335)
					if not v336 or v337 ~= true then
						return false
					end
					if v_u_319 == nil then
						return v_u_317
					end
					local v338 = v_u_319.isOpen
					local v339, v340 = pcall(v338)
					return not v339 or v340 ~= false
				end
			end
		end
		return false
	end
	local function v_u_351() -- name: ensureHunt
		-- upvalues: (ref) v_u_319, (ref) v_u_321, (ref) v_u_309, (copy) v_u_6, (copy) v_u_318, (copy) p_u_3, (ref) v_u_26, (ref) v_u_18, (ref) v_u_323, (ref) v_u_320
		if v_u_319 == nil and (not v_u_321 and v_u_309 ~= nil) then
			local v342 = v_u_6.new("Frame", {
				["Name"] = "HuntHolder",
				["BackgroundTransparency"] = 1,
				["ClipsDescendants"] = true,
				["Visible"] = false,
				["Size"] = nil,
				["Size"] = UDim2.fromOffset(0, 0)
			}, v_u_309)
			local v343 = v_u_318.new
			local v344 = p_u_3
			local v346 = {
				["mode"] = "mini",
				["w"] = nil,
				["splitTap"] = true,
				["onSize"] = nil,
				["w"] = v_u_26.cards.w,
				["onSize"] = function() -- name: onSize
					-- upvalues: (ref) v_u_18, (ref) v_u_323
					if v_u_18 and v_u_323 ~= nil then
						local v345 = v_u_323
						pcall(v345)
					end
				end
			}
			local v347, v348 = pcall(v343, v344, v342, 0, v346)
			if v347 and v348 ~= nil then
				v_u_319 = v348
				v_u_320 = v342
				if v348.frame ~= nil then
					v348.frame.Position = UDim2.fromOffset(0, 0)
				end
				local v349 = v348.paint
				if type(v349) == "function" then
					local v350 = v348.paint
					pcall(v350)
					return
				end
			else
				warn("[MenuHomeV2] hunt tile failed:", v348)
				v_u_321 = true
				v342:Destroy()
			end
		end
	end
	local function v_u_367() -- name: huntKinds
		-- upvalues: (ref) v_u_319, (copy) v_u_318, (copy) v_u_7, (ref) v_u_26
		local v352 = {}
		if v_u_319 ~= nil then
			local v353 = v_u_319.heightFor
			if type(v353) == "function" then
				local v354 = v_u_318.layout
				if type(v354) == "function" then
					local v_u_355 = false
					local function v356()
						-- upvalues: (ref) v_u_355, (ref) v_u_7
						v_u_355 = v_u_7.isTouch() == true
					end
					pcall(v356)
					local v357 = v_u_355
					for _, v358 in {
						"full",
						"mini",
						"phone",
						"slim"
					} do
						if v358 == "slim" and v357 then
							continue
						end
						local v359 = v_u_319.heightFor
						local v360, v361 = pcall(v359, v358)
						local v362 = v_u_318.layout
						local v363, v364 = pcall(v362, v358)
						if not v360 or (not v363 or (type(v361) ~= "number" or type(v364) ~= "table")) then
							continue
						end
						local v365 = {
							["kind"] = v358
						}
						local v366
						if v358 == "phone" or v358 == "slim" then
							v366 = v_u_26.cards.w
						else
							v366 = v364.w
						end
						v365.w = v366
						v365.h = v361
						table.insert(v352, v365)
					end
					return v352
				end
			end
		end
		return v352
	end
	v_u_323 = function()
		-- upvalues: (ref) v_u_309, (ref) v_u_310, (ref) v_u_18, (ref) v_u_313, (ref) v_u_26, (copy) v_u_341, (copy) v_u_351, (ref) v_u_319, (copy) v_u_367, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15, (ref) v_u_312, (ref) v_u_317, (copy) v_u_331, (ref) v_u_322, (ref) v_u_315, (ref) v_u_316, (copy) v_u_6, (copy) p_u_4, (copy) p_u_3, (ref) v_u_320
		if v_u_309 == nil or (v_u_310 == nil or not v_u_18) then
			return
		else
			local v368 = v_u_313
			local v369
			if v368 then
				v369 = v368.frame
			else
				v369 = v368
			end
			local v370
			if v369 == nil then
				v370 = false
			else
				v370 = v369.Visible == true
			end
			local v371 = {
				["shown"] = v370
			}
			if v370 then
				local v372 = v368.heightFor
				if type(v372) == "function" then
					local v373 = v368.heightFor
					local v374 = v_u_26.cards.w
					local v375, v376 = pcall(v373, "card", v374)
					local v377 = v368.heightFor
					local v378 = v_u_26.cards.w
					local v379, v380 = pcall(v377, "row", v378)
					v371.cardH = not v375 and 0 or v376
					v371.rowH = not v379 and 0 or v380
				end
			end
			local v381 = not v370
			if v381 then
				v381 = v_u_341()
			end
			if v381 then
				v_u_351()
			end
			local v382 = {
				["touch"] = v_u_14,
				["phone"] = v_u_15,
				["tutorial"] = v371,
				["hunt"] = v381 and v_u_319 ~= nil and {
					["kinds"] = v_u_367()
				} or nil
			}
			local v383 = v_u_10.cardsPlan(v_u_26.cards, v382)
			local v384
			if v370 then
				v384 = v383.tutorialHidden == true
			else
				v384 = v370
			end
			local v385 = table.concat
			local v386 = {}
			local v387 = tostring(v370)
			local v388 = v383.form
			local v389 = v371.cardH
			local v390 = tostring(v389)
			local v391 = v371.rowH
			local v392 = tostring(v391)
			local v393 = v383.task ~= nil
			local v394 = tostring(v393)
			local v395 = tostring(v384)
			local v396 = v383.huntKind
			local v397 = tostring(v396)
			local v398 = v383.hunt
			if v398 then
				v398 = v383.hunt.w
			end
			local v399 = tostring(v398)
			local v400 = v383.hunt
			if v400 then
				v400 = v383.hunt.h
			end
			__set_list(v386, 1, {v387, v388, v390, v392, v394, v395, v397, v399, (tostring(v400))})
			local v401 = v385(v386, "|")
			if v401 == v_u_312 then
				local v402 = v383.hunt ~= nil
				if v_u_319 ~= nil then
					local v403 = v_u_319.setActive
					if type(v403) == "function" then
						local v404 = v_u_319.setActive
						local v405 = v402 and v_u_317
						if v405 then
							v405 = v_u_331()
						end
						pcall(v404, v405)
					end
				end
			else
				v_u_312 = v401
				v_u_322 = v383
				if v369 ~= nil and v384 ~= v_u_315 then
					v_u_315 = v384
					if v384 then
						if v_u_316 == nil then
							v_u_316 = v_u_6.new("Frame", {
								["Name"] = "TutorialHolder",
								["BackgroundTransparency"] = 1,
								["Visible"] = false,
								["Size"] = nil,
								["Size"] = UDim2.fromOffset(0, 0)
							}, p_u_4)
						end
						v369.Parent = v_u_316
					else
						v369.Parent = v_u_309
					end
					local v406
					if v_u_313 == nil then
						v406 = false
					else
						v406 = p_u_3.tutorialCard == v_u_313
					end
					local v407 = v_u_315 and (v406 or v_u_317) and true or nil
					if p_u_3.tutorialCardOff ~= v407 then
						p_u_3.tutorialCardOff = v407
						if p_u_3.syncTutorial then
							p_u_3.syncTutorial()
						end
					end
				end
				if v370 and (not v384 and v369 ~= nil) then
					local v408 = v368.form
					if type(v408) == "function" and v368.form() ~= v383.form then
						local v409 = v368.setForm
						if type(v409) == "function" then
							v368.setForm(v383.form)
						end
					end
					v369.AutomaticSize = Enum.AutomaticSize.None
					local v410 = v383.tutorial
					v369.Position = UDim2.fromOffset(v410.x, v410.y)
					v369.Size = UDim2.fromOffset(v410.w, v410.h)
				end
				if v_u_320 ~= nil then
					if v383.hunt == nil then
						v_u_320.Visible = false
					else
						local v411 = v_u_320
						local v412 = v383.hunt
						v411.Position = UDim2.fromOffset(v412.x, v412.y)
						v411.Size = UDim2.fromOffset(v412.w, v412.h)
						if v_u_319 ~= nil then
							local v413 = v_u_319.setKind
							if type(v413) == "function" then
								local v414 = v_u_319.setKind
								local v415 = v383.huntKind
								pcall(v414, v415)
							end
						end
						v_u_320.Visible = true
					end
				end
				local v416 = v383.hunt ~= nil
				if v_u_319 ~= nil then
					local v417 = v_u_319.setActive
					if type(v417) == "function" then
						local v418 = v_u_319.setActive
						local v419 = v416 and v_u_317
						if v419 then
							v419 = v_u_331()
						end
						pcall(v418, v419)
					end
				end
				if v383.task ~= nil then
					local v420 = v_u_310.btn
					local v421 = v383.task
					v420.Position = UDim2.fromOffset(v421.x, v421.y)
					v420.Size = UDim2.fromOffset(v421.w, v421.h)
					local v422 = v_u_310.sub
					local v423 = v383.taskSub
					v422.Position = UDim2.fromOffset(v423.x, v423.y)
					v422.Size = UDim2.fromOffset(v423.w, v423.h)
					local v424 = v_u_310.label
					local v425 = v383.taskLabel
					v424.Position = UDim2.fromOffset(v425.x, v425.y)
					v424.Size = UDim2.fromOffset(v425.w, v425.h)
				end
				v_u_310.btn.Visible = v383.task ~= nil
			end
		end
	end
	if v_u_26.cards.w > 0 and v_u_26.cards.h > 0 then
		local v426 = v_u_6.new("Frame", {
			["Name"] = "Cards",
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}, p_u_4)
		local v427 = v_u_26.cards
		v426.Position = UDim2.fromOffset(v427.x, v427.y)
		v426.Size = UDim2.fromOffset(v427.w, v427.h)
		local _ = v426
		local v428
		if p_u_5.has("MenuTutorialCard") then
			v428 = p_u_5.lib("MenuTutorialCard")
		else
			v428 = nil
		end
		if v428 ~= nil then
			local v429 = v428.new
			if type(v429) == "function" then
				local v430 = p_u_3.playColW
				function p_u_3.playColW()
					-- upvalues: (ref) v_u_322
					return v_u_322.colW
				end
				local v431 = v428.new
				local v432, v433 = pcall(v431, p_u_3, v426, 1, {
					["form"] = "row"
				})
				p_u_3.playColW = v430
				if v432 then
					local v434 = v433
					if p_u_3.tutorialCard == nil then
						p_u_3.tutorialCard = v433
						v_u_313 = v434
						v_u_314 = true
					else
						v_u_313 = v434
					end
				else
					warn("[MenuHomeV2] tutorial card failed:", v433)
					v_u_2:SetAttribute("ClientError", "menu tutorial card: " .. tostring(v433))
				end
			end
		end
		local v435 = v_u_322.task or {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v_u_26.cards.w,
			["h"] = v_u_322.taskH
		}
		v_u_310 = v12(p_u_3, {
			["parent"] = nil,
			["name"] = "TaskCard",
			["rect"] = nil,
			["text"] = "Loading tasks",
			["sub"] = "",
			["kind"] = "row",
			["textSize"] = nil,
			["onClick"] = nil,
			["parent"] = v426,
			["rect"] = v435,
			["textSize"] = v_u_15 and 15 or 17,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_3, (ref) v_u_311
				if p_u_3.openTask then
					p_u_3.openTask(v_u_311)
				else
					p_u_3.setTab("tasks")
				end
			end
		})
		local v436 = v_u_10.taskTexts(v435.w, v435.h)
		local v437 = v_u_310.label
		local v438 = v436.label
		v437.Position = UDim2.fromOffset(v438.x, v438.y)
		v437.Size = UDim2.fromOffset(v438.w, v438.h)
		local v439 = v_u_310.sub
		local v440 = v436.sub
		v439.Position = UDim2.fromOffset(v440.x, v440.y)
		v439.Size = UDim2.fromOffset(v440.w, v440.h)
		v_u_310.sub.Visible = true
		v_u_310.sub.TextColor3 = v_u_8.accent
		v_u_310.btn.Visible = false
	end
	local function v_u_452() -- name: paintTask
		-- upvalues: (ref) v_u_310, (ref) v_u_323, (copy) p_u_3, (ref) v_u_311, (copy) v_u_8
		if v_u_310 == nil then
			return
		else
			v_u_323()
			local v441 = p_u_3.cache and (p_u_3.cache.tasks and p_u_3.cache.tasks.data) or nil
			if type(v441) == "table" then
				local v_u_442 = nil
				local function v443()
					-- upvalues: (ref) v_u_442, (ref) p_u_3
					v_u_442 = p_u_3.cctx.shared.Tasks
				end
				pcall(v443)
				local v444
				if p_u_3.firstOpenTask then
					v444 = p_u_3.firstOpenTask(nil)
				else
					v444 = nil
				end
				local v445
				if v444 and v_u_442 then
					v445 = v_u_442.get(v444) or nil
				else
					v445 = nil
				end
				v_u_311 = v444
				if v445 then
					local v446 = (v441.tasks and v441.tasks[v444] or {}).state or "available"
					local v447 = tostring(v446)
					local v448 = v_u_310.sub
					local v449
					if v447 == "ready" then
						v449 = v_u_8.success
					elseif v447 == "active" then
						v449 = v_u_8.accent
					else
						v449 = v_u_8.info
					end
					v448.TextColor3 = v449
					v_u_310.sub.Text = v447 == "ready" and "READY TO HAND IN" or (v447 == "active" and "CURRENT TASK" or "NEW TASK")
					local v450 = v_u_310.setText
					local v451 = v445.title
					v450((tostring(v451)))
				else
					v_u_310.sub.TextColor3 = v_u_8.muted
					v_u_310.sub.Text = "NO OPEN TASK"
					v_u_310.setText("Every job is done, for now")
				end
			else
				v_u_310.setText("Tasks")
				v_u_310.sub.Text = "TASKS"
				v_u_311 = nil
				return
			end
		end
	end
	local v_u_453 = v_u_6.label({
		["parent"] = nil,
		["name"] = "RaidWindow",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["fit"] = true,
		["parent"] = p_u_4,
		["textSize"] = v_u_15 and 13 or 15,
		["color"] = v_u_8.accent,
		["position"] = UDim2.fromOffset(v_u_26.clock.x, v_u_26.clock.y),
		["size"] = UDim2.fromOffset(v_u_26.clock.w, v_u_26.clock.h)
	})
	v_u_453.Visible = false
	local v_u_455 = v12(p_u_3, {
		["parent"] = nil,
		["name"] = "Deploy",
		["rect"] = nil,
		["text"] = "DEPLOY",
		["textSize"] = nil,
		["kind"] = "accent",
		["onClick"] = nil,
		["parent"] = p_u_4,
		["rect"] = v_u_26.deploy,
		["textSize"] = v_u_15 and 28 or 36,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_16, (copy) p_u_5, (copy) v_u_17
			for _, v454 in v_u_16 do
				if v454.id ~= "deploy" then
					continue
				end
				p_u_5.activate(v454)
				return
			end
			if v_u_17.deploy() ~= true then
				p_u_5.activate(p_u_5.categories.byId("deploy"))
			end
		end
	})
	local function v_u_466() -- name: paintDeploy
		-- upvalues: (copy) v_u_10, (copy) v_u_55, (copy) v_u_455, (copy) p_u_3
		if v_u_10.deployMode((v_u_55())) == "party" then
			local v_u_456 = false
			local function v457()
				-- upvalues: (ref) v_u_456, (ref) p_u_3
				v_u_456 = p_u_3.partyDeploying() == true
			end
			pcall(v457)
			local function v461()
				-- upvalues: (ref) p_u_3
				local v458 = p_u_3.myParty()
				local v459
				if type(v458) == "table" then
					local v460 = v458.members
					if type(v460) == "table" then
						v459 = #v458.members > 1
					else
						v459 = false
					end
				else
					v459 = false
				end
				return v459
			end
			local v462, v463 = pcall(v461)
			if v462 then
				v462 = v463 == true
			end
			if v462 then
				v462 = not p_u_3.isLeader()
			end
			local v464 = v_u_455.setEnabled
			local v465 = not v_u_456
			if v465 then
				v465 = not v462
			end
			v464(v465)
			v_u_455.setText(v_u_456 and "DEPLOYING" or (v462 and "LEADER DEPLOYS" or "DEPLOY"))
		else
			v_u_455.setEnabled(true)
			v_u_455.setText("DEPLOY")
		end
	end
	function v_u_17.deploy() -- name: deploy
		-- upvalues: (copy) v_u_10, (copy) v_u_55, (copy) v_u_6, (copy) p_u_3, (copy) p_u_5
		if v_u_10.deployMode((v_u_55())) ~= "party" then
			return false
		end
		local v_u_467 = false
		local function v470()
			-- upvalues: (ref) v_u_467
			local v468 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
			local v469
			if v468 == nil then
				v469 = false
			else
				v469 = v468:GetAttribute("DeployClosed") == true
			end
			v_u_467 = v469
		end
		pcall(v470)
		if v_u_467 then
			v_u_6.toast("Deployments are closed", "warn", "Check the banner for when they open again.")
			return true
		end
		local function v474()
			-- upvalues: (ref) p_u_3
			local v471 = p_u_3.myParty()
			local v472
			if type(v471) == "table" then
				local v473 = v471.members
				if type(v473) == "table" then
					v472 = #v471.members > 1
				else
					v472 = false
				end
			else
				v472 = false
			end
			return v472
		end
		local v475, v476 = pcall(v474)
		if v475 then
			v475 = v476 == true
		end
		if v475 and not p_u_3.isLeader() then
			v_u_6.toast("Only the squad leader deploys", "warn")
			return true
		end
		local function v477() -- name: go
			-- upvalues: (ref) p_u_3
			p_u_3.partyOp({
				["op"] = "deploy"
			})
		end
		local v478
		if p_u_5.has("MenuTutorialCard") then
			v478 = p_u_5.lib("MenuTutorialCard")
		else
			v478 = nil
		end
		if v478 ~= nil then
			local v479 = v478.gateDeploy
			if type(v479) == "function" then
				local v480 = v478.gateDeploy
				local v481 = p_u_3
				local v482, v483 = pcall(v480, v481, v477)
				if v482 and v483 == true then
					return true
				end
			end
		end
		p_u_3.partyOp({
			["op"] = "deploy"
		})
		return true
	end
	local v_u_484 = {}
	local function v_u_490(p485, p486, p487) -- name: setDot
		-- upvalues: (copy) v_u_36, (copy) v_u_484, (copy) v_u_6, (copy) v_u_8
		local v488 = v_u_36[p485]
		if v488 ~= nil then
			local v489 = v_u_484[p485]
			if v489 == nil then
				if not p486 then
					return
				end
				v489 = v_u_6.new("Frame", {
					["Name"] = "Dot",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["BackgroundColor3"] = v_u_8.accent,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -44, 0.5, 0),
					["Size"] = UDim2.fromOffset(8, 8)
				}, v488.btn)
				v_u_484[p485] = v489
			end
			if v489.Visible ~= p486 then
				v489.Visible = p486
			end
			if p487 ~= nil and v489.BackgroundColor3 ~= p487 then
				v489.BackgroundColor3 = p487
			end
		end
	end
	function v_u_17.badges() -- name: badges
		-- upvalues: (copy) v_u_36, (copy) v_u_490, (ref) v_u_2, (copy) v_u_8, (copy) v_u_9, (copy) p_u_3, (copy) p_u_5
		v_u_490("starter", true)
		local v491 = v_u_490
		local v492 = "store"
		local v493 = v_u_2
		local v494 = (tonumber(v493:GetAttribute("StoreFeatured")) or 0) > 0
		local v495
		if v_u_2:GetAttribute("StoreFeaturedSale") == true then
			v495 = v_u_8.danger
		else
			v495 = v_u_8.accent
		end
		v491(v492, v494, v495)
		local v496 = v_u_2:GetAttribute("MenuTasksBadge")
		local v497, v498
		if type(v496) == "string" then
			local v499, v500 = string.match(v496, "^(%d+)/(%d+)$")
			v497 = tonumber(v499) or 0
			v498 = tonumber(v500) or 0
		else
			v497 = 0
			v498 = 0
		end
		local v501 = v497 + v498
		local v502 = v_u_36.tasks
		if v502 then
			v502.setBadge(v501)
		end
		local v503 = v_u_2
		local v504 = tonumber(v503:GetAttribute("BmBadge")) or 0
		local v505 = math.floor(v504)
		local v506 = v_u_2
		local v507 = tonumber(v506:GetAttribute("TradeReqCount")) or 0
		local v508 = v505 + math.floor(v507)
		local v509 = v_u_36.market
		if v509 then
			v509.setBadge(v508)
		end
		local v510 = v_u_490
		local v511 = "market"
		local v512
		if v_u_2:GetAttribute("RsLive") == true then
			local v513 = v_u_2
			local v514 = tonumber(v513:GetAttribute("BmBadge")) or 0
			local v515 = math.floor(v514)
			local v516 = v_u_2
			local v517 = tonumber(v516:GetAttribute("TradeReqCount")) or 0
			v512 = v515 + math.floor(v517) == 0
		else
			v512 = false
		end
		v510(v511, v512)
		local v518 = v_u_2
		local v519 = tonumber(v518:GetAttribute("PassClaimable")) or 0
		local v520 = v_u_36.pass
		if v520 then
			v520.setBadge(v519)
		end
		local v521
		if v_u_9 and v_u_9.newOffersTotal then
			local v522 = v_u_9.newOffersTotal
			local v523, v524 = pcall(v522)
			v521 = v523 and (tonumber(v524) or 0) or 0
		else
			v521 = 0
		end
		local v525 = v_u_36.traders
		if v525 then
			v525.setBadge(v521)
		end
		local v526 = 0
		local v527 = p_u_3.profile
		if type(v527) == "table" then
			local v528 = v527.inv
			if type(v528) == "table" then
				local v529 = v527.inv.overflow
				v526 = tonumber(v529) or 0
			end
		end
		local v530 = v_u_36.character
		if v530 then
			v530.setBadge(v526)
		end
		local v531 = 0
		if type(v527) == "table" then
			local v532 = v527.crafts
			if type(v532) == "table" then
				local v533 = p_u_5.now()
				for _, v534 in v527.crafts do
					if type(v534) ~= "table" then
						continue
					end
					local v535 = v534.readyAt
					if type(v535) ~= "number" or v534.readyAt > v533 then
						continue
					end
					v531 = v531 + 1
				end
			end
		end
		local v536 = v_u_36.hideout
		if v536 then
			v536.setBadge(v531)
		end
	end
	function v_u_17.tick() -- name: tick
		-- upvalues: (ref) v_u_18, (copy) v_u_10, (copy) p_u_5, (copy) v_u_453, (copy) v_u_466, (copy) v_u_302, (copy) v_u_306, (copy) v_u_452, (copy) v_u_17
		if v_u_18 then
			local v537 = workspace:GetAttribute("WorldWindowEnd")
			local v538 = v_u_10.clockText(v537, p_u_5.now())
			v_u_453.Visible = v538 ~= nil
			if v538 ~= nil and v_u_453.Text ~= v538 then
				v_u_453.Text = v538
			end
			v_u_466()
			v_u_302()
			v_u_306(false)
			v_u_452()
			v_u_17.badges()
		end
	end
	function v_u_17.refresh(p539, p540) -- name: refresh
		-- upvalues: (ref) v_u_18, (ref) v_u_283, (ref) v_u_282, (ref) v_u_281, (copy) p_u_3, (copy) v_u_55, (copy) v_u_17, (copy) v_u_139, (copy) v_u_466, (copy) v_u_452
		if v_u_18 then
			if p539 == "result" and (type(p540) == "table" and p540.op == "worldSwitch") then
				local v541 = v_u_283
				v_u_283 = nil
				if v_u_282 ~= nil then
					local v542 = v_u_282.setEnabled
					if type(v542) == "function" then
						v_u_282.setEnabled(true)
					end
				end
				if v_u_281 ~= nil then
					local v543 = v_u_281.setEnabled
					if type(v543) == "function" then
						local v544 = v_u_281.setEnabled
						local function v545()
							-- upvalues: (ref) p_u_3
							return p_u_3.cctx.shared.GameMode.isPvpve()
						end
						local v546, v547 = pcall(v545)
						if v546 then
							v546 = v547 == true
						end
						if v546 then
							v546 = v_u_55()
						end
						local v548 = not v546
						if v548 then
							local function v552()
								-- upvalues: (ref) p_u_3
								local v549 = p_u_3.myParty()
								local v550
								if type(v549) == "table" then
									local v551 = v549.members
									if type(v551) == "table" then
										v550 = #v549.members > 1
									else
										v550 = false
									end
								else
									v550 = false
								end
								return v550
							end
							local v553
							v548, v553 = pcall(v552)
							if v548 then
								v548 = v553 == true
							end
							if v548 then
								local function v554()
									-- upvalues: (ref) p_u_3
									return p_u_3.isLeader() ~= false
								end
								local v555, v556 = pcall(v554)
								local v557 = not v555 or v556 == true
								v548 = not v557
							end
						end
						v544(not v548)
					end
				end
				if v_u_17.paintChips then
					v_u_17.paintChips()
				end
				if v541 ~= nil and (v541.kind == "pvp" and (p540.ok == false and p540.code == "unknown_op")) then
					v_u_139()
				end
			end
			if p539 == "profile" or (p539 == "party" or p539 == "tutorial") then
				v_u_17.paintChips()
				v_u_466()
				v_u_452()
			end
		end
	end
	function v_u_17.show() -- name: show
		-- upvalues: (ref) v_u_317, (ref) v_u_313, (copy) p_u_3, (ref) v_u_315, (copy) v_u_17, (copy) v_u_10, (copy) p_u_5, (copy) v_u_453, (copy) v_u_466, (copy) v_u_452, (copy) v_u_306, (ref) v_u_18
		v_u_317 = true
		local v558
		if v_u_313 == nil then
			v558 = false
		else
			v558 = p_u_3.tutorialCard == v_u_313
		end
		local v559 = v_u_315 and (v558 or v_u_317) and true or nil
		if p_u_3.tutorialCardOff ~= v559 then
			p_u_3.tutorialCardOff = v559
			if p_u_3.syncTutorial then
				p_u_3.syncTutorial()
			end
		end
		v_u_17.paintChips()
		local v560 = workspace:GetAttribute("WorldWindowEnd")
		local v561 = v_u_10.clockText(v560, p_u_5.now())
		v_u_453.Visible = v561 ~= nil
		if v561 ~= nil and v_u_453.Text ~= v561 then
			v_u_453.Text = v561
		end
		v_u_466()
		v_u_452()
		v_u_17.badges()
		v_u_306(true)
		if p_u_3.cache and p_u_3.cache.tasks == nil then
			task.spawn(function()
				-- upvalues: (ref) p_u_3, (ref) v_u_18, (ref) v_u_452, (ref) v_u_17
				local v562 = p_u_3.fetch
				pcall(v562, "tasks", nil, 20)
				if v_u_18 then
					v_u_452()
					v_u_17.badges()
				end
			end)
		end
		if p_u_3.syncTutorial then
			p_u_3.syncTutorial()
		end
	end
	function v_u_17.hide() -- name: hide
		-- upvalues: (ref) v_u_317, (ref) v_u_319, (ref) v_u_313, (copy) p_u_3, (ref) v_u_315
		v_u_317 = false
		if v_u_319 ~= nil then
			local v563 = v_u_319.setActive
			if type(v563) == "function" then
				local v564 = v_u_319.setActive
				pcall(v564, false)
			end
		end
		local v565
		if v_u_313 == nil then
			v565 = false
		else
			v565 = p_u_3.tutorialCard == v_u_313
		end
		local v566 = v_u_315 and (v565 or v_u_317) and true or nil
		if p_u_3.tutorialCardOff ~= v566 then
			p_u_3.tutorialCardOff = v566
			if p_u_3.syncTutorial then
				p_u_3.syncTutorial()
			end
		end
	end
	local v567 = p_u_3.changed
	table.insert(v_u_19, v567:Connect(function(p568, p569)
		-- upvalues: (copy) v_u_17
		v_u_17.refresh(p568, p569)
	end))
	v_u_17.paintChips()
	local v570 = workspace:GetAttribute("WorldWindowEnd")
	local v571 = v_u_10.clockText(v570, p_u_5.now())
	v_u_453.Visible = v571 ~= nil
	if v571 ~= nil and v_u_453.Text ~= v571 then
		v_u_453.Text = v571
	end
	v_u_466()
	v_u_302()
	v_u_452()
	v_u_17.badges()
	v_u_306(true)
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (ref) v_u_18, (copy) v_u_19, (copy) v_u_20, (ref) v_u_109, (ref) v_u_313, (copy) p_u_3, (ref) v_u_314, (ref) v_u_315, (ref) v_u_319, (ref) v_u_320, (ref) v_u_316
		if v_u_18 then
			v_u_18 = false
			for _, v_u_572 in v_u_19 do
				pcall(function()
					-- upvalues: (copy) v_u_572
					v_u_572:Disconnect()
				end)
			end
			table.clear(v_u_19)
			for _, v573 in v_u_20 do
				pcall(v573)
			end
			table.clear(v_u_20)
			if v_u_109 ~= nil then
				local v574 = v_u_109.destroy
				local v575 = v_u_109
				pcall(v574, v575)
				v_u_109 = nil
			end
			if v_u_313 ~= nil then
				local v_u_576 = v_u_313
				v_u_313 = nil
				pcall(function()
					-- upvalues: (copy) v_u_576
					v_u_576.destroy()
				end)
				if p_u_3.tutorialCard == v_u_576 then
					p_u_3.tutorialCard = nil
				end
			end
			if v_u_314 or v_u_315 then
				p_u_3.tutorialCardOff = nil
			end
			v_u_314 = false
			v_u_315 = false
			if v_u_319 ~= nil then
				local v577 = v_u_319
				v_u_319 = nil
				local v578 = v577.destroy
				pcall(v578)
			end
			if v_u_320 ~= nil then
				local function v579()
					-- upvalues: (ref) v_u_320
					v_u_320:Destroy()
				end
				pcall(v579)
				v_u_320 = nil
			end
			if v_u_316 ~= nil then
				local function v580()
					-- upvalues: (ref) v_u_316
					v_u_316:Destroy()
				end
				pcall(v580)
				v_u_316 = nil
			end
		end
	end
	return v_u_17
end
return v1