-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmRestock

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {}
local v_u_6 = v1.LocalPlayer
v_u_5.POLL = 20
v_u_5.POLL_FAST = 1
v_u_5.CONFIRM_SECONDS = 6
v_u_5.CONFIRM_GUARD = 0.4
v_u_5.LIGHT_GAP = 1.1
v_u_5.LONG_SECONDS = 86400
local v_u_7 = {
	["preview"] = true,
	["check"] = true,
	["history"] = true,
	["cont"] = true
}
function v_u_5.describe(p8, _) -- name: describe
	local v9 = {
		["state"] = "none",
		["line"] = "Reading the restock ...",
		["notes"] = nil,
		["buttons"] = nil,
		["notes"] = {},
		["buttons"] = {
			["edit"] = false,
			["cancel"] = false,
			["hold"] = false,
			["resume"] = false,
			["stop"] = false
		}
	}
	if type(p8) ~= "table" then
		return v9
	end
	local v10 = p8.line
	v9.line = type(v10) ~= "string" and "No restock planned. The market shows no timer." or string.gsub(p8.line, ", 1 items$", ", 1 item")
	local v11 = p8.plan
	if type(v11) ~= "table" then
		return v9
	end
	local v12 = v11.st
	local v13 = v11.ph
	if v12 == "p" then
		if v11.ho == true then
			v9.state = "held"
		elseif v13 == "soon" then
			v9.state = "planned"
		elseif v13 == "over" then
			v9.state = "over"
		else
			v9.state = "live"
		end
		v9.buttons.stop = v13 ~= "over"
		v9.buttons.edit = v13 == "soon"
		v9.buttons.cancel = v13 == "soon"
		local v14 = v9.buttons
		local v15
		if v11.ho == true then
			v15 = false
		else
			v15 = v13 ~= "over"
		end
		v14.hold = v15
		v9.buttons.resume = v11.ho == true
	elseif v12 == "e" or (v12 == "x" or v12 == "c") then
		v9.state = "ended"
	end
	local v16 = p8.drift
	if type(v16) == "table" then
		local v17 = v11.ix
		if type(v17) == "table" then
			for v18, v19 in p8.drift do
				local v20 = v11.ix[v18]
				if type(v19) ~= "table" or (v19.warn ~= true or type(v20) ~= "table") then
					continue
				end
				local v21 = v9.notes
				local v22 = {
					["text"] = nil,
					["kind"] = "warn"
				}
				local v23 = tostring(v18)
				local v24 = v20.id
				local v25 = tostring(v24)
				local v26 = v19.ratio
				v22.text = ("Row %s %s: price now %.1f x average (1.0 at planning). The planned price may no longer fit. Cancel before the start if it does not."):format(v23, v25, tonumber(v26) or 0)
				table.insert(v21, v22)
			end
		end
	end
	local v27 = p8.switch
	if type(v27) == "table" and p8.switch.rs == false then
		local v28 = v9.notes
		table.insert(v28, {
			["text"] = "Restock sales are OFF (switch in the SERVER tab). Nothing can be bought.",
			["kind"] = "warn"
		})
	end
	local v29 = p8.switch
	if type(v29) == "table" and p8.switch.freeze == true then
		local v30 = v9.notes
		table.insert(v30, {
			["text"] = "The market is frozen (switch in the SERVER tab).",
			["kind"] = "warn"
		})
	end
	local v31 = p8.finishing
	if type(v31) == "table" then
		for _, v32 in p8.finishing do
			if type(v32) ~= "table" or v32.state ~= "gaveup" then
				continue
			end
			local v33 = v9.notes
			table.insert(v33, {
				["text"] = "The report of an ended restock could not be written. Look at the history.",
				["kind"] = "warn"
			})
			return v9
		end
	end
	return v9
end
function v_u_5.techLines(p34) -- name: techLines
	local v35 = {}
	if type(p34) ~= "table" then
		return v35
	end
	local v36 = p34.counters
	if type(v36) == "table" then
		local v37 = "throttles %s  \194\183  settleGiveUp %s  \194\183  auditDropped %s  \194\183  rollbackBlocked %s  \194\183  commitFailAfterAck %s  \194\183  encodeMs %s  \194\183  cooldownRefusals %s"
		local v38 = v36.throttles
		local v39
		if type(v38) == "number" and (v38 == v38 and v38 ~= (1 / 0)) then
			v39 = v38 ~= (-1 / 0)
		else
			v39 = false
		end
		local v40 = not v39 and "n/a" or tostring(v38)
		local v41 = v36.settleGiveUp
		local v42
		if type(v41) == "number" and (v41 == v41 and v41 ~= (1 / 0)) then
			v42 = v41 ~= (-1 / 0)
		else
			v42 = false
		end
		local v43 = not v42 and "n/a" or tostring(v41)
		local v44 = v36.auditDropped
		local v45
		if type(v44) == "number" and (v44 == v44 and v44 ~= (1 / 0)) then
			v45 = v44 ~= (-1 / 0)
		else
			v45 = false
		end
		local v46 = not v45 and "n/a" or tostring(v44)
		local v47 = v36.rsRollbackBlocked
		local v48
		if type(v47) == "number" and (v47 == v47 and v47 ~= (1 / 0)) then
			v48 = v47 ~= (-1 / 0)
		else
			v48 = false
		end
		local v49 = not v48 and "n/a" or tostring(v47)
		local v50 = v36.commitFailAfterAck
		local v51
		if type(v50) == "number" and (v50 == v50 and v50 ~= (1 / 0)) then
			v51 = v50 ~= (-1 / 0)
		else
			v51 = false
		end
		local v52 = not v51 and "n/a" or tostring(v50)
		local v53 = v36.encodeMs
		local v54
		if type(v53) == "number" and (v53 == v53 and v53 ~= (1 / 0)) then
			v54 = v53 ~= (-1 / 0)
		else
			v54 = false
		end
		local v55 = not v54 and "n/a" or tostring(v53)
		local v56 = v36.cooldownRefusals
		local v57
		if type(v56) == "number" and (v56 == v56 and v56 ~= (1 / 0)) then
			v57 = v56 ~= (-1 / 0)
		else
			v57 = false
		end
		local v58 = not v57 and "n/a" or tostring(v56)
		table.insert(v35, v37:format(v40, v43, v46, v49, v52, v55, v58))
		local v59 = "bought %s  \194\183  units %s  \194\183  cash %s  \194\183  reclaims %s  \194\183  deadlines %s"
		local v60 = v36.bought
		local v61
		if type(v60) == "number" and (v60 == v60 and v60 ~= (1 / 0)) then
			v61 = v60 ~= (-1 / 0)
		else
			v61 = false
		end
		local v62 = not v61 and "n/a" or tostring(v60)
		local v63 = v36.units
		local v64
		if type(v63) == "number" and (v63 == v63 and v63 ~= (1 / 0)) then
			v64 = v63 ~= (-1 / 0)
		else
			v64 = false
		end
		local v65 = not v64 and "n/a" or tostring(v63)
		local v66 = v36.cash
		local v67
		if type(v66) == "number" and (v66 == v66 and v66 ~= (1 / 0)) then
			v67 = v66 ~= (-1 / 0)
		else
			v67 = false
		end
		local v68 = not v67 and "n/a" or tostring(v66)
		local v69 = v36.reclaims
		local v70
		if type(v69) == "number" and (v69 == v69 and v69 ~= (1 / 0)) then
			v70 = v69 ~= (-1 / 0)
		else
			v70 = false
		end
		local v71 = not v70 and "n/a" or tostring(v69)
		local v72 = v36.deadlines
		local v73
		if type(v72) == "number" and (v72 == v72 and v72 ~= (1 / 0)) then
			v73 = v72 ~= (-1 / 0)
		else
			v73 = false
		end
		local v74 = not v73 and "n/a" or tostring(v72)
		table.insert(v35, v59:format(v62, v65, v68, v71, v74))
	end
	local v75 = p34.fleet
	if type(v75) == "table" then
		local v76 = v75.coverage
		local v77
		if type(v76) == "number" and (v76 == v76 and v76 ~= (1 / 0)) then
			v77 = v76 ~= (-1 / 0)
		else
			v77 = false
		end
		local v78
		if v77 then
			local v79 = v75.coverage * 100 + 0.5
			v78 = ("%d percent"):format((math.floor(v79)))
		else
			v78 = "n/a"
		end
		local v80 = "fleet %s players  \194\183  proposal %s  \194\183  coverage %s  \194\183  pages %s"
		local v81 = v75.players
		local v82
		if type(v81) == "number" and (v81 == v81 and v81 ~= (1 / 0)) then
			v82 = v81 ~= (-1 / 0)
		else
			v82 = false
		end
		local v83 = not v82 and "n/a" or tostring(v81)
		local v84 = v75.suggestPe
		local v85
		if type(v84) == "number" and (v84 == v84 and v84 ~= (1 / 0)) then
			v85 = v84 ~= (-1 / 0)
		else
			v85 = false
		end
		local v86 = not v85 and "n/a" or tostring(v84)
		local v87 = v75.pages
		local v88
		if type(v87) == "number" and (v87 == v87 and v87 ~= (1 / 0)) then
			v88 = v87 ~= (-1 / 0)
		else
			v88 = false
		end
		local v89 = not v88 and "n/a" or tostring(v87)
		table.insert(v35, v80:format(v83, v86, v78, v89))
	end
	local v90 = "plan version %s  \194\183  generation %s  \194\183  last read %s s ago  \194\183  state %s  \194\183  messages sent %s (a count, the server keeps no send time)"
	local v91 = p34.ver
	local v92
	if type(v91) == "number" and (v91 == v91 and v91 ~= (1 / 0)) then
		v92 = v91 ~= (-1 / 0)
	else
		v92 = false
	end
	local v93 = not v92 and "n/a" or tostring(v91)
	local v94 = p34.gen
	local v95
	if type(v94) == "number" and (v94 == v94 and v94 ~= (1 / 0)) then
		v95 = v94 ~= (-1 / 0)
	else
		v95 = false
	end
	local v96 = not v95 and "n/a" or tostring(v94)
	local v97 = p34.age
	local v98
	if type(v97) == "number" and (v97 == v97 and v97 ~= (1 / 0)) then
		v98 = v97 ~= (-1 / 0)
	else
		v98 = false
	end
	local v99
	if v98 then
		local v100 = p34.age
		local v101 = math.floor(v100)
		v99 = tostring(v101)
	else
		v99 = "n/a"
	end
	local v102 = p34.planState or "n/a"
	local v103 = tostring(v102)
	local v104 = p34.sent
	local v105
	if type(v104) == "number" and (v104 == v104 and v104 ~= (1 / 0)) then
		v105 = v104 ~= (-1 / 0)
	else
		v105 = false
	end
	local v106 = not v105 and "n/a" or tostring(v104)
	table.insert(v35, v90:format(v93, v96, v99, v103, v106))
	return v35
end
function v_u_5.build(p_u_107) -- name: build
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2
	local v_u_108 = require(script.Parent:WaitForChild("FilmRestockForm"))
	local v_u_109 = v_u_108.kit(p_u_107)
	local v_u_110 = v_u_109.HushUI
	local _ = v_u_109.Theme
	local v_u_111 = v_u_109.C
	local v_u_112 = p_u_107.body
	local v_u_113 = p_u_107.api
	local v114 = p_u_107.inner
	local v_u_115 = true
	p_u_107.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_115
		v_u_115 = false
	end)
	local function v116()
		-- upvalues: (ref) v_u_4
		return require((v_u_4:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("BmRs", 5)))
	end
	local _, _ = pcall(v116)
	local v_u_117 = {}
	local v_u_118 = nil
	local v_u_119 = 0
	local v_u_120 = 0
	local v_u_121 = false
	local v_u_122 = 0
	local v_u_123 = false
	local v_u_124 = {}
	local v_u_125 = {}
	local v_u_126 = {}
	local v_u_127 = 0
	local v_u_128 = {}
	local v_u_129 = false
	local function v130() -- name: serverNow
		-- upvalues: (ref) v_u_120
		return os.time() + v_u_120
	end
	local function v_u_131(_) end
	local function v_u_140(p132) -- name: applyStatus
		-- upvalues: (ref) v_u_118, (ref) v_u_119, (ref) v_u_120, (ref) v_u_131, (copy) v_u_124, (ref) v_u_5, (ref) v_u_6, (ref) v_u_122
		if type(p132) == "table" then
			v_u_118 = p132
			v_u_119 = os.clock()
			local v133 = p132.now
			local v134
			if type(v133) == "number" and (v133 == v133 and v133 ~= (1 / 0)) then
				v134 = v133 ~= (-1 / 0)
			else
				v134 = false
			end
			if v134 then
				v_u_120 = p132.now - os.time()
			end
			v_u_131(p132)
			for _, v135 in v_u_124 do
				pcall(v135, p132)
			end
			local v136 = v_u_5.describe(v_u_118, nil)
			if v_u_6 then
				local v137 = v_u_6
				local v138 = v136.state
				local v139 = v_u_122 > 0
				v137:SetAttribute("FilmRestock", ("%s|%s"):format(v138, (tostring(v139))))
			end
		end
	end
	local function v_u_161(p_u_141, p142, p_u_143, p144) -- name: send
		-- upvalues: (ref) v_u_122, (ref) v_u_5, (ref) v_u_118, (ref) v_u_6, (ref) v_u_7, (copy) v_u_140, (copy) v_u_113
		local v145 = {}
		if type(p142) == "table" then
			for v146, v147 in p142 do
				v145[v146] = v147
			end
		end
		v145.cmd = p_u_141
		v_u_122 = v_u_122 + 1
		local v148 = v_u_5.describe(v_u_118, nil)
		if v_u_6 then
			local v149 = v_u_6
			local v150 = v148.state
			local v151 = v_u_122 > 0
			v149:SetAttribute("FilmRestock", ("%s|%s"):format(v150, (tostring(v151))))
		end
		local function v160(p152) -- name: done
			-- upvalues: (ref) v_u_122, (ref) v_u_7, (copy) p_u_141, (ref) v_u_140, (ref) v_u_5, (ref) v_u_118, (ref) v_u_6, (copy) p_u_143
			local v153 = v_u_122 - 1
			v_u_122 = math.max(0, v153)
			if type(p152) == "table" then
				local v154 = p152.data
				if type(v154) == "table" and not v_u_7[p_u_141] then
					local v155 = p152.data.line
					if type(v155) == "string" then
						v_u_140(p152.data)
					end
				end
			end
			local v156 = v_u_5.describe(v_u_118, nil)
			if v_u_6 then
				local v157 = v_u_6
				local v158 = v156.state
				local v159 = v_u_122 > 0
				v157:SetAttribute("FilmRestock", ("%s|%s"):format(v158, (tostring(v159))))
			end
			if p_u_143 then
				p_u_143(p152)
			end
		end
		if p144 == "write" then
			v_u_113.call("server.rs", v145, v160)
		else
			v_u_113.callQuiet("server.rs", v145, v160)
		end
	end
	local function v170(p162, p163, p164, p165) -- name: call
		-- upvalues: (copy) v_u_128, (ref) v_u_129, (ref) v_u_115, (ref) v_u_5, (ref) v_u_127, (copy) v_u_161
		if p165 == "light" then
			if p162 == "preview" then
				for v166 = #v_u_128, 1, -1 do
					if v_u_128[v166].cmd ~= "preview" then
						continue
					end
					table.remove(v_u_128, v166)
				end
			end
			local v167 = v_u_128
			table.insert(v167, {
				["cmd"] = p162,
				["args"] = p163,
				["cb"] = p164
			})
			if not v_u_129 then
				v_u_129 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_115, (ref) v_u_128, (ref) v_u_5, (ref) v_u_127, (ref) v_u_161, (ref) v_u_129
					while v_u_115 and #v_u_128 > 0 do
						local v168 = v_u_5.LIGHT_GAP - (os.clock() - v_u_127)
						if v168 > 0 then
							task.wait(v168)
						end
						local v169 = table.remove(v_u_128, 1)
						if not v169 then
							continue
						end
						v_u_127 = os.clock()
						v_u_161(v169.cmd, v169.args, v169.cb, "light")
					end
					v_u_129 = false
				end)
			end
		else
			v_u_161(p162, p163, p164, p165)
			return
		end
	end
	v_u_117.call = v170
	function v_u_117.refresh()
		-- upvalues: (copy) v_u_161, (ref) v_u_6, (copy) v_u_117
		local v_u_171 = false
		v_u_161("status", {
			["sample"] = true
		}, function(p172)
			-- upvalues: (copy) v_u_171, (ref) v_u_6, (ref) v_u_117
			if type(p172) == "table" and (p172.ok ~= true and v_u_171 ~= true) then
				local v173 = p172.msg or "The server did not answer."
				local v174 = tostring(v173) or ""
				if v_u_6 then
					v_u_6:SetAttribute("FilmRestockError", v174)
				end
				if v_u_117.errLbl then
					v_u_117.errLbl.Text = v174
					v_u_117.errLbl.Visible = v174 ~= ""
				end
			end
		end, "status")
	end
	v_u_109.section("Restock  \194\183  status")
	local v_u_175 = v_u_109.note("Reading the restock ...", v_u_111.text, "RsStatusLine")
	local v_u_176 = v_u_109.note("", v_u_111.accent, "RsStay")
	v_u_176.Visible = false
	local v_u_177 = v_u_110.new("Frame", {
		["Name"] = "RsNotes",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_112)
	v_u_177.LayoutOrder = v_u_109.nextOrder()
	v_u_110.layout(v_u_177, "v", 4)
	local v_u_178 = v_u_110.new("Frame", {
		["Name"] = "RsLong",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_112)
	v_u_178.LayoutOrder = v_u_109.nextOrder()
	v_u_110.layout(v_u_178, "v", 4)
	v_u_117.errLbl = v_u_109.note("", v_u_111.danger, "RsFrameError")
	v_u_117.errLbl.Visible = false
	local v_u_179 = v_u_109.row(nil, "RsButtons")
	local v180 = (v114 - 24) / 5
	local v_u_181 = math.floor(v180)
	local v_u_182 = {}
	local function v_u_190() -- name: paintButtons
		-- upvalues: (ref) v_u_5, (ref) v_u_118, (copy) v_u_182, (copy) v_u_126
		local v183 = v_u_5.describe(v_u_118, nil).buttons
		v_u_182.refresh.api.setEnabled(true)
		v_u_182.edit.api.setEnabled(v183.edit)
		v_u_182.hold.api.setText(v183.resume and "Resume" or "Hold")
		v_u_182.hold.api.setEnabled(v183.hold or v183.resume)
		local v184 = v_u_182.stop.api.setText
		local v185 = v_u_126.stop
		local v186
		if v185 == nil then
			v186 = false
		else
			v186 = os.clock() - v185 < v_u_5.CONFIRM_SECONDS
		end
		v184(v186 and "AGAIN: STOP" or "Stop")
		v_u_182.stop.api.setEnabled(v183.stop)
		local v187 = v_u_182.cancel.api.setText
		local v188 = v_u_126.cancel
		local v189
		if v188 == nil then
			v189 = false
		else
			v189 = os.clock() - v188 < v_u_5.CONFIRM_SECONDS
		end
		v187(v189 and "AGAIN: CANCEL" or "Cancel")
		v_u_182.cancel.api.setEnabled(v183.cancel)
	end
	local function v_u_198(p191, p192) -- name: twoPress
		-- upvalues: (copy) v_u_126, (ref) v_u_5, (copy) v_u_190, (ref) v_u_115
		local v193 = os.clock()
		local v194 = v_u_126[p191]
		local v195
		if v194 == nil then
			v195 = false
		else
			v195 = os.clock() - v194 < v_u_5.CONFIRM_SECONDS
		end
		if v195 and v193 - v_u_126[p191] >= v_u_5.CONFIRM_GUARD then
			v_u_126[p191] = nil
			p192()
			v_u_190()
		else
			local v196 = v_u_126[p191]
			local v197
			if v196 == nil then
				v197 = false
			else
				v197 = os.clock() - v196 < v_u_5.CONFIRM_SECONDS
			end
			if not v197 then
				v_u_126[p191] = v193
				task.delay(v_u_5.CONFIRM_SECONDS + 0.2, function()
					-- upvalues: (ref) v_u_115, (ref) v_u_190
					if v_u_115 then
						v_u_190()
					end
				end)
			end
			v_u_190()
		end
	end
	local function v_u_211(p199, p_u_200) -- name: brake
		-- upvalues: (ref) v_u_118, (ref) v_u_6, (copy) v_u_117, (copy) v_u_161, (copy) p_u_107
		local v201 = v_u_118
		local v202
		if type(v201) == "table" then
			v202 = v_u_118.plan
		else
			v202 = nil
		end
		local v203
		if type(v202) == "table" then
			v203 = v202.r
		else
			v203 = nil
		end
		if v203 == nil then
			if v_u_6 then
				v_u_6:SetAttribute("FilmRestockError", "No restock to change.")
			end
			if v_u_117.errLbl then
				v_u_117.errLbl.Text = "No restock to change."
				v_u_117.errLbl.Visible = true
			end
		else
			if v_u_6 then
				v_u_6:SetAttribute("FilmRestockError", "")
			end
			if v_u_117.errLbl then
				v_u_117.errLbl.Text = ""
				v_u_117.errLbl.Visible = false
			end
			v_u_161(p199, {
				["rid"] = v203
			}, function(p204)
				-- upvalues: (ref) p_u_107, (copy) p_u_200, (ref) v_u_6, (ref) v_u_117
				if type(p204) == "table" and p204.ok == true then
					if p_u_107.handle then
						local v205 = p_u_107.handle.status
						if type(v205) == "function" then
							local v206 = p_u_107.handle.status
							local v207 = p204.msg or p_u_200
							local v208 = tostring(v207)
							pcall(v206, v208)
							return
						end
					end
				else
					local v209 = p204 and p204.msg or "The server did not answer."
					local v210 = tostring(v209) or ""
					if v_u_6 then
						v_u_6:SetAttribute("FilmRestockError", v210)
					end
					if v_u_117.errLbl then
						v_u_117.errLbl.Text = v210
						v_u_117.errLbl.Visible = v210 ~= ""
					end
				end
			end, "write")
		end
	end
	local function v219(p212, p213, p214, p215) -- name: addBtn
		-- upvalues: (copy) v_u_109, (copy) v_u_179, (copy) v_u_181, (copy) v_u_125, (copy) v_u_182
		local v216, v217 = v_u_109.btn(v_u_179, p213, p214, v_u_181, p215)
		v216.Name = "Rs_" .. p212
		v216.LayoutOrder = #v_u_125 + 1
		local v218 = v_u_125
		table.insert(v218, v217)
		v_u_182[p212] = {
			["button"] = v216,
			["api"] = v217,
			["click"] = p215
		}
	end
	v219("refresh", "Refresh", "ghost", function()
		-- upvalues: (ref) v_u_6, (copy) v_u_117, (copy) v_u_161
		if v_u_6 then
			v_u_6:SetAttribute("FilmRestockError", "")
		end
		if v_u_117.errLbl then
			v_u_117.errLbl.Text = ""
			v_u_117.errLbl.Visible = false
		end
		local v_u_220 = false
		v_u_161("status", {
			["sample"] = true
		}, function(p221)
			-- upvalues: (copy) v_u_220, (ref) v_u_6, (ref) v_u_117
			if type(p221) == "table" and (p221.ok ~= true and v_u_220 ~= true) then
				local v222 = p221.msg or "The server did not answer."
				local v223 = tostring(v222) or ""
				if v_u_6 then
					v_u_6:SetAttribute("FilmRestockError", v223)
				end
				if v_u_117.errLbl then
					v_u_117.errLbl.Text = v223
					v_u_117.errLbl.Visible = v223 ~= ""
				end
			end
		end, "status")
	end)
	v219("hold", "Hold", "secondary", function()
		-- upvalues: (ref) v_u_5, (ref) v_u_118, (copy) v_u_211
		if v_u_5.describe(v_u_118, nil).buttons.resume then
			v_u_211("resume", "The restock resumes in 30 seconds.")
		else
			v_u_211("hold", "The restock is paused.")
		end
	end)
	v219("stop", "Stop", "danger", function()
		-- upvalues: (copy) v_u_198, (copy) v_u_211
		v_u_198("stop", function()
			-- upvalues: (ref) v_u_211
			v_u_211("stop", "The restock was stopped.")
		end)
	end)
	v219("cancel", "Cancel", "danger", function()
		-- upvalues: (copy) v_u_198, (copy) v_u_211
		v_u_198("cancel", function()
			-- upvalues: (ref) v_u_211
			v_u_211("cancel", "The restock was cancelled.")
		end)
	end)
	v219("edit", "Edit", "secondary", function()
		-- upvalues: (ref) v_u_118, (copy) v_u_117, (ref) v_u_6, (copy) p_u_107
		local v224 = v_u_118
		local v225
		if type(v224) == "table" then
			v225 = v_u_118.plan
		else
			v225 = nil
		end
		if type(v225) == "table" and (v225.st == "p" and (v225.ph == "soon" and v_u_117.formApi)) then
			v_u_117.formApi.edit(v225)
			if v_u_6 then
				v_u_6:SetAttribute("FilmRestockError", "")
			end
			if v_u_117.errLbl then
				v_u_117.errLbl.Text = ""
				v_u_117.errLbl.Visible = false
			end
			if p_u_107.handle then
				local v226 = p_u_107.handle.status
				if type(v226) == "function" then
					local v227 = p_u_107.handle.status
					pcall(v227, "The plan is in the form. Saving makes a new plan and cancels this one.")
				end
			end
		end
	end)
	local v_u_228 = v_u_110.label({
		["parent"] = nil,
		["name"] = "RsTech",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_112,
		["color"] = v_u_111.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_228.LayoutOrder = v_u_109.nextOrder()
	v_u_228.RichText = false
	local v229 = v_u_110.new("Frame", {
		["Name"] = "RsLiveHost",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_112)
	v229.LayoutOrder = v_u_109.nextOrder()
	v_u_110.layout(v229, "v", 8)
	local v230 = v_u_110.new("Frame", {
		["Name"] = "RsFormHost",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_112)
	v230.LayoutOrder = v_u_109.nextOrder()
	v_u_110.layout(v230, "v", 8)
	local v236 = (function() -- name: liveModule
		local v231 = script.Parent:FindFirstChild("FilmRestockLive")
		if v231 and v231:IsA("ModuleScript") then
			local v232 = require
			local v233, v234 = pcall(v232, v231)
			if v233 and type(v234) == "table" then
				local v235 = v234.build
				if type(v235) == "function" then
					return v234
				end
			end
			warn("[FilmRestock] FilmRestockLive failed:", v234)
		end
		return nil
	end)()
	if v236 then
		local v237 = v236.build
		local v241 = {
			["body"] = v229,
			["api"] = v_u_113,
			["handle"] = p_u_107.handle,
			["inner"] = v114,
			["syncers"] = p_u_107.syncers,
			["gui"] = p_u_107.gui,
			["call"] = v170,
			["onStatus"] = function(p238) -- name: onStatus
				-- upvalues: (copy) v_u_124
				local v239 = v_u_124
				table.insert(v239, p238)
			end,
			["status"] = function() -- name: status
				-- upvalues: (ref) v_u_118
				return v_u_118
			end,
			["now"] = v130,
			["refresh"] = v_u_117.refresh,
			["setFast"] = function(p240) -- name: setFast
				-- upvalues: (ref) v_u_121
				v_u_121 = p240 == true
			end,
			["kit"] = v_u_109,
			["form"] = function() -- name: form
				-- upvalues: (copy) v_u_117
				return v_u_117.formApi
			end
		}
		local v242, v243 = pcall(v237, v241)
		if v242 then
			v_u_117.liveApi = v243
		else
			warn("[FilmRestock] live window failed:", v243)
		end
	end
	local v244 = v_u_108.build
	local v250 = {
		["body"] = v230,
		["call"] = v170,
		["inner"] = v114,
		["gui"] = p_u_107.gui,
		["handle"] = p_u_107.handle,
		["status"] = function() -- name: status
			-- upvalues: (ref) v_u_118
			return v_u_118
		end,
		["now"] = v130,
		["setFast"] = function(p245) -- name: setFast
			-- upvalues: (ref) v_u_121
			v_u_121 = p245 == true
		end,
		["onSaved"] = function() -- name: onSaved
			-- upvalues: (copy) v_u_161, (ref) v_u_6, (copy) v_u_117
			local v_u_246 = true
			v_u_161("status", {
				["sample"] = false
			}, function(p247)
				-- upvalues: (copy) v_u_246, (ref) v_u_6, (ref) v_u_117
				if type(p247) == "table" and (p247.ok ~= true and v_u_246 ~= true) then
					local v248 = p247.msg or "The server did not answer."
					local v249 = tostring(v248) or ""
					if v_u_6 then
						v_u_6:SetAttribute("FilmRestockError", v249)
					end
					if v_u_117.errLbl then
						v_u_117.errLbl.Text = v249
						v_u_117.errLbl.Visible = v249 ~= ""
					end
				end
			end, "status")
		end
	}
	local v251, v_u_252 = pcall(v244, v250)
	if v251 then
		v_u_117.formApi = v_u_252
		table.insert(v_u_124, function(p253)
			-- upvalues: (copy) v_u_252
			v_u_252.onStatus(p253)
		end)
	else
		warn("[FilmRestock] form failed:", v_u_252)
		v_u_109.note("The plan form could not be built: " .. tostring(v_u_252), v_u_111.danger)
	end
	local function v_u_279() -- name: paint
		-- upvalues: (ref) v_u_5, (ref) v_u_118, (copy) v_u_175, (copy) v_u_111, (copy) v_u_176, (copy) v_u_108, (copy) v_u_177, (copy) v_u_110, (copy) v_u_228, (copy) v_u_190, (ref) v_u_123, (copy) v_u_178, (copy) v_u_109, (copy) v_u_198, (copy) v_u_211
		local v254 = v_u_5.describe(v_u_118, nil)
		v_u_175.Text = v254.line
		local v255 = v_u_175
		local v256
		if v254.state == "live" then
			v256 = v_u_111.success
		elseif v254.state == "held" then
			v256 = v_u_111.accent
		elseif v254.state == "none" or v254.state == "ended" then
			v256 = v_u_111.text2
		else
			v256 = v_u_111.text
		end
		v255.TextColor3 = v256
		local v257 = v_u_118
		local v258
		if type(v257) == "table" then
			local v259 = v_u_118.jobs
			if type(v259) == "table" then
				v258 = v_u_118.jobs.save
			else
				v258 = nil
			end
		else
			v258 = nil
		end
		if type(v258) == "table" then
			local v260 = v_u_176
			local v261 = v_u_108.etaText
			local v262 = v_u_118
			local v263
			if type(v262) == "table" then
				v263 = v_u_118.now
			else
				v263 = nil
			end
			v260.Text = v261(v258, v263)
			v_u_176.Visible = true
		else
			v_u_176.Visible = false
		end
		for _, v264 in v_u_177:GetChildren() do
			if not v264:IsA("GuiObject") then
				continue
			end
			v264:Destroy()
		end
		for v265, v266 in v254.notes do
			local v267 = v_u_110.label
			local v268 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v_u_177,
				["name"] = "Note" .. v265,
				["text"] = v266.text
			}
			local v269
			if v266.kind == "warn" then
				v269 = v_u_111.accent
			else
				v269 = v_u_111.text2
			end
			v268.color = v269
			v268.size = UDim2.new(1, 0, 0, 0)
			local v270 = v267(v268)
			v270.RichText = false
			v270.LayoutOrder = v265
		end
		v_u_228.Text = table.concat(v_u_5.techLines(v_u_118), "\n")
		v_u_190()
		local v271 = v_u_118
		local v272
		if type(v271) == "table" then
			v272 = v_u_118.plan
		else
			v272 = nil
		end
		local v273
		if type(v272) == "table" and (v272.st == "p" and v272.ph == "live") then
			local v274 = v272.t0
			if type(v274) == "number" and (v274 == v274 and v274 ~= (1 / 0)) then
				v273 = v274 ~= (-1 / 0)
			else
				v273 = false
			end
			if v273 then
				local v275 = v272.t1
				if type(v275) == "number" and (v275 == v275 and v275 ~= (1 / 0)) then
					v273 = v275 ~= (-1 / 0)
				else
					v273 = false
				end
				if v273 then
					v273 = v272.t1 - v272.t0 > v_u_5.LONG_SECONDS
				end
			end
		else
			v273 = false
		end
		if v273 and not v_u_123 then
			v_u_123 = true
			for _, v276 in v_u_178:GetChildren() do
				if not v276:IsA("GuiObject") then
					continue
				end
				v276:Destroy()
			end
			local v277 = v_u_110.label({
				["parent"] = nil,
				["name"] = "LongText",
				["text"] = "A restock is still running. It lasts more than 24 hours. Stop it here if it should end now.",
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v_u_178,
				["color"] = v_u_111.accent,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v277.LayoutOrder = 1
			v277.RichText = false
			local v278 = v_u_109.btn(v_u_178, "Stop the restock", "danger", 200, function()
				-- upvalues: (ref) v_u_198, (ref) v_u_211
				v_u_198("stop", function()
					-- upvalues: (ref) v_u_211
					v_u_211("stop", "The restock was stopped.")
				end)
			end)
			v278.Name = "Rs_LongStop"
			v278.LayoutOrder = 2
			v_u_178.Visible = true
		elseif not v273 then
			v_u_178.Visible = false
		end
	end
	v_u_131 = function(_)
		-- upvalues: (copy) v_u_279
		v_u_279()
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_115, (copy) p_u_107, (copy) v_u_112, (ref) v_u_121, (ref) v_u_5, (copy) v_u_161, (ref) v_u_6, (copy) v_u_117, (copy) v_u_126, (copy) v_u_190
		local v280 = false
		local v281 = 0
		while true do
			while true do
				if not v_u_115 then
					return
				end
				local v282 = p_u_107.gui.Enabled
				if v282 then
					v282 = v_u_112.Visible
				end
				if v282 and (not v280 and p_u_107.handle) then
					local v283 = p_u_107.handle.status
					if type(v283) == "function" then
						local v284 = p_u_107.handle.status
						pcall(v284, "Restock.")
					end
				end
				if v282 then
					break
				end
				task.wait(v_u_121 and 0.25 or 0.5)
				v280 = v282
			end
			local v285
			if v_u_121 then
				v285 = v_u_5.POLL_FAST
			else
				v285 = v_u_5.POLL
			end
			if not v280 or v285 <= os.clock() - v281 then
				v281 = os.clock()
				local v_u_286 = true
				v_u_161("status", {
					["sample"] = not v_u_121 ~= false
				}, function(p287)
					-- upvalues: (copy) v_u_286, (ref) v_u_6, (ref) v_u_117
					if type(p287) == "table" and (p287.ok ~= true and v_u_286 ~= true) then
						local v288 = p287.msg or "The server did not answer."
						local v289 = tostring(v288) or ""
						if v_u_6 then
							v_u_6:SetAttribute("FilmRestockError", v289)
						end
						if v_u_117.errLbl then
							v_u_117.errLbl.Text = v289
							v_u_117.errLbl.Visible = v289 ~= ""
						end
					end
				end, "status")
			end
			local v290 = v_u_126.stop
			local v291
			if v290 == nil then
				v291 = false
			else
				v291 = os.clock() - v290 < v_u_5.CONFIRM_SECONDS
			end
			if v291 then
				break
			end
			local v292 = v_u_126.cancel
			local v293
			if v292 == nil then
				v293 = false
			else
				v293 = os.clock() - v292 < v_u_5.CONFIRM_SECONDS
			end
			if v293 then
				v_u_190()
				::l2::
				task.wait(v_u_121 and 0.25 or 0.5)
				v280 = v282
			else
				task.wait(v_u_121 and 0.25 or 0.5)
				v280 = v282
			end
		end
		v_u_190()
		goto l2
	end)
	v_u_279()
	function v_u_117.data() -- name: data
		-- upvalues: (ref) v_u_118
		return v_u_118
	end
	function v_u_117.form() -- name: form
		-- upvalues: (copy) v_u_117
		return v_u_117.formApi
	end
	function v_u_117.live() -- name: live
		-- upvalues: (copy) v_u_117
		return v_u_117.liveApi
	end
	function v_u_117.describe() -- name: describe
		-- upvalues: (ref) v_u_5, (ref) v_u_118
		return v_u_5.describe(v_u_118, nil)
	end
	function v_u_117.press(p294) -- name: press
		-- upvalues: (copy) v_u_182
		local v295 = v_u_182[p294 == "resume" and "hold" or p294]
		if v295 then
			v295.click()
		end
	end
	function v_u_117.state() -- name: state
		-- upvalues: (ref) v_u_5, (ref) v_u_118, (ref) v_u_122, (ref) v_u_121, (copy) v_u_128, (copy) v_u_117
		local v296 = v_u_5.describe(v_u_118, nil)
		local v297 = {
			["state"] = v296.state,
			["line"] = v296.line,
			["busy"] = v_u_122,
			["fast"] = v_u_121,
			["queued"] = #v_u_128,
			["notes"] = #v296.notes,
			["error"] = not v_u_117.errLbl and "" or v_u_117.errLbl.Text
		}
		local v298
		if v_u_117.formApi then
			v298 = v_u_117.formApi.formState()
		else
			v298 = nil
		end
		v297.form = v298
		v297.live = v_u_117.liveApi ~= nil
		return v297
	end
	if v_u_3:IsStudio() and v_u_6 then
		v_u_6:GetAttributeChangedSignal("FilmRestockCmd"):Connect(function()
			-- upvalues: (ref) v_u_6, (copy) v_u_117, (copy) v_u_161, (ref) v_u_2, (copy) v_u_108, (ref) v_u_120, (copy) v_u_211, (ref) v_u_118
			local v299 = v_u_6:GetAttribute("FilmRestockCmd")
			if type(v299) == "string" and v299 ~= "" then
				v_u_6:SetAttribute("FilmRestockCmd", nil)
				local v300, v_u_301 = string.match(v299, "^(%a+)%s*(.*)$")
				local v_u_302 = v_u_117.formApi
				if v300 == "refresh" then
					local v_u_303 = false
					v_u_161("status", {
						["sample"] = true
					}, function(p304)
						-- upvalues: (copy) v_u_303, (ref) v_u_6, (ref) v_u_117
						if type(p304) == "table" and (p304.ok ~= true and v_u_303 ~= true) then
							local v305 = p304.msg or "The server did not answer."
							local v306 = tostring(v305) or ""
							if v_u_6 then
								v_u_6:SetAttribute("FilmRestockError", v306)
							end
							if v_u_117.errLbl then
								v_u_117.errLbl.Text = v306
								v_u_117.errLbl.Visible = v306 ~= ""
							end
						end
					end, "status")
					local v_u_307 = {
						["ok"] = true
					}
					local function v308()
						-- upvalues: (ref) v_u_2, (copy) v_u_307
						return v_u_2:JSONEncode(v_u_307)
					end
					local v309, v310 = pcall(v308)
					local v311 = v_u_6
					local v312 = "FilmRestockResult"
					if not v309 then
						v310 = tostring(v_u_307)
					end
					v311:SetAttribute(v312, v310)
					return
				elseif v300 == "state" then
					local v_u_313 = v_u_117.state()
					local function v314()
						-- upvalues: (ref) v_u_2, (copy) v_u_313
						return v_u_2:JSONEncode(v_u_313)
					end
					local v315, v316 = pcall(v314)
					local v317 = v_u_6
					local v318 = "FilmRestockResult"
					if not v315 then
						v316 = tostring(v_u_313)
					end
					v317:SetAttribute(v318, v316)
					return
				elseif v300 == "fill" and v_u_302 then
					local function v319()
						-- upvalues: (ref) v_u_2, (copy) v_u_301
						return v_u_2:JSONDecode(v_u_301)
					end
					local v320, v321 = pcall(v319)
					if v320 and type(v321) == "table" then
						local v322 = v_u_302.getState()
						for v323, v324 in v321 do
							if v323 == "rows" and type(v324) == "table" then
								v322.rows = {}
								for _, v325 in v324 do
									local v326 = v_u_108.newRow()
									for v327, v329 in v325 do
										if v327 == "typed" and type(v329) == "table" then
											v326.typed = v329
										else
											if type(v329) == "number" and (v327 ~= "w" and v327 ~= "stack") then
												local v329 = tostring(v329)
											end
											v326[v327] = v329
										end
									end
									local v330 = v322.rows
									table.insert(v330, v326)
								end
							else
								local v331 = v322[v323]
								if type(v331) == "string" and type(v324) == "number" then
									v322[v323] = tostring(v324)
								else
									v322[v323] = v324
								end
							end
						end
						v_u_302.setState(v322)
						local v_u_332 = {
							["ok"] = true,
							["rows"] = nil,
							["rows"] = #v322.rows
						}
						local function v333()
							-- upvalues: (ref) v_u_2, (copy) v_u_332
							return v_u_2:JSONEncode(v_u_332)
						end
						local v334, v335 = pcall(v333)
						local v336 = v_u_6
						local v337 = "FilmRestockResult"
						if not v334 then
							v335 = tostring(v_u_332)
						end
						v336:SetAttribute(v337, v335)
					else
						local v_u_338 = {
							["ok"] = false,
							["why"] = "bad json"
						}
						local function v339()
							-- upvalues: (ref) v_u_2, (copy) v_u_338
							return v_u_2:JSONEncode(v_u_338)
						end
						local v340, v341 = pcall(v339)
						local v342 = v_u_6
						local v343 = "FilmRestockResult"
						if not v340 then
							v341 = tostring(v_u_338)
						end
						v342:SetAttribute(v343, v341)
					end
				elseif v300 == "quick" and v_u_302 then
					local v344 = tonumber(v_u_301) or 600
					local v345 = v_u_302.getState()
					v345.startText = v_u_108.formatTime(os.time() + v_u_120 + v344, v345.zone)
					v_u_302.setState(v345)
					local v_u_346 = {
						["ok"] = true,
						["start"] = nil,
						["start"] = v345.startText
					}
					local function v347()
						-- upvalues: (ref) v_u_2, (copy) v_u_346
						return v_u_2:JSONEncode(v_u_346)
					end
					local v348, v349 = pcall(v347)
					local v350 = v_u_6
					local v351 = "FilmRestockResult"
					if not v348 then
						v349 = tostring(v_u_346)
					end
					v350:SetAttribute(v351, v349)
					return
				elseif v300 == "preview" and v_u_302 then
					v_u_302.preview()
					local v_u_352 = {
						["ok"] = true
					}
					local function v353()
						-- upvalues: (ref) v_u_2, (copy) v_u_352
						return v_u_2:JSONEncode(v_u_352)
					end
					local v354, v355 = pcall(v353)
					local v356 = v_u_6
					local v357 = "FilmRestockResult"
					if not v354 then
						v355 = tostring(v_u_352)
					end
					v356:SetAttribute(v357, v355)
					return
				elseif v300 == "save" and v_u_302 then
					v_u_302.savePress()
					task.delay(v_u_108.CONFIRM_GUARD + 0.1, function()
						-- upvalues: (copy) v_u_302, (ref) v_u_2, (ref) v_u_6
						v_u_302.savePress()
						local v_u_358 = v_u_302.formState()
						local function v359()
							-- upvalues: (ref) v_u_2, (copy) v_u_358
							return v_u_2:JSONEncode(v_u_358)
						end
						local v360, v361 = pcall(v359)
						local v362 = v_u_6
						local v363 = "FilmRestockResult"
						if not v360 then
							v361 = tostring(v_u_358)
						end
						v362:SetAttribute(v363, v361)
					end)
					return
				elseif v300 == "stop" then
					v_u_211("stop", "")
					local v_u_364 = {
						["ok"] = true
					}
					local function v365()
						-- upvalues: (ref) v_u_2, (copy) v_u_364
						return v_u_2:JSONEncode(v_u_364)
					end
					local v366, v367 = pcall(v365)
					local v368 = v_u_6
					local v369 = "FilmRestockResult"
					if not v366 then
						v367 = tostring(v_u_364)
					end
					v368:SetAttribute(v369, v367)
					return
				elseif v300 == "hold" or (v300 == "resume" or v300 == "cancel") then
					v_u_211(v300, "")
					local v_u_370 = {
						["ok"] = true
					}
					local function v371()
						-- upvalues: (ref) v_u_2, (copy) v_u_370
						return v_u_2:JSONEncode(v_u_370)
					end
					local v372, v373 = pcall(v371)
					local v374 = v_u_6
					local v375 = "FilmRestockResult"
					if not v372 then
						v373 = tostring(v_u_370)
					end
					v374:SetAttribute(v375, v373)
					return
				elseif v300 == "edit" and v_u_302 then
					local v376 = v_u_118
					local v377
					if type(v376) == "table" then
						v377 = v_u_118.plan
					else
						v377 = nil
					end
					v_u_302.edit(v377)
					local v_u_378 = {
						["ok"] = true
					}
					local function v379()
						-- upvalues: (ref) v_u_2, (copy) v_u_378
						return v_u_2:JSONEncode(v_u_378)
					end
					local v380, v381 = pcall(v379)
					local v382 = v_u_6
					local v383 = "FilmRestockResult"
					if not v380 then
						v381 = tostring(v_u_378)
					end
					v382:SetAttribute(v383, v381)
					return
				elseif v300 == "discard" and v_u_302 then
					v_u_302.discard()
					local v_u_384 = {
						["ok"] = true
					}
					local function v385()
						-- upvalues: (ref) v_u_2, (copy) v_u_384
						return v_u_2:JSONEncode(v_u_384)
					end
					local v386, v387 = pcall(v385)
					local v388 = v_u_6
					local v389 = "FilmRestockResult"
					if not v386 then
						v387 = tostring(v_u_384)
					end
					v388:SetAttribute(v389, v387)
					return
				elseif v300 == "raw" then
					local function v390()
						-- upvalues: (ref) v_u_2, (copy) v_u_301
						return v_u_2:JSONDecode(v_u_301)
					end
					local v391, v392 = pcall(v390)
					if v391 and type(v392) == "table" then
						local v393 = v392.cmd
						if type(v393) == "string" then
							local v394 = v392.cmd
							v392.cmd = nil
							v_u_161(v394, v392, function(p_u_395)
								-- upvalues: (ref) v_u_2, (ref) v_u_6
								local function v396()
									-- upvalues: (ref) v_u_2, (copy) p_u_395
									return v_u_2:JSONEncode(p_u_395)
								end
								local v397, v398 = pcall(v396)
								local v399 = v_u_6
								local v400 = "FilmRestockResult"
								if not v397 then
									v398 = tostring(p_u_395)
								end
								v399:SetAttribute(v400, v398)
							end, "write")
							return
						end
					end
					local v_u_401 = {
						["ok"] = false,
						["why"] = "bad json"
					}
					local function v402()
						-- upvalues: (ref) v_u_2, (copy) v_u_401
						return v_u_2:JSONEncode(v_u_401)
					end
					local v403, v404 = pcall(v402)
					local v405 = v_u_6
					local v406 = "FilmRestockResult"
					if not v403 then
						v404 = tostring(v_u_401)
					end
					v405:SetAttribute(v406, v404)
				else
					local v_u_407 = {
						["ok"] = false,
						["why"] = "unknown"
					}
					local function v408()
						-- upvalues: (ref) v_u_2, (copy) v_u_407
						return v_u_2:JSONEncode(v_u_407)
					end
					local v409, v410 = pcall(v408)
					local v411 = v_u_6
					local v412 = "FilmRestockResult"
					if not v409 then
						v410 = tostring(v_u_407)
					end
					v411:SetAttribute(v412, v410)
				end
			else
				return
			end
		end)
	end
	if p_u_107.handle then
		p_u_107.handle.restock = v_u_117
	end
	local v_u_413 = true
	v_u_161("status", {
		["sample"] = true
	}, function(p414)
		-- upvalues: (copy) v_u_413, (ref) v_u_6, (copy) v_u_117
		if type(p414) == "table" and (p414.ok ~= true and v_u_413 ~= true) then
			local v415 = p414.msg or "The server did not answer."
			local v416 = tostring(v415) or ""
			if v_u_6 then
				v_u_6:SetAttribute("FilmRestockError", v416)
			end
			if v_u_117.errLbl then
				v_u_117.errLbl.Text = v416
				v_u_117.errLbl.Visible = v416 ~= ""
			end
		end
	end, "status")
	return v_u_117
end
return v_u_5