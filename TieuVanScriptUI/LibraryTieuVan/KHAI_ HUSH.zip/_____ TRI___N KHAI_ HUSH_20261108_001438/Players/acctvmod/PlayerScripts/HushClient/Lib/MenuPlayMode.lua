-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayMode

local v_u_127 = {
	["GAP"] = 8,
	["TITLE_SIZE"] = 16,
	["TITLE_LINE"] = 20,
	["BODY_SIZE"] = 13,
	["BODY_LINE"] = 17,
	["NOTE_SIZE"] = 12,
	["NOTE_LINE"] = 16,
	["CHECK"] = 16,
	["MIN_CARD_H"] = 64,
	["lines"] = function(p1, p2, p3) -- name: lines
		local v4 = (utf8.len(p1) or #p1) * p2 * 0.6
		local v5 = p3 * 0.92
		local v6 = v4 / math.max(40, v5)
		local v7 = math.ceil(v6)
		return math.max(1, v7)
	end,
	["layout"] = function(p8, p9) -- name: layout
		-- upvalues: (copy) v_u_127
		local v10 = p9.inset or 16
		local v11 = p9.touch or 44
		local v12 = v_u_127.GAP
		local v13 = (p8 - v12) / 2
		local v14 = math.floor(v13)
		local v15 = v14 - v10 * 2
		local v16 = p9.body or {}
		local v17 = p9.title or {}
		local v18 = v_u_127.lines(v16.classic or "", v_u_127.BODY_SIZE, v15)
		local v19 = v_u_127.lines(v16.fptp or "", v_u_127.BODY_SIZE, v15)
		local v20 = math.max(v18, v19)
		local v21 = v15 - v_u_127.CHECK - 6
		local v22 = v_u_127.lines(v17.classic or "", v_u_127.TITLE_SIZE, v21)
		local v23 = v_u_127.lines
		local v24 = v17.fptp or ""
		local v25 = v_u_127.TITLE_SIZE
		local v26 = math.max(v22, v23(v24, v25, v21))
		local v27 = v26 * v_u_127.TITLE_LINE
		local v28 = v_u_127.MIN_CARD_H
		local v29 = 8 + v27 + 4 + v20 * v_u_127.BODY_LINE + 10
		local v30 = math.max(v28, v11, v29)
		local v31 = p8 - v14 - v12
		local v32 = {
			["w"] = p8,
			["gap"] = v12,
			["cardW"] = v14,
			["cardH"] = v30,
			["rowH"] = v30,
			["titleLines"] = v26,
			["bodyLines"] = v20,
			["lines"] = {
				["classic"] = v18,
				["fptp"] = v19
			},
			["cards"] = {
				["classic"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v14,
					["h"] = v30
				},
				["fptp"] = {
					["x"] = nil,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["x"] = v14 + v12,
					["w"] = v31,
					["h"] = v30
				}
			},
			["parts"] = {
				["title"] = {
					["x"] = nil,
					["y"] = 8,
					["w"] = nil,
					["h"] = nil,
					["x"] = v10,
					["w"] = v21,
					["h"] = v27
				},
				["check"] = {
					["x"] = v10 + v15 - v_u_127.CHECK,
					["y"] = 8 + (v_u_127.TITLE_LINE - v_u_127.CHECK) // 2,
					["w"] = v_u_127.CHECK,
					["h"] = v_u_127.CHECK
				},
				["body"] = {
					["x"] = v10,
					["y"] = 8 + v27 + 4,
					["w"] = v15,
					["h"] = v20 * v_u_127.BODY_LINE
				}
			}
		}
		local v33 = v_u_127.lines(p9.note or "", v_u_127.NOTE_SIZE, p8 - v10 * 2)
		v32.lines.note = v33
		v32.noteH = v33 * v_u_127.NOTE_LINE
		v32.note = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v10,
			["w"] = p8 - v10 * 2,
			["h"] = v32.noteH
		}
		return v32
	end,
	["build"] = function(p34, p35, p_u_36) -- name: build
		-- upvalues: (copy) v_u_127
		local v_u_37 = p34.ui
		local v_u_38 = p34.theme
		local v_u_39 = v_u_38.color
		local v40 = p34.kit
		local v_u_41 = p34.cctx.lib.PlayBriefModel
		if type(v_u_41) == "table" then
			local v42 = v_u_41.modeCards
			if type(v42) == "function" and v40 ~= nil then
				local v43 = v40.section
				if type(v43) == "function" then
					local v_u_44 = v_u_38.space.m
					local v45 = p_u_36.order or 60
					local v_u_46 = {
						["cards"] = {}
					}
					local v_u_47 = {}
					local v_u_48 = p_u_36.width or 440
					local v_u_49 = nil
					local v_u_50 = v40.section(p35, v_u_41.T.sheetMode, v45)
					v_u_50.Name = "ModeSection"
					v_u_37.pad(v_u_50, {
						v_u_44 - 12,
						v_u_44,
						0,
						0
					})
					v_u_46.header = v_u_50
					local v_u_51 = v_u_37.new("Frame", {
						["Name"] = "ModeRow",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_127.MIN_CARD_H),
						["LayoutOrder"] = v45 + 1
					}, p35)
					v_u_37.layout(v_u_51, "h", v_u_127.GAP)
					v_u_46.row = v_u_51
					local function v72(p_u_52, p53) -- name: mkCard
						-- upvalues: (copy) v_u_37, (copy) v_u_39, (ref) v_u_127, (copy) v_u_51, (copy) v_u_44, (copy) v_u_47, (copy) v_u_38, (copy) v_u_46, (ref) v_u_49
						local v54 = v_u_37.new("TextButton", {
							["Name"] = nil,
							["Text"] = "",
							["AutoButtonColor"] = false,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.1,
							["BorderSizePixel"] = 0,
							["LayoutOrder"] = nil,
							["Size"] = nil,
							["Selectable"] = true,
							["ClipsDescendants"] = true,
							["Name"] = p_u_52,
							["BackgroundColor3"] = v_u_39.raised,
							["LayoutOrder"] = p53,
							["Size"] = UDim2.new(0.5, -v_u_127.GAP / 2, 1, 0)
						}, v_u_51)
						v54.SelectionImageObject = v_u_37.selectionImage()
						local v55 = v_u_37.stroke(v54, v_u_39.line)
						local v56 = v_u_37.new("Frame", {
							["Name"] = "Top",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["BackgroundTransparency"] = 1,
							["ZIndex"] = 2,
							["Active"] = false,
							["BackgroundColor3"] = v_u_39.accent,
							["Size"] = UDim2.new(1, 0, 0, 2)
						}, v54)
						local v_u_57 = v_u_37.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = "",
							["style"] = "h3",
							["textSize"] = nil,
							["wrap"] = true,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["zindex"] = 3,
							["parent"] = v54,
							["textSize"] = v_u_127.TITLE_SIZE,
							["position"] = UDim2.fromOffset(v_u_44, 8),
							["size"] = UDim2.fromOffset(100, v_u_127.TITLE_LINE)
						})
						v_u_57.TextYAlignment = Enum.TextYAlignment.Top
						local v_u_58 = v_u_37.label({
							["parent"] = nil,
							["name"] = "Body",
							["text"] = "",
							["style"] = "small",
							["textSize"] = nil,
							["color"] = nil,
							["wrap"] = true,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["zindex"] = 3,
							["parent"] = v54,
							["textSize"] = v_u_127.BODY_SIZE,
							["color"] = v_u_39.text2,
							["position"] = UDim2.fromOffset(v_u_44, 34),
							["size"] = UDim2.fromOffset(100, 34)
						})
						v_u_58.TextYAlignment = Enum.TextYAlignment.Top
						local v59 = v_u_37.icon("check", {
							["parent"] = nil,
							["name"] = "Check",
							["size"] = nil,
							["thickness"] = 2,
							["color"] = nil,
							["zindex"] = 3,
							["parent"] = v54,
							["size"] = v_u_127.CHECK,
							["color"] = v_u_39.accent
						})
						v59.Visible = false
						local v_u_60 = {
							["id"] = nil,
							["btn"] = nil,
							["stroke"] = nil,
							["top"] = nil,
							["title"] = nil,
							["body"] = nil,
							["check"] = nil,
							["hover"] = false,
							["locked"] = false,
							["selected"] = false,
							["id"] = p_u_52,
							["btn"] = v54,
							["stroke"] = v55,
							["top"] = v56,
							["title"] = v_u_57,
							["body"] = v_u_58,
							["check"] = v59
						}
						local v61 = v_u_47
						local v62 = v54.MouseEnter
						local function v63()
							-- upvalues: (copy) v_u_60, (ref) v_u_37, (ref) v_u_38, (ref) v_u_46
							v_u_60.hover = true
							v_u_37.sound(v_u_38.sounds.hover)
							v_u_46.repaint()
						end
						table.insert(v61, v62:Connect(v63))
						local v64 = v_u_47
						local v65 = v54.MouseLeave
						local function v66()
							-- upvalues: (copy) v_u_60, (ref) v_u_46
							v_u_60.hover = false
							v_u_46.repaint()
						end
						table.insert(v64, v65:Connect(v66))
						local v67 = v_u_47
						local v68 = v54.Activated
						local function v69()
							-- upvalues: (ref) v_u_46, (copy) p_u_52
							v_u_46.press(p_u_52)
						end
						table.insert(v67, v68:Connect(v69))
						v_u_37.tooltip(v54, function()
							-- upvalues: (copy) v_u_57, (copy) v_u_60, (ref) v_u_49, (copy) v_u_58
							local v70 = {
								["title"] = string.upper(v_u_57.Text)
							}
							local v71
							if v_u_60.locked and (v_u_49 and v_u_49.why) then
								v71 = v_u_49.why
							else
								v71 = v_u_58.Text
							end
							v70.body = v71
							return v70
						end)
						return v_u_60
					end
					v_u_46.cards.classic = v72("classic", 1)
					v_u_46.cards.fptp = v72("fptp", 2)
					local v_u_73 = v_u_37.label({
						["parent"] = nil,
						["name"] = "ModeNote",
						["text"] = "",
						["style"] = "small",
						["textSize"] = nil,
						["color"] = nil,
						["wrap"] = true,
						["size"] = nil,
						["track"] = false,
						["parent"] = p35,
						["textSize"] = v_u_127.NOTE_SIZE,
						["color"] = v_u_39.text2,
						["size"] = UDim2.new(1, 0, 0, v_u_127.NOTE_LINE)
					})
					v_u_73.LayoutOrder = v45 + 2
					local v74 = Instance.new("UIPadding")
					local v75 = UDim.new(0, v_u_44)
					local v76 = UDim.new(0, v_u_44)
					v74.PaddingLeft = v75
					v74.PaddingRight = v76
					v74.Parent = v_u_73
					v_u_46.note = v_u_73
					local function v_u_92(p77) -- name: applyLayout
						-- upvalues: (ref) v_u_48, (ref) v_u_49, (ref) v_u_127, (copy) v_u_44, (copy) v_u_38, (copy) v_u_51, (copy) v_u_73, (copy) v_u_46
						v_u_48 = p77
						local v78 = v_u_49
						local v79 = v_u_127.layout
						local v80 = {
							["inset"] = v_u_44,
							["touch"] = v_u_38.touch(44),
							["title"] = {
								["classic"] = v78 and (v78.cards[1].title or "") or "",
								["fptp"] = v78 and (v78.cards[2].title or "") or ""
							},
							["body"] = {
								["classic"] = v78 and (v78.cards[1].body or "") or "",
								["fptp"] = v78 and (v78.cards[2].body or "") or ""
							},
							["note"] = v78 and v78.note or ""
						}
						local v81 = v79(p77, v80)
						v_u_51.Size = UDim2.new(0, v81.w, 0, v81.rowH)
						v_u_73.Size = UDim2.new(1, 0, 0, v81.noteH)
						for _, v82 in v_u_46.cards do
							local v83 = v81.parts
							local v84 = v82.title
							local v85 = v82.title
							local v86 = UDim2.fromOffset(v83.title.x, v83.title.y)
							local v87 = UDim2.fromOffset(v83.title.w, v83.title.h)
							v84.Position = v86
							v85.Size = v87
							local v88 = v82.body
							local v89 = v82.body
							local v90 = UDim2.fromOffset(v83.body.x, v83.body.y)
							local v91 = UDim2.fromOffset(v83.body.w, v83.body.h)
							v88.Position = v90
							v89.Size = v91
							v82.check.Position = UDim2.fromOffset(v83.check.x, v83.check.y)
						end
						v_u_46.last = v81
					end
					function v_u_46.shown() -- name: shown
						-- upvalues: (ref) v_u_49
						local v93
						if v_u_49 == nil then
							v93 = false
						else
							v93 = v_u_49.show == true
						end
						return v93
					end
					local function v_u_111() -- name: paintLast
						-- upvalues: (ref) v_u_49, (copy) v_u_50, (copy) v_u_51, (copy) v_u_73, (copy) v_u_46, (copy) v_u_37, (copy) v_u_39
						if v_u_49 ~= nil then
							local v94 = v_u_49.show == true
							local v95 = v_u_51
							local v96 = v_u_73
							v_u_50.Visible = v94
							v95.Visible = v94
							v96.Visible = v94
							for _, v97 in v_u_49.cards do
								local v98 = v_u_46.cards[v97.id]
								v_u_37.setText(v98.title, v97.title)
								v_u_37.setText(v98.body, v97.body)
								v98.selected = v97.selected
								v98.locked = v_u_49.locked == true
								local v99 = v97.selected
								local v100 = v_u_49.locked == true
								v98.check.Visible = v99
								if v100 then
									local v101 = v98.stroke
									local v102
									if v99 then
										v102 = v_u_39.accentDim
									else
										v102 = v_u_39.line
									end
									v101.Color = v102
									v98.top.BackgroundTransparency = 1
									v98.btn.BackgroundColor3 = v_u_39.raised
									local v103 = v98.title
									local v104
									if v99 then
										v104 = v_u_39.text
									else
										v104 = v_u_39.muted
									end
									v103.TextColor3 = v104
									v98.body.TextColor3 = v_u_39.muted
									v_u_37.setIconColor(v98.check, v_u_39.accentDim)
								else
									local v105 = v98.stroke
									local v106
									if v99 then
										v106 = v_u_39.accent
									elseif v98.hover then
										v106 = v_u_39.lineStrong
									else
										v106 = v_u_39.line
									end
									v105.Color = v106
									v98.top.BackgroundTransparency = v99 and 0 or 1
									local v107 = v98.btn
									local v108
									if v99 then
										v108 = v_u_39.accentDeep
									else
										v108 = v_u_39.raised
									end
									v107.BackgroundColor3 = v108
									local v109 = v98.title
									local v110
									if v99 then
										v110 = v_u_39.accent
									else
										v110 = v_u_39.text
									end
									v109.TextColor3 = v110
									v98.body.TextColor3 = v_u_39.text2
									v_u_37.setIconColor(v98.check, v_u_39.accent)
								end
								v98.btn:SetAttribute("Selected", v99)
								v98.btn:SetAttribute("Locked", v100)
							end
							v_u_73.Text = v_u_49.note
							v_u_51:SetAttribute("Mode", v_u_49.mode)
						end
					end
					function v_u_46.repaint() -- name: repaint
						-- upvalues: (copy) v_u_111
						v_u_111()
					end
					function v_u_46.press(p112) -- name: press
						-- upvalues: (copy) v_u_46, (copy) v_u_37, (copy) v_u_38, (copy) p_u_36
						local v113 = v_u_46.cards[p112]
						if v113 ~= nil and (not v113.selected or v113.locked) then
							if v113.locked then
								v_u_37.sound(v_u_38.sounds.error)
							end
							local v114 = p_u_36.choose
							if type(v114) == "function" then
								p_u_36.choose(p112)
							end
						end
					end
					function v_u_46.paint(p115) -- name: paint
						-- upvalues: (copy) p_u_36, (copy) v_u_41, (ref) v_u_49, (copy) v_u_92, (ref) v_u_48, (copy) v_u_111
						if not p115 then
							local v116 = p_u_36.state
							if type(v116) == "function" then
								local v117 = p_u_36.state
								local v118
								v118, p115 = pcall(v117)
								if not v118 or type(p115) ~= "table" then
									p115 = nil
								end
							else
								p115 = nil
							end
						end
						if p115 ~= nil then
							local v119 = v_u_41.modeCards(p115, p115.words)
							local v120 = (v_u_49 == nil or (v_u_49.cards[1].body ~= v119.cards[1].body or v_u_49.cards[2].body ~= v119.cards[2].body)) and true or v_u_49.note ~= v119.note
							v_u_49 = v119
							if v120 then
								v_u_92(v_u_48)
							end
						end
						v_u_111()
					end
					function v_u_46.relayout(p121) -- name: relayout
						-- upvalues: (copy) v_u_92
						v_u_92(p121)
					end
					function v_u_46.focus(p122) -- name: focus
						-- upvalues: (copy) v_u_46, (copy) v_u_51
						local v123 = p122 == "fptp" and "fptp" or "classic"
						local v124 = v_u_46.cards[v123]
						if v124 and (v124.btn.Visible and v_u_51.Visible) then
							return v124.btn
						else
							return nil
						end
					end
					function v_u_46.destroy() -- name: destroy
						-- upvalues: (copy) v_u_47, (copy) v_u_50, (copy) v_u_51, (copy) v_u_73
						for _, v_u_125 in v_u_47 do
							pcall(function()
								-- upvalues: (copy) v_u_125
								v_u_125:Disconnect()
							end)
						end
						table.clear(v_u_47)
						local function v126()
							-- upvalues: (ref) v_u_50, (ref) v_u_51, (ref) v_u_73
							v_u_50:Destroy()
							v_u_51:Destroy()
							v_u_73:Destroy()
						end
						pcall(v126)
					end
					v_u_46.paint()
					if v_u_49 == nil then
						v_u_50.Visible = false
						v_u_51.Visible = false
						v_u_73.Visible = false
					end
					v_u_92(v_u_48)
					return v_u_46
				end
			end
		end
		return nil
	end
}
return v_u_127