-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMail

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v5 = script.Parent:FindFirstChild("MailRows")
local v_u_6
if v5 and v5:IsA("ModuleScript") then
	local v7 = require
	local v8
	v8, v_u_6 = pcall(v7, v5)
	if not v8 or type(v_u_6) ~= "table" then
		v_u_6 = nil
	end
else
	v_u_6 = nil
end
local v9 = script.Parent:FindFirstChild("MailDeliveries")
local v_u_10
if v9 and v9:IsA("ModuleScript") then
	local v11 = require
	local v12
	v12, v_u_10 = pcall(v11, v9)
	if not v12 or type(v_u_10) ~= "table" then
		v_u_10 = nil
	end
else
	v_u_10 = nil
end
local v_u_13 = nil
function v_u_4.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_13
	local v14
	if v_u_13 == nil then
		v14 = false
	else
		v14 = v_u_13.alive == true
	end
	return v14
end
function v_u_4.close() -- name: close
	-- upvalues: (ref) v_u_13
	local v15 = v_u_13
	if v15 and (v15.alive and v15.api) then
		v15.api.close()
	end
end
function v_u_4.headAfter(p16, p17, p18, p19, p20) -- name: headAfter
	-- upvalues: (copy) v_u_6
	if p17.ok == false then
		return (p18 == nil or p18 == "all") and {
			["text"] = nil,
			["kind"] = "danger",
			["untilAt"] = nil,
			["text"] = p19 or "That did not work",
			["untilAt"] = p20 + 8
		} or p16
	else
		return p19 and string.find(p19, "full", 1, true) and {
			["text"] = nil,
			["kind"] = "warn",
			["untilAt"] = nil,
			["text"] = p19,
			["untilAt"] = p20 + 8
		} or (v_u_6 and v_u_6.isPartial(p17) and {
			["text"] = nil,
			["kind"] = "warn",
			["untilAt"] = nil,
			["text"] = p19 or v_u_6.partialText(p17.data.moved, p17.data.left),
			["untilAt"] = p20 + 8
		} or nil)
	end
end
function v_u_4.headShown(p21, p22, p23) -- name: headShown
	if p21 == nil or p21.untilAt < p22 then
		return nil
	elseif p21.kind == "danger" and p23 == 0 then
		return nil
	else
		return p21
	end
end
local function v_u_29(p24) -- name: modalButtons
	local v25 = p24.api.frame:FindFirstChild("Buttons", true)
	local v26 = nil
	local v27 = nil
	if v25 then
		for _, v28 in v25:GetChildren() do
			if not v28:IsA("GuiButton") then
				continue
			end
			if v28.LayoutOrder == 1 then
				v26 = v28
			else
				if v28.LayoutOrder ~= 2 then
					continue
				end
				v27 = v28
			end
		end
	end
	return v26, v27
end
local function v_u_40(p30) -- name: linkPad
	-- upvalues: (copy) v_u_29
	if p30.alive and p30.api then
		local v31, v32 = v_u_29(p30)
		local v33 = nil
		if p30.list and (p30.list.Visible and p30.list.AbsoluteCanvasSize.Y > p30.list.AbsoluteWindowSize.Y + 2) then
			local v34 = -1
			for _, v35 in p30.rows do
				local v36 = v35.btn
				if not v36 or (not v36.Parent or (not v36.Selectable or (not v35.frame.Visible or v34 >= v35.frame.LayoutOrder))) then
					continue
				end
				v34 = v35.frame.LayoutOrder
				v33 = v36
			end
		end
		local v37 = v31 ~= nil and v31.Visible
		if v37 then
			v37 = v31.Selectable
		end
		local v38
		if v37 then
			v38 = v31
		elseif v32 and v32.Selectable then
			v38 = v32
		else
			v38 = nil
		end
		if v33 == nil then
			v37 = false
		elseif v37 then
			if v32 == nil then
				v37 = false
			else
				v37 = v32.Selectable
			end
		end
		if p30.padLast ~= v33 or (p30.padDown ~= v38 or (p30.padA ~= v31 or (p30.padB ~= v32 or p30.padBoth ~= v37))) then
			if p30.padLast and (p30.padLast ~= v33 and p30.padLast.Parent) then
				p30.padLast.NextSelectionDown = nil
			end
			p30.padLast = v33
			p30.padDown = v38
			p30.padA = v31
			p30.padB = v32
			p30.padBoth = v37
			if v33 then
				v33.NextSelectionDown = v38
			end
			if v31 then
				v31.NextSelectionUp = v33
				local v39
				if v37 then
					v39 = v32
				else
					v39 = nil
				end
				v31.NextSelectionRight = v39
			end
			if v32 then
				v32.NextSelectionUp = v33
				if not v37 then
					v31 = nil
				end
				v32.NextSelectionLeft = v31
			end
		end
	else
		return
	end
end
v_u_4._linkPad = v_u_40
local function v_u_47(p41, p42) -- name: ruleText
	-- upvalues: (copy) v_u_6
	if not v_u_6 or (not p41 or (not p41.cargo or p41.cargo.expired)) then
		local v43
		if v_u_6 and (p41 and p42 ~= true) then
			v43 = v_u_6.ruleLine(p41.showDeliveries, p41.bmDays)
		else
			v43 = nil
		end
		return not v43 and "An insured item comes back if you died and nobody carried it out." or "An insured item comes back if you died and nobody carried it out." .. "\n" .. v43
	end
	local v44 = "An insured item comes back if you died and nobody carried it out."
	local v45 = "\n"
	local v46
	if p42 == true then
		v46 = v_u_6.TEXT.cargoHeldShort
	else
		v46 = v_u_6.TEXT.cargoHeld
	end
	return v44 .. v45 .. v46
end
local function v_u_84() -- name: paintTexts
	-- upvalues: (ref) v_u_13, (copy) v_u_47, (copy) v_u_10, (copy) v_u_4, (copy) v_u_6, (copy) v_u_29, (copy) v_u_40
	local v48 = v_u_13
	if v48 and v48.alive then
		local v49 = v48.C
		local v50 = v48.Rail.mailLive()
		if v50 then
			local v51 = v48.ruleLbl
			if v51 and v48.view ~= "letters" then
				local v52 = v_u_47(v50, v48.Theme.isPhone())
				if v51.Text ~= v52 then
					v51.Text = v52
				end
			end
			if v50.expired > 0 and v48.view ~= "letters" then
				v48.sawExpired = true
			end
			local v53 = os.clock()
			for _, v54 in v50.rows do
				local v55 = v48.rows[v54.e.id]
				if not v55 then
					continue
				end
				local v56 = v48.notes[v54.e.id]
				if v56 and v56.untilAt < v53 then
					v48.notes[v54.e.id] = nil
					v56 = nil
				end
				local v57, v58
				if v54.ready then
					v57 = true
					v58 = "Ready"
				else
					v58 = "Returning in " .. v_u_13.Rail.waitText(v54.left)
					v57 = false
				end
				local v59
				if v56 then
					v59 = v49.danger
				elseif v57 then
					v59 = v49.success
				else
					v59 = v49.text
				end
				if v56 then
					v58 = v56.text
				end
				if v55.status.Text ~= v58 then
					v55.status.Text = v58
				end
				v55.status.TextColor3 = v59
				local v60 = v55.dot
				local v61
				if v56 then
					v61 = v49.danger
				elseif v57 then
					v61 = v49.success
				else
					v61 = v49.muted
				end
				v60.BackgroundColor3 = v61
				local v62 = v55.stroke
				local v63
				if v56 then
					v63 = v49.danger
				else
					v63 = v49.line
				end
				v62.Color = v63
				local v64 = v48.busy ~= nil
				local v65
				if v57 then
					v65 = v48.busy == v54.e.id and "Claiming" or "Claim"
				else
					v65 = v48.Rail.waitText(v54.left)
				end
				if v55.btnText ~= v65 then
					v55.btnText = v65
					v55.api.setText(v65)
				end
				local v66 = v57 and "primary" or "secondary"
				if v55.kind ~= v66 then
					v55.kind = v66
					v55.api.setKind(v66)
					local v67 = v55.lbl
					local v68
					if v57 then
						v68 = v49.ink
					else
						v68 = v49.text2
					end
					v67.TextColor3 = v68
				end
				if v57 then
					v57 = not v64
				end
				if v55.enabled == v57 then
					continue
				end
				v55.enabled = v57
				v55.api.setEnabled(v57)
			end
			local v69 = #v50.deliveries
			local v70 = 0
			for _, v71 in v50.deliveries do
				if v71.expired then
					continue
				end
				v70 = v70 + 1
			end
			if v_u_10 then
				v_u_10.paint(v48, v50, v53)
			end
			local v72 = v_u_4.headShown(v48.headNote, v53, v50.count + v69)
			local v73
			if v72 then
				v73 = v72.text
			elseif v_u_6 then
				v73 = v_u_6.summary(v50.ready, v50.pending, v50.count, v70)
			else
				v73 = v50.count == 0 and "" or ("%d READY  \194\183  %d ON THE WAY"):format(v50.ready, v50.pending)
			end
			if v48.summary.Text ~= v73 then
				v48.summary.Text = v73
			end
			local v74 = v48.summary
			local v75
			if v72 then
				if v72.kind == "warn" then
					v75 = v49.accent
				else
					v75 = v49.danger
				end
			else
				v75 = v49.text2
			end
			v74.TextColor3 = v75
			local v76 = UDim2.new(v72 and 1 or 0.7, 0, 1, 0)
			if v48.summary.Size ~= v76 then
				v48.summary.Size = v76
			end
			v48.cap.Visible = v72 == nil
			local v77 = ("MAILBOX %d / %d"):format(v50.count, v50.capacity)
			local v78
			if v_u_6 then
				v77, v78 = v_u_6.capText(v50.count, v50.capacity, v50.bm, v50.bmMax, v70)
			else
				v78 = false
			end
			if v48.cap.Text ~= v77 then
				v48.cap.Text = v77
			end
			if v48.capFull ~= v78 then
				v48.capFull = v78
				local v79 = v48.cap
				local v80
				if v78 then
					v80 = v49.accent
				else
					v80 = v49.text2
				end
				v79.TextColor3 = v80
			end
			local v81 = v_u_29(v48)
			if v81 then
				local v82
				if v_u_6 then
					v82 = v_u_6.allVisible(v50.ready, v70)
				else
					v82 = v50.ready >= 2
				end
				if v82 then
					v82 = v48.view ~= "letters"
				end
				v81.Visible = v82
				local v83
				if v_u_6 then
					v83 = v_u_6.allLabel(v50.ready, v70)
				else
					v83 = ("Claim all (%d)"):format(v50.ready)
				end
				if v48.allText ~= v83 then
					v48.allText = v83
					if v81 then
						v81 = v81:FindFirstChild("Text", true)
					end
					if v81 and v81:IsA("TextLabel") then
						v81.Text = v_u_13.Theme.track(string.upper(v83), 1)
					end
				end
			end
			v_u_40(v48)
		end
	else
		return
	end
end
local function v_u_118(p_u_85, p86, p87) -- name: buildRow
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v88 = p_u_85.UI
	local v89 = p_u_85.Theme
	local v90 = p_u_85.C
	local v91 = p_u_85.Kit
	local _ = p_u_85.Rail
	local v92 = p86.e
	local v93 = v88.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Mail_" .. v92.id,
		["BackgroundColor3"] = v90.raised,
		["Size"] = UDim2.new(1, -8, 0, 80),
		["LayoutOrder"] = p87
	}, p_u_85.list)
	local v94 = v88.stroke(v93, v90.line)
	local v95 = v88.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v90.accent,
		["Size"] = UDim2.new(0, 3, 1, 0),
		["Visible"] = p86.ready
	}, v93)
	local v96 = v92.item
	local v97
	if type(v96) == "table" then
		v97 = v92.item.mods
	else
		v97 = nil
	end
	local v98 = v91.itemCell
	local v99 = v92.itemId or v92.item.id
	v98(v93, tostring(v99), {
		["size"] = 64,
		["w"] = 1.25,
		["h"] = 1,
		["wish"] = false,
		["mods"] = nil,
		["mods"] = v97
	}).Position = UDim2.fromOffset(14, 8)
	local v100 = v88.label
	local v101 = {
		["parent"] = nil,
		["name"] = "Name",
		["text"] = nil,
		["style"] = "bodyStrong",
		["textSize"] = 16,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v93
	}
	local v102 = v92.name or v91.itemName(v92.itemId)
	v101.text = tostring(v102)
	v101.position = UDim2.fromOffset(108, 8)
	v101.size = UDim2.new(1, -276, 0, 22)
	v100(v101).TextTruncate = Enum.TextTruncate.AtEnd
	local v103 = string.upper
	local v104 = v92.note or "Insurance return"
	local v105 = v103((tostring(v104)))
	local v106 = v92.mapName
	if type(v106) == "string" and v92.mapName ~= "" then
		v105 = v105 .. "  \194\183  " .. string.upper(v92.mapName)
	end
	v88.label({
		["parent"] = nil,
		["name"] = "Meta",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v93,
		["text"] = v105,
		["color"] = v90.text2,
		["position"] = UDim2.fromOffset(108, 31),
		["size"] = UDim2.new(1, -276, 0, 18)
	})
	local v107 = v88.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = v90.muted,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromOffset(108, 61),
		["Size"] = UDim2.fromOffset(6, 6)
	}, v93)
	local v108 = v88.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v93,
		["color"] = v90.text2,
		["position"] = UDim2.fromOffset(122, 52),
		["size"] = UDim2.new(1, -290, 0, 18)
	})
	local v_u_109 = v92.id
	local v110, v111 = v88.button({
		["parent"] = nil,
		["name"] = "Claim",
		["text"] = "Claim",
		["kind"] = "primary",
		["width"] = 144,
		["maxTextWidth"] = 108,
		["height"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v93,
		["height"] = v89.touch(40),
		["position"] = UDim2.new(1, -14, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_4, (copy) v_u_109
			v_u_4._press(v_u_109)
		end
	})
	local v_u_112 = v111.label
	local v113 = v111._visuals
	local v114
	if type(v113) == "table" then
		v114 = table.find(v113, v_u_112)
	else
		v114 = nil
	end
	if v114 then
		table.remove(v113, v114)
	end
	local v_u_115 = {
		["frame"] = nil,
		["edge"] = nil,
		["stroke"] = nil,
		["dot"] = nil,
		["status"] = nil,
		["btn"] = nil,
		["api"] = nil,
		["lbl"] = nil,
		["btnText"] = "Claim",
		["kind"] = "primary",
		["enabled"] = true,
		["frame"] = v93,
		["edge"] = v95,
		["stroke"] = v94,
		["dot"] = v107,
		["status"] = v108,
		["btn"] = v110,
		["api"] = v111,
		["lbl"] = v_u_112
	}
	p_u_85.rows[v_u_109] = v_u_115
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_112, (copy) p_u_85, (copy) v_u_115
		v_u_3.Heartbeat:Wait()
		v_u_3.Heartbeat:Wait()
		if v_u_112.Parent and p_u_85.alive then
			local v116 = v_u_112
			local v117
			if v_u_115.kind == "primary" then
				v117 = p_u_85.C.ink
			else
				v117 = p_u_85.C.text2
			end
			v116.TextColor3 = v117
		end
	end)
	return v110
end
local function v_u_123(p119) -- name: focusedRow
	-- upvalues: (copy) v_u_1
	local v120 = v_u_1.SelectedObject
	if not (v120 and v120:IsDescendantOf(p119.list)) then
		return nil, 0
	end
	while v120.Parent and v120.Parent ~= p119.list do
		v120 = v120.Parent
	end
	local v121 = string.match(v120.Name, "^Mail_(.+)$")
	local v122
	if v121 and p119.btnOrder then
		v122 = table.find(p119.btnOrder, v121)
	else
		v122 = nil
	end
	if not v122 then
		if v120:IsA("GuiObject") then
			return v121, v120.LayoutOrder
		end
		v122 = 0
	end
	return v121, v122
end
local function v_u_129(p124, p125) -- name: reorder
	p124.firstBtn = p124.delBtn
	for v126, v127 in p125.rows do
		local v128 = p124.rows[v127.e.id]
		if not v128 then
			continue
		end
		v128.frame.LayoutOrder = (p124.insBase or 0) + v126
		v128.edge.Visible = v127.ready
		if not v127.ready or p124.firstBtn then
			continue
		end
		p124.firstBtn = v128.btn
	end
end
local function v_u_137(p130) -- name: releaseHold
	if p130.holdUntil == nil then
		return
	else
		p130.holdUntil = nil
		p130.heldH = nil
		p130.wantH = p130.realH or p130.wantH
		if p130.alive then
			if p130.fitNow then
				p130.fitNow()
			elseif p130.list.Parent and p130.wantH then
				local v131 = p130.list
				local v132 = UDim2.new
				local v133 = p130.listH
				local v134 = p130.fitH or 0
				local v135 = math.max(v133, v134)
				local v136 = p130.wantH
				v131.Size = v132(1, 0, 0, (math.min(v135, v136)))
			end
		else
			return
		end
	end
end
local function v_u_144(p138) -- name: holdStart
	-- upvalues: (copy) v_u_2
	if p138.holdUntil == nil then
		p138.heldH = p138.list.Size.Y.Offset
	end
	local v139 = p138.holdUntil or 0
	local v140 = os.clock() + 8
	p138.holdUntil = math.max(v139, v140)
	local function v141()
		-- upvalues: (ref) v_u_2
		return v_u_2:GetMouseLocation()
	end
	local v142, v143 = pcall(v141)
	if not v142 then
		v143 = nil
	end
	p138.claimMouse = v143
end
local function v_u_149(p_u_145) -- name: tryRelease
	-- upvalues: (copy) v_u_2, (copy) v_u_149, (copy) v_u_137
	if p_u_145.alive and (p_u_145.holdUntil ~= nil and os.clock() >= p_u_145.holdUntil - 0.01) then
		if p_u_145.claimMouse and (p_u_145.claimOkAt and (os.clock() - p_u_145.claimOkAt < 3 and p_u_145.UI.device() == "Keyboard")) then
			local function v146()
				-- upvalues: (ref) v_u_2
				return v_u_2:GetMouseLocation()
			end
			local v147, v148 = pcall(v146)
			if v147 and (v148 - p_u_145.claimMouse).Magnitude < 12 then
				task.delay(0.3, function()
					-- upvalues: (ref) v_u_149, (copy) p_u_145
					v_u_149(p_u_145)
				end)
				return
			end
		end
		v_u_137(p_u_145)
	end
end
local function v_u_159(p_u_150, p151, p152) -- name: settle
	-- upvalues: (copy) v_u_149
	local v153 = os.clock()
	local v154 = p_u_150.shieldUntil or 0
	local v155 = v153 + p151
	p_u_150.shieldUntil = math.max(v154, v155)
	if p_u_150.holdUntil == nil then
		p_u_150.heldH = p_u_150.list.Size.Y.Offset
	end
	local v156
	if p152 == true then
		v156 = v153 + p151
	else
		local v157 = p_u_150.holdUntil or 0
		local v158 = v153 + p151
		v156 = math.max(v157, v158)
	end
	p_u_150.holdUntil = v156
	task.delay(p151 + 0.05, function()
		-- upvalues: (ref) v_u_149, (copy) p_u_150
		v_u_149(p_u_150)
	end)
end
local function v_u_219(p_u_160) -- name: rebuild
	-- upvalues: (copy) v_u_6, (copy) v_u_129, (copy) v_u_159, (copy) v_u_123, (copy) v_u_10, (copy) v_u_118, (copy) v_u_3, (copy) v_u_1, (copy) v_u_84
	local v_u_161 = p_u_160.Rail
	local v_u_162 = p_u_160.Kit
	local v_u_163 = p_u_160.UI
	local v_u_164 = p_u_160.C
	local v_u_165 = v_u_161.mailLive()
	local v166, v167
	if v_u_165 then
		v166, v167 = v_u_161.mailLayoutSig(v_u_165.rows)
		local v168
		if v_u_6 then
			local v169 = v_u_165.insLog
			v168 = type(v169) == "table" and #v_u_165.insLog or 0
		else
			v168 = 0
		end
		if v_u_6 and (#v_u_165.deliveries > 0 or v_u_165.expired > 0) then
			v166 = v166 .. "|" .. v_u_6.layoutSig(v_u_165.deliveries, v_u_165.expired)
		elseif #v_u_165.rows == 0 and v168 == 0 then
			v166 = v_u_6 and v_u_165.showDeliveries and "empty+d" or "empty"
			v167 = v166
		end
		if v168 > 0 then
			v166 = v166 .. "|L" .. v_u_6.logSig(v_u_165.insLog)
		end
	else
		v166 = v_u_161.failed("mail") and "failed" or "loading"
		v167 = v166
	end
	if v166 == p_u_160.sig then
		if v167 ~= p_u_160.order then
			p_u_160.order = v167
			if v_u_165 then
				v_u_129(p_u_160, v_u_165)
			end
		end
	else
		p_u_160.sig = v166
		p_u_160.order = v167
		if p_u_160.claimOkAt and os.clock() - p_u_160.claimOkAt < 5 then
			v_u_159(p_u_160, 0.6)
		end
		local v_u_170, v_u_171 = v_u_123(p_u_160)
		local v_u_172 = v_u_165 and #v_u_165.deliveries or 0
		local v_u_173 = not v_u_165 and 0 or v_u_165.expired
		local v_u_174 = p_u_160.Theme.isPhone()
		if v_u_174 then
			if v_u_165 == nil then
				v_u_174 = false
			else
				v_u_174 = #v_u_165.rows == 0
			end
		end
		local v175
		if v_u_165 then
			if v_u_6 then
				v175 = v_u_6.listHeight(#v_u_165.rows, v_u_172, v_u_173 > 0, v_u_174)
			else
				v175 = #v_u_165.rows == 0 and 168 or #v_u_165.rows * 88 - 8
			end
		else
			v175 = 168
		end
		local v_u_176
		if v_u_165 and v_u_6 then
			local v177 = v_u_165.insLog
			v_u_176 = type(v177) == "table" and #v_u_165.insLog or 0
		else
			v_u_176 = 0
		end
		if v_u_176 > 0 then
			if #v_u_165.rows == 0 and v_u_172 == 0 then
				v175 = (v_u_173 <= 0 and 0 or v_u_6.TUNE.noticeStep) + v_u_6.logHeight(v_u_176) - 8
			else
				v175 = v175 + (8 + v_u_6.logHeight(v_u_176))
			end
		end
		p_u_160.realH = v175 + 8
		local v178
		if p_u_160.holdUntil == nil then
			v178 = false
		else
			v178 = os.clock() < p_u_160.holdUntil
		end
		local v179
		if v178 then
			local v180 = p_u_160.realH
			local v181 = p_u_160.heldH or 0
			v179 = math.max(v180, v181)
		else
			v179 = p_u_160.realH
		end
		p_u_160.wantH = v179
		local v182 = p_u_160.list
		local v183 = UDim2.new
		local v184 = p_u_160.listH
		local v185 = p_u_160.fitH or 0
		local v186 = math.max(v184, v185)
		local v187 = p_u_160.wantH
		v182.Size = v183(1, 0, 0, (math.min(v186, v187)))
		v_u_163.keepScroll(p_u_160.list, function()
			-- upvalues: (copy) v_u_162, (copy) p_u_160, (ref) v_u_10, (copy) v_u_165, (copy) v_u_173, (ref) v_u_6, (copy) v_u_172, (copy) v_u_176, (copy) v_u_163, (copy) v_u_161, (copy) v_u_164, (copy) v_u_174, (ref) v_u_118
			v_u_162.clear(p_u_160.list)
			p_u_160.rows = {}
			p_u_160.firstBtn = nil
			p_u_160.delBtn = nil
			p_u_160.btnOrder = nil
			p_u_160.insBase = 0
			local v188 = 0
			if v_u_10 and (v_u_165 and v_u_173 > 0) then
				v188 = v188 + 1
				v_u_10.notice(p_u_160, v_u_6.expiredText(v_u_173, v_u_165.cargoGone == true), v188)
			end
			if v_u_165 and (#v_u_165.rows ~= 0 or (v_u_172 ~= 0 or v_u_176 ~= 0)) then
				local v189 = {}
				if v_u_10 and v_u_172 > 0 then
					v188 = v_u_10.build(p_u_160, v_u_165.deliveries, v188, v_u_174)
					p_u_160.delBtn = p_u_160.firstBtn
					for _, v190 in v_u_165.deliveries do
						if v190.expired then
							continue
						end
						local v191 = v190.id
						table.insert(v189, v191)
					end
					if #v_u_165.rows > 0 then
						v188 = v188 + 1
						v_u_10.header(p_u_160, v_u_6.TEXT.sectionInsurance, v188)
					end
				end
				p_u_160.insBase = v188
				for v192, v193 in v_u_165.rows do
					local v194 = v_u_118(p_u_160, v193, v188 + v192)
					if v193.ready and not p_u_160.firstBtn then
						p_u_160.firstBtn = v194
					end
					if not v193.ready then
						continue
					end
					local v195 = v193.e.id
					table.insert(v189, v195)
				end
				if v_u_172 > 0 then
					p_u_160.btnOrder = v189
				end
				if v_u_176 > 0 then
					local v196 = v188 + #v_u_165.rows + 1
					if v_u_10 then
						v_u_10.header(p_u_160, v_u_6.TEXT.sectionReport, v196)
					else
						p_u_160.Kit.section(p_u_160.list, v_u_6.TEXT.sectionReport, v196)
					end
					for v197, v198 in v_u_165.insLog do
						local v199 = v_u_163.new("Frame", {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.35,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Name"] = "Report_" .. v198.id,
							["BackgroundColor3"] = v_u_164.raised,
							["Size"] = UDim2.new(1, -8, 0, 30),
							["LayoutOrder"] = v196 + v197
						}, p_u_160.list)
						v_u_163.stroke(v199, v_u_164.line)
						local v200
						if v198.kind == "warn" then
							v200 = v_u_164.danger
						elseif v198.kind == "ok" then
							v200 = v_u_164.success
						elseif v198.kind == "info" then
							v200 = v_u_164.accent
						else
							v200 = v_u_164.text2
						end
						v_u_163.new("Frame", {
							["Name"] = "Edge",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["ZIndex"] = 3,
							["BackgroundColor3"] = v200,
							["Size"] = UDim2.new(0, 3, 1, 0)
						}, v199)
						v_u_163.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = nil,
							["style"] = "bodyStrong",
							["textSize"] = 14,
							["track"] = false,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v199,
							["text"] = v198.name,
							["position"] = UDim2.fromOffset(14, 0),
							["size"] = UDim2.new(0.5, -14, 1, 0)
						}).TextTruncate = Enum.TextTruncate.AtEnd
						v_u_163.label({
							["parent"] = nil,
							["name"] = "State",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["track"] = false,
							["align"] = "right",
							["position"] = nil,
							["size"] = nil,
							["parent"] = v199,
							["text"] = v198.text,
							["color"] = v200,
							["position"] = UDim2.new(0.5, 0, 0, 0),
							["size"] = UDim2.new(0.5, -14, 1, 0)
						}).TextTruncate = Enum.TextTruncate.AtEnd
					end
				end
			else
				local v201 = v_u_163.new("Frame", {
					["Name"] = "Empty",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Size"] = UDim2.new(1, -8, 0, 168),
					["LayoutOrder"] = v188 + 1
				}, p_u_160.list)
				local v202 = v_u_161.glyph("mail", v201, 40, v_u_164.muted)
				v202.AnchorPoint = Vector2.new(0.5, 0)
				v202.Position = UDim2.new(0.5, 0, 0, 26)
				local v203
				if v_u_165 then
					v203 = not (v_u_6 and v_u_165.showDeliveries) and "Nothing here yet. Insured items that were lost in a raid come back here." or v_u_6.TEXT.empty
				else
					v203 = not v_u_161.failed("mail") and "Checking the mailbox..." or p_u_160.mc.failText("mail", "The mailbox is not available right now. Try again in a moment.")
				end
				v_u_163.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["align"] = "center",
					["valign"] = "top",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v201,
					["text"] = v203,
					["color"] = v_u_164.text2,
					["position"] = UDim2.new(0.5, 0, 0, 84),
					["anchor"] = Vector2.new(0.5, 0),
					["size"] = UDim2.fromOffset(232, 0)
				}).TextYAlignment = Enum.TextYAlignment.Top
			end
		end)
		if v_u_170 then
			local v_u_204 = {}
			p_u_160.settleToken = v_u_204
			task.spawn(function()
				-- upvalues: (ref) v_u_3, (copy) p_u_160, (copy) v_u_204, (ref) v_u_1, (copy) v_u_170, (copy) v_u_171
				v_u_3.Heartbeat:Wait()
				v_u_3.Heartbeat:Wait()
				v_u_3.Heartbeat:Wait()
				v_u_3.Heartbeat:Wait()
				v_u_3.Heartbeat:Wait()
				if p_u_160.alive and (p_u_160.settleToken == v_u_204 and p_u_160.UI.device() == "Gamepad") then
					local v205 = v_u_1.SelectedObject
					if not (v205 and (v205:IsDescendantOf(p_u_160.list) and v205.Selectable)) then
						local v206 = p_u_160.rows[v_u_170]
						local v207
						if v206 then
							v207 = v206.btn
						else
							local v208 = p_u_160.btnOrder
							if v208 and #v208 > 0 then
								local v209 = p_u_160.rows
								local v210 = v_u_171
								local v211 = #v208
								local v212 = v209[v208[math.min(v210, v211)]]
								if v212 then
									v207 = v212.btn
								else
									v207 = p_u_160.firstBtn
								end
							else
								local v213 = p_u_160.Rail.mailLive()
								local v214
								if v213 then
									local v215 = v213.rows
									local v216 = v_u_171
									local v217 = #v213.rows
									v214 = v215[math.min(v216, v217)]
								else
									v214 = nil
								end
								local v218
								if v214 and v214.ready then
									v218 = p_u_160.rows[v214.e.id]
								else
									v218 = nil
								end
								if v218 then
									v207 = v218.btn
								else
									v207 = p_u_160.firstBtn
								end
							end
						end
						if v207 and (v207.Parent and v207.Selectable) then
							v_u_1.SelectedObject = v207
						end
					end
				else
					return
				end
			end)
		end
		v_u_84()
	end
end
function v_u_4._press(p220) -- name: _press
	-- upvalues: (ref) v_u_13, (copy) v_u_4
	local v221 = v_u_13
	if not v221 or (not v221.alive or (not v221.shieldUntil or os.clock() >= v221.shieldUntil)) then
		v_u_4._claim(p220)
	end
end
function v_u_4._claim(p222) -- name: _claim
	-- upvalues: (ref) v_u_13, (copy) v_u_144, (copy) v_u_84
	local v223 = v_u_13
	if v223 and (v223.alive and not v223.busy) then
		local v224 = v223.mc
		v223.busy = p222
		v223.busyAt = os.clock()
		v223.castAt = v223.updates
		v_u_144(v223)
		v_u_84()
		if v223.Rail.stubActive("mail") then
			v223.Rail.stubClaim(v224, p222)
		else
			v224.op(p222 == "all" and {
				["op"] = "mailClaim",
				["all"] = true
			} or {
				["op"] = "mailClaim",
				["id"] = nil,
				["id"] = p222
			})
		end
	else
		return
	end
end
local function v_u_234(p225, p226) -- name: onResult
	-- upvalues: (copy) v_u_6, (copy) v_u_159, (copy) v_u_219, (copy) v_u_137, (copy) v_u_4, (copy) v_u_84
	if type(p226) == "table" and p226.op == "mailClaim" then
		local v227 = p225.busy
		local v228 = p226.msg
		local v229
		if type(v228) == "string" and p226.msg ~= "" then
			v229 = p226.msg
		else
			v229 = nil
		end
		if v229 == nil and v_u_6 then
			local v230 = nil
			local v231
			if v227 == nil or v227 == "all" then
				v231 = nil
			else
				v231 = p225.Rail.mailLive()
			end
			if v231 then
				for _, v232 in v231.deliveries do
					if v232.id ~= v227 then
						continue
					end
					v230 = v232.title
				end
			end
			v229 = v_u_6.claimText(p226, v230)
			if v229 and p226.ok ~= false then
				local v233 = p225.UI.toast
				pcall(v233, v229, "success")
			end
		end
		if p226.ok == false then
			p225.busy = nil
			v_u_137(p225)
		else
			p225.claimOkAt = os.clock()
			v_u_159(p225, 0.9, true)
			if p225.updates > p225.castAt then
				p225.busy = nil
				p225.sig = ""
				v_u_219(p225)
			else
				p225.fresh = true
			end
		end
		if p226.ok == false then
			if v227 ~= nil and v227 ~= "all" then
				p225.notes[v227] = {
					["text"] = v229 or "That did not work",
					["untilAt"] = os.clock() + 8
				}
			end
		else
			p225.notes = {}
		end
		p225.headNote = v_u_4.headAfter(p225.headNote, p226, v227, v229, os.clock())
		v_u_84()
	end
end
local function v_u_242(p235) -- name: paintViewTabs
	local v236 = p235.ML
	if v236 and p235.tabLetters then
		local v237 = v236.unread()
		local v238 = p235.Rail.mailLive()
		local v239 = not v238 and 0 or v238.ready + v238.waiting
		local v240 = v237 <= 0 and "Letters" or ("Letters (%d)"):format(v237)
		local v241 = v239 <= 0 and "Deliveries" or ("Deliveries (%d)"):format(v239)
		if p235.tabLettersText ~= v240 then
			p235.tabLettersText = v240
			p235.tabLetters.setText(v240)
		end
		if p235.tabDeliveriesText ~= v241 then
			p235.tabDeliveriesText = v241
			p235.tabDeliveries.setText(v241)
		end
	end
end
local function v_u_248(p243, p244) -- name: setView
	-- upvalues: (copy) v_u_47, (copy) v_u_242, (copy) v_u_84
	if p243.lv then
		p243.view = p244
		local v245 = p244 == "letters"
		p243.head.Visible = not v245
		p243.list.Visible = not v245
		p243.lv.head.Visible = v245
		p243.lv.list.Visible = v245
		p243.tabLetters.setKind(v245 and "primary" or "secondary")
		p243.tabDeliveries.setKind(v245 and "secondary" or "primary")
		if p243.ruleLbl then
			p243.ruleLbl.Text = v245 and "News, patch notes and known bugs from the HUSH team." or v_u_47(p243.Rail.mailLive(), p243.Theme.isPhone())
			local v246 = p243.ruleLbl
			local v247
			if v245 then
				v247 = p243.Theme.isPhone()
			else
				v247 = v245
			end
			v246.Visible = not v247
		end
		p243.lv.refresh()
		if not v245 then
			p243.Rail.markSeen()
		end
		v_u_242(p243)
		v_u_84()
	end
end
local function v_u_271(p_u_249, p_u_250, p251) -- name: roomFor
	local v_u_252 = p_u_250:FindFirstAncestor("Body")
	local v_u_253
	if v_u_252 then
		v_u_253 = v_u_252:FindFirstChildOfClass("UIListLayout")
	else
		v_u_253 = nil
	end
	if not (v_u_252 and v_u_253) then
		return p_u_249.listH
	end
	local v265, v266 = pcall(function()
		-- upvalues: (copy) p_u_249, (copy) p_u_250, (copy) v_u_252, (copy) v_u_253
		local v254 = p_u_249.UI
		local v255 = p_u_249.Theme
		local v256 = v254.pointer().scaleOf
		local v257 = p_u_250
		local v258 = math.max(0.01, v256(v257))
		local _, v259 = v254.modalLimits(p_u_249.width, v255.refSize(), v254.safeInsets())
		local v260 = v258 / v255.uiScale()
		local v261 = v259 / math.max(0.25, v260)
		local v262 = math.floor(v261) - (v255.space.m + v255.touch(v255.control) + v255.space.l)
		local v263 = v_u_252:FindFirstChildOfClass("UIPadding")
		local v264 = not v263 and 0 or v263.PaddingTop.Offset + v263.PaddingBottom.Offset
		return v262 - ((v_u_253.AbsoluteContentSize.Y - p_u_250.AbsoluteSize.Y) / v258 + v264)
	end)
	if not v265 or (type(v266) ~= "number" or v266 ~= v266) then
		return p_u_249.listH
	end
	local v267 = math.floor(v266)
	local v268 = p_u_249.listH
	local v269 = p251 or p_u_249.listH
	local v270 = math.max(v268, v269)
	return math.clamp(v267, 40, v270)
end
local function v_u_307(p_u_272) -- name: fitLetters
	-- upvalues: (copy) v_u_271, (copy) v_u_3
	local v_u_273 = p_u_272.lv.list
	local v_u_274 = v_u_273:FindFirstChildOfClass("UIListLayout")
	if v_u_274 then
		local function v_u_285() -- name: fit
			-- upvalues: (copy) p_u_272, (copy) v_u_273, (copy) v_u_274, (ref) v_u_271
			if p_u_272.alive then
				local v275 = p_u_272.UI.pointer().scaleOf
				local v276 = v_u_273
				local v277 = math.max(0.01, v275(v276))
				if v_u_273.Parent and v_u_273.Visible then
					local v278 = v_u_274.AbsoluteContentSize.Y / v277
					local v279 = math.ceil(v278)
					local v280 = v_u_271(p_u_272, v_u_273)
					local v281 = math.clamp(v279, 40, v280)
					if v_u_273.Size.Y.Offset ~= v281 then
						v_u_273.Size = UDim2.new(1, 0, 0, v281)
						return
					end
				elseif p_u_272.list and (p_u_272.list.Parent and (p_u_272.list.Visible and p_u_272.wantH)) then
					local v282 = v_u_271(p_u_272, p_u_272.list, 420)
					local v283 = p_u_272.wantH
					local v284 = math.min(v282, v283)
					p_u_272.fitH = v284
					if p_u_272.list.Size.Y.Offset ~= v284 then
						p_u_272.list.Size = UDim2.new(1, 0, 0, v284)
					end
				end
			end
		end
		local v_u_286 = false
		local v_u_287 = false
		local function v_u_291() -- name: fitSafe
			-- upvalues: (ref) v_u_286, (ref) v_u_287, (ref) v_u_291, (copy) v_u_285
			if v_u_286 then
				if not v_u_287 then
					v_u_287 = true
					task.defer(function()
						-- upvalues: (ref) v_u_287, (ref) v_u_291
						v_u_287 = false
						v_u_291()
					end)
				end
			else
				v_u_286 = true
				local v288 = v_u_285
				local v289, v290 = pcall(v288)
				v_u_286 = false
				if not v289 then
					warn("[MenuMail] fit failed:", v290)
				end
			end
		end
		v_u_274:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(v_u_291)
		v_u_273:GetPropertyChangedSignal("Visible"):Connect(v_u_291)
		local v292 = v_u_273:FindFirstAncestor("Body")
		if v292 then
			v292 = v_u_273:FindFirstAncestor("Body"):FindFirstChildOfClass("UIListLayout")
		end
		if v292 then
			v292:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
				-- upvalues: (ref) v_u_291
				task.defer(v_u_291)
			end)
		end
		v_u_291()
		p_u_272.fitNow = v_u_291
		local v_u_293 = nil
		p_u_272.lettersOpen = p_u_272.ML.listen(function()
			-- upvalues: (copy) p_u_272, (copy) v_u_273, (ref) v_u_293
			task.delay(0.12, function()
				-- upvalues: (ref) p_u_272, (ref) v_u_273, (ref) v_u_293
				if p_u_272.alive and v_u_273.Parent then
					local v294 = nil
					for _, v295 in v_u_273:GetChildren() do
						if not (v295:IsA("GuiObject") and v295:FindFirstChild("BodyBox", true)) then
							continue
						end
						v294 = v295
					end
					if v294 then
						if v_u_293 ~= v294.Name then
							v_u_293 = v294.Name
							local v296 = v294.AbsolutePosition.Y - v_u_273.AbsolutePosition.Y + v_u_273.CanvasPosition.Y
							local v297 = v_u_273.AbsoluteWindowSize.Y
							local v298 = v294.AbsoluteSize.Y
							local v299 = v_u_273.CanvasPosition.Y
							if v298 <= v297 then
								local v300 = v296 + v298 - v297
								v296 = math.clamp(v299, v300, v296)
							end
							v_u_273.CanvasPosition = Vector2.new(0, (math.max(0, v296)))
						end
					else
						v_u_293 = nil
						return
					end
				else
					return
				end
			end)
		end)
		local v301, v_u_302 = pcall(function()
			return require(script.Parent:WaitForChild("VirtualPad"))
		end)
		if v301 then
			p_u_272.stickConn = v_u_3.Heartbeat:Connect(function(p303)
				-- upvalues: (copy) p_u_272, (copy) v_u_273, (copy) v_u_302
				if p_u_272.alive and (v_u_273.Visible and p_u_272.UI.device() == "Gamepad") then
					for _, v304 in v_u_302.gamepadState() do
						if v304.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						local v305 = v304.Position.Y
						if math.abs(v305) <= 0.2 then
							continue
						end
						local v306 = v_u_273
						v306.CanvasPosition = v306.CanvasPosition + Vector2.new(0, -v304.Position.Y * 600 * p303)
					end
				end
			end)
		end
	end
end
local function v_u_318(p_u_308, p309, p310) -- name: mountLetters
	-- upvalues: (copy) v_u_248, (copy) v_u_242, (copy) v_u_307
	local v311, v312 = pcall(function()
		-- upvalues: (copy) p_u_308
		return p_u_308.mc.cctx.lib.MenuLetters
	end)
	if v311 and type(v312) == "table" then
		local v313 = p_u_308.UI
		local v314 = p_u_308.Theme
		local v315 = v313.new("Frame", {
			["Name"] = "ViewSwitch",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Size"] = UDim2.new(1, 0, 0, v314.touch(36))
		}, p309)
		v313.layout(v315, "h", 8)
		local _, v316 = v313.button({
			["parent"] = nil,
			["name"] = "TabLetters",
			["text"] = "Letters",
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = 170,
			["maxTextWidth"] = 140,
			["onClick"] = nil,
			["parent"] = v315,
			["height"] = v314.touch(36),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_248, (copy) p_u_308
				v_u_248(p_u_308, "letters")
			end
		})
		local _, v317 = v313.button({
			["parent"] = nil,
			["name"] = "TabDeliveries",
			["text"] = "Deliveries",
			["kind"] = "primary",
			["height"] = nil,
			["width"] = 170,
			["maxTextWidth"] = 140,
			["onClick"] = nil,
			["parent"] = v315,
			["height"] = v314.touch(36),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_248, (copy) p_u_308
				v_u_248(p_u_308, "deliveries")
			end
		})
		p_u_308.ML = v312
		p_u_308.head = p310
		p_u_308.tabLetters = v316
		p_u_308.tabDeliveries = v317
		p_u_308.lv = v312.mount(p_u_308, p309, p_u_308.listH)
		p_u_308.lettersOff = v312.listen(function()
			-- upvalues: (ref) v_u_242, (copy) p_u_308
			v_u_242(p_u_308)
		end)
		v_u_307(p_u_308)
	end
end
function v_u_4.update() -- name: update
	-- upvalues: (ref) v_u_13, (copy) v_u_219, (copy) v_u_84, (copy) v_u_242
	local v319 = v_u_13
	if v319 and v319.alive then
		v319.updates = v319.updates + 1
		if v319.fresh then
			v319.fresh = false
			v319.busy = nil
		end
		v_u_219(v319)
		v_u_84()
		v_u_242(v319)
		if v319.view ~= "letters" then
			v319.Rail.markSeen()
		end
	end
end
function v_u_4.tick() -- name: tick
	-- upvalues: (ref) v_u_13, (copy) v_u_137, (copy) v_u_219, (copy) v_u_84, (copy) v_u_242
	local v320 = v_u_13
	if v320 and v320.alive then
		if v320.busy and os.clock() - v320.busyAt > 6 then
			v320.busy = nil
			v_u_137(v320)
		end
		v_u_219(v320)
		v_u_84()
		v_u_242(v320)
	end
end
function v_u_4.open(p321, p322, p323) -- name: open
	-- upvalues: (ref) v_u_13, (copy) v_u_6, (copy) v_u_4, (copy) v_u_318, (copy) v_u_1, (copy) v_u_234, (copy) v_u_219, (copy) v_u_40, (copy) v_u_248, (copy) v_u_84
	if not (v_u_13 and v_u_13.alive) then
		local v_u_324 = p321.cctx.lib.MenuRail
		v_u_324.bind(p321)
		local v_u_325 = p321.ui
		local v326 = p321.theme
		local v_u_327 = v326.color
		local v328 = v326.refSize()
		local v329 = v328.X - 32
		local v330 = math.min(680, v329)
		local v331 = v328.Y - 440
		local v_u_332 = math.clamp(v331, 150, 420)
		local v333 = v326.isTouch()
		local v_u_335 = {
			["alive"] = true,
			["mc"] = nil,
			["Rail"] = nil,
			["UI"] = nil,
			["Theme"] = nil,
			["C"] = nil,
			["Kit"] = nil,
			["rows"] = nil,
			["notes"] = nil,
			["sig"] = "",
			["order"] = "",
			["settleToken"] = nil,
			["listH"] = nil,
			["width"] = nil,
			["busy"] = nil,
			["busyAt"] = 0,
			["updates"] = 0,
			["castAt"] = 0,
			["returnTo"] = nil,
			["unbind"] = nil,
			["conn"] = nil,
			["MR"] = nil,
			["claim"] = nil,
			["mc"] = p321,
			["Rail"] = v_u_324,
			["UI"] = v_u_325,
			["Theme"] = v326,
			["C"] = v_u_327,
			["Kit"] = p321.kit,
			["rows"] = {},
			["notes"] = {},
			["listH"] = v_u_332,
			["width"] = v330,
			["returnTo"] = p322,
			["MR"] = v_u_6,
			["claim"] = function(p334) -- name: claim
				-- upvalues: (ref) v_u_4
				v_u_4._press(p334)
			end
		}
		v_u_13 = v_u_335
		local v344 = {
			["title"] = "Mail",
			["body"] = "An insured item comes back if you died and nobody carried it out.",
			["width"] = nil,
			["build"] = nil,
			["buttons"] = nil,
			["onClose"] = nil,
			["width"] = v330,
			["build"] = function(p336) -- name: build
				-- upvalues: (copy) v_u_325, (copy) v_u_335, (copy) v_u_327, (copy) v_u_332, (ref) v_u_318
				local v337 = v_u_325.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 20)
				}, p336)
				v_u_335.summary = v_u_325.label({
					["parent"] = nil,
					["name"] = "Summary",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["track"] = false,
					["size"] = nil,
					["parent"] = v337,
					["color"] = v_u_327.text2,
					["size"] = UDim2.new(0.7, 0, 1, 0)
				})
				v_u_335.cap = v_u_325.label({
					["parent"] = nil,
					["name"] = "Capacity",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["track"] = false,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v337,
					["color"] = v_u_327.text2,
					["position"] = UDim2.fromScale(0.7, 0),
					["size"] = UDim2.new(0.3, 0, 1, 0)
				})
				v_u_335.list = v_u_325.list({
					["parent"] = nil,
					["name"] = "MailList",
					["size"] = nil,
					["gap"] = 8,
					["parent"] = p336,
					["size"] = UDim2.new(1, 0, 0, v_u_332)
				})
				v_u_335.list.LayoutOrder = 2
				local v338 = v_u_318
				local v339 = v_u_335
				local v340, v341 = pcall(v338, v339, p336, v337)
				if not v340 then
					warn("[MenuMail] letters view failed:", v341)
					v_u_335.lv = nil
				end
			end,
			["buttons"] = {
				{
					["text"] = "Claim all",
					["kind"] = "secondary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_4
						v_u_4._press("all")
						return true
					end
				},
				{
					["text"] = "Close",
					["kind"] = "primary",
					["hint"] = nil,
					["hint"] = not v333 and "menu" or nil
				}
			},
			["onClose"] = function() -- name: onClose
				-- upvalues: (copy) v_u_335, (copy) v_u_324, (ref) v_u_13, (copy) v_u_325, (ref) v_u_1
				v_u_335.alive = false
				if v_u_335.sawExpired then
					v_u_324.clearExpired()
				end
				if v_u_335.conn then
					v_u_335.conn:Disconnect()
				end
				if v_u_335.padConn then
					v_u_335.padConn:Disconnect()
				end
				if v_u_335.lettersOff then
					v_u_335.lettersOff()
				end
				if v_u_335.lettersOpen then
					v_u_335.lettersOpen()
				end
				if v_u_335.stickConn then
					v_u_335.stickConn:Disconnect()
				end
				if v_u_335.lv then
					v_u_335.lv.destroy()
				end
				if v_u_335.unbind then
					local v342 = v_u_335.unbind
					pcall(v342)
				end
				if v_u_13 == v_u_335 then
					v_u_13 = nil
				end
				local v_u_343 = v_u_335.returnTo
				if v_u_343 and v_u_325.device() == "Gamepad" then
					task.delay(0.15, function()
						-- upvalues: (copy) v_u_343, (ref) v_u_325, (ref) v_u_1
						if v_u_343.Parent and (v_u_325.modalCount() == 0 and v_u_325.device() == "Gamepad") then
							v_u_1.SelectedObject = v_u_343
						end
					end)
				end
			end
		}
		v_u_335.api = v_u_325.modal(v344)
		v_u_335.conn = p321.changed:Connect(function(p345, p346)
			-- upvalues: (copy) v_u_335, (ref) v_u_234
			if p345 == "result" and v_u_335.alive then
				v_u_234(v_u_335, p346)
			end
		end)
		local v347 = p321.cctx.controllers.Input
		if v347 then
			local v348 = v347.bind
			if type(v348) == "function" then
				local v349 = v347.bind
				local function v350()
					-- upvalues: (ref) v_u_4
					v_u_4.close()
				end
				local v351, v352 = pcall(v349, "menu", v350)
				if v351 and type(v352) == "function" then
					v_u_335.unbind = v352
				end
			end
		end
		v_u_219(v_u_335)
		v_u_335.padConn = v_u_335.list:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(function()
			-- upvalues: (ref) v_u_40, (copy) v_u_335
			v_u_40(v_u_335)
		end)
		v_u_324.fetch(p321, "mail", {
			["force"] = true,
			["refresh"] = true
		})
		for _, v353 in v_u_335.api.body:GetChildren() do
			if not v353:IsA("TextLabel") or v353.LayoutOrder ~= 2 then
				continue
			end
			v_u_335.ruleLbl = v353
		end
		if v_u_335.lv and v_u_335.ML then
			v_u_335.ML.fetch(p321, true)
			local v354 = v_u_335.Rail.mailLive()
			local v355
			if type(v354) == "table" then
				local v356 = v354.waiting
				v355 = (tonumber(v356) or 0) > 0
			else
				v355 = false
			end
			v_u_248(v_u_335, type(p323) == "table" and p323.view == "deliveries" and "deliveries" or (v_u_335.ML.unread() > 0 and not v355 and "letters" or "deliveries"))
		else
			v_u_324.markSeen()
			v_u_84()
		end
		if v_u_325.device() == "Gamepad" then
			task.delay(0.2, function()
				-- upvalues: (copy) v_u_335, (ref) v_u_1
				if v_u_335.alive and (v_u_335.firstBtn and v_u_335.firstBtn.Parent) then
					v_u_1.SelectedObject = v_u_335.firstBtn
				end
			end)
		end
	end
end
return v_u_4