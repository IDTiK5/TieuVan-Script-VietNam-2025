-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HotwireUI

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("ContextActionService")
local v3 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("HotwireRules"))
local v_u_5 = require(v3:WaitForChild("Theme"))
local v_u_6 = require(script.Parent.HushUI)
local v_u_7 = require(script.Parent.HotwireUILayout)
local v_u_8 = {}
local v_u_9 = v_u_5.color
local v_u_10 = v_u_7.K
local v_u_11 = {
	["opened"] = 0,
	["presses"] = 0,
	["sent"] = 0,
	["hits"] = 0,
	["misses"] = 0,
	["rebuilds"] = 0,
	["errors"] = 0
}
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = ""
local function v_u_23(p17, p18, p19, p20, p21, p22) -- name: frame
	-- upvalues: (copy) v_u_6
	return v_u_6.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Name"] = p18,
		["BackgroundColor3"] = p20,
		["BackgroundTransparency"] = p21 or 0,
		["Position"] = UDim2.fromOffset(p19.x, p19.y),
		["Size"] = UDim2.fromOffset(p19.w, p19.h),
		["ZIndex"] = p22 or 1
	}, p17)
end
local function v_u_31(p24, p25, p26, p27, p28, p29, p30) -- name: label
	-- upvalues: (copy) v_u_6
	return v_u_6.label({
		["parent"] = nil,
		["name"] = nil,
		["text"] = nil,
		["style"] = "body",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = nil,
		["size"] = nil,
		["position"] = nil,
		["zindex"] = 3,
		["parent"] = p24,
		["name"] = p25,
		["text"] = p26,
		["textSize"] = p28,
		["color"] = p29,
		["align"] = p30 or "left",
		["size"] = UDim2.fromOffset(p27.w, p27.h),
		["position"] = UDim2.fromOffset(p27.x, p27.y)
	})
end
local function v_u_72() -- name: build
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (ref) v_u_14, (ref) v_u_15, (ref) v_u_12, (ref) v_u_13, (ref) v_u_16, (copy) v_u_11, (copy) v_u_6, (copy) v_u_23, (copy) v_u_9, (copy) v_u_31, (copy) v_u_10, (copy) v_u_8
	local v32 = v_u_5.safeRefSize()
	local v33 = v_u_5.isTouch()
	local v34 = v_u_7.compute(v32.X, v32.Y, {
		["touch"] = v33,
		["scale"] = v_u_5.uiScale(),
		["phone"] = v_u_5.isPhone(),
		["avoidY"] = v_u_14,
		["interval"] = v_u_15,
		["need"] = v_u_12.rules.need,
		["style"] = v_u_12.rules.style
	})
	local v35 = v_u_14
	local v36 = string.format("%d,%d,%s,%d,%s,%s", v32.X, v32.Y, tostring(v33), v_u_12.rules.need, v_u_12.rules.style, (tostring(v35)))
	if not v_u_13 or v36 ~= v_u_16 then
		if v_u_13 and v_u_13.gui then
			local function v37()
				-- upvalues: (ref) v_u_13
				v_u_13.gui:Destroy()
			end
			pcall(v37)
		end
		v_u_13 = nil
		v_u_16 = ""
		local v38 = v_u_11
		v38.rebuilds = v38.rebuilds + 1
		v_u_16 = v36
		local v39, v40 = v_u_6.screen("HushHotwire", v_u_5.layer.hud + 3)
		local v41 = v_u_23(v40, "Card", v34.card, v_u_9.bg, v_u_5.alpha.glass, 1)
		v_u_6.stroke(v41, v_u_9.lineStrong)
		local v42 = {
			["gui"] = v39,
			["root"] = v40,
			["lay"] = v34,
			["card"] = v41,
			["pips"] = {},
			["hints"] = {},
			["title"] = v_u_31(v40, "Title", v34.titleText, v34.title, v34.sizes.title, v_u_9.text, "left")
		}
		local v43 = v_u_23(v40, "Bar", v34.bar, v_u_9.raised, 0, 2)
		v_u_6.stroke(v43, v_u_9.line)
		v42.bar = v43
		v42.zone = v_u_23(v40, "Zone", v34.bar, v_u_9.success, 0.25, 3)
		v42.timerBack = v_u_23(v40, "TimerBack", v34.timer, v_u_9.line, 0.3, 2)
		v42.timer = v_u_23(v40, "Timer", v34.timer, v_u_9.accent, 0, 3)
		if v_u_10.TIME_LIMIT <= 0 then
			v42.timerBack.Visible = false
			v42.timer.Visible = false
		end
		v42.pointer = v_u_23(v40, "Pointer", v34.bar, v_u_9.white, 0, 5)
		v42.count = v_u_31(v40, "Count", "", v34.count, v34.sizes.status, v_u_9.text, "left")
		for v44, v45 in v34.pips do
			local v46 = v_u_23(v40, "Pip" .. v44, v45, v_u_9.raised, 0, 3)
			v_u_6.stroke(v46, v_u_9.lineStrong)
			local v47 = v42.pips
			table.insert(v47, v46)
		end
		v42.message = v_u_31(v40, "Message", "", v34.message, v34.sizes.message, v_u_9.text2, "center")
		v42.misses = v_u_31(v40, "Misses", "", v34.misses, v34.sizes.misses, v_u_9.text2, "right")
		if v34.hints then
			for v48, v49 in v34.hints.items do
				local v50 = v_u_23(v40, v49.action == v_u_7.ACTION_SPARK and "SparkChip" or "ExitChip", v49.chip, v_u_9.raised, 0.1, 4)
				v_u_6.stroke(v50, v_u_9.lineStrong)
				local v51 = v_u_31(v50, "Key", "", {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v49.chip.w,
					["h"] = v49.chip.h
				}, 13, v_u_9.text, "center")
				if v49.action == v_u_7.ACTION_SPARK then
					local v52 = v_u_6.hint
					local v53 = v_u_7.ACTION_SPARK
					local v54, v55 = pcall(v52, v53)
					local v56 = v_u_7.sparkKeyText
					local v57 = v_u_6.device()
					if not v54 then
						v55 = nil
					end
					v51.Text = v56(v57, v55)
					v42.sparkKey = v51
				else
					local v58 = v_u_6.hint
					local v59 = v_u_7.ACTION_EXIT
					local v60, v61 = pcall(v58, v59)
					local v62 = v_u_6.hint
					local v63, v64 = pcall(v62, "interact")
					local v65 = v_u_7.exitKeyText
					local v66 = v_u_6.device()
					if not v60 then
						v61 = nil
					end
					if not v63 then
						v64 = nil
					end
					v51.Text = v65(v66, v61, v64)
					v42.exitKey = v51
				end
				v_u_31(v40, "HintText" .. v48, v49.text, v49.label, v49.textSize, v_u_9.text2, "left")
				local v67 = v42.hints
				table.insert(v67, v50)
			end
		end
		if v34.spark then
			local v68 = v34.spark
			local v69 = v_u_6.new("TextButton", {
				["Name"] = "Spark",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.05,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["ZIndex"] = 6,
				["BackgroundColor3"] = v_u_9.accent,
				["Position"] = UDim2.fromOffset(v68.x, v68.y),
				["Size"] = UDim2.fromOffset(v68.w, v68.h)
			}, v40)
			v_u_6.new("UICorner", {
				["CornerRadius"] = UDim.new(0.5, 0)
			}, v69)
			v_u_6.stroke(v69, v_u_9.accentDim, 3)
			local v70 = v_u_7.fitSize(v_u_7.TEXT.spark, v68.w - 16, 28, 14, true)
			v_u_6.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = nil,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["zindex"] = 7,
				["parent"] = v69,
				["text"] = v_u_7.TEXT.spark,
				["textSize"] = v70,
				["color"] = v_u_9.ink,
				["size"] = UDim2.fromScale(1, 1)
			})
			v69.InputBegan:Connect(function(p71)
				-- upvalues: (ref) v_u_8
				if p71.UserInputType == Enum.UserInputType.Touch or p71.UserInputType == Enum.UserInputType.MouseButton1 then
					v_u_8.press("button")
				end
			end)
			v42.sparkBtn = v69
		end
		v_u_13 = v42
	end
end
local function v_u_74() -- name: nowOf
	-- upvalues: (ref) v_u_12
	local v73 = v_u_12
	if v73 then
		v73 = v_u_12.now
	end
	if v73 then
		return v73()
	else
		return workspace:GetServerTimeNow()
	end
end
function v_u_8.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_12
	return v_u_12 ~= nil
end
function v_u_8.open(p75) -- name: open
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_4, (ref) v_u_14, (ref) v_u_15, (copy) v_u_11, (copy) v_u_2, (copy) v_u_72
	if type(p75) == "table" then
		local v76 = p75.seed
		if type(v76) == "number" then
			local v77 = p75.startAt
			if type(v77) == "number" then
				if v_u_12 then
					v_u_8.close("reopen")
				end
				local v78 = p75.now
				local v79
				if type(v78) == "function" then
					v79 = p75.now
				else
					v79 = nil
				end
				v_u_12 = {
					["rules"] = nil,
					["spec"] = nil,
					["now"] = nil,
					["onPress"] = nil,
					["onClose"] = nil,
					["onExit"] = nil,
					["flashText"] = nil,
					["flashKind"] = nil,
					["flashAt"] = -1000000000,
					["doneAt"] = nil,
					["opened"] = nil,
					["rules"] = v_u_4.new(p75.seed, p75.startAt, p75.spec),
					["spec"] = p75.spec,
					["now"] = v79,
					["onPress"] = p75.onPress,
					["onClose"] = p75.onClose,
					["onExit"] = p75.onExit,
					["opened"] = os.clock()
				}
				if p75.avoidY ~= nil then
					v_u_14 = p75.avoidY
				end
				if p75.interval ~= nil then
					v_u_15 = p75.interval
				end
				local v80 = v_u_11
				v80.opened = v80.opened + 1
				local function v82()
					-- upvalues: (ref) v_u_2, (ref) v_u_8
					v_u_2:BindActionAtPriority("HushHotwireSpark", function(_, p81, _)
						-- upvalues: (ref) v_u_8
						if p81 == Enum.UserInputState.Begin then
							v_u_8.press("key")
						end
						return Enum.ContextActionResult.Sink
					end, false, Enum.ContextActionPriority.High.Value + 10, Enum.KeyCode.Space, Enum.UserInputType.MouseButton1, Enum.KeyCode.ButtonA)
				end
				pcall(v82)
				local function v84()
					-- upvalues: (ref) v_u_2, (ref) v_u_8
					v_u_2:BindActionAtPriority("HushHotwireExit", function(_, p83, _)
						-- upvalues: (ref) v_u_8
						if p83 == Enum.UserInputState.Begin then
							v_u_8.requestExit("pad")
						end
						return Enum.ContextActionResult.Sink
					end, false, Enum.ContextActionPriority.High.Value + 10, Enum.KeyCode.ButtonB)
				end
				pcall(v84)
				local v85 = v_u_72
				local v86, v87 = pcall(v85)
				if not v86 then
					local v88 = v_u_11
					v88.errors = v88.errors + 1
					if v_u_11.errors <= 3 then
						warn("[HotwireUI] " .. "build" .. " failed: " .. tostring(v87))
					end
				end
				return true
			end
		end
	end
	return false
end
function v_u_8.requestExit(p89) -- name: requestExit
	-- upvalues: (ref) v_u_12, (copy) v_u_11
	local v90 = v_u_12
	if v90 then
		local v91 = v90.onExit
		if type(v91) == "function" then
			local v92 = v90.onExit
			local v93, v94 = pcall(v92, p89 or "pad")
			if not v93 then
				local v95 = v_u_11
				v95.errors = v95.errors + 1
				if v_u_11.errors <= 3 then
					warn("[HotwireUI] " .. "onExit" .. " failed: " .. tostring(v94))
				end
			end
			return v93
		end
	end
	return false
end
function v_u_8.setAvoid(p96, p97) -- name: setAvoid
	-- upvalues: (ref) v_u_14, (ref) v_u_15, (ref) v_u_12, (copy) v_u_72, (copy) v_u_11
	v_u_14 = p96
	v_u_15 = p97
	if v_u_12 then
		local v98 = v_u_72
		local v99, v100 = pcall(v98)
		if not v99 then
			local v101 = v_u_11
			v101.errors = v101.errors + 1
			if v_u_11.errors <= 3 then
				warn("[HotwireUI] " .. "rebuild" .. " failed: " .. tostring(v100))
			end
		end
	end
end
function v_u_8.close(p102) -- name: close
	-- upvalues: (ref) v_u_12, (copy) v_u_2, (ref) v_u_13, (ref) v_u_16, (copy) v_u_11
	local v103 = v_u_12
	v_u_12 = nil
	local function v104()
		-- upvalues: (ref) v_u_2
		v_u_2:UnbindAction("HushHotwireSpark")
		v_u_2:UnbindAction("HushHotwireExit")
	end
	pcall(v104)
	if v_u_13 and v_u_13.gui then
		local function v105()
			-- upvalues: (ref) v_u_13
			v_u_13.gui:Destroy()
		end
		pcall(v105)
	end
	v_u_13 = nil
	v_u_16 = ""
	if v103 then
		local v106 = v103.onClose
		if type(v106) == "function" then
			local v107 = v103.onClose
			local v108, v109 = pcall(v107, p102 or "closed")
			if not v108 then
				local v110 = v_u_11
				v110.errors = v110.errors + 1
				if v_u_11.errors <= 3 then
					warn("[HotwireUI] " .. "onClose" .. " failed: " .. tostring(v109))
				end
			end
		end
	end
end
function v_u_8.press(_) -- name: press
	-- upvalues: (ref) v_u_12, (copy) v_u_4, (copy) v_u_11, (copy) v_u_7, (copy) v_u_6
	local v111 = v_u_12
	if not v111 then
		return nil
	end
	local v112 = v_u_12
	if v112 then
		v112 = v_u_12.now
	end
	local v113
	if v112 then
		v113 = v112()
	else
		v113 = workspace:GetServerTimeNow()
	end
	local v114 = v_u_4.press(v111.rules, v113)
	local v115 = v_u_11
	v115.presses = v115.presses + 1
	local v116, v117 = v_u_7.flashText(v114)
	if v_u_12 and v116 then
		local v118 = v_u_12
		local v119 = v_u_12
		local v120 = v_u_12
		local v121 = os.clock()
		v118.flashText = v116
		v119.flashKind = v117
		v120.flashAt = v121
	end
	if v114 == "hit" then
		local v122 = v_u_11
		v122.hits = v122.hits + 1
		local v_u_123 = "click"
		local function v124()
			-- upvalues: (ref) v_u_6, (copy) v_u_123
			v_u_6.sound(v_u_123)
		end
		pcall(v124)
	elseif v114 == "miss" then
		local v125 = v_u_11
		v125.misses = v125.misses + 1
		local v_u_126 = "error"
		local function v127()
			-- upvalues: (ref) v_u_6, (copy) v_u_126
			v_u_6.sound(v_u_126)
		end
		pcall(v127)
	end
	if v114 == "hit" or v114 == "miss" then
		local v128 = v111.onPress
		if type(v128) == "function" then
			local v129 = v_u_11
			v129.sent = v129.sent + 1
			local v130 = v111.onPress
			local v131, v132 = pcall(v130, {
				["at"] = v113,
				["res"] = v114
			})
			if not v131 then
				local v133 = v_u_11
				v133.errors = v133.errors + 1
				if v_u_11.errors <= 3 then
					warn("[HotwireUI] " .. "onPress" .. " failed: " .. tostring(v132))
				end
			end
		end
	end
	if v111.rules.done and v111.doneAt == nil then
		v111.doneAt = os.clock()
		if v111.rules.ok then
			local v_u_134 = "confirm"
			local function v135()
				-- upvalues: (ref) v_u_6, (copy) v_u_134
				v_u_6.sound(v_u_134)
			end
			pcall(v135)
		end
	end
	return v114
end
function v_u_8.server(p136) -- name: server
	-- upvalues: (ref) v_u_12, (copy) v_u_4, (copy) v_u_72, (copy) v_u_7, (copy) v_u_8
	if type(p136) == "table" then
		local v137 = p136.kind
		if v137 == "hw_start" then
			local v138 = p136.seed
			if type(v138) == "number" then
				local v139 = p136.startAt
				if type(v139) == "number" and v_u_12 then
					local v140 = v_u_12.spec
					v_u_12.rules = v_u_4.new(p136.seed, p136.startAt, v140)
					v_u_12.doneAt = nil
					v_u_12.flashText = nil
					local v141 = v_u_72
					pcall(v141)
					return
				end
			end
		end
		if v137 == "hw_res" then
			if p136.res == "late" or p136.res == "early" then
				local v142 = p136.res
				local v143, v144 = v_u_7.flashText(v142)
				if v_u_12 and v143 then
					local v145 = v_u_12
					local v146 = v_u_12
					local v147 = v_u_12
					local v148 = os.clock()
					v145.flashText = v143
					v146.flashKind = v144
					v147.flashAt = v148
					return
				end
			end
		elseif v137 == "hw_end" and v_u_12 then
			if p136.ok == true then
				local v149 = v_u_12.rules
				local v150 = v_u_12.rules
				v149.done = true
				v150.ok = true
				v_u_12.doneAt = v_u_12.doneAt or os.clock()
				return
			end
			v_u_8.close("end")
		end
	end
end
function v_u_8.step(_) -- name: step
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) v_u_72, (copy) v_u_11, (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_6, (copy) v_u_8
	local v_u_151 = v_u_12
	if v_u_151 then
		if not v_u_13 then
			local v152 = v_u_72
			local v153, v154 = pcall(v152)
			if not v153 then
				local v155 = v_u_11
				v155.errors = v155.errors + 1
				if v_u_11.errors <= 3 then
					warn("[HotwireUI] " .. "build" .. " failed: " .. tostring(v154))
				end
				return
			end
		end
		local v_u_156 = v_u_13
		if v_u_156 then
			local v157 = v_u_12
			if v157 then
				v157 = v_u_12.now
			end
			local v_u_158
			if v157 then
				v_u_158 = v157()
			else
				v_u_158 = workspace:GetServerTimeNow()
			end
			local v_u_159 = v_u_4.view(v_u_151.rules, v_u_158)
			local v_u_160 = v_u_156.lay
			local function v192()
				-- upvalues: (ref) v_u_7, (copy) v_u_160, (copy) v_u_159, (copy) v_u_156, (ref) v_u_9, (copy) v_u_151, (ref) v_u_10, (ref) v_u_4, (copy) v_u_158, (ref) v_u_6
				local v161 = v_u_7.zoneRect(v_u_160, v_u_159.lo, v_u_159.hi)
				v_u_156.zone.Position = UDim2.fromOffset(v161.x, v161.y)
				v_u_156.zone.Size = UDim2.fromOffset(v161.w, v161.h)
				local v162 = v_u_7.pointerRect(v_u_160, v_u_159.pointer)
				v_u_156.pointer.Position = UDim2.fromOffset(v162.x, v162.y)
				v_u_156.pointer.Size = UDim2.fromOffset(v162.w, v162.h)
				local v163 = v_u_7.timerFill(v_u_160, v_u_159.timeLeft)
				v_u_156.timer.Size = UDim2.fromOffset(v163.w, v163.h)
				v_u_156.count.Text = v_u_7.countText(v_u_159.count, v_u_159.need)
				local v164 = v_u_7.pipStates(v_u_159.count, v_u_159.need)
				for v165, v166 in v_u_156.pips do
					local v167
					if v164[v165] == "done" then
						v167 = v_u_9.success
					else
						v167 = v_u_9.raised
					end
					v166.BackgroundColor3 = v167
				end
				v_u_156.misses.Text = v_u_7.missText(v_u_159.misses)
				local v168, v169
				if os.clock() - v_u_151.flashAt < v_u_10.FLASH_S then
					v168 = v_u_151.flashText
					v169 = v_u_151.flashKind
				else
					v168 = nil
					v169 = nil
				end
				if v168 == nil and v_u_159.state ~= "run" then
					v168, v169 = v_u_7.resultText(v_u_159.state, v_u_4.cooldownLeft(v_u_151.rules, v_u_158))
				end
				v_u_156.message.Text = v168 or ""
				local v170 = v_u_156.message
				local v171
				if v169 == "good" then
					v171 = v_u_9.success
				elseif v169 == "bad" then
					v171 = v_u_9.danger
				else
					v171 = v_u_9.text2
				end
				v170.TextColor3 = v171
				local v172 = os.clock() - v_u_151.flashAt < 0.18
				local v173 = v_u_156.pointer
				local v174
				if v172 and v_u_151.flashKind == "good" then
					v174 = v_u_9.success
				elseif v172 and v_u_151.flashKind == "bad" then
					v174 = v_u_9.danger
				else
					v174 = v_u_9.white
				end
				v173.BackgroundColor3 = v174
				if v_u_156.sparkKey then
					local v175 = v_u_6.hint
					local v176 = v_u_7.ACTION_SPARK
					local v177, v178 = pcall(v175, v176)
					local v179 = v_u_7.sparkKeyText
					local v180 = v_u_6.device()
					if not v177 then
						v178 = nil
					end
					local v181 = v179(v180, v178)
					if v_u_156.sparkKey.Text ~= v181 then
						v_u_156.sparkKey.Text = v181
					end
				end
				if v_u_156.exitKey then
					local v182 = v_u_6.hint
					local v183 = v_u_7.ACTION_EXIT
					local v184, v185 = pcall(v182, v183)
					local v186 = v_u_6.hint
					local v187, v188 = pcall(v186, "interact")
					local v189 = v_u_7.exitKeyText
					local v190 = v_u_6.device()
					if not v184 then
						v185 = nil
					end
					if not v187 then
						v188 = nil
					end
					local v191 = v189(v190, v185, v188)
					if v_u_156.exitKey.Text ~= v191 then
						v_u_156.exitKey.Text = v191
					end
				end
			end
			local v193, v194 = pcall(v192)
			if not v193 then
				local v195 = v_u_11
				v195.errors = v195.errors + 1
				if v_u_11.errors <= 3 then
					warn("[HotwireUI] " .. "step" .. " failed: " .. tostring(v194))
				end
			end
			if v_u_151.rules.done and (v_u_151.rules.ok and (v_u_151.doneAt ~= nil and os.clock() - v_u_151.doneAt >= v_u_10.DONE_S)) then
				v_u_8.close("wired")
			end
		end
	else
		return
	end
end
function v_u_8.view() -- name: view
	-- upvalues: (ref) v_u_12, (copy) v_u_4, (copy) v_u_74
	local v196 = v_u_12
	if v196 then
		return v_u_4.view(v196.rules, v_u_74())
	else
		return nil
	end
end
function v_u_8.stats() -- name: stats
	-- upvalues: (copy) v_u_11, (ref) v_u_12
	return {
		["opened"] = v_u_11.opened,
		["presses"] = v_u_11.presses,
		["sent"] = v_u_11.sent,
		["hits"] = v_u_11.hits,
		["misses"] = v_u_11.misses,
		["rebuilds"] = v_u_11.rebuilds,
		["errors"] = v_u_11.errors,
		["open"] = v_u_12 and 1 or 0
	}
end
v_u_5.scaleChanged:Connect(function()
	-- upvalues: (ref) v_u_12, (copy) v_u_72
	if v_u_12 then
		local v197 = v_u_72
		pcall(v197)
	end
end)
return v_u_8