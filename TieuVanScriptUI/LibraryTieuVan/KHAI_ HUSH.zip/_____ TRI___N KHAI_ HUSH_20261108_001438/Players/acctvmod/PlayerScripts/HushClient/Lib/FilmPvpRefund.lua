-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPvpRefund

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.parseUid(p6) -- name: parseUid
	if type(p6) == "string" then
		local v7 = string.match(p6, "^%s*(%d+)%s*$")
		if v7 == nil or #v7 > 15 then
			return nil
		else
			local v8 = tonumber(v7)
			if v8 == nil or v8 < 1 then
				return nil
			else
				return v8
			end
		end
	else
		return nil
	end
end
function v_u_4.parseDays(p9) -- name: parseDays
	if type(p9) == "string" and not string.match(p9, "^%s*$") then
		local v10 = string.match(p9, "^%s*(%d+)%s*$")
		local v11
		if v10 then
			v11 = tonumber(v10)
		else
			v11 = nil
		end
		if v11 == nil or (v11 < 1 or v11 > 45) then
			return false, nil
		else
			return true, v11
		end
	else
		return true, nil
	end
end
function v_u_4.buildArgs(p12, p13, p14, p15) -- name: buildArgs
	local v16 = {
		["userId"] = p12,
		["execute"] = p14 == true,
		["insured"] = p15 == true
	}
	if p13 ~= nil then
		v16.days = p13
	end
	return v16
end
function v_u_4.clip(p17) -- name: clip
	local v18 = tostring(p17 or "")
	if #v18 > 6000 then
		return string.sub(v18, 1, 6000) .. "\n... cut, the rest is in the server log"
	else
		return v18
	end
end
function v_u_4.mount(p19, p_u_20, p21, p22) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2
	local v23 = type(p22) ~= "table" and {} or p22
	if type(p21) == "table" then
		local v24 = p21.color
		if type(v24) ~= "table" then
			p21 = v_u_3.Theme
		end
	else
		p21 = v_u_3.Theme
	end
	local v_u_25 = p21.color
	local v26 = v23.inner
	local v27 = type(v26) ~= "number" and 438 or v23.inner
	local v28 = v23.gui
	local v_u_29
	if v23.player == nil then
		v_u_29 = v_u_5
	else
		v_u_29 = v23.player
	end
	local v30 = 0
	local v_u_31 = true
	if v28 then
		v28.Destroying:Connect(function()
			-- upvalues: (ref) v_u_31
			v_u_31 = false
		end)
	end
	local v32 = v_u_3.label({
		["parent"] = nil,
		["text"] = "PvP refund  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p19,
		["color"] = v_u_25.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v33 = v23.order
	local v34, v35
	if type(v33) == "function" then
		v34 = v23.order()
		v35 = v30
	else
		v30 = v30 + 1
		v34 = v30
		v35 = v30
	end
	v32.LayoutOrder = v34
	local v36 = v_u_3.label({
		["parent"] = nil,
		["name"] = "RefundNote",
		["text"] = "After HUSHGUARD banned a PvP cheater: type his user id (days: 1 to 45, empty = 30) and press DRY RUN to see the victims and what they lost. EXECUTE puts the recorded losses into each victim\'s gift inbox, once per death. Nothing happens by itself.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p19,
		["color"] = v_u_25.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v37 = v23.order
	local v38
	if type(v37) == "function" then
		v38 = v23.order()
	else
		v30 = v35 + 1
		v38 = v30
		v35 = v30
	end
	v36.LayoutOrder = v38
	local v39 = v_u_3.new
	local v40 = {
		["Name"] = "RefundIdRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v41 = UDim2.new
	local v42 = p21.touch
	v40.Size = v41(1, 0, 0, type(v42) ~= "function" and 36 or p21.touch(36))
	local v43 = v39("Frame", v40, p19)
	local v44 = v23.order
	local v45
	if type(v44) == "function" then
		v45 = v23.order()
	else
		v30 = v35 + 1
		v45 = v30
		v35 = v30
	end
	v43.LayoutOrder = v45
	v_u_3.layout(v43, "h", 6)
	local v46 = (v27 - 6) / 2
	local v47 = math.floor(v46)
	local v48 = v_u_3.input
	local v49 = {
		["parent"] = nil,
		["name"] = "RefundUid",
		["size"] = nil,
		["placeholder"] = "Banned user id",
		["parent"] = v43
	}
	local v50 = UDim2.fromOffset
	local v51 = p21.touch
	v49.size = v50(v47, type(v51) ~= "function" and 36 or p21.touch(36))
	local v52, v_u_53 = v48(v49)
	v52.LayoutOrder = 1
	local v54 = v_u_3.input
	local v55 = {
		["parent"] = nil,
		["name"] = "RefundDays",
		["size"] = nil,
		["placeholder"] = "Days 1 to 45 (empty = 30)",
		["parent"] = v43
	}
	local v56 = UDim2.fromOffset
	local v57 = p21.touch
	v55.size = v56(v47, type(v57) ~= "function" and 36 or p21.touch(36))
	local v58, v_u_59 = v54(v55)
	v58.LayoutOrder = 2
	local v_u_60 = false
	local v62 = {
		["parent"] = nil,
		["name"] = "RefundInsured",
		["label"] = "Include insured items",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = p19,
		["width"] = v27,
		["onChange"] = function(p61) -- name: onChange
			-- upvalues: (ref) v_u_60
			v_u_60 = p61 == true
		end
	}
	local v63, v_u_64 = v_u_3.toggle(v62)
	local v65 = v23.order
	local v66
	if type(v65) == "function" then
		v66 = v23.order()
	else
		v30 = v35 + 1
		v66 = v30
		v35 = v30
	end
	v63.LayoutOrder = v66
	local v67 = v_u_3.new
	local v68 = {
		["Name"] = "RefundButtons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v69 = UDim2.new
	local v70 = p21.touch
	v68.Size = v69(1, 0, 0, type(v70) ~= "function" and 34 or p21.touch(34))
	local v71 = v67("Frame", v68, p19)
	local v72 = v23.order
	local v73
	if type(v72) == "function" then
		v73 = v23.order()
	else
		v30 = v35 + 1
		v73 = v30
		v35 = v30
	end
	v71.LayoutOrder = v73
	v_u_3.layout(v71, "h", 6)
	local v_u_74 = v_u_3.label({
		["parent"] = nil,
		["name"] = "RefundStatus",
		["text"] = "Idle.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p19,
		["color"] = v_u_25.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v75 = v23.order
	local v76
	if type(v75) == "function" then
		v76 = v23.order()
	else
		v30 = v35 + 1
		v76 = v30
		v35 = v30
	end
	v_u_74.LayoutOrder = v76
	local v77 = v_u_3.new("ScrollingFrame", {
		["Name"] = "RefundOut",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollingDirection"] = nil,
		["BackgroundColor3"] = v_u_25.raised,
		["Size"] = UDim2.new(1, 0, 0, 180),
		["CanvasSize"] = UDim2.new(0, 0, 0, 0),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, p19)
	local v78 = v23.order
	local v79
	if type(v78) == "function" then
		v79 = v23.order()
	else
		v30 = v35 + 1
		v79 = v30
	end
	v77.LayoutOrder = v79
	local v_u_80 = v_u_3.label({
		["parent"] = nil,
		["name"] = "RefundText",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v77,
		["color"] = v_u_25.text2,
		["size"] = UDim2.new(1, -8, 0, 0)
	})
	local v_u_81 = false
	local v_u_82 = false
	local v_u_83 = 0
	local v_u_84 = "none"
	local v_u_85 = nil
	local function v_u_101(p_u_86) -- name: run
		-- upvalues: (ref) v_u_81, (copy) p_u_20, (ref) v_u_3, (copy) v_u_74, (copy) v_u_25, (ref) v_u_4, (copy) v_u_53, (copy) v_u_59, (ref) v_u_82, (ref) v_u_83, (ref) v_u_85, (copy) v_u_29, (ref) v_u_84, (ref) v_u_60, (ref) v_u_31, (copy) v_u_80
		if v_u_81 then
			return
		else
			local v87 = p_u_20
			if type(v87) == "function" then
				local v88 = v_u_4.parseUid(v_u_53.Text)
				if v88 == nil then
					v_u_3.setText(v_u_74, "Type the user id of the banned player (digits only).")
					v_u_74.TextColor3 = v_u_25.danger
					return
				else
					local v89, v90 = v_u_4.parseDays(v_u_59.Text)
					if v89 then
						v_u_81 = true
						v_u_82 = false
						v_u_83 = os.clock()
						if v_u_85 then
							local v91 = v_u_85.setText
							if type(v91) == "function" then
								v_u_85.setText("Execute")
							end
						end
						if v_u_29 then
							v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
						end
						v_u_3.setText(v_u_74, p_u_86 and "Delivering ..." or "Reading the kills ...")
						v_u_74.TextColor3 = v_u_25.text2
						if v_u_29 then
							v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
						end
						p_u_20("pvpkills.refund", v_u_4.buildArgs(v88, v90, p_u_86, v_u_60), function(p92)
							-- upvalues: (ref) v_u_81, (ref) v_u_31, (ref) v_u_84, (copy) p_u_86, (ref) v_u_3, (ref) v_u_74, (ref) v_u_25, (ref) v_u_80, (ref) v_u_4, (ref) v_u_29, (ref) v_u_82
							v_u_81 = false
							if v_u_31 then
								if type(p92) == "table" then
									v_u_84 = p92.ok == true and "ok" or "bad"
									local v93
									if p92.ok == true then
										v93 = false
									else
										local v94 = p92.msg
										if type(v94) == "string" then
											local v95 = p92.msg
											v93 = string.sub(v95, 1, 9) == "No answer"
										else
											v93 = false
										end
									end
									local v96
									if p92.ok == true then
										v96 = p_u_86 and "Done." or "Dry run, nothing was changed."
									else
										v96 = v93 and "No answer yet. The server may still be working: wait a minute, then run DRY RUN to see what is done. Do not compensate by hand before that." or "Refused or failed."
									end
									local v97 = p92.ok ~= true
									v_u_3.setText(v_u_74, v96)
									local v98 = v_u_74
									local v99
									if v97 then
										v99 = v_u_25.danger
									else
										v99 = v_u_25.text2
									end
									v98.TextColor3 = v99
									v_u_3.setText(v_u_80, v_u_4.clip(p92.msg))
								else
									v_u_84 = "bad"
									v_u_3.setText(v_u_74, "The server did not answer.")
									v_u_74.TextColor3 = v_u_25.danger
								end
								if v_u_29 then
									v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
								end
							end
						end)
					else
						local v100 = ("Days must be a whole number from 1 to %d, or empty."):format(45)
						v_u_3.setText(v_u_74, v100)
						v_u_74.TextColor3 = v_u_25.danger
					end
				end
			else
				v_u_3.setText(v_u_74, "No connection to the server.")
				v_u_74.TextColor3 = v_u_25.danger
				return
			end
		end
	end
	local function v107() -- name: onExecute
		-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_83, (copy) v_u_101, (ref) v_u_85, (copy) v_u_29, (ref) v_u_84, (ref) v_u_3, (copy) v_u_74, (copy) v_u_25
		if v_u_81 then
			return
		elseif v_u_82 and os.clock() - v_u_83 <= 8 then
			v_u_101(true)
		else
			v_u_82 = true
			v_u_83 = os.clock()
			if v_u_85 then
				local v102 = v_u_85.setText
				if type(v102) == "function" then
					v_u_85.setText("Press again to execute")
				end
			end
			if v_u_29 then
				v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
			end
			local v103, v104 = ("Press EXECUTE again within %d seconds to deliver the items. Run a DRY RUN first."):format(8)
			v_u_3.setText(v_u_74, v103)
			local v105 = v_u_74
			local v106
			if v104 then
				v106 = v_u_25.danger
			else
				v106 = v_u_25.text2
			end
			v105.TextColor3 = v106
		end
	end
	local v108 = v_u_3.button
	local v109 = {
		["parent"] = nil,
		["text"] = "Dry run",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v71
	}
	local v110 = p21.touch
	v109.height = type(v110) ~= "function" and 34 or p21.touch(34)
	v109.width = v47
	v109.maxTextWidth = v47 - 12
	function v109.onClick() -- name: onClick
		-- upvalues: (copy) v_u_101
		v_u_101(false)
	end
	v108(v109).Name = "RefundDry"
	local v111 = v_u_3.button
	local v112 = {
		["parent"] = nil,
		["text"] = "Execute",
		["kind"] = "danger",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v71
	}
	local v113 = p21.touch
	v112.height = type(v113) ~= "function" and 34 or p21.touch(34)
	v112.width = v47
	v112.maxTextWidth = v47 - 12
	v112.onClick = v107
	local v114, v115 = v111(v112)
	v114.Name = "RefundExecute"
	v_u_85 = v115
	task.spawn(function()
		-- upvalues: (ref) v_u_31, (ref) v_u_82, (ref) v_u_83, (ref) v_u_85, (copy) v_u_29, (ref) v_u_81, (ref) v_u_84
		while v_u_31 do
			if v_u_82 and os.clock() - v_u_83 > 8 then
				v_u_82 = false
				v_u_83 = os.clock()
				if v_u_85 then
					local v116 = v_u_85.setText
					if type(v116) == "function" then
						v_u_85.setText("Execute")
					end
				end
				if v_u_29 then
					v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
				end
			end
			task.wait(0.5)
		end
	end)
	if v_u_2:IsStudio() and v_u_29 then
		local v_u_126 = v_u_29:GetAttributeChangedSignal("FilmPvpRefundCmd"):Connect(function()
			-- upvalues: (copy) v_u_29, (copy) v_u_53, (copy) v_u_59, (ref) v_u_60, (copy) v_u_64, (copy) v_u_101, (ref) v_u_81, (ref) v_u_82, (ref) v_u_83, (ref) v_u_85, (ref) v_u_84, (ref) v_u_3, (copy) v_u_74, (copy) v_u_25
			local v117 = v_u_29:GetAttribute("FilmPvpRefundCmd")
			if type(v117) == "string" and v117 ~= "" then
				v_u_29:SetAttribute("FilmPvpRefundCmd", nil)
				local v118, v119 = string.match(v117, "^(%a+)%s*(.-)$")
				if v118 == "uid" then
					v_u_53.Text = v119
					return
				elseif v118 == "days" then
					v_u_59.Text = v119
				elseif v118 == "insured" then
					v_u_60 = v119 == "on"
					if v_u_64 then
						local v120 = v_u_64.set
						if type(v120) == "function" then
							v_u_64.set(v_u_60)
							return
						end
					end
				else
					if v118 == "dry" then
						v_u_101(false)
						return
					end
					if v118 == "execute" then
						if v_u_81 then
							return
						end
						if v_u_82 and os.clock() - v_u_83 <= 8 then
							v_u_101(true)
							return
						end
						v_u_82 = true
						v_u_83 = os.clock()
						if v_u_85 then
							local v121 = v_u_85.setText
							if type(v121) == "function" then
								v_u_85.setText("Press again to execute")
							end
						end
						if v_u_29 then
							v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
						end
						local v122, v123 = ("Press EXECUTE again within %d seconds to deliver the items. Run a DRY RUN first."):format(8)
						v_u_3.setText(v_u_74, v122)
						local v124 = v_u_74
						local v125
						if v123 then
							v125 = v_u_25.danger
						else
							v125 = v_u_25.text2
						end
						v124.TextColor3 = v125
					end
				end
			else
				return
			end
		end)
		if v28 then
			v28.Destroying:Connect(function()
				-- upvalues: (copy) v_u_126
				v_u_126:Disconnect()
			end)
		end
	end
	if v_u_29 then
		v_u_29:SetAttribute("FilmPvpRefund", ("busy=%d|armed=%d|last=%s"):format(v_u_81 and 1 or 0, v_u_82 and 1 or 0, v_u_84))
	end
	return {
		["dry"] = function() -- name: dry
			-- upvalues: (copy) v_u_101
			v_u_101(false)
		end,
		["execute"] = v107,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_31
			return v_u_31
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_60, (ref) v_u_84
			return {
				["busy"] = v_u_81,
				["armed"] = v_u_82,
				["insured"] = v_u_60,
				["last"] = v_u_84
			}
		end
	}
end
return v_u_4