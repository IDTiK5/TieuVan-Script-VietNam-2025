-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimArms

local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = math.rad
function v_u_1.init(p10, p11) -- name: init
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
	v_u_2 = p10
	v_u_3 = p10.lib.AnimFit
	v_u_4 = p10.lib.AnimClassPoses
	v_u_5 = p10.lib.AnimReload
	v_u_6 = p10.lib.AnimMelee
	local v12 = v_u_6.install
	local v13 = p10.lib
	pcall(v12, v13)
	v_u_7 = p10.lib.AnimPoses
	v_u_8 = p11
end
local v_u_14 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_15 = {
	"UpperTorso",
	"LowerTorso",
	"Head",
	"RightUpperLeg",
	"LeftUpperLeg",
	"RightLowerLeg",
	"LeftLowerLeg"
}
local v_u_16 = { "LeftHand" }
local function v_u_23(p17) -- name: dataOf
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_16
	local v18 = v_u_14[p17]
	if not v18 then
		v18 = {
			["sizes"] = nil,
			["weapon"] = nil,
			["info"] = nil,
			["magJoints"] = nil,
			["magBase"] = nil,
			["fitShift"] = 0,
			["lastFit"] = nil,
			["sizes"] = {},
			["magJoints"] = {},
			["magBase"] = {}
		}
		for _, v19 in v_u_15 do
			local v20 = p17.model:FindFirstChild(v19)
			if not (v20 and v20:IsA("BasePart")) then
				continue
			end
			v18.sizes[v19] = v20.Size
		end
		for _, v21 in v_u_16 do
			local v22 = p17.model:FindFirstChild(v21)
			v18.sizes[v21] = not (v22 and v22:IsA("BasePart")) and Vector3.new(1, 0.35, 1) or v22.Size
		end
		v_u_14[p17] = v18
	end
	return v18
end
local function v_u_57(p24, p25, p26) -- name: weaponInfo
	-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) v_u_1
	local v27 = p25.weapon
	if not (v27 and v27.model) then
		p24.weapon = nil
		p24.info = nil
		return nil
	end
	local v28 = v27.model
	local v29 = tonumber(v28:GetAttribute("WeaponScale")) or 1
	if p24.weapon == v27 and (p24.info and (p24.info.wid == p26.wid and (p24.info.holdType == p26.holdType and p24.info.scale == v29))) then
		return p24.info
	end
	local v30 = v27.model
	local v31 = v27.handle
	local v32 = v_u_4.fromModel(v30)
	local v33 = v_u_4.classOf(p26.wid, p26.def, v32)
	if p26.holdType == "melee1h" or p26.holdType == "melee2h" then
		v33 = p26.holdType
	end
	local v34 = {
		["class"] = nil,
		["adj"] = nil,
		["samples"] = nil,
		["mag"] = nil,
		["magRot"] = nil,
		["support"] = nil,
		["scale"] = nil,
		["wid"] = nil,
		["holdType"] = nil,
		["class"] = v33,
		["adj"] = v_u_4.adjOf(p26.wid, v32),
		["samples"] = {},
		["scale"] = v29,
		["wid"] = p26.wid,
		["holdType"] = p26.holdType
	}
	if v31 then
		local v35 = v27.gripInv:Inverse()
		v34.samples = v_u_3.samplesOf(v30, v31, v35)
		if #v34.samples > 0 then
			local v36 = v34.samples[1]
			local v37 = v34.samples[1]
			for _, v38 in v34.samples do
				v36 = v36:Min(v38)
				v37 = v37:Max(v38)
			end
			v34.center = (v36 + v37) * 0.5
		end
		if v27.support then
			v34.support = v27.gripInv * v27.support
		end
		local v39 = p25.model:FindFirstChild("RightHand")
		if v27.relInv and (v39 and v39:IsA("BasePart")) then
			local v40 = v27.gripInv * v27.relInv
			local v41 = v39.Size * 0.5 * (v_u_1.HAND_SAMPLE or 0.82)
			for _, v42 in { -1, 0, 1 } do
				for _, v43 in { -1, 0, 1 } do
					for _, v44 in { -1, 0, 1 } do
						local v45 = v34.samples
						local v46 = v41.X * v42
						local v47 = v41.Y * v43
						local v48 = v41.Z * v44
						local v49 = v40 * Vector3.new(v46, v47, v48)
						table.insert(v45, v49)
					end
				end
			end
		end
		p24.magJoints = {}
		local v50 = Vector3.new(0, 0, 0)
		local v51 = 0
		for _, v52 in v30:GetDescendants() do
			if not v52:IsA("BasePart") then
				continue
			end
			local v53 = v52.Name
			if v53 ~= "Magazine" and string.match(v53, "^Magazine[_%d]") == nil and v53 ~= "MagazineAlt" or v52.Transparency >= 0.95 then
				continue
			end
			local v54 = v27.gripInv * v31.CFrame:ToObjectSpace(v52.CFrame)
			v50 = v50 + v54.Position
			v51 = v51 + 1
			v34.magRot = v34.magRot or v54.Rotation
			for _, v55 in v30:GetDescendants() do
				if not (v55:IsA("Weld") or v55:IsA("Motor6D")) or (v55.Part1 ~= v52 or v55.Name == "WeaponGrip") then
					continue
				end
				local v56 = p24.magJoints
				table.insert(v56, v55)
				if typeof(v55:GetAttribute("AnimBaseC0")) == "CFrame" then
					continue
				end
				v55:SetAttribute("AnimBaseC0", v55.C0)
			end
		end
		if v51 > 0 then
			v34.mag = v50 / v51
		end
	end
	p24.weapon = v27
	p24.info = v34
	p24.warm = nil
	p24.equipAt = p26.now
	return v34
end
local function v_u_61(p58) -- name: restoreMag
	for _, v59 in p58.magJoints do
		local v60 = v59:GetAttribute("AnimBaseC0")
		if not v59.Parent or (typeof(v60) ~= "CFrame" or v59.C0 == v60) then
			continue
		end
		v59.C0 = v60
	end
end
local function v_u_73(p62, p63, p64, p65) -- name: placeRight
	local v66 = p62.rig
	local v67 = p62.weapon
	local v68
	if v67 and (v67.handle and v67.relInv) then
		v68 = p63 * v67.gripInv * v67.relInv
	else
		v68 = p63 * p62.rgaInv
	end
	local v69 = p62.rig.joints.RightWrist
	local v70
	if v69 then
		v70 = (v68 * v69.c1).Position
	else
		v70 = v68.Position
	end
	local v71 = p64 + 0.55
	local v72 = Vector3.new(v71, -1, 0.45)
	if p65 then
		v72 = p65 * v72
	end
	v66:solve2("RightShoulder", "RightElbow", "RightWrist", v70, v72, Vector3.new(0, 0, 1))
	if v66.joints.RightWrist then
		v66:orientEnd("RightWrist", v68)
	end
end
local function v_u_86(p74, p75, p76, p77, p78, p79) -- name: placeLeft
	local v80 = p74.rig
	local v81
	if p78 then
		v81 = CFrame.new(p75) * p76 * CFrame.new(-p74.lgaInv:Inverse().Position)
	else
		v81 = CFrame.new(p75) * p76 * p74.lgaInv
	end
	local v82 = v80.joints.LeftWrist
	local v83
	if v82 then
		v83 = (v81 * v82.c1).Position
	else
		v83 = v81.Position
	end
	local v84 = -0.55 - p77 * 0.5
	local v85 = Vector3.new(v84, -1, 0.35)
	if p79 then
		v85 = p79 * v85
	end
	v80:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v83, v85, Vector3.new(0, 0, 1))
	if v82 then
		v80:orientEnd("LeftWrist", v81)
	end
end
local function v_u_93(p87) -- name: freeLeft
	local v88 = p87.rig
	local v89 = 6.283185307179586 * ((p87.phase + 0.5) % 1)
	local v90 = math.sin(v89) * (0.3 + 0.6 * p87.wSprint) * p87.gw
	local v91 = v90 + 0.1
	local v92 = 0.25 + 1 * p87.wSprint + math.max(0, v90) * 0.2
	v88:setT("LeftShoulder", CFrame.Angles(v91, 0, -0.12))
	v88:setT("LeftElbow", CFrame.Angles(v92, 0, 0))
	if v88.joints.LeftWrist then
		v88:setT("LeftWrist", CFrame.Angles(-0.08, 0, 0))
	end
end
v_u_1.LEFT_SMOOTH = 0.07
v_u_1.LEFT_CARRY = 0.25
function v_u_1.follow(p94, p95, p96, p97, p98) -- name: follow
	local v99 = p94[p95]
	local v100 = p94[p95 .. "V"]
	local v101 = p94[p95 .. "At"]
	if v99 == nil or (v100 == nil or (v101 == nil or p97 - v101 > 0.2)) then
		local v102 = p95 .. "V"
		local v103 = p95 .. "At"
		p94[p95] = p96
		p94[v102] = Vector3.new(0, 0, 0)
		p94[v103] = p97
		return p96
	end
	local v104 = p97 - v101
	local v105 = math.clamp(v104, 0.004166666666666667, 0.1)
	local v106 = 2 / math.max(p98, 0.001)
	local v107 = v106 * v105
	local v108 = 1 / (v107 + 1 + v107 * 0.48 * v107 + v107 * 0.235 * v107 * v107)
	local v109 = v99 - p96
	local v110 = (v100 + v109 * v106) * v105
	local v111 = (v100 - v110 * v106) * v108
	local v112 = p96 + (v109 + v110) * v108
	local v113 = p95 .. "V"
	local v114 = p95 .. "At"
	p94[p95] = v112
	p94[v113] = v111
	p94[v114] = p97
	return v112
end
function v_u_1.tossReset(p115) -- name: tossReset
	-- upvalues: (copy) v_u_14
	local v116 = v_u_14[p115]
	if v116 and v116.tossMotor ~= nil then
		local v117 = v116.tossMotor
		v116.tossMotor = nil
		if v117 and v117.Parent then
			local v118 = v117:GetAttribute("TossBaseC0")
			if typeof(v118) == "CFrame" then
				if v117.C0 ~= v118 then
					v117.C0 = v118
				end
				v117:SetAttribute("TossBaseC0", nil)
			end
		end
	end
end
function v_u_1.tossGuard(p119, p120) -- name: tossGuard
	-- upvalues: (copy) v_u_14
	local v121 = v_u_14[p119]
	if v121 and (v121.tossMotor ~= nil and (p120 == nil or p120.toss == nil)) then
		local v122 = v121.tossMotor
		v121.tossMotor = nil
		if v122 and v122.Parent then
			local v123 = v122:GetAttribute("TossBaseC0")
			if typeof(v123) == "CFrame" then
				if v122.C0 ~= v123 then
					v122.C0 = v123
				end
				v122:SetAttribute("TossBaseC0", nil)
			end
		end
	end
end
local function v_u_145(p124, p125, p126, p127, p128) -- name: tossApply
	local v129 = p124.weapon
	local v130
	if v129 then
		v130 = v129.motor
	else
		v130 = nil
	end
	local v131
	if p127.swing then
		v131 = p127.swing.toss
	else
		v131 = nil
	end
	if p125.tossMotor ~= nil and (v131 == nil or p125.tossMotor ~= v130) then
		local v132 = p125.tossMotor
		p125.tossMotor = nil
		if v132 and v132.Parent then
			local v133 = v132:GetAttribute("TossBaseC0")
			if typeof(v133) == "CFrame" then
				if v132.C0 ~= v133 then
					v132.C0 = v133
				end
				v132:SetAttribute("TossBaseC0", nil)
			end
		end
	end
	if v131 == nil or (v130 == nil or (v130.Parent == nil or (p126 == nil or v129.relInv == nil))) then
		return
	else
		local v134 = p124.model:FindFirstChild("RightHand")
		if v134 ~= nil and v130.Part0 == v134 then
			local v135 = v130:GetAttribute("TossBaseC0")
			if typeof(v135) ~= "CFrame" then
				v135 = v130.C0
				v130:SetAttribute("TossBaseC0", v135)
			end
			p125.tossMotor = v130
			local v136 = p128 * v129.gripInv * v129.relInv
			local v137 = (CFrame.Angles(0, -p127.stanceChest, 0) * p127.chest * CFrame.new(0, p127.bobY, 0)):VectorToWorldSpace(v131.off)
			local v138 = v131.up
			local v139 = v137 + Vector3.new(0, v138, 0)
			local v140 = p126.center or Vector3.new(0, 0, 0)
			local v141 = CFrame.new(v140) * CFrame.Angles(v131.angle, 0, 0) * CFrame.new(-v140)
			local v142 = v129.gripInv:Inverse()
			local v143 = v130.C1
			local v144 = v143:Inverse() * (v142 * v141 * v142:Inverse()) * v143
			v130.C0 = v136:Inverse() * CFrame.new(v139) * v136 * v135 * v144
		end
	end
end
function v_u_1.armed(p146) -- name: armed
	-- upvalues: (copy) v_u_23, (copy) v_u_57, (ref) v_u_4, (ref) v_u_5, (ref) v_u_8, (ref) v_u_3, (copy) v_u_9, (ref) v_u_6, (ref) v_u_2, (copy) v_u_1, (copy) v_u_73, (copy) v_u_145, (copy) v_u_86, (copy) v_u_93, (copy) v_u_61
	local v147 = p146.st
	local v148 = v147.rig
	local v_u_149 = v_u_23(v147)
	local v150 = v_u_57(v_u_149, v147, p146)
	local v151 = p146.holdType
	local v152
	if v150 then
		v152 = v150.class
	elseif v151 == "melee1h" or v151 == "melee2h" then
		v152 = v151
	else
		v152 = v_u_4.classOf(p146.wid, p146.def, nil)
	end
	local v153
	if v150 then
		v153 = v150.adj
	else
		v153 = nil
	end
	local v154
	if p146.gunHold and (v151 ~= "melee1h" and (v151 ~= "melee2h" and (v_u_4.twinName(v152) ~= nil and (v147.model:GetAttribute("TwinPair") == true and v147.model:FindFirstChild("HeldWeapon2") ~= nil)))) then
		v152 = v_u_4.twinName(v152)
		v154 = true
	else
		v154 = false
	end
	local v155 = v_u_4.spec(v152)
	local v156 = v147.rig
	local v157 = v156.bone.RightShoulder
	local v158 = v156.bone.RightElbow
	local v159
	if v157 and v158 then
		v159 = v157 + v158
	else
		v159 = 1.727 * v147.scale
	end
	local v160 = v159 / 1.727
	local v161 = v147.shR
	local v162 = p146.gunHold
	local v163 = v151 == "melee1h" and true or v151 == "melee2h"
	local v164 = p146.now
	local v165 = v_u_4.grip(v152, "ready", v161, v160, v153)
	if v147.wSneak > 0.001 and v_u_4.hasPose(v152, "sneak") then
		v165 = v165:Lerp(v_u_4.grip(v152, "sneak", v161, v160, v153), v147.wSneak)
	end
	local v166 = v147.wAim
	if v153 and (v153.reloadDrop and (v153.reloadDrop > 0 and (v147.reloading and (v162 and not p146.busyAction)))) then
		local v167 = v164 - v147.reloadStart
		local v168
		if v147.reloadSingle > 0 then
			v168 = v167 % v147.reloadSingle / v147.reloadSingle
		else
			local v169 = v147.reloadDur
			local v170 = v167 / math.max(v169, 0.2)
			v168 = math.clamp(v170, 0, 1)
		end
		local v171 = v155.reload.kind
		local v172 = v_u_5.at(v147.reloadSingle > 0 and "single" or (v171 == "rotary" and "rotary" or "mag"), v168)
		local v173 = v147.wAim
		local v174 = v153.reloadDrop
		v166 = v173 * (1 - math.clamp(v174, 0, 1) * v172.tilt)
	end
	local v175 = v165:Lerp(v_u_4.grip(v152, "aim", v161, v160, v153), v166):Lerp(v_u_4.grip(v152, "sprint", v161, v160, v153), v147.wSprint)
	if p146.busyAction then
		if v_u_4.hasPose(v152, "busy") then
			v175 = v_u_4.grip(v152, "busy", v161, v160, v153)
		else
			v175 = v165 * CFrame.new(0, v160 * -0.1, v160 * 0.1) * CFrame.Angles(-0.35, 0, 0)
		end
	end
	local v176 = v_u_4.twoHanded(v152, v147.wAim > 0.5 and "aim" or (v147.wSprint > 0.5 and "sprint" or "ready"))
	if v163 then
		v176 = v151 == "melee2h"
	end
	local v177 = v155.equip
	if v177 and (v162 and (v_u_149.equipAt and not (p146.busyAction or v163))) then
		local v178 = (v164 - v_u_149.equipAt) / v177.dur
		if v178 >= 0 and v178 < 1 then
			v175 = v_u_4.gripOf(v177.from, v161, v160, v153):Lerp(v175, v_u_8.smooth(v178))
		end
	end
	local v179 = false
	local v_u_180 = v147.rig
	local v183 = v_u_3.boxesOf(function(p181)
		-- upvalues: (copy) v_u_149
		return v_u_149.sizes[p181]
	end, function(p182)
		-- upvalues: (copy) v_u_180
		return v_u_180.part[p182]
	end, 0.04)
	if p146.extraBoxes then
		for v184, v185 in p146.extraBoxes do
			if v185.cf == nil or v185.half == nil then
				if v185.c == nil or v185.s == nil then
					continue
				end
				local v186 = CFrame.new(v185.c.X or v185.c[1], v185.c.Y or v185.c[2], v185.c.Z or v185.c[3]) * CFrame.Angles(0, v_u_9(v185.yaw or 0), 0)
				local v187 = v185.s
				local v188 = {
					["name"] = nil,
					["cf"] = nil,
					["inv"] = nil,
					["half"] = nil,
					["group"] = "vehicle",
					["name"] = "Veh" .. v184,
					["cf"] = v186,
					["inv"] = v186:Inverse()
				}
				local v189 = (v187.X or v187[1]) * 0.5
				local v190 = (v187.Y or v187[2]) * 0.5
				local v191 = (v187.Z or v187[3]) * 0.5
				v188.half = Vector3.new(v189, v190, v191)
				table.insert(v183, v188)
			else
				local v192 = {
					["name"] = v185.name or "Veh" .. v184,
					["cf"] = v185.cf,
					["inv"] = v185.inv or v185.cf:Inverse(),
					["half"] = v185.half,
					["group"] = v185.group or "vehicle"
				}
				table.insert(v183, v192)
			end
		end
	end
	if p146.swing then
		local v193 = p146.swing
		local v194 = v_u_6.grip(v193, v161)
		local v195 = v_u_8.smooth(v193.t / 0.05)
		local v196 = 1 - v_u_8.smooth((v193.t - (p146.swingDur - 0.06)) / 0.06)
		v175 = v175:Lerp(v194, (math.min(v195, v196)))
		v179 = true
	elseif p146.bashing then
		local v197 = p146.bashU * v_u_6.BASH_DUR
		local function v198()
			-- upvalues: (ref) v_u_2
			return v_u_2.shared.Weapons
		end
		local v199, v200 = pcall(v198)
		local v201 = v_u_6.bashSample
		if not v199 then
			v200 = nil
		end
		local v202 = v201(v151, v197, v160, v200)
		local v203 = v_u_8.smooth(v197 / 0.07)
		local v204 = 1 - v_u_8.smooth((v197 - (v_u_6.BASH_DUR - 0.12)) / 0.12)
		local v205 = v_u_6.grip(v202, v161)
		local v206 = v153 and v153.bashRam or v155.bashRam
		if v206 and (v206 > 0 and v162) then
			local v207 = 0.12
			local function v208()
				-- upvalues: (ref) v_u_2
				return v_u_2.shared.Weapons.SHOVE.meleeWindup
			end
			local v209, v210 = pcall(v208)
			if v209 then
				if type(v210) ~= "number" then
					v210 = v207
				end
			else
				v210 = v207
			end
			local v211 = v197 / v210
			local v212
			if v211 < 0.5 then
				v212 = -0.45 * v_u_8.smooth(v211 / 0.5)
			elseif v211 < 1 then
				v212 = -0.45 + 1.45 * v_u_8.smooth((v211 - 0.5) / 0.5)
			else
				local v213 = v_u_8.smooth
				local v214 = v197 - v210
				local v215 = v_u_6.BASH_DUR - v210
				v212 = 1 - v213(v214 / math.max(v215, 0.05))
			end
			v205 = v_u_4.grip(v152, "aim", v161, v160, v153) * CFrame.new(0, 0, -v206 * v160 * v212)
		end
		if v153 and v153.bash then
			v205 = v205 + v153.bash * v160
		end
		if v153 and v153.bashRoll then
			v205 = v205 * CFrame.Angles(0, 0, (v_u_9(v153.bashRoll)))
		end
		v175 = v175:Lerp(v205, (math.min(v203, v204)))
		v179 = true
	end
	local v216 = p146.sway
	if v216 ~= nil and (v163 and not (v179 or p146.busyAction)) then
		v175 = v175 * CFrame.new(v216.x * v160, v216.y * v160, v216.z * v160) * CFrame.Angles(v_u_9(v216.pitch), 0, (v_u_9(v216.roll)))
	end
	local v217 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0) * v175
	local v218
	if v162 then
		local v219 = v147.wAim
		local v220 = v147.wSneak
		v218 = math.max(v219, v220)
	else
		v218 = 0
	end
	if v218 > 0 and not v179 then
		local v221 = v217.LookVector
		local v222 = v221.X
		local v223 = v221.Z
		local v224 = Vector3.new(v222, 0, v223)
		if v224.Magnitude > 0.2 then
			v217 = v217:Lerp(CFrame.lookAt(v217.Position, v217.Position + v224.Unit), v218 * 0.85)
		end
	end
	if v147.kick > 0.001 then
		local v225 = v147.kick * v147.kickScale
		v217 = v217 * CFrame.new(0.02 * v225, 0.05 * v225, 0.26 * v225) * CFrame.Angles(0.19198621771937624 * v225, 0.03490658503988659 * v225, 0)
	end
	local v226 = p146.poleRot
	local v227 = p146.aimYawRes
	if v227 == nil and (p146.aimYawAbs ~= nil and (v162 and not v179)) then
		local v228 = v217.LookVector
		local v229 = -v228.X
		local v230 = -v228.Z
		local v231 = math.atan2(v229, v230)
		v227 = (p146.aimYawAbs - v231 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v232 = p146.yawCap
		if v232 then
			local v233 = -v232
			v227 = math.clamp(v227, v233, v232)
		end
	end
	if v227 ~= nil and (v227 ~= 0 and (v162 and not v179)) then
		local v234 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0)
		v217 = v_u_1.yawGrip(v217, v234 * v161, v227)
	end
	if p146.aimPitchAbs ~= nil and (v162 and not v179) then
		local v235 = v217.LookVector
		local v236 = v235.Y
		local v237 = v235.X * v235.X + v235.Z * v235.Z
		local v238 = math.sqrt(v237)
		local v239 = math.atan2(v236, v238)
		local v240 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0)
		local v241 = v_u_1.pitchGrip
		local v242 = v240 * v161
		local v243 = p146.aimPitchAbs - v239
		v217 = v241(v217, v242, (math.clamp(v243, -1.45, 1.45)))
	end
	if v226 == nil and (v227 ~= nil or p146.aimYawAbs ~= nil) then
		local v244 = v217.LookVector
		local v245 = CFrame.Angles
		local v246 = -v244.X
		local v247 = -v244.Z
		v226 = v245(0, math.atan2(v246, v247), 0)
	end
	if p146.aimPitch and (p146.aimPitch ~= 0 and (v162 and not v179)) then
		local _, _, v248 = v_u_1.pitchSplit(p146.aimPitch, v218)
		local v249 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0)
		v217 = v_u_1.pitchGrip(v217, v249 * v161, v248)
	end
	if v155.sway and (v162 and (not v179 and v147.gw > 0.01)) then
		local v250 = v155.sway * v147.gw * (1 - 0.45 * v147.wAim)
		local v251 = v147.phase
		local v252 = CFrame.new
		local v253 = 6.283185307179586 * (v251 - 0.2)
		local v254 = math.sin(v253) * 0.07 * v250 * v160
		local v255 = 6.283185307179586 * (v251 - 0.1)
		local v256 = math.sin(v255)
		local v257 = v217 * v252(v254, -math.abs(v256) * 0.06 * v250 * v160, 0)
		local v258 = CFrame.Angles
		local v259 = 6.283185307179586 * (v251 - 0.25)
		v217 = v257 * v258(0, 0, math.sin(v259) * 0.06 * v250)
	end
	local v260 = not v150 and 1 or v150.scale
	local v261, v262
	if v147.reloading and (v162 and not p146.busyAction) then
		local v263 = v164 - v147.reloadStart
		if v147.reloadSingle > 0 then
			v261 = v263 % v147.reloadSingle / v147.reloadSingle
		else
			local v264 = v147.reloadDur
			local v265 = v263 / math.max(v264, 0.2)
			v261 = math.clamp(v265, 0, 1)
		end
		local v266 = v155.reload
		v262 = v_u_5.at(v147.reloadSingle > 0 and "single" or (v266.kind == "rotary" and "rotary" or "mag"), v261)
		local v267 = v262.tilt
		local v268 = v153 and (v153.reload or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0)
		v217 = v217 * CFrame.new(v266.shift * v260 * v267) * CFrame.Angles(v_u_9(v266.tilt.pitch + v268.X) * v267, v_u_9(v266.tilt.yaw + v268.Y) * v267, v_u_9(v266.tilt.roll + v268.Z) * v267)
		if v266.kind == "rotary" and (v261 > 0.2 and v261 < 0.8) then
			local v269 = 12.566370614359172 * (v261 - 0.2) / 0.6
			local v270 = math.sin(v269) * 0.06 * v260
			v217 = v217 * CFrame.new(0, v270, 0) * CFrame.Angles(v270 * 0.5, 0, 0)
		end
	else
		v261 = 0
		v262 = nil
	end
	local v271 = p146.bashing
	if v271 then
		v271 = v_u_6.bashStyleOf(v151) == "whip"
	end
	if v176 then
		if v179 then
			local v272 = v151 == "melee1h"
		end
		v176 = not (v272 or v271)
		if v176 then
			v176 = not p146.oneHand
		end
	end
	local v273 = v148:pivot("LeftShoulder").Position
	local v274 = v147.rig
	local v275 = v274.bone.LeftShoulder
	local v276 = v274.bone.LeftElbow
	local v277
	if v275 and v276 then
		v277 = v275 + v276
	else
		v277 = 1.727 * v147.scale
	end
	local v278 = v150 and v150.support and v150.support.Position or v_u_4.supportFallback(v152) * v160 * (v163 and 1 or math.max(v260, 1))
	if v153 and v153.support then
		v278 = v278 + v153.support
	end
	local v279 = v153 and v153.slide or 1
	local v280 = v_u_4.leftRoll(v152)
	local v281
	if v176 then
		v281 = math.min(1, v279)
		local v282 = v277 * 0.985 + (v163 and 0.15 or 0.35)
		if v163 then
			local v283 = v217.Position
			local v284 = v217.Rotation * v278
			local v285 = v283 - v273
			local v286 = v284:Dot(v284)
			local v287 = 2 * v285:Dot(v284)
			local v288 = v285:Dot(v285) - v282 * v282
			local v289 = v287 * v287 - 4 * v286 * v288
			if v286 > 1e-9 then
				local v290 = -v287 / (2 * v286)
				if v289 >= 0 then
					local v291 = math.sqrt(v289)
					local v292 = (-v287 - v291) / (2 * v286)
					local v293 = (-v287 + v291) / (2 * v286)
					v290 = math.min(v281, v293)
					if v292 > v290 then
						v290 = v281
					end
				end
				local v294 = math.max(v281, 0.15)
				v281 = math.clamp(v290, 0.15, v294)
			end
		else
			for _ = 1, 8 do
				if ((v217 * CFrame.new(v278 * v281)).Position - v273).Magnitude <= v282 or v281 <= 0.15 then
					break
				end
				v281 = v281 - 0.12
			end
			v281 = math.max(v281, 0.15)
		end
	else
		v281 = 1
	end
	local v295 = nil
	local v296
	if v150 and #v150.samples > 0 then
		local v297 = v148.joints.RightWrist
		local v298 = not (v147.weapon and (v147.weapon.relInv and v297)) and Vector3.new(0, 0, 0) or (v147.weapon.gripInv * v147.weapon.relInv * v297.c1).Position
		local v299 = {
			["shoulderR"] = nil,
			["reachR"] = nil,
			["gripOffset"] = nil,
			["maxShift"] = nil,
			["margin"] = 0.03,
			["shoulderR"] = v148:pivot("RightShoulder").Position
		}
		local v300 = v147.rig
		local v301 = v300.bone.RightShoulder
		local v302 = v300.bone.RightElbow
		local v303
		if v301 and v302 then
			v303 = v301 + v302
		else
			v303 = 1.727 * v147.scale
		end
		v299.reachR = v303 * 0.985
		v299.gripOffset = v298
		v299.maxShift = v155.maxShift * v160
		local v304 = nil
		if v154 then
			v304 = nil
		elseif v262 then
			local v305 = v155.reload
			local v306
			if v262.t < 0.5 then
				v306 = v262.from
			else
				v306 = v262.to
			end
			if v306 == "support" then
				v304 = v278 * v281
			elseif v306 == "mag" then
				if v150.mag then
					v304 = v150.mag
				else
					v304 = (v305.magWell or Vector3.new(0, -0.35, -0.2)) * v260
				end
			elseif v306 == "port" then
				v304 = (v305.port or Vector3.new(0, -0.3, -0.45)) * v260
			end
		elseif v176 then
			v304 = v278 * v281
		end
		local v307 = v150.samples
		if v304 then
			v299.shoulderL = v273
			v299.reachL = v277 * 0.985 + 0.35
			v299.support = v304
			v307 = table.clone(v150.samples)
			local v308 = CFrame.new(v304) * v280 * v147.lgaInv
			local v309 = v_u_149.sizes.LeftHand * 0.5 * (v_u_1.HAND_SAMPLE_L or 0.85)
			for _, v310 in { -1, 0, 1 } do
				for _, v311 in { -1, 0, 1 } do
					for _, v312 in { -1, 0, 1 } do
						local v313 = v309.X * v310
						local v314 = v309.Y * v311
						local v315 = v309.Z * v312
						local v316 = v308 * Vector3.new(v313, v314, v315)
						table.insert(v307, v316)
					end
				end
			end
		end
		v296 = v217 + (v_u_149.warm or Vector3.new(0, 0, 0)) * 0.9
		if v_u_3.worst(v296, v307, v183) > v_u_3.TOLERANCE or (v296 * v298 - v299.shoulderR).Magnitude > v299.reachR + 0.01 then
			v299.start = v296
			local v317, v318 = v_u_3.fit(v217, v307, v183, v299)
			if v318.depth > 0.05 then
				v299.start = nil
				v296, v295 = v_u_3.fit(v217, v307, v183, v299)
				if v295.depth >= v318.depth - 0.01 then
					v296 = v317
					v295 = v318
				end
			else
				v296 = v317
				v295 = v318
			end
			v295.n = #v307
			v295.slide = v281
			v295.sup = (v299.support or Vector3.new(0, 0, 0)).Magnitude
		end
		v_u_149.warm = v296.Position - v217.Position
	else
		v296 = v217
	end
	local v319 = v147.wAim > 0.5 and v151 ~= "pistol" and 0.35 or 0
	v_u_73(v147, v296, v319, v226)
	v_u_145(v147, v_u_149, v150, p146, v296)
	local v320 = nil
	local v321 = v296.Rotation
	local v322 = false
	if p146.busyAction and p146.handsAction then
		v320 = v_u_3.pushOut(p146.handsAction[2], v183, 0.55)
	elseif v154 then
		local v323 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0)
		local v324 = v_u_4.mirrorGrip(v323, v296, (v147.shR.X + v147.shL.X) * 0.5)
		v320 = v324.Position
		v321 = v324.Rotation
	elseif v262 then
		local v325 = v155.reload
		local v326 = p146.chest
		local v327 = v160 * -0.4
		local v328 = v160 * -0.15
		local v329 = v160 * -1.05
		local v330 = v326 * Vector3.new(v327, v328, v329)
		local v331 = {
			["support"] = (v296 * CFrame.new(v278 * v281)).Position
		}
		local v332
		if v150 and v150.mag then
			v332 = v150.mag
		else
			v332 = (v325.magWell or Vector3.new(0, -0.35, -0.2)) * v260
		end
		v331.mag = v296 * v332
		v331.pouch = v330
		v331.port = v296 * ((v325.port or Vector3.new(0, -0.3, -0.45)) * v260)
		local v333 = v331[v262.from]:Lerp(v331[v262.to], v262.t)
		v320 = v_u_3.pushOut(v333, v183, v262.magInHand and 0.7 or 0.62)
		v321 = v296.Rotation * v_u_4.leftRoll(v152) * CFrame.Angles(0, 0, 0)
		v322 = v262.magInHand
	elseif v176 then
		v320 = (v296 * CFrame.new(v278 * v281)).Position
		v321 = v296.Rotation * v280
	end
	if v320 then
		local v334 = false
		if v176 and (v163 and (v147.weapon and v147.weapon.wrapped)) then
			local v335 = v296.LookVector
			local v336 = v148:pivot("LeftShoulder").Position - v320
			local v337 = v336 - v335 * v336:Dot(v335)
			if v337.Magnitude > 0.001 then
				local v338 = v337.Unit
				local v339 = -v335
				v321 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v338:Cross(v339), v338, v339)
				v334 = true
			end
		end
		v_u_86(v147, v320, v321, v319, v334, v226)
	else
		v_u_93(v147)
		local v340
		if p146.swing then
			v340 = p146.swing.left
		else
			v340 = nil
		end
		if v340 and (v179 and v151 == "melee1h") then
			local v341 = p146.swing
			local v342 = v_u_8.smooth(v341.t / 0.05)
			local v343 = 1 - v_u_8.smooth((v341.t - (p146.swingDur - 0.06)) / 0.06)
			local v344 = math.min(v342, v343)
			local v345 = v148:pivot("LeftWrist").Position
			local v346 = CFrame.Angles(0, -p146.stanceChest, 0) * p146.chest * CFrame.new(0, p146.bobY, 0)
			local v347 = v_u_3.pushOutRadial(v346 * (v147.shL + v340), v183, 0.55)
			local v348 = v_u_1.follow(v_u_149, "leftFree", v345:Lerp(v347, (math.clamp(v344, 0, 1))), v164, v_u_1.LEFT_SMOOTH)
			local v349 = -0.55 - v319 * 0.5
			v148:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v348, Vector3.new(v349, -1, 0.35), Vector3.new(0, 0, 1))
			v_u_149.leftSwingEnd = v164
		elseif v_u_149.leftSwingEnd == nil or (v_u_149.leftFree == nil or v164 - v_u_149.leftSwingEnd > v_u_1.LEFT_CARRY) then
			v_u_149.leftFree = nil
			v_u_149.leftSwingEnd = nil
		else
			local v350 = (v164 - v_u_149.leftSwingEnd) / v_u_1.LEFT_CARRY
			local v351 = math.clamp(v350, 0, 1)
			local v352 = v148:pivot("LeftWrist").Position
			local v353 = v_u_1.follow
			local v354 = v_u_1.LEFT_SMOOTH * (1 - v351)
			local v355 = v353(v_u_149, "leftFree", v352, v164, (math.max(v354, 0.015)))
			local v356 = -0.55 - v319 * 0.5
			v148:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v355, Vector3.new(v356, -1, 0.35), Vector3.new(0, 0, 1))
		end
	end
	local v357 = p146.leftPlant
	if v357 ~= nil and (v357.pos ~= nil and ((v357.w or 0) > 0.001 and v148.joints.LeftWrist)) then
		local v358 = v357.w
		local v359 = math.clamp(v358, 0, 1)
		local v360 = v148:pivot("LeftWrist").Position
		local v361 = -0.55 - v319 * 0.5
		local v362 = Vector3.new(v361, -1, 0.35)
		if v226 then
			v362 = v226 * v362
		end
		local v363 = v148:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v360:Lerp(v357.pos, v359), v362, Vector3.new(0, 0, 1))
		if type(v363) == "number" and v363 > 1.02 then
			local v364 = 1 - (v363 - 1.02) * 2.5
			local v365 = math.clamp(v364, 0, 1)
			v148:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v360:Lerp(v357.pos, v359 * v365), v362, Vector3.new(0, 0, 1))
		end
	end
	if #v_u_149.magJoints > 0 then
		local v366
		if v262 and (v155.reload.kind == "rotary" and (v261 > 0.22 and v261 < 0.78)) then
			local v367 = Vector3.new(0.6, -0.1, 0) * v260
			local v368 = 3.141592653589793 * (v261 - 0.22) / 0.56
			v366 = v367 * math.sin(v368)
		else
			v366 = nil
		end
		if v366 then
			for _, v369 in v_u_149.magJoints do
				local v370 = v369:GetAttribute("AnimBaseC0")
				if not v369.Parent or typeof(v370) ~= "CFrame" then
					continue
				end
				v369.C0 = CFrame.new(v366) * v370
			end
		elseif v322 and (v320 and (v147.weapon and v147.weapon.handle)) then
			local v371 = v296 * v147.weapon.gripInv
			local v372 = CFrame.new(v320)
			local v373
			if v150.magRot then
				v373 = v296.Rotation * v150.magRot
			else
				v373 = v296.Rotation
			end
			local v374 = v372 * v373
			for _, v375 in v_u_149.magJoints do
				local v376 = v375:GetAttribute("AnimBaseC0")
				if not v375.Parent or (not v375.Part1 or typeof(v376) ~= "CFrame") then
					continue
				end
				v375.C0 = v371:Inverse() * v374 * v375.C1
			end
		else
			v_u_61(v_u_149)
		end
	end
	v_u_149.lastFit = v295
	v_u_149.lastLeft = v320
	v_u_149.lastStep = v262
end
local v_u_377 = {}
function v_u_1.stance(p378, p379) -- name: stance
	-- upvalues: (copy) v_u_377, (ref) v_u_4
	local v380 = p378 or ""
	local v381 = "|"
	local v382
	if p379 then
		v382 = p379.class
	else
		v382 = p379
	end
	local v383 = v380 .. v381 .. tostring(v382)
	local v384 = v_u_377[v383]
	if not v384 then
		local v385 = v_u_4.spec(v_u_4.classOf(p378, p379, nil))
		v384 = { v385.stance.aim, v385.stance.ready }
		v_u_377[v383] = v384
	end
	return v384[1], v384[2]
end
v_u_1.stanceCache = v_u_377
function v_u_1.lastFit(p386) -- name: lastFit
	-- upvalues: (copy) v_u_14
	local v387 = v_u_14[p386]
	if v387 then
		v387 = v387.lastFit
	end
	return v387
end
function v_u_1.lastLeft(p388) -- name: lastLeft
	-- upvalues: (copy) v_u_14
	local v389 = v_u_14[p388]
	local v390
	if v389 then
		v390 = v389.lastLeft
	else
		v390 = v389
	end
	if v389 then
		v389 = v389.lastStep
	end
	return v390, v389
end
function v_u_1.heavy(p391) -- name: heavy
	-- upvalues: (copy) v_u_14, (ref) v_u_4
	local v392 = v_u_14[p391]
	if v392 then
		v392 = v392.info
	end
	return v392 and (v_u_4.spec(v392.class).sway or 0) or 0
end
function v_u_1.pitchSplit(p393, p394) -- name: pitchSplit
	local v395 = math.clamp(p393, -1.45, 1.45)
	local v396 = v395 * 0.35
	local v397 = math.clamp(v396, -0.5, 0.5)
	local v398 = v395 * 0.4
	local v399 = math.clamp(v398, -0.6, 0.6)
	local v400 = v395 - v397 * (1 - math.clamp(p394, 0, 1) * 0.85)
	return v397, v399, math.clamp(v400, -1.45, 1.45)
end
function v_u_1.pitchGrip(p401, p402, p403) -- name: pitchGrip
	local v404 = p401.LookVector
	local v405 = v404.X
	local v406 = v404.Z
	local v407 = Vector3.new(v405, 0, v406)
	local v408 = v407.Magnitude <= 0.2 and Vector3.new(1, 0, 0) or v407.Unit:Cross(Vector3.new(0, 1, 0))
	return CFrame.new(p402) * CFrame.fromAxisAngle(v408, p403) * CFrame.new(-p402) * p401
end
function v_u_1.yawGrip(p409, p410, p411) -- name: yawGrip
	return CFrame.new(p410) * CFrame.Angles(0, p411, 0) * CFrame.new(-p410) * p409
end
function v_u_1.release(p412) -- name: release
	-- upvalues: (copy) v_u_14, (copy) v_u_61
	local v413 = v_u_14[p412]
	if v413 then
		local v414 = v413.tossMotor
		v413.tossMotor = nil
		if v414 and v414.Parent then
			local v415 = v414:GetAttribute("TossBaseC0")
			if typeof(v415) == "CFrame" then
				if v414.C0 ~= v415 then
					v414.C0 = v415
				end
				v414:SetAttribute("TossBaseC0", nil)
			end
		end
		v_u_61(v413)
		v_u_14[p412] = nil
	end
end
return v_u_1