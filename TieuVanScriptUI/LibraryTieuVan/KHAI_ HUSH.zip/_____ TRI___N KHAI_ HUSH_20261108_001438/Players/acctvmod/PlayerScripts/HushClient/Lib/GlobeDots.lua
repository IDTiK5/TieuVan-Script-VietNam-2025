-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GlobeDots

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("Theme"))
local v_u_5 = require(v3:WaitForChild("GlobeMath"))
local v_u_6 = require(v3:WaitForChild("GlobeLattice"))
local v_u_7 = require(v3:WaitForChild("GlobeGov"))
local v_u_8 = require(v3:WaitForChild("GlobeLand"))
local v_u_9 = nil
local function v10()
	-- upvalues: (ref) v_u_9
	v_u_9 = require(script.Parent:WaitForChild("HushUI", 5))
end
pcall(v10)
local v_u_11 = v_u_5.CONST
local v_u_12 = math.floor
local v_u_13 = math.max
local v_u_14 = math.min
local v_u_15 = math.sqrt
local v_u_16 = math.abs
local v_u_17 = os.clock
local _ = v_u_6.horizonKeeps
local v_u_18 = { 0.5714285714285714, 0.7142857142857143, 0.8571428571428571 }
local v_u_19 = v_u_6.TUNING
local v_u_20 = {
	["TUNING"] = {
		["P0_DEG"] = 2.5,
		["C0_DEG"] = 2.8,
		["SETS_PER_FRAME"] = {
			["high"] = 250,
			["mid"] = 250,
			["low"] = 150,
			["mini"] = 150
		},
		["CREATE_MS"] = {
			["high"] = 3,
			["mid"] = 3,
			["low"] = 2,
			["mini"] = 2
		},
		["BUILD_MS"] = {
			["high"] = 2.5,
			["mid"] = 2.5,
			["low"] = 1,
			["mini"] = 2.5
		},
		["BUILD_FIRST_MS"] = 6,
		["CHUNK"] = 256,
		["WORLD_STEP_MS"] = 8,
		["ATTACH_FRAMES"] = 300,
		["ATTACH_WORLD_MS"] = 9,
		["PRE_FRAMES"] = 1200,
		["FIRST_FRAMES"] = 700,
		["COARSE_FIRST_MAX"] = 1200,
		["COARSE_FIRST_GOAL"] = 800,
		["SIZE_FILL"] = { 4, 3 },
		["SIZE_CONTOUR"] = { 3, 2 },
		["MIN_REAL_PX"] = 2,
		["BAND2_ALPHA"] = 0.3,
		["BAND2_MIX"] = 0.38,
		["APPEAR_ALPHA"] = 0.6,
		["APPEAR_S"] = 0.07,
		["RETURN_S"] = 0.12,
		["SLEEP_S"] = 0.25,
		["POOL_FACTOR"] = 1.1,
		["POOL_PLUS"] = 200,
		["TRIM_MAX"] = 100,
		["RESERVE"] = 80,
		["HARD_FACTOR"] = 1.25,
		["MOVE_SCALE"] = 0.7,
		["CAL_SETS"] = 300,
		["CAL_RUNS"] = 4,
		["CAL_FACTOR"] = 3,
		["CAL_AFTER_FRAMES"] = 6,
		["PHASE_FRAMES"] = 30,
		["PHASE_SKIP"] = 3,
		["PHASE_A_MIN"] = 10,
		["PHONE_FILL_MIN_ZOOM"] = 2,
		["MINI_CAP"] = 300,
		["buildDelay"] = 0,
		["METER"] = 240,
		["MIN_STEP_MS"] = {
			["high"] = 0,
			["mid"] = 0,
			["low"] = 25,
			["mini"] = 0
		},
		["DENSITY_MIN"] = 50,
		["FLOOR_MAJOR_DEG"] = 60
	}
}
local v_u_21 = v_u_20.TUNING
local v_u_22 = {
	["high"] = "pc",
	["mid"] = "tablet",
	["low"] = "phone",
	["mini"] = "phone"
}
local v_u_23 = { 1000, 1000 }
local v_u_24 = 0
function v_u_20.connCount() -- name: connCount
	-- upvalues: (ref) v_u_24
	return v_u_24
end
local function v_u_29(p25) -- name: newFrame
	-- upvalues: (copy) v_u_21
	local v26 = Instance.new("Frame")
	v26.BorderSizePixel = 0
	v26.Active = false
	v26.Selectable = false
	v26.Interactable = false
	v26.Visible = false
	local v27 = p25.chunk
	if not v27 or p25.chunkN >= v_u_21.CHUNK then
		v27 = Instance.new("Folder")
		v27.Name = "c"
		v27.Parent = p25.layer
		p25.chunk = v27
		p25.chunkN = 0
	end
	p25.chunkN = p25.chunkN + 1
	v26.Parent = v27
	p25.frames[v26] = true
	p25.total = p25.total + 1
	local v28 = p25.free[1]
	v28.n = v28.n + 1
	v28[v28.n] = v26
	p25.nFree = p25.nFree + 1
	return v26
end
local function v_u_44(p30, p31, p32, p33, p34) -- name: acquire
	-- upvalues: (copy) v_u_21
	local v35 = p30.free[p31]
	local v36 = nil
	if v35.n > 0 then
		v36 = v35[v35.n]
		v35[v35.n] = nil
		v35.n = v35.n - 1
	else
		local v37 = p30.free[3 - p31]
		if v37.n > 0 then
			v36 = v37[v37.n]
			v37[v37.n] = nil
			v37.n = v37.n - 1
		end
	end
	if not v36 then
		return nil
	end
	p30.nFree = p30.nFree - 1
	v36.BackgroundColor3 = p30.col[p33][p31]
	v36.Size = p30.ud[p32][p31]
	if p34 then
		v36.BackgroundTransparency = v_u_21.APPEAR_ALPHA
		local v38 = p30.apN + 1
		p30.apN = v38
		local v39 = p30.apF
		local v40 = p30.apT
		local v41 = p30.apA
		local v42 = p30.now
		local v43 = p31 ~= 2 and 0 or v_u_21.BAND2_ALPHA
		v39[v38] = v36
		v40[v38] = v42
		v41[v38] = v43
		p30.apOf[v36] = v38
	else
		v36.BackgroundTransparency = p31 ~= 2 and 0 or v_u_21.BAND2_ALPHA
	end
	v36.Visible = true
	return v36
end
local function v_u_47(p45) -- name: mkLayer
	local v46 = p45.n
	return {
		["win"] = nil,
		["slot"] = nil,
		["pos"] = nil,
		["st"] = nil,
		["dlo"] = nil,
		["dhi"] = nil,
		["hk"] = nil,
		["sig"] = "",
		["win"] = p45,
		["slot"] = table.create(v46, false),
		["pos"] = table.create(v46, 0),
		["st"] = table.create(v46, 16),
		["dlo"] = table.create(v46, 2),
		["dhi"] = table.create(v46, -1),
		["hk"] = table.create(v46, 0)
	}
end
local function v_u_56(p48) -- name: buildHeld
	local v49 = {}
	local v50 = {}
	for _, v51 in p48 do
		local v52 = v51.slot
		local v53 = v51.win.key
		for v54 = 1, v51.win.n do
			if not v52[v54] then
				continue
			end
			local v55 = v53[v54]
			v49[v55] = v54
			v50[v55] = v51
		end
	end
	return v49, v50
end
local function v_u_79(p57, p58, p59, p60, p61) -- name: claim
	local v62 = p57.win
	local v63 = p57.slot
	local v64 = p57.pos
	local v65 = p57.st
	local v66 = p57.win.key
	local _ = v62.ex
	local _ = v62.ey
	local _ = v62.ez
	local v67 = v62.info
	local v68 = 0
	for v69 = 1, v62.n do
		local v70 = v66[v69]
		local v71 = p58[v70]
		if not v71 then
			continue
		end
		local v72 = p59[v70]
		local v73 = v72.slot[v71]
		local v74 = v72.pos[v71]
		local v75 = v72.st[v71]
		v63[v69] = v73
		v64[v69] = v74
		v65[v69] = v75
		v72.slot[v71] = false
		p58[v70] = nil
		v68 = v68 + 1
		if not p60 then
			continue
		end
		local v76 = v67[v69]
		local v77 = (v76 % 128 - v76 % 8) / 8
		local v78 = v65[v69] % 4
		if v78 < 1 then
			continue
		end
		v73.BackgroundColor3 = p61.col[v77][v78]
	end
	return v68
end
local function v_u_92(p80, p81, p82, p83) -- name: releaseHeld
	local v84 = 0
	for v85, v86 in p81 do
		local v87 = p82[v85]
		if not p83[v87] then
			continue
		end
		local v88 = v87.slot[v86]
		if not v88 then
			continue
		end
		local v89 = v87.st[v86] % 4
		v88.Visible = false
		local v90 = p80.apOf[v88]
		if v90 then
			p80.apOf[v88] = nil
			p80.apF[v90] = false
		end
		local v91 = p80.free[v89 == 2 and 2 or 1]
		v91.n = v91.n + 1
		v91[v91.n] = v88
		p80.nFree = p80.nFree + 1
		v87.slot[v86] = false
		v84 = v84 + 1
	end
	return v84
end
local v_u_93 = v_u_24
local v_u_94 = v_u_9
local v_u_95 = {}
local v_u_96 = {}
local function v_u_102(p97, p98, p99) -- name: createFrames
	-- upvalues: (copy) v_u_29, (copy) v_u_17
	local v100 = p97.ceiling
	local v101 = 0
	if v101 < p98 and p97.total < v100 then
		v_u_29(p97)
		v101 = v101 + 1
		if v101 % 8 ~= 0 or p99 > v_u_17() then
			continue
		end
	end
	return v101
end
local function v_u_125(p103) -- name: syncWindows
	-- upvalues: (copy) v_u_47, (copy) v_u_56, (copy) v_u_79, (copy) v_u_92
	local v104 = p103.mgr
	local v105 = v104.coarse
	local v106 = v104.fine
	local v107 = p103.coarseL
	local v108 = p103.fineL
	local v109
	if v105 and (not v107 or v107.win ~= v105) then
		local v110 = v_u_47(v105)
		if v107 then
			local v111, v112 = v_u_56({ v107 })
			v_u_79(v110, v111, v112, v107.win.zonesVer ~= v105.zonesVer, p103)
			v_u_92(p103, v111, v112, {
				[v107] = true
			})
		end
		p103.coarseL = v110
		v109 = true
	else
		v109 = false
	end
	if v106 and (not v108 or v108.win ~= v106) then
		local v113 = v_u_47(v106)
		local v114 = {}
		if v108 then
			table.insert(v114, v108)
		end
		if p103.coarseL then
			local v115 = p103.coarseL
			table.insert(v114, v115)
		end
		if #v114 > 0 then
			local v116, v117 = v_u_56(v114)
			local v118 = false
			for _, v119 in v114 do
				if v119.win.zonesVer == v106.zonesVer then
					continue
				end
				v118 = true
			end
			v_u_79(v113, v116, v117, v118, p103)
			if v108 and p103.coarseL then
				local v120 = {}
				local v121 = {}
				for v122, v123 in v116 do
					if v117[v122] ~= v108 then
						continue
					end
					v120[v122] = v123
					v121[v122] = v108
				end
				v_u_79(p103.coarseL, v120, v121, false, p103)
				for v124 in v116 do
					if v117[v124] ~= v108 or v120[v124] ~= nil then
						continue
					end
					v116[v124] = nil
				end
			end
			if v108 then
				v_u_92(p103, v116, v117, {
					[v108] = true
				})
			end
		end
		p103.fineL = v113
		p103.fineSerial = p103.fineSerial + 1
		p103.swaps = p103.swaps + 1
		v109 = true
	end
	return v109
end
local function v_u_135(p126, p127) -- name: dropLayer
	if p127 then
		local v128 = p127.slot
		local v129 = p127.st
		for v130 = 1, p127.win.n do
			local v131 = v128[v130]
			if not v131 then
				continue
			end
			local v132 = v129[v130] % 4
			v131.Visible = false
			local v133 = p126.apOf[v131]
			if v133 then
				p126.apOf[v131] = nil
				p126.apF[v133] = false
			end
			local v134 = p126.free[v132 == 2 and 2 or 1]
			v134.n = v134.n + 1
			v134[v134.n] = v131
			p126.nFree = p126.nFree + 1
			v128[v130] = false
		end
	end
end
local function v_u_154(p136) -- name: styleOf
	-- upvalues: (copy) v_u_4, (copy) v_u_21, (copy) v_u_12, (copy) v_u_13
	local v137 = v_u_4.color
	local v138 = v137.bgDeep:Lerp(v137.info, 0.05)
	local v139 = v137.muted:Lerp(v137.text2, 0.25)
	local v140 = v137.text2:Lerp(v137.text, 0.35)
	local v141 = v137.muted:Lerp(v137.accentDim, 0.4)
	local v142 = v137.text2:Lerp(v137.accent, 0.3)
	local v143 = {
		v139,
		v139:Lerp(v141, 0.5),
		v141,
		v140,
		v140:Lerp(v142, 0.5),
		v142
	}
	local v144 = {}
	for v145 = 1, 6 do
		v144[v145] = { v143[v145], v143[v145]:Lerp(v138, v_u_21.BAND2_MIX) }
	end
	p136.col = v144
	local v146 = p136.S
	local v147 = {}
	local v148 = {}
	local v149 = {}
	for v150 = 1, 2 do
		v147[v150] = {}
		v148[v150] = {}
		v149[v150] = {}
		local v151
		if v150 == 1 then
			v151 = v_u_21.SIZE_FILL
		else
			v151 = v_u_21.SIZE_CONTOUR
		end
		for v152 = 1, 2 do
			local v153 = v_u_13(v_u_21.MIN_REAL_PX, (v_u_12(v151[v152] * v146 + 0.5)))
			v147[v150][v152] = v153
			v148[v150][v152] = v153 / 2
			v149[v150][v152] = UDim2.fromOffset(v153 / v146, v153 / v146)
		end
	end
	p136.sizeReal = v147
	p136.halfR = v148
	p136.ud = v149
	p136.halfFlat = {
		v148[1][1],
		v148[1][2],
		v148[2][1],
		v148[2][2]
	}
	p136.invS = 1 / v146
end
local function v_u_283(p155, p156, p157, p158, p159, p160) -- name: drawLayer
	-- upvalues: (copy) v_u_19, (copy) v_u_11, (copy) v_u_12, (copy) v_u_18, (copy) v_u_21, (copy) v_u_44
	local v161 = p156.win
	local v162 = v161.n
	local v163 = v161.nFill or 0
	local v164 = v161.ex
	local v165 = v161.ey
	local v166 = v161.ez
	local v167 = v161.info
	local v168 = v161.key
	local v169 = p156.slot
	local v170 = p156.pos
	local v171 = p156.st
	local v172 = p156.dlo
	local v173 = p156.dhi
	local v174 = p156.hk
	local v175 = p157.dqa
	local v176 = p157.dqb
	local v177 = p157.maj
	local v178 = p159 .. ":" .. p160 .. ":" .. p157.stride .. ":" .. p155.fineSerial .. ":" .. v175 .. ":" .. v176
	if p156.sig ~= v178 then
		p156.sig = v178
		for v179 = 1, v162 do
			v172[v179] = 2
			v173[v179] = -1
		end
	end
	local v180 = p157.m11
	local v181 = p157.m12
	local v182 = p157.m21
	local v183 = p157.m22
	local v184 = p157.m23
	local v185 = p157.m31
	local v186 = p157.m32
	local v187 = p157.m33
	local v188 = p157.RS
	local v189 = p157.cxS
	local v190 = p157.cyS
	local v191 = p157.limit
	local v192 = p155.invS
	local v193 = v_u_19.HORIZON
	local v194 = v193[1]
	local v195 = v193[2]
	local v196 = v193[3]
	local v197 = p155.halfFlat
	local v198 = v_u_19.HORIZON_HYST
	local v199 = v_u_11.BAND_EDGE
	local v200 = v_u_11.DEPTH_HYST
	local v201 = v_u_11.DEPTH_MIN
	local v202 = p155.halfR
	local v203 = p157.budget
	local v204 = p157.want
	local v205 = p157.live
	local v206 = p157.missed
	local v207 = p157.hard
	local v208 = p157.deferred
	local v209 = p157.capped
	local v210 = p157.writes
	local v211 = p157.acq
	local v212 = 0
	local v213 = p157.fade
	local v214 = p157.stride
	local v215, v216, v217, v218
	if p158 then
		v215 = p158.cx
		v216 = p158.cy
		v217 = p158.cz
		v218 = p158.cosRho
	else
		v215 = 0
		v217 = 0
		v218 = 2
		v216 = 0
	end
	local v219 = p158 ~= nil
	for v220 = 1, v162 do
		local v221 = v164[v220]
		local v222 = v165[v220]
		local v223 = v166[v220]
		local v224 = v185 * v221 + v186 * v222 + v187 * v223
		local v225, v226, v227, v228, v229, v230, v231, v232, v233, v234, v235, v236, v237, v238, v239, v240, v241, v242, v243, v244, v245, v246, v247, v248, v249, v250, v251, v252, v253, v254, v255, v256, v257, v258, v259, v260, v261, v262, v263, v264, v265, v266, v267, v268, v269, v270, v271, v272, v273, v274, v275, v276
		if v172[v220] <= v224 and v224 < v173[v220] then
			local v277 = v188 * (v180 * v221 + v181 * v222)
			local v278 = v188 * (v182 * v221 + v183 * v222 + v184 * v223)
			if v277 * v277 + v278 * v278 <= v191 then
				v204 = v204 + 1
				v205 = v205 + 1
				v212 = v212 + 1
				local v279 = v174[v220]
				local v280 = v_u_12(v189 + v277 - v279 + 0.5)
				local v281 = v_u_12(v190 - v278 - v279 + 0.5)
				local v282 = (v280 + 64) * 8192 + v281 + 64
				if v282 == v170[v220] then
					continue
				end
				v170[v220] = v282
				v210 = v210 + 1
				v169[v220].Position = UDim2.fromOffset(v280 * v192, v281 * v192)
			else
				v172[v220] = 2
				v173[v220] = -1
				v225 = v163 < v220
				if v225 then
					v226 = p160
				else
					v226 = p159
				end
				v227 = v171[v220]
				v228 = false
				if v201 <= v224 and (not v219 or v218 > v221 * v215 + v222 * v216 + v223 * v217) then
					v229 = v188 * (v180 * v221 + v181 * v222)
					v230 = v188 * (v182 * v221 + v183 * v222 + v184 * v223)
					if v229 * v229 + v230 * v230 <= v191 then
						v228 = true
					end
				else
					v230 = 0
					v229 = 0
				end
				if v228 then
					v231 = v169[v220]
					v232 = v227 % 4
					v233 = v227 // 4 % 4
					if v228 then
						while v233 < 3 and v224 < v193[v233 + 1] do
							v233 = v233 + 1
						end
						while v233 > 0 and v193[v233] + v198 <= v224 do
							v233 = v233 - 1
						end
						v234 = -1
						v235 = 0
						if v226 >= 0 then
							v236 = v167[v220]
							if v225 then
								v237 = v236 % 8
								v238 = v168[v220]
								if v238 <= -1 and v238 >= -900000000 then
									v239 = (v236 - v236 % 128) / 128
									if v239 < 3 then
										v240 = v224 * v_u_18[v239]
										v235 = v240 < v194 and (v240 < v195 and (v240 < v196 and 3 or 2) or 1) or 0
										if v233 < v235 then
											v241 = v235
										else
											v241 = v233
										end
									else
										v239 = v234
										v241 = v233
									end
								else
									v239 = v234
									v241 = v233
								end
								if v237 <= v226 - v241 then
									v242 = true
								elseif v237 == 0 then
									v242 = (v241 < 2 or (v238 > -1 or v238 < -900000000)) and true or (-v238 - 1) % 16384 == 0
								else
									v242 = false
								end
								if v242 and v176 < 1000 then
									v243 = -v238 - 1
									if v177 == nil then
										v244 = v176
									elseif v177[v243 // 16384 + 1] then
										v244 = v175
									else
										v244 = v176
									end
									if v244 <= v243 * 0.0078125 * 0.6180339887498949 % 1 * 1000 then
										v242 = false
									end
								end
							else
								v245 = v236 % 8
								v242 = v245 == 0 and true or v245 <= v226 - v233
								if v242 and (v214 > 1 and v168[v220] % 65521 * 40503 % 65536 // 256 % v214 ~= 0) then
									v239 = v234
									v242 = false
								else
									v239 = v234
								end
							end
						else
							v239 = v234
							v242 = false
						end
						if v242 then
							v204 = v204 + 1
							if v232 == 1 then
								v246 = v224 < v199 - v200 and 2 or 1
							else
								v246 = v199 + v200 <= v224 and 1 or 2
							end
							if v231 then
								if v232 ~= v246 then
									v247 = v167[v220]
									v248 = (v247 % 128 - v247 % 8) / 8
									v231.BackgroundColor3 = p155.col[v248][v246]
									v231.Size = p155.ud[v225 and 2 or 1][v246]
									v231.BackgroundTransparency = v246 ~= 2 and 0 or v_u_21.BAND2_ALPHA
								end
							elseif v207 < v204 then
								v209 = v209 + 1
							elseif v227 >= 16 and v203 <= 0 then
								v208 = v208 + 1
							else
								if v227 >= 16 then
									v203 = v203 - 1
								end
								v249 = v167[v220]
								v250 = (v249 % 128 - v249 % 8) / 8
								v211 = v211 + 1
								v251 = v_u_44
								v252 = v225 and 2 or 1
								if v213 then
									v253 = v227 >= 16
								else
									v253 = v213
								end
								v231 = v251(p155, v246, v252, v250, v253)
								if v231 then
									v169[v220] = v231
									v170[v220] = -1
								else
									v206 = v206 + 1
								end
							end
							if v231 then
								v205 = v205 + 1
								if v225 then
									v246 = v246 + 2
								end
								v254 = v197[v246]
								v255 = v_u_12(v189 + v229 - v254 + 0.5)
								v256 = v_u_12(v190 - v230 - v254 + 0.5)
								v257 = (v255 + 64) * 8192 + v256 + 64
								if v257 ~= v170[v220] then
									v170[v220] = v257
									v210 = v210 + 1
									v231.Position = UDim2.fromOffset(v255 * v192, v256 * v192)
								end
								v258 = 2
								if v233 < 3 then
									v259 = v193[v233 + 1]
									if v201 >= v259 then
										v259 = v201
									end
								else
									v259 = v201
								end
								if v233 > 0 then
									v260 = v193[v233] + v198
									if v260 >= v258 then
										v260 = v258
									end
								else
									v260 = v258
								end
								if v239 >= 0 then
									v261 = v_u_18[v239]
									if v235 < 3 then
										v262 = v193[v235 + 1] / v261
										if v259 >= v262 then
											v262 = v259
										end
									else
										v262 = v259
									end
									if v235 > 0 then
										v263 = v193[v235] / v261
										if v263 >= v260 then
											v263 = v260
										end
									else
										v263 = v260
									end
								else
									v262 = v259
									v263 = v260
								end
								if v246 == 1 then
									if v262 < v199 - v200 then
										v262 = v199 - v200
									end
								elseif v199 + v200 < v263 then
									v263 = v199 + v200
								end
								if v262 < v263 then
									v172[v220] = v262
									v173[v220] = v263
									v174[v220] = v254
								end
							end
							v264 = v246 + 4 * v233 + 16
						elseif v231 then
							if v203 <= 0 then
								v208 = v208 + 1
								v205 = v205 + 1
								v265 = v202[v225 and 2 or 1][v232 == 0 and 1 or v232]
								v266 = v_u_12(v189 + v229 - v265 + 0.5)
								v267 = v_u_12(v190 - v230 - v265 + 0.5)
								v268 = (v266 + 64) * 8192 + v267 + 64
								if v268 ~= v170[v220] then
									v170[v220] = v268
									v231.Position = UDim2.fromOffset(v266 * v192, v267 * v192)
								end
								v264 = v232 + 4 * v233 + 16
							else
								v203 = v203 - 1
								v231.Visible = false
								v269 = p155.apOf[v231]
								if v269 then
									p155.apOf[v231] = nil
									p155.apF[v269] = false
								end
								v270 = p155.free[v232 == 2 and 2 or 1]
								v270.n = v270.n + 1
								v270[v270.n] = v231
								p155.nFree = p155.nFree + 1
								v169[v220] = false
								v264 = 16 + 4 * v233
							end
						else
							v264 = 16 + 4 * v233
						end
					else
						if v231 then
							v231.Visible = false
							v271 = p155.apOf[v231]
							if v271 then
								p155.apOf[v231] = nil
								p155.apF[v271] = false
							end
							v272 = p155.free[v232 == 2 and 2 or 1]
							v272.n = v272.n + 1
							v272[v272.n] = v231
							p155.nFree = p155.nFree + 1
							v169[v220] = false
						end
						v264 = 4 * v233
					end
					if v264 == v227 then
						continue
					end
					v171[v220] = v264
				else
					if v227 == 0 then
						continue
					end
					v273 = v169[v220]
					if v273 then
						v274 = v227 % 4
						v273.Visible = false
						v275 = p155.apOf[v273]
						if v275 then
							p155.apOf[v273] = nil
							p155.apF[v275] = false
						end
						v276 = p155.free[v274 == 2 and 2 or 1]
						v276.n = v276.n + 1
						v276[v276.n] = v273
						p155.nFree = p155.nFree + 1
						v169[v220] = false
					end
					v171[v220] = 0
				end
			end
		else
			v172[v220] = 2
			v173[v220] = -1
			v225 = v163 < v220
			if v225 then
				v226 = p160
			else
				v226 = p159
			end
			v227 = v171[v220]
			v228 = false
			if v201 <= v224 and (not v219 or v218 > v221 * v215 + v222 * v216 + v223 * v217) then
				v229 = v188 * (v180 * v221 + v181 * v222)
				v230 = v188 * (v182 * v221 + v183 * v222 + v184 * v223)
				if v229 * v229 + v230 * v230 <= v191 then
					v228 = true
				end
			else
				v230 = 0
				v229 = 0
			end
			if v228 then
				v231 = v169[v220]
				v232 = v227 % 4
				v233 = v227 // 4 % 4
				if v228 then
					while v233 < 3 and v224 < v193[v233 + 1] do
						v233 = v233 + 1
					end
					while v233 > 0 and v193[v233] + v198 <= v224 do
						v233 = v233 - 1
					end
					v234 = -1
					v235 = 0
					if v226 >= 0 then
						v236 = v167[v220]
						if v225 then
							v237 = v236 % 8
							v238 = v168[v220]
							if v238 <= -1 and v238 >= -900000000 then
								v239 = (v236 - v236 % 128) / 128
								if v239 < 3 then
									v240 = v224 * v_u_18[v239]
									v235 = v240 < v194 and (v240 < v195 and (v240 < v196 and 3 or 2) or 1) or 0
									if v233 < v235 then
										v241 = v235
									else
										v241 = v233
									end
								else
									v239 = v234
									v241 = v233
								end
							else
								v239 = v234
								v241 = v233
							end
							if v237 <= v226 - v241 then
								v242 = true
							elseif v237 == 0 then
								v242 = (v241 < 2 or (v238 > -1 or v238 < -900000000)) and true or (-v238 - 1) % 16384 == 0
							else
								v242 = false
							end
							if v242 and v176 < 1000 then
								v243 = -v238 - 1
								if v177 == nil then
									v244 = v176
								elseif v177[v243 // 16384 + 1] then
									v244 = v175
								else
									v244 = v176
								end
								if v244 <= v243 * 0.0078125 * 0.6180339887498949 % 1 * 1000 then
									v242 = false
								end
							end
						else
							v245 = v236 % 8
							v242 = v245 == 0 and true or v245 <= v226 - v233
							if v242 and (v214 > 1 and v168[v220] % 65521 * 40503 % 65536 // 256 % v214 ~= 0) then
								v239 = v234
								v242 = false
							else
								v239 = v234
							end
						end
					else
						v239 = v234
						v242 = false
					end
					if v242 then
						v204 = v204 + 1
						if v232 == 1 then
							v246 = v224 < v199 - v200 and 2 or 1
						else
							v246 = v199 + v200 <= v224 and 1 or 2
						end
						if v231 then
							if v232 ~= v246 then
								v247 = v167[v220]
								v248 = (v247 % 128 - v247 % 8) / 8
								v231.BackgroundColor3 = p155.col[v248][v246]
								v231.Size = p155.ud[v225 and 2 or 1][v246]
								v231.BackgroundTransparency = v246 ~= 2 and 0 or v_u_21.BAND2_ALPHA
							end
						elseif v207 < v204 then
							v209 = v209 + 1
						elseif v227 >= 16 and v203 <= 0 then
							v208 = v208 + 1
						else
							if v227 >= 16 then
								v203 = v203 - 1
							end
							v249 = v167[v220]
							v250 = (v249 % 128 - v249 % 8) / 8
							v211 = v211 + 1
							v251 = v_u_44
							v252 = v225 and 2 or 1
							if v213 then
								v253 = v227 >= 16
							else
								v253 = v213
							end
							v231 = v251(p155, v246, v252, v250, v253)
							if v231 then
								v169[v220] = v231
								v170[v220] = -1
							else
								v206 = v206 + 1
							end
						end
						if v231 then
							v205 = v205 + 1
							if v225 then
								v246 = v246 + 2
							end
							v254 = v197[v246]
							v255 = v_u_12(v189 + v229 - v254 + 0.5)
							v256 = v_u_12(v190 - v230 - v254 + 0.5)
							v257 = (v255 + 64) * 8192 + v256 + 64
							if v257 ~= v170[v220] then
								v170[v220] = v257
								v210 = v210 + 1
								v231.Position = UDim2.fromOffset(v255 * v192, v256 * v192)
							end
							v258 = 2
							if v233 < 3 then
								v259 = v193[v233 + 1]
								if v201 >= v259 then
									v259 = v201
								end
							else
								v259 = v201
							end
							if v233 > 0 then
								v260 = v193[v233] + v198
								if v260 >= v258 then
									v260 = v258
								end
							else
								v260 = v258
							end
							if v239 >= 0 then
								v261 = v_u_18[v239]
								if v235 < 3 then
									v262 = v193[v235 + 1] / v261
									if v259 >= v262 then
										v262 = v259
									end
								else
									v262 = v259
								end
								if v235 > 0 then
									v263 = v193[v235] / v261
									if v263 >= v260 then
										v263 = v260
									end
								else
									v263 = v260
								end
							else
								v262 = v259
								v263 = v260
							end
							if v246 == 1 then
								if v262 < v199 - v200 then
									v262 = v199 - v200
								end
							elseif v199 + v200 < v263 then
								v263 = v199 + v200
							end
							if v262 < v263 then
								v172[v220] = v262
								v173[v220] = v263
								v174[v220] = v254
							end
						end
						v264 = v246 + 4 * v233 + 16
					elseif v231 then
						if v203 <= 0 then
							v208 = v208 + 1
							v205 = v205 + 1
							v265 = v202[v225 and 2 or 1][v232 == 0 and 1 or v232]
							v266 = v_u_12(v189 + v229 - v265 + 0.5)
							v267 = v_u_12(v190 - v230 - v265 + 0.5)
							v268 = (v266 + 64) * 8192 + v267 + 64
							if v268 ~= v170[v220] then
								v170[v220] = v268
								v231.Position = UDim2.fromOffset(v266 * v192, v267 * v192)
							end
							v264 = v232 + 4 * v233 + 16
						else
							v203 = v203 - 1
							v231.Visible = false
							v269 = p155.apOf[v231]
							if v269 then
								p155.apOf[v231] = nil
								p155.apF[v269] = false
							end
							v270 = p155.free[v232 == 2 and 2 or 1]
							v270.n = v270.n + 1
							v270[v270.n] = v231
							p155.nFree = p155.nFree + 1
							v169[v220] = false
							v264 = 16 + 4 * v233
						end
					else
						v264 = 16 + 4 * v233
					end
				else
					if v231 then
						v231.Visible = false
						v271 = p155.apOf[v231]
						if v271 then
							p155.apOf[v231] = nil
							p155.apF[v271] = false
						end
						v272 = p155.free[v232 == 2 and 2 or 1]
						v272.n = v272.n + 1
						v272[v272.n] = v231
						p155.nFree = p155.nFree + 1
						v169[v220] = false
					end
					v264 = 4 * v233
				end
				if v264 == v227 then
					continue
				end
				v171[v220] = v264
			else
				if v227 == 0 then
					continue
				end
				v273 = v169[v220]
				if v273 then
					v274 = v227 % 4
					v273.Visible = false
					v275 = p155.apOf[v273]
					if v275 then
						p155.apOf[v273] = nil
						p155.apF[v275] = false
					end
					v276 = p155.free[v274 == 2 and 2 or 1]
					v276.n = v276.n + 1
					v276[v276.n] = v273
					p155.nFree = p155.nFree + 1
					v169[v220] = false
				end
				v171[v220] = 0
			end
		end
	end
	p157.budget = v203
	p157.want = v204
	p157.live = v205
	p157.missed = v206
	p157.deferred = v208
	p157.capped = v209
	p157.writes = v210
	p157.acq = v211
	p157.steady = (p157.steady or 0) + v212
end
local function v_u_297(p284, p285, p286) -- name: levelsFor
	-- upvalues: (copy) v_u_13, (copy) v_u_14
	local v287 = p284.mgr
	local v288 = v287.fillM
	local v289 = v287.contM
	if v288 == nil or v289 == nil then
		return -1, -1
	end
	local v290, v291
	if p284.moving then
		v290 = p284.mvF
		v291 = p284.mvC
	else
		v290 = p284.rsF
		v291 = p284.rsC
	end
	local v292 = v_u_13(0, v288 - v290)
	local v293 = v_u_13(0, v289 - v291)
	local v294
	if p284.noFill then
		v294 = -1
	else
		local v295
		if p284.moving then
			v295 = p284.mvMode
		else
			v295 = p284.rsMode
		end
		v294 = v295 == 2 and -1 or v292
	end
	if p284.tier == "mini" then
		v294 = v_u_14(v294, 0)
		v293 = -1
	end
	if p286 then
		local v296 = p285.win
		v294 = v296.fillM == nil and -1 or v_u_14(v294, v296.fillM)
		if v296.contM == nil then
			return v294, -1
		end
		v293 = v_u_14(v293, v296.contM)
	end
	return v294, v293
end
local function v_u_311(p298, p299, p300, p301) -- name: firstLevels
	-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_6, (copy) v_u_21
	local v302 = p298.lat0
	local v303 = p298.lon0
	local v304 = v_u_11.R1 * p298.lensR * p298.z
	local v305 = {
		{ p300, p301 },
		{ -1, p301 },
		{ -1, (v_u_13(0, p301 - 1)) },
		{ -1, 0 }
	}
	local v306 = v305[#v305]
	local v307 = 0
	for _, v308 in v305 do
		local v309, v310 = v_u_6.visible(p299.win, v302, v303, v304, p298.lensR, v_u_13(v308[1], 0), v_u_13(v308[2], 0), v308[1] < 0)
		v307 = v309 + (v308[2] < 0 and 0 or v310)
		if v307 <= v_u_21.COARSE_FIRST_MAX then
			v306 = v308
			break
		end
		v306 = v308
	end
	p298.firstCount = v307
	return v306[1], v306[2]
end
local v_u_312 = {}
for v313 = 0, 63 do
	local v314 = v_u_15((v313 + 0.5) / 64) * 0.9
	local v315 = v313 * 2.399963
	local v316 = v313 + 1
	local v317 = v313 + 1
	local v318 = v314 * math.cos(v315)
	local v319 = v314 * math.sin(v315)
	v_u_95[v316] = v318
	v_u_96[v317] = v319
end
local function v_u_338(p320, p321) -- name: coverageHoles
	-- upvalues: (copy) v_u_11, (copy) v_u_95, (copy) v_u_96, (copy) v_u_15
	local v322 = p320.fineL
	local v323 = p320.coarseL
	if not (v322 or v323) then
		return 64
	end
	local v324 = v_u_11.R1 * p320.lensR * p320.z
	local v325 = p320.lensR
	local v326 = 0
	for v327 = 1, 64 do
		local v328 = v_u_95[v327] * v325 / v324
		local v329 = -v_u_96[v327] * v325 / v324
		local v330 = v328 * v328 + v329 * v329
		if v330 >= 0.97 then
			continue
		end
		local v331 = v_u_15(1 - v330)
		local v332 = v328 * p321.m11 + v329 * p321.m21 + v331 * p321.m31
		local v333 = v328 * p321.m12 + v329 * p321.m22 + v331 * p321.m32
		local v334 = v329 * p321.m23 + v331 * p321.m33
		local v335
		if v322 then
			local v336 = v322.win
			v335 = v332 * v336.cx + v333 * v336.cy + v334 * v336.cz >= v336.cosRho
		else
			v335 = false
		end
		if not v335 and v323 then
			local v337 = v323.win
			v335 = v332 * v337.cx + v333 * v337.cy + v334 * v337.cz >= v337.cosRho
		end
		if v335 then
			continue
		end
		v326 = v326 + 1
	end
	return v326
end
local function v_u_391(p339) -- name: drawAll
	-- upvalues: (copy) v_u_5, (copy) v_u_11, (copy) v_u_21, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (copy) v_u_6, (copy) v_u_17, (copy) v_u_283, (copy) v_u_297, (copy) v_u_311, (copy) v_u_338
	local v340 = p339.ctx
	local v341 = p339.lat0 * 0.017453292519943295
	local v342 = p339.lon0 * 0.017453292519943295
	local v343, v344, v345, v346, v347, v348, v349, v350 = v_u_5.matrix(v341, v342)
	v340.m11 = v343
	v340.m12 = v344
	v340.m21 = v345
	v340.m22 = v346
	v340.m23 = v347
	v340.m31 = v348
	v340.m32 = v349
	v340.m33 = v350
	local v351 = p339.S
	local v352 = v_u_11.R1 * p339.lensR * p339.z
	v340.RS = v352 * v351
	local v353 = p339.cx * v351
	local v354 = p339.cy * v351
	v340.cxS = v353
	v340.cyS = v354
	local v355 = (p339.lensR - 1) * v351
	v340.limit = v355 * v355
	v340.budget = p339.firstDone and (v_u_21.SETS_PER_FRAME[p339.tier] or 150) or 100000
	v340.want = 0
	v340.live = 0
	v340.missed = 0
	v340.deferred = 0
	v340.capped = 0
	v340.writes = 0
	v340.acq = 0
	v340.steady = 0
	v340.hard = v_u_12(p339:capNow() * v_u_21.HARD_FACTOR + 0.5)
	local v356 = not p339.moving
	if v356 then
		v356 = not p339:isReduced()
	end
	v340.fade = v356
	local v357
	if p339.moving then
		v357 = p339.mvMode
	else
		v357 = p339.rsMode
	end
	v340.stride = v357 == 1 and 2 or 1
	local v358
	if p339.moving then
		v358 = p339.mvDq
	else
		v358 = p339.rsDq
	end
	local v359 = v358[1]
	local v360 = v358[2]
	local v361 = p339.edgeMajor
	v340.dqa = v359
	v340.dqb = v360
	v340.maj = v361
	v340.stride0 = v340.stride
	local v362 = p339.fineL
	local v363 = p339.coarseL
	local v364 = p339.noFill
	if p339.tier == "low" then
		p339.noFill = p339.z < v_u_21.PHONE_FILL_MIN_ZOOM
	else
		p339.noFill = false
	end
	if p339.noFill ~= v364 then
		p339.dropsDirty = true
	end
	if v362 then
		local v365 = p339.mgr
		local v366 = v365.fillM
		local v367 = v365.contM
		local v368, v369
		if v366 == nil or v367 == nil then
			v368 = -1
			v369 = -1
		else
			local v370, v371
			if p339.moving then
				v370 = p339.mvF
				v371 = p339.mvC
			else
				v370 = p339.rsF
				v371 = p339.rsC
			end
			local v372 = v_u_13(0, v366 - v370)
			v369 = v_u_13(0, v367 - v371)
			if p339.noFill then
				v368 = -1
			else
				local v373
				if p339.moving then
					v373 = p339.mvMode
				else
					v373 = p339.rsMode
				end
				v368 = v373 == 2 and -1 or v372
			end
			if p339.tier == "mini" then
				v368 = v_u_14(v368, 0)
				v369 = -1
			end
		end
		if p339.tier == "mini" then
			if p339.miniVer ~= p339.viewVer .. ":" .. p339.fineSerial then
				local v374 = v_u_11.R1 * p339.lensR * p339.z
				local v375 = v_u_6.visible(v362.win, p339.lat0, p339.lon0, v374, p339.lensR, 0, 0, false) / (v_u_21.MINI_CAP * 0.8)
				p339.miniStrideV = v_u_13(1, (math.ceil(v375)))
				p339.miniVer = p339.viewVer .. ":" .. p339.fineSerial
			end
			v340.stride = p339.miniStrideV or 1
		end
		local v376 = v_u_17()
		v_u_283(p339, v362, v340, nil, v368, v369)
		p339.tFineMs = (v_u_17() - v376) * 1000
		p339.levelF = v368
		p339.levelC = v369
	end
	local v377 = true
	if v362 and v363 then
		local v378 = v_u_6.rhoVis(v352, p339.lensR)
		if v_u_6.angleBetween(p339.lat0, p339.lon0, v362.win.cLat, v362.win.cLon) + v378 <= v362.win.rho - 0.003 then
			v377 = false
		end
	end
	if v363 and (v377 or not v363.idle) then
		v363.idle = not v377
		local v379, v380 = v_u_297(p339, v363, true)
		if not v362 then
			if p339.tier == "mini" then
				if not p339.miniStrideV or p339.miniVer ~= p339.viewVer then
					local v381 = v_u_11.R1 * p339.lensR * p339.z
					local v382 = v_u_6.visible(v363.win, p339.lat0, p339.lon0, v381, p339.lensR, 0, 0, false) / (v_u_21.MINI_CAP * 0.8)
					p339.miniStrideV = v_u_13(1, (math.ceil(v382)))
					p339.miniVer = p339.viewVer
				end
				v340.stride = p339.miniStrideV
			else
				if p339.firstVer ~= p339.viewVer or not p339.firstF then
					local v383, v384 = v_u_311(p339, v363, v379, v380)
					p339.firstF = v383
					p339.firstC = v384
					p339.firstVer = p339.viewVer
				end
				v379 = p339.firstF
				v380 = p339.firstC
			end
			p339.levelF = v379
			p339.levelC = v380
		end
		local v385 = v_u_17()
		local v386 = v_u_283
		local v387
		if v362 then
			v387 = v362.win
		else
			v387 = nil
		end
		v386(p339, v363, v340, v387, v379, v380)
		p339.tCoarseMs = (v_u_17() - v385) * 1000
		v340.stride = v340.stride0
	end
	p339.live = v340.live
	p339.wantN = v340.want
	p339.missed = v340.missed
	p339.deferred = v340.deferred
	p339.capped = v340.capped
	local v388 = v340.writes
	local v389 = v340.acq
	local v390 = v340.steady
	p339.writesN = v388
	p339.acqN = v389
	p339.steadyN = v390
	p339.coarseOnly = v362 == nil
	p339.drawFrames = p339.drawFrames + 1
	if v_u_338(p339, v340) > 0 then
		p339.holeFrames = p339.holeFrames + 1
	end
end
local function v_u_397(p392) -- name: effCaps
	-- upvalues: (copy) v_u_14, (copy) v_u_13
	local v393 = p392.baseRest
	local v394 = p392.baseMove
	local v395 = p392.gov
	if v395 then
		local v396 = v395:caps()
		v393 = v_u_14(v393, v396.rest)
		v394 = v_u_14(v394, v396.move)
	end
	return v_u_13(1, v393), v_u_13(1, v394)
end
function v_u_312.capNow(p398) -- name: capNow
	-- upvalues: (copy) v_u_14, (copy) v_u_13
	local v399 = p398.baseRest
	local v400 = p398.baseMove
	local v401 = p398.gov
	if v401 then
		local v402 = v401:caps()
		v399 = v_u_14(v399, v402.rest)
		v400 = v_u_14(v400, v402.move)
	end
	local v403 = v_u_13(1, v399)
	local v404 = v_u_13(1, v400)
	if p398.moving then
		return v404
	else
		return v403
	end
end
local function v_u_415(p405) -- name: majorEdges
	-- upvalues: (copy) v_u_16, (copy) v_u_21
	local v406 = p405.edgeMajor
	if v406 then
		return v406
	end
	local v407 = p405.world
	local v408 = v407.contour
	if not (v407.ready and v408) then
		return nil
	end
	local v409 = v407.nContour
	local v410 = 1
	local v411 = 0
	local v412 = {}
	for v413 = 1, v409 + 1 do
		if v409 < v413 or v410 < v413 and (v_u_16(v408.ax[v413] - v408.bx[v413 - 1]) > 1e-9 or v_u_16(v408.ay[v413] - v408.by[v413 - 1]) > 1e-9) then
			if v_u_21.FLOOR_MAJOR_DEG <= v411 then
				for v414 = v410, v413 - 1 do
					v412[v414] = true
				end
			end
			v410 = v413
			v411 = 0
		end
		if v413 > v409 then
			continue
		end
		v411 = v411 + v408.r[v413] * v408.n0[v413]
	end
	p405.edgeMajor = v412
	return v412
end
local function v_u_428(p416, p417, p418, p419, p420, p421) -- name: densitiesFor
	-- upvalues: (copy) v_u_23, (copy) v_u_415, (copy) v_u_21, (copy) v_u_12, (copy) v_u_13, (copy) v_u_6
	if p416.denseBelow <= p420 or (p421 <= p420 or p421 <= 0) then
		return v_u_23
	else
		local v422 = v_u_415(p416)
		if v422 then
			local v423 = {}
			v_u_6.visible(p417, p416.lat0, p416.lon0, p418, p416.lensR, 0, p419, true, v423)
			local v424 = #v423
			local v425 = 0
			for _, v426 in v423 do
				if not v422[(-v426.key - 1) // 16384 + 1] then
					continue
				end
				v425 = v425 + 1
			end
			if v424 <= p420 or v424 == 0 then
				return v_u_23
			else
				return p420 <= v425 and { v_u_13(v_u_21.DENSITY_MIN, (v_u_12(p420 * 1000 / v425))), 0 } or { 1000, (v_u_12((p420 - v425) * 1000 / (v424 - v425))) }
			end
		else
			local v427 = v_u_13(v_u_21.DENSITY_MIN, (v_u_12(p420 * 1000 / p421)))
			return { v427, v427 }
		end
	end
end
local function v_u_443(p429, p430, p431, p432, p433, p434) -- name: resolveCap
	-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_428, (copy) v_u_13
	local v435, v436, v437 = v_u_6.budgetDrops(p430, p429.lat0, p429.lon0, p431, p429.lensR, p432, p433, p434, p429.noFill)
	if v437 <= p434 then
		return v435, v436, 0, v_u_23
	end
	if p429.noFill then
		return v435, v436, 0, v_u_428(p429, p430, p431, v_u_13(0, p433 - v436), p434, v437)
	end
	local v438, v439 = v_u_6.visible(p430, p429.lat0, p429.lon0, p431, p429.lensR, p432 - v435, p433 - v436, false)
	if v438 / 2 + v439 <= p434 then
		return v435, v436, 1, v_u_23
	end
	local v440, v441, v442 = v_u_6.budgetDrops(p430, p429.lat0, p429.lon0, p431, p429.lensR, p432, p433, p434, true)
	return v440, v441, 2, v_u_428(p429, p430, p431, v_u_13(0, p433 - v441), p434, v442)
end
local function v_u_458(p444) -- name: computeMoveDrops
	-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_13, (copy) v_u_11, (copy) v_u_443
	local v445 = p444.fineL
	if v445 then
		v445 = p444.fineL.win
	end
	local v446 = p444.mgr.fillM
	local v447 = p444.mgr.contM
	if v445 and (v446 ~= nil and (v447 ~= nil and p444.tier ~= "mini")) then
		local v448 = v_u_17()
		local v449 = p444.baseRest
		local v450 = p444.baseMove
		local v451 = p444.gov
		if v451 then
			local v452 = v451:caps()
			v449 = v_u_14(v449, v452.rest)
			v450 = v_u_14(v450, v452.move)
		end
		v_u_13(1, v449)
		local v453 = v_u_13(1, v450)
		local v454, v455, v456, v457 = v_u_443(p444, v445, v_u_11.R1 * p444.lensR * p444.z, v446, v447, v453)
		p444.mvF = v454
		p444.mvC = v455
		p444.mvMode = v456
		p444.mvDq = v457
		p444.dropMs = (v_u_17() - v448) * 1000
		p444.needDraw = true
	end
end
local function v_u_480(p459) -- name: computeDrops
	-- upvalues: (copy) v_u_17, (copy) v_u_23, (copy) v_u_14, (copy) v_u_13, (copy) v_u_11, (copy) v_u_443
	local v460 = v_u_17()
	p459.dropsDirty = false
	local v461 = p459.fineL
	if v461 then
		v461 = p459.fineL.win
	end
	if v461 and (p459.mgr.fillM and p459.tier ~= "mini") then
		local v462 = p459.baseRest
		local v463 = p459.baseMove
		local v464 = p459.gov
		if v464 then
			local v465 = v464:caps()
			v462 = v_u_14(v462, v465.rest)
			v463 = v_u_14(v463, v465.move)
		end
		local v466 = v_u_13(1, v462)
		local v467 = v_u_13(1, v463)
		local v468 = v_u_11.R1 * p459.lensR * p459.z
		local v469 = p459.mgr.fillM
		local v470 = p459.mgr.contM
		if v469 ~= nil and v470 ~= nil then
			local v471, v472, v473, v474 = v_u_443(p459, v461, v468, v469, v470, v467)
			local v475, v476, v477, v478
			if v467 == v466 then
				v475 = v474
				v476 = v473
				v477 = v472
				v478 = v471
			elseif v471 == 0 and (v472 == 0 and (v473 == 0 and (v474 == v_u_23 and v467 <= v466))) then
				v475 = v_u_23
				v478 = 0
				v477 = 0
				v476 = 0
			else
				v478, v477, v476, v475 = v_u_443(p459, v461, v468, v469, v470, v466)
			end
			if v471 < v478 then
				v478 = v471
			end
			if v472 < v477 then
				v477 = v472
			end
			if v473 < v476 then
				v476 = v473
			end
			if v475 ~= v_u_23 and (v475[1] < v474[1] or v475[2] < v474[2]) then
				v475 = v474
			end
			p459.rsF = v478
			p459.rsC = v477
			p459.mvF = v471
			p459.mvC = v472
			p459.rsMode = v476
			p459.mvMode = v473
			p459.rsDq = v475
			p459.mvDq = v474
			p459.dropMs = (v_u_17() - v460) * 1000
			p459.dropsKnown = true
			p459.needDraw = true
		end
	else
		p459.rsF = 0
		p459.rsC = 0
		p459.mvF = 0
		p459.mvC = 0
		p459.rsMode = 0
		p459.mvMode = 0
		local v479 = v_u_23
		p459.rsDq = v_u_23
		p459.mvDq = v479
		return
	end
end
function v_u_312.calibrate(p481) -- name: calibrate
	-- upvalues: (copy) v_u_21, (copy) v_u_17, (copy) v_u_14, (copy) v_u_7
	local v482 = v_u_21.CAL_SETS
	local v483 = {}
	for v484 = 1, 2 do
		local v485 = p481.free[v484]
		for v486 = v485.n, 1, -1 do
			if v482 <= #v483 then
				break
			end
			v483[#v483 + 1] = v485[v486]
		end
	end
	local v487 = #v483
	if v487 < 20 then
		return p481.calC or 0
	end
	for v488 = 1, v487 do
		v483[v488].BackgroundTransparency = 1
		v483[v488].Visible = true
	end
	local v489 = (1 / 0)
	for v490 = 0, v_u_21.CAL_RUNS do
		local v491 = v_u_17()
		local v492 = v490 * 3
		for v493 = 1, v487 do
			v483[v493].Position = UDim2.fromOffset(v492 + v493 % 17, v492 + v493 % 13)
		end
		local v494 = (v_u_17() - v491) * 1000000 / v487
		if v490 <= 0 then
			break
		end
		v489 = v_u_14(v489, v494)
	end
	for v495 = 1, v487 do
		v483[v495].Visible = false
		v483[v495].BackgroundTransparency = 0
	end
	p481.calC = v489
	local v496, v497 = v_u_7.capsFor(p481.tier, v489 * v_u_21.CAL_FACTOR)
	p481.baseMove = v_u_14(p481.baseMove, v496)
	p481.baseRest = v_u_14(p481.baseRest, v497)
	if p481.gov then
		p481.gov:limit(p481.baseMove, p481.baseRest)
	end
	p481.dropsDirty = true
	p481.calDone = true
	return v489
end
local function v_u_506(p498, p499) -- name: baselineTick
	-- upvalues: (copy) v_u_21, (copy) v_u_312
	local v500 = p498.bl
	local v501 = p498.gov
	if not v501 or (v500.phase == "done" or p498.moving) then
		return false
	end
	local v502 = p498.layer.Visible
	local v503 = p499 * 1000
	if v500.phase == "A" then
		if not v502 then
			v500.n = v500.n + 1
			if v500.n > v_u_21.PHASE_SKIP then
				local v504 = v500.samples
				table.insert(v504, v503)
			end
			if #v500.samples >= v_u_21.PHASE_FRAMES then
				p498.baseA = v501:baselinePhase("A", v500.samples)
				v500.phase = "B"
				v500.samples = {}
				v500.vis = 0
			end
			return true
		end
		if #v500.samples >= v_u_21.PHASE_A_MIN then
			p498.baseA = v501:baselinePhase("A", v500.samples)
		end
		v500.phase = "B"
		v500.samples = {}
		v500.vis = 0
	end
	if not v502 then
		return false
	end
	v500.vis = v500.vis + 1
	if v500.vis <= v_u_21.CAL_AFTER_FRAMES then
		return true
	end
	if not p498.calDone then
		if p498.nFree >= v_u_21.CAL_SETS or p498.total >= p498.ceiling then
			v_u_312.calibrate(p498)
			p498.calDone = true
		end
		return true
	end
	local v505 = v500.samples
	table.insert(v505, v503)
	if #v500.samples >= v_u_21.PHASE_FRAMES then
		p498.baseB = v501:baselinePhase("B", v500.samples)
		v500.samples = {}
		if v501:needsRecheck() then
			v500.rechecks = v500.rechecks + 1
		else
			v500.phase = "done"
		end
		p498.dropsDirty = true
	end
	return v500.phase ~= "done"
end
function v_u_312.prime(p507, p508, p509) -- name: prime
	-- upvalues: (copy) v_u_17, (copy) v_u_13, (copy) v_u_21, (copy) v_u_14, (copy) v_u_102
	if p507.primed then
		return true
	end
	local v510 = v_u_17()
	local v511 = v510 + p508 / 1000
	local v512 = p507.world
	if not (v512.ready or v512:prepare((v_u_13(0.0005, v511 - v_u_17())))) then
		if p509 then
			p507.cpuMs = p507.cpuMs + (v_u_17() - v510) * 1000
		end
		if not p507.firstDone then
			local v513 = p507.fp
			v513.prime = v513.prime + (v_u_17() - v510) * 1000
		end
		return false
	end
	local v514
	if p507.firstDone then
		v514 = v_u_21.PRE_FRAMES
	else
		v514 = v_u_14(v_u_21.PRE_FRAMES, v_u_21.FIRST_FRAMES)
	end
	if p507.total < v514 then
		v_u_102(p507, v514 - p507.total, v511)
	end
	if p509 then
		p507.cpuMs = p507.cpuMs + (v_u_17() - v510) * 1000
	end
	if not p507.firstDone then
		local v515 = p507.fp
		v515.prime = v515.prime + (v_u_17() - v510) * 1000
	end
	if p507.total >= v_u_14(v_u_21.PRE_FRAMES, p507.ceiling) then
		p507.primed = true
	end
	return p507.primed
end
local function v_u_521(p516) -- name: trim
	-- upvalues: (copy) v_u_21
	local v517 = p516.ceiling
	local v518 = 0
	while v517 < p516.total and (p516.nFree > 0 and v518 < v_u_21.TRIM_MAX) do
		local v519
		if p516.free[2].n > 0 then
			v519 = p516.free[2]
		else
			v519 = p516.free[1]
		end
		if v519.n == 0 then
			v519 = p516.free[1]
		end
		if v519.n == 0 then
			break
		end
		local v520 = v519[v519.n]
		v519[v519.n] = nil
		v519.n = v519.n - 1
		p516.nFree = p516.nFree - 1
		p516.total = p516.total - 1
		p516.frames[v520] = nil
		v520:Destroy()
		v518 = v518 + 1
	end
	p516.trimmed = p516.trimmed + v518
end
local function v_u_525(p522) -- name: updateCeiling
	-- upvalues: (copy) v_u_7, (copy) v_u_397, (copy) v_u_21, (copy) v_u_12
	local v523 = v_u_7.TIERS[p522.tier == "mini" and "low" or p522.tier]
	local v524 = select(1, v_u_397(p522))
	if p522.tier == "mini" then
		v524 = v_u_21.MINI_CAP
	end
	p522.ceiling = v_u_12(v524 * v_u_21.POOL_FACTOR + v_u_21.POOL_PLUS)
	p522.restNow = v524
	return v523
end
function v_u_312.step(p526, p527, _, p528) -- name: step
	-- upvalues: (copy) v_u_17, (copy) v_u_312, (copy) v_u_21, (copy) v_u_506, (copy) v_u_525, (copy) v_u_11, (copy) v_u_125, (copy) v_u_458, (copy) v_u_480, (copy) v_u_521, (copy) v_u_391, (copy) v_u_102, (copy) v_u_14
	if p526.destroyed then
		return false
	end
	local v529 = v_u_17()
	p526.now = v529
	p526.steps = p526.steps + 1
	local v530 = (type(p527) ~= "number" or (p527 ~= p527 or (p527 < 0 or p527 >= 1000000))) and 0.016666666666666666 or p527
	if debug.profilebegin then
		debug.profilebegin("Globe.dots")
	end
	if not p526.primed then
		if p526.world.ready then
			if p526.firstDone then
				v_u_312.prime(p526, v_u_21.CREATE_MS[p526.tier] or 3)
			end
		else
			v_u_312.prime(p526, v_u_21.WORLD_STEP_MS)
		end
	end
	local v531 = false
	if p526.moving then
		if p526.gov and (not p528 and p526.primed) then
			p526.gov:feed(v530 * 1000, v529)
		end
	else
		v531 = v_u_506(p526, v530) and true or v531
	end
	v_u_525(p526)
	local v532 = v_u_17()
	local v533 = p526.world
	local v534
	if v533.ready then
		local v535 = p526.mgr
		local v536 = (p526.viewVer ~= p526.mgrVer or (v535.fine == nil or v535.coarse == nil)) and true or p526.zonesVer ~= v533.zonesVer
		if p526.settleUpd then
			if v529 - p526.lastChange >= 0.55 then
				p526.settleUpd = false
				v536 = true
			else
				v531 = true
			end
		end
		if v536 then
			v535:update(v529, p526.lat0, p526.lon0, p526.z, v_u_11.R1 * p526.lensR * p526.z, p526.lensR)
			p526.mgrVer = p526.viewVer
			p526.zonesVer = v533.zonesVer
		end
		if v536 or v535:busy() then
			local v537
			if v535.coarse == nil then
				v537 = v_u_21.BUILD_FIRST_MS
			else
				v537 = v_u_21.BUILD_MS[p526.tier] or 4
			end
			v535:pump(v529, v537 / 1000)
			if v_u_125(p526) then
				p526.needDraw = true
				p526.dropsDirty = true
				p526.swappedNow = true
				p526.buildMs = p526.fineL and (p526.fineL.win.ms or 0) or 0
			end
		end
		v534 = v535:busy() and true or v531
	else
		v534 = true
	end
	p526.tWinMs = (v_u_17() - v532) * 1000
	if not p526.firstDone then
		local v538 = p526.fp
		v538.win = v538.win + p526.tWinMs
	end
	local v539 = (p526.mgr.fillM or 0) * 16 + (p526.mgr.contM or 0)
	if v539 ~= p526.stageKey then
		p526.stageKey = v539
		p526.stageDirty = p526.moving
	end
	if p526.stageDirty and (p526.moving and (not p526.swappedNow and p526.fineL)) then
		p526.stageDirty = false
		v_u_458(p526)
	end
	p526.swappedNow = false
	if not p526.moving then
		if v529 - p526.lastChange >= v_u_21.RETURN_S then
			local v540 = p526.gov
			if v540 and v540:pending() then
				v540:apply()
				p526.dropsDirty = true
			end
			if p526.dropsDirty and p526.fineL then
				v_u_480(p526)
				p526.needDraw = true
			elseif p526.dropsDirty and not p526.mgr:busy() then
				p526.dropsDirty = false
			end
			if p526.total > p526.ceiling then
				v_u_521(p526)
				v534 = p526.total > p526.ceiling and p526.nFree > 0 and true or v534
			end
		else
			v534 = true
		end
	end
	if p526.needDraw and (p526.fineL or p526.coarseL) then
		p526.needDraw = false
		local v541 = v_u_17()
		v_u_391(p526)
		if not p526.firstDone then
			local v542 = p526.fp
			v542.draw = v542.draw + (v_u_17() - v541) * 1000
		end
		if p526.deferred > 0 then
			p526.needDraw = true
			v534 = true
		end
		if p526.missed > 0 and (p526.total < p526.ceiling or p526.nFree > 0) then
			p526.needDraw = true
			v534 = true
		end
		if not p526.firstDone and p526.live > 0 then
			p526.firstDone = true
			p526.firstDots = p526.live
			p526.tFirst = p526.cpuMs + (v_u_17() - v529) * 1000
		end
	end
	local v543 = p526.live + p526.missed
	local v544
	if p526.calDone then
		v544 = v_u_21.RESERVE
	else
		v544 = v_u_21.CAL_SETS + 20
	end
	local v545 = v543 + v544
	if p526.total < v545 and (p526.total < p526.ceiling and (p526.firstDone or p526.total < 320)) then
		local v546 = v_u_17() + (v_u_21.CREATE_MS[p526.tier] or 3) / 1000
		v_u_102(p526, v545 - p526.total, v546)
		v534 = p526.total < v545 and p526.total < p526.ceiling and true or v534
		if p526.missed > 0 then
			p526.needDraw = true
		end
	end
	if p526.apN > 0 then
		local v547 = p526.apH
		local v548 = p526.apF
		local v549 = p526.apT
		local v550 = p526.apA
		local v551 = v_u_17()
		while v547 <= p526.apN and v551 - v549[v547] >= v_u_21.APPEAR_S do
			local v552 = v548[v547]
			if v552 then
				v552.BackgroundTransparency = v550[v547]
				p526.apOf[v552] = nil
			end
			v548[v547] = nil
			v547 = v547 + 1
		end
		if p526.apN < v547 then
			p526.apN = 0
			v547 = 1
		else
			v534 = true
		end
		p526.apH = v547
	end
	local v553 = (v_u_17() - v529) * 1000
	if not p526.firstDone then
		p526.cpuMs = p526.cpuMs + v553
	end
	p526.lastMs = v553
	local v554 = p526.meterT
	local v555 = p526.meterI % v_u_21.METER + 1
	p526.meterI = v555
	p526.meterN = v_u_14(p526.meterN + 1, v_u_21.METER)
	v554[v555] = v553 / 1000
	local v556 = not p526.moving and (not p526.calDone and (p526.primed and p526.layer.Visible)) and true or v534
	if debug.profileend then
		debug.profileend()
	end
	return (not p526.primed or p526.needDraw) and true or v556
end
local function v_u_562(p557, p558, p559) -- name: pctl
	-- upvalues: (copy) v_u_12, (copy) v_u_14, (copy) v_u_13
	local v560 = {}
	for v561 = 1, p559 do
		v560[#v560 + 1] = p557[v561]
	end
	table.sort(v560)
	return #v560 == 0 and 0 or v560[v_u_13(1, (v_u_14(#v560, (v_u_12(p558 * #v560 + 0.5)))))]
end
function v_u_312.holeShare(p563) -- name: holeShare
	return p563.drawFrames == 0 and 0 or p563.holeFrames / p563.drawFrames
end
function v_u_312.sample(p564, p565) -- name: sample
	local v566 = {}
	for _, v567 in { p564.fineL, p564.coarseL } do
		if not v567 then
			continue
		end
		local v568 = v567.slot
		local v569 = v567.win
		for v570 = 1, v569.n do
			local v571 = v568[v570]
			if not v571 or (not v571.Visible or #v566 >= p565) then
				continue
			end
			v566[#v566 + 1] = {
				["frame"] = v571,
				["key"] = v569.key[v570],
				["ex"] = v569.ex[v570],
				["ey"] = v569.ey[v570],
				["ez"] = v569.ez[v570],
				["kind"] = (v569.nFill or 0) < v570 and 2 or 1,
				["band"] = v567.st[v570] % 4
			}
		end
	end
	return v566
end
function v_u_312.stats(p572) -- name: stats
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_562, (copy) v_u_23, (copy) v_u_312
	local v573 = p572.gov
	local v574 = p572.baseRest
	local v575 = p572.baseMove
	local v576 = p572.gov
	if v576 then
		local v577 = v576:caps()
		v574 = v_u_14(v574, v577.rest)
		v575 = v_u_14(v575, v577.move)
	end
	local v578 = v_u_13(1, v574)
	local v579 = v_u_13(1, v575)
	local v580 = p572.fineL
	local v581 = p572.coarseL
	local v582 = p572.meterT
	local v583 = {
		["visible"] = p572.live,
		["wanted"] = p572.wantN,
		["candidates"] = (not v580 and 0 or v580.win.n) + (not v581 and 0 or v581.win.n),
		["pool"] = p572.total,
		["free"] = p572.nFree,
		["instances"] = p572.total,
		["levelFill"] = p572.levelF,
		["levelContour"] = p572.levelC,
		["dropFill"] = p572.rsF,
		["dropContour"] = p572.rsC,
		["dropMove"] = p572.mvF + p572.mvC,
		["moveDropFill"] = p572.mvF,
		["moveDropContour"] = p572.mvC,
		["ms"] = p572.lastMs,
		["ma"] = v_u_562(v582, 0.5, p572.meterN) * 1000,
		["p95"] = v_u_562(v582, 0.95, p572.meterN) * 1000,
		["thin"] = p572.mvF + p572.mvC + (p572.mvDq == v_u_23 and 0 or 1),
		["capRest"] = v578,
		["capMove"] = v579
	}
	local v584
	if v573 then
		v584 = v573.base or nil
	else
		v584 = nil
	end
	v583.base = v584
	v583.trips = v573 and (v573:trips() or 0) or 0
	v583.off = false
	v583.quality = not v573 and 1 or v573:quality()
	local v585
	if v573 then
		v585 = v573:atFloor()
	else
		v585 = false
	end
	v583.qFloor = v585
	v583.stepMs = not v573 and 0 or v573:stepMs()
	v583.densRest = p572.rsDq[1]
	v583.densRestMinor = p572.rsDq[2]
	v583.densMove = p572.mvDq[1]
	v583.densMoveMinor = p572.mvDq[2]
	v583.restLevel = not v573 and 0 or v573:restLevel()
	v583.floorTrips = not v573 and 0 or v573:floorTrips()
	v583.recoveries = not v573 and 0 or v573:recoveries()
	v583.holeShare = v_u_312.holeShare(p572)
	v583.holeFrames = p572.holeFrames
	v583.drawFrames = p572.drawFrames
	v583.coarse = p572.coarseOnly and 1 or 0
	v583.buildMs = p572.buildMs
	v583.firstDots = p572.firstDots
	v583.tFirst = p572.tFirst
	v583.firstParts = p572.fp
	v583.tAttach = p572.tAttach
	local v586
	if v573 then
		v586 = v_u_14(v573:restCap(), p572.baseRest)
	else
		v586 = p572.baseRest
	end
	v583.restCap = v586
	v583.restTrips = v573 and v573:restTrips() or 0
	v583.baseA = p572.baseA
	v583.baseB = p572.baseB
	v583.calC = p572.calC
	v583.heapKB = collectgarbage("count")
	v583.swaps = p572.swaps
	v583.trimmed = p572.trimmed
	v583.missed = p572.missed
	v583.deferred = p572.deferred
	v583.capped = p572.capped
	v583.dropMs = p572.dropMs
	v583.tFineMs = p572.tFineMs
	v583.tCoarseMs = p572.tCoarseMs
	v583.tWinMs = p572.tWinMs
	v583.writes = p572.writesN
	v583.acquired = p572.acqN
	v583.steady = p572.steadyN
	v583.moving = p572.moving
	v583.tier = p572.tier
	v583.firstCount = p572.firstCount
	v583.blPhase = p572.bl.phase
	v583.calDone = p572.calDone
	v583.fine = v580 ~= nil
	v583.coarseWin = v581 ~= nil
	v583.fineN = not v580 and 0 or v580.win.n
	v583.coarseN = not v581 and 0 or v581.win.n
	return v583
end
local function v_u_589(p587) -- name: resetWindows
	-- upvalues: (copy) v_u_135, (copy) v_u_6, (copy) v_u_22, (copy) v_u_21, (copy) v_u_23
	v_u_135(p587, p587.fineL)
	v_u_135(p587, p587.coarseL)
	p587.fineL = nil
	p587.coarseL = nil
	p587.fineSerial = p587.fineSerial + 1
	p587.mgr = v_u_6.newWindows(p587.world, {
		["tier"] = v_u_22[p587.tier] or "pc",
		["buildDelay"] = v_u_21.buildDelay
	})
	p587.mgrVer = -1
	p587.needDraw = true
	p587.firstF = nil
	p587.firstC = nil
	p587.rsF = 0
	p587.rsC = 0
	p587.mvF = 0
	p587.mvC = 0
	p587.rsMode = 0
	p587.mvMode = 0
	local v588 = v_u_23
	p587.rsDq = v_u_23
	p587.mvDq = v588
	p587.dropsDirty = true
end
local function v_u_600(p590, p591) -- name: applyTier
	-- upvalues: (copy) v_u_7, (copy) v_u_21, (copy) v_u_14
	p590.tier = p591
	local v592 = v_u_7.TIERS[p591 == "mini" and "low" or p591] or v_u_7.TIERS.high
	local v593 = v592.rest
	local v594 = v592.move
	p590.tierRest = v593
	p590.tierMove = v594
	if p591 == "mini" then
		local v595 = v_u_21.MINI_CAP
		local v596 = v_u_21.MINI_CAP
		p590.tierRest = v595
		p590.tierMove = v596
	else
		local v597 = p590.tierMove * v_u_21.MOVE_SCALE
		p590.tierMove = math.floor(v597)
	end
	local v598 = p590.tierRest
	local v599 = p590.tierMove
	p590.baseRest = v598
	p590.baseMove = v599
	p590.denseBelow = p591 == "mini" and 0 or v592.min
	if p590.capsOpt then
		p590.baseRest = v_u_14(p590.baseRest, p590.capsOpt.rest or p590.baseRest)
		p590.baseMove = v_u_14(p590.baseMove, p590.capsOpt.move or p590.baseMove)
	end
	p590.ownGov = false
	if p591 == "mini" then
		p590.calDone = true
	end
	if p590.gov0 == nil and p591 ~= "mini" then
		p590.gov = v_u_7.new({
			["rest"] = p590.tierRest,
			["move"] = p590.tierMove,
			["min"] = v592.min,
			["floorRest"] = v592.floorRest,
			["floorMove"] = v592.floorMove,
			["stepMs"] = v592.stepMs,
			["floorStepMs"] = v592.floorStepMs
		})
		p590.ownGov = true
		return
	elseif p590.gov0 == nil or p591 == "mini" then
		p590.gov = nil
	else
		p590.gov = p590.gov0
	end
end
function v_u_20.new(p601, p602) -- name: new
	-- upvalues: (copy) v_u_17, (copy) v_u_4, (copy) v_u_23, (copy) v_u_21, (copy) v_u_312, (copy) v_u_154, (copy) v_u_600, (copy) v_u_525, (copy) v_u_6, (copy) v_u_8, (copy) v_u_22, (ref) v_u_94, (copy) v_u_102, (copy) v_u_14, (copy) v_u_13, (copy) v_u_2, (copy) v_u_480, (copy) v_u_589
	local v603 = v_u_17()
	local v604 = p602 or {}
	local v605 = v604.lensR or 386
	local v_u_607 = {
		["layer"] = p601,
		["lensR"] = v605,
		["cx"] = v604.cx or v605,
		["cy"] = v604.cy or v605,
		["S"] = v604.scale or v_u_4.uiScale(),
		["lat0"] = 0,
		["lon0"] = 0,
		["z"] = 1,
		["viewVer"] = 0,
		["mgrVer"] = -1,
		["zonesVer"] = -1,
		["moving"] = false,
		["lastChange"] = v_u_17() - 10,
		["frames"] = {},
		["free"] = {
			{
				["n"] = 0
			},
			{
				["n"] = 0
			}
		},
		["total"] = 0,
		["nFree"] = 0,
		["ceiling"] = 0,
		["ctx"] = {},
		["apF"] = {},
		["apOf"] = {},
		["apT"] = {},
		["apA"] = {},
		["apN"] = 0,
		["apH"] = 1,
		["now"] = v_u_17(),
		["live"] = 0,
		["wantN"] = 0,
		["missed"] = 0,
		["deferred"] = 0,
		["capped"] = 0,
		["rsF"] = 0,
		["rsC"] = 0,
		["rsMode"] = 0,
		["mvMode"] = 0,
		["rsDq"] = v_u_23,
		["mvDq"] = v_u_23,
		["mvF"] = 0,
		["mvC"] = 0,
		["levelF"] = 0,
		["levelC"] = 0,
		["needDraw"] = true,
		["dropsDirty"] = true,
		["primed"] = false,
		["cpuMs"] = 0,
		["fp"] = {
			["prime"] = 0,
			["win"] = 0,
			["draw"] = 0
		},
		["steps"] = 0,
		["drawFrames"] = 0,
		["fineSerial"] = 0,
		["holeFrames"] = 0,
		["swaps"] = 0,
		["trimmed"] = 0,
		["lastMs"] = 0,
		["meterT"] = table.create(v_u_21.METER, 0),
		["meterI"] = 0,
		["meterN"] = 0,
		["reducedFn"] = v604.reduced or function()
			return false
		end,
		["reduceFlag"] = false,
		["capsOpt"] = v604.caps,
		["gov0"] = v604.gov,
		["bl"] = {
			["phase"] = "A",
			["samples"] = nil,
			["n"] = 0,
			["vis"] = 0,
			["rechecks"] = 0,
			["samples"] = {}
		},
		["destroyed"] = false,
		["capNow"] = v_u_312.capNow,
		["isReduced"] = function(p606)
			return p606.reduceFlag or p606.reducedFn() == true
		end
	}
	v_u_154(v_u_607)
	v_u_600(v_u_607, v604.tier or "high")
	v_u_525(v_u_607)
	v_u_607.world = v604.lattice or v_u_6.new({
		["land"] = nil,
		["p0"] = nil,
		["c0"] = nil,
		["adaptive"] = true,
		["land"] = v_u_8,
		["p0"] = v_u_21.P0_DEG,
		["c0"] = v_u_21.C0_DEG
	})
	if v604.tintZones then
		v_u_607.world:setZones(v604.tintZones)
	end
	v_u_607.mgr = v_u_6.newWindows(v_u_607.world, {
		["tier"] = v_u_22[v_u_607.tier] or "pc",
		["buildDelay"] = v_u_21.buildDelay
	})
	if v_u_607.layer then
		v_u_607.layer:SetAttribute("HushNoFade", true)
		if v_u_94 and v_u_94.noFade then
			local function v608()
				-- upvalues: (ref) v_u_94, (copy) v_u_607
				v_u_94.noFade[v_u_607.layer] = true
			end
			pcall(v608)
		end
	end
	local v609 = v_u_17() + 0.012
	v_u_102(v_u_607, v_u_21.ATTACH_FRAMES, v609)
	v_u_607.world:prepare((v_u_13(0.0005, (v_u_14(v_u_21.ATTACH_WORLD_MS / 1000, v609 - v_u_17() + 0.004)))))
	local v_u_610 = {
		["layer"] = p601
	}
	local v611 = v_u_607.world
	local v612 = v_u_607.mgr
	v_u_610.world = v611
	v_u_610.mgr = v612
	local v_u_613 = {}
	local v614 = v_u_4.scaleChanged
	local function v622(p615)
		-- upvalues: (copy) v_u_607, (ref) v_u_4, (ref) v_u_154, (ref) v_u_13
		local v616 = v_u_607
		if type(p615) ~= "number" then
			p615 = v_u_4.uiScale()
		end
		v616.S = p615
		v_u_154(v_u_607)
		for _, v617 in { v_u_607.fineL, v_u_607.coarseL } do
			if not v617 then
				continue
			end
			for v618 = 1, v617.win.n do
				local v619 = v617.slot[v618]
				if not v619 then
					continue
				end
				local v620 = v_u_13(1, v617.st[v618] % 4)
				v619.Size = v_u_607.ud[(v617.win.nFill or 0) < v618 and 2 or 1][v620]
				v617.pos[v618] = -1
			end
		end
		for _, v621 in { v_u_607.fineL, v_u_607.coarseL } do
			if not v621 then
				continue
			end
			v621.sig = ""
		end
		v_u_607.needDraw = true
	end
	table.insert(v_u_613, v614:Connect(v622))
	local function v626()
		-- upvalues: (copy) v_u_613, (ref) v_u_2, (copy) v_u_607
		local v623 = v_u_613
		local v624 = v_u_2.WindowFocused
		local function v625()
			-- upvalues: (ref) v_u_607
			if v_u_607.gov and v_u_607.bl.phase == "done" then
				v_u_607.gov:focusReturned()
				v_u_607.bl = {
					["phase"] = "B",
					["samples"] = nil,
					["n"] = 0,
					["vis"] = 0,
					["rechecks"] = 0,
					["samples"] = {}
				}
			end
		end
		table.insert(v623, v624:Connect(v625))
	end
	pcall(v626)
	function v_u_610.setGeometry(p627, p628, p629) -- name: setGeometry
		-- upvalues: (copy) v_u_607
		local v630
		if type(p627) == "number" and (p627 == p627 and p627 ~= (1 / 0)) then
			v630 = p627 ~= (-1 / 0)
		else
			v630 = false
		end
		if v630 then
			local v631
			if type(p628) == "number" and (p628 == p628 and p628 ~= (1 / 0)) then
				v631 = p628 ~= (-1 / 0)
			else
				v631 = false
			end
			if v631 then
				local v632
				if type(p629) == "number" and (p629 == p629 and p629 ~= (1 / 0)) then
					v632 = p629 ~= (-1 / 0)
				else
					v632 = false
				end
				if v632 and p629 > 0 then
					if p627 ~= v_u_607.cx or (p628 ~= v_u_607.cy or p629 ~= v_u_607.lensR) then
						local v633 = v_u_607
						local v634 = v_u_607
						v_u_607.cx = p627
						v633.cy = p628
						v634.lensR = p629
						for _, v635 in { v_u_607.fineL, v_u_607.coarseL } do
							if not v635 then
								continue
							end
							for v636 = 1, v635.win.n do
								v635.pos[v636] = -1
							end
						end
						local v637 = v_u_607
						v637.viewVer = v637.viewVer + 1
						v_u_607.needDraw = true
						v_u_607.dropsDirty = true
					end
				end
			end
		end
	end
	function v_u_610.setView(p638, p639, p640) -- name: setView
		-- upvalues: (copy) v_u_607, (ref) v_u_17
		local v641
		if type(p638) == "number" and (p638 == p638 and p638 ~= (1 / 0)) then
			v641 = p638 ~= (-1 / 0)
		else
			v641 = false
		end
		if v641 then
			local v642
			if type(p639) == "number" and (p639 == p639 and p639 ~= (1 / 0)) then
				v642 = p639 ~= (-1 / 0)
			else
				v642 = false
			end
			if v642 then
				local v643
				if type(p640) == "number" and (p640 == p640 and p640 ~= (1 / 0)) then
					v643 = p640 ~= (-1 / 0)
				else
					v643 = false
				end
				if v643 and p640 > 0 then
					if p638 ~= v_u_607.lat0 or (p639 ~= v_u_607.lon0 or p640 ~= v_u_607.z) then
						local v644 = v_u_607
						local v645 = v_u_607
						v_u_607.lat0 = p638
						v644.lon0 = p639
						v645.z = p640
						local v646 = v_u_607
						v646.viewVer = v646.viewVer + 1
						v_u_607.lastChange = v_u_17()
						v_u_607.settleUpd = true
						v_u_607.needDraw = true
						v_u_607.dropsDirty = true
					end
				end
			end
		end
	end
	function v_u_610.setMoving(p647) -- name: setMoving
		-- upvalues: (copy) v_u_607, (ref) v_u_17, (ref) v_u_480
		local v648 = p647 == true
		if v648 ~= v_u_607.moving then
			v_u_607.moving = v648
			v_u_607.needDraw = true
			if v648 then
				v_u_607.lastChange = v_u_17()
				if v_u_607.fineL and not v_u_607.dropsKnown then
					v_u_480(v_u_607)
					return
				end
			else
				v_u_607.dropsDirty = true
			end
		end
	end
	function v_u_610.step(p649, p650, p651) -- name: step
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.step(v_u_607, p649, p650, p651)
	end
	function v_u_610.feed(p652, p653) -- name: feed
		-- upvalues: (copy) v_u_607, (ref) v_u_17
		local v654 = v_u_607.gov
		if v654 and (v_u_607.moving and (v_u_607.primed and p653 ~= true)) then
			local v655
			if type(p652) == "number" and (p652 == p652 and p652 ~= (1 / 0)) then
				v655 = p652 ~= (-1 / 0)
			else
				v655 = false
			end
			if v655 and p652 >= 0 then
				v654:feed(p652 * 1000, v_u_17())
			end
		end
	end
	function v_u_610.stepMs() -- name: stepMs
		-- upvalues: (copy) v_u_607
		local v656 = v_u_607.gov
		return not v656 and 0 or v656:stepMs()
	end
	function v_u_610.rebaseline() -- name: rebaseline
		-- upvalues: (copy) v_u_607
		local v657 = v_u_607.gov
		if not v657 or (v_u_607.destroyed or (v_u_607.moving or (v_u_607.bl.phase ~= "done" or v657:restLevel() == 0))) then
			return false
		end
		v657:focusReturned()
		v_u_607.bl = {
			["phase"] = "A",
			["samples"] = nil,
			["n"] = 0,
			["vis"] = 0,
			["rechecks"] = 0,
			["samples"] = {}
		}
		return true
	end
	function v_u_610.setZones(p658) -- name: setZones
		-- upvalues: (copy) v_u_607
		if type(p658) ~= "table" then
			return false
		end
		local v659 = {}
		if type(p658) == "table" then
			for _, v660 in p658 do
				if type(v660) ~= "table" then
					continue
				end
				local v661 = v660.lat
				local v662
				if type(v661) == "number" and (v661 == v661 and v661 ~= (1 / 0)) then
					v662 = v661 ~= (-1 / 0)
				else
					v662 = false
				end
				if not v662 then
					continue
				end
				local v663 = v660.lon
				local v664
				if type(v663) == "number" and (v663 == v663 and v663 ~= (1 / 0)) then
					v664 = v663 ~= (-1 / 0)
				else
					v664 = false
				end
				if not v664 then
					continue
				end
				if v660.km ~= nil then
					local v665 = v660.km
					local v666
					if type(v665) == "number" and (v665 == v665 and v665 ~= (1 / 0)) then
						v666 = v665 ~= (-1 / 0)
					else
						v666 = false
					end
					if not v666 then
						continue
					end
				end
				v659[#v659 + 1] = v660
			end
		end
		local v667 = v_u_607.world.setZones
		local v668 = v_u_607.world
		local v669, v670 = pcall(v667, v668, v659)
		if not v669 then
			return false
		end
		if v670 then
			local v671 = v_u_607
			v671.viewVer = v671.viewVer + 1
			v_u_607.needDraw = true
		end
		return v670
	end
	function v_u_610.setCaps(p672, p673) -- name: setCaps
		-- upvalues: (copy) v_u_607, (ref) v_u_14
		if type(p672) ~= "number" or (p672 ~= p672 or (p672 <= 0 or p672 == (1 / 0))) then
			p672 = nil
		end
		if type(p673) ~= "number" or (p673 ~= p673 or (p673 <= 0 or p673 == (1 / 0))) then
			p673 = nil
		end
		v_u_607.capsOpt = {
			["rest"] = p672,
			["move"] = p673
		}
		v_u_607.baseRest = v_u_14(v_u_607.tierRest, p672 or v_u_607.tierRest)
		v_u_607.baseMove = v_u_14(v_u_607.tierMove, p673 or v_u_607.tierMove)
		v_u_607.dropsDirty = true
		v_u_607.needDraw = true
	end
	function v_u_610.setTier(p674) -- name: setTier
		-- upvalues: (copy) v_u_607, (ref) v_u_6, (ref) v_u_22, (ref) v_u_600, (ref) v_u_525, (ref) v_u_589, (copy) v_u_610
		if p674 ~= v_u_607.tier and v_u_6.TUNING.FILL_MAX_PX[v_u_22[p674] or ""] then
			v_u_600(v_u_607, p674)
			v_u_525(v_u_607)
			v_u_607.bl = {
				["phase"] = nil,
				["samples"] = nil,
				["n"] = 0,
				["vis"] = 0,
				["rechecks"] = 0,
				["phase"] = v_u_607.layer.Visible and "B" or "A",
				["samples"] = {}
			}
			v_u_607.calDone = false
			v_u_589(v_u_607)
			v_u_610.gov = v_u_607.gov
		end
	end
	function v_u_610.calibrate() -- name: calibrate
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.calibrate(v_u_607)
	end
	function v_u_610.setReduceMotion(p675) -- name: setReduceMotion
		-- upvalues: (copy) v_u_607
		v_u_607.reduceFlag = p675 == true
	end
	function v_u_610.prime(p676) -- name: prime
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.prime(v_u_607, p676 or 3, true)
	end
	function v_u_610.stats() -- name: stats
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.stats(v_u_607)
	end
	function v_u_610.pending() -- name: pending
		-- upvalues: (copy) v_u_607
		local v677 = v_u_607.needDraw or v_u_607.mgr:busy() or (v_u_607.apN > 0 or (not v_u_607.primed or v_u_607.dropsDirty))
		if not v677 then
			if v_u_607.settleUpd == true then
				v677 = true
			elseif v_u_607.total > v_u_607.ceiling then
				v677 = v_u_607.nFree > 0
			else
				v677 = false
			end
		end
		return v677
	end
	function v_u_610.holeShare() -- name: holeShare
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.holeShare(v_u_607)
	end
	function v_u_610.sample(p678) -- name: sample
		-- upvalues: (ref) v_u_312, (copy) v_u_607
		return v_u_312.sample(v_u_607, p678 or 20)
	end
	function v_u_610.meter() -- name: meter
		-- upvalues: (ref) v_u_21, (copy) v_u_607
		local v679 = {}
		for v680 = 1, v_u_21.METER do
			v679[v680] = v_u_607.meterT[v680]
		end
		return v679
	end
	function v_u_610.destroy() -- name: destroy
		-- upvalues: (copy) v_u_607, (copy) v_u_613
		if not v_u_607.destroyed then
			v_u_607.destroyed = true
			for _, v681 in v_u_613 do
				v681:Disconnect()
			end
			for v682 in v_u_607.frames do
				v682:Destroy()
			end
			v_u_607.frames = {}
			if v_u_607.layer then
				for _, v683 in v_u_607.layer:GetChildren() do
					if v683.Name ~= "c" or not v683:IsA("Folder") then
						continue
					end
					v683:Destroy()
				end
			end
			v_u_607.chunk = nil
			v_u_607.free = {
				{
					["n"] = 0
				},
				{
					["n"] = 0
				}
			}
			local v684 = v_u_607
			v_u_607.total = 0
			v684.nFree = 0
			local v685 = v_u_607
			v_u_607.fineL = nil
			v685.coarseL = nil
		end
	end
	v_u_610.gov = v_u_607.gov
	v_u_610._self = v_u_607
	v_u_607.tAttach = (v_u_17() - v603) * 1000
	return v_u_610
end
function v_u_20.probe(p686) -- name: probe
	-- upvalues: (ref) v_u_94, (copy) v_u_4, (copy) v_u_12, (copy) v_u_20, (copy) v_u_17, (ref) v_u_93, (copy) v_u_21, (copy) v_u_13, (copy) v_u_7, (copy) v_u_1
	local v687 = p686 or {}
	local v_u_688, v689 = v_u_94.screen("GlobeDotsProbe", v_u_4.layer.menu + 6, {})
	local v690 = v687.D or 772
	local v691 = v_u_4.refSize()
	local v692 = Instance.new("Frame")
	v692.Name = "Lens"
	v692.BackgroundColor3 = v_u_4.color.bgDeep
	v692.BorderSizePixel = 0
	v692.Size = UDim2.fromOffset(v690, v690)
	v692.Position = UDim2.fromOffset(v_u_12((v691.X - v690) / 2), (v_u_12((v691.Y - v690) / 2)))
	local v693 = Instance.new("UICorner")
	v693.CornerRadius = UDim.new(0.5, 0)
	v693.Parent = v692
	v692.Parent = v689
	local v694 = Instance.new("Frame")
	v694.Name = "Dots"
	v694.BackgroundTransparency = 1
	v694.BorderSizePixel = 0
	v694.Size = UDim2.fromScale(1, 1)
	v694.Visible = v687.visible ~= false
	v694.Parent = v692
	local v695 = v687.tier or "high"
	local v_u_696 = v_u_20.new(v694, {
		["lensR"] = v690 / 2,
		["cx"] = v690 / 2,
		["cy"] = v690 / 2,
		["tier"] = v695,
		["caps"] = v687.caps,
		["lattice"] = v687.lattice,
		["scale"] = v687.scale,
		["tintZones"] = v687.tintZones,
		["reduced"] = v687.reduced,
		["gov"] = v687.gov
	})
	local v_u_697 = {
		["d"] = v_u_696,
		["gui"] = v_u_688,
		["lens"] = v692,
		["layer"] = v694,
		["D"] = v690,
		["tier"] = v695
	}
	local v_u_698 = nil
	local v_u_699 = v_u_17()
	local v_u_700 = 0
	local v_u_701 = false
	local v_u_702 = false
	local function v_u_706(p703) -- name: onBeat
		-- upvalues: (ref) v_u_17, (copy) v_u_696, (ref) v_u_701, (ref) v_u_21, (copy) v_u_697, (ref) v_u_13, (ref) v_u_7, (ref) v_u_700, (ref) v_u_702, (ref) v_u_699, (ref) v_u_698, (ref) v_u_93
		local v704 = v_u_17()
		v_u_696.feed(p703, v_u_701)
		local v705 = v_u_13(v_u_21.MIN_STEP_MS[v_u_697.tier] or 0, v_u_696.stepMs())
		if v_u_7.stepDue(v704 * 1000, v_u_700, v705) then
			v_u_700 = v704 * 1000
			if v_u_702 and v704 - v_u_699 >= 0.25 then
				v_u_702 = false
				v_u_696.setMoving(false)
			end
			if not v_u_696.step(p703, 0, true) and (not v_u_702 and (v704 - v_u_699 >= v_u_21.SLEEP_S and v_u_698)) then
				v_u_698:Disconnect()
				v_u_698 = nil
				v_u_93 = v_u_93 - 1
			end
		end
	end
	function v_u_697.wake() -- name: wake
		-- upvalues: (ref) v_u_698, (ref) v_u_1, (copy) v_u_706, (ref) v_u_93
		if not v_u_698 then
			v_u_698 = v_u_1.Heartbeat:Connect(v_u_706)
			v_u_93 = v_u_93 + 1
		end
	end
	function v_u_697.setView(p707, p708, p709) -- name: setView
		-- upvalues: (ref) v_u_699, (ref) v_u_17, (ref) v_u_702, (copy) v_u_696, (copy) v_u_697
		v_u_699 = v_u_17()
		if not v_u_702 then
			v_u_702 = true
			v_u_696.setMoving(true)
		end
		v_u_696.setView(p707, p708, p709)
		v_u_697.wake()
	end
	function v_u_697.place(p710, p711, p712) -- name: place
		-- upvalues: (ref) v_u_699, (ref) v_u_17, (copy) v_u_696, (copy) v_u_697
		v_u_699 = v_u_17() - 1
		v_u_696.setView(p710, p711, p712)
		v_u_697.wake()
	end
	function v_u_697.ignoreGov(p713) -- name: ignoreGov
		-- upvalues: (ref) v_u_701
		v_u_701 = p713 == true
	end
	function v_u_697.conns() -- name: conns
		-- upvalues: (ref) v_u_698
		return v_u_698 and 1 or 0
	end
	function v_u_697.awake() -- name: awake
		-- upvalues: (ref) v_u_698
		return v_u_698 ~= nil
	end
	function v_u_697.sleep() -- name: sleep
		-- upvalues: (ref) v_u_698, (ref) v_u_93
		if v_u_698 then
			v_u_698:Disconnect()
			v_u_698 = nil
			v_u_93 = v_u_93 - 1
		end
	end
	function v_u_697.setTier(p714) -- name: setTier
		-- upvalues: (copy) v_u_697, (copy) v_u_696
		v_u_697.tier = p714
		v_u_696.setTier(p714)
	end
	function v_u_697.destroy() -- name: destroy
		-- upvalues: (ref) v_u_698, (ref) v_u_93, (copy) v_u_696, (copy) v_u_688
		if v_u_698 then
			v_u_698:Disconnect()
			v_u_698 = nil
			v_u_93 = v_u_93 - 1
		end
		v_u_696.destroy()
		v_u_688:Destroy()
	end
	v_u_697.wake()
	return v_u_697
end
return v_u_20