-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutRoom

local v_u_1 = game:GetService("CollectionService")
local v2 = {}
local v_u_3 = Enum.Material
local v_u_4 = {
	["floor"] = Color3.fromHex("45484B"),
	["floorPatch"] = Color3.fromHex("3A3D40"),
	["wall"] = Color3.fromHex("5E6164"),
	["wallDamp"] = Color3.fromHex("3F4245"),
	["ceiling"] = Color3.fromHex("2E3033"),
	["pipe"] = Color3.fromHex("4E5A52"),
	["pipeRust"] = Color3.fromHex("6E4A34"),
	["conduit"] = Color3.fromHex("7A7E82"),
	["cable"] = Color3.fromHex("1B1C1E"),
	["steel"] = Color3.fromHex("4A4F55"),
	["steelDark"] = Color3.fromHex("2E3237"),
	["hazard"] = Color3.fromHex("B8962E"),
	["wood"] = Color3.fromHex("6A503A"),
	["mattress"] = Color3.fromHex("8C8574"),
	["khaki"] = Color3.fromHex("7D735A"),
	["olive"] = Color3.fromHex("4B5234"),
	["barrel"] = Color3.fromHex("3E5A6B"),
	["barrelRust"] = Color3.fromHex("6B4B32"),
	["tube"] = Color3.fromHex("DCEBF2"),
	["warm"] = Color3.fromHex("FFD29A"),
	["red"] = Color3.fromHex("A33A32"),
	["stain"] = Color3.fromHex("202224")
}
local function v_u_14(p5, p6, p7, p8, p9, p10) -- name: P
	local v11 = Instance.new("Part")
	if p10 and p10.shape then
		v11.Shape = p10.shape
	end
	v11.Name = p10 and (p10.n or "Part") or "Part"
	v11.Anchored = true
	v11.Size = p6
	v11.CFrame = p7 * (p10 and p10.r or CFrame.identity)
	v11.Color = p8
	v11.Material = p9
	v11.TopSurface = Enum.SurfaceType.Smooth
	v11.BottomSurface = Enum.SurfaceType.Smooth
	local v12
	if p10 == nil then
		v12 = false
	else
		v12 = p10.c == true
	end
	v11.CanCollide = v12
	v11.CanQuery = (not p10 or p10.q == nil) and true or p10.q
	v11.CanTouch = false
	local v13
	if p10 and p10.s ~= nil then
		v13 = p10.s
	else
		v13 = p6.X * p6.Y * p6.Z > 0.8
	end
	v11.CastShadow = v13
	if p10 and p10.t then
		v11.Transparency = p10.t
	end
	if p10 and p10.refl then
		v11.Reflectance = p10.refl
	end
	v11.Parent = p5
	return v11
end
local function v_u_29(p15, p16, p17, p18, p19, p20) -- name: wallRun
	-- upvalues: (copy) v_u_14, (copy) v_u_4, (copy) v_u_3, (copy) v_u_1
	local v21 = p17 - p16
	local v22 = v21.Magnitude
	if v22 >= 0.05 then
		local v23 = (p16 + p17) / 2
		local v24 = CFrame.lookAt(v23, v23 + v21.Unit)
		local v25 = v_u_14(p15, Vector3.new(p19, 1, v22), v24 * CFrame.new(0, 0.5, 0), v_u_4.wallDamp, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "WallBase"
		})
		v25:SetAttribute("BuildingId", "hideout")
		v_u_1:AddTag(v25, "HushWallBase")
		local v26 = v_u_14
		local v27 = p18 - 1
		local v28 = v26(p15, Vector3.new(p19, v27, v22), v24 * CFrame.new(0, (p18 - 1) / 2 + 1, 0), v_u_4.wall, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "Wall"
		})
		v28:SetAttribute("BuildingId", "hideout")
		v28:SetAttribute("Face", p20)
		v28:SetAttribute("Cut", true)
		v_u_1:AddTag(v28, "HushWall")
	end
end
local function v_u_40(p30, p31, p32, p33, p34, p35) -- name: surfaceText
	local v36 = Instance.new("SurfaceGui")
	v36.Face = p31
	v36.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	v36.PixelsPerStud = 40
	v36.LightInfluence = 1
	v36.CanvasSize = Vector2.new(400, 100)
	local v37 = Instance.new("TextLabel")
	v37.BackgroundTransparency = 1
	v37.Size = UDim2.fromScale(1, 1)
	v37.Text = p32
	v37.TextColor3 = p33
	v37.TextScaled = true
	v37.Font = p34
	v37.TextTransparency = 0.15
	local v38 = Instance.new("UITextSizeConstraint")
	local v39 = 120 * (p35 or 1)
	v38.MaxTextSize = math.floor(v39)
	v38.Parent = v37
	v37.Parent = v36
	v36.Parent = p30
end
local v_u_41 = {
	{
		["pos"] = Vector3.new(26, 0, -24),
		["minLevel"] = 0,
		["flicker"] = true
	},
	{
		["pos"] = Vector3.new(-8, 0, -16),
		["minLevel"] = 1
	},
	{
		["pos"] = Vector3.new(12, 0, -16),
		["minLevel"] = 1,
		["dead"] = true
	},
	{
		["pos"] = Vector3.new(-8, 0, 10),
		["minLevel"] = 0
	},
	{
		["pos"] = Vector3.new(14, 0, 12),
		["minLevel"] = 1
	},
	{
		["pos"] = Vector3.new(28, 0, -4),
		["minLevel"] = 2
	},
	{
		["pos"] = Vector3.new(24, 0, 18),
		["minLevel"] = 2
	},
	{
		["pos"] = Vector3.new(-14, 0, 24),
		["minLevel"] = 2
	},
	{
		["pos"] = Vector3.new(4, 0, 24),
		["minLevel"] = 3
	},
	{
		["pos"] = Vector3.new(-30, 0, 20),
		["minLevel"] = 1,
		["lane"] = true
	},
	{
		["pos"] = Vector3.new(-30, 0, -2),
		["minLevel"] = 1,
		["lane"] = true
	},
	{
		["pos"] = Vector3.new(-30, 0, -24),
		["minLevel"] = 2,
		["lane"] = true
	}
}
local v_u_42 = {
	{
		["pos"] = Vector3.new(33, 3.95, 14.5),
		["range"] = 16,
		["brightness"] = 1.2
	},
	{
		["pos"] = Vector3.new(-13.8, 2.65, 23.6),
		["range"] = 13,
		["brightness"] = 1
	},
	{
		["pos"] = Vector3.new(-1.2, 4.3, -4.65),
		["range"] = 14,
		["brightness"] = 1.1
	}
}
local function v_u_64(p43, p44, p45, p46, p47, p48) -- name: buildTube
	-- upvalues: (copy) v_u_14, (copy) v_u_4, (copy) v_u_3, (copy) v_u_1
	local v49 = p45.len or 6
	local v50 = CFrame.new
	local v51 = p44 + p45.pos
	local v52 = p46 - 1.55
	local v53 = v50(v51 + Vector3.new(0, v52, 0))
	local v54 = v_u_14
	local v55 = v49 + 0.3
	v54(p43, Vector3.new(v55, 0.22, 0.7), v53 * CFrame.new(0, 0.25, 0), v_u_4.steel, v_u_3.Metal, {
		["n"] = "Housing",
		["s"] = false,
		["q"] = false
	})
	for _, v56 in { -1, 1 } do
		v_u_14(p43, Vector3.new(0.06, 1.3, 0.06), v53 * CFrame.new(v56 * v49 * 0.4, 1, 0), v_u_4.steelDark, v_u_3.Metal, {
			["n"] = "Chain",
			["s"] = false,
			["q"] = false
		})
	end
	local v57 = v_u_14
	local v58 = Vector3.new(v49, 0.22, 0.22)
	local v59 = v_u_4.tube
	local v60
	if p47 then
		v60 = v_u_3.Neon
	else
		v60 = v_u_3.Glass
	end
	local v61 = v57(p43, v58, v53, v59, v60, {
		["shape"] = nil,
		["n"] = "Tube",
		["s"] = false,
		["q"] = false,
		["shape"] = Enum.PartType.Cylinder
	})
	v61:SetAttribute("Kind", "Interior")
	v61:SetAttribute("BuildingId", "hideout")
	v61:SetAttribute("Flicker", p45.flicker == true)
	v61:SetAttribute("Dead", p45.dead == true and true or not p47)
	v61:SetAttribute("LightColor", v_u_4.tube)
	v61:SetAttribute("HideoutTube", p48)
	local v62 = Instance.new("PointLight")
	v62.Color = v_u_4.tube
	v62.Range = p45.lane and 26 or 22
	v62.Brightness = p47 and 1.35 or 0
	v62.Shadows = false
	local v63
	if p47 then
		v63 = p45.dead ~= true
	else
		v63 = p47
	end
	v62.Enabled = v63
	v62.Parent = v61
	if p47 and p45.dead ~= true then
		v_u_1:AddTag(v61, "HushLight")
		return v61
	else
		if not p47 then
			v61.Color = Color3.fromHex("5A5E62")
		end
		return v61
	end
end
function v2.build(p65, p_u_66, p67, p68) -- name: build
	-- upvalues: (copy) v_u_1, (copy) v_u_14, (copy) v_u_4, (copy) v_u_3, (copy) v_u_29, (copy) v_u_40, (copy) v_u_41, (copy) v_u_64, (copy) v_u_42
	local v69
	if p68 then
		v69 = p68.shell == false
	else
		v69 = p68
	end
	local v70 = not v69
	local v71
	if p68 == nil then
		v71 = false
	else
		v71 = p68.wallExt == true
	end
	local v_u_72 = p67.half
	local v_u_73 = p67.height
	local v74 = p67.wall
	local v_u_75 = Instance.new("Model")
	v_u_75.Name = "HideoutRoom"
	v_u_75:SetAttribute("BuildingId", "hideout")
	v_u_75:SetAttribute("Kind", "Hideout")
	v_u_75:SetAttribute("Indoor", true)
	v_u_1:AddTag(v_u_75, "HushBuilding")
	v_u_75:SetAttribute("SizeX", v_u_72.X * 2)
	v_u_75:SetAttribute("SizeZ", v_u_72.Z * 2)
	local v_u_76 = {}
	local v_u_77 = Instance.new("Folder")
	v_u_77.Name = "HideoutLights"
	if v70 then
		local v78 = v_u_14
		local v79 = v_u_72.X * 2 + v74 * 2
		local v80 = v_u_72.Z * 2 + v74 * 2
		local v81 = v78(v_u_75, Vector3.new(v79, 1, v80), CFrame.new(p_u_66.X + 0, p_u_66.Y + -0.5, p_u_66.Z + 0), v_u_4.floor, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "Floor"
		})
		v81:SetAttribute("BuildingId", "hideout")
		v81:SetAttribute("Room", "Basement")
		v_u_1:AddTag(v81, "HushFloor")
		local v82 = Random.new(4242)
		for _ = 1, 14 do
			local v83 = v82:NextNumber(3, 9)
			local v84 = v82:NextNumber(3, 9)
			local v85 = v_u_14
			local v86 = Vector3.new(v83, 0.02, v84)
			local v87 = v82:NextNumber(-v_u_72.X + 5, v_u_72.X - 5)
			local v88 = v82:NextNumber(-v_u_72.Z + 5, v_u_72.Z - 5)
			v85(v_u_75, v86, CFrame.new(p_u_66.X + v87, p_u_66.Y + 0.01, p_u_66.Z + v88) * CFrame.Angles(0, v82:NextNumber(0, 3.141592653589793), 0), v_u_4.floorPatch, v_u_3.Concrete, {
				["n"] = "Patch",
				["s"] = false,
				["q"] = false
			})
		end
		for _ = 1, 8 do
			local v89 = v_u_14
			local v90 = v82:NextNumber(1.5, 4)
			local v91 = Vector3.new(v90, 0.02, v82:NextNumber(1.5, 4))
			local v92 = v82:NextNumber(-v_u_72.X + 4, v_u_72.X - 4)
			local v93 = v82:NextNumber(-v_u_72.Z + 4, v_u_72.Z - 4)
			v89(v_u_75, v91, CFrame.new(p_u_66.X + v92, p_u_66.Y + 0.025, p_u_66.Z + v93) * CFrame.Angles(0, v82:NextNumber(0, 3.141592653589793), 0), v_u_4.stain, v_u_3.Slate, {
				["n"] = "Stain",
				["s"] = false,
				["q"] = false,
				["t"] = 0.55
			})
		end
		v_u_14(v_u_75, Vector3.new(5.5, 0.02, 3.8), CFrame.new(p_u_66.X + 26, p_u_66.Y + 0.03, p_u_66.Z + -12), Color3.fromHex("1E2226"), v_u_3.Slate, {
			["n"] = "Puddle",
			["s"] = false,
			["q"] = false,
			["refl"] = 0.35,
			["t"] = 0.1
		})
		v_u_14(v_u_75, Vector3.new(1.6, 0.04, 1.6), CFrame.new(p_u_66.X + 4, p_u_66.Y + 0.03, p_u_66.Z + 0), v_u_4.steelDark, v_u_3.DiamondPlate, {
			["n"] = "Drain",
			["s"] = false,
			["q"] = false
		})
		for v94 = -2, 2 do
			local v95 = v_u_14
			local v96 = v94 * 1.6 + 26
			v95(v_u_75, Vector3.new(0.9, 0.03, 3), CFrame.new(p_u_66.X + v96, p_u_66.Y + 0.03, p_u_66.Z + -27.5) * CFrame.Angles(0, 0.6108652381980153, 0), v_u_4.hazard, v_u_3.Concrete, {
				["n"] = "Hazard",
				["s"] = false,
				["q"] = false
			})
		end
		local v97 = v_u_14
		local v98 = v_u_72.X * 2 + v74 * 2
		local v99 = v_u_72.Z * 2 + v74 * 2
		local v100 = Vector3.new(v98, 1, v99)
		local v101 = v_u_73 + 0.5
		local v102 = v97(v_u_75, v100, CFrame.new(p_u_66.X + 0, p_u_66.Y + v101, p_u_66.Z + 0), v_u_4.ceiling, v_u_3.Concrete, {
			["n"] = "Ceiling"
		})
		v102:SetAttribute("BuildingId", "hideout")
		v_u_1:AddTag(v102, "HushRoof")
		for v103 = -30, 30, 12 do
			local v104 = v_u_14
			local v105 = v_u_72.Z * 2
			local v106 = Vector3.new(1.4, 1.2, v105)
			local v107 = v_u_73 - 0.6
			local v108 = v104(v_u_75, v106, CFrame.new(p_u_66.X + v103, p_u_66.Y + v107, p_u_66.Z + 0), v_u_4.ceiling, v_u_3.Concrete, {
				["n"] = "Beam"
			})
			v108:SetAttribute("BuildingId", "hideout")
			v_u_1:AddTag(v108, "HushRoof")
		end
		local v109 = -v_u_72.Z - v74 / 2
		local v110 = v_u_72.Z + v74 / 2
		local v111 = -v_u_72.X - v74 / 2
		local v112 = v_u_72.X + v74 / 2
		local v113 = v_u_29
		local v114 = p_u_66.X - v_u_72.X - v74
		local v115 = p_u_66.Y
		local v116 = p_u_66.Z + v109
		local v117 = Vector3.new(v114, v115, v116)
		local v118 = p_u_66.X + 26 - 2.3
		local v119 = p_u_66.Y
		local v120 = p_u_66.Z + v109
		v113(v_u_75, v117, Vector3.new(v118, v119, v120), v_u_73, v74, "N")
		local v121 = v_u_29
		local v122 = p_u_66.X + 26 + 2.3
		local v123 = p_u_66.Y
		local v124 = p_u_66.Z + v109
		local v125 = Vector3.new(v122, v123, v124)
		local v126 = p_u_66.X + v_u_72.X + v74
		local v127 = p_u_66.Y
		local v128 = p_u_66.Z + v109
		v121(v_u_75, v125, Vector3.new(v126, v127, v128), v_u_73, v74, "N")
		local v129 = v_u_14
		local v130 = v_u_73 - 7.8
		local v131 = Vector3.new(4.6, v130, v74)
		local v132 = (v_u_73 - 7.8) / 2 + 7.8
		local v133 = v129(v_u_75, v131, CFrame.new(p_u_66.X + 26, p_u_66.Y + v132, p_u_66.Z + v109), v_u_4.wall, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "Lintel"
		})
		v133:SetAttribute("BuildingId", "hideout")
		v133:SetAttribute("Face", "N")
		v133:SetAttribute("Cut", true)
		v_u_1:AddTag(v133, "HushWall")
		local v134 = v_u_29
		local v135 = p_u_66.X - v_u_72.X - v74
		local v136 = p_u_66.Y
		local v137 = p_u_66.Z + v110
		local v138 = Vector3.new(v135, v136, v137)
		local v139 = p_u_66.X + v_u_72.X + v74
		local v140 = p_u_66.Y
		local v141 = p_u_66.Z + v110
		v134(v_u_75, v138, Vector3.new(v139, v140, v141), v_u_73, v74, "S")
		local v142 = v_u_29
		local v143 = p_u_66.X + v111
		local v144 = p_u_66.Y
		local v145 = p_u_66.Z - v_u_72.Z
		local v146 = Vector3.new(v143, v144, v145)
		local v147 = p_u_66.X + v111
		local v148 = p_u_66.Y
		local v149 = p_u_66.Z + v_u_72.Z
		v142(v_u_75, v146, Vector3.new(v147, v148, v149), v_u_73, v74, "W")
		local v150 = v_u_29
		local v151 = p_u_66.X + v112
		local v152 = p_u_66.Y
		local v153 = p_u_66.Z - v_u_72.Z
		local v154 = Vector3.new(v151, v152, v153)
		local v155 = p_u_66.X + v112
		local v156 = p_u_66.Y
		local v157 = p_u_66.Z + v_u_72.Z
		v150(v_u_75, v154, Vector3.new(v155, v156, v157), v_u_73, v74, "E")
		for _, v158 in p67.pillars or {} do
			local v159 = v_u_14
			local v160 = Vector3.new(2.4, v_u_73, 2.4)
			local v161 = v158.X
			local v162 = v_u_73 / 2
			local v163 = v158.Z
			local v164 = v159(v_u_75, v160, CFrame.new(p_u_66.X + v161, p_u_66.Y + v162, p_u_66.Z + v163), v_u_4.wall, v_u_3.Concrete, {
				["c"] = true,
				["n"] = "Pillar"
			})
			local v165 = v_u_14
			local v166 = v158.X
			local v167 = v158.Z
			v165(v_u_75, Vector3.new(2.6, 1, 2.6), CFrame.new(p_u_66.X + v166, p_u_66.Y + 0.5, p_u_66.Z + v167), v_u_4.wallDamp, v_u_3.Concrete, {
				["n"] = "PillarFoot"
			})
			local v168 = v_u_14
			local v169 = v158.X
			local v170 = v158.Z
			v168(v_u_75, Vector3.new(2.5, 0.8, 2.5), CFrame.new(p_u_66.X + v169, p_u_66.Y + 4.2, p_u_66.Z + v170), v_u_4.hazard, v_u_3.Concrete, {
				["n"] = "PillarStripe",
				["s"] = false
			})
			v_u_1:AddTag(v164, "HushOccluder")
		end
		local v171 = -v_u_72.Z
		local v172 = v_u_14
		local v173 = v171 + 1.6
		v172(v_u_75, Vector3.new(6.6, 0.6, 3.2), CFrame.new(p_u_66.X + 26, p_u_66.Y + 0.3, p_u_66.Z + v173), v_u_4.wallDamp, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "Step"
		})
		local v174 = v_u_14
		local v175 = v171 + 0.8
		v174(v_u_75, Vector3.new(6.6, 0.6, 1.6), CFrame.new(p_u_66.X + 26, p_u_66.Y + 0.9, p_u_66.Z + v175), v_u_4.wallDamp, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "Step"
		})
		local v176 = v_u_14
		local v177 = v171 + 0.1
		local v178 = v176(v_u_75, Vector3.new(5.4, 7.2, 0.5), CFrame.new(p_u_66.X + 26, p_u_66.Y + 4.8, p_u_66.Z + v177), v_u_4.steelDark, v_u_3.Metal, {
			["n"] = "DoorFrame"
		})
		v178:SetAttribute("BuildingId", "hideout")
		v178:SetAttribute("Face", "N")
		v178:SetAttribute("Cut", true)
		v_u_1:AddTag(v178, "HushWall")
		v178.CanCollide = true
		local v179 = v_u_14
		local v180 = v171 + 0.35
		local v181 = v179(v_u_75, Vector3.new(4.2, 6.4, 0.35), CFrame.new(p_u_66.X + 26, p_u_66.Y + 4.6, p_u_66.Z + v180), v_u_4.steel, v_u_3.DiamondPlate, {
			["n"] = "DoorLeaf"
		})
		v181:SetAttribute("BuildingId", "hideout")
		v181:SetAttribute("Face", "N")
		v181:SetAttribute("Cut", true)
		v_u_1:AddTag(v181, "HushWall")
		v_u_40(v181, Enum.NormalId.Back, "NO LIGHT UPSTAIRS", Color3.fromHex("B8962E"), Enum.Font.Oswald, 0.4)
		local v182 = v_u_14
		local v183 = v171 + 0.6
		local v184 = v182(v_u_75, Vector3.new(0.3, 1.8, 0.3), CFrame.new(p_u_66.X + 27.4, p_u_66.Y + 4.4, p_u_66.Z + v183), v_u_4.steelDark, v_u_3.Metal, {
			["n"] = "Handle"
		})
		v184:SetAttribute("BuildingId", "hideout")
		v184:SetAttribute("Face", "N")
		v184:SetAttribute("Cut", true)
		v_u_1:AddTag(v184, "HushWall")
		for _, v185 in { 2.4, 6.6 } do
			local v186 = v_u_14
			local v187 = v171 + 0.55
			local v188 = v186(v_u_75, Vector3.new(0.4, 0.8, 0.4), CFrame.new(p_u_66.X + 23.9, p_u_66.Y + v185, p_u_66.Z + v187), v_u_4.steelDark, v_u_3.Metal, {
				["n"] = "Hinge"
			})
			v188:SetAttribute("BuildingId", "hideout")
			v188:SetAttribute("Face", "N")
			v188:SetAttribute("Cut", true)
			v_u_1:AddTag(v188, "HushWall")
		end
		local v189 = v_u_14
		local v190 = v171 + 0.75
		local v191 = v189(v_u_75, Vector3.new(6, 0.45, 0.35), CFrame.new(p_u_66.X + 26, p_u_66.Y + 4.2, p_u_66.Z + v190), v_u_4.wood, v_u_3.Wood, {
			["n"] = "Bar"
		})
		v191:SetAttribute("BuildingId", "hideout")
		v191:SetAttribute("Face", "N")
		v191:SetAttribute("Cut", true)
		v_u_1:AddTag(v191, "HushWall")
		local function v201(p192, p193, p194, p195, p196) -- name: pipeRun
			-- upvalues: (copy) p_u_66, (ref) v_u_14, (copy) v_u_75, (ref) v_u_3, (ref) v_u_1
			local v197 = (p193 + p194) / 2
			local v198 = (p194 - p193).Magnitude
			local v199 = CFrame.lookAt(p_u_66 + v197, p_u_66 + p194) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v200 = v_u_14(v_u_75, Vector3.new(v198, p195, p195), v199, p196, v_u_3.Metal, {
				["shape"] = nil,
				["n"] = "Pipe",
				["s"] = false,
				["shape"] = Enum.PartType.Cylinder
			})
			v200:SetAttribute("BuildingId", "hideout")
			v200:SetAttribute("Face", p192)
			v200:SetAttribute("Cut", true)
			v_u_1:AddTag(v200, "HushWall")
		end
		local v202 = -v_u_72.X
		local v203 = -v_u_72.Z + 0.6
		local v204 = Vector3.new(v202, 9.6, v203)
		local v205 = -v_u_72.Z + 0.6
		v201("N", v204, Vector3.new(22.8, 9.6, v205), 0.9, v_u_4.pipe)
		local v206 = -v_u_72.X
		local v207 = -v_u_72.Z + 0.5
		local v208 = Vector3.new(v206, 10.4, v207)
		local v209 = v_u_72.X
		local v210 = -v_u_72.Z + 0.5
		v201("N", v208, Vector3.new(v209, 10.4, v210), 0.5, v_u_4.pipeRust)
		local v211 = -v_u_72.X + 0.6
		local v212 = -v_u_72.Z
		local v213 = Vector3.new(v211, 9.8, v212)
		local v214 = -v_u_72.X + 0.6
		local v215 = v_u_72.Z
		v201("W", v213, Vector3.new(v214, 9.8, v215), 0.7, v_u_4.pipe)
		local v216 = v_u_72.X - 0.6
		local v217 = -v_u_72.Z
		local v218 = Vector3.new(v216, 9.6, v217)
		local v219 = v_u_72.X - 0.6
		local v220 = v_u_72.Z
		v201("E", v218, Vector3.new(v219, 9.6, v220), 0.8, v_u_4.pipeRust)
		local v221 = -v_u_72.X
		local v222 = v_u_72.Z - 0.6
		local v223 = Vector3.new(v221, 10.2, v222)
		local v224 = v_u_72.X
		local v225 = v_u_72.Z - 0.6
		v201("S", v223, Vector3.new(v224, 10.2, v225), 0.6, v_u_4.pipe)
		local v226 = v_u_14
		local v227 = -v_u_72.Z + 0.6
		local v228 = v226(v_u_75, Vector3.new(0.7, 9.6, 0.7), CFrame.new(p_u_66.X + 24, p_u_66.Y + 4.8, p_u_66.Z + v227), v_u_4.pipe, v_u_3.Metal, {
			["n"] = "DropPipe"
		})
		v228:SetAttribute("BuildingId", "hideout")
		v228:SetAttribute("Face", "N")
		v228:SetAttribute("Cut", true)
		v_u_1:AddTag(v228, "HushWall")
		local v229 = v_u_14
		local v230 = -v_u_72.Z + 1.1
		local v231 = v229(v_u_75, Vector3.new(0.2, 1.4, 1.4), CFrame.new(p_u_66.X + 24, p_u_66.Y + 5.5, p_u_66.Z + v230), v_u_4.red, v_u_3.Metal, {
			["shape"] = nil,
			["r"] = nil,
			["n"] = "Valve",
			["s"] = false,
			["shape"] = Enum.PartType.Cylinder,
			["r"] = CFrame.Angles(0, 1.5707963267948966, 0)
		})
		v231:SetAttribute("BuildingId", "hideout")
		v231:SetAttribute("Face", "N")
		v231:SetAttribute("Cut", true)
		v_u_1:AddTag(v231, "HushWall")
		for _, v232 in { 2, 17 } do
			if v71 and v232 == 17 then
				continue
			end
			local v233 = v_u_14
			local v234 = -v_u_72.Z + 0.2
			local v235 = v233(v_u_75, Vector3.new(0.25, 6, 0.25), CFrame.new(p_u_66.X + v232, p_u_66.Y + 6.2, p_u_66.Z + v234), v_u_4.conduit, v_u_3.Metal, {
				["n"] = "Conduit",
				["s"] = false
			})
			v235:SetAttribute("BuildingId", "hideout")
			v235:SetAttribute("Face", "N")
			v235:SetAttribute("Cut", true)
			v_u_1:AddTag(v235, "HushWall")
			local v236 = v_u_14
			local v237 = -v_u_72.Z + 0.25
			local v238 = v236(v_u_75, Vector3.new(0.9, 0.9, 0.35), CFrame.new(p_u_66.X + v232, p_u_66.Y + 8.2, p_u_66.Z + v237), v_u_4.conduit, v_u_3.Metal, {
				["n"] = "JBox",
				["s"] = false
			})
			v238:SetAttribute("BuildingId", "hideout")
			v238:SetAttribute("Face", "N")
			v238:SetAttribute("Cut", true)
			v_u_1:AddTag(v238, "HushWall")
		end
		local v239 = v71 and 31.5 or 20
		local v240 = v_u_14
		local v241 = -v_u_72.Z + 0.35
		local v242 = v240(v_u_75, Vector3.new(2.4, 3.2, 0.6), CFrame.new(p_u_66.X + v239, p_u_66.Y + 5.4, p_u_66.Z + v241), v_u_4.steel, v_u_3.Metal, {
			["n"] = "FuseBox"
		})
		v242:SetAttribute("BuildingId", "hideout")
		v242:SetAttribute("Face", "N")
		v242:SetAttribute("Cut", true)
		v_u_1:AddTag(v242, "HushWall")
		v242:SetAttribute("Fuse", true)
		local v243 = v_u_14
		local v244 = -v_u_72.Z + 0.68
		local v245 = v243(v_u_75, Vector3.new(0.5, 0.5, 0.1), CFrame.new(p_u_66.X + v239, p_u_66.Y + 6.2, p_u_66.Z + v244), v_u_4.hazard, v_u_3.Plastic, {
			["n"] = "Warning",
			["s"] = false
		})
		v245:SetAttribute("BuildingId", "hideout")
		v245:SetAttribute("Face", "N")
		v245:SetAttribute("Cut", true)
		v_u_1:AddTag(v245, "HushWall")
		local v246 = v_u_14
		local v247 = -v_u_72.X + 0.1
		local v248 = v246(v_u_75, Vector3.new(0.1, 1.6, 9), CFrame.new(p_u_66.X + v247, p_u_66.Y + 7.6, p_u_66.Z + 2), v_u_4.wall, v_u_3.Concrete, {
			["n"] = "Stencil",
			["s"] = false
		})
		v248:SetAttribute("BuildingId", "hideout")
		v248:SetAttribute("Face", "W")
		v248:SetAttribute("Cut", true)
		v_u_1:AddTag(v248, "HushWall")
		v_u_40(v248, Enum.NormalId.Right, "RANGE: EARS ON", Color3.fromHex("C9CCCF"), Enum.Font.Oswald, 0.6)
		local v249 = v_u_14
		local v250 = -v_u_72.X + 0.1
		local v251 = v249(v_u_75, Vector3.new(0.1, 1.4, 6), CFrame.new(p_u_66.X + v250, p_u_66.Y + 6.2, p_u_66.Z + 26), v_u_4.wall, v_u_3.Concrete, {
			["n"] = "Chalk",
			["s"] = false
		})
		v251:SetAttribute("BuildingId", "hideout")
		v251:SetAttribute("Face", "W")
		v251:SetAttribute("Cut", true)
		v_u_1:AddTag(v251, "HushWall")
		v_u_40(v251, Enum.NormalId.Right, "STAY QUIET", Color3.fromHex("D9D4C5"), Enum.Font.PermanentMarker, 0.5)
		local v252 = p67.lane
		local v253 = v252.x1
		local v254 = -v_u_72.Z
		local v255 = v252.fenceZ1
		local v256 = v255 - v254
		local v257 = v_u_14
		local v258 = Vector3.new(1.2, 3.2, v256)
		local v259 = (v254 + v255) / 2
		v257(v_u_75, v258, CFrame.new(p_u_66.X + v253, p_u_66.Y + 1.6, p_u_66.Z + v259), v_u_4.wallDamp, v_u_3.Concrete, {
			["c"] = true,
			["n"] = "LaneBarrier"
		})
		local v260 = v256 / 2
		local v261 = math.floor(v260)
		local v262 = math.max(1, v261)
		local v263 = v256 / v262
		for v264 = 0, v262 - 1 do
			local v265 = v_u_14
			local v266 = Vector3.new(1.3, 0.3, v263)
			local v267 = v254 + (v264 + 0.5) * v263
			local v268 = CFrame.new(p_u_66.X + v253, p_u_66.Y + 3.3, p_u_66.Z + v267)
			local v269
			if v264 % 2 == 0 then
				v269 = v_u_4.hazard
			else
				v269 = v_u_4.cable
			end
			v265(v_u_75, v266, v268, v269, v_u_3.Concrete, {
				["n"] = "LaneCap",
				["s"] = false,
				["q"] = false
			})
		end
		for v270 = v254 + 3, v255, 6 do
			v_u_14(v_u_75, Vector3.new(0.3, 3.4, 0.3), CFrame.new(p_u_66.X + v253, p_u_66.Y + 4.8, p_u_66.Z + v270), v_u_4.steelDark, v_u_3.Metal, {
				["n"] = "RailPost"
			})
		end
		local v271 = v_u_14
		local v272 = Vector3.new(v256, 0.25, 0.25)
		local v273 = (v254 + v255) / 2
		v271(v_u_75, v272, CFrame.new(p_u_66.X + v253, p_u_66.Y + 6.4, p_u_66.Z + v273), v_u_4.steel, v_u_3.Metal, {
			["shape"] = nil,
			["r"] = nil,
			["n"] = "Rail",
			["s"] = false,
			["shape"] = Enum.PartType.Cylinder,
			["r"] = CFrame.Angles(0, 1.5707963267948966, 0)
		})
		local v274 = -v_u_72.Z + 1.4
		local v275 = v_u_14
		local v276 = (v252.x0 + v252.x1) / 2
		v275(v_u_75, Vector3.new(11.6, 8.5, 2.2), CFrame.new(p_u_66.X + v276, p_u_66.Y + 4.25, p_u_66.Z + v274), Color3.fromHex("4A3F33"), v_u_3.Ground, {
			["c"] = true,
			["n"] = "Berm"
		})
		local v277 = Random.new(99)
		for v278 = 0, 3 do
			local v279 = v_u_14
			local v280 = (v252.x0 + v252.x1) / 2 + ({
				-4.9,
				-3.3,
				3.3,
				4.9
			})[v278 + 1]
			local v281 = v274 + 1.6
			local v282 = CFrame.new(p_u_66.X + v280, p_u_66.Y + 3.1, p_u_66.Z + v281)
			local v283 = CFrame.Angles
			local v284 = -10 + v277:NextNumber(-3, 3)
			v279(v_u_75, Vector3.new(2.2, 6.2, 0.7), v282 * v283(math.rad(v284), v277:NextNumber(-0.1, 0.1), 0), v_u_4.mattress:Lerp(v_u_4.khaki, v277:NextNumber(0, 0.5)), v_u_3.Fabric, {
				["n"] = "Mattress"
			})
		end
		for v285 = 0, 7 do
			local v286 = v252.x0 + 1.2 + v285 % 4 * 2.6 + (v285 >= 4 and 1.3 or 0)
			local v287 = v285 >= 4 and 1.25 or 0.42
			local v288 = v_u_14
			local v289 = v274 + 3.2
			v288(v_u_75, Vector3.new(2.4, 0.85, 1.25), CFrame.new(p_u_66.X + v286, p_u_66.Y + v287, p_u_66.Z + v289) * CFrame.Angles(0, v277:NextNumber(-0.1, 0.1), 0), v_u_4.khaki:Lerp(v_u_4.olive, v277:NextNumber(0, 0.6)), v_u_3.Fabric, {
				["n"] = "Sandbag"
			})
		end
		for v290 = 0, 5 do
			local v291 = -40 + v290 * 16
			local v292 = math.rad(v291)
			local v293 = 18 + math.sin(v292) * 5
			local v294 = -20 + math.cos(v292) * 5
			local v295 = Vector3.new(v293, 0, v294)
			for v296 = 0, 1 do
				local v297 = v_u_14
				local v298 = v295.X
				local v299 = 0.42 + v296 * 0.84
				local v300 = v295.Z
				v297(v_u_75, Vector3.new(2.4, 0.85, 1.25), CFrame.new(p_u_66.X + v298, p_u_66.Y + v299, p_u_66.Z + v300) * CFrame.Angles(0, v292 + 1.5707963267948966 + v296 * 0.2, 0), v_u_4.khaki:Lerp(v_u_4.olive, (v290 + v296) % 3 / 3), v_u_3.Fabric, {
					["n"] = "Sandbag"
				})
			end
		end
		local v301 = CFrame.new(p_u_66) * p67.cot
		v_u_14(v_u_75, Vector3.new(7, 0.3, 2.8), v301 * CFrame.new(0, 1.6, 0), v_u_4.olive, v_u_3.Fabric, {
			["n"] = "Cot",
			["c"] = true
		})
		for _, v302 in { -1, 1 } do
			local v303 = v301 * CFrame.new(v302 * 3.2, 0.75, 0)
			local v304 = CFrame.Angles
			local v305 = 12 * v302
			local v306 = v303 * v304(0, 0, (math.rad(v305)))
			local v307 = v_u_4.steelDark
			local v308 = v_u_3.Metal
			local v309 = Instance.new("Part")
			v309.Name = "Part"
			v309.Anchored = true
			v309.Size = Vector3.new(0.2, 1.5, 2.8)
			v309.CFrame = v306 * CFrame.identity
			v309.Color = v307
			v309.Material = v308
			v309.TopSurface = Enum.SurfaceType.Smooth
			v309.BottomSurface = Enum.SurfaceType.Smooth
			v309.CanCollide = false
			v309.CanQuery = true
			v309.CanTouch = false
			v309.CastShadow = true
			v309.Parent = v_u_75
		end
		local v310 = v301 * CFrame.new(0.6, 1.9, 0)
		local v311 = Color3.fromHex("5B4A3A")
		local v312 = v_u_3.Fabric
		local v313 = {
			["n"] = "SleepingBag"
		}
		local v314 = Instance.new("Part")
		if v313 and v313.shape then
			v314.Shape = v313.shape
		end
		v314.Name = v313 and (v313.n or "Part") or "Part"
		v314.Anchored = true
		v314.Size = Vector3.new(5.2, 0.35, 2.4)
		v314.CFrame = v310 * (v313 and v313.r or CFrame.identity)
		v314.Color = v311
		v314.Material = v312
		v314.TopSurface = Enum.SurfaceType.Smooth
		v314.BottomSurface = Enum.SurfaceType.Smooth
		local v315
		if v313 == nil then
			v315 = false
		else
			v315 = v313.c == true
		end
		v314.CanCollide = v315
		v314.CanQuery = (not v313 or v313.q == nil) and true or v313.q
		v314.CanTouch = false
		v314.CastShadow = (not v313 or v313.s == nil) and true or v313.s
		if v313 and v313.t then
			v314.Transparency = v313.t
		end
		if v313 and v313.refl then
			v314.Reflectance = v313.refl
		end
		v314.Parent = v_u_75
		local v316 = v301 * CFrame.new(-2.6, 1.95, 0)
		local v317 = Color3.fromHex("8A8578")
		local v318 = v_u_3.Fabric
		local v319 = {
			["n"] = "Pillow"
		}
		local v320 = Instance.new("Part")
		if v319 and v319.shape then
			v320.Shape = v319.shape
		end
		v320.Name = v319 and (v319.n or "Part") or "Part"
		v320.Anchored = true
		v320.Size = Vector3.new(1.6, 0.5, 1.9)
		v320.CFrame = v316 * (v319 and v319.r or CFrame.identity)
		v320.Color = v317
		v320.Material = v318
		v320.TopSurface = Enum.SurfaceType.Smooth
		v320.BottomSurface = Enum.SurfaceType.Smooth
		local v321
		if v319 == nil then
			v321 = false
		else
			v321 = v319.c == true
		end
		v320.CanCollide = v321
		v320.CanQuery = (not v319 or v319.q == nil) and true or v319.q
		v320.CanTouch = false
		v320.CastShadow = (not v319 or v319.s == nil) and true or v319.s
		if v319 and v319.t then
			v320.Transparency = v319.t
		end
		if v319 and v319.refl then
			v320.Reflectance = v319.refl
		end
		v320.Parent = v_u_75
		local v322 = v301 * CFrame.new(-0.4, 0.8, -2.8)
		local v323 = v_u_4.olive
		local v324 = v_u_3.Metal
		local v325 = {
			["n"] = "Footlocker",
			["c"] = true
		}
		local v326 = Instance.new("Part")
		if v325 and v325.shape then
			v326.Shape = v325.shape
		end
		v326.Name = v325 and (v325.n or "Part") or "Part"
		v326.Anchored = true
		v326.Size = Vector3.new(3, 1.6, 1.8)
		v326.CFrame = v322 * (v325 and v325.r or CFrame.identity)
		v326.Color = v323
		v326.Material = v324
		v326.TopSurface = Enum.SurfaceType.Smooth
		v326.BottomSurface = Enum.SurfaceType.Smooth
		local v327
		if v325 == nil then
			v327 = false
		else
			v327 = v325.c == true
		end
		v326.CanCollide = v327
		v326.CanQuery = (not v325 or v325.q == nil) and true or v325.q
		v326.CanTouch = false
		v326.CastShadow = (not v325 or v325.s == nil) and true or v325.s
		if v325 and v325.t then
			v326.Transparency = v325.t
		end
		if v325 and v325.refl then
			v326.Reflectance = v325.refl
		end
		v326.Parent = v_u_75
		local v328 = v301 * CFrame.new(-1.8, 2.05, -2.8)
		local v329 = Color3.fromHex("D8CFA8")
		local v330 = v_u_3.Plastic
		local v331 = {
			["n"] = "Lantern"
		}
		local v332 = Instance.new("Part")
		if v331 and v331.shape then
			v332.Shape = v331.shape
		end
		v332.Name = v331 and (v331.n or "Part") or "Part"
		v332.Anchored = true
		v332.Size = Vector3.new(0.6, 0.9, 0.6)
		v332.CFrame = v328 * (v331 and v331.r or CFrame.identity)
		v332.Color = v329
		v332.Material = v330
		v332.TopSurface = Enum.SurfaceType.Smooth
		v332.BottomSurface = Enum.SurfaceType.Smooth
		local v333
		if v331 == nil then
			v333 = false
		else
			v333 = v331.c == true
		end
		v332.CanCollide = v333
		v332.CanQuery = (not v331 or v331.q == nil) and true or v331.q
		v332.CanTouch = false
		local v334
		if v331 and v331.s ~= nil then
			v334 = v331.s
		else
			v334 = false
		end
		v332.CastShadow = v334
		if v331 and v331.t then
			v332.Transparency = v331.t
		end
		if v331 and v331.refl then
			v332.Reflectance = v331.refl
		end
		v332.Parent = v_u_75
		local v335 = Random.new(7)
		for v336, v337 in {
			Vector3.new(30, 0, 26),
			Vector3.new(32.6, 0, 25.4),
			Vector3.new(31.2, 0, 23),
			Vector3.new(27.4, 0, 27.2)
		} do
			local v338
			if v336 % 2 == 0 then
				v338 = v_u_4.barrel
			else
				v338 = v_u_4.barrelRust
			end
			local v339 = v337.X
			local v340 = v337.Z
			local v341 = CFrame.new(p_u_66.X + v339, p_u_66.Y + 1.9, p_u_66.Z + v340) * CFrame.Angles(0, v335:NextNumber(0, 6), 1.5707963267948966)
			local v342 = v_u_3.CorrodedMetal
			local v343 = {
				["shape"] = nil,
				["n"] = "Barrel",
				["c"] = true,
				["shape"] = Enum.PartType.Cylinder
			}
			local v344 = Instance.new("Part")
			if v343 and v343.shape then
				v344.Shape = v343.shape
			end
			v344.Name = v343 and (v343.n or "Part") or "Part"
			v344.Anchored = true
			v344.Size = Vector3.new(3.8, 2.6, 2.6)
			v344.CFrame = v341 * (v343 and v343.r or CFrame.identity)
			v344.Color = v338
			v344.Material = v342
			v344.TopSurface = Enum.SurfaceType.Smooth
			v344.BottomSurface = Enum.SurfaceType.Smooth
			local v345
			if v343 == nil then
				v345 = false
			else
				v345 = v343.c == true
			end
			v344.CanCollide = v345
			v344.CanQuery = (not v343 or v343.q == nil) and true or v343.q
			v344.CanTouch = false
			v344.CastShadow = (not v343 or v343.s == nil) and true or v343.s
			if v343 and v343.t then
				v344.Transparency = v343.t
			end
			if v343 and v343.refl then
				v344.Reflectance = v343.refl
			end
			v344.Parent = v_u_75
		end
		local v346 = CFrame.new(p_u_66.X + 22, p_u_66.Y + 1.7, p_u_66.Z + 27.2)
		local v347 = Color3.fromHex("3F4A3A")
		local v348 = v_u_3.Fabric
		local v349 = {
			["n"] = "TarpPile",
			["c"] = true
		}
		local v350 = Instance.new("Part")
		if v349 and v349.shape then
			v350.Shape = v349.shape
		end
		v350.Name = v349 and (v349.n or "Part") or "Part"
		v350.Anchored = true
		v350.Size = Vector3.new(6, 3.4, 4.5)
		v350.CFrame = v346 * (v349 and v349.r or CFrame.identity)
		v350.Color = v347
		v350.Material = v348
		v350.TopSurface = Enum.SurfaceType.Smooth
		v350.BottomSurface = Enum.SurfaceType.Smooth
		local v351
		if v349 == nil then
			v351 = false
		else
			v351 = v349.c == true
		end
		v350.CanCollide = v351
		v350.CanQuery = (not v349 or v349.q == nil) and true or v349.q
		v350.CanTouch = false
		v350.CastShadow = (not v349 or v349.s == nil) and true or v349.s
		if v349 and v349.t then
			v350.Transparency = v349.t
		end
		if v349 and v349.refl then
			v350.Reflectance = v349.refl
		end
		v350.Parent = v_u_75
		local v352 = CFrame.new(p_u_66.X + 16.6, p_u_66.Y + 1.1, p_u_66.Z + 27.8) * CFrame.Angles(0, 0.2, 0)
		local v353 = Color3.fromHex("5A4330")
		local v354 = v_u_3.WoodPlanks
		local v355 = {
			["n"] = "Crate",
			["c"] = true
		}
		local v356 = Instance.new("Part")
		if v355 and v355.shape then
			v356.Shape = v355.shape
		end
		v356.Name = v355 and (v355.n or "Part") or "Part"
		v356.Anchored = true
		v356.Size = Vector3.new(3, 2.2, 3)
		v356.CFrame = v352 * (v355 and v355.r or CFrame.identity)
		v356.Color = v353
		v356.Material = v354
		v356.TopSurface = Enum.SurfaceType.Smooth
		v356.BottomSurface = Enum.SurfaceType.Smooth
		local v357
		if v355 == nil then
			v357 = false
		else
			v357 = v355.c == true
		end
		v356.CanCollide = v357
		v356.CanQuery = (not v355 or v355.q == nil) and true or v355.q
		v356.CanTouch = false
		v356.CastShadow = (not v355 or v355.s == nil) and true or v355.s
		if v355 and v355.t then
			v356.Transparency = v355.t
		end
		if v355 and v355.refl then
			v356.Reflectance = v355.refl
		end
		v356.Parent = v_u_75
		local v358 = CFrame.new(p_u_66.X + 16.8, p_u_66.Y + 3.1, p_u_66.Z + 27.6) * CFrame.Angles(0, -0.3, 0)
		local v359 = Color3.fromHex("4B5234")
		local v360 = v_u_3.WoodPlanks
		local v361 = {
			["n"] = "Crate"
		}
		local v362 = Instance.new("Part")
		if v361 and v361.shape then
			v362.Shape = v361.shape
		end
		v362.Name = v361 and (v361.n or "Part") or "Part"
		v362.Anchored = true
		v362.Size = Vector3.new(2.4, 1.8, 2.4)
		v362.CFrame = v358 * (v361 and v361.r or CFrame.identity)
		v362.Color = v359
		v362.Material = v360
		v362.TopSurface = Enum.SurfaceType.Smooth
		v362.BottomSurface = Enum.SurfaceType.Smooth
		local v363
		if v361 == nil then
			v363 = false
		else
			v363 = v361.c == true
		end
		v362.CanCollide = v363
		v362.CanQuery = (not v361 or v361.q == nil) and true or v361.q
		v362.CanTouch = false
		v362.CastShadow = (not v361 or v361.s == nil) and true or v361.s
		if v361 and v361.t then
			v362.Transparency = v361.t
		end
		if v361 and v361.refl then
			v362.Reflectance = v361.refl
		end
		v362.Parent = v_u_75
		local v364 = (Vector3.new(0, 0, 18)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v364), CFrame.lookAt(p_u_66 + Vector3.new(30, 0.1, 1), p_u_66 + Vector3.new(30, 0.1, 10)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v365 = (Vector3.new(0, 0, -17)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v365), CFrame.lookAt(p_u_66 + Vector3.new(30, 0.1, -16.5), p_u_66 + Vector3.new(30, 0.1, -25)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v366 = (Vector3.new(-49.4, 0, -0.39999962)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v366), CFrame.lookAt(p_u_66 + Vector3.new(5.3, 0.1, -25.2), p_u_66 + Vector3.new(-19.4, 0.1, -25.4)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v367 = (Vector3.new(-0.20000076, 0, 17.9)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v367), CFrame.lookAt(p_u_66 + Vector3.new(-19.5, 0.1, -16.45), p_u_66 + Vector3.new(-19.6, 0.1, -7.5)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v368 = (Vector3.new(-13.1, 0, 0)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v368), CFrame.lookAt(p_u_66 + Vector3.new(23.05, 0.12, -6.5), p_u_66 + Vector3.new(16.5, 0.12, -6.5)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v369 = (Vector3.new(-9.5, 0, 1.9000001)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v369), CFrame.lookAt(p_u_66 + Vector3.new(11.75, 0.12, -5.55), p_u_66 + Vector3.new(7, 0.12, -4.6)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v370 = (Vector3.new(0, 0, 11)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v370), CFrame.lookAt(p_u_66 + Vector3.new(30.2, 0.12, 15.5), p_u_66 + Vector3.new(30.2, 0.12, 21)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v371 = (Vector3.new(-19.7, 0, 3.5)).Magnitude
		v_u_14(v_u_75, Vector3.new(0.18, 0.18, v371), CFrame.lookAt(p_u_66 + Vector3.new(20.35, 0.12, 22.75), p_u_66 + Vector3.new(10.5, 0.12, 24.5)), v_u_4.cable, v_u_3.Rubber, {
			["n"] = "Cable",
			["s"] = false,
			["q"] = false
		})
		local v372 = Random.new(1309)
		local v373 = CFrame.new(p_u_66.X + 2, p_u_66.Y + 0, p_u_66.Z + -4) * CFrame.Angles(0, 0.13962634015954636, 0)
		local v374 = v373 * CFrame.new(0, 0.03, 0.4)
		local v375 = Color3.fromHex("4A3530")
		local v376 = v_u_3.Fabric
		local v377 = {
			["n"] = "Rug",
			["s"] = false,
			["q"] = false
		}
		local v378 = Instance.new("Part")
		if v377 and v377.shape then
			v378.Shape = v377.shape
		end
		v378.Name = v377 and (v377.n or "Part") or "Part"
		v378.Anchored = true
		v378.Size = Vector3.new(12, 0.05, 9)
		v378.CFrame = v374 * (v377 and v377.r or CFrame.identity)
		v378.Color = v375
		v378.Material = v376
		v378.TopSurface = Enum.SurfaceType.Smooth
		v378.BottomSurface = Enum.SurfaceType.Smooth
		local v379
		if v377 == nil then
			v379 = false
		else
			v379 = v377.c == true
		end
		v378.CanCollide = v379
		v378.CanQuery = (not v377 or v377.q == nil) and true or v377.q
		v378.CanTouch = false
		v378.CastShadow = (not v377 or v377.s == nil) and true or v377.s
		if v377 and v377.t then
			v378.Transparency = v377.t
		end
		if v377 and v377.refl then
			v378.Reflectance = v377.refl
		end
		v378.Parent = v_u_75
		local v380 = v373 * CFrame.new(0, 0.05, 0.4)
		local v381 = Color3.fromHex("5A4038")
		local v382 = v_u_3.Fabric
		local v383 = {
			["n"] = "RugField",
			["s"] = false,
			["q"] = false
		}
		local v384 = Instance.new("Part")
		if v383 and v383.shape then
			v384.Shape = v383.shape
		end
		v384.Name = v383 and (v383.n or "Part") or "Part"
		v384.Anchored = true
		v384.Size = Vector3.new(11, 0.04, 8)
		v384.CFrame = v380 * (v383 and v383.r or CFrame.identity)
		v384.Color = v381
		v384.Material = v382
		v384.TopSurface = Enum.SurfaceType.Smooth
		v384.BottomSurface = Enum.SurfaceType.Smooth
		local v385
		if v383 == nil then
			v385 = false
		else
			v385 = v383.c == true
		end
		v384.CanCollide = v385
		v384.CanQuery = (not v383 or v383.q == nil) and true or v383.q
		v384.CanTouch = false
		v384.CastShadow = (not v383 or v383.s == nil) and true or v383.s
		if v383 and v383.t then
			v384.Transparency = v383.t
		end
		if v383 and v383.refl then
			v384.Reflectance = v383.refl
		end
		v384.Parent = v_u_75
		local v386 = v373 * CFrame.new(0, 3, 0)
		local v387 = v_u_4.wood
		local v388 = v_u_3.WoodPlanks
		local v389 = {
			["n"] = "MapTable",
			["c"] = true
		}
		local v390 = Instance.new("Part")
		if v389 and v389.shape then
			v390.Shape = v389.shape
		end
		v390.Name = v389 and (v389.n or "Part") or "Part"
		v390.Anchored = true
		v390.Size = Vector3.new(8, 0.3, 4.4)
		v390.CFrame = v386 * (v389 and v389.r or CFrame.identity)
		v390.Color = v387
		v390.Material = v388
		v390.TopSurface = Enum.SurfaceType.Smooth
		v390.BottomSurface = Enum.SurfaceType.Smooth
		local v391
		if v389 == nil then
			v391 = false
		else
			v391 = v389.c == true
		end
		v390.CanCollide = v391
		v390.CanQuery = (not v389 or v389.q == nil) and true or v389.q
		v390.CanTouch = false
		v390.CastShadow = (not v389 or v389.s == nil) and true or v389.s
		if v389 and v389.t then
			v390.Transparency = v389.t
		end
		if v389 and v389.refl then
			v390.Reflectance = v389.refl
		end
		v390.Parent = v_u_75
		for _, v392 in { -3.6, 3.6 } do
			for _, v393 in { -1.8, 1.8 } do
				local v394 = v373 * CFrame.new(v392, 1.43, v393)
				local v395 = v_u_4.steelDark
				local v396 = v_u_3.Metal
				local v397 = {
					["n"] = "Leg"
				}
				local v398 = Instance.new("Part")
				if v397 and v397.shape then
					v398.Shape = v397.shape
				end
				v398.Name = v397 and (v397.n or "Part") or "Part"
				v398.Anchored = true
				v398.Size = Vector3.new(0.35, 2.85, 0.35)
				v398.CFrame = v394 * (v397 and v397.r or CFrame.identity)
				v398.Color = v395
				v398.Material = v396
				v398.TopSurface = Enum.SurfaceType.Smooth
				v398.BottomSurface = Enum.SurfaceType.Smooth
				local v399
				if v397 == nil then
					v399 = false
				else
					v399 = v397.c == true
				end
				v398.CanCollide = v399
				v398.CanQuery = (not v397 or v397.q == nil) and true or v397.q
				v398.CanTouch = false
				local v400
				if v397 and v397.s ~= nil then
					v400 = v397.s
				else
					v400 = false
				end
				v398.CastShadow = v400
				if v397 and v397.t then
					v398.Transparency = v397.t
				end
				if v397 and v397.refl then
					v398.Reflectance = v397.refl
				end
				v398.Parent = v_u_75
			end
		end
		local v401 = v373 * CFrame.new(-0.6, 3.17, 0.1) * CFrame.Angles(0, 0.04, 0)
		local v402 = Color3.fromHex("CFC6AE")
		local v403 = v_u_3.Fabric
		local v404 = {
			["n"] = "TownMap",
			["s"] = false,
			["q"] = false
		}
		local v405 = Instance.new("Part")
		if v404 and v404.shape then
			v405.Shape = v404.shape
		end
		v405.Name = v404 and (v404.n or "Part") or "Part"
		v405.Anchored = true
		v405.Size = Vector3.new(5.4, 0.04, 3.4)
		v405.CFrame = v401 * (v404 and v404.r or CFrame.identity)
		v405.Color = v402
		v405.Material = v403
		v405.TopSurface = Enum.SurfaceType.Smooth
		v405.BottomSurface = Enum.SurfaceType.Smooth
		local v406
		if v404 == nil then
			v406 = false
		else
			v406 = v404.c == true
		end
		v405.CanCollide = v406
		v405.CanQuery = (not v404 or v404.q == nil) and true or v404.q
		v405.CanTouch = false
		local v407
		if v404 and v404.s ~= nil then
			v407 = v404.s
		else
			v407 = false
		end
		v405.CastShadow = v407
		if v404 and v404.t then
			v405.Transparency = v404.t
		end
		if v404 and v404.refl then
			v405.Reflectance = v404.refl
		end
		v405.Parent = v_u_75
		for _ = 1, 6 do
			local v408 = v373 * CFrame.new(-0.6 + v372:NextNumber(-2.4, 2.4), 3.24, v372:NextNumber(-1.4, 1.4))
			local v409 = v_u_4.red
			local v410 = v_u_3.Plastic
			local v411 = {
				["n"] = "Pin",
				["s"] = false,
				["q"] = false
			}
			local v412 = Instance.new("Part")
			if v411 and v411.shape then
				v412.Shape = v411.shape
			end
			v412.Name = v411 and (v411.n or "Part") or "Part"
			v412.Anchored = true
			v412.Size = Vector3.new(0.16, 0.12, 0.16)
			v412.CFrame = v408 * (v411 and v411.r or CFrame.identity)
			v412.Color = v409
			v412.Material = v410
			v412.TopSurface = Enum.SurfaceType.Smooth
			v412.BottomSurface = Enum.SurfaceType.Smooth
			local v413
			if v411 == nil then
				v413 = false
			else
				v413 = v411.c == true
			end
			v412.CanCollide = v413
			v412.CanQuery = (not v411 or v411.q == nil) and true or v411.q
			v412.CanTouch = false
			local v414
			if v411 and v411.s ~= nil then
				v414 = v411.s
			else
				v414 = false
			end
			v412.CastShadow = v414
			if v411 and v411.t then
				v412.Transparency = v411.t
			end
			if v411 and v411.refl then
				v412.Reflectance = v411.refl
			end
			v412.Parent = v_u_75
		end
		local v415 = v373 * CFrame.new(3, 3.17, -1.2) * CFrame.Angles(0, 0.5, 0)
		local v416 = Color3.fromHex("D9D4C5")
		local v417 = v_u_3.Fabric
		local v418 = {
			["n"] = "Notes",
			["s"] = false,
			["q"] = false
		}
		local v419 = Instance.new("Part")
		if v418 and v418.shape then
			v419.Shape = v418.shape
		end
		v419.Name = v418 and (v418.n or "Part") or "Part"
		v419.Anchored = true
		v419.Size = Vector3.new(1.1, 0.04, 1.4)
		v419.CFrame = v415 * (v418 and v418.r or CFrame.identity)
		v419.Color = v416
		v419.Material = v417
		v419.TopSurface = Enum.SurfaceType.Smooth
		v419.BottomSurface = Enum.SurfaceType.Smooth
		local v420
		if v418 == nil then
			v420 = false
		else
			v420 = v418.c == true
		end
		v419.CanCollide = v420
		v419.CanQuery = (not v418 or v418.q == nil) and true or v418.q
		v419.CanTouch = false
		local v421
		if v418 and v418.s ~= nil then
			v421 = v418.s
		else
			v421 = false
		end
		v419.CastShadow = v421
		if v418 and v418.t then
			v419.Transparency = v418.t
		end
		if v418 and v418.refl then
			v419.Reflectance = v418.refl
		end
		v419.Parent = v_u_75
		local v422 = v373 * CFrame.new(2.6, 3.19, -0.7) * CFrame.Angles(0, -0.3, 0)
		local v423 = Color3.fromHex("BFB8A6")
		local v424 = v_u_3.Fabric
		local v425 = {
			["n"] = "Notes",
			["s"] = false,
			["q"] = false
		}
		local v426 = Instance.new("Part")
		if v425 and v425.shape then
			v426.Shape = v425.shape
		end
		v426.Name = v425 and (v425.n or "Part") or "Part"
		v426.Anchored = true
		v426.Size = Vector3.new(0.9, 0.04, 1.2)
		v426.CFrame = v422 * (v425 and v425.r or CFrame.identity)
		v426.Color = v423
		v426.Material = v424
		v426.TopSurface = Enum.SurfaceType.Smooth
		v426.BottomSurface = Enum.SurfaceType.Smooth
		local v427
		if v425 == nil then
			v427 = false
		else
			v427 = v425.c == true
		end
		v426.CanCollide = v427
		v426.CanQuery = (not v425 or v425.q == nil) and true or v425.q
		v426.CanTouch = false
		local v428
		if v425 and v425.s ~= nil then
			v428 = v425.s
		else
			v428 = false
		end
		v426.CastShadow = v428
		if v425 and v425.t then
			v426.Transparency = v425.t
		end
		if v425 and v425.refl then
			v426.Reflectance = v425.refl
		end
		v426.Parent = v_u_75
		local v429 = v373 * CFrame.new(3.2, 3.4, 1.3) * CFrame.Angles(0, 0, 1.5707963267948966)
		local v430 = Color3.fromHex("3E5F6B")
		local v431 = v_u_3.Metal
		local v432 = {
			["shape"] = nil,
			["n"] = "Mug",
			["s"] = false,
			["q"] = false,
			["shape"] = Enum.PartType.Cylinder
		}
		local v433 = Instance.new("Part")
		if v432 and v432.shape then
			v433.Shape = v432.shape
		end
		v433.Name = v432 and (v432.n or "Part") or "Part"
		v433.Anchored = true
		v433.Size = Vector3.new(0.5, 0.4, 0.4)
		v433.CFrame = v429 * (v432 and v432.r or CFrame.identity)
		v433.Color = v430
		v433.Material = v431
		v433.TopSurface = Enum.SurfaceType.Smooth
		v433.BottomSurface = Enum.SurfaceType.Smooth
		local v434
		if v432 == nil then
			v434 = false
		else
			v434 = v432.c == true
		end
		v433.CanCollide = v434
		v433.CanQuery = (not v432 or v432.q == nil) and true or v432.q
		v433.CanTouch = false
		local v435
		if v432 and v432.s ~= nil then
			v435 = v432.s
		else
			v435 = false
		end
		v433.CastShadow = v435
		if v432 and v432.t then
			v433.Transparency = v432.t
		end
		if v432 and v432.refl then
			v433.Reflectance = v432.refl
		end
		v433.Parent = v_u_75
		local v436 = v373 * CFrame.new(-3.3, 3.2, -1.4)
		local v437 = v_u_4.steelDark
		local v438 = v_u_3.Metal
		local v439 = {
			["n"] = "LampBase",
			["s"] = false,
			["q"] = false
		}
		local v440 = Instance.new("Part")
		if v439 and v439.shape then
			v440.Shape = v439.shape
		end
		v440.Name = v439 and (v439.n or "Part") or "Part"
		v440.Anchored = true
		v440.Size = Vector3.new(0.8, 0.12, 0.8)
		v440.CFrame = v436 * (v439 and v439.r or CFrame.identity)
		v440.Color = v437
		v440.Material = v438
		v440.TopSurface = Enum.SurfaceType.Smooth
		v440.BottomSurface = Enum.SurfaceType.Smooth
		local v441
		if v439 == nil then
			v441 = false
		else
			v441 = v439.c == true
		end
		v440.CanCollide = v441
		v440.CanQuery = (not v439 or v439.q == nil) and true or v439.q
		v440.CanTouch = false
		local v442
		if v439 and v439.s ~= nil then
			v442 = v439.s
		else
			v442 = false
		end
		v440.CastShadow = v442
		if v439 and v439.t then
			v440.Transparency = v439.t
		end
		if v439 and v439.refl then
			v440.Reflectance = v439.refl
		end
		v440.Parent = v_u_75
		local v443 = v373 * CFrame.new(-3.3, 3.9, -1.4)
		local v444 = v_u_4.steelDark
		local v445 = v_u_3.Metal
		local v446 = {
			["n"] = "LampArm",
			["s"] = false,
			["q"] = false
		}
		local v447 = Instance.new("Part")
		if v446 and v446.shape then
			v447.Shape = v446.shape
		end
		v447.Name = v446 and (v446.n or "Part") or "Part"
		v447.Anchored = true
		v447.Size = Vector3.new(0.12, 1.4, 0.12)
		v447.CFrame = v443 * (v446 and v446.r or CFrame.identity)
		v447.Color = v444
		v447.Material = v445
		v447.TopSurface = Enum.SurfaceType.Smooth
		v447.BottomSurface = Enum.SurfaceType.Smooth
		local v448
		if v446 == nil then
			v448 = false
		else
			v448 = v446.c == true
		end
		v447.CanCollide = v448
		v447.CanQuery = (not v446 or v446.q == nil) and true or v446.q
		v447.CanTouch = false
		local v449
		if v446 and v446.s ~= nil then
			v449 = v446.s
		else
			v449 = false
		end
		v447.CastShadow = v449
		if v446 and v446.t then
			v447.Transparency = v446.t
		end
		if v446 and v446.refl then
			v447.Reflectance = v446.refl
		end
		v447.Parent = v_u_75
		local v450 = v373 * CFrame.new(-3.1, 4.6, -1.1)
		local v451 = Color3.fromHex("2F3A33")
		local v452 = v_u_3.Metal
		local v453 = {
			["n"] = "LampShade",
			["s"] = false,
			["q"] = false
		}
		local v454 = Instance.new("Part")
		if v453 and v453.shape then
			v454.Shape = v453.shape
		end
		v454.Name = v453 and (v453.n or "Part") or "Part"
		v454.Anchored = true
		v454.Size = Vector3.new(0.9, 0.5, 0.9)
		v454.CFrame = v450 * (v453 and v453.r or CFrame.identity)
		v454.Color = v451
		v454.Material = v452
		v454.TopSurface = Enum.SurfaceType.Smooth
		v454.BottomSurface = Enum.SurfaceType.Smooth
		local v455
		if v453 == nil then
			v455 = false
		else
			v455 = v453.c == true
		end
		v454.CanCollide = v455
		v454.CanQuery = (not v453 or v453.q == nil) and true or v453.q
		v454.CanTouch = false
		local v456
		if v453 and v453.s ~= nil then
			v456 = v453.s
		else
			v456 = false
		end
		v454.CastShadow = v456
		if v453 and v453.t then
			v454.Transparency = v453.t
		end
		if v453 and v453.refl then
			v454.Reflectance = v453.refl
		end
		v454.Parent = v_u_75
		local function v459(p457) -- name: chair
			-- upvalues: (ref) v_u_14, (copy) v_u_75, (ref) v_u_4, (ref) v_u_3
			v_u_14(v_u_75, Vector3.new(1.6, 0.2, 1.6), p457 * CFrame.new(0, 1.9, 0), v_u_4.steel, v_u_3.Metal, {
				["n"] = "ChairSeat",
				["c"] = true
			})
			v_u_14(v_u_75, Vector3.new(1.6, 1.7, 0.18), p457 * CFrame.new(0, 2.9, 0.75), v_u_4.steel, v_u_3.Metal, {
				["n"] = "ChairBack"
			})
			for _, v458 in { -0.7, 0.7 } do
				v_u_14(v_u_75, Vector3.new(0.12, 1.9, 0.12), p457 * CFrame.new(v458, 0.95, -0.6), v_u_4.steelDark, v_u_3.Metal, {
					["s"] = false
				})
				v_u_14(v_u_75, Vector3.new(0.12, 3.6, 0.12), p457 * CFrame.new(v458, 1.8, 0.7), v_u_4.steelDark, v_u_3.Metal, {
					["s"] = false
				})
			end
		end
		v459(v373 * CFrame.new(-1.6, 0, 3.4) * CFrame.Angles(0, 0.17453292519943295, 0))
		v459(v373 * CFrame.new(5.4, 0, 0.4) * CFrame.Angles(0, 1.3089969389957472, 0))
		v459(v373 * CFrame.new(-1.5, 0, -4.8) * CFrame.Angles(0, -0.3490658503988659, 0) * CFrame.new(0, 0.8, 0) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.new(0, -0.8, 0))
		local v460 = v_u_72.Z - 1.2
		local v461 = CFrame.new(p_u_66.X + -20, p_u_66.Y + 0, p_u_66.Z + v460)
		for _, v462 in { -2.9, 2.9 } do
			for _, v463 in { -0.95, 0.95 } do
				local v464 = v461 * CFrame.new(v462, 3.6, v463)
				local v465 = v_u_4.steelDark
				local v466 = v_u_3.Metal
				local v467 = {
					["n"] = "Post"
				}
				local v468 = Instance.new("Part")
				if v467 and v467.shape then
					v468.Shape = v467.shape
				end
				v468.Name = v467 and (v467.n or "Part") or "Part"
				v468.Anchored = true
				v468.Size = Vector3.new(0.22, 7.2, 0.22)
				v468.CFrame = v464 * (v467 and v467.r or CFrame.identity)
				v468.Color = v465
				v468.Material = v466
				v468.TopSurface = Enum.SurfaceType.Smooth
				v468.BottomSurface = Enum.SurfaceType.Smooth
				local v469
				if v467 == nil then
					v469 = false
				else
					v469 = v467.c == true
				end
				v468.CanCollide = v469
				v468.CanQuery = (not v467 or v467.q == nil) and true or v467.q
				v468.CanTouch = false
				local v470
				if v467 and v467.s ~= nil then
					v470 = v467.s
				else
					v470 = false
				end
				v468.CastShadow = v470
				if v467 and v467.t then
					v468.Transparency = v467.t
				end
				if v467 and v467.refl then
					v468.Reflectance = v467.refl
				end
				v468.Parent = v_u_75
			end
		end
		local v471 = v461 * CFrame.new(0, 3.5, 0)
		local v472 = v_u_4.steelDark
		local v473 = v_u_3.Metal
		local v474 = {
			["n"] = "PantryCollider",
			["c"] = true,
			["t"] = 1,
			["s"] = false,
			["q"] = false
		}
		local v475 = Instance.new("Part")
		if v474 and v474.shape then
			v475.Shape = v474.shape
		end
		v475.Name = v474 and (v474.n or "Part") or "Part"
		v475.Anchored = true
		v475.Size = Vector3.new(6, 7, 2.1)
		v475.CFrame = v471 * (v474 and v474.r or CFrame.identity)
		v475.Color = v472
		v475.Material = v473
		v475.TopSurface = Enum.SurfaceType.Smooth
		v475.BottomSurface = Enum.SurfaceType.Smooth
		local v476
		if v474 == nil then
			v476 = false
		else
			v476 = v474.c == true
		end
		v475.CanCollide = v476
		v475.CanQuery = (not v474 or v474.q == nil) and true or v474.q
		v475.CanTouch = false
		v475.CastShadow = (not v474 or v474.s == nil) and true or v474.s
		if v474 and v474.t then
			v475.Transparency = v474.t
		end
		if v474 and v474.refl then
			v475.Reflectance = v474.refl
		end
		v475.Parent = v_u_75
		for v477 = 0, 3 do
			local v478 = v477 * 2.1 + 0.5
			local v479 = v461 * CFrame.new(0, v478, 0)
			local v480 = v_u_4.steel
			local v481 = v_u_3.Metal
			local v482 = {
				["n"] = "ShelfBoard"
			}
			local v483 = Instance.new("Part")
			if v482 and v482.shape then
				v483.Shape = v482.shape
			end
			v483.Name = v482 and (v482.n or "Part") or "Part"
			v483.Anchored = true
			v483.Size = Vector3.new(6, 0.12, 2.1)
			v483.CFrame = v479 * (v482 and v482.r or CFrame.identity)
			v483.Color = v480
			v483.Material = v481
			v483.TopSurface = Enum.SurfaceType.Smooth
			v483.BottomSurface = Enum.SurfaceType.Smooth
			local v484
			if v482 == nil then
				v484 = false
			else
				v484 = v482.c == true
			end
			v483.CanCollide = v484
			v483.CanQuery = (not v482 or v482.q == nil) and true or v482.q
			v483.CanTouch = false
			v483.CastShadow = (not v482 or v482.s == nil) and true or v482.s
			if v482 and v482.t then
				v483.Transparency = v482.t
			end
			if v482 and v482.refl then
				v483.Reflectance = v482.refl
			end
			v483.Parent = v_u_75
			local v485 = -2.6
			while v485 < 2.4 do
				local v486 = v372:NextInteger(1, 4)
				if v486 == 1 then
					for v487 = 0, v372:NextInteger(2, 4) do
						local v488 = v461 * CFrame.new(v485 + 0.25 + v487 * 0.48, v478 + 0.36, v372:NextNumber(-0.4, 0.3)) * CFrame.Angles(0, 0, 1.5707963267948966)
						local v489
						if v372:NextNumber() < 0.5 then
							v489 = v_u_4.olive
						else
							v489 = Color3.fromHex("9C7A3C")
						end
						local v490 = v_u_3.Metal
						local v491 = {
							["shape"] = nil,
							["n"] = "Can",
							["s"] = false,
							["q"] = false,
							["shape"] = Enum.PartType.Cylinder
						}
						local v492 = Instance.new("Part")
						if v491 and v491.shape then
							v492.Shape = v491.shape
						end
						v492.Name = v491 and (v491.n or "Part") or "Part"
						v492.Anchored = true
						v492.Size = Vector3.new(0.6, 0.42, 0.42)
						v492.CFrame = v488 * (v491 and v491.r or CFrame.identity)
						v492.Color = v489
						v492.Material = v490
						v492.TopSurface = Enum.SurfaceType.Smooth
						v492.BottomSurface = Enum.SurfaceType.Smooth
						local v493
						if v491 == nil then
							v493 = false
						else
							v493 = v491.c == true
						end
						v492.CanCollide = v493
						v492.CanQuery = (not v491 or v491.q == nil) and true or v491.q
						v492.CanTouch = false
						local v494
						if v491 and v491.s ~= nil then
							v494 = v491.s
						else
							v494 = false
						end
						v492.CastShadow = v494
						if v491 and v491.t then
							v492.Transparency = v491.t
						end
						if v491 and v491.refl then
							v492.Reflectance = v491.refl
						end
						v492.Parent = v_u_75
					end
					v485 = v485 + 2.2
				elseif v486 == 2 then
					local v495 = v461 * CFrame.new(v485 + 0.6, v478 + 0.71, 0)
					local v496 = Color3.fromHex("5E7F8F")
					local v497 = v_u_3.Glass
					local v498 = {
						["n"] = "WaterJug",
						["t"] = 0.3,
						["s"] = false,
						["q"] = false
					}
					local v499 = Instance.new("Part")
					if v498 and v498.shape then
						v499.Shape = v498.shape
					end
					v499.Name = v498 and (v498.n or "Part") or "Part"
					v499.Anchored = true
					v499.Size = Vector3.new(1.2, 1.3, 1.2)
					v499.CFrame = v495 * (v498 and v498.r or CFrame.identity)
					v499.Color = v496
					v499.Material = v497
					v499.TopSurface = Enum.SurfaceType.Smooth
					v499.BottomSurface = Enum.SurfaceType.Smooth
					local v500
					if v498 == nil then
						v500 = false
					else
						v500 = v498.c == true
					end
					v499.CanCollide = v500
					v499.CanQuery = (not v498 or v498.q == nil) and true or v498.q
					v499.CanTouch = false
					v499.CastShadow = (not v498 or v498.s == nil) and true or v498.s
					if v498 and v498.t then
						v499.Transparency = v498.t
					end
					if v498 and v498.refl then
						v499.Reflectance = v498.refl
					end
					v499.Parent = v_u_75
					v485 = v485 + 1.5
				elseif v486 == 3 then
					local v501 = v461 * CFrame.new(v485 + 0.8, v478 + 0.56, 0) * CFrame.Angles(0, v372:NextNumber(-0.2, 0.2), 0)
					local v502 = v_u_4.khaki
					local v503 = v_u_3.Fabric
					local v504 = {
						["n"] = "Sack",
						["s"] = false,
						["q"] = false
					}
					local v505 = Instance.new("Part")
					if v504 and v504.shape then
						v505.Shape = v504.shape
					end
					v505.Name = v504 and (v504.n or "Part") or "Part"
					v505.Anchored = true
					v505.Size = Vector3.new(1.6, 1, 1.4)
					v505.CFrame = v501 * (v504 and v504.r or CFrame.identity)
					v505.Color = v502
					v505.Material = v503
					v505.TopSurface = Enum.SurfaceType.Smooth
					v505.BottomSurface = Enum.SurfaceType.Smooth
					local v506
					if v504 == nil then
						v506 = false
					else
						v506 = v504.c == true
					end
					v505.CanCollide = v506
					v505.CanQuery = (not v504 or v504.q == nil) and true or v504.q
					v505.CanTouch = false
					v505.CastShadow = (not v504 or v504.s == nil) and true or v504.s
					if v504 and v504.t then
						v505.Transparency = v504.t
					end
					if v504 and v504.refl then
						v505.Reflectance = v504.refl
					end
					v505.Parent = v_u_75
					v485 = v485 + 1.9
				else
					v485 = v485 + v372:NextNumber(0.5, 1.1)
				end
			end
		end
		local v507 = -v_u_72.Z + 2
		local v508 = CFrame.new(p_u_66.X + -21, p_u_66.Y + 3.5, p_u_66.Z + v507) * CFrame.Angles(0, 0, 1.5707963267948966)
		local v509 = Color3.fromHex("8C8F86")
		local v510 = v_u_3.Metal
		local v511 = {
			["shape"] = nil,
			["n"] = "Heater",
			["c"] = true,
			["shape"] = Enum.PartType.Cylinder
		}
		local v512 = Instance.new("Part")
		if v511 and v511.shape then
			v512.Shape = v511.shape
		end
		v512.Name = v511 and (v511.n or "Part") or "Part"
		v512.Anchored = true
		v512.Size = Vector3.new(7, 3.2, 3.2)
		v512.CFrame = v508 * (v511 and v511.r or CFrame.identity)
		v512.Color = v509
		v512.Material = v510
		v512.TopSurface = Enum.SurfaceType.Smooth
		v512.BottomSurface = Enum.SurfaceType.Smooth
		local v513
		if v511 == nil then
			v513 = false
		else
			v513 = v511.c == true
		end
		v512.CanCollide = v513
		v512.CanQuery = (not v511 or v511.q == nil) and true or v511.q
		v512.CanTouch = false
		v512.CastShadow = (not v511 or v511.s == nil) and true or v511.s
		if v511 and v511.t then
			v512.Transparency = v511.t
		end
		if v511 and v511.refl then
			v512.Reflectance = v511.refl
		end
		v512.Parent = v_u_75
		local v514 = CFrame.new(p_u_66.X + -21, p_u_66.Y + 7.1, p_u_66.Z + v507) * CFrame.Angles(0, 0, 1.5707963267948966)
		local v515 = v_u_4.steelDark
		local v516 = v_u_3.Metal
		local v517 = {
			["shape"] = nil,
			["n"] = "HeaterCap",
			["s"] = false,
			["shape"] = Enum.PartType.Cylinder
		}
		local v518 = Instance.new("Part")
		if v517 and v517.shape then
			v518.Shape = v517.shape
		end
		v518.Name = v517 and (v517.n or "Part") or "Part"
		v518.Anchored = true
		v518.Size = Vector3.new(0.4, 3.4, 3.4)
		v518.CFrame = v514 * (v517 and v517.r or CFrame.identity)
		v518.Color = v515
		v518.Material = v516
		v518.TopSurface = Enum.SurfaceType.Smooth
		v518.BottomSurface = Enum.SurfaceType.Smooth
		local v519
		if v517 == nil then
			v519 = false
		else
			v519 = v517.c == true
		end
		v518.CanCollide = v519
		v518.CanQuery = (not v517 or v517.q == nil) and true or v517.q
		v518.CanTouch = false
		v518.CastShadow = (not v517 or v517.s == nil) and true or v517.s
		if v517 and v517.t then
			v518.Transparency = v517.t
		end
		if v517 and v517.refl then
			v518.Reflectance = v517.refl
		end
		v518.Parent = v_u_75
		local v520 = CFrame.new(p_u_66.X + -21, p_u_66.Y + 8.6, p_u_66.Z + v507)
		local v521 = v_u_4.pipeRust
		local v522 = v_u_3.Metal
		local v523 = {
			["n"] = "Flue"
		}
		local v524 = Instance.new("Part")
		if v523 and v523.shape then
			v524.Shape = v523.shape
		end
		v524.Name = v523 and (v523.n or "Part") or "Part"
		v524.Anchored = true
		v524.Size = Vector3.new(0.5, 3, 0.5)
		v524.CFrame = v520 * (v523 and v523.r or CFrame.identity)
		v524.Color = v521
		v524.Material = v522
		v524.TopSurface = Enum.SurfaceType.Smooth
		v524.BottomSurface = Enum.SurfaceType.Smooth
		local v525
		if v523 == nil then
			v525 = false
		else
			v525 = v523.c == true
		end
		v524.CanCollide = v525
		v524.CanQuery = (not v523 or v523.q == nil) and true or v523.q
		v524.CanTouch = false
		local v526
		if v523 and v523.s ~= nil then
			v526 = v523.s
		else
			v526 = false
		end
		v524.CastShadow = v526
		if v523 and v523.t then
			v524.Transparency = v523.t
		end
		if v523 and v523.refl then
			v524.Reflectance = v523.refl
		end
		v524.Parent = v_u_75
		local v527 = v507 + 1.65
		local v528 = CFrame.new(p_u_66.X + -21, p_u_66.Y + 1.6, p_u_66.Z + v527)
		local v529 = v_u_4.hazard
		local v530 = v_u_3.Plastic
		local v531 = {
			["n"] = "Label",
			["s"] = false,
			["q"] = false
		}
		local v532 = Instance.new("Part")
		if v531 and v531.shape then
			v532.Shape = v531.shape
		end
		v532.Name = v531 and (v531.n or "Part") or "Part"
		v532.Anchored = true
		v532.Size = Vector3.new(1, 0.5, 0.2)
		v532.CFrame = v528 * (v531 and v531.r or CFrame.identity)
		v532.Color = v529
		v532.Material = v530
		v532.TopSurface = Enum.SurfaceType.Smooth
		v532.BottomSurface = Enum.SurfaceType.Smooth
		local v533
		if v531 == nil then
			v533 = false
		else
			v533 = v531.c == true
		end
		v532.CanCollide = v533
		v532.CanQuery = (not v531 or v531.q == nil) and true or v531.q
		v532.CanTouch = false
		local v534
		if v531 and v531.s ~= nil then
			v534 = v531.s
		else
			v534 = false
		end
		v532.CastShadow = v534
		if v531 and v531.t then
			v532.Transparency = v531.t
		end
		if v531 and v531.refl then
			v532.Reflectance = v531.refl
		end
		v532.Parent = v_u_75
		local v535 = v507 + 0.6
		local v536 = CFrame.new(p_u_66.X + -18.6, p_u_66.Y + 0.4, p_u_66.Z + v535)
		local v537 = v_u_4.steelDark
		local v538 = v_u_3.Metal
		local v539 = {
			["n"] = "Bucket",
			["s"] = false
		}
		local v540 = Instance.new("Part")
		if v539 and v539.shape then
			v540.Shape = v539.shape
		end
		v540.Name = v539 and (v539.n or "Part") or "Part"
		v540.Anchored = true
		v540.Size = Vector3.new(1.4, 0.8, 1.4)
		v540.CFrame = v536 * (v539 and v539.r or CFrame.identity)
		v540.Color = v537
		v540.Material = v538
		v540.TopSurface = Enum.SurfaceType.Smooth
		v540.BottomSurface = Enum.SurfaceType.Smooth
		local v541
		if v539 == nil then
			v541 = false
		else
			v541 = v539.c == true
		end
		v540.CanCollide = v541
		v540.CanQuery = (not v539 or v539.q == nil) and true or v539.q
		v540.CanTouch = false
		v540.CastShadow = (not v539 or v539.s == nil) and true or v539.s
		if v539 and v539.t then
			v540.Transparency = v539.t
		end
		if v539 and v539.refl then
			v540.Reflectance = v539.refl
		end
		v540.Parent = v_u_75
		for v542, v543 in { 17.4, 19.6 } do
			local v544 = v_u_72.X - 0.95
			local v545 = CFrame.new(p_u_66.X + v544, p_u_66.Y + 0, p_u_66.Z + v543) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v546 = v545 * CFrame.new(0, 3.2, 0)
			local v547
			if v542 == 1 then
				v547 = Color3.fromHex("4E5A52")
			else
				v547 = Color3.fromHex("4A4F55")
			end
			local v548 = v_u_3.Metal
			local v549 = {
				["n"] = "Locker",
				["c"] = true
			}
			local v550 = Instance.new("Part")
			if v549 and v549.shape then
				v550.Shape = v549.shape
			end
			v550.Name = v549 and (v549.n or "Part") or "Part"
			v550.Anchored = true
			v550.Size = Vector3.new(2.1, 6.4, 1.8)
			v550.CFrame = v546 * (v549 and v549.r or CFrame.identity)
			v550.Color = v547
			v550.Material = v548
			v550.TopSurface = Enum.SurfaceType.Smooth
			v550.BottomSurface = Enum.SurfaceType.Smooth
			local v551
			if v549 == nil then
				v551 = false
			else
				v551 = v549.c == true
			end
			v550.CanCollide = v551
			v550.CanQuery = (not v549 or v549.q == nil) and true or v549.q
			v550.CanTouch = false
			v550.CastShadow = (not v549 or v549.s == nil) and true or v549.s
			if v549 and v549.t then
				v550.Transparency = v549.t
			end
			if v549 and v549.refl then
				v550.Reflectance = v549.refl
			end
			v550.Parent = v_u_75
			for v552 = 0, 2 do
				local v553 = v545 * CFrame.new(0, v552 * 0.22 + 5.4, -0.92)
				local v554 = v_u_4.steelDark
				local v555 = v_u_3.Metal
				local v556 = {
					["s"] = false,
					["q"] = false
				}
				local v557 = Instance.new("Part")
				if v556 and v556.shape then
					v557.Shape = v556.shape
				end
				v557.Name = v556 and (v556.n or "Part") or "Part"
				v557.Anchored = true
				v557.Size = Vector3.new(1.4, 0.08, 0.04)
				v557.CFrame = v553 * (v556 and v556.r or CFrame.identity)
				v557.Color = v554
				v557.Material = v555
				v557.TopSurface = Enum.SurfaceType.Smooth
				v557.BottomSurface = Enum.SurfaceType.Smooth
				local v558
				if v556 == nil then
					v558 = false
				else
					v558 = v556.c == true
				end
				v557.CanCollide = v558
				v557.CanQuery = (not v556 or v556.q == nil) and true or v556.q
				v557.CanTouch = false
				local v559
				if v556 and v556.s ~= nil then
					v559 = v556.s
				else
					v559 = false
				end
				v557.CastShadow = v559
				if v556 and v556.t then
					v557.Transparency = v556.t
				end
				if v556 and v556.refl then
					v557.Reflectance = v556.refl
				end
				v557.Parent = v_u_75
			end
			local v560 = v545 * CFrame.new(0.75, 3.4, -0.94)
			local v561 = v_u_4.conduit
			local v562 = v_u_3.Metal
			local v563 = {
				["n"] = "Handle",
				["s"] = false,
				["q"] = false
			}
			local v564 = Instance.new("Part")
			if v563 and v563.shape then
				v564.Shape = v563.shape
			end
			v564.Name = v563 and (v563.n or "Part") or "Part"
			v564.Anchored = true
			v564.Size = Vector3.new(0.12, 0.6, 0.08)
			v564.CFrame = v560 * (v563 and v563.r or CFrame.identity)
			v564.Color = v561
			v564.Material = v562
			v564.TopSurface = Enum.SurfaceType.Smooth
			v564.BottomSurface = Enum.SurfaceType.Smooth
			local v565
			if v563 == nil then
				v565 = false
			else
				v565 = v563.c == true
			end
			v564.CanCollide = v565
			v564.CanQuery = (not v563 or v563.q == nil) and true or v563.q
			v564.CanTouch = false
			local v566
			if v563 and v563.s ~= nil then
				v566 = v563.s
			else
				v566 = false
			end
			v564.CastShadow = v566
			if v563 and v563.t then
				v564.Transparency = v563.t
			end
			if v563 and v563.refl then
				v564.Reflectance = v563.refl
			end
			v564.Parent = v_u_75
		end
		local v567 = v_u_72.X - 3.4
		local v568 = CFrame.new(p_u_66.X + v567, p_u_66.Y + 0.04, p_u_66.Z + 18.6) * CFrame.Angles(0, 1.2217304763960306, 0)
		local v569 = Color3.fromHex("8E7454")
		local v570 = v_u_3.Cardboard
		local v571 = {
			["n"] = "Flattened",
			["s"] = false,
			["q"] = false
		}
		local v572 = Instance.new("Part")
		if v571 and v571.shape then
			v572.Shape = v571.shape
		end
		v572.Name = v571 and (v571.n or "Part") or "Part"
		v572.Anchored = true
		v572.Size = Vector3.new(2, 0.06, 2.8)
		v572.CFrame = v568 * (v571 and v571.r or CFrame.identity)
		v572.Color = v569
		v572.Material = v570
		v572.TopSurface = Enum.SurfaceType.Smooth
		v572.BottomSurface = Enum.SurfaceType.Smooth
		local v573
		if v571 == nil then
			v573 = false
		else
			v573 = v571.c == true
		end
		v572.CanCollide = v573
		v572.CanQuery = (not v571 or v571.q == nil) and true or v571.q
		v572.CanTouch = false
		local v574
		if v571 and v571.s ~= nil then
			v574 = v571.s
		else
			v574 = false
		end
		v572.CastShadow = v574
		if v571 and v571.t then
			v572.Transparency = v571.t
		end
		if v571 and v571.refl then
			v572.Reflectance = v571.refl
		end
		v572.Parent = v_u_75
		local v575 = CFrame.new(p_u_66.X + 32.6, p_u_66.Y + 0, p_u_66.Z + -18.4) * CFrame.Angles(0, 0.06981317007977318, 0)
		local v576 = v575 * CFrame.new(0, 0.2, 0)
		local v577 = Color3.fromHex("5A4330")
		local v578 = v_u_3.WoodPlanks
		local v579 = {
			["n"] = "Pallet",
			["c"] = true
		}
		local v580 = Instance.new("Part")
		if v579 and v579.shape then
			v580.Shape = v579.shape
		end
		v580.Name = v579 and (v579.n or "Part") or "Part"
		v580.Anchored = true
		v580.Size = Vector3.new(4.2, 0.4, 3.4)
		v580.CFrame = v576 * (v579 and v579.r or CFrame.identity)
		v580.Color = v577
		v580.Material = v578
		v580.TopSurface = Enum.SurfaceType.Smooth
		v580.BottomSurface = Enum.SurfaceType.Smooth
		local v581
		if v579 == nil then
			v581 = false
		else
			v581 = v579.c == true
		end
		v580.CanCollide = v581
		v580.CanQuery = (not v579 or v579.q == nil) and true or v579.q
		v580.CanTouch = false
		v580.CastShadow = (not v579 or v579.s == nil) and true or v579.s
		if v579 and v579.t then
			v580.Transparency = v579.t
		end
		if v579 and v579.refl then
			v580.Reflectance = v579.refl
		end
		v580.Parent = v_u_75
		for v582 = 0, 3 do
			local v583 = -1.2 + v582 % 2 * 2.4
			local v584 = v582 / 2
			local v585 = -0.8 + math.floor(v584) * 1.5
			local v586 = v575 * CFrame.new(v583, 1.3, v585) * CFrame.Angles(0, v372:NextNumber(-0.15, 0.15), 0)
			local v587
			if v582 == 2 then
				v587 = v_u_4.olive
			else
				v587 = v_u_4.red
			end
			local v588 = v_u_3.Metal
			local v589 = {
				["n"] = "Jerrycan"
			}
			local v590 = Instance.new("Part")
			if v589 and v589.shape then
				v590.Shape = v589.shape
			end
			v590.Name = v589 and (v589.n or "Part") or "Part"
			v590.Anchored = true
			v590.Size = Vector3.new(1.3, 1.8, 0.7)
			v590.CFrame = v586 * (v589 and v589.r or CFrame.identity)
			v590.Color = v587
			v590.Material = v588
			v590.TopSurface = Enum.SurfaceType.Smooth
			v590.BottomSurface = Enum.SurfaceType.Smooth
			local v591
			if v589 == nil then
				v591 = false
			else
				v591 = v589.c == true
			end
			v590.CanCollide = v591
			v590.CanQuery = (not v589 or v589.q == nil) and true or v589.q
			v590.CanTouch = false
			v590.CastShadow = (not v589 or v589.s == nil) and true or v589.s
			if v589 and v589.t then
				v590.Transparency = v589.t
			end
			if v589 and v589.refl then
				v590.Reflectance = v589.refl
			end
			v590.Parent = v_u_75
		end
		local v592 = (p67.pillars or {})[2]
		if v592 then
			local v593 = v592.X + 2.6
			local v594 = v592.Z + 0.6
			local v595 = CFrame.new(p_u_66.X + v593, p_u_66.Y + 1.1, p_u_66.Z + v594) * CFrame.Angles(0, 0.15, 0)
			local v596 = Color3.fromHex("5A4330")
			local v597 = v_u_3.WoodPlanks
			local v598 = {
				["n"] = "Crate",
				["c"] = true
			}
			local v599 = Instance.new("Part")
			if v598 and v598.shape then
				v599.Shape = v598.shape
			end
			v599.Name = v598 and (v598.n or "Part") or "Part"
			v599.Anchored = true
			v599.Size = Vector3.new(2.6, 2.2, 2.6)
			v599.CFrame = v595 * (v598 and v598.r or CFrame.identity)
			v599.Color = v596
			v599.Material = v597
			v599.TopSurface = Enum.SurfaceType.Smooth
			v599.BottomSurface = Enum.SurfaceType.Smooth
			local v600
			if v598 == nil then
				v600 = false
			else
				v600 = v598.c == true
			end
			v599.CanCollide = v600
			v599.CanQuery = (not v598 or v598.q == nil) and true or v598.q
			v599.CanTouch = false
			v599.CastShadow = (not v598 or v598.s == nil) and true or v598.s
			if v598 and v598.t then
				v599.Transparency = v598.t
			end
			if v598 and v598.refl then
				v599.Reflectance = v598.refl
			end
			v599.Parent = v_u_75
			local v601 = v592.X + 2.5
			local v602 = v592.Z + 0.5
			local v603 = CFrame.new(p_u_66.X + v601, p_u_66.Y + 3.05, p_u_66.Z + v602) * CFrame.Angles(0, -0.25, 0)
			local v604 = v_u_4.olive
			local v605 = v_u_3.WoodPlanks
			local v606 = {
				["n"] = "Crate"
			}
			local v607 = Instance.new("Part")
			if v606 and v606.shape then
				v607.Shape = v606.shape
			end
			v607.Name = v606 and (v606.n or "Part") or "Part"
			v607.Anchored = true
			v607.Size = Vector3.new(2.1, 1.7, 2.1)
			v607.CFrame = v603 * (v606 and v606.r or CFrame.identity)
			v607.Color = v604
			v607.Material = v605
			v607.TopSurface = Enum.SurfaceType.Smooth
			v607.BottomSurface = Enum.SurfaceType.Smooth
			local v608
			if v606 == nil then
				v608 = false
			else
				v608 = v606.c == true
			end
			v607.CanCollide = v608
			v607.CanQuery = (not v606 or v606.q == nil) and true or v606.q
			v607.CanTouch = false
			v607.CastShadow = (not v606 or v606.s == nil) and true or v606.s
			if v606 and v606.t then
				v607.Transparency = v606.t
			end
			if v606 and v606.refl then
				v607.Reflectance = v606.refl
			end
			v607.Parent = v_u_75
			local v609 = v592.X
			local v610 = v592.Z + 1.5
			local v611 = CFrame.new(p_u_66.X + v609, p_u_66.Y + 3.2, p_u_66.Z + v610) * CFrame.Angles(0, 0, 1.5707963267948966)
			local v612 = v_u_4.red
			local v613 = v_u_3.Metal
			local v614 = {
				["shape"] = nil,
				["n"] = "Extinguisher",
				["s"] = false,
				["shape"] = Enum.PartType.Cylinder
			}
			local v615 = Instance.new("Part")
			if v614 and v614.shape then
				v615.Shape = v614.shape
			end
			v615.Name = v614 and (v614.n or "Part") or "Part"
			v615.Anchored = true
			v615.Size = Vector3.new(1.4, 0.6, 0.6)
			v615.CFrame = v611 * (v614 and v614.r or CFrame.identity)
			v615.Color = v612
			v615.Material = v613
			v615.TopSurface = Enum.SurfaceType.Smooth
			v615.BottomSurface = Enum.SurfaceType.Smooth
			local v616
			if v614 == nil then
				v616 = false
			else
				v616 = v614.c == true
			end
			v615.CanCollide = v616
			v615.CanQuery = (not v614 or v614.q == nil) and true or v614.q
			v615.CanTouch = false
			local v617
			if v614 and v614.s ~= nil then
				v617 = v614.s
			else
				v617 = false
			end
			v615.CastShadow = v617
			if v614 and v614.t then
				v615.Transparency = v614.t
			end
			if v614 and v614.refl then
				v615.Reflectance = v614.refl
			end
			v615.Parent = v_u_75
			local v618 = v592.X - 0.4
			local v619 = v592.Z + 1.23
			local v620 = CFrame.new(p_u_66.X + v618, p_u_66.Y + 5.6, p_u_66.Z + v619) * CFrame.Angles(0, 0, 0.06)
			local v621 = Color3.fromHex("D9D4C5")
			local v622 = v_u_3.Fabric
			local v623 = {
				["n"] = "Notice",
				["s"] = false,
				["q"] = false
			}
			local v624 = Instance.new("Part")
			if v623 and v623.shape then
				v624.Shape = v623.shape
			end
			v624.Name = v623 and (v623.n or "Part") or "Part"
			v624.Anchored = true
			v624.Size = Vector3.new(1.1, 1.4, 0.05)
			v624.CFrame = v620 * (v623 and v623.r or CFrame.identity)
			v624.Color = v621
			v624.Material = v622
			v624.TopSurface = Enum.SurfaceType.Smooth
			v624.BottomSurface = Enum.SurfaceType.Smooth
			local v625
			if v623 == nil then
				v625 = false
			else
				v625 = v623.c == true
			end
			v624.CanCollide = v625
			v624.CanQuery = (not v623 or v623.q == nil) and true or v623.q
			v624.CanTouch = false
			local v626
			if v623 and v623.s ~= nil then
				v626 = v623.s
			else
				v626 = false
			end
			v624.CastShadow = v626
			if v623 and v623.t then
				v624.Transparency = v623.t
			end
			if v623 and v623.refl then
				v624.Reflectance = v623.refl
			end
			v624.Parent = v_u_75
		end
		local v627 = (p67.pillars or {})[1]
		if v627 then
			local v628 = v627.X - 3.6
			local v629 = v627.Z + 2.2
			local v630 = CFrame.new(p_u_66.X + v628, p_u_66.Y + 0, p_u_66.Z + v629) * CFrame.Angles(0, -0.20943951023931956, 0)
			local v631 = v630 * CFrame.new(0, 0.2, 0)
			local v632 = Color3.fromHex("5A4330")
			local v633 = v_u_3.WoodPlanks
			local v634 = {
				["n"] = "Pallet",
				["c"] = true
			}
			local v635 = Instance.new("Part")
			if v634 and v634.shape then
				v635.Shape = v634.shape
			end
			v635.Name = v634 and (v634.n or "Part") or "Part"
			v635.Anchored = true
			v635.Size = Vector3.new(4, 0.4, 3.6)
			v635.CFrame = v631 * (v634 and v634.r or CFrame.identity)
			v635.Color = v632
			v635.Material = v633
			v635.TopSurface = Enum.SurfaceType.Smooth
			v635.BottomSurface = Enum.SurfaceType.Smooth
			local v636
			if v634 == nil then
				v636 = false
			else
				v636 = v634.c == true
			end
			v635.CanCollide = v636
			v635.CanQuery = (not v634 or v634.q == nil) and true or v634.q
			v635.CanTouch = false
			v635.CastShadow = (not v634 or v634.s == nil) and true or v634.s
			if v634 and v634.t then
				v635.Transparency = v634.t
			end
			if v634 and v634.refl then
				v635.Reflectance = v634.refl
			end
			v635.Parent = v_u_75
			for v637 = 0, 4 do
				local v638 = v637 == 4 and 0 or -0.95 + v637 % 2 * 1.9
				local v639 = v637 / 2
				local v640 = 0.85 + math.floor(v639) * 0.8
				local v641 = v630 * CFrame.new(v638, v640, 0) * CFrame.Angles(0, v372:NextNumber(-0.1, 0.1), 0)
				local v642 = v_u_4.khaki:Lerp(v_u_4.mattress, v372:NextNumber(0, 0.6))
				local v643 = v_u_3.Fabric
				local v644 = {
					["n"] = "Sack"
				}
				local v645 = Instance.new("Part")
				if v644 and v644.shape then
					v645.Shape = v644.shape
				end
				v645.Name = v644 and (v644.n or "Part") or "Part"
				v645.Anchored = true
				v645.Size = Vector3.new(1.8, 0.8, 3)
				v645.CFrame = v641 * (v644 and v644.r or CFrame.identity)
				v645.Color = v642
				v645.Material = v643
				v645.TopSurface = Enum.SurfaceType.Smooth
				v645.BottomSurface = Enum.SurfaceType.Smooth
				local v646
				if v644 == nil then
					v646 = false
				else
					v646 = v644.c == true
				end
				v645.CanCollide = v646
				v645.CanQuery = (not v644 or v644.q == nil) and true or v644.q
				v645.CanTouch = false
				v645.CastShadow = (not v644 or v644.s == nil) and true or v644.s
				if v644 and v644.t then
					v645.Transparency = v644.t
				end
				if v644 and v644.refl then
					v645.Reflectance = v644.refl
				end
				v645.Parent = v_u_75
			end
		end
		local v647 = CFrame.new(p_u_66.X + -4.6, p_u_66.Y + 0, p_u_66.Z + 20.6) * CFrame.Angles(0, -0.3490658503988659, 0)
		local v648 = v647 * CFrame.new(0, 0.8, 0)
		local v649 = Color3.fromHex("5B4A3A")
		local v650 = v_u_3.Fabric
		local v651 = {
			["n"] = "Armchair",
			["c"] = true
		}
		local v652 = Instance.new("Part")
		if v651 and v651.shape then
			v652.Shape = v651.shape
		end
		v652.Name = v651 and (v651.n or "Part") or "Part"
		v652.Anchored = true
		v652.Size = Vector3.new(3.4, 1.6, 3.2)
		v652.CFrame = v648 * (v651 and v651.r or CFrame.identity)
		v652.Color = v649
		v652.Material = v650
		v652.TopSurface = Enum.SurfaceType.Smooth
		v652.BottomSurface = Enum.SurfaceType.Smooth
		local v653
		if v651 == nil then
			v653 = false
		else
			v653 = v651.c == true
		end
		v652.CanCollide = v653
		v652.CanQuery = (not v651 or v651.q == nil) and true or v651.q
		v652.CanTouch = false
		v652.CastShadow = (not v651 or v651.s == nil) and true or v651.s
		if v651 and v651.t then
			v652.Transparency = v651.t
		end
		if v651 and v651.refl then
			v652.Reflectance = v651.refl
		end
		v652.Parent = v_u_75
		local v654 = v647 * CFrame.new(0, 2.6, 1.15) * CFrame.Angles(-0.17453292519943295, 0, 0)
		local v655 = Color3.fromHex("534335")
		local v656 = v_u_3.Fabric
		local v657 = {
			["n"] = "ArmchairBack"
		}
		local v658 = Instance.new("Part")
		if v657 and v657.shape then
			v658.Shape = v657.shape
		end
		v658.Name = v657 and (v657.n or "Part") or "Part"
		v658.Anchored = true
		v658.Size = Vector3.new(3.4, 2.6, 0.9)
		v658.CFrame = v654 * (v657 and v657.r or CFrame.identity)
		v658.Color = v655
		v658.Material = v656
		v658.TopSurface = Enum.SurfaceType.Smooth
		v658.BottomSurface = Enum.SurfaceType.Smooth
		local v659
		if v657 == nil then
			v659 = false
		else
			v659 = v657.c == true
		end
		v658.CanCollide = v659
		v658.CanQuery = (not v657 or v657.q == nil) and true or v657.q
		v658.CanTouch = false
		v658.CastShadow = (not v657 or v657.s == nil) and true or v657.s
		if v657 and v657.t then
			v658.Transparency = v657.t
		end
		if v657 and v657.refl then
			v658.Reflectance = v657.refl
		end
		v658.Parent = v_u_75
		for _, v660 in { -1.45, 1.45 } do
			local v661 = v647 * CFrame.new(v660, 2.1, 0)
			local v662 = Color3.fromHex("4E3F32")
			local v663 = v_u_3.Fabric
			local v664 = {
				["n"] = "Arm"
			}
			local v665 = Instance.new("Part")
			if v664 and v664.shape then
				v665.Shape = v664.shape
			end
			v665.Name = v664 and (v664.n or "Part") or "Part"
			v665.Anchored = true
			v665.Size = Vector3.new(0.6, 1.1, 3.1)
			v665.CFrame = v661 * (v664 and v664.r or CFrame.identity)
			v665.Color = v662
			v665.Material = v663
			v665.TopSurface = Enum.SurfaceType.Smooth
			v665.BottomSurface = Enum.SurfaceType.Smooth
			local v666
			if v664 == nil then
				v666 = false
			else
				v666 = v664.c == true
			end
			v665.CanCollide = v666
			v665.CanQuery = (not v664 or v664.q == nil) and true or v664.q
			v665.CanTouch = false
			v665.CastShadow = (not v664 or v664.s == nil) and true or v664.s
			if v664 and v664.t then
				v665.Transparency = v664.t
			end
			if v664 and v664.refl then
				v665.Reflectance = v664.refl
			end
			v665.Parent = v_u_75
		end
		local v667 = v647 * CFrame.new(0.2, 1.65, -0.2) * CFrame.Angles(0, 0.4, 0)
		local v668 = Color3.fromHex("6B6F5A")
		local v669 = v_u_3.Fabric
		local v670 = {
			["n"] = "Blanket",
			["s"] = false,
			["q"] = false
		}
		local v671 = Instance.new("Part")
		if v670 and v670.shape then
			v671.Shape = v670.shape
		end
		v671.Name = v670 and (v670.n or "Part") or "Part"
		v671.Anchored = true
		v671.Size = Vector3.new(2, 0.08, 1.4)
		v671.CFrame = v667 * (v670 and v670.r or CFrame.identity)
		v671.Color = v668
		v671.Material = v669
		v671.TopSurface = Enum.SurfaceType.Smooth
		v671.BottomSurface = Enum.SurfaceType.Smooth
		local v672
		if v670 == nil then
			v672 = false
		else
			v672 = v670.c == true
		end
		v671.CanCollide = v672
		v671.CanQuery = (not v670 or v670.q == nil) and true or v670.q
		v671.CanTouch = false
		local v673
		if v670 and v670.s ~= nil then
			v673 = v670.s
		else
			v673 = false
		end
		v671.CastShadow = v673
		if v670 and v670.t then
			v671.Transparency = v670.t
		end
		if v670 and v670.refl then
			v671.Reflectance = v670.refl
		end
		v671.Parent = v_u_75
		local v674 = CFrame.new(p_u_66.X + -8.2, p_u_66.Y + 0, p_u_66.Z + 21.4) * CFrame.Angles(0, 0.20943951023931956, 0)
		local v675 = v674 * CFrame.new(0, 1, 0)
		local v676 = Color3.fromHex("6A503A")
		local v677 = v_u_3.WoodPlanks
		local v678 = {
			["n"] = "SideCrate",
			["c"] = true
		}
		local v679 = Instance.new("Part")
		if v678 and v678.shape then
			v679.Shape = v678.shape
		end
		v679.Name = v678 and (v678.n or "Part") or "Part"
		v679.Anchored = true
		v679.Size = Vector3.new(2, 2, 2)
		v679.CFrame = v675 * (v678 and v678.r or CFrame.identity)
		v679.Color = v676
		v679.Material = v677
		v679.TopSurface = Enum.SurfaceType.Smooth
		v679.BottomSurface = Enum.SurfaceType.Smooth
		local v680
		if v678 == nil then
			v680 = false
		else
			v680 = v678.c == true
		end
		v679.CanCollide = v680
		v679.CanQuery = (not v678 or v678.q == nil) and true or v678.q
		v679.CanTouch = false
		v679.CastShadow = (not v678 or v678.s == nil) and true or v678.s
		if v678 and v678.t then
			v679.Transparency = v678.t
		end
		if v678 and v678.refl then
			v679.Reflectance = v678.refl
		end
		v679.Parent = v_u_75
		local v681 = v674 * CFrame.new(-0.2, 2.15, 0.2)
		local v682 = Color3.fromHex("3A3634")
		local v683 = v_u_3.Fabric
		local v684 = {
			["n"] = "Book",
			["s"] = false,
			["q"] = false
		}
		local v685 = Instance.new("Part")
		if v684 and v684.shape then
			v685.Shape = v684.shape
		end
		v685.Name = v684 and (v684.n or "Part") or "Part"
		v685.Anchored = true
		v685.Size = Vector3.new(1.1, 0.3, 0.8)
		v685.CFrame = v681 * (v684 and v684.r or CFrame.identity)
		v685.Color = v682
		v685.Material = v683
		v685.TopSurface = Enum.SurfaceType.Smooth
		v685.BottomSurface = Enum.SurfaceType.Smooth
		local v686
		if v684 == nil then
			v686 = false
		else
			v686 = v684.c == true
		end
		v685.CanCollide = v686
		v685.CanQuery = (not v684 or v684.q == nil) and true or v684.q
		v685.CanTouch = false
		local v687
		if v684 and v684.s ~= nil then
			v687 = v684.s
		else
			v687 = false
		end
		v685.CastShadow = v687
		if v684 and v684.t then
			v685.Transparency = v684.t
		end
		if v684 and v684.refl then
			v685.Reflectance = v684.refl
		end
		v685.Parent = v_u_75
		local v688 = v674 * CFrame.new(0.5, 2.25, -0.4)
		local v689 = Color3.fromHex("D8CFA8")
		local v690 = v_u_3.Plastic
		local v691 = {
			["n"] = "Candle",
			["s"] = false,
			["q"] = false
		}
		local v692 = Instance.new("Part")
		if v691 and v691.shape then
			v692.Shape = v691.shape
		end
		v692.Name = v691 and (v691.n or "Part") or "Part"
		v692.Anchored = true
		v692.Size = Vector3.new(0.3, 0.5, 0.3)
		v692.CFrame = v688 * (v691 and v691.r or CFrame.identity)
		v692.Color = v689
		v692.Material = v690
		v692.TopSurface = Enum.SurfaceType.Smooth
		v692.BottomSurface = Enum.SurfaceType.Smooth
		local v693
		if v691 == nil then
			v693 = false
		else
			v693 = v691.c == true
		end
		v692.CanCollide = v693
		v692.CanQuery = (not v691 or v691.q == nil) and true or v691.q
		v692.CanTouch = false
		local v694
		if v691 and v691.s ~= nil then
			v694 = v691.s
		else
			v694 = false
		end
		v692.CastShadow = v694
		if v691 and v691.t then
			v692.Transparency = v691.t
		end
		if v691 and v691.refl then
			v692.Reflectance = v691.refl
		end
		v692.Parent = v_u_75
		for _ = 1, 8 do
			local v695 = v372:NextNumber(-18, 26)
			local v696 = v372:NextNumber(-22, 22)
			local v697 = v695 - 2
			if math.abs(v697) < 7 then
				local v698 = v696 + 4
				if math.abs(v698) < 5 then
					v695 = v695 + 14
				end
			end
			local v699 = v_u_14
			local v700 = v372:NextNumber(0.8, 1.2)
			v699(v_u_75, Vector3.new(v700, 0.03, v372:NextNumber(1.1, 1.5)), CFrame.new(p_u_66.X + v695, p_u_66.Y + 0.04, p_u_66.Z + v696) * CFrame.Angles(0, v372:NextNumber(0, 3.141592653589793), 0), Color3.fromHex("A8A08C"):Lerp(v_u_4.stain, v372:NextNumber(0.2, 0.5)), v_u_3.Fabric, {
				["n"] = "Paper",
				["s"] = false,
				["q"] = false
			})
		end
		for _ = 1, 5 do
			local v701 = v372:NextNumber(-18, 26)
			local v702 = v372:NextNumber(-20, 20)
			local v703 = CFrame.new(p_u_66.X + v701, p_u_66.Y + 0.21, p_u_66.Z + v702) * CFrame.Angles(0, v372:NextNumber(0, 3.141592653589793), 0)
			local v704 = v_u_4.olive:Lerp(Color3.fromHex("9C7A3C"), v372:NextNumber())
			local v705 = v_u_3.Metal
			local v706 = {
				["shape"] = nil,
				["n"] = "Can",
				["s"] = false,
				["q"] = false,
				["shape"] = Enum.PartType.Cylinder
			}
			local v707 = Instance.new("Part")
			if v706 and v706.shape then
				v707.Shape = v706.shape
			end
			v707.Name = v706 and (v706.n or "Part") or "Part"
			v707.Anchored = true
			v707.Size = Vector3.new(0.6, 0.42, 0.42)
			v707.CFrame = v703 * (v706 and v706.r or CFrame.identity)
			v707.Color = v704
			v707.Material = v705
			v707.TopSurface = Enum.SurfaceType.Smooth
			v707.BottomSurface = Enum.SurfaceType.Smooth
			local v708
			if v706 == nil then
				v708 = false
			else
				v708 = v706.c == true
			end
			v707.CanCollide = v708
			v707.CanQuery = (not v706 or v706.q == nil) and true or v706.q
			v707.CanTouch = false
			local v709
			if v706 and v706.s ~= nil then
				v709 = v706.s
			else
				v709 = false
			end
			v707.CastShadow = v709
			if v706 and v706.t then
				v707.Transparency = v706.t
			end
			if v706 and v706.refl then
				v707.Reflectance = v706.refl
			end
			v707.Parent = v_u_75
		end
		local v710 = v_u_72.X - 0.5
		local v711 = CFrame.new(p_u_66.X + v710, p_u_66.Y + 2.6, p_u_66.Z + 4) * CFrame.Angles(0.13962634015954636, 0, -0.24434609527920614)
		local v712 = v_u_4.wood
		local v713 = v_u_3.Wood
		local v714 = {
			["n"] = "Broom",
			["s"] = false
		}
		local v715 = Instance.new("Part")
		if v714 and v714.shape then
			v715.Shape = v714.shape
		end
		v715.Name = v714 and (v714.n or "Part") or "Part"
		v715.Anchored = true
		v715.Size = Vector3.new(0.18, 5.4, 0.18)
		v715.CFrame = v711 * (v714 and v714.r or CFrame.identity)
		v715.Color = v712
		v715.Material = v713
		v715.TopSurface = Enum.SurfaceType.Smooth
		v715.BottomSurface = Enum.SurfaceType.Smooth
		local v716
		if v714 == nil then
			v716 = false
		else
			v716 = v714.c == true
		end
		v715.CanCollide = v716
		v715.CanQuery = (not v714 or v714.q == nil) and true or v714.q
		v715.CanTouch = false
		local v717
		if v714 and v714.s ~= nil then
			v717 = v714.s
		else
			v717 = false
		end
		v715.CastShadow = v717
		if v714 and v714.t then
			v715.Transparency = v714.t
		end
		if v714 and v714.refl then
			v715.Reflectance = v714.refl
		end
		v715.Parent = v_u_75
		local v718 = v_u_72.X - 0.45
		local v719 = CFrame.new(p_u_66.X + v718, p_u_66.Y + 0.45, p_u_66.Z + 4.9)
		local v720 = Color3.fromHex("8C7A5E")
		local v721 = v_u_3.Fabric
		local v722 = {
			["n"] = "BroomHead",
			["s"] = false,
			["q"] = false
		}
		local v723 = Instance.new("Part")
		if v722 and v722.shape then
			v723.Shape = v722.shape
		end
		v723.Name = v722 and (v722.n or "Part") or "Part"
		v723.Anchored = true
		v723.Size = Vector3.new(0.4, 0.9, 1.4)
		v723.CFrame = v719 * (v722 and v722.r or CFrame.identity)
		v723.Color = v720
		v723.Material = v721
		v723.TopSurface = Enum.SurfaceType.Smooth
		v723.BottomSurface = Enum.SurfaceType.Smooth
		local v724
		if v722 == nil then
			v724 = false
		else
			v724 = v722.c == true
		end
		v723.CanCollide = v724
		v723.CanQuery = (not v722 or v722.q == nil) and true or v722.q
		v723.CanTouch = false
		local v725
		if v722 and v722.s ~= nil then
			v725 = v722.s
		else
			v725 = false
		end
		v723.CastShadow = v725
		if v722 and v722.t then
			v723.Transparency = v722.t
		end
		if v722 and v722.refl then
			v723.Reflectance = v722.refl
		end
		v723.Parent = v_u_75
		local function v734(p726, p727) -- name: window
			-- upvalues: (ref) v_u_14, (copy) v_u_75, (ref) v_u_4, (ref) v_u_3, (ref) v_u_1
			local v728 = v_u_14(v_u_75, Vector3.new(4.4, 2, 0.5), p727, v_u_4.steelDark, v_u_3.Metal, {
				["n"] = "WindowFrame",
				["s"] = false
			})
			v728:SetAttribute("BuildingId", "hideout")
			v728:SetAttribute("Face", p726)
			v728:SetAttribute("Cut", true)
			v_u_1:AddTag(v728, "HushWall")
			local v729 = v_u_14(v_u_75, Vector3.new(4, 1.6, 0.1), p727 * CFrame.new(0, 0, 0.1), Color3.fromHex("7F95A6"), v_u_3.Glass, {
				["n"] = "WindowGlass",
				["t"] = 0.35,
				["s"] = false,
				["q"] = false
			})
			v729:SetAttribute("BuildingId", "hideout")
			v729:SetAttribute("Face", p726)
			v729:SetAttribute("Cut", true)
			v_u_1:AddTag(v729, "HushWall")
			for v730, v731 in { 9, -7, 4 } do
				local v732 = v_u_14(v_u_75, Vector3.new(4.8, 0.45, 0.2), p727 * CFrame.new(0, -0.6 + (v730 - 1) * 0.6, -0.4) * CFrame.Angles(0, 0, (math.rad(v731))), v_u_4.wood, v_u_3.WoodPlanks, {
					["n"] = "Board",
					["s"] = false
				})
				v732:SetAttribute("BuildingId", "hideout")
				v732:SetAttribute("Face", p726)
				v732:SetAttribute("Cut", true)
				v_u_1:AddTag(v732, "HushWall")
			end
			local v733 = Instance.new("SpotLight")
			v733.Face = Enum.NormalId.Front
			v733.Angle = 60
			v733.Range = 16
			v733.Brightness = 0.6
			v733.Color = Color3.fromHex("9FB4C8")
			v733.Shadows = false
			v733.Parent = v729
		end
		local v735 = -v_u_72.Z + 0.1
		v734("N", CFrame.new(p_u_66.X + -9, p_u_66.Y + 9.2, p_u_66.Z + v735) * CFrame.Angles(0, 3.141592653589793, 0))
		local v736 = -v_u_72.X + 0.1
		v734("W", CFrame.new(p_u_66.X + v736, p_u_66.Y + 9.2, p_u_66.Z + -14) * CFrame.Angles(0, -1.5707963267948966, 0))
		v_u_75.Parent = p65
	end
	v_u_77.Parent = p65
	local v_u_737 = {}
	return {
		["model"] = v_u_75,
		["lights"] = v_u_77,
		["tubes"] = v_u_76,
		["setLightLevel"] = function(p738, p739) -- name: setLightLevel
			-- upvalues: (copy) v_u_77, (copy) v_u_76, (copy) v_u_737, (ref) v_u_41, (ref) v_u_64, (copy) p_u_66, (copy) v_u_73, (ref) v_u_42, (ref) v_u_14, (ref) v_u_4, (ref) v_u_3, (copy) v_u_72
			for _, v740 in v_u_77:GetChildren() do
				v740:Destroy()
			end
			table.clear(v_u_76)
			table.clear(v_u_737)
			for v741, v742 in v_u_41 do
				local v743
				if v742.minLevel <= p738 then
					v743 = not v742.lane or p739
				else
					v743 = false
				end
				if v742.lane and not p739 then
					v743 = false
				end
				local v744 = v_u_64(v_u_77, p_u_66, v742, v_u_73, v743, v741)
				if not v743 or v742.dead == true then
					continue
				end
				local v745 = v_u_76
				table.insert(v745, v744)
			end
			for _, v746 in v_u_42 do
				local v747 = v_u_14(v_u_77, Vector3.new(0.35, 0.35, 0.35), CFrame.new(p_u_66 + v746.pos), v_u_4.warm, v_u_3.Neon, {
					["shape"] = nil,
					["n"] = "Bulb",
					["s"] = false,
					["q"] = false,
					["shape"] = Enum.PartType.Ball
				})
				local v748 = Instance.new("PointLight")
				v748.Color = v_u_4.warm
				v748.Range = v746.range
				local v749
				if p738 <= 0 then
					v749 = v746.brightness
				else
					v749 = v746.brightness * 0.45
				end
				v748.Brightness = v749
				v748.Shadows = p738 <= 0
				v748.Parent = v747
				local v750 = v_u_737
				table.insert(v750, v747)
			end
			if p738 >= 3 then
				for v751 = 0, 11 do
					local v752 = v751 * 3.4 + -20
					local v753 = v_u_14
					local v754 = v_u_77
					local v755 = CFrame.new
					local v756 = p_u_66
					local v757 = v751 * 1.3
					local v758 = math.sin(v757) * 0.25 + 8.6
					local v759 = v_u_72.Z - 1.2
					local v760 = v753(v754, Vector3.new(0.3, 0.3, 0.3), v755(v756 + Vector3.new(v752, v758, v759)), v_u_4.warm, v_u_3.Neon, {
						["shape"] = nil,
						["n"] = "StringBulb",
						["s"] = false,
						["q"] = false,
						["shape"] = Enum.PartType.Ball
					})
					if v751 % 3 ~= 0 then
						continue
					end
					local v761 = Instance.new("PointLight")
					v761.Color = v_u_4.warm
					v761.Range = 9
					v761.Brightness = 0.5
					v761.Parent = v760
				end
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) v_u_75, (copy) v_u_77
			v_u_75:Destroy()
			v_u_77:Destroy()
		end
	}
end
return v2