-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDBadge

local v_u_1 = game:GetService("Players")
local v_u_170 = {
	["TIER_NAMES"] = {
		"COMMON",
		"RARE",
		"EPIC",
		"LEGENDARY"
	},
	["tierColor"] = function(p2, p3) -- name: tierColor
		local v4 = tonumber(p3) or 1
		local v5 = math.floor(v4)
		local v6 = math.clamp(v5, 1, 4)
		return (p2.rarity[v6 + 1] or p2.color.accent):Lerp(Color3.new(1, 1, 1), 0.22)
	end,
	["emblem"] = function(p7, p8, p9, p10, p11) -- name: emblem
		-- upvalues: (copy) v_u_170
		local v12 = p8.color
		local v13
		if p11 then
			local v14 = v_u_170.tierColor
			local v15
			if p9 then
				v15 = p9.tier
			else
				v15 = p9
			end
			v13 = v14(p8, v15)
		else
			v13 = v12.muted
		end
		local v16 = p7.new("Frame", {
			["Name"] = "Emblem",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(p10, p10)
		})
		local v17 = p10 * 0.7 + 0.5
		local v18 = math.floor(v17)
		local v19 = p7.new("Frame", {
			["Name"] = "Diamond",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(v18, v18),
			["BackgroundColor3"] = v13,
			["BackgroundTransparency"] = p11 and 0.8 or 0.93
		}, v16)
		local v20 = p7.stroke
		local v21 = p10 / 36 + 0.5
		local v22 = math.floor(v21)
		v20(v19, v13, math.max(1, v22), p11 and 0 or 0.35)
		local v23 = v18 * 0.74 + 0.5
		local v24 = math.floor(v23)
		local v25 = p7.new("Frame", {
			["Name"] = "Inner",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(v24, v24)
		}, v16)
		p7.stroke(v25, v13, 1, p11 and 0.55 or 0.75)
		local v26 = p10 * 0.4 + 0.5
		local v27 = math.floor(v26)
		local v28 = p7.icon
		local v29 = p9 and p9.icon or "star"
		local v30 = tostring(v29)
		local v31 = {
			["parent"] = v16,
			["size"] = v27
		}
		local v32
		if p11 then
			v32 = v12.text
		else
			v32 = v12.muted
		end
		v31.color = v32
		v31.anchor = Vector2.new(0.5, 0.5)
		v31.position = UDim2.fromScale(0.5, 0.5)
		v28(v30, v31)
		return v16
	end,
	["new"] = function(p_u_33) -- name: new
		-- upvalues: (copy) v_u_1, (copy) v_u_170
		local v_u_34 = p_u_33.lib.HushUI
		local v_u_35 = p_u_33.shared.Theme
		local v_u_36 = p_u_33.shared.Badges
		local v_u_37 = v_u_35.color
		local v_u_38 = v_u_1.LocalPlayer
		local v39 = {}
		local v_u_40 = true
		local v_u_41 = nil
		local v_u_42 = nil
		local v_u_43 = nil
		local v_u_44 = {}
		local v_u_45 = nil
		local v_u_46 = 0
		local v_u_47 = 0
		local v_u_48 = 0
		local function v_u_71() -- name: placeFeed
			-- upvalues: (ref) v_u_43, (copy) v_u_35, (copy) v_u_38, (copy) v_u_34, (copy) p_u_33
			local v49 = v_u_43
			if v49 then
				local v50
				if v_u_35.isPhone() then
					local v51 = v_u_38:GetAttribute("Place") or "Menu"
					if tostring(v51) == "Raid" and v_u_34.device() == "Touch" then
						local v52 = p_u_33.controllers.HUD
						if v52 and v52.columnState then
							v50 = v52.columnState()
						else
							v50 = nil
						end
					else
						v50 = nil
					end
				else
					v50 = nil
				end
				if v50 then
					local v53 = v_u_34.safeInsets()
					v49.AnchorPoint = Vector2.new(0.5, 0)
					local v54 = UDim2.fromOffset
					local v55 = v50.cx + v53.l
					local v56 = math.floor(v55)
					local v57 = v50.feedTop + v53.t
					v49.Position = v54(v56, (math.floor(v57)))
					local v58 = UDim2.fromOffset
					local v59 = v50.w
					v49.Size = v58(math.floor(v59), 136)
					local v60 = v49:FindFirstChildOfClass("UIListLayout")
					if v60 then
						v60.VerticalAlignment = Enum.VerticalAlignment.Top
						v60.HorizontalAlignment = Enum.HorizontalAlignment.Center
					end
					local v61 = {}
					for _, v62 in v49:GetChildren() do
						if v62.Name ~= "Line" or not v62:IsA("GuiObject") then
							continue
						end
						table.insert(v61, v62)
					end
					table.sort(v61, function(p63, p64)
						return p63.LayoutOrder < p64.LayoutOrder
					end)
					local v65 = (v50.feedRoom + 6) / 34
					local v66 = math.floor(v65)
					local v67 = math.max(0, v66)
					for v68, v69 in v61 do
						local v70 = #v61 - v67 < v68
						if v69.Visible == v70 then
							continue
						end
						v69.Visible = v70
					end
				end
			else
				return
			end
		end
		local function v_u_89() -- name: build
			-- upvalues: (copy) v_u_34, (copy) v_u_35, (ref) v_u_41, (ref) v_u_42, (copy) v_u_38, (ref) v_u_43, (copy) v_u_71
			local v72, v73 = v_u_34.screen("HushBadge", v_u_35.layer.toast + 1, {
				["insets"] = "None"
			})
			v_u_41 = v72
			v_u_42 = v73
			local v74 = v_u_38:GetAttribute("Place") or "Menu"
			local v75 = tostring(v74)
			local v76
			if v75 == "Raid" then
				v76 = v_u_34.device() == "Touch"
			else
				v76 = false
			end
			local v77 = v75 == "Menu"
			local v78 = v_u_34.safeInsets()
			local v79 = v_u_34.new
			local v80 = "Frame"
			local v81 = {
				["Name"] = "Feed",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(v76 and 1 or 0, v77 and 1 or 0.5)
			}
			local v82
			if v77 then
				v82 = UDim2.new(0, 40 + v78.l, 1, -(44 + v78.b))
			else
				local v83 = UDim2.new
				local v84 = v76 and 1 or 0
				local v85
				if v76 then
					v85 = -(24 + v78.r)
				else
					v85 = 24 + v78.l
				end
				v82 = v83(v84, v85, 0.42, 0)
			end
			v81.Position = v82
			v81.Size = UDim2.fromOffset(360, 136)
			local v86 = v79(v80, v81, v73)
			local v87 = v_u_34.layout(v86, "v", 6)
			v87.VerticalAlignment = Enum.VerticalAlignment.Bottom
			local v88
			if v76 then
				v88 = Enum.HorizontalAlignment.Right
			else
				v88 = Enum.HorizontalAlignment.Left
			end
			v87.HorizontalAlignment = v88
			v_u_43 = v86
			v_u_71()
		end
		local function v_u_113(p90) -- name: buildCard
			-- upvalues: (ref) v_u_42, (copy) v_u_36, (ref) v_u_170, (copy) v_u_35, (copy) v_u_34, (copy) v_u_37, (copy) v_u_38
			local v91 = v_u_42
			if not v91 then
				return nil
			end
			local v92 = {}
			for _, v93 in p90 do
				local v94 = v_u_36.get(v93)
				if not v94 then
					continue
				end
				table.insert(v92, v94)
			end
			if #v92 == 0 then
				return nil
			end
			table.sort(v92, function(p95, p96)
				return p95.tier > p96.tier
			end)
			local v97 = v92[1]
			local v98 = v_u_170.tierColor(v_u_35, v97.tier)
			local v99 = v_u_34.device() == "Touch" and 440 or 540
			local v100 = v_u_34.new
			local v101 = {
				["Name"] = "Banner",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.04,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["BackgroundColor3"] = v_u_37.bg,
				["AnchorPoint"] = Vector2.new(0.5, 0)
			}
			local v102 = UDim2.new
			local v103 = v_u_38:GetAttribute("Place") or "Menu"
			v101.Position = v102(0.5, 0, 0, tostring(v103) == "Menu" and 128 or v_u_34.topInset() + 12 + v_u_34.safeInsets().t)
			v101.Size = UDim2.fromOffset(v99, 0)
			v101.AutomaticSize = Enum.AutomaticSize.Y
			local v104 = v100("Frame", v101, v91)
			v_u_34.stroke(v104, v98, 1, 0.3)
			v_u_34.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v98,
				["Size"] = UDim2.new(0, 4, 1, 0)
			}, v104)
			v_u_34.new("UISizeConstraint", {
				["MinSize"] = Vector2.new(v99, 104)
			}, v104)
			local v105 = v_u_170.emblem(v_u_34, v_u_35, v97, 76, true)
			v105.AnchorPoint = Vector2.new(0, 0.5)
			v105.Position = UDim2.new(0, 22, 0.5, 0)
			v105.Parent = v104
			local v106 = v_u_34.new("Frame", {
				["Name"] = "Body",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v104)
			v_u_34.pad(v106, {
				116,
				18,
				16,
				16
			})
			v_u_34.layout(v106, "v", 3)
			local v107 = #v92 > 2
			v_u_34.label({
				["parent"] = nil,
				["name"] = "Kicker",
				["text"] = nil,
				["style"] = "caps",
				["textSize"] = 12,
				["color"] = nil,
				["size"] = nil,
				["order"] = 1,
				["parent"] = v106,
				["text"] = v107 and "Badges earned" or "Badge earned",
				["color"] = v98,
				["size"] = UDim2.new(1, 0, 0, 16)
			})
			if v107 then
				v_u_34.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "h2",
					["size"] = nil,
					["order"] = 2,
					["parent"] = v106,
					["text"] = ("%d new badges"):format(#v92),
					["size"] = UDim2.new(1, 0, 0, 30)
				})
				local v108 = {}
				for _, v109 in v92 do
					local v110 = v109.name
					table.insert(v108, v110)
				end
				v_u_34.label({
					["parent"] = nil,
					["name"] = "Desc",
					["text"] = nil,
					["style"] = "small",
					["wrap"] = true,
					["size"] = nil,
					["valign"] = "top",
					["order"] = 3,
					["parent"] = v106,
					["text"] = table.concat(v108, ", "),
					["size"] = UDim2.new(1, 0, 0, 34)
				}).TextTruncate = Enum.TextTruncate.AtEnd
			else
				for v111, v112 in v92 do
					v_u_34.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "h2",
						["size"] = nil,
						["order"] = nil,
						["parent"] = v106,
						["text"] = v112.name,
						["size"] = UDim2.new(1, 0, 0, 30),
						["order"] = 2 + (v111 - 1) * 2
					})
					v_u_34.label({
						["parent"] = nil,
						["name"] = "Desc",
						["text"] = nil,
						["style"] = "small",
						["wrap"] = true,
						["size"] = nil,
						["valign"] = "top",
						["order"] = nil,
						["parent"] = v106,
						["text"] = v112.desc,
						["size"] = UDim2.new(1, 0, 0, 34),
						["order"] = 3 + (v111 - 1) * 2
					}).TextTruncate = Enum.TextTruncate.AtEnd
				end
			end
			v_u_34.label({
				["parent"] = nil,
				["name"] = "Where",
				["text"] = "See all badges under BADGES in the menu",
				["style"] = "micro",
				["color"] = nil,
				["size"] = nil,
				["order"] = 20,
				["parent"] = v106,
				["color"] = v_u_37.text2,
				["size"] = UDim2.new(1, 0, 0, 14)
			})
			v_u_34.new("Frame", {
				["Name"] = "Time",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.35,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v98,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, 2)
			}, v104)
			return v104
		end
		local function v_u_118() -- name: showNext
			-- upvalues: (copy) v_u_44, (copy) v_u_113, (ref) v_u_48, (ref) v_u_45, (copy) v_u_38, (copy) v_u_34, (copy) v_u_35
			local v114 = table.remove(v_u_44, 1)
			if v114 then
				local v115 = v_u_113(v114)
				if v115 then
					v_u_48 = v_u_48 + 1
					v_u_45 = {
						["card"] = v115,
						["at"] = os.clock()
					}
					local v116 = v_u_38:GetAttribute("Place") or "Menu"
					local v117 = tostring(v116) == "Menu" and 128 or v_u_34.topInset() + 12 + v_u_34.safeInsets().t
					v115.Position = UDim2.new(0.5, 0, 0, v117 - 12)
					v_u_34.fade(v115, 0, "slow", {
						["from"] = 1
					})
					v_u_34.tween(v115, {
						["Position"] = UDim2.new(0.5, 0, 0, v117)
					}, "slow", Enum.EasingStyle.Quint)
					v_u_34.sound(v_u_35.sounds.unlock, v_u_35.sounds.confirm)
				end
			else
				return
			end
		end
		local function v_u_121() -- name: hideCurrent
			-- upvalues: (ref) v_u_45, (copy) v_u_34
			local v119 = v_u_45
			v_u_45 = nil
			if v119 then
				local v_u_120 = v119.card
				v_u_34.fade(v_u_120, 1, "slow", {
					["onDone"] = function() -- name: onDone
						-- upvalues: (copy) v_u_120
						v_u_120:Destroy()
					end
				})
			end
		end
		function v39.banner(p122) -- name: banner
			-- upvalues: (ref) v_u_40, (copy) v_u_36, (copy) v_u_44
			if v_u_40 and type(p122) == "table" then
				local v123 = {}
				for _, v124 in p122 do
					if type(v124) ~= "string" or (not v_u_36.get(v124) or #v123 >= 40) then
						continue
					end
					table.insert(v123, v124)
				end
				if #v123 ~= 0 then
					if #v123 <= 2 then
						for _, v125 in v123 do
							local v126 = v_u_44
							table.insert(v126, { v125 })
						end
					else
						local v127 = v_u_44
						table.insert(v127, v123)
					end
					while #v_u_44 > 6 do
						table.remove(v_u_44, 1)
					end
				end
			else
				return
			end
		end
		function v39.feed(p128) -- name: feed
			-- upvalues: (ref) v_u_43, (ref) v_u_40, (copy) v_u_71, (copy) v_u_36, (ref) v_u_170, (copy) v_u_35, (copy) v_u_37, (ref) v_u_46, (copy) v_u_34, (copy) v_u_38, (copy) p_u_33
			local v129 = v_u_43
			if v_u_40 and (v129 and type(p128) == "table") then
				v_u_71()
				local v130 = p128.name or "Someone"
				local v131 = tostring(v130)
				if #v131 > 32 then
					v131 = string.sub(v131, 1, 32)
				end
				local v132 = v_u_36.get(p128.id)
				local v133 = p128.n
				local v134 = tonumber(v133)
				if v132 or v134 then
					local v135
					if v132 then
						v135 = v_u_170.tierColor(v_u_35, v132.tier)
					else
						v135 = v_u_37.accent
					end
					local v136
					if v132 then
						v136 = string.upper(v132.name)
					else
						v136 = ("%d BADGES"):format((math.floor(v134 or 0)))
					end
					v_u_46 = v_u_46 + 1
					local v137 = {}
					for _, v138 in v129:GetChildren() do
						if v138.Name ~= "Line" then
							continue
						end
						table.insert(v137, v138)
					end
					table.sort(v137, function(p139, p140)
						return p139.LayoutOrder < p140.LayoutOrder
					end)
					while #v137 >= 4 do
						table.remove(v137, 1):Destroy()
					end
					local v141 = v_u_34.new
					local v142 = "Frame"
					local v143 = {
						["Name"] = "Line",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["BackgroundColor3"] = v_u_37.bg
					}
					local v144
					if v_u_35.isPhone() then
						local v145 = v_u_38:GetAttribute("Place") or "Menu"
						if tostring(v145) == "Raid" and v_u_34.device() == "Touch" then
							local v146 = p_u_33.controllers.HUD
							if v146 and v146.columnState then
								v144 = v146.columnState()
							else
								v144 = nil
							end
						else
							v144 = nil
						end
					else
						v144 = nil
					end
					local v147
					if v144 then
						v147 = UDim2.new(1, 0, 0, 28)
					else
						v147 = UDim2.fromOffset(360, 28)
					end
					v143.Size = v147
					v143.LayoutOrder = v_u_46
					local v_u_148 = v141(v142, v143, v129)
					v_u_34.stroke(v_u_148, v_u_37.line, 1, 0.2)
					v_u_34.new("Frame", {
						["Name"] = "Bar",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["BackgroundColor3"] = v135,
						["Size"] = UDim2.new(0, 2, 1, 0)
					}, v_u_148)
					local v149 = v_u_170.emblem(v_u_34, v_u_35, v132 or {
						["icon"] = "star",
						["tier"] = 2
					}, 22, true)
					v149.AnchorPoint = Vector2.new(0, 0.5)
					v149.Position = UDim2.new(0, 8, 0.5, 0)
					v149.Parent = v_u_148
					local v150 = v_u_34.label({
						["parent"] = nil,
						["name"] = "Text",
						["rich"] = true,
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 13,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v_u_148,
						["text"] = ("<font color=\"#%s\">%s</font> earned <font color=\"#%s\">%s</font>"):format(v_u_37.text:ToHex(), v131:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), v135:ToHex(), (v136:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))),
						["color"] = v_u_37.text2,
						["position"] = UDim2.fromOffset(38, 0),
						["size"] = UDim2.new(1, -46, 1, 0)
					})
					v150.TextTruncate = Enum.TextTruncate.AtEnd
					local v151
					if v_u_35.isPhone() then
						local v152 = v_u_38:GetAttribute("Place") or "Menu"
						if tostring(v152) == "Raid" and v_u_34.device() == "Touch" then
							local v153 = p_u_33.controllers.HUD
							if v153 and v153.columnState then
								v151 = v153.columnState()
							else
								v151 = nil
							end
						else
							v151 = nil
						end
					else
						v151 = nil
					end
					if v151 then
						v150.TextWrapped = true
						v150.TextTruncate = Enum.TextTruncate.None
						v150.AutomaticSize = Enum.AutomaticSize.Y
						v150.Size = UDim2.new(1, -46, 0, 28)
						v150.TextYAlignment = Enum.TextYAlignment.Center
						v_u_148.AutomaticSize = Enum.AutomaticSize.Y
					end
					v_u_34.fade(v_u_148, 0, "fast", {
						["from"] = 1
					})
					task.delay(6, function()
						-- upvalues: (copy) v_u_148, (ref) v_u_34
						if v_u_148.Parent then
							local v154 = {
								["onDone"] = function() -- name: onDone
									-- upvalues: (ref) v_u_148
									v_u_148:Destroy()
								end
							}
							v_u_34.fade(v_u_148, 1, "slow", v154)
						end
					end)
				end
			else
				return
			end
		end
		function v39.update(p155) -- name: update
			-- upvalues: (ref) v_u_40, (ref) v_u_41, (copy) v_u_89, (ref) v_u_47, (copy) v_u_71, (ref) v_u_45, (copy) v_u_121, (copy) v_u_44, (copy) v_u_38, (copy) v_u_118
			if v_u_40 then
				if not (v_u_41 and v_u_41.Parent) then
					v_u_89()
				end
				v_u_47 = v_u_47 + p155
				if v_u_47 >= 0.1 then
					v_u_47 = 0
					v_u_71()
				end
				local v156 = v_u_45
				if v156 then
					local v157 = os.clock() - v156.at
					local v158 = v156.card:FindFirstChild("Time")
					if v158 then
						local v159 = UDim2.new
						local v160 = 1 - v157 / 5
						v158.Size = v159(math.clamp(v160, 0, 1), 0, 0, 2)
					end
					if v157 >= 5 then
						v_u_121()
						return
					end
				elseif #v_u_44 > 0 then
					local v161 = v_u_38:GetAttribute("Place") or "Menu"
					local v162 = tostring(v161)
					if v162 == "Hideout" or v162 == "Menu" and v_u_38:GetAttribute("MenuOpen") == true then
						v_u_118()
					end
				end
			end
		end
		function v39.rebuild() -- name: rebuild
			-- upvalues: (ref) v_u_45, (ref) v_u_41, (copy) v_u_89
			if v_u_45 then
				local function v163()
					-- upvalues: (ref) v_u_45
					v_u_45.card:Destroy()
				end
				pcall(v163)
				v_u_45 = nil
			end
			if v_u_41 then
				v_u_41:Destroy()
			end
			v_u_41 = nil
			v_u_89()
		end
		function v39.state() -- name: state
			-- upvalues: (copy) v_u_44, (ref) v_u_45, (ref) v_u_48, (ref) v_u_43, (copy) v_u_38
			local v164 = #v_u_44
			local v165 = v_u_45 ~= nil
			local v166 = tostring(v165)
			local v167 = v_u_48
			local v168 = v_u_43 and #v_u_43:GetChildren() or 0
			local v169 = v_u_38:GetAttribute("Place") or "Menu"
			return ("queue=%d current=%s shown=%d feed=%d place=%s"):format(v164, v166, v167, v168, (tostring(v169)))
		end
		function v39.feedFrame() -- name: feedFrame
			-- upvalues: (ref) v_u_43
			return v_u_43
		end
		function v39.destroy() -- name: destroy
			-- upvalues: (ref) v_u_40, (ref) v_u_41
			v_u_40 = false
			if v_u_41 then
				v_u_41:Destroy()
			end
		end
		v_u_89()
		return v39
	end
}
return v_u_170