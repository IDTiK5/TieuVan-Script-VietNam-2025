-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreFeatured

return {
	["new"] = function(p_u_1, p_u_2) -- name: new
		local v_u_3 = p_u_1.ui
		local v4 = p_u_1.theme
		local v_u_5 = v4.color
		local v_u_6 = p_u_1.compact()
		local v_u_7 = v4.isPhone()
		local v_u_8 = p_u_1.cctx.shared.LimitedSale
		local v_u_9 = {}
		local v_u_10 = true
		local v_u_11 = nil
		local v_u_12 = nil
		local v_u_13 = os.clock()
		local v_u_14 = (-1 / 0)
		local v_u_15 = {}
		local v_u_16 = {}
		local v_u_17 = false
		local function v_u_23(p18) -- name: entryOf
			if type(p18) == "table" then
				local v19 = p18.products
				if type(v19) == "table" then
					local v20 = p18.featured
					if type(v20) == "string" then
						for _, v21 in p18.products do
							if v21.id ~= p18.featured then
								continue
							end
							local v22 = v21.limited
							if type(v22) ~= "table" then
								continue
							end
							return v21
						end
						return nil
					end
				end
			end
			return nil
		end
		function v_u_9.setView(p24, p25) -- name: setView
			-- upvalues: (ref) v_u_12, (copy) v_u_23, (ref) v_u_11, (ref) v_u_15, (ref) v_u_13
			if type(p24) == "table" then
				local v26 = v_u_12
				if not rawequal(p24, v26) then
					v_u_12 = p24
					v_u_11 = v_u_23(p24)
					v_u_15 = {}
					if type(p24) == "table" then
						local v27 = p24.products
						if type(v27) == "table" then
							for _, v28 in p24.products do
								if type(v28) ~= "table" then
									continue
								end
								local v29 = v28.id
								if type(v29) ~= "string" then
									continue
								end
								local v30 = v28.limited
								if type(v30) ~= "table" then
									continue
								end
								v_u_15[v28.id] = v28
							end
						end
					end
					local v31 = os.clock()
					if type(p25) == "number" and (p25 == p25 and p25 <= v31) then
						v31 = p25
					end
					v_u_13 = v31
				end
			else
				return
			end
		end
		function v_u_9.entry() -- name: entry
			-- upvalues: (ref) v_u_11
			return v_u_11
		end
		local function v_u_39(p32) -- name: statusOf
			-- upvalues: (copy) v_u_8, (ref) v_u_13
			if type(p32) == "table" then
				local v33 = p32.limited
				if type(v33) == "table" then
					local v34 = p32.limited
					if v34.state == "running" then
						local v35 = v_u_8.TUNE
						local v36 = v34.now
						local v37 = v34.endsAt
						if type(v36) == "number" and (v36 == v36 and (v36 ~= (1 / 0) and (v36 ~= (-1 / 0) and v36 >= v35.minClock))) then
							if type(v37) == "number" and (v37 == v37 and (v37 ~= (1 / 0) and v37 >= v35.minClock)) then
								local v38 = v37 - v_u_8.clientNow(v36, v_u_13, os.clock())
								if v38 == v38 and v35.maxHours * 3600 + v35.skew >= v38 then
									if v38 <= 0 then
										return "ended", v38
									else
										return "running", v38
									end
								else
									return "unusable", nil
								end
							else
								return "unusable", nil
							end
						else
							return "unusable", nil
						end
					else
						return "coming", nil
					end
				end
			end
			return "none", nil
		end
		local function v_u_43(p40) -- name: textOf
			-- upvalues: (copy) v_u_39, (copy) v_u_8
			local v41, v42 = v_u_39(p40)
			if v41 == "none" then
				return ""
			elseif v41 == "unusable" then
				return "LIMITED TIME"
			elseif v41 == "coming" then
				return v_u_8.timerText("coming", nil)
			elseif v41 == "ended" then
				return v_u_8.timerText("ended", nil)
			else
				return v_u_8.timerText("running", v42)
			end
		end
		local function v_u_47(p44) -- name: toneOf
			-- upvalues: (copy) v_u_39, (copy) v_u_8
			local v45, v46 = v_u_39(p44)
			return v45 ~= "running" and "none" or v_u_8.tone(v46)
		end
		function v_u_9.left(p48) -- name: left
			-- upvalues: (ref) v_u_11, (ref) v_u_15, (copy) v_u_39
			local v49
			if p48 == nil then
				v49 = v_u_11
			else
				v49 = v_u_15[p48]
				if v49 == nil then
					if v_u_11 == nil or v_u_11.id ~= p48 then
						v49 = nil
					else
						v49 = v_u_11
					end
				end
			end
			local _, v50 = v_u_39(v49)
			return v50
		end
		function v_u_9.text(p51) -- name: text
			-- upvalues: (copy) v_u_43, (ref) v_u_11, (ref) v_u_15
			local v52 = v_u_43
			local v53
			if p51 == nil then
				v53 = v_u_11
			else
				v53 = v_u_15[p51]
				if v53 == nil then
					if v_u_11 == nil or v_u_11.id ~= p51 then
						v53 = nil
					else
						v53 = v_u_11
					end
				end
			end
			return v52(v53)
		end
		function v_u_9.tone(p54) -- name: tone
			-- upvalues: (copy) v_u_47, (ref) v_u_11, (ref) v_u_15
			local v55 = v_u_47
			local v56
			if p54 == nil then
				v56 = v_u_11
			else
				v56 = v_u_15[p54]
				if v56 == nil then
					if v_u_11 == nil or v_u_11.id ~= p54 then
						v56 = nil
					else
						v56 = v_u_11
					end
				end
			end
			return v55(v56)
		end
		function v_u_9.status(p57) -- name: status
			-- upvalues: (copy) v_u_39, (ref) v_u_11, (ref) v_u_15
			local v58 = v_u_39
			local v59
			if p57 == nil then
				v59 = v_u_11
			else
				v59 = v_u_15[p57]
				if v59 == nil then
					if v_u_11 == nil or v_u_11.id ~= p57 then
						v59 = nil
					else
						v59 = v_u_11
					end
				end
			end
			return v58(v59)
		end
		local function v_u_67(p60, p61, p62) -- name: paintOne
			-- upvalues: (copy) v_u_9, (copy) v_u_8
			local v63, v64 = v_u_9.status(p60.pid)
			if p60.bare then
				local v65 = p60.lbl
				local v66
				if v63 == "running" and v64 ~= nil then
					v66 = v_u_8.remaining(v64)
				else
					v66 = v63 == "ended" and "ENDED" or (v63 == "coming" and "COMING SOON" or "")
				end
				v65.Text = v66
				if p60.caption then
					p60.caption.Text = v63 == "running" and "ENDS IN" or (v63 == "ended" and "THE SALE IS OVER" or "LIMITED TIME OFFER")
				end
			else
				p60.lbl.Text = p61
			end
			p60.lbl.TextColor3 = p62
			p60.lbl:SetAttribute("TimerText", p61)
		end
		local function v_u_75() -- name: paintAll
			-- upvalues: (ref) v_u_16, (copy) v_u_67, (copy) v_u_9, (copy) v_u_5
			local v68 = {}
			for _, v69 in v_u_16 do
				if not v69.lbl.Parent then
					continue
				end
				local v70 = v_u_67
				local v71 = v_u_9.text(v69.pid)
				local v72 = v69.pid
				local v73 = v_u_9.tone(v72)
				local v74
				if v73 == "minute" then
					v74 = v_u_5.danger
				elseif v73 == "hour" then
					v74 = v_u_5.accent
				else
					v74 = v_u_5.text
				end
				v70(v69, v71, v74)
				table.insert(v68, v69)
			end
			v_u_16 = v68
		end
		local function v_u_86() -- name: tick
			-- upvalues: (ref) v_u_16, (ref) v_u_11, (copy) v_u_75, (copy) v_u_39, (ref) v_u_15, (ref) v_u_10, (copy) p_u_2, (ref) v_u_14, (copy) p_u_1
			if next(v_u_16) ~= nil or v_u_11 ~= nil then
				v_u_75()
				local v76 = false
				local v77 = false
				local v78, v79
				if v_u_11 == nil then
					v78 = v77
					v79 = v76
				else
					local v80 = v_u_39(v_u_11)
					if v80 == "ended" then
						v76 = true
						v78 = v77
						v79 = v76
					elseif v80 == "running" then
						v78 = v77
						v79 = v76
					else
						v77 = true
						v78 = v77
						v79 = v76
					end
				end
				for _, v81 in v_u_16 do
					local v82 = v81.pid
					local v83
					if v82 == nil then
						v83 = v_u_11
					else
						v83 = v_u_15[v82]
						if v83 == nil then
							if v_u_11 == nil or v_u_11.id ~= v82 then
								v83 = nil
							else
								v83 = v_u_11
							end
						end
					end
					local v84 = v_u_39(v83)
					if v84 == "ended" then
						v76 = true
						v79 = v76
					else
						if v84 == "running" then
							continue
						end
						v77 = true
						v78 = v77
					end
				end
				if v79 then
					if v_u_10 and p_u_2.onRefresh then
						local v85 = os.clock()
						if v85 - v_u_14 >= 5 then
							v_u_14 = v85
							p_u_1.invalidate("store")
							p_u_2.onRefresh()
						end
					end
				elseif v78 and (os.clock() - v_u_14 >= 30 and (v_u_10 and p_u_2.onRefresh)) then
					v_u_14 = os.clock()
					p_u_1.invalidate("store")
					p_u_2.onRefresh()
				end
			end
		end
		v_u_9.tick = v_u_86
		function v_u_9.timerLabel(p87, p88, p89, p90, p91, p92) -- name: timerLabel
			-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_5, (ref) v_u_16, (copy) v_u_67, (ref) v_u_17, (copy) p_u_2, (ref) v_u_10, (copy) v_u_86
			local v93 = p91 or "bodyStrong"
			local v94
			if type(p88) == "table" then
				local v95 = p88.id
				if type(v95) == "string" then
					v94 = p88.id
				else
					v94 = nil
				end
			else
				v94 = nil
			end
			local v96 = v_u_3.label
			local v97 = {
				["parent"] = nil,
				["name"] = "LimitedTimer",
				["text"] = nil,
				["style"] = nil,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = p87,
				["text"] = v_u_9.text(v94),
				["style"] = v93
			}
			local v98 = v_u_9.tone(v94)
			local v99
			if v98 == "minute" then
				v99 = v_u_5.danger
			elseif v98 == "hour" then
				v99 = v_u_5.accent
			else
				v99 = v_u_5.text
			end
			v97.color = v99
			v97.position = p89
			v97.size = p90
			local v100 = v96(v97)
			local v101 = {
				["lbl"] = v100,
				["style"] = v93,
				["bare"] = p92 ~= nil,
				["caption"] = p92,
				["pid"] = v94
			}
			local v102 = v_u_16
			table.insert(v102, v101)
			local v103 = v_u_67
			local v104 = v_u_9.text(v94)
			local v105 = v_u_9.tone(v94)
			local v106
			if v105 == "minute" then
				v106 = v_u_5.danger
			elseif v105 == "hour" then
				v106 = v_u_5.accent
			else
				v106 = v_u_5.text
			end
			v103(v101, v104, v106)
			if not v_u_17 then
				if p_u_2.noTicker == true then
					return v100
				end
				v_u_17 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_10, (ref) p_u_2, (ref) v_u_86, (ref) v_u_17
					while v_u_10 do
						if p_u_2.isVisible == nil or p_u_2.isVisible() then
							local v107 = v_u_86
							pcall(v107)
						end
						task.wait(1)
					end
					v_u_17 = false
				end)
			end
			return v100
		end
		function v_u_9.banner(p108, p_u_109, p110, p111) -- name: banner
			-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) p_u_2, (copy) v_u_9
			local v112 = v_u_7 and 196 or (v_u_6 and 236 or 268)
			local v113 = v_u_3.new("TextButton", {
				["Name"] = "Featured",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.05,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["BackgroundColor3"] = v_u_5.raised,
				["LayoutOrder"] = p111,
				["Size"] = UDim2.fromOffset(p110, v112)
			}, p108)
			v113.SelectionImageObject = v_u_3.selectionImage()
			local v_u_114 = v_u_3.stroke(v113, v_u_5.accent, 2, 0.1)
			local v115 = p_u_109.banner
			local v116
			if type(v115) == "string" then
				v116 = p_u_109.banner ~= ""
			else
				v116 = false
			end
			if v116 then
				v_u_3.new("ImageLabel", {
					["Name"] = "BannerArt",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Image"] = nil,
					["ScaleType"] = nil,
					["Size"] = nil,
					["ZIndex"] = 0,
					["Image"] = p_u_109.banner,
					["ScaleType"] = Enum.ScaleType.Crop,
					["Size"] = UDim2.fromScale(1, 1)
				}, v113)
			end
			v_u_3.new("Frame", {
				["Name"] = "Accent",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_5.accent,
				["Size"] = UDim2.new(1, 0, 0, 3)
			}, v113)
			v_u_3.new("Frame", {
				["Name"] = "Glow",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_5.accentDeep,
				["BackgroundTransparency"] = v116 and 1 or 0.4,
				["Size"] = UDim2.new(0.31, 0, 1, 0)
			}, v113)
			local v117 = p110 * 0.29
			local v118 = math.floor(v117)
			v_u_3.badge("FEATURED", "accent", {
				["parent"] = nil,
				["name"] = "BadgeFeatured",
				["position"] = nil,
				["height"] = 18,
				["zindex"] = 6,
				["parent"] = v113,
				["position"] = UDim2.fromOffset(10, 10)
			})
			local v119 = v_u_3.badge
			local v120 = p_u_109.badge
			v119((type(v120) ~= "string" or p_u_109.badge == "") and "LIMITED TIME" or p_u_109.badge, "danger", {
				["parent"] = nil,
				["name"] = "BadgeLimited",
				["position"] = nil,
				["height"] = 18,
				["zindex"] = 6,
				["parent"] = v113,
				["position"] = UDim2.fromOffset(10, 32)
			})
			local v121 = p_u_109.showcase
			if type(v121) == "table" and (v121[1] and p_u_2.itemIcon) then
				local v122 = v112 - 28
				local v123 = math.min(v122, v118)
				local v124 = p_u_2.itemIcon
				local v125 = v121[1]
				local v126 = UDim2.fromOffset
				local v127 = (v118 - v123) / 2
				local v128 = v124(v113, v125, v123, v126(math.floor(v127) + 6, 20), nil, true)
				if v128 then
					v128.Name = "Preview"
				end
			end
			local v129 = p110 * 0.7
			local v130 = math.floor(v129)
			local v131
			if v_u_7 then
				v131 = 16
			else
				local v132 = p110 * 0.015
				local v133 = math.floor(v132)
				v131 = math.clamp(v133, 20, 30)
			end
			local v134 = p110 * 0.31
			local v135 = math.floor(v134) + v131
			local v136 = v130 - 16 - v135
			local v137 = math.max(120, v136)
			local v138 = v_u_3.label
			local v139 = {
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v113
			}
			local v140 = p_u_109.name
			v139.text = tostring(v140)
			v139.style = v_u_7 and "h2" or "h1"
			v139.position = UDim2.fromOffset(v135, v_u_7 and 14 or 28)
			v139.size = UDim2.fromOffset(v137, v_u_7 and 30 or 40)
			v138(v139)
			local v141 = v_u_7 and 46 or 74
			local v142
			if v_u_7 and v137 < 270 then
				v142 = v137 + 12
			else
				v142 = v137
			end
			local v143 = v_u_3.label
			local v144 = {
				["parent"] = nil,
				["name"] = "Blurb",
				["text"] = nil,
				["style"] = nil,
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v113
			}
			local v145 = p_u_109.blurb or ""
			v144.text = tostring(v145)
			v144.style = v_u_7 and "small" or "body"
			v144.color = v_u_5.text2
			v144.position = UDim2.fromOffset(v135, v141)
			v144.size = UDim2.fromOffset(v142, v_u_7 and 32 or 44)
			v143(v144).TextYAlignment = Enum.TextYAlignment.Top
			local v146 = {}
			for v147 = 2, #(v121 or {}) do
				local v148 = v121[v147]
				table.insert(v146, v148)
			end
			local v149 = v_u_7 and 36 or 48
			local v150 = #v146
			local v151 = v137 - (math.max(1, v150) - 1) * 4
			local v152 = #v146
			local v153 = v151 / math.max(1, v152)
			local v154 = math.floor(v153)
			local v155 = math.min(v149, v154)
			local v156 = #v146
			local v157
			if v155 < 28 then
				v155 = 28
				local v158 = (v137 + 4) / (v155 + 4)
				local v159 = math.floor(v158) - 1
				v156 = math.max(1, v159)
				v157 = #v146 - v156
			else
				v157 = 0
			end
			local v160 = v141 + (v_u_7 and 36 or 50)
			local v161 = v_u_3.new("Frame", {
				["Name"] = "Contents",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(v135, v160),
				["Size"] = UDim2.fromOffset(v137, v155 + 14)
			}, v113)
			for v162 = 1, v156 do
				local v163 = v146[v162]
				local v164 = (v162 - 1) * (v155 + 4)
				local v165 = p_u_2.itemIcon and p_u_2.itemIcon(v161, v163, v155, UDim2.fromOffset(v164, 0), nil, false)
				if v165 then
					local v166 = v163.id
					v165.Name = "Content_" .. tostring(v166)
				end
				local v167 = v163.n
				if (tonumber(v167) or 1) <= 1 then
					continue
				end
				local v168 = v_u_3.label
				local v169 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "center",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v161
				}
				local v170 = v163.n
				v169.text = "x" .. tostring(v170)
				v169.color = v_u_5.text
				v169.position = UDim2.fromOffset(v164 - 2, v155 + 1)
				v169.size = UDim2.fromOffset(v155 + 4, 12)
				v168(v169)
			end
			if v157 > 0 then
				local v171 = v_u_3.label
				local v172 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v161,
					["text"] = "+" .. tostring(v157),
					["color"] = v_u_5.text2
				}
				local v173 = UDim2.fromOffset
				local v174 = v156 * (v155 + 4)
				local v175 = v155 / 2
				v172.position = v173(v174, math.floor(v175) - 8)
				v172.size = UDim2.fromOffset(v155, 16)
				v171(v172)
			end
			v_u_3.label({
				["parent"] = nil,
				["name"] = "LostNote",
				["text"] = "Can be lost in a raid like any other gear.",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v113,
				["color"] = v_u_5.muted,
				["position"] = UDim2.fromOffset(v135, v160 + v155 + 16),
				["size"] = UDim2.fromOffset(v137, 14)
			})
			if p_u_109.giftable == true and p_u_2.gift then
				local v176 = v112 - 40
				local v177 = v160 + v155 + 34
				local v178 = math.max(v176, v177)
				v_u_3.button({
					["parent"] = nil,
					["name"] = "GiftButton",
					["text"] = "Gift",
					["kind"] = "ghost",
					["icon"] = "heart",
					["height"] = 28,
					["width"] = 96,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v113,
					["position"] = UDim2.fromOffset(v135, v178),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_2, (copy) p_u_109
						p_u_2.gift(p_u_109)
					end
				})
				if p_u_109.pack == true and v137 >= 300 then
					v_u_3.label({
						["parent"] = nil,
						["name"] = "GiftNote",
						["text"] = "Gifts may come without crates and keys. The dialog says why.",
						["style"] = "micro",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v113,
						["color"] = v_u_5.muted,
						["position"] = UDim2.fromOffset(v135 + 104, v178),
						["size"] = UDim2.fromOffset(v137 - 104, 28)
					})
				end
			end
			local v179 = p110 - v130 - 16
			local v180 = v_u_3.label({
				["parent"] = nil,
				["name"] = "TimerCaption",
				["text"] = "LIMITED TIME OFFER",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v113,
				["color"] = v_u_5.accent,
				["position"] = UDim2.fromOffset(v130, v_u_7 and 14 or 28),
				["size"] = UDim2.fromOffset(v179, 14)
			})
			local v181 = v_u_9.timerLabel(v113, p_u_109, UDim2.fromOffset(v130, v_u_7 and 32 or 48), UDim2.fromOffset(v179, v_u_7 and 26 or 34), "monoL", v180)
			v181.Name = "Countdown"
			v181.TextXAlignment = Enum.TextXAlignment.Left
			v_u_3.label({
				["parent"] = nil,
				["name"] = "TimerNote",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v113,
				["text"] = v_u_7 and "Gone when the timer ends." or "Gone when the timer ends. The price is shown on the button.",
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(v130, v_u_7 and 62 or 90),
				["size"] = UDim2.fromOffset(v179, v_u_7 and 28 or 30)
			}).TextYAlignment = Enum.TextYAlignment.Top
			local v182 = p_u_109.worthOf
			if type(v182) == "table" and p_u_2.worth then
				local v_u_183 = v_u_3.label({
					["parent"] = nil,
					["name"] = "WorthLine",
					["text"] = "",
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v113,
					["color"] = v_u_5.text2,
					["position"] = UDim2.fromOffset(v130, v_u_7 and 92 or 122),
					["size"] = UDim2.fromOffset(v179, v_u_7 and 28 or (v_u_6 and 34 or 44))
				})
				v_u_183.TextYAlignment = Enum.TextYAlignment.Top
				local function v185() -- name: paintWorth
					-- upvalues: (ref) p_u_2, (copy) p_u_109, (ref) v_u_7, (ref) v_u_6, (copy) v_u_183
					local v184 = p_u_2.worth(p_u_109, v_u_7 or v_u_6)
					v_u_183.Text = v184 or ""
					v_u_183.Visible = v184 ~= nil
				end
				local v186 = p_u_2.worth(p_u_109, v_u_7 or v_u_6)
				v_u_183.Text = v186 or ""
				v_u_183.Visible = v186 ~= nil
				if p_u_2.watchWorth then
					p_u_2.watchWorth(p_u_109, v185)
				end
			end
			p_u_2.buy(v113, p_u_109, true, UDim2.fromOffset(v130, v112 - (v_u_7 and 66 or 76)), Vector2.zero, v179)
			v113.MouseButton1Click:Connect(function()
				-- upvalues: (ref) p_u_2, (copy) p_u_109
				if p_u_2.open then
					p_u_2.open(p_u_109.id)
				end
			end)
			v113.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_114
				v_u_114.Transparency = 0
			end)
			v113.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_114
				v_u_114.Transparency = 0.1
			end)
			v113:SetAttribute("TimerText", v_u_9.text())
			return v113
		end
		function v_u_9.destroy() -- name: destroy
			-- upvalues: (ref) v_u_10, (ref) v_u_16
			v_u_10 = false
			v_u_16 = {}
		end
		return v_u_9
	end
}