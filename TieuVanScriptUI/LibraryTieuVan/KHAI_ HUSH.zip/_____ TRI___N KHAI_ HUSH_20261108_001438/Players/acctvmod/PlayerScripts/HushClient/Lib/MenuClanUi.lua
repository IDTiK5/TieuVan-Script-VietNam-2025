-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanUi

return {
	["new"] = function(p_u_1) -- name: new
		local v_u_2 = p_u_1.ui
		local v_u_3 = p_u_1.theme
		local v_u_4 = v_u_3.color
		local v_u_5 = p_u_1.kit
		local v_u_6 = p_u_1.cctx
		local v_u_7 = {}
		local v_u_8 = nil
		local function v9()
			-- upvalues: (ref) v_u_8, (copy) v_u_6
			v_u_8 = v_u_6.shared.ClanTag
		end
		pcall(v9)
		local v_u_10 = nil
		local function v11()
			-- upvalues: (ref) v_u_10, (copy) v_u_6
			v_u_10 = v_u_6.lib.ServerClock
		end
		pcall(v11)
		local v_u_12 = nil
		local function v13()
			-- upvalues: (ref) v_u_12, (copy) v_u_6
			v_u_12 = v_u_6.shared.ClanStyle
		end
		pcall(v13)
		local v_u_14 = nil
		local function v15()
			-- upvalues: (ref) v_u_14, (copy) v_u_6
			v_u_14 = v_u_6.lib.BusyDots
		end
		pcall(v15)
		v_u_7.busyDots = v_u_14
		function v_u_7.press(p16, p17) -- name: press
			-- upvalues: (copy) p_u_1
			p16.Activated:Connect(p17)
			local v18 = p_u_1.uiHook
			if type(v18) == "function" then
				p_u_1.uiHook(p16, p17)
			end
		end
		function v_u_7.frame(p19, p20, p21, p22, p23) -- name: frame
			-- upvalues: (copy) v_u_2
			local v24 = v_u_2.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Name"] = p20,
				["Size"] = p21
			}, p19)
			if p22 then
				v24.Position = p22
			end
			if p23 then
				v24.LayoutOrder = p23
			end
			return v24
		end
		function v_u_7.btn(p25) -- name: btn
			-- upvalues: (copy) v_u_3, (copy) v_u_2, (ref) v_u_14
			local v26 = v_u_3.touch
			local v27 = p25.height or 44
			local v28 = v26((math.max(44, v27)))
			local v29 = p25.text or ""
			local v_u_30 = tostring(v29)
			local v31, v_u_32 = v_u_2.button({
				["parent"] = p25.parent,
				["text"] = v_u_30,
				["kind"] = p25.kind or "secondary",
				["width"] = p25.width,
				["height"] = v28,
				["maxTextWidth"] = p25.maxTextWidth,
				["onClick"] = p25.onClick,
				["name"] = p25.name,
				["order"] = p25.order,
				["position"] = p25.position,
				["anchor"] = p25.anchor,
				["tooltip"] = p25.tooltip,
				["disabled"] = p25.disabled
			})
			local v_u_33 = false
			local v_u_34 = p25.disabled ~= true
			local v_u_35 = nil
			local v_u_36 = nil
			function v_u_32.busy(p37, p38) -- name: busy
				-- upvalues: (ref) v_u_33, (ref) v_u_14, (copy) v_u_32, (ref) v_u_30, (ref) v_u_35, (ref) v_u_36, (ref) v_u_3, (ref) v_u_34
				v_u_33 = p37
				if p37 and (v_u_14 ~= nil and v_u_32.label ~= nil) then
					local v39 = v_u_14.strip
					if p38 == nil then
						p38 = v_u_30
					end
					local v40 = v39(p38)
					if v_u_35 ~= nil and v_u_36 == v40 then
						v_u_32.setEnabled(false)
						return
					end
					if v_u_35 then
						local v41 = v_u_35
						pcall(v41)
						v_u_35 = nil
					end
					v_u_36 = nil
					v_u_36 = v40
					local v43 = {
						["transform"] = function(p42) -- name: transform
							-- upvalues: (ref) v_u_3
							return v_u_3.track(string.upper(p42), 1)
						end
					}
					v_u_35 = v_u_14.animate(v_u_32.label, v40, v43)
				else
					if v_u_35 then
						local v44 = v_u_35
						pcall(v44)
						v_u_35 = nil
					end
					v_u_36 = nil
					local v45 = v_u_32.setText
					local v46
					if p37 then
						v46 = p38 or v_u_30
					else
						v46 = v_u_30
					end
					v45(v46)
				end
				local v47 = v_u_32.setEnabled
				local v48 = v_u_34
				if v48 then
					v48 = not p37
				end
				v47(v48)
			end
			function v_u_32.enable(p49) -- name: enable
				-- upvalues: (ref) v_u_34, (copy) v_u_32, (ref) v_u_33
				v_u_34 = p49
				local v50 = v_u_32.setEnabled
				if p49 then
					p49 = not v_u_33
				end
				v50(p49)
			end
			function v_u_32.caption(p51) -- name: caption
				-- upvalues: (ref) v_u_30, (ref) v_u_33, (copy) v_u_32
				v_u_30 = p51
				if not v_u_33 then
					v_u_32.setText(p51)
				end
			end
			return v31, v_u_32
		end
		function v_u_7.status(p52, p53) -- name: status
			-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_14
			local v_u_54 = v_u_2.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = nil,
				["wrap"] = nil,
				["valign"] = nil,
				["align"] = nil,
				["size"] = nil,
				["position"] = nil,
				["order"] = nil,
				["visible"] = nil,
				["track"] = false,
				["parent"] = p52,
				["name"] = p53.name or "Status",
				["text"] = p53.text or "",
				["style"] = p53.style or "small",
				["wrap"] = p53.wrap == true,
				["valign"] = p53.valign,
				["align"] = p53.align,
				["size"] = p53.size,
				["position"] = p53.position,
				["order"] = p53.order,
				["visible"] = p53.visible
			})
			local v55 = p53.kind
			local v56
			if v55 == "danger" then
				v56 = v_u_4.danger
			elseif v55 == "warn" then
				v56 = v_u_4.accent
			elseif v55 == "success" then
				v56 = v_u_4.success
			else
				v56 = v_u_4.text2
			end
			v_u_54.TextColor3 = v56
			local v57 = {
				["lbl"] = v_u_54
			}
			local v_u_58 = nil
			local v_u_59 = ""
			function v57.set(p60, p61) -- name: set
				-- upvalues: (ref) v_u_58, (ref) v_u_59, (copy) v_u_54, (ref) v_u_4
				if v_u_58 then
					local v62 = v_u_58
					pcall(v62)
					v_u_58 = nil
				end
				v_u_59 = ""
				v_u_54.Text = p60 or ""
				local v63 = v_u_54
				local v64
				if p61 == "danger" then
					v64 = v_u_4.danger
				elseif p61 == "warn" then
					v64 = v_u_4.accent
				elseif p61 == "success" then
					v64 = v_u_4.success
				else
					v64 = v_u_4.text2
				end
				v63.TextColor3 = v64
				v_u_54.Visible = v_u_54.Text ~= ""
			end
			function v57.setBusy(p65, p66) -- name: setBusy
				-- upvalues: (ref) v_u_58, (ref) v_u_59, (copy) v_u_54, (ref) v_u_4, (ref) v_u_14
				local v67 = tostring(p65) .. "|" .. tostring(p66)
				if v_u_58 == nil or (v67 ~= v_u_59 or v_u_54.Parent == nil) then
					if v_u_58 then
						local v68 = v_u_58
						pcall(v68)
						v_u_58 = nil
					end
					v_u_59 = ""
					local v69 = v_u_54
					local v70
					if p66 == "danger" then
						v70 = v_u_4.danger
					elseif p66 == "warn" then
						v70 = v_u_4.accent
					elseif p66 == "success" then
						v70 = v_u_4.success
					else
						v70 = v_u_4.text2
					end
					v69.TextColor3 = v70
					if v_u_14 == nil then
						v_u_54.Text = tostring(p65 or "")
						v_u_54.Visible = v_u_54.Text ~= ""
					else
						local v71, v72 = v_u_14.split(p65)
						v_u_54.Visible = true
						v_u_58 = v_u_14.animate(v_u_54, v71, {
							["suffix"] = v72
						})
						v_u_59 = v67
					end
				else
					return
				end
			end
			function v57.busy() -- name: busy
				-- upvalues: (ref) v_u_58
				return v_u_58 ~= nil
			end
			return v57
		end
		function v_u_7.row(p73, p74, p75, p76) -- name: row
			-- upvalues: (copy) v_u_2, (copy) v_u_4
			local v77 = v_u_2.new
			local v78 = "Frame"
			local v79 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "R" .. p74
			}
			local v80
			if p76 then
				v80 = v_u_4.accentDeep
			else
				v80 = v_u_4.raised
			end
			v79.BackgroundColor3 = v80
			v79.BackgroundTransparency = p74 % 2 == 0 and 0.5 or 0.3
			v79.Size = UDim2.new(1, -6, 0, p75)
			v79.LayoutOrder = p74
			return v77(v78, v79, p73)
		end
		function v_u_7.chip(p81, p82, p83, p84) -- name: chip
			-- upvalues: (copy) v_u_2
			local v85 = p84 or {}
			v85.parent = p81
			return v_u_2.badge(p82, p83 or "muted", v85)
		end
		function v_u_7.dirStyle(p86) -- name: dirStyle
			-- upvalues: (ref) v_u_12
			if v_u_12 == nil or (type(p86) ~= "string" or (p86 == "" or #p86 > 40)) then
				return nil
			else
				if not string.find(p86, "=", 1, true) then
					p86 = "c=" .. p86
				end
				local v87 = v_u_12.parse
				local v88, v89 = pcall(v87, p86)
				if v88 and type(v89) == "table" then
					return v89
				else
					return nil
				end
			end
		end
		function v_u_7.tagChip(p90, p91, p92, p93) -- name: tagChip
			-- upvalues: (ref) v_u_8, (copy) v_u_7, (ref) v_u_12
			local v94 = type(p91) ~= "string" and "????" or p91
			local v95 = v_u_8 and not v_u_8.valid(v94) and "????" or v94
			local v96
			if type(p93) == "table" and p93.tagStyle ~= nil then
				v96 = p93.tagStyle
				p93 = {}
				for v97, v98 in p93 do
					if v97 == "tagStyle" then
						continue
					end
					p93[v97] = v98
				end
			else
				v96 = nil
			end
			local v99 = "["
			local v100 = "]"
			if type(v96) == "table" then
				local v101 = v96.brackets
				if type(v101) == "table" then
					local v102 = v96.brackets[1]
					if type(v102) == "string" then
						local v103 = v96.brackets[2]
						if type(v103) == "string" then
							v99 = v96.brackets[1]
							v100 = v96.brackets[2]
						end
					end
				end
			end
			local v104 = v_u_7.chip(p90, v99 .. v95 .. v100, "accent", p93)
			if v96 ~= nil and v_u_12 ~= nil then
				local v105 = v_u_12.color3
				local v106, v107 = pcall(v105, v96)
				if v106 and typeof(v107) == "Color3" then
					local v108 = v104:FindFirstChildWhichIsA("TextLabel")
					if v108 then
						v108.TextColor3 = v107
					end
					return v104
				end
			end
			if v_u_8 then
				local v109 = v_u_8.color
				if type(v109) == "function" then
					local v110 = v_u_8.color
					local v111, v112 = pcall(v110, p92, 0.55, 0.95)
					local v113 = v111 and typeof(v112) == "Color3" and v104:FindFirstChildWhichIsA("TextLabel")
					if v113 then
						v113.TextColor3 = v112
					end
				end
			end
			return v104
		end
		function v_u_7.empty(p114, p115, p116) -- name: empty
			-- upvalues: (copy) v_u_5
			return v_u_5.empty(p114, p115, p116)
		end
		function v_u_7.section(p117, p118, p119, p120) -- name: section
			-- upvalues: (copy) v_u_5
			return v_u_5.section(p117, p118, p119, p120)
		end
		function v_u_7.skeleton(p121, p122, p123) -- name: skeleton
			-- upvalues: (copy) v_u_2, (copy) v_u_4
			for v124 = 1, p122 do
				v_u_2.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.6,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Skeleton" .. v124,
					["BackgroundColor3"] = v_u_4.raised,
					["Size"] = UDim2.new(1, -6, 0, p123),
					["LayoutOrder"] = v124
				}, p121)
			end
		end
		function v_u_7.label(p125, p126) -- name: label
			-- upvalues: (ref) v_u_8
			if v_u_8 then
				local v127 = v_u_8.label
				if type(v127) == "function" then
					local v128 = v_u_8.label
					local v129, v130 = pcall(v128, p125, p126)
					if v129 and type(v130) == "string" then
						return v130
					end
				end
			end
			return ("[%s] %s"):format(tostring(p125), (tostring(p126)))
		end
		function v_u_7.cosName(p_u_131) -- name: cosName
			-- upvalues: (copy) v_u_6
			local function v132()
				-- upvalues: (ref) v_u_6, (copy) p_u_131
				return v_u_6.shared.KillCardCosmetics.byId(p_u_131)
			end
			local v133, v_u_134 = pcall(v132)
			if v133 and type(v_u_134) == "table" then
				local function v135()
					-- upvalues: (ref) v_u_6, (copy) v_u_134
					return v_u_6.lib.MenuClanModel.cosText(v_u_134)
				end
				local v136, v137 = pcall(v135)
				if v136 then
					return v137
				else
					return nil
				end
			else
				return nil
			end
		end
		function v_u_7.left(p138) -- name: left
			-- upvalues: (ref) v_u_10
			local v139 = tonumber(p138)
			if v139 == nil then
				return 0
			end
			if v_u_10 then
				local v140 = v_u_10.left
				if type(v140) == "function" then
					local v141 = v_u_10.left
					local v142, v143 = pcall(v141, v139)
					if v142 and type(v143) == "number" then
						return v143
					end
				end
			end
			local v144 = v139 - os.time()
			return math.max(0, v144)
		end
		function v_u_7.now() -- name: now
			-- upvalues: (ref) v_u_10
			if v_u_10 then
				local v145 = v_u_10.now
				if type(v145) == "function" then
					local v146 = v_u_10.now
					local v147, v148 = pcall(v146)
					if v147 and type(v148) == "number" then
						return v148
					end
				end
			end
			return os.time()
		end
		function v_u_7.confirm(p_u_149) -- name: confirm
			-- upvalues: (copy) v_u_2
			local v150 = v_u_2.modal
			local v151 = {
				["title"] = p_u_149.title,
				["body"] = p_u_149.body,
				["width"] = p_u_149.width or 460,
				["kind"] = p_u_149.danger and "danger" or nil,
				["buttons"] = {
					{
						["text"] = p_u_149.yes or "CONFIRM",
						["kind"] = p_u_149.danger and "danger" or "primary",
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) p_u_149
							if p_u_149.onYes then
								p_u_149.onYes()
							end
						end
					},
					{
						["text"] = nil,
						["kind"] = "secondary",
						["text"] = p_u_149.no or "CANCEL"
					}
				}
			}
			return v150(v151)
		end
		function v_u_7.typeConfirm(p_u_152) -- name: typeConfirm
			-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
			local v153 = string.upper
			local v154 = p_u_152.expect or ""
			local v_u_155 = v153((tostring(v154)))
			local v_u_156 = nil
			local v_u_157 = nil
			local v158 = v_u_2.modal
			local v161 = {
				["title"] = nil,
				["body"] = nil,
				["width"] = nil,
				["kind"] = "danger",
				["build"] = nil,
				["buttons"] = nil,
				["title"] = p_u_152.title,
				["body"] = p_u_152.body,
				["width"] = p_u_152.width or 460,
				["build"] = function(p159) -- name: build
					-- upvalues: (ref) v_u_2, (copy) p_u_152, (ref) v_u_3, (ref) v_u_156, (ref) v_u_157, (ref) v_u_4
					local _, v160 = v_u_2.input({
						["parent"] = nil,
						["name"] = "Confirm",
						["placeholder"] = nil,
						["maxLength"] = 24,
						["size"] = nil,
						["parent"] = p159,
						["placeholder"] = p_u_152.placeholder or "Type the tag",
						["size"] = UDim2.new(1, 0, 0, v_u_3.touch(44))
					})
					v_u_156 = v160
					v_u_157 = v_u_2.label({
						["parent"] = nil,
						["name"] = "Hint",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = p159,
						["color"] = v_u_4.danger,
						["size"] = UDim2.new(1, 0, 0, 20)
					})
				end,
				["buttons"] = {
					{
						["text"] = nil,
						["kind"] = "danger",
						["onClick"] = nil,
						["text"] = p_u_152.yes or "CONFIRM",
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_156, (copy) v_u_155, (ref) v_u_157, (copy) p_u_152
							if string.upper((string.gsub(not v_u_156 and "" or v_u_156.Text, "%s", ""))) == v_u_155 then
								if p_u_152.onYes then
									p_u_152.onYes()
								end
								return false
							else
								if v_u_157 then
									v_u_157.Text = p_u_152.mismatch or "That does not match."
								end
								return true
							end
						end
					},
					{
						["text"] = nil,
						["kind"] = "secondary",
						["text"] = p_u_152.no or "CANCEL"
					}
				}
			}
			return v158(v161)
		end
		local v_u_162 = nil
		local function v163()
			-- upvalues: (ref) v_u_162, (copy) v_u_6
			v_u_162 = v_u_6.lib.MenuClanLook
		end
		pcall(v163)
		v_u_7.look = v_u_162
		function v_u_7.card(p164, p165, p166, p167) -- name: card
			-- upvalues: (copy) v_u_2, (copy) v_u_4
			local v168 = p167 or {}
			local v169 = v_u_2.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["ClipsDescendants"] = true,
				["Name"] = p165,
				["BackgroundColor3"] = v168.fill or v_u_4.raised,
				["BackgroundTransparency"] = v168.transparency or 0.25,
				["LayoutOrder"] = v168.order or 0
			}, p164)
			if p166 then
				v169.Position = UDim2.fromOffset(p166.x, p166.y)
				v169.Size = UDim2.fromOffset(p166.w, p166.h)
			end
			v_u_2.corner(v169, v168.radius or 6)
			v_u_2.stroke(v169, v168.stroke or v_u_4.line, 1, v168.strokeTransparency or 0.15)
			return v169
		end
		local v_u_170 = nil
		local function v171()
			-- upvalues: (ref) v_u_170, (copy) v_u_6
			v_u_170 = v_u_6.lib.TextFitting
		end
		pcall(v171)
		function v_u_7.fitLine(p172, p173, p174) -- name: fitLine
			-- upvalues: (ref) v_u_170
			if v_u_170 ~= nil then
				local v175 = v_u_170.fit
				if type(v175) == "function" and (p172 ~= nil and p172:IsA("TextLabel")) then
					local v176 = v_u_170.fit
					pcall(v176, p172, p173, p174 or 9)
				end
			end
		end
		function v_u_7.text(p177, p178, p179, p180, p181) -- name: text
			-- upvalues: (copy) v_u_2
			local v182 = p181 or {}
			return v_u_2.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = nil,
				["color"] = nil,
				["align"] = nil,
				["valign"] = nil,
				["wrap"] = nil,
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["parent"] = p177,
				["name"] = p178,
				["text"] = p179,
				["style"] = v182.style or "body",
				["color"] = v182.color,
				["align"] = v182.align,
				["valign"] = v182.valign,
				["wrap"] = v182.wrap,
				["size"] = UDim2.fromOffset(p180.w, p180.h),
				["position"] = UDim2.fromOffset(p180.x, p180.y)
			})
		end
		function v_u_7.pill(p183, p184, p185, p186, p187, p188) -- name: pill
			-- upvalues: (copy) v_u_2, (copy) v_u_4
			local v189 = p188 or {}
			local v190 = v_u_2.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Name"] = p184,
				["BackgroundColor3"] = v189.fill or v_u_4.bg,
				["BackgroundTransparency"] = v189.fillTransparency or 0.15
			}, p183)
			if p187 then
				v190.Position = UDim2.fromOffset(p187.x, p187.y)
				v190.Size = UDim2.fromOffset(p187.w, p187.h)
			end
			v_u_2.corner(v190, 4)
			v_u_2.stroke(v190, p186, 1, 0.3)
			v_u_2.label({
				["parent"] = nil,
				["name"] = "Label",
				["text"] = nil,
				["style"] = nil,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v190,
				["text"] = p185,
				["style"] = v189.style or "micro",
				["color"] = p186,
				["size"] = UDim2.fromScale(1, 1)
			})
			return v190
		end
		function v_u_7.avatar(p191, p192, p193, p194, p195, p196) -- name: avatar
			-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_162
			local v197 = p196 or {}
			local v198 = v_u_2.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Name"] = p192,
				["BackgroundColor3"] = v_u_4.raised2 or v_u_4.raised
			}, p191)
			if p195 then
				v198.Position = UDim2.fromOffset(p195.x, p195.y)
				v198.Size = UDim2.fromOffset(p195.w, p195.h)
			end
			local v199 = v_u_2.corner
			local v200 = p195.w / 2
			v199(v198, (math.floor(v200)))
			local v201
			if v_u_162 then
				local v202 = v_u_162.headshotUrl
				if type(v202) == "function" then
					v201 = v_u_162.headshotUrl(p193, 150)
				else
					v201 = nil
				end
			else
				v201 = nil
			end
			if v201 then
				local v203 = v_u_2.new("ImageLabel", {
					["Name"] = "Shot",
					["Image"] = nil,
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["ScaleType"] = nil,
					["Image"] = v201,
					["Size"] = UDim2.fromScale(1, 1),
					["ScaleType"] = Enum.ScaleType.Crop
				}, v198)
				local v204 = v_u_2.corner
				local v205 = p195.w / 2
				v204(v203, (math.floor(v205)))
			else
				local v206
				if v_u_162 then
					local v207 = v_u_162.glyph
					v206 = type(v207) ~= "function" and "?" or v_u_162.glyph(p194)
				else
					v206 = "?"
				end
				v_u_2.label({
					["parent"] = nil,
					["name"] = "Glyph",
					["text"] = nil,
					["style"] = nil,
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["track"] = false,
					["parent"] = v198,
					["text"] = v206,
					["style"] = v197.glyphStyle or "bodyStrong",
					["color"] = v_u_4.text2,
					["size"] = UDim2.fromScale(1, 1)
				})
			end
			if v197.ring then
				v_u_2.stroke(v198, v197.ring, 2, 0.1)
			end
			if v197.dot then
				local v208 = p195.w * 0.26
				local v209 = math.floor(v208)
				local v210 = math.max(8, v209)
				local v211 = v_u_2.new("Frame", {
					["Name"] = "Dot",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 3,
					["BackgroundColor3"] = v197.dot,
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(1, 2, 1, 2),
					["Size"] = UDim2.fromOffset(v210, v210)
				}, v198)
				v_u_2.corner(v211, v210)
				v_u_2.stroke(v211, v_u_4.bgDeep or v_u_4.bg, 2, 0)
			end
			v198.ClipsDescendants = false
			return v198
		end
		return v_u_7
	end
}