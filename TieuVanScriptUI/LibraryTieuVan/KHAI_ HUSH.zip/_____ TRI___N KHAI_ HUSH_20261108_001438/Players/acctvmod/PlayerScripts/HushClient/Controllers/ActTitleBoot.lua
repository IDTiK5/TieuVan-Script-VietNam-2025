-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / ActTitleBoot

local v_u_1 = {
	["name"] = "ActTitleBoot",
	["order"] = 96,
	["POLL"] = 0.5,
	["RETRY_SECONDS"] = 90
}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = 0
local v_u_6 = ""
local v_u_7 = 0
function v_u_1.init(p_u_8) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_2
	v_u_3 = p_u_8
	local function v9()
		-- upvalues: (ref) v_u_4, (copy) p_u_8
		v_u_4 = p_u_8.lib.ActTitleCard
		v_u_4.init(p_u_8)
	end
	local v10, v11 = pcall(v9)
	if not v10 then
		v_u_4 = nil
		warn("[ActTitleBoot] the title card failed to start:", v11)
		v_u_2:SetAttribute("ClientError", "acttitle: " .. tostring(v11))
	end
end
function v_u_1.step(p12) -- name: step
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_1, (copy) v_u_2, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3
	if v_u_4 == nil then
		return
	else
		v_u_5 = v_u_5 + p12
		if v_u_5 < v_u_1.POLL then
			return
		else
			local v13 = v_u_5
			v_u_5 = 0
			local v14 = v_u_2:GetAttribute("RaidId") or ""
			local v15 = tostring(v14)
			if v15 == "" then
				v_u_6 = ""
				v_u_7 = 0
				if v_u_4.active() then
					v_u_4.stop()
				end
				return
			elseif v15 == v_u_6 then
				return
			else
				local v_u_16 = false
				local function v17()
					-- upvalues: (ref) v_u_16, (ref) v_u_3
					v_u_16 = v_u_3.runtime:GetAttribute("MapId") == "tokyo"
				end
				pcall(v17)
				if v_u_16 then
					v_u_7 = v_u_7 + v13
					local v18 = v_u_4.maybePlay
					local v19, v20, v21 = pcall(v18)
					if not v19 or (v20 or v21 ~= "entry" and v21 ~= "busy") or v_u_7 >= v_u_1.RETRY_SECONDS then
						v_u_6 = v15
						v_u_7 = 0
					end
				else
					return
				end
			end
		end
	end
end
return v_u_1