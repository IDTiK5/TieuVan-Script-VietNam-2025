-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutRecipe

local v_u_1 = game:GetService("Players")
local v2 = {}
local v_u_3 = {
	["mat_scrap"] = "Trash, cabinets, crates, toolboxes",
	["mat_cloth"] = "Trash, cabinets, desks",
	["mat_screws"] = "Toolboxes, crates, cabinets",
	["mat_tape"] = "Toolboxes, crates, car trunks",
	["mat_wires"] = "Toolboxes, desks, crates",
	["mat_electronics"] = "Desks, offices, shops",
	["mat_chemicals"] = "Toolboxes, fridges, the hospital",
	["mat_toolkit"] = "Toolboxes, car trunks (rare)",
	["mat_carbattery"] = "Car trunks, toolboxes (rare)",
	["mat_fuelcan"] = "Car trunks, the gas station",
	["med_bandage"] = "Medicine cabinets, bodies, cabinets",
	["med_painkillers"] = "Medicine cabinets, bodies",
	["med_medkit"] = "Medicine cabinets, the hospital, supply drops",
	["quest_bloodbag"] = "The hospital, medicine cabinets",
	["val_laptop"] = "Desks, offices, safes",
	["val_bourbon"] = "Cabinets, desks, safes",
	["throw_bottle"] = "Trash, cabinets, crates"
}
function v2.new(p_u_4) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_5 = p_u_4.HushUI
	local v_u_6 = p_u_4.Theme
	local v_u_7 = v_u_6.color
	local v_u_8 = v_u_1.LocalPlayer
	local v_u_9 = {}
	local v_u_10 = {}
	local v_u_11 = nil
	local v_u_12 = false
	local function v_u_17() -- name: icons
		-- upvalues: (ref) v_u_12, (copy) p_u_4, (ref) v_u_11
		if not v_u_12 then
			v_u_12 = true
			local function v13()
				-- upvalues: (ref) p_u_4
				return p_u_4.cctx.lib.ItemIcons
			end
			local v14, v15 = pcall(v13)
			if v14 and type(v15) == "table" then
				local v16 = v15.get
				if type(v16) == "function" then
					v_u_11 = v15
				end
			end
		end
		return v_u_11
	end
	function v_u_9.def(p18) -- name: def
		-- upvalues: (copy) p_u_4
		local v19 = p_u_4.Items
		if not v19 then
			local v_u_20 = "Items"
			local function v21()
				-- upvalues: (ref) p_u_4, (copy) v_u_20
				return p_u_4.cctx.shared[v_u_20]
			end
			local v22
			v22, v19 = pcall(v21)
			if not v22 or type(v19) ~= "table" then
				v19 = nil
			end
		end
		if v19 and v19.get then
			local v23 = v19.get
			local v24, v25 = pcall(v23, p18)
			if v24 and type(v25) == "table" then
				return v25
			end
		end
		return nil
	end
	function v_u_9.name(p26) -- name: name
		-- upvalues: (copy) p_u_4
		local v27 = p_u_4.Items
		if not v27 then
			local v_u_28 = "Items"
			local function v29()
				-- upvalues: (ref) p_u_4, (copy) v_u_28
				return p_u_4.cctx.shared[v_u_28]
			end
			local v30
			v30, v27 = pcall(v29)
			if not v30 or type(v27) ~= "table" then
				v27 = nil
			end
		end
		local v31
		if v27 and v27.get then
			local v32 = v27.get
			local v33
			v33, v31 = pcall(v32, p26)
			if not v33 or type(v31) ~= "table" then
				v31 = nil
			end
		else
			v31 = nil
		end
		if v31 then
			local v34 = v31.name
			if type(v34) == "string" then
				return v31.name
			end
		end
		local v35 = string.gsub(p26, "_", " ")
		return string.upper((string.sub(v35, 1, 1))) .. string.sub(v35, 2)
	end
	function v_u_9.have(p36) -- name: have
		-- upvalues: (copy) p_u_4
		local v37 = p_u_4.view
		local v38, v39 = pcall(v37)
		if not v38 or type(v39) ~= "table" then
			v39 = nil
		end
		if v39 then
			local v40 = v39.stock
			if type(v40) == "table" then
				local v41 = v39.stock[p36]
				return tonumber(v41) or 0
			end
		end
		return 0
	end
	function v_u_9.hasStock() -- name: hasStock
		-- upvalues: (copy) p_u_4
		local v42 = p_u_4.view
		local v43, v44 = pcall(v42)
		if not v43 or type(v44) ~= "table" then
			v44 = nil
		end
		local v45
		if v44 == nil then
			v45 = false
		else
			local v46 = v44.stock
			v45 = type(v46) == "table"
		end
		return v45
	end
	function v_u_9.seen(p47) -- name: seen
		-- upvalues: (copy) p_u_4, (copy) v_u_9
		local v48 = p_u_4.view
		local v49, v50 = pcall(v48)
		if not v49 or type(v50) ~= "table" then
			v50 = nil
		end
		if v50 then
			local v51 = v50.seen
			if type(v51) == "table" then
				return v50.seen[p47] == true and true or v_u_9.have(p47) > 0
			end
		end
		return true
	end
	function v_u_9.where(p52) -- name: where
		-- upvalues: (copy) p_u_4, (ref) v_u_3
		local v53 = {}
		local v_u_54 = "Factions"
		local function v55()
			-- upvalues: (ref) p_u_4, (copy) v_u_54
			return p_u_4.cctx.shared[v_u_54]
		end
		local v56, v57 = pcall(v55)
		if not v56 or type(v57) ~= "table" then
			v57 = nil
		end
		if v57 then
			local v58 = v57.defs
			if type(v58) == "table" then
				for _, v59 in v57.defs do
					if v59.material ~= p52 then
						continue
					end
					local v60 = v59.name
					local v61 = tostring(v60)
					table.insert(v53, ("Weekly faction rewards only (%s)"):format(v61))
				end
			end
		end
		local v_u_62 = "Traders"
		local function v63()
			-- upvalues: (ref) p_u_4, (copy) v_u_62
			return p_u_4.cctx.shared[v_u_62]
		end
		local v64, v65 = pcall(v63)
		if not v64 or type(v65) ~= "table" then
			v65 = nil
		end
		if v65 then
			local v66 = v65.ORDER
			if type(v66) == "table" and v65.get then
				for _, v67 in v65.ORDER do
					local v68 = v65.get(v67)
					for _, v69 in v68 and (v68.offers or {}) or {} do
						if v69.id ~= p52 then
							continue
						end
						local v70 = v68.name
						local v71 = tostring(v70)
						local v72 = v69.lvl
						local v73 = tonumber(v72) or 1
						table.insert(v53, ("%s sells it (trader level %d)"):format(v71, v73))
					end
				end
			end
		end
		if v_u_3[p52] then
			local v74 = v_u_3[p52]
			table.insert(v53, v74)
		end
		return v53
	end
	local v_u_75 = {}
	local v_u_76 = false
	local v_u_77 = setmetatable({}, {
		["__mode"] = "k"
	})
	function v_u_9.wished(p78) -- name: wished
		-- upvalues: (copy) v_u_75, (copy) v_u_8
		local v79 = v_u_75[p78]
		if v79 and os.clock() - v79.t < 4 then
			return v79.on
		end
		local v80 = v_u_8:GetAttribute("Wishlist")
		if type(v80) ~= "string" or v80 == "" then
			return false
		end
		for _, v81 in string.split(v80, ",") do
			if v81 ~= p78 then
				continue
			end
			return true
		end
		return false
	end
	local function v_u_84() -- name: paintAll
		-- upvalues: (copy) v_u_77
		for v82, v83 in v_u_77 do
			if not v82.Parent then
				continue
			end
			pcall(v83)
		end
	end
	local v85 = v_u_8:GetAttributeChangedSignal("Wishlist")
	table.insert(v_u_10, v85:Connect(v_u_84))
	function v_u_9.toggleWish(p86) -- name: toggleWish
		-- upvalues: (copy) v_u_9, (copy) v_u_75, (copy) p_u_4, (copy) v_u_5, (ref) v_u_76, (copy) v_u_77, (copy) v_u_84
		local v87 = not v_u_9.wished(p86)
		v_u_75[p86] = {
			["on"] = v87,
			["t"] = os.clock()
		}
		if p_u_4.act then
			p_u_4.act("wish", {
				["id"] = p86,
				["on"] = v87
			})
		end
		local v88 = v_u_5.sound
		pcall(v88, v87 and "confirm" or "click")
		if v87 and (v_u_5.device() == "Touch" or not v_u_76) then
			v_u_76 = true
			local v89, v90 = pcall(function()
				return require(game:GetService("ReplicatedStorage").Hush.Shared.HideoutWhy)
			end)
			if v89 and type(v90) == "table" then
				local v91 = v_u_5.toast
				local v92 = v90.WISH_TOAST_TITLE
				local v93 = v90.WISH_TOAST_BODY
				pcall(v91, v92, "info", v93)
			end
		end
		for v94, v95 in v_u_77 do
			if not v94.Parent then
				continue
			end
			pcall(v95)
		end
		task.delay(4.2, v_u_84)
	end
	function v_u_9.chip(p96, p97, p98) -- name: chip
		-- upvalues: (copy) v_u_7, (copy) v_u_5
		local v99 = p98 or {}
		local v100 = v99.color or v_u_7.text2
		local v101 = v99.height or 22
		local v102 = v_u_5.new
		local v103 = "Frame"
		local v104 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = v99.name or "Chip"
		}
		local v105
		if v99.fill then
			v105 = v100
		else
			v105 = v_u_7.bg
		end
		v104.BackgroundColor3 = v105
		v104.BackgroundTransparency = v99.fill and 0.82 or 0.25
		v104.Size = UDim2.fromOffset(0, v101)
		v104.AutomaticSize = Enum.AutomaticSize.X
		v104.LayoutOrder = v99.order or 0
		local v106 = v102(v103, v104)
		v_u_5.stroke(v106, v100, 1, 0.35)
		v_u_5.pad(v106, {
			8,
			8,
			0,
			0
		})
		v_u_5.layout(v106, "h", 6, "center")
		local v107 = v106:FindFirstChildOfClass("UIListLayout")
		if v107 then
			v107.VerticalAlignment = Enum.VerticalAlignment.Center
		end
		if v99.icon then
			local v108 = v_u_5.icon
			local v109 = v99.icon
			local v110 = {
				["parent"] = v106
			}
			local v111 = v101 - 8
			v110.size = math.min(14, v111)
			v110.color = v100
			v108(v109, v110).LayoutOrder = 1
		end
		v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["track"] = nil,
			["parent"] = v106,
			["text"] = p97,
			["style"] = v99.style or "micro",
			["color"] = v100,
			["size"] = UDim2.fromOffset(0, v101),
			["track"] = v99.track
		}).LayoutOrder = 2
		if p96 then
			v106.Parent = p96
		end
		return v106
	end
	function v_u_9.arrow(p112, p113, p114) -- name: arrow
		-- upvalues: (copy) v_u_5, (copy) v_u_7
		local v115 = v_u_5.new("Frame", {
			["Name"] = "Arrow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.fromOffset(28, p114 or 56),
			["LayoutOrder"] = p113 or 0
		})
		v_u_5.new("Frame", {
			["Name"] = "Shaft",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.text2,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 4, 0.5, 0),
			["Size"] = UDim2.fromOffset(20, 2)
		}, v115)
		for v116, v117 in { -45, 45 } do
			v_u_5.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["Name"] = "Head" .. v116,
				["BackgroundColor3"] = v_u_7.text2,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0, 7.5, 0.5, v117 < 0 and -3.5 or 3.5),
				["Size"] = UDim2.fromOffset(10, 2),
				["Rotation"] = v117
			}, v115)
		end
		if p112 then
			v115.Parent = p112
		end
		return v115
	end
	function v_u_9.cashChip(p118, p119, p_u_120, p121, p122) -- name: cashChip
		-- upvalues: (copy) v_u_5, (copy) v_u_7
		local v123 = p122 or 64
		local v_u_124
		if p_u_120 == nil then
			v_u_124 = false
		else
			v_u_124 = p_u_120 > 0
		end
		local v125 = v_u_5.commas
		local v126 = p119 + 0.5
		local v127 = math.floor(v126)
		local v128 = "$" .. v125((math.max(0, v127)))
		local v129 = #v128 * 11 + 44
		local v130 = math.max(112, v129)
		local v131 = v_u_5.new("Frame", {
			["Name"] = "Cash",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_7.raised,
			["Size"] = UDim2.fromOffset(v130, v123),
			["LayoutOrder"] = p121 or 0
		})
		local v132 = v_u_5.stroke
		local v133
		if v_u_124 then
			v133 = v_u_7.danger
		else
			v133 = v_u_7.line
		end
		v132(v131, v133)
		local v134 = v123 / 2
		local v135 = math.floor(v134)
		local v136 = v_u_5.icon
		local v137 = "cash"
		local v138 = {
			["parent"] = nil,
			["size"] = 16,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v131
		}
		local v139
		if v_u_124 then
			v139 = v_u_7.danger
		else
			v139 = v_u_7.accent
		end
		v138.color = v139
		v138.position = UDim2.fromOffset(12, v135 - 10)
		v138.anchor = Vector2.new(0, 0.5)
		v136(v137, v138)
		local v140 = v_u_5.label
		local v141 = {
			["parent"] = nil,
			["name"] = "Amount",
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v131,
			["text"] = v128
		}
		local v142
		if v_u_124 then
			v142 = v_u_7.danger
		else
			v142 = v_u_7.text
		end
		v141.color = v142
		v141.size = UDim2.new(1, -44, 0, 22)
		v141.position = UDim2.fromOffset(34, v135 - 21)
		v140(v141)
		local v143 = v_u_5.label
		local v144 = {
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["fit"] = true,
			["parent"] = v131
		}
		local v145
		if v_u_124 then
			local v146 = v_u_5.commas
			local v147 = p_u_120 + 0.5
			local v148 = math.floor(v147)
			v145 = ("$" .. v146((math.max(0, v148)))) .. " SHORT"
		else
			v145 = "CASH"
		end
		v144.text = v145
		local v149
		if v_u_124 then
			v149 = v_u_7.danger
		else
			v149 = v_u_7.muted
		end
		v144.color = v149
		v144.size = UDim2.new(1, -24, 0, 14)
		v144.position = UDim2.fromOffset(12, v135 + 4)
		v143(v144)
		v_u_5.tooltip(v131, function()
			-- upvalues: (copy) v_u_124, (ref) v_u_5, (copy) p_u_120
			local v150 = {
				["title"] = "CASH",
				["body"] = nil
			}
			local v151
			if v_u_124 then
				local v152 = p_u_120
				local v153 = v_u_5.commas
				local v154 = v152 + 0.5
				local v155 = math.floor(v154)
				v151 = ("You are %s short. Sell loot to the traders to raise it."):format("$" .. v153((math.max(0, v155))))
			else
				v151 = "Paid when the build starts."
			end
			v150.body = v151
			return v150
		end)
		if p118 then
			v131.Parent = p118
		end
		return v131
	end
	function v_u_9.stat(p156, p157) -- name: stat
		-- upvalues: (copy) v_u_5, (copy) v_u_7
		local v158 = v_u_5.new
		local v159 = "Frame"
		local v160 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil
		}
		local v161 = p157.name
		if not v161 then
			local v162 = p157.label
			v161 = "Stat_" .. tostring(v162)
		end
		v160.Name = v161
		v160.BackgroundColor3 = v_u_7.raised
		v160.Size = p157.size or UDim2.new(0.5, -4, 0, 0)
		v160.AutomaticSize = Enum.AutomaticSize.Y
		v160.LayoutOrder = p157.order or 0
		local v163 = v158(v159, v160)
		v_u_5.stroke(v163, v_u_7.line)
		v_u_5.pad(v163, {
			12,
			12,
			10,
			10
		})
		v_u_5.layout(v163, "v", 2)
		v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v163,
			["text"] = p157.label,
			["color"] = v_u_7.text2,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Value",
			["text"] = nil,
			["style"] = "monoL",
			["color"] = nil,
			["order"] = 2,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v163,
			["text"] = p157.value,
			["color"] = p157.color or v_u_7.text,
			["size"] = UDim2.new(1, 0, 0, 28)
		})
		if p157.sub and p157.sub ~= "" then
			v_u_5.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["track"] = false,
				["parent"] = v163,
				["text"] = p157.sub,
				["color"] = v_u_7.muted
			})
		end
		if p156 then
			v163.Parent = p156
		end
		return v163
	end
	function v_u_9.section(p164, p165, p166, p167) -- name: section
		-- upvalues: (copy) v_u_5, (copy) v_u_7
		local v168 = v_u_5.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Section_" .. p166,
			["Size"] = UDim2.new(1, -8, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p166
		})
		v_u_5.layout(v168, "v", 8)
		local v169 = v_u_5.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Size"] = UDim2.new(1, 0, 0, 22)
		}, v168)
		v_u_5.new("Frame", {
			["Name"] = "Tick",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.accent,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 0, 0.5, 0),
			["Size"] = UDim2.fromOffset(3, 12)
		}, v169)
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v169,
			["text"] = p165,
			["color"] = v_u_7.text2,
			["position"] = UDim2.fromOffset(12, 0),
			["size"] = UDim2.new(p167 and 0.55 or 1, -12, 1, 0)
		})
		if p167 then
			v_u_5.label({
				["parent"] = nil,
				["name"] = "Right",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v169,
				["text"] = p167,
				["color"] = v_u_7.muted,
				["position"] = UDim2.fromScale(0.55, 0),
				["size"] = UDim2.new(0.45, 0, 1, 0)
			})
		end
		v_u_5.divider({
			["parent"] = nil,
			["order"] = 1,
			["parent"] = v168
		})
		v168.Parent = p164
		return v168
	end
	local function v_u_173(p170, p171) -- name: glyphOf
		local v172 = p171 and p171.category or ""
		return (string.find(v172, "fire") or (string.find(p170, "^pistol_") or (string.find(p170, "^rifle_") or (string.find(p170, "^smg_") or (string.find(p170, "^shotgun_") or (string.find(p170, "^revolver_") or string.find(p170, "^melee_"))))))) and "weapon" or (string.find(p170, "^ammo_") and "ammo" or ((string.find(p170, "^med_") or (string.find(p170, "^vest_") or string.find(p170, "^helmet_"))) and "health" or (string.find(p170, "^key") and "door" or (string.find(p170, "^val_") and "cash" or ((string.find(p170, "^tape_") or string.find(p170, "^quest_")) and "task" or (string.find(p170, "^zombie_") and "skull" or (string.find(p170, "^throw_flare") and "flare" or "loot")))))))
	end
	local v_u_174 = Color3.fromRGB(58, 68, 80)
	function v_u_9.cell(p175, p_u_176, p177) -- name: cell
		-- upvalues: (copy) v_u_6, (copy) p_u_4, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_174, (copy) v_u_17, (copy) v_u_173, (copy) v_u_77
		local v_u_178 = p177 or {}
		local v179 = v_u_178.size or 56
		if v_u_6.isPhone and v_u_6.isPhone() then
			v179 = v_u_6.touch(v179)
		end
		local v180 = v179 * (v_u_178.w or 1)
		local v181 = math.floor(v180)
		local v182 = p_u_4.Items
		if not v182 then
			local v_u_183 = "Items"
			local function v184()
				-- upvalues: (ref) p_u_4, (copy) v_u_183
				return p_u_4.cctx.shared[v_u_183]
			end
			local v185
			v185, v182 = pcall(v184)
			if not v185 or type(v182) ~= "table" then
				v182 = nil
			end
		end
		local v_u_186
		if v182 and v182.get then
			local v187 = v182.get
			local v188
			v188, v_u_186 = pcall(v187, p_u_176)
			if not v188 or type(v_u_186) ~= "table" then
				v_u_186 = nil
			end
		else
			v_u_186 = nil
		end
		local v189 = v_u_178.name or ""
		local v190 = tostring(v189)
		local v191 = (v_u_178.output == true or (string.sub(v190, 1, 4) == "Out_" or string.sub(v190, 1, 7) == "Unlock_")) and true or string.sub(v190, 1, 4) == "New_"
		local v_u_192 = v_u_178.known == true and true or (v191 or v_u_9.seen(p_u_176))
		local v_u_193 = not v_u_186 or v_u_186.shown or (v_u_186.rarity or 1)
		local v_u_194 = v_u_178.count
		local v_u_195 = v_u_178.need
		local v_u_196 = v_u_9.have(p_u_176)
		local v_u_197
		if v_u_195 then
			if v_u_178.haveKnown == false then
				v_u_197 = v_u_178.missing == true
			else
				v_u_197 = v_u_196 < v_u_195
			end
		else
			v_u_197 = false
		end
		local v198 = v_u_195 ~= nil and not v_u_197
		if v198 then
			v198 = v_u_178.haveKnown ~= false
		end
		local v199 = v_u_178.locked == true
		local v200 = v_u_178.caption == true
		local v_u_201 = v_u_5.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true,
			["Selectable"] = true,
			["Name"] = v_u_178.name or "Item_" .. p_u_176,
			["BackgroundColor3"] = v_u_7.raised,
			["BackgroundTransparency"] = v200 and 1 or 0.15,
			["Size"] = UDim2.fromOffset(v181, v179 + (v200 and 16 or 0)),
			["LayoutOrder"] = v_u_178.order or 0
		})
		v_u_201.SelectionImageObject = v_u_5.selectionImage()
		if v_u_178.padDefault then
			v_u_201:SetAttribute("PadDefault", true)
		end
		v_u_201:SetAttribute("ItemId", p_u_176)
		v_u_201:SetAttribute("Seen", v_u_192)
		v_u_201:SetAttribute("Output", v191)
		v_u_201:SetAttribute("Locked", v199)
		local v202
		if v200 then
			v202 = v_u_5.new("Frame", {
				["Name"] = "Box",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ClipsDescendants"] = true,
				["BackgroundColor3"] = v_u_7.raised,
				["Size"] = UDim2.fromOffset(v181, v179)
			}, v_u_201)
		else
			v202 = v_u_201
		end
		if v_u_192 then
			local v203 = v_u_5.new("Frame", {
				["Name"] = "Tint",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_6.rarityColor(v_u_193),
				["BackgroundTransparency"] = v_u_6.alpha.rarity,
				["Size"] = UDim2.fromScale(1, 1)
			}, v202)
			v_u_5.new("UIGradient", {
				["Rotation"] = 90,
				["Transparency"] = nil,
				["Transparency"] = NumberSequence.new(0.35, 0)
			}, v203)
		end
		local v_u_204
		if v_u_197 then
			v_u_204 = v_u_7.danger
		elseif v198 then
			v_u_204 = v_u_7.success
		elseif v_u_192 then
			if v199 then
				v_u_204 = v_u_7.line
			else
				v_u_204 = v_u_6.rarityColor(v_u_193):Lerp(v_u_7.line, 0.55)
			end
		else
			v_u_204 = v_u_174
		end
		local v_u_205 = v198 and 0.5 or 0
		local v_u_206 = v_u_5.stroke(v202, v_u_204, 1, v_u_205)
		local v207
		if v_u_178.label == false then
			v207 = false
		else
			v207 = v179 >= 48
		end
		local v208 = v207 and 14 or 4
		local v209 = v_u_194 and v207 and 14 or 4
		local v_u_210
		if string.find(p_u_176, "^zombie_") then
			v_u_210 = nil
		else
			v_u_210 = v_u_17()
		end
		local v211 = nil
		if v_u_210 then
			local v212 = v_u_210.get
			local v213 = {
				["parent"] = nil,
				["size"] = nil,
				["position"] = nil,
				["zindex"] = 2,
				["mods"] = nil,
				["parent"] = v202,
				["size"] = UDim2.new(1, -8, 1, -(v208 + v209)),
				["position"] = UDim2.fromOffset(4, v208),
				["mods"] = v_u_178.mods
			}
			local v214, v_u_215 = pcall(v212, p_u_176, false, v213)
			if v214 and typeof(v_u_215) == "Instance" then
				v211 = v_u_215
				if v_u_192 then
					if v199 then
						v_u_215.ImageTransparency = 0.45
					end
				else
					v_u_215.ImageColor3 = v_u_7.muted
					v_u_215.ImageTransparency = 0.35
				end
				v_u_201.Destroying:Connect(function()
					-- upvalues: (copy) v_u_215, (copy) v_u_210
					local function v216()
						-- upvalues: (ref) v_u_215
						v_u_215.ImageColor3 = Color3.new(1, 1, 1)
						v_u_215.ImageTransparency = 0
					end
					pcall(v216)
					local v217 = v_u_210.release
					local v218 = v_u_215
					pcall(v217, v218)
				end)
			end
		end
		if not v211 then
			local v219 = v_u_5.icon
			local v220 = v_u_173(p_u_176, v_u_186)
			local v221 = {
				["parent"] = v202
			}
			local v222 = math.min(v181, v179) * 0.4
			v221.size = math.floor(v222)
			local v223
			if v_u_192 and not v199 then
				v223 = v_u_7.text2
			else
				v223 = v_u_7.muted
			end
			v221.color = v223
			v221.position = UDim2.new(0.5, 0, 0, v208 + (v179 - v208 - v209) / 2)
			v221.anchor = Vector2.new(0.5, 0.5)
			v219(v220, v221).Name = "Glyph"
		end
		if v207 then
			local v224
			if v_u_186 and v_u_186.short then
				v224 = v_u_186.short
			else
				v224 = string.upper(string.gsub(p_u_176, "_", " "))
			end
			local v225 = v_u_5.label
			local v226 = {
				["parent"] = nil,
				["name"] = "Short",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["zindex"] = 3,
				["parent"] = v202,
				["text"] = v224
			}
			local v227
			if v_u_192 and not v199 then
				v227 = v_u_7.text
			else
				v227 = v_u_7.muted
			end
			v226.color = v227
			v226.position = UDim2.fromOffset(4, 1)
			v226.size = UDim2.new(1, -8 - (v_u_178.wish and 12 or 0), 0, 13)
			v225(v226)
		end
		if v200 then
			local v228
			if v_u_186 and v_u_186.short then
				v228 = v_u_186.short
			else
				v228 = string.upper(string.gsub(p_u_176, "_", " "))
			end
			local v229 = v_u_5.label
			local v230 = {
				["parent"] = nil,
				["name"] = "Caption",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "center",
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_201,
				["text"] = v228
			}
			local v231
			if v_u_192 and not v199 then
				v231 = v_u_7.text2
			else
				v231 = v_u_7.muted
			end
			v230.color = v231
			v230.position = UDim2.fromOffset(0, v179 + 2)
			v230.size = UDim2.new(1, 0, 0, 14)
			v229(v230)
		end
		if v_u_194 then
			local v232
			if v_u_197 and v_u_178.haveKnown ~= false then
				v232 = ("%d/%d"):format(v_u_196, v_u_195 or v_u_194)
			else
				v232 = ("x%d"):format(v_u_194)
			end
			local v233 = v_u_5.label
			local v234 = {
				["parent"] = nil,
				["name"] = "Count",
				["text"] = nil,
				["style"] = "mono",
				["textSize"] = 13,
				["color"] = nil,
				["align"] = "right",
				["autoX"] = true,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["track"] = false,
				["zindex"] = 4,
				["parent"] = v202,
				["text"] = v232
			}
			local v235
			if v_u_197 then
				v235 = v_u_7.danger
			elseif v198 then
				v235 = v_u_7.success
			else
				v235 = v_u_7.text
			end
			v234.color = v235
			v234.size = UDim2.fromOffset(0, 16)
			v234.position = UDim2.new(1, -2, 1, -2)
			v234.anchor = Vector2.new(1, 1)
			local v236 = v233(v234)
			v236.BackgroundColor3 = v_u_7.bg
			v236.BackgroundTransparency = 0.25
			v_u_5.pad(v236, {
				3,
				3,
				0,
				0
			})
		end
		if not v_u_192 or v191 and v199 then
			v_u_5.icon("lock", {
				["parent"] = nil,
				["size"] = nil,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 4,
				["parent"] = v202,
				["size"] = v179 >= 48 and 12 or 10,
				["color"] = v_u_7.text2,
				["position"] = UDim2.new(0, 4, 1, -4),
				["anchor"] = Vector2.new(0, 1)
			}).Name = "Lock"
		end
		local v_u_237 = nil
		local v_u_238 = false
		local function v_u_245() -- name: paint
			-- upvalues: (copy) v_u_206, (ref) v_u_238, (ref) v_u_7, (copy) v_u_204, (copy) v_u_205, (ref) v_u_237, (ref) v_u_9, (copy) p_u_176, (ref) v_u_5
			local v239 = v_u_206
			local v240
			if v_u_238 then
				v240 = v_u_7.accent
			else
				v240 = v_u_204
			end
			v239.Color = v240
			v_u_206.Transparency = v_u_238 and 0 or v_u_205
			if v_u_237 then
				local v241 = v_u_9.wished(p_u_176)
				local v242 = v_u_5.setIconColor
				local v243 = v_u_237
				local v244
				if v241 then
					v244 = v_u_7.accent
				else
					v244 = v_u_7.muted
				end
				v242(v243, v244)
				v_u_237.Visible = v241 or (v_u_238 or v_u_5.device() == "Touch")
			end
		end
		if v_u_178.wish and v_u_186 then
			v_u_237 = v_u_5.icon("star", {
				["parent"] = nil,
				["size"] = 11,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 4,
				["parent"] = v202,
				["color"] = v_u_7.muted,
				["position"] = UDim2.new(1, -3, 0, 3),
				["anchor"] = Vector2.new(1, 0)
			})
			v_u_237.Name = "Star"
			v_u_77[v_u_201] = v_u_245
			v_u_201.Activated:Connect(function()
				-- upvalues: (ref) v_u_9, (copy) p_u_176
				v_u_9.toggleWish(p_u_176)
			end)
		else
			v_u_201.Activated:Connect(function()
				-- upvalues: (ref) v_u_5, (copy) v_u_201
				v_u_5.showTooltip(v_u_201)
			end)
		end
		v_u_201.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_238, (copy) v_u_245
			v_u_238 = true
			v_u_245()
		end)
		v_u_201.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_238, (copy) v_u_245
			v_u_238 = false
			v_u_245()
		end)
		v_u_201.SelectionGained:Connect(function()
			-- upvalues: (ref) v_u_238, (copy) v_u_245, (ref) v_u_5, (copy) v_u_201
			v_u_238 = true
			v_u_245()
			v_u_5.showTooltip(v_u_201)
		end)
		v_u_201.SelectionLost:Connect(function()
			-- upvalues: (ref) v_u_238, (copy) v_u_245, (ref) v_u_5, (copy) v_u_201
			v_u_238 = false
			v_u_245()
			if v_u_5.tooltipOwner() == v_u_201 then
				v_u_5.hideTooltip()
			end
		end)
		v_u_5.tooltip(v_u_201, function()
			-- upvalues: (copy) v_u_195, (copy) v_u_178, (copy) v_u_196, (ref) v_u_197, (ref) v_u_7, (copy) v_u_194, (copy) v_u_186, (ref) v_u_6, (copy) v_u_193, (ref) v_u_9, (copy) p_u_176, (copy) v_u_192
			local v246 = {}
			if v_u_195 and v_u_178.haveKnown ~= false then
				local v247 = {
					["label"] = "In your stash",
					["value"] = nil,
					["color"] = nil,
					["value"] = ("%d  (need %d)"):format(v_u_196, v_u_195)
				}
				local v248
				if v_u_197 then
					v248 = v_u_7.danger
				else
					v248 = v_u_7.success
				end
				v247.color = v248
				table.insert(v246, v247)
			elseif v_u_195 and v_u_197 then
				local v249 = {
					["label"] = "In your stash",
					["value"] = "not enough",
					["color"] = nil,
					["color"] = v_u_7.danger
				}
				table.insert(v246, v249)
			elseif v_u_194 then
				local v250 = {
					["label"] = "Amount",
					["value"] = nil
				}
				local v251 = v_u_194
				v250.value = "x" .. tostring(v251)
				table.insert(v246, v250)
			end
			if v_u_186 then
				local v252 = {
					["label"] = "Rarity",
					["value"] = nil,
					["color"] = nil
				}
				local v253 = v_u_193
				v252.value = v_u_6.rarityName[math.clamp(v253, 1, 6)]
				v252.color = v_u_6.rarityColor(v_u_193)
				table.insert(v246, v252)
			end
			for _, v254 in v_u_9.where(p_u_176) do
				table.insert(v246, {
					["label"] = "Where",
					["value"] = nil,
					["value"] = v254
				})
			end
			for _, v255 in v_u_178.tip or {} do
				table.insert(v246, v255)
			end
			local v256 = nil
			if v_u_192 then
				if v_u_186 then
					v256 = v_u_186.desc
				end
			else
				v256 = "Not found yet. Bring one out of a raid and it shows here in full."
			end
			if v_u_178.wish and v_u_186 then
				local v257 = v_u_9.wished(p_u_176)
				v256 = (v256 and v256 .. "\n\n" or "") .. (v257 and "On your NEEDED list (select again to remove it)." or "Select it to add it to your NEEDED list: in a raid it shows a star and containers holding it glow amber.")
			end
			local v258 = {
				["title"] = string.upper(v_u_9.name(p_u_176)) .. (v_u_192 and "" or "  /  NOT FOUND YET"),
				["body"] = v256,
				["lines"] = v246
			}
			local v259
			if v_u_197 then
				v259 = v_u_7.danger
			else
				v259 = nil
			end
			v258.color = v259
			return v258
		end)
		v_u_245()
		if p175 then
			v_u_201.Parent = p175
		end
		return v_u_201
	end
	function v_u_9.destroy() -- name: destroy
		-- upvalues: (copy) v_u_10, (copy) v_u_77
		for _, v260 in v_u_10 do
			v260:Disconnect()
		end
		table.clear(v_u_10)
		table.clear(v_u_77)
	end
	return v_u_9
end
return v2