-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / CrateStageFx

game:GetService("Workspace")
game:GetService("RunService")
local v_u_1 = {}
local v_u_2 = { 1, 3, 2 }
local v_u_3 = math.max
local _ = math.min
local v_u_4 = math.floor
local v_u_5 = math.abs
local v_u_6 = math.sin
local v_u_7 = math.cos
local v_u_8 = math.rad
local function v_u_12(p9, p10, p11) -- name: C
	return Color3.fromRGB(p9, p10, p11)
end
v_u_1.GLOW = {
	Color3.fromRGB(205, 212, 224),
	Color3.fromRGB(96, 226, 128),
	Color3.fromRGB(70, 158, 255),
	Color3.fromRGB(184, 98, 255),
	Color3.fromRGB(255, 196, 64),
	Color3.fromRGB(255, 84, 184),
	v_u_12(255, 60, 210)
}
v_u_1.SIG_B = Color3.fromRGB(50, 230, 255)
v_u_1.NEUTRAL = Color3.fromRGB(255, 238, 205)
local v_u_13 = {
	["smoke"] = "rbxasset://textures/particles/smoke_main.dds",
	["sparkles"] = "rbxasset://textures/particles/sparkles_main.dds",
	["sparks"] = "rbxasset://textures/particles/fire_sparks_main.dds",
	["shock"] = "rbxasset://textures/particles/explosion01_shockwave_main.dds",
	["glow"] = "rbxasset://textures/glow.png"
}
v_u_1.TEX = v_u_13
local function v_u_17(p14, p15, p16) -- name: mix
	return p14:Lerp(p15, p16 < 0 and 0 or (p16 > 1 and 1 or p16))
end
local function v_u_27(p18, p19, p20, p21, p22, p23, p24, p25) -- name: part
	local v26 = Instance.new("Part")
	v26.Name = p19
	v26.Anchored = true
	v26.CanCollide = false
	v26.CanQuery = false
	v26.CanTouch = false
	v26.CastShadow = false
	v26.Massless = true
	v26.TopSurface = Enum.SurfaceType.Smooth
	v26.BottomSurface = Enum.SurfaceType.Smooth
	if p25 then
		v26.Shape = p25
	end
	v26.Size = p20
	v26.CFrame = p21
	v26.Color = p22
	v26.Material = p23
	v26.Transparency = p24 or 0
	v26.Parent = p18
	return v26
end
local function v_u_34(p28, p29, p30) -- name: emitter
	local v31 = Instance.new("ParticleEmitter")
	v31.Name = p29
	v31.Rate = 0
	v31.Enabled = true
	v31.LockedToPart = false
	v31.Lifetime = NumberRange.new(1, 2)
	v31.Speed = NumberRange.new(1, 2)
	v31.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	for v32, v33 in p30 do
		v31[v32] = v33
	end
	v31.Parent = p28
	return v31
end
local function v_u_41(...) -- name: ns
	local v35 = { ... }
	local v36 = {}
	for v37 = 1, #v35, 2 do
		local v38 = NumberSequenceKeypoint.new
		local v39 = v35[v37]
		local v40 = v35[v37 + 1]
		table.insert(v36, v38(v39, v40))
	end
	return NumberSequence.new(v36)
end
local function v_u_43(p42) -- name: limits
	return p42 == "low" and {
		["plates"] = 6,
		["strips"] = 3,
		["rate"] = 0.3,
		["rings"] = 2,
		["godray"] = false,
		["shadows"] = false,
		["dust"] = false
	} or {
		["plates"] = 12,
		["strips"] = 6,
		["rate"] = 1,
		["rings"] = 3,
		["godray"] = false,
		["shadows"] = true,
		["dust"] = true
	}
end
local v_u_44 = {}
v_u_44.__index = v_u_44
function v_u_1.build(p45, p46, p47, _) -- name: build
	-- upvalues: (copy) v_u_43, (copy) v_u_44, (copy) v_u_27, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7, (copy) v_u_3, (copy) v_u_1, (copy) v_u_12, (copy) v_u_34, (copy) v_u_13, (copy) v_u_41
	local v48 = p47 == "low" and "low" or "high"
	local v_u_49 = v_u_43(v48)
	local v50 = v_u_44
	local v_u_51 = setmetatable({}, v50)
	v_u_51.quality = v48
	v_u_51.origin = p45
	v_u_51.L = v_u_49
	v_u_51.t0 = os.clock()
	local v53, v54 = pcall(function()
		local v52 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
		return require(v52:WaitForChild("CrateLooks", 5))
	end)
	if not v53 then
		v54 = nil
	end
	v_u_51.Looks = v54
	local v55 = v54 and (v54.lookOf(p46) or "field") or "field"
	v_u_51.lookName = v55
	local v56
	if v54 then
		v56 = v54.LOOKS[v55]
	else
		v56 = v54
	end
	v_u_51.seamColor = v56 and v56.seam or Color3.fromRGB(255, 236, 190)
	v_u_51.coreColor = v56 and v56.core or Color3.fromRGB(255, 190, 90)
	v_u_51.mouthColor = v56 and v56.mouth or Color3.fromRGB(255, 205, 120)
	local v_u_57 = Instance.new("Folder")
	for v58, v59 in {
		["Name"] = "CrateStage"
	} do
		v_u_57[v58] = v59
	end
	v_u_51.root = v_u_57
	local v_u_60 = CFrame.new(p45)
	v_u_51.O = v_u_60
	local v61 = v_u_60 * CFrame.new(0, -0.5, 0)
	local v62 = Color3.fromRGB(42, 46, 56)
	local v63 = Enum.Material.SmoothPlastic
	local v64 = Instance.new("Part")
	v64.Name = "Floor"
	v64.Anchored = true
	v64.CanCollide = false
	v64.CanQuery = false
	v64.CanTouch = false
	v64.CastShadow = false
	v64.Massless = true
	v64.TopSurface = Enum.SurfaceType.Smooth
	v64.BottomSurface = Enum.SurfaceType.Smooth
	v64.Size = Vector3.new(80, 1, 80)
	v64.CFrame = v61
	v64.Color = v62
	v64.Material = v63
	v64.Transparency = 0
	v64.Parent = v_u_57
	v64.Reflectance = 0.15
	v64.CastShadow = true
	v_u_27(v_u_57, "Pedestal", Vector3.new(0.5, 9.2, 9.2), v_u_60 * CFrame.new(0, 0.25, 0) * CFrame.Angles(0, 0, 1.5707963267948966), Color3.fromRGB(72, 78, 92), Enum.Material.SmoothPlastic, 0, Enum.PartType.Cylinder).Reflectance = 0.15
	v_u_51.crown = v_u_27(v_u_57, "Crown", Vector3.new(0.06, 9.5, 9.5), v_u_60 * CFrame.new(0, 0.03, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_51.seamColor, Enum.Material.Neon, 0.35, Enum.PartType.Cylinder)
	v_u_51.floorRings = {}
	for v65, v66 in { 16, 25, 36 } do
		local v67 = v_u_27(v_u_57, "FloorRing" .. v65, Vector3.new(0.02, v66, v66), v_u_60 * CFrame.new(0, 0.011 + (3 - v65) * 0.012, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_51.seamColor, Enum.Material.Neon, 0.9, Enum.PartType.Cylinder)
		local v68 = v_u_27
		local v69 = "FloorMask" .. v65
		local v70 = v66 - 0.3
		local v71 = v66 - 0.3
		v68(v_u_57, v69, Vector3.new(0.02, v70, v71), v_u_60 * CFrame.new(0, 0.016 + (3 - v65) * 0.012, 0) * CFrame.Angles(0, 0, 1.5707963267948966), Color3.fromRGB(42, 46, 56), Enum.Material.SmoothPlastic, 0, Enum.PartType.Cylinder).Reflectance = 0.15
		local v72 = v_u_51.floorRings
		table.insert(v72, v67)
	end
	v_u_51.plates = {}
	v_u_51.strips = {}
	local v73 = v_u_49.plates
	local v74 = v_u_8(v73 == 12 and 216 or 200)
	local v75 = v74 / v73
	for v76 = 1, v73 do
		local v77 = -v74 / 2 + (v76 - 0.5) * v75
		local v78 = v_u_6(v77) * 19
		local v79 = v_u_7(v77) * 19
		local v80 = Vector3.new(v78, 23, v79)
		local v81 = v_u_60 * CFrame.lookAt(v80, Vector3.new(0, 23, 0))
		local v82 = v75 / 2
		local v83 = math.tan(v82) * 38 * 0.92
		local v84 = "Plate" .. v76
		local v85 = Vector3.new(v83, 46, 0.6)
		local v86 = Color3.fromRGB(24, 26, 33)
		local v87 = Enum.Material.SmoothPlastic
		local v88 = Instance.new("Part")
		v88.Name = v84
		v88.Anchored = true
		v88.CanCollide = false
		v88.CanQuery = false
		v88.CanTouch = false
		v88.CastShadow = false
		v88.Massless = true
		v88.TopSurface = Enum.SurfaceType.Smooth
		v88.BottomSurface = Enum.SurfaceType.Smooth
		v88.Size = v85
		v88.CFrame = v81
		v88.Color = v86
		v88.Material = v87
		v88.Transparency = 0
		v88.Parent = v_u_57
		v88.Reflectance = 0.04
		local v89 = v_u_51.plates
		table.insert(v89, v88)
	end
	local v90 = v_u_49.strips
	for v91 = 1, v90 do
		local v92 = -v74 / 2 + (v91 - 0.5) * v74 / v90
		local v93 = v_u_6(v92) * 18.55
		local v94 = v_u_7(v92) * 18.55
		local v95 = Vector3.new(v93, 23, v94)
		local v96 = v_u_60 * CFrame.lookAt(v95, Vector3.new(0, 23, 0))
		local v97 = "Strip" .. v91
		local v98 = v_u_51.seamColor
		local v99 = Enum.Material.Neon
		local v100 = Instance.new("Part")
		v100.Name = v97
		v100.Anchored = true
		v100.CanCollide = false
		v100.CanQuery = false
		v100.CanTouch = false
		v100.CastShadow = false
		v100.Massless = true
		v100.TopSurface = Enum.SurfaceType.Smooth
		v100.BottomSurface = Enum.SurfaceType.Smooth
		v100.Size = Vector3.new(0.14, 46, 0.14)
		v100.CFrame = v96
		v100.Color = v98
		v100.Material = v99
		v100.Transparency = 0
		v100.Parent = v_u_57
		local v101 = v_u_51.strips
		table.insert(v101, v100)
	end
	local v102 = v_u_60 * CFrame.new(0, 46.5, 0)
	local v103 = Color3.fromRGB(8, 9, 11)
	local v104 = Enum.Material.SmoothPlastic
	local v105 = Instance.new("Part")
	v105.Name = "Ceiling"
	v105.Anchored = true
	v105.CanCollide = false
	v105.CanQuery = false
	v105.CanTouch = false
	v105.CastShadow = false
	v105.Massless = true
	v105.TopSurface = Enum.SurfaceType.Smooth
	v105.BottomSurface = Enum.SurfaceType.Smooth
	v105.Size = Vector3.new(80, 1, 80)
	v105.CFrame = v102
	v105.Color = v103
	v105.Material = v104
	v105.Transparency = 0
	v105.Parent = v_u_57
	v_u_51.kit = false
	local v_u_106
	if v54 then
		local v107 = v54.stage
		local v108, v109
		v108, v_u_106, v109 = pcall(v107, v55, v48)
		if v108 and typeof(v_u_106) == "Instance" then
			v_u_51.kit = v109 == true
		else
			v_u_106 = v54.base()
			v54.apply(v_u_106, v55, "stage", v48)
		end
	else
		v_u_106 = Instance.new("Model")
		for v110, v111 in {
			["Name"] = "CrateBase"
		} do
			v_u_106[v110] = v111
		end
	end
	v_u_106.Name = "Crate"
	v_u_51.crateCF = v_u_60 * CFrame.new(0, 0.5, 0)
	v_u_106:PivotTo(v_u_51.crateCF)
	for _, v112 in v_u_106:GetDescendants() do
		if not v112:IsA("BasePart") then
			continue
		end
		if v112.Material == Enum.Material.Metal then
			v112.Material = Enum.Material.SmoothPlastic
			v112.Reflectance = v_u_3(v112.Reflectance, 0.12)
		end
		v112.CanCollide = false
		v112.CanQuery = false
		v112.CanTouch = false
		v112.CastShadow = true
	end
	v_u_106.Parent = v_u_57
	v_u_51.crate = v_u_106
	v_u_51.body = v_u_106:FindFirstChild("Body")
	v_u_51.lid = v_u_106:FindFirstChild("LidPlate")
	local v113 = v_u_51.lid
	if v113 then
		v113 = v_u_51.lid:FindFirstChild("LidHinge")
	end
	v_u_51.hinge = v113
	local v114 = v_u_51.hinge
	if v114 then
		v114 = v_u_51.hinge.C0
	end
	v_u_51.hingeC0 = v114
	local v115 = v_u_51.lid
	if v115 then
		v115 = v_u_51.lid.Color
	end
	v_u_51.lidColor = v115
	v_u_51.lidParts = {}
	if v_u_51.lid then
		for _, v116 in v_u_106:GetDescendants() do
			if not v116:IsA("BasePart") then
				continue
			end
			local v117 = v116 == v_u_51.lid
			if not v117 then
				for _, v118 in v116:GetChildren() do
					if not v118:IsA("Weld") or v118.Part0 ~= v_u_51.lid then
						continue
					end
					v117 = true
				end
			end
			if not v117 then
				continue
			end
			local v119 = v_u_51.lidParts
			local v120 = {
				["part"] = v116,
				["tr"] = v116.Transparency
			}
			table.insert(v119, v120)
		end
	end
	local function v126(p121) -- name: entry
		-- upvalues: (ref) v_u_106
		local v122 = v_u_106:FindFirstChild(p121)
		if not (v122 and v122:IsA("BasePart")) then
			return {
				["part"] = nil
			}
		end
		local v123 = nil
		for _, v124 in v122:GetChildren() do
			if not (v124:IsA("Weld") or v124:IsA("Motor6D")) then
				continue
			end
			v123 = v124
		end
		local v125 = {
			["part"] = v122,
			["weld"] = v123
		}
		if v123 then
			v123 = v123.C0
		end
		v125.c0 = v123
		v125.po = v122.PivotOffset
		return v125
	end
	v_u_51.sgnX = v_u_51.kit and 1 or -1
	v_u_51.latches = {}
	v_u_51.pins = {}
	v_u_51.latches[1] = v126("Latch" .. 1)
	v_u_51.pins[1] = v126("Detail_Pin" .. 1)
	v_u_51.latches[2] = v126("Latch" .. 2)
	v_u_51.pins[2] = v126("Detail_Pin" .. 2)
	v_u_51.latches[3] = v126("Latch" .. 3)
	v_u_51.pins[3] = v126("Detail_Pin" .. 3)
	v_u_51.lock = v126("Detail_Lock")
	v_u_51.shackle = v126("Detail_Shackle")
	v_u_51.glow = v_u_106:FindFirstChild("Detail_Glow")
	v_u_51.plate = v_u_106:FindFirstChild("Detail_LockPlate")
	v_u_51.lockParts = {}
	if v_u_51.lock.part then
		for _, v134 in v_u_106:GetDescendants() do
			if not v134:IsA("BasePart") or v134 == v_u_51.glow then
				continue
			end
			local v128 = v134
			local v129 = 0
			while v134 and v129 < 6 do
				if v134 == v_u_51.lock.part then
					local v130 = v_u_51.lockParts
					local v131 = {
						["part"] = v128,
						["tr"] = v128.Transparency
					}
					table.insert(v130, v131)
					break
				end
				local v132 = nil
				for _, v133 in v134:GetChildren() do
					if not v133:IsA("Weld") or v133.Part1 ~= v134 then
						continue
					end
					v132 = v133.Part0
				end
				v129 = v129 + 1
				local v134 = v132
			end
		end
	end
	v_u_51.holeRest = nil
	v_u_51.lockRestCF = nil
	if v_u_51.plate and (v_u_51.lock.part and v_u_51.body) then
		local v135 = v_u_51.kit and 0 or 0.06
		v_u_51.holeRest = v_u_51.plate.Position + Vector3.new(0, v135, 0.04)
		v_u_51.lockRestCF = v_u_51.body.CFrame * v_u_51.lock.c0
	end
	v_u_51.seams = {}
	for _, v136 in v_u_106:GetChildren() do
		local v137 = v136.Name
		if string.sub(v137, 1, 5) ~= "Seam_" or not v136:IsA("BasePart") then
			continue
		end
		local v138 = v_u_51.seams
		table.insert(v138, v136)
	end
	v_u_51.mouth = v_u_106:FindFirstChild("Mouth")
	local v139 = v_u_51.body
	if v139 then
		v139 = v_u_51.body:FindFirstChild("BurstPoint")
	end
	v_u_51.burstPoint = v139
	if v139 then
		v139 = v139:FindFirstChild("CoreLight")
	end
	v_u_51.coreLight = v139
	v_u_51.crateSize = not v_u_51.body and Vector3.new(5.3, 1.5, 2.2) or v_u_51.body.Size
	local v140 = v_u_51.crateSize
	v_u_51.burstPos = (v_u_60 * CFrame.new(0, 0.5 + v140.Y, 0)).Position
	v_u_51.crateTop = 0.5 + v140.Y
	v_u_51.column = {}
	local v141 = {
		0.13,
		0.32,
		0.62,
		1
	}
	local v142 = {
		0.06,
		0.42,
		0.76,
		0.91
	}
	for v143 = 1, #v141 do
		local v144 = v_u_27
		local v145 = "Column" .. v143
		local v146 = v141[v143] * 2
		local v147 = v141[v143] * 2
		local v148 = v144(v_u_57, v145, Vector3.new(1, v146, v147), v_u_60 * CFrame.new(0, 10, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_1.NEUTRAL, Enum.Material.Neon, 1, Enum.PartType.Cylinder)
		v_u_51.column[v143] = {
			["part"] = v148,
			["tr"] = v142[v143],
			["dia"] = v141[v143] * 2
		}
	end
	v_u_51.godrays = {}
	if v_u_49.godray then
		for v149 = 1, 6 do
			local v150 = "Godray" .. v149
			local v151 = v_u_60 * CFrame.new(0, 20, 0)
			local v152 = v_u_1.NEUTRAL
			local v153 = Enum.Material.Neon
			local v154 = Instance.new("Part")
			v154.Name = v150
			v154.Anchored = true
			v154.CanCollide = false
			v154.CanQuery = false
			v154.CanTouch = false
			v154.CastShadow = false
			v154.Massless = true
			v154.TopSurface = Enum.SurfaceType.Smooth
			v154.BottomSurface = Enum.SurfaceType.Smooth
			v154.Size = Vector3.new(0.05, 30, 5)
			v154.CFrame = v151
			v154.Color = v152
			v154.Material = v153
			v154.Transparency = 1
			v154.Parent = v_u_57
			local v155 = v_u_51.godrays
			table.insert(v155, v154)
		end
	end
	local function v_u_164(p156, p157, p158) -- name: lightPart
		-- upvalues: (copy) v_u_57
		local v159 = v_u_57
		local v160
		if p158 then
			v160 = CFrame.lookAt(p157, p158)
		else
			v160 = CFrame.new(p157)
		end
		local v161 = Color3.fromRGB(255, 255, 255)
		local v162 = Enum.Material.SmoothPlastic
		local v163 = Instance.new("Part")
		v163.Name = p156
		v163.Anchored = true
		v163.CanCollide = false
		v163.CanQuery = false
		v163.CanTouch = false
		v163.CastShadow = false
		v163.Massless = true
		v163.TopSurface = Enum.SurfaceType.Smooth
		v163.BottomSurface = Enum.SurfaceType.Smooth
		v163.Size = Vector3.new(0.2, 0.2, 0.2)
		v163.CFrame = v160
		v163.Color = v161
		v163.Material = v162
		v163.Transparency = 1
		v163.Parent = v159
		return v163
	end
	v_u_51.lights = {}
	local function v177(p165, p166, p167, p168, p169, p170, p171) -- name: spot
		-- upvalues: (copy) v_u_164, (copy) v_u_60, (copy) v_u_49, (copy) v_u_51
		local v172 = v_u_164(p165, v_u_60.Position + p166, v_u_60.Position + p167)
		local v173 = {
			["Angle"] = p168,
			["Range"] = p169,
			["Brightness"] = p170,
			["Color"] = p171,
			["Shadows"] = v_u_49.shadows,
			["Face"] = Enum.NormalId.Front
		}
		local v174 = Instance.new("SpotLight")
		for v175, v176 in v173 do
			v174[v175] = v176
		end
		if v172 then
			v174.Parent = v172
		end
		v_u_51.lights[p165] = v174
		return v174
	end
	v177("KeyLightL", Vector3.new(5, 12, -4), Vector3.new(0, 1.2, 0), 46, 32, 2.6, v_u_12(210, 225, 255))
	if v48 == "high" then
		v177("KeyLightR", Vector3.new(-5, 12, -4), Vector3.new(0, 1.2, 0), 46, 32, 2.2, v_u_12(255, 225, 200))
		v177("FillLight", Vector3.new(-3.5, 5.5, -10), Vector3.new(0, 1, -1), 50, 26, 3, v_u_12(255, 238, 218))
	end
	v_u_51.beams = {}
	local v178 = v_u_164("BeamTarget", v_u_60.Position + Vector3.new(0, 1.8, 0))
	local v179 = Instance.new("Attachment")
	for v180, v181 in {
		["Name"] = "T"
	} do
		v179[v180] = v181
	end
	if v178 then
		v179.Parent = v178
	end
	for _, v182 in { "KeyLightL", "KeyLightR" } do
		local v183 = v_u_57:FindFirstChild(v182)
		if not v183 then
			continue
		end
		local v184 = Instance.new("Attachment")
		for v185, v186 in {
			["Name"] = "B"
		} do
			v184[v185] = v186
		end
		if v183 then
			v184.Parent = v183
		end
		local v187 = {
			["Attachment0"] = nil,
			["Attachment1"] = nil,
			["Width0"] = 0.4,
			["Width1"] = 4.5,
			["FaceCamera"] = true,
			["LightEmission"] = 1,
			["LightInfluence"] = 0,
			["Transparency"] = nil,
			["Color"] = nil,
			["Segments"] = 1,
			["Attachment0"] = v184,
			["Attachment1"] = v179,
			["Transparency"] = NumberSequence.new(0.955),
			["Color"] = ColorSequence.new(v_u_12(190, 210, 255))
		}
		local v188 = Instance.new("Beam")
		for v189, v190 in v187 do
			v188[v189] = v190
		end
		if v183 then
			v188.Parent = v183
		end
		local v191 = v_u_51.beams
		table.insert(v191, v188)
	end
	v_u_51.lights.CoreLight = v_u_51.coreLight
	local v192 = v_u_1.NEUTRAL
	local v193 = v_u_164("ColumnLight", v_u_60.Position + Vector3.new(0, 8, 0))
	local v194 = Instance.new("PointLight")
	for v195, v196 in {
		["Range"] = 26,
		["Brightness"] = 0,
		["Color"] = nil,
		["Shadows"] = false,
		["Color"] = v192
	} do
		v194[v195] = v196
	end
	if v193 then
		v194.Parent = v193
	end
	v_u_51.lights.ColumnLight = v194
	if v48 == "high" then
		local v197 = Color3.fromRGB(255, 244, 220)
		local v198 = v_u_164("FlashLight", v_u_60.Position + Vector3.new(0, 3.5, -3))
		local v199 = Instance.new("PointLight")
		for v200, v201 in {
			["Range"] = 30,
			["Brightness"] = 0,
			["Color"] = nil,
			["Shadows"] = false,
			["Color"] = v197
		} do
			v199[v200] = v201
		end
		if v198 then
			v199.Parent = v198
		end
		v_u_51.lights.FlashLight = v199
	end
	v_u_51.emitters = {}
	if v_u_49.dust then
		local v202 = v_u_60 * CFrame.new(0, 7, 0)
		local v203 = Color3.fromRGB(255, 255, 255)
		local v204 = Enum.Material.SmoothPlastic
		local v205 = Instance.new("Part")
		v205.Name = "DustVolume"
		v205.Anchored = true
		v205.CanCollide = false
		v205.CanQuery = false
		v205.CanTouch = false
		v205.CastShadow = false
		v205.Massless = true
		v205.TopSurface = Enum.SurfaceType.Smooth
		v205.BottomSurface = Enum.SurfaceType.Smooth
		v205.Size = Vector3.new(36, 14, 36)
		v205.CFrame = v202
		v205.Color = v203
		v205.Material = v204
		v205.Transparency = 1
		v205.Parent = v_u_57
		v_u_51.emitters.dust = v_u_34(v205, "Dust", {
			["Texture"] = nil,
			["Rate"] = 7,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["Size"] = nil,
			["Transparency"] = nil,
			["LightEmission"] = 0.8,
			["Shape"] = nil,
			["ShapeStyle"] = nil,
			["Color"] = nil,
			["SpreadAngle"] = nil,
			["Texture"] = v_u_13.smoke,
			["Lifetime"] = NumberRange.new(7, 10),
			["Speed"] = NumberRange.new(0.05, 0.25),
			["Size"] = v_u_41(0, 0.07, 1, 0.07),
			["Transparency"] = v_u_41(0, 1, 0.2, 0.55, 0.8, 0.55, 1, 1),
			["Shape"] = Enum.ParticleEmitterShape.Box,
			["ShapeStyle"] = Enum.ParticleEmitterShapeStyle.Volume,
			["Color"] = ColorSequence.new(v_u_12(255, 240, 220)),
			["SpreadAngle"] = Vector2.new(180, 180)
		})
	end
	local v206 = CFrame.new(v_u_51.burstPos)
	local v207 = Color3.fromRGB(255, 255, 255)
	local v208 = Enum.Material.SmoothPlastic
	local v209 = Instance.new("Part")
	v209.Name = "FxAnchor"
	v209.Anchored = true
	v209.CanCollide = false
	v209.CanQuery = false
	v209.CanTouch = false
	v209.CastShadow = false
	v209.Massless = true
	v209.TopSurface = Enum.SurfaceType.Smooth
	v209.BottomSurface = Enum.SurfaceType.Smooth
	v209.Size = Vector3.new(0.2, 0.2, 0.2)
	v209.CFrame = v206
	v209.Color = v207
	v209.Material = v208
	v209.Transparency = 1
	v209.Parent = v_u_57
	v_u_51.fxAnchor = v209
	local v210 = {
		["Name"] = "Up",
		["CFrame"] = nil,
		["CFrame"] = CFrame.Angles(0, 0, 0)
	}
	local v211 = Instance.new("Attachment")
	for v212, v213 in v210 do
		v211[v212] = v213
	end
	if v209 then
		v211.Parent = v209
	end
	v_u_51.sparks = v_u_34(v209, "Sparks", {
		["Texture"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["EmissionDirection"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["LightEmission"] = 1,
		["LightInfluence"] = 0,
		["Acceleration"] = Vector3.new(0, -16, 0),
		["Color"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["Texture"] = v_u_13.sparkles,
		["Lifetime"] = NumberRange.new(0.7, 1.6),
		["Speed"] = NumberRange.new(10, 22),
		["SpreadAngle"] = Vector2.new(28, 28),
		["EmissionDirection"] = Enum.NormalId.Top,
		["Size"] = v_u_41(0, 0.45, 1, 0.05),
		["Transparency"] = v_u_41(0, 0, 0.7, 0.1, 1, 1),
		["Color"] = ColorSequence.new(v_u_1.NEUTRAL),
		["Rotation"] = NumberRange.new(0, 360),
		["RotSpeed"] = NumberRange.new(-180, 180)
	})
	v_u_51.emitters.sparks = v_u_51.sparks
	v_u_51.shock = v_u_34(v209, "Shock", {
		["Texture"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["LightEmission"] = 1,
		["LightInfluence"] = 0,
		["EmissionDirection"] = nil,
		["Orientation"] = nil,
		["Color"] = nil,
		["Texture"] = v_u_13.shock,
		["Lifetime"] = NumberRange.new(0.6, 0.6),
		["Speed"] = NumberRange.new(0.05, 0.05),
		["Size"] = v_u_41(0, 1, 1, 18),
		["Transparency"] = v_u_41(0, 0.3, 1, 1),
		["EmissionDirection"] = Enum.NormalId.Top,
		["Orientation"] = Enum.ParticleOrientation.VelocityPerpendicular,
		["Color"] = ColorSequence.new(v_u_1.NEUTRAL)
	})
	v_u_51.emitters.shock = v_u_51.shock
	v_u_51.confetti = {}
	local v214 = {
		{
			["tex"] = nil,
			["size"] = nil,
			["light"] = 0.7,
			["orient"] = nil,
			["squash"] = nil,
			["tex"] = v_u_13.glow,
			["size"] = v_u_41(0, 0.34, 1, 0.34),
			["orient"] = Enum.ParticleOrientation.FacingCamera
		},
		{
			["tex"] = nil,
			["size"] = nil,
			["light"] = 1,
			["orient"] = nil,
			["squash"] = nil,
			["tex"] = v_u_13.sparkles,
			["size"] = v_u_41(0, 0.4, 1, 0.1),
			["orient"] = Enum.ParticleOrientation.FacingCamera
		},
		{
			["tex"] = nil,
			["size"] = nil,
			["light"] = 1,
			["orient"] = nil,
			["squash"] = -1.2,
			["tex"] = v_u_13.sparks,
			["size"] = v_u_41(0, 0.55, 1, 0.55),
			["orient"] = Enum.ParticleOrientation.VelocityParallel
		}
	}
	for v215 = 1, v48 == "high" and 3 or 1 do
		local v216 = v214[v215]
		local v217 = v_u_34(v209, "Confetti" .. v215, {
			["Texture"] = nil,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["SpreadAngle"] = nil,
			["EmissionDirection"] = nil,
			["Size"] = nil,
			["Transparency"] = nil,
			["LightEmission"] = nil,
			["LightInfluence"] = 0,
			["Acceleration"] = Vector3.new(0, -18, 0),
			["Drag"] = 1.2,
			["Rotation"] = nil,
			["RotSpeed"] = nil,
			["Orientation"] = nil,
			["Color"] = nil,
			["Texture"] = v216.tex,
			["Lifetime"] = NumberRange.new(2.2, 3.6),
			["Speed"] = NumberRange.new(14, 26),
			["SpreadAngle"] = Vector2.new(34, 34),
			["EmissionDirection"] = Enum.NormalId.Top,
			["Size"] = v216.size,
			["Transparency"] = v_u_41(0, 0, 0.8, 0, 1, 1),
			["LightEmission"] = v216.light,
			["Rotation"] = NumberRange.new(0, 360),
			["RotSpeed"] = NumberRange.new(-200, 200),
			["Orientation"] = v216.orient,
			["Color"] = ColorSequence.new(v_u_12(255, 255, 255))
		})
		if v216.squash then
			v217.Squash = NumberSequence.new(v216.squash)
		end
		v_u_51.confetti[v215] = v217
		v_u_51.emitters["confetti" .. v215] = v217
	end
	v_u_51.colSparks = v_u_34(v209, "ColumnSparks", {
		["Texture"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["EmissionDirection"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["LightEmission"] = 1,
		["LightInfluence"] = 0,
		["Acceleration"] = Vector3.new(0, 1, 0),
		["Color"] = nil,
		["Rate"] = 0,
		["Texture"] = v_u_13.sparkles,
		["Lifetime"] = NumberRange.new(1.2, 2.4),
		["Speed"] = NumberRange.new(4, 9),
		["SpreadAngle"] = Vector2.new(8, 8),
		["EmissionDirection"] = Enum.NormalId.Top,
		["Size"] = v_u_41(0, 0.3, 1, 0.04),
		["Transparency"] = v_u_41(0, 0.1, 0.8, 0.3, 1, 1),
		["Color"] = ColorSequence.new(v_u_1.NEUTRAL)
	})
	v_u_51.emitters.colSparks = v_u_51.colSparks
	v_u_51.latchSparks = v_u_51.sparks
	if v48 == "high" then
		v_u_51.puff = v_u_34(v209, "Puff", {
			["Texture"] = nil,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["SpreadAngle"] = nil,
			["EmissionDirection"] = nil,
			["Size"] = nil,
			["Transparency"] = nil,
			["LightEmission"] = 0.3,
			["LightInfluence"] = 0.5,
			["Color"] = nil,
			["Texture"] = v_u_13.smoke,
			["Lifetime"] = NumberRange.new(0.8, 1.4),
			["Speed"] = NumberRange.new(2, 5),
			["SpreadAngle"] = Vector2.new(60, 60),
			["EmissionDirection"] = Enum.NormalId.Top,
			["Size"] = v_u_41(0, 0.8, 1, 3.2),
			["Transparency"] = v_u_41(0, 0.6, 1, 1),
			["Color"] = ColorSequence.new(v_u_12(190, 190, 196))
		})
		v_u_51.emitters.puff = v_u_51.puff
	end
	v_u_51:_buildKey()
	v_u_51.discs = {}
	for v218 = 1, v_u_49.rings do
		local v219 = {
			["part"] = nil,
			["t"] = nil,
			["dur"] = 0.7,
			["maxD"] = 22,
			["part"] = v_u_27(v_u_57, "RingDisc" .. v218, Vector3.new(0.05, 1, 1), v_u_60 * CFrame.new(0, 0.6, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_1.NEUTRAL, Enum.Material.Neon, 1, Enum.PartType.Cylinder)
		}
		v_u_51.discs[v218] = v219
	end
	v_u_51.winner = nil
	v_u_51.frame = nil
	v_u_51.fired = {}
	v_u_51.shockTexOk = true
	return v_u_51
end
function v_u_44._buildKey(p220) -- name: _buildKey
	-- upvalues: (copy) v_u_27, (copy) v_u_7, (copy) v_u_6
	local v221 = p220.root
	local v222 = p220.Looks and p220.Looks.DETAIL
	if v222 then
		v222 = p220.Looks.DETAIL[p220.lookName]
	end
	local v223
	if v222 then
		v223 = v222.key
	else
		v223 = Color3.fromRGB(206, 210, 218)
	end
	local v224
	if v222 then
		v224 = v222.keyBow
	else
		v224 = v223
	end
	local v225 = nil
	local v226
	if p220.Looks and p220.Looks.kitKey then
		local v227 = p220.Looks.kitKey
		local v228 = p220.lookName
		local v229
		v229, v226 = pcall(v227, v228)
		if v229 and typeof(v226) == "Instance" then
			p220.keyKit = true
		else
			v226 = v225
		end
	else
		v226 = v225
	end
	if not v226 then
		local v230 = Instance.new("Model")
		for v231, v232 in {
			["Name"] = "Key"
		} do
			v230[v231] = v232
		end
		local v233 = v230
		local v234 = CFrame.Angles(0, 1.5707963267948966, 0)
		local v235 = CFrame.new(0, 0, 0)
		local v236 = v233
		local v237 = Enum.Material.SmoothPlastic
		local v238 = Instance.new("Part")
		v238.Name = "Tip"
		v238.Anchored = true
		v238.CanCollide = false
		v238.CanQuery = false
		v238.CanTouch = false
		v238.CastShadow = false
		v238.Massless = true
		v238.TopSurface = Enum.SurfaceType.Smooth
		v238.BottomSurface = Enum.SurfaceType.Smooth
		v238.Size = Vector3.new(0.02, 0.02, 0.02)
		v238.CFrame = v235
		v238.Color = v223
		v238.Material = v237
		v238.Transparency = 0
		v238.Parent = v236
		v238.CastShadow = false
		v238.Reflectance = 0.38
		v238.Transparency = 1
		v233.PrimaryPart = v238
		local v239 = CFrame.new(0.09, 0, -0.3)
		local v240 = v233
		local v241 = Enum.Material.SmoothPlastic
		local v242 = Instance.new("Part")
		v242.Name = "BitBlade"
		v242.Anchored = true
		v242.CanCollide = false
		v242.CanQuery = false
		v242.CanTouch = false
		v242.CastShadow = false
		v242.Massless = true
		v242.TopSurface = Enum.SurfaceType.Smooth
		v242.BottomSurface = Enum.SurfaceType.Smooth
		v242.Size = Vector3.new(0.16, 0.07, 0.6)
		v242.CFrame = v239
		v242.Color = v223
		v242.Material = v241
		v242.Transparency = 0
		v242.Parent = v240
		v242.CastShadow = false
		v242.Reflectance = 0.38
		local v243 = CFrame.new(0.22, 0, -0.1)
		local v244 = v233
		local v245 = Enum.Material.SmoothPlastic
		local v246 = Instance.new("Part")
		v246.Name = "BitTooth1"
		v246.Anchored = true
		v246.CanCollide = false
		v246.CanQuery = false
		v246.CanTouch = false
		v246.CastShadow = false
		v246.Massless = true
		v246.TopSurface = Enum.SurfaceType.Smooth
		v246.BottomSurface = Enum.SurfaceType.Smooth
		v246.Size = Vector3.new(0.1, 0.07, 0.11)
		v246.CFrame = v243
		v246.Color = v223
		v246.Material = v245
		v246.Transparency = 0
		v246.Parent = v244
		v246.CastShadow = false
		v246.Reflectance = 0.38
		local v247 = CFrame.new(0.255, 0, -0.29)
		local v248 = v233
		local v249 = Enum.Material.SmoothPlastic
		local v250 = Instance.new("Part")
		v250.Name = "BitTooth2"
		v250.Anchored = true
		v250.CanCollide = false
		v250.CanQuery = false
		v250.CanTouch = false
		v250.CastShadow = false
		v250.Massless = true
		v250.TopSurface = Enum.SurfaceType.Smooth
		v250.BottomSurface = Enum.SurfaceType.Smooth
		v250.Size = Vector3.new(0.17, 0.07, 0.11)
		v250.CFrame = v247
		v250.Color = v223
		v250.Material = v249
		v250.Transparency = 0
		v250.Parent = v248
		v250.CastShadow = false
		v250.Reflectance = 0.38
		local v251 = CFrame.new(0.23, 0, -0.48)
		local v252 = v233
		local v253 = Enum.Material.SmoothPlastic
		local v254 = Instance.new("Part")
		v254.Name = "BitTooth3"
		v254.Anchored = true
		v254.CanCollide = false
		v254.CanQuery = false
		v254.CanTouch = false
		v254.CastShadow = false
		v254.Massless = true
		v254.TopSurface = Enum.SurfaceType.Smooth
		v254.BottomSurface = Enum.SurfaceType.Smooth
		v254.Size = Vector3.new(0.12, 0.07, 0.11)
		v254.CFrame = v251
		v254.Color = v223
		v254.Material = v253
		v254.Transparency = 0
		v254.Parent = v252
		v254.CastShadow = false
		v254.Reflectance = 0.38
		local v255 = CFrame.new(0, 0, -1.01) * v234
		local v256 = Enum.PartType.Cylinder
		local v257 = v_u_27(v233, "Shaft", Vector3.new(0.78, 0.12, 0.12), v255, v223, Enum.Material.SmoothPlastic, 0, v256)
		v257.CastShadow = false
		v257.Reflectance = 0.42
		local v258 = CFrame.new(0, 0, -0.72) * v234
		local v259 = Enum.PartType.Cylinder
		local v260 = v_u_27(v233, "Collar1", Vector3.new(0.06, 0.2, 0.2), v258, v224, Enum.Material.SmoothPlastic, 0, v259)
		v260.CastShadow = false
		v260.Reflectance = 0.4
		local v261 = CFrame.new(0, 0, -0.82) * v234
		local v262 = Enum.PartType.Cylinder
		local v263 = v_u_27(v233, "Collar2", Vector3.new(0.05, 0.17, 0.17), v261, v224, Enum.Material.SmoothPlastic, 0, v262)
		v263.CastShadow = false
		v263.Reflectance = 0.4
		local v264 = CFrame.new(0, 0, -1.42) * v234
		local v265 = Enum.PartType.Cylinder
		local v266 = v_u_27(v233, "Neck", Vector3.new(0.18, 0.17, 0.17), v264, v223, Enum.Material.SmoothPlastic, 0, v265)
		v266.CastShadow = false
		v266.Reflectance = 0.42
		local v267 = p220.quality == "low" and 6 or 8
		local v268 = 3.141592653589793 / v267
		local v269 = math.tan(v268) * 0.47 + 0.07
		v226 = v233
		for v270 = 1, v267 do
			local v271 = (v270 - 1) / v267 * 2 * 3.141592653589793
			local v272 = "Bow" .. v270
			local v273 = Vector3.new(0.17, 0.07, v269)
			local v274 = CFrame.new(v_u_7(v271) * 0.235, 0, v_u_6(v271) * 0.235 + -1.74) * CFrame.Angles(0, -v271, 0)
			local v275 = Enum.Material.SmoothPlastic
			local v276 = Instance.new("Part")
			v276.Name = v272
			v276.Anchored = true
			v276.CanCollide = false
			v276.CanQuery = false
			v276.CanTouch = false
			v276.CastShadow = false
			v276.Massless = true
			v276.TopSurface = Enum.SurfaceType.Smooth
			v276.BottomSurface = Enum.SurfaceType.Smooth
			v276.Size = v273
			v276.CFrame = v274
			v276.Color = v224
			v276.Material = v275
			v276.Transparency = 0
			v276.Parent = v226
			v276.CastShadow = false
			v276.Reflectance = 0.38
		end
		v226:ScaleTo(0.82)
	end
	v226.Parent = v221
	p220.key = v226
	p220.keyParts = {}
	for _, v277 in v226:GetDescendants() do
		if not v277:IsA("BasePart") then
			continue
		end
		p220.keyParts[v277] = v277.Transparency
		v277.Anchored = true
	end
	v226.Parent = nil
end
function v_u_44._keyShow(p278, p279) -- name: _keyShow
	if p279 and not p278.key.Parent then
		p278.key.Parent = p278.root
	elseif not p279 and p278.key.Parent then
		p278.key.Parent = nil
	end
end
function v_u_44._latchPos(p280, p281) -- name: _latchPos
	local v282 = p280.latches[p281]
	if v282 then
		v282 = p280.latches[p281].part
	end
	if v282 then
		return v282.Position
	end
	local v283 = p280.burstPos
	local v284 = (p281 - 2) * 1.5
	return v283 + Vector3.new(v284, -0.7, -1.2)
end
function v_u_44._emit(p285, p286, p287) -- name: _emit
	p286:Emit(p287)
	p285.emitLog = p285.emitLog or {}
	local v288 = p285.emitLog
	local v289 = {
		["t"] = os.clock(),
		["n"] = p287,
		["life"] = p286.Lifetime.Max
	}
	table.insert(v288, v289)
	if #p285.emitLog > 64 then
		table.remove(p285.emitLog, 1)
	end
end
function v_u_44.liveParticles(p290) -- name: liveParticles
	-- upvalues: (copy) v_u_3
	local v291 = os.clock()
	local v292 = 0
	for _, v293 in p290.emitLog or {} do
		if v291 - v293.t >= v293.life then
			continue
		end
		v292 = v292 + v293.n
	end
	for _, v294 in p290.emitters do
		if v294.Rate <= 0 then
			continue
		end
		v292 = v292 + v294.Rate * v294.Lifetime.Max * 0.6
	end
	p290.peakParticles = v_u_3(p290.peakParticles or 0, v292)
	return v292
end
function v_u_44.fire(p_u_295, p_u_296, p_u_297, p_u_298) -- name: fire
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_1, (copy) v_u_12
	local function v308()
		-- upvalues: (copy) p_u_295, (copy) p_u_296, (ref) v_u_2, (copy) p_u_297, (ref) v_u_4, (ref) v_u_3, (ref) v_u_1, (copy) p_u_298, (ref) v_u_12
		local v299 = p_u_295.L.rate
		if p_u_296 == "latch" then
			local v300 = p_u_295:_latchPos(v_u_2[p_u_297 or 3] or 2)
			p_u_295.fxAnchor.CFrame = CFrame.lookAt(v300, v300 + Vector3.new(0, 0.3, -1))
			p_u_295.latchSparks.Color = ColorSequence.new(p_u_295.seamColor)
			p_u_295:_emit(p_u_295.latchSparks, (v_u_3(2, (v_u_4(6 * v299)))))
			if p_u_295.puff then
				p_u_295:_emit(p_u_295.puff, (v_u_3(1, (v_u_4(2 * v299)))))
			end
			p_u_295.fxAnchor.CFrame = CFrame.new(p_u_295.burstPos)
			return
		elseif p_u_296 == "burst" then
			p_u_295.fxAnchor.CFrame = CFrame.new(p_u_295.burstPos)
			p_u_295.sparks.Color = ColorSequence.new(v_u_1.NEUTRAL)
			p_u_295:_emit(p_u_295.sparks, (v_u_4(70 * v299)))
			if p_u_295.puff then
				p_u_295:_emit(p_u_295.puff, (v_u_3(4, (v_u_4(14 * v299)))))
			end
			p_u_295.shock.Color = ColorSequence.new(v_u_1.NEUTRAL)
			p_u_295:_ring(1, v_u_1.NEUTRAL, 0)
			return
		elseif p_u_296 == "ring" then
			p_u_295:_ring(p_u_297 or 1, p_u_298 or v_u_1.NEUTRAL, 0)
			return
		elseif p_u_296 == "confetti" then
			local v301 = v_u_4((p_u_297 or 40) * v299)
			local v302 = p_u_298 and p_u_298.color or v_u_1.NEUTRAL
			local v303 = { v302, Color3.fromRGB(255, 255, 255), v_u_12(255, 214, 120) }
			local v304 = p_u_298 and p_u_298.extra and { v302, Color3.fromRGB(255, 92, 220), v_u_12(80, 235, 255) } or v303
			local v305 = #p_u_295.confetti
			for v306, v307 in p_u_295.confetti do
				v307.Color = ColorSequence.new(v304[v306] or v302)
				p_u_295:_emit(v307, (v_u_3(1, (v_u_4(v301 / v305)))))
			end
			p_u_295.sparks.Color = ColorSequence.new(v302)
			p_u_295:_emit(p_u_295.sparks, (v_u_3(4, (v_u_4(v301 * 0.3)))))
		elseif p_u_296 == "glitter" then
			p_u_295.sparks.Color = ColorSequence.new(v_u_12(255, 255, 255))
			p_u_295:_emit(p_u_295.sparks, (v_u_4(14 * v299)))
		end
	end
	return pcall(v308)
end
function v_u_44._ring(p309, p310, p311, _) -- name: _ring
	-- upvalues: (copy) v_u_3
	local v312 = p309.fxAnchor
	local v313 = CFrame.new
	local v314 = p309.burstPos
	local v315 = p309.crateTop - 0.65
	v312.CFrame = v313(v314 - Vector3.new(0, v315, 0))
	p309.shock.Color = ColorSequence.new(p311)
	p309:_emit(p309.shock, 1)
	p309.fxAnchor.CFrame = CFrame.new(p309.burstPos)
	local v316 = p309.discs[(p310 - 1) % v_u_3(1, #p309.discs) + 1]
	if v316 then
		v316.t = os.clock()
		v316.color = p311
	end
end
function v_u_44.setWinner(p317, p_u_318, p319, p320) -- name: setWinner
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	p317:clearWinner()
	if not p_u_318 then
		p_u_318 = Instance.new("Model")
		for v321, v322 in {
			["Name"] = "WinnerBlock"
		} do
			p_u_318[v321] = v322
		end
		local v323 = CFrame.new(0, 0, 0)
		local v324 = Enum.Material.SmoothPlastic
		local v325 = Instance.new("Part")
		v325.Name = "Block"
		v325.Anchored = true
		v325.CanCollide = false
		v325.CanQuery = false
		v325.CanTouch = false
		v325.CastShadow = false
		v325.Massless = true
		v325.TopSurface = Enum.SurfaceType.Smooth
		v325.BottomSurface = Enum.SurfaceType.Smooth
		v325.Size = Vector3.new(3.2, 0.7, 0.5)
		v325.CFrame = v323
		v325.Color = p319
		v325.Material = v324
		v325.Transparency = 0
		v325.Parent = p_u_318
		p_u_318.PrimaryPart = v325
	end
	for _, v326 in p_u_318:GetDescendants() do
		if v326:IsA("BasePart") then
			v326.Anchored = true
			v326.CanCollide = false
			v326.CanQuery = false
			v326.CanTouch = false
			v326.CastShadow = false
			v326.Massless = true
		else
			if not (v326:IsA("Script") or (v326:IsA("LocalScript") or v326:IsA("Sound"))) then
				continue
			end
			v326:Destroy()
		end
	end
	local _, v327 = p_u_318:GetBoundingBox()
	local v_u_328 = 3.7 / v_u_3(v_u_3(v327.X, v327.Y, v327.Z), 0.01)
	pcall(function()
		-- upvalues: (copy) p_u_318, (copy) v_u_328
		p_u_318:ScaleTo(v_u_328)
	end)
	local v329, v330 = p_u_318:GetBoundingBox()
	local v331 = p_u_318:GetPivot():ToObjectSpace(v329)
	local v332 = v330.X >= v330.Y and v330.X >= v330.Z and "x" or (v330.Z >= v330.Y and "z" or "y")
	local v333 = v332 == "x" and Vector3.new(1, 0, 0) or (v332 == "y" and Vector3.new(0, 1, 0) or Vector3.new(0, 0, 1))
	local v334 = v331.Position:Dot(v333)
	local v335 = v333 * ((v332 == "z" and v_u_5(v334) < 0.05 and -1 or (v_u_5(v334) < 0.05 and 1 or v334)) < 0 and -1 or 1)
	local v336 = v332 == "y" and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	local v337 = CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.lookAt(Vector3.new(0, 0, 0), v335, v336):Inverse()
	local v338 = {}
	for _, v339 in p_u_318:GetDescendants() do
		if not v339:IsA("BasePart") then
			continue
		end
		local v340 = {
			["Color"] = v339.Color,
			["Material"] = v339.Material
		}
		local v341
		if v339:IsA("MeshPart") then
			v341 = v339.TextureID
		else
			v341 = nil
		end
		v340.TextureID = v341
		v340.Reflectance = v339.Reflectance
		v340.Transparency = v339.Transparency
		v340.Visible = v339.Transparency < 0.99
		v338[v339] = v340
	end
	local v342 = {
		["Name"] = "StageRim",
		["FillTransparency"] = 1,
		["OutlineTransparency"] = 0,
		["OutlineColor"] = nil,
		["DepthMode"] = nil,
		["Enabled"] = false,
		["OutlineColor"] = p319,
		["DepthMode"] = Enum.HighlightDepthMode.Occluded
	}
	local v343 = Instance.new("Highlight")
	for v344, v345 in v342 do
		v343[v344] = v345
	end
	if p_u_318 then
		v343.Parent = p_u_318
	end
	local v346
	if p317.quality == "high" then
		local v347 = p_u_318.PrimaryPart or p_u_318:FindFirstChildWhichIsA("BasePart", true)
		v346 = Instance.new("PointLight")
		for v348, v349 in {
			["Name"] = "WinnerLight",
			["Range"] = 10,
			["Brightness"] = 0,
			["Color"] = nil,
			["Shadows"] = false,
			["Color"] = p319
		} do
			v346[v348] = v349
		end
		if v347 then
			v346.Parent = v347
		end
	else
		v346 = nil
	end
	local v350, v351
	if p317.O and p317.root then
		local v352 = p317.O.Position + Vector3.new(-0.6, 5, -3)
		local v353 = p317.root
		local v354 = CFrame.lookAt(v352, p317.O.Position + Vector3.new(0, 4.3, 0))
		local v355 = Color3.fromRGB(255, 255, 255)
		local v356 = Enum.Material.SmoothPlastic
		v350 = Instance.new("Part")
		v350.Name = "WinnerKeyLight"
		v350.Anchored = true
		v350.CanCollide = false
		v350.CanQuery = false
		v350.CanTouch = false
		v350.CastShadow = false
		v350.Massless = true
		v350.TopSurface = Enum.SurfaceType.Smooth
		v350.BottomSurface = Enum.SurfaceType.Smooth
		v350.Size = Vector3.new(0.2, 0.2, 0.2)
		v350.CFrame = v354
		v350.Color = v355
		v350.Material = v356
		v350.Transparency = 1
		v350.Parent = v353
		local v357 = {
			["Name"] = "WinnerKey",
			["Range"] = 14,
			["Brightness"] = 0,
			["Color"] = nil,
			["Shadows"] = false,
			["Color"] = Color3.fromRGB(255, 244, 226):Lerp(p319, 0.1)
		}
		v351 = Instance.new("PointLight")
		for v358, v359 in v357 do
			v351[v358] = v359
		end
		if v350 then
			v351.Parent = v350
		end
	else
		v351 = nil
		v350 = nil
	end
	local v360 = 0
	local v361 = 0
	for v362, v363 in v338 do
		if not v363.Visible then
			continue
		end
		local v364 = v362.Size
		local v365 = v364.X * v364.Y * v364.Z
		local v366 = v363.Color
		v360 = v360 + (0.2126 * v366.R + 0.7152 * v366.G + 0.0722 * v366.B) * v365
		v361 = v361 + v365
	end
	local v367
	if v361 > 0 then
		v367 = v360 / v361
	else
		v367 = nil
	end
	p317.winner = {
		["model"] = nil,
		["parts"] = nil,
		["hl"] = nil,
		["light"] = nil,
		["key"] = nil,
		["keyPart"] = nil,
		["base"] = nil,
		["off"] = nil,
		["color"] = nil,
		["rarity"] = nil,
		["spin"] = 0,
		["drag"] = 0,
		["sil"] = false,
		["shown"] = false,
		["k"] = 0,
		["lum"] = nil,
		["model"] = p_u_318,
		["parts"] = v338,
		["hl"] = v343,
		["light"] = v346,
		["key"] = v351,
		["keyPart"] = v350,
		["base"] = v337,
		["off"] = v331,
		["color"] = p319,
		["rarity"] = p320,
		["lum"] = v367
	}
	return p_u_318
end
v_u_44.KEY_BRIGHT = 1.2
function v_u_44.clearWinner(p368) -- name: clearWinner
	local v_u_369 = p368.winner
	if v_u_369 then
		pcall(function()
			-- upvalues: (copy) v_u_369
			v_u_369.model:Destroy()
		end)
		if v_u_369.keyPart then
			pcall(function()
				-- upvalues: (copy) v_u_369
				v_u_369.keyPart:Destroy()
			end)
		end
		p368.winner = nil
	end
end
function v_u_44._silhouette(p370, p371) -- name: _silhouette
	local v372 = p370.winner
	if v372 and v372.sil ~= p371 then
		v372.sil = p371
		for v373, v374 in v372.parts do
			if p371 then
				v373.Color = Color3.fromRGB(14, 15, 18)
				v373.Material = Enum.Material.SmoothPlastic
				if v373:IsA("MeshPart") then
					v373.TextureID = ""
				end
				v373.Reflectance = 0
				for _, v375 in v373:GetChildren() do
					if not v375:IsA("SurfaceAppearance") then
						continue
					end
					v375:SetAttribute("StageHidden", true)
					v375.Parent = nil
					v372.sa = v372.sa or {}
					local v376 = v372.sa
					table.insert(v376, { v375, v373 })
				end
			else
				v373.Material = v374.Material
				if v373:IsA("MeshPart") and v374.TextureID then
					v373.TextureID = v374.TextureID
				end
				v373.Reflectance = v374.Reflectance
			end
		end
		if not p371 and v372.sa then
			for _, v_u_377 in v372.sa do
				pcall(function()
					-- upvalues: (copy) v_u_377
					v_u_377[1].Parent = v_u_377[2]
				end)
			end
			v372.sa = nil
		end
		v372.hl.Enabled = p371
	end
end
function v_u_44.winnerUpdate(p378, p379) -- name: winnerUpdate
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_44
	local v_u_380 = p378.winner
	if v_u_380 then
		if p379.show and not v_u_380.shown then
			v_u_380.model.Parent = p378.root
			v_u_380.shown = true
		elseif not p379.show and v_u_380.shown then
			v_u_380.model.Parent = nil
			v_u_380.shown = false
		end
		if v_u_380.shown then
			local v381 = p379.reveal < 0.02
			if v381 ~= v_u_380.sil then
				p378:_silhouette(v381)
			end
			if not v381 then
				local v382 = p379.reveal
				local v383 = v382 < 0 and 0 or (v382 > 1 and 1 or v382)
				for v384, v385 in v_u_380.parts do
					v384.Color = Color3.fromRGB(14, 15, 18):Lerp(v385.Color, v383)
				end
				local v386 = v_u_380.hl
				local v387 = v383 * 1.4
				v386.OutlineTransparency = v387 < 0 and 0 or (v387 > 1 and 1 or v387)
				if v383 >= 1 then
					v_u_380.hl.Enabled = false
				else
					v_u_380.hl.Enabled = true
				end
			end
			local v388 = p379.rise
			local v389 = v388 < 0 and 0 or (v388 > 1 and 1 or v388)
			local v390 = 1 - (1 - v389) * (1 - v389)
			local v391 = p378.crateTop - 0.6
			local v392 = p378.O.Position.Y + 4.3
			local v393 = p378.O.Position.X
			local v394 = v391 + (v392 - v391) * v390 + v_u_6(p379.t * 1.6) * 0.15
			local v395 = p378.O.Position.Z
			local v396 = Vector3.new(v393, v394, v395)
			local v397 = v_u_8(p379.spin or 0)
			local v_u_398 = CFrame.new(v396) * CFrame.Angles(0, v397, 0) * CFrame.Angles(0, 0, (v_u_8(v_u_6(p379.t * 0.9) * 8))) * v_u_380.base
			pcall(function()
				-- upvalues: (copy) v_u_380, (copy) v_u_398
				v_u_380.model:PivotTo(v_u_398 * CFrame.new(-v_u_380.off.Position))
			end)
			local v399
			if v_u_380.lum then
				local v400 = v_u_380.lum
				local v401 = 0.28 / math.max(v400, 0.02)
				v399 = math.clamp(v401, 0.25, 2)
			else
				v399 = 1
			end
			if v_u_380.light then
				v_u_380.light.Brightness = p379.light * 0.55 * math.min(v399, 1)
			end
			if v_u_380.key then
				v_u_380.key.Brightness = p379.light * v_u_44.KEY_BRIGHT * v399
			end
			if v_u_380.hl and not v_u_380.sil then
				local v402
				if v_u_380.lum == nil or v_u_380.lum >= 0.09 then
					v402 = false
				else
					v402 = p379.light > 0.2
				end
				v_u_380.hl.Enabled = v402
				if v402 then
					v_u_380.hl.OutlineTransparency = 0.45
				end
			end
		end
	else
		return
	end
end
function v_u_44.update(p403, p404) -- name: update
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_2, (copy) v_u_17, (copy) v_u_3, (copy) v_u_7, (copy) v_u_6
	if p403.root then
		local v405 = p404.env
		local v406 = p404.glowColor or v_u_1.NEUTRAL
		local v407 = p404.flood or 0
		local v408 = v407 < 0 and 0 or (v407 > 1 and 1 or v407)
		local v409 = p403.seamColor:Lerp(v406, v408 < 0 and 0 or (v408 > 1 and 1 or v408))
		local v410 = p403.coreColor:Lerp(v406, v408 < 0 and 0 or (v408 > 1 and 1 or v408))
		local v411 = v_u_1.NEUTRAL:Lerp(v406, v408 < 0 and 0 or (v408 > 1 and 1 or v408))
		if p404.jitter then
			p403.jittered = true
			p403.crate:PivotTo(p403.crateCF * CFrame.new(p404.jitter.X, p404.jitter.Y, 0))
		elseif p403.jittered then
			p403.jittered = false
			p403.crate:PivotTo(p403.crateCF)
		end
		if p403.hinge and p403.hingeC0 then
			p403.hinge.C0 = p403.hingeC0 * CFrame.Angles(v_u_8(126 * v405.lid * (p403.kit and -1 or 1)), 0, 0)
		end
		if p403.lid and p403.lidColor then
			local v412 = p403.lid
			local v413 = p403.lidColor
			local v414 = Color3.new(0, 0, 0)
			local v415 = v405.lid
			v412.Color = v413:Lerp(v414, (v415 < 0 and 0 or (v415 > 1 and 1 or v415)) * 0.6)
			local v416 = v405.lidfade or 0
			local v417 = v416 < 0 and 0 or (v416 > 1 and 1 or v416)
			if v417 ~= p403.lidFadeNow then
				p403.lidFadeNow = v417
				for _, v418 in p403.lidParts do
					v418.part.Transparency = v418.tr + (1 - v418.tr) * v417
					for _, v419 in v418.part:GetChildren() do
						if not v419:IsA("SurfaceGui") then
							continue
						end
						v419.Enabled = v417 < 0.5
					end
				end
			end
		end
		local v420 = p404.rig
		local v421 = p403.kit and -1 or 1
		for v422 = 1, 3 do
			local v423 = p403.latches[v422]
			if v423 and (v423.weld and v423.c0) then
				local v424
				if v420 then
					v424 = v420.hasp[v422]
				else
					local v425 = (p404.u - p404.latchTimes[v_u_2[v422]]) / 0.22
					local v426 = v425 < 0 and 0 or (v425 > 1 and 1 or v425)
					v424 = (1 - (1 - v426) * (1 - v426)) * 56
				end
				local v427 = (p404.u - p404.burstU) / 0.55
				local v428 = v427 < 0 and 0 or (v427 > 1 and 1 or v427)
				local v429 = v423.po * CFrame.Angles(v_u_8(p403.sgnX * v424), 0, 0) * v423.po:Inverse()
				if v428 > 0 then
					local v430 = ({ -5.5, 3.2, 5.5 })[v422]
					v429 = CFrame.new(v421 * v430 * v428, v428 * 5 - v428 * 9 * v428, v421 * -1.2 * v428) * v429 * CFrame.Angles(v_u_8(v428 * 280), v_u_8(v428 * 160), 0)
				end
				v423.weld.C0 = v423.c0 * v429
				local v431 = v423.part
				local v432 = (v428 - 0.7) / 0.3
				v431.Transparency = v432 < 0 and 0 or (v432 > 1 and 1 or v432)
			end
			local v433 = p403.pins[v422]
			if not (v433 and (v433.weld and (v433.c0 and v420))) then
				continue
			end
			v433.weld.C0 = CFrame.new(0, v420.pin[v422], 0) * v433.c0
		end
		if v420 and (p403.lock.weld and p403.lock.c0) then
			local v434 = v420.lockPos
			local v435 = CFrame.new(v421 * v434.X, v434.Y, v421 * v434.Z) * p403.lock.c0 * CFrame.Angles(v_u_8(-p403.sgnX * v420.lockPitch), 0, 0)
			p403.lock.weld.C0 = v435
			p403.lockC0 = v435
			if p403.shackle.weld and p403.shackle.c0 then
				local v436 = p403.shackle.po
				p403.shackle.weld.C0 = CFrame.new(0, v420.shackleRise, 0) * p403.shackle.c0 * v436 * CFrame.Angles(0, v_u_8(v420.shackleYaw), 0) * v436:Inverse()
			end
			if p403.glow then
				local v437 = p403.glow
				local v438 = v420.glow
				v437.Transparency = 1 - (v438 < 0 and 0 or (v438 > 1 and 1 or v438)) * 0.9
			end
		end
		local v439 = v405.lidfade or 0
		local v440 = v439 < 0 and 0 or (v439 > 1 and 1 or v439)
		if v440 ~= p403.lockFadeNow then
			p403.lockFadeNow = v440
			for _, v441 in p403.lockParts do
				v441.part.Transparency = v441.tr + (1 - v441.tr) * v440
			end
		end
		for _, v442 in p403.seams do
			local v443 = v405.seam
			if not v442 then
				continue
			end
			local v444 = v443 < 0 and 0 or (v443 > 1 and 1 or v443)
			v442.Color = Color3.fromRGB(0, 0, 0):Lerp(v409, v444 * 0.85 + 0.15)
			v442.Transparency = 1 - v444 * 0.92
		end
		if p403.mouth then
			p403.mouth.Color = p403.mouthColor:Lerp(v406, v408 < 0 and 0 or (v408 > 1 and 1 or v408))
			p403.mouth.Transparency = 1 - v405.mouth * 0.9
		end
		if p403.coreLight then
			p403.coreLight.Brightness = v405.core * 1.4
			p403.coreLight.Color = v410
		end
		local v445 = p403.crown
		local v446 = 0.15 + 0.85 * v405.seam
		if v445 then
			local v447 = v446 < 0 and 0 or (v446 > 1 and 1 or v446)
			v445.Color = Color3.fromRGB(0, 0, 0):Lerp(v409, v447 * 0.85 + 0.15)
			v445.Transparency = 1 - v447 * 0.92
		end
		p403.crown.Transparency = 0.35 + (1 - v405.seam) * 0.5
		for v448, v449 in p403.floorRings do
			v449.Color = v409
			v449.Transparency = 1 - (0.35 + 0.5 * v405.wall) * (1 - 0.15 * v448)
		end
		for _, v450 in p403.beams do
			local v451 = NumberSequence.new
			local v452 = 0.035 + 0.02 * v405.wall
			local v453 = v408 * 0.8
			v450.Transparency = v451(1 - v452 * (1 - (v453 < 0 and 0 or (v453 > 1 and 1 or v453))))
			v450.Color = ColorSequence.new(v_u_17(Color3.fromRGB(190, 210, 255), v406, v408))
		end
		local v454 = v405.wall
		for _, v455 in p403.strips do
			v455.Color = Color3.fromRGB(0, 0, 0):Lerp(v409, 0.1 + 0.9 * v454)
			v455.Transparency = 0.2 * (1 - v454)
		end
		local v456 = p404.tier
		local v457 = v456.column - 18
		local v458 = v408 < 0 and 0 or (v408 > 1 and 1 or v408)
		local v459 = (18 + v457 * (v458 * v458 * (3 - v458 * 2))) * v405.column
		local v460 = v405.column
		local v461 = v460 < 0 and 0 or (v460 > 1 and 1 or v460)
		local v462 = v405.colw or 1
		for _, v463 in p403.column do
			local v464 = v_u_3(0.2, v459)
			local v465 = v463.dia * v462
			v463.part.Size = Vector3.new(v464, v465, v465)
			local v466 = v463.part
			local v467 = CFrame.new
			local v468 = p403.burstPos
			local v469 = v464 / 2
			v466.CFrame = v467(v468 + Vector3.new(0, v469, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
			v463.part.Color = v411
			v463.part.Transparency = 1 - (1 - v463.tr) * v461
		end
		if p403.lights.ColumnLight then
			local v470 = p403.lights.ColumnLight
			v470.Brightness = v461 * 0.9
			v470.Color = v411
			local v471 = v470.Parent
			local v472 = CFrame.new
			local v473 = p403.burstPos
			local v474 = 4 + v459 * 0.25
			v471.CFrame = v472(v473 + Vector3.new(0, v474, 0))
		end
		p403.colSparks.Rate = (v461 * 26 + (1 - v461) * v405.charge * 24) * p403.L.rate
		p403.colSparks.Color = ColorSequence.new(v411)
		if #p403.godrays > 0 then
			local v475
			if v456.godray then
				local v476 = p404.godray or 0
				v475 = v476 < 0 and 0 or (v476 > 1 and 1 or v476)
			else
				v475 = 0
			end
			for v477, v478 in p403.godrays do
				local v479 = v477 / #p403.godrays * 2 * 3.141592653589793 + (p404.uWarp or p404.u) * 0.12
				local v480 = CFrame.new
				local v481 = p403.burstPos
				local v482 = v_u_7(v479) * 3.2
				local v483 = v_u_6(v479) * 3.2
				v478.CFrame = v480(v481 + Vector3.new(v482, 15, v483)) * CFrame.Angles(0, -v479, 0)
				v478.Color = v411
				v478.Transparency = 1 - v475 * 0.14
			end
		end
		if p403.lights.FillLight then
			p403.lights.FillLight.Brightness = (1 - v461 * 0.6) * 3
		end
		if p403.lights.FlashLight then
			p403.lights.FlashLight.Brightness = v405.flash * 5
		end
		local v484 = os.clock()
		for _, v485 in p403.discs do
			if not v485.t then
				continue
			end
			local v486 = (v484 - v485.t) / v485.dur
			if v486 >= 1 then
				v485.t = nil
				v485.part.Transparency = 1
			else
				local v487 = v485.maxD - 1
				local v488 = v486 < 0 and 0 or (v486 > 1 and 1 or v486)
				local v489 = 1 + v487 * (1 - (1 - v488) * (1 - v488))
				v485.part.Size = Vector3.new(0.05, v489, v489)
				v485.part.Color = v485.color or v411
				v485.part.Transparency = 0.55 + 0.45 * v486
			end
		end
		p403:liveParticles()
		if p404.key then
			p403:_keyUpdate(p404.key, p404.rig)
		end
	end
end
function v_u_44._keyUpdate(p490, p491, p492) -- name: _keyUpdate
	-- upvalues: (copy) v_u_8
	p490:_keyShow(p491.show)
	if p491.show then
		local v493 = p490.holeRest or p490.burstPos + Vector3.new(0, -0.7, -1.3)
		local v494 = CFrame.new(v493 + (not p492 and Vector3.new(0, 0, 0) or p492.keyOff)) * CFrame.Angles(0, 0, (v_u_8(not p492 and 0 or p492.keyRoll)))
		if p492 and (p490.lockC0 and (p490.lockRestCF and p490.body)) then
			v494 = p490.body.CFrame * p490.lockC0 * p490.lockRestCF:Inverse() * v494
		end
		p490.key:PivotTo(v494)
		local v495 = p491.fade or 0
		if v495 ~= p490.keyFadeNow then
			p490.keyFadeNow = v495
			for v496, v497 in p490.keyParts do
				v496.Transparency = v497 + (1 - v497) * v495
			end
		end
	end
end
function v_u_44.keyTarget(p498) -- name: keyTarget
	return p498.holeRest or p498.burstPos + Vector3.new(0, -0.7, -1.3)
end
function v_u_44.counts(p499) -- name: counts
	-- upvalues: (copy) v_u_4
	local v500 = {
		["parts"] = 0,
		["lights"] = 0,
		["emitters"] = 0,
		["highlights"] = 0,
		["descendants"] = 0,
		["particles"] = nil,
		["particles"] = v_u_4(p499.peakParticles or 0)
	}
	for _, v501 in p499.root:GetDescendants() do
		v500.descendants = v500.descendants + 1
		if v501:IsA("BasePart") then
			v500.parts = v500.parts + 1
		elseif v501:IsA("Light") then
			v500.lights = v500.lights + 1
		elseif v501:IsA("ParticleEmitter") then
			v500.emitters = v500.emitters + 1
		else
			if not v501:IsA("Highlight") then
				continue
			end
			v500.highlights = v500.highlights + 1
		end
	end
	if p499.winner then
		for _, v502 in p499.winner.model:GetDescendants() do
			if not v502:IsA("Highlight") then
				continue
			end
			v500.highlights = v500.highlights + 1
		end
	end
	return v500
end
function v_u_44.parent(p503, p504) -- name: parent
	p503.root.Parent = p504
end
function v_u_44.destroy(p_u_505) -- name: destroy
	if p_u_505.root then
		pcall(function()
			-- upvalues: (copy) p_u_505
			p_u_505.root:Destroy()
		end)
	end
	p_u_505.root = nil
	p_u_505.winner = nil
end
return v_u_1