-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanShopModel

local v_u_14 = {
	["catalog"] = nil,
	["style"] = nil,
	["timeText"] = function(p1)
		local v2 = tonumber(p1) or 0
		local v3 = math.floor(v2)
		local v4 = math.max(0, v3)
		local v5 = v4 / 86400
		local v6 = math.floor(v5)
		local v7 = v4 % 86400 / 3600
		local v8 = math.floor(v7)
		local v9 = v4 % 3600 / 60
		local v10 = math.floor(v9)
		if v6 > 0 then
			return ("%dd %dh"):format(v6, v8)
		elseif v8 > 0 then
			return ("%dh %dm"):format(v8, v10)
		else
			return ("%dm"):format(v10)
		end
	end,
	["bind"] = function(p11, p12, p13) -- name: bind
		-- upvalues: (copy) v_u_14
		v_u_14.catalog = p11
		v_u_14.style = p12
		if type(p13) == "function" then
			v_u_14.timeText = p13
		end
	end,
	["TEXT"] = {
		["SHOP_OWNED"] = "Your clan already owns this.",
		["SHOP_COINS"] = "Your clan does not have enough coins.",
		["SHOP_PTS"] = "Your clan needs more clan points first.",
		["SHOP_MAX"] = "Your clan is at the maximum size.",
		["SHOP_LOCKED"] = "This is not available yet.",
		["dup"] = "Your clan already has this.",
		["dead"] = "This clan is closing."
	},
	["UI"] = {
		["ASK_OFFICER"] = "Ask an officer",
		["TERMINAL_ROBUX"] = "Open the main menu to buy with Robux.",
		["PENDING"] = "Delivery in progress. This can take a minute.",
		["OWNED"] = "Owned",
		["EQUIPPED"] = "Equipped",
		["MEDAL"] = "Earned by the top 3 clans each week.",
		["NEEDS_EMBLEM"] = "Needs an emblem pack first",
		["NEEDS_OTHER"] = "Needs another item first",
		["ROBUX_SOON"] = "Robux purchase is not available yet.",
		["MAX_SIZE"] = "Your clan is at the maximum size.",
		["LOADING"] = "Loading the shop...",
		["LOAD_RETRY"] = "Could not load the shop. Retrying...",
		["LOAD_FAIL"] = "Could not load the shop. Please try again.",
		["NO_CLAN"] = "Join a clan to see its shop.",
		["EMPTY_CAT"] = "Nothing to show in this category yet.",
		["FOOTER"] = "CLAN POINTS count what your clan earned in all weeks and are never spent. CLAN COINS are paid out every week and are spent here. See the LOG for purchases.",
		["AFTER_PAYOUT"] = "Available after the next weekly payout",
		["PREVIEW"] = "PREVIEW",
		["DONE"] = "Done."
	},
	["SWATCH_WORD"] = {
		["tc"] = "COLOR",
		["ts"] = "SHAPE",
		["em"] = "EMBLEM",
		["pl"] = "PLATE",
		["kf"] = "FRAME",
		["wm"] = "MARK",
		["bn"] = "BANNER",
		["bt"] = "TRIM",
		["fx"] = "EXTRA",
		["bd"] = "MEDAL",
		["ex"] = "SLOTS",
		["st"] = "STASH"
	},
	["EXPAND_STEP"] = 10,
	["FAKE_TIERS"] = {
		{
			["pts"] = 40000,
			["coins"] = 8000,
			["robux"] = 599
		},
		{
			["pts"] = 120000,
			["coins"] = 20000,
			["robux"] = 999
		},
		{
			["pts"] = 300000,
			["coins"] = 40000,
			["robux"] = 1499
		}
	},
	["BASE_CAP"] = 30
}
local function v_u_25(p15) -- name: commas
	local v16 = tonumber(p15) or 0
	local v17 = math.floor(v16)
	local v18 = v17 < 0
	local v19 = math.abs(v17)
	local v20 = tostring(v19)
	local v21 = #v20
	local v22 = ""
	for v23 = 1, v21 do
		v22 = v22 .. string.sub(v20, v23, v23)
		local v24 = v21 - v23
		if v24 <= 0 or v24 % 3 ~= 0 then
			continue
		end
		v22 = v22 .. ","
	end
	return (v18 and "-" or "") .. v22
end
v_u_14.commas = v_u_25
local function v_u_30(p26) -- name: deep
	-- upvalues: (copy) v_u_30
	if type(p26) ~= "table" then
		return p26
	end
	local v27 = {}
	for v28, v29 in p26 do
		v27[v28] = v_u_30(v29)
	end
	return v27
end
function v_u_14.norm(p31) -- name: norm
	-- upvalues: (copy) v_u_14
	local v32 = type(p31) ~= "table" and {} or p31
	local v33 = v32.next
	local v34
	if type(v33) == "table" then
		v34 = {}
		local v35 = v32.next.pts
		local v36 = tonumber(v35)
		v34.pts = (v36 == nil or (v36 ~= v36 or (v36 == (1 / 0) or v36 == (-1 / 0)))) and 0 or v36
		local v37 = v32.next.coins
		local v38 = tonumber(v37)
		v34.coins = (v38 == nil or (v38 ~= v38 or (v38 == (1 / 0) or v38 == (-1 / 0)))) and 0 or v38
		local v39 = v32.next.robux
		local v40 = tonumber(v39)
		v34.robux = (v40 == nil or (v40 ~= v40 or (v40 == (1 / 0) or v40 == (-1 / 0)))) and 0 or v40
		v34.ok = v32.next.ok == true
	else
		v34 = nil
	end
	local v41 = v32.can
	local v42 = type(v41) ~= "table" and {} or v32.can
	local v43 = v32.rbx
	local v44 = type(v43) ~= "table" and {} or v32.rbx
	local v45 = {}
	local v46 = v44.items
	if type(v46) == "table" then
		for v47, v48 in v44.items do
			v45[tostring(v47)] = v48 ~= false
		end
	end
	local v49 = v32.week
	local v50 = type(v49) ~= "table" and {} or v32.week
	local v51 = v32.lp
	local v52
	if type(v51) == "table" then
		v52 = {}
		local v53 = v32.lp.w
		local v54 = tonumber(v53)
		v52.w = (v54 == nil or (v54 ~= v54 or (v54 == (1 / 0) or v54 == (-1 / 0)))) and 0 or v54
		local v55 = v32.lp.p
		local v56 = tonumber(v55)
		v52.p = (v56 == nil or (v56 ~= v56 or (v56 == (1 / 0) or v56 == (-1 / 0)))) and 0 or v56
		local v57 = v32.lp.c
		local v58 = tonumber(v57)
		v52.c = (v58 == nil or (v58 ~= v58 or (v58 == (1 / 0) or v58 == (-1 / 0)))) and 0 or v58
		local v59 = v32.lp.r
		local v60 = tonumber(v59)
		v52.r = (v60 == nil or (v60 ~= v60 or (v60 == (1 / 0) or v60 == (-1 / 0)))) and 0 or v60
	else
		v52 = nil
	end
	local v61 = nil
	local v62 = v32.bd
	if type(v62) == "table" then
		local v63 = v32.bd.r
		if tonumber(v63) ~= nil then
			v61 = {}
			local v64 = v32.bd.w
			local v65 = tonumber(v64)
			v61.w = (v65 == nil or (v65 ~= v65 or (v65 == (1 / 0) or v65 == (-1 / 0)))) and 0 or v65
			local v66 = v32.bd.r
			local v67 = tonumber(v66)
			local v68 = (v67 == nil or (v67 ~= v67 or (v67 == (1 / 0) or v67 == (-1 / 0)))) and 0 or v67
			v61.r = math.floor(v68)
		end
	end
	local v69 = {}
	local v70 = v32.own
	if type(v70) == "table" then
		for v71, v72 in v32.own do
			if v72 ~= 1 and v72 ~= true then
				continue
			end
			v69[tostring(v71)] = 1
		end
	end
	local v73 = {}
	local v74 = v32.eq
	if type(v74) == "table" then
		for v75, v76 in v32.eq do
			if type(v76) ~= "string" or v76 == "" then
				continue
			end
			v73[tostring(v75)] = v76
		end
	end
	local v77 = {}
	local v78 = v32.credits
	if type(v78) == "table" then
		for v79, v80 in v32.credits do
			local v81 = tostring(v79)
			local v82 = tonumber(v80)
			local v83 = (v82 == nil or (v82 ~= v82 or (v82 == (1 / 0) or v82 == (-1 / 0)))) and 0 or v82
			local v84 = math.floor(v83)
			v77[v81] = math.max(0, v84)
		end
	end
	local v85 = {}
	local v86 = v32.pend
	if type(v86) == "table" then
		for v87, v88 in v32.pend do
			if type(v87) == "string" and v88 == true then
				v85[v87] = true
			else
				if type(v88) ~= "string" then
					continue
				end
				v85[v88] = true
			end
		end
	end
	local v89 = {
		["v"] = 1,
		["pts"] = nil,
		["ptsWeek"] = nil,
		["coins"] = nil,
		["xt"] = nil,
		["cap"] = nil,
		["next"] = nil,
		["own"] = nil,
		["eq"] = nil,
		["lp"] = nil,
		["bd"] = nil,
		["can"] = nil,
		["rbx"] = nil,
		["credits"] = nil,
		["pending"] = nil,
		["pend"] = nil,
		["week"] = nil,
		["release"] = nil
	}
	local v90 = v32.pts
	local v91 = tonumber(v90)
	local v92 = (v91 == nil or (v91 ~= v91 or (v91 == (1 / 0) or v91 == (-1 / 0)))) and 0 or v91
	v89.pts = math.max(0, v92)
	local v93 = v32.ptsWeek
	local v94 = tonumber(v93)
	local v95 = (v94 == nil or (v94 ~= v94 or (v94 == (1 / 0) or v94 == (-1 / 0)))) and 0 or v94
	v89.ptsWeek = math.max(0, v95)
	local v96 = v32.coins
	local v97 = tonumber(v96)
	local v98 = (v97 == nil or (v97 ~= v97 or (v97 == (1 / 0) or v97 == (-1 / 0)))) and 0 or v97
	v89.coins = math.max(0, v98)
	local v99 = v32.xt
	local v100 = tonumber(v99)
	local v101 = (v100 == nil or (v100 ~= v100 or (v100 == (1 / 0) or v100 == (-1 / 0)))) and 0 or v100
	local v102 = math.floor(v101)
	local v103 = math.min(3, v102)
	v89.xt = math.max(0, v103)
	local v104 = 1
	local v105 = v32.cap
	local v106 = v_u_14.BASE_CAP
	local v107 = tonumber(v105)
	if v107 == nil or (v107 ~= v107 or (v107 == (1 / 0) or v107 == (-1 / 0))) then
		v107 = v106
	end
	local v108 = math.floor(v107)
	v89.cap = math.max(v104, v108)
	v89.next = v34
	v89.own = v69
	v89.eq = v73
	v89.lp = v52
	v89.bd = v61
	v89.can = {
		["spend"] = v42.spend == true,
		["robux"] = v42.robux ~= false
	}
	v89.rbx = {
		["on"] = v44.on ~= false,
		["items"] = v45
	}
	v89.credits = v77
	local v109 = v32.pending
	local v110 = tonumber(v109)
	local v111 = (v110 == nil or (v110 ~= v110 or (v110 == (1 / 0) or v110 == (-1 / 0)))) and 0 or v110
	local v112 = math.floor(v111)
	v89.pending = math.max(0, v112)
	v89.pend = v85
	local v113 = {}
	local v114 = v50.reset
	local v115 = tonumber(v114)
	local v116 = (v115 == nil or (v115 ~= v115 or (v115 == (1 / 0) or v115 == (-1 / 0)))) and 0 or v115
	v113.reset = math.max(0, v116)
	v89.week = v113
	local v117 = v32.release
	local v118
	if tonumber(v117) then
		local v119 = v32.release
		local v120 = tonumber(v119)
		v118 = math.floor(v120)
	else
		v118 = nil
	end
	v89.release = v118
	return v89
end
function v_u_14.categories() -- name: categories
	-- upvalues: (copy) v_u_14
	local v121 = {
		{
			["id"] = "all",
			["text"] = "ALL"
		}
	}
	local v122 = v_u_14.catalog
	if v122 then
		for _, v123 in v122.CATEGORIES do
			local v124 = {
				["id"] = v123.id,
				["text"] = v123.name
			}
			table.insert(v121, v124)
		end
	end
	return v121
end
function v_u_14.equippable(p125) -- name: equippable
	-- upvalues: (copy) v_u_14
	local v126 = v_u_14.catalog
	if not v126 or type(p125) ~= "table" then
		return false
	end
	for _, v127 in v126.SLOTS do
		if v127 ~= p125.slot then
			continue
		end
		return true
	end
	return false
end
function v_u_14.expandEntry(p128) -- name: expandEntry
	-- upvalues: (copy) v_u_14
	local v129 = v_u_14.catalog
	if p128.xt >= 3 then
		return {
			["id"] = "expand",
			["max"] = true
		}
	end
	local v130 = {
		["id"] = "expand",
		["row"] = nil,
		["level"] = nil
	}
	local v131 = v129.get
	local v132 = p128.xt + 1
	v130.row = v131("ex_" .. tostring(v132))
	v130.level = p128.xt + 1
	return v130
end
function v_u_14.visible(p133, p134) -- name: visible
	-- upvalues: (copy) v_u_14
	local v135 = v_u_14.catalog
	local v136 = {}
	if not v135 then
		return v136
	end
	for _, v137 in v135.ITEMS do
		if v137.slot == "ex" or (not v135.live(v137.id, p133.release) or p134 ~= "all" and v137.cat ~= p134) then
			continue
		end
		local v138 = {
			["id"] = v137.id,
			["row"] = v137
		}
		table.insert(v136, v138)
	end
	if p134 == "all" or p134 == "slots" then
		local v139 = v_u_14.expandEntry
		table.insert(v136, v139(p133))
	end
	return v136
end
function v_u_14.expandReason(p140) -- name: expandReason
	-- upvalues: (copy) v_u_25, (copy) v_u_14
	local v141 = p140.next
	if v141 == nil or v141.ok then
		return ""
	else
		local v142 = v141.pts - p140.pts - p140.ptsWeek
		if v142 > 0 then
			return ("Needs %s more clan points"):format((v_u_25(v142)))
		else
			return v_u_14.UI.AFTER_PAYOUT
		end
	end
end
function v_u_14.cardState(p143, p144, p145) -- name: cardState
	-- upvalues: (copy) v_u_14, (copy) v_u_25
	local v146 = v_u_14.catalog
	local v147 = type(p145) ~= "table" and {} or p145
	local v148 = v147.awaiting or {}
	local v149 = {
		["id"] = nil,
		["kind"] = "item",
		["note"] = "",
		["noteKind"] = "info",
		["owned"] = false,
		["equipped"] = false,
		["variant"] = 1,
		["id"] = p143.id
	}
	if p143.max then
		v149.kind = "max"
		v149.note = v_u_14.UI.MAX_SIZE
		v149.noteKind = "success"
		return v149
	end
	local v150 = p143.row
	if v150 == nil then
		v149.kind = "max"
		return v149
	end
	v149.row = v150
	local v151 = p144.can.spend
	local v152 = p144.own[v150.id] == 1
	local v153, v154 = v146.splitEq(p144.eq[v150.slot])
	v149.owned = v152
	local v155
	if v152 then
		v155 = v153 == v150.id
	else
		v155 = v152
	end
	v149.equipped = v155
	local v156 = (v147.variants or {})[v150.id]
	local v157 = tonumber(v156)
	local v158 = v157 == nil and (v149.equipped and v154 and v154 or 1) or v157
	local v159 = v150.variants
	local v160 = math.floor(v158)
	local v161 = math.min(v159, v160)
	v149.variant = math.max(1, v161)
	v149.varName = v150.varNames[v149.variant]
	local v162 = v149.equipped
	if v162 then
		v162 = v154 == v149.variant
	end
	v149.same = v162
	local v163 = v148[v150.id] == true and true or p144.pend[v150.id] == true
	if v150.earned then
		v149.kind = "medal"
		local v164
		if p144.bd == nil or p144.bd.r < 1 then
			v164 = false
		else
			v164 = p144.bd.r <= 3
		end
		v149.owned = v164
		local v165
		if v149.owned then
			v165 = ("Your clan holds the medal for place %d."):format(p144.bd.r)
		else
			v165 = v_u_14.UI.MEDAL
		end
		v149.note = v165
		v149.noteKind = v149.owned and "success" or "info"
		return v149
	end
	if v150.slot == "ex" then
		v149.kind = "expand"
		local v166 = p144.next
		local v167
		if v166 then
			v167 = v166.pts
		else
			v167 = (v_u_14.FAKE_TIERS[p143.level or 1] or v_u_14.FAKE_TIERS[1]).pts
		end
		local v168
		if v166 and v166.coins > 0 then
			v168 = v166.coins
		else
			v168 = v150.coins
		end
		local v169
		if v166 and v166.robux > 0 then
			v169 = v166.robux
		else
			v169 = v150.robux
		end
		local v170 = p144.pts + p144.ptsWeek
		local v171 = {}
		local v172
		if v167 > 0 then
			local v173 = v170 / v167
			local v174 = math.min(1, v173)
			v172 = math.max(0, v174)
		else
			v172 = 1
		end
		v171.value = v172
		v171.text = ("%s / %s CLAN POINTS"):format(v_u_25((math.min(v170, v167))), (v_u_25(v167)))
		v149.bar = v171
		v149.conseq = ("%d to %d members"):format(p144.cap, v150.slots or p144.cap + v_u_14.EXPAND_STEP)
		local v175
		if v166 == nil then
			v175 = false
		else
			v175 = v166.ok == true
		end
		v149.price = v168
		v149.robuxPrice = v169
		if v163 then
			v149.pending = {
				["text"] = "PENDING",
				["enabled"] = false
			}
			v149.note = v_u_14.UI.PENDING
			return v149
		end
		local v176 = ""
		if v175 then
			if v151 then
				if p144.coins < v168 then
					v176 = ("Needs %s more coins"):format((v_u_25(v168 - p144.coins)))
				end
			else
				v176 = v_u_14.UI.ASK_OFFICER
			end
		else
			v176 = v_u_14.expandReason(p144)
		end
		v149.coin = {
			["text"] = v_u_25(v168) .. " COINS",
			["enabled"] = v176 == "",
			["reason"] = v176
		}
		local v177 = v146.slotsProductOf(v150.xt)
		if (v177 and (p144.credits[v177] or 0) or 0) > 0 then
			v149.credit = {
				["text"] = "USE CREDIT",
				["enabled"] = nil,
				["enabled"] = v175
			}
		elseif p144.rbx.on and (not v147.terminal and v150.xt) then
			local v178 = {
				["text"] = "R$ " .. v_u_25(v169)
			}
			if v175 then
				local v179 = v150.xt
				local v180 = "s" .. tostring(v179)
				v175 = p144.rbx.items[tostring(v180)] ~= false
				if v175 then
					v175 = p144.can.robux
				end
			end
			v178.enabled = v175
			v149.robux = v178
		end
		if v147.terminal then
			v149.terminal = true
		end
		v149.note = v176
		v149.noteKind = "warn"
		return v149
	end
	v149.price = v150.coins
	if v163 and not v152 then
		v149.pending = {
			["text"] = "PENDING",
			["enabled"] = false
		}
		v149.note = v_u_14.UI.PENDING
		return v149
	end
	if v152 then
		if v_u_14.equippable(v150) then
			local v181 = v151 and "" or v_u_14.UI.ASK_OFFICER
			v149.equip = {
				["text"] = v149.same and "UNEQUIP" or "EQUIP",
				["off"] = v149.same,
				["enabled"] = v151,
				["reason"] = v181
			}
			local v182
			if v149.equipped then
				v182 = v_u_14.UI.EQUIPPED
			else
				v182 = v_u_14.UI.OWNED
			end
			v149.note = v182
			v149.noteKind = v149.equipped and "success" or "info"
			if v181 ~= "" then
				v149.note = v181
				v149.noteKind = "warn"
				return v149
			end
		else
			v149.note = v_u_14.UI.OWNED
			v149.noteKind = "success"
		end
		return v149
	end
	local v183 = v146.needsMet(p144.own, v150.id)
	local v184 = ""
	local v185, v186, v187, v188, v189, v190
	if v183 then
		if v151 then
			if p144.coins < v150.coins then
				v184 = ("Needs %s more coins"):format((v_u_25(v150.coins - p144.coins)))
			end
		else
			v184 = v_u_14.UI.ASK_OFFICER
		end
		if v146.buyableWithCoins(v150.id) then
			v149.coin = {
				["text"] = v_u_25(v150.coins) .. " COINS",
				["enabled"] = v184 == "",
				["reason"] = v184
			}
		end
		v185 = v146.productOf(v150.tier)
		if (v185 and (p144.credits[v185] or 0) or 0) > 0 then
			v149.credit = {
				["text"] = "USE CREDIT",
				["enabled"] = nil,
				["enabled"] = v183
			}
		elseif v150.tier >= 1 and p144.rbx.on then
			if v147.terminal then
				v149.terminal = true
			else
				v186 = v146.robuxOf(v150.id)
				if v186 then
					v187 = {
						["text"] = "R$ " .. v_u_25(v186)
					}
					if v183 then
						v188 = v150.tier
						v189 = p144.rbx.items[tostring(v188)] ~= false
						if v189 then
							v189 = p144.can.robux
						end
					else
						v189 = v183
					end
					v187.enabled = v189
					v149.robux = v187
					if v183 then
						v190 = v150.tier
						if p144.rbx.items[tostring(v190)] == false and v184 == "" then
							v184 = v_u_14.UI.ROBUX_SOON
						end
					end
				end
			end
		end
		v149.note = v184
		v149.noteKind = "warn"
		return v149
	else
		local v191 = v150.needs
		if type(v191) == "table" then
			local v192 = v150.needs[1]
			if type(v192) == "string" then
				local v193 = v150.needs[1]
				if string.sub(v193, 1, 3) == "em_" then
					v184 = v_u_14.UI.NEEDS_EMBLEM
					if v146.buyableWithCoins(v150.id) then
						v149.coin = {
							["text"] = v_u_25(v150.coins) .. " COINS",
							["enabled"] = v184 == "",
							["reason"] = v184
						}
					end
					v185 = v146.productOf(v150.tier)
					if (v185 and (p144.credits[v185] or 0) or 0) > 0 then
						v149.credit = {
							["text"] = "USE CREDIT",
							["enabled"] = nil,
							["enabled"] = v183
						}
					elseif v150.tier >= 1 and p144.rbx.on then
						if v147.terminal then
							v149.terminal = true
						else
							v186 = v146.robuxOf(v150.id)
							if v186 then
								v187 = {
									["text"] = "R$ " .. v_u_25(v186)
								}
								if v183 then
									v188 = v150.tier
									v189 = p144.rbx.items[tostring(v188)] ~= false
									if v189 then
										v189 = p144.can.robux
									end
								else
									v189 = v183
								end
								v187.enabled = v189
								v149.robux = v187
								if v183 then
									v190 = v150.tier
									if p144.rbx.items[tostring(v190)] == false and v184 == "" then
										v184 = v_u_14.UI.ROBUX_SOON
									end
								end
							end
						end
					end
					v149.note = v184
					v149.noteKind = "warn"
					return v149
				else
					v184 = v_u_14.UI.NEEDS_OTHER
					if v146.buyableWithCoins(v150.id) then
						v149.coin = {
							["text"] = v_u_25(v150.coins) .. " COINS",
							["enabled"] = v184 == "",
							["reason"] = v184
						}
					end
					v185 = v146.productOf(v150.tier)
					if (v185 and (p144.credits[v185] or 0) or 0) > 0 then
						v149.credit = {
							["text"] = "USE CREDIT",
							["enabled"] = nil,
							["enabled"] = v183
						}
					elseif v150.tier >= 1 and p144.rbx.on then
						if v147.terminal then
							v149.terminal = true
						else
							v186 = v146.robuxOf(v150.id)
							if v186 then
								v187 = {
									["text"] = "R$ " .. v_u_25(v186)
								}
								if v183 then
									v188 = v150.tier
									v189 = p144.rbx.items[tostring(v188)] ~= false
									if v189 then
										v189 = p144.can.robux
									end
								else
									v189 = v183
								end
								v187.enabled = v189
								v149.robux = v187
								if v183 then
									v190 = v150.tier
									if p144.rbx.items[tostring(v190)] == false and v184 == "" then
										v184 = v_u_14.UI.ROBUX_SOON
									end
								end
							end
						end
					end
					v149.note = v184
					v149.noteKind = "warn"
					return v149
				end
			else
				v184 = v_u_14.UI.NEEDS_OTHER
				if v146.buyableWithCoins(v150.id) then
					v149.coin = {
						["text"] = v_u_25(v150.coins) .. " COINS",
						["enabled"] = v184 == "",
						["reason"] = v184
					}
				end
				v185 = v146.productOf(v150.tier)
				if (v185 and (p144.credits[v185] or 0) or 0) > 0 then
					v149.credit = {
						["text"] = "USE CREDIT",
						["enabled"] = nil,
						["enabled"] = v183
					}
				elseif v150.tier >= 1 and p144.rbx.on then
					if v147.terminal then
						v149.terminal = true
					else
						v186 = v146.robuxOf(v150.id)
						if v186 then
							v187 = {
								["text"] = "R$ " .. v_u_25(v186)
							}
							if v183 then
								v188 = v150.tier
								v189 = p144.rbx.items[tostring(v188)] ~= false
								if v189 then
									v189 = p144.can.robux
								end
							else
								v189 = v183
							end
							v187.enabled = v189
							v149.robux = v187
							if v183 then
								v190 = v150.tier
								if p144.rbx.items[tostring(v190)] == false and v184 == "" then
									v184 = v_u_14.UI.ROBUX_SOON
								end
							end
						end
					end
				end
				v149.note = v184
				v149.noteKind = "warn"
				return v149
			end
		else
			v184 = v_u_14.UI.NEEDS_OTHER
			if v146.buyableWithCoins(v150.id) then
				v149.coin = {
					["text"] = v_u_25(v150.coins) .. " COINS",
					["enabled"] = v184 == "",
					["reason"] = v184
				}
			end
			v185 = v146.productOf(v150.tier)
			if (v185 and (p144.credits[v185] or 0) or 0) > 0 then
				v149.credit = {
					["text"] = "USE CREDIT",
					["enabled"] = nil,
					["enabled"] = v183
				}
			elseif v150.tier >= 1 and p144.rbx.on then
				if v147.terminal then
					v149.terminal = true
				else
					v186 = v146.robuxOf(v150.id)
					if v186 then
						v187 = {
							["text"] = "R$ " .. v_u_25(v186)
						}
						if v183 then
							v188 = v150.tier
							v189 = p144.rbx.items[tostring(v188)] ~= false
							if v189 then
								v189 = p144.can.robux
							end
						else
							v189 = v183
						end
						v187.enabled = v189
						v149.robux = v187
						if v183 then
							v190 = v150.tier
							if p144.rbx.items[tostring(v190)] == false and v184 == "" then
								v184 = v_u_14.UI.ROBUX_SOON
							end
						end
					end
				end
			end
			v149.note = v184
			v149.noteKind = "warn"
			return v149
		end
	end
end
function v_u_14.head(p194) -- name: head
	-- upvalues: (copy) v_u_25, (copy) v_u_14
	local v195 = p194.next
	local v196 = {
		["coins"] = v_u_25(p194.coins),
		["payout"] = v_u_14.timeText(p194.week.reset)
	}
	if v195 then
		local v197 = p194.pts + p194.ptsWeek
		local v198 = v_u_25
		local v199 = v195.pts
		v196.pts = ("%s / %s"):format(v198((math.min(v197, v199))), (v_u_25(v195.pts)))
		local v200
		if v195.pts > 0 then
			local v201 = v197 / v195.pts
			local v202 = math.min(1, v201)
			v200 = math.max(0, v202)
		else
			v200 = 1
		end
		v196.bar = v200
	else
		v196.pts = v_u_25(p194.pts + p194.ptsWeek)
		v196.bar = 1
	end
	if p194.lp and p194.lp.c > 0 then
		v196.last = ("+%s coins"):format((v_u_25(p194.lp.c)))
	end
	return v196
end
function v_u_14.previewShop(p203, p204) -- name: previewShop
	-- upvalues: (copy) v_u_14
	local v205 = p203.own
	local v206 = {}
	if type(v205) == "table" then
		for v207, v208 in v205 do
			v206[tostring(v207)] = v208
		end
	end
	local v209 = p203.eq
	local v210 = {}
	if type(v209) == "table" then
		for v211, v212 in v209 do
			v210[tostring(v211)] = v212
		end
	end
	if type(p204) == "table" then
		local v213 = p204.item
		if type(v213) == "string" then
			local v214 = v_u_14.catalog.get(p204.item)
			if v214 and v_u_14.equippable(v214) then
				v206[v214.id] = 1
				local v215 = v214.slot
				local v216 = v214.variants
				local v217 = p204.variant
				local v218 = tonumber(v217) or 1
				local v219 = math.floor(v218)
				local v220 = math.min(v216, v219)
				local v221 = math.max(1, v220)
				v210[v215] = v214.id .. ":" .. tostring(v221)
			end
		end
	end
	return {
		["own"] = v206,
		["eq"] = v210,
		["bd"] = p203.bd
	}
end
function v_u_14.styleOf(p222, p223) -- name: styleOf
	-- upvalues: (copy) v_u_14
	local v224 = v_u_14.style
	if not v224 then
		return nil
	end
	local v225 = v224.encode(v_u_14.previewShop(p222, p223))
	if v225 == "" and p223 ~= nil then
		v225 = v224.encode(v_u_14.previewShop(p222, nil))
	end
	return v224.parse(v225)
end
function v_u_14.swatch(p226, p227) -- name: swatch
	-- upvalues: (copy) v_u_14
	local v228 = v_u_14.style
	local v229 = {
		["word"] = v_u_14.SWATCH_WORD[p226.slot] or "ITEM",
		["brackets"] = { "[", "]" }
	}
	if not (v228 and v_u_14.equippable(p226)) then
		return v229
	end
	local v230 = p226.variants
	local v231 = math.floor(p227)
	local v232 = math.min(v230, v231)
	local v233 = math.max(1, v232)
	local v234 = {
		["own"] = {
			[p226.id] = 1
		},
		["eq"] = {
			[p226.slot] = p226.id .. ":" .. tostring(v233)
		}
	}
	local v235 = v228.parse(v228.encode(v234))
	if v235 then
		v229.style = v235
		v229.colors = v235.color
		v229.brackets = v235.brackets or v229.brackets
	end
	return v229
end
function v_u_14.equipSet(p236, p237, p238, p239) -- name: equipSet
	local v240 = p236.eq
	local v241 = {}
	if type(v240) == "table" then
		for v242, v243 in v240 do
			v241[tostring(v242)] = v243
		end
	end
	if p239 then
		v241[p237.slot] = nil
		return v241
	end
	local v244 = p237.slot
	local v245 = p237.variants
	local v246 = math.floor(p238)
	local v247 = math.min(v245, v246)
	local v248 = math.max(1, v247)
	v241[v244] = p237.id .. ":" .. tostring(v248)
	return v241
end
function v_u_14.confirm(p249, p250, p251, p252) -- name: confirm
	-- upvalues: (copy) v_u_14, (copy) v_u_25
	local v253 = p251.row
	local v254 = not v253 and "" or v253.name
	if p251.id ~= "expand" or not v253 then
		return p249 == "robux" and {
			["title"] = "BUY WITH ROBUX",
			["yes"] = "CONTINUE",
			["body"] = nil,
			["body"] = ("Buy %s for [%s] with Robux? It costs R$ %s and belongs to the whole clan. This cannot be undone."):format(v254, p252, (v_u_25(v_u_14.catalog.robuxOf(v253.id) or 0)))
		} or (p249 == "credit" and {
			["title"] = "USE CREDIT",
			["yes"] = "USE CREDIT",
			["body"] = nil,
			["body"] = ("Use your credit for %s? The clan gets it. This cannot be undone."):format(v254)
		} or {
			["title"] = "BUY ITEM",
			["yes"] = "BUY",
			["body"] = nil,
			["body"] = ("Buy %s for [%s]? %s coins. Everyone in the clan will see it. This cannot be undone."):format(v254, p252, (v_u_25(v253.coins)))
		})
	end
	local v255 = p250.cap
	local v256 = v253.slots or p250.cap + v_u_14.EXPAND_STEP
	local v257 = p250.next
	if p249 == "robux" then
		local v258
		if v257 and v257.robux > 0 then
			v258 = v257.robux
		else
			v258 = v253.robux
		end
		return {
			["title"] = "EXPAND CLAN",
			["yes"] = "EXPAND",
			["body"] = nil,
			["body"] = ("Expand [%s] from %d to %d members for R$ %s? Everyone in the clan can use the new slots. This cannot be undone."):format(p252, v255, v256, (v_u_25(v258)))
		}
	end
	if p249 == "credit" then
		return {
			["title"] = "EXPAND CLAN",
			["yes"] = "USE CREDIT",
			["body"] = nil,
			["body"] = ("Use your credit to expand [%s] from %d to %d members? Everyone in the clan can use the new slots. This cannot be undone."):format(p252, v255, v256)
		}
	end
	local v259
	if v257 and v257.coins > 0 then
		v259 = v257.coins
	else
		v259 = v253.coins
	end
	return {
		["title"] = "EXPAND CLAN",
		["yes"] = "EXPAND",
		["body"] = nil,
		["body"] = ("Expand [%s] from %d to %d members for %s coins? Everyone in the clan can use the new slots. This cannot be undone."):format(p252, v255, v256, (v_u_25(v259)))
	}
end
function v_u_14.reason(p260, p261) -- name: reason
	-- upvalues: (copy) v_u_14
	local v262 = type(p260) ~= "table" and {} or p260
	local v263 = v262.data
	local v264 = (type(v263) ~= "table" and {} or v262.data).code or v262.code
	if type(v264) == "string" and v_u_14.TEXT[v264] then
		return v_u_14.TEXT[v264]
	end
	if type(p261) == "function" then
		local v265, v266 = pcall(p261, p260)
		if v265 and type(v266) == "string" then
			return v266
		end
	end
	return "That did not work. Please try again."
end
function v_u_14.fake(p267) -- name: fake
	-- upvalues: (copy) v_u_14
	local v268 = type(p267) ~= "table" and {} or p267
	local v269
	if v268.rank == "owner" then
		v269 = true
	else
		local v270 = v268.perm
		if type(v270) == "table" then
			v269 = v268.perm.useShop == true
		else
			v269 = false
		end
	end
	local v271 = v_u_14.FAKE_TIERS[1]
	return {
		["v"] = 1,
		["pts"] = 31200,
		["ptsWeek"] = 1800,
		["coins"] = 8421,
		["xt"] = 0,
		["cap"] = nil,
		["next"] = nil,
		["own"] = nil,
		["eq"] = nil,
		["lp"] = nil,
		["can"] = nil,
		["rbx"] = nil,
		["credits"] = nil,
		["pending"] = 0,
		["week"] = nil,
		["cap"] = v_u_14.BASE_CAP,
		["next"] = {
			["pts"] = nil,
			["coins"] = nil,
			["robux"] = nil,
			["ok"] = false,
			["pts"] = v271.pts,
			["coins"] = v271.coins,
			["robux"] = v271.robux
		},
		["own"] = {
			["tc_basic"] = 1,
			["ts_brackets"] = 1,
			["pl_accent"] = 1
		},
		["eq"] = {
			["tc"] = "tc_basic:3"
		},
		["lp"] = {
			["w"] = 1,
			["p"] = 3120,
			["c"] = 3120,
			["r"] = 2
		},
		["can"] = {
			["spend"] = nil,
			["robux"] = true,
			["spend"] = v269
		},
		["rbx"] = {
			["on"] = true,
			["items"] = nil,
			["items"] = {
				["1"] = true,
				["2"] = true,
				["3"] = true,
				["4"] = true
			}
		},
		["credits"] = {
			["clan_item_2"] = 1
		},
		["week"] = {
			["reset"] = 273600
		}
	}
end
local function v_u_274(p272) -- name: advance
	-- upvalues: (copy) v_u_14
	p272.xt = p272.xt + 1
	p272.cap = p272.cap + v_u_14.EXPAND_STEP
	local v273 = v_u_14.FAKE_TIERS[p272.xt + 1]
	if v273 then
		p272.next = {
			["pts"] = v273.pts,
			["coins"] = v273.coins,
			["robux"] = v273.robux,
			["ok"] = p272.pts >= v273.pts
		}
	else
		p272.next = nil
	end
end
function v_u_14.simulate(p275, p276, p277) -- name: simulate
	-- upvalues: (copy) v_u_14, (copy) v_u_30, (copy) v_u_274
	local v278 = v_u_14.catalog
	local v279 = v_u_14.norm(p275)
	local v280 = v_u_30(v279)
	local v281 = type(p277) ~= "table" and {} or p277
	if p276 == "clanShopBuy" then
		local v282 = v278.get(v281.item)
		if v282 == nil or (not v278.buyableWithCoins(v282.id) or v282.slot == "ex") then
			return false, "BAD_ARGS", v279
		end
		if not v279.can.spend then
			return false, "DENIED", v279
		end
		if v279.own[v282.id] == 1 then
			return false, "SHOP_OWNED", v279
		end
		if not v278.needsMet(v279.own, v282.id) then
			return false, "SHOP_LOCKED", v279
		end
		if v279.coins < v282.coins then
			return false, "SHOP_COINS", v279
		end
		v280.coins = v280.coins - v282.coins
		v280.own[v282.id] = 1
		return true, nil, v280
	elseif p276 == "clanShopEquip" then
		if not v279.can.spend then
			return false, "DENIED", v279
		end
		local v283 = v281.set
		if type(v283) ~= "table" then
			return false, "BAD_ARGS", v279
		end
		local v284 = {}
		for v285, v286 in v283 do
			if not v278.validEq(v279.own, v285, v286) then
				return false, "BAD_ARGS", v279
			end
			v284[v285] = v286
		end
		v280.eq = v284
		return true, nil, v280
	elseif p276 == "clanShopRobux" or p276 == "clanShopRedeem" then
		local v287 = v278.get(v281.item)
		if v287 == nil then
			return false, "BAD_ARGS", v279
		end
		if v287.slot == "ex" then
			if v279.xt + 1 ~= v287.xt then
				return false, "dup", v279
			end
		else
			if v279.own[v287.id] == 1 then
				return false, "SHOP_OWNED", v279
			end
			if not v278.needsMet(v279.own, v287.id) then
				return false, "SHOP_LOCKED", v279
			end
		end
		if p276 == "clanShopRedeem" then
			local v288
			if v287.slot == "ex" then
				v288 = v278.slotsProductOf(v287.xt)
			else
				v288 = v278.productOf(v287.tier)
			end
			if v288 == nil or (v279.credits[v288] or 0) < 1 then
				return false, "BAD_ARGS", v279
			end
			local v289 = v280.credits
			v289[v288] = v289[v288] - 1
		end
		if v287.slot == "ex" then
			v_u_274(v280)
		else
			v280.own[v287.id] = 1
		end
		return true, nil, v280
	else
		if p276 ~= "clanExpand" and p276 ~= "clanExpandRobux" then
			return false, "BAD_ARGS", v279
		end
		if v279.xt >= 3 or v279.next == nil then
			return false, "SHOP_MAX", v279
		end
		if not v279.next.ok then
			return false, "SHOP_PTS", v279
		end
		if p276 == "clanExpand" then
			if not v279.can.spend then
				return false, "DENIED", v279
			end
			if v279.coins < v279.next.coins then
				return false, "SHOP_COINS", v279
			end
			v280.coins = v280.coins - v279.next.coins
		end
		v_u_274(v280)
		return true, nil, v280
	end
end
function v_u_14.board(p290, p291) -- name: board
	local v292 = {
		["rows"] = nil,
		["hasTotal"] = false,
		["mineRank"] = nil,
		["rows"] = {}
	}
	if type(p290) ~= "table" then
		return v292
	end
	for v301, v294 in p290 do
		if type(v294) ~= "table" then
			continue
		end
		local v295 = v294.tag
		if type(v295) ~= "string" then
			continue
		end
		local v296 = v294.tot
		local v297 = tonumber(v296)
		if v297 ~= nil then
			v292.hasTotal = true
		end
		local v298 = {}
		local v299 = v294.rank
		local v300 = tonumber(v299)
		if v300 ~= nil and (v300 == v300 and (v300 ~= (1 / 0) and v300 ~= (-1 / 0))) then
			local v301 = v300
		end
		v298.rank = math.floor(v301)
		v298.id = v294.id
		v298.tag = v294.tag
		local v302 = v294.name or "?"
		v298.name = tostring(v302)
		local v303 = v294.pts
		local v304 = tonumber(v303)
		local v305 = (v304 == nil or (v304 ~= v304 or (v304 == (1 / 0) or v304 == (-1 / 0)))) and 0 or v304
		local v306 = math.floor(v305)
		v298.weekly = math.max(0, v306)
		local v307
		if v297 then
			local v308 = math.floor(v297)
			v307 = math.max(0, v308)
		else
			v307 = nil
		end
		v298.total = v307
		local v309 = v294.count
		v298.count = tonumber(v309)
		local v310
		if p291 == nil then
			v310 = false
		else
			v310 = v294.id == p291
		end
		v298.mine = v310
		if v298.mine then
			v292.mineRank = v298.rank
		end
		local v311 = v292.rows
		table.insert(v311, v298)
	end
	table.sort(v292.rows, function(p312, p313)
		return p312.rank < p313.rank
	end)
	return v292
end
function v_u_14.fakeBoard(p314, p315) -- name: fakeBoard
	local v316 = {}
	for v317, v318 in {
		{ "BLKO", "Black Ops" },
		{ "RAVN", "Ravens" },
		{ "HUSH", "The Quiet Ones" },
		{ "KSTR", "Kestrel Wing" },
		{ "WOLF", "Night Wolves" },
		{ "DOCS", "Field Medics" },
		{ "ASHG", "Ashgrove Guard" },
		{ "TOXN", "Toxic Squad" }
	} do
		local v319 = v318[1]
		local v320 = string.format("%012x", 4096 * v317)
		if v317 == 4 and (type(p315) == "string" and p315 ~= "") then
			if type(p314) == "string" then
				v319 = p315
				v320 = p314
			else
				v319 = p315
			end
		end
		local v321 = {
			["rank"] = v317,
			["id"] = v320,
			["tag"] = v319,
			["name"] = v318[2],
			["pts"] = 9800 - v317 * 1050,
			["tot"] = 640000 - v317 * 71000,
			["count"] = 30 - v317
		}
		table.insert(v316, v321)
	end
	return v316
end
return v_u_14