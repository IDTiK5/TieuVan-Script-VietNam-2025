-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PerfHud

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	["FPS_GOOD"] = 50,
	["FPS_WARN"] = 30,
	["PING_GOOD"] = 100,
	["PING_WARN"] = 200,
	["REFRESH"] = 0.5,
	["FPS_WINDOW"] = 1,
	["FPS_BUCKET"] = 0.1,
	["FPS_MIN_TIME"] = 0.25,
	["FPS_MAX_DT"] = 5,
	["PING_ALPHA"] = 0.35,
	["CHAR_W"] = 0.62,
	["TIERS"] = {
		"full",
		"mid",
		"short",
		"min"
	}
}
local v_u_4 = {
	["full"] = 4,
	["mid"] = 3,
	["short"] = 2,
	["min"] = 1
}
local v_u_5 = {
	["full"] = {
		"fps",
		"ping",
		"region",
		"id",
		"players",
		"version"
	},
	["mid"] = {
		"fps",
		"ping",
		"region",
		"id",
		"players"
	},
	["short"] = {
		"fps",
		"ping",
		"region",
		"id"
	},
	["min"] = { "fps", "ping" }
}
local v6 = utf8.char(183)
local v_u_7 = {
	["full"] = nil,
	["mid"] = nil,
	["short"] = "  ",
	["min"] = "  ",
	["full"] = " " .. v6 .. " ",
	["mid"] = " " .. v6 .. " "
}
v_u_3.PAD_H = 6
v_u_3.EDGE = 4
v_u_3.MARGIN = 8
v_u_3.GAP = 6
v_u_3.VGAP = 2
v_u_3.FOOTER_CENTER = 15
local v_u_8 = {
	["NA"] = true,
	["SA"] = true,
	["EU"] = true,
	["AS"] = true,
	["OC"] = true,
	["MEA"] = true
}
local v_u_9 = {
	["good"] = "#5FBF7A",
	["warn"] = "#E8A33D",
	["bad"] = "#D8453B",
	["none"] = "#9AA3AE"
}
function v_u_3.newFps(p10, p_u_11) -- name: newFps
	-- upvalues: (copy) v_u_3
	if type(p_u_11) ~= "number" or p_u_11 <= 0 then
		p_u_11 = v_u_3.FPS_BUCKET
	end
	if type(p10) ~= "number" or p10 <= 0 then
		p10 = v_u_3.FPS_WINDOW
	end
	local v12 = p10 / p_u_11 - 1e-9
	local v13 = math.ceil(v12)
	local v_u_14 = math.max(2, v13)
	local v_u_15 = table.create(v_u_14, 0)
	local v_u_16 = table.create(v_u_14, 0)
	local v_u_17 = 1
	return {
		["push"] = function(p18) -- name: push
			-- upvalues: (ref) v_u_3, (copy) v_u_15, (ref) v_u_17, (copy) v_u_16, (copy) p_u_11, (copy) v_u_14
			if type(p18) == "number" and (p18 == p18 and p18 > 0) then
				if v_u_3.FPS_MAX_DT < p18 then
					p18 = v_u_3.FPS_MAX_DT
				end
				local v19 = v_u_15
				local v20 = v_u_17
				v19[v20] = v19[v20] + 1
				local v21 = v_u_16
				local v22 = v_u_17
				v21[v22] = v21[v22] + p18
				if p_u_11 <= v_u_16[v_u_17] then
					v_u_17 = v_u_17 % v_u_14 + 1
					v_u_15[v_u_17] = 0
					v_u_16[v_u_17] = 0
				end
			end
		end,
		["value"] = function() -- name: value
			-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_16, (ref) v_u_3
			local v23 = 0
			local v24 = 0
			for v25 = 1, v_u_14 do
				v23 = v23 + v_u_15[v25]
				v24 = v24 + v_u_16[v25]
			end
			if v24 < v_u_3.FPS_MIN_TIME or v23 < 2 then
				return nil
			else
				return v23 / v24
			end
		end,
		["reset"] = function() -- name: reset
			-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_16, (ref) v_u_17
			for v26 = 1, v_u_14 do
				v_u_15[v26] = 0
				v_u_16[v26] = 0
			end
			v_u_17 = 1
		end
	}
end
function v_u_3.smooth(p27, p28, p29) -- name: smooth
	-- upvalues: (copy) v_u_3
	if type(p28) ~= "number" or (p28 ~= p28 or (p28 == (1 / 0) or p28 == (-1 / 0))) then
		return p27
	end
	if p27 == nil then
		return p28
	end
	local v30
	if type(p29) == "number" then
		v30 = math.clamp(p29, 0, 1)
	else
		v30 = v_u_3.PING_ALPHA
	end
	return p27 + (p28 - p27) * v30
end
function v_u_3.fpsTone(p31) -- name: fpsTone
	-- upvalues: (copy) v_u_3
	return type(p31) == "number" and p31 == p31 and (v_u_3.FPS_GOOD <= p31 and "good" or (v_u_3.FPS_WARN <= p31 and "warn" or "bad")) or "none"
end
function v_u_3.pingTone(p32) -- name: pingTone
	-- upvalues: (copy) v_u_3
	return type(p32) == "number" and p32 == p32 and (p32 < v_u_3.PING_GOOD and "good" or (p32 < v_u_3.PING_WARN and "warn" or "bad")) or "none"
end
function v_u_3.shortId(p33) -- name: shortId
	if type(p33) ~= "string" then
		return "local"
	end
	local v34 = string.gsub(p33, "[^%w]", "")
	return #v34 == 0 and "local" or string.lower((string.sub(v34, 1, 6)))
end
function v_u_3.cleanRegion(p35) -- name: cleanRegion
	-- upvalues: (copy) v_u_8
	if type(p35) == "string" and v_u_8[p35] then
		return p35
	else
		return nil
	end
end
function v_u_3.regionOf(p36, p37, p38, p39) -- name: regionOf
	-- upvalues: (copy) v_u_3
	if p36 == "Raid" and type(p37) == "table" then
		if p37.private == true then
			return "PRIVATE"
		end
		local v40 = v_u_3.cleanRegion(p37.region)
		if v40 then
			return v40
		end
	end
	return v_u_3.cleanRegion(p39) or v_u_3.cleanRegion(p38)
end
local function v_u_69(p41, p42, p43) -- name: seg
	-- upvalues: (copy) v_u_3
	if p41 == "fps" then
		local v44 = p42.fps
		if type(v44) ~= "number" or v44 ~= v44 then
			return ("<font color=\"%s\">...</font> FPS"):format(p43.none), "... FPS"
		end
		local v45 = v44 + 0.5
		local v46 = math.floor(v45)
		local v47 = math.clamp(v46, 0, 999)
		return ("<font color=\"%s\">%d</font> FPS"):format(p43[v_u_3.fpsTone(v47)] or p43.none, v47), ("%d FPS"):format(v47)
	end
	if p41 ~= "ping" then
		if p41 == "region" then
			local v48 = p42.region
			if type(v48) == "string" and p42.region ~= "" then
				local v49 = p42.region
				local v50 = string.gsub(v49, "&", "&amp;")
				local v51 = string.gsub(v50, "<", "&lt;")
				return string.gsub(v51, ">", "&gt;"), p42.region
			end
		elseif p41 == "id" then
			local v52 = p42.id
			if type(v52) == "string" and p42.id ~= "" then
				local v53 = p42.id
				local v54 = string.gsub(v53, "&", "&amp;")
				local v55 = string.gsub(v54, "<", "&lt;")
				return string.gsub(v55, ">", "&gt;"), p42.id
			end
		elseif p41 == "players" then
			local v56 = p42.players
			if type(v56) == "number" and p42.players == p42.players then
				local v57 = p42.players
				local v58 = math.floor(v57)
				local v59 = math.clamp(v58, 0, 999)
				local v60 = ("%d %s"):format(v59, v59 == 1 and "player" or "players")
				return v60, v60
			end
		elseif p41 == "version" then
			local v61 = p42.version
			if type(v61) == "string" and p42.version ~= "" then
				local v62 = "v" .. p42.version
				local v63 = string.gsub(v62, "&", "&amp;")
				local v64 = string.gsub(v63, "<", "&lt;")
				return string.gsub(v64, ">", "&gt;"), v62
			end
		end
		return nil, nil
	end
	local v65 = p42.ping
	if type(v65) ~= "number" or v65 ~= v65 then
		return ("<font color=\"%s\">...</font> ms"):format(p43.none), "... ms"
	end
	local v66 = v65 + 0.5
	local v67 = math.floor(v66)
	local v68 = math.clamp(v67, 0, 9999)
	return ("<font color=\"%s\">%d</font> ms"):format(p43[v_u_3.pingTone(v68)] or p43.none, v68), ("%d ms"):format(v68)
end
function v_u_3.line(p70, p71, p72) -- name: line
	-- upvalues: (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_69
	local v73 = p72 or v_u_9
	local v74 = v_u_5[p71] or v_u_5.min
	local v75 = v_u_7[p71] or "  "
	local v76 = {}
	local v77 = {}
	for _, v78 in v74 do
		local v79, v80 = v_u_69(v78, p70, v73)
		if not (v79 and v80) then
			continue
		end
		table.insert(v76, v79)
		table.insert(v77, v80)
	end
	return table.concat(v76, v75), table.concat(v77, v75)
end
function v_u_3.fitStatus(p81) -- name: fitStatus
	return {
		["fps"] = 888,
		["ping"] = 888,
		["region"] = nil,
		["id"] = nil,
		["players"] = 88,
		["version"] = nil,
		["region"] = p81.region,
		["id"] = p81.id,
		["version"] = p81.version
	}
end
function v_u_3.widthOf(p82, p83, p84) -- name: widthOf
	-- upvalues: (copy) v_u_3
	return (utf8.len(p82) or #p82) * v_u_3.CHAR_W * p83 + p84 * 2
end
function v_u_3.pickTier(p85, p86, p87, p88) -- name: pickTier
	-- upvalues: (copy) v_u_3
	local v89 = v_u_3.fitStatus(p85)
	for _, v90 in v_u_3.TIERS do
		local _, v91 = v_u_3.line(v89, v90)
		if v_u_3.widthOf(v91, p86, p87) > p88 then
			continue
		end
		return v90
	end
	return nil
end
function v_u_3.tierRank(p92) -- name: tierRank
	-- upvalues: (copy) v_u_4
	return type(p92) == "string" and (v_u_4[p92] or 0) or 0
end
function v_u_3.freeSpans(p93, p94, p95, p96) -- name: freeSpans
	local v97 = {}
	for _, v98 in p93 do
		local v99 = v98[1]
		local v100 = v98[2]
		if type(v99) ~= "number" or (type(v100) ~= "number" or (v99 ~= v99 or (v100 ~= v100 or v99 >= v100))) then
			continue
		end
		local v101 = { v99 - p96, v100 + p96 }
		table.insert(v97, v101)
	end
	table.sort(v97, function(p102, p103)
		return p102[1] < p103[1]
	end)
	local v104 = {}
	for _, v105 in v97 do
		if p94 < v105[1] then
			local v106 = v105[1]
			local v107 = math.min(v106, p95)
			if p94 < v107 then
				table.insert(v104, { p94, v107 })
			end
		end
		if p94 < v105[2] then
			p94 = v105[2]
		end
		if p95 > p94 then
			continue
		end
	end
	if p94 < p95 then
		table.insert(v104, { p94, p95 })
	end
	return v104
end
function v_u_3.pickSpan(p108, p109, p110) -- name: pickSpan
	local v111 = 0
	local v112 = (1 / 0)
	local v113 = nil
	for _, v114 in p108 do
		local v115 = v114[2] - v114[1]
		if p110 > v115 then
			continue
		end
		if v114[1] <= p109 and p109 <= v114[2] then
			return v114
		end
		local v116 = p109 - v114[1]
		local v117 = math.abs(v116)
		local v118 = p109 - v114[2]
		local v119 = math.abs(v118)
		local v120 = math.min(v117, v119)
		if v111 + 1e-6 >= v115 then
			local v121 = v115 - v111
			if math.abs(v121) > 1e-6 or v120 >= v112 then
				continue
			end
		end
		v113 = v114
		v112 = v120
		v111 = v115
	end
	return v113
end
function v_u_3.placeX(p122, p123, p124) -- name: placeX
	local v125 = p122[1] + p123 / 2
	local v126 = p122[2] - p123 / 2
	if v126 < v125 then
		return (p122[1] + p122[2]) / 2
	else
		return math.clamp(p124, v125, v126)
	end
end
function v_u_3.textSpan(p127, p128, p129, p130) -- name: textSpan
	local v131 = math.min(p129, p128)
	local v132 = math.max(0, v131)
	if p130 == "right" then
		return p127 + p128 - v132, p127 + p128
	elseif p130 == "center" then
		return p127 + (p128 - v132) / 2, p127 + (p128 + v132) / 2
	else
		return p127, p127 + v132
	end
end
function v_u_3.stripY(p133, p134, p135, p136) -- name: stripY
	-- upvalues: (copy) v_u_3
	if p133 == "bottom" then
		return p134 - p136 - p135
	end
	if p133 ~= "footer" then
		return p136
	end
	local v137 = p134 - v_u_3.FOOTER_CENTER - p135 / 2
	return math.floor(v137)
end
function v_u_3.stripOrder(p138, p139) -- name: stripOrder
	local v140 = {
		["kind"] = "top",
		["obstacles"] = nil,
		["obstacles"] = p138
	}
	local v141 = {
		["kind"] = "bottom",
		["obstacles"] = nil,
		["obstacles"] = p138
	}
	return p139 and { v141, v140 } or { v140, v141 }
end
function v_u_3.layout(p142) -- name: layout
	-- upvalues: (copy) v_u_3
	local _, v143 = v_u_3.line(v_u_3.fitStatus(p142.s), "min")
	local v144 = v_u_3.widthOf(v143, p142.size, p142.padH)
	local v145 = 0
	local v146 = nil
	for _, v147 in p142.strips do
		local v148 = v_u_3.stripY(v147.kind, p142.H, p142.rowH, p142.edge)
		local v149 = {}
		for _, v150 in v147.obstacles do
			if v150[4] <= v148 - p142.vgap or v150[2] >= v148 + p142.rowH + p142.vgap then
				continue
			end
			local v151 = { v150[1], v150[3] }
			table.insert(v149, v151)
		end
		local v152 = v_u_3.freeSpans(v149, p142.margin, p142.W - p142.margin, p142.gap)
		local v153 = v_u_3.pickSpan(v152, p142.W / 2, v144)
		if not v153 then
			break
		end
		local v154 = v_u_3.pickTier(p142.s, p142.size, p142.padH, v153[2] - v153[1])
		local v155 = v_u_3.tierRank(v154)
		if not v154 or v145 >= v155 then
			break
		end
		v146 = {
			["kind"] = v147.kind,
			["y"] = v148,
			["span"] = v153,
			["tier"] = v154
		}
		v145 = v155
	end
	if not v146 then
		return nil
	end
	local v156, v157 = v_u_3.line(p142.s, v146.tier, p142.hex)
	v146.rich = v156
	v146.plain = v157
	v146.w = v_u_3.widthOf(v157, p142.size, p142.padH)
	v146.cx = v_u_3.placeX(v146.span, v146.w, p142.W / 2)
	return v146
end
local v_u_158 = {
	"Vitals",
	"Noise",
	"Clock",
	"RaidModTag",
	"Weapon",
	"Squad",
	"LevelPlate",
	"FreeRaidTag",
	"Quick",
	"EventBar",
	"Tasks",
	"Extracts",
	"Notices"
}
v_u_3.HUD_BLOCKS = v_u_158
local v_u_159 = false
local v_u_160 = false
local v_u_161 = nil
local v_u_162 = nil
local v_u_163 = nil
local v_u_164 = nil
local v_u_165 = nil
local v_u_166 = nil
local v_u_167 = nil
local v_u_168 = v_u_9
local v_u_169 = nil
local v_u_170 = {}
local v_u_171 = {}
local v_u_172 = nil
local v_u_173 = v_u_3.newFps()
local v_u_174 = nil
local v_u_175 = 0
local v_u_176 = true
local v_u_177 = nil
local v_u_178 = 0
local v_u_179 = false
local v_u_180 = 0
local v_u_181 = {}
local v_u_182 = nil
local v_u_183 = nil
local v_u_184 = "off"
local function v_u_187(p185) -- name: shown
	while p185 and not p185:IsA("ScreenGui") do
		if p185:IsA("GuiObject") and not p185.Visible then
			return false
		end
		p185 = p185.Parent
	end
	local v186
	if p185 == nil then
		v186 = false
	else
		v186 = p185.Enabled
	end
	return v186
end
local function v_u_190() -- name: readTeleport
	-- upvalues: (ref) v_u_177, (ref) v_u_178, (ref) v_u_161, (copy) v_u_3
	if v_u_177 == nil and (v_u_178 < 6 and (v_u_161 and v_u_161.config.PLACE_MODE == "Raid")) then
		v_u_178 = v_u_178 + 1
		local v188, v189 = pcall(function()
			return game:GetService("TeleportService"):GetLocalPlayerTeleportData()
		end)
		if v188 and type(v189) == "table" then
			v_u_177 = {
				["region"] = v_u_3.cleanRegion(v189.region),
				["private"] = v189.private == true
			}
		end
	end
end
local v_u_191 = Vector2.zero
local v_u_192 = 1
local function v_u_196(p193) -- name: rectOf
	-- upvalues: (copy) v_u_187, (ref) v_u_191, (ref) v_u_192
	if not (p193:IsA("GuiObject") and (p193.Visible and v_u_187(p193))) then
		return nil
	end
	local v194 = p193.AbsoluteSize
	if v194.X < 3 or v194.Y < 3 then
		return nil
	end
	local v195 = p193.AbsolutePosition - v_u_191
	return {
		v195.X / v_u_192,
		v195.Y / v_u_192,
		(v195.X + v194.X) / v_u_192,
		(v195.Y + v194.Y) / v_u_192
	}
end
local function v_u_227() -- name: collectHud
	-- upvalues: (copy) v_u_1, (copy) v_u_158, (copy) v_u_196, (ref) v_u_161, (ref) v_u_163, (ref) v_u_191, (ref) v_u_192
	local v197 = {}
	local v198 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v199
	if v198 then
		v199 = v198:FindFirstChild("HushHUD")
	else
		v199 = nil
	end
	local v200
	if v199 then
		v200 = v199:FindFirstChild("Root")
	else
		v200 = nil
	end
	if v200 then
		for _, v201 in v_u_158 do
			local v202 = v200:FindFirstChild(v201)
			local v203
			if v202 then
				v203 = v_u_196(v202)
			else
				v203 = nil
			end
			if not v203 then
				continue
			end
			table.insert(v197, v203)
		end
	end
	local function v206()
		-- upvalues: (ref) v_u_161
		local v204 = v_u_161.controllers.Input
		if v204 then
			local v205 = v204.touchRects
			if type(v205) == "function" then
				return v204.touchRects()
			end
		end
		return nil
	end
	local v207, v208 = pcall(v206)
	if v207 and type(v208) == "table" then
		local v_u_209 = Vector2.zero
		local function v218()
			-- upvalues: (ref) v_u_161, (ref) v_u_163, (ref) v_u_191, (ref) v_u_209
			local v210 = v_u_161.controllers.Input
			local v211
			if v210 then
				local v212 = v210.touch
				if type(v212) == "function" then
					v211 = v210.touch()
				else
					v211 = nil
				end
			else
				v211 = nil
			end
			local v213
			if v211 then
				v213 = v211.root
			else
				v213 = nil
			end
			local v214 = v_u_163.viewport()
			if v213 and v213.Parent then
				local v215 = v_u_191 - v213.AbsolutePosition
				local v216 = v215.X
				if math.abs(v216) < v214.X / 4 then
					local v217 = v215.Y
					if math.abs(v217) < v214.Y / 4 then
						v_u_209 = v215
					end
				end
			end
		end
		pcall(v218)
		local v219 = v_u_209
		for v220, v221 in v208 do
			if v220 == "moveZone" or typeof(v221) ~= "Rect" then
				continue
			end
			local v222 = {
				(v221.Min.X - v219.X) / v_u_192,
				(v221.Min.Y - v219.Y) / v_u_192,
				(v221.Max.X - v219.X) / v_u_192,
				(v221.Max.Y - v219.Y) / v_u_192
			}
			table.insert(v197, v222)
		end
	end
	local v223 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v224
	if v223 then
		v224 = v223:FindFirstChild("HushTestTag")
	else
		v224 = nil
	end
	local v225
	if v224 then
		v225 = v224:FindFirstChild("TestTag", true)
	else
		v225 = nil
	end
	local v226
	if v225 then
		v226 = v_u_196(v225)
	else
		v226 = nil
	end
	if v226 then
		table.insert(v197, v226)
	end
	return v197
end
local function v_u_243() -- name: collectMenu
	-- upvalues: (copy) v_u_1, (copy) v_u_187, (copy) v_u_3, (ref) v_u_191, (ref) v_u_192, (copy) v_u_196
	local v228 = {}
	local v229 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v230
	if v229 then
		v230 = v229:FindFirstChild("HushMenu")
	else
		v230 = nil
	end
	local v231
	if v230 then
		v231 = v230:FindFirstChild("Root")
	else
		v231 = nil
	end
	local v232
	if v231 then
		v232 = v231:FindFirstChild("Footer")
	else
		v232 = nil
	end
	if v232 then
		for _, v233 in v232:GetChildren() do
			if not v233:IsA("TextLabel") or (v233.Text == "" or not v_u_187(v233)) then
				continue
			end
			local v234 = v233.TextXAlignment == Enum.TextXAlignment.Right and "right" or (v233.TextXAlignment == Enum.TextXAlignment.Center and "center" or "left")
			local v235, v236 = v_u_3.textSpan(v233.AbsolutePosition.X, v233.AbsoluteSize.X, v233.TextBounds.X, v234)
			local v237 = (v233.AbsolutePosition.Y - v_u_191.Y) / v_u_192
			local v238 = {
				(v235 - v_u_191.X) / v_u_192,
				v237,
				(v236 - v_u_191.X) / v_u_192,
				v237 + v233.AbsoluteSize.Y / v_u_192
			}
			table.insert(v228, v238)
		end
	end
	local v239 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v240
	if v239 then
		v240 = v239:FindFirstChild("HushTestTag")
	else
		v240 = nil
	end
	local v241
	if v240 then
		v241 = v240:FindFirstChild("TestTag", true)
	else
		v241 = nil
	end
	local v242
	if v241 then
		v242 = v_u_196(v241)
	else
		v242 = nil
	end
	if v242 then
		table.insert(v228, v242)
	end
	return v228
end
local function v_u_274() -- name: refresh
	-- upvalues: (ref) v_u_164, (ref) v_u_165, (ref) v_u_166, (ref) v_u_167, (ref) v_u_160, (ref) v_u_163, (copy) v_u_1, (ref) v_u_184, (ref) v_u_182, (ref) v_u_192, (ref) v_u_191, (copy) v_u_190, (ref) v_u_174, (copy) v_u_3, (ref) v_u_181, (copy) v_u_173, (ref) v_u_161, (ref) v_u_177, (ref) v_u_183, (copy) v_u_243, (copy) v_u_227, (ref) v_u_168
	local v244 = v_u_165
	local v245 = v_u_166
	local v246 = v_u_167
	if v_u_160 and (v_u_164 and (v244 and (v245 and (v246 and v_u_163)))) then
		local v247 = v_u_1.LocalPlayer
		local v248 = v247:GetAttribute("Place") == "Transit" and "off" or (v247:GetAttribute("MenuOpen") == true and "menu" or "hud")
		v_u_184 = v248
		if v248 == "off" then
			local v249 = v_u_164
			if v249 and v249.Enabled ~= false then
				v249.Enabled = false
			end
			v_u_182 = nil
			return
		else
			local v250 = v_u_163.uiScale
			v_u_192 = math.max(0.01, v250())
			v_u_191 = v244.AbsolutePosition
			local v251 = v244.AbsoluteSize
			if v251.X < 80 or v251.Y < 40 then
				return
			else
				v_u_190()
				local function v252()
					-- upvalues: (ref) v_u_1
					return v_u_1.LocalPlayer:GetNetworkPing()
				end
				local v253, v254 = pcall(v252)
				if v253 and type(v254) == "number" then
					v_u_174 = v_u_3.smooth(v_u_174, v254 * 1000)
				end
				local v255 = {
					["fps"] = v_u_181.fps or v_u_173.value(),
					["ping"] = v_u_181.ping or v_u_174
				}
				local v256 = v_u_1.LocalPlayer
				local v257
				if v_u_161 then
					v257 = v_u_161.config.PLACE_MODE
				else
					v257 = nil
				end
				v255.region = v_u_3.regionOf(v257, v_u_177, v256:GetAttribute("Region"), v256:GetAttribute("DevRegion"))
				local v258 = v_u_3.shortId
				local v259, v260 = pcall(function()
					return game.JobId
				end)
				v255.id = v258((not v259 or type(v260) ~= "string") and "" or v260)
				v255.players = #v_u_1:GetPlayers()
				local v261 = v_u_161.config.VERSION or ""
				v255.version = tostring(v261)
				v_u_183 = v255
				local v262 = v_u_163.phoneText(12, "caption")
				local v263 = v262 * 1.4
				local v264 = math.ceil(v263)
				local v265
				if v248 == "menu" then
					v265 = v_u_243()
				else
					v265 = v_u_227()
				end
				local v266 = v248 == "menu" and {
					{
						["kind"] = "footer",
						["obstacles"] = nil,
						["obstacles"] = v265
					}
				} or v_u_3.stripOrder(v265, v_u_163.isPhone() == true)
				local v267 = v_u_3.layout({
					["W"] = v251.X / v_u_192,
					["H"] = v251.Y / v_u_192,
					["size"] = v262,
					["padH"] = v_u_3.PAD_H,
					["rowH"] = v264,
					["edge"] = v_u_3.EDGE,
					["margin"] = v_u_3.MARGIN,
					["gap"] = v_u_3.GAP,
					["vgap"] = v_u_3.VGAP,
					["s"] = v255,
					["hex"] = v_u_168,
					["strips"] = v266
				})
				v_u_182 = v267
				if v267 then
					if v246.Text ~= v267.rich then
						v246.Text = v267.rich
					end
					if v246.TextSize ~= v262 then
						v246.TextSize = v262
					end
					v245.Size = UDim2.fromOffset(0, v264)
					v246.Size = UDim2.fromOffset(0, v264)
					local v268 = UDim2.fromOffset
					local v269 = v267.cx + 0.5
					local v270 = math.floor(v269)
					local v271 = v267.y + 0.5
					v245.Position = v268(v270, (math.floor(v271)))
					v245.Visible = true
					local v272 = v_u_164
					if v272 and v272.Enabled ~= true then
						v272.Enabled = true
					end
				else
					local v273 = v_u_164
					if v273 and v273.Enabled ~= false then
						v273.Enabled = false
					end
				end
			end
		end
	else
		return
	end
end
local function v_u_280() -- name: build
	-- upvalues: (ref) v_u_162, (ref) v_u_163, (ref) v_u_164, (ref) v_u_165, (ref) v_u_168, (copy) v_u_3, (ref) v_u_166, (ref) v_u_167
	local v275, v276 = v_u_162.screen("HushPerfHud", v_u_163.layer.menu + 1, {
		["enabled"] = false
	})
	v_u_164 = v275
	v_u_165 = v276
	local v277 = v_u_163.color
	v_u_168 = {
		["good"] = v_u_163.hex(v277.success),
		["warn"] = v_u_163.hex(v277.accent),
		["bad"] = v_u_163.hex(v277.danger),
		["none"] = v_u_163.hex(v277.text2)
	}
	local v278 = v_u_162.new("Frame", {
		["Name"] = "PerfHud",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.45,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Active"] = false,
		["Visible"] = false,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v277.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(0, v_u_3.EDGE),
		["Size"] = UDim2.fromOffset(0, 17),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v276)
	v_u_162.pad(v278, {
		v_u_3.PAD_H,
		v_u_3.PAD_H,
		0,
		0
	})
	v_u_162.stroke(v278, v277.line, 1, 0.5)
	local v279 = v_u_162.new("TextLabel", {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["RichText"] = true,
		["TextWrapped"] = false,
		["Text"] = "",
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Active"] = false,
		["FontFace"] = v_u_163.font.mono,
		["TextColor3"] = v277.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextYAlignment"] = Enum.TextYAlignment.Center,
		["Size"] = UDim2.fromOffset(0, 17),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v278)
	v_u_166 = v278
	v_u_167 = v279
end
local function v_u_286(p281) -- name: onHeartbeat
	-- upvalues: (copy) v_u_173, (ref) v_u_175, (ref) v_u_176, (copy) v_u_3, (copy) v_u_274, (ref) v_u_180, (copy) v_u_1
	v_u_173.push(p281)
	v_u_175 = v_u_175 + p281
	if v_u_176 or v_u_175 >= v_u_3.REFRESH then
		v_u_175 = 0
		v_u_176 = false
		local v282 = v_u_274
		local v283, v284 = pcall(v282)
		if v283 then
			v_u_180 = 0
			return
		end
		v_u_180 = v_u_180 + 1
		if v_u_180 <= 3 then
			warn("[PerfHud] update failed:", v284)
		end
		if v_u_180 >= 5 then
			v_u_1.LocalPlayer:SetAttribute("ClientError", "perfhud: " .. tostring(v284))
			local v285 = v_u_3.disable
			pcall(v285)
		end
	end
end
function v_u_3.enable() -- name: enable
	-- upvalues: (ref) v_u_160, (ref) v_u_159, (ref) v_u_164, (copy) v_u_280, (copy) v_u_1, (copy) v_u_173, (ref) v_u_174, (ref) v_u_175, (ref) v_u_176, (ref) v_u_180, (ref) v_u_169, (copy) v_u_2, (copy) v_u_286
	if not v_u_160 and v_u_159 then
		v_u_160 = true
		if not (v_u_164 and v_u_164.Parent) then
			local v287 = v_u_280
			local v288, v289 = pcall(v287)
			if not v288 then
				v_u_160 = false
				warn("[PerfHud] build failed:", v289)
				v_u_1.LocalPlayer:SetAttribute("ClientError", "perfhud build: " .. tostring(v289))
				return
			end
		end
		v_u_173.reset()
		v_u_174 = nil
		v_u_175 = 0
		v_u_176 = true
		v_u_180 = 0
		v_u_169 = v_u_2.Heartbeat:Connect(v_u_286)
	end
end
function v_u_3.disable() -- name: disable
	-- upvalues: (ref) v_u_169, (ref) v_u_160, (ref) v_u_164, (ref) v_u_182
	if v_u_169 then
		v_u_169:Disconnect()
		v_u_169 = nil
	end
	v_u_160 = false
	if v_u_164 then
		v_u_164.Enabled = false
	end
	v_u_182 = nil
end
local function v_u_294() -- name: maybeFetch
	-- upvalues: (copy) v_u_1, (ref) v_u_179, (ref) v_u_161
	local v_u_290 = v_u_1.LocalPlayer
	if v_u_179 or (not v_u_161 or (not v_u_161.net or v_u_290:GetAttribute("PerfHud") ~= nil)) then
		return
	elseif v_u_161.session.place(v_u_290) == "Raid" then
		v_u_179 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_161, (copy) v_u_290
			local v291 = v_u_161.net.invoke
			local v292, v293 = pcall(v291, "menu.get", {
				["what"] = "settings"
			})
			if v292 and (type(v293) == "table" and (v293.error == nil and v_u_290:GetAttribute("PerfHud") == nil)) then
				v_u_290:SetAttribute("PerfHud", v293.showFps == true)
			end
		end)
	end
end
function v_u_3.start(p_u_295) -- name: start
	-- upvalues: (ref) v_u_159, (ref) v_u_161, (ref) v_u_162, (ref) v_u_163, (copy) v_u_1, (copy) v_u_170, (ref) v_u_176, (ref) v_u_160, (copy) v_u_3, (copy) v_u_294, (ref) v_u_172, (copy) v_u_171, (ref) v_u_181, (copy) v_u_190
	if v_u_159 or not (p_u_295 and p_u_295.config) then
		return
	else
		v_u_159 = true
		v_u_161 = p_u_295
		local v296, v297 = pcall(function()
			-- upvalues: (copy) p_u_295
			return p_u_295.lib.HushUI
		end)
		if v296 and type(v297) == "table" then
			v_u_162 = v297
			local v298 = v_u_162.bind
			pcall(v298, p_u_295)
			v_u_163 = v_u_162.Theme
			local v_u_299 = v_u_1.LocalPlayer
			for _, v_u_300 in {
				"PerfHud",
				"Place",
				"MenuOpen",
				"HudMounted",
				"Region"
			} do
				local v301 = v_u_170
				local v302 = v_u_299:GetAttributeChangedSignal(v_u_300)
				local function v304()
					-- upvalues: (ref) v_u_176, (copy) v_u_300, (ref) v_u_1, (ref) v_u_160, (ref) v_u_3, (ref) v_u_294
					v_u_176 = true
					if v_u_300 == "PerfHud" then
						local v303 = v_u_1.LocalPlayer:GetAttribute("PerfHud") == true
						if v303 and not v_u_160 then
							v_u_3.enable()
							return
						end
						if not v303 and v_u_160 then
							v_u_3.disable()
							return
						end
					elseif v_u_300 == "Place" then
						v_u_294()
					end
				end
				table.insert(v301, v302:Connect(v304))
			end
			local v305 = v_u_170
			local v306 = v_u_163.scaleChanged
			local function v307()
				-- upvalues: (ref) v_u_176
				v_u_176 = true
			end
			table.insert(v305, v306:Connect(v307))
			v_u_172 = v_u_162.onDevice(function()
				-- upvalues: (ref) v_u_176
				v_u_176 = true
			end)
			if p_u_295.on then
				for _, v308 in { "ui.rebuild", "touch.layout" } do
					local v309 = v_u_171
					local v310 = p_u_295.on
					local function v311()
						-- upvalues: (ref) v_u_176
						v_u_176 = true
					end
					table.insert(v309, v310(v308, v311))
				end
			end
			if p_u_295.command then
				p_u_295.command("perfhud.on", function()
					-- upvalues: (copy) v_u_299
					v_u_299:SetAttribute("PerfHud", true)
					return "PerfHud on"
				end)
				p_u_295.command("perfhud.off", function()
					-- upvalues: (copy) v_u_299
					v_u_299:SetAttribute("PerfHud", false)
					return "PerfHud off"
				end)
				p_u_295.command("perfhud.state", function()
					-- upvalues: (ref) v_u_3
					local v312 = v_u_3.state()
					local v313 = v312.enabled
					local v314 = tostring(v313)
					local v315 = v312.visible
					local v316 = tostring(v315)
					local v317 = v312.context
					local v318 = v312.strip
					local v319 = tostring(v318)
					local v320 = v312.tier
					local v321 = tostring(v320)
					local v322 = v312.text
					local v323 = v312.rect.x
					local v324 = v312.rect.y
					local v325 = v312.rect.w
					local v326 = v312.rect.h
					local v327 = v312.fps
					local v328 = tostring(v327)
					local v329 = v312.ping
					local v330 = tostring(v329)
					local v331 = v312.region
					local v332 = tostring(v331)
					local v333 = v312.id
					local v334 = tostring(v333)
					local v335 = v312.players
					return ("enabled %s, visible %s, context %s, strip %s, tier %s, text [%s], rect x %d y %d w %d h %d, fps %s, ping %s, region %s, id %s, players %s"):format(v314, v316, v317, v319, v321, v322, v323, v324, v325, v326, v328, v330, v332, v334, (tostring(v335)))
				end)
				p_u_295.command("perfhud.overlaps", function()
					-- upvalues: (ref) v_u_3
					local v336, v337 = v_u_3.overlaps()
					return (#v336 == 0 and "nothing under the row" or #v336 .. " UNDER the row: " .. table.concat(v336, " | ")) .. "; " .. (#v337 == 0 and "nothing above it" or #v337 .. " above it (cover the row): " .. table.concat(v337, " | "))
				end)
				p_u_295.command("perfhud.fake", function(p338)
					-- upvalues: (ref) v_u_181, (ref) v_u_176
					if p338[1] == nil or p338[1] == "off" then
						v_u_181 = {}
						v_u_176 = true
						return "fake values off"
					end
					local v339 = {}
					local v340 = p338[1]
					v339.fps = tonumber(v340)
					local v341 = p338[2]
					v339.ping = tonumber(v341)
					v_u_181 = v339
					v_u_176 = true
					local v342 = v_u_181.fps
					local v343 = tostring(v342)
					local v344 = v_u_181.ping
					return ("fake fps %s, ping %s"):format(v343, (tostring(v344)))
				end)
			end
			v_u_190()
			v_u_294()
			local v345 = v_u_1.LocalPlayer:GetAttribute("PerfHud") == true
			if v345 and not v_u_160 then
				v_u_3.enable()
			elseif not v345 and v_u_160 then
				v_u_3.disable()
			end
		else
			v_u_159 = false
			warn("[PerfHud] HushUI is not available")
			return
		end
	end
end
function v_u_3.state() -- name: state
	-- upvalues: (ref) v_u_166, (ref) v_u_182, (ref) v_u_183, (ref) v_u_160, (ref) v_u_164, (ref) v_u_184
	local v346 = v_u_166
	local v347
	if v346 and v346.Parent then
		local v348 = v346.AbsolutePosition
		local v349 = v346.AbsoluteSize
		v347 = {}
		local v350 = v348.X + 0.5
		v347.x = math.floor(v350)
		local v351 = v348.Y + 0.5
		v347.y = math.floor(v351)
		local v352 = v349.X + 0.5
		v347.w = math.floor(v352)
		local v353 = v349.Y + 0.5
		v347.h = math.floor(v353)
	else
		v347 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = 0,
			["h"] = 0
		}
	end
	local v354 = v_u_182
	local v355 = v_u_183
	local v356 = {
		["enabled"] = v_u_160
	}
	local v357 = v_u_160 and (v_u_164 ~= nil and v_u_164.Enabled)
	if v357 then
		if v346 == nil then
			v357 = false
		else
			v357 = v346.Visible
		end
	end
	v356.visible = v357
	v356.context = v_u_184
	local v358
	if v354 then
		v358 = v354.kind
	else
		v358 = nil
	end
	v356.strip = v358
	local v359
	if v354 then
		v359 = v354.tier
	else
		v359 = nil
	end
	v356.tier = v359
	v356.text = not v354 and "" or v354.plain
	v356.rect = v347
	local v360
	if v355 then
		v360 = v355.fps
	else
		v360 = nil
	end
	v356.fps = v360
	local v361
	if v355 then
		v361 = v355.ping
	else
		v361 = nil
	end
	v356.ping = v361
	local v362
	if v355 then
		v362 = v355.region
	else
		v362 = nil
	end
	v356.region = v362
	local v363
	if v355 then
		v363 = v355.id
	else
		v363 = nil
	end
	v356.id = v363
	local v364
	if v355 then
		v364 = v355.players
	else
		v364 = nil
	end
	v356.players = v364
	return v356
end
local function v_u_369(p365, p366) -- name: draws
	if string.find(p365.Name, "Shade") or p365.Name == "Grain" then
		return false
	end
	if p365.AbsoluteSize.X >= p366.X * 0.8 and p365.AbsoluteSize.Y >= p366.Y * 0.6 then
		return false
	end
	if p365.BackgroundTransparency < 0.9 then
		return true
	end
	if p365:IsA("TextLabel") or p365:IsA("TextButton") then
		local v367
		if p365.Text == "" then
			v367 = false
		else
			v367 = p365.TextTransparency < 0.9
		end
		return v367
	end
	if not (p365:IsA("ImageLabel") or p365:IsA("ImageButton")) then
		return false
	end
	local v368
	if p365.Image == "" then
		v368 = false
	else
		v368 = p365.ImageTransparency < 0.9
	end
	return v368
end
function v_u_3.overlaps() -- name: overlaps
	-- upvalues: (ref) v_u_166, (ref) v_u_164, (copy) v_u_1, (ref) v_u_163, (copy) v_u_187, (copy) v_u_369, (copy) v_u_3
	local v370 = {}
	local v371 = {}
	local v372 = v_u_166
	local v373 = v_u_164
	local v374 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not (v372 and (v372.Parent and (v373 and (v373.Enabled and v374)))) then
		return v370, v371
	end
	local v375 = v372.AbsolutePosition
	local v376 = v372.AbsoluteSize
	local v377 = v_u_163.viewport()
	for _, v378 in v374:GetChildren() do
		if not v378:IsA("ScreenGui") or (not v378.Enabled or v378 == v373) then
			continue
		end
		local v379
		if v378.DisplayOrder > v373.DisplayOrder then
			v379 = v371
		else
			v379 = v370
		end
		for _, v380 in v378:GetDescendants() do
			if #v379 >= 12 or not (v380:IsA("GuiObject") and (v_u_187(v380) and v_u_369(v380, v377))) then
				continue
			end
			local v381 = v380.AbsolutePosition
			local v382 = v380.AbsoluteSize
			if v380:IsA("TextLabel") and v380.BackgroundTransparency >= 0.9 then
				local v383, v384 = v_u_3.textSpan(v381.X, v382.X, v380.TextBounds.X, v380.TextXAlignment == Enum.TextXAlignment.Right and "right" or (v380.TextXAlignment == Enum.TextXAlignment.Center and "center" or "left"))
				v381 = Vector2.new(v383, v381.Y)
				v382 = Vector2.new(v384 - v383, v382.Y)
			end
			if v381.X >= v375.X + v376.X or (v381.X + v382.X <= v375.X or (v381.Y >= v375.Y + v376.Y or v381.Y + v382.Y <= v375.Y)) then
				continue
			end
			local v385 = v378.Name .. "." .. v380.Name
			table.insert(v379, v385)
		end
	end
	return v370, v371
end
function v_u_3.destroy() -- name: destroy
	-- upvalues: (copy) v_u_3, (ref) v_u_159, (copy) v_u_170, (copy) v_u_171, (ref) v_u_172, (ref) v_u_164, (ref) v_u_165, (ref) v_u_166, (ref) v_u_167
	v_u_3.disable()
	v_u_159 = false
	for _, v386 in v_u_170 do
		v386:Disconnect()
	end
	table.clear(v_u_170)
	for _, v387 in v_u_171 do
		v387()
	end
	table.clear(v_u_171)
	if v_u_172 then
		v_u_172()
		v_u_172 = nil
	end
	if v_u_164 then
		v_u_164:Destroy()
	end
	v_u_164 = nil
	v_u_165 = nil
	v_u_166 = nil
	v_u_167 = nil
end
return v_u_3