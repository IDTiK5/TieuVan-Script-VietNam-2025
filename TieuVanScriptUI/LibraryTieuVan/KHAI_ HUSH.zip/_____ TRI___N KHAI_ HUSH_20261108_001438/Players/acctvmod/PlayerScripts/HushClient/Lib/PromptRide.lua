-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PromptRide

local v_u_14 = {
	["VERSION"] = 1,
	["PROMPT_DIST"] = 6,
	["LOCK_KEY"] = "veh_locked",
	["PHASE_ACTIONS"] = {
		["VehEnter"] = true,
		["VehExit"] = true,
		["VehExitFast"] = true,
		["VehAbort"] = true
	},
	["TEXT"] = {
		["claimed"] = "Claimed by another squad",
		["closed"] = "Closed"
	},
	["busy"] = function(p1, p2) -- name: busy
		-- upvalues: (copy) v_u_14
		if p1 == nil then
			if p2 == nil then
				return false
			else
				return p2 == "Eject" and true or v_u_14.PHASE_ACTIONS[p2] == true
			end
		else
			return true
		end
	end,
	["distance"] = function(p3, p4) -- name: distance
		-- upvalues: (copy) v_u_14
		if p3 == "Vehicle" then
			if type(p4) == "number" and (p4 == p4 and v_u_14.PROMPT_DIST < p4) then
				return v_u_14.PROMPT_DIST
			else
				return nil
			end
		else
			return nil
		end
	end,
	["seatOf"] = function(p5) -- name: seatOf
		if type(p5) == "string" then
			local v6, v7 = string.match(p5, "^Veh_(%a+)_(Seat_%w+)$")
			if v6 == nil or v7 == nil then
				return nil, nil
			else
				return v6, v7
			end
		else
			return nil, nil
		end
	end,
	["predictArgs"] = function(p8, p9) -- name: predictArgs
		-- upvalues: (copy) v_u_14
		if p9 == false then
			return nil, nil
		else
			local v10, v11 = v_u_14.seatOf(p8)
			if v10 == "drive" or v10 == "ride" then
				return v11, "ENTER"
			else
				return nil, nil
			end
		end
	end,
	["stashPrefix"] = function(p12, p13) -- name: stashPrefix
		-- upvalues: (copy) v_u_14
		if p12 == v_u_14.LOCK_KEY then
			return v_u_14.TEXT.closed, true
		elseif p12 == nil or p12 ~= p13 then
			return v_u_14.TEXT.claimed, true
		else
			return nil, false
		end
	end
}
return v_u_14