-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MailRows

local v_u_232 = {
	["TUNE"] = {
		["warnDays"] = 3,
		["bmMax"] = 10,
		["bmDays"] = 14,
		["tiles"] = 3,
		["rowStep"] = 88,
		["headStep"] = 34,
		["noticeStep"] = 44,
		["logStep"] = 38,
		["logMax"] = 10
	},
	["TEXT"] = {
		["rule2"] = "Things you buy in the Blackmarket and the store wait here. Move them to your stash when you have room.",
		["ruleBm"] = " Blackmarket deliveries expire after {days} days.",
		["toStash"] = "To stash",
		["moving"] = "Moving",
		["expired"] = "Expired",
		["noLimit"] = "No time limit",
		["heldChip"] = "STASH FULL",
		["heldLine"] = "Your stash was full",
		["sectionDeliveries"] = "Deliveries",
		["sectionInsurance"] = "Insurance returns",
		["sectionReport"] = "Insurance report",
		["stashFull"] = "Your stash is full. Make room first.",
		["empty"] = "Nothing here yet. Your purchases and insured items from a raid wait here.",
		["cargoTitle"] = "Cargo package",
		["cargoHeld"] = "Your pilot flies one package at a time. Move this one to your stash before you call him again.",
		["cargoHeldShort"] = "Move this package to your stash before you call the pilot again.",
		["cargoExpired"] = "Your cargo package expired. The pilot got rid of it.",
		["cargoDebrief"] = "Cargo package waiting in your mail (7 days)."
	},
	["spanText"] = function(p1) -- name: spanText
		local v2 = tonumber(p1)
		local v3 = (v2 == nil or (v2 ~= v2 or (v2 == (1 / 0) or v2 == (-1 / 0)))) and 0 or v2
		local v4 = math.ceil(v3)
		local v5 = math.max(0, v4)
		if v5 <= 0 then
			return "now"
		elseif v5 < 60 then
			return ("%d s"):format(v5)
		else
			local v6 = v5 / 60
			local v7 = math.ceil(v6)
			local v8 = v7 // 60
			local v9 = v7 % 60
			if v8 > 0 then
				if v9 > 0 then
					return ("%d h %d min"):format(v8, v9)
				else
					return ("%d h"):format(v8)
				end
			else
				return ("%d min"):format(v9)
			end
		end
	end,
	["isOrderFill"] = function(p10) -- name: isOrderFill
		local v11
		if type(p10) == "table" and p10.src == "bm" then
			local v12 = p10.ref
			if type(v12) == "string" then
				local v13 = p10.ref
				v11 = string.sub(v13, 1, 1) == "f"
			else
				v11 = false
			end
		else
			v11 = false
		end
		return v11
	end,
	["isDelivery"] = function(p14) -- name: isDelivery
		local v15
		if type(p14) == "table" and p14.kind == "delivery" then
			local v16 = p14.id
			if type(v16) == "string" then
				v15 = p14.id ~= ""
			else
				v15 = false
			end
		else
			v15 = false
		end
		return v15
	end,
	["isHeld"] = function(p17) -- name: isHeld
		if type(p17) ~= "table" or p17.src ~= "store" then
			return false
		end
		local v18
		if p17.held == true then
			v18 = true
		else
			local v19 = p17.ref
			if type(v19) == "string" then
				local v20 = p17.ref
				v18 = string.sub(v20, 1, 2) == "ov"
			else
				v18 = false
			end
		end
		return v18
	end,
	["chipText"] = function(p21) -- name: chipText
		return p21 == "bm" and "BLACKMARKET" or (p21 == "store" and "STORE" or (p21 == "lift" and "CARGO" or "DELIVERY"))
	end,
	["expiryText"] = function(p22, p23) -- name: expiryText
		-- upvalues: (copy) v_u_232
		if type(p22) == "number" and p22 == p22 then
			local v24 = (p23 or v_u_232.TUNE.warnDays) * 86400
			if p22 <= 0 then
				return v_u_232.TEXT.expired, "gone"
			else
				local v25 = p22 <= v24 and "warn" or "ok"
				local v26 = p22 / 3600
				local v27 = math.ceil(v26)
				if v27 >= 24 then
					if v24 < p22 then
						local v28 = p22 / 86400
						return ("Expires in %d d"):format((math.ceil(v28))), v25
					else
						local v29 = v27 // 24
						local v30 = v27 % 24
						if v30 == 0 then
							return ("Expires in %d d"):format(v29), v25
						else
							return ("Expires in %d d %d h"):format(v29, v30), v25
						end
					end
				else
					return "Expires today, in " .. v_u_232.spanText(p22), v25
				end
			end
		else
			return v_u_232.TEXT.noLimit, "none"
		end
	end,
	["badgeText"] = function(p31) -- name: badgeText
		local v32 = tonumber(p31)
		local v33 = (v32 == nil or (v32 ~= v32 or (v32 == (1 / 0) or v32 == (-1 / 0)))) and 0 or v32
		local v34 = math.floor(v33)
		local v35 = math.max(0, v34)
		return v35 > 9 and "9+" or tostring(v35)
	end,
	["badgeCount"] = function(p36, p37, p38) -- name: badgeCount
		local v39 = tonumber(p36)
		local v40 = (v39 == nil or (v39 ~= v39 or (v39 == (1 / 0) or v39 == (-1 / 0)))) and 0 or v39
		local v41 = math.floor(v40)
		local v42 = math.max(0, v41)
		local v43 = tonumber(p37)
		local v44 = (v43 == nil or (v43 ~= v43 or (v43 == (1 / 0) or v43 == (-1 / 0)))) and 0 or v43
		local v45 = math.floor(v44)
		local v46 = v42 + math.max(0, v45)
		local v47 = tonumber(p38)
		local v48 = (v47 == nil or (v47 ~= v47 or (v47 == (1 / 0) or v47 == (-1 / 0)))) and 0 or v47
		local v49 = math.floor(v48)
		return v46 + math.max(0, v49)
	end,
	["model"] = function(p50, p51) -- name: model
		-- upvalues: (copy) v_u_232
		if not v_u_232.isDelivery(p50) then
			return nil
		end
		local v52 = {}
		local v53 = p50.items
		if type(v53) == "table" then
			for _, v54 in p50.items do
				if type(v54) ~= "table" then
					continue
				end
				local v55 = v54.id
				if type(v55) ~= "string" or v54.id == "" then
					continue
				end
				local v56 = {
					["id"] = v54.id
				}
				local v57 = v54.n
				local v58 = tonumber(v57)
				local v59 = (v58 == nil or (v58 ~= v58 or (v58 == (1 / 0) or v58 == (-1 / 0)))) and 1 or v58
				local v60 = math.floor(v59)
				v56.n = math.max(1, v60)
				local v61 = v54.name
				local v62
				if type(v61) == "string" then
					v62 = v54.name
				else
					v62 = nil
				end
				v56.name = v62
				table.insert(v52, v56)
			end
		end
		local v63 = p50.src ~= "bm" and (p50.src ~= "store" and p50.src ~= "lift") and "store" or p50.src
		if v63 ~= "bm" and v63 ~= "lift" then
			p51 = nil
		end
		local v64, v65 = v_u_232.expiryText(p51)
		local v66 = v_u_232.isHeld(p50)
		if v66 then
			v64 = v_u_232.TEXT.heldLine
			v65 = "none"
		end
		local v67 = p50.title
		local v68
		if type(v67) == "string" and p50.title ~= "" then
			v68 = p50.title
		else
			v68 = not (v52[1] and v52[1].name) and "Delivery" or v52[1].name
		end
		if v_u_232.isOrderFill(p50) then
			v68 = v68 .. " (buy order)"
		end
		local v69 = #v52
		local v70 = v_u_232.TUNE.tiles
		local v71 = {}
		for v72 = 1, math.min(v69, v70) do
			v71[v72] = v52[v72]
		end
		local v73 = 0
		for _, v74 in v52 do
			v73 = v73 + v74.n
		end
		local v75 = {
			["id"] = p50.id,
			["src"] = v63
		}
		local v76
		if v66 then
			v76 = v_u_232.TEXT.heldChip
		else
			v76 = v_u_232.chipText(v63)
		end
		v75.chip = v76
		v75.held = v66
		v75.title = v68
		v75.items = v52
		v75.tiles = v71
		local v77 = #v52 - #v71
		v75.more = math.max(0, v77)
		v75.kinds = #v52
		v75.units = v73
		local v78 = p50.at
		local v79 = tonumber(v78)
		v75.at = (v79 == nil or (v79 ~= v79 or (v79 == (1 / 0) or v79 == (-1 / 0)))) and 0 or v79
		v75.left = p51
		v75.text = v64
		v75.level = v65
		v75.expired = v65 == "gone"
		return v75
	end,
	["rows"] = function(p80, p81, p82) -- name: rows
		-- upvalues: (copy) v_u_232
		local v83 = {}
		if type(p80) ~= "table" then
			return v83
		end
		local v84 = tonumber(p81)
		local v85 = (v84 == nil or (v84 ~= v84 or (v84 == (1 / 0) or v84 == (-1 / 0)))) and 0 or v84
		local v86 = math.max(0, v85)
		local v87 = {}
		local v88 = 0
		for _, v89 in p80 do
			if not v_u_232.isDelivery(v89) or v87[v89.id] then
				continue
			end
			v87[v89.id] = true
			local v90 = nil
			local v91 = v89.expLeft
			if type(v91) == "number" and v89.expLeft == v89.expLeft then
				v90 = v89.expLeft - v86
			else
				local v92 = v89.exp
				if type(v92) == "number" and (v89.exp > 0 and p82) then
					v90 = v89.exp - p82
				end
			end
			local v93 = v_u_232.model(v89, v90)
			if not v93 then
				continue
			end
			v88 = v88 + 1
			v93.idx = v88
			table.insert(v83, v93)
		end
		table.sort(v83, function(p94, p95)
			local v96 = p94.level == "warn" and true or p94.level == "gone"
			if v96 == (p95.level == "warn" and true or p95.level == "gone") then
				if v96 and (p94.left or 0) ~= (p95.left or 0) then
					return (p94.left or 0) < (p95.left or 0)
				elseif p94.at == p95.at then
					return p94.idx < p95.idx
				else
					return p94.at > p95.at
				end
			else
				return v96
			end
		end)
		return v83
	end,
	["cargoSubtitle"] = function(p97, p98) -- name: cargoSubtitle
		local v99 = tonumber(p97)
		local v100 = (v99 == nil or (v99 ~= v99 or (v99 == (1 / 0) or v99 == (-1 / 0)))) and 0 or v99
		local v101 = math.floor(v100)
		local v102 = math.max(0, v101)
		local v103 = tonumber(p98)
		local v104 = (v103 == nil or (v103 ~= v103 or (v103 == (1 / 0) or v103 == (-1 / 0)))) and 0 or v103
		local v105 = math.floor(v104)
		local v106 = math.max(0, v105)
		local v107 = v106 // 86400
		local v108 = v106 % 86400 // 3600
		local v109 = v106 % 3600 // 60
		local v110
		if v107 > 0 then
			v110 = ("%dd %dh"):format(v107, v108)
		elseif v108 > 0 then
			v110 = ("%dh %dm"):format(v108, v109)
		else
			v110 = ("%dm"):format((math.max(1, v109)))
		end
		return (v102 == 1 and "1 item" or ("%d items"):format(v102)) .. ", expires in " .. v110
	end,
	["cargoModel"] = function(p111, p112) -- name: cargoModel
		-- upvalues: (copy) v_u_232
		if type(p111) == "table" then
			local v113 = p111.id
			if type(v113) == "string" and p111.id ~= "" then
				local v114 = tonumber(p112)
				local v115 = (v114 == nil or (v114 ~= v114 or (v114 == (1 / 0) or v114 == (-1 / 0)))) and 0 or v114
				local v116 = math.max(0, v115)
				local v117 = p111.expLeft
				local v118
				if type(v117) == "number" and p111.expLeft == p111.expLeft then
					v118 = p111.expLeft - v116
				else
					v118 = nil
				end
				local v119 = v_u_232.model
				local v120 = {
					["id"] = nil,
					["kind"] = "delivery",
					["src"] = "lift",
					["title"] = nil,
					["items"] = nil,
					["at"] = nil,
					["id"] = p111.id
				}
				local v121 = p111.title
				local v122
				if type(v121) == "string" and p111.title ~= "" then
					v122 = p111.title
				else
					v122 = v_u_232.TEXT.cargoTitle
				end
				v120.title = v122
				v120.items = p111.items
				v120.at = p111.at
				local v123 = v119(v120, v118)
				if not v123 then
					return nil
				end
				v123.cargo = true
				v123.idx = 0
				local v124
				if v118 == nil then
					v124 = false
				else
					v124 = v118 <= 0
				end
				v123.expired = v124
				local v125 = v_u_232.TUNE.warnDays * 86400
				v123.level = v123.expired and "gone" or ((v118 == nil or v118 > v125) and (p111.warn == true and "warn" or "ok") or "warn")
				local v126
				if v123.expired then
					v126 = v_u_232.TEXT.expired
				else
					v126 = v_u_232.cargoSubtitle(#v123.items, v118 or 0)
				end
				v123.text = v126
				return v123
			end
		end
		return nil
	end,
	["rowsOf"] = function(p127, p128, p129) -- name: rowsOf
		-- upvalues: (copy) v_u_232
		local v130 = type(p127) ~= "table" and {} or p127
		local v131 = v_u_232.rows(v130.entries, p128, p129)
		local v132 = v_u_232.cargoModel(v130.cargo, p128)
		if v132 then
			table.insert(v131, 1, v132)
		end
		return v131
	end,
	["layoutSig"] = function(p133, p134) -- name: layoutSig
		local v135 = {}
		for _, v136 in p133 do
			local v137 = v136.id
			local v138 = v136.kinds
			local v139 = v136.src
			table.insert(v135, ("%s:%d:%s"):format(v137, v138, v139))
		end
		local v140 = table.concat(v135, ",")
		local v141 = tonumber(p134)
		local v142 = (v141 == nil or (v141 ~= v141 or (v141 == (1 / 0) or v141 == (-1 / 0)))) and 0 or v141
		local v143 = math.floor(v142)
		if v143 > 0 then
			v140 = v140 .. "|n" .. v143
		end
		return v140
	end,
	["listHeight"] = function(p144, p145, p146, p147) -- name: listHeight
		-- upvalues: (copy) v_u_232
		local v148 = v_u_232.TUNE
		if p145 <= 0 and not p146 then
			return p144 <= 0 and 168 or p144 * v148.rowStep - 8
		end
		local v149 = 0
		if p146 then
			v149 = v149 + v148.noticeStep
		end
		if p145 > 0 then
			v149 = v149 + ((p147 == true and p144 <= 0 and 0 or v148.headStep) + p145 * v148.rowStep)
		end
		if p144 > 0 then
			v149 = v149 + ((p145 <= 0 and 0 or v148.headStep) + p144 * v148.rowStep)
		end
		if p145 <= 0 and p144 <= 0 then
			v149 = v149 + 176
		end
		return v149 - 8
	end,
	["logRows"] = function(p150) -- name: logRows
		-- upvalues: (copy) v_u_232
		local v151 = {}
		if type(p150) ~= "table" then
			return v151
		end
		for _, v152 in p150 do
			if #v151 >= v_u_232.TUNE.logMax then
				break
			end
			if type(v152) ~= "table" then
				continue
			end
			local v153 = v152.id
			if type(v153) ~= "string" then
				continue
			end
			local v154 = v152.text
			if type(v154) ~= "string" or v152.text == "" then
				continue
			end
			local v155 = v152.kind ~= "ok" and (v152.kind ~= "warn" and v152.kind ~= "info") and "muted" or v152.kind
			local v156 = v152.name
			local v157
			if type(v156) == "string" and v152.name ~= "" then
				local v158 = v152.name
				v157 = string.sub(v158, 1, 60)
			else
				v157 = "Item"
			end
			local v159 = v152.text
			local v160 = string.sub(v159, 1, 60)
			local v161 = v152.hint
			if type(v161) == "string" and v152.hint ~= "" then
				local v162 = v160 .. ", " .. v152.hint
				v160 = string.sub(v162, 1, 80)
			end
			local v163 = {}
			local v164 = v152.id
			v163.id = string.sub(v164, 1, 40)
			v163.name = v157
			v163.text = v160
			v163.kind = v155
			table.insert(v151, v163)
		end
		return v151
	end,
	["logSig"] = function(p165) -- name: logSig
		local v166 = {}
		for _, v167 in p165 do
			local v168 = v167.id .. ":" .. v167.text
			table.insert(v166, v168)
		end
		return table.concat(v166, ",")
	end,
	["logHeight"] = function(p169) -- name: logHeight
		-- upvalues: (copy) v_u_232
		return p169 <= 0 and 0 or v_u_232.TUNE.headStep + p169 * v_u_232.TUNE.logStep
	end,
	["allLabel"] = function(p170, p171) -- name: allLabel
		local v172 = math.max(0, p170) + math.max(0, p171)
		if p171 > 0 and p170 <= 0 then
			return ("To stash all (%d)"):format(v172)
		else
			return ("Claim all (%d)"):format(v172)
		end
	end,
	["allVisible"] = function(p173, p174) -- name: allVisible
		return math.max(0, p173) + math.max(0, p174) >= 2
	end,
	["summary"] = function(p175, p176, p177, p178) -- name: summary
		if p178 <= 0 then
			return p177 == 0 and "" or ("%d READY  \194\183  %d ON THE WAY"):format(p175, p176)
		end
		local v179 = p178 == 1 and "1 TO MOVE" or ("%d TO MOVE"):format(p178)
		if p177 > 0 then
			v179 = v179 .. ("  \194\183  %d READY  \194\183  %d ON THE WAY"):format(p175, p176)
		end
		return v179
	end,
	["capText"] = function(p180, p181, p182, p183, p184) -- name: capText
		if p184 <= 0 then
			return ("MAILBOX %d / %d"):format(p180, p181), false
		elseif p182 > 0 then
			return ("BLACKMARKET %d / %d"):format(p182, p183), p183 <= p182
		elseif p180 > 0 then
			return ("MAILBOX %d / %d"):format(p180, p181), false
		else
			return "", false
		end
	end,
	["expiredText"] = function(p185, p186) -- name: expiredText
		-- upvalues: (copy) v_u_232
		local v187 = tonumber(p185)
		local v188 = (v187 == nil or (v187 ~= v187 or (v187 == (1 / 0) or v187 == (-1 / 0)))) and 0 or v187
		local v189 = math.floor(v188)
		local v190 = math.max(0, v189)
		if p186 == true and v190 == 1 then
			return v_u_232.TEXT.cargoExpired
		else
			return v190 == 1 and "1 delivery expired" or ("%d deliveries expired"):format(v190)
		end
	end,
	["noteStep"] = function(p191, p192, p193) -- name: noteStep
		local v194 = tonumber(p191)
		local v195 = (v194 == nil or (v194 ~= v194 or (v194 == (1 / 0) or v194 == (-1 / 0)))) and 0 or v194
		local v196 = math.floor(v195)
		local v197 = math.max(0, v196)
		local v198 = tonumber(p192)
		local v199 = (v198 == nil or (v198 ~= v198 or (v198 == (1 / 0) or v198 == (-1 / 0)))) and 0 or v198
		local v200 = math.floor(v199)
		local v201 = math.max(0, v200)
		local v202 = tonumber(p193)
		local v203 = (v202 == nil or (v202 ~= v202 or (v202 == (1 / 0) or v202 == (-1 / 0)))) and 0 or v202
		local v204 = math.floor(v203)
		if v204 <= 0 then
			return 0, v201
		elseif v197 < v204 then
			return v204, v201 + (v204 - v197)
		else
			return v197, v201
		end
	end,
	["ruleLine"] = function(p205, p206) -- name: ruleLine
		-- upvalues: (copy) v_u_232
		if not p205 then
			return nil
		end
		local v207 = v_u_232.TUNE.bmDays
		local v208 = tonumber(p206)
		if v208 ~= nil and (v208 == v208 and (v208 ~= (1 / 0) and v208 ~= (-1 / 0))) then
			v207 = v208
		end
		local v209 = math.floor(v207)
		if v209 < 1 then
			v209 = v_u_232.TUNE.bmDays
		end
		return v_u_232.TEXT.rule2 .. v_u_232.TEXT.ruleBm:gsub("{days}", (tostring(v209)))
	end,
	["partialText"] = function(p210, p211) -- name: partialText
		local v212 = tonumber(p210)
		local v213 = (v212 == nil or (v212 ~= v212 or (v212 == (1 / 0) or v212 == (-1 / 0)))) and 0 or v212
		local v214 = math.floor(v213)
		local v215 = math.max(0, v214)
		local v216 = tonumber(p211)
		local v217 = (v216 == nil or (v216 ~= v216 or (v216 == (1 / 0) or v216 == (-1 / 0)))) and 0 or v216
		local v218 = math.floor(v217)
		return ("%d of %d moved. Make room for the rest."):format(v215, v215 + math.max(0, v218))
	end,
	["claimText"] = function(p219, p220) -- name: claimText
		-- upvalues: (copy) v_u_232
		if type(p219) == "table" then
			local v221 = p219.msg
			if type(v221) == "string" and p219.msg ~= "" then
				return p219.msg
			else
				local v222 = p219.data
				if p219.ok == false then
					if type(v222) == "table" and v222.full == true then
						return v_u_232.TEXT.stashFull
					else
						return nil
					end
				else
					if type(v222) == "table" then
						local v223 = v222.moved
						if type(v223) == "number" then
							local v224 = v222.left
							if type(v224) == "number" and v222.left > 0 then
								return v_u_232.partialText(v222.moved, v222.left)
							else
								return (not p220 or p220 == "") and "Moved to your stash" or p220 .. " is in your stash"
							end
						end
					end
					return nil
				end
			end
		else
			return nil
		end
	end,
	["isPartial"] = function(p225) -- name: isPartial
		if type(p225) ~= "table" or p225.ok == false then
			return false
		end
		local v226 = p225.data
		if type(v226) ~= "table" then
			return false
		end
		local v227
		if v226.full == true then
			v227 = true
		else
			local v228 = v226.left
			if type(v228) == "number" then
				v227 = v226.left > 0
			else
				v227 = false
			end
		end
		return v227
	end,
	["pulseOn"] = function(p229, p230) -- name: pulseOn
		for _, v231 in p229 do
			if p230[v231] then
				continue
			end
			return true
		end
		return false
	end
}
local v_u_233 = nil
v_u_232.heldOnFn = nil
function v_u_232.heldOn() -- name: heldOn
	-- upvalues: (copy) v_u_232, (ref) v_u_233
	local v234 = v_u_232.heldOnFn
	if v234 ~= nil then
		local v235, v236 = pcall(v234)
		if v235 then
			v235 = v236 == false
		end
		return not v235
	end
	local function v240()
		-- upvalues: (ref) v_u_233
		if v_u_233 == nil then
			local v237 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
			local v238
			if v237 then
				v238 = v237:FindFirstChild("Shared")
			else
				v238 = nil
			end
			local v239
			if v238 then
				v239 = v238:FindFirstChild("Config")
			else
				v239 = nil
			end
			if v239 == nil then
				return nil
			end
			v_u_233 = require(v239)
		end
		return v_u_233.flag("OverflowMail")
	end
	local v241, v242 = pcall(v240)
	if v241 then
		v241 = v242 == false
	end
	return not v241
end
function v_u_232.cardTip(p243, p244, p245, p246) -- name: cardTip
	-- upvalues: (copy) v_u_232
	if p245 then
		if p246 == nil then
			p246 = v_u_232.heldOn()
		end
		p243 = p246 and "Letters from the HUSH team, things you bought, items that did not fit your stash, and insured items that were lost in a raid." or "Letters from the HUSH team, things you bought, and insured items that were lost in a raid."
	end
	if p244 > 0 then
		p243 = ("%d %s waiting for your stash. %s"):format(p244, p244 == 1 and "delivery" or "deliveries", p243)
	end
	return p243
end
function v_u_232.tipLines(p247) -- name: tipLines
	local v248 = {}
	for _, v249 in p247.items do
		local v250 = "%s%s"
		local v251 = v249.name
		local v252
		if type(v251) == "string" and v249.name ~= "" then
			v252 = v249.name
		else
			v252 = v249.id
		end
		local v253 = v249.n <= 1 and "" or " x" .. v249.n
		table.insert(v248, v250:format(v252, v253))
	end
	return v248
end
return v_u_232