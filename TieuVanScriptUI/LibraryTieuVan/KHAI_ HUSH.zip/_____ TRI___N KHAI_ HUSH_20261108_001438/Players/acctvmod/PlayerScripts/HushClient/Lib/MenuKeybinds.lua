-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuKeybinds

local v_u_1 = game:GetService("Players").LocalPlayer
local v_u_2 = {
	{ "moveUp", "Move forward" },
	{ "moveDown", "Move back" },
	{ "moveLeft", "Move left" },
	{ "moveRight", "Move right" },
	{ "fire", "Fire" },
	{ "aim", "Aim" },
	{ "reload", "Reload" },
	{ "interact", "Interact / use" },
	{ "promptDown", "Next interaction" },
	{ "sprint", "Sprint" },
	{ "sneak", "Sneak" },
	{ "melee", "Melee / punch" },
	{ "throw", "Throw" },
	{ "swap", "Swap weapon" },
	{ "primary", "Primary weapon" },
	{ "secondary", "Sidearm" },
	{ "meleeSlot", "Melee weapon" },
	{ "quick1", "Quick slot 1" },
	{ "quick2", "Quick slot 2" },
	{ "quick3", "Quick slot 3" },
	{ "quick4", "Quick slot 4" },
	{ "inventory", "Inventory" },
	{ "rotateItem", "Rotate item (inventory)" },
	{ "flashlight", "Flashlight" },
	{ "nightVision", "Night vision" },
	{ "tasks", "Fold mission list" },
	{ "hideUi", "Hide interface" },
	{ "ping", "Quick calls" },
	{ "chat", "Squad chat" },
	{ "fireMode", "Fire mode" },
	{ "map", "Map" },
	{ "extracts", "Show extracts" },
	{ "camLeft", "Rotate camera left" },
	{ "camRight", "Rotate camera right" },
	{ "viewToggle", "Switch first / third person" },
	{ "menu", "Settings (raid) / menu (hideout)" }
}
local v_u_3 = {}
local v_u_4 = {}
for _, v5 in v_u_2 do
	v_u_3[v5[1]] = v5[2]
end
v_u_4.LABEL = v_u_3
function v_u_4.labelOf(p6) -- name: labelOf
	-- upvalues: (copy) v_u_3
	local v7 = v_u_3[p6]
	if not v7 then
		local v8 = string.gsub(p6, "(%u)", " %1")
		v7 = string.upper((string.sub(v8, 1, 1))) .. string.lower((string.sub(v8, 2)))
	end
	return v7
end
function v_u_4.refuseText(p9, p10, p11, p12) -- name: refuseText
	return p9 ~= "reserved" and (type(p11) == "string" and (string.sub(p11, 1, 4) == "move" and (type(p12) == "string" and string.sub(p12, 1, 11) == "MouseButton")) and "Movement can only use keyboard keys." or "That key cannot be used. Try another one.") or p10 .. " is reserved and cannot be bound."
end
function v_u_4.clearedText(p13, p14) -- name: clearedText
	if type(p14) == "table" and (p14[1] ~= nil or p14[2] ~= nil) then
		return p13 .. ": slot cleared"
	else
		return p13 .. ": NOT BOUND. RESET on its row puts the default back."
	end
end
function v_u_4.new(p_u_15, p16, p17) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_1
	local v_u_18 = p17 or {}
	local v_u_19 = p_u_15.ui
	local v_u_20 = p_u_15.theme
	local v_u_21 = v_u_20.color
	local v_u_22 = p_u_15.cctx and p_u_15.cctx.controllers
	if v_u_22 then
		v_u_22 = p_u_15.cctx.controllers.Input
	end
	local v_u_23 = {}
	local v24 = v_u_18.width
	local v25 = tonumber(v24) or 900
	local v_u_26 = math.floor(v25)
	local v_u_27 = v_u_19.new("Frame", {
		["Name"] = "Keybinds",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(0, v_u_26, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v_u_18.order or 0
	}, p16)
	v_u_19.layout(v_u_27, "v", 8)
	local v_u_28 = {}
	local v_u_29 = nil
	local v_u_30 = nil
	local v_u_31 = nil
	local v_u_32 = {}
	local v_u_33 = {}
	local v_u_34 = nil
	local v_u_35 = nil
	local v_u_36 = nil
	local v_u_37 = ""
	local function v_u_52() -- name: ids
		-- upvalues: (copy) v_u_22, (copy) p_u_15, (ref) v_u_2
		local v38 = {}
		local v39 = {}
		local v40
		if v_u_22 == nil then
			v40 = false
		else
			local v41 = v_u_22.keyBinding
			if type(v41) == "function" then
				local v42 = v_u_22.rebindKey
				v40 = type(v42) == "function"
			else
				v40 = false
			end
		end
		local v43 = not v40 and {} or v_u_22.keyBindIds()
		local v44 = {}
		for _, v45 in v43 do
			v44[v45] = true
		end
		local function v46()
			-- upvalues: (ref) p_u_15
			return p_u_15.cctx.lib.PlayModeSel.liveShown(p_u_15.cctx)
		end
		local v47, v48 = pcall(v46)
		if v47 and v48 == false then
			v39.viewToggle = true
		end
		for _, v49 in v_u_2 do
			if not v44[v49[1]] or v39[v49[1]] then
				continue
			end
			local v50 = v49[1]
			table.insert(v38, v50)
			v39[v49[1]] = true
		end
		for _, v51 in v43 do
			if v39[v51] then
				continue
			end
			table.insert(v38, v51)
		end
		return v38
	end
	local function v_u_62() -- name: save
		-- upvalues: (copy) v_u_22, (copy) p_u_15, (copy) v_u_18
		local v53
		if v_u_22 == nil then
			v53 = false
		else
			local v54 = v_u_22.keyBinding
			if type(v54) == "function" then
				local v55 = v_u_22.rebindKey
				v53 = type(v55) == "function"
			else
				v53 = false
			end
		end
		if v53 then
			local v_u_56 = v_u_22.keyBindingString()
			local function v59()
				-- upvalues: (ref) p_u_15, (copy) v_u_56
				local v57 = p_u_15.profile
				if type(v57) == "table" then
					local v58 = p_u_15.profile.settings
					if type(v58) ~= "table" then
						p_u_15.profile.settings = {}
					end
					p_u_15.profile.settings.keybinds = v_u_56
				end
			end
			pcall(v59)
			local v60 = v_u_18.save
			if type(v60) == "function" then
				local v61 = v_u_18.save
				pcall(v61, v_u_56)
			end
		end
	end
	local v_u_63 = "Keyboard"
	local function v64()
		-- upvalues: (ref) v_u_63, (copy) v_u_22
		v_u_63 = v_u_22.device()
	end
	pcall(v64)
	local v_u_65 = v_u_63 == "Touch" and "Tap a binding, then press the new key on a keyboard. Touch and controller controls stay as they are." or (v_u_63 == "Gamepad" and "Keyboard and mouse bindings. Select one and press the new key on a keyboard. Controller controls stay as they are." or "Click a binding, then press the new key or mouse button. Controller and touch controls stay as they are.")
	local function v_u_91(p66) -- name: paintRow
		-- upvalues: (copy) v_u_28, (copy) v_u_22, (ref) v_u_29, (copy) v_u_21
		local v67 = v_u_28[p66]
		if v67 then
			local v68
			if v_u_22 == nil then
				v68 = false
			else
				local v69 = v_u_22.keyBinding
				if type(v69) == "function" then
					local v70 = v_u_22.rebindKey
					v68 = type(v70) == "function"
				else
					v68 = false
				end
			end
			if v68 then
				local v71 = v_u_22.keyBinding(p66) or {}
				local v72 = v_u_22.keyDefault(p66) or {}
				local v73
				if v71 == nil or v72 == nil then
					v73 = v71 == v72
				elseif #v71 == #v72 then
					for v74, v75 in v71 do
						if v72[v74] == v75 then
							continue
						end
						v73 = false
					end
					v73 = true
				else
					v73 = false
				end
				local v76 = not v73
				for v77, v78 in { v67.p, v67.s } do
					local v79
					if v_u_29 == nil or v_u_29.id ~= p66 then
						v79 = false
					else
						v79 = v_u_29.slot == v77
					end
					local v80 = v71[v77]
					local v81
					if v79 then
						v81 = "PRESS A KEY"
					elseif v80 == nil then
						v81 = "-"
					else
						local v82
						if v_u_22 == nil then
							v82 = false
						else
							local v83 = v_u_22.keyBinding
							if type(v83) == "function" then
								local v84 = v_u_22.rebindKey
								v82 = type(v84) == "function"
							else
								v82 = false
							end
						end
						if v82 then
							v81 = v_u_22.keyName(v80)
						else
							v81 = v80
						end
					end
					v78.Text = v81
					local v85
					if v77 == 1 and (v71[1] == nil and v71[2] == nil) then
						v85 = not v79
					else
						v85 = false
					end
					if v85 then
						v78.Text = "NOT BOUND"
					end
					local v86
					if v80 == nil then
						v86 = false
					else
						v86 = v72[v77] == v80
					end
					local v87
					if v79 then
						v87 = v_u_21.accent
					elseif v85 then
						v87 = v_u_21.danger
					elseif v80 == nil then
						v87 = v_u_21.muted
					elseif v86 then
						v87 = v_u_21.text
					else
						v87 = v_u_21.accent
					end
					v78.TextColor3 = v87
					local v88 = v78:FindFirstChildOfClass("UIStroke")
					if v88 then
						local v89
						if v79 then
							v89 = v_u_21.accent
						else
							v89 = v_u_21.line
						end
						v88.Color = v89
					end
					local v90
					if v79 then
						v90 = v_u_21.accentDeep
					else
						v90 = v_u_21.raised
					end
					v78.BackgroundColor3 = v90
				end
				v67.r.Visible = v76
				v67.r.Selectable = v76
				return
			end
		end
	end
	local function v_u_96() -- name: paintAll
		-- upvalues: (copy) v_u_28, (copy) v_u_91, (ref) v_u_1, (ref) v_u_29, (ref) v_u_35, (ref) v_u_36
		for v92 in v_u_28 do
			v_u_91(v92)
		end
		local v93 = v_u_1
		local v94 = "KeybindsCapture"
		local v95
		if v_u_29 then
			v95 = v_u_29.id .. ":" .. v_u_29.slot
		else
			v95 = nil
		end
		v93:SetAttribute(v94, v95)
		if v_u_35 then
			v_u_35.Visible = v_u_29 ~= nil
			v_u_36.Visible = v_u_29 ~= nil
		end
	end
	local function v_u_184(p_u_97, p_u_98, p_u_99) -- name: apply
		-- upvalues: (copy) v_u_22, (copy) v_u_62, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (copy) v_u_19, (ref) v_u_29, (copy) v_u_21, (copy) v_u_96, (ref) v_u_30, (ref) v_u_31, (ref) v_u_65, (ref) v_u_4
		local v100, v101 = v_u_22.rebindKey(p_u_97, p_u_98, p_u_99, false)
		if v100 then
			v_u_62()
			local v102 = v_u_3[p_u_97]
			if not v102 then
				local v103 = string.gsub(p_u_97, "(%u)", " %1")
				v102 = string.upper((string.sub(v103, 1, 1))) .. string.lower((string.sub(v103, 2)))
			end
			local v104 = ": "
			if p_u_99 == nil then
				p_u_99 = "-"
			else
				local v105
				if v_u_22 == nil then
					v105 = false
				else
					local v106 = v_u_22.keyBinding
					if type(v106) == "function" then
						local v107 = v_u_22.rebindKey
						v105 = type(v107) == "function"
					else
						v105 = false
					end
				end
				if v105 then
					p_u_99 = v_u_22.keyName(p_u_99)
				end
			end
			local v108 = v102 .. v104 .. p_u_99
			v_u_37 = v108
			if v_u_34 then
				v_u_19.setText(v_u_34, v108)
				local v109 = v_u_34
				local v110
				if v_u_29 then
					v110 = v_u_21.accent
				else
					v110 = v_u_21.text2
				end
				v109.TextColor3 = v110
			end
			v_u_96()
			return
		elseif type(v101) == "table" and #v101 > 0 then
			local v111 = {}
			for _, v112 in v101 do
				local v113 = v_u_3[v112]
				if not v113 then
					local v114 = string.gsub(v112, "(%u)", " %1")
					v113 = string.upper((string.sub(v114, 1, 1))) .. string.lower((string.sub(v114, 2)))
				end
				table.insert(v111, v113)
			end
			local v115 = (v_u_22.keyBinding(p_u_97) or {})[p_u_98]
			local v116 = string.format
			local v117 = "%s is already bound to %s."
			local v118
			if p_u_99 == nil then
				v118 = "-"
			else
				local v119
				if v_u_22 == nil then
					v119 = false
				else
					local v120 = v_u_22.keyBinding
					if type(v120) == "function" then
						local v121 = v_u_22.rebindKey
						v119 = type(v121) == "function"
					else
						v119 = false
					end
				end
				if v119 then
					v118 = v_u_22.keyName(p_u_99)
				else
					v118 = p_u_99
				end
			end
			local v122 = v116(v117, v118, table.concat(v111, ", "))
			local v123
			if v115 then
				local v124 = string.format
				local v125 = " Swap gives %s to %s."
				if v115 == nil then
					v115 = "-"
				else
					local v126
					if v_u_22 == nil then
						v126 = false
					else
						local v127 = v_u_22.keyBinding
						if type(v127) == "function" then
							local v128 = v_u_22.rebindKey
							v126 = type(v128) == "function"
						else
							v126 = false
						end
					end
					if v126 then
						v115 = v_u_22.keyName(v115)
					end
				end
				v123 = v124(v125, v115, v111[1])
			else
				v123 = " Swap leaves " .. v111[1] .. " without it."
			end
			local v129 = v122 .. v123
			local function v_u_145(p130) -- name: answer
				-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_22, (copy) p_u_97, (copy) p_u_98, (copy) p_u_99, (ref) v_u_62, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_29, (ref) v_u_21, (ref) v_u_65, (ref) v_u_96
				v_u_30 = nil
				v_u_31 = nil
				if p130 == "swap" then
					if v_u_22.rebindKey(p_u_97, p_u_98, p_u_99, true) then
						v_u_62()
						local v131 = p_u_97
						local v132 = v_u_3[v131]
						if not v132 then
							local v133 = string.gsub(v131, "(%u)", " %1")
							v132 = string.upper((string.sub(v133, 1, 1))) .. string.lower((string.sub(v133, 2)))
						end
						local v134 = ": "
						local v135 = p_u_99
						if v135 == nil then
							v135 = "-"
						else
							local v136
							if v_u_22 == nil then
								v136 = false
							else
								local v137 = v_u_22.keyBinding
								if type(v137) == "function" then
									local v138 = v_u_22.rebindKey
									v136 = type(v138) == "function"
								else
									v136 = false
								end
							end
							if v136 then
								v135 = v_u_22.keyName(v135)
							end
						end
						local v139 = v132 .. v134 .. v135 .. " (swapped)"
						v_u_37 = v139
						if v_u_34 then
							v_u_19.setText(v_u_34, v139)
							local v140 = v_u_34
							local v141
							if v_u_29 then
								v141 = v_u_21.accent
							else
								v141 = v_u_21.text2
							end
							v140.TextColor3 = v141
						end
					end
				else
					local v142 = v_u_65
					v_u_37 = v142
					if v_u_34 then
						v_u_19.setText(v_u_34, v142)
						local v143 = v_u_34
						local v144
						if v_u_29 then
							v144 = v_u_21.accent
						else
							v144 = v_u_21.text2
						end
						v143.TextColor3 = v144
					end
				end
				v_u_96()
			end
			v_u_31 = function(p146)
				-- upvalues: (ref) v_u_30, (copy) v_u_145
				local v147 = v_u_30
				v_u_145(p146)
				if v147 then
					local v148 = v147.close
					pcall(v148)
				end
			end
			local v166 = {
				["title"] = "Key already in use",
				["body"] = nil,
				["width"] = 520,
				["buttons"] = nil,
				["onClose"] = nil,
				["body"] = v129,
				["buttons"] = {
					{
						["text"] = "Cancel",
						["kind"] = "secondary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_65, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_29, (ref) v_u_21, (ref) v_u_96
							v_u_30 = nil
							v_u_31 = nil
							local v149 = v_u_65
							v_u_37 = v149
							if v_u_34 then
								v_u_19.setText(v_u_34, v149)
								local v150 = v_u_34
								local v151
								if v_u_29 then
									v151 = v_u_21.accent
								else
									v151 = v_u_21.text2
								end
								v150.TextColor3 = v151
							end
							v_u_96()
						end
					},
					{
						["text"] = "Swap",
						["kind"] = "primary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_22, (copy) p_u_97, (copy) p_u_98, (copy) p_u_99, (ref) v_u_62, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_29, (ref) v_u_21, (ref) v_u_96
							v_u_30 = nil
							v_u_31 = nil
							if v_u_22.rebindKey(p_u_97, p_u_98, p_u_99, true) then
								v_u_62()
								local v152 = p_u_97
								local v153 = v_u_3[v152]
								if not v153 then
									local v154 = string.gsub(v152, "(%u)", " %1")
									v153 = string.upper((string.sub(v154, 1, 1))) .. string.lower((string.sub(v154, 2)))
								end
								local v155 = ": "
								local v156 = p_u_99
								if v156 == nil then
									v156 = "-"
								else
									local v157
									if v_u_22 == nil then
										v157 = false
									else
										local v158 = v_u_22.keyBinding
										if type(v158) == "function" then
											local v159 = v_u_22.rebindKey
											v157 = type(v159) == "function"
										else
											v157 = false
										end
									end
									if v157 then
										v156 = v_u_22.keyName(v156)
									end
								end
								local v160 = v153 .. v155 .. v156 .. " (swapped)"
								v_u_37 = v160
								if v_u_34 then
									v_u_19.setText(v_u_34, v160)
									local v161 = v_u_34
									local v162
									if v_u_29 then
										v162 = v_u_21.accent
									else
										v162 = v_u_21.text2
									end
									v161.TextColor3 = v162
								end
							end
							v_u_96()
						end
					}
				},
				["onClose"] = function() -- name: onClose
					-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_65, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_29, (ref) v_u_21, (ref) v_u_96
					if v_u_30 then
						v_u_30 = nil
						v_u_31 = nil
						local v163 = v_u_65
						v_u_37 = v163
						if v_u_34 then
							v_u_19.setText(v_u_34, v163)
							local v164 = v_u_34
							local v165
							if v_u_29 then
								v165 = v_u_21.accent
							else
								v165 = v_u_21.text2
							end
							v164.TextColor3 = v165
						end
						v_u_96()
					end
				end
			}
			v_u_30 = v_u_19.modal(v166)
			local function v168()
				-- upvalues: (ref) v_u_30
				for _, v167 in v_u_30.frame:FindFirstChild("Buttons", true):GetChildren() do
					if not v167:IsA("GuiButton") then
						continue
					end
					v167.Name = v167.LayoutOrder == 1 and "Cancel" or "Swap"
				end
			end
			pcall(v168)
			local v169 = v_u_3[p_u_97]
			if not v169 then
				local v170 = string.gsub(p_u_97, "(%u)", " %1")
				v169 = string.upper((string.sub(v170, 1, 1))) .. string.lower((string.sub(v170, 2)))
			end
			local v171 = ": "
			if p_u_99 == nil then
				p_u_99 = "-"
			else
				local v172
				if v_u_22 == nil then
					v172 = false
				else
					local v173 = v_u_22.keyBinding
					if type(v173) == "function" then
						local v174 = v_u_22.rebindKey
						v172 = type(v174) == "function"
					else
						v172 = false
					end
				end
				if v172 then
					p_u_99 = v_u_22.keyName(p_u_99)
				end
			end
			local v175 = v169 .. v171 .. p_u_99 .. " is in use. Swap or cancel."
			v_u_37 = v175
			if v_u_34 then
				v_u_19.setText(v_u_34, v175)
				local v176 = v_u_34
				local v177
				if v_u_29 then
					v177 = v_u_21.accent
				else
					v177 = v_u_21.text2
				end
				v176.TextColor3 = v177
			end
			v_u_96()
		else
			local v178 = v_u_4.refuseText
			local v179
			if p_u_99 == nil then
				v179 = "-"
			else
				local v180
				if v_u_22 == nil then
					v180 = false
				else
					local v181 = v_u_22.keyBinding
					if type(v181) == "function" then
						local v182 = v_u_22.rebindKey
						v180 = type(v182) == "function"
					else
						v180 = false
					end
				end
				if v180 then
					v179 = v_u_22.keyName(p_u_99)
				else
					v179 = p_u_99
				end
			end
			local v183 = v178(v101, v179, p_u_97, p_u_99)
			v_u_37 = v183
			if v_u_34 then
				v_u_19.setText(v_u_34, v183)
				v_u_34.TextColor3 = v_u_21.danger
			end
			v_u_96()
		end
	end
	local function v_u_227(p_u_185, p_u_186) -- name: startCapture
		-- upvalues: (copy) v_u_22, (ref) v_u_30, (ref) v_u_29, (copy) v_u_96, (copy) v_u_32, (ref) v_u_36, (copy) v_u_62, (ref) v_u_4, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (copy) v_u_19, (copy) v_u_21, (ref) v_u_65, (copy) v_u_184
		local v187
		if v_u_22 == nil then
			v187 = false
		else
			local v188 = v_u_22.keyBinding
			if type(v188) == "function" then
				local v189 = v_u_22.rebindKey
				v187 = type(v189) == "function"
			else
				v187 = false
			end
		end
		if v187 and not v_u_30 then
			if v_u_29 then
				local v190 = v_u_29.cancel
				pcall(v190)
				v_u_29 = nil
			end
			v_u_96()
			local v_u_191 = {
				["id"] = p_u_185,
				["slot"] = p_u_186,
				["cancel"] = function() end
			}
			local v_u_192 = os.clock()
			v_u_29 = v_u_191
			v_u_191.cancel = v_u_22.captureKey(function(p193)
				-- upvalues: (ref) v_u_29, (copy) v_u_191, (ref) v_u_32, (ref) v_u_36, (ref) v_u_22, (copy) p_u_185, (copy) p_u_186, (ref) v_u_62, (ref) v_u_4, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21, (ref) v_u_96, (ref) v_u_65, (copy) v_u_192, (ref) v_u_184
				if v_u_29 == v_u_191 then
					v_u_29 = nil
					if p193 and string.sub(p193, 1, 11) == "MouseButton" then
						if v_u_32[v_u_36] then
							if v_u_22.rebindKey(p_u_185, p_u_186, nil) then
								v_u_62()
							end
							local v194 = p_u_185
							local v195 = v_u_4.clearedText
							local v196 = v_u_3[v194]
							if not v196 then
								local v197 = string.gsub(v194, "(%u)", " %1")
								v196 = string.upper((string.sub(v197, 1, 1))) .. string.lower((string.sub(v197, 2)))
							end
							local v198
							if v_u_22 == nil then
								v198 = false
							else
								local v199 = v_u_22.keyBinding
								if type(v199) == "function" then
									local v200 = v_u_22.rebindKey
									v198 = type(v200) == "function"
								else
									v198 = false
								end
							end
							local v201
							if v198 then
								v201 = v_u_22.keyBinding(v194)
							else
								v201 = nil
							end
							local v202, v203 = v195(v196, v201)
							v_u_37 = v202
							if v_u_34 then
								v_u_19.setText(v_u_34, v202)
								local v204 = v_u_34
								local v205
								if v203 then
									v205 = v_u_21.danger
								elseif v_u_29 then
									v205 = v_u_21.accent
								else
									v205 = v_u_21.text2
								end
								v204.TextColor3 = v205
							end
							v_u_96()
							return
						end
						for v206, v207 in v_u_32 do
							if not (v207 and v206.Parent) then
								continue
							end
							local v208 = v_u_65
							v_u_37 = v208
							if v_u_34 then
								v_u_19.setText(v_u_34, v208)
								local v209 = v_u_34
								local v210
								if v_u_29 then
									v210 = v_u_21.accent
								else
									v210 = v_u_21.text2
								end
								v209.TextColor3 = v210
							end
							v_u_96()
							return
						end
					end
					if p193 == nil then
						local v211 = os.clock() - v_u_192 >= 9.5 and "Nothing was pressed for 10 seconds, so the binding stayed as it was." or v_u_65
						v_u_37 = v211
						if v_u_34 then
							v_u_19.setText(v_u_34, v211)
							local v212 = v_u_34
							local v213
							if v_u_29 then
								v213 = v_u_21.accent
							else
								v213 = v_u_21.text2
							end
							v212.TextColor3 = v213
						end
						v_u_96()
					else
						v_u_184(p_u_185, p_u_186, p193)
					end
				else
					return
				end
			end, function(p214)
				-- upvalues: (ref) v_u_29, (copy) v_u_191, (ref) v_u_22, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
				if v_u_29 == v_u_191 then
					if p214 == nil then
						p214 = "-"
					else
						local v215
						if v_u_22 == nil then
							v215 = false
						else
							local v216 = v_u_22.keyBinding
							if type(v216) == "function" then
								local v217 = v_u_22.rebindKey
								v215 = type(v217) == "function"
							else
								v215 = false
							end
						end
						if v215 then
							p214 = v_u_22.keyName(p214)
						end
					end
					local v218 = p214 .. " is reserved. Press another key."
					v_u_37 = v218
					if v_u_34 then
						v_u_19.setText(v_u_34, v218)
						v_u_34.TextColor3 = v_u_21.danger
					end
				end
			end)
			local v219 = string.format
			local v220 = "%s: press a key or click a mouse button for the %s binding."
			local v221 = v_u_3[p_u_185]
			if not v221 then
				local v222 = string.gsub(p_u_185, "(%u)", " %1")
				v221 = string.upper((string.sub(v222, 1, 1))) .. string.lower((string.sub(v222, 2)))
			end
			local v223, v224 = v219(v220, v221, p_u_186 == 1 and "primary" or "secondary")
			v_u_37 = v223
			if v_u_34 then
				v_u_19.setText(v_u_34, v223)
				local v225 = v_u_34
				local v226
				if v224 then
					v226 = v_u_21.danger
				elseif v_u_29 then
					v226 = v_u_21.accent
				else
					v226 = v_u_21.text2
				end
				v225.TextColor3 = v226
			end
			v_u_96()
		end
	end
	v_u_23.startCapture = v_u_227
	local function v_u_235(p_u_228) -- name: trackHover
		-- upvalues: (copy) v_u_33, (copy) v_u_32
		local v229 = v_u_33
		local v230 = p_u_228.MouseEnter
		local function v231()
			-- upvalues: (ref) v_u_32, (copy) p_u_228
			v_u_32[p_u_228] = true
		end
		table.insert(v229, v230:Connect(v231))
		local v232 = v_u_33
		local v233 = p_u_228.MouseLeave
		local function v234()
			-- upvalues: (ref) v_u_32, (copy) p_u_228
			v_u_32[p_u_228] = nil
		end
		table.insert(v232, v233:Connect(v234))
	end
	local function v_u_243(p236, p237, p238, p239, p240) -- name: cellButton
		-- upvalues: (copy) v_u_19, (copy) v_u_21, (copy) v_u_20, (copy) v_u_235
		local v_u_241 = v_u_19.new("TextButton", {
			["Name"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextTruncate"] = nil,
			["Text"] = "-",
			["Name"] = p237,
			["BackgroundColor3"] = v_u_21.raised,
			["Position"] = UDim2.fromOffset(p238, 2),
			["Size"] = UDim2.fromOffset(p239, p240 - 4),
			["FontFace"] = v_u_20.font.monoBold,
			["TextColor3"] = v_u_21.text,
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		}, p236)
		v_u_19.stroke(v_u_241, v_u_21.line)
		local function v242()
			-- upvalues: (copy) v_u_241, (ref) v_u_19
			v_u_241.SelectionImageObject = v_u_19.selectionImage()
		end
		pcall(v242)
		v_u_235(v_u_241)
		return v_u_241
	end
	local function v_u_250() -- name: resetAll
		-- upvalues: (copy) v_u_22, (ref) v_u_29, (copy) v_u_96, (copy) v_u_62, (ref) v_u_37, (ref) v_u_34, (copy) v_u_19, (copy) v_u_21
		local v244
		if v_u_22 == nil then
			v244 = false
		else
			local v245 = v_u_22.keyBinding
			if type(v245) == "function" then
				local v246 = v_u_22.rebindKey
				v244 = type(v246) == "function"
			else
				v244 = false
			end
		end
		if v244 then
			if v_u_29 then
				local v247 = v_u_29.cancel
				pcall(v247)
				v_u_29 = nil
			end
			v_u_96()
			v_u_22.resetKeys(nil)
			v_u_62()
			v_u_37 = "All key bindings are back to default."
			if v_u_34 then
				v_u_19.setText(v_u_34, "All key bindings are back to default.")
				local v248 = v_u_34
				local v249
				if v_u_29 then
					v249 = v_u_21.accent
				else
					v249 = v_u_21.text2
				end
				v248.TextColor3 = v249
			end
			v_u_96()
		end
	end
	function v_u_23.resetRow(p251) -- name: resetRow
		-- upvalues: (copy) v_u_22, (ref) v_u_29, (copy) v_u_96, (copy) v_u_62, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (copy) v_u_19, (copy) v_u_21
		local v252
		if v_u_22 == nil then
			v252 = false
		else
			local v253 = v_u_22.keyBinding
			if type(v253) == "function" then
				local v254 = v_u_22.rebindKey
				v252 = type(v254) == "function"
			else
				v252 = false
			end
		end
		if v252 then
			if v_u_29 then
				local v255 = v_u_29.cancel
				pcall(v255)
				v_u_29 = nil
			end
			v_u_96()
			v_u_22.resetKeys(p251)
			v_u_62()
			local v256 = v_u_3[p251]
			if not v256 then
				local v257 = string.gsub(p251, "(%u)", " %1")
				v256 = string.upper((string.sub(v257, 1, 1))) .. string.lower((string.sub(v257, 2)))
			end
			local v258 = v256 .. ": back to default"
			v_u_37 = v258
			if v_u_34 then
				v_u_19.setText(v_u_34, v258)
				local v259 = v_u_34
				local v260
				if v_u_29 then
					v260 = v_u_21.accent
				else
					v260 = v_u_21.text2
				end
				v259.TextColor3 = v260
			end
			v_u_96()
		end
	end
	v_u_23.resetAll = v_u_250
	local function v_u_344() -- name: build
		-- upvalues: (copy) v_u_33, (copy) v_u_28, (copy) v_u_32, (copy) v_u_27, (ref) v_u_65, (copy) v_u_22, (copy) v_u_20, (copy) v_u_19, (copy) v_u_250, (copy) v_u_235, (ref) v_u_34, (ref) v_u_37, (copy) v_u_21, (ref) v_u_29, (copy) v_u_96, (ref) v_u_35, (copy) v_u_62, (ref) v_u_4, (ref) v_u_3, (ref) v_u_36, (copy) v_u_26, (copy) v_u_52, (copy) v_u_243, (copy) v_u_18, (copy) v_u_227
		for _, v261 in v_u_33 do
			v261:Disconnect()
		end
		table.clear(v_u_33)
		table.clear(v_u_28)
		table.clear(v_u_32)
		for _, v262 in v_u_27:GetChildren() do
			if v262:IsA("UIListLayout") then
				continue
			end
			v262:Destroy()
		end
		local v_u_263 = "Keyboard"
		local function v264()
			-- upvalues: (ref) v_u_263, (ref) v_u_22
			v_u_263 = v_u_22.device()
		end
		pcall(v264)
		v_u_65 = v_u_263 == "Touch" and "Tap a binding, then press the new key on a keyboard. Touch and controller controls stay as they are." or (v_u_263 == "Gamepad" and "Keyboard and mouse bindings. Select one and press the new key on a keyboard. Controller controls stay as they are." or "Click a binding, then press the new key or mouse button. Controller and touch controls stay as they are.")
		local v265 = v_u_20.touch(36)
		local v266 = v_u_19.new
		local v267 = {
			["Name"] = "Top",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1
		}
		local v268 = UDim2.new
		local v269 = v265 + 4
		v267.Size = v268(1, 0, 0, (math.max(40, v269)))
		local v270 = v266("Frame", v267, v_u_27)
		v_u_235((v_u_19.button({
			["parent"] = nil,
			["name"] = "ResetAll",
			["text"] = "Reset all",
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = 170,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v270,
			["height"] = v265,
			["position"] = UDim2.new(1, -170, 0, 2),
			["onClick"] = v_u_250
		})))
		v_u_34 = v_u_19.label({
			["parent"] = nil,
			["name"] = "Status",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v270,
			["text"] = v_u_37 ~= "" and v_u_37 or v_u_65,
			["color"] = v_u_21.text2,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.new(1, -186, 1, 0)
		})
		local v271 = v_u_20.touch(32)
		local v272 = v_u_19.new("Frame", {
			["Name"] = "CaptureBar",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.new(1, 0, 0, v271 + 2)
		}, v_u_27)
		v_u_19.layout(v272, "h", 8)
		local v277 = {
			["parent"] = nil,
			["name"] = "CaptureCancel",
			["text"] = "Cancel",
			["kind"] = "ghost",
			["height"] = nil,
			["width"] = 130,
			["order"] = 1,
			["onClick"] = nil,
			["parent"] = v272,
			["height"] = v271,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_29, (ref) v_u_96, (ref) v_u_65, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
				if v_u_29 then
					if v_u_29 then
						local v273 = v_u_29.cancel
						pcall(v273)
						v_u_29 = nil
					end
					v_u_96()
					local v274 = v_u_65
					v_u_37 = v274
					if v_u_34 then
						v_u_19.setText(v_u_34, v274)
						local v275 = v_u_34
						local v276
						if v_u_29 then
							v276 = v_u_21.accent
						else
							v276 = v_u_21.text2
						end
						v275.TextColor3 = v276
					end
				end
			end
		}
		local v278 = v_u_19.button(v277)
		v_u_35 = v278
		v_u_235(v278)
		local v293 = {
			["parent"] = nil,
			["name"] = "CaptureClear",
			["text"] = "Clear slot",
			["kind"] = "ghost",
			["height"] = nil,
			["width"] = 150,
			["order"] = 2,
			["onClick"] = nil,
			["parent"] = v272,
			["height"] = v271,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_29, (ref) v_u_96, (ref) v_u_22, (ref) v_u_62, (ref) v_u_4, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
				local v279 = v_u_29
				if v279 then
					if v_u_29 then
						local v280 = v_u_29.cancel
						pcall(v280)
						v_u_29 = nil
					end
					v_u_96()
					if v_u_22.rebindKey(v279.id, v279.slot, nil) then
						v_u_62()
					end
					local v281 = v279.id
					local v282 = v_u_4.clearedText
					local v283 = v_u_3[v281]
					if not v283 then
						local v284 = string.gsub(v281, "(%u)", " %1")
						v283 = string.upper((string.sub(v284, 1, 1))) .. string.lower((string.sub(v284, 2)))
					end
					local v285
					if v_u_22 == nil then
						v285 = false
					else
						local v286 = v_u_22.keyBinding
						if type(v286) == "function" then
							local v287 = v_u_22.rebindKey
							v285 = type(v287) == "function"
						else
							v285 = false
						end
					end
					local v288
					if v285 then
						v288 = v_u_22.keyBinding(v281)
					else
						v288 = nil
					end
					local v289, v290 = v282(v283, v288)
					v_u_37 = v289
					if v_u_34 then
						v_u_19.setText(v_u_34, v289)
						local v291 = v_u_34
						local v292
						if v290 then
							v292 = v_u_21.danger
						elseif v_u_29 then
							v292 = v_u_21.accent
						else
							v292 = v_u_21.text2
						end
						v291.TextColor3 = v292
					end
					v_u_96()
				end
			end
		}
		local v294 = v_u_19.button(v293)
		v_u_36 = v294
		v_u_235(v294)
		local v295 = v_u_20.touch(28) + 4
		local v296 = math.max(32, v295)
		local v297 = (v_u_26 - 84) * 0.3
		local v298 = math.floor(v297)
		local v299 = (v_u_26 - 84) * 0.2
		local v300 = math.floor(v299)
		local v301 = v_u_26 - 84 - v298 - v300 * 2 - 24
		local v302 = v_u_19.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 3,
			["Size"] = UDim2.new(1, 0, 0, 20)
		}, v_u_27)
		local v303 = {
			6,
			v298,
			v298 + v300 + 8,
			v298 + v300 * 2 + 16
		}
		for v304, v305 in {
			"Action",
			"Primary",
			"Secondary",
			"Controller"
		} do
			local v306 = v_u_19.label
			local v307 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v302,
				["text"] = v305,
				["position"] = UDim2.fromOffset(v303[v304], 0)
			}
			local v308 = UDim2.fromOffset
			local v309
			if v304 == 1 then
				v309 = v298 - 12
			elseif v304 == 4 then
				v309 = v301
			else
				v309 = v300
			end
			v307.size = v308(v309, 20)
			v306(v307)
		end
		local v310 = v_u_19.new("Frame", {
			["Name"] = "Rows",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 4,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_27)
		v_u_19.layout(v310, "v", 0)
		for v311, v_u_312 in v_u_52() do
			local v313 = v_u_19.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Row_" .. v_u_312,
				["BackgroundColor3"] = v_u_21.raised,
				["BackgroundTransparency"] = v311 % 2 == 0 and 0.55 or 1,
				["Size"] = UDim2.new(1, 0, 0, v296),
				["LayoutOrder"] = v311
			}, v310)
			local v314 = v_u_19.label
			local v315 = {
				["parent"] = nil,
				["name"] = "Label",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v313
			}
			local v316 = v_u_3[v_u_312]
			if not v316 then
				local v317 = string.gsub(v_u_312, "(%u)", " %1")
				v316 = string.upper((string.sub(v317, 1, 1))) .. string.lower((string.sub(v317, 2)))
			end
			v315.text = v316
			v315.color = v_u_21.text
			v315.position = UDim2.fromOffset(6, 0)
			v315.size = UDim2.fromOffset(v298 - 12, v296)
			v314(v315)
			local v318 = v_u_243(v313, "P_" .. v_u_312, v298, v300, v296)
			local v319 = v_u_243(v313, "S_" .. v_u_312, v298 + v300 + 8, v300, v296)
			local v320 = "-"
			local v321 = v_u_18.padText
			local v322
			if type(v321) == "function" then
				local v323 = v_u_18.padText
				local v324
				v324, v322 = pcall(v323, v_u_312)
				if v324 then
					if type(v322) ~= "string" then
						v322 = v320
					end
				else
					v322 = v320
				end
			else
				v322 = v320
			end
			local v325 = v_u_19.label({
				["parent"] = nil,
				["name"] = "Pad",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v313,
				["text"] = v322,
				["color"] = v_u_21.text2,
				["position"] = UDim2.fromOffset(v298 + v300 * 2 + 16, 0),
				["size"] = UDim2.fromOffset(v301, v296)
			})
			local v326 = v_u_19.new
			local v327 = "TextButton"
			local v328 = {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["Text"] = "RESET",
				["Visible"] = false,
				["Name"] = "R_" .. v_u_312,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -4, 0, v296 > 32 and 2 or 4)
			}
			local v329 = UDim2.fromOffset
			local v330 = 76
			local v331
			if v296 > 32 then
				v331 = v296 - 4
			else
				v331 = v296 - 8
			end
			v328.Size = v329(v330, v331)
			v328.FontFace = v_u_20.font.heading
			v328.TextColor3 = v_u_21.text2
			v328.TextTruncate = Enum.TextTruncate.AtEnd
			local v_u_332 = v326(v327, v328, v313)
			v_u_19.stroke(v_u_332, v_u_21.line)
			local function v333()
				-- upvalues: (copy) v_u_332, (ref) v_u_19
				v_u_332.SelectionImageObject = v_u_19.selectionImage()
			end
			pcall(v333)
			v_u_235(v_u_332)
			v_u_28[v_u_312] = {
				["p"] = v318,
				["s"] = v319,
				["r"] = v_u_332,
				["pad"] = v325
			}
			v318.Activated:Connect(function()
				-- upvalues: (ref) v_u_227, (copy) v_u_312
				v_u_227(v_u_312, 1)
			end)
			v319.Activated:Connect(function()
				-- upvalues: (ref) v_u_227, (copy) v_u_312
				v_u_227(v_u_312, 2)
			end)
			v_u_332.Activated:Connect(function()
				-- upvalues: (copy) v_u_312, (ref) v_u_22, (ref) v_u_29, (ref) v_u_96, (ref) v_u_62, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
				local v334 = v_u_312
				local v335
				if v_u_22 == nil then
					v335 = false
				else
					local v336 = v_u_22.keyBinding
					if type(v336) == "function" then
						local v337 = v_u_22.rebindKey
						v335 = type(v337) == "function"
					else
						v335 = false
					end
				end
				if v335 then
					if v_u_29 then
						local v338 = v_u_29.cancel
						pcall(v338)
						v_u_29 = nil
					end
					v_u_96()
					v_u_22.resetKeys(v334)
					v_u_62()
					local v339 = v_u_3[v334]
					if not v339 then
						local v340 = string.gsub(v334, "(%u)", " %1")
						v339 = string.upper((string.sub(v340, 1, 1))) .. string.lower((string.sub(v340, 2)))
					end
					local v341 = v339 .. ": back to default"
					v_u_37 = v341
					if v_u_34 then
						v_u_19.setText(v_u_34, v341)
						local v342 = v_u_34
						local v343
						if v_u_29 then
							v343 = v_u_21.accent
						else
							v343 = v_u_21.text2
						end
						v342.TextColor3 = v343
					end
					v_u_96()
				end
			end)
		end
		v_u_19.label({
			["parent"] = nil,
			["name"] = "Fixed",
			["text"] = "Fixed: camera zoom on the mouse wheel, clicking a row of an interaction list, Esc and the function keys F8 to F12.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 5,
			["size"] = nil,
			["parent"] = v_u_27,
			["color"] = v_u_21.muted,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_96()
	end
	function v_u_23.refresh() -- name: refresh
		-- upvalues: (copy) v_u_27, (copy) v_u_344
		if v_u_27.Parent then
			v_u_344()
		end
	end
	function v_u_23.capturing() -- name: capturing
		-- upvalues: (ref) v_u_29
		if v_u_29 then
			return v_u_29.id .. ":" .. v_u_29.slot
		else
			return nil
		end
	end
	function v_u_23.destroy() -- name: destroy
		-- upvalues: (ref) v_u_29, (copy) v_u_96, (ref) v_u_30, (ref) v_u_31, (copy) v_u_33, (copy) v_u_27
		if v_u_29 then
			local v345 = v_u_29.cancel
			pcall(v345)
			v_u_29 = nil
		end
		v_u_96()
		if v_u_30 then
			local v346 = v_u_30.close
			pcall(v346)
			v_u_30 = nil
			v_u_31 = nil
		end
		for _, v347 in v_u_33 do
			v347:Disconnect()
		end
		v_u_27:Destroy()
	end
	v_u_23.frame = v_u_27
	pcall(v_u_344)
	if v_u_22 and v_u_22.bindingsChanged then
		local v_u_348 = v_u_22.bindingsChanged:Connect(function()
			-- upvalues: (copy) v_u_27, (copy) v_u_96
			if v_u_27.Parent then
				v_u_96()
			end
		end)
		local v_u_349 = v_u_23.destroy
		function v_u_23.destroy()
			-- upvalues: (copy) v_u_348, (copy) v_u_349
			v_u_348:Disconnect()
			v_u_349()
		end
	end
	local function v413()
		-- upvalues: (copy) p_u_15, (copy) v_u_23, (ref) v_u_30, (ref) v_u_37, (copy) v_u_27, (copy) v_u_28, (copy) v_u_227, (ref) v_u_31, (copy) v_u_22, (ref) v_u_29, (copy) v_u_96, (copy) v_u_62, (ref) v_u_34, (copy) v_u_19, (copy) v_u_21, (ref) v_u_3, (ref) v_u_65, (ref) v_u_4
		local v350 = p_u_15.cctx.command
		v350("kb.state", function(p351)
			-- upvalues: (ref) v_u_23, (ref) v_u_30, (ref) v_u_37, (ref) v_u_27, (ref) v_u_28
			local v352 = {}
			local v353 = v_u_23.capturing
			local v354 = "cap=" .. tostring(v353())
			local v355 = v_u_30 ~= nil
			local v356 = "modal=" .. tostring(v355)
			local v357 = "status=" .. v_u_37
			local v358 = "visible="
			local v359
			if v_u_27.Parent == nil then
				v359 = false
			else
				v359 = v_u_27.Visible
			end
			__set_list(v352, 1, {v354, v356, v357, v358 .. tostring(v359)})
			for _, v360 in p351 do
				local v361 = v_u_28[v360]
				if not v361 then
					continue
				end
				local v362 = string.format
				local v363 = v361.p.Text
				local v364 = v361.s.Text
				local v365 = v361.r.Visible
				local v366 = tostring(v365)
				table.insert(v352, v362("%s=[%s|%s|reset=%s]", v360, v363, v364, v366))
			end
			return table.concat(v352, " ")
		end)
		v350("kb.click", function(p367)
			-- upvalues: (ref) v_u_227, (ref) v_u_23
			local v368 = v_u_227
			local v369 = p367[1] or ""
			local v370 = p367[2]
			v368(v369, tonumber(v370) or 1)
			local v371 = v_u_23.capturing
			return "capture " .. tostring(v371())
		end)
		v350("kb.answer", function(p372)
			-- upvalues: (ref) v_u_31
			if not v_u_31 then
				return "no modal"
			end
			v_u_31(p372[1] or "cancel")
			local v373 = p372[1]
			return "answered " .. tostring(v373)
		end)
		v350("kb.reset", function(p374)
			-- upvalues: (ref) v_u_22, (ref) v_u_29, (ref) v_u_96, (ref) v_u_62, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21, (ref) v_u_3
			if p374[1] == "all" or p374[1] == nil then
				local v375
				if v_u_22 == nil then
					v375 = false
				else
					local v376 = v_u_22.keyBinding
					if type(v376) == "function" then
						local v377 = v_u_22.rebindKey
						v375 = type(v377) == "function"
					else
						v375 = false
					end
				end
				if v375 then
					if v_u_29 then
						local v378 = v_u_29.cancel
						pcall(v378)
						v_u_29 = nil
					end
					v_u_96()
					v_u_22.resetKeys(nil)
					v_u_62()
					v_u_37 = "All key bindings are back to default."
					if v_u_34 then
						v_u_19.setText(v_u_34, "All key bindings are back to default.")
						local v379 = v_u_34
						local v380
						if v_u_29 then
							v380 = v_u_21.accent
						else
							v380 = v_u_21.text2
						end
						v379.TextColor3 = v380
					end
					v_u_96()
				end
			else
				local v381 = p374[1]
				local v382
				if v_u_22 == nil then
					v382 = false
				else
					local v383 = v_u_22.keyBinding
					if type(v383) == "function" then
						local v384 = v_u_22.rebindKey
						v382 = type(v384) == "function"
					else
						v382 = false
					end
				end
				if v382 then
					if v_u_29 then
						local v385 = v_u_29.cancel
						pcall(v385)
						v_u_29 = nil
					end
					v_u_96()
					v_u_22.resetKeys(v381)
					v_u_62()
					local v386 = v_u_3[v381]
					if not v386 then
						local v387 = string.gsub(v381, "(%u)", " %1")
						v386 = string.upper((string.sub(v387, 1, 1))) .. string.lower((string.sub(v387, 2)))
					end
					local v388 = v386 .. ": back to default"
					v_u_37 = v388
					if v_u_34 then
						v_u_19.setText(v_u_34, v388)
						local v389 = v_u_34
						local v390
						if v_u_29 then
							v390 = v_u_21.accent
						else
							v390 = v_u_21.text2
						end
						v389.TextColor3 = v390
					end
					v_u_96()
				end
			end
			local v391 = "ok "
			local v392
			if v_u_22 == nil then
				v392 = false
			else
				local v393 = v_u_22.keyBinding
				if type(v393) == "function" then
					local v394 = v_u_22.rebindKey
					v392 = type(v394) == "function"
				else
					v392 = false
				end
			end
			return v391 .. (not v392 and "?" or v_u_22.keyBindingString())
		end)
		v350("kb.cancel", function()
			-- upvalues: (ref) v_u_29, (ref) v_u_96, (ref) v_u_65, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
			if v_u_29 then
				local v395 = v_u_29.cancel
				pcall(v395)
				v_u_29 = nil
			end
			v_u_96()
			local v396 = v_u_65
			v_u_37 = v396
			if v_u_34 then
				v_u_19.setText(v_u_34, v396)
				local v397 = v_u_34
				local v398
				if v_u_29 then
					v398 = v_u_21.accent
				else
					v398 = v_u_21.text2
				end
				v397.TextColor3 = v398
			end
			return "ok"
		end)
		v350("kb.clear", function()
			-- upvalues: (ref) v_u_29, (ref) v_u_96, (ref) v_u_22, (ref) v_u_62, (ref) v_u_4, (ref) v_u_3, (ref) v_u_37, (ref) v_u_34, (ref) v_u_19, (ref) v_u_21
			local v399 = v_u_29
			if not v399 then
				return "not capturing"
			end
			if v_u_29 then
				local v400 = v_u_29.cancel
				pcall(v400)
				v_u_29 = nil
			end
			v_u_96()
			v_u_22.rebindKey(v399.id, v399.slot, nil)
			v_u_62()
			local v401 = v399.id
			local v402 = v_u_4.clearedText
			local v403 = v_u_3[v401]
			if not v403 then
				local v404 = string.gsub(v401, "(%u)", " %1")
				v403 = string.upper((string.sub(v404, 1, 1))) .. string.lower((string.sub(v404, 2)))
			end
			local v405
			if v_u_22 == nil then
				v405 = false
			else
				local v406 = v_u_22.keyBinding
				if type(v406) == "function" then
					local v407 = v_u_22.rebindKey
					v405 = type(v407) == "function"
				else
					v405 = false
				end
			end
			local v408
			if v405 then
				v408 = v_u_22.keyBinding(v401)
			else
				v408 = nil
			end
			local v409, v410 = v402(v403, v408)
			v_u_37 = v409
			if v_u_34 then
				v_u_19.setText(v_u_34, v409)
				local v411 = v_u_34
				local v412
				if v410 then
					v412 = v_u_21.danger
				elseif v_u_29 then
					v412 = v_u_21.accent
				else
					v412 = v_u_21.text2
				end
				v411.TextColor3 = v412
			end
			v_u_96()
			return "cleared " .. v399.id .. ":" .. v399.slot .. " " .. v_u_22.keyBindingString()
		end)
	end
	pcall(v413)
	return v_u_23
end
return v_u_4