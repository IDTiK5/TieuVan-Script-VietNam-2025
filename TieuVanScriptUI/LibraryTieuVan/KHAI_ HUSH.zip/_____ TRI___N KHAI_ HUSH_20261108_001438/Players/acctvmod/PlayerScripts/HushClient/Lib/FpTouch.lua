-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpTouch

local v_u_1 = game:GetService("Players")
local v_u_23 = {
	["DRAG_DEG_PER_PX"] = 0.25,
	["LOOK_RATE"] = 180,
	["DEAD"] = 0.15,
	["INNER"] = 0.75,
	["SENS_MIN"] = 0.2,
	["SENS_MAX"] = 6,
	["MAX_DT"] = 0.1,
	["MAX_STEP"] = 120,
	["ATTR"] = "FpTouchSens",
	["cleanSens"] = function(p2) -- name: cleanSens
		-- upvalues: (copy) v_u_23
		if type(p2) ~= "number" or (p2 ~= p2 or (p2 == (1 / 0) or p2 == (-1 / 0))) then
			return 1
		end
		local v3 = v_u_23.SENS_MIN
		local v4 = v_u_23.SENS_MAX
		return math.clamp(p2, v3, v4)
	end,
	["stickRate"] = function(p5) -- name: stickRate
		-- upvalues: (copy) v_u_23
		if type(p5) ~= "number" or (p5 ~= p5 or p5 <= v_u_23.DEAD) then
			return 0
		end
		local v6 = (p5 - v_u_23.DEAD) / (v_u_23.INNER - v_u_23.DEAD)
		local v7 = math.clamp(v6, 0, 1)
		return v_u_23.LOOK_RATE * v7
	end,
	["clampStep"] = function(p8) -- name: clampStep
		-- upvalues: (copy) v_u_23
		if p8 ~= p8 then
			return 0
		end
		local v9 = -v_u_23.MAX_STEP
		local v10 = v_u_23.MAX_STEP
		return math.clamp(p8, v9, v10)
	end,
	["stickDelta"] = function(p11, p12, p13, p14, p15) -- name: stickDelta
		-- upvalues: (copy) v_u_23
		local v16 = v_u_23.stickRate(p13) * v_u_23.cleanSens(p15)
		local v17 = v_u_23.MAX_DT
		local v18 = math.clamp(p14, 0, v17)
		return -p11 * v16 * v18, p12 * v16 * v18
	end,
	["dragDelta"] = function(p19, p20, p21) -- name: dragDelta
		-- upvalues: (copy) v_u_23
		local v22 = v_u_23.DRAG_DEG_PER_PX * v_u_23.cleanSens(p21)
		return -p19 * v22, -p20 * v22
	end
}
local v_u_24 = false
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = -10
local v_u_28 = nil
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = 0
local v_u_34 = false
local v_u_35 = true
local v_u_36 = os.clock
local v_u_37 = nil
local function v_u_43() -- name: sens
	-- upvalues: (ref) v_u_37, (copy) v_u_23, (copy) v_u_1
	if v_u_37 ~= nil then
		return v_u_23.cleanSens(v_u_37)
	end
	local function v39()
		-- upvalues: (ref) v_u_1, (ref) v_u_23
		local v38 = v_u_1.LocalPlayer
		if v38 then
			return v38:GetAttribute(v_u_23.ATTR)
		else
			return nil
		end
	end
	local v40, v41 = pcall(v39)
	local v42 = v_u_23.cleanSens
	if not v40 then
		v41 = nil
	end
	return v42(v41)
end
local v_u_58 = {
	["began"] = function(p44, p_u_45) -- name: began
		-- upvalues: (ref) v_u_31, (ref) v_u_32
		local v46, v47, v48 = pcall(function()
			-- upvalues: (copy) p_u_45
			return p_u_45.X, p_u_45.Y
		end)
		if not v46 or (type(v47) ~= "number" or (type(v48) ~= "number" or (v47 ~= v47 or v48 ~= v48))) then
			v47 = nil
			v48 = nil
		end
		if v47 ~= nil and v48 ~= nil then
			v_u_31 = p44
			v_u_32 = {
				["x"] = v47,
				["y"] = v48
			}
		end
	end,
	["moved"] = function(p49, p_u_50) -- name: moved
		-- upvalues: (ref) v_u_31, (ref) v_u_32, (copy) v_u_23, (copy) v_u_43, (ref) v_u_29, (ref) v_u_30
		if p49 == v_u_31 and v_u_32 ~= nil then
			local v51, v52, v53 = pcall(function()
				-- upvalues: (copy) p_u_50
				return p_u_50.X, p_u_50.Y
			end)
			if not v51 or (type(v52) ~= "number" or (type(v53) ~= "number" or (v52 ~= v52 or v53 ~= v53))) then
				v52 = nil
				v53 = nil
			end
			if v52 ~= nil and v53 ~= nil then
				local v54, v55 = v_u_23.dragDelta(v52 - v_u_32.x, v53 - v_u_32.y, v_u_43())
				local v56 = v_u_32
				v_u_32.x = v52
				v56.y = v53
				v_u_29 = v_u_29 + v54
				v_u_30 = v_u_30 + v55
			end
		else
			return
		end
	end,
	["ended"] = function(p57) -- name: ended
		-- upvalues: (ref) v_u_31, (ref) v_u_32
		if p57 == v_u_31 then
			v_u_31 = nil
			v_u_32 = nil
		end
	end
}
local function v_u_78() -- name: attach
	-- upvalues: (ref) v_u_26, (ref) v_u_36, (ref) v_u_27, (ref) v_u_25, (ref) v_u_28, (copy) v_u_58, (ref) v_u_34, (ref) v_u_35
	local v59
	if v_u_26 == nil then
		local v60 = v_u_36()
		if v60 - v_u_27 < 1 then
			v59 = nil
		else
			v_u_27 = v60
			local function v63()
				-- upvalues: (ref) v_u_25, (ref) v_u_26
				local v61 = v_u_25
				if v61 and (v61.controllers and v61.controllers.Input) then
					v_u_26 = v61.controllers.Input
				else
					local v62 = script.Parent
					if v62 then
						v62 = v62.Parent
					end
					if v62 then
						v62 = v62:FindFirstChild("Controllers")
					end
					if v62 then
						v62 = v62:FindFirstChild("Input")
					end
					if v62 and v62:IsA("ModuleScript") then
						v_u_26 = require(v62)
					end
				end
			end
			pcall(v63)
			v59 = v_u_26
		end
	else
		v59 = v_u_26
	end
	local v64 = nil
	local v65
	if v59 then
		local v66 = v59.touch
		if type(v66) == "function" then
			local v67 = v59.touch
			local v68
			v68, v65 = pcall(v67)
			if v68 then
				if type(v65) ~= "table" then
					v65 = v64
				end
			else
				v65 = v64
			end
		else
			v65 = v64
		end
	else
		v65 = v64
	end
	if v65 ~= v_u_28 then
		if v_u_28 ~= nil and v_u_28 ~= v65 then
			local v69 = v_u_28.setFptp
			local v70 = v_u_28
			pcall(v69, v70, false)
		end
		v_u_28 = v65
		if v_u_28 ~= nil then
			local v71 = v_u_28.setFptp
			local v72 = v_u_28
			local v73 = v_u_58
			pcall(v71, v72, true, v73)
			if v_u_34 then
				local v74 = v_u_28.setTakedown
				local v75 = v_u_28
				pcall(v74, v75, true)
			end
			if not v_u_35 then
				local v76 = v_u_28.setEnabledAction
				local v77 = v_u_28
				pcall(v76, v77, "ads", false)
			end
		end
	end
end
function v_u_23.setActive(p79, p80) -- name: setActive
	-- upvalues: (ref) v_u_25, (ref) v_u_24, (copy) v_u_78, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_36, (ref) v_u_28, (ref) v_u_34, (ref) v_u_35
	if p80 ~= nil then
		v_u_25 = p80
	end
	local v81 = p79 == true
	if v81 == v_u_24 then
		if v81 then
			v_u_78()
		end
		return
	else
		v_u_24 = v81
		v_u_29 = 0
		v_u_30 = 0
		v_u_31 = nil
		v_u_32 = nil
		v_u_33 = v_u_36()
		if v81 then
			v_u_78()
		else
			local v82 = v_u_28
			v_u_28 = nil
			if v82 ~= nil then
				local v83 = v82.setFptp
				pcall(v83, v82, false)
			end
			v_u_34 = false
			v_u_35 = true
		end
	end
end
function v_u_23.step(_) -- name: step
	-- upvalues: (ref) v_u_24, (ref) v_u_26, (ref) v_u_36, (ref) v_u_27, (ref) v_u_25, (ref) v_u_28, (copy) v_u_78
	if not v_u_24 then
		return
	end
	local v84
	if v_u_26 == nil then
		local v85 = v_u_36()
		if v85 - v_u_27 < 1 then
			v84 = nil
		else
			v_u_27 = v85
			local function v88()
				-- upvalues: (ref) v_u_25, (ref) v_u_26
				local v86 = v_u_25
				if v86 and (v86.controllers and v86.controllers.Input) then
					v_u_26 = v86.controllers.Input
				else
					local v87 = script.Parent
					if v87 then
						v87 = v87.Parent
					end
					if v87 then
						v87 = v87:FindFirstChild("Controllers")
					end
					if v87 then
						v87 = v87:FindFirstChild("Input")
					end
					if v87 and v87:IsA("ModuleScript") then
						v_u_26 = require(v87)
					end
				end
			end
			pcall(v88)
			v84 = v_u_26
		end
	else
		v84 = v_u_26
	end
	if v84 then
		local v89 = v84.touch
		if type(v89) == "function" then
			local v90 = v84.touch
			local v91, v92 = pcall(v90)
			if v91 and (v92 ~= v_u_28 and type(v92) == "table") then
				v_u_78()
				return
			end
		elseif v_u_28 == nil then
			v_u_78()
		end
	else
		if v_u_28 == nil then
			v_u_78()
		end
		return
	end
end
function v_u_23.lookDelta() -- name: lookDelta
	-- upvalues: (ref) v_u_36, (ref) v_u_33, (copy) v_u_23, (ref) v_u_29, (ref) v_u_30, (ref) v_u_24, (ref) v_u_26, (ref) v_u_27, (ref) v_u_25, (ref) v_u_28, (copy) v_u_43
	local v93 = v_u_36()
	local v94 = v93 - v_u_33
	local v95 = v_u_23.MAX_DT
	local v96 = math.clamp(v94, 0, v95)
	v_u_33 = v93
	local v97 = v_u_29
	local v98 = v_u_30
	v_u_29 = 0
	v_u_30 = 0
	if not v_u_24 then
		return 0, 0
	end
	local v99
	if v_u_26 == nil then
		local v100 = v_u_36()
		if v100 - v_u_27 < 1 then
			v99 = nil
		else
			v_u_27 = v100
			local function v103()
				-- upvalues: (ref) v_u_25, (ref) v_u_26
				local v101 = v_u_25
				if v101 and (v101.controllers and v101.controllers.Input) then
					v_u_26 = v101.controllers.Input
				else
					local v102 = script.Parent
					if v102 then
						v102 = v102.Parent
					end
					if v102 then
						v102 = v102:FindFirstChild("Controllers")
					end
					if v102 then
						v102 = v102:FindFirstChild("Input")
					end
					if v102 and v102:IsA("ModuleScript") then
						v_u_26 = require(v102)
					end
				end
			end
			pcall(v103)
			v99 = v_u_26
		end
	else
		v99 = v_u_26
	end
	if v99 then
		local v104 = v99.gameBlocked
		if type(v104) == "function" then
			local v105 = v99.gameBlocked
			local v106, v107 = pcall(v105)
			if v106 and v107 == true then
				return 0, 0
			end
		end
	end
	local v108 = v_u_28
	if v108 ~= nil then
		local v109 = v108.lookStick
		if type(v109) == "function" then
			local v110 = v108.lookStick
			local v111, v_u_112 = pcall(v110, v108)
			if v111 and v_u_112 ~= nil then
				local v113, v114, v115 = pcall(function()
					-- upvalues: (copy) v_u_112
					return v_u_112.X, v_u_112.Y
				end)
				if not v113 or (type(v114) ~= "number" or (type(v115) ~= "number" or (v114 ~= v114 or v115 ~= v115))) then
					v114 = nil
					v115 = nil
				end
				if v114 ~= nil and v115 ~= nil then
					local v116 = v114 * v114 + v115 * v115
					local v117 = math.sqrt(v116)
					if v117 > 1e-6 then
						local v118, v119 = v_u_23.stickDelta(v114 / v117, v115 / v117, v117, v96, v_u_43())
						v97 = v97 + v118
						v98 = v98 + v119
					end
				end
			end
		end
	end
	return v_u_23.clampStep(v97), v_u_23.clampStep(v98)
end
function v_u_23.adsOn() -- name: adsOn
	-- upvalues: (ref) v_u_28, (ref) v_u_24
	local v120 = v_u_28
	local v121 = v_u_24
	if v121 then
		if v120 == nil then
			v121 = false
		else
			v121 = v120.adsOn == true
		end
	end
	return v121
end
function v_u_23.setAds(p122) -- name: setAds
	-- upvalues: (ref) v_u_28, (ref) v_u_24
	local v123 = v_u_28
	if v_u_24 and v123 ~= nil then
		local v124 = v123.setAds
		if type(v124) == "function" then
			local v125 = v123.setAds
			local v126 = p122 == true
			pcall(v125, v123, v126)
		end
	end
end
function v_u_23.setAdsEnabled(p127) -- name: setAdsEnabled
	-- upvalues: (ref) v_u_35, (ref) v_u_28
	v_u_35 = p127 ~= false
	local v128 = v_u_28
	if v128 ~= nil then
		if not v_u_35 then
			local v129 = v128.setAds
			pcall(v129, v128, false)
		end
		local v130 = v128.setEnabledAction
		local v131 = v_u_35
		pcall(v130, v128, "ads", v131)
	end
end
function v_u_23.setTakedown(p132) -- name: setTakedown
	-- upvalues: (ref) v_u_34, (ref) v_u_24, (ref) v_u_28
	local v133
	if p132 == true then
		v133 = v_u_24
	else
		v133 = false
	end
	v_u_34 = v133
	local v134 = v_u_28
	if v134 ~= nil then
		local v135 = v134.setTakedown
		if type(v135) == "function" then
			local v136 = v134.setTakedown
			local v137 = v_u_34
			pcall(v136, v134, v137)
		end
	end
end
function v_u_23.isActive() -- name: isActive
	-- upvalues: (ref) v_u_24
	return v_u_24
end
function v_u_23.debugState() -- name: debugState
	-- upvalues: (ref) v_u_24, (ref) v_u_28, (ref) v_u_35, (ref) v_u_34, (ref) v_u_31, (ref) v_u_29, (ref) v_u_30, (copy) v_u_43
	local v138 = string.format
	local v139 = "active=%s pad=%s ads=%s adsEnabled=%s takedown=%s drag=%s acc=%.2f,%.2f sens=%.2f"
	local v140 = v_u_24
	local v141 = tostring(v140)
	local v142 = v_u_28 ~= nil
	local v143 = tostring(v142)
	local v144
	if v_u_28 == nil then
		v144 = false
	else
		v144 = v_u_28.adsOn == true
	end
	local v145 = tostring(v144)
	local v146 = v_u_35
	local v147 = tostring(v146)
	local v148 = v_u_34
	local v149 = tostring(v148)
	local v150 = v_u_31 ~= nil
	return v138(v139, v141, v143, v145, v147, v149, tostring(v150), v_u_29, v_u_30, v_u_43())
end
v_u_23._test = {
	["hooks"] = v_u_58,
	["setTouch"] = function(p151) -- name: setTouch
		-- upvalues: (ref) v_u_28
		v_u_28 = p151
	end,
	["setInput"] = function(p152) -- name: setInput
		-- upvalues: (ref) v_u_26
		v_u_26 = p152
	end,
	["setClock"] = function(p153) -- name: setClock
		-- upvalues: (ref) v_u_36, (ref) v_u_33
		v_u_36 = p153 or os.clock
		v_u_33 = v_u_36()
	end,
	["setSens"] = function(p154) -- name: setSens
		-- upvalues: (ref) v_u_37
		v_u_37 = p154
	end,
	["reset"] = function() -- name: reset
		-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (ref) v_u_28, (ref) v_u_34, (ref) v_u_35, (ref) v_u_37, (ref) v_u_36, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33
		v_u_24 = false
		v_u_25 = nil
		v_u_26 = nil
		v_u_28 = nil
		v_u_34 = false
		v_u_35 = true
		v_u_37 = nil
		v_u_36 = os.clock
		v_u_27 = -10
		v_u_29 = 0
		v_u_30 = 0
		v_u_31 = nil
		v_u_32 = nil
		v_u_33 = v_u_36()
	end,
	["state"] = function() -- name: state
		-- upvalues: (ref) v_u_24, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_34, (ref) v_u_35
		return {
			["active"] = v_u_24,
			["accYaw"] = v_u_29,
			["accPitch"] = v_u_30,
			["drag"] = v_u_31 ~= nil,
			["takedown"] = v_u_34,
			["adsEnabled"] = v_u_35
		}
	end
}
return v_u_23