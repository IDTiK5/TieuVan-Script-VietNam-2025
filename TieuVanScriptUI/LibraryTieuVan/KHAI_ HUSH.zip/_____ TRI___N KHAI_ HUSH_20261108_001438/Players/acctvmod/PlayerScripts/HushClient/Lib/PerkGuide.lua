-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PerkGuide

local v_u_1 = {
	["BRANCH_NAME"] = {
		["gun"] = "GUNCRAFT",
		["grit"] = "GRIT",
		["ghost"] = "GHOST",
		["life"] = "LIFELINE",
		["kit"] = "KIT"
	}
}
local v_u_2 = {
	"gun",
	"grit",
	"ghost",
	"life",
	"kit"
}
v_u_1.TEXT = {
	["free"] = "FREE",
	["spent"] = "SPENT",
	["bonus"] = "BONUS",
	["tokens"] = "TOKENS",
	["none"] = "none",
	["helpTitle"] = "HOW POINTS WORK",
	["helpLong"] = "HOW POINTS WORK",
	["helpShort"] = "HELP",
	["spentHere"] = "SPENT HERE",
	["flawNote"] = "A flaw lends you bonus points that only work in its branch. Dropping it takes them back.",
	["lobby"] = "Only in the lobby.",
	["nothing"] = "Nothing to unlearn.",
	["undoFree"] = "Learned since your last raid. Use UNDO, it is free.",
	["undoBlocked"] = "Another perk depends on this. Undo that one first.",
	["unlearnBlocked"] = "Another perk depends on this. Unlearn that one first.",
	["finishRaid"] = "Finish a raid first. You get 3 tokens per raid."
}
local v_u_3 = v_u_1.TEXT
local function v_u_14(p4) -- name: fixOne
	local v5 = 1
	local v6 = ""
	while true do
		local v7, v8 = string.find(p4, "1 points", v5, true)
		if not v7 then
			break
		end
		local v9
		if v7 > 1 then
			local v10 = v7 - 1
			local v11 = v7 - 1
			v9 = string.sub(p4, v10, v11)
		else
			v9 = ""
		end
		local v12 = v7 - 1
		local v13 = v6 .. string.sub(p4, v5, v12)
		if v9 == "" or not string.find(v9, "%d") then
			v6 = v13 .. "1 point"
		else
			v6 = v13 .. "1 points"
		end
		v5 = v8 + 1
	end
	return v6 .. string.sub(p4, v5)
end
v_u_1.fixOne = v_u_14
function v_u_1.charCount(p15) -- name: charCount
	local v16 = 0
	for v17 = 1, #p15 do
		local v18 = string.byte(p15, v17)
		if v18 >= 128 and v18 < 192 then
			continue
		end
		v16 = v16 + 1
	end
	return v16
end
function v_u_1.flawGive(p19) -- name: flawGive
	local v20 = {}
	if type(p19) == "table" then
		local v21 = p19.flaws
		if type(v21) == "table" then
			local v22 = 0
			local v23
			if type(p19) == "table" then
				local v24 = p19.flawSlots
				v23 = type(v24) ~= "table" and {} or p19.flawSlots
			else
				v23 = {}
			end
			local v25 = v23.refundCap
			local v26 = tonumber(v25)
			local v27 = (v26 == nil or v26 ~= v26) and 6 or math.floor(v26)
			for _, v28 in p19.flaws do
				if v28.active ~= true then
					continue
				end
				local v29 = v28.refund
				local v30 = tonumber(v29)
				local v31 = (v30 == nil or v30 ~= v30) and 0 or math.floor(v30)
				local v32 = v27 - v22
				local v33 = math.max(0, v32)
				local v34 = math.min(v31, v33)
				v22 = v22 + v34
				local v35 = v28.id
				v20[tostring(v35)] = v34
			end
			return v20
		end
	end
	return v20
end
function v_u_1.boundBy(p36) -- name: boundBy
	-- upvalues: (copy) v_u_1
	local v37 = {}
	if type(p36) == "table" then
		local v38 = p36.flaws
		if type(v38) == "table" then
			local v39 = v_u_1.flawGive(p36)
			for _, v40 in p36.flaws do
				if v40.active ~= true then
					continue
				end
				local v41 = v40.branch
				local v42 = tostring(v41)
				local v43 = v40.branch
				local v44 = v37[tostring(v43)] or 0
				local v45 = v40.id
				v37[v42] = v44 + (v39[tostring(v45)] or 0)
			end
			for v46, v47 in v37 do
				if v47 > 0 then
					continue
				end
				v37[v46] = nil
			end
			return v37
		end
	end
	return v37
end
local function v_u_54(p48) -- name: boundList
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v49 = v_u_1.boundBy(p48)
	local v50 = {}
	local v51 = 0
	for _, v52 in v_u_2 do
		if not v49[v52] then
			continue
		end
		local v53 = {
			["branch"] = v52,
			["n"] = v49[v52]
		}
		table.insert(v50, v53)
		v51 = v51 + v49[v52]
	end
	return v50, v51
end
function v_u_1.bar(p55, p56) -- name: bar
	-- upvalues: (copy) v_u_54, (copy) v_u_3, (copy) v_u_1
	local v57
	if type(p55) == "table" then
		local v58 = p55.points
		v57 = type(v58) ~= "table" and {} or p55.points
	else
		v57 = {}
	end
	local v59 = v57.spent
	local v60 = tonumber(v59)
	local v61 = (v60 == nil or v60 ~= v60) and 0 or math.floor(v60)
	local v62 = v57.free
	local v63 = tonumber(v62)
	local v64 = (v63 == nil or v63 ~= v63) and 0 or math.floor(v63)
	local v65
	if p56 == nil then
		v65 = 0
	else
		v61 = 0
		local v66
		if type(p55) == "table" then
			local v67 = p55.branches
			v66 = type(v67) ~= "table" and {} or p55.branches
		else
			v66 = {}
		end
		for _, v68 in v66 do
			if v68.id ~= p56 then
				continue
			end
			local v69 = v68.spent
			local v70 = tonumber(v69)
			if v70 == nil or v70 ~= v70 then
				v61 = 0
			else
				v61 = math.floor(v70)
			end
		end
		local v71 = v57.bound
		if type(v71) == "table" then
			local v72 = v57.bound[p56]
			local v73 = tonumber(v72)
			if v73 == nil or v73 ~= v73 then
				v65 = 0
			else
				v65 = math.floor(v73)
			end
		else
			v65 = 0
		end
	end
	local v74, v75 = v_u_54(p55)
	local v76 = v_u_3.none
	local v77 = v_u_3.none
	local v78 = 0
	local v79 = v57.bound
	if type(v79) == "table" then
		for _, v80 in v74 do
			local v81 = v57.bound[v80.branch]
			local v82 = tonumber(v81)
			v78 = v78 + ((v82 == nil or v82 ~= v82) and 0 or math.floor(v82))
		end
	end
	if #v74 == 1 then
		local v83 = v74[1].n
		local v84 = v74[1].branch
		v77 = ("+%d %s"):format(v83, v_u_1.BRANCH_NAME[tostring(v84)] or string.upper((tostring(v84))))
		if v78 > 0 and v78 < v74[1].n then
			v76 = ("%s (%d left)"):format(v77, v78)
		else
			v76 = v77
		end
	elseif #v74 > 1 then
		local v85 = {}
		for _, v86 in v74 do
			local v87 = v86.n
			local v88 = v86.branch
			local v89 = v_u_1.BRANCH_NAME[tostring(v88)] or string.upper((tostring(v88)))
			table.insert(v85, ("+%d %s"):format(v87, v89))
		end
		v76 = table.concat(v85, " ")
		v77 = ("+%d bonus"):format(v75)
	end
	local v90
	if p55 then
		v90 = p55.tokens
	else
		v90 = p55
	end
	local v91 = tonumber(v90)
	local v92 = (v91 == nil or v91 ~= v91) and 0 or math.floor(v91)
	local v93
	if p55 then
		v93 = p55.tokensMax
	else
		v93 = p55
	end
	local v94 = tonumber(v93)
	local v95 = (v94 == nil or v94 ~= v94) and 9 or math.floor(v94)
	local v96 = {}
	local v97 = {
		["id"] = "free",
		["label"] = nil,
		["labelShort"] = nil,
		["value"] = nil,
		["short"] = nil,
		["color"] = "accent",
		["icon"] = nil,
		["label"] = v_u_3.free,
		["labelShort"] = v_u_3.free
	}
	local v98
	if v65 > 0 then
		v98 = ("%d + %d %s"):format(v64, v65, v_u_3.bonus)
	else
		v98 = tostring(v64)
	end
	v97.value = v98
	local v99
	if v65 > 0 then
		v99 = ("%d +%d"):format(v64, v65)
	else
		v99 = tostring(v64)
	end
	v97.short = v99
	local v100 = {
		["id"] = "spent",
		["label"] = nil,
		["labelShort"] = nil,
		["value"] = nil,
		["short"] = nil,
		["color"] = "text",
		["icon"] = nil
	}
	local v101
	if p56 == nil then
		v101 = v_u_3.spent
	else
		v101 = v_u_3.spentHere
	end
	v100.label = v101
	v100.labelShort = v_u_3.spent
	v100.value = tostring(v61)
	v100.short = tostring(v61)
	__set_list(v96, 1, {v97, v100, {
	["id"] = "bonus",
	["label"] = nil,
	["labelShort"] = nil,
	["value"] = nil,
	["short"] = nil,
	["color"] = nil,
	["icon"] = nil,
	["label"] = v_u_3.bonus,
	["labelShort"] = v_u_3.bonus,
	["value"] = v76,
	["short"] = v77,
	["color"] = v75 > 0 and "info" or "muted",
	["icon"] = v75 > 0 and "info" or nil
}, {
	["id"] = "tokens",
	["label"] = nil,
	["labelShort"] = nil,
	["value"] = nil,
	["short"] = nil,
	["color"] = nil,
	["icon"] = nil,
	["label"] = v_u_3.tokens,
	["labelShort"] = v_u_3.tokens,
	["value"] = ("%d of %d"):format(v92, v95),
	["short"] = ("%d/%d"):format(v92, v95),
	["color"] = v92 > 0 and "success" or "text2"
}})
	local v102
	if v75 > 0 then
		local v103 = p56 == nil and 0 or (v_u_1.boundBy(p55)[p56] or 0)
		if p56 == nil or v103 > 0 then
			if #v74 == 1 then
				v102 = {
					["text"] = nil,
					["color"] = "info",
					["icon"] = "info"
				}
				local v104 = v74[1].branch
				local v105 = v_u_1.BRANCH_NAME[tostring(v104)] or string.upper((tostring(v104)))
				local v106 = v74[1].branch
				v102.text = ("+%d bonus points are bound to %s. They can only be spent in %s."):format(v75, v105, v_u_1.BRANCH_NAME[tostring(v106)] or string.upper((tostring(v106))))
			else
				v102 = {
					["text"] = nil,
					["color"] = "info",
					["icon"] = "info",
					["text"] = ("+%d bonus points are bound to their branches. Each can only be spent in its own branch."):format(v75)
				}
			end
		else
			local v107 = {}
			for _, v108 in v74 do
				local v109 = v108.branch
				local v110 = v_u_1.BRANCH_NAME[tostring(v109)] or string.upper((tostring(v109)))
				table.insert(v107, v110)
			end
			v102 = {
				["text"] = nil,
				["color"] = "info",
				["icon"] = "info",
				["text"] = ("+%d bonus points wait in %s."):format(v75, table.concat(v107, " and "))
			}
		end
	else
		v102 = nil
	end
	return {
		["chips"] = v96,
		["note"] = v102,
		["bonus"] = v75
	}
end
function v_u_1.isFresh(p111) -- name: isFresh
	if p111.fresh == nil then
		return p111.canUndo == true
	else
		return p111.fresh == true
	end
end
function v_u_1.nodeState(p112, _) -- name: nodeState
	local v113
	if p112 then
		v113 = p112.rank
	else
		v113 = p112
	end
	local v114 = tonumber(v113)
	if ((v114 == nil or v114 ~= v114) and 0 or math.floor(v114)) <= 0 then
		return p112.state == "open" and p112.learnable == true and {
			["kind"] = "available",
			["icon"] = "plus",
			["iconColor"] = "accent",
			["edge"] = "accent",
			["edgeA"] = 0.15,
			["bg"] = "raised",
			["bgA"] = 0.1,
			["thick"] = 1
		} or (p112.state == "open" and {
			["kind"] = "needs",
			["icon"] = "minus",
			["iconColor"] = "text2",
			["edge"] = "line",
			["edgeA"] = 0,
			["bg"] = "raised",
			["bgA"] = 0.2,
			["thick"] = 1
		} or (p112.state == "blocked" and {
			["kind"] = "blocked",
			["icon"] = "warning",
			["iconColor"] = "danger",
			["edge"] = "danger",
			["edgeA"] = 0.3,
			["bg"] = "dangerDeep",
			["bgA"] = 0.2,
			["thick"] = 1
		} or {
			["kind"] = "locked",
			["icon"] = "arrowUp",
			["iconColor"] = "text2",
			["edge"] = "line",
			["edgeA"] = 0.3,
			["bg"] = "raised",
			["bgA"] = 0.5,
			["thick"] = 1
		}))
	end
	local v115
	if p112.fresh == nil then
		v115 = p112.canUndo == true
	else
		v115 = p112.fresh == true
	end
	return v115 and {
		["kind"] = "fresh",
		["icon"] = "check",
		["iconColor"] = "success",
		["edge"] = "success",
		["edgeA"] = 0,
		["bg"] = "accentDeep",
		["bgA"] = 0.05,
		["lock"] = nil,
		["thick"] = 2
	} or {
		["kind"] = "lockedin",
		["icon"] = "check",
		["iconColor"] = "accent",
		["edge"] = "accent",
		["edgeA"] = 0.4,
		["bg"] = "accentDeep",
		["bgA"] = 0.05,
		["lock"] = "lock",
		["thick"] = 1
	}
end
function v_u_1.shortWhy(p116) -- name: shortWhy
	-- upvalues: (copy) v_u_14
	local v117 = tostring(p116 or "")
	local v118 = string.gsub(v117, " free points", " points")
	return v_u_14((string.gsub(v118, "%.$", "")))
end
function v_u_1.learnWhy(p119) -- name: learnWhy
	-- upvalues: (copy) v_u_14
	if type(p119) == "table" then
		local v120 = p119.rank
		local v121 = tonumber(v120)
		if ((v121 == nil or v121 ~= v121) and 0 or math.floor(v121)) > 0 and (p119.state ~= "max" and p119.learnable ~= true) then
			local v122 = p119.why or ""
			local v123 = tostring(v122)
			local v124 = string.gsub(v123, " free points", " points")
			local v125 = v_u_14((string.gsub(v124, "%.$", "")))
			if v125 == "" then
				return nil
			else
				return ("Next rank: %s."):format(string.lower((string.sub(v125, 1, 1))) .. string.sub(v125, 2))
			end
		end
	end
	return nil
end
function v_u_1.reason(p126, p127, p128) -- name: reason
	-- upvalues: (copy) v_u_3, (copy) v_u_14, (copy) v_u_1
	if type(p126) == "table" then
		local v129
		if type(p127) == "table" then
			v129 = p127.canChange == true
		else
			v129 = false
		end
		local v130 = p126.rank
		local v131 = tonumber(v130)
		local v132 = (v131 == nil or v131 ~= v131) and 0 or math.floor(v131)
		local v133
		if p127 then
			v133 = p127.tokens
		else
			v133 = p127
		end
		local v134 = tonumber(v133)
		local v135 = (v134 == nil or v134 ~= v134) and 0 or math.floor(v134)
		local v136
		if p127 then
			v136 = p127.tokensPerRaid
		else
			v136 = p127
		end
		local v137 = tonumber(v136)
		local v138 = (v137 == nil or v137 ~= v137) and 3 or math.floor(v137)
		local v139
		if p127 then
			v139 = p127.raids
		else
			v139 = p127
		end
		local v140 = tonumber(v139)
		local v141 = (v140 == nil or v140 ~= v140) and 0 or math.floor(v140)
		if v129 then
			if v132 <= 0 then
				if p126.learnable == true then
					local v142 = p126.nextCost
					local v143 = tonumber(v142)
					local v144 = (v143 == nil or v143 ~= v143) and 1 or math.floor(v143)
					return ("Costs %d %s. Hold to learn."):format(v144, v144 == 1 and "point" or "points"), "ok"
				else
					local v145 = p126.why or ""
					local v146 = tostring(v145)
					local v147 = string.gsub(v146, " free points", " points")
					local v148 = v_u_14((string.gsub(v147, "%.$", "")))
					if type(p128) == "string" and p128 ~= "" then
						v148 = v_u_14(p128)
					end
					local v149 = p126.trial
					if type(v149) == "table" and p126.trial.done ~= true then
						local v150 = p126.trial.have
						local v151 = tonumber(v150)
						local v152 = (v151 == nil or v151 ~= v151) and 0 or math.floor(v151)
						local v153 = p126.trial.need
						local v154 = tonumber(v153)
						local v155 = ("%d of %d"):format(v152, (v154 == nil or v154 ~= v154) and 0 or math.floor(v154))
						local v156 = p126.why or ""
						local v157 = tostring(v156)
						local v158 = string.gsub(v157, " free points", " points")
						local v159 = v_u_14((string.gsub(v158, "%.$", "")))
						local v160 = string.sub(v159, 1, 6) == "Trial:" and "" or v159
						if v160 == "" or string.sub(v160, 1, 5) == "Needs" then
							v160 = ""
							if type(p128) == "string" and p128 ~= "" then
								local v161 = {}
								local v162 = v_u_14(p128)
								if string.sub(v162, 1, 7) == "Needs: " then
									v162 = string.sub(v162, 8)
								end
								for v163 in string.gmatch(v162 .. "  \194\183  ", "(.-)  \194\183  ") do
									if v163 == "" or string.sub(v163, 1, 6) == "Trial " then
										continue
									end
									table.insert(v161, v163)
								end
								if #v161 > 0 then
									v160 = "Needs " .. table.concat(v161, "; ")
								end
							else
								local v164 = p126.why or ""
								local v165 = tostring(v164)
								local v166 = string.gsub(v165, " free points", " points")
								if v_u_14((string.gsub(v166, "%.$", ""))) ~= "" then
									local v167 = p126.why or ""
									local v168 = tostring(v167)
									local v169 = string.gsub(v168, " free points", " points")
									local v170 = v_u_14((string.gsub(v169, "%.$", "")))
									if string.sub(v170, 1, 6) ~= "Trial:" then
										local v171 = p126.why or ""
										local v172 = tostring(v171)
										local v173 = string.gsub(v172, " free points", " points")
										v160 = v_u_14((string.gsub(v173, "%.$", "")))
									end
								end
							end
						end
						local v174
						if v160 == "" then
							local v175 = string.gsub
							local v176 = p126.trial.text or ""
							local v177 = v175(tostring(v176), "%.$", "")
							v174 = ("Finish the trial: %s.%s"):format(v155, v177 == "" and "" or " " .. v177 .. ".")
						else
							v174 = ("%s. Then finish the trial: %s."):format(v160, v155)
						end
						if p126.state == "blocked" then
							return v174, "bad"
						else
							return v174, "info"
						end
					else
						local v178 = v148 == "" and "Locked." or v148
						if p126.state == "open" and type(p127) == "table" then
							local v179 = p127.points
							if type(v179) == "table" then
								local v180 = p127.points.bound
								if type(v180) == "table" then
									for v181, v182 in p127.points.bound do
										if v181 == p126.branch then
											continue
										end
										local v183 = tonumber(v182)
										if ((v183 == nil or v183 ~= v183) and 0 or math.floor(v183)) <= 0 then
											continue
										end
										local v184 = tonumber(v182)
										return ("%s (+%d bonus only in %s)"):format(v178, (v184 == nil or v184 ~= v184) and 0 or math.floor(v184), v_u_1.BRANCH_NAME[tostring(v181)] or string.upper((tostring(v181)))), "info"
									end
								end
							end
						end
						local v185 = v178 .. (string.sub(v178, -1) == ")" and "" or ".")
						if p126.state == "blocked" then
							return v185, "bad"
						else
							return v185, "info"
						end
					end
				end
			else
				local v_u_186 = v_u_1.learnWhy(p126)
				local function v189(p187, p188) -- name: joined
					-- upvalues: (copy) v_u_186
					if v_u_186 == nil then
						return p187, p188
					else
						return p187 .. " " .. v_u_186, p188
					end
				end
				if p126.canUndo == true then
					return v189(v_u_3.undoFree, "ok")
				else
					local v190 = p126.unlearnCost
					local v191 = tonumber(v190)
					local v192 = (v191 == nil or v191 ~= v191) and 1 or math.floor(v191)
					if p126.fresh == true then
						return v189(v_u_3.undoBlocked, "bad")
					elseif p126.canUnlearn == true then
						return v189(("Locked in. Unlearn costs %d %s. Hold to unlearn."):format(v192, v192 == 1 and "token" or "tokens"), "ok")
					else
						local v193 = p126.unlearnWhy or ""
						local v194 = tostring(v193)
						if string.find(v194, "depends", 1, true) then
							return v189(v_u_3.unlearnBlocked, "bad")
						elseif v135 < v192 then
							if v141 == 0 then
								return v189(("Finish a raid first. You get %d tokens per raid."):format(v138), "bad")
							else
								return v189(("Needs %d %s, you have %d. You get %d per finished raid."):format(v192, v192 == 1 and "token" or "tokens", v135, v138), "bad")
							end
						else
							return v189(v_u_3.unlearnBlocked, "bad")
						end
					end
				end
			end
		else
			return v_u_3.lobby, "info"
		end
	else
		return "", "info"
	end
end
function v_u_1.undoReason(p195) -- name: undoReason
	-- upvalues: (copy) v_u_3
	if type(p195) == "table" then
		local v196 = p195.rank
		local v197 = tonumber(v196)
		local v198 = (v197 == nil or v197 ~= v197) and 0 or math.floor(v197)
		if p195.canUndo == true then
			return v_u_3.undoFree
		else
			return (v198 <= 0 or p195.fresh == false) and "Nothing learned since your last raid. Locked in perks need UNLEARN." or v_u_3.undoBlocked
		end
	else
		return ""
	end
end
function v_u_1.tierHeader(p199, p200, p201) -- name: tierHeader
	-- upvalues: (copy) v_u_1
	local v202
	if p201 then
		v202 = p201.gate
	else
		v202 = p201
	end
	local v203 = tonumber(v202)
	local v204 = (v203 == nil or v203 ~= v203) and 0 or math.floor(v203)
	local v205
	if p201 then
		v205 = p201.have
	else
		v205 = p201
	end
	local v206 = tonumber(v205)
	local v207 = (v206 == nil or v206 ~= v206) and 0 or math.floor(v206)
	local v208 = p201 == nil and true or p201.open == true
	local v209 = v_u_1.BRANCH_NAME[tostring(p199)] or string.upper((tostring(p199)))
	local v210
	if v208 then
		if v204 == 0 then
			v210 = ("TIER %d  \194\183  open from the start"):format(p200)
		else
			v210 = ("TIER %d  \194\183  open  \194\183  %d points spent here, %d needed"):format(p200, v207, v204)
		end
	else
		local v211 = v204 - v207
		v210 = ("TIER %d  \194\183  spend %d more in %s  \194\183  %d of %d"):format(p200, math.max(0, v211), v209, v207, v204)
	end
	local v212 = {
		["text"] = v210,
		["have"] = v207,
		["gate"] = v204,
		["open"] = v208
	}
	local v213
	if v204 > 0 then
		local v214 = v207 / v204
		v213 = math.clamp(v214, 0, 1)
	else
		v213 = 1
	end
	v212.frac = v213
	return v212
end
function v_u_1.flawLines(p215, p216, p217) -- name: flawLines
	-- upvalues: (copy) v_u_1, (copy) v_u_14
	local v218 = p217 or v_u_1.flawGive(p216)
	local v219 = p215.branch
	local v220 = v_u_1.BRANCH_NAME[tostring(v219)] or string.upper((tostring(v219)))
	local v221 = p216 and p216.flawSlots
	if v221 then
		v221 = p216.flawSlots.holdRaids
	end
	local v222 = tonumber(v221)
	local v223 = (v222 == nil or v222 ~= v222) and 3 or math.floor(v222)
	if p215.active ~= true then
		local v224 = 0
		for _, v225 in v218 do
			v224 = v224 + v225
		end
		local v226 = p215.refund
		local v227 = tonumber(v226)
		local v228 = (v227 == nil or v227 ~= v227) and 0 or math.floor(v227)
		local v229 = 0
		local v230
		if type(p216) == "table" then
			local v231 = p216.flawSlots
			v230 = type(v231) ~= "table" and {} or p216.flawSlots
		else
			v230 = {}
		end
		local v232 = v230.refundCap
		local v233 = tonumber(v232)
		local v234 = ((v233 == nil or v233 ~= v233) and 6 or math.floor(v233)) - v224
		local v235 = math.max(v229, v234)
		local v236 = math.min(v228, v235)
		local v237
		if v236 > 0 then
			v237 = ("Gives %d bonus %s to %s"):format(v236, v236 == 1 and "point" or "points", v220)
		else
			local v238 = "Gives no bonus points (limit %d reached)"
			local v239
			if type(p216) == "table" then
				local v240 = p216.flawSlots
				v239 = type(v240) ~= "table" and {} or p216.flawSlots
			else
				v239 = {}
			end
			local v241 = v239.refundCap
			local v242 = tonumber(v241)
			v237 = v238:format((v242 == nil or v242 ~= v242) and 6 or math.floor(v242))
		end
		local v243 = ("Dropping it later takes them back. Hold it %d raids first."):format(v223)
		local v244
		if p215.canTake == true or not p215.why then
			v244 = "muted"
		else
			local v245 = v_u_14
			local v246 = p215.why
			v243 = v245((tostring(v246)))
			v244 = "bad"
		end
		return {
			["line1"] = nil,
			["kind1"] = "info",
			["line2"] = nil,
			["kind2"] = nil,
			["tag"] = nil,
			["line1"] = v237,
			["line2"] = v243,
			["kind2"] = v244
		}
	end
	local v247 = p215.id
	local v248
	if v218[tostring(v247)] == nil then
		local v249 = p215.refund
		local v250 = tonumber(v249)
		v248 = (v250 == nil or v250 ~= v250) and 0 or math.floor(v250)
	else
		local v251 = p215.id
		v248 = v218[tostring(v251)]
	end
	local v252 = ("Lends %d %s to %s"):format(v248, v248 == 1 and "point" or "points", v220)
	local v253 = p215.holdLeft
	local v254 = tonumber(v253)
	local v255 = (v254 == nil or v254 ~= v254) and 0 or math.floor(v254)
	local v256
	if p215.dropNeed == nil then
		v256 = nil
	else
		local v257 = p215.dropNeed
		local v258 = tonumber(v257)
		v256 = (v258 == nil or v258 ~= v258) and 0 or math.floor(v258)
	end
	if p216 then
		p216 = p216.tokens
	end
	local v259 = tonumber(p216)
	local v260 = (v259 == nil or v259 ~= v259) and 0 or math.floor(v259)
	if v255 > 0 then
		return {
			["line1"] = nil,
			["kind1"] = "info",
			["line2"] = nil,
			["kind2"] = "muted",
			["tag"] = "BORROWED",
			["line1"] = v252,
			["line2"] = ("Keep it for %d more %s."):format(v255, v255 == 1 and "raid" or "raids")
		}
	end
	if v256 ~= nil and v256 > 0 then
		return {
			["line1"] = nil,
			["kind1"] = "info",
			["line2"] = nil,
			["kind2"] = "bad",
			["tag"] = "BORROWED",
			["line1"] = v252,
			["line2"] = ("Dropping it takes %d %s back. Unlearn %d %s first (costs at least %d %s, you have %d)."):format(v248, v248 == 1 and "point" or "points", v256, v256 == 1 and "point" or "points", v256, v256 == 1 and "token" or "tokens", v260)
		}
	end
	if v256 ~= nil or (p215.canDrop == true or not p215.why) then
		return {
			["line1"] = nil,
			["kind1"] = "info",
			["line2"] = nil,
			["kind2"] = "muted",
			["tag"] = "BORROWED",
			["line1"] = v252,
			["line2"] = ("Dropping it takes %d unspent %s back."):format(v248, v248 == 1 and "point" or "points")
		}
	end
	local v261 = {
		["line1"] = nil,
		["kind1"] = "info",
		["line2"] = nil,
		["kind2"] = "bad",
		["tag"] = "BORROWED",
		["line1"] = v252
	}
	local v262 = v_u_14
	local v263 = p215.why
	v261.line2 = v262((tostring(v263)))
	return v261
end
function v_u_1.sections() -- name: sections
	return {
		{
			["id"] = "points",
			["head"] = "POINTS",
			["color"] = "accent",
			["text"] = "You earn 1 point per Field Level and 1 per First. FREE is what you have not spent yet."
		},
		{
			["id"] = "example",
			["head"] = "EXAMPLE",
			["color"] = "text",
			["text"] = "Field Level 7 + 6 Firsts + 3 bonus points = 16 points. Spend 5 of them in one branch and its tier 2 opens."
		},
		{
			["id"] = "tiers",
			["head"] = "TIERS",
			["color"] = "text",
			["text"] = "A tier opens when you have spent enough points in the same branch: 0, 5, 8, 12 and 16."
		},
		{
			["id"] = "bonus",
			["head"] = "BONUS",
			["color"] = "info",
			["text"] = "A flaw lends you bonus points, up to 6. They can only be spent in the branch of the flaw and are used up first there."
		},
		{
			["id"] = "undo",
			["head"] = "UNDO",
			["color"] = "success",
			["text"] = "A perk you learned since your last finished raid can be undone for free."
		},
		{
			["id"] = "lockedin",
			["head"] = "LOCKED IN",
			["color"] = "text2",
			["icon"] = "lock",
			["text"] = "When a raid ends, your perks lock in. UNLEARN takes one back for tokens. You get 3 tokens per finished raid, up to 9."
		},
		{
			["id"] = "flaws",
			["head"] = "FLAWS",
			["color"] = "danger",
			["text"] = "You may drop a flaw after 3 finished raids. Its bonus points go back. If you already spent them, unlearn that many points first."
		}
	}
end
v_u_1.LEGEND = {
	{
		["id"] = "available",
		["icon"] = "plus",
		["iconColor"] = "accent",
		["label"] = "AVAILABLE"
	},
	{
		["id"] = "needs",
		["icon"] = "minus",
		["iconColor"] = "text2",
		["label"] = "NEEDS POINTS"
	},
	{
		["id"] = "locked",
		["icon"] = "arrowUp",
		["iconColor"] = "text2",
		["label"] = "NEEDS TIER"
	},
	{
		["id"] = "fresh",
		["icon"] = "check",
		["iconColor"] = "success",
		["label"] = "FREE UNDO"
	},
	{
		["id"] = "lockedin",
		["icon"] = "lock",
		["iconColor"] = "text2",
		["label"] = "LOCKED IN"
	},
	{
		["id"] = "blocked",
		["icon"] = "warning",
		["iconColor"] = "danger",
		["label"] = "BLOCKED"
	}
}
function v_u_1.legendItems() -- name: legendItems
	-- upvalues: (copy) v_u_1
	return v_u_1.LEGEND
end
v_u_1.LEGEND_ROW_H = 26
v_u_1.LEGEND_EM = 0.62
v_u_1.LEGEND_SIZE = 13
function v_u_1.legend(p264, p265) -- name: legend
	-- upvalues: (copy) v_u_1
	if type(p265) ~= "number" or p265 <= 0 then
		p265 = v_u_1.LEGEND_SIZE
	end
	local v266 = 0
	local v267 = 0
	local v268 = {}
	for _, v269 in v_u_1.LEGEND do
		local v270 = v269.label
		local v271 = 0
		for v272 = 1, #v270 do
			local v273 = string.byte(v270, v272)
			if v273 >= 128 and v273 < 192 then
				continue
			end
			v271 = v271 + 1
		end
		local v274 = v271 * p265 * v_u_1.LEGEND_EM
		local v275 = math.ceil(v274) + 22 + 12
		if v266 > 0 and p264 < v266 + v275 then
			v267 = v267 + v_u_1.LEGEND_ROW_H
			v266 = 0
		end
		local v276 = {
			["x"] = v266,
			["y"] = v267,
			["w"] = v275,
			["h"] = v_u_1.LEGEND_ROW_H - 4
		}
		table.insert(v268, v276)
		v266 = v266 + (v275 + 4)
	end
	return {
		["rects"] = v268,
		["height"] = v267 + v_u_1.LEGEND_ROW_H,
		["rows"] = v267 / v_u_1.LEGEND_ROW_H + 1
	}
end
function v_u_1.guideRows(p277, p278) -- name: guideRows
	-- upvalues: (copy) v_u_1
	local v279 = (type(p278) ~= "number" or p278 <= 0) and 13 or p278
	local v280 = v279 * 1.3
	local v281 = math.ceil(v280)
	local v282 = (p277 - 16) / (v279 * 0.6)
	local v283 = math.floor(v282)
	local v284 = math.max(8, v283)
	local v285 = 0
	local v286 = {}
	for _, v287 in v_u_1.sections() do
		local v288 = v287.text
		local v289 = 0
		for v290 = 1, #v288 do
			local v291 = string.byte(v288, v290)
			if v291 >= 128 and v291 < 192 then
				continue
			end
			v289 = v289 + 1
		end
		local v292 = v289 / v284
		local v293 = math.ceil(v292)
		local v294 = v279 * 1.2
		local v295 = math.ceil(v294)
		local v296 = math.max(16, v295)
		local v297 = v296 + v293 * v281 + 10
		local v298 = {
			["section"] = v287,
			["y"] = v285,
			["h"] = v297,
			["headH"] = v296,
			["textY"] = v285 + v296,
			["textH"] = v293 * v281,
			["lines"] = v293
		}
		table.insert(v286, v298)
		v285 = v285 + v297
	end
	local v299 = v_u_1.legend(p277 - 16, v279)
	return {
		["rows"] = v286,
		["legendY"] = v285 + 6,
		["legend"] = v299,
		["height"] = v285 + 6 + 16 + v299.height
	}
end
return v_u_1