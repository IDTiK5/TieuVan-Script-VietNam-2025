-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EjectRagdoll

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("PhysicsService")
local v_u_3 = require(script.Parent.EjectRagdollPlan)
local v4 = {}
local v_u_5 = v_u_3.TUNE
local v_u_6 = {
	["Head"] = true,
	["UpperTorso"] = true,
	["LowerTorso"] = true,
	["LeftUpperArm"] = true,
	["LeftLowerArm"] = true,
	["LeftHand"] = true,
	["RightUpperArm"] = true,
	["RightLowerArm"] = true,
	["RightHand"] = true,
	["LeftUpperLeg"] = true,
	["LeftLowerLeg"] = true,
	["LeftFoot"] = true,
	["RightUpperLeg"] = true,
	["RightLowerLeg"] = true,
	["RightFoot"] = true
}
local v_u_7 = {}
local v_u_8 = {
	["made"] = 0,
	["joints"] = 0,
	["path"] = 0,
	["refused"] = 0,
	["handoffs"] = 0,
	["snaps"] = 0,
	["errors"] = 0,
	["caughtUp"] = 0
}
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = {}
function v4.bind(p12) -- name: bind
	-- upvalues: (ref) v_u_10
	if p12 ~= nil then
		v_u_10 = p12
	end
end
local function v_u_16() -- name: folder
	-- upvalues: (ref) v_u_9
	local v13 = v_u_9
	if v13 and v13.Parent then
		return v13
	end
	local v14 = workspace:FindFirstChild("HushLocal")
	if not v14 then
		v14 = Instance.new("Folder")
		v14.Name = "HushLocal"
		v14.Parent = workspace
	end
	local v15 = v14:FindFirstChild("EjectPuppets")
	if not v15 then
		v15 = Instance.new("Folder")
		v15.Name = "EjectPuppets"
		v15.Parent = v14
	end
	v_u_9 = v15
	return v_u_9
end
local function v_u_21(p_u_17) -- name: isRegistered
	-- upvalues: (copy) v_u_2
	local function v18()
		-- upvalues: (ref) v_u_2, (copy) p_u_17
		return v_u_2:IsCollisionGroupRegistered(p_u_17)
	end
	local v19, v20 = pcall(v18)
	if v19 then
		v19 = v20 == true
	end
	return v19
end
local function v_u_26(p22) -- name: strip
	-- upvalues: (copy) v_u_6
	for _, v23 in p22:GetDescendants() do
		if not (v23:IsA("LuaSourceContainer") or (v23:IsA("BillboardGui") or (v23:IsA("SurfaceGui") or (v23:IsA("Light") or (v23:IsA("Highlight") or (v23:IsA("ForceField") or (v23:IsA("Sound") or (v23:IsA("ParticleEmitter") or (v23:IsA("Beam") or (v23:IsA("Trail") or (v23:IsA("ProximityPrompt") or (v23:IsA("Fire") or (v23:IsA("Smoke") or v23:IsA("Sparkles")))))))))))))) then
			continue
		end
		v23:Destroy()
	end
	local v_u_24 = p22:FindFirstChildOfClass("Humanoid")
	if v_u_24 then
		v_u_24.EvaluateStateMachine = false
		v_u_24.BreakJointsOnDeath = false
		v_u_24.RequiresNeck = false
		v_u_24.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v_u_24.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		pcall(function()
			-- upvalues: (copy) v_u_24
			v_u_24:ChangeState(Enum.HumanoidStateType.Physics)
		end)
	end
	for _, v25 in p22:GetDescendants() do
		if not v25:IsA("BasePart") then
			continue
		end
		v25.LocalTransparencyModifier = 0
		if not v_u_6[v25.Name] and (v25.Name ~= "Handle" or (v25.Parent == nil or not v25.Parent:IsA("Accessory"))) or v25.Transparency <= 0.99 then
			continue
		end
		v25.Transparency = 0
	end
end
local function v_u_30(p27, p28) -- name: insideWeapon
	local v29 = p27.Parent
	while v29 and v29 ~= p28 do
		if v29.Name == "HeldWeapon" or (v29:IsA("Tool") or v29:IsA("Accessory")) then
			return true
		end
		v29 = v29.Parent
	end
	return false
end
local function v_u_43(p31) -- name: makeJoints
	-- upvalues: (copy) v_u_30
	local v32 = {}
	for _, v33 in p31:GetDescendants() do
		if not v33:IsA("Motor6D") then
			continue
		end
		table.insert(v32, v33)
	end
	local v34 = 0
	for _, v35 in v32 do
		local v36 = v35.Part0
		local v37 = v35.Part1
		if v36 and v37 then
			if v_u_30(v35, p31) or v_u_30(v37, p31) then
				local v38 = Instance.new("WeldConstraint")
				v38.Part0 = v36
				v38.Part1 = v37
				v38.Parent = v37
			else
				local v39 = Instance.new("Attachment")
				v39.Name = "EjectRagA"
				v39.CFrame = v35.C0
				v39.Parent = v36
				local v40 = Instance.new("Attachment")
				v40.Name = "EjectRagB"
				v40.CFrame = v35.C1
				v40.Parent = v37
				local v41 = Instance.new("BallSocketConstraint")
				v41.Name = "EjectRagJoint"
				v41.Attachment0 = v39
				v41.Attachment1 = v40
				v41.LimitsEnabled = true
				v41.TwistLimitsEnabled = true
				local v42 = string.find(string.lower(v37.Name), "head", 1, true) ~= nil
				v41.UpperAngle = v42 and 35 or 60
				v41.TwistLowerAngle = v42 and -30 or -40
				v41.TwistUpperAngle = v42 and 30 or 40
				v41.Parent = v36
				v34 = v34 + 1
			end
		end
		v35:Destroy()
	end
	return v34
end
local function v_u_48(p44, p45) -- name: trunkOf
	for _, v46 in { "LowerTorso", "UpperTorso", "Torso" } do
		local v47 = p44:FindFirstChild(v46)
		if not (v47 and v47:IsA("BasePart")) then
			continue
		end
		return v47
	end
	return p45
end
local function v_u_52(p49) -- name: allParts
	local v50 = {}
	for _, v51 in p49:GetDescendants() do
		if not v51:IsA("BasePart") then
			continue
		end
		table.insert(v50, v51)
	end
	return v50
end
local function v_u_58(p_u_53) -- name: landingFx
	-- upvalues: (copy) v_u_16, (ref) v_u_10
	local v_u_54 = Instance.new("Part")
	v_u_54.Name = "EjectDust"
	v_u_54.Anchored = true
	v_u_54.CanCollide = false
	v_u_54.CanQuery = false
	v_u_54.CanTouch = false
	v_u_54.Transparency = 1
	v_u_54.Size = Vector3.new(0.5, 0.5, 0.5)
	v_u_54.CFrame = CFrame.new(p_u_53)
	v_u_54.Parent = v_u_16()
	local v55 = Instance.new("ParticleEmitter")
	v55.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v55.Color = ColorSequence.new(Color3.fromRGB(150, 140, 126))
	v55.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
	v55.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.8), NumberSequenceKeypoint.new(1, 3.2) })
	v55.Lifetime = NumberRange.new(0.5, 1)
	v55.Speed = NumberRange.new(3, 7)
	v55.SpreadAngle = Vector2.new(180, 180)
	v55.Rate = 0
	v55.Parent = v_u_54
	v55:Emit(10)
	task.delay(1.6, function()
		-- upvalues: (copy) v_u_54
		v_u_54:Destroy()
	end)
	local function v57()
		-- upvalues: (ref) v_u_10, (copy) p_u_53
		local v56 = v_u_10
		if v56 then
			v56 = v_u_10.controllers
		end
		if v56 then
			v56 = v56.Audio
		end
		if v56 and v56.play3D then
			v56.play3D("impact_wall", p_u_53, {
				["volume"] = 0.9,
				["pitch"] = 0.8
			})
		end
	end
	pcall(v57)
end
function v4.play(p59, p60, p61) -- name: play
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_7, (copy) v_u_5, (copy) v_u_8, (copy) v_u_26, (copy) v_u_48, (copy) v_u_21, (copy) v_u_43, (copy) v_u_16, (copy) v_u_52
	if type(p59) == "table" then
		local v62 = p59.uid
		if type(v62) == "number" then
			local v63 = v_u_3.clean(p59)
			if v63 == nil then
				return "bad"
			end
			local v64 = p59.uid
			if p61 == nil and v63.at ~= nil then
				local v65
				v65, p61 = pcall(function()
					return workspace:GetServerTimeNow()
				end)
				if not v65 then
					p61 = nil
				end
			end
			local v66 = v_u_3.startAge(v63, p61)
			local v_u_67 = v_u_1:GetPlayerByUserId(v64)
			if v_u_67 then
				v_u_67 = v_u_67.Character
			end
			if not (v_u_67 and v_u_67.Parent) then
				v_u_67 = nil
			end
			if v_u_67 == nil then
				return "far"
			end
			for v68 = #v_u_7, 1, -1 do
				if v_u_7[v68].uid ~= v64 then
					continue
				end
				local v_u_69 = v_u_7[v68]
				pcall(function()
					-- upvalues: (copy) v_u_69
					v_u_69.model:Destroy()
				end)
				table.remove(v_u_7, v68)
			end
			while #v_u_7 >= v_u_5.MAX_PUPPETS do
				local v_u_70 = table.remove(v_u_7, 1)
				if not v_u_70 then
					continue
				end
				pcall(function()
					-- upvalues: (copy) v_u_70
					v_u_70.model:Destroy()
				end)
			end
			local v71 = v_u_67.Archivable
			v_u_67.Archivable = true
			local v72, v73 = pcall(function()
				-- upvalues: (copy) v_u_67
				return v_u_67:Clone()
			end)
			v_u_67.Archivable = v71
			if not v72 or v73 == nil then
				local v74 = v_u_8
				v74.refused = v74.refused + 1
				return "refused"
			end
			v73.Name = "EjectPuppet"
			v_u_26(v73)
			local v75 = v73:FindFirstChild("HumanoidRootPart")
			if not (v75 and v75:IsA("BasePart")) then
				if v73.PrimaryPart then
					v75 = v73.PrimaryPart
				else
					v75 = v73:FindFirstChildWhichIsA("BasePart", true)
				end
			end
			if v75 == nil then
				v73:Destroy()
				local v76 = v_u_8
				v76.refused = v76.refused + 1
				return "refused"
			end
			if v73.PrimaryPart == nil then
				v73.PrimaryPart = v75
			end
			local v77 = v_u_48(v73, v75)
			local v78 = 0
			for _, v79 in v73:GetDescendants() do
				if not v79:IsA("Motor6D") then
					continue
				end
				v78 = v78 + 1
			end
			local v80 = type(p60) ~= "number" and 3 or p60
			local v81 = 0
			for _, v82 in v_u_7 do
				if v82.kind ~= "joints" or v82.frozen then
					continue
				end
				v81 = v81 + 1
			end
			local v83 = v_u_3.mode(v80, v78)
			local v84 = v_u_3.groupName(v66, v_u_21)
			local v85 = v83 == "joints" and (v_u_5.MAX_SIM <= v81 or v84 == nil) and "path" or v83
			local v86 = v_u_3.sample(v63, v66)
			local v87 = v63.launch.x
			local v88 = v63.launch.z
			local v89 = Vector3.new(v87, 0, v88)
			local v90 = v63.handoff.yaw
			if v89.Magnitude > 0.5 then
				local v91 = -v89.X
				local v92 = -v89.Z
				local v93 = math.atan2(v91, v92)
				v90 = math.deg(v93)
			end
			local v94 = v89.Magnitude <= 0.01 and Vector3.new(0, 0, -1) or v89.Unit
			local v_u_95 = {
				["uid"] = nil,
				["model"] = nil,
				["kind"] = nil,
				["plan"] = nil,
				["t0"] = nil,
				["trunk"] = nil,
				["root"] = nil,
				["parts"] = nil,
				["group"] = nil,
				["late"] = nil,
				["handed"] = false,
				["frozen"] = false,
				["flatDir"] = nil,
				["uid"] = v64,
				["model"] = v73,
				["kind"] = v85,
				["plan"] = v63,
				["t0"] = os.clock() - v66,
				["trunk"] = v77,
				["root"] = v75,
				["parts"] = {},
				["late"] = v_u_5.EARLY_S <= v66,
				["flatDir"] = v94
			}
			if v85 == "joints" then
				v_u_43(v73)
			end
			v73.Parent = v_u_16()
			v_u_95.parts = v_u_52(v73)
			local v96 = v86.x
			local v97 = v86.y
			local v98 = v86.z
			local v99 = Vector3.new(v96, v97, v98)
			local v100 = (v85 ~= "path" or v66 <= 0) and 0 or v_u_3.tumble(v63, v66)
			local v_u_101 = CFrame.new(v99) * CFrame.Angles(0, math.rad(v90), 0) * CFrame.Angles(math.rad(v100), 0, 0)
			pcall(function()
				-- upvalues: (copy) v_u_95, (copy) v_u_101
				v_u_95.model:PivotTo(v_u_101 * v_u_95.trunk.CFrame:Inverse() * v_u_95.model:GetPivot())
			end)
			if v66 > 0 then
				local v102 = v_u_8
				v102.caughtUp = v102.caughtUp + 1
			end
			if v85 == "joints" then
				for _, v103 in v_u_95.parts do
					v103.Anchored = false
					v103.CanTouch = false
					v103.CanQuery = false
					local v104
					if v103 == v75 then
						v104 = false
					else
						v104 = v103 ~= v77
					end
					v103.CanCollide = v104
					v103.CustomPhysicalProperties = PhysicalProperties.new(0.7, 0.5, 0.1, 1, 1)
				end
				if v84 ~= nil then
					v_u_95.group = v84
					for _, v105 in v_u_95.parts do
						v105.CollisionGroup = v84
					end
				end
				local v106
				if v66 > 0 then
					v106 = v_u_3.velocityAt(v63, v66)
				else
					v106 = v63.launch
				end
				local v107 = v106.x
				local v108 = v106.y
				local v109 = v106.z
				local v110 = Vector3.new(v107, v108, v109)
				local v111 = v94.Z
				local v112 = -v94.X
				local v113 = Vector3.new(v111, 0, v112) * 6
				for _, v114 in v_u_95.parts do
					v114.AssemblyLinearVelocity = v110
					v114.AssemblyAngularVelocity = v113
				end
				local v115 = v_u_8
				v115.joints = v115.joints + 1
			else
				for _, v116 in v_u_95.parts do
					v116.Anchored = true
					v116.CanCollide = false
					v116.CanQuery = false
					v116.CanTouch = false
				end
				local v117 = v_u_8
				v117.path = v117.path + 1
			end
			local v118 = v_u_8
			v118.made = v118.made + 1
			local v119 = v_u_7
			table.insert(v119, v_u_95)
			return v85
		end
	end
	return "bad"
end
local function v_u_141(p_u_120) -- name: handOver
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_58, (copy) v_u_11
	local v121 = v_u_3.lyingPose(p_u_120.plan.handoff)
	local v122 = v121.x
	local v123 = v121.y
	local v124 = v121.z
	local v125 = Vector3.new(v122, v123, v124)
	local v126 = v121.yawDeg
	local v127 = v121.pitchDeg
	local v_u_128 = CFrame.new(v125) * CFrame.Angles(0, math.rad(v126), 0) * CFrame.Angles(math.rad(v127), 0, 0)
	pcall(function()
		-- upvalues: (copy) p_u_120, (copy) v_u_128
		p_u_120.model:PivotTo(v_u_128 * p_u_120.trunk.CFrame:Inverse() * p_u_120.model:GetPivot())
	end)
	if not p_u_120.frozen then
		p_u_120.frozen = true
		for _, v129 in p_u_120.parts do
			v129.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v129.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
			v129.Anchored = true
			v129.CanCollide = false
		end
	end
	p_u_120.handed = true
	local v130 = v_u_8
	v130.handoffs = v130.handoffs + 1
	local v131 = v_u_58
	local v132 = p_u_120.plan.to.x
	local v133 = p_u_120.plan.to.y + 0.2
	local v134 = p_u_120.plan.to.z
	local v135 = Vector3.new(v132, v133, v134)
	pcall(v131, v135)
	for _, v136 in v_u_11 do
		local v137 = p_u_120.uid
		local v138, v139 = pcall(v136, v137, v121)
		if v138 then
			continue
		end
		local v140 = v_u_8
		v140.errors = v140.errors + 1
		if v_u_8.errors > 3 then
			continue
		end
		warn("[EjectRagdoll] " .. "handoff hook" .. " failed: " .. tostring(v139))
	end
end
local function v_u_187(p_u_142, p143, p144) -- name: stepOne
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_21, (copy) v_u_8, (copy) v_u_141
	local v145 = p_u_142.plan
	local v146 = v_u_3.phaseAt(v145, p143)
	if v146 == "flight" then
		local v147 = v_u_3.target(v145, p143)
		if p_u_142.kind == "joints" then
			if not p_u_142.late and v_u_5.EARLY_S <= p143 then
				p_u_142.late = true
				local v148 = v_u_3.groupName(p143, v_u_21)
				if v148 ~= nil then
					p_u_142.group = v148
					for _, v149 in p_u_142.parts do
						v149.CollisionGroup = v148
					end
				end
			end
			local v150 = v_u_3.pullWeight(v145, p143)
			local v151 = p_u_142.trunk.Position
			local v152, v153 = v_u_3.follow({
				["x"] = v151.X,
				["y"] = v151.Y,
				["z"] = v151.Z
			}, nil, v147, v_u_3.velocityAt(v145, p143), p144, v150)
			if v153 then
				local v154 = v_u_8
				v154.snaps = v154.snaps + 1
				local v155 = p_u_142.model
				local v156 = p_u_142.model:GetPivot()
				local v157 = v147.x
				local v158 = v147.y
				local v159 = v147.z
				v155:PivotTo(v156 + (Vector3.new(v157, v158, v159) - v151))
			end
			local v160 = p_u_142.trunk
			local v161 = v152.x
			local v162 = v152.y
			local v163 = v152.z
			v160.AssemblyLinearVelocity = Vector3.new(v161, v162, v163)
			if v150 > 0 then
				local v164 = v_u_3.lyingPose(v145.handoff)
				local v165 = v147.x
				local v166 = v147.y
				local v167 = v147.z
				local v168 = Vector3.new(v165, v166, v167)
				local v169 = v164.yawDeg
				local v170 = v164.pitchDeg
				local v171 = CFrame.new(v168) * CFrame.Angles(0, math.rad(v169), 0) * CFrame.Angles(math.rad(v170), 0, 0)
				local v172 = p_u_142.trunk.CFrame
				local v173 = p144 * 18
				local v174 = v150 * math.min(1, v173)
				local v_u_175 = v172:Lerp(v171, (math.clamp(v174, 0, 1)))
				pcall(function()
					-- upvalues: (copy) p_u_142, (copy) v_u_175
					p_u_142.model:PivotTo(v_u_175 * p_u_142.trunk.CFrame:Inverse() * p_u_142.model:GetPivot())
				end)
				for _, v176 in p_u_142.parts do
					if v176 == p_u_142.trunk then
						continue
					end
					v176.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
				end
				return
			end
		else
			local v177 = v_u_3.lyingPose(v145.handoff)
			local v178 = v_u_3.tumble(v145, p143)
			local v179 = v147.x
			local v180 = v147.y
			local v181 = v147.z
			local v182 = Vector3.new(v179, v180, v181)
			local v183 = v177.yawDeg
			local v_u_184 = CFrame.new(v182) * CFrame.Angles(0, math.rad(v183), 0) * CFrame.Angles(math.rad(v178), 0, 0)
			pcall(function()
				-- upvalues: (copy) p_u_142, (copy) v_u_184
				p_u_142.model:PivotTo(v_u_184 * p_u_142.trunk.CFrame:Inverse() * p_u_142.model:GetPivot())
			end)
		end
	else
		if not p_u_142.handed then
			v_u_141(p_u_142)
		end
		if v146 == "fade" then
			local v185 = v_u_3.fadeAlpha(v145, p143)
			for _, v186 in p_u_142.parts do
				v186.LocalTransparencyModifier = v185
			end
		end
	end
end
function v4.step(p188) -- name: step
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_141, (copy) v_u_187, (copy) v_u_8
	if #v_u_7 ~= 0 then
		local v189 = os.clock()
		local v190 = (type(p188) ~= "number" or (p188 ~= p188 or p188 <= 0)) and 0.016666666666666666 or math.min(p188, 0.25)
		for v191 = #v_u_7, 1, -1 do
			local v_u_192 = v_u_7[v191]
			if v_u_192.model.Parent == nil then
				table.remove(v_u_7, v191)
			else
				local v193 = v189 - v_u_192.t0
				if v_u_5.MAX_AGE < v193 or v_u_3.phaseAt(v_u_192.plan, v193) == "done" then
					if not v_u_192.handed then
						local v194 = v_u_141
						pcall(v194, v_u_192)
					end
					table.remove(v_u_7, v191)
					pcall(function()
						-- upvalues: (copy) v_u_192
						v_u_192.model:Destroy()
					end)
				else
					local v195 = v_u_187
					local v196, v197 = pcall(v195, v_u_192, v193, v190)
					if v196 then
						continue
					end
					local v198 = v_u_8
					v198.errors = v198.errors + 1
					if v_u_8.errors <= 3 then
						warn("[EjectRagdoll] " .. "step" .. " failed: " .. tostring(v197))
					end
					table.remove(v_u_7, v191)
					pcall(function()
						-- upvalues: (copy) v_u_192
						v_u_192.model:Destroy()
					end)
				end
			end
		end
	end
end
function v4.focus(p199) -- name: focus
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	if not p199 then
		local v200 = v_u_1.LocalPlayer
		p199 = not v200 and -1 or v200.UserId
	end
	for _, v201 in v_u_7 do
		if v201.uid ~= p199 or v201.handed then
			continue
		end
		local v202 = v201.trunk.AssemblyLinearVelocity
		return {
			["pos"] = v201.trunk.Position,
			["vel"] = v202,
			["age"] = os.clock() - v201.t0,
			["dur"] = v201.plan.dur
		}
	end
	return nil
end
function v4.active(p203) -- name: active
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	if not p203 then
		local v204 = v_u_1.LocalPlayer
		p203 = not v204 and -1 or v204.UserId
	end
	for _, v205 in v_u_7 do
		if v205.uid ~= p203 or v205.handed then
			continue
		end
		return true
	end
	return false
end
function v4.onHandoff(p_u_206) -- name: onHandoff
	-- upvalues: (copy) v_u_11
	local v207 = v_u_11
	table.insert(v207, p_u_206)
	return function()
		-- upvalues: (ref) v_u_11, (copy) p_u_206
		local v208 = table.find(v_u_11, p_u_206)
		if v208 then
			table.remove(v_u_11, v208)
		end
	end
end
function v4.stats() -- name: stats
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v209 = 0
	for _, v210 in v_u_7 do
		if v210.handed then
			continue
		end
		v209 = v209 + 1
	end
	return {
		["puppets"] = #v_u_7,
		["flying"] = v209,
		["made"] = v_u_8.made,
		["joints"] = v_u_8.joints,
		["path"] = v_u_8.path,
		["refused"] = v_u_8.refused,
		["handoffs"] = v_u_8.handoffs,
		["snaps"] = v_u_8.snaps,
		["errors"] = v_u_8.errors,
		["caughtUp"] = v_u_8.caughtUp
	}
end
function v4.clear() -- name: clear
	-- upvalues: (copy) v_u_7, (ref) v_u_9
	for _, v_u_211 in v_u_7 do
		pcall(function()
			-- upvalues: (copy) v_u_211
			v_u_211.model:Destroy()
		end)
	end
	table.clear(v_u_7)
	local v212 = v_u_9
	if v212 and v212.Parent then
		v212:ClearAllChildren()
	end
end
return v4