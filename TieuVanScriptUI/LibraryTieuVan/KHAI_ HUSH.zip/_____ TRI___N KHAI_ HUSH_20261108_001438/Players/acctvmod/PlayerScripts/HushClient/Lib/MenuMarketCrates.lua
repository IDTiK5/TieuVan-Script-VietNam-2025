-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketCrates

local v_u_1 = {
	["REFRESH"] = 10,
	["WIDE_MIN"] = 640,
	["CARD_H"] = 292,
	["ROW_H"] = 92,
	["FALLBACK_IDS"] = {
		"skin_crate_field",
		"skin_crate_tacet",
		"skin_crate_vault",
		"skin_crate_halloween",
		"skin_crate_tokyo"
	}
}
local function v_u_7(p_u_2) -- name: caseIds
	-- upvalues: (copy) v_u_1
	local v3, v4 = pcall(function()
		-- upvalues: (copy) p_u_2
		return p_u_2.mc.cctx.shared.CaseOdds.ORDER
	end)
	if v3 and (type(v4) == "table" and #v4 > 0) then
		return v4
	end
	local v5 = p_u_2.Data.cm
	if v5 ~= nil then
		local v6 = v5.ORDER
		if type(v6) == "table" and #v5.ORDER > 0 then
			return v5.ORDER
		end
	end
	return v_u_1.FALLBACK_IDS
end
function v_u_1.new(p_u_8, p_u_9) -- name: new
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v_u_10 = p_u_8.ui
	local v_u_11 = p_u_8.theme
	local v_u_12 = p_u_8.C
	local v_u_13 = p_u_8.Data
	local v_u_14 = p_u_8.data
	local v_u_15 = p_u_8.h
	local v_u_16 = p_u_8.phone == true
	local v_u_17 = {}
	local v_u_18 = true
	local v_u_19 = false
	local v_u_20 = {}
	local v_u_21 = v_u_7(p_u_8)
	local v_u_22 = {}
	local v_u_23 = "loading"
	local v_u_24 = false
	local v_u_25 = (-1 / 0)
	local v_u_26 = "none"
	local v_u_27 = {}
	local v_u_28 = {}
	local v_u_29 = nil
	local v_u_30 = ""
	local v_u_31 = -1
	local v_u_32 = nil
	local function v33()
		-- upvalues: (ref) v_u_32, (copy) p_u_8
		v_u_32 = p_u_8.mc.cctx.lib.MenuMarketCrateKit
	end
	pcall(v33)
	local v34 = p_u_8.controlFrame("crates")
	local v35 = p_u_8.Data.cm
	local v36
	if v35 == nil then
		v36 = nil
	else
		local v37 = v35.TEXT
		if type(v37) == "table" then
			v36 = v35.TEXT.openYours
		else
			v36 = nil
		end
	end
	local v38 = (type(v36) ~= "string" or v36 == "") and "OPEN YOUR CASES" or v36
	local v_u_40 = v_u_15.button(v34, v38, "secondary", function()
		-- upvalues: (copy) p_u_8
		local function v39()
			-- upvalues: (ref) p_u_8
			p_u_8.mc.openCrates()
		end
		pcall(v39)
	end, {
		["name"] = "OpenYours",
		["height"] = 40,
		["width"] = nil,
		["anchor"] = nil,
		["position"] = nil,
		["maxTextWidth"] = nil,
		["width"] = p_u_8.compact and 190 or 210,
		["anchor"] = Vector2.new(1, 0.5),
		["position"] = UDim2.new(1, 0, 0.5, 0),
		["maxTextWidth"] = p_u_8.compact and 176 or 196
	})
	local v41 = v_u_10.list({
		["parent"] = nil,
		["name"] = "Scroll",
		["size"] = nil,
		["gap"] = 10,
		["padding"] = nil,
		["parent"] = p_u_9,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			0,
			8,
			0,
			10
		}
	})
	local v_u_42 = v_u_10.new("Frame", {
		["Name"] = "StripHost",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v41)
	v_u_10.layout(v_u_42, "v", 6)
	local v_u_43 = v_u_10.new("Frame", {
		["Name"] = "Cards",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v41)
	local v44 = v_u_10.label
	local v45 = {
		["parent"] = nil,
		["name"] = "Footer",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v41
	}
	local v46 = p_u_8.Data.cm
	local v47
	if v46 == nil then
		v47 = nil
	else
		local v48 = v46.TEXT
		if type(v48) == "table" then
			v47 = v46.TEXT.footer
		else
			v47 = nil
		end
	end
	v45.text = (type(v47) ~= "string" or v47 == "") and "A case holds one random finish. Opening needs a key or cash. Finishes are cosmetic, stay on your account and cannot be traded." or v47
	v45.color = v_u_12.text2
	v44(v45)
	local function v_u_51(p49) -- name: clearChildren
		for _, v50 in p49:GetChildren() do
			if v50:IsA("UIListLayout") or v50:IsA("UIPadding") then
				continue
			end
			v50:Destroy()
		end
	end
	local function v_u_55() -- name: wantWide
		-- upvalues: (copy) v_u_16, (copy) v_u_15, (copy) p_u_9, (ref) v_u_1, (copy) p_u_8
		if v_u_16 then
			return false
		else
			local function v52()
				-- upvalues: (ref) v_u_15, (ref) p_u_9
				return v_u_15.designSize(p_u_9, false)
			end
			local v53, v54 = pcall(v52)
			if v53 and (typeof(v54) == "Vector2" and v54.X > 40) then
				return v54.X >= v_u_1.WIDE_MIN
			else
				return not p_u_8.compact
			end
		end
	end
	local function v_u_61(p56) -- name: paintStrip
		-- upvalues: (copy) v_u_51, (copy) v_u_42, (ref) v_u_29, (copy) v_u_13, (copy) v_u_12, (ref) v_u_23, (copy) v_u_10
		v_u_51(v_u_42)
		v_u_29 = nil
		local v57 = v_u_13.crateBanner(p56)
		local v58 = nil
		local v59 = v_u_12.accent
		if v57 == nil then
			if v_u_23 == "error" then
				v_u_29 = "prices"
				v58 = v_u_13.TEXT.pricesDown
				v59 = v_u_12.danger
			end
		else
			v_u_29 = v57.kind
			v58 = v57.text
			if v57.kind == "wait" then
				v59 = v_u_12.info
			elseif v57.kind == "restricted" then
				v59 = v_u_12.accent
			else
				v59 = v_u_12.danger
			end
		end
		if v58 ~= nil then
			local v60 = v_u_10.new("Frame", {
				["Name"] = "Strip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 1,
				["BackgroundColor3"] = v_u_12.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v_u_42)
			v_u_10.stroke(v60, v59)
			v_u_10.pad(v60, {
				12,
				10,
				6,
				6
			})
			v_u_10.layout(v60, "v", 0)
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v60,
				["text"] = v58,
				["color"] = v_u_12.text
			})
			v60:SetAttribute("Kind", v_u_29)
		end
	end
	local function v_u_71(p62, p63, p64, p65, p66, p67, p68, p69, p70) -- name: makeButton
		-- upvalues: (copy) v_u_15, (copy) v_u_11
		return v_u_15.button(p62, p63, p64, p67, {
			["name"] = p65,
			["size"] = p66,
			["height"] = v_u_11.touch(44),
			["disabled"] = p68,
			["onDisabledClick"] = p69,
			["maxTextWidth"] = p70 or 130
		})
	end
	local function v_u_135(p72) -- name: buildWide
		-- upvalues: (ref) v_u_1, (copy) v_u_10, (copy) v_u_43, (copy) v_u_15, (copy) v_u_11, (copy) v_u_12, (copy) v_u_27, (ref) v_u_23, (ref) v_u_22, (copy) p_u_8, (ref) v_u_32, (copy) v_u_71, (copy) v_u_28
		for _, v73 in p72 do
			local v74 = v73.tallyLine
			if type(v74) ~= "string" or v73.tallyLine == "" then
				continue
			end
			v75 = true
		end
		local v75 = false
		local v76 = v_u_1.CARD_H + (v75 and 30 or 0)
		local v77 = #p72 / 3
		local v78 = math.ceil(v77)
		local v79 = math.max(1, v78)
		local v80 = v_u_10.new("Frame", {
			["Name"] = "Wide",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v79 * v76 + (v79 - 1) * 12)
		}, v_u_43)
		local v81 = v_u_10.layout(v80, "h", 12)
		if v79 > 1 and (typeof(v81) == "Instance" and v81:IsA("UIListLayout")) then
			v81.Wraps = true
		end
		for v82, v_u_83 in p72 do
			local v84 = v_u_83.id
			local v85 = v_u_15.item(v84)
			local v_u_86 = v_u_11.rarityColor(not v85 and 1 or (v85.shown or v85.rarity))
			local v87 = v_u_10.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ClipsDescendants"] = true,
				["Name"] = "Card_" .. v_u_83.id,
				["BackgroundColor3"] = v_u_12.raised,
				["Size"] = UDim2.new(0.3333333333333333, v79 > 1 and -9 or -8, 0, v76),
				["LayoutOrder"] = v82
			}, v80)
			local v88 = v_u_10.stroke
			local v_u_89 = v_u_12.line
			local v90, v91 = pcall(function()
				-- upvalues: (copy) v_u_86, (copy) v_u_89
				return v_u_86:Lerp(v_u_89, 0.5)
			end)
			if not v90 then
				v91 = v_u_86
			end
			v88(v87, v91)
			v_u_10.new("Frame", {
				["Name"] = "Strip",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v_u_86,
				["Size"] = UDim2.new(1, 0, 0, 4)
			}, v87)
			local _, v92 = v_u_15.icon(v87, v_u_83.id, 96, {
				["position"] = UDim2.fromOffset(12, 16)
			})
			local v93 = v_u_27
			table.insert(v93, v92)
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 20,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v87,
				["text"] = v_u_83.itemName,
				["color"] = v_u_12.text,
				["position"] = UDim2.fromOffset(120, 14),
				["size"] = UDim2.new(1, -132, 0, 26)
			})
			v_u_10.label({
				["parent"] = nil,
				["name"] = "OpenLine",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "top",
				["fit"] = true,
				["track"] = false,
				["parent"] = v87,
				["text"] = v_u_83.openLine,
				["color"] = v_u_12.text2,
				["position"] = UDim2.fromOffset(120, 44),
				["size"] = UDim2.new(1, -132, 0, 44)
			})
			local v94, v95, v96
			if v_u_23 == "ok" or next(v_u_22) ~= nil then
				v94 = v_u_83.fromText
				v95 = v_u_83.listedText
				v96 = v_u_83.avgText
			elseif v_u_23 == "error" then
				v96 = ""
				v94 = "Prices not available"
				v95 = ""
			else
				v96 = ""
				v94 = "Loading prices"
				v95 = ""
			end
			v_u_10.label({
				["parent"] = nil,
				["name"] = "From",
				["text"] = nil,
				["style"] = "mono",
				["textSize"] = 16,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v87,
				["text"] = v94,
				["color"] = v_u_12.accent,
				["position"] = UDim2.fromOffset(120, 90),
				["size"] = UDim2.new(1, -132, 0, 22)
			})
			local v97 = v_u_10.label
			local v98 = {
				["parent"] = nil,
				["name"] = "Counts",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v87
			}
			local v99
			if v95 == "" then
				v99 = v_u_83.ownText
			else
				local v100 = string.lower
				local v101 = v_u_83.ownText
				local v102 = v100((string.sub(v101, 1, 1)))
				local v103 = v_u_83.ownText
				v99 = ("%s, %s"):format(v95, v102 .. string.sub(v103, 2))
			end
			v98.text = v99
			v98.color = v_u_12.text
			v98.position = UDim2.fromOffset(12, 122)
			v98.size = UDim2.new(1, -24, 0, 18)
			v97(v98)
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Average",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v87,
				["text"] = v96,
				["color"] = v_u_12.text2,
				["position"] = UDim2.fromOffset(12, 140),
				["size"] = UDim2.new(1, -24, 0, 18)
			})
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Chances",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "top",
				["fit"] = true,
				["track"] = false,
				["parent"] = v87,
				["text"] = v_u_83.chanceLine,
				["color"] = v_u_12.text2,
				["position"] = UDim2.fromOffset(12, 160),
				["size"] = UDim2.new(1, -24, 0, 36)
			})
			if v75 then
				local v104 = v_u_83.tallyLine
				if type(v104) == "string" and v_u_83.tallyLine ~= "" then
					v_u_10.label({
						["parent"] = nil,
						["name"] = "Tally",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "top",
						["fit"] = true,
						["track"] = false,
						["parent"] = v87,
						["text"] = v_u_83.tallyLine,
						["color"] = v_u_12.accent,
						["position"] = UDim2.fromOffset(12, 198),
						["size"] = UDim2.new(1, -24, 0, 28)
					})
				end
			end
			local v105
			if v_u_83.own > 0 and v_u_83.buttons.sell.enabled ~= true then
				v105 = v_u_83.buttons.sell.short
			else
				v105 = nil
			end
			if v105 ~= nil then
				v_u_10.label({
					["parent"] = nil,
					["name"] = "SellWhy",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v87,
					["text"] = v105,
					["color"] = v_u_12.accent,
					["position"] = UDim2.fromOffset(12, (v75 and 30 or 0) + 198),
					["size"] = UDim2.new(1, -24, 0, 16)
				})
			end
			local v106 = v_u_10.new("Frame", {
				["Name"] = "Buttons",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 12, 1, -12),
				["Size"] = UDim2.new(1, -24, 0, v_u_11.touch(44))
			}, v87)
			v_u_10.layout(v106, "h", 6)
			local v107 = {
				["id"] = v_u_83.id,
				["card"] = v_u_83,
				["act"] = {}
			}
			function v107.act.listings()
				-- upvalues: (copy) v_u_83, (ref) p_u_8
				local v108 = v_u_83.id
				if p_u_8.nav then
					local v109 = p_u_8.nav.openItem
					if type(v109) == "function" then
						p_u_8.nav.openItem(v108)
					end
				end
			end
			function v107.act.sell()
				-- upvalues: (copy) v_u_83, (ref) p_u_8, (ref) v_u_32, (ref) v_u_10
				if v_u_83.buttons.sell.enabled == true then
					local v110 = v_u_83.id
					if p_u_8.nav then
						local v111 = p_u_8.nav.sell
						if type(v111) == "function" then
							p_u_8.nav.sell(v110)
							return
						end
					end
				else
					local v112 = v_u_83.buttons.sell.reason or v_u_83.buttons.sell.short
					if v_u_32 ~= nil then
						local v113 = v_u_32.explain
						if type(v113) == "function" then
							v_u_32.explain(p_u_8, v112)
							return
						end
					end
					if type(v112) == "string" and v112 ~= "" then
						local v114 = v_u_10.toast
						pcall(v114, v112, "warn")
					end
				end
			end
			function v107.act.odds()
				-- upvalues: (copy) v_u_83, (ref) v_u_32, (ref) p_u_8, (ref) v_u_10
				local v115 = v_u_83.id
				if v_u_32 ~= nil then
					local v116 = v_u_32.odds
					if type(v116) == "function" then
						v_u_32.odds(p_u_8, v115)
						return
					end
				end
				if v_u_32 ~= nil then
					local v117 = v_u_32.explain
					if type(v117) == "function" then
						v_u_32.explain(p_u_8, "The chances of this item could not be shown.")
						return
					end
				end
				local v118 = v_u_10.toast
				pcall(v118, "The chances of this item could not be shown.", "warn")
			end
			local v119 = UDim2.new(0.3333333333333333, -4, 0, v_u_11.touch(44))
			v107.listings = v_u_71(v106, "LISTINGS", "primary", "Listings", v119, function()
				-- upvalues: (copy) v_u_83, (ref) p_u_8
				local v120 = v_u_83.id
				if p_u_8.nav then
					local v121 = p_u_8.nav.openItem
					if type(v121) == "function" then
						p_u_8.nav.openItem(v120)
					end
				end
			end)
			local v_u_122 = v_u_83.buttons.sell
			local v128, v129 = v_u_71(v106, "SELL", "secondary", "Sell", v119, function()
				-- upvalues: (copy) v_u_83, (ref) p_u_8
				local v123 = v_u_83.id
				if p_u_8.nav then
					local v124 = p_u_8.nav.sell
					if type(v124) == "function" then
						p_u_8.nav.sell(v123)
					end
				end
			end, v_u_122.enabled ~= true, function()
				-- upvalues: (copy) v_u_122, (ref) v_u_32, (ref) p_u_8, (ref) v_u_10
				local v125 = v_u_122.reason or v_u_122.short
				if v_u_32 ~= nil then
					local v126 = v_u_32.explain
					if type(v126) == "function" then
						v_u_32.explain(p_u_8, v125)
						return
					end
				end
				if type(v125) == "string" and v125 ~= "" then
					local v127 = v_u_10.toast
					pcall(v127, v125, "warn")
				end
			end)
			v107.sell = v128
			v107.sellApi = v129
			v107.odds = v_u_71(v106, "ODDS", "secondary", "Odds", v119, function()
				-- upvalues: (copy) v_u_83, (ref) v_u_32, (ref) p_u_8, (ref) v_u_10
				local v130 = v_u_83.id
				if v_u_32 ~= nil then
					local v131 = v_u_32.odds
					if type(v131) == "function" then
						v_u_32.odds(p_u_8, v130)
						return
					end
				end
				if v_u_32 ~= nil then
					local v132 = v_u_32.explain
					if type(v132) == "function" then
						v_u_32.explain(p_u_8, "The chances of this item could not be shown.")
						return
					end
				end
				local v133 = v_u_10.toast
				pcall(v133, "The chances of this item could not be shown.", "warn")
			end)
			v107.frame = v87
			local v134 = v_u_28
			table.insert(v134, v107)
		end
	end
	local function v_u_181(p136) -- name: buildRows
		-- upvalues: (ref) v_u_1, (copy) v_u_10, (copy) v_u_43, (copy) v_u_15, (copy) v_u_11, (copy) v_u_12, (copy) p_u_8, (copy) v_u_27, (ref) v_u_23, (ref) v_u_22, (ref) v_u_32, (copy) v_u_71, (copy) v_u_28
		for _, v137 in p136 do
			local v138 = v137.tallyLine
			if type(v138) ~= "string" or v137.tallyLine == "" then
				continue
			end
			v139 = true
		end
		local v139 = false
		local v140 = v_u_1.ROW_H + (v139 and 30 or 0)
		local v141 = v_u_10.new("Frame", {
			["Name"] = "Rows",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_43)
		v_u_10.layout(v141, "v", 8)
		for v142, v_u_143 in p136 do
			local v144 = v_u_143.id
			local v145 = v_u_15.item(v144)
			local v_u_146 = v_u_11.rarityColor(not v145 and 1 or (v145.shown or v145.rarity))
			local v_u_147 = v_u_10.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ClipsDescendants"] = true,
				["Name"] = "Row_" .. v_u_143.id,
				["BackgroundColor3"] = v_u_12.raised,
				["Size"] = UDim2.new(1, 0, 0, v140),
				["LayoutOrder"] = v142
			}, v141)
			local v148 = v_u_10.stroke
			local v_u_149 = v_u_12.line
			local v150, v151 = pcall(function()
				-- upvalues: (copy) v_u_146, (copy) v_u_149
				return v_u_146:Lerp(v_u_149, 0.5)
			end)
			if not v150 then
				v151 = v_u_146
			end
			v148(v_u_147, v151)
			v_u_10.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v_u_146,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v_u_147)
			local v_u_152 = v_u_10.new("TextButton", {
				["Name"] = "Hit",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Selectable"] = true,
				["ZIndex"] = 1,
				["Size"] = UDim2.fromScale(1, 1)
			}, v_u_147)
			local function v153()
				-- upvalues: (copy) v_u_152, (ref) v_u_10
				v_u_152.SelectionImageObject = v_u_10.selectionImage()
			end
			pcall(v153)
			v_u_152.Activated:Connect(function()
				-- upvalues: (ref) v_u_10, (ref) v_u_11, (copy) v_u_143, (ref) p_u_8
				v_u_10.sound(v_u_11.sounds.click)
				local v154 = v_u_143.id
				if p_u_8.nav then
					local v155 = p_u_8.nav.openItem
					if type(v155) == "function" then
						p_u_8.nav.openItem(v154)
					end
				end
			end)
			local _, v156 = v_u_15.icon(v_u_147, v_u_143.id, 72, {
				["position"] = UDim2.fromOffset(10, 10)
			})
			local v157 = v_u_27
			table.insert(v157, v156)
			local v158, v159
			if v_u_23 == "ok" or next(v_u_22) ~= nil then
				v158 = v_u_143.fromText
				v159 = v_u_143.listedText
				local _ = v_u_143.avgText
			elseif v_u_23 == "error" then
				v158 = "Prices not available"
				v159 = ""
			else
				v158 = "Loading prices"
				v159 = ""
			end
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 17,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v_u_147,
				["text"] = v_u_143.itemName,
				["color"] = v_u_12.text,
				["position"] = UDim2.fromOffset(92, 8),
				["size"] = UDim2.new(1, -364, 0, 22)
			})
			v_u_10.label({
				["parent"] = nil,
				["name"] = "From",
				["text"] = nil,
				["style"] = "mono",
				["textSize"] = 14,
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v_u_147,
				["text"] = v158,
				["color"] = v_u_12.accent,
				["anchor"] = Vector2.new(1, 0),
				["position"] = UDim2.new(1, -122, 0, 8),
				["size"] = UDim2.fromOffset(150, 22)
			})
			local v160 = v_u_10.label
			local v161 = {
				["parent"] = nil,
				["name"] = "Counts",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v_u_147
			}
			local v162
			if v159 == "" then
				v162 = v_u_143.ownText
			else
				local v163 = string.lower
				local v164 = v_u_143.ownText
				local v165 = v163((string.sub(v164, 1, 1)))
				local v166 = v_u_143.ownText
				v162 = ("%s, %s"):format(v159, v165 .. string.sub(v166, 2))
			end
			v161.text = v162
			v161.color = v_u_12.text
			v161.position = UDim2.fromOffset(92, 32)
			v161.size = UDim2.new(1, -214, 0, 18)
			v160(v161)
			v_u_10.label({
				["parent"] = nil,
				["name"] = "Chances",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "top",
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v_u_147,
				["text"] = v_u_143.chanceLine,
				["color"] = v_u_12.text2,
				["position"] = UDim2.fromOffset(92, 52),
				["size"] = UDim2.new(1, -214, 0, 34)
			})
			if v139 then
				local v167 = v_u_143.tallyLine
				if type(v167) == "string" and v_u_143.tallyLine ~= "" then
					v_u_10.label({
						["parent"] = nil,
						["name"] = "Tally",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "top",
						["fit"] = true,
						["track"] = false,
						["zindex"] = 3,
						["parent"] = v_u_147,
						["text"] = v_u_143.tallyLine,
						["color"] = v_u_12.accent,
						["position"] = UDim2.fromOffset(92, 88),
						["size"] = UDim2.new(1, -214, 0, 28)
					})
				end
			end
			local v168 = {
				["id"] = v_u_143.id,
				["card"] = v_u_143,
				["hit"] = v_u_152,
				["frame"] = v_u_147,
				["act"] = {}
			}
			function v168.act.listings()
				-- upvalues: (copy) v_u_143, (ref) p_u_8
				local v169 = v_u_143.id
				if p_u_8.nav then
					local v170 = p_u_8.nav.openItem
					if type(v170) == "function" then
						p_u_8.nav.openItem(v169)
					end
				end
			end
			function v168.act.odds()
				-- upvalues: (copy) v_u_143, (ref) v_u_32, (ref) p_u_8, (ref) v_u_10
				local v171 = v_u_143.id
				if v_u_32 ~= nil then
					local v172 = v_u_32.odds
					if type(v172) == "function" then
						v_u_32.odds(p_u_8, v171)
						return
					end
				end
				if v_u_32 ~= nil then
					local v173 = v_u_32.explain
					if type(v173) == "function" then
						v_u_32.explain(p_u_8, "The chances of this item could not be shown.")
						return
					end
				end
				local v174 = v_u_10.toast
				pcall(v174, "The chances of this item could not be shown.", "warn")
			end
			v168.odds = v_u_71(v_u_147, "ODDS", "secondary", "Odds", UDim2.fromOffset(104, v_u_11.touch(44)), function()
				-- upvalues: (copy) v_u_143, (ref) v_u_32, (ref) p_u_8, (ref) v_u_10
				local v175 = v_u_143.id
				if v_u_32 ~= nil then
					local v176 = v_u_32.odds
					if type(v176) == "function" then
						v_u_32.odds(p_u_8, v175)
						return
					end
				end
				if v_u_32 ~= nil then
					local v177 = v_u_32.explain
					if type(v177) == "function" then
						v_u_32.explain(p_u_8, "The chances of this item could not be shown.")
						return
					end
				end
				local v178 = v_u_10.toast
				pcall(v178, "The chances of this item could not be shown.", "warn")
			end, false, nil, 84)
			v168.odds.AnchorPoint = Vector2.new(1, 0)
			v168.odds.Position = UDim2.new(1, -8, 0, 8)
			v168.odds.ZIndex = 4
			local function v179()
				-- upvalues: (ref) v_u_10, (copy) v_u_147, (ref) v_u_12
				v_u_10.icon("chevronRight", {
					["parent"] = nil,
					["size"] = 14,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["zindex"] = 3,
					["parent"] = v_u_147,
					["color"] = v_u_12.text2,
					["position"] = UDim2.new(1, -22, 1, -18),
					["anchor"] = Vector2.new(0.5, 0.5)
				})
			end
			pcall(v179)
			local v180 = v_u_28
			table.insert(v180, v168)
		end
	end
	local function v_u_194(p182) -- name: sigOf
		local v183
		if type(p182) == "table" then
			local v184 = p182.crate
			v183 = type(v184) ~= "table" and {} or p182.crate
		else
			v183 = {}
		end
		local v185 = v183.tab
		local v186 = tostring(v185)
		local v187 = v183.why
		local v188 = tostring(v187)
		local v189 = v183.sell
		local v190 = tostring(v189)
		local v191 = v183.buy
		local v192 = tostring(v191)
		local v193 = v183.order
		return ("%s/%s/%s/%s/%s"):format(v186, v188, v190, v192, (tostring(v193)))
	end
	local function v_u_200() -- name: stashCount
		-- upvalues: (copy) v_u_14, (copy) v_u_21, (copy) v_u_13
		local v195 = 0
		local function v196()
			-- upvalues: (ref) v_u_14
			return v_u_14:stash()
		end
		local v197, v198 = pcall(v196)
		if v197 and type(v198) == "table" then
			for _, v199 in v_u_21 do
				v195 = v195 + (v_u_13.crateOwned(v198, v199) * 7 + 1)
			end
		end
		return v195
	end
	function v_u_17.build() -- name: build
		-- upvalues: (ref) v_u_18, (copy) v_u_27, (copy) v_u_28, (copy) v_u_51, (copy) v_u_43, (copy) p_u_8, (copy) v_u_61, (ref) v_u_30, (copy) v_u_194, (ref) v_u_31, (copy) v_u_200, (copy) v_u_14, (copy) v_u_13, (copy) v_u_21, (ref) v_u_22, (ref) v_u_26, (copy) v_u_55, (copy) v_u_135, (copy) v_u_181, (copy) p_u_9, (ref) v_u_29, (ref) v_u_23
		if v_u_18 then
			for _, v201 in v_u_27 do
				pcall(v201)
			end
			table.clear(v_u_27)
			table.clear(v_u_28)
			v_u_51(v_u_43)
			local v202 = p_u_8.state
			v_u_61(v202)
			v_u_30 = v_u_194(v202)
			v_u_31 = v_u_200()
			local v_u_203 = {}
			local function v204()
				-- upvalues: (ref) v_u_203, (ref) v_u_14
				v_u_203 = v_u_14:stash()
			end
			pcall(v204)
			local v205 = v_u_13.crateCards(v202, v_u_21, v_u_22, v_u_203, {
				["rules"] = p_u_8.rules
			})
			v_u_26 = v_u_55() and "wide" or "rows"
			if v_u_26 == "wide" then
				v_u_135(v205)
			else
				v_u_181(v205)
			end
			p_u_9:SetAttribute("Mode", v_u_26)
			p_u_9:SetAttribute("Cards", #v205)
			p_u_9:SetAttribute("Strip", v_u_29 or "")
			p_u_9:SetAttribute("Status", v_u_23)
		end
	end
	function v_u_17.load(p206) -- name: load
		-- upvalues: (ref) v_u_24, (ref) v_u_18, (copy) v_u_14, (ref) v_u_25, (ref) v_u_1, (copy) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_17
		if v_u_24 or not v_u_18 then
			return
		else
			local v_u_207 = v_u_14:clock()
			if p206 == true or v_u_207 - v_u_25 >= v_u_1.REFRESH then
				v_u_24 = true
				v_u_25 = v_u_207
				task.spawn(function()
					-- upvalues: (ref) v_u_14, (ref) v_u_21, (ref) v_u_24, (ref) v_u_18, (ref) v_u_22, (ref) v_u_23, (ref) v_u_25, (copy) v_u_207, (ref) v_u_1, (ref) v_u_17
					local v208 = v_u_14:prices(v_u_21)
					v_u_24 = false
					if not v_u_18 then
						return
					end
					if type(v208) == "table" and v208.ok then
						local v209 = v208.prices
						if type(v209) == "table" then
							v_u_22 = v208.prices
							v_u_23 = "ok"
							v_u_17.build()
						else
							if type(v208) == "table" and (v208.code == "RATE" or v208.code == "MUTED") then
								v_u_25 = v_u_207 - v_u_1.REFRESH + 3
							elseif next(v_u_22) == nil then
								v_u_23 = "error"
							end
							v_u_17.build()
						end
					else
						if type(v208) == "table" and (v208.code == "RATE" or v208.code == "MUTED") then
							v_u_25 = v_u_207 - v_u_1.REFRESH + 3
						elseif next(v_u_22) == nil then
							v_u_23 = "error"
						end
						v_u_17.build()
						return
					end
				end)
			end
		end
	end
	function v_u_17.show() -- name: show
		-- upvalues: (ref) v_u_19, (copy) v_u_17
		v_u_19 = true
		v_u_17.build()
		v_u_17.load(true)
	end
	function v_u_17.hide() -- name: hide
		-- upvalues: (ref) v_u_19
		v_u_19 = false
	end
	function v_u_17.refresh(_) -- name: refresh
		-- upvalues: (ref) v_u_19, (copy) v_u_17
		if v_u_19 then
			v_u_17.build()
		end
	end
	function v_u_17.reload() -- name: reload
		-- upvalues: (ref) v_u_25, (ref) v_u_22, (ref) v_u_23, (copy) v_u_17, (ref) v_u_19
		v_u_25 = (-1 / 0)
		v_u_22 = {}
		v_u_23 = "loading"
		v_u_17.build()
		if v_u_19 then
			v_u_17.load(true)
		end
	end
	function v_u_17.onNote(_) -- name: onNote
		-- upvalues: (ref) v_u_19, (copy) v_u_17
		if v_u_19 then
			v_u_17.load(true)
		end
	end
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (ref) v_u_18, (ref) v_u_19, (copy) v_u_27, (copy) v_u_20
		v_u_18 = false
		v_u_19 = false
		for _, v210 in v_u_27 do
			pcall(v210)
		end
		table.clear(v_u_27)
		for _, v_u_211 in v_u_20 do
			pcall(function()
				-- upvalues: (copy) v_u_211
				v_u_211:Disconnect()
			end)
		end
		table.clear(v_u_20)
	end
	local v213 = {
		["Disconnect"] = p_u_8.onState(function(p212)
			-- upvalues: (ref) v_u_18, (copy) v_u_194, (ref) v_u_30, (copy) v_u_17
			if v_u_18 and v_u_194(p212) ~= v_u_30 then
				v_u_17.build()
			end
		end)
	}
	table.insert(v_u_20, v213)
	local v_u_214 = 0
	local v215 = {
		["Disconnect"] = p_u_8.onTick(function()
			-- upvalues: (ref) v_u_19, (ref) v_u_18, (ref) v_u_214, (copy) v_u_200, (ref) v_u_31, (copy) v_u_17, (ref) v_u_1
			if v_u_19 and v_u_18 then
				v_u_214 = v_u_214 + 1
				if v_u_200() ~= v_u_31 then
					v_u_17.build()
				end
				if v_u_214 % v_u_1.REFRESH == 0 then
					v_u_17.load(false)
				end
			end
		end)
	}
	table.insert(v_u_20, v215)
	pcall(function()
		-- upvalues: (copy) v_u_20, (copy) p_u_9, (ref) v_u_18, (ref) v_u_19, (copy) v_u_55, (ref) v_u_26, (copy) v_u_17
		local v216 = v_u_20
		local v217 = p_u_9:GetPropertyChangedSignal("AbsoluteSize")
		local function v218()
			-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_55, (ref) v_u_26, (ref) v_u_17
			if v_u_18 and v_u_19 and (v_u_55() and "wide" or "rows") ~= v_u_26 then
				task.defer(v_u_17.build)
			end
		end
		table.insert(v216, v217:Connect(v218))
	end)
	function v_u_17.state() -- name: state
		-- upvalues: (ref) v_u_26, (copy) v_u_28, (ref) v_u_23, (ref) v_u_29, (copy) v_u_21, (ref) v_u_25, (ref) v_u_30, (copy) v_u_40
		return {
			["mode"] = v_u_26,
			["cards"] = #v_u_28,
			["status"] = v_u_23,
			["strip"] = v_u_29,
			["ids"] = v_u_21,
			["lastRead"] = v_u_25,
			["sig"] = v_u_30,
			["open"] = v_u_40.Text
		}
	end
	function v_u_17.strip() -- name: strip
		-- upvalues: (ref) v_u_29
		return v_u_29
	end
	function v_u_17.cards() -- name: cards
		-- upvalues: (copy) v_u_28
		local v219 = {}
		for _, v220 in v_u_28 do
			local v221 = {
				["id"] = v220.id,
				["card"] = v220.card,
				["listings"] = v220.listings,
				["sell"] = v220.sell,
				["odds"] = v220.odds,
				["hit"] = v220.hit,
				["frame"] = v220.frame,
				["sellEnabled"] = v220.card.buttons.sell.enabled
			}
			table.insert(v219, v221)
		end
		return v219
	end
	function v_u_17.press(p222, p223) -- name: press
		-- upvalues: (copy) v_u_28
		for _, v224 in v_u_28 do
			if v224.id ~= p222 then
				continue
			end
			local v225 = v224.act[p223]
			if type(v225) ~= "function" then
				continue
			end
			v224.act[p223]()
			return true
		end
		return false
	end
	v_u_17.frame = p_u_9
	task.defer(function()
		-- upvalues: (ref) v_u_18, (copy) v_u_17
		if v_u_18 then
			v_u_17.build()
		end
	end)
	return v_u_17
end
return v_u_1