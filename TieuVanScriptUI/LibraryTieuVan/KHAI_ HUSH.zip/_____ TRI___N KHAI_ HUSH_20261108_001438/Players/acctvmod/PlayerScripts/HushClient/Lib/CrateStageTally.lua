-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / CrateStageTally

local v_u_13 = {
	["TEXT"] = {
		["tallied"] = "  TALLIED",
		["word"] = "TALLY"
	},
	["LEAD"] = 0.35,
	["LEAD_QUICK"] = 0.2,
	["DRAW"] = 0.5,
	["DRAW_QUICK"] = 0.3,
	["STREAK"] = 0.35,
	["INSTANCES"] = 9,
	["lineSuffix"] = function(p1) -- name: lineSuffix
		-- upvalues: (copy) v_u_13
		return (type(p1) ~= "table" or p1.tally ~= true) and "" or v_u_13.TEXT.tallied
	end,
	["state"] = function(p2, p3, p4, p5) -- name: state
		-- upvalues: (copy) v_u_13
		if p5 == true then
			return {
				["progress"] = 1,
				["streak"] = nil,
				["shown"] = true
			}
		end
		local v6
		if p3 then
			v6 = v_u_13.LEAD_QUICK
		else
			v6 = v_u_13.LEAD
		end
		local v7
		if p3 then
			v7 = v_u_13.DRAW_QUICK
		else
			v7 = v_u_13.DRAW
		end
		if p4 == true then
			return {
				["progress"] = nil,
				["streak"] = nil,
				["shown"] = nil,
				["progress"] = v6 + v7 <= p2 and 1 or 0,
				["shown"] = v6 + v7 <= p2
			}
		end
		local v8 = p2 - v6
		if v8 < 0 then
			return {
				["progress"] = 0,
				["streak"] = nil,
				["shown"] = false
			}
		end
		local v9 = v8 / v7
		local v10 = v9 < 0 and 0 or (v9 > 1 and 1 or v9)
		local v11 = v8 - v7
		local v12
		if v11 >= 0 and v11 < v_u_13.STREAK then
			v12 = v11 / v_u_13.STREAK
		else
			v12 = nil
		end
		return {
			["progress"] = nil,
			["streak"] = nil,
			["shown"] = true,
			["progress"] = v10,
			["streak"] = v12
		}
	end
}
local function v_u_24(p_u_14) -- name: makeParts
	-- upvalues: (copy) v_u_13
	local v_u_15 = p_u_14.D
	if v_u_15 then
		v_u_15 = p_u_14.D.TallyMark
	end
	if v_u_15 == nil then
		local v16
		v16, v_u_15 = pcall(function()
			-- upvalues: (copy) p_u_14
			return p_u_14.opts.cctx.lib.TallyMark
		end)
		if not v16 then
			v_u_15 = nil
		end
	end
	if v_u_15 == nil then
		pcall(function()
			-- upvalues: (ref) v_u_15
			v_u_15 = require(script.Parent:WaitForChild("TallyMark", 5))
		end)
	end
	if v_u_15 == nil then
		return nil
	end
	local v17 = p_u_14.Theme
	local v18 = p_u_14.phone and 26 or 52
	local v19 = v_u_15.new(p_u_14.root, {
		["size"] = nil,
		["level"] = 0,
		["name"] = "TallyMark",
		["size"] = v18
	})
	v19.frame.ZIndex = 24
	v19.frame.AnchorPoint = Vector2.new(0, 0.5)
	v19.frame.ClipsDescendants = true
	for _, v20 in v19.strokes do
		v20.ZIndex = 25
	end
	local v21 = Instance.new("Frame")
	v21.Name = "Streak"
	v21.BackgroundColor3 = Color3.new(1, 1, 1)
	v21.BorderSizePixel = 0
	v21.AnchorPoint = Vector2.new(0.5, 0.5)
	v21.Size = UDim2.new(0.45, 0, 1.4, 0)
	v21.Position = UDim2.fromScale(-0.3, 0.5)
	v21.Rotation = 18
	v21.ZIndex = 26
	v21.Visible = false
	local v22 = Instance.new("UIGradient")
	v22.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.25), NumberSequenceKeypoint.new(1, 1) })
	v22.Parent = v21
	v21.Parent = v19.frame
	local v23 = Instance.new("TextLabel")
	v23.Name = "TallyWord"
	v23.BackgroundTransparency = 1
	v23.AnchorPoint = Vector2.new(0, 0.5)
	v23.Size = UDim2.fromOffset(p_u_14.phone and 80 or 150, p_u_14.phone and 16 or 22)
	v23.FontFace = Font.fromName("Oswald", Enum.FontWeight.Bold)
	v23.TextSize = p_u_14.phone and 14 or 20
	v23.TextXAlignment = Enum.TextXAlignment.Left
	v23.TextColor3 = v_u_15.colorOf(0, v17)
	v23.TextStrokeTransparency = 0.55
	v23.Text = v_u_13.TEXT.word
	v23.ZIndex = 24
	v23.Visible = false
	v23.Parent = p_u_14.root
	return {
		["mark"] = v19,
		["streak"] = v21,
		["word"] = v23
	}
end
function v_u_13.play(p25, p26, p27, p28, p29) -- name: play
	-- upvalues: (copy) v_u_13, (copy) v_u_24
	if p25 == nil or p25.root == nil then
		return
	else
		local v30 = type(p29) ~= "table" and {} or p29
		local v31
		if type(p26) == "table" then
			v31 = p26.result
		else
			v31 = nil
		end
		if type(v31) == "table" and v31.tally == true then
			local v32 = v_u_13.state(p27 - p28, v30.quick, v30.reduced, v30.skipped)
			if v32.shown then
				local v33 = p25._tally
				if v33 == nil then
					v33 = v_u_24(p25)
					if v33 == nil then
						return
					end
					p25._tally = v33
				end
				local v34 = v33.mark
				local v35 = v33.streak
				local v36 = v33.word
				local v37 = p25.stampFrame
				local v38 = v37.AbsoluteSize
				local v39 = (v37.Size.X.Offset <= 0 or v38.X <= 0) and 1 or v38.X / v37.Size.X.Offset
				local v40 = p25.stampWord.TextBounds.X / v39
				local v41 = v37.Position.X.Offset + 22 + v40 + (p25.phone and 12 or 20)
				local v42 = -0.14 * v37.Size.Y.Offset
				local v43 = v34.frame
				local v44 = UDim2.new
				local v45 = math.floor(v41)
				local v46 = v42 - (p25.phone and 6 or 10)
				v43.Position = v44(0, v45, 0.36, (math.floor(v46)))
				local v47 = UDim2.new
				local v48 = v41 + v34.size + 8
				local v49 = math.floor(v48)
				local v50 = v42 - (p25.phone and 6 or 10)
				v36.Position = v47(0, v49, 0.36, (math.floor(v50)))
				v34:setProgress(v32.progress)
				v34.frame.Visible = true
				v36.Visible = v32.progress >= 1
				v36.TextTransparency = 0
				if v32.streak == nil then
					if v35.Visible then
						v35.Visible = false
					end
				else
					v35.Visible = true
					v35.Position = UDim2.fromScale(-0.3 + 1.6 * v32.streak, 0.5)
				end
			else
				v_u_13.hide(p25)
				return
			end
		else
			v_u_13.hide(p25)
			return
		end
	end
end
function v_u_13.hide(p51) -- name: hide
	local v52
	if p51 then
		v52 = p51._tally
	else
		v52 = nil
	end
	if v52 ~= nil then
		if v52.mark.frame.Visible then
			v52.mark.frame.Visible = false
		end
		if v52.word.Visible then
			v52.word.Visible = false
		end
		if v52.streak.Visible then
			v52.streak.Visible = false
		end
	end
end
function v_u_13.count(p53) -- name: count
	-- upvalues: (copy) v_u_13
	local v54
	if p53 then
		v54 = p53._tally
	else
		v54 = nil
	end
	return v54 == nil and 0 or v_u_13.INSTANCES
end
return v_u_13