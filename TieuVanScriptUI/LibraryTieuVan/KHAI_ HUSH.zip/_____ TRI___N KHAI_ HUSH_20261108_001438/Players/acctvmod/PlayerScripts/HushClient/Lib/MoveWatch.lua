-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MoveWatch

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {
	["STICK_MIN"] = 0.5,
	["SPEED_MAX"] = 0.5,
	["STUCK_AFTER"] = 1.5,
	["LONG_STUCK"] = 8,
	["ANCHOR_AFTER"] = 4,
	["LOOK_GAP"] = 5,
	["LOG_GAP"] = 20,
	["LOG_MAX"] = 6,
	["SEND_GAP"] = 60,
	["SEND_MAX"] = 4,
	["REMOTE"] = "mv.stuck",
	["LINE_MAX"] = 380,
	["ARRIVE_MAX"] = 80,
	["HEALS"] = {
		["panel_inv"] = "panels",
		["panel_map"] = "panels",
		["panel_set"] = "panels",
		["anchored"] = "anchor",
		["nan"] = "nan",
		["touch_ghost"] = "touch"
	}
}
local v_u_6 = {
	["Physics"] = true,
	["PlatformStanding"] = true,
	["Seated"] = true,
	["Dead"] = true,
	["Ragdoll"] = true,
	["FallingDown"] = true,
	["GettingUp"] = true
}
local v_u_7 = {
	{ "inv", "panel_inv" },
	{ "map", "panel_map" },
	{ "set", "panel_set" }
}
local v_u_8 = {
	["stuck"] = 0,
	["lookAt"] = -1000000000,
	["logAt"] = -1000000000,
	["sendAt"] = -1000000000,
	["logs"] = 0,
	["sends"] = 0,
	["looks"] = 0,
	["explained"] = 0,
	["reports"] = 0,
	["heals"] = 0,
	["errors"] = 0,
	["faults"] = 0,
	["faultTags"] = nil,
	["off"] = false,
	["fps"] = 60,
	["last"] = "",
	["lastKnown"] = "",
	["started"] = false,
	["raidSince"] = nil,
	["hum"] = nil,
	["mdPre"] = 1,
	["mdPreAt"] = -1000000000,
	["seenRe"] = 0,
	["seenPan"] = 0,
	["seenTouch"] = 0,
	["fixReports"] = 0,
	["faultTags"] = {}
}
function v_u_5.advance(p9, p10, p11, p12) -- name: advance
	-- upvalues: (copy) v_u_5
	if v_u_5.STICK_MIN < p11 and p12 < v_u_5.SPEED_MAX then
		return p9 + p10
	end
	local v13 = p9 - p10 * 2
	return math.max(0, v13)
end
function v_u_5.classify(p14, p15) -- name: classify
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_6
	local v16 = {}
	local v17 = {}
	local v18 = v_u_5.LONG_STUCK <= p15
	if p14.dead then
		table.insert(v16, "dead")
	end
	if p14.ready == false then
		local v19
		if p14.arriveLate then
			v19 = v17
		else
			v19 = v16
		end
		local v20 = p14.arriveLate and "not_ready" or "arriving"
		table.insert(v19, v20)
	end
	local v21 = p14.action
	if v21 == "Revive" or (v21 == "Climb" or (v21 == "Vault" or (v21 == "Unlock" or v21 == "Prying"))) then
		local v22 = "act_" .. string.lower(v21)
		table.insert(v16, v22)
	elseif v21 == "VehEnter" or (v21 == "VehExit" or (v21 == "VehExitFast" or (v21 == "VehAbort" or v21 == "Eject"))) then
		local v23 = "act_" .. string.lower(v21)
		table.insert(v16, v23)
	end
	if p14.ride then
		table.insert(v16, "riding")
	end
	local v24 = p14.predAction
	if type(v24) == "string" and p14.predAction ~= "" then
		table.insert(v16, "pred_action")
	end
	if p14.held then
		table.insert(v16, "held")
	end
	local v25 = false
	for _, v26 in v_u_7 do
		if not (p14.open and p14.open[v26[1]]) then
			continue
		end
		if p14.proof and p14.proof[v26[1]] then
			v25 = true
		else
			local v27 = v26[2]
			table.insert(v17, v27)
		end
	end
	if v25 then
		table.insert(v16, "panel_open")
	end
	if p14.wall then
		local v28
		if v18 then
			v28 = v17
		else
			v28 = v16
		end
		table.insert(v28, v18 and "wall_long" or "wall")
	end
	if p14.zbody then
		local v29
		if v18 then
			v29 = v17
		else
			v29 = v16
		end
		table.insert(v29, v18 and "zbody_long" or "zbody")
	end
	if p14.anchored and not p14.held then
		if v_u_5.ANCHOR_AFTER <= p15 then
			table.insert(v17, "anchored")
		else
			table.insert(v16, "anchor_short")
		end
	end
	if p14.nan then
		table.insert(v17, "nan")
	end
	if p14.ghost then
		table.insert(v17, "touch_ghost")
	end
	if p14.mdZero and (p14.mvStrong and not p14.blocked) then
		table.insert(v17, "ctrl_over")
	end
	if p14.owner == "server" or p14.owner == "other" then
		table.insert(v17, "owner")
	end
	local v30
	if p14.plat or p14.sit then
		table.insert(v17, "state")
		if not p14.dead then
			v30 = p14.ws
			if type(v30) == "number" and p14.ws < 1 then
				table.insert(v17, "ws_low")
			end
		end
		v33 = p14.snare
		if type(v33) == "number" and p14.snare < 0.3 then
			table.insert(v17, "snare")
		end
		if #v16 == 0 and #v17 == 0 then
			table.insert(v17, "unknown")
		end
		return v16, v17
	end
	local v31 = v_u_6
	local v32 = p14.state
	if not v31[tostring(v32)] then
		if not p14.dead then
			v30 = p14.ws
			if type(v30) == "number" and p14.ws < 1 then
				table.insert(v17, "ws_low")
			end
		end
		v33 = p14.snare
		if type(v33) == "number" and p14.snare < 0.3 then
			table.insert(v17, "snare")
		end
		if #v16 == 0 and #v17 == 0 then
			table.insert(v17, "unknown")
		end
		return v16, v17
	end
	table.insert(v17, "state")
	if not p14.dead then
		v30 = p14.ws
		if type(v30) == "number" and p14.ws < 1 then
			table.insert(v17, "ws_low")
		end
	end
	local v33 = p14.snare
	if type(v33) == "number" and p14.snare < 0.3 then
		table.insert(v17, "snare")
	end
	if #v16 == 0 and #v17 == 0 then
		table.insert(v17, "unknown")
	end
	return v16, v17
end
function v_u_5.line(p34, p35, p36, p37, p38) -- name: line
	local v39 = p34.open or {}
	local v40 = p34.proof or {}
	local v41 = {}
	local v42 = (type(p37) ~= "number" or p37 ~= p37) and "nan" or string.format("%." .. tostring(1) .. "f", (math.abs(p37)))
	local v43 = p34.stick
	local v44 = (type(v43) ~= "number" or v43 ~= v43) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v43)))
	local v45 = p34.speed
	local v46 = ("[MoveWatch] stuck=%ss stick=%s speed=%s suspects=%s known=%s healed=%s"):format(v42, v44, (type(v45) ~= "number" or v45 ~= v45) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v45))), table.concat(p36, "+"), #p35 <= 0 and "none" or table.concat(p35, "+"), #p38 <= 0 and "none" or table.concat(p38, "+"))
	local v47 = p34.device
	local v48 = tostring(v47)
	local v49 = p34.place
	local v50 = tostring(v49)
	local v51 = p34.status
	local v52 = tostring(v51)
	local v53 = p34.ready and "1" or "0"
	local v54 = p34.enabled and "1" or "0"
	local v55 = p34.blocked and "1" or "0"
	local v56 = p34.live and "1" or "0"
	local v57 = p34.modal and "1" or "0"
	local v58 = p34.lock
	local v59 = tostring(v58)
	local v60 = p34.cerr
	local v61 = ("dev=%s place=%s status=%s ready=%s enabled=%s blocked=%s live=%s modal=%s lock=%s cerr=%s"):format(v48, v50, v52, v53, v54, v55, v56, v57, v59, (tostring(v60)))
	local v62 = ("panels=inv%s%s,map%s%s,set%s%s"):format(v39.inv and "1" or "0", v40.inv and "1" or "0", v39.map and "1" or "0", v40.map and "1" or "0", v39.set and "1" or "0", v40.set and "1" or "0")
	local v63 = p34.dead and "1" or "0"
	local v64 = p34.downed and "1" or "0"
	local v65 = p34.action
	local v66 = tostring(v65)
	local v67 = p34.predAction
	local v68 = ("dead=%s down=%s act=%s pred=%s held=%s anch=%s"):format(v63, v64, v66, tostring(v67), p34.held and "1" or "0", p34.anchored and "1" or "0")
	local v69 = "ws=%s state=%s floor=%s plat=%s sit=%s hp=%s md=%s/%s mv=%s raw=%s nan=%s owner=%s"
	local v70 = p34.ws
	local v71 = (type(v70) ~= "number" or v70 ~= v70) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v70)))
	local v72 = p34.state
	local v73 = tostring(v72)
	local v74 = p34.floor
	local v75 = tostring(v74)
	local v76 = p34.plat and "1" or "0"
	local v77 = p34.sit and "1" or "0"
	local v78 = p34.hp
	local v79 = (type(v78) ~= "number" or v78 ~= v78) and "nan" or string.format("%." .. tostring(0) .. "f", (math.abs(v78)))
	local v80 = p34.md
	local v81 = (type(v80) ~= "number" or v80 ~= v80) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v80)))
	local v82
	if p34.mdPre == nil or p34.mdPre < 0 then
		v82 = "none"
	else
		local v83 = p34.mdPre
		v82 = (type(v83) ~= "number" or v83 ~= v83) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v83)))
	end
	local v84 = p34.mv
	local v85 = (type(v84) ~= "number" or v84 ~= v84) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v84)))
	local v86 = p34.raw
	local v87 = (type(v86) ~= "number" or v86 ~= v86) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v86)))
	local v88 = p34.nan and "1" or "0"
	local v89 = p34.owner
	local v90 = v69:format(v71, v73, v75, v76, v77, v79, v81, v82, v85, v87, v88, (tostring(v89)))
	local v91 = p34.tvisible and "1" or "0"
	local v92 = p34.tmove and "1" or "0"
	local v93 = p34.ghostMove and "1" or "0"
	local v94 = p34.taim and "1" or "0"
	local v95 = p34.ghostAim and "1" or "0"
	local v96 = p34.tstate
	local v97 = ("touch=%s move=%s%s aim=%s%s tstate=%s"):format(v91, v92, v93, v94, v95, (tostring(v96)))
	local v98 = "input=%s hw=%s%s%s%s%s snare=%s zb=%s wall=%s ovl=%s snaps=%s"
	local v99 = p34.lastInput
	local v100 = tostring(v99)
	local v101 = p34.kbd and "1" or "0"
	local v102 = p34.pad and "1" or "0"
	local v103 = p34.mouse and "1" or "0"
	local v104 = p34.touchHw and "1" or "0"
	local v105 = p34.accel and "1" or "0"
	local v106
	if p34.snare == nil then
		v106 = "none"
	else
		local v107 = p34.snare
		v106 = (type(v107) ~= "number" or v107 ~= v107) and "nan" or string.format("%." .. tostring(2) .. "f", (math.abs(v107)))
	end
	local v108 = p34.zbText
	local v109 = tostring(v108)
	local v110 = p34.wallName
	local v111 = tostring(v110)
	local v112 = p34.overlap
	local v113 = tostring(v112)
	local v114 = p34.snaps
	local v115 = v98:format(v100, v101, v102, v103, v104, v105, v106, v109, v111, v113, (tostring(v114)))
	local v116 = p34.streaming and "1" or "0"
	local v117 = p34.integrity
	local v118 = tostring(v117)
	local v119 = p34.pingMs
	local v120 = (type(v119) ~= "number" or v119 ~= v119) and "nan" or string.format("%." .. tostring(0) .. "f", (math.abs(v119)))
	local v121 = p34.fps
	local v122 = (type(v121) ~= "number" or v121 ~= v121) and "nan" or string.format("%." .. tostring(0) .. "f", (math.abs(v121)))
	local v123 = p34.view
	local v124 = tostring(v123)
	local v125 = p34.reasserts
	local v126 = tostring(v125)
	local v127 = p34.panelHeals
	local v128 = tostring(v127)
	local v129 = p34.touchHeals
	__set_list(v41, 1, {v46, v61, v62, v68, v90, v97, v115, ("stream=%s/%s ping=%sms fps=%s view=%s fix=%s/%s/%s"):format(v116, v118, v120, v122, v124, v126, v128, (tostring(v129)))})
	return table.concat(v41, " | ")
end
function v_u_5.packet(p130, p131, p132, p133, p134) -- name: packet
	-- upvalues: (copy) v_u_5
	local v135
	if p133 == p133 then
		local v136 = math.clamp(p133, 0, 3600) * 10 + 0.5
		v135 = math.floor(v136) / 10
	else
		v135 = 0
	end
	local v137 = {
		["v"] = 1,
		["t"] = nil,
		["b"] = nil,
		["h"] = nil,
		["d"] = nil,
		["k"] = nil,
		["l"] = nil,
		["s"] = nil,
		["t"] = v135,
		["b"] = table.concat(p131, "+"),
		["h"] = table.concat(p132, "+")
	}
	local v138 = p130.device
	v137.d = tostring(v138)
	v137.k = ("k%sp%sm%st%sa%s"):format(p130.kbd and "1" or "0", p130.pad and "1" or "0", p130.mouse and "1" or "0", p130.touchHw and "1" or "0", p130.accel and "1" or "0")
	local v139 = p130.lastInput
	local v140 = tostring(v139)
	v137.l = string.sub(v140, 1, 16)
	local v141 = v_u_5.LINE_MAX
	v137.s = string.sub(p134, 1, v141)
	return v137
end
local function v_u_159(p142, p143, p144, p145) -- name: rays
	local v146 = p145.X
	local v147 = p145.Z
	local v148 = Vector3.new(v146, 0, v147)
	if v148.Magnitude < 0.05 then
		return false, "none"
	end
	local v149 = RaycastParams.new()
	v149.FilterType = Enum.RaycastFilterType.Exclude
	local v150 = { p142 }
	local v151 = workspace:FindFirstChild("HushLocal")
	if v151 then
		table.insert(v150, v151)
	end
	v149.FilterDescendantsInstances = v150
	local v152 = p143.Position
	local v153 = p144.HipHeight + p143.Size.Y / 2 - 0.7
	local v154 = math.max(0, v153)
	local v155 = v152 - Vector3.new(0, v154, 0)
	for _, v156 in { p143.Position, v155 } do
		local v157 = workspace:Raycast(v156, v148.Unit * 2.2, v149)
		if not (v157 and v157.Instance.CanCollide) then
			continue
		end
		local v158 = v157.Instance.Name
		return true, string.sub(v158, 1, 24)
	end
	return false, "none"
end
local function v_u_216(_, p160, _) -- name: gather
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (copy) v_u_159
	local v_u_161 = v_u_1.LocalPlayer
	local v_u_162 = v_u_161.Character
	local v163
	if v_u_162 then
		v163 = v_u_162:FindFirstChildOfClass("Humanoid")
	else
		v163 = v_u_162
	end
	local v_u_164
	if v_u_162 then
		v_u_164 = v_u_162:FindFirstChild("HumanoidRootPart")
	else
		v_u_164 = v_u_162
	end
	if not (v_u_162 and (v163 and v_u_164)) then
		return nil
	end
	local v165
	if p160.touch then
		v165 = p160.touch()
	else
		v165 = nil
	end
	local v166 = not p160.blockers and {} or p160.blockers()
	local v167 = v166.mv
	local v168 = typeof(v167) ~= "Vector3" and Vector3.new(0, 0, 0) or v166.mv
	local v169 = v166.raw
	local v170 = typeof(v169) ~= "Vector3" and Vector3.new(0, 0, 0) or v166.raw
	local v171 = v_u_164.AssemblyLinearVelocity
	local v172 = {
		["device"] = p160.device(),
		["place"] = v_u_161:GetAttribute("Place"),
		["status"] = v_u_161:GetAttribute("RaidStatus"),
		["ready"] = v_u_161:GetAttribute("RaidClientReady") == true
	}
	local v173
	if v_u_8.raidSince == nil then
		v173 = false
	else
		v173 = os.clock() - v_u_8.raidSince >= v_u_5.ARRIVE_MAX
	end
	v172.arriveLate = v173
	v172.enabled = v166.enabled
	v172.blocked = v166.blocked
	v172.live = v166.live
	v172.modal = v166.modal
	v172.open = v166.open
	v172.proof = v166.proof
	v172.dead = v_u_162:GetAttribute("Dead") == true
	v172.downed = v_u_162:GetAttribute("Downed") == true
	v172.action = v_u_162:GetAttribute("Action") or ""
	v172.ride = v_u_162:GetAttribute("RideVehicle") ~= nil
	v172.predAction = v_u_161:GetAttribute("PredAction") or ""
	v172.held = v_u_162:GetAttribute("HushHeld") ~= nil
	v172.anchored = v_u_164.Anchored
	v172.ws = v163.WalkSpeed
	v172.state = v163:GetState().Name
	v172.floor = v163.FloorMaterial.Name
	v172.plat = v163.PlatformStand
	v172.sit = v163.Sit
	v172.hp = v163.Health
	v172.md = v163.MoveDirection.Magnitude
	v172.mv = v168.Magnitude
	v172.raw = v170.Magnitude
	v172.nan = v168.Magnitude ~= v168.Magnitude and true or v170.Magnitude ~= v170.Magnitude
	local v174
	if os.clock() - v_u_8.mdPreAt < 0.25 then
		v174 = v_u_8.mdPre < 0.05
	else
		v174 = v163.MoveDirection.Magnitude < 0.05
	end
	v172.mdZero = v174
	v172.mdPre = os.clock() - v_u_8.mdPreAt >= 0.25 and -1 or v_u_8.mdPre
	v172.mvStrong = v168.Magnitude > 0.3
	local v175 = v171.X * v171.X + v171.Z * v171.Z
	v172.speed = math.sqrt(v175)
	v172.stick = not (v165 and v165.move) and 0 or v165.move.Magnitude
	local v176
	if v165 == nil then
		v176 = false
	else
		v176 = v165.visible == true
	end
	v172.tvisible = v176
	local v177
	if v165 == nil then
		v177 = false
	else
		v177 = v165.moveTouch ~= nil
	end
	v172.tmove = v177
	local v178
	if v165 == nil then
		v178 = false
	else
		v178 = v165.aimTouch ~= nil
	end
	v172.taim = v178
	v172.kbd = v_u_3.KeyboardEnabled
	v172.pad = v_u_3.GamepadEnabled
	v172.mouse = v_u_3.MouseEnabled
	v172.touchHw = v_u_3.TouchEnabled
	v172.accel = v_u_3.AccelerometerEnabled
	v172.lastInput = v_u_3:GetLastInputType().Name
	v172.fps = v_u_8.fps
	v172.lock = v_u_161:GetAttribute("InvUIWorldLocked")
	local v179 = v_u_161:GetAttribute("ClientError")
	v172.cerr = (type(v179) ~= "string" or v179 == "") and "none" or string.gsub(string.sub(v179, 1, 60), "[%c%-|]", "_")
	local v180
	if v_u_164.Anchored then
		v180 = "anchored"
	else
		local v181, v182 = pcall(function()
			-- upvalues: (copy) v_u_164
			return v_u_164:GetNetworkOwner()
		end)
		v180 = v181 and (v182 == nil and "server" or (v182 == v_u_1.LocalPlayer and "me" or "other")) or "err"
	end
	v172.owner = v180
	local v183 = v_u_162:GetAttribute("SpeedViolations") or 0
	local v184 = tostring(v183)
	local v185 = v_u_162:GetAttribute("WallViolations") or 0
	local v186 = tostring(v185)
	local v187 = v_u_162:GetAttribute("Rescues") or 0
	v172.snaps = ("%s/%s/%s"):format(v184, v186, (tostring(v187)))
	v172.tstate = "none"
	if v165 and v165.moveTouch ~= nil then
		local v188 = v165.moveTouch.UserInputState
		v172.tstate = not v188 and "?" or v188.Name
		v172.ghostMove = v188 == Enum.UserInputState.End and true or v188 == Enum.UserInputState.Cancel
	end
	if v165 and v165.aimTouch ~= nil then
		local v189 = v165.aimTouch.UserInputState
		v172.ghostAim = v189 == Enum.UserInputState.End and true or v189 == Enum.UserInputState.Cancel
	end
	v172.ghost = v172.ghostMove == true and true or v172.ghostAim == true
	local v190 = v_u_162:GetAttribute("SnareMul")
	if type(v190) ~= "number" or v190 ~= v190 then
		v190 = nil
	end
	v172.snare = v190
	local v191 = v_u_161:GetAttribute("ZBlockStats")
	v172.zbText = type(v191) ~= "string" and "none" or string.sub(v191, 1, 24)
	local v192, v193 = string.match(v172.zbText, "^(%d+) (%d+)")
	v172.zbody = (tonumber(v192) or 0) + (tonumber(v193) or 0) > 0
	local v194, v195 = v_u_159(v_u_162, v_u_164, v163, v168)
	v172.wall = v194
	v172.wallName = v195
	local v205, v206 = pcall(function()
		-- upvalues: (copy) v_u_162, (copy) v_u_164
		local v196 = OverlapParams.new()
		v196.FilterType = Enum.RaycastFilterType.Exclude
		local v197 = { v_u_162 }
		local v198 = workspace:FindFirstChild("HushLocal")
		if v198 then
			table.insert(v197, v198)
		end
		v196.FilterDescendantsInstances = v197
		v196.RespectCanCollide = true
		v196.MaxParts = 6
		local v199 = workspace:GetPartsInPart(v_u_164, v196)
		local v200 = #v199
		local v201 = {}
		for v202 = 1, math.min(v200, 3) do
			local v203 = v199[v202].Name
			local v204 = string.sub(v203, 1, 16)
			table.insert(v201, v204)
		end
		return ("%d:%s"):format(#v199, #v201 <= 0 and "none" or table.concat(v201, ","))
	end)
	v172.overlap = not v205 and "err" or v206
	local v207, v208 = pcall(function()
		return workspace.StreamingEnabled
	end)
	if v207 then
		v207 = v208 == true
	end
	v172.streaming = v207
	local v209, v210 = pcall(function()
		return workspace.StreamingIntegrityMode.Name
	end)
	v172.integrity = not v209 and "?" or v210
	local v211, v212 = pcall(function()
		-- upvalues: (copy) v_u_161
		return v_u_161:GetNetworkPing() * 1000
	end)
	v172.pingMs = not v211 and 0 or v212
	local v213 = workspace.CurrentCamera
	v172.view = not v213 and "?" or ("%dx%d"):format(v213.ViewportSize.X, v213.ViewportSize.Y)
	local v214 = p160._moveKeep
	v172.reasserts = type(v214) ~= "table" and "n" or v214.reasserts
	local v215 = p160._healStats
	v172.panelHeals = type(v215) ~= "table" and "n" or v215.panels
	v172.touchHeals = not (v165 and v165.staleReleases) and 0 or v165.staleReleases
	return v172
end
local function v_u_219(p217) -- name: send
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v218 = v_u_4:FindFirstChild("HushNet")
	if v218 then
		v218 = v218:FindFirstChild(v_u_5.REMOTE)
	end
	if v218 and v218:IsA("RemoteEvent") then
		v218:FireServer(p217)
	end
end
local function v_u_235(p220, p221, p222, p223, p224, p225, p226) -- name: publish
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_5, (copy) v_u_219
	local v227 = v_u_1.LocalPlayer
	local v228 = v_u_8
	v228.reports = v228.reports + 1
	local v229 = v_u_5.line(p220, p221, p222, p224, p223)
	v_u_8.last = v229
	v227:SetAttribute("MoveWatch", (string.sub(v229, 1, 200)))
	local v230 = os.clock()
	if p225 or v_u_8.logs < v_u_5.LOG_MAX and v230 - v_u_8.logAt >= v_u_5.LOG_GAP then
		local v231 = v_u_8
		v231.logs = v231.logs + 1
		v_u_8.logAt = v230
		print(v229)
	end
	if p226 and (p225 or v_u_8.sends < v_u_5.SEND_MAX and v230 - v_u_8.sendAt >= v_u_5.SEND_GAP) then
		local v232 = v_u_8
		v232.sends = v232.sends + 1
		v_u_8.sendAt = v230
		local v233 = v_u_219
		local v234 = v_u_5.packet
		pcall(v233, v234(p220, p222, p223, p224, v229))
	end
	return v229
end
local function v_u_254(p236, p237, p238, p239, p240) -- name: look
	-- upvalues: (copy) v_u_8, (copy) v_u_216, (copy) v_u_5, (copy) v_u_235
	local v241 = v_u_8
	v241.looks = v241.looks + 1
	local v242 = v_u_216(p236, p237, p238)
	if v242 then
		local v243, v244 = v_u_5.classify(v242, p238)
		if #v243 > 0 and not p239 then
			local v245 = v_u_8
			v245.explained = v245.explained + 1
			v_u_8.lastKnown = table.concat(v243, "+")
			return "known: " .. v_u_8.lastKnown
		else
			local v246 = {}
			local v247 = {}
			for _, v248 in v244 do
				local v249 = v_u_5.HEALS[v248]
				if not v249 or (v246[v249] or v249 == "anchor" and p238 < v_u_5.ANCHOR_AFTER) then
					continue
				end
				v246[v249] = true
				local v250 = p237.heal
				local v251, v252 = pcall(v250, v249)
				if not v251 or v252 ~= true then
					continue
				end
				table.insert(v247, v249)
				local v253 = v_u_8
				v253.heals = v253.heals + 1
			end
			return v_u_235(v242, v243, v244, v247, p238, p239, p240)
		end
	else
		return "no character"
	end
end
local function v_u_263(p255, p256, p257) -- name: fixReport
	-- upvalues: (copy) v_u_216, (copy) v_u_8, (copy) v_u_235
	local v258 = v_u_216(p255, p256, 0)
	if v258 then
		local v259 = v_u_8
		v259.fixReports = v259.fixReports + 1
		local v260 = p257 == "reassert" and "ctrl_over" or (p257 == "touch" and "touch_ghost" or "panel_inv")
		if p257 == "panels" then
			local v261 = p256._healStats
			local v262
			if type(v261) == "table" then
				v262 = v261.last
			else
				v262 = nil
			end
			v260 = v262 == "MapUI" and "panel_map" or (v262 == "RaidSettings" and "panel_set" or "panel_inv")
		end
		v_u_235(v258, {}, { v260 }, { p257 }, 0, false, true)
	end
end
local function v_u_295(p264, p265, p266) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_5, (copy) v_u_254, (copy) v_u_263
	local v267 = v_u_1.LocalPlayer
	local v268 = v_u_8
	local v269 = v_u_8.fps
	local v270 = 1 / math.max(p266, 0.004166666666666667)
	v268.fps = v269 + (math.clamp(v270, 1, 240) - v_u_8.fps) * 0.05
	if v267:GetAttribute("Place") == "Raid" then
		if v_u_8.raidSince == nil then
			v_u_8.raidSince = os.clock()
		end
		local v271 = v267.Character
		local v272
		if v271 then
			v272 = v271:FindFirstChildOfClass("Humanoid")
		else
			v272 = v271
		end
		local v273
		if v271 then
			v273 = v271:FindFirstChild("HumanoidRootPart")
		else
			v273 = v271
		end
		if v271 and (v272 and v273) then
			if v271:GetAttribute("Dead") == true or v272.Health <= 0 then
				v_u_8.stuck = 0
				return
			else
				v_u_8.hum = v272
				local v274 = os.clock()
				local v275
				if p265.touch then
					v275 = p265.touch()
				else
					v275 = nil
				end
				local v276 = p265.device()
				local v277 = v267:GetAttribute("RaidStatus")
				if v277 == "Alive" or v277 == "Downed" then
					if v267:GetAttribute("RaidClientReady") == true or v274 - v_u_8.raidSince >= v_u_5.ARRIVE_MAX then
						local v278 = (v276 ~= "Touch" or (not v275 or (v275.visible ~= true or not v275.move))) and 0 or v275.move.Magnitude
						local v279 = v_u_8
						local v280 = v_u_5.advance
						local v281 = v_u_8.stuck
						local v282 = v273.AssemblyLinearVelocity
						local v283 = v282.X * v282.X + v282.Z * v282.Z
						v279.stuck = v280(v281, p266, v278, (math.sqrt(v283)))
						if v_u_8.stuck >= v_u_5.STUCK_AFTER and v274 - v_u_8.lookAt >= v_u_5.LOOK_GAP then
							v_u_8.lookAt = v274
							v_u_254(p264, p265, v_u_8.stuck, false, true)
						end
						local v284 = p265._moveKeep
						local v285 = p265._healStats
						local v286
						if type(v284) == "table" then
							local v287 = v284.reasserts
							v286 = type(v287) ~= "number" and 0 or v284.reasserts
						else
							v286 = 0
						end
						local v288
						if type(v285) == "table" then
							local v289 = v285.panels
							v288 = type(v289) ~= "number" and 0 or v285.panels
						else
							v288 = 0
						end
						local v290
						if v275 then
							local v291 = v275.staleReleases
							v290 = type(v291) ~= "number" and 0 or v275.staleReleases
						else
							v290 = 0
						end
						if v_u_8.seenRe < v286 or (v_u_8.seenPan < v288 or v_u_8.seenTouch < v290) then
							local v292 = v_u_8.seenRe < v286 and "reassert" or (v_u_8.seenPan < v288 and "panels" or "touch")
							local v293 = v_u_8
							local v294 = v_u_8
							v_u_8.seenRe = v286
							v293.seenPan = v288
							v294.seenTouch = v290
							if v_u_8.sends < v_u_5.SEND_MAX and v274 - v_u_8.sendAt >= v_u_5.SEND_GAP then
								v_u_263(p264, p265, v292)
							end
						end
					else
						v_u_8.stuck = 0
					end
				else
					v_u_8.stuck = 0
					return
				end
			end
		else
			v_u_8.stuck = 0
			return
		end
	else
		v_u_8.stuck = 0
		v_u_8.raidSince = nil
		return
	end
end
function v_u_5.start(p_u_296, p_u_297) -- name: start
	-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_295, (copy) v_u_254, (copy) v_u_5
	if not v_u_8.started then
		v_u_8.started = true
		local function v299()
			-- upvalues: (ref) v_u_2, (ref) v_u_8
			(v_u_2.PreAnimation or v_u_2.Stepped):Connect(function()
				-- upvalues: (ref) v_u_8
				local v298 = v_u_8.hum
				if v298 and v298.Parent then
					v_u_8.mdPre = v298.MoveDirection.Magnitude
					v_u_8.mdPreAt = os.clock()
				end
			end)
		end
		pcall(v299)
		v_u_2.Heartbeat:Connect(function(p300)
			-- upvalues: (ref) v_u_8, (ref) v_u_295, (copy) p_u_296, (copy) p_u_297
			if not v_u_8.off then
				local v301 = v_u_295
				local v302 = p_u_296
				local v303 = p_u_297
				local v304, v305 = pcall(v301, v302, v303, p300)
				if not v304 then
					local v306 = v_u_8
					v306.errors = v306.errors + 1
					if v_u_8.errors <= 2 then
						warn("[MoveWatch] step failed:", v305)
					end
					if v_u_8.errors >= 5 then
						v_u_8.off = true
						warn("[MoveWatch] switched off after 5 errors")
					end
				end
			end
		end)
		local function v318()
			-- upvalues: (copy) p_u_296, (ref) v_u_8, (ref) v_u_254, (copy) p_u_297, (ref) v_u_5
			p_u_296.command("movewatch.state", function()
				-- upvalues: (ref) v_u_8
				local v307 = v_u_8.off
				return ("off=%s stuck=%.1f looks=%d explained=%d reports=%d heals=%d logs=%d sends=%d fixReports=%d errors=%d known=%s last=%s"):format(tostring(v307), v_u_8.stuck, v_u_8.looks, v_u_8.explained, v_u_8.reports, v_u_8.heals, v_u_8.logs, v_u_8.sends, v_u_8.fixReports, v_u_8.errors, v_u_8.lastKnown, v_u_8.last)
			end)
			p_u_296.command("movewatch.look", function()
				-- upvalues: (ref) v_u_254, (ref) p_u_296, (ref) p_u_297, (ref) v_u_8, (ref) v_u_5
				local v308 = v_u_254
				local v309 = p_u_296
				local v310 = p_u_297
				local v311 = v_u_8.stuck
				local v312 = v_u_5.STUCK_AFTER
				return v308(v309, v310, math.max(v311, v312), true, false)
			end)
			p_u_296.command("movewatch.send", function()
				-- upvalues: (ref) v_u_254, (ref) p_u_296, (ref) p_u_297, (ref) v_u_8, (ref) v_u_5
				local v313 = v_u_254
				local v314 = p_u_296
				local v315 = p_u_297
				local v316 = v_u_8.stuck
				local v317 = v_u_5.STUCK_AFTER
				return v313(v314, v315, math.max(v316, v317), true, true)
			end)
		end
		pcall(v318)
	end
end
v_u_5.FAULT_MAX = 4
function v_u_5.faultPacket(p319, p320) -- name: faultPacket
	-- upvalues: (copy) v_u_5
	local v321 = {
		["v"] = 1,
		["t"] = 0,
		["b"] = "client_err",
		["h"] = "none",
		["d"] = "other",
		["k"] = "k0p0m0t0a0",
		["l"] = "",
		["s"] = nil
	}
	local v322 = string.gsub(p319 .. ": " .. p320, "[%c]", " ")
	local v323 = v_u_5.LINE_MAX
	v321.s = string.sub(v322, 1, v323)
	return v321
end
function v_u_5.fault(p324, p325) -- name: fault
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_219
	if v_u_8.faultTags[p324] or v_u_8.faults >= v_u_5.FAULT_MAX then
		return false
	end
	v_u_8.faultTags[p324] = true
	local v326 = v_u_8
	v326.faults = v326.faults + 1
	local v327 = v_u_219
	local v328 = v_u_5.faultPacket
	return pcall(v327, v328(p324, p325))
end
v_u_5._state = v_u_8
return v_u_5