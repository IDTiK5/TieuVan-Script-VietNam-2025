-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / NightVision

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("AssetService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = {
	["name"] = "NightVision",
	["order"] = 15
}
local v_u_8 = v1.LocalPlayer
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = false
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = -1000000000
local v_u_22 = {
	["place"] = "Menu",
	["tod"] = "Day",
	["weather"] = "Clear",
	["hunt"] = false,
	["inside"] = false,
	["under"] = false,
	["dead"] = true,
	["tier"] = nil
}
local v_u_23 = false
local v_u_24 = nil
local v_u_25 = 0
local v_u_26 = false
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = ""
local v_u_33 = "none"
local v_u_34 = -1
local v_u_35 = -1000000000
local v_u_36 = true
local v_u_37 = nil
local v_u_38 = {}
local function v_u_43(p_u_39) -- name: notify
	-- upvalues: (ref) v_u_9
	local v40 = v_u_9.controllers.HUD
	if v40 and v40.notify then
		local v41 = v40.notify
		if pcall(v41, p_u_39, "info") then
			return
		end
	end
	local function v42()
		-- upvalues: (ref) v_u_9, (copy) p_u_39
		v_u_9.lib.HushUI.toast(p_u_39, "info")
	end
	pcall(v42)
end
local function v_u_48() -- name: viewportSize
	-- upvalues: (ref) v_u_9, (copy) v_u_6
	local function v44()
		-- upvalues: (ref) v_u_9
		return v_u_9.shared.Theme.viewport()
	end
	local v45, v46 = pcall(v44)
	if v45 and (typeof(v46) == "Vector2" and (v46.X > 8 and v46.Y > 8)) then
		return v46.X, v46.Y
	else
		local v47 = v_u_6.CurrentCamera
		if v47 == nil or v47.ViewportSize.X <= 8 then
			return 1920, 1080
		else
			return v47.ViewportSize.X, v47.ViewportSize.Y
		end
	end
end
local function v_u_74(p49) -- name: poll
	-- upvalues: (ref) v_u_21, (copy) v_u_8, (copy) v_u_22, (ref) v_u_9, (ref) v_u_20, (ref) v_u_10, (ref) v_u_15, (ref) v_u_16, (copy) v_u_3
	v_u_21 = p49
	local v50 = v_u_8:GetAttribute("Place")
	v_u_22.place = type(v50) ~= "string" and "Menu" or v50
	local v51 = v_u_8.Character
	local v52 = v51 == nil and true or v51:GetAttribute("Dead") == true
	if not v52 and v51 then
		local v53 = v51:FindFirstChildOfClass("Humanoid")
		if v53 == nil then
			v52 = false
		else
			v52 = v53.Health <= 0
		end
	end
	if not v52 then
		local v54 = v_u_9.controllers.Camera
		if v54 and v54.mode then
			local v55 = v54.mode
			local v56, v57 = pcall(v55)
			v52 = v56 and v57 == "spectate" and true or v52
		end
	end
	v_u_22.dead = v52
	if v51 ~= v_u_20 then
		v_u_20 = v51
		if v_u_10.isOn(v_u_15) then
			v_u_10.release(v_u_15, p49)
		end
	end
	local v58 = v_u_16
	if v58 == nil and v51 then
		v58 = v_u_10.tierOfId(v51:GetAttribute("Helmet"))
	end
	v_u_22.tier = v58
	if v_u_22.place == "Raid" and v58 ~= nil then
		local v59 = v_u_3:FindFirstChild("HushRuntime")
		local v60
		if v59 then
			v60 = v59:FindFirstChild("Raid")
		else
			v60 = nil
		end
		local v61
		if v60 then
			v61 = v60:GetAttribute("TimeOfDay")
		else
			v61 = nil
		end
		local v62
		if v60 then
			v62 = v60:GetAttribute("Weather")
		else
			v62 = nil
		end
		v_u_22.tod = type(v61) ~= "string" and "Day" or v61
		v_u_22.weather = type(v62) ~= "string" and "Clear" or v62
		local v63 = v_u_22
		local v64
		if v60 == nil then
			v64 = false
		else
			v64 = v60:GetAttribute("Hunt") == true
		end
		v63.hunt = v64
		local v65 = v_u_9.controllers.Atmosphere
		local v66
		if v65 and v65.isInside then
			local v67 = v65.isInside
			local v68
			v66, v68 = pcall(v67)
			if v66 then
				v66 = v68 == true
			end
		else
			v66 = false
		end
		v_u_22.inside = v66
		local function v69()
			-- upvalues: (ref) v_u_9
			return v_u_9.shared.MapInfo.fromRuntime()
		end
		local v70, v71 = pcall(v69)
		v_u_22.under = v70 and (type(v71) == "table" and v71.underground == true) and true or false
	else
		local v72 = v_u_22
		local v73 = v_u_22
		v_u_22.hunt = false
		v72.inside = false
		v73.under = false
	end
end
local function v_u_82(p75) -- name: reconcile
	-- upvalues: (copy) v_u_22, (ref) v_u_17, (ref) v_u_10, (ref) v_u_15, (ref) v_u_19, (ref) v_u_11, (copy) v_u_43
	local v76
	if v_u_22.place == "Raid" and not v_u_22.dead then
		v76 = v_u_22.tier
	else
		v76 = nil
	end
	if v76 ~= v_u_17 then
		v_u_17 = v76
		if v_u_10.isOn(v_u_15) or v_u_10.blend(v_u_15, p75) > 0 then
			v_u_10.release(v_u_15, p75)
		end
		v_u_19 = nil
	end
	if v_u_17 == nil or not v_u_10.isOn(v_u_15) then
		v_u_19 = nil
	else
		local v77, v78 = v_u_10.allowed(v_u_22.place, v_u_22.tod, v_u_22.inside, v_u_22.under, v_u_22.hunt, v_u_22.dead)
		local v79, v80 = v_u_11.grace(v_u_19, v77, p75)
		v_u_19 = v79
		if v80 then
			v_u_19 = nil
			if v_u_10.isOn(v_u_15) or v_u_10.blend(v_u_15, p75) > 0 then
				v_u_10.release(v_u_15, p75)
			end
			local v81 = v_u_11.refusalText(v_u_10, v78)
			if v81 then
				v_u_43(v81)
				return
			end
		end
	end
end
local function v_u_95(p83) -- name: lampStep
	-- upvalues: (ref) v_u_18, (ref) v_u_11, (ref) v_u_10, (ref) v_u_15, (ref) v_u_9
	local v84 = v_u_11.exclusion
	local v85 = v_u_18
	local v86 = v_u_10.isOn(v_u_15)
	local v87 = v_u_9.controllers.Atmosphere
	local v88
	if v87 and v87.flashlightOn then
		local v89 = v87.flashlightOn
		local v90
		v88, v90 = pcall(v89)
		if v88 then
			v88 = v90 == true
		end
	else
		v88 = false
	end
	local v91, v92 = v84(v85, v86, v88)
	v_u_18 = v92
	if v91 == "cut" then
		v_u_10.release(v_u_15, p83)
	elseif v91 == "restore" then
		local v93 = v_u_9.controllers.Atmosphere
		if v93 and v93.setFlashlight then
			local v94 = v93.setFlashlight
			pcall(v94, nil)
		end
	end
end
local function v_u_104(p96) -- name: applyGrade
	-- upvalues: (ref) v_u_27, (copy) v_u_2
	if type(p96) == "table" then
		local v97 = v_u_27
		if v97 == nil or v97.Parent ~= v_u_2 then
			v97 = v_u_2:FindFirstChild("HushNvgGrade")
			if not (v97 and v97:IsA("ColorCorrectionEffect")) then
				v97 = Instance.new("ColorCorrectionEffect")
				v97.Name = "HushNvgGrade"
				v97.Parent = v_u_2
			end
			v_u_27 = v97
		end
		v97.Saturation = p96.saturation
		v97.Brightness = p96.brightness
		v97.Contrast = p96.contrast
		local v98 = Color3.new
		local v99 = p96.tint[1] / 255
		local v100 = math.clamp(v99, 0, 1)
		local v101 = p96.tint[2] / 255
		local v102 = math.clamp(v101, 0, 1)
		local v103 = p96.tint[3] / 255
		v97.TintColor = v98(v100, v102, (math.clamp(v103, 0, 1)))
		v97.Enabled = true
	elseif v_u_27 then
		v_u_27.Enabled = false
	end
end
local function v_u_106() -- name: destroyMask
	-- upvalues: (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34
	if v_u_28 then
		v_u_28:Destroy()
	end
	v_u_28 = nil
	v_u_29 = nil
	v_u_30 = nil
	if v_u_31 ~= nil then
		local function v105()
			-- upvalues: (ref) v_u_31
			v_u_31:Destroy()
		end
		pcall(v105)
		v_u_31 = nil
	end
	v_u_32 = ""
	v_u_33 = "none"
	v_u_34 = -1
end
local function v_u_109() -- name: ensureMaskGui
	-- upvalues: (ref) v_u_28, (copy) v_u_8, (ref) v_u_11
	if v_u_28 and v_u_28.Parent then
		return v_u_28
	end
	local v107 = v_u_8:FindFirstChildOfClass("PlayerGui")
	if v107 == nil then
		return nil
	end
	local v_u_108 = Instance.new("ScreenGui")
	v_u_108.Name = "HushNvgMask"
	v_u_108.ResetOnSpawn = false
	v_u_108.IgnoreGuiInset = true
	v_u_108.DisplayOrder = v_u_11.MASK_ORDER
	v_u_108.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_108.Enabled = false
	pcall(function()
		-- upvalues: (copy) v_u_108
		v_u_108.ScreenInsets = Enum.ScreenInsets.None
	end)
	v_u_108.Parent = v107
	v_u_28 = v_u_108
	return v_u_108
end
local function v_u_126(p_u_110, p111, p112, p113) -- name: buildMaskImage
	-- upvalues: (ref) v_u_36, (ref) v_u_12, (ref) v_u_10, (copy) v_u_5, (ref) v_u_31, (ref) v_u_29
	if not v_u_36 then
		return false
	end
	local v_u_114, v_u_115 = v_u_12.imageSize(p112, p113)
	local v116 = v_u_10.maskRects(v_u_114, v_u_115, p111)
	if v116 == nil then
		return false
	end
	local v_u_117 = v_u_12.raster(v116, v_u_114, v_u_115, v_u_12.FEATHER)
	local function v124()
		-- upvalues: (ref) v_u_5, (copy) v_u_114, (copy) v_u_115, (copy) v_u_117, (copy) p_u_110, (ref) v_u_31, (ref) v_u_29
		local v118 = v_u_5:CreateEditableImage({
			["Size"] = Vector2.new(v_u_114, v_u_115)
		})
		local v119 = buffer.create(v_u_114 * v_u_115 * 4)
		for v120 = 1, v_u_114 * v_u_115 do
			local v121 = (v120 - 1) * 4 + 3
			local v122 = v_u_117[v120]
			buffer.writeu8(v119, v121, v122)
		end
		v118:WritePixelsBuffer(Vector2.zero, Vector2.new(v_u_114, v_u_115), v119)
		local v123 = Instance.new("ImageLabel")
		v123.Name = "Lens"
		v123.BackgroundTransparency = 1
		v123.BorderSizePixel = 0
		v123.Size = UDim2.fromScale(1, 1)
		v123.ScaleType = Enum.ScaleType.Stretch
		v123.ImageTransparency = 1
		v123.Active = false
		v123.ImageContent = Content.fromObject(v118)
		v123.Parent = p_u_110
		v_u_31 = v118
		v_u_29 = v123
	end
	if pcall(v124) then
		return true
	end
	v_u_36 = false
	if v_u_31 ~= nil then
		local function v125()
			-- upvalues: (ref) v_u_31
			v_u_31:Destroy()
		end
		pcall(v125)
		v_u_31 = nil
	end
	return false
end
local function v_u_136(p127, p128, p129, p130) -- name: buildMaskStrips
	-- upvalues: (ref) v_u_10, (ref) v_u_30
	local v131 = v_u_10.maskStrips(p129, p130, p128)
	if v131 == nil then
		return false
	end
	local v132 = Instance.new("CanvasGroup")
	v132.Name = "Lens"
	v132.BackgroundTransparency = 1
	v132.BorderSizePixel = 0
	v132.Size = UDim2.fromScale(1, 1)
	v132.GroupTransparency = 1
	v132.Active = false
	for v133, v134 in v131 do
		local v135 = Instance.new("Frame")
		v135.Name = "S" .. v133
		v135.BackgroundColor3 = Color3.new(0, 0, 0)
		v135.BorderSizePixel = 0
		v135.Position = UDim2.fromScale(v134.x / p129, v134.y / p130)
		v135.Size = UDim2.fromScale(v134.w / p129, v134.h / p130)
		v135.Active = false
		v135.Parent = v132
	end
	v132.Parent = p127
	v_u_30 = v132
	return true
end
local function v_u_142(p137, p138, p139, p140) -- name: buildMask
	-- upvalues: (copy) v_u_106, (ref) v_u_35, (copy) v_u_109, (copy) v_u_126, (ref) v_u_33, (copy) v_u_136, (ref) v_u_32
	v_u_106()
	v_u_35 = os.clock()
	local v141 = v_u_109()
	if v141 ~= nil then
		if v_u_126(v141, p137, p138, p139) then
			v_u_33 = "image"
		else
			if not v_u_136(v141, p137, p138, p139) then
				return
			end
			v_u_33 = "strips"
		end
		v_u_32 = p140
	end
end
local function v_u_150(p143) -- name: maskReady
	-- upvalues: (copy) v_u_48, (ref) v_u_32, (ref) v_u_28, (ref) v_u_35, (copy) v_u_142
	local v144, v145 = v_u_48()
	local v146 = math.floor(v144)
	local v147 = tostring(v146)
	local v148 = math.floor(v145)
	local v149 = p143 .. "|" .. v147 .. "x" .. tostring(v148)
	if v149 == v_u_32 and (v_u_28 ~= nil and v_u_28.Parent ~= nil) then
		return true
	end
	if os.clock() - v_u_35 < 0.5 then
		return false
	end
	v_u_142(p143, v144, v145, v149)
	return v_u_32 == v149
end
local function v_u_172() -- name: fpFacts
	-- upvalues: (ref) v_u_9, (copy) v_u_14
	local v151 = v_u_9.controllers.FpView
	if not (v151 and v151.active) then
		return false, "tp", false
	end
	local v152 = v151.active
	local v153, v154 = pcall(v152)
	if not v153 or v154 ~= true then
		return false, "tp", false
	end
	local v155 = "tp"
	local v156 = v_u_14.FpCam
	if v156 == nil then
		local v_u_157 = "FpCam"
		local function v158()
			-- upvalues: (ref) v_u_9, (copy) v_u_157
			return v_u_9.lib[v_u_157]
		end
		local v159
		v159, v156 = pcall(v158)
		if not v159 or type(v156) ~= "table" then
			v156 = false
		end
		v_u_14.FpCam = v156
	end
	local v160 = v156 or nil
	if v160 and v160.effectiveSide then
		local v161 = v160.effectiveSide
		local v162, v163 = pcall(v161)
		v155 = v162 and v163 == "fp" and "fp" or v155
	end
	local v164 = false
	local v165 = v_u_14.ScopeView
	if v165 == nil then
		local v_u_166 = "ScopeView"
		local function v167()
			-- upvalues: (ref) v_u_9, (copy) v_u_166
			return v_u_9.lib[v_u_166]
		end
		local v168
		v168, v165 = pcall(v167)
		if not v168 or type(v165) ~= "table" then
			v165 = false
		end
		v_u_14.ScopeView = v165
	end
	local v169 = v165 or nil
	if v169 and v169.isScoped then
		local v170 = v169.isScoped
		local v171
		v164, v171 = pcall(v170)
		if v164 then
			v164 = v171 == true
		end
	end
	return true, v155, v164
end
local function v_u_182(p173, p174, p175, p176, p177) -- name: updateMask
	-- upvalues: (ref) v_u_11, (copy) v_u_22, (copy) v_u_150, (ref) v_u_34, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30
	local v178 = v_u_11.maskAlpha(p174, p175, p176, p177, v_u_22.dead)
	local v179 = (v178 > 0 and not v_u_150(p173) and 0 or v178) * 100 + 0.5
	local v180 = math.floor(v179) / 100
	if v180 == v_u_34 then
		return
	else
		v_u_34 = v180
		local v181 = v_u_28
		if v181 == nil then
			return
		else
			v181.Enabled = v180 > 0
			if v_u_29 then
				v_u_29.ImageTransparency = 1 - v180
			elseif v_u_30 then
				v_u_30.GroupTransparency = 1 - v180
			end
		end
	end
end
local function v_u_188(p183) -- name: coneVis
	-- upvalues: (ref) v_u_9
	local v184 = v_u_9.controllers.Vision
	if v184 and v184.visibility then
		local v185 = v184.visibility
		local v186, v187 = pcall(v185, p183)
		if v186 and type(v187) == "number" then
			return v187
		end
	end
	return 1
end
local function v_u_195(p189, p190) -- name: heatStep
	-- upvalues: (ref) v_u_13, (ref) v_u_17, (copy) v_u_188, (ref) v_u_26
	if v_u_13 == nil then
		return
	else
		local v191
		if v_u_17 == "thermal" then
			v191 = p189 > 0
		else
			v191 = false
		end
		if v191 then
			local v192 = v_u_13.configure
			local v193 = true
			local v194
			if p190 then
				v194 = nil
			else
				v194 = v_u_188
			end
			v192(v193, p189, v194)
			v_u_26 = true
		elseif v_u_26 then
			v_u_26 = false
			v_u_13.configure(false, 0, nil)
			v_u_13.reset()
		end
	end
end
local function v_u_198() -- name: clearLook
	-- upvalues: (ref) v_u_9, (ref) v_u_27, (ref) v_u_28, (ref) v_u_34, (ref) v_u_13, (ref) v_u_26, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25
	local v196 = v_u_9.controllers.Atmosphere
	if v196 and v196.setNightVision then
		local v197 = v196.setNightVision
		pcall(v197, nil)
	end
	if v_u_27 then
		v_u_27.Enabled = false
	end
	if v_u_28 and v_u_34 ~= 0 then
		v_u_28.Enabled = false
		v_u_34 = 0
	end
	if v_u_13 ~= nil and v_u_26 then
		v_u_26 = false
		v_u_13.configure(false, 0, nil)
		v_u_13.reset()
	end
	v_u_23 = false
	v_u_24 = nil
	v_u_25 = 0
end
local function v_u_212(p199, p200) -- name: render
	-- upvalues: (ref) v_u_9, (copy) v_u_38, (ref) v_u_23, (ref) v_u_11, (ref) v_u_24, (ref) v_u_25, (ref) v_u_10, (copy) v_u_104, (copy) v_u_172, (copy) v_u_182, (copy) v_u_195
	local v201 = v_u_9.controllers.Atmosphere
	local v202
	if v201 and v201.quality then
		local v203 = v201.quality
		local v204
		v202, v204 = pcall(v203)
		if v202 then
			if type(v204) == "number" then
				v202 = v204 <= 2
			else
				v202 = false
			end
		end
	else
		v202 = false
	end
	local v205
	if v202 then
		v205 = v_u_38[p199].low
	else
		v205 = v_u_38[p199].std
	end
	if not v_u_23 or v_u_11.changed(v_u_24, v205, v_u_25, p200) then
		local v206 = v_u_10.lightSpec(p199, p200, v202)
		if v206 ~= nil then
			local v207 = v_u_9.controllers.Atmosphere
			if v207 and v207.setNightVision then
				local v208 = v207.setNightVision
				pcall(v208, v206)
			end
			v_u_104(v206.grade)
		end
		v_u_23 = true
		v_u_24 = v205
		v_u_25 = p200
	end
	local v209, v210, v211 = v_u_172()
	v_u_182(p199, p200, v209, v210, v211)
	v_u_195(p200, v209)
end
local function v_u_231() -- name: syncTouch
	-- upvalues: (ref) v_u_9, (ref) v_u_11, (ref) v_u_17, (copy) v_u_22, (ref) v_u_37, (copy) v_u_14, (ref) v_u_10, (ref) v_u_15
	local v213 = v_u_9.controllers.Input
	if v213 and (v213.touch and v213.touchButton) then
		local v214 = v213.touch
		local v215, v216 = pcall(v214)
		if v215 and v216 ~= nil then
			local v217 = v_u_11.touchShown(v_u_17, v_u_22.place, v_u_22.hunt, v_u_22.dead)
			if v217 and not (v_u_37 and v_u_37.Parent) then
				local v218 = v_u_14.TouchControls
				if v218 == nil then
					local v_u_219 = "TouchControls"
					local function v220()
						-- upvalues: (ref) v_u_9, (copy) v_u_219
						return v_u_9.lib[v_u_219]
					end
					local v221
					v221, v218 = pcall(v220)
					if not v221 or type(v218) ~= "table" then
						v218 = false
					end
					v_u_14.TouchControls = v218
				end
				local v222 = v218 or nil
				local v223
				if v222 then
					v223 = v222.NVG_MAIN
				else
					v223 = nil
				end
				if v223 then
					local v224 = v213.touchButton
					local v225 = {
						["text"] = nil,
						["anchor"] = nil,
						["pos"] = nil,
						["size"] = nil,
						["toggle"] = true,
						["text"] = v223.text,
						["anchor"] = v223.anchor,
						["pos"] = Vector2.new(v223.x, v223.y),
						["size"] = v223.size
					}
					local v226, v227 = pcall(v224, "nightVision", v225)
					if v226 and (typeof(v227) == "Instance" and v227:IsA("GuiButton")) then
						v_u_37 = v227
					end
				end
			end
			if v_u_37 and v_u_37.Parent then
				if v_u_37.Visible ~= v217 then
					v_u_37.Visible = v217
				end
				if v216.setToggle then
					local v228 = v216.setToggle
					local v229 = v_u_10.isOn
					local v230 = v_u_15
					pcall(v228, v216, "nightVision", v229(v230))
				end
			end
		end
	else
		return
	end
end
local function v_u_235() -- name: fullReset
	-- upvalues: (ref) v_u_10, (ref) v_u_15, (ref) v_u_17, (ref) v_u_19, (ref) v_u_20, (ref) v_u_18, (ref) v_u_9, (copy) v_u_198, (copy) v_u_106, (ref) v_u_13, (ref) v_u_26, (ref) v_u_21, (ref) v_u_37
	local v232 = os.clock()
	if v_u_10.isOn(v_u_15) or v_u_10.blend(v_u_15, v232) > 0 then
		v_u_10.release(v_u_15, v232)
	end
	v_u_10.reset(v_u_15)
	v_u_17 = nil
	v_u_19 = nil
	v_u_20 = nil
	if v_u_18 then
		v_u_18 = false
		local v233 = v_u_9.controllers.Atmosphere
		if v233 and v233.setFlashlight then
			local v234 = v233.setFlashlight
			pcall(v234, nil)
		end
	end
	v_u_198()
	v_u_106()
	if v_u_13 ~= nil then
		v_u_13.configure(false, 0, nil)
		v_u_13.reset()
	end
	v_u_26 = false
	v_u_21 = -1000000000
	if v_u_37 and v_u_37.Parent then
		v_u_37.Visible = false
	end
end
function v_u_7.on() -- name: on
	-- upvalues: (ref) v_u_15, (ref) v_u_10
	local v236
	if v_u_15 == nil then
		v236 = false
	else
		v236 = v_u_10.isOn(v_u_15)
	end
	return v236
end
function v_u_7.tier() -- name: tier
	-- upvalues: (ref) v_u_17
	return v_u_17
end
function v_u_7.blend() -- name: blend
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_10
	return (v_u_15 == nil or v_u_17 == nil) and 0 or v_u_10.blend(v_u_15, os.clock())
end
function v_u_7.visionMods(p237, p238) -- name: visionMods
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_10
	if v_u_15 == nil or v_u_17 == nil then
		return nil, nil, nil
	end
	local v239 = v_u_10.blend(v_u_15, os.clock())
	if v239 <= 0 then
		return nil, nil, nil
	end
	local v240 = v_u_10.visionMods
	local v241 = v_u_17
	if type(p237) ~= "string" then
		p237 = nil
	end
	if type(p238) ~= "string" then
		p238 = nil
	end
	return v240(v241, v239, p237, p238)
end
function v_u_7.press() -- name: press
	-- upvalues: (ref) v_u_10, (ref) v_u_15, (copy) v_u_74, (copy) v_u_82, (ref) v_u_17, (ref) v_u_9, (ref) v_u_11, (copy) v_u_231, (copy) v_u_22, (copy) v_u_43, (ref) v_u_18
	if v_u_10 == nil or v_u_15 == nil then
		return
	else
		local v242 = os.clock()
		v_u_74(v242)
		v_u_82(v242)
		if v_u_17 == nil then
			return
		elseif v_u_10.isOn(v_u_15) then
			if v_u_10.press(v_u_15, v242) then
				local v243 = v_u_9.controllers.Audio
				if v243 and v243.play then
					local v244 = v243.play
					local v245 = {
						["volume"] = v_u_11.CLICK_VOLUME,
						["pitch"] = v_u_11.CLICK_PITCH
					}
					pcall(v244, "item_flashlight", v245)
				end
				v_u_231()
			end
			return
		else
			local v246, v247 = v_u_10.allowed(v_u_22.place, v_u_22.tod, v_u_22.inside, v_u_22.under, v_u_22.hunt, v_u_22.dead)
			if v246 then
				if v_u_10.press(v_u_15, v242) then
					local v248 = v_u_9.controllers.Audio
					if v248 and v248.play then
						local v249 = v248.play
						local v250 = {
							["volume"] = v_u_11.CLICK_VOLUME,
							["pitch"] = v_u_11.CLICK_PITCH
						}
						pcall(v249, "item_flashlight", v250)
					end
					local v251 = v_u_9.controllers.Atmosphere
					if v251 and v251.setFlashlight then
						local v252 = v251.setFlashlight
						pcall(v252, false)
					end
					v_u_18 = true
					v_u_231()
				end
			else
				local v253 = v_u_11.refusalText(v_u_10, v247)
				if v253 then
					v_u_43(v253)
				end
			end
		end
	end
end
function v_u_7.debugState() -- name: debugState
	-- upvalues: (ref) v_u_13, (ref) v_u_17, (copy) v_u_22, (ref) v_u_16, (ref) v_u_15, (ref) v_u_10, (ref) v_u_18, (ref) v_u_9, (ref) v_u_23, (ref) v_u_24, (ref) v_u_33, (ref) v_u_34, (ref) v_u_32, (ref) v_u_27, (ref) v_u_37
	local v254 = os.clock()
	local v255
	if v_u_13 == nil then
		v255 = nil
	else
		v255 = v_u_13.stats()
	end
	local v256 = {
		["tier"] = v_u_17 or "none",
		["helmetTier"] = v_u_22.tier or "none",
		["forced"] = v_u_16 or "none"
	}
	local v257
	if v_u_15 == nil then
		v257 = false
	else
		v257 = v_u_10.isOn(v_u_15)
	end
	v256.on = v257
	v256.blend = (v_u_15 == nil or v_u_17 == nil) and 0 or v_u_10.blend(v_u_15, v254)
	v256.place = v_u_22.place
	v256.tod = v_u_22.tod
	v256.weather = v_u_22.weather
	v256.inside = v_u_22.inside
	v256.under = v_u_22.under
	v256.hunt = v_u_22.hunt
	v256.dead = v_u_22.dead
	v256.held = v_u_18
	local v258 = v_u_9.controllers.Atmosphere
	local v259
	if v258 and v258.flashlightOn then
		local v260 = v258.flashlightOn
		local v261
		v259, v261 = pcall(v260)
		if v259 then
			v259 = v261 == true
		end
	else
		v259 = false
	end
	v256.flash = v259
	v256.applied = v_u_23
	v256.key = v_u_24 or "none"
	v256.mask = v_u_33
	v256.maskAlpha = v_u_34
	v256.maskKey = v_u_32
	local v262
	if v_u_27 == nil then
		v262 = false
	else
		v262 = v_u_27.Enabled
	end
	v256.grade = v262
	local v263
	if v_u_37 == nil then
		v263 = false
	else
		v263 = v_u_37.Parent ~= nil
	end
	v256.touch = v263
	v256.heat = v255
	v256.cooldown = v_u_15 == nil and 0 or v_u_10.cooldownLeft(v_u_15, v254)
	return v256
end
function v_u_7.init(p_u_264) -- name: init
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_15, (copy) v_u_38, (ref) v_u_13, (copy) v_u_7, (copy) v_u_4, (ref) v_u_16, (ref) v_u_21
	v_u_9 = p_u_264
	v_u_10 = p_u_264.shared.NightVisionRules
	v_u_11 = p_u_264.lib.NvgLogic
	v_u_12 = p_u_264.lib.NvgMask
	v_u_15 = v_u_10.newState()
	for _, v265 in v_u_10.ORDER do
		v_u_38[v265] = {
			["std"] = v265 .. "|std",
			["low"] = v265 .. "|low"
		}
	end
	local function v266()
		-- upvalues: (ref) v_u_13, (copy) p_u_264
		v_u_13 = p_u_264.lib.NvgHeat
	end
	pcall(v266)
	p_u_264.command("nvg.state", function()
		-- upvalues: (ref) v_u_7
		local v267 = v_u_7.debugState()
		local v268 = {}
		for v269 in v267 do
			table.insert(v268, v269)
		end
		table.sort(v268)
		local v270 = {}
		for _, v271 in v268 do
			local v272 = v267[v271]
			if type(v272) == "table" then
				local v273 = {}
				for v274, v275 in v272 do
					local v276 = tostring(v274) .. "=" .. tostring(v275)
					table.insert(v273, v276)
				end
				table.sort(v273)
				v272 = "{" .. table.concat(v273, ",") .. "}"
			end
			local v277 = v271 .. "=" .. tostring(v272)
			table.insert(v270, v277)
		end
		return table.concat(v270, " ")
	end)
	p_u_264.command("nvg.press", function()
		-- upvalues: (ref) v_u_7
		v_u_7.press()
		local v278 = v_u_7.on
		return "pressed, on=" .. tostring(v278())
	end)
	p_u_264.command("nvg.force", function(p279)
		-- upvalues: (ref) v_u_4, (ref) v_u_16, (ref) v_u_10, (ref) v_u_21
		if not v_u_4:IsStudio() then
			return "nvg.force works in Studio only"
		end
		local v280 = p279[1]
		if v280 == nil or v280 == "off" then
			v_u_16 = nil
		else
			if v_u_10.TIERS[v280] == nil then
				return "usage: nvg.force <mono|dual|quad|thermal|off>"
			end
			v_u_16 = v280
		end
		v_u_21 = -1000000000
		local v281 = v_u_16
		return "forced tier " .. tostring(v281)
	end)
end
function v_u_7.start() -- name: start
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_235
	local v282 = v_u_9.controllers.Input
	if v282 and v282.bind then
		v282.bind("nightVision", function()
			-- upvalues: (ref) v_u_7
			v_u_7.press()
		end)
	end
	v_u_9.session.onPlaceChanged(function()
		-- upvalues: (ref) v_u_235
		v_u_235()
	end)
end
function v_u_7.step(_) -- name: step
	-- upvalues: (ref) v_u_10, (ref) v_u_15, (ref) v_u_11, (ref) v_u_21, (copy) v_u_74, (copy) v_u_82, (copy) v_u_231, (ref) v_u_17, (ref) v_u_28, (ref) v_u_23, (copy) v_u_106, (copy) v_u_172, (copy) v_u_150, (ref) v_u_18, (copy) v_u_95, (copy) v_u_212, (copy) v_u_198
	if v_u_10 == nil or v_u_15 == nil then
		return
	else
		local v283 = os.clock()
		if v_u_11.due(v283, v_u_21) then
			v_u_74(v283)
			v_u_82(v283)
			v_u_231()
			if v_u_17 == nil then
				if v_u_28 ~= nil and not v_u_23 then
					v_u_106()
				end
			elseif v_u_172() then
				v_u_150(v_u_17)
			end
		end
		if v_u_17 == nil and not (v_u_18 or v_u_23) then
			return
		else
			if v_u_18 or v_u_10.isOn(v_u_15) then
				v_u_95(v283)
			end
			local v284 = v_u_17 == nil and 0 or v_u_10.blend(v_u_15, v283)
			if v_u_17 == nil or v284 <= 0 then
				if v_u_23 then
					v_u_198()
				end
			else
				v_u_212(v_u_17, v284)
			end
		end
	end
end
return v_u_7