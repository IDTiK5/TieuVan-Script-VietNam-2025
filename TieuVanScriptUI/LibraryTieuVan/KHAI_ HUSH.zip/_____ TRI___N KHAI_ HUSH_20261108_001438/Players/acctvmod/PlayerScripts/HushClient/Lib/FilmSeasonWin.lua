-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmSeasonWin

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
local v_u_6 = script
if v_u_6 then
	v_u_6 = script.Parent
end
function v_u_4._setPlayer(p7) -- name: _setPlayer
	-- upvalues: (ref) v_u_5
	v_u_5 = p7
end
v_u_4.MIN_FINISH_DAYS = 20
v_u_4.ANSWER_MAX = 160
function v_u_4.texts(p8) -- name: texts
	-- upvalues: (copy) v_u_4
	if type(p8) ~= "table" then
		return {
			["start"] = "reading ...",
			["end"] = "reading ...",
			["source"] = "READING",
			["sourceKind"] = "info",
			["length"] = "",
			["default"] = "",
			["who"] = "",
			["warn"] = nil
		}
	end
	local v9 = p8.source == "stored"
	local v10 = p8.days
	local v11 = tonumber(v10) or 0
	local v12
	if v9 then
		local v13 = p8.byName
		local v14
		if type(v13) == "string" then
			v14 = v13 ~= ""
		else
			v14 = false
		end
		local v15 = not v14 and "Set by the owner" or "Set by " .. p8.byName
		local v16 = p8.v
		local v17
		if (tonumber(v16) or 0) > 0 then
			local v18 = p8.v
			local v19 = tonumber(v18)
			local v20 = math.floor(v19)
			v17 = ", version " .. tostring(v20)
		else
			v17 = ""
		end
		v12 = v15 .. v17
	else
		v12 = ""
	end
	local v21 = p8.stale == true and "No good read of the setting for 15 minutes: this server uses the built in window until it can read it again." or (p8.good ~= true and p8.studio ~= true and "This server has no good read of the setting yet: it uses the built in window until it reads it." or nil)
	local v22
	if v11 > 0 and v11 < v_u_4.MIN_FINISH_DAYS then
		v22 = ("Warning: %d days is shorter than the %d days that earning every tier needs. The last tiers, also on the paid CLASSIFIED track, can then only be reached with bought skips."):format(math.floor(v11), v_u_4.MIN_FINISH_DAYS)
		if v21 then
			v22 = v21 .. " " .. v22
		end
	else
		v22 = v21
	end
	local v23 = {}
	local v24 = p8.startText
	local v25
	if type(v24) == "string" then
		v25 = v24 ~= ""
	else
		v25 = false
	end
	v23.start = not v25 and "unknown" or p8.startText
	local v26 = p8.endText
	local v27
	if type(v26) == "string" then
		v27 = v26 ~= ""
	else
		v27 = false
	end
	v23["end"] = not v27 and "unknown" or p8.endText
	v23.source = v9 and "SET BY OWNER" or "BUILT IN"
	v23.sourceKind = v9 and "warn" or "info"
	local v28
	if v11 > 0 then
		local v29 = math.floor(v11)
		v28 = tostring(v29) .. (v11 == 1 and " day" or " days")
	else
		v28 = ""
	end
	v23.length = v28
	local v30 = p8.defaultStartText
	local v31
	if type(v30) == "string" then
		v31 = v30 ~= ""
	else
		v31 = false
	end
	local v32
	if v31 then
		local v33 = p8.defaultEndText
		local v34
		if type(v33) == "string" then
			v34 = v33 ~= ""
		else
			v34 = false
		end
		v32 = not v34 and "" or "Built in: " .. p8.defaultStartText .. " to " .. p8.defaultEndText
	else
		v32 = ""
	end
	v23.default = v32
	v23.who = v12
	v23.warn = v22
	return v23
end
function v_u_4.precheck(p35, p36, p37, p38) -- name: precheck
	if type(p37) == "table" then
		local v39, v40 = p37.parse(p35)
		if v39 == nil then
			return false, "Start: " .. tostring(v40)
		else
			local v41, v42 = p37.parse(p36)
			if v41 == nil then
				return false, "End: " .. tostring(v42)
			else
				local v43, v44 = p37.validate(v39, v41, p38)
				if v43 then
					return true, ""
				else
					return false, tostring(v44)
				end
			end
		end
	else
		return true, ""
	end
end
v_u_4.PAD = 10
v_u_4.GAP = 8
function v_u_4.layout(p45, p46) -- name: layout
	local v47 = (type(p45) ~= "number" or (p45 ~= p45 or p45 <= 0)) and 438 or math.floor(p45)
	local v49 = type(p46) ~= "function" and function(p48)
		return p48
	end or p46
	local v50 = v49(38)
	local v51 = math.max(v50, 38)
	local v52 = v49(36)
	local v53 = math.max(v52, 36)
	local v54 = {}
	local v55 = 0
	v54.caption = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 22,
		["y"] = v55,
		["w"] = v47
	}
	local v56 = v55 + 26
	local v57 = v47 < 460
	local v58 = v47 - 20
	local v59 = 10
	v54.card = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 0,
		["y"] = v56,
		["w"] = v47
	}
	local v60
	if v57 then
		v54.startTile = {
			["x"] = 10,
			["y"] = nil,
			["w"] = nil,
			["h"] = 54,
			["y"] = v59,
			["w"] = v58
		}
		local v61 = v59 + 62
		v54.endTile = {
			["x"] = 10,
			["y"] = nil,
			["w"] = nil,
			["h"] = 54,
			["y"] = v61,
			["w"] = v58
		}
		v60 = v61 + 62
	else
		local v62 = (v58 - 8) / 2
		local v63 = math.floor(v62)
		v54.startTile = {
			["x"] = 10,
			["y"] = nil,
			["w"] = nil,
			["h"] = 54,
			["y"] = v59,
			["w"] = v63
		}
		v54.endTile = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 54,
			["x"] = v63 + 10 + 8,
			["y"] = v59,
			["w"] = v58 - v63 - 8
		}
		v60 = v59 + 62
	end
	v54.badge = {
		["x"] = 10,
		["y"] = nil,
		["w"] = 112,
		["h"] = 20,
		["y"] = v60
	}
	v54.length = {
		["x"] = 130,
		["y"] = nil,
		["w"] = nil,
		["h"] = 20,
		["y"] = v60,
		["w"] = v58 - 112 - 8
	}
	local v64 = v60 + 24
	v54.default = {
		["x"] = 10,
		["y"] = nil,
		["w"] = nil,
		["h"] = 24,
		["y"] = v64,
		["w"] = v58
	}
	local v65 = v64 + 24
	v54.who = {
		["x"] = 10,
		["y"] = nil,
		["w"] = nil,
		["h"] = 24,
		["y"] = v65,
		["w"] = v58
	}
	local v66 = v65 + 24
	v54.warn = {
		["x"] = 10,
		["y"] = nil,
		["w"] = nil,
		["h"] = 88,
		["y"] = v66,
		["w"] = v58
	}
	local v67 = v66 + 98
	v54.card.h = v67
	local v68 = v56 + (v67 + 8)
	local v69
	if v57 then
		v54.startLabel = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 18,
			["y"] = v68,
			["w"] = v47
		}
		local v70 = v68 + 18
		v54.startInput = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v70,
			["w"] = v47,
			["h"] = v51
		}
		local v71 = v70 + (v51 + 8)
		v54.endLabel = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 18,
			["y"] = v71,
			["w"] = v47
		}
		local v72 = v71 + 18
		v54.endInput = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v72,
			["w"] = v47,
			["h"] = v51
		}
		v69 = v72 + (v51 + 8)
	else
		local v73 = (v47 - 8) / 2
		local v74 = math.floor(v73)
		v54.startLabel = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 18,
			["y"] = v68,
			["w"] = v74
		}
		v54.endLabel = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 18,
			["x"] = v74 + 8,
			["y"] = v68,
			["w"] = v47 - v74 - 8
		}
		local v75 = v68 + 18
		v54.startInput = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v75,
			["w"] = v74,
			["h"] = v51
		}
		v54.endInput = {
			["x"] = v74 + 8,
			["y"] = v75,
			["w"] = v47 - v74 - 8,
			["h"] = v51
		}
		v69 = v75 + (v51 + 8)
	end
	local v76
	if v47 < 340 then
		v54.apply = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v69,
			["w"] = v47,
			["h"] = v53
		}
		local v77 = v69 + (v53 + 8)
		v54.reset = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v77,
			["w"] = v47,
			["h"] = v53
		}
		v76 = v77 + (v53 + 8)
	else
		local v78 = (v47 - 8) * 0.4
		local v79 = math.floor(v78)
		local v80 = math.min(160, v79)
		v54.apply = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v69,
			["w"] = v80,
			["h"] = v53
		}
		local v81 = {
			["x"] = v80 + 8,
			["y"] = v69
		}
		local v82 = v47 - v80 - 8
		v81.w = math.min(v82, 240)
		v81.h = v53
		v54.reset = v81
		v76 = v69 + (v53 + 8)
	end
	v54.answer = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 48,
		["y"] = v76,
		["w"] = v47
	}
	local v83 = v76 + 52
	v54.note = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 104,
		["y"] = v83,
		["w"] = v47
	}
	return {
		["width"] = v47,
		["height"] = v83 + 104,
		["stacked"] = v57,
		["r"] = v54
	}
end
function v_u_4.fits(p84) -- name: fits
	local v85 = p84.r
	local v86 = {}
	local v87 = {
		["startTile"] = true,
		["endTile"] = true,
		["badge"] = true,
		["length"] = true,
		["default"] = true,
		["who"] = true,
		["warn"] = true
	}
	for v88, v89 in v85 do
		if v89.w <= 0 or v89.h <= 0 then
			local v90 = v88 .. " is empty"
			table.insert(v86, v90)
		end
		if v89.x < 0 or (v89.y < 0 or (v89.x + v89.w > p84.width or v89.y + v89.h > p84.height)) then
			local v91 = v88 .. " leaves the block"
			table.insert(v86, v91)
		end
		if not v87[v88] or v89.x >= 10 and (v89.x + v89.w <= v85.card.w - 10 and (v89.y >= 10 and v89.y + v89.h <= v85.card.h - 10)) then
			continue
		end
		local v92 = v88 .. " leaves the card"
		table.insert(v86, v92)
	end
	local v93 = {}
	local v94 = {}
	for v95 in v85 do
		local v96
		if v87[v95] then
			v96 = v93
		else
			v96 = v94
		end
		table.insert(v96, v95)
	end
	table.sort(v94)
	table.sort(v93)
	for _, v97 in { v94, v93 } do
		for v98 = 1, #v97 do
			for v99 = v98 + 1, #v97 do
				local v100 = v85[v97[v98]]
				local v101 = v85[v97[v99]]
				local v102
				if v100.x < v101.x + v101.w and (v101.x < v100.x + v100.w and v100.y < v101.y + v101.h) then
					v102 = v101.y < v100.y + v100.h
				else
					v102 = false
				end
				if not v102 then
					continue
				end
				local v103 = v97[v98] .. " overlaps " .. v97[v99]
				table.insert(v86, v103)
			end
		end
	end
	return #v86 == 0, v86
end
function v_u_4.mount(p_u_104, p_u_105, p_u_106, p107) -- name: mount
	-- upvalues: (ref) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
	if v_u_5 == nil or v_u_5:GetAttribute("FilmAllowed") ~= true then
		return nil
	end
	local v_u_108 = require(v_u_6:WaitForChild("HushUI"))
	local v_u_109 = type(p107) ~= "table" and {} or p107
	if type(p_u_106) == "table" then
		local v110 = p_u_106.color
		if type(v110) ~= "table" then
			p_u_106 = v_u_108.Theme
		end
	else
		p_u_106 = v_u_108.Theme
	end
	local v_u_111 = p_u_106.color
	local v112 = v_u_109.inner
	local v113 = type(v112) ~= "number" and 438 or v_u_109.inner
	local v_u_114 = v_u_109.gui
	local v_u_115 = "SeasonWindowRules"
	local function v116()
		-- upvalues: (ref) v_u_2, (copy) v_u_115
		return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_115, 5)))
	end
	local v117, v_u_118 = pcall(v116)
	if not v117 then
		v_u_118 = nil
	end
	local function v121(p119)
		-- upvalues: (copy) p_u_106
		local v120 = p_u_106.touch
		if type(v120) == "function" then
			return p_u_106.touch(p119)
		else
			return p119
		end
	end
	local v_u_122 = true
	if v_u_114 then
		v_u_114.Destroying:Connect(function()
			-- upvalues: (ref) v_u_122
			v_u_122 = false
		end)
	end
	local v123 = v_u_4.layout(v113, v121)
	local v124 = v123.r
	local v_u_125 = v_u_108.new("Frame", {
		["Name"] = "SeasonWinBlock",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v123.height)
	}, p_u_104)
	local v126 = v_u_109.order
	if type(v126) == "function" then
		v_u_125.LayoutOrder = v_u_109.order()
	end
	local v127 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinCaption",
		["text"] = "BATTLE PASS WINDOW  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_125,
		["color"] = v_u_111.accent,
		["size"] = UDim2.fromOffset(v124.caption.w, v124.caption.h)
	})
	local v128 = v124.caption
	v127.Position = UDim2.fromOffset(v128.x, v128.y)
	v127.Size = UDim2.fromOffset(v128.w, v128.h)
	local v_u_129 = v_u_108.new("Frame", {
		["Name"] = "SeasonWinCard",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v_u_111.raised
	}, v_u_125)
	local v130 = v124.card
	v_u_129.Position = UDim2.fromOffset(v130.x, v130.y)
	v_u_129.Size = UDim2.fromOffset(v130.w, v130.h)
	v_u_108.corner(v_u_129, 6)
	v_u_108.stroke(v_u_129, v_u_111.line)
	local function v135(p131, p132, p133) -- name: tile
		-- upvalues: (copy) v_u_108, (copy) v_u_111, (copy) v_u_129
		local v134 = v_u_108.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Name"] = p131,
			["BackgroundColor3"] = v_u_111.bg
		}, v_u_129)
		v134.Position = UDim2.fromOffset(p133.x, p133.y)
		v134.Size = UDim2.fromOffset(p133.w, p133.h)
		v_u_108.corner(v134, 4)
		v_u_108.stroke(v134, v_u_111.line, 1, 0.5)
		v_u_108.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v134,
			["name"] = p131 .. "Caption",
			["text"] = p132,
			["color"] = v_u_111.muted,
			["position"] = UDim2.fromOffset(10, 6),
			["size"] = UDim2.fromOffset(p133.w - 20, 14)
		})
		return v_u_108.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = "reading ...",
			["style"] = "monoL",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v134,
			["name"] = p131 .. "Value",
			["color"] = v_u_111.text,
			["position"] = UDim2.fromOffset(10, 24),
			["size"] = UDim2.fromOffset(p133.w - 20, 24)
		})
	end
	local v_u_136 = v135("SeasonWinStart", "STARTS", v124.startTile)
	local v_u_137 = v135("SeasonWinEnd", "ENDS", v124.endTile)
	local v_u_138 = v_u_108.new("Frame", {
		["Name"] = "SeasonWinBadgeHolder",
		["BackgroundTransparency"] = 1
	}, v_u_129)
	local v139 = v124.badge
	v_u_138.Position = UDim2.fromOffset(v139.x, v139.y)
	v_u_138.Size = UDim2.fromOffset(v139.w, v139.h)
	local v_u_140 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinLength",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_129,
		["color"] = v_u_111.text2,
		["size"] = UDim2.fromOffset(v124.length.w, v124.length.h)
	})
	local v141 = v124.length
	v_u_140.Position = UDim2.fromOffset(v141.x, v141.y)
	v_u_140.Size = UDim2.fromOffset(v141.w, v141.h)
	local v_u_142 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinDefault",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_129,
		["color"] = v_u_111.muted,
		["size"] = UDim2.fromOffset(v124.default.w, v124.default.h)
	})
	local v143 = v124.default
	v_u_142.Position = UDim2.fromOffset(v143.x, v143.y)
	v_u_142.Size = UDim2.fromOffset(v143.w, v143.h)
	local v_u_144 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinWho",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_129,
		["color"] = v_u_111.muted,
		["size"] = UDim2.fromOffset(v124.who.w, v124.who.h)
	})
	local v145 = v124.who
	v_u_144.Position = UDim2.fromOffset(v145.x, v145.y)
	v_u_144.Size = UDim2.fromOffset(v145.w, v145.h)
	local v_u_146 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinWarn",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["parent"] = v_u_129,
		["color"] = v_u_111.danger,
		["size"] = UDim2.fromOffset(v124.warn.w, v124.warn.h)
	})
	local v147 = v124.warn
	v_u_146.Position = UDim2.fromOffset(v147.x, v147.y)
	v_u_146.Size = UDim2.fromOffset(v147.w, v147.h)
	v_u_146.TextYAlignment = Enum.TextYAlignment.Top
	local function v152(p148, p149, p150) -- name: fieldLabel
		-- upvalues: (copy) v_u_108, (copy) v_u_125, (copy) v_u_111
		local v151 = v_u_108.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_125,
			["name"] = p148,
			["text"] = p149,
			["color"] = v_u_111.text2,
			["size"] = UDim2.fromOffset(p150.w, p150.h)
		})
		v151.Position = UDim2.fromOffset(p150.x, p150.y)
		v151.Size = UDim2.fromOffset(p150.w, p150.h)
	end
	v152("SeasonWinStartCaption", "New start (YYYY-MM-DD HH:MM UTC)", v124.startLabel)
	v152("SeasonWinEndCaption", "New end (YYYY-MM-DD HH:MM UTC)", v124.endLabel)
	local v153, v_u_154 = v_u_108.input({
		["parent"] = nil,
		["name"] = "SeasonWinStartInput",
		["placeholder"] = "2026-10-23 18:00 UTC",
		["width"] = nil,
		["text"] = "",
		["maxLength"] = 30,
		["parent"] = v_u_125,
		["width"] = v124.startInput.w
	})
	local v155 = v124.startInput
	v153.Position = UDim2.fromOffset(v155.x, v155.y)
	v153.Size = UDim2.fromOffset(v155.w, v155.h)
	local v156, v_u_157 = v_u_108.input({
		["parent"] = nil,
		["name"] = "SeasonWinEndInput",
		["placeholder"] = "2026-12-04 18:00 UTC",
		["width"] = nil,
		["text"] = "",
		["maxLength"] = 30,
		["parent"] = v_u_125,
		["width"] = v124.endInput.w
	})
	local v158 = v124.endInput
	v156.Position = UDim2.fromOffset(v158.x, v158.y)
	v156.Size = UDim2.fromOffset(v158.w, v158.h)
	local v_u_159 = nil
	local v_u_160 = false
	local v_u_161 = 0
	local v_u_162 = (-1 / 0)
	local v_u_163 = nil
	local v_u_164 = nil
	local function v_u_185(p165, p_u_166) -- name: act
		-- upvalues: (ref) v_u_160, (copy) p_u_105, (ref) v_u_161, (ref) v_u_4, (copy) v_u_108, (ref) v_u_163, (copy) v_u_111, (ref) v_u_122, (ref) v_u_162, (ref) v_u_159, (ref) v_u_164, (copy) v_u_109
		if v_u_160 then
			return
		else
			local v167 = p_u_105
			if type(v167) == "function" then
				v_u_160 = true
				local v_u_168 = os.clock()
				v_u_161 = v_u_168
				task.delay(20, function()
					-- upvalues: (ref) v_u_160, (ref) v_u_161, (copy) v_u_168
					if v_u_160 and v_u_161 == v_u_168 then
						v_u_160 = false
					end
				end)
				if not p_u_166 then
					local v169 = tostring("Working ...")
					if #v169 > v_u_4.ANSWER_MAX then
						local v170 = v_u_4.ANSWER_MAX
						v169 = string.sub(v169, 1, v170)
					end
					v_u_108.setText(v_u_163, v169)
					v_u_163.TextColor3 = v_u_111.text2
				end
				local function v182(p171) -- name: done
					-- upvalues: (ref) v_u_161, (copy) v_u_168, (ref) v_u_160, (ref) v_u_122, (ref) v_u_162, (ref) v_u_159, (copy) p_u_166, (ref) v_u_4, (ref) v_u_108, (ref) v_u_163, (ref) v_u_111, (ref) v_u_164
					if v_u_161 == v_u_168 then
						v_u_160 = false
					end
					if v_u_122 then
						v_u_162 = os.clock()
						if type(p171) == "table" then
							local v172 = p171.data
							if type(v172) == "table" then
								v_u_159 = p171.data
							end
							if not p_u_166 then
								local v173 = p171.msg or (p171.ok and "Done." or "Refused.")
								local v174 = tostring(v173)
								local v175 = p171.ok ~= true
								local v176 = tostring(v174)
								if #v176 > v_u_4.ANSWER_MAX then
									local v177 = v_u_4.ANSWER_MAX
									v176 = string.sub(v176, 1, v177)
								end
								v_u_108.setText(v_u_163, v176)
								local v178 = v_u_163
								local v179
								if v175 then
									v179 = v_u_111.danger
								else
									v179 = v_u_111.text2
								end
								v178.TextColor3 = v179
							end
						elseif not p_u_166 then
							local v180 = tostring("The server did not answer.")
							if #v180 > v_u_4.ANSWER_MAX then
								local v181 = v_u_4.ANSWER_MAX
								v180 = string.sub(v180, 1, v181)
							end
							v_u_108.setText(v_u_163, v180)
							v_u_163.TextColor3 = v_u_111.danger
						end
						v_u_164(v_u_159)
					end
				end
				local v183
				if p_u_166 then
					local v184 = v_u_109.sendQuiet
					if type(v184) == "function" then
						v183 = v_u_109.sendQuiet
						v183("season.window", p165, v182)
					else
						v183 = p_u_105
						v183("season.window", p165, v182)
					end
				else
					v183 = p_u_105
					v183("season.window", p165, v182)
					return
				end
			else
				return
			end
		end
	end
	local function v186() -- name: refresh
		-- upvalues: (copy) v_u_185
		v_u_185({
			["cmd"] = "status"
		}, true)
	end
	local function v_u_193(p187, p188) -- name: apply
		-- upvalues: (ref) v_u_4, (copy) v_u_118, (copy) v_u_108, (ref) v_u_163, (copy) v_u_111, (copy) v_u_185
		local v189, v190 = v_u_4.precheck(p187, p188, v_u_118, os.time())
		if v189 then
			v_u_185({
				["cmd"] = "set",
				["start"] = p187,
				["end"] = p188
			})
		else
			local v191 = tostring(v190)
			if #v191 > v_u_4.ANSWER_MAX then
				local v192 = v_u_4.ANSWER_MAX
				v191 = string.sub(v191, 1, v192)
			end
			v_u_108.setText(v_u_163, v191)
			v_u_163.TextColor3 = v_u_111.danger
		end
	end
	local v194 = v_u_108.button({
		["parent"] = nil,
		["text"] = "APPLY",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_125,
		["height"] = v124.apply.h,
		["width"] = v124.apply.w,
		["maxTextWidth"] = v124.apply.w - 24,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_193, (copy) v_u_154, (copy) v_u_157
			v_u_193(v_u_154.Text, v_u_157.Text)
		end
	})
	v194.Name = "SeasonWinApply"
	local v195 = v124.apply
	v194.Position = UDim2.fromOffset(v195.x, v195.y)
	v194.Size = UDim2.fromOffset(v195.w, v195.h)
	local v196 = v_u_108.button({
		["parent"] = nil,
		["text"] = "RESET TO DEFAULT",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_125,
		["height"] = v124.reset.h,
		["width"] = v124.reset.w,
		["maxTextWidth"] = v124.reset.w - 24,
		["onClick"] = function() -- name: resetDefault
			-- upvalues: (copy) v_u_185
			v_u_185({
				["cmd"] = "reset"
			})
		end
	})
	v196.Name = "SeasonWinReset"
	local v197 = v124.reset
	v196.Position = UDim2.fromOffset(v197.x, v197.y)
	v196.Size = UDim2.fromOffset(v197.w, v197.h)
	v_u_163 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["parent"] = v_u_125,
		["color"] = v_u_111.text2,
		["size"] = UDim2.fromOffset(v124.answer.w, v124.answer.h)
	})
	local v198 = v_u_163
	local v199 = v124.answer
	v198.Position = UDim2.fromOffset(v199.x, v199.y)
	v198.Size = UDim2.fromOffset(v199.w, v199.h)
	v_u_163.TextYAlignment = Enum.TextYAlignment.Top
	local v200 = v_u_108.label({
		["parent"] = nil,
		["name"] = "SeasonWinNote",
		["text"] = "The pass day starts at the time of day of the start. Moving the start moves the day change, the week change and the missions of the next day. Banked XP, bought tiers and claimed rewards are never lost. Players see the new dates the next time they open the pass.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["parent"] = v_u_125,
		["color"] = v_u_111.muted,
		["size"] = UDim2.fromOffset(v124.note.w, v124.note.h)
	})
	local v201 = v124.note
	v200.Position = UDim2.fromOffset(v201.x, v201.y)
	v200.Size = UDim2.fromOffset(v201.w, v201.h)
	v200.TextYAlignment = Enum.TextYAlignment.Top
	local v_u_202 = nil
	v_u_164 = function(p203)
		-- upvalues: (ref) v_u_4, (copy) v_u_108, (copy) v_u_136, (copy) v_u_137, (ref) v_u_202, (copy) v_u_138, (copy) v_u_140, (copy) v_u_142, (copy) v_u_144, (copy) v_u_146, (copy) v_u_154, (copy) v_u_157, (ref) v_u_5
		local v204 = v_u_4.texts(p203)
		v_u_108.setText(v_u_136, v204.start)
		v_u_108.setText(v_u_137, v204["end"])
		if v_u_202 then
			v_u_202:Destroy()
		end
		local v205 = {
			["parent"] = nil,
			["name"] = "SeasonWinBadge",
			["parent"] = v_u_138
		}
		v_u_202 = v_u_108.badge(v204.source, v204.sourceKind, v205)
		v_u_108.setText(v_u_140, v204.length)
		v_u_108.setText(v_u_142, v204.default)
		v_u_108.setText(v_u_144, v204.who)
		v_u_108.setText(v_u_146, v204.warn or "")
		if type(p203) == "table" and (not v_u_154:IsFocused() and (not v_u_157:IsFocused() and (v_u_154.Text == "" and v_u_157.Text == ""))) then
			v_u_154.PlaceholderText = v204.start
			v_u_157.PlaceholderText = v204["end"]
		end
		if v_u_5 then
			v_u_5:SetAttribute("FilmSeasonWin", ("src=%s|start=%s|end=%s"):format(type(p203) == "table" and p203.source == "stored" and "stored" or "default", v204.start, v204["end"]))
		end
	end
	v_u_164(nil)
	if v_u_3:IsStudio() and v_u_5 then
		local v_u_209 = v_u_5:GetAttributeChangedSignal("FilmSeasonCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_185, (copy) v_u_193
			local v206 = v_u_5:GetAttribute("FilmSeasonCmd")
			if type(v206) == "string" and v206 ~= "" then
				v_u_5:SetAttribute("FilmSeasonCmd", nil)
				if v206 == "status" then
					v_u_185({
						["cmd"] = "status"
					}, true)
					return
				elseif v206 == "reset" then
					v_u_185({
						["cmd"] = "reset"
					})
				else
					local v207, v208 = string.match(v206, "^set%s+(.-)|(.+)$")
					if v207 and v208 then
						v_u_193(v207, v208)
					end
				end
			else
				return
			end
		end)
		if v_u_114 then
			v_u_114.Destroying:Connect(function()
				-- upvalues: (copy) v_u_209
				v_u_209:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_122, (copy) v_u_114, (copy) p_u_104, (ref) v_u_160, (ref) v_u_162, (copy) v_u_185
		local v210 = false
		while v_u_122 do
			local v211 = v_u_114 == nil or v_u_114.Enabled
			if v211 then
				v211 = p_u_104.Visible
			end
			if v211 and (not v_u_160 and (not v210 or os.clock() - v_u_162 >= 5)) then
				v_u_162 = os.clock()
				v_u_185({
					["cmd"] = "status"
				}, true)
			end
			task.wait(0.5)
			v210 = v211
		end
	end)
	return {
		["refresh"] = v186,
		["paint"] = function(p212) -- name: paint
			-- upvalues: (ref) v_u_159, (ref) v_u_164
			v_u_159 = p212
			v_u_164(p212)
		end
	}
end
return v_u_4