-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUICtxClamp

local v_u_45 = {
	["GAP"] = 8,
	["at"] = function(p1, p2, p3, p4) -- name: at
		local v5 = p4.l or 0
		local v6 = math.max(0, v5)
		local v7 = p4.t or 0
		local v8 = math.max(0, v7)
		local v9 = p4.r or 0
		local v10 = math.max(0, v9)
		local v11 = p4.b or 0
		local v12 = math.max(0, v11)
		local v13 = p3.X - v6 - v10
		local v14 = math.max(1, v13)
		local v15 = p3.Y - v8 - v12
		local v16 = math.max(1, v15)
		local v17 = p2.X
		local v18 = math.min(v17, v14)
		local v19 = p2.Y
		local v20 = math.min(v19, v16)
		local v21 = p2.Y > v16 + 0.01
		local v22 = p1.X
		local v23
		if type(v22) == "number" and (v22 == v22 and v22 ~= (1 / 0)) then
			v23 = v22 ~= (-1 / 0)
		else
			v23 = false
		end
		local v24
		if v23 then
			v24 = p1.X
		else
			v24 = p3.X / 2
		end
		local v25 = p1.Y
		local v26
		if type(v25) == "number" and (v25 == v25 and v25 ~= (1 / 0)) then
			v26 = v25 ~= (-1 / 0)
		else
			v26 = false
		end
		local v27
		if v26 then
			v27 = p1.Y
		else
			v27 = p3.Y / 2
		end
		local v28 = v24 + 4
		if v28 + v18 > p3.X - v10 then
			v28 = v24 - 4 - v18
			if v6 > v28 then
				v28 = p3.X - v10 - v18
			end
		end
		local v29 = v27 + 4
		if v29 + v20 > p3.Y - v12 then
			v29 = v27 - 4 - v20
			if v8 > v29 then
				v29 = p3.Y - v12 - v20
			end
		end
		local v30 = p3.X - v10 - v18
		local v31 = math.max(v6, v30)
		local v32 = math.clamp(v28, v6, v31)
		local v33 = p3.Y - v12 - v20
		local v34 = math.max(v8, v33)
		return v32, math.clamp(v29, v8, v34), v20, v21
	end,
	["margins"] = function(p35, p36, p37, p38) -- name: margins
		-- upvalues: (copy) v_u_45
		local v39 = v_u_45.GAP
		local v40 = {}
		local v41 = (p35.l or 0) - p36.X + v39
		v40.l = math.max(v39, v41)
		local v42 = (p35.t or 0) - p36.Y + v39
		v40.t = math.max(v39, v42)
		local v43 = (p35.r or 0) - p37 + v39
		v40.r = math.max(v39, v43)
		local v44 = (p35.b or 0) - p38 + v39
		v40.b = math.max(v39, v44)
		return v40
	end
}
local function v_u_61(p46) -- name: overlayArea
	-- upvalues: (copy) v_u_45
	local v47 = game:GetService("GuiService")
	local v48 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
	local v_u_49 = require(v48:WaitForChild("Theme"))
	local v50 = require(script.Parent:WaitForChild("HushUI"))
	local v51 = v_u_49.uiScale()
	local v52 = v_u_49.viewport() / v51
	local v53 = v47:GetGuiInset() / v51
	local v_u_54 = false
	local function v55()
		-- upvalues: (ref) v_u_54, (copy) v_u_49
		v_u_54 = v_u_49.devViewport() ~= nil
	end
	pcall(v55)
	local v56
	if v_u_54 or (p46.AbsoluteSize.X < 50 or p46.AbsoluteSize.Y < 50) then
		v56 = Vector2.new(v52.X - v53.X, v52.Y - v53.Y)
	else
		v56 = p46.AbsoluteSize / v51
	end
	local v57 = v52.X - v53.X - v56.X
	local v58 = math.max(0, v57)
	local v59 = v52.Y - v53.Y - v56.Y
	local v60 = math.max(0, v59)
	return v56, v_u_45.margins(v50.safeInsets(), v53, v58, v60)
end
local function v_u_69(p62, p63) -- name: addScroll
	local v64 = Instance.new("ScrollingFrame")
	v64.Name = "RowScroll"
	v64.BackgroundTransparency = 1
	v64.BorderSizePixel = 0
	v64.Position = UDim2.fromOffset(0, 2)
	v64.Size = UDim2.new(1, 0, 1, -4)
	v64.CanvasSize = UDim2.fromOffset(0, p63 - 2)
	v64.ScrollingDirection = Enum.ScrollingDirection.Y
	v64.ScrollBarThickness = 3
	v64.ScrollBarImageColor3 = Color3.fromRGB(90, 96, 108)
	v64.VerticalScrollBarInset = Enum.ScrollBarInset.None
	v64.ElasticBehavior = Enum.ElasticBehavior.Never
	v64.ZIndex = 50
	v64.Parent = p62
	local v_u_65 = nil
	for _, v66 in p62:GetChildren() do
		if not v66:IsA("TextButton") then
			continue
		end
		v66.Position = v66.Position - UDim2.fromOffset(0, 2)
		v66.Parent = v64
		if v_u_65 ~= nil and v66.Position.Y.Offset >= v_u_65.Position.Y.Offset then
			continue
		end
		v_u_65 = v66
	end
	task.defer(function()
		-- upvalues: (ref) v_u_65
		local v67, v68 = pcall(function()
			return require(script.Parent:WaitForChild("HushUI"))
		end)
		if v67 and (v_u_65 and (v_u_65.Parent and v68.device() == "Gamepad")) then
			game:GetService("GuiService").SelectedObject = v_u_65
		end
	end)
end
function v_u_45.place(p70, p71, p72) -- name: place
	-- upvalues: (copy) v_u_61, (copy) v_u_45, (copy) v_u_69
	local v73 = Vector2.new(p70.Size.X.Offset, p70.Size.Y.Offset)
	local v74, v75 = v_u_61(p72)
	local v76, v77, v78, v79 = v_u_45.at(p71, v73, v74, v75)
	if v79 then
		p70.Size = UDim2.fromOffset(v73.X, v78)
		v_u_69(p70, v73.Y)
	end
	local v80 = v75.l
	local v81 = math.ceil(v80)
	local v82 = v75.t
	local v83 = math.ceil(v82)
	local v84 = v76 + 0.5
	local v85 = math.floor(v84)
	local v86 = v74.X - v75.r - v73.X
	local v87 = math.floor(v86)
	local v88 = math.max(v81, v87)
	local v89 = math.clamp(v85, v81, v88)
	local v90 = v77 + 0.5
	local v91 = math.floor(v90)
	local v92 = v74.Y - v75.b - v78
	local v93 = math.floor(v92)
	local v94 = math.max(v83, v93)
	local v95 = math.clamp(v91, v83, v94)
	p70.Position = UDim2.fromOffset(v89, v95)
	p70:SetAttribute("CtxArea", ("%d,%d"):format(v74.X, v74.Y))
end
return v_u_45