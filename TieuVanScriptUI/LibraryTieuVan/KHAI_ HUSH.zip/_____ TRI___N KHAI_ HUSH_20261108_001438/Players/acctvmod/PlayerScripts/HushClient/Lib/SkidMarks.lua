-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SkidMarks

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = require(script.Parent.SkidMarksPlan)
local v_u_5 = {}
local v_u_6 = v_u_4.TUNE
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = 0
local v_u_12 = {}
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = 0
local v_u_17 = {
	["active"] = 0,
	["drawn"] = 0,
	["recycled"] = 0,
	["rays"] = 0,
	["errors"] = 0
}
local function v_u_19() -- name: newPart
	local v18 = Instance.new("Part")
	v18.Name = "Skid"
	v18.Anchored = true
	v18.CanCollide = false
	v18.CanQuery = false
	v18.CanTouch = false
	v18.CastShadow = false
	v18.Massless = true
	v18.Locked = true
	v18.Material = Enum.Material.SmoothPlastic
	v18.Color = Color3.fromRGB(14, 14, 16)
	v18.TopSurface = Enum.SurfaceType.Smooth
	v18.BottomSurface = Enum.SurfaceType.Smooth
	return v18
end
local function v_u_25(p20) -- name: paramsFor
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_7, (ref) v_u_8
	if v_u_13 ~= nil and v_u_14 == p20 then
		return v_u_13
	end
	local v21 = RaycastParams.new()
	v21.FilterType = Enum.RaycastFilterType.Exclude
	local v22 = { p20 }
	if v_u_7 ~= nil and v_u_7.Character ~= nil then
		local v23 = v_u_7.Character
		table.insert(v22, v23)
	end
	local v24 = v_u_8
	if v24 == nil or v24.Parent == nil then
		v24 = Instance.new("Folder")
		v24.Name = "HushSkidMarks"
		v24.Parent = workspace
		v_u_8 = v24
	end
	table.insert(v22, v24)
	v21.FilterDescendantsInstances = v22
	v21.RespectCanCollide = true
	v21.IgnoreWater = false
	v_u_13 = v21
	v_u_14 = p20
	return v21
end
local function v_u_30() -- name: tick
	-- upvalues: (ref) v_u_16, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (copy) v_u_17, (ref) v_u_15
	local v26 = os.clock()
	if v26 >= v_u_16 then
		v_u_16 = v26 + 0.1
		local v27 = 0
		for _, v28 in v_u_9 do
			if not v28.busy then
				continue
			end
			local v29 = v26 - v28.bornAt
			if v_u_6.FADE_S <= v29 then
				v28.busy = false
				v28.part.Parent = nil
			else
				v27 = v27 + 1
				v28.part.Transparency = v_u_4.alpha(v29, v28.strength)
			end
		end
		v_u_17.active = v27
		if v27 == 0 and v_u_15 ~= nil then
			v_u_15:Disconnect()
			v_u_15 = nil
		end
	end
end
local function v_u_61(p31, p32, p33, p34) -- name: lay
	-- upvalues: (ref) v_u_10, (copy) v_u_3, (ref) v_u_11, (copy) v_u_4, (copy) v_u_9, (copy) v_u_19, (copy) v_u_17, (copy) v_u_6, (ref) v_u_8, (ref) v_u_15, (copy) v_u_2, (copy) v_u_30
	if v_u_10 == nil then
		local v35 = v_u_3.TouchEnabled
		if v35 then
			v35 = not v_u_3.KeyboardEnabled
		end
		v_u_11 = v_u_4.budget(v35)
		v_u_10 = v_u_4.ring(v_u_11)
	end
	local v36 = v_u_4.take(v_u_10)
	local v37 = v_u_9[v36]
	if v37 == nil then
		v37 = {
			["part"] = nil,
			["bornAt"] = 0,
			["strength"] = 1,
			["busy"] = false,
			["part"] = v_u_19()
		}
		v_u_9[v36] = v37
	elseif v37.busy then
		local v38 = v_u_17
		v38.recycled = v38.recycled + 1
	end
	local v39, v40, v41, v42, v43, v44, v45 = v_u_4.segment(p31.X, p31.Y, p31.Z, p32.X, p32.Y, p32.Z)
	if v42 > 0.0001 then
		local v46 = Vector3.new(v43, v44, v45)
		local v47 = p33.Magnitude <= 0.5 and Vector3.new(0, 1, 0) or p33.Unit
		local v48 = v_u_4.layerLift(v36)
		local v49 = Vector3.new(v39, v40, v41) + v47 * v48
		local v50 = v37.part
		local v51 = v_u_6.WIDTH
		local v52 = v_u_6.THICK
		local v53 = v42 + v_u_6.OVERLAP
		v50.Size = Vector3.new(v51, v52, v53)
		v37.part.CFrame = CFrame.lookAt(v49, v49 + v46, v47)
		v37.bornAt = os.clock()
		v37.strength = p34
		v37.busy = true
		v37.part.Transparency = v_u_4.alpha(0, p34)
		local v54 = v37.part
		local v55 = v_u_8
		if v55 == nil or v55.Parent == nil then
			v55 = Instance.new("Folder")
			v55.Name = "HushSkidMarks"
			v55.Parent = workspace
			v_u_8 = v55
		end
		v54.Parent = v55
		local v56 = v_u_17
		v56.drawn = v56.drawn + 1
		if v_u_15 == nil then
			v_u_15 = v_u_2.Heartbeat:Connect(function()
				-- upvalues: (ref) v_u_30, (ref) v_u_17
				local v57 = v_u_30
				local v58, v59 = pcall(v57)
				if not v58 then
					local v60 = v_u_17
					v60.errors = v60.errors + 1
					if v_u_17.errors <= 3 then
						warn("[SkidMarks] " .. "tick" .. " failed: " .. tostring(v59))
					end
				end
			end)
		end
	end
end
function v_u_5.step(_, p_u_62, p_u_63, p_u_64) -- name: step
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_25, (copy) v_u_6, (copy) v_u_17, (copy) v_u_61
	if type(p_u_62) == "table" and type(p_u_63) == "table" then
		local function v83()
			-- upvalues: (copy) p_u_64, (ref) v_u_4, (copy) p_u_63, (ref) v_u_12, (ref) v_u_25, (copy) p_u_62, (ref) v_u_6, (ref) v_u_17, (ref) v_u_61
			local v65 = p_u_64
			local v66 = type(v65) ~= "table" and {} or p_u_64
			local v67, v68 = v_u_4.mode({
				["speed"] = p_u_63.speed,
				["fwd"] = p_u_63.fwd,
				["latRear"] = p_u_63.latRear,
				["handbrake"] = v66.handbrake,
				["throttle"] = v66.throttle,
				["grounded"] = p_u_63.grounded
			})
			if v67 == nil then
				for v69 in v_u_12 do
					v_u_12[v69] = nil
				end
			else
				local v70 = {}
				for _, v71 in v_u_4.wheelsFor(v67) do
					v70[v71] = true
				end
				for v72 in v_u_12 do
					if v70[v72] then
						continue
					end
					v_u_12[v72] = nil
				end
				local v73 = v_u_25(p_u_62.model)
				local v74 = 0
				for _, v75 in p_u_62.wheels do
					if not v70[v75.name] or v74 >= v_u_6.MAX_PER_FRAME then
						continue
					end
					local v76 = v75.att.WorldPosition + Vector3.new(0, 0.6, 0)
					local v77 = v_u_17
					v77.rays = v77.rays + 1
					local v78 = workspace
					local v79 = -(v75.rayLen + 0.6 + 0.3)
					local v80 = v78:Raycast(v76, Vector3.new(0, v79, 0), v73)
					if v80 == nil or v80.Material == Enum.Material.Water then
						v_u_12[v75.name] = nil
					else
						local v81 = v_u_12[v75.name]
						if v81 == nil then
							v_u_12[v75.name] = v80.Position
						else
							local v82 = v_u_4.gate((v80.Position - v81).Magnitude)
							if v82 == "reset" then
								v_u_12[v75.name] = v80.Position
							else
								if v82 ~= "draw" then
									continue
								end
								v_u_61(v81, v80.Position, v80.Normal, v68)
								v74 = v74 + 1
								v_u_12[v75.name] = v80.Position
							end
						end
					end
				end
			end
		end
		local v84, v85 = pcall(v83)
		if not v84 then
			local v86 = v_u_17
			v86.errors = v86.errors + 1
			if v_u_17.errors <= 3 then
				warn("[SkidMarks] " .. "step" .. " failed: " .. tostring(v85))
			end
		end
	end
end
function v_u_5.stop() -- name: stop
	-- upvalues: (copy) v_u_12, (ref) v_u_13, (ref) v_u_14
	for v87 in v_u_12 do
		v_u_12[v87] = nil
	end
	v_u_13 = nil
	v_u_14 = nil
end
function v_u_5.clear() -- name: clear
	-- upvalues: (copy) v_u_9, (copy) v_u_17, (copy) v_u_5
	for _, v88 in v_u_9 do
		v88.busy = false
		v88.part.Parent = nil
	end
	v_u_17.active = 0
	v_u_5.stop()
end
function v_u_5.stats() -- name: stats
	-- upvalues: (copy) v_u_17, (ref) v_u_11
	return {
		["active"] = v_u_17.active,
		["pool"] = v_u_11,
		["drawn"] = v_u_17.drawn,
		["recycled"] = v_u_17.recycled,
		["rays"] = v_u_17.rays,
		["errors"] = v_u_17.errors
	}
end
return v_u_5