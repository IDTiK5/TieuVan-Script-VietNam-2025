-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GrenadeFx

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = {}
local v7 = v4:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_8 = require((v7:WaitForChild("GrenadeRules")))
local v_u_9 = require((v7:WaitForChild("Assets")))
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = 0
local v_u_22 = 0
local function v_u_26() -- name: ensureFolder
	-- upvalues: (ref) v_u_11, (copy) v_u_5
	local v23 = v_u_11
	if v23 and v23.Parent then
		return v23
	end
	local v24 = v_u_5:FindFirstChild("HushLocal")
	if not v24 then
		v24 = Instance.new("Folder")
		v24.Name = "HushLocal"
		v24.Parent = v_u_5
	end
	local v25 = v24:FindFirstChild("GrenadeFx")
	if not v25 then
		v25 = Instance.new("Folder")
		v25.Name = "GrenadeFx"
		v25.Parent = v24
	end
	v_u_11 = v25
	return v_u_11
end
local function v_u_31() -- name: ensureGui
	-- upvalues: (ref) v_u_13, (copy) v_u_2, (ref) v_u_14, (ref) v_u_15
	if v_u_13 and v_u_13.Parent then
		return
	else
		local v27 = v_u_2.LocalPlayer
		if v27 then
			v27 = v27:FindFirstChildOfClass("PlayerGui")
		end
		if v27 then
			local v28 = Instance.new("ScreenGui")
			v28.Name = "HushGrenadeFlash"
			v28.ResetOnSpawn = false
			v28.IgnoreGuiInset = true
			v28.DisplayOrder = 12
			v28.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
			local v29 = Instance.new("Frame")
			v29.Name = "SmokeHaze"
			v29.BackgroundColor3 = Color3.fromRGB(150, 152, 150)
			v29.BackgroundTransparency = 1
			v29.BorderSizePixel = 0
			v29.Size = UDim2.fromScale(1, 1)
			v29.Active = false
			v29.Visible = false
			v29.ZIndex = 1
			v29.Parent = v28
			local v30 = Instance.new("Frame")
			v30.Name = "White"
			v30.BackgroundColor3 = Color3.new(1, 1, 1)
			v30.BackgroundTransparency = 1
			v30.BorderSizePixel = 0
			v30.Size = UDim2.fromScale(1, 1)
			v30.Active = false
			v30.Visible = false
			v30.ZIndex = 2
			v30.Parent = v28
			v28.Parent = v27
			v_u_13 = v28
			v_u_14 = v30
			v_u_15 = v29
		end
	end
end
local function v_u_44(p_u_32) -- name: build
	-- upvalues: (copy) v_u_9
	local function v33()
		-- upvalues: (ref) v_u_9, (copy) p_u_32
		return v_u_9.get("Item", p_u_32)
	end
	local v34, v35 = pcall(v33)
	if not v34 or (typeof(v35) ~= "Instance" or not v35:IsA("Model")) then
		return nil, nil
	end
	for _, v36 in v35:GetDescendants() do
		if not v36:IsA("LuaSourceContainer") then
			continue
		end
		v36:Destroy()
	end
	local v37 = v35.PrimaryPart
	local v38 = -1
	if not v37 then
		for _, v39 in v35:GetDescendants() do
			if not v39:IsA("BasePart") then
				continue
			end
			local v40 = v39.Size.X * v39.Size.Y * v39.Size.Z
			if v38 >= v40 then
				continue
			end
			v37 = v39
			v38 = v40
		end
	end
	if not v37 then
		v35:Destroy()
		return nil, nil
	end
	for _, v41 in v35:GetDescendants() do
		if not v41:IsA("BasePart") then
			continue
		end
		v41.CanCollide = false
		v41.CanQuery = false
		v41.CanTouch = false
		v41.CastShadow = false
		v41.Massless = true
		if v41 == v37 then
			continue
		end
		v41.Anchored = false
		for _, v42 in v41:GetChildren() do
			if not (v42:IsA("WeldConstraint") or v42:IsA("Weld")) then
				continue
			end
			v42:Destroy()
		end
		local v43 = Instance.new("Weld")
		v43.Name = "Weld_" .. v41.Name
		v43.Part0 = v37
		v43.Part1 = v41
		v43.C0 = v37.CFrame:ToObjectSpace(v41.CFrame)
		v43.C1 = CFrame.new()
		v43.Parent = v41
	end
	v37.Anchored = true
	return v35, v37
end
function v_u_6.prop(p45) -- name: prop
	-- upvalues: (copy) v_u_8, (copy) v_u_44, (copy) v_u_26
	if not v_u_8.isGrenade(p45) then
		return nil, nil
	end
	local v46, v47 = v_u_44(p45)
	if not (v46 and v47) then
		return nil, nil
	end
	v46.Name = "Thrown_" .. p45
	v46.Parent = v_u_26()
	return v47, v46
end
function v_u_6.hold(p48, p49) -- name: hold
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_8, (copy) v_u_2, (copy) v_u_44
	if v_u_19 and (not p48 or p49 ~= v_u_20) then
		v_u_19:Destroy()
		v_u_19 = nil
		v_u_20 = nil
	end
	if p48 and (p49 and (v_u_8.isGrenade(p49) and not v_u_19)) then
		local v50 = v_u_2.LocalPlayer
		if v50 then
			v50 = v50.Character
		end
		local v51
		if v50 then
			v51 = v50:FindFirstChild("LeftHand") or v50:FindFirstChild("RightHand")
		else
			v51 = v50
		end
		if v51 then
			local v52, v53 = v_u_44(p49)
			if v52 and v53 then
				local v54
				if v52:GetAttribute("ImportedBy") ~= nil and true or v52:GetAttribute("FitScale") ~= nil then
					v54 = CFrame.new()
				else
					v54 = CFrame.Angles(0, 0, 1.5707963267948966)
				end
				v53.Anchored = false
				local v55 = Instance.new("Weld")
				v55.Part0 = v51
				v55.Part1 = v53
				v55.C0 = CFrame.new(0, -0.32, -0.12) * v54
				v55.Parent = v53
				v52.Name = "HeldGrenade"
				v52.Parent = v50
				v_u_19 = v52
				v_u_20 = p49
			end
		else
			return
		end
	else
		return
	end
end
function v_u_6.flashAlpha() -- name: flashAlpha
	-- upvalues: (ref) v_u_21
	return v_u_21
end
local function v_u_64(p56) -- name: flashLevel
	-- upvalues: (copy) v_u_16, (copy) v_u_8
	local v57 = 0
	for v58 = #v_u_16, 1, -1 do
		local v59 = v_u_16[v58]
		local v60 = p56 - v59.t0
		if v59.dur <= v60 then
			table.remove(v_u_16, v58)
		else
			local v61 = v_u_8.flashCurve
			local v62 = v59.dur
			local v63 = v59.f
			v57 = math.max(v57, v61(v60, v62, v63))
		end
	end
	return v57
end
local function v_u_71(p65) -- name: lightBurst
	-- upvalues: (copy) v_u_26
	local v66 = v_u_26()
	local v_u_67 = Instance.new("Part")
	v_u_67.Name = "FlashLight"
	v_u_67.Anchored = true
	v_u_67.CanCollide = false
	v_u_67.CanQuery = false
	v_u_67.CanTouch = false
	v_u_67.CastShadow = false
	v_u_67.Shape = Enum.PartType.Ball
	v_u_67.Material = Enum.Material.Neon
	v_u_67.Color = Color3.fromRGB(255, 252, 240)
	v_u_67.Size = Vector3.new(1.5, 1.5, 1.5)
	v_u_67.CFrame = CFrame.new(p65 + Vector3.new(0, 1.2, 0))
	local v_u_68 = Instance.new("PointLight")
	v_u_68.Color = Color3.fromRGB(255, 250, 235)
	v_u_68.Range = 60
	v_u_68.Brightness = 9
	v_u_68.Shadows = false
	v_u_68.Parent = v_u_67
	v_u_67.Parent = v66
	task.spawn(function()
		-- upvalues: (copy) v_u_67, (copy) v_u_68
		local v69 = os.clock()
		while true do
			local v70 = (os.clock() - v69) / 0.55
			if v70 >= 1 or not v_u_67.Parent then
				break
			end
			v_u_67.Size = Vector3.new(1, 1, 1) * (v70 * 9 + 1.5)
			v_u_67.Transparency = v70
			v_u_68.Brightness = (1 - v70) ^ 2 * 9
			task.wait()
		end
		v_u_67:Destroy()
	end)
end
local function v_u_77(p72, p73) -- name: emitter
	local v74 = Instance.new("ParticleEmitter")
	v74.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v74.LightEmission = 0
	v74.LightInfluence = 0.9
	v74.Rate = 0
	v74.Shape = Enum.ParticleEmitterShape.Box
	v74.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	v74.Rotation = NumberRange.new(0, 360)
	v74.RotSpeed = NumberRange.new(-12, 12)
	for v75, v76 in p73 do
		v74[v75] = v76
	end
	v74.Parent = p72
	return v74
end
local function v_u_81(p78, p79, p80) -- name: seq
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p78), NumberSequenceKeypoint.new(0.2, p79), NumberSequenceKeypoint.new(1, p80) })
end
local function v_u_91(p82) -- name: addCloud
	-- upvalues: (copy) v_u_17, (copy) v_u_1, (copy) v_u_8, (copy) v_u_77, (copy) v_u_81, (ref) v_u_10
	if not v_u_17[p82] then
		local v83 = {
			["part"] = nil,
			["start"] = nil,
			["life"] = nil,
			["radius"] = nil,
			["size"] = Vector3.new(0, 0, 0),
			["x"] = nil,
			["z"] = nil,
			["ground"] = nil,
			["part"] = p82,
			["start"] = tonumber(p82:GetAttribute("StartAt")) or v_u_1.now(),
			["life"] = tonumber(p82:GetAttribute("Life")) or v_u_8.SMOKE.life,
			["radius"] = tonumber(p82:GetAttribute("Radius")) or v_u_8.SMOKE.radius,
			["x"] = p82.Position.X,
			["z"] = p82.Position.Z,
			["ground"] = p82.Position.Y - 0.5
		}
		local v84 = v_u_77(p82, {
			["Name"] = "SmokeMain",
			["Color"] = nil,
			["Transparency"] = nil,
			["Size"] = nil,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["SpreadAngle"] = nil,
			["Acceleration"] = Vector3.new(0.3, 0.5, 0),
			["Color"] = ColorSequence.new(Color3.fromRGB(196, 198, 196), Color3.fromRGB(128, 130, 128)),
			["Transparency"] = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.15, 0.1),
				NumberSequenceKeypoint.new(0.75, 0.2),
				NumberSequenceKeypoint.new(1, 1)
			}),
			["Size"] = v_u_81(7, 10, 13),
			["Lifetime"] = NumberRange.new(5, 7),
			["Speed"] = NumberRange.new(0.2, 1.1),
			["SpreadAngle"] = Vector2.new(180, 180)
		})
		local v85 = v_u_77(p82, {
			["Name"] = "SmokeHaze",
			["Color"] = nil,
			["Transparency"] = nil,
			["Size"] = nil,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["SpreadAngle"] = nil,
			["ZOffset"] = -1,
			["Color"] = ColorSequence.new(Color3.fromRGB(176, 178, 176), Color3.fromRGB(140, 142, 140)),
			["Transparency"] = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.2, 0.26),
				NumberSequenceKeypoint.new(0.8, 0.36),
				NumberSequenceKeypoint.new(1, 1)
			}),
			["Size"] = v_u_81(11, 15, 18),
			["Lifetime"] = NumberRange.new(6, 8),
			["Speed"] = NumberRange.new(0.1, 0.6),
			["SpreadAngle"] = Vector2.new(180, 180)
		})
		local v_u_86 = v_u_77(p82, {
			["Name"] = "SmokeBurst",
			["Color"] = nil,
			["Transparency"] = nil,
			["Size"] = nil,
			["Lifetime"] = nil,
			["Speed"] = nil,
			["SpreadAngle"] = nil,
			["Drag"] = 2.2,
			["Color"] = ColorSequence.new(Color3.fromRGB(215, 215, 212), Color3.fromRGB(150, 152, 150)),
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.6, 0.45), NumberSequenceKeypoint.new(1, 1) }),
			["Size"] = v_u_81(4, 8, 11),
			["Lifetime"] = NumberRange.new(1.4, 2.2),
			["Speed"] = NumberRange.new(7, 13),
			["SpreadAngle"] = Vector2.new(180, 180)
		})
		v83.main = v84
		v83.low = v85
		v83.burst = v_u_86
		task.defer(function()
			-- upvalues: (copy) v_u_86
			if v_u_86.Parent then
				v_u_86:Emit(26)
			end
		end)
		local v87 = v_u_10 and v_u_10.controllers
		if v87 then
			v87 = v_u_10.controllers.Audio
		end
		if v87 and v87.loop then
			local v88 = v87.loop
			local v89, v90 = pcall(v88, "gren_smoke_loop", p82)
			if v89 then
				v83.loop = v90
			end
		end
		v_u_17[p82] = v83
	end
end
local function v_u_120() -- name: stepClouds
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_17, (copy) v_u_8
	local v92 = v_u_2.LocalPlayer
	if v92 then
		v92 = v92.Character
	end
	if v92 then
		v92 = v92:FindFirstChild("HumanoidRootPart")
	end
	local v93 = v_u_1.now()
	local v94 = 0
	for v95, v96 in v_u_17 do
		if v95.Parent then
			local v97 = v93 - v96.start
			local v98 = v_u_8.smokeRadius(v97) * (v96.radius / v_u_8.SMOKE.radius)
			local v99 = v_u_8.smokeStrength(v97)
			local v100 = v_u_8.SMOKE.height
			local v101 = v98 * 2
			local v102 = math.max(0.1, v101)
			local v103 = v98 * 2
			local v104 = math.max(0.1, v103)
			local v105 = Vector3.new(v102, v100, v104)
			if (v105 - v96.size).Magnitude > 0.05 then
				v95.Size = v105
				v95.CFrame = CFrame.new(v96.x, v96.ground + v105.Y / 2, v96.z)
				v96.size = v105
			end
			local v106 = v96.radius
			local v107 = (v98 / math.max(1, v106)) ^ 2
			v96.main.Rate = 30 * v99 * v107
			v96.low.Rate = 12 * v99 * v107
			if v96.life <= v97 then
				local v108 = v96.main
				local v109 = v96.low
				v108.Enabled = false
				v109.Enabled = false
			end
			if not v92 or v99 <= 0 then
				continue
			end
			local v110 = v92.Position.X - v95.Position.X
			local v111 = v92.Position.Z - v95.Position.Z
			local v112 = v110 * v110 + v111 * v111
			local v113 = math.sqrt(v112)
			if v98 <= 0.5 or v113 >= v98 then
				continue
			end
			local v114 = 1.15 - v113 / v98
			local v115 = v99 * math.clamp(v114, 0, 1)
			v94 = math.max(v94, v115)
		else
			local v116 = v_u_17[v95]
			v_u_17[v95] = nil
			if not v116 then
				continue
			end
			local v117 = v116.loop
			if type(v117) ~= "table" then
				continue
			end
			local v118 = v116.loop.stop
			if type(v118) ~= "function" then
				continue
			end
			local v119 = v116.loop.stop
			pcall(v119)
		end
	end
	return v94
end
function v_u_6.smokeAtMe() -- name: smokeAtMe
	-- upvalues: (ref) v_u_22
	return v_u_22
end
local function v_u_135(p121) -- name: watch
	-- upvalues: (copy) v_u_91, (copy) v_u_18, (copy) v_u_17
	local function v123(p122) -- name: consider
		-- upvalues: (ref) v_u_91
		if p122.Name == "SmokeCloud" and p122:IsA("BasePart") then
			v_u_91(p122)
		end
	end
	for _, v124 in p121:GetChildren() do
		if v124.Name ~= "SmokeCloud" or not v124:IsA("BasePart") then
			continue
		end
		v_u_91(v124)
	end
	local v125 = v_u_18
	local v126 = p121.ChildAdded
	table.insert(v125, v126:Connect(v123))
	local v127 = v_u_18
	local v128 = p121.ChildRemoved
	local function v134(p129)
		-- upvalues: (ref) v_u_17
		if p129:IsA("BasePart") then
			local v130 = v_u_17[p129]
			v_u_17[p129] = nil
			if v130 then
				local v131 = v130.loop
				if type(v131) == "table" then
					local v132 = v130.loop.stop
					if type(v132) == "function" then
						local v133 = v130.loop.stop
						pcall(v133)
					end
				end
			end
		end
	end
	table.insert(v127, v128:Connect(v134))
end
local function v_u_138() -- name: step
	-- upvalues: (ref) v_u_21, (copy) v_u_64, (copy) v_u_120, (ref) v_u_22, (ref) v_u_14, (ref) v_u_15
	v_u_21 = v_u_64((os.clock()))
	v_u_22 = v_u_22 + (v_u_120() - v_u_22) * 0.2
	if v_u_22 < 0.01 then
		v_u_22 = 0
	end
	if v_u_14 then
		v_u_14.Visible = v_u_21 > 0.004
		v_u_14.BackgroundTransparency = 1 - v_u_21
	end
	if v_u_15 then
		v_u_15.Visible = v_u_22 > 0.01
		local v136 = v_u_15
		local v137 = v_u_22 * 0.5
		v136.BackgroundTransparency = 1 - math.clamp(v137, 0, 0.5)
	end
end
v_u_6._step = v_u_138
function v_u_6.onFx(p139) -- name: onFx
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (copy) v_u_71, (ref) v_u_12, (copy) v_u_3, (copy) v_u_138, (copy) v_u_31, (copy) v_u_16, (copy) v_u_2
	if type(p139) == "table" then
		local v140 = p139.k
		if v140 == "throw" then
			if v_u_8.isGrenade(p139.id) then
				local v141 = p139.path
				if type(v141) == "table" then
					local v142 = p139.path[1]
					if typeof(v142) == "Vector3" then
						local v_u_143 = p139.path[1]
						local v144 = v_u_10 and v_u_10.controllers
						if v144 then
							v144 = v_u_10.controllers.Audio
						end
						if v144 and v144.play3D then
							local v145 = v144.play3D
							pcall(v145, "gren_pin", v_u_143, nil)
						end
						task.delay(0.22, function()
							-- upvalues: (copy) v_u_143, (ref) v_u_10
							local v146 = v_u_143
							local v147 = v_u_10 and v_u_10.controllers
							if v147 then
								v147 = v_u_10.controllers.Audio
							end
							if v147 and v147.play3D then
								local v148 = v147.play3D
								pcall(v148, "gren_spoon", v146, nil)
							end
						end)
						return
					end
				end
			end
		elseif v140 == "gland" then
			local v149 = p139.p
			if typeof(v149) == "Vector3" then
				local v150 = p139.p
				local v151 = v_u_10 and v_u_10.controllers
				if v151 then
					v151 = v_u_10.controllers.Audio
				end
				if v151 and v151.play3D then
					local v152 = v151.play3D
					pcall(v152, "gren_bounce", v150, nil)
					return
				end
			end
		elseif v140 == "flashbang" then
			local v153 = p139.p
			if typeof(v153) == "Vector3" then
				local v154 = p139.p
				local v155 = v_u_10 and v_u_10.controllers
				if v155 then
					v155 = v_u_10.controllers.Audio
				end
				if v155 and v155.play3D then
					local v156 = v155.play3D
					pcall(v156, "gren_flash", v154, nil)
				end
				v_u_71(p139.p)
				if not v_u_12 then
					v_u_12 = v_u_3.Heartbeat:Connect(v_u_138)
					return
				end
			end
		elseif v140 == "flashhit" then
			local v157 = p139.f
			local v158 = tonumber(v157)
			local v159 = p139.d
			local v160 = tonumber(v159)
			if v158 and (v160 and (v158 > 0 and v160 > 0)) then
				v_u_31()
				if not v_u_12 then
					v_u_12 = v_u_3.Heartbeat:Connect(v_u_138)
				end
				local v161 = v_u_16
				local v162 = {
					["t0"] = os.clock(),
					["dur"] = v160,
					["f"] = math.min(v158, 1)
				}
				table.insert(v161, v162)
				while #v_u_16 > 4 do
					table.remove(v_u_16, 1)
				end
				local v163 = v_u_10 and v_u_10.lib
				if v163 then
					v163 = v_u_10.lib.AudioEars
				end
				if v163 and v163.onBlast then
					local v164 = v163.onBlast
					local v165 = math.min(1, v158)
					pcall(v164, v165)
					return
				end
			end
		elseif v140 == "smokepop" then
			local v166 = p139.p
			if typeof(v166) == "Vector3" then
				local v167 = p139.p
				local v168 = v_u_10 and v_u_10.controllers
				if v168 then
					v168 = v_u_10.controllers.Audio
				end
				if v168 and v168.play3D then
					local v169 = v168.play3D
					pcall(v169, "gren_smoke_pop", v167, nil)
					return
				end
			end
		elseif v140 == "explode" and p139.g == "frag" then
			local v170 = p139.p
			if typeof(v170) == "Vector3" then
				local v171 = v_u_2.LocalPlayer
				if v171 then
					v171 = v171.Character
				end
				if v171 then
					v171 = v171:FindFirstChild("HumanoidRootPart")
				end
				local v172 = (not v171 and 100 or (p139.p - v171.Position).Magnitude) < 150 and "gren_frag" or "gren_frag_far"
				local v173 = p139.p
				local v174 = v_u_10 and v_u_10.controllers
				if v174 then
					v174 = v_u_10.controllers.Audio
				end
				if v174 and v174.play3D then
					local v175 = v174.play3D
					pcall(v175, v172, v173, nil)
				end
			end
		end
	end
end
function v_u_6.count() -- name: count
	-- upvalues: (copy) v_u_17, (copy) v_u_16
	local v176 = 0
	for _ in v_u_17 do
		v176 = v176 + 1
	end
	return v176, #v_u_16
end
function v_u_6.clear() -- name: clear
	-- upvalues: (copy) v_u_16, (copy) v_u_17, (copy) v_u_6, (ref) v_u_14, (ref) v_u_15, (ref) v_u_21, (ref) v_u_22
	table.clear(v_u_16)
	for v177 in v_u_17 do
		local v178 = v_u_17[v177]
		v_u_17[v177] = nil
		if not v178 then
			continue
		end
		local v179 = v178.loop
		if type(v179) ~= "table" then
			continue
		end
		local v180 = v178.loop.stop
		if type(v180) ~= "function" then
			continue
		end
		local v181 = v178.loop.stop
		pcall(v181)
	end
	v_u_6.hold(false)
	if v_u_14 then
		v_u_14.Visible = false
	end
	if v_u_15 then
		v_u_15.Visible = false
	end
	v_u_21 = 0
	v_u_22 = 0
end
function v_u_6.init(p182) -- name: init
	-- upvalues: (ref) v_u_10, (ref) v_u_12, (copy) v_u_3, (copy) v_u_138, (copy) v_u_5, (copy) v_u_135, (copy) v_u_18
	v_u_10 = p182
	if not v_u_12 then
		v_u_12 = v_u_3.Heartbeat:Connect(v_u_138)
	end
	local v183 = v_u_5:FindFirstChild("HushCombat")
	if v183 then
		v_u_135(v183)
	end
	local v184 = v_u_18
	local v185 = v_u_5.ChildAdded
	local function v187(p186)
		-- upvalues: (ref) v_u_135
		if p186.Name == "HushCombat" then
			v_u_135(p186)
		end
	end
	table.insert(v184, v185:Connect(v187))
end
return v_u_6