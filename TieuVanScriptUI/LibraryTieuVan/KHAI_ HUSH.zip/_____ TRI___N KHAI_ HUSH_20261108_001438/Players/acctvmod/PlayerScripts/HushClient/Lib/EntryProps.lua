-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryProps

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v3 = {}
local v_u_4 = v1.LocalPlayer
function v3.gfxQuality() -- name: gfxQuality
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v5 = v_u_4
	if v5 then
		v5 = v_u_4:GetAttribute("GfxQuality")
	end
	if type(v5) == "number" then
		return v5
	end
	local v_u_6 = false
	local function v8()
		-- upvalues: (ref) v_u_6, (ref) v_u_2
		local v7 = v_u_2.TouchEnabled
		if v7 then
			v7 = not v_u_2.KeyboardEnabled
		end
		v_u_6 = v7
	end
	pcall(v8)
	return v_u_6 and 1 or 3
end
local function v_u_16(p9, p10, ...) -- name: audioCall
	local v11 = p9 and p9.controllers
	if v11 then
		v11 = p9.controllers.Audio
	end
	if v11 and not v11._broken then
		local v12 = v11[p10]
		if type(v12) == "function" then
			local v13 = v11[p10]
			local v14, v15 = pcall(v13, ...)
			if v14 then
				return v15
			end
		end
	end
	return nil
end
function v3.new(p17, p18, p19) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v20 = {
		["cctx"] = nil,
		["folder"] = nil,
		["g"] = nil,
		["heli"] = nil,
		["heliDone"] = false,
		["ropes"] = nil,
		["ropeFolder"] = nil,
		["pickup"] = nil,
		["pickupDone"] = false,
		["pickupGround"] = nil,
		["pickupFx"] = nil,
		["PickupFx"] = nil,
		["dust"] = nil,
		["dustEmitter"] = nil,
		["sounds"] = nil,
		["quality"] = nil,
		["spin"] = 0,
		["t"] = 0,
		["cctx"] = p17,
		["folder"] = p18,
		["g"] = p19,
		["ropes"] = {},
		["sounds"] = {}
	}
	local v21 = v_u_4
	if v21 then
		v21 = v_u_4:GetAttribute("GfxQuality")
	end
	if type(v21) ~= "number" then
		local v_u_22 = false
		local function v24()
			-- upvalues: (ref) v_u_22, (ref) v_u_2
			local v23 = v_u_2.TouchEnabled
			if v23 then
				v23 = not v_u_2.KeyboardEnabled
			end
			v_u_22 = v23
		end
		pcall(v24)
		v21 = v_u_22 and 1 or 3
	end
	v20.quality = v21
	return v20
end
local function v_u_38(p_u_25) -- name: ensureHeli
	if p_u_25.heli or p_u_25.heliDone then
		return
	else
		local v26, v27 = pcall(function()
			-- upvalues: (copy) p_u_25
			return p_u_25.cctx.lib.HeliRig
		end)
		if v26 and v27 then
			local v28 = v27.create
			local v29 = p_u_25.cctx
			local v30 = p_u_25.folder
			local v31, v32 = pcall(v28, v29, v30, {
				["light"] = false,
				["sound"] = true
			})
			if v31 and v32 then
				p_u_25.heli = v32
				p_u_25.HeliRig = v27
				local v33 = v27.size
				local v34, v35 = pcall(v33, v32)
				if v34 and typeof(v35) == "Vector3" then
					local v36 = v35.X * 0.4
					p_u_25.doorX = math.clamp(v36, 1.8, 5)
				end
				for _, v37 in v32.model:GetDescendants() do
					if not v37:IsA("BasePart") then
						continue
					end
					v37.CastShadow = true
				end
			else
				p_u_25.heliDone = true
			end
		else
			p_u_25.heliDone = true
			return
		end
	end
end
local function v_u_43(p39, p40) -- name: makeRope
	if not p39.ropeFolder then
		local v41 = Instance.new("Folder")
		v41.Name = "Ropes"
		v41.Parent = p39.folder
		p39.ropeFolder = v41
	end
	local v42 = Instance.new("Part")
	v42.Name = "Rope" .. p40
	v42.Anchored = true
	v42.CanCollide = false
	v42.CanQuery = false
	v42.CanTouch = false
	v42.CastShadow = false
	v42.Material = Enum.Material.Fabric
	v42.Color = Color3.fromRGB(54, 46, 36)
	v42.Size = Vector3.new(0.22, 0.22, 1)
	v42.TopSurface = Enum.SurfaceType.Smooth
	v42.BottomSurface = Enum.SurfaceType.Smooth
	v42.Parent = p39.ropeFolder
	return v42
end
local function v_u_61(p44, p45, p46) -- name: updateRopes
	-- upvalues: (copy) v_u_43
	local _ = p44.g
	local v47 = p44.doorX or 2.6
	for _, v48 in p45.ropes do
		local v49 = p44.ropes[v48.id]
		if not v49 then
			v49 = v_u_43(p44, v48.id)
			p44.ropes[v48.id] = v49
		end
		if v48.len <= 0.002 then
			v49.Transparency = 1
		else
			v49.Transparency = 0
			local v50
			if v48.tx then
				local v51 = v48.tx
				local v52 = v48.ty
				local v53 = v48.tz
				v50 = Vector3.new(v51, v52, v53)
			else
				v50 = (p46 * CFrame.new(v48.side * v47, 3, 0.5)).Position
			end
			local v54 = v48.gx
			local v55 = v48.gy
			local v56 = v48.gz
			local v57 = v50 + (Vector3.new(v54, v55, v56) - v50) * v48.len
			local v58 = (v50 + v57) / 2
			local v59 = (v57 - v50).Magnitude
			local v60 = math.max(v59, 0.1)
			v49.Size = Vector3.new(0.22, 0.22, v60)
			v49.CFrame = CFrame.lookAt(v58, v57)
		end
	end
end
local function v_u_68(p62, p63) -- name: updateDust
	if p62.quality >= 2 then
		if not p62.dust then
			local v64 = Instance.new("Part")
			v64.Name = "Dust"
			v64.Anchored = true
			v64.CanCollide = false
			v64.CanQuery = false
			v64.CanTouch = false
			v64.CastShadow = false
			v64.Transparency = 1
			v64.Size = Vector3.new(1, 1, 1)
			v64.Parent = p62.folder
			local v65 = Instance.new("ParticleEmitter")
			v65.Texture = "rbxasset://textures/particles/smoke_main.dds"
			v65.Color = ColorSequence.new(Color3.fromRGB(176, 164, 140))
			v65.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(0.5, 0.82), NumberSequenceKeypoint.new(1, 1) })
			v65.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 9) })
			v65.Lifetime = NumberRange.new(1.1, 1.8)
			v65.Speed = NumberRange.new(14, 22)
			v65.SpreadAngle = Vector2.new(180, 8)
			v65.EmissionDirection = Enum.NormalId.Top
			v65.Rotation = NumberRange.new(0, 360)
			v65.RotSpeed = NumberRange.new(-40, 40)
			v65.LightEmission = 0
			v65.Rate = 0
			v65.Parent = v64
			p62.dust = v64
			p62.dustEmitter = v65
		end
		p62.dust.CFrame = CFrame.new(p63.x, p63.y + 0.6, p63.z)
		local v66 = p62.dustEmitter
		local v67 = p63.a
		v66.Rate = math.clamp(v67, 0, 1) * 70
	end
end
local function v_u_77(p69) -- name: truckModel
	local v70 = p69 and p69.shared
	if v70 then
		v70 = p69.shared.Assets
	end
	if v70 then
		local v71 = v70.get
		local v72, v73 = pcall(v71, "Prop", "Car_Pickup")
		if v72 and (typeof(v73) == "Instance" and v73:IsA("Model")) then
			local v74 = string.find(v73.Name, "_MISSING", 1, true) ~= nil
			for _, v75 in v73:GetDescendants() do
				if not string.find(v75.Name, "_MISSING", 1, true) then
					continue
				end
				v74 = true
			end
			if v74 then
				v73:Destroy()
				return nil
			else
				for _, v76 in v73:GetDescendants() do
					if v76:IsA("BasePart") then
						v76.Anchored = true
						v76.CanCollide = false
						v76.CanQuery = false
						v76.CanTouch = false
					else
						if not (v76:IsA("Sound") or v76:IsA("LuaSourceContainer")) then
							continue
						end
						v76:Destroy()
					end
				end
				return v73
			end
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_85(p_u_78) -- name: ensureTruck
	-- upvalues: (copy) v_u_77
	if p_u_78.pickup or p_u_78.pickupDone then
		return
	else
		local v79 = v_u_77(p_u_78.cctx)
		if v79 then
			v79.Name = "Truck"
			v79.Parent = p_u_78.folder
			p_u_78.pickup = v79
			local v80, v81 = pcall(function()
				-- upvalues: (copy) p_u_78
				return p_u_78.cctx.lib.EntryPickupFx
			end)
			if v80 and v81 then
				local v82 = v81.attach
				local v83, v84 = pcall(v82, v79)
				if v83 then
					p_u_78.pickupFx = v84
					p_u_78.PickupFx = v81
				end
			end
		else
			p_u_78.pickupDone = true
		end
	end
end
local function v_u_103(p_u_86, p87, p88) -- name: updateTruck
	-- upvalues: (copy) v_u_85
	v_u_85(p_u_86)
	local v89 = p_u_86.pickup
	if v89 then
		local v90 = p87.y
		local v91, v92 = pcall(function()
			-- upvalues: (copy) p_u_86
			return p_u_86.cctx.lib.EntryRig
		end)
		local v93 = v91 and v92 and v92.groundAt(p87.x, p87.y, p87.z, 4, 8)
		if v93 then
			local v94 = p87.y - 4
			local v95 = p87.y + 4
			local v96 = math.clamp(v93, v94, v95)
			if p_u_86.pickupGround then
				local v97 = p_u_86.pickupGround
				local v98 = v96 - p_u_86.pickupGround
				local v99 = p88 * 8
				v96 = v97 + v98 * math.min(1, v99)
			end
			p_u_86.pickupGround = v96
		end
		if p_u_86.pickupGround then
			v90 = p_u_86.pickupGround
		end
		local v100 = CFrame.new(p87.x, v90, p87.z) * CFrame.Angles(0, p87.yaw, 0) * CFrame.Angles(p87.pitch or 0, 0, 0)
		v89:PivotTo(v100)
		if p_u_86.pickupFx then
			local v101 = p_u_86.PickupFx.update
			local v102 = p_u_86.pickupFx
			pcall(v101, v102, v100, p87, p88)
		end
	end
end
function v3.update(p104, p105, p106) -- name: update
	-- upvalues: (copy) v_u_38, (copy) v_u_61, (copy) v_u_68, (copy) v_u_103
	if p104 then
		p104.t = p104.t + p106
		if p105.heli and not p104.heliDone then
			if p105.heli.vis then
				v_u_38(p104)
				local v107 = p104.heli
				if v107 then
					local v108 = p105.heli
					local v109 = CFrame.new(v108.x, v108.y, v108.z) * CFrame.Angles(0, v108.yaw, 0) * CFrame.Angles(v108.pitch or 0, 0, 0)
					p104.HeliRig.pose(v107, v109, p106, p104.t)
					if p105.ropes then
						v_u_61(p104, p105, v109)
					end
				end
			elseif p104.heli then
				local v110 = p104.HeliRig.destroy
				local v111 = p104.heli
				pcall(v110, v111)
				p104.heli = nil
				p104.heliDone = true
				for _, v112 in p104.ropes do
					v112.Transparency = 1
				end
			end
		end
		if p105.dust then
			v_u_68(p104, p105.dust)
		end
		if p105.pickup then
			if p105.pickup.vis then
				v_u_103(p104, p105.pickup, p106)
				return
			end
			if p104.pickup then
				if p104.pickupFx then
					local v113 = p104.PickupFx.destroy
					local v114 = p104.pickupFx
					pcall(v113, v114)
					p104.pickupFx = nil
				end
				p104.pickup:Destroy()
				p104.pickup = nil
				p104.pickupDone = true
			end
		end
	end
end
function v3.cue(p115, p116) -- name: cue
	-- upvalues: (copy) v_u_16
	if p115 then
		local v117 = p115.cctx
		if p116 == "heli_flyby" then
			local v118
			if p115.heli then
				v118 = p115.heli.model.PrimaryPart or p115.heli.model:FindFirstChildWhichIsA("BasePart")
			else
				v118 = nil
			end
			if v118 then
				local v119 = p115.sounds
				local v120 = v_u_16
				table.insert(v119, v120(v117, "play3D", "ev_heli_flyby", v118))
				return
			end
		elseif p116 == "door_slam" then
			local v121
			if p115.pickup then
				v121 = p115.pickup.PrimaryPart or p115.pickup:FindFirstChildWhichIsA("BasePart")
			else
				v121 = nil
			end
			if v121 then
				local v122 = p115.sounds
				local v123 = v_u_16
				table.insert(v122, v123(v117, "play3D", "door_slam", v121))
				return
			end
		elseif p116 == "engine" or p116 == "engine_leave" then
			local v124
			if p115.pickup then
				v124 = p115.pickup.PrimaryPart or p115.pickup:FindFirstChildWhichIsA("BasePart")
			else
				v124 = nil
			end
			if v124 then
				local v125 = p115.sounds
				local v126 = v_u_16
				table.insert(v125, v126(v117, "play3D", "ev_engine", v124))
			end
		end
	end
end
function v3.count(p127) -- name: count
	if not p127 then
		return 0
	end
	local v128 = 0
	if p127.heli then
		v128 = v128 + #p127.heli.model:GetDescendants()
	end
	if p127.ropeFolder then
		v128 = v128 + #p127.ropeFolder:GetChildren()
	end
	if p127.pickup then
		v128 = v128 + #p127.pickup:GetDescendants()
	end
	if p127.dust then
		v128 = v128 + 2
	end
	return v128
end
function v3.finished(p129) -- name: finished
	if not p129 then
		return true
	end
	local v130
	if p129.heli == nil then
		v130 = p129.pickup == nil
	else
		v130 = false
	end
	return v130
end
function v3.destroy(p_u_131) -- name: destroy
	if p_u_131 then
		for _, v_u_132 in p_u_131.sounds do
			if v_u_132 == nil then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_132
				local v133 = v_u_132
				if typeof(v133) == "Instance" then
					v_u_132:Destroy()
				else
					local v134 = v_u_132
					if type(v134) == "table" then
						local v135 = v_u_132.stop or v_u_132.Stop or (v_u_132.destroy or v_u_132.Destroy)
						if type(v135) == "function" then
							v135(v_u_132)
						end
					end
				end
			end)
		end
		p_u_131.sounds = {}
		if p_u_131.heli and p_u_131.HeliRig then
			local v136 = p_u_131.HeliRig.destroy
			local v137 = p_u_131.heli
			pcall(v136, v137)
		end
		p_u_131.heli = nil
		if p_u_131.pickupFx then
			local v138 = p_u_131.PickupFx.destroy
			local v139 = p_u_131.pickupFx
			pcall(v138, v139)
			p_u_131.pickupFx = nil
		end
		if p_u_131.pickup then
			pcall(function()
				-- upvalues: (copy) p_u_131
				p_u_131.pickup:Destroy()
			end)
			p_u_131.pickup = nil
		end
		for _, v_u_140 in p_u_131.ropes do
			pcall(function()
				-- upvalues: (copy) v_u_140
				v_u_140:Destroy()
			end)
		end
		p_u_131.ropes = {}
		if p_u_131.ropeFolder then
			pcall(function()
				-- upvalues: (copy) p_u_131
				p_u_131.ropeFolder:Destroy()
			end)
			p_u_131.ropeFolder = nil
		end
		if p_u_131.dust then
			pcall(function()
				-- upvalues: (copy) p_u_131
				p_u_131.dust:Destroy()
			end)
			p_u_131.dust = nil
			p_u_131.dustEmitter = nil
		end
		p_u_131.heliDone = true
		p_u_131.pickupDone = true
	end
end
return v3