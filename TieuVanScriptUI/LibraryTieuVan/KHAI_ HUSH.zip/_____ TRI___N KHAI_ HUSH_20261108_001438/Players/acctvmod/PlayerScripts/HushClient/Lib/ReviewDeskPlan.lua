-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewDeskPlan

local v_u_34 = {
	["PAD"] = 14,
	["GAP"] = 10,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["TEXT"] = 13,
	["SMALL"] = 11,
	["LINE"] = 17,
	["AVATAR"] = 44,
	["BAR"] = 4,
	["CHIP_H"] = 20,
	["CHIP_GAP"] = 6,
	["GROUP_H"] = 26,
	["COL_SPLIT"] = 720,
	["SB"] = 8,
	["MAX_LINES_TALL"] = 8,
	["SHORT_H"] = 420,
	["MAX_LINES_SHORT"] = 5,
	["STATUS_H"] = 20,
	["RELOAD_PAD"] = 40,
	["VERDICT_ROW_MIN"] = 124,
	["opts"] = function(p1, p2, p3) -- name: opts
		-- upvalues: (copy) v_u_34
		local v4 = math.max(p1, 0.1)
		local v5
		if p2 then
			local v6 = 44 / v4
			local v7 = math.ceil(v6)
			v5 = math.max(36, v7)
		else
			v5 = 36
		end
		local v8 = {
			["scale"] = v4,
			["touch"] = p2
		}
		if p3 == nil then
			p3 = p2
		end
		v8.phone = p3
		v8.tap = v5
		v8.pad = v_u_34.PAD
		v8.gap = v_u_34.GAP
		return v8
	end,
	["fs"] = function(p9, p10) -- name: fs
		if not p9.phone then
			return p10
		end
		local v11 = 11 / p9.scale
		local v12 = math.ceil(v11)
		return math.max(p10, v12)
	end,
	["textW"] = function(p13, p14, p15) -- name: textW
		-- upvalues: (copy) v_u_34
		local v16 = tostring(p13 or "")
		local v17 = (utf8.len(v16) or #v16) * p14
		local v18
		if p15 == true then
			v18 = v_u_34.CHAR_CAPS
		else
			v18 = v_u_34.CHAR
		end
		local v19 = v17 * v18 + 2
		return math.ceil(v19)
	end,
	["lineH"] = function(p20, p21) -- name: lineH
		-- upvalues: (copy) v_u_34
		local v22 = (p21 or v_u_34.fs(p20, v_u_34.TEXT)) * 1.3
		return math.ceil(v22)
	end,
	["lines"] = function(p23, p24, p25) -- name: lines
		-- upvalues: (copy) v_u_34
		local v26 = tostring(p23 or "")
		local v27 = (p24 - 2) / (p25 * v_u_34.CHAR)
		local v28 = math.floor(v27)
		local v29 = math.max(1, v28)
		local v30 = 0
		for v31 in string.gmatch(v26 .. "\n", "([^\n]*)\n") do
			local v32 = (utf8.len(v31) or #v31) / v29
			local v33 = math.ceil(v32)
			v30 = v30 + math.max(1, v33)
		end
		return math.max(1, v30)
	end
}
local function v_u_41(p35, p36) -- name: cutAt
	if p36 <= 0 then
		return 0
	end
	local v37 = #p35
	local v38 = 1
	local v39 = 0
	while v38 <= v37 do
		local v40 = string.byte(p35, v38)
		if v40 < 128 or v40 >= 192 then
			v39 = v39 + 1
			if p36 < v39 then
				return v38 - 1
			end
		end
		v38 = v38 + 1
	end
	return v37
end
function v_u_34.clip(p42, p43, p44, p45) -- name: clip
	-- upvalues: (copy) v_u_34, (copy) v_u_41
	local v46 = tostring(p42 or "")
	local v47 = v_u_34.lines(v46, p43, p44)
	if v47 <= p45 then
		return v46, v47
	end
	local v48 = utf8.len(v46) or #v46
	local v49 = 0
	while v49 < v48 do
		local v50 = (v49 + v48) / 2
		local v51 = math.ceil(v50)
		local v52 = v_u_41(v46, v51)
		local v53 = string.sub(v46, 1, v52) .. "..."
		if v_u_34.lines(v53, p43, p44) <= p45 then
			v49 = v51
		else
			v48 = v51 - 1
		end
	end
	local v54 = v_u_41(v46, v49)
	local v55 = string.sub(v46, 1, v54)
	local v56 = string.gsub(v55, "%s+$", "") .. "..."
	return v56, v_u_34.lines(v56, p43, p44)
end
function v_u_34.window(p57, p58, _, p59) -- name: window
	local v60 = p59 or {
		["l"] = 0,
		["r"] = 0,
		["t"] = 0,
		["b"] = 0
	}
	local v61 = p57 - v60.l - v60.r - 24
	local v62 = p58 - v60.t - v60.b - 24
	local v63 = math.min(1000, v61)
	local v64 = math.max(280, v63)
	local v65 = math.min(640, v62)
	local v66 = math.max(240, v65)
	local v67 = v60.l + 12
	local v68 = (v61 - v64) / 2
	local v69 = v67 + math.floor(v68)
	local v70 = v60.t + 12
	local v71 = (v62 - v66) / 2
	local v72 = v70 + math.floor(v71)
	return {
		["x"] = math.max(0, v69),
		["y"] = math.max(0, v72),
		["w"] = v64,
		["h"] = v66
	}
end
local v_u_73 = { "SUSPECTS", "MY VERDICTS", "HELP" }
function v_u_34.tabs(p74, p75) -- name: tabs
	-- upvalues: (copy) v_u_34, (copy) v_u_73
	for _, v76 in { v_u_34.fs(p75, 13), v_u_34.fs(p75, 12), v_u_34.fs(p75, 11) } do
		local v77 = {}
		local v78 = 0
		for _, v79 in v_u_73 do
			local v80 = v_u_34.textW(v79, v76, true) + 24
			local v81 = math.max(72, v80)
			table.insert(v77, v81)
			v78 = v78 + v81
		end
		local v82 = v78 + (#v_u_73 - 1) * 8
		if v82 > p74 then
			break
		end
		local v83 = 0
		local v84 = {}
		for v85, v86 in v77 do
			v84[v85] = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v83,
				["w"] = v86,
				["h"] = p75.tap
			}
			v83 = v83 + (v86 + 8)
		end
		return {
			["rects"] = nil,
			["size"] = nil,
			["total"] = nil,
			["fits"] = true,
			["rects"] = v84,
			["size"] = v76,
			["total"] = v82
		}, v76
	end
	local v87 = v_u_34.fs(p75, 11)
	local v88 = (p74 - 16) / 3
	local v89 = math.floor(v88)
	local v90 = {
		{
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = (v89 + 8) * 0,
			["w"] = v89,
			["h"] = p75.tap
		},
		{
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = (v89 + 8) * 1,
			["w"] = v89,
			["h"] = p75.tap
		},
		{
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = (v89 + 8) * 2,
			["w"] = v89,
			["h"] = p75.tap
		}
	}
	local v91 = true
	for _, v92 in v_u_73 do
		if v89 >= v_u_34.textW(v92, v87, true) + 8 then
			continue
		end
		v91 = false
	end
	return {
		["rects"] = v90,
		["size"] = v87,
		["total"] = p74,
		["fits"] = v91
	}, v87
end
function v_u_34.frame(p93, p94, p95, p96) -- name: frame
	-- upvalues: (copy) v_u_34
	local v97 = p95.pad
	local v98 = p95.gap
	local v99 = p95.tap
	local v100 = {}
	local v101
	if p94 < v_u_34.SHORT_H then
		v101 = p93 < 720
	else
		v101 = false
	end
	local v102
	if v101 then
		v102 = 0
	else
		local v103 = p95.tap + 16
		v102 = math.max(56, v103)
	end
	v100.short = v101
	v100.header = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["w"] = p93,
		["h"] = v102
	}
	local v104 = p93 - 2 * v97
	local v105 = p93 >= 720
	local v106 = v_u_34.tabs
	local v107
	if v105 then
		local v108 = v104 * 0.5
		v107 = math.floor(v108)
	elseif v101 then
		v107 = v104 - v99 - v98
	else
		v107 = v104
	end
	local v109 = v106(v107, p95)
	local v110
	if v101 then
		v110 = v97
	else
		v110 = v102 + v98
	end
	if v101 then
		v100.close = {
			["x"] = p93 - v97 - v99,
			["y"] = v110,
			["w"] = v99,
			["h"] = v99
		}
		v100.title = nil
	else
		local v111 = p93 - v97 - v99
		local v112 = (v102 - v99) / 2
		v100.close = {
			["x"] = v111,
			["y"] = math.floor(v112),
			["w"] = v99,
			["h"] = v99
		}
		local v113 = (v102 - 30) / 2
		v100.title = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 30,
			["x"] = v97,
			["y"] = math.floor(v113),
			["w"] = p93 - 3 * v97 - v99
		}
	end
	local v114 = {}
	for v115, v116 in v109.rects do
		v114[v115] = {
			["x"] = v97 + v116.x,
			["y"] = v110,
			["w"] = v116.w,
			["h"] = v116.h
		}
	end
	v100.tabs = v114
	v100.tabSize = v109.size
	v100.tabsFit = v109.fits
	local v117 = v_u_34.textW("RELOAD", v_u_34.fs(p95, 13), true) + v_u_34.RELOAD_PAD
	local v118, v119, v120, v121, v122
	if v105 then
		v118 = v97 + v109.total + v98 * 2
		v119 = p93 - v97 - v117 - v98 - v118
		v120 = p95.tap
		v121 = v110 + p95.tap + v98
		v122 = v110
	else
		v119 = v104 - v117 - v98
		v122 = v110 + p95.tap + v98
		v120 = p95.tap
		v121 = v122 + v120 + v98
		v118 = v97
	end
	v100.search = {
		["x"] = v118,
		["y"] = v122,
		["w"] = math.max(0, v119),
		["h"] = v120
	}
	v100.reload = {
		["x"] = p93 - v97 - v117,
		["y"] = v122,
		["w"] = v117,
		["h"] = v120
	}
	v100.status = {
		["x"] = v97,
		["y"] = p94 - v97 - v_u_34.STATUS_H,
		["w"] = v104,
		["h"] = v_u_34.STATUS_H
	}
	local v123 = v100.status.y - v98
	local v124 = v110 + p95.tap + v98
	local v125 = v123 - v121
	v100.bodyList = {
		["x"] = v97,
		["y"] = v121,
		["w"] = v104,
		["h"] = math.max(0, v125)
	}
	local v126 = v123 - v124
	v100.bodyOther = {
		["x"] = v97,
		["y"] = v124,
		["w"] = v104,
		["h"] = math.max(0, v126)
	}
	local v127
	if p96 == 1 or p96 == nil then
		v127 = v100.bodyList
	else
		v127 = v100.bodyOther
	end
	v100.body = v127
	v100.singleRow = v105
	return v100
end
local function v_u_138(p128, p129, p130) -- name: chipSpec
	-- upvalues: (copy) v_u_34, (copy) v_u_41
	local v131 = (p129 - 16 - 2) / (p130 * v_u_34.CHAR_CAPS)
	local v132 = math.floor(v131)
	local v133 = math.max(1, v132)
	if v133 < (utf8.len(p128) or #p128) then
		local v134 = v133 - 3
		local v135 = v_u_41(p128, (math.max(1, v134)))
		p128 = string.sub(p128, 1, v135) .. "..."
	end
	local v136 = {
		["text"] = p128
	}
	local v137 = v_u_34.textW(p128, p130, true) + 16
	v136.w = math.min(p129, v137)
	return v136
end
function v_u_34.card(p139, p140, p141) -- name: card
	-- upvalues: (copy) v_u_34, (copy) v_u_138
	local v142 = v_u_34.fs(p140, v_u_34.TEXT)
	local v143 = v_u_34.fs(p140, v_u_34.SMALL)
	local v144 = {}
	local v145 = v_u_34.BAR + 8 + v_u_34.AVATAR + 10
	local v146 = p139 - v145 - 10
	v144.bar = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = 0,
		["w"] = v_u_34.BAR
	}
	v144.avatar = {
		["x"] = nil,
		["y"] = 10,
		["w"] = nil,
		["h"] = nil,
		["x"] = v_u_34.BAR + 8,
		["w"] = v_u_34.AVATAR,
		["h"] = v_u_34.AVATAR
	}
	local v147 = (v_u_34.fs(p140, 15) or v_u_34.fs(p140, v_u_34.TEXT)) * 1.3
	local v148 = math.ceil(v147)
	v144.name = {
		["x"] = nil,
		["y"] = 10,
		["w"] = nil,
		["h"] = nil,
		["x"] = v145,
		["w"] = v146,
		["h"] = v148
	}
	local v149 = v148 + 10 + 4
	local v150 = 0
	local v151 = 0
	local v152 = {}
	for _, v153 in p141.chips or {} do
		local v154 = v_u_138(v153, v146, v143)
		if v150 > 0 and v146 < v150 + v_u_34.CHIP_GAP + v154.w then
			v151 = v151 + 1
			v150 = 0
		end
		local v155 = v150 == 0 and 0 or v150 + v_u_34.CHIP_GAP
		local v156 = {
			["rect"] = {
				["x"] = v145 + v155,
				["y"] = v149 + v151 * (v_u_34.CHIP_H + v_u_34.CHIP_GAP),
				["w"] = v154.w,
				["h"] = v_u_34.CHIP_H
			},
			["text"] = v154.text,
			["size"] = v143
		}
		table.insert(v152, v156)
		v150 = v155 + v154.w
	end
	v144.chips = v152
	local v157 = #v152 <= 0 and 0 or (v151 + 1) * v_u_34.CHIP_H + v151 * v_u_34.CHIP_GAP
	local v158 = v149 + v157 + (v157 > 0 and 8 or 0)
	local v159 = p141.maxLines or v_u_34.MAX_LINES_TALL
	local v160, v161 = v_u_34.clip(p141.summary or "", v146, v142, v159)
	local v162 = (v142 or v_u_34.fs(p140, v_u_34.TEXT)) * 1.3
	local v163 = math.ceil(v162)
	v144.summary = {
		["x"] = v145,
		["y"] = v158,
		["w"] = v146,
		["h"] = v161 * v163
	}
	v144.summaryText = v160
	v144.summarySize = v142
	local v164 = v158 + v161 * v163
	local v165 = 10 + v_u_34.AVATAR
	local v166 = math.max(v164, v165)
	local v167 = {}
	local v168 = p141.action and 2 or 1
	local v169 = v166 + 10
	local v170 = (p139 - 20 - (v168 - 1) * 8) / v168
	local v171 = math.floor(v170)
	local v172 = 0
	if p141.action then
		v167.action = {
			["x"] = v172 * (v171 + 8) + 10,
			["y"] = v169,
			["w"] = v171,
			["h"] = p140.tap
		}
		v172 = v172 + 1
	end
	v167.verdict = {
		["x"] = v172 * (v171 + 8) + 10,
		["y"] = v169,
		["w"] = v171,
		["h"] = p140.tap
	}
	v144.buttons = v167
	v144.btnSize = v142
	local v173 = v169 + p140.tap + 10
	v144.bar = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["w"] = v_u_34.BAR,
		["h"] = v173
	}
	v144.h = v173
	v144.w = p139
	return v144
end
function v_u_34.list(p174, p175, p176) -- name: list
	-- upvalues: (copy) v_u_34
	local v177 = v_u_34.COL_SPLIT <= p174 and 2 or 1
	local v178 = p174 - v_u_34.SB
	local v179 = p176.gap
	local v180 = (v178 - (v177 - 1) * v179) / v177
	local v181 = math.floor(v180)
	local v182 = 0
	local v183 = {}
	for _, v184 in p175 do
		local v185 = {
			["kind"] = "header",
			["title"] = nil,
			["rect"] = nil,
			["title"] = v184.title,
			["rect"] = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v182,
				["w"] = v178,
				["h"] = v_u_34.GROUP_H
			}
		}
		table.insert(v183, v185)
		local v186 = v182 + (v_u_34.GROUP_H + 6)
		local v187 = 1
		while v187 <= #v184.cards do
			local v188 = {}
			local v189 = 0
			for v190 = 0, v177 - 1 do
				local v191 = v184.cards[v187 + v190]
				if v191 == nil then
					continue
				end
				local v192 = v_u_34.card(v181, p176, v191)
				table.insert(v188, v192)
				local v193 = v192.h
				v189 = math.max(v189, v193)
			end
			for v194, v195 in v188 do
				local v196 = {
					["kind"] = "card",
					["rect"] = nil,
					["parts"] = nil,
					["index"] = nil,
					["rect"] = {
						["x"] = (v194 - 1) * (v181 + v179),
						["y"] = v186,
						["w"] = v181,
						["h"] = v195.h
					},
					["parts"] = v195,
					["index"] = v187 + v194 - 1
				}
				table.insert(v183, v196)
			end
			v186 = v186 + (v189 + v179)
			v187 = v187 + v177
		end
		v182 = v186 + 4
	end
	return v183, math.max(0, v182)
end
function v_u_34.mineRow(p197, p198, p199) -- name: mineRow
	-- upvalues: (copy) v_u_34, (copy) v_u_138
	local v200 = v_u_34.fs(p198, v_u_34.TEXT)
	local v201 = v_u_34.fs(p198, v_u_34.SMALL)
	local v202 = {}
	local v203 = (v_u_34.fs(p198, 15) or v_u_34.fs(p198, v_u_34.TEXT)) * 1.3
	local v204 = math.ceil(v203)
	local v205 = p197 - 20
	local v206 = v_u_138
	local v207 = p199.verdict or ""
	local v208 = v205 * 0.5
	local v209 = v206(v207, math.floor(v208), v201)
	v202.chip = {
		["x"] = nil,
		["y"] = 10,
		["w"] = nil,
		["h"] = nil,
		["x"] = p197 - 10 - v209.w,
		["w"] = v209.w,
		["h"] = v_u_34.CHIP_H
	}
	v202.chipText = v209.text
	v202.chipSize = v201
	v202.name = {
		["x"] = 10,
		["y"] = 10,
		["w"] = nil,
		["h"] = nil,
		["w"] = v205 - v209.w - 8,
		["h"] = v204
	}
	local v210 = v_u_34.CHIP_H
	local v211 = math.max(v204, v210) + 10 + 4
	local v212 = (v200 or v_u_34.fs(p198, v_u_34.TEXT)) * 1.3
	local v213 = math.ceil(v212)
	local v214, v215 = v_u_34.clip(p199.meta or "", v205, v201, 2)
	local v216 = (v201 or v_u_34.fs(p198, v_u_34.TEXT)) * 1.3
	v202.meta = {
		["x"] = 10,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v211,
		["w"] = v205,
		["h"] = v215 * math.ceil(v216)
	}
	v202.metaText = v214
	v202.metaSize = v201
	local v217 = (v201 or v_u_34.fs(p198, v_u_34.TEXT)) * 1.3
	local v218 = v211 + v215 * math.ceil(v217)
	if p199.comment and p199.comment ~= "" then
		local v219, v220 = v_u_34.clip(p199.comment, v205, v200, 3)
		v202.comment = {
			["x"] = 10,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v218 + 4,
			["w"] = v205,
			["h"] = v220 * v213
		}
		v202.commentText = v219
		v202.commentSize = v200
		v218 = v218 + (4 + v220 * v213)
	end
	v202.h = v218 + 10
	v202.w = p197
	return v202
end
function v_u_34.help(p221, p222, _, p223) -- name: help
	-- upvalues: (copy) v_u_34
	local v224 = v_u_34.fs(p222, v_u_34.TEXT)
	local v225 = (v224 or v_u_34.fs(p222, v_u_34.TEXT)) * 1.3
	local v226 = math.ceil(v225)
	local v227 = {
		["items"] = {}
	}
	local v228 = (v_u_34.fs(p222, 15) or v_u_34.fs(p222, v_u_34.TEXT)) * 1.3
	local v229 = math.ceil(v228)
	v227.title = {
		["x"] = 4,
		["y"] = 4,
		["w"] = nil,
		["h"] = nil,
		["w"] = p221 - 8,
		["h"] = v229
	}
	local v230 = v229 + 4 + 8
	for _, v231 in p223 do
		local v232 = v_u_34.lines(v231, p221 - 8 - 16 - v_u_34.SB, v224)
		local v233 = v227.items
		local v234 = {
			["bullet"] = {
				["x"] = 4,
				["y"] = nil,
				["w"] = 16,
				["h"] = nil,
				["y"] = v230,
				["h"] = v226
			},
			["text"] = {
				["x"] = 20,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v230,
				["w"] = p221 - 8 - 16 - v_u_34.SB,
				["h"] = v232 * v226
			},
			["size"] = v224
		}
		table.insert(v233, v234)
		v230 = v230 + (v232 * v226 + 8)
	end
	v227.h = v230 + 4
	return v227
end
function v_u_34.verdict(p235, p236, p237, p238) -- name: verdict
	-- upvalues: (copy) v_u_34
	local v239 = p237.pad
	local v240 = p235 - 2 * v239
	local v241 = math.min(560, v240)
	local v242 = v241 - 32
	local v243 = v_u_34.fs(p237, v_u_34.TEXT)
	local v244 = {}
	local v245 = 12
	local v246 = (v_u_34.fs(p237, 18) or v_u_34.fs(p237, v_u_34.TEXT)) * 1.3
	local v247 = math.ceil(v246)
	v244.title = {
		["x"] = 16,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v245,
		["w"] = v242,
		["h"] = v247
	}
	local v248 = v245 + (v247 + 4)
	local v249 = (v_u_34.fs(p237, 15) or v_u_34.fs(p237, v_u_34.TEXT)) * 1.3
	local v250 = math.ceil(v249)
	v244.who = {
		["x"] = 16,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v248,
		["w"] = v242,
		["h"] = v250
	}
	local v251 = v248 + (v250 + 8)
	local v252, v253 = v_u_34.clip(p238.note or "", v242, v243, 4)
	local v254 = (v243 or v_u_34.fs(p237, v_u_34.TEXT)) * 1.3
	v244.note = {
		["x"] = 16,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v251,
		["w"] = v242,
		["h"] = v253 * math.ceil(v254)
	}
	v244.noteText = v252
	v244.noteSize = v243
	local v255 = (v243 or v_u_34.fs(p237, v_u_34.TEXT)) * 1.3
	local v256 = v251 + (v253 * math.ceil(v255) + 10)
	local v257 = 3 * v_u_34.VERDICT_ROW_MIN + 16 <= v242
	local v258 = {}
	local v259
	if v257 then
		local v260 = (v242 - 16) / 3
		local v261 = math.floor(v260)
		v258[1] = {
			["x"] = (v261 + 8) * 0 + 16,
			["y"] = v256,
			["w"] = v261,
			["h"] = p237.tap
		}
		v258[2] = {
			["x"] = (v261 + 8) * 1 + 16,
			["y"] = v256,
			["w"] = v261,
			["h"] = p237.tap
		}
		v258[3] = {
			["x"] = (v261 + 8) * 2 + 16,
			["y"] = v256,
			["w"] = v261,
			["h"] = p237.tap
		}
		v259 = v256 + (p237.tap + 10)
	else
		for v262 = 1, 3 do
			v258[v262] = {
				["x"] = 16,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v256,
				["w"] = v242,
				["h"] = p237.tap
			}
			v256 = v256 + (p237.tap + 8)
		end
		v259 = v256 + 2
	end
	v244.verdicts = v258
	v244.oneRow = v257
	v244.comment = {
		["x"] = 16,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v259,
		["w"] = v242,
		["h"] = p237.tap
	}
	local v263 = v259 + (p237.tap + 10)
	local v264 = (v242 - 8) / 2
	local v265 = math.floor(v264)
	v244.cancel = {
		["x"] = 16,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v263,
		["w"] = v265,
		["h"] = p237.tap
	}
	v244.send = {
		["x"] = v265 + 16 + 8,
		["y"] = v263,
		["w"] = v265,
		["h"] = p237.tap
	}
	local v266 = v263 + (p237.tap + 12)
	v244.panelH = v266
	local v267 = p236 - 2 * v239
	v244.fits = v266 <= v267
	local v268 = math.min(v266, v267)
	local v269 = (p235 - v241) / 2
	local v270 = math.floor(v269)
	local v271 = (p236 - v268) / 2
	v244.panel = {
		["x"] = v270,
		["y"] = math.floor(v271),
		["w"] = v241,
		["h"] = v268
	}
	v244.scroll = v267 < v266
	v244.btnSize = v243
	return v244
end
function v_u_34.audit(p272, _) -- name: audit
	for _, v273 in p272 do
		local v274 = {}
		for v275 in v273.parts do
			table.insert(v274, v275)
		end
		table.sort(v274)
		for _, v276 in v274 do
			local v277 = v273.parts[v276]
			if v277.w < 0 or v277.h < 0 then
				return {
					["problem"] = v273.name .. ": " .. v276 .. " has a negative size"
				}
			end
			local v278 = v273.box
			local v279
			if v277.x >= -0.01 and (v277.y >= -0.01 and v277.x + v277.w <= v278.w + 0.01) then
				v279 = v277.y + v277.h <= v278.h + 0.01
			else
				v279 = false
			end
			if v279 then
				continue
			end
			return {
				["problem"] = ("%s: %s leaves its box (%d,%d,%d,%d in %dx%d)"):format(v273.name, v276, v277.x, v277.y, v277.w, v277.h, v273.box.w, v273.box.h)
			}
		end
		for v280 = 1, #v274 do
			for v281 = v280 + 1, #v274 do
				local v282 = v273.parts[v274[v280]]
				local v283 = v273.parts[v274[v281]]
				local v284
				if v282.x < v283.x + v283.w - 0.01 and (v283.x < v282.x + v282.w - 0.01 and v282.y < v283.y + v283.h - 0.01) then
					v284 = v283.y < v282.y + v282.h - 0.01
				else
					v284 = false
				end
				if not v284 then
					continue
				end
				return {
					["problem"] = ("%s: %s overlaps %s"):format(v273.name, v274[v280], v274[v281])
				}
			end
		end
	end
	return {
		["problem"] = nil
	}
end
return v_u_34