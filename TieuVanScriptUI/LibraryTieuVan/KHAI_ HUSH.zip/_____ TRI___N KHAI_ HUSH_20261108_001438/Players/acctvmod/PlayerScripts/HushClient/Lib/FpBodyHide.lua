-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpBodyHide

local v_u_1 = {
	["REASSERT_EVERY"] = 0.5
}
local v_u_2 = {}
local v_u_3 = {}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = 0
local v_u_7 = 0
local v_u_8 = 0
local function v_u_14(p_u_9) -- name: take
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_7
	if v_u_6 > 0 and ((p_u_9:IsA("BasePart") or p_u_9:IsA("Decal")) and v_u_2[p_u_9] == nil) then
		local v10, v11 = pcall(function()
			-- upvalues: (copy) p_u_9
			return p_u_9.LocalTransparencyModifier
		end)
		local v12 = (not v10 or type(v11) ~= "number") and 0 or v11
		if p_u_9:GetAttribute("HushGearHidden") == true then
			v_u_3[p_u_9] = true
		else
			v12 = v12 >= 1 and 0 or v12
		end
		v_u_2[p_u_9] = v12
		v_u_7 = v_u_7 + 1
		local v_u_13 = v_u_6
		pcall(function()
			-- upvalues: (copy) p_u_9, (copy) v_u_13
			p_u_9.LocalTransparencyModifier = v_u_13
		end)
	end
end
local function v_u_18() -- name: restoreAll
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (ref) v_u_7
	for v_u_15, v16 in v_u_2 do
		if not v_u_15.Parent then
			continue
		end
		local v_u_17 = v_u_15:GetAttribute("HushGearHidden") == true and 1 or (v_u_3[v_u_15] and 0 or v16)
		pcall(function()
			-- upvalues: (copy) v_u_15, (copy) v_u_17
			v_u_15.LocalTransparencyModifier = v_u_17
		end)
	end
	table.clear(v_u_2)
	table.clear(v_u_3)
	v_u_7 = 0
end
function v_u_1.setLevel(p19, p20) -- name: setLevel
	-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (copy) v_u_18, (copy) v_u_14, (copy) v_u_2
	local v_u_21 = (type(p19) ~= "number" or p19 ~= p19) and 0 or math.clamp(p19, 0, 1)
	if v_u_21 <= 0 then
		v_u_6 = 0
		if v_u_5 ~= nil or (v_u_7 ~= 0 or v_u_4 ~= nil) then
			if v_u_4 then
				v_u_4:Disconnect()
				v_u_4 = nil
			end
			v_u_18()
			v_u_5 = nil
		end
	else
		local v22 = v_u_21 ~= v_u_6
		v_u_6 = v_u_21
		if p20 ~= nil and p20 ~= v_u_5 then
			if v_u_4 then
				v_u_4:Disconnect()
				v_u_4 = nil
			end
			v_u_18()
			v_u_5 = nil
			v_u_6 = v_u_21
		end
		if v_u_5 == nil then
			if p20 ~= nil and p20.Parent ~= nil then
				v_u_5 = p20
				for _, v23 in p20:GetDescendants() do
					v_u_14(v23)
				end
				v_u_4 = p20.DescendantAdded:Connect(v_u_14)
			end
			return
		elseif v22 then
			for v_u_24, _ in v_u_2 do
				if not v_u_24.Parent or v_u_24.LocalTransparencyModifier == v_u_21 then
					continue
				end
				pcall(function()
					-- upvalues: (copy) v_u_24, (copy) v_u_21
					v_u_24.LocalTransparencyModifier = v_u_21
				end)
			end
		end
	end
end
function v_u_1.step(p25) -- name: step
	-- upvalues: (ref) v_u_6, (ref) v_u_8, (copy) v_u_1, (ref) v_u_5, (ref) v_u_4, (copy) v_u_18, (copy) v_u_2, (copy) v_u_3, (ref) v_u_7
	if v_u_6 <= 0 then
		return
	else
		v_u_8 = v_u_8 + p25
		if v_u_8 < v_u_1.REASSERT_EVERY then
			return
		else
			v_u_8 = 0
			if v_u_5 == nil or v_u_5.Parent ~= nil then
				for v_u_26, _ in v_u_2 do
					if v_u_26.Parent == nil then
						v_u_2[v_u_26] = nil
						v_u_3[v_u_26] = nil
						v_u_7 = v_u_7 - 1
					else
						if v_u_26.LocalTransparencyModifier == v_u_6 then
							continue
						end
						local v_u_27 = v_u_6
						pcall(function()
							-- upvalues: (copy) v_u_26, (copy) v_u_27
							v_u_26.LocalTransparencyModifier = v_u_27
						end)
					end
				end
			else
				if v_u_4 then
					v_u_4:Disconnect()
					v_u_4 = nil
				end
				v_u_18()
				v_u_5 = nil
			end
		end
	end
end
function v_u_1.reassert() -- name: reassert
	-- upvalues: (ref) v_u_6, (ref) v_u_8, (copy) v_u_1
	if v_u_6 > 0 then
		v_u_8 = v_u_1.REASSERT_EVERY
		v_u_1.step(0)
	end
end
function v_u_1.stop() -- name: stop
	-- upvalues: (ref) v_u_6, (ref) v_u_8, (ref) v_u_4, (copy) v_u_18, (ref) v_u_5
	v_u_6 = 0
	v_u_8 = 0
	if v_u_4 then
		v_u_4:Disconnect()
		v_u_4 = nil
	end
	v_u_18()
	v_u_5 = nil
end
function v_u_1.level() -- name: level
	-- upvalues: (ref) v_u_6
	return v_u_6
end
function v_u_1.count() -- name: count
	-- upvalues: (ref) v_u_7
	return v_u_7
end
function v_u_1.active() -- name: active
	-- upvalues: (ref) v_u_6
	return v_u_6 > 0
end
function v_u_1.character() -- name: character
	-- upvalues: (ref) v_u_5
	return v_u_5
end
return v_u_1