-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreGiveLayout

local v_u_35 = {
	["PAD"] = 12,
	["AVATAR"] = 56,
	["GAP"] = 8,
	["TEXT_GAP"] = 12,
	["NAME_H"] = 26,
	["USER_H"] = 18,
	["BOX_PAD_X"] = 10,
	["BOX_PAD_Y"] = 8,
	["LINE_H"] = 20,
	["CHAR_W"] = 7.4,
	["CHECK_W"] = 130,
	["WHO_GAP"] = 12,
	["SEND_W"] = 360,
	["INPUT_MIN_W"] = 80,
	["lines"] = function(p1, p2) -- name: lines
		-- upvalues: (copy) v_u_35
		local v3 = (type(p1) == "string" and #p1 or 0) * v_u_35.CHAR_W
		local v4 = p2 * 0.92
		local v5 = v3 / math.max(40, v4)
		local v6 = math.ceil(v5)
		return math.max(1, v6)
	end,
	["rows"] = function(p7) -- name: rows
		return {
			["who"] = p7(40),
			["friend"] = p7(42),
			["send"] = p7(46),
			["ctl"] = p7(38)
		}
	end,
	["who"] = function(p8, p9) -- name: who
		-- upvalues: (copy) v_u_35
		local v10 = v_u_35.INPUT_MIN_W
		local v11 = p8 - v_u_35.CHECK_W - v_u_35.WHO_GAP
		local v12 = math.max(v10, v11)
		local v13 = {
			["row"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p8,
				["h"] = p9
			},
			["input"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v12,
				["h"] = p9
			},
			["check"] = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v12 + v_u_35.WHO_GAP,
				["w"] = v_u_35.CHECK_W,
				["h"] = p9
			}
		}
		return v13
	end,
	["send"] = function(p14, p15) -- name: send
		-- upvalues: (copy) v_u_35
		local v16 = v_u_35.SEND_W
		return {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = math.min(v16, p14),
			["h"] = p15
		}
	end,
	["card"] = function(p17, p18) -- name: card
		-- upvalues: (copy) v_u_35
		local v19 = v_u_35.PAD
		local v20 = v19 + v_u_35.AVATAR + v_u_35.TEXT_GAP
		local v21 = p17 - v20 - v19
		local v22 = math.max(40, v21)
		local v23 = v_u_35.NAME_H + 2 + v_u_35.USER_H
		local v24 = (v_u_35.AVATAR - v23) / 2
		local v25 = v19 + math.floor(v24)
		local v26 = {
			["w"] = p17,
			["avatar"] = {
				["x"] = v19,
				["y"] = v19,
				["w"] = v_u_35.AVATAR,
				["h"] = v_u_35.AVATAR
			},
			["name"] = {
				["x"] = v20,
				["y"] = v25,
				["w"] = v22,
				["h"] = v_u_35.NAME_H
			},
			["user"] = {
				["x"] = v20,
				["y"] = v25 + v_u_35.NAME_H + 2,
				["w"] = v22,
				["h"] = v_u_35.USER_H
			}
		}
		local v27 = v19 + v_u_35.AVATAR
		local v28 = p17 - 2 * v19 - 2 * v_u_35.BOX_PAD_X
		local v29 = p18 or {}
		for _, v30 in { "warn", "hint" } do
			local v31 = v29[v30]
			if type(v31) ~= "string" or v31 == "" then
				continue
			end
			local v32 = v_u_35.lines(v31, v28) * v_u_35.LINE_H
			local v33 = v32 + 2 * v_u_35.BOX_PAD_Y
			local v34 = v27 + v_u_35.GAP
			v26[v30] = {
				["x"] = v19,
				["y"] = v34,
				["w"] = p17 - 2 * v19,
				["h"] = v33
			}
			v26[v30 .. "Text"] = {
				["x"] = v19 + v_u_35.BOX_PAD_X,
				["y"] = v34 + v_u_35.BOX_PAD_Y,
				["w"] = v28,
				["h"] = v32
			}
			v27 = v34 + v33
		end
		v26.h = v27 + v19
		return v26
	end
}
return v_u_35