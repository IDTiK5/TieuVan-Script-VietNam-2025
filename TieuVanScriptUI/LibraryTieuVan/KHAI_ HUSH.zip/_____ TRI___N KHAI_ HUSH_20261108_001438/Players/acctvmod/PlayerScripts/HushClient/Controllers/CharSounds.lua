-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / CharSounds

local v_u_1 = game:GetService("Players")
local v2 = {
	["name"] = "CharSounds",
	["order"] = 4
}
local v_u_3 = nil
local v_u_4 = v_u_1.LocalPlayer
local v_u_5 = {
	["Running"] = true,
	["Jumping"] = true,
	["Landing"] = true,
	["FreeFalling"] = true,
	["Swimming"] = true,
	["Splash"] = true,
	["Climbing"] = true,
	["GettingUp"] = true,
	["Died"] = true
}
local v_u_6 = 0
local v_u_7 = "absent"
local v_u_8 = {}
local function v_u_13() -- name: disableScript
	-- upvalues: (copy) v_u_4, (ref) v_u_7, (ref) v_u_6
	local v9 = v_u_4:FindFirstChildOfClass("PlayerScripts")
	local v_u_10
	if v9 then
		v_u_10 = v9:FindFirstChild("RbxCharacterSounds")
	else
		v_u_10 = v9
	end
	if v_u_10 and v_u_10:IsA("BaseScript") then
		v_u_7 = pcall(function()
			-- upvalues: (copy) v_u_10
			v_u_10.Enabled = false
		end) and "disabled" or "enabled"
	elseif v_u_7 == "absent" and v9 then
		local v_u_11 = nil
		v_u_11 = v9.ChildAdded:Connect(function(p_u_12)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_11
			if p_u_12.Name == "RbxCharacterSounds" and p_u_12:IsA("BaseScript") then
				pcall(function()
					-- upvalues: (copy) p_u_12
					p_u_12.Enabled = false
				end)
				v_u_7 = "disabled"
				v_u_4:SetAttribute("CharSoundsMuted", v_u_7 .. " removed=" .. v_u_6)
				if v_u_11 then
					v_u_11:Disconnect()
				end
			end
		end)
	end
end
local function v_u_39(p14, p_u_15) -- name: watchCharacter
	-- upvalues: (copy) v_u_5, (ref) v_u_6, (copy) v_u_4, (ref) v_u_7
	local function v_u_29(p16) -- name: watchRoot
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) p_u_15
		for _, v_u_17 in p16:GetChildren() do
			local v18
			if v_u_17:IsA("Sound") and v_u_5[v_u_17.Name] then
				local v19 = v_u_17.SoundId
				v18 = v19 == "" and true or string.sub(v19, 1, 18) == "rbxasset://sounds/"
			else
				v18 = false
			end
			if not v18 then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_17
				v_u_17.Volume = 0
				v_u_17:Stop()
				v_u_17:Destroy()
			end)
			v_u_6 = v_u_6 + 1
		end
		local v20 = p_u_15
		local v21 = p16.ChildAdded
		local function v28(p_u_22)
			-- upvalues: (ref) v_u_5, (ref) v_u_6
			local v23
			if p_u_22:IsA("Sound") and v_u_5[p_u_22.Name] then
				local v24 = p_u_22.SoundId
				v23 = v24 == "" and true or string.sub(v24, 1, 18) == "rbxasset://sounds/"
			else
				v23 = false
			end
			if v23 then
				pcall(function()
					-- upvalues: (copy) p_u_22
					p_u_22.Volume = 0
					p_u_22:Stop()
					p_u_22:Destroy()
				end)
				v_u_6 = v_u_6 + 1
			end
			task.defer(function()
				-- upvalues: (copy) p_u_22, (ref) v_u_5, (ref) v_u_6
				if p_u_22.Parent then
					local v_u_25 = p_u_22
					local v26
					if v_u_25:IsA("Sound") and v_u_5[v_u_25.Name] then
						local v27 = v_u_25.SoundId
						v26 = v27 == "" and true or string.sub(v27, 1, 18) == "rbxasset://sounds/"
					else
						v26 = false
					end
					if not v26 then
						return
					end
					pcall(function()
						-- upvalues: (copy) v_u_25
						v_u_25.Volume = 0
						v_u_25:Stop()
						v_u_25:Destroy()
					end)
					v_u_6 = v_u_6 + 1
				end
			end)
		end
		table.insert(v20, v21:Connect(v28))
	end
	for _, v_u_30 in p14:GetChildren() do
		local v31
		if v_u_30:IsA("Sound") and v_u_5[v_u_30.Name] then
			local v32 = v_u_30.SoundId
			v31 = v32 == "" and true or string.sub(v32, 1, 18) == "rbxasset://sounds/"
		else
			v31 = false
		end
		if not v31 then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_30
			v_u_30.Volume = 0
			v_u_30:Stop()
			v_u_30:Destroy()
		end)
		v_u_6 = v_u_6 + 1
	end
	local v33 = p14:FindFirstChild("HumanoidRootPart")
	if v33 then
		v_u_29(v33)
	end
	local v34 = p14.ChildAdded
	local function v38(p_u_35)
		-- upvalues: (copy) v_u_29, (ref) v_u_5, (ref) v_u_6
		if p_u_35.Name == "HumanoidRootPart" then
			v_u_29(p_u_35)
			return
		else
			local v36
			if p_u_35:IsA("Sound") and v_u_5[p_u_35.Name] then
				local v37 = p_u_35.SoundId
				v36 = v37 == "" and true or string.sub(v37, 1, 18) == "rbxasset://sounds/"
			else
				v36 = false
			end
			if v36 then
				pcall(function()
					-- upvalues: (copy) p_u_35
					p_u_35.Volume = 0
					p_u_35:Stop()
					p_u_35:Destroy()
				end)
				v_u_6 = v_u_6 + 1
			end
		end
	end
	table.insert(p_u_15, v34:Connect(v38))
	v_u_4:SetAttribute("CharSoundsMuted", v_u_7 .. " removed=" .. v_u_6)
end
local function v_u_51(p40) -- name: watchPlayer
	-- upvalues: (copy) v_u_8, (copy) v_u_39
	local v41 = {}
	v_u_8[p40] = v41
	local v_u_42 = {}
	local function v45(p43) -- name: onChar
		-- upvalues: (copy) v_u_42, (ref) v_u_39
		for _, v44 in v_u_42 do
			v44:Disconnect()
		end
		table.clear(v_u_42)
		v_u_39(p43, v_u_42)
	end
	if p40.Character then
		local v46 = p40.Character
		for _, v47 in v_u_42 do
			v47:Disconnect()
		end
		table.clear(v_u_42)
		v_u_39(v46, v_u_42)
	end
	local v48 = p40.CharacterAdded
	table.insert(v41, v48:Connect(v45))
	local v49 = p40.CharacterRemoving
	table.insert(v41, v49:Connect(function()
		-- upvalues: (copy) v_u_42
		for _, v50 in v_u_42 do
			v50:Disconnect()
		end
		table.clear(v_u_42)
	end))
end
local function v_u_58() -- name: leftover
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v52 = 0
	for _, v53 in v_u_1:GetPlayers() do
		local v54 = v53.Character
		if not v54 then
			continue
		end
		for _, v55 in v54:GetDescendants() do
			local v56
			if v55:IsA("Sound") and v_u_5[v55.Name] then
				local v57 = v55.SoundId
				v56 = v57 == "" and true or string.sub(v57, 1, 18) == "rbxasset://sounds/"
			else
				v56 = false
			end
			if not v56 then
				continue
			end
			v52 = v52 + 1
		end
	end
	return v52
end
function v2.init(p59) -- name: init
	-- upvalues: (ref) v_u_3, (copy) v_u_13, (copy) v_u_4, (ref) v_u_7, (ref) v_u_6, (copy) v_u_58
	v_u_3 = p59
	v_u_13()
	v_u_4:SetAttribute("CharSoundsMuted", v_u_7 .. " removed=" .. v_u_6)
	if v_u_3 and v_u_3.command then
		v_u_3.command("charsounds.state", function()
			-- upvalues: (ref) v_u_7, (ref) v_u_6, (ref) v_u_58
			return string.format("script=%s removed=%d left=%d", v_u_7, v_u_6, (v_u_58()))
		end)
	end
end
function v2.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_51, (copy) v_u_8, (ref) v_u_7, (copy) v_u_13, (copy) v_u_4, (ref) v_u_6
	for _, v60 in v_u_1:GetPlayers() do
		v_u_51(v60)
	end
	v_u_1.PlayerAdded:Connect(v_u_51)
	v_u_1.PlayerRemoving:Connect(function(p61)
		-- upvalues: (ref) v_u_8
		local v62 = v_u_8[p61]
		if v62 then
			for _, v63 in v62 do
				v63:Disconnect()
			end
			v_u_8[p61] = nil
		end
	end)
	task.delay(3, function()
		-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_4, (ref) v_u_6
		if v_u_7 ~= "disabled" then
			v_u_13()
		end
		v_u_4:SetAttribute("CharSoundsMuted", v_u_7 .. " removed=" .. v_u_6)
	end)
end
return v2