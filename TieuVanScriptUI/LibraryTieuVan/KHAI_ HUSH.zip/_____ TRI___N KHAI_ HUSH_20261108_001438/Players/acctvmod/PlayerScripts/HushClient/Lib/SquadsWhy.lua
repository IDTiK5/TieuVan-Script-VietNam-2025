-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadsWhy

local v_u_18 = {
	["VIS_HELP"] = {
		["private"] = "Invite only. Nobody finds your squad in the browser, and you can only invite players on this server.",
		["friends"] = "Friends find your squad in SQUADS on any lobby server and can join. Nobody else sees it.",
		["public"] = "Everybody sees your squad in the browser and can join until it is full."
	},
	["INVITE_BODY"] = "Survivors on this server, friends first. A friend on another server finds you in SQUADS if your squad is FRIENDS or PUBLIC.",
	["inviteEmpty"] = function() -- name: inviteEmpty
		return "Nobody else is on this server right now. Open your squad as FRIENDS in SQUADS and friends on other servers find it there. PUBLIC lets solo players find it too."
	end,
	["SQUADS_TIP"] = "Find a squad to join, or choose who may join yours: private (invite only), friends, or public. This only decides who can join your squad in the lobby. The % is the share of your squad in an age group that can chat with you; ? means Roblox has not told us yet. For a raid without other squads use PRIVATE RAID on the PLAY tab.",
	["SQUADS_TIP_PVPVE"] = "Find a squad to join, or choose who may join yours: private (invite only), friends, or public. This only decides who can join your squad in the lobby. Squads always queue for public raids together. The % is the share of your squad in an age group that can chat with you; ? means Roblox has not told us yet.",
	["squadsTip"] = function(p1) -- name: squadsTip
		-- upvalues: (copy) v_u_18
		if p1 == true then
			return v_u_18.SQUADS_TIP_PVPVE
		else
			return v_u_18.SQUADS_TIP
		end
	end,
	["AGE_TIP"] = "Share of this squad\'s players who are in an age group that can chat with you. ? = Roblox has not told us yet.",
	["openHeader"] = function(p2) -- name: openHeader
		local v3 = p2.total
		local v4 = tonumber(v3) or 0
		local v5 = (v4 ~= v4 or v4 < 0) and 0 or math.floor(v4)
		local v6 = p2.open
		local v7
		if type(v6) == "number" then
			local v8 = p2.open
			local v9 = tonumber(v8) or 0
			local v10 = (v9 ~= v9 or v9 < 0) and 0 or math.floor(v9)
			v7 = math.min(v10, v5)
		else
			v7 = v5
		end
		local v11 = p2.cross and " (this and other lobby servers)" or " on this server"
		local v12 = ("%d open squad%s%s"):format(v7, v7 == 1 and "" or "s", v11)
		if v7 < v5 then
			v12 = v12 .. (", %d searching"):format(v5 - v7)
		end
		return v12
	end,
	["rowTags"] = function(p13) -- name: rowTags
		local v14 = {}
		if type(p13) ~= "table" then
			return v14
		end
		if p13.diffLocked == true then
			local v15 = string.upper
			local v16 = p13.diff or "Hard"
			local v17 = v15((tostring(v16))) .. " NOT UNLOCKED"
			table.insert(v14, v17)
		end
		if p13.searching == true then
			table.insert(v14, "SEARCHING")
		end
		return v14
	end,
	["ml"] = nil,
	["howFor"] = nil
}
local v_u_19 = nil
local v_u_20 = nil
function v_u_18.ladderOn() -- name: ladderOn
	-- upvalues: (ref) v_u_19, (copy) v_u_18, (ref) v_u_20
	if v_u_19 ~= nil then
		return v_u_19
	end
	local v21 = v_u_18.ml
	if v21 == nil then
		if v_u_20 == nil then
			local v22
			v22, v21 = pcall(function()
				local v23 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				local v24
				if v23 == nil then
					v24 = nil
				else
					v24 = v23:FindFirstChild("Shared")
				end
				local v25
				if v24 == nil then
					v25 = nil
				else
					v25 = v24:FindFirstChild("MapLadder")
				end
				if v25 == nil then
					return nil
				else
					return require(v25)
				end
			end)
			if v22 and type(v21) == "table" then
				v_u_20 = v21
			else
				v21 = nil
			end
		else
			v21 = v_u_20
		end
	end
	if type(v21) == "table" then
		local v26 = v21.enabled
		if type(v26) == "function" then
			local v27 = v21.howLine
			if type(v27) == "function" then
				local v28 = v21.enabled
				local v29, v30 = pcall(v28)
				if v29 then
					v29 = v30 == true
				end
				return v29
			end
		end
	end
	return false
end
function v_u_18.setSource(p31, p32) -- name: setSource
	-- upvalues: (copy) v_u_18, (ref) v_u_19
	local v33 = v_u_18
	if type(p31) ~= "table" then
		p31 = nil
	end
	v33.ml = p31
	local v34 = v_u_18
	if type(p32) ~= "function" then
		p32 = nil
	end
	v34.howFor = p32
	v_u_19 = nil
end
function v_u_18.setLadder(p35, p36) -- name: setLadder
	-- upvalues: (ref) v_u_19, (copy) v_u_18
	local v37
	if p35 == nil then
		v37 = nil
	else
		v37 = p35 == true
	end
	v_u_19 = v37
	local v38 = v_u_18
	if type(p36) ~= "function" then
		p36 = nil
	end
	v38.howFor = p36
end
local function v_u_47(p39, p40) -- name: defaultHow
	-- upvalues: (copy) v_u_18, (ref) v_u_20
	local v41 = v_u_18.ml
	if v41 == nil then
		if v_u_20 == nil then
			local v42
			v42, v41 = pcall(function()
				local v43 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				local v44
				if v43 == nil then
					v44 = nil
				else
					v44 = v43:FindFirstChild("Shared")
				end
				local v45
				if v44 == nil then
					v45 = nil
				else
					v45 = v44:FindFirstChild("MapLadder")
				end
				if v45 == nil then
					return nil
				else
					return require(v45)
				end
			end)
			if v42 and type(v41) == "table" then
				v_u_20 = v41
			else
				v41 = nil
			end
		else
			v41 = v_u_20
		end
	end
	local v46
	if type(v41) == "table" then
		v46 = v41.howLine
	else
		v46 = nil
	end
	if type(v46) == "function" then
		return v46(p39, p40, {
			["shop"] = false
		})
	else
		return nil
	end
end
function v_u_18.diffTip(p48, p49) -- name: diffTip
	-- upvalues: (copy) v_u_18, (copy) v_u_47
	if type(p49) == "table" and (p48 == "Hard" or p48 == "Nightmare") then
		local v50 = p49.map
		if type(v50) == "string" and (p49.map ~= "" and v_u_18.ladderOn()) then
			local v51 = string.find(p49.map, "^[%?%s]+$") ~= nil and "the next area" or p49.map
			local v52 = v_u_18.howFor
			if v52 == nil then
				v52 = v_u_47
			end
			local v53 = p49.mapId
			local v54, v55 = pcall(v52, v53, p48)
			return ("This squad plays %s on %s. You have not unlocked %s there yet.%s"):format(p48, v51, p48, (not v54 or (type(v55) ~= "string" or v55 == "")) and "" or " " .. v55)
		end
	end
	return p48 == "Hard" and "This squad plays Hard. You have not unlocked it yet: finish your first raid to unlock Hard." or (p48 == "Nightmare" and "This squad plays Nightmare. You have not unlocked it yet: it opens with Doc\'s task PATIENT ZERO." or ("This squad plays %s. You have not unlocked it yet."):format((tostring(p48))))
end
v_u_18.SEARCHING_TIP = "This squad is searching for a raid. Try again in a minute."
function v_u_18.joinState(p56) -- name: joinState
	-- upvalues: (copy) v_u_18
	if type(p56) ~= "table" then
		return nil
	end
	if p56.diffLocked ~= true then
		return p56.searching == true and {
			["text"] = "Busy",
			["title"] = "SEARCHING",
			["body"] = nil,
			["body"] = v_u_18.SEARCHING_TIP
		} or nil
	end
	local v57 = {
		["text"] = "Locked",
		["title"] = nil,
		["body"] = nil
	}
	local v58 = string.upper
	local v59 = p56.diff or "Hard"
	v57.title = v58((tostring(v59))) .. " NOT UNLOCKED"
	v57.body = v_u_18.diffTip(p56.diff, p56)
	return v57
end
function v_u_18.inviteButton(p60, p61) -- name: inviteButton
	if p60 == "Raid" then
		return "In a raid", false
	elseif p60 == "Transit" then
		return "Travelling", false
	else
		local v62 = tonumber(p61) or 0
		local v63 = math.ceil(v62)
		if v63 > 0 then
			return ("Sent %d s"):format(v63), false
		else
			return "Invite", true
		end
	end
end
function v_u_18.voiceButton(p64, p65) -- name: voiceButton
	return p64 and "Normal lobby" or (p65 and "Voice lobby" or "Voice lobby (soon)")
end
v_u_18.MIC_TIP = "Squad voice chat in the menu is not here yet. In a raid, voice is proximity based where Roblox voice is enabled."
v_u_18.MIC_TOAST_TITLE = "Party voice is not here yet"
v_u_18.MIC_TOAST_SUB = "In a raid, voice is proximity based where Roblox voice is enabled."
function v_u_18.inviteExpiry(p66, p67) -- name: inviteExpiry
	local v68 = tonumber(p66)
	local v69 = tonumber(p67)
	if v68 == nil or v69 == nil then
		return nil
	else
		local v70 = v68 - v69
		local v71 = math.ceil(v70)
		if v71 <= 0 then
			return nil
		else
			return ("Expires in %d s"):format(v71)
		end
	end
end
v_u_18.SEND_FAILED = "Your message was not sent. Roblox could not deliver it. Try again."
function v_u_18.chatStatusText(p72) -- name: chatStatusText
	local v73 = tostring(p72)
	local v74
	if v73 == "TextFilterFailed" or v73 == "ModerationTextFilter" then
		v74 = "Filtered by Roblox."
	elseif v73 == "Floodchecked" then
		v74 = "Too fast. Wait a moment."
	elseif v73 == "InvalidPrivacySettings" then
		v74 = "Your privacy settings block this chat."
	elseif v73 == "InvalidTextChannelPermissions" then
		v74 = "You cannot write in this chat right now."
	else
		if v73 ~= "MessageTooLong" then
			return "Your message was not sent."
		end
		v74 = "The message is too long."
	end
	return "Your message was not sent. " .. v74
end
function v_u_18.chatKeyReason(p75) -- name: chatKeyReason
	if type(p75) ~= "table" or p75.place ~= "Raid" then
		return nil
	end
	if p75.flagOn == false then
		return "Squad chat is switched off right now."
	end
	if p75.shown == false then
		return "Squad chat is turned off in SETTINGS."
	end
	local v76 = p75.channel
	return (type(v76) ~= "string" or p75.channel == "") and "Squad chat needs at least one squad mate in the raid." or nil
end
function v_u_18.keyDue(p77, p78) -- name: keyDue
	return p77 == nil and true or p78 - p77 >= 3
end
return v_u_18