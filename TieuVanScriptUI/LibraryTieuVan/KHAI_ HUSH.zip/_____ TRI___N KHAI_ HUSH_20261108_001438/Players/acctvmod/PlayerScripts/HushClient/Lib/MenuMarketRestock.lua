-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketRestock

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("TweenService")
local v_u_482 = {
	["TEAL"] = Color3.fromHex("#3FD0C9"),
	["TEAL_DEEP"] = Color3.fromHex("#0E2B2C"),
	["TEAL_DIM"] = Color3.fromHex("#2A8F8B"),
	["CARD_H"] = 270,
	["WIDE_MIN"] = 640,
	["STRIP_H"] = 48,
	["STRIP_H_PHONE"] = 40,
	["WARN_H"] = 30,
	["CHIPS_MIN_W"] = 980,
	["TEXT"] = {
		["empty"] = "There is no restock right now.",
		["loading"] = "Loading the restock",
		["hidden"] = "Nothing in this restock is open to your account.",
		["foot"] = "Prices are per unit. Your limits count for your account. Purchases come to your mail or your stash.",
		["pad"] = "L2 and R2 change the amount by ten. X sets the least, Y the most.",
		["back"] = "Back",
		["refresh"] = "Refresh",
		["view"] = "VIEW RESTOCK",
		["openMail"] = "OPEN MAIL",
		["title"] = "MARKET RESTOCK",
		["retry"] = "Retry"
	},
	["columnsFor"] = function(p3, p4) -- name: columnsFor
		-- upvalues: (copy) v_u_482
		if p4 ~= true then
			local v5
			if type(p3) == "number" and (p3 == p3 and p3 > (-1 / 0)) then
				v5 = p3 < (1 / 0)
			else
				v5 = false
			end
			if v5 and p3 >= v_u_482.WIDE_MIN then
				return 2
			end
		end
		return 1
	end,
	["chipTone"] = function(p6) -- name: chipTone
		return p6 == "ok" and "success" or ((p6 == "low" or p6 == "held") and "accent" or (p6 == "out" and "danger" or (p6 == "paused" and "info" or "teal")))
	end,
	["padAction"] = function(p7) -- name: padAction
		return p7 == "ButtonL2" and "tenDown" or (p7 == "ButtonR2" and "tenUp" or (p7 == "ButtonX" and "min" or (p7 == "ButtonY" and "max" or nil)))
	end,
	["sig"] = function(p8) -- name: sig
		if type(p8) == "table" then
			local v9 = p8.items
			if type(v9) == "table" then
				local v10 = {}
				local v11 = p8.r
				local v12 = tostring(v11)
				local v13 = p8.rv
				local v14 = tostring(v13)
				local v15 = p8.gen
				__set_list(v10, 1, {v12, v14, (tostring(v15))})
				for _, v16 in p8.items do
					if type(v16) ~= "table" then
						continue
					end
					local v17 = v16.i
					local v18 = tostring(v17)
					local v19 = v16.id
					local v20 = tostring(v19)
					local v21 = v16.u
					local v22 = tostring(v21)
					table.insert(v10, ("%s:%s:%s"):format(v18, v20, v22))
				end
				return table.concat(v10, "|")
			end
		end
		return "none"
	end,
	["cheapest"] = function(p23, p24, p25, p26, p27) -- name: cheapest
		if type(p24) == "table" then
			local v28 = p24.items
			if type(v28) == "table" and p23.rsPhase(p24, p26) == "live" then
				local v29 = nil
				for _, v30 in p24.items do
					if type(v30) ~= "table" or v30.id ~= p25 then
						continue
					end
					local v31 = v30.u
					local v32
					if type(v31) == "number" and (v31 == v31 and v31 > (-1 / 0)) then
						v32 = v31 < (1 / 0)
					else
						v32 = false
					end
					if not v32 then
						continue
					end
					local v33 = p23.rsStage(p24, v30, p26, nil)
					local v34
					if type(p27) == "table" then
						v34 = p27[v30.i]
					else
						v34 = nil
					end
					local v35
					if v30.st == "out" then
						v35 = true
					elseif type(v34) == "table" then
						v35 = v34.st == "out"
					else
						v35 = false
					end
					if v33 == "soon" or (v35 or v29 ~= nil and v30.u >= v29) then
						continue
					end
					v29 = v30.u
				end
				return v29 ~= nil and {
					["ph"] = "live",
					["u"] = nil,
					["u"] = v29
				} or nil
			end
		end
		return nil
	end,
	["LINE_LIFE"] = 15,
	["new"] = function(p_u_36, p_u_37) -- name: new
		-- upvalues: (copy) v_u_482, (copy) v_u_2, (copy) v_u_1
		local v_u_38 = p_u_36.ui
		local v_u_39 = p_u_36.theme
		local v_u_40 = p_u_36.C
		local v_u_41 = p_u_36.Data
		local v_u_42 = p_u_36.data
		local v_u_43 = p_u_36.h
		local v_u_44 = p_u_36.phone == true
		local v_u_45 = p_u_36.compact == true
		local v_u_46 = {}
		local v_u_47 = 166 + 2 * v_u_39.touch(44) + 16
		local v_u_48 = true
		local v_u_49 = {
			["body"] = nil,
			["fetching"] = false,
			["lastFetchAt"] = (-1 / 0),
			["lastFetchSrv"] = nil,
			["startDue"] = nil,
			["qty"] = nil,
			["armedAt"] = nil,
			["sending"] = nil,
			["line"] = nil,
			["widgets"] = nil,
			["stripSig"] = "",
			["stripH"] = 0,
			["pageOpen"] = false,
			["visible"] = false,
			["pulse"] = nil,
			["releases"] = nil,
			["conns"] = nil,
			["pins"] = nil,
			["lastDot"] = nil,
			["qty"] = {},
			["armedAt"] = {},
			["sending"] = {},
			["line"] = {},
			["widgets"] = {},
			["releases"] = {},
			["conns"] = {},
			["pins"] = {}
		}
		local v_u_50 = v_u_482.TEAL
		local function v_u_53(p51) -- name: clearKids
			for _, v52 in p51:GetChildren() do
				if v52:IsA("UIListLayout") or (v52:IsA("UIPadding") or v52:IsA("UIGridLayout")) then
					continue
				end
				v52:Destroy()
			end
		end
		function v_u_46.current() -- name: current
			-- upvalues: (copy) p_u_36, (copy) v_u_49
			local v54 = p_u_36.state
			if type(v54) == "table" then
				local v55 = v_u_49.body
				local v56
				if type(v55) == "table" then
					local v57 = v55._at
					local v58
					if type(v57) == "number" and (v57 == v57 and v57 > (-1 / 0)) then
						v58 = v57 < (1 / 0)
					else
						v58 = false
					end
					v56 = not v58 and (-1 / 0) or v55._at
				else
					v56 = (-1 / 0)
				end
				local v59 = v54._at
				local v60
				if type(v59) == "number" and (v59 == v59 and v59 > (-1 / 0)) then
					v60 = v59 < (1 / 0)
				else
					v60 = false
				end
				local v61 = not v60 and (-1 / 0) or v54._at
				local v62 = v54.rk
				if type(v62) == "table" then
					if type(v55) == "table" and v61 <= v56 then
						local v63 = v55.rk
						if type(v63) == "table" then
							return v55.rk, v55
						else
							return nil, nil
						end
					else
						return v54.rk, v54
					end
				else
					if type(v55) == "table" then
						local v64 = v55.rk
						if type(v64) == "table" and v61 < v56 then
							return v55.rk, v55
						end
					end
					return nil, nil
				end
			else
				return nil, nil
			end
		end
		function v_u_46.now() -- name: now
			-- upvalues: (copy) v_u_46, (copy) v_u_41, (copy) v_u_42
			local v65, v66 = v_u_46.current()
			if v65 == nil then
				return nil
			else
				return v_u_41.serverNow(v66, v_u_42:clock())
			end
		end
		function v_u_46.rows() -- name: rows
			-- upvalues: (copy) v_u_49, (copy) v_u_41, (copy) v_u_42
			local v67 = v_u_49.body
			if type(v67) == "table" then
				local v68 = v67.rk
				if type(v68) == "table" then
					return v67.rk, v_u_41.serverNow(v67, v_u_42:clock())
				end
			end
			return nil, nil
		end
		local function v_u_80(p69) -- name: adopt
			-- upvalues: (copy) v_u_49, (copy) v_u_42
			local v70 = v_u_49.body
			local v71
			if type(v70) == "table" then
				local v72 = v70.rk
				if type(v72) == "table" then
					v71 = v70.rk.r
				else
					v71 = nil
				end
			else
				v71 = nil
			end
			local v73
			if type(p69) == "table" then
				local v74 = p69.rk
				if type(v74) == "table" then
					v73 = p69.rk.r
				else
					v73 = nil
				end
			else
				v73 = nil
			end
			if v71 ~= nil and v73 ~= v71 then
				table.clear(v_u_49.qty)
				table.clear(v_u_49.armedAt)
				table.clear(v_u_49.sending)
				table.clear(v_u_49.line)
				table.clear(v_u_42.rsOpens)
				table.clear(v_u_42.rsMarks)
				table.clear(v_u_42.rsLast)
				if type(p69) == "table" then
					local v75 = p69.rk
					if type(v75) == "table" then
						local v76 = p69.rk.items
						if type(v76) == "table" then
							for _, v77 in p69.rk.items do
								if type(v77) ~= "table" then
									continue
								end
								local v78 = v77.i
								if type(v78) ~= "number" then
									continue
								end
								local v79 = v77.open
								if type(v79) ~= "number" then
									continue
								end
								v_u_42.rsOpens[v77.i] = v77.open
							end
						end
					end
				end
			end
			v_u_49.body = p69
		end
		function v_u_46.fetch(_) -- name: fetch
			-- upvalues: (copy) v_u_49, (ref) v_u_48, (copy) v_u_42, (copy) v_u_80, (copy) v_u_41, (copy) v_u_46
			if not v_u_49.fetching and v_u_48 then
				v_u_49.fetching = true
				v_u_49.lastFetchAt = v_u_42:clock()
				task.spawn(function()
					-- upvalues: (ref) v_u_42, (ref) v_u_49, (ref) v_u_48, (ref) v_u_80, (ref) v_u_41, (ref) v_u_46
					local v81 = v_u_42:restock(1)
					v_u_49.fetching = false
					if v_u_48 then
						if type(v81) == "table" and v81.ok ~= false then
							v_u_80(v81)
						else
							v_u_42.rk = v_u_49.body
						end
						local v82 = v_u_49
						local v83
						if v_u_49.body == nil then
							v83 = nil
						else
							v83 = v_u_41.serverNow(v_u_49.body, v_u_42:clock())
						end
						v82.lastFetchSrv = v83
						v_u_46.sync()
					end
				end)
			end
		end
		local function v_u_92(p84, p85) -- name: maybeFetch
			-- upvalues: (copy) v_u_42, (copy) v_u_41, (copy) v_u_49, (copy) v_u_46
			local v86 = v_u_42:clock()
			local v87 = v_u_41.serverNow(p85, v86)
			if v87 == nil then
				return
			elseif v_u_49.body == nil then
				if not v_u_49.fetching and v86 - v_u_49.lastFetchAt >= 3 then
					v_u_46.fetch()
				end
			else
				local v88 = v_u_49.body.rk
				local v89
				if type(v88) == "table" then
					v89 = v_u_49.body.rk.items
				else
					v89 = nil
				end
				local v90, v91 = v_u_41.rsFetchDelay(p84, v89, v_u_49.lastFetchSrv or v87, v87, v86 - v_u_49.lastFetchAt, v_u_49.pageOpen, math.random())
				if v91 == "start" then
					if v_u_49.startDue == nil then
						v_u_49.startDue = v86 + v90
						v_u_49.lastFetchSrv = v87
					end
				elseif v90 <= 0 then
					v_u_46.fetch()
				end
				if v_u_49.startDue ~= nil and v_u_49.startDue <= v86 then
					v_u_49.startDue = nil
					v_u_46.fetch()
				end
			end
		end
		function v_u_46.active() -- name: active
			-- upvalues: (copy) v_u_46, (copy) v_u_41, (copy) v_u_42
			local v93, v94 = v_u_46.current()
			if v93 == nil then
				return false
			end
			local v95 = v_u_41.serverNow(v94, v_u_42:clock())
			local v96 = v_u_41.rsPhase(v93, v95)
			local v97
			if v96 == nil then
				v97 = false
			else
				v97 = v96 ~= "over"
			end
			return v97
		end
		function v_u_46.tiles() -- name: tiles
			-- upvalues: (copy) v_u_46, (copy) v_u_41, (copy) v_u_42
			local v98, v99 = v_u_46.rows()
			return (v98 == nil or (v99 == nil or not v_u_46.active())) and {} or v_u_41.rsTiles(v98, v99, v_u_42.rsMarks)
		end
		function v_u_46.tile(p100) -- name: tile
			-- upvalues: (copy) v_u_46
			return v_u_46.tiles()[p100]
		end
		function v_u_46.filterIds() -- name: filterIds
			-- upvalues: (copy) v_u_46, (copy) v_u_41
			local v101, v102 = v_u_46.rows()
			return (v101 == nil or (v102 == nil or not v_u_46.active())) and {} or v_u_41.rsFilterIds(v101, v102)
		end
		function v_u_46.cheapest(p103) -- name: cheapest
			-- upvalues: (copy) v_u_46, (ref) v_u_482, (copy) v_u_41, (copy) v_u_42
			local v104, v105 = v_u_46.rows()
			if v104 == nil or (v105 == nil or not v_u_46.active()) then
				return nil
			else
				return v_u_482.cheapest(v_u_41, v104, p103, v105, v_u_42.rsMarks)
			end
		end
		local function v_u_110(p106) -- name: itemOf
			-- upvalues: (copy) v_u_46
			local v107 = v_u_46.rows()
			if type(v107) == "table" then
				local v108 = v107.items
				if type(v108) == "table" then
					for _, v109 in v107.items do
						if type(v109) ~= "table" or v109.i ~= p106 then
							continue
						end
						return v109
					end
				end
			end
			return nil
		end
		local v_u_247 = {
			["paint"] = function(p111) -- name: paint
				-- upvalues: (copy) v_u_46, (copy) v_u_110, (copy) v_u_42, (copy) v_u_49, (copy) v_u_41, (copy) v_u_38, (ref) v_u_482, (copy) v_u_40, (copy) v_u_50
				local v112, v113 = v_u_46.rows()
				local v114 = v_u_110(p111.ix)
				if v112 ~= nil and (v113 ~= nil and v114 ~= nil) then
					local v115 = p111.ix
					local v116 = v_u_42:clock()
					local v117 = v_u_42:rsCtx({
						["qty"] = v_u_49.qty
					})
					local v118 = v117.per
					if type(v118) == "function" then
						local v119 = v117.per(v115)
						v117.per = nil
						if type(v119) == "table" then
							for v120, v121 in v119 do
								v117[v120] = v121
							end
						end
					end
					local v122 = v_u_41.rsCard(v112, v114, v117)
					p111.card = v122
					p111.item = v114
					v_u_49.qty[v115] = v122.qty
					local v123
					if v_u_49.armedAt[v115] == nil then
						v123 = false
					else
						local v124 = v_u_41.rsConfirm(v_u_49.armedAt[v115], v116)
						v123 = v124.armed
						if not v124.armed then
							v_u_49.armedAt[v115] = nil
						end
					end
					local v125 = v122.button
					if v123 and (v125.enabled ~= true or v125.less ~= nil) then
						v_u_49.armedAt[v115] = nil
						v123 = false
					end
					local v126 = v_u_49.sending[v115] == true
					local v127 = p111.name
					local v128 = v122.name
					if v127 ~= nil and (v127.Parent ~= nil and v127:GetAttribute("RsText") ~= v128) then
						v127:SetAttribute("RsText", v128)
						local v129 = v_u_38.setText
						pcall(v129, v127, v128)
					end
					local v130 = p111.unit
					local v131 = v122.unit
					if v130 ~= nil and (v130.Parent ~= nil and v130:GetAttribute("RsText") ~= v131) then
						v130:SetAttribute("RsText", v131)
						local v132 = v_u_38.setText
						pcall(v132, v130, v131)
					end
					local v133 = p111.total
					local v134 = v122.totalText
					if v133 ~= nil and (v133.Parent ~= nil and v133:GetAttribute("RsText") ~= v134) then
						v133:SetAttribute("RsText", v134)
						local v135 = v_u_38.setText
						pcall(v135, v133, v134)
					end
					local v136 = v122.chip
					local v137 = v_u_482.chipTone(v136.kind)
					local v138 = p111.chipLbl
					local v139 = v136.text
					if v138 ~= nil and (v138.Parent ~= nil and v138:GetAttribute("RsText") ~= v139) then
						v138:SetAttribute("RsText", v139)
						local v140 = v_u_38.setText
						pcall(v140, v138, v139)
					end
					local v141 = p111.chipLbl
					local v142
					if v137 == "success" then
						v142 = v_u_40.success
					elseif v137 == "accent" then
						v142 = v_u_40.accent
					elseif v137 == "danger" then
						v142 = v_u_40.danger
					elseif v137 == "info" then
						v142 = v_u_40.info
					else
						v142 = v_u_50
					end
					v141.TextColor3 = v142
					local v143 = p111.chipStroke
					local v144
					if v137 == "success" then
						v144 = v_u_40.success
					elseif v137 == "accent" then
						v144 = v_u_40.accent
					elseif v137 == "danger" then
						v144 = v_u_40.danger
					elseif v137 == "info" then
						v144 = v_u_40.info
					else
						v144 = v_u_50
					end
					v143.Color = v144
					p111.frame:SetAttribute("Chip", v136.st)
					p111.frame:SetAttribute("Stage", v122.stage)
					p111.frame:SetAttribute("Ix", v115)
					p111.drop.Visible = v122.drop ~= nil
					if v122.drop ~= nil then
						local v145 = p111.dropLbl
						local v146 = v122.drop
						if v145 ~= nil and (v145.Parent ~= nil and v145:GetAttribute("RsText") ~= v146) then
							v145:SetAttribute("RsText", v146)
							local v147 = v_u_38.setText
							pcall(v147, v145, v146)
						end
					end
					local v148 = p111.limit
					local v149 = v122.limit or ""
					if v148 ~= nil and (v148.Parent ~= nil and v148:GetAttribute("RsText") ~= v149) then
						v148:SetAttribute("RsText", v149)
						local v150 = v_u_38.setText
						pcall(v150, v148, v149)
					end
					local v151 = p111.left
					local v152 = v122.left or ""
					if v151 ~= nil and (v151.Parent ~= nil and v151:GetAttribute("RsText") ~= v152) then
						v151:SetAttribute("RsText", v152)
						local v153 = v_u_38.setText
						pcall(v153, v151, v152)
					end
					local v154 = ""
					local v155 = v_u_40.text2
					local v156 = v_u_49.line[v115]
					if v156 ~= nil and v116 - v156.at > v_u_482.LINE_LIFE then
						v_u_49.line[v115] = nil
						v156 = nil
					end
					if v126 then
						v154 = v_u_41.RS_EXTRA.GETTING
						v155 = v_u_50
					elseif v156 == nil then
						if v125.enabled == true or (v125.reason == nil or v125.brief == true) then
							if v122.opening == nil then
								if v122.opens ~= nil then
									v154 = v122.opens
									v155 = v_u_50
								end
							else
								v154 = v122.opening
								v155 = v_u_50
							end
						else
							v154 = v125.reason
							v155 = v_u_40.accent
						end
					else
						v154 = v156.text
						if v156.kind == "success" then
							v155 = v_u_40.success
						elseif v156.kind == "warn" then
							v155 = v_u_40.accent
						else
							v155 = v_u_40.danger
						end
					end
					local v157 = p111.status
					if v157 ~= nil and (v157.Parent ~= nil and v157:GetAttribute("RsText") ~= v154) then
						v157:SetAttribute("RsText", v154)
						local v158 = v_u_38.setText
						pcall(v158, v157, v154)
					end
					p111.status.TextColor3 = v155
					local v159 = p111.qty
					local v160 = v_u_41.commas(v122.qty)
					if v159 ~= nil and (v159.Parent ~= nil and v159:GetAttribute("RsText") ~= v160) then
						v159:SetAttribute("RsText", v160)
						local v161 = v_u_38.setText
						pcall(v161, v159, v160)
					end
					local v162 = not v126
					if v162 then
						v162 = v122.stage ~= "soon"
					end
					local v163 = p111.minus.api.setEnabled
					local v164
					if v162 then
						v164 = v122.qty > v122.q1
					else
						v164 = v162
					end
					v163(v164)
					local v165 = p111.plus.api.setEnabled
					local v166
					if v162 then
						v166 = v122.qty < v122.max
					else
						v166 = v162
					end
					v165(v166)
					local v167 = p111.min.api.setEnabled
					local v168
					if v162 then
						v168 = v122.qty > v122.q1
					else
						v168 = v162
					end
					v167(v168)
					local v169 = p111.max.api.setEnabled
					if v162 then
						v162 = v122.qty < v122.max
					end
					v169(v162)
					local v170 = true
					local v171
					if v126 then
						v171 = v_u_41.RS_EXTRA.GETTING
						v170 = false
					elseif v125.less == nil then
						if v125.enabled == true then
							if v123 then
								v171 = v_u_41.rsConfirmLabel(v125.total or v122.total)
							else
								v171 = v125.label
							end
						else
							if v125.brief == true then
								v171 = v125.label
							else
								v171 = v125.short or v125.label
							end
							v170 = false
						end
					else
						v171 = v125.label
					end
					p111.buy.api.setText(v171)
					p111.buy.api.setEnabled(v170)
					p111.buy.api.setKind(v170 and "primary" or "secondary")
					p111.buy.btn:SetAttribute("Armed", v123)
					p111.buy.btn:SetAttribute("Why", v125.why)
					p111.frame:SetAttribute("Why", v125.why)
					p111.frame:SetAttribute("Qty", v122.qty)
				end
			end,
			["press"] = function(p172) -- name: press
				-- upvalues: (copy) v_u_49, (copy) v_u_42, (copy) v_u_247, (copy) v_u_38, (copy) v_u_41, (copy) v_u_46, (ref) v_u_48
				local v_u_173 = p172.ix
				local v174 = p172.card
				local v175 = p172.item
				if v174 == nil or (v175 == nil or v_u_49.sending[v_u_173] == true) then
					return
				else
					local v176 = v174.button
					local v177 = v_u_42:clock()
					if v176.less == nil then
						if v176.enabled == true then
							local v178 = v_u_41.rsConfirm(v_u_49.armedAt[v_u_173], v177)
							if v178.armed then
								if v178.accepts then
									local v179 = v_u_46.rows()
									if type(v179) == "table" then
										v_u_49.sending[v_u_173] = true
										v_u_49.armedAt[v_u_173] = nil
										v_u_49.line[v_u_173] = nil
										v_u_247.paint(p172)
										local v_u_180 = v174.qty
										local v_u_181 = v175.u
										local v_u_182 = v179.r
										task.spawn(function()
											-- upvalues: (ref) v_u_42, (copy) v_u_182, (copy) v_u_173, (copy) v_u_180, (copy) v_u_181, (ref) v_u_49, (ref) v_u_48, (ref) v_u_41, (ref) v_u_38, (ref) v_u_46
											local v183 = v_u_42:rsBuy({
												["r"] = v_u_182,
												["i"] = v_u_173,
												["n"] = v_u_180,
												["u"] = v_u_181
											})
											v_u_49.sending[v_u_173] = nil
											if v_u_48 then
												local v184 = v_u_41.rsResultLine(v183)
												v184.at = v_u_42:clock()
												if v184.kind == "success" then
													if v184.saving == true and not string.find(v184.text, "Saving", 1, true) then
														v184.text = v184.text .. " Saving."
													end
													local v185 = v_u_38.toast
													local v186 = v184.text
													pcall(v185, v186, "success")
												end
												v_u_49.line[v_u_173] = v184
												v_u_46.fetch(true)
												v_u_46.sync()
											end
										end)
									end
								else
									return
								end
							else
								v_u_49.armedAt[v_u_173] = v177
								v_u_247.paint(p172)
								return
							end
						else
							local v187 = v176.reason or v176.short
							if type(v187) == "string" and v187 ~= "" then
								local v188 = v_u_38.toast
								pcall(v188, v187, "warn")
							end
							return
						end
					else
						v_u_49.qty[v_u_173] = v176.setQty
						v_u_42:rsClearLast(v_u_173)
						v_u_49.armedAt[v_u_173] = v177
						v_u_247.paint(p172)
						return
					end
				end
			end,
			["step"] = function(p189, p190) -- name: step
				-- upvalues: (copy) v_u_49, (copy) v_u_41, (copy) v_u_42, (copy) v_u_247
				local v191 = p189.card
				local v192 = p189.item
				if v191 ~= nil and (v192 ~= nil and v_u_49.sending[p189.ix] ~= true) then
					local v193 = v_u_49.qty
					local v194 = p189.ix
					local v195 = v_u_41.rsStepQty
					local v196 = v191.qty
					local function v197()
						-- upvalues: (ref) v_u_42
						return v_u_42:cash()
					end
					local v198, v199 = pcall(v197)
					if v198 then
						local v200
						if type(v199) == "number" and (v199 == v199 and v199 > (-1 / 0)) then
							v200 = v199 < (1 / 0)
						else
							v200 = false
						end
						if not v200 then
							v199 = nil
						end
					else
						v199 = nil
					end
					v193[v194] = v195(v192, v196, p190, v199)
					local v201 = p189.ix
					v_u_49.armedAt[v201] = nil
					v_u_49.line[p189.ix] = nil
					v_u_42:rsClearLast(p189.ix)
					v_u_247.paint(p189)
				end
			end,
			["new"] = function(p202, p203, p204, p205) -- name: new
				-- upvalues: (copy) v_u_38, (ref) v_u_482, (copy) v_u_47, (copy) v_u_43, (copy) v_u_40, (copy) v_u_41, (copy) v_u_50, (copy) v_u_39, (copy) v_u_247
				local v_u_206 = {
					["ix"] = p203,
					["id"] = p204,
					["releases"] = {}
				}
				local v207 = v_u_38.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.05,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["ClipsDescendants"] = true,
					["Name"] = "RsCard_" .. tostring(p203),
					["BackgroundColor3"] = v_u_482.TEAL_DEEP,
					["Size"] = UDim2.new(1, 0, 0, v_u_47),
					["LayoutOrder"] = p205
				}, p202)
				v_u_38.stroke(v207, v_u_482.TEAL_DIM)
				v_u_38.new("Frame", {
					["Name"] = "Strip",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["ZIndex"] = 2,
					["BackgroundColor3"] = v_u_482.TEAL,
					["Size"] = UDim2.new(1, 0, 0, 4)
				}, v207)
				v_u_206.frame = v207
				local _, v208 = v_u_43.icon(v207, p204, 56, {
					["position"] = UDim2.fromOffset(12, 14)
				})
				local v209 = v_u_206.releases
				table.insert(v209, v208)
				v_u_206.name = v_u_38.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = "",
					["style"] = "bodyStrong",
					["textSize"] = 18,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_40.text,
					["position"] = UDim2.fromOffset(76, 12),
					["size"] = UDim2.new(1, -212, 0, 24)
				})
				v_u_206.word = v_u_43.pill(v207, v_u_41.RS_WORD or "RESTOCK", v_u_50, {
					["name"] = "Word",
					["position"] = nil,
					["h"] = 18,
					["solid"] = true,
					["position"] = UDim2.fromOffset(76, 42)
				})
				v_u_206.drop = v_u_43.pill(v207, "", v_u_50, {
					["name"] = "Drop",
					["position"] = nil,
					["h"] = 18,
					["position"] = UDim2.fromOffset(158, 42)
				})
				v_u_206.dropLbl = v_u_206.drop:FindFirstChild("Text")
				v_u_206.drop.Visible = false
				local v210 = v_u_38.new("Frame", {
					["Name"] = "Chip",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.2,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_40.bgDeep,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -12, 0, 14),
					["Size"] = UDim2.fromOffset(116, 20)
				}, v207)
				v_u_206.chipStroke = v_u_38.stroke(v210, v_u_50)
				v_u_206.chipLbl = v_u_38.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = "",
					["style"] = "micro",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v210,
					["color"] = v_u_50,
					["size"] = UDim2.fromScale(1, 1)
				})
				v_u_206.unit = v_u_38.label({
					["parent"] = nil,
					["name"] = "Unit",
					["text"] = "",
					["style"] = "mono",
					["textSize"] = 17,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_50,
					["position"] = UDim2.fromOffset(12, 76),
					["size"] = UDim2.new(0.5, -12, 0, 22)
				})
				v_u_206.total = v_u_38.label({
					["parent"] = nil,
					["name"] = "Total",
					["text"] = "",
					["style"] = "mono",
					["textSize"] = 15,
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_40.text,
					["position"] = UDim2.new(0.5, 0, 0, 76),
					["size"] = UDim2.new(0.5, -12, 0, 22)
				})
				v_u_206.limit = v_u_38.label({
					["parent"] = nil,
					["name"] = "Limit",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_40.text2,
					["position"] = UDim2.fromOffset(12, 100),
					["size"] = UDim2.new(1, -24, 0, 18)
				})
				v_u_206.left = v_u_38.label({
					["parent"] = nil,
					["name"] = "Left",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_40.text,
					["position"] = UDim2.fromOffset(12, 118),
					["size"] = UDim2.new(1, -24, 0, 18)
				})
				v_u_206.status = v_u_38.label({
					["parent"] = nil,
					["name"] = "Status",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["valign"] = "top",
					["track"] = false,
					["parent"] = v207,
					["color"] = v_u_40.text2,
					["position"] = UDim2.fromOffset(12, 136),
					["size"] = UDim2.new(1, -24, 0, 32)
				})
				local v_u_211 = v_u_39.touch(44)
				local v_u_212 = v_u_38.new("Frame", {
					["Name"] = "Stepper",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(12, 170),
					["Size"] = UDim2.new(1, -24, 0, v_u_211)
				}, v207)
				v_u_38.layout(v_u_212, "h", 4)
				local function v237(p213, p214, p215, p216, p_u_217) -- name: sbtn
					-- upvalues: (ref) v_u_38, (ref) v_u_40, (copy) v_u_211, (copy) v_u_212, (ref) v_u_39, (ref) v_u_482
					local v_u_218 = v_u_38.new("TextButton", {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Selectable"] = true,
						["Name"] = p213,
						["BackgroundColor3"] = v_u_40.raised,
						["Size"] = UDim2.fromOffset(p215, v_u_211),
						["LayoutOrder"] = p216
					}, v_u_212)
					local function v219()
						-- upvalues: (copy) v_u_218, (ref) v_u_38
						v_u_218.SelectionImageObject = v_u_38.selectionImage()
					end
					pcall(v219)
					local v_u_220 = v_u_38.stroke(v_u_218, v_u_40.lineStrong)
					local v_u_221 = {}
					local v_u_222 = nil
					if p214 == "minus" or p214 == "plus" then
						local v223 = v_u_38.new("Frame", {
							["Name"] = "BarH",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = v_u_40.text,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Size"] = UDim2.fromOffset(14, 2)
						}, v_u_218)
						table.insert(v_u_221, v223)
						if p214 == "plus" then
							local v224 = v_u_38.new
							local v225 = {
								["Name"] = "BarV",
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_40.text,
								["AnchorPoint"] = Vector2.new(0.5, 0.5),
								["Position"] = UDim2.fromScale(0.5, 0.5),
								["Size"] = UDim2.fromOffset(2, 14)
							}
							table.insert(v_u_221, v224("Frame", v225, v_u_218))
						end
						v_u_218:SetAttribute("Glyph", p214 == "plus" and "plus" or "minus")
					else
						v_u_222 = v_u_38.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "caps",
							["textSize"] = 15,
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v_u_218,
							["text"] = p214,
							["color"] = v_u_40.text,
							["size"] = UDim2.fromScale(1, 1)
						})
					end
					local v_u_226 = true
					local v234 = {
						["setEnabled"] = function(p227) -- name: setEnabled
							-- upvalues: (ref) v_u_226, (ref) v_u_222, (ref) v_u_40, (copy) v_u_221, (copy) v_u_220, (copy) v_u_218
							v_u_226 = p227
							if v_u_222 ~= nil then
								local v228 = v_u_222
								local v229
								if p227 then
									v229 = v_u_40.text
								else
									v229 = v_u_40.muted
								end
								v228.TextColor3 = v229
							end
							for _, v230 in v_u_221 do
								local v231
								if p227 then
									v231 = v_u_40.text
								else
									v231 = v_u_40.muted
								end
								v230.BackgroundColor3 = v231
							end
							local v232 = v_u_220
							local v233
							if p227 then
								v233 = v_u_40.lineStrong
							else
								v233 = v_u_40.line
							end
							v232.Color = v233
							v_u_218:SetAttribute("Disabled", not p227)
						end
					}
					v_u_218.Activated:Connect(function()
						-- upvalues: (ref) v_u_226, (ref) v_u_38, (ref) v_u_39, (copy) p_u_217
						if v_u_226 then
							v_u_38.sound(v_u_39.sounds.click)
							task.spawn(p_u_217)
						end
					end)
					v_u_218.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_226, (copy) v_u_220, (ref) v_u_482
						if v_u_226 then
							v_u_220.Color = v_u_482.TEAL
						end
					end)
					v_u_218.MouseLeave:Connect(function()
						-- upvalues: (copy) v_u_220, (ref) v_u_226, (ref) v_u_40
						local v235 = v_u_220
						local v236
						if v_u_226 then
							v236 = v_u_40.lineStrong
						else
							v236 = v_u_40.line
						end
						v235.Color = v236
					end)
					return {
						["btn"] = v_u_218,
						["api"] = v234
					}
				end
				v_u_206.minus = v237("Minus", "minus", v_u_211, 1, function()
					-- upvalues: (ref) v_u_247, (copy) v_u_206
					v_u_247.step(v_u_206, "down")
				end)
				local v238 = v_u_38.new("Frame", {
					["Name"] = "QtyBox",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.2,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["BackgroundColor3"] = v_u_40.bgDeep,
					["Size"] = UDim2.fromOffset(60, v_u_211)
				}, v_u_212)
				v_u_38.stroke(v238, v_u_40.line)
				v_u_206.qty = v_u_38.label({
					["parent"] = nil,
					["name"] = "Qty",
					["text"] = "",
					["style"] = "mono",
					["textSize"] = 17,
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v238,
					["color"] = v_u_40.text,
					["size"] = UDim2.fromScale(1, 1)
				})
				v_u_206.plus = v237("Plus", "plus", v_u_211, 3, function()
					-- upvalues: (ref) v_u_247, (copy) v_u_206
					v_u_247.step(v_u_206, "up")
				end)
				v_u_206.min = v237("Min", "MIN", v_u_39.touch(56), 4, function()
					-- upvalues: (ref) v_u_247, (copy) v_u_206
					v_u_247.step(v_u_206, "min")
				end)
				v_u_206.max = v237("Max", "MAX", v_u_39.touch(56), 5, function()
					-- upvalues: (ref) v_u_247, (copy) v_u_206
					v_u_247.step(v_u_206, "max")
				end)
				local v242, v243 = v_u_43.button(v207, "BUY", "primary", function()
					-- upvalues: (ref) v_u_247, (copy) v_u_206
					v_u_247.press(v_u_206)
				end, {
					["name"] = "Buy",
					["size"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["maxTextWidth"] = 300,
					["onDisabledClick"] = nil,
					["size"] = UDim2.new(1, -24, 0, v_u_211),
					["anchor"] = Vector2.new(0, 1),
					["position"] = UDim2.new(0, 12, 1, -10),
					["onDisabledClick"] = function() -- name: onDisabledClick
						-- upvalues: (copy) v_u_206, (ref) v_u_38
						local v239 = v_u_206.card
						if v239 ~= nil then
							local v240 = v239.button.reason or v239.button.short
							if type(v240) == "string" and v240 ~= "" then
								local v241 = v_u_38.toast
								pcall(v241, v240, "warn")
							end
						end
					end
				})
				v_u_206.buy = {
					["btn"] = v242,
					["api"] = v243
				}
				return v_u_206
			end,
			["destroy"] = function(p244) -- name: destroy
				-- upvalues: (copy) v_u_49
				for _, v245 in p244.releases do
					pcall(v245)
				end
				table.clear(p244.releases)
				local v246 = table.find(v_u_49.widgets, p244)
				if v246 then
					table.remove(v_u_49.widgets, v246)
				end
				if p244.frame ~= nil then
					p244.frame:Destroy()
				end
			end
		}
		v_u_46.Card = v_u_247
		local function v_u_272(p_u_248, p_u_249) -- name: newHost
			-- upvalues: (copy) v_u_46, (copy) v_u_247, (copy) v_u_49
			local v_u_271 = {
				["widgets"] = nil,
				["sig"] = "",
				["widgets"] = {},
				["sync"] = function() -- name: sync
					-- upvalues: (ref) v_u_46, (copy) p_u_249, (copy) v_u_271, (ref) v_u_247, (copy) p_u_248, (ref) v_u_49
					local v250 = v_u_46.rows()
					local v251 = v250 == nil and {} or p_u_249(v250)
					local v252 = {}
					for _, v253 in v251 do
						local v254 = v253.i
						local v255 = tostring(v254)
						local v256 = v253.id
						local v257 = tostring(v256)
						table.insert(v252, ("%s:%s"):format(v255, v257))
					end
					local v258 = table.concat(v252, "|")
					local v259 = "/"
					local v260
					if v250 == nil then
						v260 = ""
					else
						local v261 = v250.r
						v260 = tostring(v261)
					end
					local v262 = v258 .. v259 .. v260
					if v262 ~= v_u_271.sig then
						v_u_271.sig = v262
						for _, v263 in v_u_271.widgets do
							v_u_247.destroy(v263)
						end
						table.clear(v_u_271.widgets)
						for v264, v265 in v251 do
							local v266 = v_u_247.new(p_u_248, v265.i, v265.id, v264)
							local v267 = v_u_271.widgets
							table.insert(v267, v266)
							local v268 = v_u_49.widgets
							table.insert(v268, v266)
						end
					end
					for _, v269 in v_u_271.widgets do
						v_u_247.paint(v269)
					end
				end,
				["destroy"] = function() -- name: destroy
					-- upvalues: (copy) v_u_271, (ref) v_u_247
					for _, v270 in v_u_271.widgets do
						v_u_247.destroy(v270)
					end
					table.clear(v_u_271.widgets)
					v_u_271.sig = ""
				end
			}
			return v_u_271
		end
		local v_u_273 = {
			["icons"] = {}
		}
		local v274
		if v_u_44 then
			v274 = v_u_482.STRIP_H_PHONE
		else
			v274 = v_u_482.STRIP_H
		end
		local v275 = v_u_482.WARN_H
		v_u_49.mainH = v274
		v_u_49.warnH = v275
		v_u_49.viewH = 36
		v_u_49.mailH = 26
		v_u_49.pairY = 2
		pcall(function()
			-- upvalues: (copy) p_u_36, (copy) v_u_44, (copy) v_u_39, (copy) v_u_49
			local v276 = p_u_36.mc.cctx.lib.MenuMarketLayout.strip({
				["phone"] = nil,
				["floor"] = nil,
				["w"] = 600,
				["warn"] = true,
				["phone"] = v_u_44,
				["floor"] = v_u_39.touch(1)
			})
			local v277 = v_u_49
			local v278 = v_u_49
			local v279 = v_u_49
			local v280 = v_u_49
			local v281 = v_u_49
			local v282 = v276.mainH
			local v283 = v276.warnH
			local v284 = v276.view.h
			local v285 = v276.mail.h
			local v286 = v276.textTop.y
			v277.mainH = v282
			v278.warnH = v283
			v279.viewH = v284
			v280.mailH = v285
			v281.pairY = v286
		end)
		local v_u_287 = v_u_38.new("Frame", {
			["Name"] = "RestockStrip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_482.TEAL_DEEP,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_37)
		v_u_273.frame = v_u_287
		v_u_273.stroke = v_u_38.stroke(v_u_287, v_u_482.TEAL, 1)
		v_u_38.new("Frame", {
			["Name"] = "Mark",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_482.TEAL,
			["Size"] = UDim2.new(0, 4, 1, 0)
		}, v_u_287)
		local v288 = v_u_38.new("Frame", {
			["Name"] = "Main",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, 0),
			["Size"] = UDim2.new(1, 0, 0, v_u_49.mainH)
		}, v_u_287)
		v_u_273.main = v288
		local v_u_289 = v_u_38.new("Frame", {
			["Name"] = "Icons",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(14, 0),
			["Size"] = UDim2.fromOffset(0, v_u_49.mainH)
		}, v288)
		v_u_273.iconHost = v_u_289
		local v_u_290 = not v_u_44 and 156 or v_u_39.touch(40)
		v_u_273.textLbl = v_u_38.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "bodyStrong",
			["textSize"] = nil,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v288,
			["textSize"] = v_u_44 and 14 or 17,
			["color"] = v_u_482.TEAL,
			["position"] = UDim2.fromOffset(14, 0),
			["size"] = UDim2.new(1, -(14 + v_u_290 + 12), 0, not v_u_44 and 26 or v_u_49.mainH)
		})
		v_u_273.dropLbl = v_u_38.label({
			["parent"] = nil,
			["name"] = "Drop",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["visible"] = nil,
			["parent"] = v288,
			["color"] = v_u_40.text2,
			["position"] = UDim2.fromOffset(14, v_u_49.pairY + 26),
			["size"] = UDim2.new(1, -(14 + v_u_290 + 12), 0, 18),
			["visible"] = not v_u_44
		})
		v_u_273.chipHost = v_u_38.new("Frame", {
			["Name"] = "Chips",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -(v_u_290 + 20), 0.5, 0),
			["Size"] = UDim2.fromOffset(0, 22),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v288)
		v_u_38.layout(v_u_273.chipHost, "h", 6)
		if v_u_44 then
			local v291, v292 = v_u_38.iconButton({
				["parent"] = nil,
				["icon"] = "chevronRight",
				["size"] = nil,
				["kind"] = "secondary",
				["name"] = "View",
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v288,
				["size"] = v_u_290,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -8, 0.5, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_46
					v_u_46.openPage()
				end
			})
			v_u_273.viewBtn = v291
			v_u_273.viewApi = v292
		else
			local v293, v294 = v_u_43.button(v288, v_u_482.TEXT.view, "primary", function()
				-- upvalues: (copy) v_u_46
				v_u_46.openPage()
			end, {
				["name"] = "View",
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["maxTextWidth"] = nil,
				["size"] = UDim2.fromOffset(v_u_290, v_u_49.viewH),
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -8, 0.5, 0),
				["maxTextWidth"] = v_u_290 - 24
			})
			v_u_273.viewBtn = v293
			v_u_273.viewApi = v294
		end
		local v295 = v_u_38.new("Frame", {
			["Name"] = "Warn",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Position"] = UDim2.fromOffset(0, v_u_49.mainH),
			["Size"] = UDim2.new(1, 0, 0, v_u_49.warnH)
		}, v_u_287)
		v_u_273.warnRow = v295
		v_u_273.warnLbl = v_u_38.label({
			["parent"] = nil,
			["name"] = "WarnText",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v295,
			["color"] = v_u_40.accent,
			["position"] = UDim2.fromOffset(14, 0),
			["size"] = UDim2.new(1, -150, 1, 0)
		})
		local v297, v298 = v_u_43.button(v295, v_u_482.TEXT.openMail, "secondary", function()
			-- upvalues: (copy) p_u_36
			local function v296()
				-- upvalues: (ref) p_u_36
				p_u_36.mc.cctx.lib.MenuMail.open(p_u_36.mc, nil, {
					["view"] = "deliveries"
				})
			end
			pcall(v296)
		end, {
			["name"] = "OpenMail",
			["size"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 104,
			["size"] = UDim2.fromOffset(120, v_u_49.mailH),
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -8, 0.5, 0)
		})
		v_u_273.warnBtn = v297
		v_u_273.warnApi = v298
		local function v_u_304(p299) -- name: startPulse
			-- upvalues: (copy) v_u_273, (ref) v_u_2
			if p299 and v_u_273.tween == nil then
				v_u_273.stroke.Thickness = 2
				local function v300()
					-- upvalues: (ref) v_u_2, (ref) v_u_273
					return v_u_2:Create(v_u_273.stroke, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["Transparency"] = 0.75
					})
				end
				local v301, v302 = pcall(v300)
				if v301 and v302 ~= nil then
					v_u_273.tween = v302
					v302:Play()
					return
				end
			elseif not p299 and v_u_273.tween ~= nil then
				if v_u_273.tween ~= nil then
					local function v303()
						-- upvalues: (ref) v_u_273
						v_u_273.tween:Cancel()
					end
					pcall(v303)
					v_u_273.tween = nil
				end
				v_u_273.stroke.Transparency = 0
				v_u_273.stroke.Thickness = 1
			end
		end
		local function v_u_306() -- name: releaseIcons
			-- upvalues: (copy) v_u_273, (copy) v_u_53, (copy) v_u_289
			for _, v305 in v_u_273.icons do
				pcall(v305)
			end
			table.clear(v_u_273.icons)
			v_u_53(v_u_289)
		end
		function v_u_46.stripModel() -- name: stripModel
			-- upvalues: (copy) v_u_46, (copy) v_u_39, (copy) v_u_44, (copy) v_u_49, (copy) v_u_42, (copy) v_u_41
			local v307, v308 = v_u_46.current()
			if v307 == nil then
				return nil
			end
			local v309 = {
				["reduced"] = v_u_39.reduced(),
				["phone"] = v_u_44
			}
			local v310 = v_u_49.body
			if type(v310) == "table" then
				local v311 = v310.rk
				if type(v311) == "table" and v310.rk.r == v307.r then
					v309.items = v310.rk.items
				end
			end
			local v312 = v_u_42:clock()
			local v313 = v_u_41.serverNow(v308, v312)
			if v313 == nil then
				return nil
			end
			local v314
			if type(v310) == "table" then
				local v315 = v310.rk
				if type(v315) == "table" and v310.rk.r == v307.r then
					v314 = v310.rk
				else
					v314 = v307
				end
			else
				v314 = v307
			end
			v309.warn = v_u_41.rsMailWarn(v314, v313)
			return v_u_41.rsStrip(v307, v313, v309)
		end
		function v_u_273.paint() -- name: paint
			-- upvalues: (copy) v_u_46, (copy) v_u_273, (copy) v_u_287, (copy) v_u_306, (copy) v_u_49, (copy) p_u_36, (copy) p_u_37, (copy) v_u_43, (copy) v_u_44, (ref) v_u_482, (copy) v_u_53, (copy) v_u_289, (copy) v_u_38, (copy) v_u_40, (copy) v_u_50, (copy) v_u_290, (copy) v_u_304, (copy) v_u_39
			local v316 = v_u_46.stripModel()
			if v316 == nil then
				if v_u_273.tween ~= nil then
					local function v317()
						-- upvalues: (ref) v_u_273
						v_u_273.tween:Cancel()
					end
					pcall(v317)
					v_u_273.tween = nil
				end
				v_u_273.stroke.Transparency = 0
				v_u_273.stroke.Thickness = 1
				v_u_287.Visible = false
				v_u_306()
				v_u_273.sig = ""
				if v_u_49.stripH ~= 0 then
					v_u_49.stripH = 0
					local v318 = p_u_36.setStripHeight
					pcall(v318, 0)
				end
			else
				v_u_287.Visible = true
				p_u_37:SetAttribute("Phase", v316.phase)
				local function v319()
					-- upvalues: (ref) v_u_43, (ref) p_u_37
					return v_u_43.designSize(p_u_37, false)
				end
				local v320, v321 = pcall(v319)
				local v322 = (not v320 or (typeof(v321) ~= "Vector2" or v321.X <= 40)) and 0 or v321.X
				local v323 = v316.live and (#v316.chips > 0 and not v_u_44)
				if v323 then
					v323 = v322 == 0 and true or v_u_482.CHIPS_MIN_W <= v322
				end
				local v324 = {}
				for _, v325 in v316.icons do
					table.insert(v324, v325)
				end
				local v326 = {}
				if v323 then
					for _, v327 in v316.chips do
						local v328 = v327.id .. ":" .. v327.chip.text
						table.insert(v326, v328)
					end
				end
				local v329 = table.concat(v324, ",")
				local v330 = v316.more
				local v331 = v_u_44
				local v332 = v329 .. "#" .. tostring(v330) .. "#" .. table.concat(v326, ",") .. "#" .. tostring(v331)
				if v332 ~= v_u_273.sig then
					v_u_273.sig = v332
					v_u_306()
					v_u_53(v_u_273.chipHost)
					local v333 = 0
					if not v_u_44 then
						for v334, v335 in v324 do
							local v336 = v_u_43.icon
							local v337 = v_u_289
							local v338 = {}
							local v339 = UDim2.fromOffset
							local v340 = (v_u_49.mainH - 34) / 2
							v338.position = v339(v333, (math.floor(v340)))
							v338.order = v334
							local _, v341 = v336(v337, v335, 34, v338)
							local v342 = v_u_273.icons
							table.insert(v342, v341)
							v333 = v333 + 38
						end
						if v316.more > 0 then
							local v343 = v_u_38.label
							local v344 = {
								["parent"] = nil,
								["name"] = "More",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v_u_289
							}
							local v345 = v316.more
							v344.text = "+" .. tostring(v345)
							v344.color = v_u_482.TEAL
							v344.position = UDim2.fromOffset(v333, 0)
							v344.size = UDim2.fromOffset(34, v_u_49.mainH)
							v343(v344)
							v333 = v333 + 36
						end
					end
					v_u_289.Size = UDim2.fromOffset(v333, v_u_49.mainH)
					v_u_273.textLbl.Position = UDim2.fromOffset(v333 + 14 + (v333 > 0 and 8 or 0), 0)
					local v346 = v333 + 14 + (v333 > 0 and 8 or 0)
					local v347 = 0
					if v323 then
						for _, v348 in v316.chips do
							local v349 = v_u_482.chipTone(v348.chip.kind)
							local v350
							if v349 == "success" then
								v350 = v_u_40.success
							elseif v349 == "accent" then
								v350 = v_u_40.accent
							elseif v349 == "danger" then
								v350 = v_u_40.danger
							elseif v349 == "info" then
								v350 = v_u_40.info
							else
								v350 = v_u_50
							end
							v_u_43.pill(v_u_273.chipHost, v348.chip.text, v350, {
								["name"] = nil,
								["h"] = 20,
								["name"] = "Chip_" .. v348.id
							})
							v347 = v347 + 96
						end
					end
					v_u_273.textLbl.Size = UDim2.new(1, -(v346 + v_u_290 + 20 + v347), 0, not v_u_44 and 26 or v_u_49.mainH)
					v_u_273.dropLbl.Position = UDim2.fromOffset(v346, v_u_49.pairY + 26)
					v_u_273.dropLbl.Size = UDim2.new(1, -(v346 + v_u_290 + 20 + v347), 0, 18)
				end
				local v351
				if v_u_44 then
					v351 = v316.short
				else
					v351 = v316.text
				end
				if v_u_44 and v316.drop ~= nil then
					v351 = v351 .. "  " .. v316.drop
				end
				local v352 = v_u_273.textLbl
				if v352 ~= nil and (v352.Parent ~= nil and v352:GetAttribute("RsText") ~= v351) then
					v352:SetAttribute("RsText", v351)
					local v353 = v_u_38.setText
					pcall(v353, v352, v351)
				end
				local v354 = v_u_273.textLbl
				local v355
				if v316.phase == "paused" or v316.phase == "resume" then
					v355 = v_u_40.info
				else
					v355 = v_u_482.TEAL
				end
				v354.TextColor3 = v355
				if not v_u_44 then
					local v356 = v_u_273.dropLbl
					local v357 = v316.drop or ""
					if v356 ~= nil and (v356.Parent ~= nil and v356:GetAttribute("RsText") ~= v357) then
						v356:SetAttribute("RsText", v357)
						local v358 = v_u_38.setText
						pcall(v358, v356, v357)
					end
					v_u_273.dropLbl.Visible = v316.drop ~= nil
					v_u_273.textLbl.Size = UDim2.new(v_u_273.textLbl.Size.X.Scale, v_u_273.textLbl.Size.X.Offset, 0, v316.drop ~= nil and 26 or v_u_49.mainH)
					v_u_273.textLbl.Position = UDim2.fromOffset(v_u_273.textLbl.Position.X.Offset, v316.drop == nil and 0 or v_u_49.pairY)
				end
				local v359 = v316.warn
				v_u_273.warnRow.Visible = v359 ~= nil
				if v359 ~= nil then
					local v360 = v_u_273.warnLbl
					local v361 = v359.text
					if v360 ~= nil and (v360.Parent ~= nil and v360:GetAttribute("RsText") ~= v361) then
						v360:SetAttribute("RsText", v361)
						local v362 = v_u_38.setText
						pcall(v362, v360, v361)
					end
					v_u_273.warnBtn.Visible = v359.button ~= nil
				end
				local v363 = v_u_49.mainH + (v359 == nil and 0 or v_u_49.warnH)
				if v363 ~= v_u_49.stripH then
					v_u_49.stripH = v363
					local v364 = p_u_36.setStripHeight
					pcall(v364, v363)
				end
				v_u_287:SetAttribute("Phase", v316.phase)
				v_u_287:SetAttribute("Text", v316.text)
				v_u_287:SetAttribute("Pulse", v316.pulse == true)
				v_u_287:SetAttribute("Warn", v359 == nil and "" or v359.code)
				local v365 = v_u_304
				local v366
				if v316.pulse == true then
					v366 = not v_u_39.reduced()
				else
					v366 = false
				end
				v365(v366)
			end
		end
		local v_u_367 = {
			["open"] = false
		}
		local v_u_368 = v_u_38.new("Frame", {
			["Name"] = "RestockPage",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["Position"] = UDim2.fromOffset(0, 0),
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_36.inner)
		v_u_367.root = v_u_368
		local v369 = v_u_39.touch(36)
		local v370 = v_u_38.new("Frame", {
			["Name"] = "Bar",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v369)
		}, v_u_368)
		local v371 = v_u_45 and 104 or 120
		local v_u_372, _ = v_u_43.button(v370, v_u_482.TEXT.back, "secondary", function()
			-- upvalues: (copy) v_u_46
			v_u_46.closePage()
		end, {
			["icon"] = "chevronLeft",
			["name"] = "Back",
			["height"] = 36,
			["width"] = nil,
			["width"] = v371
		})
		v_u_367.backBtn = v_u_372
		v_u_367.title = v_u_38.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = nil,
			["textSize"] = nil,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v370,
			["text"] = v_u_482.TEXT.title,
			["style"] = v_u_45 and "h3" or "h2",
			["textSize"] = v_u_45 and 20 or 26,
			["color"] = v_u_482.TEAL,
			["position"] = UDim2.fromOffset(v371 + 12, 0),
			["size"] = UDim2.new(1, -(v371 + 12 + 104 + 8), 0, v369)
		})
		local v374, _ = v_u_43.button(v370, v_u_482.TEXT.refresh, "secondary", function()
			-- upvalues: (copy) v_u_367, (copy) v_u_42, (copy) v_u_46
			v_u_367.lastRefresh = v_u_367.lastRefresh or (-1 / 0)
			local v373 = v_u_42:clock()
			if v373 - v_u_367.lastRefresh >= 3 then
				v_u_367.lastRefresh = v373
				v_u_46.fetch(true)
			end
		end, {
			["name"] = "Refresh",
			["height"] = 36,
			["width"] = 104,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 90,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_367.refreshBtn = v374
		local v_u_375 = v_u_38.list({
			["parent"] = nil,
			["name"] = "Scroll",
			["position"] = nil,
			["size"] = nil,
			["gap"] = 10,
			["padding"] = nil,
			["parent"] = v_u_368,
			["position"] = UDim2.fromOffset(0, v369 + 8),
			["size"] = UDim2.new(1, 0, 1, -(v369 + 8)),
			["padding"] = {
				0,
				8,
				0,
				10
			}
		})
		v_u_367.scroll = v_u_375
		v_u_367.status = v_u_38.label({
			["parent"] = nil,
			["name"] = "Status",
			["text"] = "",
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v_u_375,
			["color"] = v_u_482.TEAL
		})
		v_u_367.sub = v_u_38.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v_u_375,
			["color"] = v_u_40.text2
		})
		v_u_367.warn = v_u_38.label({
			["parent"] = nil,
			["name"] = "Warn",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v_u_375,
			["color"] = v_u_40.accent
		})
		v_u_367.cards = v_u_38.new("Frame", {
			["Name"] = "Cards",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 4,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_375)
		v_u_367.grid = v_u_38.new("UIGridLayout", {
			["CellSize"] = UDim2.new(1, 0, 0, v_u_47),
			["CellPadding"] = UDim2.fromOffset(12, 12),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v_u_367.cards)
		v_u_367.msg = v_u_38.label({
			["parent"] = nil,
			["name"] = "Message",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 5,
			["parent"] = v_u_375,
			["color"] = v_u_40.text2
		})
		v_u_367.hintLbl = v_u_38.label({
			["parent"] = nil,
			["name"] = "PadHint",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 6,
			["visible"] = false,
			["parent"] = v_u_375,
			["text"] = v_u_482.TEXT.pad,
			["color"] = v_u_40.text2
		})
		v_u_367.foot = v_u_38.label({
			["parent"] = nil,
			["name"] = "Footer",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 7,
			["parent"] = v_u_375,
			["text"] = v_u_482.TEXT.foot,
			["color"] = v_u_40.text2
		})
		v_u_367.host = v_u_272(v_u_367.cards, function(p376)
			local v377 = {}
			local v378 = p376.items
			if type(v378) == "table" then
				for _, v379 in p376.items do
					if type(v379) ~= "table" then
						continue
					end
					local v380 = v379.i
					if type(v380) ~= "number" then
						continue
					end
					local v381 = v379.id
					if type(v381) ~= "string" then
						continue
					end
					table.insert(v377, v379)
				end
			end
			return v377
		end)
		local function v_u_389() -- name: applyColumns
			-- upvalues: (copy) v_u_43, (copy) v_u_375, (ref) v_u_482, (copy) v_u_45, (copy) v_u_44, (copy) v_u_367, (copy) v_u_47, (copy) v_u_368
			local function v382()
				-- upvalues: (ref) v_u_43, (ref) v_u_375
				return v_u_43.designSize(v_u_375, true)
			end
			local v383, v384 = pcall(v382)
			local v385 = (not v383 or typeof(v384) ~= "Vector2") and 0 or v384.X
			local v386 = v_u_482.columnsFor(v385 <= 40 and (v_u_45 and 0 or 1000) or v385, v_u_44)
			v_u_367.cols = v386
			local v387 = v_u_367.grid
			local v388
			if v386 == 2 then
				v388 = UDim2.new(0.5, -6, 0, v_u_47)
			else
				v388 = UDim2.new(1, 0, 0, v_u_47)
			end
			v387.CellSize = v388
			v_u_368:SetAttribute("Columns", v386)
		end
		function v_u_367.paint() -- name: paint
			-- upvalues: (copy) v_u_367, (copy) v_u_389, (copy) v_u_46, (ref) v_u_482, (copy) v_u_368, (copy) v_u_38
			if v_u_367.open then
				v_u_389()
				local v390, _ = v_u_46.current()
				local v391, _ = v_u_46.rows()
				local v392 = v_u_46.stripModel()
				if v390 == nil or v392 == nil then
					v_u_367.host.destroy()
					v_u_367.status.Text = ""
					v_u_367.sub.Text = ""
					v_u_367.warn.Text = ""
					v_u_367.msg.Text = v_u_482.TEXT.empty
					v_u_367.msg.Visible = true
					v_u_368:SetAttribute("State", "none")
					return
				else
					local v393 = v_u_367.status
					local v394 = v392.text
					if v393 ~= nil and (v393.Parent ~= nil and v393:GetAttribute("RsText") ~= v394) then
						v393:SetAttribute("RsText", v394)
						local v395 = v_u_38.setText
						pcall(v395, v393, v394)
					end
					local v396 = v_u_367.sub
					local v397 = v392.drop or ""
					if v396 ~= nil and (v396.Parent ~= nil and v396:GetAttribute("RsText") ~= v397) then
						v396:SetAttribute("RsText", v397)
						local v398 = v_u_38.setText
						pcall(v398, v396, v397)
					end
					v_u_367.sub.Visible = v392.drop ~= nil
					local v399 = v_u_367.warn
					local v400 = v392.warn == nil and "" or v392.warn.text
					if v399 ~= nil and (v399.Parent ~= nil and v399:GetAttribute("RsText") ~= v400) then
						v399:SetAttribute("RsText", v400)
						local v401 = v_u_38.setText
						pcall(v401, v399, v400)
					end
					v_u_367.warn.Visible = v392.warn ~= nil
					if v391 == nil then
						v_u_367.host.destroy()
						v_u_367.msg.Text = v_u_482.TEXT.loading
						v_u_367.msg.Visible = true
						v_u_368:SetAttribute("State", "loading")
					else
						v_u_367.host.sync()
						local v402 = #v_u_367.host.widgets == 0
						v_u_367.msg.Text = not v402 and "" or v_u_482.TEXT.hidden
						v_u_367.msg.Visible = v402
						v_u_368:SetAttribute("State", v402 and "hidden" or "ok")
						v_u_368:SetAttribute("Cards", #v_u_367.host.widgets)
					end
				end
			else
				return
			end
		end
		function v_u_367.layout() -- name: layout
			-- upvalues: (copy) p_u_36, (copy) v_u_368
			local v403 = p_u_36.itemTop()
			v_u_368.Position = UDim2.fromOffset(0, v403)
			v_u_368.Size = UDim2.new(1, 0, 1, -v403)
		end
		function v_u_46.pageOpen() -- name: pageOpen
			-- upvalues: (copy) v_u_367
			return v_u_367.open
		end
		function v_u_46.openPage() -- name: openPage
			-- upvalues: (ref) v_u_48, (copy) v_u_367, (copy) p_u_36, (copy) v_u_49, (copy) v_u_45, (copy) v_u_368, (copy) v_u_46, (copy) v_u_38, (copy) v_u_372, (ref) v_u_1
			if v_u_48 and not v_u_367.open then
				if p_u_36.nav ~= nil then
					local v404 = p_u_36.nav.back
					if type(v404) == "function" then
						local v405 = p_u_36.nav.back
						pcall(v405)
					end
				end
				v_u_367.open = true
				v_u_49.pageOpen = true
				p_u_36.body.Visible = false
				if v_u_45 then
					p_u_36.setSubRowVisible(false)
				else
					p_u_36.subHost.Visible = false
				end
				local v406 = p_u_36.itemTop()
				v_u_368.Position = UDim2.fromOffset(0, v406)
				v_u_368.Size = UDim2.new(1, 0, 1, -v406)
				v_u_368.Visible = true
				p_u_36.page:SetAttribute("MarketRestock", true)
				v_u_367.paint()
				v_u_46.fetch(true)
				if v_u_38.device() == "Gamepad" then
					v_u_367.hintLbl.Visible = true
					task.defer(function()
						-- upvalues: (ref) v_u_367, (ref) v_u_372, (ref) v_u_1
						if v_u_367.open and v_u_372.Parent then
							v_u_1.SelectedObject = v_u_372
						end
					end)
				else
					v_u_367.hintLbl.Visible = false
				end
			else
				return
			end
		end
		function v_u_46.closePage(p407) -- name: closePage
			-- upvalues: (copy) v_u_367, (copy) v_u_49, (copy) v_u_368, (copy) p_u_36, (copy) v_u_38, (copy) v_u_39
			if v_u_367.open then
				v_u_367.open = false
				v_u_49.pageOpen = false
				v_u_368.Visible = false
				p_u_36.body.Visible = true
				p_u_36.setSubRowVisible(true)
				p_u_36.subHost.Visible = true
				p_u_36.page:SetAttribute("MarketRestock", nil)
				v_u_367.host.destroy()
				if p407 ~= true then
					v_u_38.sound(v_u_39.sounds.close)
				end
			end
		end
		function v_u_46.newPinned(p408, p409) -- name: newPinned
			-- upvalues: (copy) v_u_38, (copy) v_u_272, (copy) v_u_41, (copy) v_u_46, (copy) v_u_49
			local v_u_410 = {
				["itemId"] = nil
			}
			local v_u_411 = v_u_38.new("Frame", {
				["Name"] = "RestockPinned",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = p409
			}, p408)
			v_u_38.layout(v_u_411, "v", 8)
			v_u_410.frame = v_u_411
			v_u_410.host = v_u_272(v_u_411, function(p412)
				-- upvalues: (copy) v_u_410, (ref) v_u_41
				local v413 = {}
				if v_u_410.itemId ~= nil then
					for _, v414 in v_u_41.rsForItem(p412, v_u_410.itemId) do
						local v415 = v414.i
						if type(v415) ~= "number" then
							continue
						end
						table.insert(v413, v414)
					end
				end
				return v413
			end)
			function v_u_410.sync() -- name: sync
				-- upvalues: (copy) v_u_410, (ref) v_u_46, (copy) v_u_411
				if v_u_410.itemId == nil or not v_u_46.active() then
					v_u_410.host.destroy()
					v_u_411.Visible = false
				else
					v_u_410.host.sync()
					v_u_411.Visible = #v_u_410.host.widgets > 0
					v_u_411:SetAttribute("Cards", #v_u_410.host.widgets)
				end
			end
			function v_u_410.setItem(p416) -- name: setItem
				-- upvalues: (copy) v_u_410, (copy) v_u_411
				v_u_410.itemId = p416
				if p416 == nil then
					v_u_410.host.destroy()
					v_u_411.Visible = false
				else
					v_u_410.sync()
				end
			end
			function v_u_410.destroy() -- name: destroy
				-- upvalues: (copy) v_u_410, (ref) v_u_49, (copy) v_u_411
				v_u_410.host.destroy()
				local v417 = table.find(v_u_49.pins, v_u_410)
				if v417 then
					table.remove(v_u_49.pins, v417)
				end
				v_u_411:Destroy()
			end
			local v418 = v_u_49.pins
			table.insert(v418, v_u_410)
			return v_u_410
		end
		function v_u_46.sync() -- name: sync
			-- upvalues: (ref) v_u_48, (copy) v_u_46, (copy) v_u_49, (copy) p_u_36, (copy) v_u_273, (copy) v_u_367, (copy) v_u_41, (copy) v_u_42
			if v_u_48 then
				local v_u_419 = v_u_46.active()
				if not v_u_419 and (v_u_49.body ~= nil and p_u_36.state ~= nil) then
					local v420 = p_u_36.state.rk
					if type(v420) ~= "table" then
						v_u_49.body = nil
					end
				end
				v_u_273.paint()
				if v_u_367.open then
					if v_u_419 then
						v_u_367.paint()
					else
						v_u_46.closePage(true)
					end
				end
				for _, v421 in v_u_49.pins do
					local v422 = v421.sync
					pcall(v422)
				end
				local v_u_423
				if v_u_419 then
					local v424, v425 = v_u_46.current()
					v_u_423 = v_u_41.rsDot(v424, v_u_41.serverNow(v425, v_u_42:clock()) or 0)
				else
					v_u_423 = false
				end
				if v_u_423 ~= v_u_49.lastDot then
					v_u_49.lastDot = v_u_423
					local function v426()
						-- upvalues: (ref) p_u_36, (ref) v_u_423
						p_u_36.player:SetAttribute("RsLive", v_u_423 and true or nil)
					end
					pcall(v426)
				end
				local function v427()
					-- upvalues: (ref) p_u_36, (copy) v_u_419
					p_u_36.page:SetAttribute("MarketRestockActive", v_u_419)
				end
				pcall(v427)
			end
		end
		function v_u_46.toasts() -- name: toasts
			-- upvalues: (ref) v_u_48, (copy) v_u_46, (copy) v_u_49, (copy) v_u_41, (copy) v_u_42, (copy) p_u_36
			if v_u_48 then
				local v428, v429 = v_u_46.current()
				if v428 == nil then
					return
				else
					v_u_49.toasted = v_u_49.toasted or {}
					local v_u_430, v431 = v_u_41.rsToastDue(v428, v_u_41.serverNow(v429, v_u_42:clock()), v_u_49.toasted)
					if v_u_430 ~= nil and v431 ~= nil then
						v_u_49.toasted[v431] = true
						local function v434()
							-- upvalues: (ref) p_u_36, (copy) v_u_430, (ref) v_u_41
							local v432 = p_u_36.mc.cctx.controllers.BmNotes
							if v432 then
								local v433 = v432.inject
								if type(v433) == "function" then
									v432.inject({
										["k"] = v_u_430,
										["msg"] = v_u_41.RS_TOAST[v_u_430]
									})
								end
							end
						end
						pcall(v434)
					end
				end
			else
				return
			end
		end
		function v_u_46.tick() -- name: tick
			-- upvalues: (ref) v_u_48, (copy) v_u_46, (copy) v_u_92
			if v_u_48 then
				v_u_46.toasts()
				local v435, v436 = v_u_46.current()
				if v435 ~= nil then
					v_u_92(v435, v436)
				end
				v_u_46.sync()
			end
		end
		function v_u_46.show() -- name: show
			-- upvalues: (copy) v_u_49, (copy) v_u_46
			v_u_49.visible = true
			v_u_46.sync()
			if v_u_46.current() ~= nil then
				v_u_46.fetch(true)
			end
		end
		function v_u_46.hide() -- name: hide
			-- upvalues: (copy) v_u_49, (copy) v_u_273
			v_u_49.visible = false
			if v_u_273.tween ~= nil then
				if v_u_273.tween ~= nil then
					local function v437()
						-- upvalues: (ref) v_u_273
						v_u_273.tween:Cancel()
					end
					pcall(v437)
					v_u_273.tween = nil
				end
				v_u_273.stroke.Transparency = 0
				v_u_273.stroke.Thickness = 1
			end
		end
		local v438, v439 = pcall(function()
			-- upvalues: (copy) p_u_36
			return p_u_36.mc.cctx.lib.VirtualPad
		end)
		if v438 and (v439 ~= nil and v439.InputBegan ~= nil) then
			local v440 = v_u_49.conns
			local v441 = v439.InputBegan
			local function v448(p442, _)
				-- upvalues: (copy) v_u_367, (ref) v_u_48, (copy) p_u_36, (ref) v_u_482, (ref) v_u_1, (copy) v_u_49, (copy) v_u_247
				if v_u_367.open and (v_u_48 and not p_u_36.modalOpen()) then
					local v443 = p442.KeyCode
					local v444 = v_u_482.padAction(v443.Name)
					if v444 == nil then
						return
					else
						local v445 = v_u_1.SelectedObject
						if v445 ~= nil then
							local v446 = nil
							for _, v447 in v_u_49.widgets do
								if not v445:IsDescendantOf(v447.frame) then
									continue
								end
								v446 = v447
							end
							if type(v446) == "table" and v446.frame ~= nil then
								v_u_247.step(v446, v444)
							end
						end
					end
				else
					return
				end
			end
			table.insert(v440, v441:Connect(v448))
		end
		function v_u_46.state() -- name: state
			-- upvalues: (copy) v_u_46, (copy) v_u_41, (copy) v_u_42, (copy) v_u_49, (copy) v_u_367, (ref) v_u_482
			local v449, v450 = v_u_46.current()
			local v451 = {
				["active"] = v_u_46.active()
			}
			local v452
			if v449 == nil then
				v452 = nil
			else
				v452 = v_u_41.rsPhase(v449, v_u_41.serverNow(v450, v_u_42:clock()))
			end
			v451.phase = v452
			v451.stripH = v_u_49.stripH
			v451.pageOpen = v_u_367.open
			v451.cols = v_u_367.cols
			v451.cards = #v_u_367.host.widgets
			v451.widgets = #v_u_49.widgets
			v451.pins = #v_u_49.pins
			v451.fetching = v_u_49.fetching
			v451.haveBody = v_u_49.body ~= nil
			local v453 = v_u_482.sig
			local v454 = v_u_49.body
			if v454 then
				v454 = v_u_49.body.rk
			end
			v451.sig = v453(v454)
			return v451
		end
		function v_u_46.strip() -- name: strip
			-- upvalues: (copy) v_u_287, (copy) v_u_46, (copy) v_u_49, (copy) v_u_273
			return {
				["frame"] = v_u_287,
				["model"] = v_u_46.stripModel(),
				["height"] = v_u_49.stripH,
				["view"] = v_u_273.viewBtn,
				["warnBtn"] = v_u_273.warnBtn
			}
		end
		function v_u_46.cards() -- name: cards
			-- upvalues: (copy) v_u_49
			local v455 = {}
			for _, v456 in v_u_49.widgets do
				local v457 = {
					["ix"] = v456.ix,
					["id"] = v456.id,
					["frame"] = v456.frame,
					["card"] = v456.card,
					["buy"] = v456.buy.btn,
					["plus"] = v456.plus.btn,
					["minus"] = v456.minus.btn,
					["min"] = v456.min.btn,
					["max"] = v456.max.btn
				}
				table.insert(v455, v457)
			end
			return v455
		end
		function v_u_46.press(p458, p459) -- name: press
			-- upvalues: (copy) v_u_46, (copy) v_u_49, (copy) v_u_247
			if p459 == "back" then
				v_u_46.closePage()
				return true
			else
				for _, v460 in v_u_49.widgets do
					if v460.ix ~= p458 then
						continue
					end
					if p459 == "buy" then
						v_u_247.press(v460)
					elseif p459 == "plus" then
						v_u_247.step(v460, "up")
					elseif p459 == "minus" then
						v_u_247.step(v460, "down")
					elseif p459 == "min" then
						v_u_247.step(v460, "min")
					elseif p459 == "max" then
						v_u_247.step(v460, "max")
					else
						if p459 ~= "ten" then
							return false
						end
						v_u_247.step(v460, "tenUp")
					end
					return true
				end
				return false
			end
		end
		function v_u_46.open() -- name: open
			-- upvalues: (copy) v_u_46
			v_u_46.openPage()
		end
		function v_u_46.close() -- name: close
			-- upvalues: (copy) v_u_46
			v_u_46.closePage()
		end
		function v_u_46.page() -- name: page
			-- upvalues: (copy) v_u_367
			return v_u_367
		end
		function v_u_46.reload() -- name: reload
			-- upvalues: (copy) v_u_49, (copy) v_u_42, (copy) v_u_46
			v_u_49.body = nil
			v_u_42:invalidate("restock")
			v_u_46.fetch(true)
			v_u_46.sync()
		end
		function v_u_46.destroy() -- name: destroy
			-- upvalues: (ref) v_u_48, (copy) v_u_273, (copy) v_u_306, (copy) v_u_367, (copy) v_u_49, (copy) p_u_36
			v_u_48 = false
			if v_u_273.tween ~= nil then
				if v_u_273.tween ~= nil then
					local function v461()
						-- upvalues: (ref) v_u_273
						v_u_273.tween:Cancel()
					end
					pcall(v461)
					v_u_273.tween = nil
				end
				v_u_273.stroke.Transparency = 0
				v_u_273.stroke.Thickness = 1
			end
			v_u_306()
			v_u_367.host.destroy()
			for _, v462 in table.clone(v_u_49.pins) do
				local v463 = v462.destroy
				pcall(v463)
			end
			for _, v_u_464 in v_u_49.conns do
				pcall(function()
					-- upvalues: (copy) v_u_464
					v_u_464:Disconnect()
				end)
			end
			table.clear(v_u_49.conns)
			local function v465()
				-- upvalues: (ref) p_u_36
				p_u_36.player:SetAttribute("RsLive", nil)
			end
			pcall(v465)
		end
		local v466 = v_u_49.conns
		local v469 = {
			["Disconnect"] = v_u_42:onChange(function(p467)
				-- upvalues: (ref) v_u_48, (copy) v_u_42, (copy) v_u_80, (copy) v_u_46
				if p467 == "restock" and v_u_48 then
					local v468 = v_u_42:lastRestock()
					if type(v468) == "table" and v468.ok ~= false then
						v_u_80(v468)
					end
					task.defer(v_u_46.sync)
				end
			end)
		}
		table.insert(v466, v469)
		local v470 = p_u_36.onState(function(_)
			-- upvalues: (ref) v_u_48, (copy) v_u_46
			if v_u_48 then
				v_u_46.sync()
			end
		end)
		local v471 = v_u_49.conns
		table.insert(v471, {
			["Disconnect"] = v470
		})
		local v472 = p_u_36.onTick(function()
			-- upvalues: (copy) v_u_46
			v_u_46.tick()
		end)
		local v473 = v_u_49.conns
		table.insert(v473, {
			["Disconnect"] = v472
		})
		local function v477()
			-- upvalues: (copy) v_u_49, (copy) p_u_37, (ref) v_u_48, (copy) v_u_273, (copy) v_u_46
			local v474 = v_u_49.conns
			local v475 = p_u_37:GetPropertyChangedSignal("AbsoluteSize")
			local function v476()
				-- upvalues: (ref) v_u_48, (ref) v_u_49, (ref) v_u_273, (ref) v_u_46
				if v_u_48 and v_u_49.visible then
					v_u_273.sig = ""
					task.defer(v_u_46.sync)
				end
			end
			table.insert(v474, v475:Connect(v476))
		end
		pcall(v477)
		local function v481()
			-- upvalues: (copy) v_u_49, (copy) v_u_368, (ref) v_u_48, (copy) v_u_367
			local v478 = v_u_49.conns
			local v479 = v_u_368:GetPropertyChangedSignal("AbsoluteSize")
			local function v480()
				-- upvalues: (ref) v_u_48, (ref) v_u_367
				if v_u_48 and v_u_367.open then
					task.defer(v_u_367.paint)
				end
			end
			table.insert(v478, v479:Connect(v480))
		end
		pcall(v481)
		return v_u_46
	end
}
return v_u_482