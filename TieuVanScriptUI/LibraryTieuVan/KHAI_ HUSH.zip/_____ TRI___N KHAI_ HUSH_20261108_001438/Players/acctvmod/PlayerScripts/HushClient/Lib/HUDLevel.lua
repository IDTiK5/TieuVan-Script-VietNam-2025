-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDLevel

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v3 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("HollowLevels"))
local v_u_5 = require(v3:WaitForChild("MapInfo"))
local v_u_73 = {
	["describe"] = function(p6, p7) -- name: describe
		-- upvalues: (copy) v_u_4, (copy) v_u_5
		if type(p6) == "table" then
			local v8 = p6.levels
			if type(v8) == "table" and #p6.levels >= 2 then
				local v9, v10 = v_u_4.levelOf(p7.Y)
				local v11 = p6.levels[v10 + 1]
				local v12, v13, v14, v15, v16
				if type(v11) == "table" then
					local v17 = v11.name
					if type(v17) == "string" then
						v12 = v11.name
						v13 = ""
						for v22, v23 in p6.zones or {} do
							if type(v23) ~= "table" then
								continue
							end
							v14 = v23.rect
							if type(v14) ~= "table" or not v_u_5.inRect(v23.rect, p7) then
								continue
							end
							v15 = v23.name
							if type(v15) == "string" then
								v13 = v23.name
							else
								v13 = v_u_4.ZONE_NAMES[v23.id]
								if not v13 then
									v16 = v23.id
									v13 = tostring(v16)
								end
							end
						end
						return v9, string.upper(v12), string.upper(v13)
					else
						if v_u_4.BY_ID[v9] then
							v12 = v_u_4.BY_ID[v9].name
						else
							v12 = v9
						end
						v13 = ""
						for v22, v23 in p6.zones or {} do
							if type(v23) ~= "table" then
								continue
							end
							v14 = v23.rect
							if type(v14) ~= "table" or not v_u_5.inRect(v23.rect, p7) then
								continue
							end
							v15 = v23.name
							if type(v15) == "string" then
								v13 = v23.name
							else
								v13 = v_u_4.ZONE_NAMES[v23.id]
								if not v13 then
									v16 = v23.id
									v13 = tostring(v16)
								end
							end
						end
						return v9, string.upper(v12), string.upper(v13)
					end
				else
					if v_u_4.BY_ID[v9] then
						v12 = v_u_4.BY_ID[v9].name
					else
						v12 = v9
					end
					v13 = ""
					for v22, v23 in p6.zones or {} do
						if type(v23) ~= "table" then
							continue
						end
						v14 = v23.rect
						if type(v14) ~= "table" or not v_u_5.inRect(v23.rect, p7) then
							continue
						end
						v15 = v23.name
						if type(v15) == "string" then
							v13 = v23.name
						else
							v13 = v_u_4.ZONE_NAMES[v23.id]
							if not v13 then
								v16 = v23.id
								v13 = tostring(v16)
							end
						end
					end
					return v9, string.upper(v12), string.upper(v13)
				end
			else
				return nil, nil, nil
			end
		else
			return nil, nil, nil
		end
	end,
	["new"] = function(p_u_24) -- name: new
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_73
		local v_u_25 = p_u_24.UI
		local v_u_26 = p_u_24.Theme.color
		local v27 = {}
		local v_u_28 = v_u_2.LocalPlayer
		local v_u_29 = nil
		local v_u_30 = nil
		local v_u_31 = nil
		local v_u_32 = nil
		local v_u_33 = nil
		local v_u_34 = false
		local v_u_35 = (1 / 0)
		local v_u_36 = ""
		local v_u_37 = nil
		local function v_u_39() -- name: build
			-- upvalues: (ref) v_u_30, (copy) v_u_25, (copy) p_u_24, (ref) v_u_31, (copy) v_u_26, (ref) v_u_32, (ref) v_u_33
			if not v_u_30 then
				local v38 = v_u_25.new("Frame", {
					["Name"] = "LevelPlate",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -296, 0, v_u_25.topInset()),
					["Size"] = UDim2.fromOffset(220, 48)
				}, p_u_24.root)
				v_u_31 = v_u_25.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "caps",
					["textSize"] = 12,
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["parent"] = v38,
					["color"] = v_u_26.muted,
					["size"] = UDim2.new(1, 0, 0, 14)
				})
				v_u_32 = v_u_25.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "caps",
					["textSize"] = 18,
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["position"] = nil,
					["parent"] = v38,
					["color"] = v_u_26.text,
					["size"] = UDim2.new(1, 0, 0, 24),
					["position"] = UDim2.fromOffset(0, 18)
				})
				v_u_33 = v_u_25.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "caps",
					["textSize"] = 12,
					["color"] = nil,
					["size"] = nil,
					["parent"] = v38,
					["color"] = v_u_26.text2,
					["size"] = UDim2.fromScale(1, 1)
				})
				v_u_31.Name = "Level"
				v_u_32.Name = "Zone"
				v_u_33.Name = "Line"
				v_u_30 = v38
			end
		end
		local function v_u_60() -- name: apply
			-- upvalues: (ref) v_u_30, (ref) v_u_34, (copy) p_u_24, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (copy) v_u_25
			if v_u_30 then
				local v40 = v_u_30
				if v_u_34 and (p_u_24.touchFrame and p_u_24.touchFrame().corner ~= nil) then
					local v41 = p_u_24.touchFrame()
					local v42 = p_u_24.bandOffset
					local v43 = type(v42) ~= "function" and 0 or p_u_24.bandOffset("LevelPlate")
					v40.AnchorPoint = Vector2.new(0, 0)
					local v44 = UDim2.fromOffset
					local v45 = v41.bandLeft or v41.left
					local v46 = math.floor(v45)
					local v47 = v41.listY
					local v48
					if type(v47) == "number" then
						v48 = v41.listY
					else
						v48 = v41.top + 96
					end
					local v49 = v48 + v43
					v40.Position = v44(v46, (math.floor(v49)))
					v40.Size = UDim2.fromOffset(230, 16)
					v_u_31.Visible = false
					v_u_32.Visible = false
					v_u_33.Visible = true
					return
				elseif v_u_34 then
					local v50 = p_u_24.touchFrame
					if v50 then
						v50 = p_u_24.touchFrame()
					end
					local v51 = not v50 and 40 or v50.left
					local v52 = not v50 and 12 or v50.top
					local v53
					if v50 then
						local v54 = v50.vitalsW
						local v55 = math.floor(v54)
						v53 = math.min(168, v55)
					else
						v53 = 168
					end
					v40.AnchorPoint = Vector2.new(0, 0)
					local v56 = UDim2.fromOffset
					local v57 = v51 + v53 + 14
					local v58 = math.floor(v57)
					local v59 = v52 + 78
					v40.Position = v56(v58, (math.floor(v59)))
					v40.Size = UDim2.fromOffset(230, 16)
					v_u_31.Visible = false
					v_u_32.Visible = false
					v_u_33.Visible = true
				else
					v40.AnchorPoint = Vector2.new(1, 0)
					v40.Position = UDim2.new(1, -296, 0, v_u_25.topInset())
					v40.Size = UDim2.fromOffset(220, 48)
					v_u_31.Visible = true
					v_u_32.Visible = true
					v_u_33.Visible = false
				end
			else
				return
			end
		end
		function v27.setCharacter(p61) -- name: setCharacter
			-- upvalues: (ref) v_u_29, (ref) v_u_35
			v_u_29 = p61
			v_u_35 = (1 / 0)
		end
		function v27.layout(p62) -- name: layout
			-- upvalues: (ref) v_u_34, (copy) v_u_60
			v_u_34 = p62 == true
			v_u_60()
		end
		function v27.update(p63) -- name: update
			-- upvalues: (ref) v_u_35, (ref) v_u_37, (ref) v_u_5, (ref) v_u_29, (ref) v_u_73, (ref) v_u_30, (ref) v_u_36, (copy) v_u_28, (copy) v_u_39, (copy) v_u_60, (copy) v_u_25, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (copy) p_u_24
			v_u_35 = v_u_35 + p63
			if v_u_35 < 0.25 then
				return
			else
				v_u_35 = 0
				v_u_37 = v_u_5.fromRuntime()
				local v64 = v_u_29
				if v64 then
					v64 = v_u_29:FindFirstChild("HumanoidRootPart")
				end
				local v65, v66, v67
				if v64 and v64:IsA("BasePart") then
					v65, v66, v67 = v_u_73.describe(v_u_37, v64.Position)
				else
					v65 = nil
					v66 = nil
					v67 = nil
				end
				if v65 then
					if not v_u_30 then
						v_u_39()
						v_u_60()
					end
					local v68 = string.format("%s|%s|%s", v65, v66 or "", v67 or "")
					if v68 ~= v_u_36 then
						v_u_36 = v68
						v_u_25.setText(v_u_31, v66 or "")
						v_u_25.setText(v_u_32, (not v67 or v67 == "") and "-" or v67)
						v_u_25.setText(v_u_33, (not v67 or v67 == "") and (v66 or "") or (v66 or "") .. "  \194\183  " .. v67)
						v_u_28:SetAttribute("HudLevel", v68)
					end
					v_u_30.Visible = true
					if v_u_34 then
						local v69 = p_u_24.touchFrame
						if v69 then
							v69 = p_u_24.touchFrame()
						end
						if v69 and v69.corner ~= nil then
							v_u_60()
							local v70 = p_u_24.mods
							local v71
							if type(v70) == "table" then
								v71 = p_u_24.mods.HUDClock
							else
								v71 = nil
							end
							if v71 then
								local v72 = v71.bandBusy
								if type(v72) == "function" and v71.bandBusy() == true then
									v_u_30.Visible = false
								end
							end
						end
					end
				else
					if v_u_30 then
						v_u_30.Visible = false
					end
					if v_u_36 ~= "" then
						v_u_36 = ""
						v_u_28:SetAttribute("HudLevel", nil)
					end
				end
			end
		end
		function v27.destroy() -- name: destroy
			-- upvalues: (ref) v_u_30, (ref) v_u_36, (copy) v_u_28
			if v_u_30 then
				v_u_30:Destroy()
				v_u_30 = nil
			end
			if v_u_36 ~= "" then
				v_u_28:SetAttribute("HudLevel", nil)
			end
		end
		return v27
	end
}
return v_u_73