-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AshHumFx

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Workspace")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Players")
local v_u_5 = {}
v_u_5.__index = v_u_5
v_u_5.MAX_ALPHA = 0.32
v_u_5.BREATH_HZ = 0.5
v_u_5.SLIDE_SECONDS = 7
v_u_5.SLIDE_RANGE = 420
function v_u_5.vignetteAlpha(p6, p7, p8, p9) -- name: vignetteAlpha
	-- upvalues: (copy) v_u_5
	if type(p6) ~= "number" or (p6 ~= p6 or (type(p9) ~= "number" or (p9 ~= p9 or p9 < p6))) then
		return 0
	end
	if type(p8) ~= "number" then
		if type(p7) == "number" then
			p8 = p7 + 14
		else
			p8 = p6 + 18
		end
	end
	if p8 + 1.5 < p9 then
		return 0
	end
	local v10 = (p9 - p6) / 4
	local v11 = math.clamp(v10, 0, 1)
	local v12
	if p8 < p9 then
		local v13 = 1 - (p9 - p8) / 1.5
		v12 = math.clamp(v13, 0, 1)
	else
		v12 = 1
	end
	local v14 = p9 * v_u_5.BREATH_HZ * 2 * 3.141592653589793
	local v15 = math.sin(v14) * 0.1 + 0.9
	return v_u_5.MAX_ALPHA * v11 * v12 * v15
end
function v_u_5.slideActive(p16, p17, p18) -- name: slideActive
	-- upvalues: (copy) v_u_5
	if type(p16) ~= "number" or (p16 ~= p16 or (type(p17) ~= "number" or (p17 ~= p17 or (type(p18) ~= "number" or (p18 ~= p18 or v_u_5.SLIDE_RANGE < p18))))) then
		return false
	end
	local v19
	if p16 <= p17 then
		v19 = p17 <= p16 + v_u_5.SLIDE_SECONDS
	else
		v19 = false
	end
	return v19
end
local function v_u_28(p20, p21, p22, p23, p24, p25) -- name: edge
	local v26 = Instance.new("Frame")
	v26.Name = p21
	v26.AnchorPoint = p22
	v26.Position = p23
	v26.Size = p24
	v26.BackgroundColor3 = Color3.new(0, 0, 0)
	v26.BackgroundTransparency = 1
	v26.BorderSizePixel = 0
	local v27 = Instance.new("UIGradient")
	v27.Rotation = p25
	v27.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	v27.Parent = v26
	v26.Parent = p20
	return v26
end
function v_u_5.new(p29) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_28
	local v30 = v_u_5
	local v31 = setmetatable({}, v30)
	v31.alpha = 0
	v31.edges = {}
	local v32 = Instance.new("ScreenGui")
	v32.Name = "AshHumVignette"
	v32.IgnoreGuiInset = true
	v32.ResetOnSpawn = false
	v32.DisplayOrder = 5
	v32.Enabled = false
	local v33 = v_u_4.LocalPlayer
	if v33 then
		v33 = v33:FindFirstChildOfClass("PlayerGui")
	end
	if v33 then
		v32.Parent = v33
	end
	v31.gui = v32
	v31.edges = {
		v_u_28(v32, "Top", Vector2.new(0, 0), UDim2.fromScale(0, 0), UDim2.fromScale(1, 0.22), 90),
		v_u_28(v32, "Bottom", Vector2.new(0, 1), UDim2.fromScale(0, 1), UDim2.fromScale(1, 0.22), 270),
		v_u_28(v32, "Left", Vector2.new(0, 0), UDim2.fromScale(0, 0), UDim2.fromScale(0.16, 1), 0),
		(v_u_28(v32, "Right", Vector2.new(1, 0), UDim2.fromScale(1, 0), UDim2.fromScale(0.16, 1), 180))
	}
	local v34 = Instance.new("Part")
	v34.Name = "AshSlide"
	v34.Anchored = true
	v34.CanCollide = false
	v34.CanQuery = false
	v34.CanTouch = false
	v34.Transparency = 1
	v34.Size = Vector3.new(60, 2, 40)
	v34.CFrame = CFrame.new(0, -1000, 0)
	local v35 = Instance.new("ParticleEmitter")
	v35.Name = "Powder"
	v35.Enabled = false
	v35.Rate = 0
	v35.Lifetime = NumberRange.new(3, 5)
	v35.Speed = NumberRange.new(10, 22)
	v35.SpreadAngle = Vector2.new(25, 25)
	v35.EmissionDirection = Enum.NormalId.Front
	v35.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 5), NumberSequenceKeypoint.new(1, 16) })
	v35.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(0.3, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v35.Color = ColorSequence.new(Color3.fromRGB(235, 240, 246))
	v35.LightEmission = 0.05
	v35.Rotation = NumberRange.new(0, 360)
	v35.RotSpeed = NumberRange.new(-20, 20)
	v35.Acceleration = Vector3.new(0, -4, 0)
	v35.Parent = v34
	v34.Parent = p29
	v31.slidePart = v34
	v31.powder = v35
	v31.slideOn = false
	return v31
end
function v_u_5.update(p36, _, p_u_37) -- name: update
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_5, (copy) v_u_2
	if typeof(p_u_37) == "Vector3" and (p_u_37.X == p_u_37.X and (p_u_37.Y == p_u_37.Y and p_u_37.Z == p_u_37.Z)) then
		local v38 = v_u_3:FindFirstChild("HushRuntime")
		local v39
		if v38 and v38:GetAttribute("MapId") == "unknown5" then
			v39 = v38:FindFirstChild("Raid")
		else
			v39 = nil
		end
		local v40 = v_u_1.now()
		local v41
		if v39 then
			local v42 = v39:GetAttribute("AshSurgeWarn")
			local v43 = v39:GetAttribute("AshSurgeAt")
			local v44 = v39:GetAttribute("AshSurgeEnd")
			if type(v42) == "number" then
				p36.lastWarn = v42
				local v45
				if type(v44) == "number" then
					v45 = v44
				elseif type(v43) == "number" then
					v45 = v43 + 14
				else
					v45 = v42 + 18
				end
				p36.lastFin = v45
			end
			v41 = v_u_5.vignetteAlpha(v42, v43, v44, v40)
			if v41 == 0 and (type(v42) ~= "number" and (p36.lastWarn and v40 <= p36.lastFin + 1.5)) then
				v41 = v_u_5.vignetteAlpha(p36.lastWarn, nil, p36.lastFin, v40)
			elseif (p36.lastFin or 0) + 1.5 < v40 then
				p36.lastWarn = nil
				p36.lastFin = nil
			end
		else
			v41 = 0
		end
		local v46 = v41 - p36.alpha
		if math.abs(v46) > 0.004 or v41 == 0 and p36.alpha ~= 0 then
			p36.alpha = v41
			p36.gui.Enabled = v41 > 0.002
			local v47 = 1 - v41
			for _, v48 in ipairs(p36.edges) do
				v48.BackgroundTransparency = v47
			end
		end
		local v49 = false
		if v39 then
			local v50 = v39:GetAttribute("AshAvalancheAt")
			local v_u_51 = v39:GetAttribute("AshAvalancheX")
			local v_u_52 = v39:GetAttribute("AshAvalancheZ")
			if type(v_u_51) == "number" and type(v_u_52) == "number" then
				local v53 = p_u_37.Y
				local v54 = (Vector3.new(v_u_51, v53, v_u_52) - p_u_37).Magnitude
				v49 = v_u_5.slideActive(v50, v40, v54)
				if v49 and not p36.slideOn then
					local v55 = p_u_37.Y
					local function v60()
						-- upvalues: (ref) v_u_2, (copy) v_u_51, (copy) p_u_37, (copy) v_u_52
						local v56 = v_u_2
						local v57 = v_u_51
						local v58 = p_u_37.Y + 300
						local v59 = v_u_52
						return v56:Raycast(Vector3.new(v57, v58, v59), Vector3.new(0, -700, 0))
					end
					local v61, v62 = pcall(v60)
					if v61 and v62 then
						v55 = v62.Position.Y
					end
					local v63 = Vector3.new(v_u_51, 0, v_u_52)
					local v64 = v63.Magnitude <= 1 and Vector3.new(0, 0, 1) or v63.Unit
					local v65 = v55 + 6
					local v66 = Vector3.new(v_u_51, v65, v_u_52)
					p36.slidePart.CFrame = CFrame.lookAt(v66, v66 + v64)
					p36.powder.Rate = 40
					p36.powder.Enabled = true
				end
			end
		end
		if not v49 and p36.slideOn then
			p36.powder.Enabled = false
			p36.powder.Rate = 0
		end
		p36.slideOn = v49
	end
end
function v_u_5.destroy(p67) -- name: destroy
	if p67.gui then
		p67.gui:Destroy()
	end
	if p67.slidePart then
		p67.slidePart:Destroy()
	end
end
return v_u_5