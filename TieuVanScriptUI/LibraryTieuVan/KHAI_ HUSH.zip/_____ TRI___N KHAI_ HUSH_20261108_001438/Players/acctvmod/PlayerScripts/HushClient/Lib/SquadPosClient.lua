-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadPosClient

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SquadPosRules"))
local v_u_4 = {
	["Rules"] = v_u_3
}
local v_u_5 = {}
local v_u_6 = -1
local v_u_7 = (-1 / 0)
local v_u_8 = {}
local v_u_9 = {
	["packets"] = 0,
	["applied"] = 0,
	["refused"] = 0,
	["stale"] = 0,
	["entries"] = 0,
	["lastSeq"] = 0,
	["lastRaw"] = ""
}
v_u_4.rx = v_u_9
function v_u_4.clear() -- name: clear
	-- upvalues: (copy) v_u_5, (ref) v_u_6, (ref) v_u_7
	table.clear(v_u_5)
	v_u_6 = -1
	v_u_7 = (-1 / 0)
end
function v_u_4.apply(p10, p11) -- name: apply
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (ref) v_u_6, (ref) v_u_7, (copy) v_u_5
	local v12 = v_u_9
	v12.packets = v12.packets + 1
	local v13, v14 = v_u_3.decode(p10)
	if v13 == nil or v14 == nil then
		local v15 = v_u_9
		v15.refused = v15.refused + 1
		return false
	end
	if v13 <= v_u_6 and p11 - v_u_7 <= v_u_3.STALE then
		local v16 = v_u_9
		v16.stale = v16.stale + 1
		return false
	end
	v_u_6 = v13
	v_u_7 = p11
	local v17 = {}
	for _, v18 in v14 do
		local v19 = v_u_5[v18.uid]
		local v20 = v18.pos
		local v21 = v18.yaw
		local v22 = v_u_3.PERIOD
		if v19 and p11 - v19.at <= v_u_3.STALE then
			local v23
			if v19.span > 0 then
				local v24 = (p11 - v19.at) / v19.span
				v23 = math.clamp(v24, 0, 1)
			else
				v23 = 1
			end
			v20 = v19.prev:Lerp(v19.pos, v23)
			local v25 = v19.prevYaw
			v21 = v25 + ((v19.yaw - v25 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v23
		end
		v17[v18.uid] = {
			["uid"] = v18.uid,
			["pos"] = v18.pos,
			["prev"] = v20,
			["yaw"] = v18.yaw,
			["prevYaw"] = v21,
			["downed"] = v18.downed,
			["at"] = p11,
			["span"] = v22
		}
	end
	table.clear(v_u_5)
	for v26, v27 in v17 do
		v_u_5[v26] = v27
	end
	local v28 = v_u_9
	v28.applied = v28.applied + 1
	v_u_9.entries = #v14
	v_u_9.lastSeq = v13
	return true
end
function v_u_4.entries(p29) -- name: entries
	-- upvalues: (copy) v_u_5, (copy) v_u_3
	local v30 = {}
	local v31 = {}
	for v32, v33 in v_u_5 do
		if p29 - v33.at > v_u_3.STALE then
			table.insert(v30, v32)
		else
			local v34
			if v33.span > 0 then
				local v35 = (p29 - v33.at) / v33.span
				v34 = math.clamp(v35, 0, 1)
			else
				v34 = 1
			end
			local v36 = v33.prev:Lerp(v33.pos, v34)
			local v37 = v33.prevYaw
			local v38 = {
				["uid"] = v32,
				["pos"] = v36,
				["yaw"] = v37 + ((v33.yaw - v37 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v34,
				["downed"] = v33.downed,
				["age"] = p29 - v33.at
			}
			table.insert(v31, v38)
		end
	end
	for _, v39 in v30 do
		v_u_5[v39] = nil
	end
	table.sort(v31, function(p40, p41)
		return p40.uid < p41.uid
	end)
	return v31
end
function v_u_4.byUid(p42) -- name: byUid
	-- upvalues: (copy) v_u_4
	local v43 = {}
	for _, v44 in v_u_4.entries(p42) do
		v43[v44.uid] = v44
	end
	return v43
end
function v_u_4.hint(p45, p46) -- name: hint
	-- upvalues: (copy) v_u_8
	v_u_8[p45] = p46
end
function v_u_4.nameOf(p47) -- name: nameOf
	-- upvalues: (copy) v_u_1, (copy) v_u_8
	local v48 = v_u_1:GetPlayerByUserId(p47)
	return not v48 and (v_u_8[p47] or "MATE") or v48.DisplayName
end
local v_u_49 = false
function v_u_4.start(p_u_50) -- name: start
	-- upvalues: (ref) v_u_49, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9, (copy) v_u_2, (copy) v_u_1
	if v_u_49 then
		return
	else
		v_u_49 = true
		task.spawn(function()
			-- upvalues: (copy) p_u_50, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9, (ref) v_u_2
			p_u_50.net.listenUnreliable(v_u_3.CHANNEL, function(p_u_51)
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_2
				local v52 = v_u_4.apply
				local v53 = os.clock
				local v54, v55 = pcall(v52, p_u_51, v53())
				if not v54 then
					local v56 = v_u_9
					v56.refused = v56.refused + 1
					warn("[SquadPosClient] packet:", v55)
				end
				if v_u_2:IsStudio() then
					local v57, v58 = pcall(function()
						-- upvalues: (copy) p_u_51
						return table.concat(p_u_51, ",")
					end)
					v_u_9.lastRaw = not v57 and "?" or v58
				end
			end)
		end)
		if v_u_2:IsStudio() then
			p_u_50.command("squadpos.rx", function()
				-- upvalues: (ref) v_u_9
				return ("packets=%d applied=%d refused=%d stale=%d lastSeq=%d entries=%d raw=[%s]"):format(v_u_9.packets, v_u_9.applied, v_u_9.refused, v_u_9.stale, v_u_9.lastSeq, v_u_9.entries, v_u_9.lastRaw)
			end)
			p_u_50.command("squadpos.dump", function()
				-- upvalues: (ref) v_u_4
				local v59 = {}
				for _, v60 in v_u_4.entries(os.clock()) do
					local v61 = v60.uid
					local v62 = v_u_4.nameOf(v60.uid)
					local v63 = v60.pos
					local v64 = tostring(v63)
					local v65 = v60.yaw
					local v66 = math.deg(v65)
					local v67 = v60.downed
					local v68 = tostring(v67)
					local v69 = v60.age
					table.insert(v59, ("%d %s pos=%s yaw=%.0f downed=%s age=%.2f"):format(v61, v62, v64, v66, v68, v69))
				end
				return #v59 <= 0 and "(none)" or table.concat(v59, "\n")
			end)
			p_u_50.command("squadpos.name", function(p70)
				-- upvalues: (ref) v_u_4
				local v71 = p70[1]
				local v72 = tonumber(v71)
				if not v72 then
					return "usage: squadpos.name <uid> <NAME>"
				end
				v_u_4.hint(v72, p70[2])
				return ("%d = %s"):format(v72, v_u_4.nameOf(v72))
			end)
			p_u_50.command("squadpos.attrs", function()
				-- upvalues: (ref) v_u_1
				local v73 = {}
				for _, v74 in v_u_1:GetPlayers() do
					local v75 = v74:GetAttribute("MapPos")
					local v76 = v74:GetAttribute("MapYaw")
					local v77 = v74.Name
					local v78 = tostring(v75)
					local v79 = tostring(v76)
					table.insert(v73, ("%s MapPos=%s MapYaw=%s"):format(v77, v78, v79))
				end
				return table.concat(v73, "\n")
			end)
			p_u_50.command("squadpos.clear", function()
				-- upvalues: (ref) v_u_4
				v_u_4.clear()
				return "cleared"
			end)
		end
	end
end
return v_u_4