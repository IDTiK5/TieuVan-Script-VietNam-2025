-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardProps

local v_u_1 = {
	["KINDS"] = {
		["g17"] = "the P17 pistol with the skin the player has on it",
		["knife"] = "a fixed combat knife (the bayonet model of the game)",
		["rifle"] = "a fixed rifle (the R-15 model of the game)",
		["mic"] = "a microphone built from handle, head and grille",
		["ice"] = "an ice floor of flat shards that cracks open",
		["flash"] = "a muzzle flash of neon spikes (R41 kcv3): its origin is the muzzle, it points along the barrel (local z backwards), k = its size 0..1 (hidden below 0.02)",
		["zombie"] = "the real walker zombie of the game (R42 anim2_zombierow, ZOMBIE DROP; a block zombie stands in without a rig): origin at the feet, looks toward local z negative, k = the clock of the shot and fall pose (k * 6 s)"
	},
	["ITEM"] = {
		["g17"] = "pistol_g17",
		["knife"] = "melee_knife",
		["rifle"] = "rifle_ar15"
	}
}
local v_u_2 = math.rad
local v_u_3 = nil
local function v_u_8(p4) -- name: gripsOf
	-- upvalues: (ref) v_u_3
	if type(p4) == "table" and p4.Grips ~= nil then
		return p4.Grips
	else
		if v_u_3 == nil then
			local v6, v7 = pcall(function()
				local v5 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v5 then
					v5 = v5:FindFirstChild("Shared")
				end
				if v5 then
					v5 = v5:FindFirstChild("KillCardGrips")
				end
				return require(v5)
			end)
			if not v6 or type(v7) ~= "table" then
				v7 = false
			end
			v_u_3 = v7
		end
		if v_u_3 then
			return v_u_3
		else
			return nil
		end
	end
end
local v_u_9 = nil
local function v_u_14(p10) -- name: zposeOf
	-- upvalues: (ref) v_u_9
	if type(p10) == "table" and p10.ZombiePose ~= nil then
		return p10.ZombiePose
	else
		if v_u_9 == nil then
			local v12, v13 = pcall(function()
				local v11 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v11 then
					v11 = v11:FindFirstChild("Shared")
				end
				if v11 then
					v11 = v11:FindFirstChild("KillCardZombiePose")
				end
				return require(v11)
			end)
			if not v12 or type(v13) ~= "table" then
				v13 = false
			end
			v_u_9 = v13
		end
		if v_u_9 then
			return v_u_9
		else
			return nil
		end
	end
end
function v_u_1.rotCF(p15) -- name: rotCF
	-- upvalues: (copy) v_u_2
	return CFrame.Angles(0, 0, (v_u_2(p15[3]))) * CFrame.Angles(0, v_u_2(p15[2]), 0) * CFrame.Angles(v_u_2(p15[1]), 0, 0)
end
function v_u_1.holdCF(p16, p17, p18, p19) -- name: holdCF
	-- upvalues: (copy) v_u_1
	if p16 == nil then
		return CFrame.identity
	end
	local v20, v21 = p16.hold(p17, p18, p19)
	return CFrame.new(v20[1], v20[2], v20[3]) * v_u_1.rotCF(v21)
end
v_u_1.MIC = {
	["handleLen"] = 0.95,
	["handleDia"] = 0.2,
	["headDia"] = 0.5,
	["grilleDia"] = 0.56,
	["grilleLen"] = 0.12
}
function v_u_1.micParts() -- name: micParts
	-- upvalues: (copy) v_u_1
	local v22 = v_u_1.MIC
	local v23 = CFrame.Angles(0, 1.5707963267948966, 0)
	local v24 = -(v22.handleLen / 2 + v22.headDia * 0.35)
	local v25 = {}
	local v26 = {
		["name"] = "Handle",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil,
		["material"] = nil
	}
	local v27 = v22.handleLen
	local v28 = v22.handleDia
	local v29 = v22.handleDia
	v26.size = Vector3.new(v27, v28, v29)
	v26.cf = v23
	v26.shape = Enum.PartType.Cylinder
	v26.color = Color3.fromRGB(28, 28, 32)
	v26.material = Enum.Material.Metal
	local v30 = {
		["name"] = "Ring",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil,
		["material"] = nil
	}
	local v31 = v22.handleDia * 1.25
	local v32 = v22.handleDia * 1.25
	v30.size = Vector3.new(0.1, v31, v32)
	v30.cf = CFrame.new(0, 0, -v22.handleLen / 2 + 0.05) * v23
	v30.shape = Enum.PartType.Cylinder
	v30.color = Color3.fromRGB(190, 192, 198)
	v30.material = Enum.Material.Metal
	local v33 = {
		["name"] = "Head",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil,
		["material"] = nil
	}
	local v34 = v22.headDia
	local v35 = v22.headDia
	local v36 = v22.headDia
	v33.size = Vector3.new(v34, v35, v36)
	v33.cf = CFrame.new(0, 0, v24)
	v33.shape = Enum.PartType.Ball
	v33.color = Color3.fromRGB(120, 124, 132)
	v33.material = Enum.Material.Metal
	local v37 = {
		["name"] = "Grille",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil,
		["material"] = nil
	}
	local v38 = v22.grilleLen
	local v39 = v22.grilleDia
	local v40 = v22.grilleDia
	v37.size = Vector3.new(v38, v39, v40)
	v37.cf = CFrame.new(0, 0, v24) * v23
	v37.shape = Enum.PartType.Cylinder
	v37.color = Color3.fromRGB(46, 48, 54)
	v37.material = Enum.Material.Metal
	__set_list(v25, 1, {v26, v30, v33, v37})
	return v25
end
local v_u_41 = {
	{
		["n"] = 5,
		["r0"] = 0,
		["r1"] = 1.1
	},
	{
		["n"] = 8,
		["r0"] = 1.1,
		["r1"] = 2.2
	},
	{
		["n"] = 11,
		["r0"] = 2.2,
		["r1"] = 3.3
	}
}
local v_u_42 = nil
function v_u_1.iceShards() -- name: iceShards
	-- upvalues: (ref) v_u_42, (copy) v_u_41, (copy) v_u_2
	if v_u_42 then
		return v_u_42
	end
	local v43 = 0
	local v44 = {}
	for v45, v46 in v_u_41 do
		for v47 = 1, v46.n do
			v43 = v43 + 1
			local v48 = v47 - 0.5
			local v49 = v43 * 12.9898 + 78.233
			local v50 = (v48 + (math.sin(v49) * 0.9999 % 2 - 1) * 0.18) / v46.n * 3.141592653589793 * 2 + v45 * 0.3
			local v51
			if v46.r0 == 0 then
				local v52 = v43 * 12.9898 + 156.466
				v51 = (math.sin(v52) * 0.9999 % 2 - 1 + 1) * 0.15 + 0.35
			else
				v51 = (v46.r0 + v46.r1) / 2
			end
			local v53
			if v46.r0 == 0 then
				v53 = v46.r1 * 0.95
			else
				v53 = (v46.r1 - v46.r0) * 0.96
			end
			local v54
			if v46.r0 == 0 then
				v54 = 3.8955748904513436 / v46.n * 1.25
			else
				local v55 = 6.283185307179586 * v51 / v46.n * 0.96
				v54 = math.max(0.5, v55)
			end
			local v56 = {
				["ring"] = v45,
				["ang"] = v50,
				["rc"] = v51,
				["w"] = v54,
				["d"] = v53
			}
			local v57 = 0.25 + 0.2 * v45
			local v58 = v43 * 12.9898 + 234.699
			v56.spread = v57 * ((math.sin(v58) * 0.9999 % 2 - 1 + 1) * 0.3 + 0.7)
			local v59 = v43 * 12.9898 + 312.932
			v56.lift = 0.04 + (math.sin(v59) * 0.9999 % 2 - 1 + 1) * 0.16 * 0.5 * (4 - v45) / 3
			local v60 = v43 * 12.9898 + 391.165
			local v61 = v_u_2((math.sin(v60) * 0.9999 % 2 - 1 + 1) * 20 / 2 + 7)
			local v62 = v43 * 12.9898 + 469.398
			v56.tilt = v61 * (math.sin(v62) * 0.9999 % 2 - 1 > 0 and 1 or -1)
			local v63 = v43 * 12.9898 + 547.6310000000001
			v56.twist = (math.sin(v63) * 0.9999 % 2 - 1) * 0.13962634015954636
			v44[v43] = v56
		end
	end
	v_u_42 = v44
	return v44
end
v_u_1.ICE_THICK = 0.2
function v_u_1.iceShardCF(p64, p65) -- name: iceShardCF
	-- upvalues: (copy) v_u_1
	local v66 = (type(p65) ~= "number" or p65 ~= p65) and 0 or p65
	local v67 = math.clamp(v66, 0, 1)
	local v68 = 1 - (1 - v67) * (1 - v67)
	local v69 = p64.rc + p64.spread * v68
	local v70 = p64.ang
	local v71 = math.cos(v70) * v69
	local v72 = p64.lift * v68 + v_u_1.ICE_THICK / 2
	local v73 = p64.ang
	local v74 = math.sin(v73) * v69
	local v75 = Vector3.new(v71, v72, v74)
	local v76 = CFrame.lookAt
	local v77 = p64.ang
	local v78 = math.cos(v77)
	local v79 = p64.ang
	local v80 = math.sin(v79)
	local v81 = v76(v75, v75 + Vector3.new(v78, 0, v80)) * CFrame.Angles(p64.tilt * v68, p64.twist * v68, 0)
	local v82 = p64.w
	local v83 = v_u_1.ICE_THICK
	local v84 = p64.d
	return v81, Vector3.new(v82, v83, v84)
end
v_u_1.ZOMBIE = {
	["height"] = 5.1,
	["neckY"] = 3.9,
	["snapDeg"] = 38,
	["hot"] = nil,
	["variants"] = 5,
	["hot"] = Color3.fromRGB(255, 140, 70)
}
local v_u_85 = {
	Color3.fromRGB(122, 150, 98),
	Color3.fromRGB(138, 160, 110),
	Color3.fromRGB(112, 140, 120),
	Color3.fromRGB(150, 158, 104),
	Color3.fromRGB(128, 146, 92)
}
local v_u_86 = {
	Color3.fromRGB(70, 84, 96),
	Color3.fromRGB(96, 70, 62),
	Color3.fromRGB(64, 92, 74),
	Color3.fromRGB(88, 88, 70),
	Color3.fromRGB(60, 66, 90)
}
local v_u_87 = {
	Color3.fromRGB(44, 48, 58),
	Color3.fromRGB(58, 52, 46),
	Color3.fromRGB(40, 54, 52),
	Color3.fromRGB(60, 58, 52),
	Color3.fromRGB(38, 42, 64)
}
function v_u_1.zombieParts(p88) -- name: zombieParts
	-- upvalues: (copy) v_u_1, (copy) v_u_85, (copy) v_u_86, (copy) v_u_87, (copy) v_u_2
	local v89 = (type(p88) ~= "number" or p88 ~= p88) and 1 or p88
	local v90 = (math.floor(v89) - 1) % v_u_1.ZOMBIE.variants + 1
	local v91 = v_u_85[v90]
	local v92 = v_u_86[v90]
	local v93 = v_u_87[v90]
	local v94 = v_u_2(8 + v90 * 2)
	return {
		{
			["name"] = "LegL",
			["size"] = Vector3.new(0.78, 2, 0.8),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new(0.42, 1, 0),
			["color"] = v93,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "LegR",
			["size"] = Vector3.new(0.78, 2, 0.8),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new(-0.42, 1, 0),
			["color"] = v93,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "Torso",
			["size"] = Vector3.new(1.9, 1.9, 0.95),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new(0, 2.95, 0),
			["color"] = v92,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "Patch",
			["size"] = Vector3.new(0.7, 0.8, 0.05),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new((v90 % 2 == 0 and -1 or 1) * 0.35, 2.8, -0.5),
			["color"] = v91,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "ArmL",
			["size"] = Vector3.new(0.6, 0.6, 1.8),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new(1.25, 3.5, -0.85) * CFrame.Angles(v94, 0, 0),
			["color"] = v91,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "ArmR",
			["size"] = Vector3.new(0.6, 0.6, 1.8),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = false,
			["cf"] = CFrame.new(-1.25, 3.5, -0.85) * CFrame.Angles(v94, 0, 0),
			["color"] = v91,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "Head",
			["size"] = Vector3.new(1.2, 1.2, 1.2),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = true,
			["cf"] = CFrame.new(0, 4.5, 0),
			["color"] = v91,
			["material"] = Enum.Material.SmoothPlastic
		},
		{
			["name"] = "EyeL",
			["size"] = Vector3.new(0.24, 0.2, 0.06),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = true,
			["cf"] = CFrame.new(0.3, 4.6, -0.62),
			["color"] = Color3.fromRGB(240, 214, 90),
			["material"] = Enum.Material.Neon
		},
		{
			["name"] = "EyeR",
			["size"] = Vector3.new(0.24, 0.2, 0.06),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = true,
			["cf"] = CFrame.new(-0.3, 4.6, -0.62),
			["color"] = Color3.fromRGB(240, 214, 90),
			["material"] = Enum.Material.Neon
		},
		{
			["name"] = "Mouth",
			["size"] = Vector3.new(0.56, 0.14, 0.06),
			["cf"] = nil,
			["color"] = nil,
			["material"] = nil,
			["head"] = true,
			["cf"] = CFrame.new(0, 4.15, -0.62),
			["color"] = Color3.fromRGB(40, 22, 22),
			["material"] = Enum.Material.SmoothPlastic
		}
	}
end
function v_u_1.zombieHeadCF(p95) -- name: zombieHeadCF
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v96 = (type(p95) ~= "number" or p95 ~= p95) and 0 or p95
	local v97 = math.clamp(v96, 0, 1)
	local v98 = CFrame.new(0, v_u_1.ZOMBIE.neckY, 0)
	return v98 * CFrame.Angles(v_u_2(v_u_1.ZOMBIE.snapDeg) * v97, 0, 0) * v98:Inverse()
end
v_u_1.WALKER = {
	["rootHeight"] = 3,
	["minJoints"] = 10,
	["tolerance"] = 0.15
}
v_u_1.BLOCK_HIP = 2
v_u_1.BLOCK_LIE = 0.5
function v_u_1.jointCF(p99, p100, p101, p102, p103) -- name: jointCF
	local v104 = p100.joints[p99]
	if v104 == nil then
		return CFrame.identity
	end
	local v105 = CFrame.fromEulerAnglesYXZ(v104[1], v104[2], v104[3])
	if p99 == "Root" then
		v105 = CFrame.new(0, -(p101 - p102) * p100.drop + p100.dip * p103, p100.slide * p103) * v105
	end
	return v105
end
function v_u_1.blockCF(p106) -- name: blockCF
	-- upvalues: (copy) v_u_1
	local v107 = v_u_1.BLOCK_HIP
	local v108 = v_u_1.BLOCK_LIE
	local v109 = p106.joints.Root
	local v110 = CFrame.new(0, v107, 0)
	return CFrame.new(0, -(v107 - v108) * p106.drop + p106.dip, p106.slide) * v110 * CFrame.fromEulerAnglesYXZ(v109[1], v109[2], v109[3]) * v110:Inverse()
end
local function v_u_113(p111) -- name: anchorAll
	for _, v112 in p111:GetDescendants() do
		if v112:IsA("BasePart") then
			v112.Anchored = true
			v112.CanCollide = false
			v112.CanQuery = false
			v112.CanTouch = false
			v112.Massless = true
		else
			if not (v112:IsA("LuaSourceContainer") or (v112:IsA("Sound") or (v112:IsA("Light") or (v112:IsA("ParticleEmitter") or v112:IsA("BillboardGui"))))) then
				continue
			end
			v112:Destroy()
		end
	end
	if p111:IsA("BasePart") then
		p111.Anchored = true
		p111.CanCollide = false
		p111.CanQuery = false
		p111.CanTouch = false
	end
end
local function v_u_118() -- name: buildMic
	-- upvalues: (copy) v_u_1, (copy) v_u_113
	local v114 = Instance.new("Model")
	v114.Name = "KcMic"
	for v115, v116 in v_u_1.micParts() do
		local v117 = Instance.new("Part")
		v117.Name = v116.name
		v117.Shape = v116.shape
		v117.Size = v116.size
		v117.Color = v116.color
		v117.Material = v116.material
		v117.TopSurface = Enum.SurfaceType.Smooth
		v117.BottomSurface = Enum.SurfaceType.Smooth
		v117.CFrame = v116.cf
		v117.Parent = v114
		if v115 ~= 1 then
			continue
		end
		v114.PrimaryPart = v117
	end
	v_u_113(v114)
	return v114
end
v_u_1.FLASH = {
	["core"] = 0.34,
	["spike"] = 1.25,
	["star"] = 0.55,
	["stars"] = 6
}
function v_u_1.flashParts() -- name: flashParts
	-- upvalues: (copy) v_u_1
	local v119 = v_u_1.FLASH
	local v120 = {}
	local v121 = {
		["name"] = "Core",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil
	}
	local v122 = v119.core
	local v123 = v119.core
	local v124 = v119.core
	v121.size = Vector3.new(v122, v123, v124)
	v121.cf = CFrame.new(0, 0, -v119.core * 0.3)
	v121.shape = Enum.PartType.Ball
	v121.color = Color3.fromRGB(255, 244, 205)
	local v125 = {
		["name"] = "Spike",
		["size"] = nil,
		["cf"] = nil,
		["shape"] = nil,
		["color"] = nil
	}
	local v126 = v119.spike
	v125.size = Vector3.new(0.09, 0.09, v126)
	v125.cf = CFrame.new(0, 0, -v119.spike / 2)
	v125.shape = Enum.PartType.Block
	v125.color = Color3.fromRGB(255, 196, 92)
	__set_list(v120, 1, {v121, v125})
	for v127 = 1, v119.stars do
		local v128 = (v127 - 1) / v119.stars * 3.141592653589793 * 2 + 0.2
		local v129 = #v120 + 1
		local v130 = {
			["name"] = "Star" .. v127
		}
		local v131 = v119.star
		v130.size = Vector3.new(0.06, 0.06, v131)
		v130.cf = CFrame.new(0, 0, -0.1) * CFrame.Angles(0, 0, v128) * CFrame.new(0, 0, -v119.star / 2) * CFrame.Angles(-0.6632251157578453, 0, 0)
		v130.shape = Enum.PartType.Block
		v130.color = Color3.fromRGB(255, 170, 70)
		v120[v129] = v130
	end
	return v120
end
local function v_u_136() -- name: buildFlash
	-- upvalues: (copy) v_u_1, (copy) v_u_113
	local v132 = Instance.new("Model")
	v132.Name = "KcFlash"
	for v133, v134 in v_u_1.flashParts() do
		local v135 = Instance.new("Part")
		v135.Name = v134.name
		v135.Shape = v134.shape
		v135.Size = v134.size
		v135.Color = v134.color
		v135.Material = Enum.Material.Neon
		v135.CastShadow = false
		v135.TopSurface = Enum.SurfaceType.Smooth
		v135.BottomSurface = Enum.SurfaceType.Smooth
		v135.CFrame = v134.cf
		v135.Parent = v132
		if v133 ~= 1 then
			continue
		end
		v132.PrimaryPart = v135
	end
	v_u_113(v132)
	return v132
end
local function v_u_145() -- name: buildIce
	-- upvalues: (copy) v_u_1, (copy) v_u_113
	local v137 = Instance.new("Model")
	v137.Name = "KcIce"
	local v138 = Instance.new("Part")
	v138.Name = "Anchor"
	v138.Size = Vector3.new(0.2, 0.2, 0.2)
	v138.Transparency = 1
	v138.Parent = v137
	v137.PrimaryPart = v138
	for v139, v140 in v_u_1.iceShards() do
		local v141 = Instance.new("Part")
		v141.Name = "Shard" .. v139
		local v142 = v140.w
		local v143 = v_u_1.ICE_THICK
		local v144 = v140.d
		v141.Size = Vector3.new(v142, v143, v144)
		v141.Material = Enum.Material.Glass
		v141.Color = Color3.fromRGB(96 + v139 * 7 % 34, 176 + v139 * 3 % 30, 240)
		v141.Transparency = 0.18 + 0.12 * (v139 * 5 % 4) / 3
		v141.Reflectance = 0.1
		v141.TopSurface = Enum.SurfaceType.Smooth
		v141.BottomSurface = Enum.SurfaceType.Smooth
		v141.Parent = v137
	end
	v_u_113(v137)
	return v137
end
local function v_u_152(p146) -- name: buildZombie
	-- upvalues: (copy) v_u_1, (copy) v_u_113
	local v147 = Instance.new("Model")
	v147.Name = "KcZombie"
	local v148 = {}
	for v149, v150 in v_u_1.zombieParts(p146) do
		local v151 = Instance.new("Part")
		v151.Name = v150.name
		v151.Size = v150.size
		v151.Color = v150.color
		v151.Material = v150.material
		v151.CastShadow = false
		v151.TopSurface = Enum.SurfaceType.Smooth
		v151.BottomSurface = Enum.SurfaceType.Smooth
		v151.CFrame = v150.cf
		v151.Parent = v147
		if v150.name == "Torso" then
			v147.PrimaryPart = v151
		end
		v148[v149] = {
			["part"] = v151,
			["rest"] = v150.cf,
			["head"] = v150.head,
			["color"] = v150.color,
			["material"] = v150.material,
			["skin"] = v150.name == "Head"
		}
	end
	v_u_113(v147)
	return v147, v148
end
local v_u_153 = {
	["Root"] = true,
	["Waist"] = true,
	["Neck"] = true,
	["LeftShoulder"] = true,
	["LeftElbow"] = true,
	["LeftWrist"] = true,
	["RightShoulder"] = true,
	["RightElbow"] = true,
	["RightWrist"] = true,
	["LeftHip"] = true,
	["LeftKnee"] = true,
	["LeftAnkle"] = true,
	["RightHip"] = true,
	["RightKnee"] = true,
	["RightAnkle"] = true
}
local function v_u_171(p_u_154) -- name: prepareWalker
	-- upvalues: (copy) v_u_153, (copy) v_u_1
	local v155 = p_u_154:FindFirstChild("HumanoidRootPart")
	if not (v155 and v155:IsA("BasePart")) then
		return nil
	end
	local v156 = {}
	local v157 = 0
	for _, v158 in p_u_154:GetDescendants() do
		if v158:IsA("Motor6D") and (v_u_153[v158.Name] and v156[v158.Name] == nil) then
			v156[v158.Name] = v158
			v157 = v157 + 1
		else
			if not (v158:IsA("LuaSourceContainer") or (v158:IsA("Sound") or (v158:IsA("Light") or (v158:IsA("ParticleEmitter") or (v158:IsA("BillboardGui") or v158:IsA("Animator")))))) then
				continue
			end
			v158:Destroy()
		end
	end
	if v157 < v_u_1.WALKER.minJoints then
		return nil
	end
	for _, v159 in p_u_154:GetDescendants() do
		if not v159:IsA("BasePart") then
			continue
		end
		v159.Anchored = v159 == v155
		v159.CanCollide = false
		v159.CanQuery = false
		v159.CanTouch = false
		v159.Massless = true
		v159.CastShadow = false
	end
	v155.Transparency = 1
	local v160, v161 = p_u_154:GetBoundingBox()
	local v_u_162 = v155.Position.Y - (v160.Position.Y - v161.Y / 2)
	if v_u_162 <= 0.5 or v_u_162 >= 12 then
		return nil
	end
	local v_u_163 = v_u_1.WALKER
	local v164 = v_u_162 - v_u_163.rootHeight
	if math.abs(v164) > v_u_163.tolerance then
		pcall(function()
			-- upvalues: (copy) p_u_154, (copy) v_u_163, (ref) v_u_162
			p_u_154:ScaleTo(p_u_154:GetScale() * v_u_163.rootHeight / v_u_162)
		end)
		local v165, v166 = p_u_154:GetBoundingBox()
		v_u_162 = v155.Position.Y - (v165.Position.Y - v166.Y / 2)
	end
	local v167 = v_u_162 * 0.55
	local v168 = v156.Root
	if v168.Part0 ~= nil and v168.Part0.Name == "HumanoidRootPart" then
		v167 = v_u_162 + v168.C0.Y
	end
	local v169 = p_u_154:FindFirstChild("UpperTorso")
	local v170
	if v169 and v169:IsA("BasePart") then
		v170 = v169.Size.Z * 0.5 + 0.04
	else
		v170 = v_u_162 * 0.5 / v_u_163.rootHeight
	end
	return {
		["root"] = v155,
		["motors"] = v156,
		["hip"] = v167,
		["lie"] = v170,
		["scale"] = v_u_162 / v_u_163.rootHeight,
		["rootH"] = v_u_162,
		["pivotRel"] = v155.CFrame:ToObjectSpace(p_u_154:GetPivot())
	}
end
local function v_u_182(p172) -- name: buildWalker
	-- upvalues: (copy) v_u_171
	local v173 = p172.deps
	local v174
	if type(v173) == "table" then
		v174 = v173.zombieRig
	else
		v174 = nil
	end
	if type(v174) ~= "function" then
		return nil, nil
	end
	local v175, v176 = pcall(v174)
	if v175 and type(v176) == "table" then
		local v177 = v176.model
		if typeof(v177) == "Instance" and v176.model:IsA("Model") then
			local v_u_178 = v176.model
			local v179 = v_u_171
			local v180, v181 = pcall(v179, v_u_178)
			if v180 and v181 ~= nil then
				return v_u_178, v181
			end
			pcall(function()
				-- upvalues: (copy) v_u_178
				v_u_178:Destroy()
			end)
			return nil, nil
		end
	end
	return nil, nil
end
function v_u_1.new(p_u_183) -- name: new
	-- upvalues: (copy) v_u_118, (copy) v_u_182, (copy) v_u_152, (copy) v_u_145, (copy) v_u_136, (copy) v_u_113, (copy) v_u_1, (copy) v_u_8, (copy) v_u_14
	local v184 = {}
	local v_u_185 = {}
	local v_u_186 = true
	local function v_u_188() -- name: clear
		-- upvalues: (ref) v_u_185
		for _, v_u_187 in v_u_185 do
			pcall(function()
				-- upvalues: (copy) v_u_187
				v_u_187.model:Destroy()
			end)
		end
		v_u_185 = {}
	end
	local function v_u_196(p189) -- name: gameModel
		-- upvalues: (copy) p_u_183
		local v190 = p_u_183.deps
		if type(v190) == "table" then
			local v191 = v190.propModel
			if type(v191) == "function" then
				local v192 = v190.propModel
				local v193
				if p189 == "g17" then
					v193 = p_u_183.skin
				else
					v193 = nil
				end
				local v194, v195 = pcall(v192, p189, v193)
				if v194 and (typeof(v195) == "Instance" and v195:IsA("Model")) then
					return v195
				else
					return nil
				end
			end
		end
		return nil
	end
	function v184.build(p197) -- name: build
		-- upvalues: (copy) v_u_188, (ref) v_u_186, (ref) v_u_118, (ref) v_u_182, (copy) p_u_183, (ref) v_u_152, (ref) v_u_145, (ref) v_u_136, (copy) v_u_196, (ref) v_u_113, (ref) v_u_185
		v_u_188()
		if v_u_186 and type(p197) == "table" then
			local v_u_198 = 0
			for _, v_u_199 in p197 do
				local v_u_200 = nil
				local v201 = CFrame.identity
				local v_u_202 = nil
				local v_u_203 = nil
				local function v215()
					-- upvalues: (copy) v_u_199, (ref) v_u_200, (ref) v_u_118, (ref) v_u_198, (ref) v_u_203, (ref) v_u_182, (ref) p_u_183, (ref) v_u_202, (ref) v_u_152, (ref) v_u_145, (ref) v_u_136, (ref) v_u_196, (ref) v_u_113
					if v_u_199.kind == "mic" then
						v_u_200 = v_u_118()
					elseif v_u_199.kind == "zombie" then
						v_u_198 = v_u_198 + 1
						local v204, v205 = v_u_182(p_u_183)
						v_u_200 = v204
						v_u_203 = v205
						if v_u_200 == nil then
							local v206 = v_u_152
							local v207 = string.match
							local v208 = v_u_199.id
							local v209 = tostring(v208)
							local v210, v211 = v206(tonumber(v207(v209, "%d+")) or v_u_198)
							v_u_200 = v210
							v_u_202 = v211
							return
						end
					else
						if v_u_199.kind == "ice" then
							v_u_200 = v_u_145()
							return
						end
						if v_u_199.kind == "flash" then
							v_u_200 = v_u_136()
							return
						end
						v_u_200 = v_u_196(v_u_199.kind)
						if v_u_200 ~= nil then
							v_u_113(v_u_200)
							local v212 = v_u_199.scale
							if type(v212) == "number" then
								local v213 = v_u_199.scale - 1
								if math.abs(v213) > 0.001 then
									local function v214()
										-- upvalues: (ref) v_u_200, (ref) v_u_199
										v_u_200:ScaleTo(v_u_199.scale)
									end
									pcall(v214)
								end
							end
						end
					end
				end
				if not pcall(v215) or v_u_200 == nil then
					continue
				end
				local v216 = v_u_200
				local v217 = v216.PrimaryPart or v216:FindFirstChildWhichIsA("BasePart", true)
				if v217 == nil then
					v216:Destroy()
				else
					local v218 = v217:FindFirstChild("Grip")
					if v218 and v218:IsA("Attachment") then
						v201 = v218.CFrame
					end
					local v219 = v217.CFrame:ToObjectSpace(v216:GetPivot())
					v216.Parent = p_u_183.parent
					local v220 = v_u_185
					local v221 = {
						["id"] = nil,
						["kind"] = nil,
						["model"] = nil,
						["grip"] = nil,
						["handle"] = nil,
						["pivotRel"] = nil,
						["scaleNow"] = 1,
						["flash"] = nil,
						["ice"] = nil,
						["zparts"] = nil,
						["walker"] = nil,
						["shards"] = nil,
						["id"] = v_u_199.id,
						["kind"] = v_u_199.kind,
						["model"] = v216,
						["grip"] = v201,
						["handle"] = v217,
						["pivotRel"] = v219,
						["flash"] = v_u_199.kind == "flash",
						["ice"] = v_u_199.kind == "ice",
						["zparts"] = v_u_202,
						["walker"] = v_u_203
					}
					local v222
					if v_u_199.kind == "ice" then
						v222 = v216:GetChildren()
					else
						v222 = nil
					end
					v221.shards = v222
					table.insert(v220, v221)
				end
			end
		end
	end
	function v184.update(p223, p224) -- name: update
		-- upvalues: (ref) v_u_186, (ref) v_u_185, (copy) p_u_183, (ref) v_u_1, (ref) v_u_8, (ref) v_u_14
		if v_u_186 and (type(p223) == "table" and type(p224) == "table") then
			for _, v_u_225 in v_u_185 do
				local v_u_226 = nil
				for _, v227 in p223 do
					if v227.id ~= v_u_225.id then
						continue
					end
					v_u_226 = v227
				end
				if v_u_226 == nil then
					break
				end
				local v228 = p224[v_u_226.at] or p224.World
				if v_u_226.on and (v228 ~= nil and (not v_u_225.flash or v_u_226.k >= 0.02)) then
					if v_u_225.model.Parent == nil then
						v_u_225.model.Parent = p_u_183.parent
					end
					local v229 = CFrame.new(v_u_226.pos[1], v_u_226.pos[2], v_u_226.pos[3]) * v_u_1.rotCF(v_u_226.rot)
					if v_u_226.at == "RightHand" or v_u_226.at == "LeftHand" then
						v229 = v_u_1.holdCF(v_u_8(p_u_183), v_u_226.kind, v_u_226.grip, v_u_226.at == "LeftHand" and "Left" or "Right") * v229
					end
					if v_u_225.walker then
						local v230 = v_u_225.walker
						local v231 = v_u_14(p_u_183)
						if v231 ~= nil then
							local v232 = v231.pose(v231.clockOf(v_u_226.k))
							for v233, v234 in v230.motors do
								v234.Transform = v_u_1.jointCF(v233, v232, v230.hip, v230.lie, v230.scale)
							end
						end
						v_u_225.model:PivotTo(v228 * v229 * CFrame.new(0, v230.rootH, 0) * v230.pivotRel)
					elseif v_u_225.zparts then
						local v235 = v_u_14(p_u_183)
						local v236
						if v235 == nil then
							v236 = nil
						else
							v236 = v235.pose(v235.clockOf(v_u_226.k))
						end
						local v237
						if v236 == nil then
							v237 = v228 * v229
						else
							v237 = v228 * v229 * v_u_1.blockCF(v236)
						end
						local v238 = v236 == nil and 0 or v236.snap
						local v239 = v_u_1.zombieHeadCF(v238)
						local v240 = (v238 - 0.35) / 0.65
						local v241 = math.clamp(v240, 0, 1)
						for _, v242 in v_u_225.zparts do
							local v243 = v242.part
							local v244
							if v242.head then
								v244 = v237 * v239 * v242.rest
							else
								v244 = v237 * v242.rest
							end
							v243.CFrame = v244
							if not v242.skin then
								continue
							end
							v242.part.Color = v242.color:Lerp(v_u_1.ZOMBIE.hot, v241)
							local v245 = v242.part
							local v246
							if v241 > 0.5 then
								v246 = Enum.Material.Neon
							else
								v246 = v242.material
							end
							v245.Material = v246
						end
					elseif v_u_225.ice then
						local v247 = v228 * v229
						for _, v248 in v_u_225.model:GetChildren() do
							local v249 = string.match
							local v250 = v248.Name
							local v251 = tonumber(v249(v250, "^Shard(%d+)$"))
							if v251 then
								local v252 = v_u_1.iceShards()[v251]
								local v253, v254 = v_u_1.iceShardCF(v252, v_u_226.k)
								v248.Size = v254
								v248.CFrame = v247 * v253
							else
								v248.CFrame = v247
							end
						end
					else
						if v_u_225.flash then
							local v255 = v_u_226.k
							local v_u_256 = math.max(0.05, v255)
							local v257 = v_u_256 - v_u_225.scaleNow
							if math.abs(v257) > 0.001 then
								pcall(function()
									-- upvalues: (copy) v_u_225, (copy) v_u_256, (ref) v_u_226
									local v258 = v_u_225.model
									local v259 = v_u_256
									local v260 = v_u_226.scale
									v258:ScaleTo(v259 * (type(v260) ~= "number" and 1 or v_u_226.scale))
								end)
								v_u_225.scaleNow = v_u_256
							end
						end
						local v261 = v228 * v229 * v_u_225.grip:Inverse()
						v_u_225.model:PivotTo(v261 * v_u_225.pivotRel)
					end
				else
					v_u_225.model.Parent = nil
				end
			end
		end
	end
	function v184.count() -- name: count
		-- upvalues: (ref) v_u_185
		return #v_u_185
	end
	function v184.destroy() -- name: destroy
		-- upvalues: (ref) v_u_186, (copy) v_u_188
		v_u_186 = false
		v_u_188()
	end
	return v184
end
return v_u_1