-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreGive

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("MarketplaceService")
local v_u_3 = {
	["DONATE_FAILED"] = "The donate page could not be loaded. Close the menu and open it again.",
	["PAID_TEXT"] = "Payment received. Sending your gift...",
	["SLOW_TEXT"] = "This takes longer than usual. Your gift is on its way, you do not need to pay again."
}
local v_u_4 = utf8.char(57346)
function v_u_3.new(p_u_5, p_u_6) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2
	local v_u_7 = p_u_5.ui
	local v_u_8 = p_u_5.theme
	local v_u_9 = v_u_8.color
	local v_u_10 = p_u_5.kit
	local v_u_11 = v_u_1.LocalPlayer
	local v_u_12 = {}
	local v_u_13 = true
	local v_u_14 = nil
	local v_u_15 = false
	local v_u_16 = 0
	local v_u_17 = nil
	local function v_u_19(p18) -- name: richAmount
		-- upvalues: (ref) v_u_4, (copy) v_u_7
		return not p18 and "..." or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_4, v_u_7.commas(p18))
	end
	local function v_u_26(p20, p21, p22, p23, p24) -- name: avatar
		-- upvalues: (copy) v_u_7, (copy) v_u_9
		local v25 = v_u_7.new("ImageLabel", {
			["Name"] = "Avatar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Image"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["BackgroundColor3"] = v_u_9.raised,
			["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%d&w=%d&h=%d"):format(p21, p24 or 48, p24 or 48),
			["Size"] = UDim2.fromOffset(p22, p22),
			["Position"] = p23 or UDim2.new()
		}, p20)
		v_u_7.corner(v25, p22)
		return v25
	end
	local function v_u_67(p27, p28, p29) -- name: boardPanel
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) p_u_5, (copy) v_u_8, (copy) v_u_19, (copy) v_u_11, (copy) v_u_26, (ref) v_u_4
		local v_u_30 = v_u_7.new("Frame", {
			["Name"] = "Board",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_9.raised,
			["Size"] = UDim2.fromOffset(p28, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p27)
		v_u_7.stroke(v_u_30, v_u_9.lineStrong, 1, 0.3)
		v_u_7.pad(v_u_30, {
			16,
			16,
			16,
			16
		})
		v_u_7.layout(v_u_30, "v", 8)
		v_u_7.label({
			["parent"] = nil,
			["text"] = "TOP DONORS",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v_u_30,
			["color"] = v_u_9.accent,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		v_u_7.label({
			["parent"] = nil,
			["text"] = "The ten most generous supporters. Anyone who donates anonymously is not listed.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v_u_30,
			["color"] = v_u_9.text2
		})
		local function v40()
			-- upvalues: (ref) p_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (copy) v_u_30, (ref) v_u_19
			if p_u_5.cctx.config.flag("RankTitles") ~= false then
				local v31 = p_u_5.cctx.shared.TitleRarity
				local v32 = v31.namesFrom(p_u_5.cctx.shared)
				local v33 = p_u_5.cctx.config.flag("TitleRarity") == false and 0 or v31.rarityOf("top_supporter")
				local v34
				if v33 > 0 then
					v34 = v31.textColor(v33, v_u_8)
				else
					v34 = v_u_9.accent
				end
				local v35 = v_u_7.new
				local v36 = "Frame"
				local v37 = {
					["Name"] = "SupporterTitle",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.85,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 3
				}
				local v38
				if v33 > 0 then
					v38 = v31.color(v33, v_u_8)
				else
					v38 = v_u_9.accentDeep
				end
				v37.BackgroundColor3 = v38
				v37.Size = UDim2.new(1, 0, 0, 0)
				v37.AutomaticSize = Enum.AutomaticSize.Y
				local v39 = v35(v36, v37, v_u_30)
				v_u_7.stroke(v39, v34, 1, 0.4)
				v_u_7.pad(v39, {
					10,
					12,
					12,
					12
				})
				v_u_7.layout(v39, "v", 4)
				v_u_7.label({
					["parent"] = nil,
					["name"] = "Line",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 1,
					["parent"] = v39,
					["text"] = ("The number one supporter earns the title %s"):format(v32.top_supporter or "TOP SUPPORTER"),
					["color"] = v34
				})
				v_u_7.label({
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v39,
					["text"] = ("Needs %s donated in total. Anonymous donors count too and stay off this list."):format(v_u_19(v31.RULES.supporterMinRobux)),
					["color"] = v_u_9.text2
				}).RichText = true
			end
		end
		pcall(v40)
		local v41
		if type(p29) == "table" then
			local v42 = p29.top
			v41 = type(v42) == "table" and (p29.top or {}) or {}
		else
			v41 = {}
		end
		if #v41 ~= 0 then
			for v43, v44 in v41 do
				local v45 = v44.userId
				local v46 = tonumber(v45) == v_u_11.UserId
				local v47 = v_u_7.new
				local v48 = "Frame"
				local v49 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Row" .. v43
				}
				local v50
				if v46 then
					v50 = v_u_9.accentDeep
				else
					v50 = v_u_9.bg
				end
				v49.BackgroundColor3 = v50
				v49.BackgroundTransparency = v46 and 0.2 or 0.5
				v49.Size = UDim2.new(1, 0, 0, 44)
				v49.LayoutOrder = 4 + v43
				local v51 = v47(v48, v49, v_u_30)
				local v52 = v_u_7.label
				local v53 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v51
				}
				local v54 = v44.rank or v43
				v53.text = "#" .. tostring(v54)
				local v55
				if v43 == 1 then
					v55 = v_u_9.accent
				else
					v55 = v_u_9.text2
				end
				v53.color = v55
				v53.size = UDim2.fromOffset(34, 44)
				v53.position = UDim2.fromOffset(8, 0)
				v52(v53)
				local v56 = v_u_26
				local v57 = v44.userId
				v56(v51, tonumber(v57) or 0, 32, UDim2.fromOffset(44, 6))
				local v58 = v_u_7.label
				local v59 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["size"] = nil,
					["position"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v51
				}
				local v60 = v44.name or "?"
				v59.text = tostring(v60)
				local v61
				if v46 then
					v61 = v_u_9.accent
				else
					v61 = v_u_9.text
				end
				v59.color = v61
				v59.size = UDim2.new(1, -230, 1, 0)
				v59.position = UDim2.fromOffset(86, 0)
				v58(v59)
				local v62 = v_u_7.label
				local v63 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["track"] = false,
					["parent"] = v51
				}
				local v64 = v44.value
				local v65 = tonumber(v64)
				v63.text = not v65 and "..." or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_4, v_u_7.commas(v65))
				v63.color = v_u_9.text
				v63.size = UDim2.fromOffset(130, 44)
				v63.position = UDim2.new(1, -8, 0, 0)
				v63.anchor = Vector2.new(1, 0)
				v62(v63).RichText = true
			end
			return v_u_30
		end
		local v66 = type(p29) == "table" and p29.topOk == false and "The board could not be loaded right now." or "No public donors yet. Be the first."
		v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 4,
			["parent"] = v_u_30,
			["text"] = v66,
			["color"] = v_u_9.muted
		})
		return v_u_30
	end
	local function v_u_96(p68, p_u_69, p70, p71) -- name: tierButton
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (ref) v_u_4, (copy) p_u_6, (ref) v_u_13, (copy) p_u_5
		local v72 = p_u_69.enabled == true
		local v73 = v_u_7.new
		local v74 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["Selectable"] = true
		}
		local v75 = p_u_69.key
		v74.Name = tostring(v75)
		v74.BackgroundColor3 = v_u_9.raised
		v74.LayoutOrder = p71
		v74.Size = UDim2.fromOffset(p70, 64)
		local v76 = v73("TextButton", v74, p68)
		v76.SelectionImageObject = v_u_7.selectionImage()
		local v77 = v_u_7.stroke
		local v78
		if v72 then
			v78 = v_u_9.lineStrong
		else
			v78 = v_u_9.line
		end
		local v_u_79 = v77(v76, v78)
		local v80 = v_u_7.icon
		local v81 = "heart"
		local v82 = {
			["size"] = 18,
			["color"] = nil
		}
		local v83
		if v72 then
			v83 = v_u_9.accent
		else
			v83 = v_u_9.muted
		end
		v82.color = v83
		local v84 = v80(v81, v82)
		v84.Position = UDim2.fromOffset(14, 23)
		v84.Parent = v76
		local v85 = v_u_7.label
		local v86 = {
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoL",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["track"] = false,
			["parent"] = v76
		}
		local v87
		if v72 then
			v87 = v_u_9.text
		else
			v87 = v_u_9.muted
		end
		v86.color = v87
		v86.size = UDim2.new(1, -70, 1, 0)
		v86.position = UDim2.fromOffset(44, 0)
		local v_u_88 = v85(v86)
		v_u_88.RichText = true
		v_u_88.TextYAlignment = Enum.TextYAlignment.Center
		local v89
		if v72 then
			local v90 = p_u_69.price
			local v91 = tonumber(v90)
			if not v91 then
				local v92 = p_u_69.robux
				v91 = tonumber(v92)
			end
			v89 = not v91 and "..." or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_4, v_u_7.commas(v91))
		else
			v89 = "Coming soon"
		end
		v_u_88.Text = v89
		if v72 then
			task.spawn(function()
				-- upvalues: (ref) p_u_6, (copy) p_u_69, (ref) v_u_13, (copy) v_u_88, (ref) v_u_4, (ref) v_u_7
				local v93 = p_u_6.clientPrice
				local v94 = p_u_69.robloxId
				local v95 = v93(tonumber(v94) or 0, "product")
				if v_u_13 and (v95 and v_u_88.Parent) then
					v_u_88.Text = not v95 and "..." or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_4, v_u_7.commas(v95))
				end
			end)
			v76.MouseButton1Click:Connect(function()
				-- upvalues: (ref) p_u_5, (copy) p_u_69
				p_u_5.op({
					["op"] = "donateBuy",
					["tier"] = nil,
					["tier"] = p_u_69.key
				})
			end)
			v76.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_79, (ref) v_u_9
				v_u_79.Color = v_u_9.accent
			end)
			v76.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_79, (ref) v_u_9
				v_u_79.Color = v_u_9.lineStrong
			end)
		end
		return v76
	end
	local function v_u_124(p97, p98) -- name: render
		-- upvalues: (copy) v_u_10, (ref) v_u_14, (copy) p_u_5, (copy) v_u_7, (copy) v_u_9, (ref) v_u_15, (ref) v_u_3, (copy) v_u_96, (copy) v_u_19, (copy) v_u_67
		v_u_10.clear(p97)
		local v99 = v_u_14
		local v100 = not p_u_5.compact()
		if v100 then
			v100 = p98 >= 900
		end
		local v101
		if v100 then
			local v102 = p98 * 0.58
			v101 = math.floor(v102)
		else
			v101 = p98
		end
		if v100 then
			p98 = p98 - v101 - 16
		end
		local v103 = v_u_7.new("Frame", {
			["Name"] = "DonateRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 10),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p97)
		v_u_7.layout(v103, v100 and "h" or "v", 16)
		local v104 = v103:FindFirstChildOfClass("UIListLayout")
		if v104 then
			v104.VerticalAlignment = Enum.VerticalAlignment.Top
		end
		local v105 = v_u_7.new("Frame", {
			["Name"] = "Left",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.fromOffset(v101, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v103)
		v_u_7.layout(v105, "v", 12)
		local v106 = v_u_7.new("Frame", {
			["Name"] = "Intro",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["BackgroundColor3"] = v_u_9.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v105)
		v_u_7.stroke(v106, v_u_9.accent, 1, 0.3)
		v_u_7.pad(v106, {
			18,
			18,
			18,
			18
		})
		v_u_7.layout(v106, "v", 8)
		v_u_7.label({
			["parent"] = nil,
			["text"] = "SUPPORT HUSH",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v106,
			["color"] = v_u_9.accent,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		v_u_7.label({
			["parent"] = nil,
			["text"] = "Thank you for any help",
			["style"] = "h1",
			["order"] = 2,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v106,
			["size"] = UDim2.new(1, 0, 0, 40)
		})
		v_u_7.label({
			["parent"] = nil,
			["text"] = "HUSH is made by a very small team, and we are grateful for every bit of help. Everything you give is reinvested into the game: better assets, new maps and a lot more polish. Donating is completely optional and gives no advantage in the game.",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v106,
			["color"] = v_u_9.text2
		})
		v_u_7.label({
			["parent"] = nil,
			["text"] = "CHOOSE AN AMOUNT",
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["order"] = 2,
			["parent"] = v105,
			["color"] = v_u_9.text2,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		local v107 = v_u_7.new("Frame", {
			["Name"] = "Tiers",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 3,
			["Size"] = UDim2.new(1, 0, 0, 10),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v105)
		local v108 = v101 >= 520 and 2 or 1
		local v109 = (v101 - (v108 - 1) * 10) / v108
		local v110 = math.floor(v109)
		v_u_7.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(v110, 64),
			["CellPadding"] = UDim2.fromOffset(10, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v107)
		if type(v99) == "table" then
			local v111 = v99.tiers
			if type(v111) == "table" then
				for v112, v113 in v99.tiers do
					v_u_96(v107, v113, v110, v112)
				end
				local v114 = v99.me or {}
				local v115 = v_u_7.new("Frame", {
					["Name"] = "Options",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 4,
					["BackgroundColor3"] = v_u_9.raised,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v105)
				v_u_7.stroke(v115, v_u_9.line)
				v_u_7.pad(v115, {
					12,
					14,
					14,
					14
				})
				v_u_7.layout(v115, "v", 4)
				local _, _ = v_u_7.toggle({
					["parent"] = nil,
					["name"] = "Anonymous",
					["label"] = "Donate anonymously (no leaderboard entry)",
					["value"] = nil,
					["width"] = nil,
					["order"] = 1,
					["onChange"] = nil,
					["parent"] = v115,
					["value"] = v114.anon == true,
					["width"] = v101 - 32,
					["onChange"] = function(p116) -- name: onChange
						-- upvalues: (ref) v_u_14, (ref) p_u_5
						local v117 = v_u_14
						if type(v117) == "table" then
							local v118 = v_u_14.me
							if type(v118) == "table" then
								v_u_14.me.anon = p116
							end
						end
						p_u_5.op({
							["op"] = "donateAnon",
							["value"] = nil,
							["value"] = p116
						})
					end
				})
				v_u_7.label({
					["parent"] = nil,
					["text"] = "On: you are not shown on the board (an existing entry is removed), and donations made while this is on are never listed. Turn it off to be listed with your public total.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v115,
					["color"] = v_u_9.text2
				})
				local v119 = v114.total
				if (tonumber(v119) or 0) > 0 then
					local v120 = v_u_7.label
					local v121 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 3,
						["parent"] = v115
					}
					local v122 = v_u_19
					local v123 = v114.total
					v121.text = ("You have donated %s so far. Thank you!"):format(v122((tonumber(v123))))
					v121.color = v_u_9.accent
					v120(v121).RichText = true
				end
				v_u_7.label({
					["parent"] = nil,
					["text"] = "Only donate if you want to. Donations can\'t be refunded and give no items. The purchase itself goes through Roblox.",
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 5,
					["parent"] = v105,
					["color"] = v_u_9.muted
				})
				v_u_67(v103, p98, v99)
			else
				v_u_10.empty(v105, not v_u_15 and "Loading..." or v_u_3.DONATE_FAILED)
				v_u_67(v103, p98, v99)
			end
		else
			v_u_10.empty(v105, not v_u_15 and "Loading..." or v_u_3.DONATE_FAILED)
			v_u_67(v103, p98, v99)
			return
		end
	end
	function v_u_12.showDonate(p_u_125, p_u_126) -- name: showDonate
		-- upvalues: (ref) v_u_16, (ref) v_u_15, (copy) v_u_124, (copy) p_u_5, (ref) v_u_13, (ref) v_u_14
		v_u_16 = v_u_16 + 1
		local v_u_127 = v_u_16
		v_u_15 = false
		v_u_124(p_u_125, p_u_126)
		task.spawn(function()
			-- upvalues: (ref) p_u_5, (ref) v_u_13, (copy) v_u_127, (ref) v_u_16, (copy) p_u_125, (ref) v_u_15, (ref) v_u_14, (ref) v_u_124, (copy) p_u_126
			local v128 = p_u_5.fetch("donate", nil, 20)
			if v_u_13 and (v_u_127 == v_u_16 and p_u_125.Parent) then
				v_u_15 = v128 == nil
				v_u_14 = v128
				v_u_124(p_u_125, p_u_126)
			end
		end)
	end
	function v_u_12.invalidate() -- name: invalidate
		-- upvalues: (copy) p_u_5, (ref) v_u_14
		p_u_5.invalidate("donate")
		v_u_14 = nil
	end
	function v_u_12.openGift(p_u_129) -- name: openGift
		-- upvalues: (ref) v_u_17, (copy) p_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_26, (copy) p_u_6, (ref) v_u_13, (copy) v_u_10, (ref) v_u_1, (copy) v_u_11, (ref) v_u_2, (ref) v_u_3
		if v_u_17 then
			return
		elseif type(p_u_129) == "table" and p_u_129.giftable then
			local v_u_130 = nil
			local v_u_131 = false
			local v_u_132 = false
			local v_u_133 = false
			local v_u_134 = nil
			local v_u_135 = nil
			local v_u_136 = nil
			local v_u_137 = nil
			local v_u_138 = nil
			local v139 = p_u_129.giftRobloxId
			local v_u_140 = tonumber(v139) or 0
			local v_u_141 = nil
			local v_u_142 = nil
			local function v143()
				-- upvalues: (ref) v_u_141, (ref) p_u_5
				v_u_141 = p_u_5.cctx.shared.GiveWho
			end
			pcall(v143)
			local function v144()
				-- upvalues: (ref) v_u_142, (ref) p_u_5
				v_u_142 = p_u_5.cctx.lib.MenuStoreGiveLayout
			end
			pcall(v144)
			local v_u_145 = 552
			local function v147()
				-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_145
				local v146 = v_u_7.modalLimits(600, v_u_8.refSize(), v_u_7.safeInsets()) - 2 * v_u_8.space.l
				v_u_145 = math.floor(v146)
			end
			pcall(v147)
			local v_u_148
			if v_u_142 then
				v_u_148 = v_u_142.rows(v_u_8.touch)
			else
				v_u_148 = {
					["who"] = v_u_8.touch(40),
					["friend"] = v_u_8.touch(42),
					["send"] = v_u_8.touch(46),
					["ctl"] = v_u_8.touch(38)
				}
			end
			local v_u_149 = nil
			local v_u_150 = {}
			local v_u_151 = false
			local v_u_152 = v_u_8.isPhone()
			local function v_u_155() -- name: clearCard
				-- upvalues: (ref) v_u_151, (ref) v_u_149, (ref) v_u_150
				v_u_151 = false
				if v_u_149 and v_u_149.Parent then
					v_u_149.Visible = false
					v_u_149.Size = UDim2.new(1, 0, 0, 0)
					for _, v153 in v_u_149:GetChildren() do
						v153:Destroy()
					end
				end
				for _, v154 in v_u_150 do
					if not v154.Parent then
						continue
					end
					v154.Visible = true
				end
			end
			local function v_u_177(p156) -- name: showCard
				-- upvalues: (ref) v_u_141, (ref) v_u_142, (ref) v_u_149, (copy) v_u_155, (ref) v_u_145, (ref) v_u_7, (ref) v_u_9, (ref) v_u_26, (ref) v_u_151, (copy) v_u_152, (ref) v_u_150
				if not (v_u_141 and (v_u_142 and (v_u_149 and v_u_149.Parent))) then
					return false
				end
				v_u_155()
				local v157 = v_u_141.card(p156)
				local v158 = v_u_142.card(v_u_145, {
					["warn"] = v157.warn,
					["hint"] = v157.hint
				})
				local v159 = v_u_149
				v159.Size = UDim2.new(1, 0, 0, v158.h)
				v159.Visible = true
				local v160 = v_u_7.new("Frame", {
					["Name"] = "Card",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_9.raised,
					["Size"] = UDim2.fromScale(1, 1)
				}, v159)
				local v161 = v_u_7.stroke
				local v162
				if v157.warn then
					v162 = v_u_9.danger
				elseif v157.hint then
					v162 = v_u_9.accent
				else
					v162 = v_u_9.lineStrong
				end
				v161(v160, v162, 1, (v157.warn or v157.hint) and 0.2 or 0)
				local v163 = v_u_26
				local v164 = p156.userId
				v163(v160, tonumber(v164) or 0, v158.avatar.w, UDim2.fromOffset(v158.avatar.x, v158.avatar.y), 150)
				local v165 = v_u_7.label
				local v166 = {
					["parent"] = nil,
					["name"] = "DisplayName",
					["text"] = nil,
					["style"] = "bodyStrong",
					["textSize"] = 20,
					["fit"] = true,
					["track"] = false,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v160
				}
				local v167 = v157.display
				v166.text = tostring(v167)
				v166.size = UDim2.new(1, -(v158.name.x + v_u_142.PAD), 0, v158.name.h)
				v166.position = UDim2.fromOffset(v158.name.x, v158.name.y)
				v165(v166)
				local v168 = v_u_7.label
				local v169 = {
					["parent"] = nil,
					["name"] = "Username",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["track"] = false,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v160
				}
				local v170 = v157.username
				v169.text = "@" .. tostring(v170)
				v169.color = v_u_9.text2
				v169.size = UDim2.new(1, -(v158.user.x + v_u_142.PAD), 0, v158.user.h)
				v169.position = UDim2.fromOffset(v158.user.x, v158.user.y)
				v168(v169)
				for _, v171 in {
					{ "warn", "Warning", v_u_9.danger },
					{ "hint", "Hint", v_u_9.accent }
				} do
					local v172 = v157[v171[1]]
					if not v172 then
						continue
					end
					local v173 = v158[v171[1]]
					local v174 = v158[v171[1] .. "Text"]
					local v175 = v_u_7.new("Frame", {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.85,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["Position"] = nil,
						["Name"] = v171[2],
						["BackgroundColor3"] = v171[3],
						["Size"] = UDim2.new(1, -2 * v_u_142.PAD, 0, v173.h),
						["Position"] = UDim2.fromOffset(v173.x, v173.y)
					}, v160)
					v_u_7.stroke(v175, v171[3], 1, 0.35)
					v_u_7.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["wrap"] = true,
						["valign"] = "top",
						["track"] = false,
						["size"] = nil,
						["position"] = nil,
						["parent"] = v175,
						["text"] = tostring(v172),
						["color"] = v171[3],
						["size"] = UDim2.new(1, -2 * v_u_142.BOX_PAD_X, 0, v174.h),
						["position"] = UDim2.fromOffset(v_u_142.BOX_PAD_X, v_u_142.BOX_PAD_Y)
					})
				end
				v_u_151 = v157.warn ~= nil and true or v157.hint ~= nil
				if v_u_152 then
					for _, v176 in v_u_150 do
						v176.Visible = false
					end
				end
				return true
			end
			local function v_u_180() -- name: sendLabel
				-- upvalues: (ref) v_u_135, (ref) v_u_130, (ref) v_u_151, (ref) p_u_6, (ref) v_u_138
				if v_u_135 then
					local v178
					if v_u_130 then
						local v179 = v_u_130.credits
						v178 = tonumber(v179) or 0
					else
						v178 = 0
					end
					if v178 > 0 then
						v_u_135.setText(v_u_151 and "Send anyway with your gift credit" or "Send with your gift credit")
						v_u_135.label.RichText = false
					else
						v_u_135.label.RichText = true
						v_u_135.label.Text = ("%s  %s"):format(v_u_151 and "SEND ANYWAY" or "SEND GIFT", p_u_6.priceRich(v_u_138))
					end
				else
					return
				end
			end
			local v_u_181 = false
			local function v_u_184(p182) -- name: lockSend
				-- upvalues: (ref) v_u_135, (ref) v_u_181
				if v_u_135 then
					local v183 = p182 == "owned" and "Already owned" or (p182 == "waiting" and "Gift already waiting" or (p182 == "version" and "Check again" or (p182 == "unlockfull" and "Nothing left to unlock" or nil)))
					if v183 then
						v_u_135.label.RichText = false
						v_u_135.setText(v183)
						v_u_181 = true
					end
					v_u_135.setEnabled(false)
				end
			end
			local function v_u_204(p_u_185) -- name: check
				-- upvalues: (ref) v_u_131, (ref) v_u_132, (ref) v_u_130, (copy) v_u_155, (ref) v_u_135, (ref) v_u_181, (copy) v_u_180, (ref) v_u_9, (ref) v_u_134, (ref) p_u_5, (copy) p_u_129, (ref) v_u_13, (ref) v_u_133, (copy) v_u_177, (ref) v_u_141, (ref) v_u_151, (ref) v_u_140, (ref) v_u_138, (ref) p_u_6, (copy) v_u_184
				if not (v_u_131 or v_u_132) then
					v_u_131 = true
					v_u_130 = nil
					v_u_155()
					if v_u_135 then
						v_u_135.setEnabled(false)
					end
					if v_u_181 then
						v_u_181 = false
						v_u_180()
					end
					local v186 = v_u_9.text2
					if v_u_134 and v_u_134.Parent then
						v_u_134.Text = "Checking..."
						v_u_134.TextColor3 = v186 or v_u_9.text2
					end
					task.spawn(function()
						-- upvalues: (ref) p_u_5, (ref) p_u_129, (copy) p_u_185, (ref) v_u_131, (ref) v_u_13, (ref) v_u_133, (ref) v_u_9, (ref) v_u_134, (ref) v_u_130, (ref) v_u_177, (ref) v_u_141, (ref) v_u_151, (ref) v_u_140, (ref) v_u_138, (ref) p_u_6, (ref) v_u_180, (ref) v_u_135, (ref) v_u_184
						local v_u_187 = p_u_5.fetch("giftCheck", {
							["id"] = p_u_129.id,
							["user"] = p_u_185
						}, 0)
						v_u_131 = false
						if v_u_13 and not v_u_133 then
							if type(v_u_187) == "table" and v_u_187.error == nil then
								if v_u_187.ok == true then
									v_u_130 = v_u_187
									local v188 = v_u_177(v_u_187)
									local v189
									if v188 then
										v189 = v_u_141.REVIEW
									else
										local v190 = p_u_129.name
										local v191 = tostring(v190)
										local v192 = v_u_187.display or v_u_187.name
										local v193 = tostring(v192)
										local v194 = v_u_187.name
										v189 = ("Gift %s to %s (@%s)."):format(v191, v193, (tostring(v194)))
									end
									local v195 = v_u_187.note
									if type(v195) == "string" and v_u_187.note ~= "" then
										if v188 then
											v189 = v_u_187.note .. " " .. v189
										else
											v189 = v189 .. " " .. v_u_187.note
										end
									end
									local v196
									if v188 and v_u_151 then
										v196 = v_u_9.text2
									else
										v196 = v_u_9.success
									end
									if v_u_134 and v_u_134.Parent then
										v_u_134.Text = v189
										v_u_134.TextColor3 = v196 or v_u_9.text2
									end
									if v_u_187.pack ~= nil then
										local v197 = v_u_187.giftRobloxId
										v_u_140 = tonumber(v197) or 0
										local v198 = v_u_187.price
										v_u_138 = tonumber(v198)
										task.spawn(function()
											-- upvalues: (ref) p_u_6, (ref) v_u_140, (ref) v_u_133, (ref) v_u_130, (copy) v_u_187, (ref) v_u_138, (ref) v_u_180
											local v199 = p_u_6.clientPrice(v_u_140, "product")
											if v199 and (not v_u_133 and v_u_130 == v_u_187) then
												v_u_138 = v199
												v_u_180()
											end
										end)
									end
									v_u_180()
									if v_u_135 then
										v_u_135.setEnabled(true)
										return
									end
								else
									local v200 = v_u_187.msg or "That did not work."
									local v201 = tostring(v200)
									local v202 = v_u_9.danger
									if v_u_134 and v_u_134.Parent then
										v_u_134.Text = v201
										v_u_134.TextColor3 = v202 or v_u_9.text2
									end
									v_u_184(v_u_187.reason)
								end
							else
								local v203 = v_u_9.danger
								if v_u_134 and v_u_134.Parent then
									v_u_134.Text = "The server could not check that right now. Try again in a moment."
									v_u_134.TextColor3 = v203 or v_u_9.text2
								end
							end
						else
							return
						end
					end)
				end
			end
			local v_u_205 = false
			local v_u_206 = false
			local function v_u_211() -- name: send
				-- upvalues: (ref) v_u_130, (ref) v_u_132, (ref) v_u_135, (ref) v_u_9, (ref) v_u_134, (ref) p_u_5, (copy) p_u_129
				if v_u_130 and not v_u_132 then
					v_u_132 = true
					if v_u_135 then
						v_u_135.setEnabled(false)
					end
					local v207 = v_u_9.text2
					if v_u_134 and v_u_134.Parent then
						v_u_134.Text = "Opening the purchase. Finish it in the Roblox window."
						v_u_134.TextColor3 = v207 or v_u_9.text2
					end
					local v208 = p_u_5.op
					local v209 = {
						["op"] = "giftBuy",
						["id"] = nil,
						["userId"] = nil,
						["useCredit"] = nil,
						["id"] = v_u_130.pack or p_u_129.id,
						["userId"] = v_u_130.userId
					}
					local v210 = v_u_130.credits
					v209.useCredit = (tonumber(v210) or 0) > 0
					v208(v209)
				end
			end
			local v212 = v_u_7.modal
			local v213 = {
				["title"] = nil,
				["width"] = 600,
				["body"] = nil,
				["build"] = nil,
				["buttons"] = nil,
				["onClose"] = nil
			}
			local v214 = p_u_129.name
			v213.title = "Gift " .. tostring(v214)
			local function v215()
				-- upvalues: (ref) p_u_5, (copy) p_u_129
				return p_u_5.cctx.shared.GiveRules.giftBody(p_u_129)
			end
			local v216, v_u_217 = pcall(v215)
			if v216 and type(v_u_217) == "string" then
				if p_u_129.pack then
					v_u_217 = v_u_217 .. " The five Halloween crates and five Special Keys come only when the player is on this server and both of you are allowed to receive paid random items. In some countries that is not allowed, so a gift to such a player comes without crates and keys. You see which version it is before you pay."
				end
				if p_u_129.art == "unlock" then
					local v218 = p_u_129.grants
					if type(v218) == "table" then
						local function v219()
							-- upvalues: (ref) v_u_217, (ref) p_u_5, (copy) p_u_129
							v_u_217 = v_u_217 .. " " .. p_u_5.cctx.lib.UnlockChain.giftHint(p_u_129.grants.mapUnlock)
						end
						pcall(v219)
					end
				end
			else
				v_u_217 = "Send it to a friend or to any player. The price shown is your own Robux price."
			end
			v213.body = v_u_217
			function v213.build(p220) -- name: build
				-- upvalues: (ref) v_u_142, (ref) v_u_7, (copy) v_u_148, (copy) v_u_204, (ref) v_u_136, (ref) v_u_130, (ref) v_u_132, (copy) v_u_155, (ref) v_u_135, (ref) v_u_9, (ref) v_u_134, (ref) v_u_149, (copy) v_u_152, (ref) v_u_150, (ref) v_u_10, (ref) v_u_1, (ref) v_u_11, (ref) p_u_5, (ref) v_u_8, (ref) v_u_26, (ref) v_u_145, (copy) v_u_211, (copy) v_u_180
				local v221 = not v_u_142 and 130 or v_u_142.CHECK_W
				local v222 = not v_u_142 and 12 or v_u_142.WHO_GAP
				local v223 = v_u_7.new("Frame", {
					["Name"] = "Who",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, v_u_148.who)
				}, p220)
				local v225, v_u_226 = v_u_7.input({
					["parent"] = nil,
					["name"] = "Username",
					["placeholder"] = "Roblox username",
					["size"] = nil,
					["maxLength"] = 21,
					["onSubmit"] = nil,
					["parent"] = v223,
					["size"] = UDim2.new(1, -(v221 + v222), 0, v_u_148.who),
					["onSubmit"] = function(p224) -- name: onSubmit
						-- upvalues: (ref) v_u_204
						v_u_204(p224)
					end
				})
				v225.Position = UDim2.fromOffset(0, 0)
				v_u_136 = v_u_226
				v_u_226:GetPropertyChangedSignal("Text"):Connect(function()
					-- upvalues: (ref) v_u_130, (ref) v_u_132, (copy) v_u_226, (ref) v_u_155, (ref) v_u_135, (ref) v_u_9, (ref) v_u_134
					if v_u_130 and not v_u_132 then
						local v227 = string.lower((string.gsub(v_u_226.Text, "^%s*@?", "")))
						local v228 = string.lower
						local v229 = v_u_130.name
						if v227 ~= v228((tostring(v229))) then
							v_u_130 = nil
							v_u_155()
							if v_u_135 then
								v_u_135.setEnabled(false)
							end
							local v230 = v_u_9.text2
							if v_u_134 and v_u_134.Parent then
								v_u_134.Text = "Press Check to look up the new name."
								v_u_134.TextColor3 = v230 or v_u_9.text2
							end
						end
					end
				end)
				v_u_7.button({
					["parent"] = nil,
					["text"] = "Check",
					["kind"] = "secondary",
					["size"] = nil,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v223,
					["size"] = UDim2.fromOffset(v221, v_u_148.who),
					["position"] = UDim2.new(1, -v221, 0, 0),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_204, (ref) v_u_136
						v_u_204(not v_u_136 and "" or v_u_136.Text)
					end
				})
				v_u_149 = v_u_7.new("Frame", {
					["Name"] = "RecipientCard",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["Visible"] = false,
					["Size"] = UDim2.new(1, 0, 0, 0)
				}, p220)
				local v231 = v_u_7.label({
					["parent"] = nil,
					["text"] = "YOUR SQUAD AND FRIENDS",
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["order"] = nil,
					["parent"] = p220,
					["color"] = v_u_9.text2,
					["size"] = UDim2.new(1, 0, 0, 14),
					["order"] = v_u_152 and 5 or 3
				})
				local v_u_232 = v_u_7.list({
					["parent"] = nil,
					["name"] = "Friends",
					["size"] = nil,
					["gap"] = 4,
					["order"] = nil,
					["parent"] = p220,
					["size"] = UDim2.new(1, 0, 0, v_u_152 and 150 or 190),
					["order"] = v_u_152 and 6 or 4
				})
				v_u_150 = { v231, v_u_232 }
				local function v_u_234(p233)
					-- upvalues: (ref) v_u_136, (ref) v_u_204
					if v_u_136 then
						v_u_136.Text = p233
					end
					v_u_204(p233)
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_232, (ref) v_u_10, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) v_u_11, (ref) p_u_5, (ref) v_u_8, (ref) v_u_26, (copy) v_u_234
					local function v236(p235) -- name: say
						-- upvalues: (ref) v_u_232, (ref) v_u_10, (ref) v_u_7, (ref) v_u_9
						if v_u_232.Parent then
							v_u_10.clear(v_u_232)
							v_u_7.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["parent"] = v_u_232,
								["text"] = p235,
								["color"] = v_u_9.muted
							})
						end
					end
					local v237 = {}
					local function v238()
						-- upvalues: (ref) v_u_1, (ref) v_u_11
						return v_u_1:GetFriendsAsync(v_u_11.UserId)
					end
					local v239, v_u_240 = pcall(v238)
					local v241
					if v239 and v_u_240 then
						v241 = true
						for _ = 1, 4 do
							local v242, v243 = pcall(function()
								-- upvalues: (copy) v_u_240
								return v_u_240:GetCurrentPage()
							end)
							if v242 and type(v243) == "table" then
								for _, v244 in v243 do
									table.insert(v237, v244)
								end
								if not v_u_240.IsFinished and pcall(function()
									-- upvalues: (copy) v_u_240
									v_u_240:AdvanceToNextPageAsync()
								end) then
									break
								end
							end
						end
					else
						v241 = false
					end
					local v_u_245 = {}
					local function v248()
						-- upvalues: (ref) p_u_5, (ref) v_u_245
						local v246 = p_u_5.myParty()
						if type(v246) == "table" then
							local v247 = v246.members
							if type(v247) == "table" then
								v_u_245 = v246.members
							end
						end
					end
					pcall(v248)
					local v_u_249 = nil
					local function v250()
						-- upvalues: (ref) v_u_249, (ref) p_u_5
						v_u_249 = p_u_5.cctx.shared.GiveRules
					end
					pcall(v250)
					local v251 = v_u_249 == nil and {} or v_u_249.pickerRows(v_u_245, v237, v_u_11.UserId, 120)
					if v_u_232.Parent then
						if #v251 == 0 then
							v236(v241 and "You have no friends on Roblox yet and nobody in your squad. Type a username above." or "Your friends could not be loaded. Type a username above.")
						else
							v_u_10.clear(v_u_232)
							for v252, v_u_253 in v251 do
								local v254 = v_u_7.new("TextButton", {
									["Name"] = nil,
									["Text"] = "",
									["AutoButtonColor"] = false,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = 0.2,
									["BorderSizePixel"] = 0,
									["Size"] = nil,
									["LayoutOrder"] = nil,
									["Selectable"] = true,
									["Name"] = "Friend" .. v252,
									["BackgroundColor3"] = v_u_9.raised,
									["Size"] = UDim2.new(1, -6, 0, v_u_8.touch(42)),
									["LayoutOrder"] = v252
								}, v_u_232)
								v254.SelectionImageObject = v_u_7.selectionImage()
								local v255 = v_u_26
								local v256 = v_u_253.userId
								v255(v254, tonumber(v256) or 0, 30, UDim2.fromOffset(8, 6))
								local v257 = v_u_7.label
								local v258 = {
									["parent"] = nil,
									["text"] = nil,
									["style"] = "bodyStrong",
									["size"] = nil,
									["position"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v254
								}
								local v259 = v_u_253.display
								v258.text = tostring(v259)
								v258.size = UDim2.new(1, -150, 0, 20)
								v258.position = UDim2.fromOffset(48, 2)
								v257(v258)
								local v260 = v_u_7.label
								local v261 = {
									["parent"] = nil,
									["text"] = nil,
									["style"] = "micro",
									["color"] = nil,
									["size"] = nil,
									["position"] = nil,
									["track"] = false,
									["parent"] = v254
								}
								local v262 = v_u_253.username
								v261.text = "@" .. tostring(v262)
								v261.color = v_u_9.text2
								v261.size = UDim2.new(1, -150, 0, 14)
								v261.position = UDim2.fromOffset(48, 22)
								v260(v261)
								if v_u_253.squad == true then
									v_u_7.badge("SQUAD", "accent", {
										["parent"] = nil,
										["anchor"] = nil,
										["position"] = nil,
										["height"] = 18,
										["parent"] = v254,
										["anchor"] = Vector2.new(1, 0.5),
										["position"] = UDim2.new(1, -8, 0.5, 0)
									})
								elseif v_u_253.online == true then
									v_u_7.badge("ONLINE", "success", {
										["parent"] = nil,
										["anchor"] = nil,
										["position"] = nil,
										["height"] = 18,
										["parent"] = v254,
										["anchor"] = Vector2.new(1, 0.5),
										["position"] = UDim2.new(1, -8, 0.5, 0)
									})
								end
								v254.MouseButton1Click:Connect(function()
									-- upvalues: (ref) v_u_234, (copy) v_u_253
									local v263 = v_u_234
									local v264 = v_u_253.username
									v263((tostring(v264)))
								end)
							end
						end
					else
						return
					end
				end)
				v_u_134 = v_u_7.label({
					["parent"] = nil,
					["text"] = "Choose a friend or type a username, then press Check.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = p220,
					["color"] = v_u_9.text2,
					["order"] = v_u_152 and 3 or 5
				})
				local v265 = not v_u_142 and 360 or v_u_142.send(v_u_145, v_u_148.send).w
				local _, v266 = v_u_7.button({
					["parent"] = nil,
					["text"] = "Send gift",
					["kind"] = "primary",
					["size"] = nil,
					["disabled"] = true,
					["order"] = nil,
					["onClick"] = nil,
					["parent"] = p220,
					["size"] = UDim2.fromOffset(v265, v_u_148.send),
					["order"] = v_u_152 and 4 or 6,
					["onClick"] = v_u_211
				})
				v_u_135 = v266
				v_u_180()
			end
			v213.buttons = {
				{
					["text"] = "Close",
					["kind"] = "close"
				}
			}
			function v213.onClose() -- name: onClose
				-- upvalues: (ref) v_u_133, (ref) v_u_17, (ref) v_u_137
				v_u_133 = true
				v_u_17 = nil
				if v_u_137 then
					v_u_137:Disconnect()
				end
			end
			local v_u_267 = v212(v213)
			task.spawn(function()
				-- upvalues: (ref) p_u_6, (copy) p_u_129, (ref) v_u_130, (ref) v_u_138, (ref) v_u_133, (copy) v_u_180
				local v268 = p_u_6.clientPrice
				local v269 = p_u_129.giftRobloxId
				local v270 = v268(tonumber(v269) or 0, "product")
				if v270 == nil and p_u_129.giftPreview == true then
					local v271 = p_u_129.giftSuggest
					v270 = tonumber(v271)
				end
				if v_u_130 == nil then
					v_u_138 = v270
				end
				if not v_u_133 then
					v_u_180()
				end
			end)
			local _ = v_u_2.PromptProductPurchaseFinished:Connect(function(_, p272, p273)
				-- upvalues: (ref) v_u_140, (ref) v_u_133, (ref) v_u_9, (ref) v_u_134, (ref) v_u_132, (ref) v_u_135, (ref) v_u_130, (ref) v_u_206, (ref) v_u_205, (ref) v_u_3
				if p273 or (v_u_140 <= 0 or (p272 ~= v_u_140 or v_u_133)) then
					if p273 and (v_u_140 > 0 and (p272 == v_u_140 and not (v_u_133 or v_u_206))) then
						v_u_205 = true
						local v274 = v_u_3.PAID_TEXT
						local v275 = v_u_9.text2
						if v_u_134 and v_u_134.Parent then
							v_u_134.Text = v274
							v_u_134.TextColor3 = v275 or v_u_9.text2
						end
						task.delay(15, function()
							-- upvalues: (ref) v_u_205, (ref) v_u_206, (ref) v_u_133, (ref) v_u_3, (ref) v_u_9, (ref) v_u_134
							if v_u_205 and not (v_u_206 or v_u_133) then
								local v276 = v_u_3.SLOW_TEXT
								local v277 = v_u_9.text2
								if v_u_134 and v_u_134.Parent then
									v_u_134.Text = v276
									v_u_134.TextColor3 = v277 or v_u_9.text2
								end
							end
						end)
					end
				else
					local v278 = v_u_9.text2
					if v_u_134 and v_u_134.Parent then
						v_u_134.Text = "The purchase was cancelled. Nothing was charged."
						v_u_134.TextColor3 = v278 or v_u_9.text2
					end
					v_u_132 = false
					if v_u_135 and v_u_130 then
						v_u_135.setEnabled(true)
						return
					end
				end
			end)
			v_u_17 = {
				["product"] = p_u_129,
				["modal"] = v_u_267,
				["onResult"] = function(p279) -- name: onResult
					-- upvalues: (ref) v_u_9, (ref) v_u_134, (ref) v_u_132, (ref) v_u_130, (copy) v_u_155, (copy) v_u_184, (ref) v_u_135, (ref) v_u_206, (ref) v_u_133, (copy) v_u_267
					local v280 = p279.op or ""
					local v281 = tostring(v280)
					if v281 == "giftBuy" then
						if p279.ok == false then
							local v282 = p279.msg or "That did not work."
							local v283 = tostring(v282)
							local v284 = v_u_9.danger
							if v_u_134 and v_u_134.Parent then
								v_u_134.Text = v283
								v_u_134.TextColor3 = v284 or v_u_9.text2
							end
							local v285 = p279.data
							local v286
							if type(v285) == "table" then
								v286 = p279.data.reason
							else
								v286 = nil
							end
							if v286 ~= nil then
								v_u_132 = false
								v_u_130 = nil
								v_u_155()
								v_u_184(v286)
								return
							end
							v_u_132 = false
							if v_u_135 and v_u_130 then
								v_u_135.setEnabled(true)
								return
							end
						else
							local v287 = p279.data
							if type(v287) == "table" and (p279.data.simulated == true and (p279.data.prompted ~= nil and not v_u_206)) then
								local v288 = v_u_9.text2
								if v_u_134 and v_u_134.Parent then
									v_u_134.Text = "Sending your gift..."
									v_u_134.TextColor3 = v288 or v_u_9.text2
									return
								end
							else
								local v289 = p279.data
								if type(v289) == "table" and p279.data.sent == true then
									v_u_206 = true
									local v290 = p279.msg or "Gift sent."
									local v291 = tostring(v290)
									local v292 = v_u_9.success
									if v_u_134 and v_u_134.Parent then
										v_u_134.Text = v291
										v_u_134.TextColor3 = v292 or v_u_9.text2
									end
									task.delay(1.4, function()
										-- upvalues: (ref) v_u_133, (ref) v_u_267
										if not v_u_133 and v_u_267 then
											v_u_267.close()
										end
									end)
									return
								end
							end
						end
						return
					elseif v281 == "storeGrant" and v_u_132 then
						local v293 = string.find
						local v294 = p279.msg or ""
						if not v293(tostring(v294), "^Gift sent") then
							local v295 = string.find
							local v296 = p279.msg or ""
							if not v295(tostring(v296), "^Your gift credit") then
								local v297 = string.find
								local v298 = p279.msg or ""
								if not v297(tostring(v298), "^The gift could not be sent") then
									return
								end
							end
						end
						v_u_206 = true
						local v299 = p279.msg or "Gift sent."
						local v300 = tostring(v299)
						local v301 = v_u_9.success
						if v_u_134 and v_u_134.Parent then
							v_u_134.Text = v300
							v_u_134.TextColor3 = v301 or v_u_9.text2
						end
						task.delay(1.6, function()
							-- upvalues: (ref) v_u_133, (ref) v_u_267
							if not v_u_133 and v_u_267 then
								v_u_267.close()
							end
						end)
					end
				end
			}
		end
	end
	function v_u_12.onResult(p302) -- name: onResult
		-- upvalues: (ref) v_u_17, (copy) v_u_12
		if type(p302) == "table" then
			if v_u_17 and v_u_17.onResult then
				v_u_17.onResult(p302)
			end
			local v303 = p302.op or ""
			local v304 = tostring(v303)
			if p302.ok ~= false and (v304 == "storeGrant" or (v304 == "donateBuy" or v304 == "donateAnon")) and v304 == "storeGrant" then
				v_u_12.invalidate()
			end
		end
	end
	function v_u_12.destroy() -- name: destroy
		-- upvalues: (ref) v_u_13, (ref) v_u_17
		v_u_13 = false
		if v_u_17 and v_u_17.modal then
			local v305 = v_u_17.modal.close
			pcall(v305)
		end
	end
	return v_u_12
end
return v_u_3