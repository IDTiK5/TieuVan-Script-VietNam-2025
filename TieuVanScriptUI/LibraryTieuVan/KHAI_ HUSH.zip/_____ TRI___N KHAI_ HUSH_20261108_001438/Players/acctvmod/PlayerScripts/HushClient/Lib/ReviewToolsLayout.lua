-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewToolsLayout

local v_u_46 = {
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["MARGIN"] = 10,
	["INFO_MIN"] = 200,
	["INFO_MAX"] = 300,
	["BTN_MIN"] = 84,
	["BAR_ROWS_MAX"] = 2,
	["SQUEEZE_MIN"] = 170,
	["ROSTER_COL_MIN"] = 170,
	["ROSTER_COLS_MAX"] = 3,
	["ROSTER_W_MAX"] = 520,
	["opts"] = function(p1, p2, p3, p4, p5, p6) -- name: opts
		local v7 = math.max(p1, 0.1)
		local v8
		if p2 then
			local v9 = 44 / v7
			local v10 = math.ceil(v9)
			v8 = math.max(36, v10)
		else
			local v11 = 30 / v7
			local v12 = math.ceil(v11)
			v8 = math.max(36, v12)
		end
		local v13
		if type(p4) == "number" and (p4 == p4 and p4 > 0) then
			local v14 = math.min(p4, 400)
			v13 = math.floor(v14)
		else
			v13 = 0
		end
		local v15
		if type(p5) == "number" and (p5 == p5 and p5 > 0) then
			local v16 = math.min(p5, 600)
			v15 = math.floor(v16)
		else
			v15 = 0
		end
		local v17
		if type(p6) == "number" and (p6 == p6 and p6 > 0) then
			local v18 = math.min(p6, 600)
			v17 = math.floor(v18)
		else
			v17 = 0
		end
		local v19 = {
			["scale"] = nil,
			["touch"] = nil,
			["phone"] = nil,
			["tap"] = nil,
			["pad"] = 8,
			["gap"] = 8,
			["top"] = nil,
			["cornerW"] = nil,
			["rightW"] = nil,
			["scale"] = v7,
			["touch"] = p2
		}
		if p3 == nil then
			p3 = p2
		end
		v19.phone = p3
		v19.tap = v8
		v19.top = v13
		v19.cornerW = v15
		v19.rightW = v17
		return v19
	end,
	["fs"] = function(p20, p21) -- name: fs
		if not p20.phone then
			return p21
		end
		local v22 = 11 / p20.scale
		local v23 = math.ceil(v22)
		return math.max(p21, v23)
	end,
	["textW"] = function(p24, p25, p26) -- name: textW
		-- upvalues: (copy) v_u_46
		local v27 = tostring(p24 or "")
		local v28 = (utf8.len(v27) or #v27) * p25
		local v29
		if p26 == true then
			v29 = v_u_46.CHAR_CAPS
		else
			v29 = v_u_46.CHAR
		end
		local v30 = v28 * v29 + 2
		return math.ceil(v30)
	end,
	["lineH"] = function(p31) -- name: lineH
		local v32 = p31 * 1.3
		return math.ceil(v32)
	end,
	["clip1"] = function(p33, p34, p35, p36) -- name: clip1
		-- upvalues: (copy) v_u_46
		local v37 = tostring(p33 or "")
		if v_u_46.textW(v37, p35, p36) <= p34 then
			return v37
		end
		local v38 = 1
		local v39 = p34 - 2
		local v40
		if p36 == true then
			v40 = v_u_46.CHAR_CAPS
		else
			v40 = v_u_46.CHAR
		end
		local v41 = v39 / (p35 * v40)
		local v42 = math.floor(v41) - 3
		local v43 = math.max(v38, v42)
		if (utf8.len(v37) or #v37) <= v43 then
			return v37
		end
		local v44
		if utf8.offset == nil then
			v44 = string.sub(v37, 1, v43)
		else
			local v45 = (utf8.offset(v37, v43 + 1) or #v37 + 1) - 1
			v44 = string.sub(v37, 1, v45)
		end
		return v44 .. "..."
	end
}
local function v_u_57(p47, p48, p49) -- name: packRows
	local v50 = {}
	local v51 = 0
	local v52 = {}
	for v53, v56 in p47 do
		local v55 = (#v50 <= 0 and 0 or p49) + v56
		if #v50 > 0 and p48 < v51 + v55 then
			table.insert(v52, v50)
			v50 = {}
			v51 = 0
		else
			local v56 = v55
		end
		table.insert(v50, v53)
		v51 = v51 + v56
	end
	if #v50 > 0 then
		table.insert(v52, v50)
	end
	return v52
end
local function v_u_127(p58, p59, p60, p61, p62, p63, p64, p65) -- name: planRoster
	-- upvalues: (copy) v_u_46
	local v66 = v_u_46.MARGIN
	local v67 = p59.pad
	local v68 = p59.gap
	local v69 = p60.rows or {}
	local v70 = #v69
	local v71 = v_u_46.lineH(p64)
	local v72 = v_u_46.lineH(p65)
	local v73 = p59.tap
	local v74 = v72 + 14
	local v75 = math.max(v73, v74)
	local v76 = p59.tap
	local v77 = v71 + 8
	local v78 = math.max(v76, v77)
	local v79 = p58 - math.max(v66, p63) * 2
	local v80 = v_u_46.ROSTER_W_MAX
	local v81 = math.min(v79, v80)
	local v82 = v81 - 2 * v67
	local v83 = v_u_46.ROSTER_COLS_MAX
	local v84 = (v82 + v68) / (v_u_46.ROSTER_COL_MIN + v68)
	local v85 = math.floor(v84)
	local v86 = math.min(v83, v85)
	local v87 = math.max(1, v86)
	local v88 = (v82 - (v87 - 1) * v68) / v87
	local v89 = math.floor(v88)
	local v90 = v70 / v87
	local v91 = math.ceil(v90)
	local v92 = v91 <= 0 and 0 or v91 * v75 + (v91 - 1) * v68
	local v93 = v78 + 3 * v67 + math.max(v92, v75)
	local v94 = p62 - p61
	local v95 = math.min(v93, v94)
	local v96 = v78 + 2 * v67
	local v97 = p62 - p61 - v78 - 2 * v67
	local v98 = math.max(0, v97)
	local v99 = v96 + math.min(v75, v98)
	local v100 = math.max(v95, v99)
	local v101 = (p58 - v81) / 2
	local v102 = math.floor(v101)
	local v103 = (p62 - p61 - v100) / 2
	local v104 = p61 + math.floor(v103)
	local v105 = v100 - v78 - 3 * v67
	local v106 = {
		["rect"] = {
			["x"] = v102,
			["y"] = v104,
			["w"] = v81,
			["h"] = v100
		},
		["size"] = p64,
		["small"] = p65,
		["cols"] = v87,
		["rowH"] = v75,
		["canvasH"] = v92,
		["items"] = {}
	}
	local v107 = p59.tap
	local v108 = v_u_46.textW(p60.close or "CLOSE", p65, true) + 24
	local v109 = math.max(v107, v108)
	v106.header = {
		["x"] = v67,
		["y"] = v67,
		["w"] = v81 - 2 * v67,
		["h"] = v78
	}
	v106.close = {
		["x"] = v81 - v67 - v109,
		["y"] = v67,
		["w"] = v109,
		["h"] = v78
	}
	local v110 = v81 - 3 * v67 - v109 - 4
	v106.title = {
		["x"] = v67 + 4,
		["y"] = v67,
		["w"] = v110,
		["h"] = v78
	}
	v106.titleText = v_u_46.clip1(p60.title or "PLAYERS", v106.title.w, p64, true)
	v106.closeText = p60.close or "CLOSE"
	v106.view = {
		["x"] = v67,
		["y"] = v78 + 2 * v67,
		["w"] = v82,
		["h"] = math.max(v105, 0)
	}
	local v111 = v_u_46.textW("ALIVE", p65, true)
	for v112, v113 in v69 do
		local v114 = (v112 - 1) % v87
		local v115 = (v112 - 1) / v87
		local v116 = math.floor(v115)
		local v117 = {
			["x"] = v114 * (v89 + v68),
			["y"] = v116 * (v75 + v68),
			["w"] = v89,
			["h"] = v75
		}
		local v118 = (v75 - 14) / 2
		local v119 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = 14,
			["h"] = 14,
			["y"] = math.floor(v118)
		}
		local v120 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v89 - 8 - v111,
			["w"] = v111,
			["h"] = v75
		}
		local v121 = v119.x + v119.w + 8
		local v122 = v120.x - 6 - v121
		local v123 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v121,
			["w"] = math.max(24, v122),
			["h"] = v75
		}
		local v124 = v106.items
		local v125 = {
			["rect"] = v117,
			["chip"] = v119,
			["name"] = v123,
			["word"] = v120,
			["userId"] = v113.userId,
			["text"] = v_u_46.clip1(v113.name, v123.w, p64, false)
		}
		local v126 = v113.word or ""
		v125.wordText = tostring(v126)
		v125.hue = v113.hue or 0
		v125.current = v113.current == true
		v125.targetable = v113.targetable == true
		table.insert(v124, v125)
	end
	return v106
end
function v_u_46.hud(p_u_128, p_u_129, p_u_130, p131) -- name: hud
	-- upvalues: (copy) v_u_46, (copy) v_u_57, (copy) v_u_127
	local v_u_132 = v_u_46.MARGIN
	local v_u_133 = p_u_130.pad
	local v_u_134 = p_u_130.gap
	local v_u_135 = v_u_46.fs(p_u_130, 13)
	local v136 = v_u_46.fs(p_u_130, 11)
	v_u_46.lineH(v_u_135)
	local v_u_137 = v_u_46.lineH(v136)
	local v_u_138 = {}
	local v_u_139 = p_u_128 - 2 * v_u_132
	local function v151(p140, p141) -- name: planBar
		-- upvalues: (ref) v_u_46, (copy) v_u_135, (copy) p_u_130, (copy) v_u_139, (ref) v_u_57, (copy) v_u_134
		local v142 = {}
		for v143, v145 in p140 do
			if p141 ~= nil and p141[v143] ~= nil then
				local v145 = p141[v143]
			end
			local v146 = v_u_46.BTN_MIN
			local v147 = v_u_46.textW(v145, v_u_135, true) + 24
			local v148 = p_u_130.tap
			local v149 = math.max(v146, v147, v148)
			local v150 = v_u_139
			v142[v143] = math.min(v149, v150)
		end
		return v142, v_u_57(v142, v_u_139, v_u_134)
	end
	local v152 = p131.buttons or {}
	local v153, v154 = v151(v152, p131.widest)
	local v155, v156
	if #v154 > v_u_46.BAR_ROWS_MAX and p131.short ~= nil then
		v155, v156 = v151(p131.short, p131.widestShort)
		if #v156 < #v154 then
			v152 = p131.short
		else
			v156 = v154
			v155 = v153
		end
	else
		v156 = v154
		v155 = v153
	end
	local v157 = #v156
	local v158 = math.max(1, v157)
	local v159 = v158 * p_u_130.tap + (v158 - 1) * v_u_134
	local v160 = p_u_129 - v_u_132 - v159
	local v161 = {}
	for v162, v163 in v156 do
		local v164 = -v_u_134
		for _, v165 in v163 do
			v164 = v164 + (v155[v165] + v_u_134)
		end
		local v166 = (p_u_128 - v164) / 2
		local v167 = math.floor(v166)
		local v168 = v160 + (v162 - 1) * (p_u_130.tap + v_u_134)
		for _, v169 in v163 do
			v161[v169] = {
				["x"] = v167,
				["y"] = v168,
				["w"] = v155[v169],
				["h"] = p_u_130.tap
			}
			v167 = v167 + (v155[v169] + v_u_134)
		end
	end
	v_u_138.bar = {
		["rects"] = v161,
		["rows"] = v158,
		["size"] = v_u_135,
		["labels"] = v152
	}
	local v170 = v_u_137 + 8
	local v171 = p131.status or ""
	local v172 = tostring(v171)
	local v173 = v_u_46.textW(v172, v136, true) + 24
	local v174 = math.min(v_u_139, v173)
	local v175 = v160 - 6 - v170
	local v176 = {}
	local v177 = (p_u_128 - v174) / 2
	v176.rect = {
		["x"] = math.floor(v177),
		["y"] = v175,
		["w"] = v174,
		["h"] = v170
	}
	v176.text = v_u_46.clip1(v172, v174 - 16, v136, true)
	v176.size = v136
	v_u_138.strip = v176
	local v178 = v175 - v_u_134
	local v179 = v_u_46.INFO_MIN
	local v180 = v_u_46.INFO_MAX
	local v181 = p_u_128 * 0.34
	local v182 = math.floor(v181)
	local v183 = math.min(v180, v182)
	local v184 = math.max(v179, v183)
	local v_u_185 = math.min(v_u_139, v184)
	local v186 = p131.sw
	local v187, v188
	if v186 == nil then
		v187 = 0
		v188 = 0
	else
		local v189 = p_u_130.tap
		local v190 = v_u_46.textW(v186.list or "LIST", v136, true) + 20
		v187 = math.max(v189, v190)
		v188 = 2 * p_u_130.tap + v187 + 2 * v_u_134
		local v191 = v_u_139 - v188 - v_u_134
		local v192 = math.min(v_u_185, v191)
		local v193 = math.min(v_u_185, 140)
		v_u_185 = math.max(v192, v193)
	end
	local v_u_194 = {
		"name",
		"link",
		"weapon",
		"hp",
		"shots",
		"speed"
	}
	local v_u_195 = {
		["name"] = v_u_135 + 2,
		["link"] = v136,
		["weapon"] = v_u_135,
		["hp"] = v_u_135,
		["shots"] = v136,
		["speed"] = v136
	}
	local v196 = {
		["name"] = p131.name,
		["link"] = p131.link,
		["weapon"] = p131.weapon,
		["hp"] = p131.hp,
		["shots"] = p131.shots,
		["speed"] = p131.speed
	}
	local v197 = #v_u_194
	local function v203(p198) -- name: infoHeight
		-- upvalues: (copy) v_u_133, (copy) v_u_194, (ref) v_u_46, (copy) v_u_195
		local v199 = 2 * v_u_133
		for v200 = 1, p198 do
			local v201 = v_u_194[v200]
			local v202
			if v201 == "shots" then
				v202 = v199 + 2 * v_u_46.lineH(v_u_195[v201])
			else
				v202 = v199 + v_u_46.lineH(v_u_195[v201])
			end
			v199 = v202 + 2
		end
		return v199
	end
	local v204 = p_u_130.top or 0
	local v205 = math.max(v_u_132, v204)
	local v206 = nil
	local v_u_207, v_u_208
	if v_u_132 < v205 and (p_u_130.cornerW or 0) > 0 then
		local v209 = 2 * v_u_133
		for v210 = 1, 2 do
			local v211 = v_u_194[v210]
			local v212
			if v211 == "shots" then
				v212 = v209 + 2 * v_u_46.lineH(v_u_195[v211])
			else
				v212 = v209 + v_u_46.lineH(v_u_195[v211])
			end
			v209 = v212 + 2
		end
		if v178 - v205 < v209 then
			local v213 = p_u_130.cornerW + v_u_134
			v_u_207 = math.max(v_u_132, v213)
			local v214 = p_u_130.rightW or 0
			v206 = p_u_128 - math.max(v_u_132, v214)
			local v215
			if (p_u_130.rightW or 0) > 0 then
				v215 = math.min(v_u_185, 140)
			else
				local v216 = v_u_46.INFO_MIN
				v215 = math.min(v_u_185, v216)
			end
			local v217 = v206 - v_u_207
			local v218 = math.min(v_u_185, v217)
			v_u_185 = math.max(v218, v215)
			v_u_208 = v_u_132
		else
			v_u_208 = v_u_132
			v_u_132 = v205
		end
	else
		v_u_208 = v_u_132
		v_u_132 = v205
	end
	while v197 > 2 and v203(v197) > v178 - v_u_132 do
		v197 = v197 - 1
	end
	local v_u_219 = v203(v197)
	local v_u_220
	if p_u_130.touch and p131.pad then
		local v221 = p_u_130.tap
		v_u_220 = {
			["x"] = p_u_128 - v_u_208 - (2 * v221 + v_u_134),
			["y"] = v175 - v_u_134 - (2 * v221 + v_u_134),
			["w"] = 2 * v221 + v_u_134,
			["h"] = 2 * v221 + v_u_134
		}
	else
		v_u_220 = nil
	end
	local v222 = p131.events or {}
	local v223 = #v222
	local v224 = v_u_46.maxEventLines or 5
	local v225 = math.min(v223, v224)
	local v_u_226
	if v186 == nil then
		v_u_226 = nil
	else
		local v227 = p_u_130.tap
		local v228
		if v206 == nil then
			v228 = p_u_128 - v_u_208
		else
			v228 = v206
		end
		local function v237(p229) -- name: clear
			-- upvalues: (copy) v_u_208, (copy) p_u_128, (copy) p_u_129, (ref) v_u_207, (ref) v_u_132, (ref) v_u_185, (ref) v_u_219, (copy) v_u_134, (ref) v_u_220, (copy) v_u_138
			if p229.x < v_u_208 or (p229.x + p229.w > p_u_128 - v_u_208 or (p229.y < 0 or p_u_129 < p229.y + p229.h)) then
				return false
			end
			local v230 = {
				["x"] = v_u_207,
				["y"] = v_u_132,
				["w"] = v_u_185,
				["h"] = v_u_219
			}
			local v231
			if p229.x < v230.x + v230.w + v_u_134 and (v230.x < p229.x + p229.w + v_u_134 and p229.y < v230.y + v230.h + v_u_134) then
				v231 = v230.y < p229.y + p229.h + v_u_134
			else
				v231 = false
			end
			local v232 = not v231
			if v232 then
				local v233
				if v_u_220 == nil then
					v233 = false
				else
					local v234 = v_u_220
					if p229.x < v234.x + v234.w + v_u_134 and (v234.x < p229.x + p229.w + v_u_134 and p229.y < v234.y + v234.h + v_u_134) then
						v233 = v234.y < p229.y + p229.h + v_u_134
					else
						v233 = false
					end
				end
				v232 = not v233
				if v232 then
					local v235 = v_u_138.strip.rect
					local v236
					if p229.x < v235.x + v235.w + v_u_134 and (v235.x < p229.x + p229.w + v_u_134 and p229.y < v235.y + v235.h + v_u_134) then
						v236 = v235.y < p229.y + p229.h + v_u_134
					else
						v236 = false
					end
					v232 = not v236
				end
			end
			return v232
		end
		local v238 = {
			{
				["x"] = v228 - v188,
				["y"] = v_u_132,
				["w"] = v188,
				["h"] = v227
			}
		}
		if v_u_220 ~= nil then
			local v239 = {
				["x"] = v_u_220.x - v_u_134 - v188,
				["y"] = v_u_132,
				["w"] = v188,
				["h"] = v227
			}
			table.insert(v238, v239)
		end
		local v240 = {
			["x"] = v_u_208,
			["y"] = v175 - v_u_134 - v227,
			["w"] = v188,
			["h"] = v227
		}
		table.insert(v238, v240)
		local v241 = {
			["x"] = v_u_207,
			["y"] = v_u_132 + v_u_219 + v_u_134,
			["w"] = v188,
			["h"] = v227
		}
		table.insert(v238, v241)
		v_u_226 = v238[1]
		local v242 = false
		for _, v243 in v238 do
			if not v237(v243) then
				continue
			end
			v_u_226 = v243
			v242 = true
		end
		while not v242 and v197 > 2 do
			v197 = v197 - 1
			local v244 = v203(v197)
			v_u_226 = {
				["x"] = v_u_207,
				["y"] = v_u_132 + v244 + v_u_134,
				["w"] = v188,
				["h"] = v227
			}
			if v237(v_u_226) then
				v242 = true
			end
			v_u_219 = v244
		end
		if v_u_226.y == v_u_132 then
			local v245 = (v178 - (v_u_132 + v_u_219 + v_u_134) - 2 * v_u_133 - v_u_137 - 2) / v_u_137
			local v246 = math.floor(v245)
			if math.min(v225, v246) < v225 then
				local v247 = v_u_226.x - v_u_134
				local v248
				if v206 == nil then
					v248 = p_u_128 - v_u_208
				else
					v248 = v206
				end
				local v249 = (math.min(v247, v248) - v_u_207 - v_u_134) / 2
				local v250 = math.floor(v249)
				if v250 < v_u_185 and v_u_46.SQUEEZE_MIN <= v250 then
					local v251 = v250
					v_u_185 = v251
				end
			end
		end
	end
	local v252 = v_u_185 - 2 * v_u_133
	v_u_138.info = {
		["rect"] = {
			["x"] = v_u_207,
			["y"] = v_u_132,
			["w"] = v_u_185,
			["h"] = v_u_219
		},
		["rows"] = {}
	}
	local v253 = v_u_133
	for v254 = 1, v197 do
		local v255 = v_u_194[v254]
		local v256 = v_u_195[v255]
		local v257 = {
			["key"] = v255,
			["size"] = v256
		}
		local v258, v259
		if v255 == "link" then
			local v260 = (v_u_46.lineH(v256) - 10) / 2
			v257.dot = {
				["x"] = nil,
				["y"] = nil,
				["w"] = 10,
				["h"] = 10,
				["x"] = v_u_133,
				["y"] = v253 + math.floor(v260)
			}
			v258 = v_u_133 + 14
			v259 = v252 - 14
		else
			v258 = v_u_133
			v259 = v252
		end
		local v261
		if v255 == "shots" then
			v261 = 2 * v_u_46.lineH(v256)
		else
			v261 = v_u_46.lineH(v256)
		end
		v257.rect = {
			["x"] = v258,
			["y"] = v253,
			["w"] = v259,
			["h"] = v261
		}
		v257.lines = v255 == "shots" and 2 or 1
		if v255 == "shots" then
			local v262 = v196[v255] or ""
			v257.text = tostring(v262)
			local v263 = (v259 - 2) / (v256 * v_u_46.CHAR)
			local v264 = math.floor(v263)
			local v265 = math.max(1, v264)
			if (utf8.len(v257.text) or #v257.text) > v265 * 2 - 3 then
				local v266 = v257.text
				local v267 = v265 * 2 - 4
				local v268
				if utf8.offset == nil then
					v268 = string.sub(v266, 1, v267)
				else
					local v269 = (utf8.offset(v266, v267 + 1) or #v266 + 1) - 1
					v268 = string.sub(v266, 1, v269)
				end
				v257.text = v268 .. "..."
			end
		else
			v257.text = v_u_46.clip1(v196[v255], v259, v256, false)
		end
		local v270 = v_u_138.info.rows
		table.insert(v270, v257)
		v253 = v253 + (v261 + 2)
	end
	if v_u_220 ~= nil then
		local v271 = p_u_130.tap
		v_u_138.pad = {
			["rect"] = v_u_220,
			["buttons"] = {
				{
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v271,
					["h"] = v271
				},
				{
					["x"] = nil,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["x"] = v271 + v_u_134,
					["w"] = v271,
					["h"] = v271
				},
				{
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v271 + v_u_134,
					["w"] = v271,
					["h"] = v271
				},
				{
					["x"] = v271 + v_u_134,
					["y"] = v271 + v_u_134,
					["w"] = v271,
					["h"] = v271
				}
			},
			["names"] = {
				"left",
				"right",
				"closer",
				"farther"
			}
		}
	end
	if v_u_226 ~= nil then
		local v272 = p_u_130.tap
		v_u_138.sw = {
			["rect"] = v_u_226,
			["prev"] = {
				["x"] = v_u_226.x,
				["y"] = v_u_226.y,
				["w"] = v272,
				["h"] = v272
			},
			["next"] = {
				["x"] = v_u_226.x + v272 + v_u_134,
				["y"] = v_u_226.y,
				["w"] = v272,
				["h"] = v272
			},
			["list"] = {
				["x"] = v_u_226.x + 2 * v272 + 2 * v_u_134,
				["y"] = v_u_226.y,
				["w"] = v187,
				["h"] = v272
			},
			["labels"] = {
				["prev"] = v186.prev or "<",
				["next"] = v186.next or ">",
				["list"] = v186.list or "LIST"
			},
			["canPrev"] = v186.canPrev ~= false,
			["canNext"] = v186.canNext ~= false,
			["size"] = v136
		}
	end
	local function v278(p273, p274, p275) -- name: hitsSwitch
		-- upvalues: (ref) v_u_226, (ref) v_u_185, (copy) v_u_133, (copy) v_u_137, (copy) v_u_134
		if v_u_226 == nil then
			return false
		end
		local v276 = {
			["x"] = p273,
			["y"] = p274,
			["w"] = v_u_185,
			["h"] = 2 * v_u_133 + v_u_137 + 2 + p275 * v_u_137
		}
		local v277
		if v276.x < v_u_226.x + v_u_226.w + v_u_134 and (v_u_226.x < v276.x + v276.w + v_u_134 and v276.y < v_u_226.y + v_u_226.h + v_u_134) then
			v277 = v_u_226.y < v276.y + v276.h + v_u_134
		else
			v277 = false
		end
		return v277
	end
	local v279 = v_u_132 + v_u_219 + v_u_134
	local v280 = (v178 - v279 - 2 * v_u_133 - v_u_137 - 2) / v_u_137
	local v281 = math.floor(v280)
	local v282 = math.min(v225, v281)
	local v283 = v282 >= 1 and v278(v_u_207, v279, v282) and 0 or v282
	local v284 = false
	local v285 = v_u_207 + v_u_185 + v_u_134
	local v286
	if v_u_220 then
		v286 = v_u_220.x - v_u_134
	else
		v286 = p_u_128 - v_u_208
	end
	if v206 ~= nil then
		v286 = math.min(v286, v206)
	end
	if v283 < v225 and v285 + v_u_185 <= v286 then
		local v287 = (v178 - v_u_132 - 2 * v_u_133 - v_u_137 - 2) / v_u_137
		local v288 = math.floor(v287)
		local v289 = math.min(v225, v288)
		local v290 = v289 >= 1 and v278(v285, v_u_132, v289) and 0 or v289
		if v283 < v290 then
			v279 = v_u_132
			v_u_207 = v285
			v283 = v290
			v284 = true
		end
	end
	if v283 >= 1 then
		local v291 = {
			["rect"] = {
				["x"] = v_u_207,
				["y"] = v279,
				["w"] = v_u_185,
				["h"] = 2 * v_u_133 + v_u_137 + 2 + v283 * v_u_137
			},
			["header"] = {
				["x"] = v_u_133,
				["y"] = v_u_133,
				["w"] = v252,
				["h"] = v_u_137
			},
			["lines"] = {},
			["side"] = v284
		}
		local v292 = v_u_133 + v_u_137 + 2
		for v293 = 1, v283 do
			local v294 = v291.lines
			local v295 = {
				["rect"] = {
					["x"] = v_u_133,
					["y"] = v292,
					["w"] = v252,
					["h"] = v_u_137
				},
				["text"] = v_u_46.clip1(v222[v293], v252, v136, false)
			}
			table.insert(v294, v295)
			v292 = v292 + v_u_137
		end
		v291.size = v136
		v_u_138.events = v291
	end
	v_u_138.size = v_u_135
	v_u_138.small = v136
	if p131.roster ~= nil then
		local v296 = p_u_130.top or 0
		local v297 = math.max(v_u_208, v296)
		local v298 = v160 - v_u_134
		local v299
		if v298 - v297 < p_u_130.tap + 2 * v_u_133 + p_u_130.tap + 2 * v_u_133 then
			local v300 = p_u_130.cornerW or 0
			local v301 = p_u_130.rightW or 0
			v299 = math.max(v300, v301) + v_u_134
		else
			v_u_208 = v297
			v299 = 0
		end
		v_u_138.roster = v_u_127(p_u_128, p_u_130, p131.roster, v_u_208, v298, v299, v_u_135, v136)
	end
	return v_u_138
end
function v_u_46.rects(p302) -- name: rects
	local v303 = {}
	local v304 = p302.info.rect
	if v304 then
		table.insert(v303, {
			["name"] = "info",
			["rect"] = nil,
			["parent"] = nil,
			["rect"] = v304
		})
	end
	for _, v305 in p302.info.rows do
		local v306 = "info." .. v305.key
		local v307 = v305.rect
		local v308 = p302.info.rect
		if v307 then
			table.insert(v303, {
				["name"] = v306,
				["rect"] = v307,
				["parent"] = v308
			})
		end
		if not v305.dot then
			continue
		end
		local v309 = v305.dot
		local v310 = p302.info.rect
		if not v309 then
			continue
		end
		table.insert(v303, {
			["name"] = "info.dot",
			["rect"] = nil,
			["parent"] = nil,
			["rect"] = v309,
			["parent"] = v310
		})
	end
	if p302.events then
		local v311 = p302.events.rect
		if v311 then
			table.insert(v303, {
				["name"] = "events",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v311
			})
		end
		local v312 = p302.events.header
		local v313 = p302.events.rect
		if v312 then
			table.insert(v303, {
				["name"] = "events.header",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v312,
				["parent"] = v313
			})
		end
		for v314, v315 in p302.events.lines do
			local v316 = "events.line" .. v314
			local v317 = v315.rect
			local v318 = p302.events.rect
			if not v317 then
				continue
			end
			table.insert(v303, {
				["name"] = v316,
				["rect"] = v317,
				["parent"] = v318
			})
		end
	end
	local v319 = p302.strip.rect
	if v319 then
		table.insert(v303, {
			["name"] = "strip",
			["rect"] = nil,
			["parent"] = nil,
			["rect"] = v319
		})
	end
	for v320, v321 in p302.bar.rects do
		local v322 = "bar" .. v320
		if not v321 then
			continue
		end
		table.insert(v303, {
			["name"] = nil,
			["rect"] = nil,
			["parent"] = nil,
			["name"] = v322,
			["rect"] = v321
		})
	end
	if p302.pad then
		local v323 = p302.pad.rect
		if v323 then
			table.insert(v303, {
				["name"] = "pad",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v323
			})
		end
		for v324, v325 in p302.pad.buttons do
			local v326 = "pad." .. p302.pad.names[v324]
			local v327 = p302.pad.rect
			if not v325 then
				continue
			end
			table.insert(v303, {
				["name"] = v326,
				["rect"] = v325,
				["parent"] = v327
			})
		end
	end
	if p302.sw then
		local v328 = p302.sw.prev
		if v328 then
			table.insert(v303, {
				["name"] = "sw.prev",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v328
			})
		end
		local v329 = p302.sw.next
		if v329 then
			table.insert(v303, {
				["name"] = "sw.next",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v329
			})
		end
		local v330 = p302.sw.list
		if v330 then
			table.insert(v303, {
				["name"] = "sw.list",
				["rect"] = nil,
				["parent"] = nil,
				["rect"] = v330
			})
		end
	end
	return v303
end
function v_u_46.rosterRects(p331) -- name: rosterRects
	local v332 = {}
	local v333 = p331.roster
	if v333 == nil then
		return v332
	end
	local v334 = {
		["name"] = "roster",
		["rect"] = nil,
		["rect"] = v333.rect
	}
	table.insert(v332, v334)
	local v335 = {
		["name"] = "roster.header",
		["rect"] = nil,
		["parent"] = nil,
		["rect"] = v333.header,
		["parent"] = v333.rect
	}
	table.insert(v332, v335)
	local v336 = {
		["name"] = "roster.title",
		["rect"] = nil,
		["parent"] = nil,
		["rect"] = v333.title,
		["parent"] = v333.rect
	}
	table.insert(v332, v336)
	local v337 = {
		["name"] = "roster.close",
		["rect"] = nil,
		["parent"] = nil,
		["rect"] = v333.close,
		["parent"] = v333.rect
	}
	table.insert(v332, v337)
	local v338 = {
		["name"] = "roster.view",
		["rect"] = nil,
		["parent"] = nil,
		["rect"] = v333.view,
		["parent"] = v333.rect
	}
	table.insert(v332, v338)
	local v339 = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["w"] = v333.view.w
	}
	local v340 = v333.canvasH
	v339.h = math.max(v340, 1)
	for v341, v342 in v333.items do
		local v343 = {
			["name"] = "roster.item" .. v341,
			["rect"] = v342.rect,
			["parent"] = v339
		}
		table.insert(v332, v343)
		local v344 = {
			["name"] = "roster.item" .. v341 .. ".chip",
			["rect"] = v342.chip,
			["parent"] = v342.rect
		}
		table.insert(v332, v344)
		local v345 = {
			["name"] = "roster.item" .. v341 .. ".name",
			["rect"] = v342.name,
			["parent"] = v342.rect
		}
		table.insert(v332, v345)
		local v346 = {
			["name"] = "roster.item" .. v341 .. ".word",
			["rect"] = v342.word,
			["parent"] = v342.rect
		}
		table.insert(v332, v346)
	end
	return v332
end
function v_u_46.rosterSig(p347) -- name: rosterSig
	if type(p347) ~= "table" then
		return ""
	end
	local v348 = {}
	local v349 = p347.rect
	local v350 = string.format("%.2f,%.2f,%.2f,%.2f", v349.x, v349.y, v349.w, v349.h)
	local v351 = p347.view
	local v352 = string.format("%.2f,%.2f,%.2f,%.2f", v351.x, v351.y, v351.w, v351.h)
	local v353 = p347.close
	local v354 = string.format("%.2f,%.2f,%.2f,%.2f", v353.x, v353.y, v353.w, v353.h)
	local v355 = p347.title
	local v356 = string.format("%.2f,%.2f,%.2f,%.2f", v355.x, v355.y, v355.w, v355.h)
	local v357 = p347.canvasH
	local v358 = tostring(v357)
	local v359 = p347.size
	local v360 = tostring(v359)
	local v361 = p347.small
	local v362 = tostring(v361)
	local v363 = p347.cols
	local v364 = tostring(v363)
	local v365 = p347.titleText
	local v366 = tostring(v365)
	local v367 = p347.closeText
	__set_list(v348, 1, {v350, v352, v354, v356, v358, v360, v362, v364, v366, (tostring(v367))})
	local function v369(p368) -- name: r4
		return string.format("%.2f,%.2f,%.2f,%.2f", p368.x, p368.y, p368.w, p368.h)
	end
	for _, v370 in p347.items do
		local v371 = table.concat
		local v372 = {}
		local v373 = v370.userId
		local v374 = tostring(v373)
		local v375 = v370.text
		local v376 = v370.wordText
		local v377 = v370.hue
		__set_list(v372, 1, {v374, v375, v376, tostring(v377), v370.current and "c" or "-", v370.targetable and "t" or "-", v369(v370.rect)})
		table.insert(v348, v371(v372, ";"))
	end
	return table.concat(v348, "|")
end
return v_u_46