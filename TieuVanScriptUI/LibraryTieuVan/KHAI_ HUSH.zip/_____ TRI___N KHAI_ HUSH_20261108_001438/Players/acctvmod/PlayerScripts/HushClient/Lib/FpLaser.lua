-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpLaser

local v_u_1 = {
	["FOLLOW_BARREL"] = true,
	["MAX_LEN"] = 120,
	["OWN_HOLD"] = 0.15,
	["MIN_AIM"] = 2,
	["AIM_DIST_MIN"] = 4,
	["AIM_DIST_DEFAULT"] = 60,
	["AIM_STALE"] = 0.25,
	["CONVERGE_FULL_DEG"] = 20,
	["CONVERGE_ZERO_DEG"] = 30,
	["ZOMBIE_CONE_DEG"] = 4,
	["FP_WIDTH"] = 0.012,
	["FP_ALPHA"] = 0.6
}
local v_u_2 = math.sin
local v_u_3 = math.cos
local v_u_4 = math.rad
local v_u_5 = math.deg
local v_u_6 = math.sqrt
function v_u_1.followBarrel(p7) -- name: followBarrel
	-- upvalues: (copy) v_u_1
	local v8
	if p7 == true then
		v8 = v_u_1.FOLLOW_BARREL == true
	else
		v8 = false
	end
	return v8
end
function v_u_1.barrelDir(p9) -- name: barrelDir
	-- upvalues: (copy) v_u_6
	if p9 == nil then
		return nil
	end
	local v10 = p9.X or p9.x
	local v11 = p9.Y or p9.y
	local v12 = p9.Z or p9.z
	if type(v10) ~= "number" or (type(v11) ~= "number" or type(v12) ~= "number") then
		return nil
	end
	local v13 = v_u_6(v10 * v10 + v11 * v11 + v12 * v12)
	return v13 == v13 and (v13 ~= (1 / 0) and v13 >= 1e-6) and {
		["x"] = v10 / v13,
		["y"] = v11 / v13,
		["z"] = v12 / v13
	} or nil
end
function v_u_1.source(p14, p15, p16, p17) -- name: source
	return p14 and p15 and (p16 and "viewmodel" or (p17 == true and "hide" or "world")) or "loop"
end
function v_u_1.loopSkipsOwn(p18, p19, p20) -- name: loopSkipsOwn
	-- upvalues: (copy) v_u_1
	local v21
	if p18 == true and p20 > 0 then
		v21 = p19 - p20 < v_u_1.OWN_HOLD
	else
		v21 = false
	end
	return v21
end
function v_u_1.mode(p22, p23, p24) -- name: mode
	return p22 and p23 and "beam" or (p24 and "dot" or "none")
end
function v_u_1.baseEuler(p25, p26, p27) -- name: baseEuler
	local v28 = math.clamp(p27, 0, 1)
	local v29 = 1 - v28
	return {
		["yaw"] = (p25.yaw or 0) * v29,
		["pitch"] = (p25.pitch or 0) * v29,
		["roll"] = (p25.roll or 0) * v29 + (p26 or 0) * v28
	}
end
function v_u_1.convergeWeight(p30, p31) -- name: convergeWeight
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	local v32 = v_u_6(p30 * p30 + p31 * p31)
	return v32 <= v_u_1.CONVERGE_FULL_DEG and 1 or (v_u_1.CONVERGE_ZERO_DEG <= v32 and 0 or (v_u_1.CONVERGE_ZERO_DEG - v32) / (v_u_1.CONVERGE_ZERO_DEG - v_u_1.CONVERGE_FULL_DEG))
end
function v_u_1.mul(p33, p34) -- name: mul
	local v35 = {
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	}
	for v36 = 0, 2 do
		for v37 = 0, 2 do
			v35[v36 * 3 + v37 + 1] = p33[v36 * 3 + 1] * p34[v37 + 1] + p33[v36 * 3 + 2] * p34[v37 + 4] + p33[v36 * 3 + 3] * p34[v37 + 7]
		end
	end
	return v35
end
function v_u_1.transpose(p38) -- name: transpose
	return {
		p38[1],
		p38[4],
		p38[7],
		p38[2],
		p38[5],
		p38[8],
		p38[3],
		p38[6],
		p38[9]
	}
end
function v_u_1.apply(p39, p40) -- name: apply
	return {
		["x"] = p39[1] * p40.x + p39[2] * p40.y + p39[3] * p40.z,
		["y"] = p39[4] * p40.x + p39[5] * p40.y + p39[6] * p40.z,
		["z"] = p39[7] * p40.x + p39[8] * p40.y + p39[9] * p40.z
	}
end
function v_u_1.unit(p41) -- name: unit
	-- upvalues: (copy) v_u_6
	local v42 = v_u_6(p41.x * p41.x + p41.y * p41.y + p41.z * p41.z)
	return (v42 < 1e-9 or v42 ~= v42) and {
		["x"] = 0,
		["y"] = 0,
		["z"] = -1
	} or {
		["x"] = p41.x / v42,
		["y"] = p41.y / v42,
		["z"] = p41.z / v42
	}
end
function v_u_1.angleDeg(p43, p44) -- name: angleDeg
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	local v45 = v_u_6(p43.x * p43.x + p43.y * p43.y + p43.z * p43.z)
	local v46 = v_u_6(p44.x * p44.x + p44.y * p44.y + p44.z * p44.z)
	if v45 < 1e-9 or v46 < 1e-9 then
		return 0
	end
	local v47 = p43.y * p44.z - p43.z * p44.y
	local v48 = p43.z * p44.x - p43.x * p44.z
	local v49 = p43.x * p44.y - p43.y * p44.x
	local v50 = v_u_6(v47 * v47 + v48 * v48 + v49 * v49)
	local v51 = p43.x * p44.x + p43.y * p44.y + p43.z * p44.z
	return v_u_5((math.atan2(v50, v51)))
end
function v_u_1.euler(p52, p53, p54) -- name: euler
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_1
	local v55 = v_u_3(p53)
	local v56 = v_u_2(p53)
	local v57 = v_u_3(p52)
	local v58 = v_u_2(p52)
	local v59 = v_u_3(p54)
	local v60 = v_u_2(p54)
	local v61 = {
		v55,
		0,
		v56,
		0,
		1,
		0,
		-v56,
		0,
		v55
	}
	local v62 = {
		1,
		0,
		0,
		0,
		v57,
		-v58,
		0,
		v58,
		v57
	}
	local v63 = {
		v59,
		-v60,
		0,
		v60,
		v59,
		0,
		0,
		0,
		1
	}
	return v_u_1.mul(v_u_1.mul(v61, v62), v63)
end
function v_u_1.eulerDeg(p64, p65, p66) -- name: eulerDeg
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	return v_u_1.euler(v_u_4(p64), v_u_4(p65), (v_u_4(p66)))
end
function v_u_1.dir(p67, p68, p69, p70) -- name: dir
	-- upvalues: (copy) v_u_1
	local v71 = v_u_1.convergeWeight(p69.yaw, p69.pitch)
	local v72 = v_u_1.eulerDeg(p69.pitch * v71, p69.yaw * v71, p69.roll * v71)
	local v73 = v_u_1.mul(p68, v_u_1.transpose(v72))
	local v74 = v_u_1.apply(v_u_1.transpose(p67), p70)
	local v75 = v_u_1.unit({
		["x"] = v74.x * v71,
		["y"] = v74.y * v71,
		["z"] = v74.z * v71 - (1 - v71)
	})
	return v_u_1.unit(v_u_1.apply(p67, v_u_1.apply(v73, v75)))
end
function v_u_1.viewDir(p76, p77, p78, p79, p80, p81, p82, p83) -- name: viewDir
	-- upvalues: (copy) v_u_1, (copy) v_u_6
	local v84 = v_u_1.apply(p76, {
		["x"] = 0,
		["y"] = 0,
		["z"] = -1
	})
	local v85 = p77.x + v84.x * p83 - p82.x
	local v86 = p77.y + v84.y * p83 - p82.y
	local v87 = p77.z + v84.z * p83 - p82.z
	local v88 = v_u_6(v85 * v85 + v86 * v86 + v87 * v87)
	local v89 = v_u_1.MIN_AIM < v88 and {
		["x"] = v85 / v88,
		["y"] = v86 / v88,
		["z"] = v87 / v88
	} or v84
	local v90 = v_u_1.dir(p76, p78, v_u_1.baseEuler(p79, p80, p81), v89)
	return v90, v88, v_u_1.angleDeg(v90, v89)
end
function v_u_1.aimDist(p91, p92) -- name: aimDist
	-- upvalues: (copy) v_u_1
	if p91 == nil or (p91 ~= p91 or (p92 ~= p92 or v_u_1.AIM_STALE < p92)) then
		return v_u_1.AIM_DIST_DEFAULT
	end
	local v93 = v_u_1.AIM_DIST_MIN
	local v94 = v_u_1.MAX_LEN
	return math.clamp(p91, v93, v94)
end
function v_u_1.endDist(p95, p96, p97, p98) -- name: endDist
	-- upvalues: (copy) v_u_1
	if p95 == nil then
		p95 = v_u_1.MAX_LEN
	end
	if p97 and (p98 <= v_u_1.ZOMBIE_CONE_DEG and p96 < p95) then
		return p96
	else
		return p95
	end
end
function v_u_1.rigEnd(p99, p100) -- name: rigEnd
	if p100 == nil or (p100 ~= p100 or (p100 <= 0 or p100 >= p99)) then
		return p99
	else
		return p100
	end
end
function v_u_1.fromCFrame(p101) -- name: fromCFrame
	local v102, v103, v104, v105, v106, v107, v108, v109, v110, v111, v112, v113 = p101:GetComponents()
	return {
		v105,
		v106,
		v107,
		v108,
		v109,
		v110,
		v111,
		v112,
		v113
	}, {
		["x"] = v102,
		["y"] = v103,
		["z"] = v104
	}
end
return v_u_1