-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / NvgMask

local v_u_84 = {
	["IMAGE_H"] = 180,
	["IMAGE_W_MIN"] = 128,
	["IMAGE_W_MAX"] = 480,
	["FEATHER"] = 1.4,
	["imageSize"] = function(p1, p2) -- name: imageSize
		-- upvalues: (copy) v_u_84
		local v3 = v_u_84.IMAGE_H
		local v4 = v3 * ((type(p1) ~= "number" or (type(p2) ~= "number" or (p1 <= 0 or (p2 <= 0 or (p1 ~= p1 or p2 ~= p2))))) and 1.7777777777777777 or p1 / p2) + 0.5
		local v5 = math.floor(v4)
		local v6 = v_u_84.IMAGE_W_MIN
		local v7 = v_u_84.IMAGE_W_MAX
		local v8 = math.min(v7, v5)
		return math.max(v6, v8), v3
	end,
	["signedDist"] = function(p9, p10, p11) -- name: signedDist
		local v12 = p9.x + p9.w / 2
		local v13 = p9.y + p9.h / 2
		local v14 = p9.w / 2
		local v15 = p9.h / 2
		if p9.kind ~= "rrect" then
			local v16 = (p10 - v12) / v14
			local v17 = (p11 - v13) / v15
			local v18 = v16 * v16 + v17 * v17
			return (math.sqrt(v18) - 1) * math.min(v14, v15)
		end
		local v19 = p9.corner
		local v20 = math.min(v19, v14, v15)
		local v21 = p10 - v12
		local v22 = math.abs(v21) - (v14 - v20)
		local v23 = p11 - v13
		local v24 = math.abs(v23) - (v15 - v20)
		local v25 = math.max(v22, 0)
		local v26 = math.max(v24, 0)
		local v27 = v25 * v25 + v26 * v26
		local v28 = math.sqrt(v27)
		local v29 = math.max(v22, v24)
		return v28 + math.min(v29, 0) - v20
	end,
	["raster"] = function(p30, p31, p32, p33) -- name: raster
		-- upvalues: (copy) v_u_84
		local v34 = p33 or v_u_84.FEATHER
		local v35 = math.max(0.25, v34)
		local v36 = table.create(p31 * p32, 255)
		local v37 = #p30
		if v37 == 0 then
			return v36
		end
		local v38 = 1 / (v35 * 2)
		local v39 = {}
		local v40 = {}
		local v41 = {}
		local v42 = {}
		local v43 = {}
		local v44 = {}
		local v45 = {}
		for v46, v47 in p30 do
			v40[v46] = v47.kind
			local v48 = v47.x + v47.w / 2
			local v49 = v47.y + v47.h / 2
			v41[v46] = v48
			v42[v46] = v49
			local v50 = v47.w / 2
			local v51 = v47.h / 2
			v43[v46] = v50
			v44[v46] = v51
			local v52 = v47.corner or 0
			local v53 = v47.w / 2
			local v54 = v47.h / 2
			v45[v46] = math.min(v52, v53, v54)
			local v55 = v47.w / 2
			local v56 = v47.h / 2
			v39[v46] = math.min(v55, v56)
		end
		local v57 = 0
		for v58 = 0, p32 - 1 do
			local v59 = v58 + 0.5
			for v60 = 0, p31 - 1 do
				local v61 = v60 + 0.5
				local v62 = (1 / 0)
				for v63 = 1, v37 do
					local v64
					if v40[v63] == "rrect" then
						local v65 = v61 - v41[v63]
						local v66 = math.abs(v65) - (v43[v63] - v45[v63])
						local v67 = v59 - v42[v63]
						local v68 = math.abs(v67) - (v44[v63] - v45[v63])
						local v69 = math.max(v66, 0)
						local v70 = math.max(v68, 0)
						local v71 = v69 * v69 + v70 * v70
						local v72 = math.sqrt(v71)
						local v73 = math.max(v66, v68)
						v64 = v72 + math.min(v73, 0) - v45[v63]
					else
						local v74 = (v61 - v41[v63]) / v43[v63]
						local v75 = (v59 - v42[v63]) / v44[v63]
						local v76 = v74 * v74 + v75 * v75
						v64 = (math.sqrt(v76) - 1) * v39[v63]
					end
					if v64 >= v62 then
						continue
					end
					v62 = v64
				end
				local v77 = 0.5 + v62 * v38
				local v78 = v77 < 0 and 0 or (v77 > 1 and 1 or v77)
				v57 = v57 + 1
				local v79 = v78 * 255 + 0.5
				v36[v57] = math.floor(v79)
			end
		end
		return v36
	end,
	["openShare"] = function(p80) -- name: openShare
		local v81 = #p80
		if v81 == 0 then
			return 0
		end
		local v82 = 0
		for _, v83 in p80 do
			if v83 >= 128 then
				continue
			end
			v82 = v82 + 1
		end
		return v82 / v81
	end
}
return v_u_84