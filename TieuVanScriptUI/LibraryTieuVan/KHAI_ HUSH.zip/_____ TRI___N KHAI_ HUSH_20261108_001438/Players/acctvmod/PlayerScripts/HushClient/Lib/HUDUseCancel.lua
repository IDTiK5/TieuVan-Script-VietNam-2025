-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDUseCancel

local v_u_1 = game:GetService("Players")
local v2 = {}
local v_u_3 = {
	["Bandage"] = true,
	["Use"] = true,
	["Roll"] = true,
	["Unroll"] = true
}
function v2.new(p_u_4, p5) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_6 = p_u_4.UI
	local v7 = p_u_4.Theme.color
	local v_u_8 = p_u_4.cctx
	local v_u_9 = v_u_1.LocalPlayer
	local v_u_10 = {}
	local v_u_11 = {}
	local v_u_12 = 0
	local v_u_13 = ""
	local function v_u_22() -- name: hintText
		-- upvalues: (copy) v_u_8
		local v_u_14 = v_u_8 and v_u_8.controllers
		if v_u_14 then
			v_u_14 = v_u_8.controllers.Input
		end
		local v16, v17 = pcall(function()
			-- upvalues: (copy) v_u_14
			local v15 = v_u_14 and v_u_14.hint
			if v15 then
				v15 = v_u_14.hint("aim")
			end
			return v15
		end)
		local v_u_18 = v_u_8 and v_u_8.controllers
		if v_u_18 then
			v_u_18 = v_u_8.controllers.Input
		end
		local v20, v21 = pcall(function()
			-- upvalues: (copy) v_u_18
			local v19 = v_u_18 and v_u_18.device
			if v19 then
				v19 = v_u_18.device()
			end
			return v19
		end)
		return ((not v20 or type(v21) ~= "string") and "Keyboard" or v21) == "Touch" and "Tap to cancel" or ((not v16 or (type(v17) ~= "string" or v17 == "")) and "Cancel" or v17 .. "  Cancel")
	end
	local v_u_23 = v_u_6.new("TextButton", {
		["Name"] = "CancelChip",
		["AutoButtonColor"] = false,
		["Text"] = "",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["Selectable"] = true,
		["BackgroundColor3"] = v7.raised,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 38),
		["Size"] = UDim2.fromOffset(150, 24)
	}, p5)
	local v_u_24 = Instance.new("UIStroke")
	v_u_24.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	pcall(function()
		-- upvalues: (copy) v_u_24
		v_u_24.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	v_u_24.Color = v7.line
	v_u_24.Thickness = 1
	v_u_24.Parent = v_u_23
	local v_u_25 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["zindex"] = 5,
		["parent"] = v_u_23,
		["color"] = v7.text,
		["size"] = UDim2.fromScale(1, 1)
	})
	local function v_u_30() -- name: busy
		-- upvalues: (copy) v_u_9, (ref) v_u_3
		local v26 = v_u_9.Character
		if v26 then
			v26 = v26:GetAttribute("Action")
		end
		if type(v26) == "string" and v_u_3[v26] then
			return true
		end
		local v27 = v_u_9:GetAttribute("PredAction")
		local v28
		if type(v27) == "string" and v_u_3[v27] == true then
			local v29 = v_u_9
			v28 = os.clock() < (tonumber(v29:GetAttribute("PredActionEnds")) or 0)
		else
			v28 = false
		end
		return v28
	end
	function v_u_10.cancel(p31) -- name: cancel
		-- upvalues: (copy) v_u_30, (ref) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6
		if not v_u_30() or os.clock() - v_u_12 < 0.35 then
			return false
		end
		v_u_12 = os.clock()
		local function v32()
			-- upvalues: (ref) v_u_8
			v_u_8.net.fire("inv.op", {
				["op"] = "cancel"
			})
		end
		pcall(v32)
		v_u_9:SetAttribute("PredAction", nil)
		v_u_9:SetAttribute("PredActionEnds", nil)
		local v33 = v_u_9
		v_u_9:SetAttribute("UseCancelSent", (tonumber(v33:GetAttribute("UseCancelSent")) or 0) + 1)
		v_u_9:SetAttribute("UseCancelLast", string.format("%s@%.2f", p31 or "?", os.clock()))
		local function v34()
			-- upvalues: (ref) v_u_6
			v_u_6.sound("close")
		end
		pcall(v34)
		return true
	end
	v_u_23.Activated:Connect(function()
		-- upvalues: (copy) v_u_10
		v_u_10.cancel("chip")
	end)
	local v35 = v_u_8 and v_u_8.controllers
	if v35 then
		v35 = v_u_8.controllers.Input
	end
	if v35 then
		local v36 = v35.bind
		if type(v36) == "function" then
			for _, v_u_37 in { "aim", "fire", "swap" } do
				local v38 = v35.bind
				local v39, v40 = pcall(v38, v_u_37, function()
					-- upvalues: (copy) v_u_10, (copy) v_u_37
					v_u_10.cancel(v_u_37)
				end)
				if not v39 or type(v40) ~= "function" then
					continue
				end
				table.insert(v_u_11, v40)
			end
		end
	end
	local v_u_47 = v_u_9:GetAttributeChangedSignal("SearchHitAt"):Connect(function()
		-- upvalues: (copy) v_u_8, (copy) v_u_9
		local v_u_41 = v_u_8 and v_u_8.controllers
		if v_u_41 then
			v_u_41 = v_u_8.controllers.InventoryUI
		end
		local v43, v44 = pcall(function()
			-- upvalues: (copy) v_u_41
			local v42 = v_u_41 and v_u_41.isOpen
			if v42 then
				v42 = v_u_41.isOpen()
			end
			return v42
		end)
		if v43 and (v44 and v_u_41.close) then
			local v45 = v_u_41.close
			pcall(v45)
			local v46 = v_u_9
			v_u_9:SetAttribute("SearchHitClosed", (tonumber(v46:GetAttribute("SearchHitClosed")) or 0) + 1)
		end
	end)
	table.insert(v_u_11, function()
		-- upvalues: (copy) v_u_47
		v_u_47:Disconnect()
	end)
	pcall(function()
		-- upvalues: (copy) v_u_8, (copy) v_u_10
		v_u_8.command("usecancel", function()
			-- upvalues: (ref) v_u_10
			return v_u_10.cancel("cmd") and "sent" or "not busy"
		end)
	end)
	function v_u_10.update(p48) -- name: update
		-- upvalues: (ref) v_u_3, (copy) v_u_8, (ref) v_u_13, (copy) v_u_6, (copy) v_u_25, (copy) v_u_22, (copy) p_u_4, (copy) v_u_23
		local v49
		if type(p48) == "string" then
			v49 = v_u_3[p48] == true
		else
			v49 = false
		end
		if v49 then
			local v_u_50 = v_u_8 and v_u_8.controllers
			if v_u_50 then
				v_u_50 = v_u_8.controllers.Input
			end
			local v52, v53 = pcall(function()
				-- upvalues: (copy) v_u_50
				local v51 = v_u_50 and v_u_50.device
				if v51 then
					v51 = v_u_50.device()
				end
				return v51
			end)
			local v54 = (not v52 or type(v53) ~= "string") and "Keyboard" or v53
			local v55 = p48 .. "|" .. v54
			if v55 ~= v_u_13 then
				v_u_13 = v55
				v_u_6.setText(v_u_25, (v_u_22()))
			end
			local v56
			if v54 == "Touch" then
				local v57 = UDim2.fromOffset
				local v58 = 170
				local v59
				if p_u_4.Theme.isPhone() then
					v59 = p_u_4.Theme.touch(40)
				else
					local v60 = p_u_4.Theme.touch
					v59 = math.max(40, v60(40))
				end
				v56 = v57(v58, v59)
			else
				v56 = UDim2.fromOffset(150, 24)
			end
			if v_u_23.Size ~= v56 then
				v_u_23.Size = v56
			end
		else
			v_u_13 = ""
		end
		if v_u_23.Visible ~= v49 then
			v_u_23.Visible = v49
		end
	end
	function v_u_10.destroy() -- name: destroy
		-- upvalues: (copy) v_u_11, (copy) v_u_23
		for _, v61 in v_u_11 do
			pcall(v61)
		end
		table.clear(v_u_11)
		v_u_23:Destroy()
	end
	return v_u_10
end
return v2