-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmCodes

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(script.Parent:WaitForChild("HushUI"))
local v_u_6 = v_u_5.Theme
local v_u_7 = v_u_6.color
local v8 = {}
local v_u_9 = v1.LocalPlayer
local v_u_10 = nil
local v_u_11 = nil
local function v_u_26(p12) -- name: itemName
	-- upvalues: (ref) v_u_10, (copy) v_u_3
	if v_u_10 == nil then
		local function v13()
			-- upvalues: (ref) v_u_3
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")))
		end
		local v14, v15 = pcall(v13)
		if not v14 or type(v15) ~= "table" then
			v15 = false
		end
		v_u_10 = v15
	end
	local v16 = v_u_10 or nil
	if v16 == nil then
		return p12
	else
		local v17 = v16.get
		local v18, v19 = pcall(v17, p12)
		if v18 and type(v19) == "table" then
			if v19.name then
				local v20 = v19.name
				p12 = tostring(v20)
			end
			local v21 = v16.shownRarity
			local v22, v23 = pcall(v21, v19)
			local v24
			if v22 and type(v23) == "number" then
				local v25 = v16.RARITY_NAMES
				if type(v25) == "table" then
					v24 = v16.RARITY_NAMES[v23]
				else
					v24 = nil
				end
			else
				v24 = nil
			end
			if type(v24) == "string" then
				return p12 .. " (" .. v24 .. ")"
			else
				return p12
			end
		else
			return p12
		end
	end
end
local function v_u_31(p27) -- name: spanText
	local v28 = math.floor(p27)
	local v29 = math.max(0, v28)
	if v29 >= 86400 then
		return ("%d d %d h"):format(v29 // 86400, v29 % 86400 // 3600)
	end
	if v29 >= 3600 then
		return ("%d h %d min"):format(v29 // 3600, v29 % 3600 // 60)
	end
	local v30 = v29 // 60
	return ("%d min"):format((math.max(1, v30)))
end
function v8.build(p_u_32) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (ref) v_u_11, (copy) v_u_26, (copy) v_u_9, (ref) v_u_10, (copy) v_u_31, (copy) v_u_2
	local v_u_33 = p_u_32.body
	local v_u_34 = p_u_32.api
	local v_u_35 = true
	p_u_32.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_35
		v_u_35 = false
	end)
	local v_u_36 = require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("CodesRules")))
	local v_u_37 = v_u_36.TUNE
	local v38 = v_u_4:IsStudio()
	local v_u_39 = 0
	local function v42(p40) -- name: section
		-- upvalues: (ref) v_u_5, (copy) v_u_33, (ref) v_u_7, (ref) v_u_39
		local v41 = v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_33,
			["text"] = p40,
			["color"] = v_u_7.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_39 = v_u_39 + 1
		v41.LayoutOrder = v_u_39
		return v41
	end
	local function v46(p43, p44) -- name: note
		-- upvalues: (ref) v_u_5, (copy) v_u_33, (ref) v_u_7, (ref) v_u_39
		local v45 = v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_33,
			["text"] = p43,
			["color"] = p44 or v_u_7.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_39 = v_u_39 + 1
		v45.LayoutOrder = v_u_39
		return v45
	end
	local function v_u_47(_) end
	local v_u_48 = false
	local v_u_49 = {}
	local v_u_50 = {}
	local v_u_51 = 0
	local v_u_52 = v_u_37.codesMax
	local v_u_53 = nil
	local v_u_54 = {}
	local v_u_55 = {}
	local function v_u_56(_) end
	local v_u_57 = ""
	v42("Redeem codes  \194\183  all players")
	v46("A code gives its rewards to every player who types it in SETTINGS, once per player. The codes live on the servers only: this list is the one place a code is shown. A new code works within " .. v_u_37.pollSeconds .. " seconds on every server.")
	local v_u_58 = {}
	local function v73(p59) -- name: inputRow
		-- upvalues: (ref) v_u_5, (ref) v_u_39, (ref) v_u_6, (copy) v_u_33, (copy) p_u_32, (copy) v_u_58
		local v60 = v_u_5.new
		local v61 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil
		}
		local v62 = v_u_39 + 1
		v61.Name = "CodesRow" .. tostring(v62)
		v61.Size = UDim2.new(1, 0, 0, v_u_6.touch(34))
		local v63 = v60("Frame", v61, v_u_33)
		v_u_39 = v_u_39 + 1
		v63.LayoutOrder = v_u_39
		v_u_5.layout(v63, "h", 6)
		local v64 = 0
		for _, v65 in p59 do
			v64 = v64 + v65.weight
		end
		local v66 = p_u_32.inner - (#p59 - 1) * 6
		for v67, v68 in p59 do
			local v69 = v66 * v68.weight / v64
			local v70 = math.floor(v69)
			local v71, v72 = v_u_5.input({
				["parent"] = v63,
				["name"] = "Codes_" .. v68.key,
				["size"] = UDim2.fromOffset(v70, v_u_6.touch(34)),
				["placeholder"] = v68.placeholder
			})
			v71.LayoutOrder = v67
			v_u_58[v68.key] = v72
		end
	end
	local function v76(p74) -- name: caption
		-- upvalues: (ref) v_u_5, (copy) v_u_33, (ref) v_u_7, (ref) v_u_39
		local v75 = v_u_5.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v_u_33,
			["text"] = p74,
			["color"] = v_u_7.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v_u_39 = v_u_39 + 1
		v75.LayoutOrder = v_u_39
	end
	v42("Create a code")
	v76("CODE  (4 to 24 letters and digits, spaces and dashes are ignored)")
	v73({
		{
			["key"] = "code",
			["placeholder"] = "Code text",
			["weight"] = 1
		}
	})
	v76("REWARDS  (leave empty what you do not want)")
	v73({
		{
			["key"] = "cash",
			["placeholder"] = "Cash, 1 to 5,000,000",
			["weight"] = 1
		},
		{
			["key"] = "bm",
			["placeholder"] = "Extra Blackmarket listings",
			["weight"] = 1
		}
	})
	v76("ITEMS  (up to " .. v_u_37.itemKinds .. ": type a name, an id, a type or a rarity, then click the item)")
	if v_u_11 == nil then
		local function v77()
			-- upvalues: (ref) v_u_3
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("AdminItems", 5)))
		end
		local v78, v79 = pcall(v77)
		if not v78 or type(v79) ~= "table" then
			v79 = false
		end
		v_u_11 = v79
	end
	local v_u_80 = v_u_11 or nil
	local v_u_81
	if v_u_80 == nil then
		v_u_81 = nil
	else
		v_u_81 = v_u_80.codeOpts()
	end
	local v_u_82 = {}
	local v_u_83 = nil
	local v_u_84 = nil
	local v_u_85 = {}
	local v_u_86 = nil
	local function v_u_87() end
	local v_u_88 = {}
	local v89 = v_u_5.new("Frame", {
		["Name"] = "CodesItemSearchRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(34))
	}, v_u_33)
	v_u_39 = v_u_39 + 1
	v89.LayoutOrder = v_u_39
	v_u_5.layout(v89, "h", 6)
	local v90 = (p_u_32.inner - 12) / 4
	local v91 = math.floor(v90)
	local v92, v_u_93 = v_u_5.input({
		["parent"] = nil,
		["name"] = "Codes_itemSearch",
		["size"] = nil,
		["placeholder"] = "Item: type a name or id, e.g. 9mm or mythic weapon",
		["parent"] = v89,
		["size"] = UDim2.fromOffset(p_u_32.inner - 12 - v91 * 2, v_u_6.touch(34))
	})
	v92.LayoutOrder = 1
	local function v_u_94() end
	local function v_u_95() end
	local function v96()
		-- upvalues: (ref) v_u_94
		v_u_94()
	end
	local v97, v_u_98 = v_u_5.button({
		["parent"] = nil,
		["text"] = "All types",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v89,
		["width"] = v91,
		["onClick"] = v96,
		["maxTextWidth"] = (v91 or 160) - 12
	})
	v97.Name = "Codes_Cat"
	v97.LayoutOrder = 2
	local function v99()
		-- upvalues: (ref) v_u_95
		v_u_95()
	end
	local v100, v_u_101 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Any rarity",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v89,
		["width"] = v91,
		["onClick"] = v99,
		["maxTextWidth"] = (v91 or 160) - 12
	})
	v100.Name = "Codes_Rar"
	v100.LayoutOrder = 3
	local v102 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesItemCounts",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_33,
		["text"] = v_u_80 == nil and "" or v_u_80.countsText("codes"),
		["color"] = v_u_7.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v102.LayoutOrder = v_u_39
	v102.RichText = false
	local v_u_103 = v_u_5.new("Frame", {
		["Name"] = "Codes_Suggest",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_33)
	v_u_39 = v_u_39 + 1
	v_u_103.LayoutOrder = v_u_39
	v_u_5.layout(v_u_103, "v", 4)
	local v_u_104 = v_u_5.new("Frame", {
		["Name"] = "Codes_Items",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_33)
	v_u_39 = v_u_39 + 1
	v_u_104.LayoutOrder = v_u_39
	v_u_5.layout(v_u_104, "v", 6)
	local function v_u_107() -- name: currentFilter
		-- upvalues: (copy) v_u_80, (ref) v_u_83, (ref) v_u_84
		local v105 = {}
		if v_u_80 ~= nil then
			local v106 = v_u_80.facets()
			if v_u_83 ~= nil and v106.cats[v_u_83] ~= nil then
				v105.cat = v106.cats[v_u_83].cat
			end
			if v_u_84 ~= nil and v106.rarities[v_u_84] ~= nil then
				v105.rarity = v106.rarities[v_u_84].r
			end
		end
		return v105
	end
	local function v_u_115() -- name: paintFilterButtons
		-- upvalues: (copy) v_u_80, (copy) v_u_98, (ref) v_u_83, (copy) v_u_101, (ref) v_u_84
		if v_u_80 ~= nil then
			local v108 = v_u_80.facets()
			local v109 = v_u_98.setText
			local v110
			if v_u_83 == nil or v108.cats[v_u_83] == nil then
				v110 = "All types"
			else
				local v111 = v108.cats[v_u_83].label
				v110 = "Type: " .. tostring(v111)
			end
			v109(v110)
			local v112 = v_u_101.setText
			local v113
			if v_u_84 == nil or v108.rarities[v_u_84] == nil then
				v113 = "Any rarity"
			else
				local v114 = v108.rarities[v_u_84].name
				v113 = "Rarity: " .. tostring(v114)
			end
			v112(v113)
			v_u_98.setKind(v_u_83 == nil and "secondary" or "primary")
			v_u_101.setKind(v_u_84 == nil and "secondary" or "primary")
		end
	end
	local function v_u_152() -- name: repaintSuggest
		-- upvalues: (copy) v_u_103, (ref) v_u_86, (ref) v_u_85, (copy) p_u_32, (copy) v_u_88, (ref) v_u_5, (ref) v_u_7
		for _, v116 in v_u_103:GetChildren() do
			if not v116:IsA("GuiObject") then
				continue
			end
			v116:Destroy()
		end
		local v117 = v_u_86
		local v118
		if type(v117) == "table" then
			local v119 = v_u_86.blocked
			v118 = type(v119) ~= "table" and {} or v_u_86.blocked
		else
			v118 = {}
		end
		v_u_103.Visible = #v_u_85 > 0 and true or #v118 > 0
		local v120 = 0
		for _, v121 in v_u_85 do
			v120 = v120 + 1
			local v_u_122 = v121.id
			local v123 = v_u_103
			local v124 = v121.name
			local v125 = tostring(v124)
			local v126 = v121.id
			local v127 = tostring(v126)
			local v128 = string.upper
			local v129 = v121.rarityName or ""
			local v130 = v128((tostring(v129)))
			local v131 = v121.label or ""
			local v132 = ("%s  \194\183  %s  \194\183  %s %s"):format(v125, v127, v130, (tostring(v131)))
			local v133 = p_u_32.inner
			local function v134()
				-- upvalues: (ref) v_u_88, (copy) v_u_122
				v_u_88.pickItem(v_u_122)
			end
			local v135, _ = v_u_5.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v123,
				["text"] = v132,
				["width"] = v133,
				["onClick"] = v134,
				["maxTextWidth"] = (v133 or 160) - 12
			})
			local v136 = v121.id
			v135.Name = "Codes_Pick_" .. tostring(v136)
			v135.LayoutOrder = v120
		end
		local v137 = v_u_86
		if type(v137) == "table" then
			local v138 = v_u_86.more
			if type(v138) == "number" and v_u_86.more > 0 then
				v120 = v120 + 1
				local v139 = v_u_5.label({
					["parent"] = nil,
					["name"] = "Codes_More",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v_u_103,
					["text"] = ("+%d more. Type more letters or use the filters."):format(v_u_86.more),
					["color"] = v_u_7.muted,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
				v139.RichText = false
				v139.LayoutOrder = v120
			end
		end
		for _, v140 in v118 do
			v120 = v120 + 1
			local v141 = v_u_5.label
			local v142 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v_u_103
			}
			local v143 = v140.id
			v142.name = "Codes_Blocked_" .. tostring(v143)
			local v144 = v140.name
			local v145 = tostring(v144)
			local v146 = v140.reason
			v142.text = ("%s  \194\183  %s"):format(v145, (tostring(v146)))
			v142.color = v_u_7.muted
			v142.size = UDim2.new(1, 0, 0, 0)
			local v147 = v141(v142)
			v147.RichText = false
			v147.LayoutOrder = v120
		end
		local v148 = v_u_86
		if type(v148) == "table" then
			local v149 = v_u_86.blockedTotal
			if type(v149) == "number" and v_u_86.blockedTotal > #v118 then
				local v150 = v120 + 1
				local v151 = v_u_5.label({
					["parent"] = nil,
					["name"] = "Codes_BlockedMore",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v_u_103,
					["text"] = ("+%d more that are not possible."):format(v_u_86.blockedTotal - #v118),
					["color"] = v_u_7.muted,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
				v151.RichText = false
				v151.LayoutOrder = v150
			end
		end
	end
	local function v_u_156() -- name: runSearch
		-- upvalues: (copy) v_u_80, (copy) v_u_107, (ref) v_u_85, (ref) v_u_86, (copy) v_u_93, (copy) v_u_152
		if v_u_80 ~= nil then
			local v153 = v_u_107()
			local v154, v155 = v_u_80.search(v_u_93.Text, {
				["tool"] = "codes",
				["cat"] = nil,
				["rarity"] = nil,
				["max"] = nil,
				["cat"] = v153.cat,
				["rarity"] = v153.rarity,
				["max"] = v_u_80.SEARCH_MAX
			})
			v_u_85 = v154
			v_u_86 = v155
			v_u_152()
		end
	end
	v_u_98.setText("All types")
	v_u_94 = function()
		-- upvalues: (copy) v_u_80, (ref) v_u_83, (copy) v_u_115, (copy) v_u_156
		if v_u_80 ~= nil then
			local v157 = v_u_80.facets()
			local v158 = (v_u_83 or 0) + 1
			if #v157.cats < v158 then
				v158 = nil
			end
			v_u_83 = v158
			v_u_115()
			v_u_156()
		end
	end
	v_u_95 = function()
		-- upvalues: (copy) v_u_80, (ref) v_u_84, (copy) v_u_115, (copy) v_u_156
		if v_u_80 ~= nil then
			local v159 = v_u_80.facets()
			local v160 = (v_u_84 or 0) + 1
			if #v159.rarities < v160 then
				v160 = nil
			end
			v_u_84 = v160
			v_u_115()
			v_u_156()
		end
	end
	v_u_93:GetPropertyChangedSignal("Text"):Connect(v_u_156)
	local function v_u_178()
		-- upvalues: (copy) v_u_104, (copy) v_u_82, (ref) v_u_5, (ref) v_u_7, (ref) v_u_26, (ref) v_u_6, (copy) p_u_32, (copy) v_u_81, (copy) v_u_37, (ref) v_u_87, (copy) v_u_88
		for _, v161 in v_u_104:GetChildren() do
			if not v161:IsA("GuiObject") then
				continue
			end
			v161:Destroy()
		end
		for v162, v_u_163 in v_u_82 do
			local v_u_164 = v_u_163.id
			local v165 = v_u_5.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Codes_Item_" .. v_u_164,
				["BackgroundColor3"] = v_u_7.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = v162
			}, v_u_104)
			v_u_5.stroke(v165, v_u_7.line)
			v_u_5.pad(v165, {
				8,
				8,
				6,
				8
			})
			v_u_5.layout(v165, "v", 4)
			local v166 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v165,
				["text"] = v_u_26(v_u_164) .. "  \194\183  " .. v_u_164,
				["color"] = v_u_7.text,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v166.RichText = false
			v166.LayoutOrder = 1
			local v167 = v_u_5.new("Frame", {
				["Name"] = "Row",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(34))
			}, v165)
			v_u_5.layout(v167, "h", 6)
			local v168 = v_u_5.input
			local v169 = {
				["parent"] = v167,
				["name"] = "Codes_N_" .. v_u_164,
				["text"] = v_u_163.n,
				["size"] = UDim2.fromOffset(p_u_32.inner - 16 - 96 - 6, v_u_6.touch(34))
			}
			local v170 = "Count, at most %d"
			local v171
			if v_u_81 == nil then
				v171 = nil
			else
				v171 = v_u_81.stackOf(v_u_164)
			end
			local v172 = v_u_37.itemMax
			local v173 = (type(v171) ~= "number" and 1 or v171) * v_u_37.itemPieces
			v169.placeholder = v170:format((math.min(v172, v173)))
			local v174, v_u_175 = v168(v169)
			v174.LayoutOrder = 1
			v_u_175:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (copy) v_u_163, (copy) v_u_175, (ref) v_u_87
				v_u_163.n = v_u_175.Text
				v_u_87()
			end)
			local v176 = {
				["parent"] = nil,
				["text"] = "Remove",
				["kind"] = "ghost",
				["height"] = 32,
				["width"] = 96,
				["onClick"] = nil,
				["maxTextWidth"] = 84,
				["parent"] = v167,
				["onClick"] = function()
					-- upvalues: (ref) v_u_88, (copy) v_u_164
					v_u_88.removeItem(v_u_164)
				end
			}
			local v177, _ = v_u_5.button(v176)
			v177.Name = "Codes_Remove_" .. v_u_164
			v177.LayoutOrder = 2
		end
	end
	v76("WINDOW AND LIMIT  (empty = starts now, never ends, unlimited)")
	v73({
		{
			["key"] = "starts",
			["placeholder"] = "Starts in hours",
			["weight"] = 1
		},
		{
			["key"] = "hours",
			["placeholder"] = "Ends after hours",
			["weight"] = 1
		},
		{
			["key"] = "uses",
			["placeholder"] = "Max uses",
			["weight"] = 1
		}
	})
	v76("NOTE  (only you see it)")
	v73({
		{
			["key"] = "note",
			["placeholder"] = "e.g. launch gift for the Blackmarket",
			["weight"] = 1
		}
	})
	local v_u_179 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesPreview",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_33,
		["color"] = v_u_7.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_179.LayoutOrder = v_u_39
	v_u_179.RichText = false
	local v_u_180 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_33,
		["color"] = v_u_7.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_180.LayoutOrder = v_u_39
	v_u_180.Visible = false
	local v_u_181 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesOk",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_33,
		["color"] = v_u_7.success,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_181.LayoutOrder = v_u_39
	v_u_181.Visible = false
	local function v_u_185() -- name: draft
		-- upvalues: (copy) v_u_58, (copy) v_u_82
		local v182 = {}
		for _, v183 in v_u_82 do
			local v184 = {
				["id"] = v183.id,
				["n"] = v183.n
			}
			table.insert(v182, v184)
		end
		return {
			["code"] = v_u_58.code.Text,
			["cash"] = v_u_58.cash.Text,
			["bmListings"] = v_u_58.bm.Text,
			["items"] = v182,
			["startsInHours"] = v_u_58.starts.Text,
			["endsAfterHours"] = v_u_58.hours.Text,
			["maxUses"] = v_u_58.uses.Text,
			["note"] = v_u_58.note.Text
		}
	end
	local function v_u_203(p186) -- name: weightOf
		-- upvalues: (ref) v_u_10, (ref) v_u_3
		local v187 = false
		local v188 = 0
		if v_u_10 == nil then
			local function v189()
				-- upvalues: (ref) v_u_3
				return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")))
			end
			local v190, v191 = pcall(v189)
			if not v190 or type(v191) ~= "table" then
				v191 = false
			end
			v_u_10 = v191
		end
		local v192 = v_u_10 or nil
		if v192 ~= nil and type(p186) == "table" then
			local v193 = p186.items
			if type(v193) == "table" then
				for _, v194 in p186.items do
					local v195 = v192.get
					local v196 = v194.id
					local v197, v198 = pcall(v195, v196)
					if not v197 or type(v198) ~= "table" then
						continue
					end
					local v199 = v192.shownRarity
					local v200, v201 = pcall(v199, v198)
					v187 = v200 and (type(v201) == "number" and v201 >= 5) and true or v187
					local v202 = v198.value
					v188 = v188 + (type(v202) ~= "number" and 0 or v198.value) * v194.n
				end
			end
		end
		return v187 or v188 >= 250000, v188
	end
	local function v_u_209()
		-- upvalues: (copy) v_u_36, (copy) v_u_185, (copy) v_u_81, (ref) v_u_26, (copy) v_u_203, (ref) v_u_31, (copy) v_u_179, (ref) v_u_7
		local v204, v205 = v_u_36.makeRecord(v_u_185(), os.time(), v_u_81)
		if v204 then
			local v206 = v205.rec
			local v207 = "Gives: " .. v_u_36.summary(v206.rewards, v_u_26) .. "."
			local _, v208 = v_u_203(v206.rewards)
			if v208 > 0 then
				v207 = v207 .. " Items worth $" .. v_u_36.commas(v208) .. " for every player."
			end
			if v206.startsAt then
				v207 = v207 .. " Starts in " .. v_u_31(v206.startsAt - os.time()) .. "."
			end
			if v206.endsAt then
				v207 = v207 .. " Ends " .. (v206.startsAt and "" or "in ") .. v_u_31(v206.endsAt - os.time()) .. (v206.startsAt and " after the start." or ".")
			end
			if v206.maxUses then
				v207 = v207 .. (" At most %d redemptions."):format(v206.maxUses)
			end
			v_u_179.Text = v207
			v_u_179.TextColor3 = v_u_7.text
		else
			v_u_179.Text = tostring(v205)
			v_u_179.TextColor3 = v_u_7.muted
		end
	end
	local v_u_210 = nil
	local v_u_211 = ""
	local v_u_212 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesConfirm",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_33,
		["color"] = v_u_7.accent,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_212.LayoutOrder = v_u_39
	v_u_212.RichText = false
	v_u_212.Visible = false
	local v_u_213 = nil
	local function v214() -- name: onChange
		-- upvalues: (ref) v_u_53, (ref) v_u_210, (ref) v_u_213, (ref) v_u_48, (copy) v_u_212, (ref) v_u_209
		v_u_53 = nil
		v_u_210 = nil
		if v_u_213 ~= nil and not v_u_48 then
			v_u_213.setText("Create code")
		end
		v_u_212.Visible = false
		v_u_209()
	end
	local v_u_215 = v_u_209
	local v_u_216 = v_u_210
	local v_u_217 = v_u_213
	local v_u_218 = v_u_35
	local v219 = v_u_39
	for _, v220 in v_u_58 do
		v220:GetPropertyChangedSignal("Text"):Connect(v214)
	end
	local v_u_221 = v214
	local function v_u_225(p222) -- name: setBusy
		-- upvalues: (ref) v_u_48, (ref) v_u_217, (copy) v_u_55, (ref) v_u_9, (ref) v_u_49
		v_u_48 = p222
		if v_u_217 then
			v_u_217.setEnabled(not p222)
		end
		for _, v223 in v_u_55 do
			v223.setEnabled(not p222)
		end
		local v224 = v_u_48
		v_u_9:SetAttribute("FilmCodes", ("%d|%s"):format(#v_u_49, (tostring(v224))))
	end
	local function v_u_232(p226) -- name: apply
		-- upvalues: (ref) v_u_49, (ref) v_u_50, (ref) v_u_51, (ref) v_u_52, (copy) v_u_37, (ref) v_u_9, (ref) v_u_48, (ref) v_u_56
		if type(p226) == "table" then
			local v227 = p226.items
			if type(v227) == "table" then
				v_u_49 = p226.items
				local v228 = p226.audit
				v_u_50 = type(v228) ~= "table" and {} or p226.audit
				local v229 = p226.count
				v_u_51 = tonumber(v229) or #v_u_49
				local v230 = p226.max
				v_u_52 = tonumber(v230) or v_u_37.codesMax
				local v231 = v_u_48
				v_u_9:SetAttribute("FilmCodes", ("%d|%s"):format(#v_u_49, (tostring(v231))))
				v_u_56()
				return
			end
		end
	end
	local function v_u_264() -- name: doCreate
		-- upvalues: (ref) v_u_48, (copy) v_u_185, (copy) v_u_36, (copy) v_u_81, (ref) v_u_216, (ref) v_u_217, (copy) v_u_212, (copy) v_u_180, (ref) v_u_9, (copy) v_u_203, (copy) v_u_82, (ref) v_u_211, (ref) v_u_218, (ref) v_u_53, (ref) v_u_2, (copy) v_u_181, (copy) v_u_225, (copy) v_u_34, (copy) v_u_58, (copy) v_u_93, (ref) v_u_83, (ref) v_u_84, (copy) v_u_115, (ref) v_u_178, (copy) v_u_232
		if v_u_48 then
			return
		else
			local v233 = v_u_185()
			local v234, v235 = v_u_36.makeRecord(v233, os.time(), v_u_81)
			if v234 then
				local v236, v237 = v_u_203(v235.rec.rewards)
				if v236 then
					local v238 = {}
					for _, v239 in v_u_82 do
						local v240 = v239.id .. ":" .. v239.n
						table.insert(v238, v240)
					end
					local v241 = table.concat
					local v242 = {}
					local v243 = v233.code
					local v244 = tostring(v243)
					local v245 = v233.cash
					local v246 = tostring(v245)
					local v247 = v233.bmListings
					local v248 = tostring(v247)
					local v249 = v233.startsInHours
					local v250 = tostring(v249)
					local v251 = v233.endsAfterHours
					local v252 = tostring(v251)
					local v253 = v233.maxUses
					__set_list(v242, 1, {v244, v246, v248, v250, v252, tostring(v253), table.concat(v238, ",")})
					local v254 = v241(v242, "|")
					local v_u_255 = os.clock()
					local v256 = v_u_216
					if v256 == nil or (v_u_255 - v256 > 5 or v_u_211 ~= v254) then
						v_u_216 = v_u_255
						v_u_211 = v254
						v_u_217.setText("PRESS AGAIN TO CREATE")
						v_u_212.Text = ("PRESS AGAIN TO CREATE: every player who redeems this code gets items worth $%s."):format(v_u_36.commas(v237))
						v_u_212.Visible = true
						v_u_180.Text = ""
						v_u_180.Visible = false
						v_u_9:SetAttribute("FilmCodesError", "")
						task.delay(5.2, function()
							-- upvalues: (ref) v_u_218, (ref) v_u_216, (copy) v_u_255, (ref) v_u_217, (ref) v_u_48, (ref) v_u_212
							if v_u_218 and v_u_216 == v_u_255 then
								v_u_216 = nil
								if v_u_217 ~= nil and not v_u_48 then
									v_u_217.setText("Create code")
								end
								v_u_212.Visible = false
							end
						end)
						return
					end
					if v_u_255 - v256 < 0.4 then
						return
					end
					v_u_216 = nil
					if v_u_217 ~= nil and not v_u_48 then
						v_u_217.setText("Create code")
					end
					v_u_212.Visible = false
				end
				v_u_53 = v_u_53 or v_u_2:GenerateGUID(false)
				v233.nonce = v_u_53
				v_u_180.Text = ""
				v_u_180.Visible = false
				v_u_9:SetAttribute("FilmCodesError", "")
				v_u_181.Visible = false
				v_u_225(true)
				v_u_217.setText("Creating...")
				v_u_34.call("codes.create", {
					["draft"] = v233
				}, function(p257)
					-- upvalues: (ref) v_u_225, (ref) v_u_217, (ref) v_u_58, (ref) v_u_82, (ref) v_u_93, (ref) v_u_83, (ref) v_u_84, (ref) v_u_115, (ref) v_u_178, (ref) v_u_53, (ref) v_u_181, (ref) v_u_232, (ref) v_u_180, (ref) v_u_9
					v_u_225(false)
					v_u_217.setText("Create code")
					if p257 and p257.ok then
						for _, v258 in v_u_58 do
							v258.Text = ""
						end
						table.clear(v_u_82)
						v_u_93.Text = ""
						v_u_83 = nil
						v_u_84 = nil
						v_u_115()
						v_u_178()
						v_u_53 = nil
						local v259 = v_u_181
						local v260 = p257.msg or "Created."
						v259.Text = tostring(v260)
						v_u_181.Visible = true
						v_u_232(p257.data)
					else
						local v261 = p257 and p257.msg or "The server did not answer."
						local v262 = tostring(v261) or ""
						v_u_180.Text = v262
						v_u_180.Visible = v262 ~= ""
						v_u_9:SetAttribute("FilmCodesError", v262)
					end
				end)
			else
				v_u_216 = nil
				if v_u_217 ~= nil and not v_u_48 then
					v_u_217.setText("Create code")
				end
				v_u_212.Visible = false
				local v263 = tostring(v235) or ""
				v_u_180.Text = v263
				v_u_180.Visible = v263 ~= ""
				v_u_9:SetAttribute("FilmCodesError", v263)
			end
		end
	end
	local v265 = p_u_32.inner
	local v266, v267 = v_u_5.button({
		["parent"] = nil,
		["text"] = "Create code",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_33,
		["width"] = v265,
		["onClick"] = v_u_264,
		["maxTextWidth"] = (v265 or 160) - 12
	})
	v_u_213 = v267
	v266.Name = "CodesCreate"
	v_u_39 = v219 + 1
	v266.LayoutOrder = v_u_39
	v42("Codes  \194\183  newest first")
	local v268 = v_u_5.new("Frame", {
		["Name"] = "CodesHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(32))
	}, v_u_33)
	v_u_39 = v_u_39 + 1
	v268.LayoutOrder = v_u_39
	v_u_5.layout(v268, "h", 6)
	local v_u_269 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesCount",
		["text"] = "...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v268,
		["color"] = v_u_7.text2,
		["size"] = UDim2.fromOffset(p_u_32.inner - 126, v_u_6.touch(32))
	})
	v_u_269.LayoutOrder = 1
	local v270 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v268,
		["onClick"] = function()
			-- upvalues: (copy) v_u_180, (ref) v_u_9, (ref) v_u_47
			v_u_180.Text = ""
			v_u_180.Visible = false
			v_u_9:SetAttribute("FilmCodesError", "")
			v_u_47(false)
		end
	}
	local v271, _ = v_u_5.button(v270)
	v271.Name = "CodesRefresh"
	v271.LayoutOrder = 2
	local v_u_272 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesListError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_33,
		["color"] = v_u_7.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_272.LayoutOrder = v_u_39
	v_u_272.Visible = false
	local v_u_273 = v_u_5.new("Frame", {
		["Name"] = "CodesList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_33)
	v_u_39 = v_u_39 + 1
	v_u_273.LayoutOrder = v_u_39
	v_u_5.layout(v_u_273, "v", 8)
	local v_u_274 = v_u_5.label({
		["parent"] = nil,
		["name"] = "CodesEmpty",
		["text"] = "No codes yet.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_273,
		["color"] = v_u_7.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_274.LayoutOrder = 0
	v42("Audit  \194\183  who did what")
	local v_u_275 = v_u_5.label({
		["parent"] = nil,
		["name"] = "AuditText",
		["text"] = "Nothing yet.",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_33,
		["color"] = v_u_7.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_39 = v_u_39 + 1
	v_u_275.LayoutOrder = v_u_39
	v_u_275.RichText = false
	local v_u_276 = {
		["live"] = v_u_7.success,
		["disabled"] = v_u_7.muted,
		["usedup"] = v_u_7.danger,
		["expired"] = v_u_7.danger,
		["notstarted"] = v_u_7.accent
	}
	local v_u_277 = {
		["live"] = "LIVE",
		["disabled"] = "DISABLED",
		["usedup"] = "USED UP",
		["expired"] = "EXPIRED",
		["notstarted"] = "NOT STARTED"
	}
	local function v_u_286(p278, p279, p280) -- name: doSet
		-- upvalues: (ref) v_u_48, (copy) v_u_225, (copy) v_u_34, (copy) v_u_272, (copy) v_u_232, (copy) v_u_181, (ref) v_u_56
		if not v_u_48 then
			v_u_225(true)
			p280.setText(p279 and "Disabling..." or "Enabling...")
			v_u_34.call("codes.set", {
				["id"] = p278.id,
				["disabled"] = p279
			}, function(p281)
				-- upvalues: (ref) v_u_225, (ref) v_u_272, (ref) v_u_232, (ref) v_u_181, (ref) v_u_56
				v_u_225(false)
				if p281 and p281.ok then
					v_u_272.Visible = false
					v_u_232(p281.data)
					local v282 = v_u_181
					local v283 = p281.msg or "Done."
					v282.Text = tostring(v283)
					v_u_181.Visible = true
				else
					local v284 = v_u_272
					local v285 = p281 and p281.msg or "The server did not answer."
					v284.Text = tostring(v285)
					v_u_272.Visible = true
					v_u_56(true)
				end
			end)
		end
	end
	local function v_u_294(p287, p288) -- name: doDelete
		-- upvalues: (ref) v_u_48, (copy) v_u_225, (copy) v_u_34, (copy) v_u_272, (copy) v_u_232, (copy) v_u_181, (ref) v_u_56
		if not v_u_48 then
			v_u_225(true)
			p288.setText("Deleting...")
			v_u_34.call("codes.delete", {
				["id"] = p287.id
			}, function(p289)
				-- upvalues: (ref) v_u_225, (ref) v_u_272, (ref) v_u_232, (ref) v_u_181, (ref) v_u_56
				v_u_225(false)
				if p289 and p289.ok then
					v_u_272.Visible = false
					v_u_232(p289.data)
					local v290 = v_u_181
					local v291 = p289.msg or "Deleted."
					v290.Text = tostring(v291)
					v_u_181.Visible = true
				else
					local v292 = v_u_272
					local v293 = p289 and p289.msg or "The server did not answer."
					v292.Text = tostring(v293)
					v_u_272.Visible = true
					v_u_56(true)
				end
			end)
		end
	end
	local function v_u_365(p_u_295, p296) -- name: buildCard
		-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_273, (copy) v_u_277, (copy) v_u_276, (ref) v_u_6, (copy) p_u_32, (copy) v_u_54, (copy) v_u_286, (copy) v_u_294, (ref) v_u_56, (ref) v_u_218, (copy) v_u_55, (ref) v_u_48
		local v297 = v_u_5.new
		local v298 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil
		}
		local v299 = p_u_295.id
		v298.Name = "Code_" .. tostring(v299)
		v298.BackgroundColor3 = v_u_7.raised
		v298.Size = UDim2.new(1, 0, 0, 0)
		v298.AutomaticSize = Enum.AutomaticSize.Y
		v298.LayoutOrder = p296
		local v300 = v297("Frame", v298, v_u_273)
		local v301 = v_u_5.stroke
		local v302
		if p_u_295.state == "live" then
			v302 = v_u_7.accentDim
		else
			v302 = v_u_7.line
		end
		v301(v300, v302)
		v_u_5.pad(v300, {
			10,
			10,
			8,
			10
		})
		v_u_5.layout(v300, "v", 6)
		local v303
		if p_u_295.maxUses then
			v303 = ("%d / %d uses"):format(p_u_295.uses, p_u_295.maxUses)
		else
			v303 = ("%d %s (counted every few minutes)"):format(p_u_295.uses, p_u_295.uses == 1 and "use" or "uses")
		end
		local v304 = v_u_5.label
		local v305 = {
			["parent"] = nil,
			["name"] = "Meta",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v300
		}
		local v306 = "#%s  \194\183  %s  \194\183  %s"
		local v307 = p_u_295.id
		local v308 = tostring(v307)
		local v309 = v_u_277[p_u_295.state]
		if not v309 then
			local v310 = p_u_295.state
			v309 = tostring(v310)
		end
		v305.text = v306:format(v308, v309, v303)
		v305.color = v_u_276[p_u_295.state] or v_u_7.text2
		v305.size = UDim2.new(1, 0, 0, 0)
		local v311 = v304(v305)
		v311.LayoutOrder = 1
		v311.RichText = false
		local v312 = v_u_5.input
		local v313 = {
			["parent"] = nil,
			["name"] = "CodeText",
			["text"] = nil,
			["size"] = nil,
			["parent"] = v300
		}
		local v314 = p_u_295.code
		v313.text = tostring(v314)
		v313.size = UDim2.new(1, 0, 0, v_u_6.touch(32))
		local v315, v316 = v312(v313)
		v315.LayoutOrder = 2
		v316.TextEditable = false
		v316.ClearTextOnFocus = false
		local v317 = v_u_5.label
		local v318 = {
			["parent"] = nil,
			["name"] = "Rewards",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v300
		}
		local v319 = p_u_295.rewards
		v318.text = "Gives " .. tostring(v319)
		v318.color = v_u_7.text
		v318.size = UDim2.new(1, 0, 0, 0)
		local v320 = v317(v318)
		v320.LayoutOrder = 3
		v320.RichText = false
		local v321 = os.time()
		local v322 = {}
		local v323 = p_u_295.startsAt
		if tonumber(v323) then
			local v324
			if v321 < p_u_295.startsAt then
				local v325 = p_u_295.startsAt
				local v326 = tonumber(v325)
				v324 = "starts " .. ((v326 == nil or v326 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v326))) .. " UTC")
			else
				local v327 = p_u_295.startsAt
				local v328 = tonumber(v327)
				v324 = "started " .. ((v328 == nil or v328 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v328))) .. " UTC")
			end
			table.insert(v322, v324)
		end
		local v329 = p_u_295.endsAt
		if tonumber(v329) then
			local v330
			if v321 < p_u_295.endsAt then
				local v331 = p_u_295.endsAt
				local v332 = tonumber(v331)
				v330 = "ends " .. ((v332 == nil or v332 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v332))) .. " UTC")
			else
				local v333 = p_u_295.endsAt
				local v334 = tonumber(v333)
				v330 = "ended " .. ((v334 == nil or v334 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v334))) .. " UTC")
			end
			table.insert(v322, v330)
		end
		local v335 = p_u_295.at
		local v336 = tonumber(v335)
		local v337 = (v336 == nil or v336 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v336))) .. " UTC"
		local v338 = p_u_295.byName
		local v339 = "created " .. v337 .. " by " .. tostring(v338)
		table.insert(v322, v339)
		local v340 = v_u_5.label
		local v341 = {
			["parent"] = nil,
			["name"] = "Info",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v300
		}
		local v342 = table.concat(v322, "  \194\183  ")
		local v343
		if p_u_295.note then
			local v344 = p_u_295.note
			v343 = "\n" .. tostring(v344)
		else
			v343 = ""
		end
		v341.text = v342 .. v343
		v341.color = v_u_7.muted
		v341.size = UDim2.new(1, 0, 0, 0)
		local v345 = v340(v341)
		v345.LayoutOrder = 4
		v345.RichText = false
		local v346 = v_u_5.new("Frame", {
			["Name"] = "Actions",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 5,
			["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(32))
		}, v300)
		v_u_5.layout(v346, "h", 6)
		local v347 = (p_u_32.inner - 20 - 6) / 2
		local v348 = math.floor(v347)
		local v349
		if v_u_54[p_u_295.id] == nil then
			v349 = false
		else
			v349 = os.clock() - v_u_54[p_u_295.id] < 5
		end
		local v_u_350 = nil
		local v351 = p_u_295.disabled and "Enable" or "Disable"
		local function v352()
			-- upvalues: (ref) v_u_286, (copy) p_u_295, (ref) v_u_350
			v_u_286(p_u_295, not p_u_295.disabled, v_u_350)
		end
		local v353, v354 = v_u_5.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v346,
			["text"] = v351,
			["width"] = v348,
			["onClick"] = v352,
			["maxTextWidth"] = (v348 or 160) - 12
		})
		local v355 = v354
		v353.Name = "CodeToggle"
		v353.LayoutOrder = 1
		local v_u_356 = nil
		local function v358()
			-- upvalues: (ref) v_u_54, (copy) p_u_295, (ref) v_u_294, (ref) v_u_356, (ref) v_u_56, (ref) v_u_218
			local v357 = v_u_54[p_u_295.id]
			if v357 == nil or os.clock() - v357 >= 5 then
				v_u_54[p_u_295.id] = os.clock()
				v_u_56(true)
				task.delay(5.2, function()
					-- upvalues: (ref) v_u_218, (ref) v_u_54, (ref) p_u_295, (ref) v_u_56
					if v_u_218 and (v_u_54[p_u_295.id] ~= nil and os.clock() - v_u_54[p_u_295.id] >= 5) then
						v_u_54[p_u_295.id] = nil
						v_u_56(true)
					end
				end)
			else
				v_u_54[p_u_295.id] = nil
				v_u_294(p_u_295, v_u_356)
			end
		end
		local v359, v360 = v_u_5.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "danger",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v346,
			["text"] = v349 and "Click again to delete" or "Delete",
			["width"] = v348,
			["onClick"] = v358,
			["maxTextWidth"] = (v348 or 160) - 12
		})
		local v361 = v360
		v359.Name = "CodeDelete"
		v359.LayoutOrder = 2
		if v349 then
			v_u_5.stroke(v359, v_u_7.danger)
		end
		local v362 = v_u_55
		table.insert(v362, v355)
		local v363 = v_u_55
		local v364 = v361
		table.insert(v363, v364)
		if v_u_48 then
			v355.setEnabled(false)
			v361.setEnabled(false)
		end
	end
	local function _(p366)
		-- upvalues: (ref) v_u_2, (ref) v_u_49, (ref) v_u_51, (ref) v_u_50, (copy) v_u_54, (copy) v_u_269, (ref) v_u_52, (ref) v_u_57, (copy) v_u_273, (copy) v_u_274, (copy) v_u_55, (copy) v_u_365, (copy) v_u_275
		local v367 = v_u_51
		local v368 = v_u_2:JSONEncode(v_u_49) .. "|" .. tostring(v367) .. "|" .. v_u_2:JSONEncode(v_u_50)
		for v369, v370 in v_u_54 do
			local v371 = tostring(v369)
			local v372 = os.clock() - v370 < 5
			v368 = v368 .. "|c" .. v371 .. tostring(v372)
		end
		v_u_269.Text = ("%d of %d codes"):format(v_u_51, v_u_52)
		if v368 ~= v_u_57 or p366 == true then
			v_u_57 = v368
			for _, v373 in v_u_273:GetChildren() do
				if not v373:IsA("GuiObject") or v373 == v_u_274 then
					continue
				end
				v373:Destroy()
			end
			table.clear(v_u_55)
			v_u_274.Visible = #v_u_49 == 0
			for v374, v375 in v_u_49 do
				v_u_365(v375, v374)
			end
			local v376 = {}
			for _, v377 in v_u_50 do
				local v378 = "%s  %s  %s %s%s"
				local v379 = v377.at
				local v380 = tonumber(v379)
				local v381 = (v380 == nil or v380 <= 0) and "" or os.date("!%d %b %H:%M", (math.floor(v380))) .. " UTC"
				local v382 = v377.name
				local v383 = tostring(v382)
				local v384 = v377.what
				local v385 = tostring(v384)
				local v386 = v377.id or ""
				local v387 = tostring(v386)
				local v388
				if v377.info then
					local v389 = v377.info
					v388 = "  " .. tostring(v389)
				else
					v388 = ""
				end
				table.insert(v376, v378:format(v381, v383, v385, v387, v388))
			end
			v_u_275.Text = #v376 <= 0 and "Nothing yet." or table.concat(v376, "\n")
		end
	end
	local v_u_390 = nil
	local v_u_391 = true
	local v_u_392 = false
	if v38 then
		v42("Test redeem  \194\183  Studio only")
		v46("Runs the whole redeem on your own account: the same checks, the same grant, the same save. Repeat clears your mark of that code first, so you can try it again.")
		local v393, v_u_394 = v_u_5.input({
			["parent"] = nil,
			["name"] = "CodesTestBox",
			["size"] = nil,
			["placeholder"] = "Code to test",
			["parent"] = v_u_33,
			["size"] = UDim2.new(1, 0, 0, v_u_6.touch(34))
		})
		v_u_39 = v_u_39 + 1
		v393.LayoutOrder = v_u_39
		local v395 = v_u_5.new("Frame", {
			["Name"] = "CodesTestRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(32))
		}, v_u_33)
		v_u_39 = v_u_39 + 1
		v395.LayoutOrder = v_u_39
		v_u_5.layout(v395, "h", 6)
		local v396 = (p_u_32.inner - 6) / 2
		local v397 = math.floor(v396)
		local v_u_398 = nil
		local function v399()
			-- upvalues: (ref) v_u_391, (ref) v_u_398
			v_u_391 = not v_u_391
			v_u_398.setText(v_u_391 and "Repeat: on" or "Repeat: off")
		end
		local v400, v401 = v_u_5.button({
			["parent"] = nil,
			["text"] = "Repeat: on",
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v395,
			["width"] = v397,
			["onClick"] = v399,
			["maxTextWidth"] = (v397 or 160) - 12
		})
		v_u_398 = v401
		v400.LayoutOrder = 1
		v400.Name = "CodesTestRepeat"
		local v402, v403 = v_u_5.button({
			["parent"] = nil,
			["text"] = "Test redeem",
			["kind"] = "primary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v395,
			["width"] = v397,
			["onClick"] = function()
				-- upvalues: (copy) v_u_88, (copy) v_u_394, (ref) v_u_391
				v_u_88.test(v_u_394.Text, v_u_391)
			end,
			["maxTextWidth"] = (v397 or 160) - 12
		})
		v402.LayoutOrder = 2
		v402.Name = "CodesTestGo"
		v_u_390 = v_u_5.label({
			["parent"] = nil,
			["name"] = "CodesTestResult",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_33,
			["color"] = v_u_7.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_39 = v_u_39 + 1
		v_u_390.LayoutOrder = v_u_39
		table.insert(v_u_55, v403)
		function v_u_88.test(p404, p405) -- name: test
			-- upvalues: (ref) v_u_392, (ref) v_u_390, (ref) v_u_7, (copy) v_u_34, (ref) v_u_47
			if not v_u_392 then
				v_u_392 = true
				if v_u_390 then
					v_u_390.Text = "Testing..."
					v_u_390.TextColor3 = v_u_7.text2
				end
				v_u_34.call("codes.test", {
					["text"] = p404,
					["again"] = p405 == true
				}, function(p406)
					-- upvalues: (ref) v_u_392, (ref) v_u_390, (ref) v_u_7, (ref) v_u_47
					v_u_392 = false
					if v_u_390 then
						local v407 = p406 and (p406.msg or "The server did not answer.") or "The server did not answer."
						v_u_390.Text = tostring(v407)
						local v408 = v_u_390
						local v409
						if p406 and p406.ok then
							v409 = v_u_7.success
						else
							v409 = v_u_7.danger
						end
						v408.TextColor3 = v409
					end
					v_u_47(true)
				end)
			end
		end
	else
		function v_u_88.test(_, _) -- name: test end
	end
	local function v_u_415(p_u_410)
		-- upvalues: (copy) v_u_272, (copy) v_u_232, (copy) v_u_34
		local function v414(p411) -- name: done
			-- upvalues: (ref) v_u_272, (ref) v_u_232, (copy) p_u_410
			if p411 and p411.ok then
				v_u_272.Visible = false
				v_u_232(p411.data)
			elseif not p_u_410 then
				local v412 = v_u_272
				local v413 = p411 and p411.msg or "The server did not answer."
				v412.Text = tostring(v413)
				v_u_272.Visible = true
			end
		end
		if p_u_410 then
			v_u_34.callQuiet("codes.list", {}, v414)
		else
			v_u_34.call("codes.list", {}, v414)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_218, (copy) p_u_32, (copy) v_u_33, (ref) v_u_48, (ref) v_u_415
		local v416 = false
		local v417 = 0
		while v_u_218 do
			local v418 = p_u_32.gui.Enabled
			if v418 then
				v418 = v_u_33.Visible
			end
			if v418 and (not v416 and p_u_32.handle) then
				local v419 = p_u_32.handle.status
				if type(v419) == "function" then
					local v420 = p_u_32.handle.status
					pcall(v420, "Redeem codes.")
				end
			end
			if v418 and (not v416 or os.clock() - v417 >= 20) and not v_u_48 then
				v417 = os.clock()
				v_u_415(true)
			end
			task.wait(0.3)
			v416 = v418
		end
	end)
	v_u_215()
	function v_u_88.refresh() -- name: refresh
		-- upvalues: (ref) v_u_415
		v_u_415(false)
	end
	function v_u_88.list() -- name: list
		-- upvalues: (ref) v_u_49
		return v_u_49
	end
	function v_u_88.setDraft(p421) -- name: setDraft
		-- upvalues: (copy) v_u_58, (copy) v_u_82, (ref) v_u_178, (ref) v_u_216, (ref) v_u_213, (ref) v_u_48, (copy) v_u_212, (ref) v_u_215
		for v422, v423 in v_u_58 do
			local v424 = p421[v422]
			v423.Text = v424 == nil and "" or tostring(v424)
		end
		table.clear(v_u_82)
		local v425 = p421.items
		if type(v425) == "table" then
			for _, v426 in p421.items do
				if type(v426) ~= "table" or v426.id == nil then
					continue
				end
				local v427 = v_u_82
				local v428 = {}
				local v429 = v426.id
				v428.id = tostring(v429)
				local v430
				if v426.n == nil then
					v430 = "1"
				else
					local v431 = v426.n
					v430 = tostring(v431)
				end
				v428.n = v430
				table.insert(v427, v428)
			end
		end
		if p421.item ~= nil then
			local v432 = p421.item
			if tostring(v432) ~= "" then
				local v433 = v_u_82
				local v434 = {}
				local v435 = p421.item
				v434.id = tostring(v435)
				local v436
				if p421.itemN == nil then
					v436 = "1"
				else
					local v437 = p421.itemN
					if tostring(v437) == "" then
						v436 = "1"
					else
						local v438 = p421.itemN
						v436 = tostring(v438)
					end
				end
				v434.n = v436
				table.insert(v433, v434)
			end
		end
		v_u_178()
		v_u_216 = nil
		if v_u_213 ~= nil and not v_u_48 then
			v_u_213.setText("Create code")
		end
		v_u_212.Visible = false
		v_u_215()
	end
	function v_u_88.pickItem(p439) -- name: pickItem
		-- upvalues: (copy) v_u_80, (copy) v_u_82, (copy) v_u_37, (copy) v_u_180, (ref) v_u_9, (copy) v_u_93, (ref) v_u_178, (ref) v_u_221
		if v_u_80 == nil then
			return
		else
			for _, v440 in v_u_82 do
				if v440.id ~= p439 then
					continue
				end
				return
			end
			if #v_u_82 >= v_u_37.itemKinds then
				local v441 = ("A code holds at most %d items."):format(v_u_37.itemKinds) or ""
				v_u_180.Text = v441
				v_u_180.Visible = v441 ~= ""
				v_u_9:SetAttribute("FilmCodesError", v441)
			else
				v_u_180.Text = ""
				v_u_180.Visible = false
				v_u_9:SetAttribute("FilmCodesError", "")
				local v442 = v_u_82
				table.insert(v442, {
					["id"] = nil,
					["n"] = "1",
					["id"] = p439
				})
				v_u_93.Text = ""
				v_u_178()
				v_u_221()
			end
		end
	end
	function v_u_88.removeItem(p443) -- name: removeItem
		-- upvalues: (copy) v_u_82, (ref) v_u_178, (ref) v_u_221
		for v444, v445 in v_u_82 do
			if v445.id ~= p443 then
				continue
			end
			table.remove(v_u_82, v444)
		end
		v_u_178()
		v_u_221()
	end
	function v_u_88.setSearch(p446) -- name: setSearch
		-- upvalues: (copy) v_u_93, (copy) v_u_156
		v_u_93.Text = p446
		v_u_156()
	end
	function v_u_88.suggestions() -- name: suggestions
		-- upvalues: (ref) v_u_85
		return v_u_85
	end
	function v_u_88.chosen() -- name: chosen
		-- upvalues: (copy) v_u_82
		return v_u_82
	end
	function v_u_88.create() -- name: create
		-- upvalues: (copy) v_u_264
		v_u_264()
	end
	function v_u_88.setDisabled(p447, p448) -- name: setDisabled
		-- upvalues: (ref) v_u_49, (copy) v_u_286
		for _, v449 in v_u_49 do
			if v449.id ~= p447 then
				continue
			end
			v_u_286(v449, p448, {
				["setText"] = function(_) -- name: setText end
			})
			return
		end
	end
	function v_u_88.delete(p450) -- name: delete
		-- upvalues: (ref) v_u_49, (copy) v_u_294
		for _, v451 in v_u_49 do
			if v451.id ~= p450 then
				continue
			end
			v_u_294(v451, {
				["setText"] = function(_) -- name: setText end
			})
			return
		end
	end
	function v_u_88.formState() -- name: formState
		-- upvalues: (copy) v_u_180, (copy) v_u_181, (ref) v_u_48, (ref) v_u_49, (copy) v_u_82, (ref) v_u_216, (copy) v_u_179, (ref) v_u_213, (ref) v_u_390
		return {
			["error"] = v_u_180.Text,
			["ok"] = v_u_181.Text,
			["busy"] = v_u_48,
			["codes"] = #v_u_49,
			["items"] = #v_u_82,
			["confirm"] = v_u_216 ~= nil,
			["preview"] = v_u_179.Text,
			["createText"] = not v_u_213 and "" or v_u_213.label.Text,
			["testResult"] = not v_u_390 and "" or v_u_390.Text
		}
	end
	return v_u_88
end
return v8