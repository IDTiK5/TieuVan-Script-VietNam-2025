-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSettings

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = nil
local v_u_4 = {
	["Auto"] = 0,
	["Low"] = 1,
	["Medium"] = 2,
	["High"] = 3,
	["Ultra"] = 4
}
local v_u_5 = {
	{
		["key"] = "masterVolume",
		["group"] = "Master",
		["text"] = "Master"
	},
	{
		["key"] = "musicVolume",
		["group"] = "Music",
		["text"] = "Music"
	},
	{
		["key"] = "sfxVolume",
		["group"] = "SFX",
		["text"] = "Effects"
	},
	{
		["key"] = "ambienceVolume",
		["group"] = "Ambience",
		["text"] = "Ambience"
	},
	{
		["key"] = "uiVolume",
		["group"] = "UI",
		["text"] = "Interface"
	}
}
local v_u_6 = {
	["graphics"] = "Auto",
	["masterVolume"] = 0.5,
	["musicVolume"] = 1,
	["sfxVolume"] = 1,
	["ambienceVolume"] = 1,
	["uiVolume"] = 1,
	["touchSize"] = 2,
	["cameraZoom"] = 2,
	["uiScale"] = 1,
	["cameraShake"] = 1,
	["aimAssist"] = true,
	["voiceNoise"] = true,
	["closeSearchOnHit"] = false,
	["hideMyGear"] = false,
	["hideOthersGear"] = false,
	["touchStick"] = 2,
	["touchMoveFixed"] = false,
	["touchOpacity"] = 2,
	["hideHeadwear"] = false,
	["squadChat"] = true,
	["mapTasks"] = true,
	["mapLabels"] = true,
	["touchFire"] = "auto",
	["hudLayoutP"] = "",
	["hudLayoutT"] = "",
	["ammoStackNoAsk"] = false,
	["crateQuick"] = false,
	["skinFx"] = true,
	["showClanColors"] = true,
	["weaponSkins"] = true,
	["showFps"] = false,
	["entryMode"] = "full",
	["tradeRequests"] = "everyone",
	["statusOutline"] = true,
	["objectOutlines"] = true,
	["reduceFlashing"] = false,
	["menuStyle"] = "auto",
	["taskTracker"] = "full",
	["fov"] = 75,
	["sensitivity"] = 1,
	["fpAdsSens"] = 1,
	["fpPadSens"] = 1,
	["fpTouchSens"] = 1,
	["fpInvertY"] = false,
	["fpBob"] = 0.6,
	["fpSway"] = 0.6,
	["fpShoulder"] = "right"
}
v_u_1.DEFAULTS = v_u_6
local v_u_7 = {
	{ "move", "Move" },
	{ "fire", "Fire" },
	{ "aim", "Aim" },
	{ "reload", "Reload" },
	{ "interact", "Interact / use" },
	{
		{ "promptUp", "promptDown" },
		"Choose interaction"
	},
	{ "sprint", "Sprint" },
	{ "sneak", "Sneak" },
	{ "melee", "Melee / Punch" },
	{ "throw", "Throw (tap = aim, hold = quick)" },
	{ "swap", "Swap weapon" },
	{ "primary", "Primary weapon" },
	{ "secondary", "Sidearm" },
	{ "meleeSlot", "Melee weapon" },
	{
		{
			"quick1",
			"quick2",
			"quick3",
			"quick4"
		},
		"Quick slots 1 to 4"
	},
	{ "inventory", "Inventory" },
	{ "rotateItem", "Rotate item (inventory)" },
	{ "flashlight", "Flashlight" },
	{ "nightVision", "Night vision" },
	{ "tasks", "Fold mission list" },
	{ "hideUi", "Hide interface" },
	{ "ping", "Quick calls" },
	{ "fireMode", "Fire mode" },
	{ "map", "Map" },
	{ "extracts", "Show extracts" },
	{
		{ "camLeft", "camRight" },
		"Rotate camera"
	},
	{ "zoom", "Camera zoom" },
	{ "viewToggle", "Switch first / third person" },
	{ "menu", "Settings (in a raid)" }
}
local v_u_8 = {
	["LeftShift"] = "Shift",
	["RightShift"] = "Shift",
	["LeftControl"] = "Ctrl",
	["RightControl"] = "Ctrl",
	["LeftAlt"] = "Alt",
	["RightAlt"] = "Alt",
	["One"] = "1",
	["Two"] = "2",
	["Three"] = "3",
	["Four"] = "4",
	["Five"] = "5",
	["Six"] = "6",
	["Seven"] = "7",
	["Eight"] = "8",
	["Nine"] = "9",
	["Zero"] = "0",
	["Space"] = "Space",
	["Return"] = "Enter",
	["Backquote"] = "`",
	["Escape"] = "Esc",
	["ButtonR2"] = "RT",
	["ButtonL2"] = "LT",
	["ButtonR1"] = "RB",
	["ButtonL1"] = "LB",
	["ButtonR3"] = "RS click",
	["ButtonL3"] = "LS click",
	["ButtonSelect"] = "View",
	["ButtonStart"] = "Menu",
	["ButtonA"] = "A",
	["ButtonB"] = "B",
	["ButtonX"] = "X",
	["ButtonY"] = "Y",
	["DPadUp"] = "D-Pad Up",
	["DPadDown"] = "D-Pad Down",
	["DPadLeft"] = "D-Pad Left",
	["DPadRight"] = "D-Pad Right"
}
local v_u_9 = {
	["MouseButton1"] = "Left mouse",
	["MouseButton2"] = "Right mouse",
	["MouseButton3"] = "Middle mouse",
	["MouseWheel"] = "Mouse wheel"
}
local v_u_10 = {
	["padMod"] = "LB + "
}
local v_u_11 = {
	["primary"] = "Swap",
	["secondary"] = "Swap",
	["menu"] = "Gear button"
}
local function v_u_35(p12) -- name: bindingText
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	if type(p12) == "table" then
		local v13 = p12.keys
		local v14 = {}
		for _, v15 in type(v13) ~= "table" and {} or p12.keys do
			local v16
			if typeof(v15) == "EnumItem" then
				v16 = v15.Name
			else
				v16 = tostring(v15)
			end
			local v17 = v_u_8[v16] or v16
			if table.find(v14, v17) then
				continue
			end
			table.insert(v14, v17)
		end
		local v18 = p12.mouse
		for _, v19 in type(v18) ~= "table" and {} or p12.mouse do
			local v20
			if typeof(v19) == "EnumItem" then
				v20 = v_u_9[v19.Name] or v19.Name
			else
				v20 = tostring(v19)
			end
			if table.find(v14, v20) then
				continue
			end
			table.insert(v14, v20)
		end
		local v21 = p12.padWhen
		local v22 = type(v21) == "string" and (v_u_10[p12.padWhen] or "") or ""
		local v23 = p12.pad
		local v24 = {}
		for _, v25 in type(v23) ~= "table" and {} or p12.pad do
			local v26
			if typeof(v25) == "EnumItem" then
				v26 = v25.Name
			else
				v26 = tostring(v25)
			end
			local v27 = v22 .. (v_u_8[v26] or v26)
			if table.find(v24, v27) then
				continue
			end
			table.insert(v24, v27)
		end
		local v28 = p12.padHold
		for _, v29 in type(v28) ~= "table" and {} or p12.padHold do
			local v30 = "Hold "
			local v31 = string.gsub
			local v32
			if typeof(v29) == "EnumItem" then
				v32 = v29.Name
			else
				v32 = tostring(v29)
			end
			local v33 = v30 .. v31(v_u_8[v32] or v32, " click$", "")
			if table.find(v24, v33) then
				continue
			end
			table.insert(v24, v33)
		end
		local v34 = #v14 <= 0 and "-" or table.concat(v14, " / ")
		if #v24 > 0 then
			return v34, table.concat(v24, " / ")
		else
			return v34, "-"
		end
	else
		return "-", "-"
	end
end
local function v_u_50(p36) -- name: groupText
	local v37 = {}
	for _, v38 in p36 do
		local v39 = tonumber(v38)
		if not v39 then
			v37 = nil
			break
		end
		table.insert(v37, v39)
	end
	if v37 and #v37 > 2 then
		local v40 = true
		for v41 = 2, #v37 do
			if v37[v41] == v37[v41 - 1] + 1 then
				continue
			end
			v40 = false
		end
		if v40 then
			return ("%d to %d"):format(v37[1], v37[#v37])
		end
	end
	local v42 = #p36 > 1
	for _, v43 in p36 do
		if string.sub(v43, 1, 5) == "D-Pad" then
			continue
		end
		v42 = false
	end
	if v42 then
		return "D-Pad"
	end
	local v44 = #p36 > 1
	local v45 = {}
	for _, v46 in p36 do
		if string.sub(v46, 1, 11) ~= "LB + D-Pad " then
			v44 = false
			break
		end
		local v47 = string.sub(v46, 12)
		table.insert(v45, v47)
	end
	if v44 then
		return "LB + D-Pad " .. table.concat(v45, " / ")
	end
	local v48 = {}
	for _, v49 in p36 do
		if v49 == "-" or table.find(v48, v49) then
			continue
		end
		table.insert(v48, v49)
	end
	return #v48 <= 0 and "-" or table.concat(v48, " / ")
end
v_u_1.TEXT = {
	["touchHelp"] = nil,
	["padNote"] = "Controller only: camera zoom is a tap on RS. In an interaction list, D-Pad up and down choose.",
	["touchLayout"] = "These rows only apply on a touch screen. Move stick: Under thumb = the stick appears where you touch the left side. Fixed corner = it stays in the bottom left corner, the rest of the left side does nothing.",
	["editRaid"] = "The raid keeps running while you edit, and the HUD is hidden. Find a quiet corner first.",
	["hudCardTitle"] = "HUD LAYOUT",
	["hudCardLine"] = "Move and resize your buttons",
	["hudCardButton"] = "Edit HUD",
	["fireHelp"] = "Auto: the ring in CLASSIC raids, a FIRE button in FIRST / THIRD PERSON raids. Ring: push the aim stick into its outer ring to fire. Button: a FIRE button you can move. Ring and button: either one fires.",
	["editNoTouch"] = "Edit HUD needs a touch screen.",
	["editPad"] = "Put the controller down to edit the HUD.",
	["editNormal"] = "Move and resize the buttons, the sticks and the info blocks. Saved for this kind of device. Reset puts everything back.",
	["crateQuick"] = "On: always the short scene. Off: the long scene for the first opening, openings within a minute are shortened by themselves. You can skip any opening after one second.",
	["tempLabel"] = "Not saved (data service down)",
	["tempNote"] = "Roblox\'s data service did not answer. What you earn in this session is lost when you leave. Rejoin later to play with saving.",
	["marketBlocked"] = "Market: not available for your account. Roblox rules limit trading paid items in some regions and age groups.",
	["voiceNoDevice"] = "Voice draws the infected: turn on Roblox voice chat to use this.",
	["touchHelp"] = {
		"Move: left thumb. Push the stick to its rim to sprint, pull back to walk.",
		"Aim: right stick. Push it into the outer ring to fire. In FIRST / THIRD PERSON the right stick looks around and a FIRE button fires. The Fire control row changes this.",
		"SNEAK: tap to sneak, tap again to stand up.",
		"MORE: opens LIGHT, PING, MELEE, THROW, EXITS, CHAT, quick slots 1 to 4 (your medical items) and the turn arrows. It closes by itself.",
		"RELOAD, SWAP and BAG are always there. USE appears when something can be used.",
		"Two finger twist turns the view. Pinch zooms."
	}
}
function v_u_1.editState(p51, p52, p53, p54) -- name: editState
	return p51 and (p53 and (p54 == "Gamepad" and "pad" or (p52 and "raid" or "ok")) or "notouch") or "off"
end
function v_u_1.editNote(p55) -- name: editNote
	-- upvalues: (copy) v_u_1
	if p55 == "raid" then
		return v_u_1.TEXT.editRaid
	elseif p55 == "notouch" then
		return v_u_1.TEXT.editNoTouch
	elseif p55 == "pad" then
		return v_u_1.TEXT.editPad
	else
		return v_u_1.TEXT.editNormal
	end
end
function v_u_1.marketBlocked(p56, p57, p58) -- name: marketBlocked
	if p58 then
		if p56 == "block" then
			p58 = p57 == false
		else
			p58 = false
		end
	end
	return p58
end
function v_u_1.voiceRowState(p59, p60) -- name: voiceRowState
	return p59 and (p60 and "row" or "note") or "none"
end
function v_u_1.padWord(p61, p62) -- name: padWord
	-- upvalues: (copy) v_u_35
	if string.sub(p62, 1, 4) == "move" then
		return "Left stick"
	end
	local v63
	if type(p61) == "table" then
		v63 = p61[p62]
	else
		v63 = nil
	end
	local v64
	if v63 then
		local v65
		v65, v64 = v_u_35(v63)
	else
		v64 = "-"
	end
	if v64 ~= "-" then
		return v64
	end
	if p62 == "meleeSlot" then
		return "Swap"
	end
	if p62 == "fireMode" and (type(p61) == "table" and p61.reload) then
		local _, v66 = v_u_35(p61.reload)
		return v66 == "-" and "-" or "Hold " .. v66
	end
	if p62 ~= "primary" and p62 ~= "secondary" then
		return p62 == "throw" and "Quick slot (D-Pad)" or (p62 == "chat" and "Not on controller" or v64)
	end
	local v67
	if type(p61) == "table" and p61.swap then
		local v68
		v68, v67 = v_u_35(p61.swap)
	else
		v67 = "-"
	end
	return v67 == "-" and "Swap" or "Cycle with " .. v67
end
function v_u_1.bindingRows(p_u_69) -- name: bindingRows
	-- upvalues: (copy) v_u_11, (copy) v_u_7, (copy) v_u_35, (copy) v_u_50, (copy) v_u_1
	local v_u_70 = p_u_69 and p_u_69.controllers
	if v_u_70 then
		v_u_70 = p_u_69.controllers.Input
	end
	local v71
	if v_u_70 then
		local v72 = v_u_70.ACTIONS
		v71 = type(v72) ~= "table" and {} or v_u_70.ACTIONS
	else
		v71 = {}
	end
	local v_u_73 = false
	local function v74()
		-- upvalues: (ref) v_u_73, (copy) v_u_70
		v_u_73 = v_u_70.device() == "Touch"
	end
	pcall(v74)
	local v75, v76 = pcall(function()
		-- upvalues: (copy) p_u_69
		return p_u_69.lib.PlayModeSel.liveShown(p_u_69)
	end)
	local v77 = not v75 or v76 ~= false
	local v78 = v_u_73
	local v79 = {}
	local v80 = {}
	for _, v81 in v_u_7 do
		local v82 = v81[1]
		local v83
		if type(v82) == "table" then
			v83 = v81[1]
		else
			v83 = { v81[1] }
		end
		if v83[1] == "viewToggle" and not v77 then
			v79.viewToggle = true
		elseif v83[1] == "move" then
			local v84 = {
				["label"] = nil,
				["keys"] = "W A S D",
				["pad"] = "Left stick",
				["touch"] = nil,
				["label"] = v81[2],
				["touch"] = v78 and "Left stick" or ""
			}
			table.insert(v80, v84)
		else
			local v85 = {}
			local v86 = {}
			local v87 = false
			for _, v88 in v83 do
				v79[v88] = true
				local v89 = v71[v88]
				if not v89 then
					continue
				end
				local v90, v91 = v_u_35(v89)
				table.insert(v85, v90)
				table.insert(v86, v91)
				v87 = true
			end
			if v87 or v83[1] ~= "fireMode" then
				if not v87 then
					break
				end
				local v92
				if #v83 > 1 then
					v92 = v_u_50(v85)
				else
					v92 = v85[1]
				end
				if v83[1] == "zoom" then
					v92 = v92 == "-" and "Mouse wheel" or "Mouse wheel / " .. v92
				end
				if v83[1] == "fireMode" then
					v92 = v92 == "-" and "Hold R" or v92 .. " / hold R"
				end
				local v93
				if #v83 > 1 then
					v93 = v_u_50(v86)
				else
					v93 = v86[1]
				end
				if #v83 == 1 and v93 == "-" then
					v93 = v_u_1.padWord(v71, v83[1])
				end
				if v83[1] == "promptUp" then
					v92 = "Click a row"
					if v93 == "D-Pad" then
						v93 = "D-Pad Up / Down"
					end
				end
				if v83[1] == "fireMode" and (v93 == "-" and v71.reload) then
					local _, v94 = v_u_35(v71.reload)
					v93 = v94 == "-" and "-" or "Hold " .. v94
				end
				local v95 = {
					["label"] = v81[2],
					["keys"] = v92,
					["pad"] = v93
				}
				local v96 = v83[1]
				local v97 = not v78 or v_u_11[v96]
				if not v97 then
					local v98 = v_u_70.hint
					local v99, v100 = pcall(v98, v96)
					v97 = (not v99 or (type(v100) ~= "string" or (v100 == "" or v100 == "Tap"))) and "-" or v100
				end
				v95.touch = v97
				table.insert(v80, v95)
			else
				local v101 = {
					["label"] = nil,
					["keys"] = "Hold R",
					["pad"] = "-",
					["touch"] = nil,
					["label"] = v81[2],
					["touch"] = v78 and "Mode chip" or ""
				}
				table.insert(v80, v101)
			end
		end
	end
	local v102 = {}
	for v103 in v71 do
		if type(v103) ~= "string" or v79[v103] then
			continue
		end
		table.insert(v102, v103)
	end
	table.sort(v102)
	for _, v104 in v102 do
		local v105, v106 = v_u_35(v71[v104])
		local v107 = {}
		local v108 = string.gsub(v104, "(%u)", " %1")
		v107.label = string.upper((string.sub(v108, 1, 1))) .. string.lower((string.sub(v108, 2)))
		v107.keys = v105
		v107.pad = v106
		local v109 = not v78 or v_u_11[v104]
		if not v109 then
			local v110 = v_u_70.hint
			local v111, v112 = pcall(v110, v104)
			v109 = (not v111 or (type(v112) ~= "string" or (v112 == "" or v112 == "Tap"))) and "-" or v112
		end
		v107.touch = v109
		table.insert(v80, v107)
	end
	return v80
end
local v_u_113 = {
	["fov"] = { "Fov", 50, 100 },
	["sensitivity"] = { "Sensitivity", 0.1, 6 },
	["fpAdsSens"] = { "FpAdsSens", 0.2, 2 },
	["fpPadSens"] = { "FpPadSens", 0.2, 6 },
	["fpTouchSens"] = { "FpTouchSens", 0.2, 6 },
	["fpBob"] = { "FpBob", 0, 1 },
	["fpSway"] = { "FpSway", 0, 1 }
}
local function v_u_152(p_u_114, p115, p_u_116, p117) -- name: applyOne
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_113
	local v118 = p_u_114.cctx.controllers
	if p115 == "graphics" and type(p_u_116) == "string" then
		local v119 = v_u_4[p_u_116] or 0
		local v120 = v118.Atmosphere
		if v119 > 0 then
			v_u_2:SetAttribute("GfxQuality", v119)
			if v120 and v120.setQuality then
				local v121 = v120.setQuality
				pcall(v121, v119)
				return
			end
		else
			local v122 = v_u_2:GetAttribute("GfxQuality")
			v_u_2:SetAttribute("GfxQuality", nil)
			if v120 and (v120.setQuality and (v122 ~= nil or not p117)) then
				local v123 = v120.setQuality
				pcall(v123, "auto")
				return
			end
		end
	elseif type(p115) == "string" and string.sub(p115, -6) == "Volume" then
		local v124
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v124 = math.clamp(p_u_116, 0, 1)
		else
			v124 = nil
		end
		if v124 then
			for _, v125 in v_u_5 do
				if v125.key ~= p115 then
					continue
				end
				v_u_2:SetAttribute("Volume_" .. v125.group, v124)
				local v126 = v118.Audio
				if not (v126 and v126.setVolume) then
					continue
				end
				local v127 = v126.setVolume
				local v128 = v125.group
				pcall(v127, v128, v124)
			end
			return
		end
	elseif p115 == "touchSize" then
		local v129
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v129 = math.clamp(p_u_116, 1, 3)
		else
			v129 = nil
		end
		if v129 then
			local v130 = v_u_2
			local v131 = v129 + 0.5
			v130:SetAttribute("TouchSize", (math.floor(v131)))
			return
		end
	elseif p115 == "touchStick" then
		local v132
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v132 = math.clamp(p_u_116, 1, 4)
		else
			v132 = nil
		end
		if v132 then
			local v133 = v_u_2
			local v134 = v132 + 0.5
			v133:SetAttribute("TouchStickSize", (math.floor(v134)))
			return
		end
	elseif p115 == "touchMoveFixed" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("TouchMoveFixed", p_u_116)
			return
		end
	elseif p115 == "touchOpacity" then
		local v135
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v135 = math.clamp(p_u_116, 1, 3)
		else
			v135 = nil
		end
		if v135 then
			local v136 = v_u_2
			local v137 = v135 + 0.5
			v136:SetAttribute("TouchOpacity", (math.floor(v137)))
			return
		end
	elseif p115 == "hideHeadwear" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("HideHeadwear", p_u_116)
			return
		end
	elseif p115 == "statusOutline" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("StatusOutline", p_u_116)
			return
		end
	elseif p115 == "objectOutlines" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("ObjectOutlines", p_u_116)
			return
		end
	elseif p115 == "reduceFlashing" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("ReduceFlashing", p_u_116)
			return
		end
	elseif p115 == "menuStyle" then
		if p_u_116 == "auto" or (p_u_116 == "v2" or p_u_116 == "classic") then
			v_u_2:SetAttribute("MenuStyle", p_u_116)
			return
		end
	elseif p115 == "taskTracker" then
		if p_u_116 == "full" or (p_u_116 == "compact" or p_u_116 == "off") then
			v_u_2:SetAttribute("TaskTracker", p_u_116)
			return
		end
	elseif p115 == "squadChat" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("SquadChatShow", p_u_116)
			return
		end
	elseif p115 == "skinFx" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("SkinFx", p_u_116)
			return
		end
	elseif p115 == "showClanColors" then
		if type(p_u_116) == "boolean" then
			pcall(function()
				-- upvalues: (copy) p_u_114, (copy) p_u_116
				p_u_114.cctx.lib.ClanTagText.setColors(p_u_116)
			end)
			return
		end
	elseif p115 == "weaponSkins" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("WeaponSkins", p_u_116)
			if p_u_116 == false then
				pcall(function()
					-- upvalues: (copy) p_u_114
					p_u_114.cctx.shared.SkinVisibility.start()
				end)
				return
			end
		end
	elseif p115 == "entryMode" then
		if p_u_116 == "full" or (p_u_116 == "short" or p_u_116 == "off") then
			v_u_2:SetAttribute("EntryMode", p_u_116)
			return
		end
	elseif p115 == "showFps" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("PerfHud", p_u_116)
			return
		end
	elseif p115 == "ammoStackNoAsk" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("AmmoStackNoAsk", p_u_116)
			return
		end
	elseif p115 == "crateQuick" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("CrateQuick", p_u_116)
			return
		end
	elseif p115 == "mapTasks" or p115 == "mapLabels" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute(p115 == "mapTasks" and "MapShowTasks" or "MapShowLabels", p_u_116)
			return
		end
	elseif p115 == "touchFire" then
		if p_u_116 == "auto" or (p_u_116 == "ring" or (p_u_116 == "both" or p_u_116 == "button")) then
			v_u_2:SetAttribute("TouchFireMode", p_u_116)
			return
		end
	elseif p115 == "hudLayoutP" or p115 == "hudLayoutT" then
		if type(p_u_116) == "string" then
			local v138, v_u_139 = pcall(function()
				-- upvalues: (copy) p_u_114
				return p_u_114.cctx.lib.HudLayoutStore
			end)
			if v138 and type(v_u_139) == "table" then
				pcall(function()
					-- upvalues: (copy) p_u_114, (copy) v_u_139
					local v140 = p_u_114.cctx.lib.HudLayout
					v_u_139.attach(v140)
					v_u_139.watch(p_u_114.cctx.config)
				end)
				v_u_139.load(p115 == "hudLayoutT" and "T" or "P", p_u_116)
				return
			end
		end
	elseif p115 == "cameraZoom" then
		local v141
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v141 = math.clamp(p_u_116, 1, 4)
		else
			v141 = nil
		end
		if v141 then
			local v142 = v141 + 0.5
			local v143 = math.floor(v142)
			v_u_2:SetAttribute("CameraZoomDefault", v143)
			local v144 = v118.Camera
			if v144 and v144.setZoom then
				local v145 = v144.setZoom
				pcall(v145, v143)
				return
			end
		end
	elseif p115 == "uiScale" then
		local v146
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v146 = math.clamp(p_u_116, 0.8, 1.4)
		else
			v146 = nil
		end
		if v146 then
			v_u_2:SetAttribute("UiScaleMul", v146)
			return
		end
	elseif p115 == "cameraShake" then
		local v147
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v147 = math.clamp(p_u_116, 0, 1)
		else
			v147 = nil
		end
		if v147 then
			v_u_2:SetAttribute("CameraShake", v147)
			return
		end
	elseif p115 == "aimAssist" then
		if type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("AimAssist", p_u_116)
			return
		end
	elseif v_u_113[p115] == nil then
		if p115 == "fpInvertY" then
			if type(p_u_116) == "boolean" then
				v_u_2:SetAttribute("FpInvertY", p_u_116)
				return
			end
		elseif p115 == "fpShoulder" then
			if p_u_116 == "right" or p_u_116 == "left" then
				v_u_2:SetAttribute("FpShoulder", p_u_116)
				return
			end
		elseif p115 == "voiceNoise" then
			if type(p_u_116) == "boolean" then
				v_u_2:SetAttribute("VoiceNoiseOpt", p_u_116)
				return
			end
		elseif p115 == "closeSearchOnHit" then
			if type(p_u_116) == "boolean" then
				v_u_2:SetAttribute("CloseSearchOnHit", p_u_116)
				return
			end
		elseif p115 == "hideMyGear" then
			if type(p_u_116) == "boolean" then
				v_u_2:SetAttribute("HideMyGear", p_u_116)
				return
			end
		elseif p115 == "hideOthersGear" and type(p_u_116) == "boolean" then
			v_u_2:SetAttribute("HideOthersGear", p_u_116)
		end
	else
		local v148 = v_u_113[p115]
		local v149 = v148[2]
		local v150 = v148[3]
		local v151
		if type(p_u_116) == "number" and p_u_116 == p_u_116 then
			v151 = math.clamp(p_u_116, v149, v150)
		else
			v151 = nil
		end
		if v151 then
			v_u_2:SetAttribute(v148[1], v151)
			return
		end
	end
end
local function v_u_167(p153, p154) -- name: current
	-- upvalues: (copy) v_u_6
	local v155 = table.clone(v_u_6)
	local v156 = p153.profile
	local v157
	if type(v156) == "table" then
		local v158 = v156.settings
		if type(v158) == "table" then
			v157 = v156.settings or nil
		else
			v157 = nil
		end
	else
		v157 = nil
	end
	if v157 then
		for v159, v160 in v157 do
			v155[v159] = v160
		end
	end
	if p154 then
		for v161, v162 in p154 do
			v155[v161] = v162
		end
	end
	local v163
	if v157 then
		local v164 = v157.reduceFlashing
		if type(v164) == "boolean" then
			return v155
		end
		if p154 then
			v163 = p154.reduceFlashing
			if type(v163) == "boolean" then
				return v155
			end
		end
	elseif p154 then
		v163 = p154.reduceFlashing
		if type(v163) == "boolean" then
			return v155
		end
	end
	local v165, v166 = pcall(function()
		return game:GetService("GuiService").ReducedMotionEnabled
	end)
	if v165 then
		v165 = v166 == true
	end
	v155.reduceFlashing = v165
	return v155
end
function v_u_1.apply(p_u_168, p169) -- name: apply
	-- upvalues: (copy) v_u_6, (copy) v_u_152, (copy) v_u_1
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v170, v171, v172, v173, v174, v175, v_u_176
	local v177 = 4
	while true do
		if v177 == 1 then
			v170 = p169.reduceFlashing
			if type(v170) == "boolean" then
				v177 = 3
			else
				v177 = 2
			end
		elseif v177 == 2 then
			v171, v172 = pcall(function()
				return game:GetService("GuiService").ReducedMotionEnabled
			end)
			if v171 then
				v171 = v172 == true
			end
			v_u_176.reduceFlashing = v171
			v177 = 3
		elseif v177 == 3 then
			for v178 in v_u_6 do
				v173 = v_u_152
				v174 = v_u_176[v178]
				pcall(v173, p_u_168, v178, v174, true)
			end
			pcall(function()
				-- upvalues: (copy) p_u_168, (copy) v_u_176
				local v179 = p_u_168.cctx.controllers.Input
				if v179 then
					local v180 = v179.loadKeyBindings
					if type(v180) == "function" then
						local v181 = v179.loadKeyBindings
						local v182 = v_u_176.keybinds
						v181(type(v182) ~= "string" and "" or v_u_176.keybinds)
					end
				end
			end)
			pcall(function()
				-- upvalues: (copy) p_u_168, (copy) v_u_176
				p_u_168.cctx.emit("settings.changed", v_u_176)
			end)
			if not p_u_168._reapplyHook then
				p_u_168._reapplyHook = true
				v175 = function()
					-- upvalues: (copy) p_u_168, (ref) v_u_1
					p_u_168.cctx.command("settings.reapply", function()
						-- upvalues: (ref) p_u_168, (ref) v_u_1
						local v183 = p_u_168.cctx.net.invoke
						local v184, v185 = pcall(v183, "menu.get", {
							["what"] = "settings"
						})
						if not v184 or (type(v185) ~= "table" or v185.error ~= nil) then
							return "menu.get failed: " .. tostring(v185)
						end
						v_u_1.apply(p_u_168, v185)
						local v186 = string.format
						local v187 = v185.touchFire
						local v188 = tostring(v187)
						local v189 = v185.hudLayoutP
						local v190 = tostring(v189)
						local v191 = v185.hudLayoutT
						return v186("reapplied: touchFire=%s hudLayoutP=[%s] hudLayoutT=[%s]", v188, v190, (tostring(v191)))
					end)
				end
				pcall(v175)
			end
			return
		else
			v_u_176 = table.clone(v_u_6)
			if type(p169) == "table" then
				for v192, v193 in p169 do
					v_u_176[v192] = v193
				end
			end
			if type(p169) == "table" then
				v177 = 1
			else
				v177 = 2
			end
		end
	end
end
function v_u_1.new(p_u_194, p_u_195, p196) -- name: new
	-- upvalues: (copy) v_u_152, (copy) v_u_167, (copy) v_u_1, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (ref) v_u_3
	local v_u_197 = p196 or {}
	local v_u_198 = p_u_194.ui
	local v_u_199 = p_u_194.theme
	local v_u_200 = v_u_199.color
	local v201 = p_u_194.kit
	local v_u_202 = p_u_194.cctx.lib.MenuSettingsLayout
	local v_u_203 = game:GetService("UserInputService")
	local v_u_204 = game:GetService("GuiService")
	local v_u_205 = {}
	local v_u_206 = {}
	local v_u_207 = 0
	local v_u_208 = {}
	local v_u_209 = {}
	local v_u_210 = true
	local v211 = p_u_194.compact() and 900 or 1100
	local v212 = v_u_199.safeRefSize().X - 48
	local v213 = math.min(v211, v212)
	local v_u_214, v215 = v_u_198.panel({
		["parent"] = nil,
		["name"] = "Settings",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["padding"] = 0,
		["parent"] = p_u_195,
		["position"] = UDim2.new(0.5, 0, 0, 8),
		["anchor"] = Vector2.new(0.5, 0),
		["size"] = UDim2.new(0, v213, 1, -8)
	})
	v_u_198.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new((1 / 0), 800)
	}, v_u_214)
	local v216 = v_u_199.isTouch()
	local v_u_217 = v_u_202.compute(v213, 600, {
		["scale"] = nil,
		["touch"] = nil,
		["raid"] = nil,
		["cardOn"] = true,
		["scale"] = v_u_199.uiScale(),
		["touch"] = v216,
		["raid"] = v_u_197.raid == true
	})
	local v_u_218 = v_u_217.rowW
	local v_u_219 = v_u_217.kbW
	local v220 = v_u_217.itemH
	local v221 = v_u_199.touch
	local v222 = math.max(v220, v221(44))
	local v223 = v_u_217.pad
	v_u_198.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Settings",
		["style"] = "h2",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v215,
		["position"] = UDim2.fromOffset(v_u_217.title.x, v_u_217.title.y),
		["size"] = UDim2.fromOffset(v_u_217.title.w, v_u_217.title.h)
	})
	local v_u_224 = v_u_198.new("ScrollingFrame", {
		["Name"] = "Rail",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 0,
		["ElasticBehavior"] = nil,
		["Position"] = UDim2.fromOffset(v_u_217.rail.x, v_u_217.rail.y),
		["Size"] = UDim2.new(0, v_u_217.rail.w, 1, -(v_u_217.rail.y + v223)),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
	}, v215)
	v_u_198.layout(v_u_224, "v", v_u_202.GAP)
	local v225 = v_u_198.new("Frame", {
		["Name"] = "Heading",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_217.heading.x, v_u_217.heading.y),
		["Size"] = UDim2.fromOffset(v_u_217.heading.w, v_u_217.heading.h)
	}, v215)
	local v_u_226 = v_u_198.label({
		["parent"] = nil,
		["name"] = "HeadingText",
		["text"] = "",
		["style"] = "h3",
		["size"] = nil,
		["parent"] = v225,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	local v_u_227 = v_u_198.label({
		["parent"] = nil,
		["name"] = "HeadingLine",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v225,
		["color"] = v_u_200.text2,
		["position"] = UDim2.fromOffset(0, 24),
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_228 = v_u_198.list({
		["parent"] = nil,
		["gap"] = 10,
		["padding"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v215,
		["padding"] = {
			0,
			4,
			0,
			12
		},
		["position"] = UDim2.fromOffset(v_u_217.list.x, v_u_217.list.y),
		["size"] = UDim2.new(0, v_u_217.list.w, 1, -(v_u_217.list.y + v223))
	})
	local v_u_229 = {}
	local function v234(p230, p231, p232) -- name: newCat
		-- upvalues: (copy) v_u_198, (copy) v_u_202, (copy) v_u_228, (copy) v_u_229
		local v233 = v_u_198.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Visible"] = false,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = p231,
			["Size"] = UDim2.new(0, p232, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = v_u_202.INDEX[p230]
		}, v_u_228)
		v_u_198.layout(v233, "v", 6)
		v_u_229[p230] = v233
		return v233
	end
	local v235 = v234("gameplay", "catGameplay", v_u_218)
	local v_u_236 = v234("controls", "catControls", v_u_219)
	local v237 = v234("touch", "catTouch", v_u_218)
	local v238 = v234("camera", "catCamera", v_u_218)
	local v239 = v234("graphics", "catGraphics", v_u_218)
	local v_u_240 = v234("audio", "catAudio", v_u_218)
	local v241 = v234("interface", "catInterface", v_u_218)
	local v_u_242 = v234("account", "catAccount", v_u_218)
	local function v_u_249() -- name: deviceNow
		-- upvalues: (copy) p_u_194, (copy) v_u_198
		local function v243()
			-- upvalues: (ref) p_u_194
			return p_u_194.cctx.controllers.Input.device()
		end
		local v244, v245 = pcall(v243)
		if v244 and type(v245) == "string" then
			return v245
		end
		local v246 = v_u_198.device
		local v247, v248 = pcall(v246)
		return (not v247 or type(v248) ~= "string") and "" or v248
	end
	local function v_u_250() end
	local v_u_251 = ""
	local v_u_252 = v_u_202.visible({
		["raid"] = nil,
		["tradeOn"] = false,
		["raid"] = v_u_197.raid == true
	})
	local v_u_253 = {}
	local function v_u_259() -- name: paintRail
		-- upvalues: (copy) v_u_253, (ref) v_u_251, (copy) v_u_200, (ref) v_u_252
		for v254, v255 in v_u_253 do
			local v256 = v254 == v_u_251
			v255.bar.Visible = v256
			v255.btn.BackgroundTransparency = v256 and 0.2 or (v255.hover and 0.6 or 1)
			local v257 = v255.lbl
			local v258
			if v256 or v255.hover then
				v258 = v_u_200.text
			else
				v258 = v_u_200.text2
			end
			v257.TextColor3 = v258
			v255.btn.Visible = v_u_252[v254] ~= false
		end
	end
	local v_u_260 = v_u_252
	for v261, v_u_262 in v_u_202.CATEGORIES do
		local v263 = v_u_198.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Cat_" .. v_u_262.id,
			["BackgroundColor3"] = v_u_200.raised,
			["Size"] = UDim2.new(1, 0, 0, v222),
			["LayoutOrder"] = v261
		}, v_u_224)
		local v264 = v_u_198.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_200.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v263)
		local v_u_265 = v_u_198.new("TextLabel", {
			["Name"] = "Text",
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Text"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = v_u_199.font.heading,
			["TextSize"] = v_u_202.RAIL_TEXT_SIZE,
			["TextColor3"] = v_u_200.text2,
			["Text"] = v_u_199.track(string.upper(v_u_262.bar), 1),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(v_u_217.railText.x, 0),
			["Size"] = UDim2.new(0, v_u_217.railText.w, 1, 0)
		}, v263)
		pcall(function()
			-- upvalues: (copy) p_u_194, (copy) v_u_265, (copy) v_u_217
			p_u_194.cctx.lib.TextFitting.fit(v_u_265, v_u_217.railText.w, 11)
		end)
		local v_u_266 = {
			["btn"] = nil,
			["bar"] = nil,
			["lbl"] = nil,
			["hover"] = false,
			["btn"] = v263,
			["bar"] = v264,
			["lbl"] = v_u_265
		}
		v_u_253[v_u_262.id] = v_u_266
		v263.SelectionImageObject = v_u_198.selectionImage()
		v263.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_266, (copy) v_u_262, (ref) v_u_251, (copy) v_u_198, (copy) v_u_199, (copy) v_u_259
			v_u_266.hover = true
			if v_u_262.id ~= v_u_251 then
				v_u_198.sound(v_u_199.sounds.hover)
			end
			v_u_259()
		end)
		v263.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_266, (copy) v_u_259
			v_u_266.hover = false
			v_u_259()
		end)
		v263.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_266, (copy) v_u_259
			v_u_266.hover = true
			v_u_259()
		end)
		v263.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_266, (copy) v_u_259
			v_u_266.hover = false
			v_u_259()
		end)
		v263.Activated:Connect(function()
			-- upvalues: (copy) v_u_262, (ref) v_u_251, (copy) v_u_198, (copy) v_u_199, (ref) v_u_250
			if v_u_262.id ~= v_u_251 then
				v_u_198.sound(v_u_199.sounds.tab)
				v_u_250(v_u_262.id, true)
			end
		end)
	end
	local function v_u_269(p267) -- name: setCatVisible
		-- upvalues: (ref) v_u_260, (copy) v_u_202, (copy) v_u_197, (copy) v_u_259, (ref) v_u_251, (ref) v_u_250
		v_u_260 = v_u_202.visible({
			["raid"] = v_u_197.raid == true,
			["tradeOn"] = p267
		})
		v_u_259()
		if v_u_251 ~= "" and v_u_260[v_u_251] == false then
			local v268 = {
				["touch"] = false,
				["visible"] = nil,
				["visible"] = v_u_260
			}
			v_u_250(v_u_202.initial(v268), false)
		end
	end
	local v270 = p_u_194.profile
	local v271
	if type(v270) == "table" then
		local v272 = v270.settings
		v271 = type(v272) == "table" and (v270.settings or {}) or {}
	else
		v271 = {}
	end
	v201.section(v235, "Raid", 1)
	local _, v279 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "CloseSearchOnHit",
		["label"] = "Close search when hit",
		["value"] = nil,
		["width"] = nil,
		["order"] = 2,
		["onChange"] = nil,
		["parent"] = v235,
		["value"] = v271.closeSearchOnHit == true,
		["width"] = v_u_218,
		["onChange"] = function(p273) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v274 = p273 == true
			local v275 = v_u_152
			local v276 = p_u_194
			pcall(v275, v276, "closeSearchOnHit", v274)
			v_u_206.closeSearchOnHit = v274
			v_u_207 = os.clock() + 0
			local v_u_277 = p_u_194
			local v_u_278 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_277, (copy) v_u_278
				v_u_277.cctx.emit("settings.changed", v_u_278)
			end)
		end
	})
	v_u_208.closeSearchOnHit = v279
	v_u_198.label({
		["parent"] = nil,
		["text"] = "On: taking a hit while a container or body is open closes the loot and the inventory, so you can fight. Off: it stays open.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v235,
		["color"] = v_u_200.text2
	})
	local _, v286 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "AmmoStackAsk",
		["label"] = "Ask before stacking found in raid items",
		["value"] = nil,
		["width"] = nil,
		["order"] = 4,
		["onChange"] = nil,
		["parent"] = v235,
		["value"] = v271.ammoStackNoAsk ~= true,
		["width"] = v_u_218,
		["onChange"] = function(p280) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v281 = p280 ~= true
			local v282 = v_u_152
			local v283 = p_u_194
			pcall(v282, v283, "ammoStackNoAsk", v281)
			v_u_206.ammoStackNoAsk = v281
			v_u_207 = os.clock() + 0
			local v_u_284 = p_u_194
			local v_u_285 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_284, (copy) v_u_285
				v_u_284.cctx.emit("settings.changed", v_u_285)
			end)
		end
	})
	v_u_208.ammoStackNoAsk = v286
	v_u_198.label({
		["parent"] = nil,
		["text"] = "On: stacking found in raid items onto items that are not found in raid asks first, because the stacked items stop counting as found in raid. Off: it stacks without asking.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 5,
		["parent"] = v235,
		["color"] = v_u_200.text2
	})
	local v292 = {
		["parent"] = nil,
		["name"] = "EntryMode",
		["label"] = "Entry animation",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 6,
		["onChange"] = nil,
		["parent"] = v235,
		["options"] = {
			{
				["id"] = "full",
				["text"] = "Full"
			},
			{
				["id"] = "short",
				["text"] = "Short"
			},
			{
				["id"] = "off",
				["text"] = "Off"
			}
		},
		["value"] = v271.entryMode ~= "short" and v271.entryMode ~= "off" and "full" or v271.entryMode,
		["width"] = v_u_218,
		["onChange"] = function(p287) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v288 = v_u_152
			local v289 = p_u_194
			pcall(v288, v289, "entryMode", p287)
			v_u_206.entryMode = p287
			v_u_207 = os.clock() + 0
			local v_u_290 = p_u_194
			local v_u_291 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_290, (copy) v_u_291
				v_u_290.cctx.emit("settings.changed", v_u_291)
			end)
		end
	}
	local _, v293 = v_u_198.dropdown(v292)
	v_u_208.entryMode = v293
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Full plays the whole arrival. Short plays the last 3 seconds. Off puts you on the ground at once.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 7,
		["parent"] = v235,
		["color"] = v_u_200.text2
	})
	v201.section(v235, "Raid map", 10)
	local _, v300 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "MapTasks",
		["label"] = "Map shows tasks",
		["value"] = nil,
		["width"] = nil,
		["order"] = 11,
		["onChange"] = nil,
		["parent"] = v235,
		["value"] = v271.mapTasks ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p294) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v295 = p294 == true
			local v296 = v_u_152
			local v297 = p_u_194
			pcall(v296, v297, "mapTasks", v295)
			v_u_206.mapTasks = v295
			v_u_207 = os.clock() + 0
			local v_u_298 = p_u_194
			local v_u_299 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_298, (copy) v_u_299
				v_u_298.cctx.emit("settings.changed", v_u_299)
			end)
		end
	})
	v_u_208.mapTasks = v300
	local _, v307 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "MapLabels",
		["label"] = "Map shows labels",
		["value"] = nil,
		["width"] = nil,
		["order"] = 12,
		["onChange"] = nil,
		["parent"] = v235,
		["value"] = v271.mapLabels ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p301) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v302 = p301 == true
			local v303 = v_u_152
			local v304 = p_u_194
			pcall(v303, v304, "mapLabels", v302)
			v_u_206.mapLabels = v302
			v_u_207 = os.clock() + 0
			local v_u_305 = p_u_194
			local v_u_306 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_305, (copy) v_u_306
				v_u_305.cctx.emit("settings.changed", v_u_306)
			end)
		end
	})
	v_u_208.mapLabels = v307
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Off: the paper map hides the task chips, or the place names, for a clearer overview. A task you select in its list still shows its marker. You can also switch both on the map itself.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 13,
		["parent"] = v235,
		["color"] = v_u_200.text2
	})
	v201.section(v235, "Crates", 20)
	local _, v314 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "CrateQuick",
		["label"] = "Quick case opening",
		["value"] = nil,
		["width"] = nil,
		["order"] = 21,
		["onChange"] = nil,
		["parent"] = v235,
		["value"] = v271.crateQuick == true,
		["width"] = v_u_218,
		["onChange"] = function(p308) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v309 = p308 == true
			local v310 = v_u_152
			local v311 = p_u_194
			pcall(v310, v311, "crateQuick", v309)
			v_u_206.crateQuick = v309
			v_u_207 = os.clock() + 0
			local v_u_312 = p_u_194
			local v_u_313 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_312, (copy) v_u_313
				v_u_312.cctx.emit("settings.changed", v_u_313)
			end)
		end
	})
	v_u_208.crateQuick = v314
	v_u_198.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 22,
		["parent"] = v235,
		["text"] = v_u_1.TEXT.crateQuick,
		["color"] = v_u_200.text2
	})
	local v315 = v_u_198.new("Frame", {
		["Name"] = "SquadRules",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 30,
		["Visible"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Visible"] = v_u_197.raid ~= true
	}, v235)
	v_u_198.layout(v315, "v", 6)
	v201.section(v315, "Squad rules", 1)
	local v_u_316 = true
	local v_u_317 = 0.25
	local function v319()
		-- upvalues: (ref) v_u_316, (copy) p_u_194, (ref) v_u_317
		v_u_316 = p_u_194.config.flag("FriendlyFire") == true
		local v318 = p_u_194.config.flag
		v_u_317 = tonumber(v318("FriendlyFireScale")) or 0.25
	end
	pcall(v319)
	local v320 = v201.stat
	local v321 = v315
	local v322 = "Friendly fire in your squad"
	local v323
	if v_u_316 then
		local v324 = v_u_317 * 100 + 0.5
		v323 = ("ON  \194\183  %d%% damage"):format((math.floor(v324)))
	else
		v323 = "OFF"
	end
	local v325 = 2
	local v326
	if v_u_316 then
		v326 = v_u_200.accent
	else
		v326 = v_u_200.success
	end
	local _, v327 = v320(v321, v322, v323, v325, v326)
	v_u_208.ff = v327
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Other squads can never hurt you. The server sets this; it is shown for information.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v315,
		["color"] = v_u_200.text2
	})
	local v_u_328 = nil
	local v329 = v_u_198.new("Frame", {
		["Name"] = "AimBox",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(0, v_u_218, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_236)
	v_u_198.layout(v329, "v", 6)
	v201.section(v329, "Aiming", 1)
	local _, v336 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "AimAssist",
		["label"] = "Aim assist",
		["value"] = nil,
		["width"] = nil,
		["order"] = 2,
		["onChange"] = nil,
		["parent"] = v329,
		["value"] = v271.aimAssist ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p330) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v331 = p330 == true
			local v332 = v_u_152
			local v333 = p_u_194
			pcall(v332, v333, "aimAssist", v331)
			v_u_206.aimAssist = v331
			v_u_207 = os.clock() + 0
			local v_u_334 = p_u_194
			local v_u_335 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_334, (copy) v_u_335
				v_u_334.cctx.emit("settings.changed", v_u_335)
			end)
		end
	})
	v_u_208.aimAssist = v336
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Touch and controller only: the aim drifts gently toward an infected near your aim. Mouse aim is never assisted.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v329,
		["color"] = v_u_200.text2
	})
	v201.section(v_u_236, "Key bindings", 10)
	local v_u_337 = v_u_198.label({
		["parent"] = nil,
		["name"] = "PadHelp",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 12,
		["parent"] = v_u_236,
		["text"] = v_u_1.TEXT.padNote,
		["color"] = v_u_200.text2
	})
	v_u_337.Visible = false
	local function v_u_343(p338) -- name: padTextOf
		-- upvalues: (copy) p_u_194, (ref) v_u_1
		local v339 = p_u_194.cctx.controllers.Input
		local v340 = v_u_1.padWord
		local v341
		if v339 then
			local v342 = v339.ACTIONS
			if type(v342) == "table" then
				v341 = v339.ACTIONS
			else
				v341 = nil
			end
		else
			v341 = nil
		end
		return v340(v341, p338)
	end
	local function v_u_358() -- name: ensureKeybinds
		-- upvalues: (ref) v_u_328, (copy) p_u_194, (copy) v_u_236, (copy) v_u_219, (copy) v_u_343, (ref) v_u_152, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		if v_u_328 then
			return
		else
			local function v344()
				-- upvalues: (ref) p_u_194
				return p_u_194.cctx.lib.MenuKeybinds
			end
			local v345, v346 = pcall(v344)
			if v345 and type(v346) == "table" then
				local v347 = v346.new
				local v348 = p_u_194
				local v349 = v_u_236
				local v355 = {
					["width"] = nil,
					["order"] = 11,
					["padText"] = nil,
					["save"] = nil,
					["width"] = v_u_219,
					["padText"] = v_u_343,
					["save"] = function(p350) -- name: save
						-- upvalues: (ref) v_u_152, (ref) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
						local v351 = v_u_152
						local v352 = p_u_194
						pcall(v351, v352, "keybinds", p350)
						v_u_206.keybinds = p350
						v_u_207 = os.clock() + 0
						local v_u_353 = p_u_194
						local v_u_354 = v_u_167(p_u_194, v_u_206)
						pcall(function()
							-- upvalues: (copy) v_u_353, (copy) v_u_354
							v_u_353.cctx.emit("settings.changed", v_u_354)
						end)
					end
				}
				local v356, v357 = pcall(v347, v348, v349, v355)
				if v356 then
					v_u_328 = v357
				else
					warn("[MenuSettings] keybinds page failed:", v357)
				end
			else
				return
			end
		end
	end
	local function v_u_367() -- name: editStateNow
		-- upvalues: (copy) v_u_198, (ref) v_u_1, (copy) p_u_194, (copy) v_u_197, (copy) v_u_203
		local v359 = v_u_198.device
		local v360, v361 = pcall(v359)
		local v362 = v_u_1.editState
		local v_u_363 = "TouchLayoutEdit"
		local function v364()
			-- upvalues: (ref) p_u_194, (copy) v_u_363
			return p_u_194.cctx.config.flag(v_u_363)
		end
		local v365, v366 = pcall(v364)
		return v362(not v365 or v366 ~= false, v_u_197.raid == true, v_u_203.TouchEnabled or game:GetService("RunService"):IsStudio(), (not v360 or type(v361) ~= "string") and "" or v361)
	end
	local v368 = v_u_217.card
	local v369 = v_u_217.cardText
	local v370 = v_u_217.cardButton
	local v_u_371 = v_u_198.new("Frame", {
		["Name"] = "HudCard",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["BackgroundColor3"] = v_u_200.raised,
		["Size"] = UDim2.fromOffset(v368.w, v368.h)
	}, v237)
	local v_u_372 = v_u_198.stroke(v_u_371, v_u_200.line, 1)
	v_u_198.label({
		["parent"] = nil,
		["name"] = "HudCardTitle",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_371,
		["text"] = v_u_1.TEXT.hudCardTitle,
		["color"] = v_u_200.accent,
		["position"] = UDim2.fromOffset(v369.x, v369.y),
		["size"] = UDim2.fromOffset(v369.w, 20)
	})
	local v373 = v_u_198.label
	local v374 = {
		["parent"] = nil,
		["name"] = "HudCardLine",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_371,
		["text"] = v_u_1.TEXT.hudCardLine,
		["color"] = v_u_200.text2,
		["position"] = UDim2.fromOffset(v369.x, v369.y + 22)
	}
	local v375 = UDim2.fromOffset
	local v376 = v369.w
	local v377 = v369.h - 22
	v374.size = v375(v376, (math.max(18, v377)))
	v373(v374)
	local v394, _ = v_u_198.button({
		["parent"] = nil,
		["name"] = "EditHud",
		["text"] = nil,
		["kind"] = "primary",
		["icon"] = "settings",
		["height"] = nil,
		["width"] = nil,
		["position"] = nil,
		["size"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_371,
		["text"] = v_u_1.TEXT.hudCardButton,
		["height"] = v370.h,
		["width"] = v370.w,
		["position"] = UDim2.fromOffset(v370.x, v370.y),
		["size"] = UDim2.fromOffset(v370.w, v370.h),
		["onClick"] = function() -- name: openHudEditor
			-- upvalues: (copy) v_u_367, (copy) p_u_194, (copy) v_u_198, (copy) v_u_197, (copy) v_u_208
			local v378 = v_u_367()
			if v378 == "ok" and true or v378 == "raid" then
				local function v379()
					-- upvalues: (ref) p_u_194
					return p_u_194.cctx.lib.HudEdit
				end
				local v380, v381 = pcall(v379)
				if v380 and type(v381) == "table" then
					if v_u_197.raid then
						local function v382()
							-- upvalues: (ref) p_u_194
							p_u_194.cctx.controllers.RaidSettings.close()
						end
						pcall(v382)
					end
					local v383 = v381.open
					local v384 = p_u_194.cctx
					local v391 = {
						["afterSave"] = function(p_u_385) -- name: afterSave
							-- upvalues: (ref) p_u_194, (ref) v_u_208
							local function v390()
								-- upvalues: (ref) p_u_194, (copy) p_u_385, (ref) v_u_208
								local v386 = p_u_194.profile
								if type(v386) == "table" then
									local v387 = v386.settings
									if type(v387) ~= "table" then
										v386.settings = {}
									end
									for v388, v389 in p_u_385 do
										v386.settings[v388] = v389
									end
								end
								if p_u_385.touchFire and v_u_208.touchFire then
									v_u_208.touchFire.set(p_u_385.touchFire)
								end
							end
							pcall(v390)
						end
					}
					local v392, v393 = pcall(v383, v384, v391)
					if not v392 then
						warn("[MenuSettings] HUD editor failed:", v393)
						v_u_198.toast("The HUD editor could not open", "warn")
					end
				else
					v_u_198.toast("The HUD editor is not available", "warn")
				end
			else
				return
			end
		end
	})
	local v_u_395 = v394
	local v_u_396 = v_u_198.label({
		["parent"] = nil,
		["name"] = "EditHudNote",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 2,
		["parent"] = v237,
		["text"] = v_u_1.TEXT.editNormal,
		["color"] = v_u_200.text2
	})
	v201.section(v237, "Buttons and sticks", 10)
	local v402 = {
		["parent"] = nil,
		["name"] = "TouchFire",
		["label"] = "Fire control",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 11,
		["onChange"] = nil,
		["parent"] = v237,
		["options"] = {
			{
				["id"] = "auto",
				["text"] = "Auto"
			},
			{
				["id"] = "ring",
				["text"] = "Ring only"
			},
			{
				["id"] = "both",
				["text"] = "Ring and button"
			},
			{
				["id"] = "button",
				["text"] = "Button only"
			}
		},
		["value"] = v271.touchFire ~= "ring" and (v271.touchFire ~= "both" and v271.touchFire ~= "button") and "auto" or v271.touchFire,
		["width"] = v_u_218,
		["onChange"] = function(p397) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v398 = v_u_152
			local v399 = p_u_194
			pcall(v398, v399, "touchFire", p397)
			v_u_206.touchFire = p397
			v_u_207 = os.clock() + 0
			local v_u_400 = p_u_194
			local v_u_401 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_400, (copy) v_u_401
				v_u_400.cctx.emit("settings.changed", v_u_401)
			end)
		end
	}
	local v403, v404 = v_u_198.dropdown(v402)
	local v_u_405 = v403
	v_u_208.touchFire = v404
	local v_u_406 = v_u_198.label({
		["parent"] = nil,
		["name"] = "TouchFireNote",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 12,
		["parent"] = v237,
		["text"] = v_u_1.TEXT.fireHelp,
		["color"] = v_u_200.text2
	})
	local v407 = v_u_198.dropdown
	local v408 = {
		["parent"] = nil,
		["name"] = "TouchSize",
		["label"] = "Touch button size",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 13,
		["onChange"] = nil,
		["parent"] = v237,
		["options"] = {
			{
				["id"] = "1",
				["text"] = "Small"
			},
			{
				["id"] = "2",
				["text"] = "Default"
			},
			{
				["id"] = "3",
				["text"] = "Large"
			}
		}
	}
	local v409 = v271.touchSize
	local v410 = tonumber(v409) or 2
	v408.value = tostring(v410)
	v408.width = v_u_218
	function v408.onChange(p411) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v412 = tonumber(p411) or 2
		local v413 = v_u_152
		local v414 = p_u_194
		pcall(v413, v414, "touchSize", v412)
		v_u_206.touchSize = v412
		v_u_207 = os.clock() + 0
		local v_u_415 = p_u_194
		local v_u_416 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_415, (copy) v_u_416
			v_u_415.cctx.emit("settings.changed", v_u_416)
		end)
	end
	local _, v417 = v407(v408)
	v_u_208.touchSize = v417
	local v418 = v_u_198.dropdown
	local v419 = {
		["parent"] = nil,
		["name"] = "TouchStick",
		["label"] = "Touch stick size",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 14,
		["onChange"] = nil,
		["parent"] = v237,
		["options"] = {
			{
				["id"] = "1",
				["text"] = "Small"
			},
			{
				["id"] = "2",
				["text"] = "Default"
			},
			{
				["id"] = "3",
				["text"] = "Large"
			},
			{
				["id"] = "4",
				["text"] = "Extra large"
			}
		}
	}
	local v420 = v271.touchStick
	local v421 = (tonumber(v420) or 2) + 0.5
	local v422 = math.floor(v421)
	local v423 = math.clamp(v422, 1, 4)
	v419.value = tostring(v423)
	v419.width = v_u_218
	function v419.onChange(p424) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v425 = tonumber(p424) or 2
		local v426 = v_u_152
		local v427 = p_u_194
		pcall(v426, v427, "touchStick", v425)
		v_u_206.touchStick = v425
		v_u_207 = os.clock() + 0
		local v_u_428 = p_u_194
		local v_u_429 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_428, (copy) v_u_429
			v_u_428.cctx.emit("settings.changed", v_u_429)
		end)
	end
	local _, v430 = v418(v419)
	v_u_208.touchStick = v430
	local _, v437 = v_u_198.dropdown({
		["parent"] = nil,
		["name"] = "TouchMoveFixed",
		["label"] = "Touch move stick",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 15,
		["onChange"] = nil,
		["parent"] = v237,
		["options"] = {
			{
				["id"] = "float",
				["text"] = "Under thumb"
			},
			{
				["id"] = "fixed",
				["text"] = "Fixed corner"
			}
		},
		["value"] = v271.touchMoveFixed == true and "fixed" or "float",
		["width"] = v_u_218,
		["onChange"] = function(p431) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v432 = p431 == "fixed"
			local v433 = v_u_152
			local v434 = p_u_194
			pcall(v433, v434, "touchMoveFixed", v432)
			v_u_206.touchMoveFixed = v432
			v_u_207 = os.clock() + 0
			local v_u_435 = p_u_194
			local v_u_436 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_435, (copy) v_u_436
				v_u_435.cctx.emit("settings.changed", v_u_436)
			end)
		end
	})
	v_u_208.touchMoveFixed = v437
	local v438 = v_u_198.dropdown
	local v439 = {
		["parent"] = nil,
		["name"] = "TouchOpacity",
		["label"] = "Touch control opacity",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 16,
		["onChange"] = nil,
		["parent"] = v237,
		["options"] = {
			{
				["id"] = "1",
				["text"] = "Faint"
			},
			{
				["id"] = "2",
				["text"] = "Default"
			},
			{
				["id"] = "3",
				["text"] = "Strong"
			}
		}
	}
	local v440 = v271.touchOpacity
	local v441 = (tonumber(v440) or 2) + 0.5
	local v442 = math.floor(v441)
	local v443 = math.clamp(v442, 1, 3)
	v439.value = tostring(v443)
	v439.width = v_u_218
	function v439.onChange(p444) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v445 = tonumber(p444) or 2
		local v446 = v_u_152
		local v447 = p_u_194
		pcall(v446, v447, "touchOpacity", v445)
		v_u_206.touchOpacity = v445
		v_u_207 = os.clock() + 0
		local v_u_448 = p_u_194
		local v_u_449 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_448, (copy) v_u_449
			v_u_448.cctx.emit("settings.changed", v_u_449)
		end)
	end
	local _, v450 = v438(v439)
	v_u_208.touchOpacity = v450
	v_u_198.label({
		["parent"] = nil,
		["name"] = "TouchLayoutNote",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 17,
		["parent"] = v237,
		["text"] = v_u_1.TEXT.touchLayout,
		["color"] = v_u_200.text2
	})
	local function v_u_462() -- name: paintTouchRows
		-- upvalues: (copy) p_u_194, (ref) v_u_405, (ref) v_u_406, (copy) v_u_367, (ref) v_u_395, (ref) v_u_396, (ref) v_u_1, (copy) v_u_200, (ref) v_u_371, (copy) v_u_249, (ref) v_u_372
		local v_u_451 = "FireOptions"
		local function v452()
			-- upvalues: (ref) p_u_194, (copy) v_u_451
			return p_u_194.cctx.config.flag(v_u_451)
		end
		local v453, v454 = pcall(v452)
		local v455 = not v453 or v454 ~= false
		v_u_405.Visible = v455
		v_u_406.Visible = v455
		local v456 = v_u_367()
		local v457 = v456 == "ok" and true or v456 == "raid"
		v_u_395.Visible = v457
		v_u_396.Visible = v456 ~= "off"
		v_u_396.Text = v_u_1.editNote(v456)
		local v458 = v_u_396
		local v459
		if v456 == "raid" then
			v459 = v_u_200.accent
		else
			v459 = v_u_200.text2
		end
		v458.TextColor3 = v459
		v_u_371.Visible = v456 ~= "off"
		if v457 then
			v457 = v_u_249() == "Touch"
		end
		local v460 = v_u_372
		local v461
		if v457 then
			v461 = v_u_200.accent
		else
			v461 = v_u_200.line
		end
		v460.Color = v461
		v_u_372.Thickness = v457 and 2 or 1
	end
	v_u_462()
	local v_u_463 = v_u_198.new("Frame", {
		["Name"] = "TouchHelp",
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 20,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v237)
	v_u_198.layout(v_u_463, "v", 4)
	v201.section(v_u_463, "Touch controls", 0)
	for v464, v465 in v_u_1.TEXT.touchHelp do
		v_u_198.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_463,
			["name"] = "Help" .. v464,
			["text"] = v465,
			["color"] = v_u_200.text2,
			["order"] = v464
		})
	end
	v201.section(v238, "Camera", 1)
	local v466 = v_u_198.slider
	local v467 = {
		["parent"] = nil,
		["label"] = "Default camera zoom",
		["min"] = 1,
		["max"] = 4,
		["step"] = 1,
		["value"] = nil,
		["width"] = nil,
		["order"] = 2,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v468 = v271.cameraZoom
	v467.value = tonumber(v468) or 2
	v467.width = v_u_218
	function v467.format(p469) -- name: format
		local v470 = p469 + 0.5
		local v471 = math.floor(v470)
		return v471 == 1 and "Close" or (v471 == 2 and "Normal" or (v471 == 3 and "Far" or "Farthest"))
	end
	function v467.onChange(p472) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v473 = p472 + 0.5
		local v474 = math.floor(v473)
		local v475 = v_u_152
		local v476 = p_u_194
		pcall(v475, v476, "cameraZoom", v474)
		v_u_206.cameraZoom = v474
		v_u_207 = os.clock() + 0.6
		local v_u_477 = p_u_194
		local v_u_478 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_477, (copy) v_u_478
			v_u_477.cctx.emit("settings.changed", v_u_478)
		end)
	end
	local _, v479 = v466(v467)
	v_u_208.cameraZoom = v479
	local v480 = v_u_198.slider
	local v481 = {
		["parent"] = nil,
		["label"] = "Camera shake",
		["min"] = 0,
		["max"] = 1,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 3,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v482 = v271.cameraShake
	v481.value = tonumber(v482) or 1
	v481.width = v_u_218
	function v481.format(p483) -- name: format
		local v484 = p483 * 100 + 0.5
		return ("%d%%"):format((math.floor(v484)))
	end
	function v481.onChange(p485) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v486 = v_u_152
		local v487 = p_u_194
		pcall(v486, v487, "cameraShake", p485)
		v_u_206.cameraShake = p485
		v_u_207 = os.clock() + 0.6
		local v_u_488 = p_u_194
		local v_u_489 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_488, (copy) v_u_489
			v_u_488.cctx.emit("settings.changed", v_u_489)
		end)
	end
	local _, v490 = v480(v481)
	v_u_208.cameraShake = v490
	v201.section(v238, "FIRST / THIRD PERSON", 20)
	local v_u_491 = 90
	local function v492()
		-- upvalues: (ref) v_u_491, (copy) p_u_194, (ref) v_u_2
		v_u_491 = p_u_194.cctx.lib.PerkSight.fovCeilOf(v_u_2)
	end
	pcall(v492)
	local v493 = v_u_198.slider
	local v494 = {
		["parent"] = nil,
		["name"] = "FpFov",
		["label"] = "Field of view",
		["min"] = 50,
		["max"] = nil,
		["step"] = 1,
		["value"] = nil,
		["width"] = nil,
		["order"] = 21,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238,
		["max"] = v_u_491
	}
	local v495 = v271.fov
	v494.value = tonumber(v495) or v_u_6.fov
	v494.width = v_u_218
	function v494.format(p496) -- name: format
		local v497 = p496 + 0.5
		return ("%d"):format((math.floor(v497)))
	end
	function v494.onChange(p498) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v499 = p498 + 0.5
		local v500 = math.floor(v499)
		local v501 = v_u_152
		local v502 = p_u_194
		pcall(v501, v502, "fov", v500)
		v_u_206.fov = v500
		v_u_207 = os.clock() + 0.6
		local v_u_503 = p_u_194
		local v_u_504 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_503, (copy) v_u_504
			v_u_503.cctx.emit("settings.changed", v_u_504)
		end)
	end
	local _, v505 = v493(v494)
	v_u_208.fov = v505
	local v506 = v_u_198.slider
	local v507 = {
		["parent"] = nil,
		["name"] = "FpSensitivity",
		["label"] = "Look sensitivity",
		["min"] = 0.1,
		["max"] = 6,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 22,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v508 = v271.sensitivity
	v507.value = tonumber(v508) or v_u_6.sensitivity
	v507.width = v_u_218
	function v507.format(p509) -- name: format
		return ("%.2f"):format(p509)
	end
	function v507.onChange(p510) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v511 = v_u_152
		local v512 = p_u_194
		pcall(v511, v512, "sensitivity", p510)
		v_u_206.sensitivity = p510
		v_u_207 = os.clock() + 0.6
		local v_u_513 = p_u_194
		local v_u_514 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_513, (copy) v_u_514
			v_u_513.cctx.emit("settings.changed", v_u_514)
		end)
	end
	local _, v515 = v506(v507)
	v_u_208.sensitivity = v515
	local v516 = v_u_198.slider
	local v517 = {
		["parent"] = nil,
		["name"] = "FpAdsSens",
		["label"] = "Aim sensitivity",
		["min"] = 0.2,
		["max"] = 2,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 23,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v518 = v271.fpAdsSens
	v517.value = tonumber(v518) or v_u_6.fpAdsSens
	v517.width = v_u_218
	function v517.format(p519) -- name: format
		return ("%.2f"):format(p519)
	end
	function v517.onChange(p520) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v521 = v_u_152
		local v522 = p_u_194
		pcall(v521, v522, "fpAdsSens", p520)
		v_u_206.fpAdsSens = p520
		v_u_207 = os.clock() + 0.6
		local v_u_523 = p_u_194
		local v_u_524 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_523, (copy) v_u_524
			v_u_523.cctx.emit("settings.changed", v_u_524)
		end)
	end
	local _, v525 = v516(v517)
	v_u_208.fpAdsSens = v525
	local v526 = v_u_198.slider
	local v527 = {
		["parent"] = nil,
		["name"] = "FpPadSens",
		["label"] = "Controller look speed",
		["min"] = 0.2,
		["max"] = 6,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 24,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v528 = v271.fpPadSens
	v527.value = tonumber(v528) or v_u_6.fpPadSens
	v527.width = v_u_218
	function v527.format(p529) -- name: format
		return ("%.2f"):format(p529)
	end
	function v527.onChange(p530) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v531 = v_u_152
		local v532 = p_u_194
		pcall(v531, v532, "fpPadSens", p530)
		v_u_206.fpPadSens = p530
		v_u_207 = os.clock() + 0.6
		local v_u_533 = p_u_194
		local v_u_534 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_533, (copy) v_u_534
			v_u_533.cctx.emit("settings.changed", v_u_534)
		end)
	end
	local _, v535 = v526(v527)
	v_u_208.fpPadSens = v535
	local v536 = v_u_198.slider
	local v537 = {
		["parent"] = nil,
		["name"] = "FpTouchSens",
		["label"] = "Touch look speed",
		["min"] = 0.2,
		["max"] = 6,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 25,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v538 = v271.fpTouchSens
	v537.value = tonumber(v538) or v_u_6.fpTouchSens
	v537.width = v_u_218
	function v537.format(p539) -- name: format
		return ("%.2f"):format(p539)
	end
	function v537.onChange(p540) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v541 = v_u_152
		local v542 = p_u_194
		pcall(v541, v542, "fpTouchSens", p540)
		v_u_206.fpTouchSens = p540
		v_u_207 = os.clock() + 0.6
		local v_u_543 = p_u_194
		local v_u_544 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_543, (copy) v_u_544
			v_u_543.cctx.emit("settings.changed", v_u_544)
		end)
	end
	local _, v545 = v536(v537)
	v_u_208.fpTouchSens = v545
	v_u_198.label({
		["parent"] = nil,
		["text"] = "These apply in a FIRST / THIRD PERSON raid. Aim sensitivity is on top of the look sensitivity while you aim down the sights. Controller and touch speeds scale the stick and the swipe.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 26,
		["parent"] = v238,
		["color"] = v_u_200.text2
	})
	v201.section(v238, "View comfort", 30)
	local _, v552 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "FpInvertY",
		["label"] = "Invert look",
		["value"] = nil,
		["width"] = nil,
		["order"] = 31,
		["onChange"] = nil,
		["parent"] = v238,
		["value"] = v271.fpInvertY == true,
		["width"] = v_u_218,
		["onChange"] = function(p546) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v547 = p546 == true
			local v548 = v_u_152
			local v549 = p_u_194
			pcall(v548, v549, "fpInvertY", v547)
			v_u_206.fpInvertY = v547
			v_u_207 = os.clock() + 0
			local v_u_550 = p_u_194
			local v_u_551 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_550, (copy) v_u_551
				v_u_550.cctx.emit("settings.changed", v_u_551)
			end)
		end
	})
	v_u_208.fpInvertY = v552
	local v553 = v_u_198.slider
	local v554 = {
		["parent"] = nil,
		["name"] = "FpBob",
		["label"] = "Head bob",
		["min"] = 0,
		["max"] = 1,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 32,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v555 = v271.fpBob
	v554.value = tonumber(v555) or v_u_6.fpBob
	v554.width = v_u_218
	function v554.format(p556) -- name: format
		local v557 = p556 * 100 + 0.5
		return ("%d%%"):format((math.floor(v557)))
	end
	function v554.onChange(p558) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v559 = v_u_152
		local v560 = p_u_194
		pcall(v559, v560, "fpBob", p558)
		v_u_206.fpBob = p558
		v_u_207 = os.clock() + 0.6
		local v_u_561 = p_u_194
		local v_u_562 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_561, (copy) v_u_562
			v_u_561.cctx.emit("settings.changed", v_u_562)
		end)
	end
	local _, v563 = v553(v554)
	v_u_208.fpBob = v563
	local v564 = v_u_198.slider
	local v565 = {
		["parent"] = nil,
		["name"] = "FpSway",
		["label"] = "Weapon sway",
		["min"] = 0,
		["max"] = 1,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 33,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v238
	}
	local v566 = v271.fpSway
	v565.value = tonumber(v566) or v_u_6.fpSway
	v565.width = v_u_218
	function v565.format(p567) -- name: format
		local v568 = p567 * 100 + 0.5
		return ("%d%%"):format((math.floor(v568)))
	end
	function v565.onChange(p569) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v570 = v_u_152
		local v571 = p_u_194
		pcall(v570, v571, "fpSway", p569)
		v_u_206.fpSway = p569
		v_u_207 = os.clock() + 0.6
		local v_u_572 = p_u_194
		local v_u_573 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_572, (copy) v_u_573
			v_u_572.cctx.emit("settings.changed", v_u_573)
		end)
	end
	local _, v574 = v564(v565)
	v_u_208.fpSway = v574
	local _, v580 = v_u_198.dropdown({
		["parent"] = nil,
		["name"] = "FpShoulder",
		["label"] = "Shoulder",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 34,
		["onChange"] = nil,
		["parent"] = v238,
		["options"] = {
			{
				["id"] = "right",
				["text"] = "Right"
			},
			{
				["id"] = "left",
				["text"] = "Left"
			}
		},
		["value"] = v271.fpShoulder == "left" and "left" or "right",
		["width"] = v_u_218,
		["onChange"] = function(p575) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v576 = v_u_152
			local v577 = p_u_194
			pcall(v576, v577, "fpShoulder", p575)
			v_u_206.fpShoulder = p575
			v_u_207 = os.clock() + 0
			local v_u_578 = p_u_194
			local v_u_579 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_578, (copy) v_u_579
				v_u_578.cctx.emit("settings.changed", v_u_579)
			end)
		end
	})
	v_u_208.fpShoulder = v580
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Shoulder is the side the third person camera sits over. Head bob and weapon sway can be turned down or off if the view makes you queasy.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 35,
		["parent"] = v238,
		["color"] = v_u_200.text2
	})
	local v_u_581 = p_u_194.cctx
	local v582, v583 = pcall(function()
		-- upvalues: (copy) v_u_581
		return v_u_581.lib.PlayModeSel.liveShown(v_u_581)
	end)
	v_u_208.fpShown = not v582 or v583 ~= false
	if not v_u_208.fpShown then
		for _, v584 in v238:GetChildren() do
			if not v584:IsA("GuiObject") or v584.LayoutOrder < 20 then
				continue
			end
			v584.Visible = false
		end
	end
	v201.section(v239, "Quality", 1)
	local v585 = v_u_198.dropdown
	local v586 = {
		["parent"] = nil,
		["label"] = "Quality",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 2,
		["onChange"] = nil,
		["parent"] = v239,
		["options"] = {
			"Auto",
			"Low",
			"Medium",
			"High",
			"Ultra"
		}
	}
	local v587 = v271.graphics
	v586.value = type(v587) ~= "string" and "Auto" or v271.graphics
	v586.width = v_u_218
	function v586.onChange(p588) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v589 = v_u_152
		local v590 = p_u_194
		pcall(v589, v590, "graphics", p588)
		v_u_206.graphics = p588
		v_u_207 = os.clock() + 0
		local v_u_591 = p_u_194
		local v_u_592 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_591, (copy) v_u_592
			v_u_591.cctx.emit("settings.changed", v_u_592)
		end)
	end
	local _, v593 = v585(v586)
	v_u_208.graphics = v593
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Lower quality turns off shadows from street lamps, thins the rain and shortens the view distance. Phones start on an automatic level.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 3,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	local _, v600 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "ShowFps",
		["label"] = "FPS, ping and server",
		["value"] = nil,
		["width"] = nil,
		["order"] = 4,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.showFps == true,
		["width"] = v_u_218,
		["onChange"] = function(p594) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v595 = p594 == true
			local v596 = v_u_152
			local v597 = p_u_194
			pcall(v596, v597, "showFps", v595)
			v_u_206.showFps = v595
			v_u_207 = os.clock() + 0
			local v_u_598 = p_u_194
			local v_u_599 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_598, (copy) v_u_599
				v_u_598.cctx.emit("settings.changed", v_u_599)
			end)
		end
	})
	v_u_208.showFps = v600
	v_u_198.label({
		["parent"] = nil,
		["text"] = "A small line with your FPS and ping (green good, yellow fair, red poor) and the server you are on: region, short id, players and game version. It keeps clear of the HUD. Off by default.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 5,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	v201.section(v239, "Flashing lights", 6)
	local _, v607 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "ReduceFlashing",
		["label"] = "Reduce flashing",
		["value"] = nil,
		["width"] = nil,
		["order"] = 7,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.reduceFlashing == true,
		["width"] = v_u_218,
		["onChange"] = function(p601) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v602 = p601 == true
			local v603 = v_u_152
			local v604 = p_u_194
			pcall(v603, v604, "reduceFlashing", v602)
			v_u_206.reduceFlashing = v602
			v_u_207 = os.clock() + 0
			local v_u_605 = p_u_194
			local v_u_606 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_605, (copy) v_u_606
				v_u_605.cctx.emit("settings.changed", v_u_606)
			end)
		end
	})
	v_u_208.reduceFlashing = v607
	v_u_198.label({
		["parent"] = nil,
		["text"] = "On: no strobe flashes (the club lights pulse softly), slow lasers and screens, steady warning lights, no lightning in the rain. Starts on if your device asks for reduced motion.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 8,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	v201.section(v239, "Skins", 10)
	local _, v614 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "SkinFx",
		["label"] = "Skin effects",
		["value"] = nil,
		["width"] = nil,
		["order"] = 11,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.skinFx ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p608) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v609 = p608 == true
			local v610 = v_u_152
			local v611 = p_u_194
			pcall(v610, v611, "skinFx", v609)
			v_u_206.skinFx = v609
			v_u_207 = os.clock() + 0
			local v_u_612 = p_u_194
			local v_u_613 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_612, (copy) v_u_613
				v_u_612.cctx.emit("settings.changed", v_u_613)
			end)
		end
	})
	v_u_208.skinFx = v614
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Off: tracers, muzzle flashes and kill effects of other players\' skins use the normal look. Your own effects always show. Helps weak phones.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 12,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	local _, v621 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "WeaponSkins",
		["label"] = "Weapon skins",
		["value"] = nil,
		["width"] = nil,
		["order"] = 13,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.weaponSkins ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p615) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v616 = p615 == true
			local v617 = v_u_152
			local v618 = p_u_194
			pcall(v617, v618, "weaponSkins", v616)
			v_u_206.weaponSkins = v616
			v_u_207 = os.clock() + 0
			local v_u_619 = p_u_194
			local v_u_620 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_619, (copy) v_u_620
				v_u_619.cctx.emit("settings.changed", v_u_620)
			end)
		end
	})
	v_u_208.weaponSkins = v621
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Off: you see every weapon, yours and other players\', with its normal model and colours, and no skin effects. Applies at once. The SKINS view, the crate window and the COLLECTION tab still show skins, because you look at them on purpose.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 14,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	v201.section(v239, "Gear on screen", 20)
	local _, v628 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "HideMyGear",
		["label"] = "Hide my armor, boots and backpack",
		["value"] = nil,
		["width"] = nil,
		["order"] = 21,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.hideMyGear == true,
		["width"] = v_u_218,
		["onChange"] = function(p622) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v623 = p622 == true
			local v624 = v_u_152
			local v625 = p_u_194
			pcall(v624, v625, "hideMyGear", v623)
			v_u_206.hideMyGear = v623
			v_u_207 = os.clock() + 0
			local v_u_626 = p_u_194
			local v_u_627 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_626, (copy) v_u_627
				v_u_626.cctx.emit("settings.changed", v_u_627)
			end)
		end
	})
	v_u_208.hideMyGear = v628
	local _, v635 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "HideOthersGear",
		["label"] = "Hide armor, boots and backpacks of others",
		["value"] = nil,
		["width"] = nil,
		["order"] = 22,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.hideOthersGear == true,
		["width"] = v_u_218,
		["onChange"] = function(p629) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v630 = p629 == true
			local v631 = v_u_152
			local v632 = p_u_194
			pcall(v631, v632, "hideOthersGear", v630)
			v_u_206.hideOthersGear = v630
			v_u_207 = os.clock() + 0
			local v_u_633 = p_u_194
			local v_u_634 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_633, (copy) v_u_634
				v_u_633.cctx.emit("settings.changed", v_u_634)
			end)
		end
	})
	v_u_208.hideOthersGear = v635
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Only on your screen. Others still see your gear, and its values still count. Your figure just looks plain to you.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 23,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	local _, v642 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "HideHeadwear",
		["label"] = "Hide hair and hats under helmets",
		["value"] = nil,
		["width"] = nil,
		["order"] = 24,
		["onChange"] = nil,
		["parent"] = v239,
		["value"] = v271.hideHeadwear == true,
		["width"] = v_u_218,
		["onChange"] = function(p636) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v637 = p636 == true
			local v638 = v_u_152
			local v639 = p_u_194
			pcall(v638, v639, "hideHeadwear", v637)
			v_u_206.hideHeadwear = v637
			v_u_207 = os.clock() + 0
			local v_u_640 = p_u_194
			local v_u_641 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_640, (copy) v_u_641
				v_u_640.cctx.emit("settings.changed", v_u_641)
			end)
		end
	})
	v_u_208.hideHeadwear = v642
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Off: hair, hats and head accessories stay visible under a helmet. Only on your screen.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 25,
		["parent"] = v239,
		["color"] = v_u_200.text2
	})
	v201.section(v_u_240, "Volume", 1)
	local v_u_643 = nil
	local v_u_644 = false
	local v_u_645 = 0
	for v646, v_u_647 in v_u_5 do
		local v648 = v_u_198.slider
		local v649 = {
			["parent"] = nil,
			["label"] = nil,
			["min"] = 0,
			["max"] = 1,
			["step"] = 0.05,
			["value"] = nil,
			["width"] = nil,
			["order"] = nil,
			["format"] = nil,
			["onChange"] = nil,
			["parent"] = v_u_240,
			["label"] = v_u_647.text
		}
		local v650 = v271[v_u_647.key]
		v649.value = tonumber(v650) or (v_u_6[v_u_647.key] or 1)
		v649.width = v_u_218
		v649.order = 1 + v646
		function v649.format(p651) -- name: format
			local v652 = p651 * 100 + 0.5
			return ("%d"):format((math.floor(v652)))
		end
		function v649.onChange(p653) -- name: onChange
			-- upvalues: (copy) v_u_647, (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v654 = v_u_647.key
			local v655 = v_u_152
			local v656 = p_u_194
			pcall(v655, v656, v654, p653)
			v_u_206[v654] = p653
			v_u_207 = os.clock() + 0.6
			local v_u_657 = p_u_194
			local v_u_658 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_657, (copy) v_u_658
				v_u_657.cctx.emit("settings.changed", v_u_658)
			end)
		end
		local _, v659 = v648(v649)
		v_u_208[v_u_647.key] = v659
	end
	local function v_u_674() -- name: voiceRows
		-- upvalues: (ref) v_u_644, (copy) p_u_194, (ref) v_u_2, (ref) v_u_1, (ref) v_u_643, (copy) v_u_198, (copy) v_u_240, (copy) v_u_218, (ref) v_u_5, (ref) v_u_152, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167, (copy) v_u_208, (copy) v_u_200
		if not v_u_644 then
			local function v660()
				-- upvalues: (ref) p_u_194
				return p_u_194.cctx.config.flag("VoiceNoise") == true
			end
			local v661, v662 = pcall(v660)
			local v_u_663 = false
			local function v664()
				-- upvalues: (ref) v_u_663, (ref) v_u_2
				v_u_663 = v_u_2:FindFirstChildWhichIsA("AudioDeviceInput") ~= nil
			end
			pcall(v664)
			local v665 = v_u_1.voiceRowState
			if v661 then
				v661 = v662 == true
			end
			local v666 = v665(v661, v_u_663)
			if v666 == "row" then
				if v_u_643 then
					v_u_643:Destroy()
					v_u_643 = nil
				end
				v_u_644 = true
				local _, v673 = v_u_198.toggle({
					["parent"] = nil,
					["name"] = "VoiceNoise",
					["label"] = "Voice draws the infected",
					["value"] = nil,
					["width"] = nil,
					["order"] = nil,
					["onChange"] = nil,
					["parent"] = v_u_240,
					["value"] = v_u_2:GetAttribute("VoiceNoiseOpt") ~= false,
					["width"] = v_u_218,
					["order"] = #v_u_5 + 2,
					["onChange"] = function(p667) -- name: onChange
						-- upvalues: (ref) v_u_152, (ref) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
						local v668 = p667 == true
						local v669 = v_u_152
						local v670 = p_u_194
						pcall(v669, v670, "voiceNoise", v668)
						v_u_206.voiceNoise = v668
						v_u_207 = os.clock() + 0
						local v_u_671 = p_u_194
						local v_u_672 = v_u_167(p_u_194, v_u_206)
						pcall(function()
							-- upvalues: (copy) v_u_671, (copy) v_u_672
							v_u_671.cctx.emit("settings.changed", v_u_672)
						end)
					end
				})
				v_u_208.voiceNoise = v673
				v_u_198.label({
					["parent"] = nil,
					["text"] = "With voice chat on, speaking in a raid makes noise the infected can hear. A whisper carries a little, a shout far.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_240,
					["color"] = v_u_200.text2,
					["order"] = #v_u_5 + 3
				})
			elseif v666 == "note" and not v_u_643 then
				v_u_643 = v_u_198.label({
					["parent"] = nil,
					["name"] = "VoiceNoiseNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_240,
					["text"] = v_u_1.TEXT.voiceNoDevice,
					["color"] = v_u_200.muted,
					["order"] = #v_u_5 + 2
				})
			end
		end
	end
	v_u_674()
	v201.section(v241, "Display", 1)
	local v675 = v_u_198.slider
	local v676 = {
		["parent"] = nil,
		["label"] = "Interface scale",
		["min"] = 0.8,
		["max"] = 1.4,
		["step"] = 0.05,
		["value"] = nil,
		["width"] = nil,
		["order"] = 2,
		["format"] = nil,
		["onChange"] = nil,
		["parent"] = v241
	}
	local v677 = v271.uiScale
	v676.value = tonumber(v677) or 1
	v676.width = v_u_218
	function v676.format(p678) -- name: format
		local v679 = p678 * 100 + 0.5
		return ("%d%%"):format((math.floor(v679)))
	end
	function v676.onChange(p680) -- name: onChange
		-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
		local v681 = v_u_152
		local v682 = p_u_194
		pcall(v681, v682, "uiScale", p680)
		v_u_206.uiScale = p680
		v_u_207 = os.clock() + 0.6
		local v_u_683 = p_u_194
		local v_u_684 = v_u_167(p_u_194, v_u_206)
		pcall(function()
			-- upvalues: (copy) v_u_683, (copy) v_u_684
			v_u_683.cctx.emit("settings.changed", v_u_684)
		end)
	end
	local _, v685 = v675(v676)
	v_u_208.uiScale = v685
	v201.section(v241, "Outline and chat", 10)
	local _, v692 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "StatusOutline",
		["label"] = "Status outline",
		["value"] = nil,
		["width"] = nil,
		["order"] = 11,
		["onChange"] = nil,
		["parent"] = v241,
		["value"] = v271.statusOutline ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p686) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v687 = p686 == true
			local v688 = v_u_152
			local v689 = p_u_194
			pcall(v688, v689, "statusOutline", v687)
			v_u_206.statusOutline = v687
			v_u_207 = os.clock() + 0
			local v_u_690 = p_u_194
			local v_u_691 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_690, (copy) v_u_691
				v_u_690.cctx.emit("settings.changed", v_u_691)
			end)
		end
	})
	v_u_208.statusOutline = v692
	v_u_198.label({
		["parent"] = nil,
		["text"] = "A pulsing outline around your survivor: red while bleeding, orange with a fracture. Only on your screen.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 12,
		["parent"] = v241,
		["color"] = v_u_200.text2
	})
	local _, v699 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "SquadChat",
		["label"] = "Squad chat",
		["value"] = nil,
		["width"] = nil,
		["order"] = 13,
		["onChange"] = nil,
		["parent"] = v241,
		["value"] = v271.squadChat ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p693) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v694 = p693 == true
			local v695 = v_u_152
			local v696 = p_u_194
			pcall(v695, v696, "squadChat", v694)
			v_u_206.squadChat = v694
			v_u_207 = os.clock() + 0
			local v_u_697 = p_u_194
			local v_u_698 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_697, (copy) v_u_698
				v_u_697.cctx.emit("settings.changed", v_u_698)
			end)
		end
	})
	v_u_208.squadChat = v699
	v_u_198.label({
		["parent"] = nil,
		["text"] = "Show the chat in a raid. Only your squad sees what you write. Off: no chat box, you cannot write either.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 14,
		["parent"] = v241,
		["color"] = v_u_200.text2
	})
	v201.section(v241, "Missions and menu", 15)
	local v705 = {
		["parent"] = nil,
		["name"] = "TaskTracker",
		["label"] = "Mission list",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["order"] = 16,
		["onChange"] = nil,
		["parent"] = v241,
		["options"] = {
			{
				["id"] = "full",
				["text"] = "Full"
			},
			{
				["id"] = "compact",
				["text"] = "Compact"
			},
			{
				["id"] = "off",
				["text"] = "Off"
			}
		},
		["value"] = v271.taskTracker ~= "compact" and v271.taskTracker ~= "off" and "full" or v271.taskTracker,
		["width"] = v_u_218,
		["onChange"] = function(p700) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v701 = v_u_152
			local v702 = p_u_194
			pcall(v701, v702, "taskTracker", p700)
			v_u_206.taskTracker = p700
			v_u_207 = os.clock() + 0
			local v_u_703 = p_u_194
			local v_u_704 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_703, (copy) v_u_704
				v_u_703.cctx.emit("settings.changed", v_u_704)
			end)
		end
	}
	local _, v706 = v_u_198.dropdown(v705)
	v_u_208.taskTracker = v706
	local v_u_707 = "In a raid you can fold it any time."
	local function v710()
		-- upvalues: (copy) v_u_249, (copy) p_u_194, (ref) v_u_707
		local v708 = v_u_249()
		local v709 = p_u_194.cctx.controllers.Input.hint("tasks")
		if v708 == "Touch" then
			v_u_707 = "In a raid, tap the list to fold it."
		elseif type(v709) == "string" and v709 ~= "" then
			v_u_707 = "In a raid, " .. v709 .. " folds it."
		end
	end
	pcall(v710)
	v_u_198.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 17,
		["parent"] = v241,
		["text"] = "Full shows your missions as before. Compact shows one line. Off hides the list. " .. v_u_707,
		["color"] = v_u_200.text2
	})
	local v_u_711 = true
	local function v712()
		-- upvalues: (ref) v_u_711, (copy) p_u_194
		v_u_711 = p_u_194.cctx.config.flag("MenuStyle") ~= false
	end
	pcall(v712)
	if not v_u_197.raid and v_u_711 then
		local v720 = {
			["parent"] = nil,
			["name"] = "MenuStyle",
			["label"] = "Menu style",
			["options"] = nil,
			["value"] = nil,
			["width"] = nil,
			["order"] = 18,
			["onChange"] = nil,
			["parent"] = v241,
			["options"] = {
				{
					["id"] = "auto",
					["text"] = "Auto"
				},
				{
					["id"] = "v2",
					["text"] = "New"
				},
				{
					["id"] = "classic",
					["text"] = "Classic"
				}
			},
			["value"] = v271.menuStyle ~= "v2" and v271.menuStyle ~= "classic" and "auto" or v271.menuStyle,
			["width"] = v_u_218,
			["onChange"] = function(p713) -- name: onChange
				-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
				local v714 = v_u_152
				local v715 = p_u_194
				pcall(v714, v715, "menuStyle", p713)
				v_u_206.menuStyle = p713
				v_u_207 = os.clock() + 0
				local v_u_716 = p_u_194
				local v_u_717 = v_u_167(p_u_194, v_u_206)
				pcall(function()
					-- upvalues: (copy) v_u_716, (copy) v_u_717
					v_u_716.cctx.emit("settings.changed", v_u_717)
				end)
				local function v719()
					-- upvalues: (ref) p_u_194
					local v718 = p_u_194.restyleMenu
					if type(v718) == "function" then
						p_u_194.restyleMenu()
					end
				end
				pcall(v719)
			end
		}
		local _, v721 = v_u_198.dropdown(v720)
		v_u_208.menuStyle = v721
		v_u_198.label({
			["parent"] = nil,
			["text"] = "Auto: the new menu on a phone, tablet or console, the classic menu on a PC. New or Classic is yours on every device. The menu closes and opens again when you change it.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 19,
			["parent"] = v241,
			["color"] = v_u_200.text2
		})
	end
	local v724, v725 = pcall(function()
		-- upvalues: (copy) p_u_194
		local v722 = p_u_194.cctx.shared.GameMode
		local v723
		if v722.rule("clans") == true then
			v723 = v722.rule("clanShop") == true
		else
			v723 = false
		end
		return v723
	end)
	if v724 and v725 == true then
		v201.section(v241, "Clans", 20)
		local _, v732 = v_u_198.toggle({
			["parent"] = nil,
			["name"] = "ShowClanColors",
			["label"] = "Show clan colors",
			["value"] = nil,
			["width"] = nil,
			["order"] = 21,
			["onChange"] = nil,
			["parent"] = v241,
			["value"] = v271.showClanColors ~= false,
			["width"] = v_u_218,
			["onChange"] = function(p726) -- name: onChange
				-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
				local v727 = p726 == true
				local v728 = v_u_152
				local v729 = p_u_194
				pcall(v728, v729, "showClanColors", v727)
				v_u_206.showClanColors = v727
				v_u_207 = os.clock() + 0
				local v_u_730 = p_u_194
				local v_u_731 = v_u_167(p_u_194, v_u_206)
				pcall(function()
					-- upvalues: (copy) v_u_730, (copy) v_u_731
					v_u_730.cctx.emit("settings.changed", v_u_731)
				end)
			end
		})
		v_u_208.showClanColors = v732
		v_u_198.label({
			["parent"] = nil,
			["text"] = "Off: clan tags of other players show in plain text, without the colors and effects their clans bought. Applies at once.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 22,
			["parent"] = v241,
			["color"] = v_u_200.text2
		})
	end
	v201.section(v241, "Recording", 30)
	local _, v739 = v_u_198.toggle({
		["parent"] = nil,
		["name"] = "ObjectOutlines",
		["label"] = "Object outlines",
		["value"] = nil,
		["width"] = nil,
		["order"] = 31,
		["onChange"] = nil,
		["parent"] = v241,
		["value"] = v271.objectOutlines ~= false,
		["width"] = v_u_218,
		["onChange"] = function(p733) -- name: onChange
			-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
			local v734 = p733 == true
			local v735 = v_u_152
			local v736 = p_u_194
			pcall(v735, v736, "objectOutlines", v734)
			v_u_206.objectOutlines = v734
			v_u_207 = os.clock() + 0
			local v_u_737 = p_u_194
			local v_u_738 = v_u_167(p_u_194, v_u_206)
			pcall(function()
				-- upvalues: (copy) v_u_737, (copy) v_u_738
				v_u_737.cctx.emit("settings.changed", v_u_738)
			end)
		end
	})
	v_u_208.objectOutlines = v739
	local v_u_740 = nil
	local function v741()
		-- upvalues: (ref) v_u_740, (copy) p_u_194
		v_u_740 = p_u_194.cctx.lib.HideUiRules
	end
	pcall(v741)
	v_u_198.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 32,
		["parent"] = v241,
		["text"] = not v_u_740 and "Soft outlines around lootable containers and hideout stations. Only on your screen." or v_u_740.OUTLINE_LINE,
		["color"] = v_u_200.text2
	})
	local v_u_742 = false
	local function v743()
		-- upvalues: (ref) v_u_742, (copy) p_u_194
		v_u_742 = p_u_194.cctx.lib.HideUi.isHidden() == true
	end
	pcall(v743)
	local v746 = {
		["parent"] = nil,
		["name"] = "HideUi",
		["label"] = "Hide interface",
		["value"] = nil,
		["width"] = nil,
		["order"] = 33,
		["onChange"] = nil,
		["parent"] = v241,
		["value"] = v_u_742,
		["width"] = v_u_218,
		["onChange"] = function(p_u_744) -- name: onChange
			-- upvalues: (copy) p_u_194
			local function v745()
				-- upvalues: (ref) p_u_194, (copy) p_u_744
				p_u_194.cctx.lib.HideUi.set(p_u_744 == true)
			end
			pcall(v745)
		end
	}
	local _, v747 = v_u_198.toggle(v746)
	v_u_208.hideUi = v747
	local v_u_748 = ""
	local function v749()
		-- upvalues: (ref) v_u_748, (copy) p_u_194
		v_u_748 = p_u_194.cctx.controllers.Input.hint("hideUi")
	end
	pcall(v749)
	v_u_198.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 34,
		["parent"] = v241,
		["text"] = not v_u_740 and "Hides the HUD, markers and hints for recordings. Windows you open stay visible." or v_u_740.hideLine(v_u_748, (v_u_249())),
		["color"] = v_u_200.text2
	})
	local v750 = v_u_2:GetAttributeChangedSignal("UiHidden")
	local function v753()
		-- upvalues: (copy) v_u_208, (ref) v_u_2
		if v_u_208.hideUi then
			local v751 = v_u_208.hideUi.set
			local v752 = v_u_2:GetAttribute("UiHidden") == true
			pcall(v751, v752)
		end
	end
	table.insert(v_u_209, v750:Connect(v753))
	local v_u_754 = nil
	local v_u_755 = nil
	local v_u_756 = v201.section(v_u_242, "Trading", 1)
	v_u_756.Visible = false
	local v757, v758 = pcall(function()
		-- upvalues: (copy) p_u_194
		return p_u_194.cctx.shared.TradeView
	end)
	if v757 and type(v758) == "table" then
		local v759 = v271.tradeRequests ~= "squad" and v271.tradeRequests ~= "nobody" and "everyone" or v271.tradeRequests
		local v_u_765, v766 = v_u_198.dropdown({
			["parent"] = nil,
			["name"] = "TradeRequests",
			["label"] = nil,
			["options"] = nil,
			["value"] = nil,
			["width"] = nil,
			["order"] = 2,
			["onChange"] = nil,
			["parent"] = v_u_242,
			["label"] = v758.rtext("settingRequests", "Trade requests"),
			["options"] = v758.requestOptions(),
			["value"] = v759,
			["width"] = v_u_218,
			["onChange"] = function(p760) -- name: onChange
				-- upvalues: (ref) v_u_152, (copy) p_u_194, (ref) v_u_206, (ref) v_u_207, (ref) v_u_167
				local v761 = v_u_152
				local v762 = p_u_194
				pcall(v761, v762, "tradeRequests", p760)
				v_u_206.tradeRequests = p760
				v_u_207 = os.clock() + 0
				local v_u_763 = p_u_194
				local v_u_764 = v_u_167(p_u_194, v_u_206)
				pcall(function()
					-- upvalues: (copy) v_u_763, (copy) v_u_764
					v_u_763.cctx.emit("settings.changed", v_u_764)
				end)
			end
		})
		v_u_208.tradeRequests = v766
		local v_u_767 = nil
		local function v768()
			-- upvalues: (ref) v_u_767, (copy) p_u_194
			v_u_767 = p_u_194.cctx.controllers.TradeNotes
		end
		pcall(v768)
		local function v773() -- name: paintTradeRow
			-- upvalues: (ref) v_u_767, (ref) v_u_2, (copy) v_u_765, (copy) v_u_756, (copy) v_u_269
			local v769 = false
			if v_u_767 ~= nil then
				local v770 = v_u_767.tabState
				if type(v770) == "function" then
					local v771 = v_u_767.tabState
					local v772
					v769, v772 = pcall(v771)
					if v769 then
						if v772 == true then
							v769 = v_u_2:GetAttribute("PaidTrading") == true
						else
							v769 = false
						end
					end
				end
			end
			v_u_765.Visible = v769
			v_u_756.Visible = v769
			v_u_269(v769)
		end
		local v774 = false
		if v_u_767 ~= nil then
			local v775 = v_u_767.tabState
			if type(v775) == "function" then
				local v776 = v_u_767.tabState
				local v777, v778 = pcall(v776)
				v774 = v777
				if v774 then
					if v778 == true then
						v774 = v_u_2:GetAttribute("PaidTrading") == true
					else
						v774 = false
					end
				end
			end
		end
		v_u_765.Visible = v774
		v_u_756.Visible = v774
		v_u_269(v774)
		if v_u_767 ~= nil then
			local v779 = v_u_767.subscribe
			if type(v779) == "function" then
				v_u_208.tradeRowOff = v_u_767.subscribe(function(p780)
					-- upvalues: (ref) v_u_767, (ref) v_u_2, (copy) v_u_765, (copy) v_u_756, (copy) v_u_269
					if type(p780) == "table" and (p780.k == "state" or p780.k == "backend") then
						local v781 = false
						if v_u_767 ~= nil then
							local v782 = v_u_767.tabState
							if type(v782) == "function" then
								local v783 = v_u_767.tabState
								local v784
								v781, v784 = pcall(v783)
								if v781 then
									if v784 == true then
										v781 = v_u_2:GetAttribute("PaidTrading") == true
									else
										v781 = false
									end
								end
							end
						end
						v_u_765.Visible = v781
						v_u_756.Visible = v781
						v_u_269(v781)
					end
				end)
			end
		end
		v_u_208.tradeRowConn = v_u_2:GetAttributeChangedSignal("PaidTrading"):Connect(v773)
	end
	if not v_u_197.raid then
		v201.section(v_u_242, "Account", 10)
		local v785 = v201.stat
		local v786 = p_u_194.config.VERSION or "?"
		v785(v_u_242, "Build", tostring(v786), 11)
		local _, v787 = v201.stat(v_u_242, "Profile", "Saved", 12, v_u_200.success)
		v_u_208.temp = v787
		v_u_754 = v_u_198.label({
			["parent"] = nil,
			["name"] = "TempNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 13,
			["parent"] = v_u_242,
			["text"] = v_u_1.TEXT.tempNote,
			["color"] = v_u_200.danger
		})
		v_u_754.Visible = false
		v_u_755 = v_u_198.label({
			["parent"] = nil,
			["name"] = "MarketNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 14,
			["parent"] = v_u_242,
			["text"] = v_u_1.TEXT.marketBlocked,
			["color"] = v_u_200.text2
		})
		v_u_755.Visible = false
		local v788 = p_u_194.startTour
		if type(v788) == "function" and p_u_194.v2 ~= true then
			v_u_198.button({
				["parent"] = nil,
				["name"] = "TourButton",
				["text"] = "Show menu tour again",
				["kind"] = "ghost",
				["icon"] = "eye",
				["height"] = 36,
				["width"] = nil,
				["order"] = 15,
				["onClick"] = nil,
				["parent"] = v_u_242,
				["width"] = math.min(v_u_218, 300),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_194
					p_u_194.startTour()
				end
			})
		end
	end
	local function v_u_802() -- name: paintAccountNotes
		-- upvalues: (copy) v_u_197, (copy) v_u_208, (copy) p_u_194, (ref) v_u_1, (copy) v_u_200, (ref) v_u_754, (ref) v_u_755, (ref) v_u_2
		if not v_u_197.raid and v_u_208.temp then
			local v789 = p_u_194.derived()
			v_u_208.temp.Text = not v789.temp and "Saved" or v_u_1.TEXT.tempLabel
			local v790 = v_u_208.temp
			local v791
			if v789.temp then
				v791 = v_u_200.danger
			else
				v791 = v_u_200.success
			end
			v790.TextColor3 = v791
			v_u_754.Visible = v789.temp == true
			local v_u_792 = nil
			local function v793()
				-- upvalues: (ref) v_u_792
				v_u_792 = game:GetService("ReplicatedStorage"):FindFirstChild("Config"):GetAttribute("BmRm")
			end
			pcall(v793)
			local v794 = v_u_755
			local v795 = v_u_1.marketBlocked
			local v796 = v_u_792
			local v797 = v_u_2:GetAttribute("PaidTrading")
			local v_u_798 = "Blackmarket"
			local function v799()
				-- upvalues: (ref) p_u_194, (copy) v_u_798
				return p_u_194.cctx.config.flag(v_u_798)
			end
			local v800, v801 = pcall(v799)
			v794.Visible = v795(v796, v797, not v800 or v801 ~= false)
		end
	end
	local v_u_803 = nil
	local v_u_804 = nil
	local v_u_805 = 0
	local function v_u_814() -- name: replayBlock
		-- upvalues: (copy) p_u_194, (ref) v_u_2
		local function v806()
			-- upvalues: (ref) p_u_194
			return p_u_194.cctx.lib.MenuTutorialCard.startBlock(p_u_194)
		end
		local v807, v808 = pcall(v806)
		if v807 then
			return v808
		end
		local v809 = v_u_2:GetAttribute("Place")
		if v809 ~= nil and (v809 ~= "Menu" and v809 ~= "Hideout") or v_u_2:GetAttribute("Tutorial") == true then
			return "Finish your current raid first."
		end
		local v810 = p_u_194.myParty
		local v811 = type(v810) == "function" and p_u_194.myParty() or nil
		if type(v811) == "table" then
			local v812 = v811.members
			if type(v812) == "table" and #v811.members > 1 then
				return "Leave your squad first. The tutorial is a solo raid."
			end
		end
		local v813 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
		return v813 and v813:GetAttribute("DeployClosed") == true and "Deployments are closed right now." or nil
	end
	local function v_u_826() -- name: paintReplay
		-- upvalues: (ref) v_u_803, (ref) v_u_2, (copy) v_u_814, (ref) v_u_805, (ref) v_u_804, (copy) p_u_194, (copy) v_u_200
		if v_u_803 then
			local v_u_815 = v_u_2:GetAttribute("TutorialDone") == true
			local v816 = v_u_814()
			local v817 = os.clock() < v_u_805
			local v818 = v_u_803.setText
			pcall(v818, v817 and "Starting..." or (v_u_815 and "Replay tutorial" or "Play tutorial"))
			local v819 = v_u_803.setEnabled
			local v820
			if v816 == nil then
				v820 = not v817
			else
				v820 = false
			end
			pcall(v819, v820)
			if v_u_804 then
				local v_u_821 = v_u_815 and "Practice run. No reward, nothing is kept." or "A short solo night raid. Nothing of yours is at stake."
				local function v823()
					-- upvalues: (ref) p_u_194, (copy) v_u_815, (ref) v_u_821
					local v822 = p_u_194.cctx.lib.MenuTutorialCard
					if v_u_815 and v822.rewardOpen() then
						v_u_821 = ("Finish it once and get %s."):format(v822.rewardMoney(p_u_194))
					end
				end
				pcall(v823)
				v_u_804.Text = v816 or v_u_821
				local v824 = v_u_804
				local v825
				if v816 then
					v825 = v_u_200.accent
				else
					v825 = v_u_200.text2
				end
				v824.TextColor3 = v825
			end
		end
	end
	if not v_u_197.raid then
		local _, v834 = v_u_198.button({
			["parent"] = nil,
			["name"] = "ReplayTutorial",
			["text"] = "Replay tutorial",
			["kind"] = "ghost",
			["icon"] = "help",
			["height"] = 44,
			["width"] = nil,
			["order"] = 16,
			["onClick"] = nil,
			["parent"] = v_u_242,
			["width"] = math.min(v_u_218, 300),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_814, (copy) v_u_198, (ref) v_u_805, (copy) p_u_194, (ref) v_u_2, (copy) v_u_826
				local v827 = v_u_814()
				if v827 then
					v_u_198.toast(v827, "warn")
					return
				end
				if os.clock() < v_u_805 then
					return
				end
				local v828 = p_u_194.cctx.controllers.TutorialClient
				local v829 = false
				if v828 then
					local v830 = v828.replay
					if type(v830) == "function" then
						local v831 = v828.replay
						local v832
						v829, v832 = pcall(v831)
						if v829 then
							v829 = v832 ~= false
						end
					end
				end
				if v829 then
					if v829 then
						v_u_805 = os.clock() + 6
						v_u_198.sound("deploy")
					end
					v_u_826()
				else
					if v828 then
						local v833 = v828.replay
						if type(v833) == "function" then
							if v829 then
								v_u_805 = os.clock() + 6
								v_u_198.sound("deploy")
							end
							v_u_826()
							return
						end
						p_u_194.cctx.emit("transit.info", {
							["kind"] = "deploy",
							["map"] = "Stillwater",
							["difficulty"] = "Normal",
							["timeOfDay"] = "Night",
							["tutorial"] = true,
							["practice"] = nil,
							["practice"] = v_u_2:GetAttribute("TutorialDone") == true
						})
						p_u_194.op({
							["op"] = "tutorialReplay"
						})
						v829 = true
					else
						p_u_194.cctx.emit("transit.info", {
							["kind"] = "deploy",
							["map"] = "Stillwater",
							["difficulty"] = "Normal",
							["timeOfDay"] = "Night",
							["tutorial"] = true,
							["practice"] = nil,
							["practice"] = v_u_2:GetAttribute("TutorialDone") == true
						})
						p_u_194.op({
							["op"] = "tutorialReplay"
						})
						v829 = true
					end
					if v829 then
						v_u_805 = os.clock() + 6
						v_u_198.sound("deploy")
					end
					v_u_826()
				end
			end
		})
		v_u_803 = v834
		v_u_804 = v_u_198.label({
			["parent"] = nil,
			["name"] = "ReplayNote",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 17,
			["parent"] = v_u_242,
			["color"] = v_u_200.text2
		})
		v_u_826()
		local v835, v836 = pcall(function()
			-- upvalues: (copy) p_u_194, (copy) v_u_242, (copy) v_u_218
			p_u_194.cctx.lib.MenuCodes.build(p_u_194, v_u_242, v_u_218, 18)
		end)
		if not v835 then
			warn("[MenuSettings] redeem code row failed:", v836)
		end
	end
	local function v_u_840() -- name: paintHelp
		-- upvalues: (copy) v_u_249, (copy) v_u_203, (copy) v_u_463, (ref) v_u_337
		local v837 = v_u_249()
		local v_u_838 = false
		local function v839()
			-- upvalues: (ref) v_u_838, (ref) v_u_203
			v_u_838 = v_u_203.TouchEnabled
		end
		pcall(v839)
		v_u_463.Visible = v837 == "Touch" and true or v_u_838
		v_u_337.Visible = v837 == "Gamepad"
	end
	local function v_u_843(p841, p842) -- name: paneVisible
		while p841 and p841 ~= p842 do
			if p841:IsA("GuiObject") and not p841.Visible then
				return false
			end
			p841 = p841.Parent
		end
		return true
	end
	local function v_u_850() -- name: selectFirst
		-- upvalues: (copy) v_u_229, (ref) v_u_251, (copy) v_u_249, (copy) v_u_843, (copy) v_u_204
		local v844 = v_u_229[v_u_251]
		if v_u_249() == "Gamepad" and (v844 and v844.Parent) then
			local v845 = (1 / 0)
			local v846 = nil
			for _, v847 in v844:GetDescendants() do
				if not v847:IsA("GuiButton") or (not v847.Selectable or (v847.AbsoluteSize.X <= 1 or not v_u_843(v847, v844))) then
					continue
				end
				local v848 = v847.AbsolutePosition.Y / 8
				local v849 = math.floor(v848) * 100000 + v847.AbsolutePosition.X
				if v849 >= v845 then
					continue
				end
				v846 = v847
				v845 = v849
			end
			if v846 then
				v_u_204.SelectedObject = v846
			end
		end
	end
	local function v_u_865(p_u_851, p852)
		-- upvalues: (copy) v_u_229, (ref) v_u_260, (copy) v_u_202, (ref) v_u_251, (ref) v_u_3, (copy) v_u_198, (copy) v_u_226, (copy) v_u_227, (copy) v_u_358, (copy) v_u_259, (copy) v_u_249, (copy) v_u_203, (copy) v_u_463, (ref) v_u_337, (ref) v_u_2, (copy) v_u_228, (copy) v_u_253, (copy) v_u_224
		if v_u_229[p_u_851] == nil or v_u_260[p_u_851] == false then
			local v853 = {
				["touch"] = false,
				["visible"] = nil,
				["visible"] = v_u_260
			}
			p_u_851 = v_u_202.initial(v853)
		end
		v_u_251 = p_u_851
		if p852 == true then
			v_u_3 = p_u_851
		end
		for v854, v855 in v_u_229 do
			v855.Visible = v854 == p_u_851
		end
		local v856 = v_u_202.BY_ID[p_u_851]
		v_u_198.setText(v_u_226, v856.heading)
		v_u_198.setText(v_u_227, v856.line)
		if p_u_851 == "controls" then
			v_u_358()
		end
		v_u_259()
		local v857 = v_u_249()
		local v_u_858 = false
		local function v859()
			-- upvalues: (ref) v_u_858, (ref) v_u_203
			v_u_858 = v_u_203.TouchEnabled
		end
		pcall(v859)
		v_u_463.Visible = v857 == "Touch" and true or v_u_858
		v_u_337.Visible = v857 == "Gamepad"
		v_u_2:SetAttribute("SettingsCategory", p_u_851)
		v_u_2:SetAttribute("SettingsSubTab", v_u_202.subTabOf(p_u_851))
		local function v860()
			-- upvalues: (ref) v_u_228
			v_u_228.CanvasPosition = Vector2.zero
		end
		pcall(v860)
		task.defer(function()
			-- upvalues: (ref) v_u_253, (ref) p_u_851, (ref) v_u_224, (ref) v_u_202
			local function v864()
				-- upvalues: (ref) v_u_253, (ref) p_u_851, (ref) v_u_224, (ref) v_u_202
				local v861 = v_u_253[p_u_851]
				if v861 and (v861.btn.Parent and v_u_224.AbsoluteWindowSize.Y > 0) then
					local v862 = v861.btn.AbsolutePosition.Y - v_u_224.AbsolutePosition.Y + v_u_224.CanvasPosition.Y
					local v863 = v_u_202.scrollInto(v_u_224.AbsoluteWindowSize.Y, v_u_224.AbsoluteCanvasSize.Y, v862, v861.btn.AbsoluteSize.Y, v_u_224.CanvasPosition.Y)
					v_u_224.CanvasPosition = Vector2.new(0, v863)
				end
			end
			pcall(v864)
		end)
	end
	local function v_u_870(p866) -- name: navKey
		-- upvalues: (copy) v_u_214, (copy) p_u_195, (ref) v_u_210, (copy) v_u_203, (copy) v_u_198, (ref) v_u_328, (copy) v_u_197, (ref) v_u_865, (copy) v_u_202, (ref) v_u_251, (ref) v_u_260, (copy) v_u_850
		if v_u_214.Parent and (p_u_195.Visible and v_u_210) then
			if v_u_203:GetFocusedTextBox() == nil and (not v_u_198.modalCount or v_u_198.modalCount() <= 0) then
				if v_u_328 and v_u_328.capturing() ~= nil then
					return
				else
					local v867 = p866.KeyCode
					local v868 = 0
					local v869 = false
					if v867 == Enum.KeyCode.ButtonR2 or v_u_197.raid and v867 == Enum.KeyCode.ButtonR1 then
						v868 = 1
						v869 = true
					elseif v867 == Enum.KeyCode.ButtonL2 or v_u_197.raid and v867 == Enum.KeyCode.ButtonL1 then
						v868 = -1
						v869 = true
					elseif v867 == Enum.KeyCode.PageDown then
						v868 = 1
					elseif v867 == Enum.KeyCode.PageUp then
						v868 = -1
					end
					if v868 ~= 0 then
						v_u_865(v_u_202.step(v_u_251, v868, v_u_260), true)
						if v869 then
							task.delay(0.05, v_u_850)
						end
					end
				end
			else
				return
			end
		else
			return
		end
	end
	pcall(function()
		-- upvalues: (copy) p_u_194, (copy) v_u_209, (copy) v_u_870
		local v871 = v_u_209
		local v872 = p_u_194.cctx.lib.VirtualPad.InputBegan
		local v873 = v_u_870
		table.insert(v871, v872:Connect(v873))
	end)
	pcall(function()
		-- upvalues: (copy) p_u_194, (copy) v_u_209, (ref) v_u_328, (copy) v_u_840, (copy) v_u_462
		local v874 = p_u_194.cctx.controllers.Input
		if v874 and v874.deviceChanged then
			local v875 = v_u_209
			local v876 = v874.deviceChanged
			local function v880()
				-- upvalues: (ref) v_u_328, (ref) v_u_840, (ref) v_u_462
				if v_u_328 and (v_u_328.frame and v_u_328.frame.Parent) then
					local v877 = v_u_328.refresh
					pcall(v877)
				end
				local v878 = v_u_840
				pcall(v878)
				local v879 = v_u_462
				pcall(v879)
			end
			table.insert(v875, v876:Connect(v880))
		end
	end)
	v_u_205.subTabs = {
		["select"] = function(p881) -- name: select
			-- upvalues: (ref) v_u_865
			v_u_865(p881 == "controls" and "controls" or "gameplay", true)
		end,
		["get"] = function() -- name: get
			-- upvalues: (copy) v_u_202, (ref) v_u_251
			return v_u_202.subTabOf(v_u_251)
		end
	}
	local function v894()
		-- upvalues: (copy) p_u_194, (copy) v_u_205, (ref) v_u_251, (copy) v_u_214, (copy) v_u_202, (ref) v_u_865
		p_u_194.cctx.command("settings.sub", function(p882)
			-- upvalues: (ref) v_u_205, (ref) v_u_251, (ref) v_u_214
			local v883 = p882[1] == "controls" and "controls" or "general"
			v_u_205.subTabs.select(v883)
			local v884 = v_u_251
			local v885 = v_u_214.Parent ~= nil
			return "sub " .. v883 .. " cat=" .. v884 .. " visible=" .. tostring(v885)
		end)
		p_u_194.cctx.command("settings.cat", function(p886)
			-- upvalues: (ref) v_u_202, (ref) v_u_865, (ref) v_u_251, (ref) v_u_214
			local v887 = p886[1] or ""
			local v888 = tostring(v887)
			if v_u_202.BY_ID[v888] == nil then
				local v889 = {}
				for _, v890 in v_u_202.CATEGORIES do
					local v891 = v890.id
					table.insert(v889, v891)
				end
				return "unknown category \'" .. v888 .. "\', one of " .. table.concat(v889, " ")
			end
			v_u_865(v888, true)
			local v892 = v_u_251
			local v893 = v_u_214.Parent ~= nil
			return "cat " .. v892 .. " visible=" .. tostring(v893)
		end)
	end
	pcall(v894)
	v_u_865(v_u_202.initial({
		["touch"] = v_u_249() == "Touch",
		["last"] = v_u_3,
		["visible"] = v_u_260
	}), false)
	function v_u_205.show(p895) -- name: show
		-- upvalues: (copy) p_u_194, (copy) v_u_208, (ref) v_u_5, (ref) v_u_6, (ref) v_u_2, (copy) v_u_462, (copy) v_u_802, (copy) v_u_674, (copy) v_u_840, (copy) v_u_826, (ref) v_u_865, (copy) v_u_202, (copy) v_u_249, (ref) v_u_3, (ref) v_u_260
		local v896 = p_u_194.profile
		local v_u_897
		if type(v896) == "table" then
			local v898 = v896.settings
			v_u_897 = type(v898) == "table" and (v896.settings or {}) or {}
		else
			v_u_897 = {}
		end
		local function v926()
			-- upvalues: (ref) v_u_208, (copy) v_u_897, (ref) v_u_5, (ref) v_u_6, (ref) v_u_2
			local v899 = v_u_208.graphics.set
			local v900 = v_u_897.graphics
			v899(type(v900) ~= "string" and "Auto" or v_u_897.graphics)
			for _, v901 in v_u_5 do
				local v902 = v_u_208[v901.key].set
				local v903 = v_u_897[v901.key]
				v902(tonumber(v903) or (v_u_6[v901.key] or 1))
			end
			local v904 = v_u_208.touchSize.set
			local v905 = v_u_897.touchSize
			local v906 = tonumber(v905) or 2
			v904((tostring(v906)))
			local v907 = v_u_208.touchStick.set
			local v908 = v_u_897.touchStick
			local v909 = (tonumber(v908) or 2) + 0.5
			local v910 = math.floor(v909)
			local v911 = math.clamp(v910, 1, 4)
			v907((tostring(v911)))
			v_u_208.touchMoveFixed.set(v_u_897.touchMoveFixed == true and "fixed" or "float")
			local v912 = v_u_208.touchOpacity.set
			local v913 = v_u_897.touchOpacity
			local v914 = (tonumber(v913) or 2) + 0.5
			local v915 = math.floor(v914)
			local v916 = math.clamp(v915, 1, 3)
			v912((tostring(v916)))
			local v917 = v_u_208.cameraZoom.set
			local v918 = v_u_897.cameraZoom
			v917(tonumber(v918) or 2)
			local v919 = v_u_208.uiScale.set
			local v920 = v_u_897.uiScale
			v919(tonumber(v920) or 1)
			local v921 = v_u_208.cameraShake.set
			local v922 = v_u_897.cameraShake
			v921(tonumber(v922) or 1)
			if v_u_208.aimAssist then
				v_u_208.aimAssist.set(v_u_897.aimAssist ~= false)
			end
			if v_u_208.voiceNoise then
				v_u_208.voiceNoise.set(v_u_897.voiceNoise ~= false)
			end
			if v_u_208.closeSearchOnHit then
				v_u_208.closeSearchOnHit.set(v_u_897.closeSearchOnHit == true)
			end
			if v_u_208.hideMyGear then
				v_u_208.hideMyGear.set(v_u_897.hideMyGear == true)
			end
			if v_u_208.hideOthersGear then
				v_u_208.hideOthersGear.set(v_u_897.hideOthersGear == true)
			end
			if v_u_208.hideHeadwear then
				v_u_208.hideHeadwear.set(v_u_897.hideHeadwear == true)
			end
			if v_u_208.statusOutline then
				v_u_208.statusOutline.set(v_u_897.statusOutline ~= false)
			end
			if v_u_208.squadChat then
				v_u_208.squadChat.set(v_u_897.squadChat ~= false)
			end
			if v_u_208.objectOutlines then
				v_u_208.objectOutlines.set(v_u_897.objectOutlines ~= false)
			end
			if v_u_208.reduceFlashing then
				v_u_208.reduceFlashing.set(v_u_897.reduceFlashing == true)
			end
			if v_u_208.hideUi then
				v_u_208.hideUi.set(v_u_2:GetAttribute("UiHidden") == true)
			end
			if v_u_208.mapTasks then
				v_u_208.mapTasks.set(v_u_897.mapTasks ~= false)
			end
			if v_u_208.crateQuick then
				v_u_208.crateQuick.set(v_u_897.crateQuick == true)
			end
			if v_u_208.ammoStackNoAsk then
				v_u_208.ammoStackNoAsk.set(v_u_897.ammoStackNoAsk ~= true)
			end
			if v_u_208.skinFx then
				v_u_208.skinFx.set(v_u_897.skinFx ~= false)
			end
			if v_u_208.weaponSkins then
				v_u_208.weaponSkins.set(v_u_897.weaponSkins ~= false)
			end
			if v_u_208.showClanColors then
				v_u_208.showClanColors.set(v_u_897.showClanColors ~= false)
			end
			if v_u_208.showFps then
				v_u_208.showFps.set(v_u_897.showFps == true)
			end
			if v_u_208.entryMode then
				v_u_208.entryMode.set(v_u_897.entryMode ~= "short" and v_u_897.entryMode ~= "off" and "full" or v_u_897.entryMode)
			end
			if v_u_208.tradeRequests then
				v_u_208.tradeRequests.set(v_u_897.tradeRequests ~= "squad" and v_u_897.tradeRequests ~= "nobody" and "everyone" or v_u_897.tradeRequests)
			end
			if v_u_208.taskTracker then
				v_u_208.taskTracker.set(v_u_897.taskTracker ~= "compact" and v_u_897.taskTracker ~= "off" and "full" or v_u_897.taskTracker)
			end
			if v_u_208.menuStyle then
				v_u_208.menuStyle.set(v_u_897.menuStyle ~= "v2" and v_u_897.menuStyle ~= "classic" and "auto" or v_u_897.menuStyle)
			end
			if v_u_208.mapLabels then
				v_u_208.mapLabels.set(v_u_897.mapLabels ~= false)
			end
			if v_u_208.touchFire then
				v_u_208.touchFire.set(v_u_897.touchFire ~= "ring" and (v_u_897.touchFire ~= "both" and v_u_897.touchFire ~= "button") and "auto" or v_u_897.touchFire)
			end
			for _, v923 in {
				"fov",
				"sensitivity",
				"fpAdsSens",
				"fpPadSens",
				"fpTouchSens",
				"fpBob",
				"fpSway"
			} do
				if not v_u_208[v923] then
					continue
				end
				local v924 = v_u_208[v923].set
				local v925 = v_u_897[v923]
				v924(tonumber(v925) or v_u_6[v923])
			end
			if v_u_208.fpInvertY then
				v_u_208.fpInvertY.set(v_u_897.fpInvertY == true)
			end
			if v_u_208.fpShoulder then
				v_u_208.fpShoulder.set(v_u_897.fpShoulder == "left" and "left" or "right")
			end
		end
		pcall(v926)
		local v927 = v_u_462
		pcall(v927)
		local v928 = v_u_802
		pcall(v928)
		local v929 = v_u_674
		pcall(v929)
		local v930 = v_u_840
		pcall(v930)
		v_u_826()
		if p895 ~= true then
			v_u_865(v_u_202.initial({
				["touch"] = v_u_249() == "Touch",
				["last"] = v_u_3,
				["visible"] = v_u_260
			}), false)
		end
	end
	function v_u_205.hide() -- name: hide
		-- upvalues: (copy) v_u_205
		v_u_205.flush()
	end
	function v_u_205.flush() -- name: flush
		-- upvalues: (ref) v_u_206, (copy) p_u_194
		if next(v_u_206) ~= nil then
			local v931 = {
				["op"] = "setting",
				["settings"] = nil,
				["settings"] = v_u_206
			}
			p_u_194.op(v931)
			v_u_206 = {}
		end
	end
	function v_u_205.tick() -- name: tick
		-- upvalues: (ref) v_u_206, (ref) v_u_207, (copy) v_u_205, (copy) v_u_826, (ref) v_u_645, (copy) v_u_674, (copy) v_u_802, (copy) v_u_462, (copy) v_u_840
		if next(v_u_206) ~= nil and v_u_207 <= os.clock() then
			v_u_205.flush()
		end
		v_u_826()
		if v_u_645 <= os.clock() then
			v_u_645 = os.clock() + 2
			local v932 = v_u_674
			pcall(v932)
			local v933 = v_u_802
			pcall(v933)
		end
		local v934 = v_u_462
		pcall(v934)
		local v935 = v_u_840
		pcall(v935)
	end
	function v_u_205.refresh() -- name: refresh end
	function v_u_205.destroy() -- name: destroy
		-- upvalues: (ref) v_u_210, (copy) v_u_205, (copy) v_u_208, (ref) v_u_328, (copy) v_u_209
		v_u_210 = false
		v_u_205.flush()
		local v936 = v_u_208.tradeRowOff
		if type(v936) == "function" then
			local v937 = v_u_208.tradeRowOff
			pcall(v937)
			v_u_208.tradeRowOff = nil
		end
		if v_u_208.tradeRowConn then
			local function v938()
				-- upvalues: (ref) v_u_208
				v_u_208.tradeRowConn:Disconnect()
			end
			pcall(v938)
			v_u_208.tradeRowConn = nil
		end
		if v_u_328 then
			local v939 = v_u_328.destroy
			pcall(v939)
			v_u_328 = nil
		end
		for _, v_u_940 in v_u_209 do
			pcall(function()
				-- upvalues: (copy) v_u_940
				v_u_940:Disconnect()
			end)
		end
		table.clear(v_u_209)
	end
	return v_u_205
end
return v_u_1