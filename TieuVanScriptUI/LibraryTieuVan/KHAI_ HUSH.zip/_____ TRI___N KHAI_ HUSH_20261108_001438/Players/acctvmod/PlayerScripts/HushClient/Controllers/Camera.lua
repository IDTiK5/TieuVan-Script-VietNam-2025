-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Camera

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(v4:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Iso"))
local v_u_6 = {
	["name"] = "Camera",
	["order"] = 12,
	["RIDE_HOOK"] = true
}
local v_u_7 = table.clone(v_u_5.ZOOM_LEVELS)
table.insert(v_u_7, {
	["dist"] = 176,
	["fov"] = 22
})
v_u_6.ZOOM_LEVELS = v_u_7
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v_u_1.LocalPlayer
local v_u_11 = "scripted"
local v_u_12 = nil
local v_u_13 = Vector3.new(0, 0, 0)
local v_u_14 = Vector3.new(0, 0, 0)
local v_u_15 = false
local v_u_16 = true
local v_u_17 = Vector3.new(0, 0, 0)
local v_u_18 = Vector3.new(0, 0, 0)
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = 0
local v_u_22 = 0
local v_u_23 = v_u_5.yawForStep(0)
local v_u_24 = 0
local v_u_25 = v_u_5.DEFAULT_ZOOM
local v_u_26 = v_u_7[v_u_5.DEFAULT_ZOOM].dist
local v_u_27 = 0
local v_u_28 = v_u_7[v_u_5.DEFAULT_ZOOM].fov
local v_u_29 = {}
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = false
local v_u_34 = {}
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = 0
local function v_u_41(p38) -- name: rootOf
	if p38 then
		if p38:IsA("Player") then
			local v39 = p38.Character
			if v39 then
				v39 = v39:FindFirstChild("HumanoidRootPart")
			end
			return v39
		elseif p38:IsA("Model") then
			local v40 = p38:FindFirstChild("HumanoidRootPart")
			if v40 and v40:IsA("BasePart") then
				return v40
			else
				return p38.PrimaryPart
			end
		elseif p38:IsA("BasePart") then
			return p38
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_6.gestureNew() -- name: gestureNew
	return {
		["lock"] = nil,
		["pinchOn"] = false,
		["twistOn"] = false,
		["scale"] = 1,
		["pinchRef"] = 1,
		["twist"] = 0,
		["twistRef"] = 0,
		["lastAngle"] = nil,
		["t"] = -1000000000
	}
end
local function v_u_51(p42) -- name: gestureIntent
	if p42.lock then
		return p42.lock
	end
	local v43 = p42.scale
	local v44 = math.max(v43, 0.001)
	local v45 = math.log(v44)
	local v46 = math.abs(v45) / 0.30010459245033816
	local v47 = p42.twist
	local v48 = math.abs(v47) / 35
	local v49 = math.max(v46, v48)
	local v50 = math.min(v46, v48)
	if v49 >= 0.45 and (v50 * 1.5 <= v49 or v49 >= 1) then
		p42.lock = v48 <= v46 and "zoom" or "rotate"
	end
	return p42.lock
end
function v_u_6.lineAngle(p52) -- name: lineAngle
	if type(p52) ~= "table" then
		return nil
	end
	local v_u_53 = p52[1]
	local v_u_54 = p52[2]
	local v55, v56, v57 = pcall(function()
		-- upvalues: (copy) v_u_53
		return v_u_53.X, v_u_53.Y
	end)
	local v58, v59, v60 = pcall(function()
		-- upvalues: (copy) v_u_54
		return v_u_54.X, v_u_54.Y
	end)
	if not v55 or (not v58 or (type(v56) ~= "number" or (type(v57) ~= "number" or (type(v59) ~= "number" or type(v60) ~= "number")))) then
		return nil
	end
	if v59 - v56 == 0 and v60 - v57 == 0 then
		return nil
	end
	local v61 = v60 - v57
	local v62 = v59 - v56
	local v63 = math.atan2(v61, v62)
	return math.deg(v63)
end
function v_u_6.gestureEvent(p64, p65, p66, p67, p68, p69) -- name: gestureEvent
	-- upvalues: (copy) v_u_51
	local v70 = p69 or os.clock()
	local v71 = p67 == Enum.UserInputState.End and true or p67 == Enum.UserInputState.Cancel
	local v72 = v70 - p64.t > 0.8
	p64.t = v70
	if v72 then
		p64.lock = nil
	end
	if v71 then
		if p65 == "pinch" then
			p64.pinchOn = false
		else
			p64.twistOn = false
		end
		if not (p64.pinchOn or p64.twistOn) then
			p64.lock = nil
			p64.scale = 1
			p64.pinchRef = 1
			p64.twist = 0
			p64.twistRef = 0
			p64.lastAngle = nil
		end
		return nil
	end
	if p68 then
		return nil
	end
	local v73 = p67 == Enum.UserInputState.Begin
	if v73 and (v72 or not (p64.pinchOn or p64.twistOn)) then
		p64.lock = nil
		p64.scale = 1
		p64.pinchRef = 1
		p64.twist = 0
		p64.twistRef = 0
		p64.lastAngle = nil
		p64.pinchOn = false
		p64.twistOn = false
	end
	if p65 == "pinch" then
		p64.pinchOn = true
		if v73 then
			p64.scale = 1
			p64.pinchRef = 1
			return nil
		end
		p64.scale = p66
		if v_u_51(p64) ~= "zoom" then
			return nil
		end
		local v74 = p66 / p64.pinchRef
		if v74 > 1.35 then
			p64.pinchRef = p66
			return "zoomIn"
		end
		if v74 >= 0.74 then
			return nil
		end
		p64.pinchRef = p66
		return "zoomOut"
	end
	p64.twistOn = true
	if v73 or p64.lastAngle == nil then
		p64.twist = 0
		p64.twistRef = 0
		p64.lastAngle = p66
		return nil
	end
	local v75 = (p66 - p64.lastAngle + 90) % 180 - 90
	p64.twist = p64.twist + v75
	p64.lastAngle = p66
	if v_u_51(p64) ~= "rotate" then
		return nil
	end
	local v76 = p64.twist - p64.twistRef
	if math.abs(v76) < 35 then
		return nil
	end
	local v77 = v76 > 0 and 1 or -1
	p64.twistRef = p64.twistRef + v77 * 35
	return v77 > 0 and "cw" or "ccw"
end
function v_u_6.mode() -- name: mode
	-- upvalues: (ref) v_u_36, (ref) v_u_11
	if v_u_36 ~= nil and v_u_11 == "iso" then
		local v78 = v_u_36.modeName
		if type(v78) == "function" then
			local v79 = v_u_36.modeName
			local v80, v81 = pcall(v79)
			if v80 and (v81 == "fp" or v81 == "tp") then
				return v81
			end
		end
	end
	return v_u_11
end
function v_u_6.setMode(p82, p83) -- name: setMode
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_16, (copy) v_u_10
	if p82 == "iso" or (p82 == "scripted" or p82 == "spectate") then
		local v84 = v_u_11
		v_u_11 = p82
		if typeof(p83) ~= "Instance" then
			p83 = nil
		end
		if p82 ~= "spectate" then
			p83 = nil
		end
		v_u_12 = p83
		if p82 ~= "scripted" and (v84 == "scripted" or v84 ~= p82) then
			v_u_16 = v84 == "scripted"
			local v85 = workspace.CurrentCamera
			if v85 then
				v85.CameraType = Enum.CameraType.Scriptable
			end
		end
		v_u_10:SetAttribute("CamMode", v_u_11)
		v_u_10:SetAttribute("CamTarget", not v_u_12 and "" or v_u_12.Name)
	else
		warn("[Camera] unknown mode", p82)
	end
end
function v_u_6.setOverride(p86) -- name: setOverride
	-- upvalues: (ref) v_u_35, (ref) v_u_16, (copy) v_u_10
	local v87 = v_u_35 ~= nil
	if type(p86) ~= "function" then
		p86 = nil
	end
	v_u_35 = p86
	if v87 and v_u_35 == nil then
		v_u_16 = true
	end
	v_u_10:SetAttribute("CamOverride", v_u_35 ~= nil)
end
function v_u_6.hasOverride() -- name: hasOverride
	-- upvalues: (ref) v_u_35
	return v_u_35 ~= nil
end
function v_u_6.setViewRig(p88) -- name: setViewRig
	-- upvalues: (ref) v_u_36, (ref) v_u_37, (ref) v_u_16
	local v89 = v_u_36 ~= nil
	if type(p88) == "table" then
		local v90 = p88.render
		if type(v90) ~= "function" then
			p88 = nil
		end
	else
		p88 = nil
	end
	v_u_36 = p88
	v_u_37 = 0
	if v89 and v_u_36 == nil then
		v_u_16 = true
	end
end
function v_u_6.viewRig() -- name: viewRig
	-- upvalues: (ref) v_u_36
	return v_u_36
end
function v_u_6.yaw() -- name: yaw
	-- upvalues: (ref) v_u_36, (ref) v_u_23
	local v91 = v_u_36
	local v92
	if v91 == nil then
		v92 = nil
	else
		local v93 = v91.yaw
		if type(v93) == "function" then
			local v94 = v91.yaw
			local v95
			v95, v92 = pcall(v94)
			if not v95 or (type(v92) ~= "number" or v92 ~= v92) then
				v92 = nil
			end
		else
			v92 = nil
		end
	end
	return v92 or v_u_23
end
function v_u_6.targetYaw() -- name: targetYaw
	-- upvalues: (copy) v_u_5, (ref) v_u_22
	return v_u_5.yawForStep(v_u_22)
end
function v_u_6.forward() -- name: forward
	-- upvalues: (copy) v_u_5, (ref) v_u_36, (ref) v_u_23
	local v96 = v_u_5.directionOfYaw
	local v97 = v_u_36
	local v98
	if v97 == nil then
		v98 = nil
	else
		local v99 = v97.yaw
		if type(v99) == "function" then
			local v100 = v97.yaw
			local v101
			v101, v98 = pcall(v100)
			if not v101 or (type(v98) ~= "number" or v98 ~= v98) then
				v98 = nil
			end
		else
			v98 = nil
		end
	end
	return v96(v98 or v_u_23)
end
function v_u_6.right() -- name: right
	-- upvalues: (copy) v_u_5, (ref) v_u_36, (ref) v_u_23
	local v102 = v_u_5.directionOfYaw
	local v103 = v_u_36
	local v104
	if v103 == nil then
		v104 = nil
	else
		local v105 = v103.yaw
		if type(v105) == "function" then
			local v106 = v103.yaw
			local v107
			v107, v104 = pcall(v106)
			if not v107 or (type(v104) ~= "number" or v104 ~= v104) then
				v104 = nil
			end
		else
			v104 = nil
		end
	end
	local v108 = v102(v104 or v_u_23)
	local v109 = -v108.Z
	local v110 = v108.X
	return Vector3.new(v109, 0, v110)
end
function v_u_6.focus() -- name: focus
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_6.isoPose(p111) -- name: isoPose
	-- upvalues: (ref) v_u_11, (copy) v_u_41, (ref) v_u_12, (copy) v_u_10, (copy) v_u_7, (ref) v_u_25, (copy) v_u_5, (ref) v_u_22
	if typeof(p111) == "Vector3" then
		if typeof(p111) ~= "Vector3" then
			return nil, nil
		end
		v113 = v_u_7[v_u_25]
		return v_u_5.cameraCFrame(p111 - Vector3.new(0, 0.6, 0), v_u_5.yawForStep(v_u_22), v_u_5.PITCH, v113.dist), v113.fov
	end
	local v112
	if v_u_11 == "spectate" then
		v112 = v_u_41(v_u_12)
		if v112 and v112.Parent then
			if v112 then
				p111 = v112.Position
			else
				p111 = nil
			end
		else
			v112 = v_u_10.Character
			if v112 then
				v112 = v112:FindFirstChild("HumanoidRootPart")
			end
			if v112 then
				p111 = v112.Position
			else
				p111 = nil
			end
		end
	else
		v112 = v_u_10.Character
		if v112 then
			v112 = v112:FindFirstChild("HumanoidRootPart")
		end
		if v112 then
			p111 = v112.Position
		else
			p111 = nil
		end
	end
	if typeof(p111) ~= "Vector3" then
		return nil, nil
	end
	local v113 = v_u_7[v_u_25]
	return v_u_5.cameraCFrame(p111 - Vector3.new(0, 0.6, 0), v_u_5.yawForStep(v_u_22), v_u_5.PITCH, v113.dist), v113.fov
end
function v_u_6.subject() -- name: subject
	-- upvalues: (ref) v_u_11, (copy) v_u_41, (ref) v_u_12, (copy) v_u_10
	if v_u_11 == "scripted" then
		return nil
	end
	if v_u_11 == "spectate" then
		local v114 = v_u_41(v_u_12)
		if v114 and v114.Parent then
			return v114
		end
	end
	local v115 = v_u_10.Character
	if v115 then
		v115 = v115:FindFirstChild("HumanoidRootPart")
	end
	return v115
end
function v_u_6.zoomLevel() -- name: zoomLevel
	-- upvalues: (ref) v_u_25
	return v_u_25
end
function v_u_6.setZoom(p116) -- name: setZoom
	-- upvalues: (ref) v_u_25, (copy) v_u_7, (copy) v_u_10, (ref) v_u_8
	local v117 = p116 + 0.5
	local v118 = math.floor(v117)
	local v119 = #v_u_7
	v_u_25 = math.clamp(v118, 1, v119)
	v_u_10:SetAttribute("CamZoom", v_u_25)
	if v_u_8 then
		v_u_8.emit("camera.zoom", v_u_25)
	end
end
function v_u_6.rotate(p120) -- name: rotate
	-- upvalues: (ref) v_u_36, (ref) v_u_22, (copy) v_u_10, (ref) v_u_8
	if p120 ~= 0 and v_u_36 == nil then
		v_u_22 = v_u_22 + (p120 > 0 and 1 or -1)
		v_u_10:SetAttribute("CamStep", v_u_22 % 4)
		if v_u_8 then
			v_u_8.emit("camera.rotate", v_u_22 % 4)
		end
		local v121 = v_u_8
		if v121 then
			v121 = v_u_8.controllers.Audio
		end
		if v121 and v121.ui then
			local v122 = v121.ui
			pcall(v122, "camRotate")
		end
	end
end
local v_u_123 = v_u_6.gestureNew()
v_u_6.gesture = v_u_123
function v_u_6.onTouchPinch(_, p124, _, p125, p126) -- name: onTouchPinch
	-- upvalues: (copy) v_u_6, (copy) v_u_123, (ref) v_u_11, (ref) v_u_35, (ref) v_u_36, (ref) v_u_25
	local v127 = v_u_6.gestureEvent(v_u_123, "pinch", p124, p125, p126 or ((v_u_11 == "scripted" or v_u_35 ~= nil) and true or v_u_36 ~= nil))
	if v127 == "zoomIn" then
		v_u_6.setZoom(v_u_25 - 1)
	elseif v127 == "zoomOut" then
		v_u_6.setZoom(v_u_25 + 1)
	end
end
function v_u_6.onTouchRotate(p128, p129, _, p130, p131) -- name: onTouchRotate
	-- upvalues: (copy) v_u_6, (ref) v_u_11, (ref) v_u_35, (ref) v_u_36, (ref) v_u_8, (copy) v_u_123
	local v132 = v_u_6.lineAngle(p128)
	if v132 == nil then
		v132 = (type(p129) ~= "number" or p129 ~= p129) and 0 or p129
	end
	if not p131 then
		if v_u_11 == "scripted" or (v_u_35 ~= nil or v_u_36 ~= nil) then
			p131 = true
		else
			local v133 = v_u_8 and v_u_8.controllers
			if v133 then
				v133 = v_u_8.controllers.Input
			end
			local v134 = v133 and v133.touch
			if v134 then
				v134 = v133.touch()
			end
			if v134 and v134.thumbsDown then
				local v135 = v134.thumbsDown
				local v136
				p131, v136 = pcall(v135, v134)
				if p131 then
					p131 = v136 == true
				end
			else
				p131 = false
			end
		end
	end
	local v137 = v_u_6.gestureEvent(v_u_123, "twist", v132, p130, p131)
	if v137 == "ccw" then
		v_u_6.rotate(1)
	elseif v137 == "cw" then
		v_u_6.rotate(-1)
	end
end
function v_u_6.setAimShift(p138) -- name: setAimShift
	-- upvalues: (ref) v_u_19
	local v139
	if p138 then
		v139 = math.clamp(p138, 0, 26)
	else
		v139 = nil
	end
	v_u_19 = v139
end
function v_u_6.setScopeView(p140, p141) -- name: setScopeView
	-- upvalues: (ref) v_u_20, (ref) v_u_21
	if type(p140) == "number" and (p140 == p140 and p140 > 0) then
		v_u_20 = math.clamp(p140, 1, 400)
		v_u_21 = (type(p141) ~= "number" or p141 ~= p141) and 0 or math.clamp(p141, 0, 26)
	else
		v_u_20 = nil
		v_u_21 = 0
	end
end
function v_u_6.shake(p142, p143) -- name: shake
	-- upvalues: (copy) v_u_10, (ref) v_u_29
	if type(p142) == "number" and (type(p143) == "number" and p142 == p142) then
		if p142 > 0 then
			local v144 = v_u_10:GetAttribute("CameraShake")
			if type(v144) ~= "number" then
				v144 = v_u_10:GetAttribute("SettingCameraShake")
			end
			if ((type(v144) ~= "number" or v144 ~= v144) and 1 or math.clamp(v144, 0, 1)) > 0 then
				local v145 = os.clock()
				local v146 = math.clamp(p142, 0, 2)
				local v147 = math.clamp(p143, 0.05, 5)
				local v148 = v_u_29[#v_u_29]
				if v148 and v145 - v148.t0 < 0.06 then
					local v149 = v148.amp
					v148.amp = math.max(v149, v146)
					local v150 = v148.dur
					local v151 = v147 + (v145 - v148.t0)
					v148.dur = math.max(v150, v151)
				else
					if #v_u_29 >= 8 then
						table.remove(v_u_29, 1)
					end
					local v152 = v_u_29
					local v153 = {
						["amp"] = v146,
						["t0"] = v145,
						["dur"] = v147,
						["seed"] = math.random() * 100
					}
					table.insert(v152, v153)
				end
			end
		end
	end
end
function v_u_6.aimPlanePoint(p154) -- name: aimPlanePoint
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (ref) v_u_13, (copy) v_u_5
	local v155 = workspace.CurrentCamera
	if not v155 then
		return nil
	end
	local v156 = p154 or v_u_3:GetMouseLocation()
	local v157 = v155:ViewportPointToRay(v156.X, v156.Y)
	local v158 = v_u_10.Character
	if v158 then
		v158 = v158:FindFirstChild("HumanoidRootPart")
	end
	local v159
	if v158 then
		v159 = v158.Position.Y
	else
		v159 = v_u_13.Y
	end
	return v_u_5.rayPlaneY(v157.Origin, v157.Direction, v159)
end
local function v_u_172(p160) -- name: shakeOffset
	-- upvalues: (ref) v_u_29, (copy) v_u_10
	if #v_u_29 == 0 then
		return Vector3.new(0, 0, 0), 0
	end
	local v161 = v_u_10:GetAttribute("CameraShake")
	if type(v161) ~= "number" then
		v161 = v_u_10:GetAttribute("SettingCameraShake")
	end
	local v162 = (type(v161) ~= "number" or v161 ~= v161) and 1 or math.clamp(v161, 0, 1)
	local v163 = 0
	local v164 = 0
	local v165 = 0
	for v166 = #v_u_29, 1, -1 do
		local v167 = v_u_29[v166]
		local v168 = p160 - v167.t0
		if v167.dur <= v168 then
			table.remove(v_u_29, v166)
		else
			local v169 = 1 - v168 / v167.dur
			local v170 = v167.amp * v169 * v169 * v162
			local v171 = p160 * 18
			v163 = v163 + math.noise(v167.seed, v171, 0) * v170 * 1.3
			v164 = v164 + math.noise(v167.seed + 31.7, v171, 0) * v170 * 1.3
			v165 = v165 + math.noise(v167.seed + 63.1, v171 * 0.7, 0) * v170 * 0.020943951023931952
		end
	end
	return Vector3.new(v163, v164, 0), v165
end
local function v_u_261(p173) -- name: update
	-- upvalues: (ref) v_u_11, (ref) v_u_35, (ref) v_u_16, (copy) v_u_10, (ref) v_u_36, (copy) v_u_41, (ref) v_u_12, (copy) v_u_172, (ref) v_u_37, (ref) v_u_31, (ref) v_u_23, (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (copy) v_u_3, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (copy) v_u_6, (ref) v_u_17, (ref) v_u_18, (copy) v_u_5, (ref) v_u_15, (ref) v_u_14, (ref) v_u_22, (ref) v_u_24, (ref) v_u_26, (copy) v_u_7, (ref) v_u_25, (ref) v_u_27, (ref) v_u_28
	if v_u_11 == "scripted" then
		return
	end
	local v174 = workspace.CurrentCamera
	if not v174 then
		return
	end
	local v175 = math.clamp(p173, 0, 0.1)
	if v174.CameraType ~= Enum.CameraType.Scriptable then
		v174.CameraType = Enum.CameraType.Scriptable
	end
	if v_u_35 then
		local v176 = v_u_35
		local v177, v178, v179 = pcall(v176, v175)
		if v177 and typeof(v178) == "CFrame" then
			v174.CFrame = v178
			if type(v179) == "number" and v179 == v179 then
				v174.FieldOfView = math.clamp(v179, 1, 120)
			end
			v174.Focus = CFrame.new(v178.Position + v178.LookVector * 20)
			v_u_16 = true
			return
		end
		if not v177 then
			warn("[Camera] override failed:", v178)
			v_u_35 = nil
			v_u_16 = true
			v_u_10:SetAttribute("CamOverride", false)
		end
	end
	local v180, v181, v182, v183, v184, v185, v186, v187, v188, v189, v190, v191, v192, v193, v194, v195, v196, v197, v198, v199, v200, v201, v202, v203, v204, v205, v206, v207, v208, v209, v210, v211, v212, v213, v214, v215, v216, v217, v218, v219, v220, v221, v222, v223, v224, v225, v226, v227, v228, v229, v230, v231, v232, v233, v234, v235, v236
	if v_u_36 == nil then
		if v_u_11 ~= "spectate" then
			v180 = v_u_10.Character
			if v180 then
				v180 = v180:FindFirstChild("HumanoidRootPart")
			end
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		end
		v180 = v_u_41(v_u_12)
		if v180 and v180.Parent then
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		else
			v180 = v_u_10.Character
			if v180 then
				v180 = v180:FindFirstChild("HumanoidRootPart")
			end
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		end
	else
		local v237 = v_u_36
		local v238 = v237.render
		local v239 = {
			["mode"] = v_u_11
		}
		local v240, v241, v242, v243, v244, v245, v246, v247, v248, v249, v250, v251, v252, v253, v254, v255, v256, v257, v258, v259, v260
		if v_u_11 == "spectate" then
			v240 = v_u_41(v_u_12)
			if v240 and v240.Parent then
				v239.subject = v240
				v239.target = v_u_12
				v241, v242, v243, v244 = pcall(v238, v175, v239)
				if v241 and typeof(v242) == "CFrame" then
					v245 = os.clock()
					v246, v247 = v_u_172(v245)
					if v246 ~= Vector3.new(0, 0, 0) or v247 ~= 0 then
						v242 = v242 * CFrame.new(v246) * CFrame.Angles(0, 0, v247)
					end
					v174.CFrame = v242
					if type(v243) == "number" and v243 == v243 then
						v174.FieldOfView = math.clamp(v243, 1, 120)
					end
					if typeof(v244) ~= "CFrame" then
						v244 = v242
					end
					v174.Focus = v244
					v_u_16 = true
					v_u_37 = 0
					v248 = v237.after
					if type(v248) == "function" then
						v249 = v237.after
						v250, v251 = pcall(v249, v242, v175)
						if not v250 then
							v_u_37 = v_u_37 + 1
							if v_u_37 < 4 then
								warn("[Camera] view rig after failed:", v251)
							end
						end
					end
					if v245 - v_u_31 > 0.25 then
						v_u_31 = v245
						v252 = v_u_10
						v253 = "CamYaw"
						v254 = v_u_36
						if v254 == nil then
							v255 = nil
						else
							v256 = v254.yaw
							if type(v256) == "function" then
								v257 = v254.yaw
								v258, v255 = pcall(v257)
								if not v258 or (type(v255) ~= "number" or v255 ~= v255) then
									v255 = nil
								end
							else
								v255 = nil
							end
						end
						v259 = v255 or v_u_23
						v260 = math.deg(v259) * 10 + 0.5
						v252:SetAttribute(v253, math.floor(v260) / 10)
					end
					return
				end
				if not v241 then
					v_u_37 = v_u_37 + 1
					if v_u_37 < 4 or v_u_37 % 300 == 0 then
						warn("[Camera] view rig render failed:", v242)
					end
				end
			else
				v240 = v_u_10.Character
				if v240 then
					v240 = v240:FindFirstChild("HumanoidRootPart")
				end
				v239.subject = v240
				v239.target = v_u_12
				v241, v242, v243, v244 = pcall(v238, v175, v239)
				if v241 and typeof(v242) == "CFrame" then
					v245 = os.clock()
					v246, v247 = v_u_172(v245)
					if v246 ~= Vector3.new(0, 0, 0) or v247 ~= 0 then
						v242 = v242 * CFrame.new(v246) * CFrame.Angles(0, 0, v247)
					end
					v174.CFrame = v242
					if type(v243) == "number" and v243 == v243 then
						v174.FieldOfView = math.clamp(v243, 1, 120)
					end
					if typeof(v244) ~= "CFrame" then
						v244 = v242
					end
					v174.Focus = v244
					v_u_16 = true
					v_u_37 = 0
					v248 = v237.after
					if type(v248) == "function" then
						v249 = v237.after
						v250, v251 = pcall(v249, v242, v175)
						if not v250 then
							v_u_37 = v_u_37 + 1
							if v_u_37 < 4 then
								warn("[Camera] view rig after failed:", v251)
							end
						end
					end
					if v245 - v_u_31 > 0.25 then
						v_u_31 = v245
						v252 = v_u_10
						v253 = "CamYaw"
						v254 = v_u_36
						if v254 == nil then
							v255 = nil
						else
							v256 = v254.yaw
							if type(v256) == "function" then
								v257 = v254.yaw
								v258, v255 = pcall(v257)
								if not v258 or (type(v255) ~= "number" or v255 ~= v255) then
									v255 = nil
								end
							else
								v255 = nil
							end
						end
						v259 = v255 or v_u_23
						v260 = math.deg(v259) * 10 + 0.5
						v252:SetAttribute(v253, math.floor(v260) / 10)
					end
					return
				end
				if not v241 then
					v_u_37 = v_u_37 + 1
					if v_u_37 < 4 or v_u_37 % 300 == 0 then
						warn("[Camera] view rig render failed:", v242)
					end
				end
			end
		else
			v240 = v_u_10.Character
			if v240 then
				v240 = v240:FindFirstChild("HumanoidRootPart")
			end
			v239.subject = v240
			v239.target = v_u_12
			v241, v242, v243, v244 = pcall(v238, v175, v239)
			if v241 and typeof(v242) == "CFrame" then
				v245 = os.clock()
				v246, v247 = v_u_172(v245)
				if v246 ~= Vector3.new(0, 0, 0) or v247 ~= 0 then
					v242 = v242 * CFrame.new(v246) * CFrame.Angles(0, 0, v247)
				end
				v174.CFrame = v242
				if type(v243) == "number" and v243 == v243 then
					v174.FieldOfView = math.clamp(v243, 1, 120)
				end
				if typeof(v244) ~= "CFrame" then
					v244 = v242
				end
				v174.Focus = v244
				v_u_16 = true
				v_u_37 = 0
				v248 = v237.after
				if type(v248) == "function" then
					v249 = v237.after
					v250, v251 = pcall(v249, v242, v175)
					if not v250 then
						v_u_37 = v_u_37 + 1
						if v_u_37 < 4 then
							warn("[Camera] view rig after failed:", v251)
						end
					end
				end
				if v245 - v_u_31 > 0.25 then
					v_u_31 = v245
					v252 = v_u_10
					v253 = "CamYaw"
					v254 = v_u_36
					if v254 == nil then
						v255 = nil
					else
						v256 = v254.yaw
						if type(v256) == "function" then
							v257 = v254.yaw
							v258, v255 = pcall(v257)
							if not v258 or (type(v255) ~= "number" or v255 ~= v255) then
								v255 = nil
							end
						else
							v255 = nil
						end
					end
					v259 = v255 or v_u_23
					v260 = math.deg(v259) * 10 + 0.5
					v252:SetAttribute(v253, math.floor(v260) / 10)
				end
				return
			end
			if not v241 then
				v_u_37 = v_u_37 + 1
				if v_u_37 < 4 or v_u_37 % 300 == 0 then
					warn("[Camera] view rig render failed:", v242)
				end
			end
		end
		if v_u_11 ~= "spectate" then
			v180 = v_u_10.Character
			if v180 then
				v180 = v180:FindFirstChild("HumanoidRootPart")
			end
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		end
		v180 = v_u_41(v_u_12)
		if v180 and v180.Parent then
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		else
			v180 = v_u_10.Character
			if v180 then
				v180 = v180:FindFirstChild("HumanoidRootPart")
			end
			v181 = 1
			if v180 then
				v182 = v180.Position
				v183 = v182 - Vector3.new(0, 0.6, 0)
				v184 = v_u_9
				if v184 == nil or (v_u_11 ~= "iso" or not (v184.active() or v184.classicActive())) then
					v185 = v181
				else
					v186 = v184.classic
					v187, v185, v188, v189 = pcall(v186, v175)
					if v187 and type(v185) == "number" then
						v183 = v183 + Vector3.new(v188 or 0, 0, v189 or 0)
					else
						v185 = v181
					end
				end
				v190 = Vector3.new(0, 0, 0)
				if v_u_11 == "iso" then
					v191 = v_u_10.Character
					if v191 == nil then
						v192 = false
					else
						v192 = v191:GetAttribute("Aiming") == true
					end
					v193 = v_u_8 and v_u_8.controllers
					if v193 then
						v193 = v_u_8.controllers.Input
					end
					if v193 and v193.device then
						v194 = v193.device
						v195, v196 = pcall(v194)
						if v195 and type(v196) == "string" then
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						else
							v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
							v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
							if v_u_20 == nil then
								v198 = false
							else
								v198 = v_u_21 > 0
							end
							if v198 then
								v197 = v_u_21
							end
							if v197 > 0 then
								v199 = nil
								v200 = v_u_8 and v_u_8.controllers
								if v200 then
									v200 = v_u_8.controllers.Input
								end
								if v200 and v200.aimPoint then
									v201 = v200.aimPoint
									v202, v203 = pcall(v201)
									if v202 then
										if typeof(v203) ~= "Vector3" then
											v203 = v199
										end
									else
										v203 = v199
									end
								else
									v203 = v199
								end
								if not v203 and v196 == "Keyboard" then
									v203 = v_u_6.aimPlanePoint(nil)
								end
								if v203 then
									v204 = v203.X - v182.X
									v205 = v203.Z - v182.Z
									v206 = Vector3.new(v204, 0, v205)
									v207 = v206.Magnitude
									if v207 > 0.5 then
										v208 = v206.Unit
										if not v198 or v196 == "Keyboard" then
											v209 = v207 * 0.5
											v197 = math.min(v197, v209)
										end
										v190 = v208 * v197
									end
								end
							end
						end
					else
						v196 = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or "Keyboard"
						v197 = v_u_19 or (v192 and 9 or (v196 == "Keyboard" and 2.2 or 0))
						if v_u_20 == nil then
							v198 = false
						else
							v198 = v_u_21 > 0
						end
						if v198 then
							v197 = v_u_21
						end
						if v197 > 0 then
							v199 = nil
							v200 = v_u_8 and v_u_8.controllers
							if v200 then
								v200 = v_u_8.controllers.Input
							end
							if v200 and v200.aimPoint then
								v201 = v200.aimPoint
								v202, v203 = pcall(v201)
								if v202 then
									if typeof(v203) ~= "Vector3" then
										v203 = v199
									end
								else
									v203 = v199
								end
							else
								v203 = v199
							end
							if not v203 and v196 == "Keyboard" then
								v203 = v_u_6.aimPlanePoint(nil)
							end
							if v203 then
								v204 = v203.X - v182.X
								v205 = v203.Z - v182.Z
								v206 = Vector3.new(v204, 0, v205)
								v207 = v206.Magnitude
								if v207 > 0.5 then
									v208 = v206.Unit
									if not v198 or v196 == "Keyboard" then
										v209 = v207 * 0.5
										v197 = math.min(v197, v209)
									end
									v190 = v208 * v197
								end
							end
						end
					end
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				else
					v210, v211 = v_u_5.springVector(v_u_17, v_u_18, v190, 4.5, v175)
					v_u_17 = v210
					v_u_18 = v211
					if v_u_15 and (not v_u_16 and (v183 - v_u_13).Magnitude <= 60) then
						v212, v213 = v_u_5.springVector(v_u_13, v_u_14, v183, 9, v175)
						v_u_13 = v212
						v_u_14 = v213
					else
						v_u_13 = v183
						v_u_14 = Vector3.new(0, 0, 0)
						v_u_17 = v190
						v_u_18 = Vector3.new(0, 0, 0)
						v_u_15 = true
						if v_u_16 then
							v_u_23 = v_u_5.yawForStep(v_u_22)
							v_u_24 = 0
							v_u_26 = v_u_7[v_u_25].dist
							v_u_27 = 0
						end
						v_u_16 = false
					end
				end
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			else
				v185 = v181
				v214, v215 = v_u_5.springNumber(v_u_23, v_u_24, v_u_5.yawForStep(v_u_22), 9.5, v175)
				v_u_23 = v214
				v_u_24 = v215
				v216 = v_u_7[v_u_25]
				v217 = v_u_5.springNumber
				v218 = v_u_26
				v219 = v_u_27
				if v_u_11 == "iso" and v_u_20 ~= nil then
					v220 = v216.dist
					v221 = v_u_20
					v222 = math.max(v220, v221)
				else
					v222 = v216.dist
				end
				v223, v224 = v217(v218, v219, v222 * v185, 7, v175)
				v_u_26 = v223
				v_u_27 = v224
				v225 = v_u_28
				v226 = v216.fov - v_u_28
				v227 = v175 * 8
				v_u_28 = v225 + v226 * math.min(1, v227)
				v228 = os.clock()
				v229, v230 = v_u_172(v228)
				v231 = v_u_5.cameraCFrame(v_u_13 + v_u_17, v_u_23, v_u_5.PITCH, v_u_26)
				if v229 ~= Vector3.new(0, 0, 0) or v230 ~= 0 then
					v231 = v231 * CFrame.new(v229) * CFrame.Angles(0, 0, v230)
				end
				v174.FieldOfView = v_u_28
				v174.CFrame = v231
				v174.Focus = CFrame.new(v_u_13)
				if v228 - v_u_31 > 0.25 then
					v_u_31 = v228
					v232 = v_u_10
					v233 = v_u_23
					v234 = math.deg(v233) * 10 + 0.5
					v232:SetAttribute("CamYaw", math.floor(v234) / 10)
					v235 = v_u_10
					v236 = v_u_26 * 10 + 0.5
					v235:SetAttribute("CamDist", math.floor(v236) / 10)
				end
			end
		end
	end
end
local function v_u_263(p262) -- name: onRender
	-- upvalues: (ref) v_u_30, (copy) v_u_261
	v_u_30 = os.clock()
	v_u_261(p262)
end
local function v_u_270(p264) -- name: placeChanged
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (ref) v_u_25, (copy) v_u_6, (ref) v_u_16, (ref) v_u_11, (ref) v_u_29, (ref) v_u_15
	if p264 == "Raid" or p264 == "Hideout" then
		local v265 = v_u_10:GetAttribute("CameraZoomDefault")
		local v266
		if type(v265) == "number" and v265 == v265 then
			local v267 = v265 + 0.5
			local v268 = math.floor(v267)
			local v269 = #v_u_7
			v266 = math.clamp(v268, 1, v269)
		else
			v266 = nil
		end
		if v266 and v266 ~= v_u_25 then
			v_u_6.setZoom(v266)
		end
		v_u_6.setMode("iso")
		v_u_16 = true
	elseif p264 == "Menu" or p264 == "Transit" then
		if v_u_11 ~= "scripted" then
			v_u_6.setMode("scripted")
		end
		v_u_29 = {}
		v_u_15 = false
	end
end
local function v_u_286() -- name: bindInput
	-- upvalues: (ref) v_u_8, (copy) v_u_34, (ref) v_u_11, (copy) v_u_6, (ref) v_u_36, (ref) v_u_25, (copy) v_u_7, (copy) v_u_3
	local v_u_271 = v_u_8 and v_u_8.controllers
	if v_u_271 then
		v_u_271 = v_u_8.controllers.Input
	end
	if v_u_271 and v_u_271.bind then
		local function v281()
			-- upvalues: (ref) v_u_34, (copy) v_u_271, (ref) v_u_11, (ref) v_u_6, (ref) v_u_36, (ref) v_u_25, (ref) v_u_7
			local v272 = v_u_34
			local v273 = v_u_271.bind
			local function v274()
				-- upvalues: (ref) v_u_11, (ref) v_u_6
				if v_u_11 ~= "scripted" then
					v_u_6.rotate(1)
				end
			end
			table.insert(v272, v273("camLeft", v274))
			local v275 = v_u_34
			local v276 = v_u_271.bind
			local function v277()
				-- upvalues: (ref) v_u_11, (ref) v_u_6
				if v_u_11 ~= "scripted" then
					v_u_6.rotate(-1)
				end
			end
			table.insert(v275, v276("camRight", v277))
			local v278 = v_u_34
			local v279 = v_u_271.bind
			local function v280()
				-- upvalues: (ref) v_u_11, (ref) v_u_36, (ref) v_u_6, (ref) v_u_25, (ref) v_u_7
				if v_u_11 ~= "scripted" and v_u_36 == nil then
					v_u_6.setZoom(v_u_25 >= #v_u_7 and 1 or v_u_25 + 1)
				end
			end
			table.insert(v278, v279("zoom", v280))
		end
		if pcall(v281) then
			return
		end
	end
	local v_u_284 = v_u_3.InputBegan:Connect(function(p282, p283)
		-- upvalues: (ref) v_u_11, (ref) v_u_6
		if p283 or v_u_11 == "scripted" then
			return
		elseif p282.KeyCode == Enum.KeyCode.Q then
			v_u_6.rotate(1)
		elseif p282.KeyCode == Enum.KeyCode.E then
			v_u_6.rotate(-1)
		end
	end)
	local v285 = v_u_34
	table.insert(v285, function()
		-- upvalues: (copy) v_u_284
		v_u_284:Disconnect()
	end)
end
local function v_u_291() -- name: gestureState
	-- upvalues: (ref) v_u_22, (ref) v_u_25, (copy) v_u_6
	local v287 = string.format
	local v288 = v_u_22 % 4
	local v289 = v_u_25
	local v290 = v_u_6.gesture.lock or "-"
	return v287("step=%d zoom=%d lock=%s twist=%.1f scale=%.2f", v288, v289, tostring(v290), v_u_6.gesture.twist, v_u_6.gesture.scale)
end
local function v_u_326(p_u_292) -- name: registerGestureCommands
	-- upvalues: (copy) v_u_6, (copy) v_u_291, (ref) v_u_8
	p_u_292.command("camera.pinch", function(p293)
		-- upvalues: (ref) v_u_6, (ref) v_u_291
		local v294 = v_u_6.onTouchPinch
		local v295 = {}
		local v296 = p293[2]
		local v297 = tonumber(v296) or 1
		local v298 = 0
		local v299 = p293[1]
		local v300 = string.lower(v299 or "change")
		local v301
		if v300 == "begin" then
			v301 = Enum.UserInputState.Begin
		elseif v300 == "end" then
			v301 = Enum.UserInputState.End
		elseif v300 == "cancel" then
			v301 = Enum.UserInputState.Cancel
		else
			v301 = Enum.UserInputState.Change
		end
		v294(v295, v297, v298, v301, p293[3] == "gpe")
		return v_u_291()
	end)
	p_u_292.command("camera.twist", function(p302)
		-- upvalues: (ref) v_u_6, (ref) v_u_291
		local v303 = p302[2]
		local v304 = tonumber(v303) or 0
		local v305 = math.rad(v304)
		local v306 = Vector2.new(500, 400)
		local v307 = v_u_6.onTouchRotate
		local v308 = { v306, v306 + Vector2.new(math.cos(v305), (math.sin(v305))) * 120 }
		local v309 = 0
		local v310 = 0
		local v311 = p302[1]
		local v312 = string.lower(v311 or "change")
		local v313
		if v312 == "begin" then
			v313 = Enum.UserInputState.Begin
		elseif v312 == "end" then
			v313 = Enum.UserInputState.End
		elseif v312 == "cancel" then
			v313 = Enum.UserInputState.Cancel
		else
			v313 = Enum.UserInputState.Change
		end
		v307(v308, v309, v310, v313, p302[3] == "gpe")
		return v_u_291()
	end)
	p_u_292.command("camera.gesturereset", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_291
		local v314 = v_u_6.gesture
		local v315 = v_u_6.gesture
		local v316 = v_u_6.gesture
		local v317 = v_u_6.gesture
		local v318 = v_u_6.gesture
		local v319 = v_u_6.gesture
		v314.lock = nil
		v315.scale = 1
		v316.pinchRef = 1
		v317.twist = 0
		v318.twistRef = 0
		v319.lastAngle = nil
		local v320 = v_u_6.gesture
		local v321 = v_u_6.gesture
		local v322 = v_u_6.gesture
		v320.pinchOn = false
		v321.twistOn = false
		v322.t = -1000000000
		return v_u_291()
	end)
	local function v325()
		-- upvalues: (copy) p_u_292, (ref) v_u_8
		p_u_292.lib.TouchControls.registerDebug(p_u_292, function()
			-- upvalues: (ref) v_u_8
			local v323 = v_u_8 and v_u_8.controllers
			if v323 then
				v323 = v_u_8.controllers.Input
			end
			local v324 = v323 and v323.touch
			if v324 then
				v324 = v323.touch()
			end
			return v324
		end)
	end
	pcall(v325)
end
function v_u_6.init(p_u_327) -- name: init
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_10, (ref) v_u_11, (ref) v_u_25, (copy) v_u_7, (copy) v_u_6, (ref) v_u_22, (copy) v_u_5, (copy) v_u_1, (copy) v_u_326, (ref) v_u_23, (ref) v_u_26, (ref) v_u_28, (ref) v_u_13, (ref) v_u_30
	v_u_8 = p_u_327
	local v328, v329 = pcall(function()
		-- upvalues: (copy) p_u_327
		return p_u_327.lib.RideCam
	end)
	if not v328 or type(v329) ~= "table" then
		v329 = nil
	end
	v_u_9 = v329
	v_u_10:SetAttribute("CamMode", v_u_11)
	v_u_10:SetAttribute("CamZoom", v_u_25)
	v_u_10:SetAttribute("CamStep", 0)
	p_u_327.command("camera.zoom", function(p330)
		-- upvalues: (ref) v_u_7, (ref) v_u_6, (ref) v_u_25
		local v331 = p330[1]
		local v332 = tonumber(v331)
		if not v332 then
			return "usage: camera.zoom <1-" .. #v_u_7 .. ">"
		end
		v_u_6.setZoom(v332)
		return "zoom " .. v_u_25
	end)
	p_u_327.command("camera.rotate", function(p333)
		-- upvalues: (ref) v_u_6, (ref) v_u_22, (ref) v_u_5
		local v334 = p333[1]
		local v335 = tonumber(v334) or 1
		v_u_6.rotate(v335)
		local v336 = v_u_22 % 4
		local v337 = v_u_5.yawForStep(v_u_22)
		return "step " .. v336 .. " targetYaw " .. math.deg(v337)
	end)
	p_u_327.command("camera.mode", function(p338)
		-- upvalues: (ref) v_u_1, (ref) v_u_6, (ref) v_u_11
		local v339 = p338[1] or "iso"
		local v340
		if v339 == "spectate" and p338[2] then
			v340 = v_u_1:FindFirstChild(p338[2]) or workspace:FindFirstChild(p338[2])
		else
			v340 = nil
		end
		v_u_6.setMode(v339, v340)
		return "mode " .. v_u_11
	end)
	p_u_327.command("camera.shake", function(p341)
		-- upvalues: (ref) v_u_6
		local v342 = v_u_6.shake
		local v343 = p341[1]
		local v344 = tonumber(v343) or 0.5
		local v345 = p341[2]
		v342(v344, tonumber(v345) or 0.4)
		return "shaking"
	end)
	v_u_326(p_u_327)
	p_u_327.command("camera.info", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_23, (ref) v_u_5, (ref) v_u_22, (ref) v_u_25, (ref) v_u_26, (ref) v_u_28, (ref) v_u_13, (ref) v_u_30, (ref) v_u_10
		local v346 = workspace.CurrentCamera
		local v347 = string.format
		local v348 = "mode=%s subject=%s yaw=%.1f target=%.1f zoom=%d dist=%.1f fov=%.1f focus=%s camPos=%s type=%s renderAge=%.2f shakeScale=%.2f"
		local v349 = v_u_11
		local v350 = v_u_6.subject()
		local v351 = not (v350 and v350.Parent) and "nil" or v350.Parent:GetFullName()
		local v352 = v_u_23
		local v353 = math.deg(v352)
		local v354 = v_u_5.yawForStep(v_u_22)
		local v355 = math.deg(v354)
		local v356 = v_u_25
		local v357 = v_u_26
		local v358 = v_u_28
		local v359 = v_u_13
		local v360 = tostring(v359)
		local v361
		if v346 then
			v361 = v346.CFrame.Position
		else
			v361 = v346
		end
		local v362 = tostring(v361)
		if v346 then
			v346 = v346.CameraType
		end
		local v363 = tostring(v346)
		local v364 = os.clock() - v_u_30
		local v365 = v_u_10:GetAttribute("CameraShake")
		if type(v365) ~= "number" then
			v365 = v_u_10:GetAttribute("SettingCameraShake")
		end
		return v347(v348, v349, v351, v353, v355, v356, v357, v358, v360, v362, v363, v364, (type(v365) ~= "number" or v365 ~= v365) and 1 or math.clamp(v365, 0, 1))
	end)
end
function v_u_6.start() -- name: start
	-- upvalues: (ref) v_u_33, (copy) v_u_2, (copy) v_u_263, (copy) v_u_286, (copy) v_u_3, (ref) v_u_11, (ref) v_u_35, (ref) v_u_36, (ref) v_u_8, (ref) v_u_32, (copy) v_u_6, (ref) v_u_25, (copy) v_u_34, (copy) v_u_10, (copy) v_u_7, (copy) v_u_270, (ref) v_u_16
	if not v_u_33 then
		v_u_33 = true
		v_u_2:BindToRenderStep("HushCamera", Enum.RenderPriority.Camera.Value + 1, v_u_263)
	end
	v_u_286()
	local v_u_370 = v_u_3.InputChanged:Connect(function(p366, p367)
		-- upvalues: (ref) v_u_11, (ref) v_u_35, (ref) v_u_36, (ref) v_u_8, (ref) v_u_32, (ref) v_u_6, (ref) v_u_25
		if p367 or (v_u_11 == "scripted" or (v_u_35 ~= nil or (v_u_36 ~= nil or p366.UserInputType ~= Enum.UserInputType.MouseWheel))) then
			return
		else
			local v368 = v_u_8
			if v368 then
				v368 = v_u_8.controllers.Prompts
			end
			if v368 and (v368.choiceListVisible and v368.choiceListVisible()) then
				return
			else
				local v369 = os.clock()
				if v369 - v_u_32 < 0.12 then
					return
				else
					v_u_32 = v369
					if p366.Position.Z > 0 then
						v_u_6.setZoom(v_u_25 - 1)
					elseif p366.Position.Z < 0 then
						v_u_6.setZoom(v_u_25 + 1)
					end
				end
			end
		end
	end)
	local v371 = v_u_34
	table.insert(v371, function()
		-- upvalues: (copy) v_u_370
		v_u_370:Disconnect()
	end)
	local v_u_377 = v_u_3.TouchPinch:Connect(function(p372, p373, p374, p375, p376)
		-- upvalues: (ref) v_u_6
		v_u_6.onTouchPinch(p372, p373, p374, p375, p376)
	end)
	local v378 = v_u_34
	table.insert(v378, function()
		-- upvalues: (copy) v_u_377
		v_u_377:Disconnect()
	end)
	local v_u_384 = v_u_3.TouchRotate:Connect(function(p379, p380, p381, p382, p383)
		-- upvalues: (ref) v_u_6
		v_u_6.onTouchRotate(p379, p380, p381, p382, p383)
	end)
	local v385 = v_u_34
	table.insert(v385, function()
		-- upvalues: (copy) v_u_384
		v_u_384:Disconnect()
	end)
	v_u_10:GetAttributeChangedSignal("CameraZoomDefault"):Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_11, (ref) v_u_25, (ref) v_u_6
		local v386 = v_u_10:GetAttribute("CameraZoomDefault")
		local v387
		if type(v386) == "number" and v386 == v386 then
			local v388 = v386 + 0.5
			local v389 = math.floor(v388)
			local v390 = #v_u_7
			v387 = math.clamp(v389, 1, v390)
		else
			v387 = nil
		end
		if v387 and (v_u_11 ~= "scripted" and v387 ~= v_u_25) then
			v_u_6.setZoom(v387)
		end
	end)
	local v391 = v_u_8.session
	if v391 and v391.onPlaceChanged then
		v391.onPlaceChanged(function(p392)
			-- upvalues: (ref) v_u_270
			v_u_270(p392)
		end)
	end
	local function v401(p_u_393) -- name: hookCharacter
		-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_8, (ref) v_u_6
		if v_u_11 == "iso" then
			v_u_16 = true
		end
		local v_u_394 = p_u_393:GetAttribute("Hp")
		p_u_393:GetAttributeChangedSignal("Hp"):Connect(function()
			-- upvalues: (copy) p_u_393, (ref) v_u_8, (ref) v_u_394, (ref) v_u_11, (ref) v_u_6
			local v395 = p_u_393:GetAttribute("Hp")
			local v396 = v_u_8
			if v396 then
				v396 = v_u_8.controllers.HUD
			end
			if v396 == nil and type(v395) == "number" then
				local v397 = v_u_394
				if type(v397) == "number" and (v395 < v_u_394 and v_u_11 == "iso") then
					local v398 = v_u_394 - v395
					local v399 = v_u_6.shake
					local v400 = v398 / 40
					v399(math.clamp(v400, 0.12, 0.6), 0.28)
				end
			end
			v_u_394 = v395
		end)
	end
	v_u_10.CharacterAdded:Connect(v401)
	if v_u_10.Character then
		local v_u_402 = v_u_10.Character
		if v_u_11 == "iso" then
			v_u_16 = true
		end
		local v_u_403 = v_u_402:GetAttribute("Hp")
		v_u_402:GetAttributeChangedSignal("Hp"):Connect(function()
			-- upvalues: (copy) v_u_402, (ref) v_u_8, (ref) v_u_403, (ref) v_u_11, (ref) v_u_6
			local v404 = v_u_402:GetAttribute("Hp")
			local v405 = v_u_8
			if v405 then
				v405 = v_u_8.controllers.HUD
			end
			if v405 == nil and type(v404) == "number" then
				local v406 = v_u_403
				if type(v406) == "number" and (v404 < v_u_403 and v_u_11 == "iso") then
					local v407 = v_u_403 - v404
					local v408 = v_u_6.shake
					local v409 = v407 / 40
					v408(math.clamp(v409, 0.12, 0.6), 0.28)
				end
			end
			v_u_403 = v404
		end)
	end
end
function v_u_6.step(p410) -- name: step
	-- upvalues: (ref) v_u_30, (copy) v_u_261
	if os.clock() - v_u_30 > 0.2 then
		v_u_261(p410)
	end
end
return v_u_6