-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuWipeTimer

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_10 = {
	["ATTR"] = "WipeAt",
	["TICK"] = 20,
	["enabled"] = function(p3) -- name: enabled
		-- upvalues: (copy) v_u_1
		if p3 == nil then
			local function v4()
				-- upvalues: (ref) v_u_1
				return require((v_u_1:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
			end
			local v5, v6 = pcall(v4)
			if v5 and type(v6) == "table" then
				local v7 = v6.rule
				if type(v7) == "function" then
					p3 = v6.rule
				else
					p3 = nil
				end
			else
				p3 = nil
			end
		end
		if type(p3) ~= "function" then
			return false
		end
		local v8, v9 = pcall(p3, "pvp")
		if v8 then
			v8 = v9 == true
		end
		return v8
	end
}
local function v_u_18(p_u_11, p_u_12) -- name: sharedMod
	-- upvalues: (copy) v_u_1
	local v13, v14 = pcall(function()
		-- upvalues: (copy) p_u_11, (copy) p_u_12
		return p_u_11.cctx.shared[p_u_12]
	end)
	if v13 and type(v14) == "table" then
		return v14
	else
		local function v15()
			-- upvalues: (ref) v_u_1, (copy) p_u_12
			return require((v_u_1:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild(p_u_12, 5)))
		end
		local v16, v17 = pcall(v15)
		if v16 and type(v17) == "table" then
			return v17
		else
			return nil
		end
	end
end
local function v_u_25(p_u_19, p_u_20) -- name: libMod
	local v21, v22 = pcall(function()
		-- upvalues: (copy) p_u_19, (copy) p_u_20
		return p_u_19.cctx.lib[p_u_20]
	end)
	if v21 and type(v22) == "table" then
		return v22
	else
		local v23, v24 = pcall(function()
			-- upvalues: (copy) p_u_20
			return require((script.Parent:WaitForChild(p_u_20, 5)))
		end)
		if v23 and type(v24) == "table" then
			return v24
		else
			return nil
		end
	end
end
local function v_u_32(p26) -- name: serverNow
	-- upvalues: (copy) v_u_25
	local v27 = v_u_25(p26, "ServerClock")
	if v27 ~= nil then
		local v28 = v27.now
		if type(v28) == "function" then
			local v29 = v27.now
			local v30, v31 = pcall(v29)
			if v30 and type(v31) == "number" then
				return v31
			end
		end
	end
	return os.time()
end
function v_u_10.lineText(p33, p_u_34, p35) -- name: lineText
	-- upvalues: (copy) v_u_10
	local v_u_36 = nil
	if p_u_34 ~= nil then
		local function v37()
			-- upvalues: (ref) v_u_36, (copy) p_u_34, (ref) v_u_10
			v_u_36 = p_u_34:GetAttribute(v_u_10.ATTR)
		end
		pcall(v37)
	end
	local v38 = (type(v_u_36) ~= "number" or v_u_36 <= 0) and 0 or v_u_36
	if v38 <= 0 then
		return nil, false
	else
		local v39 = p33.timerText(p35, v38)
		if v39 == nil then
			return nil, false
		else
			return v39, v38 - p35 <= p33.PERMANENT_SEC
		end
	end
end
function v_u_10.mountLine(p_u_40, p41, p42) -- name: mountLine
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (copy) v_u_2, (copy) v_u_32
	if not v_u_10.enabled() then
		return nil
	end
	local v_u_43 = v_u_18(p_u_40, "StashWipeRules")
	if v_u_43 == nil then
		return nil
	end
	local v44 = type(p42) ~= "table" and {} or p42
	local v45 = p_u_40.ui
	local v_u_46 = p_u_40.theme.color
	local v_u_47 = v_u_2.LocalPlayer
	local v_u_48 = v45.label({
		["parent"] = nil,
		["name"] = "WipeTimer",
		["text"] = "",
		["style"] = nil,
		["color"] = nil,
		["size"] = nil,
		["wrap"] = false,
		["parent"] = p41,
		["style"] = v44.compact and "small" or "caps",
		["color"] = v_u_46.accent,
		["size"] = v44.size or UDim2.new(1, 0, 0, 20)
	})
	if v44.order then
		v_u_48.LayoutOrder = v44.order
	end
	v_u_48.Visible = false
	local v_u_49 = true
	local v_u_54 = {
		["label"] = v_u_48,
		["refresh"] = function() -- name: refresh
			-- upvalues: (ref) v_u_49, (copy) v_u_48, (ref) v_u_10, (copy) v_u_43, (copy) v_u_47, (ref) v_u_32, (copy) p_u_40, (copy) v_u_46
			if v_u_49 and v_u_48.Parent ~= nil then
				local v50, v51 = v_u_10.lineText(v_u_43, v_u_47, v_u_32(p_u_40))
				v_u_48.Visible = v50 ~= nil
				if v50 ~= nil then
					v_u_48.Text = v50
					local v52 = v_u_48
					local v53
					if v51 then
						v53 = v_u_46.danger
					else
						v53 = v_u_46.accent
					end
					v52.TextColor3 = v53
				end
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (ref) v_u_49, (copy) v_u_48
			v_u_49 = false
			if v_u_48.Parent then
				v_u_48:Destroy()
			end
		end
	}
	v_u_54.refresh()
	task.spawn(function()
		-- upvalues: (ref) v_u_49, (copy) v_u_48, (ref) v_u_10, (copy) v_u_54
		while v_u_49 and v_u_48.Parent do
			task.wait(v_u_10.TICK)
			v_u_54.refresh()
		end
	end)
	return v_u_54
end
local v_u_98 = false
function v_u_10.check(p_u_56) -- name: check
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (copy) v_u_2, (copy) v_u_25, (ref) v_u_98
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v79, v80, v81, v82, v83, v84, v85, v86, v87, v_u_88, v_u_89, v90, v91, v92, v93, v94, v95, v96, v_u_97, v99, v100, v101
	local v79, v80, v81, v82, v83, v84, v85, v86, v87, v_u_88, v_u_89, v90, v91, v92, v93, v94, v95, v96, v_u_97, v_u_98, v99, v100, v101
	local v102 = 16
	while true do
		if v102 == 1 then
			v100 = p_u_56.profile
			if type(v100) ~= "table" then
				return nil
			end
			v101 = v87.noticeFor
			v79 = v_u_25(p_u_56, "ServerClock")
			if v79 == nil then
				v102 = 11
			else
				v102 = 13
			end
		elseif v102 == 2 then
			v100 = p_u_56.profile
			if type(v100) ~= "table" then
				return nil
			end
			v101 = v87.noticeFor
			v79 = v_u_25(p_u_56, "ServerClock")
			if v79 == nil then
				v102 = 12
			else
				v102 = 13
			end
		elseif v102 == 3 then
			v100 = p_u_56.profile
			if type(v100) ~= "table" then
				return nil
			end
			v101 = v87.noticeFor
			v79 = v_u_25(p_u_56, "ServerClock")
			if v79 == nil then
				v102 = 4
			else
				v102 = 13
			end
		elseif v102 == 4 then
			v80 = os.time()
			v102 = 15
		elseif v102 == 5 then
			v80 = os.time()
			v102 = 15
		elseif v102 == 6 then
			v81 = v92.has
			if type(v81) == "function" then
				v102 = 8
			else
				v102 = 2
			end
		elseif v102 == 7 then
			v100 = p_u_56.profile
			if type(v100) ~= "table" then
				return nil
			end
			v101 = v87.noticeFor
			v79 = v_u_25(p_u_56, "ServerClock")
			if v79 == nil then
				v102 = 14
			else
				v102 = 13
			end
		elseif v102 == 8 then
			v82 = p_u_56.profile
			if type(v82) == "table" then
				v102 = 9
			else
				v102 = 1
			end
		elseif v102 == 9 then
			v83 = p_u_56.profile.settings
			if type(v83) == "table" then
				v102 = 10
			else
				v102 = 3
			end
		elseif v102 == 10 then
			for _, v103 in v87.STAGES do
				v84 = v87.stageId(v103)
				if not v92.has(p_u_56.profile.settings[v92.KEY], v84) then
					continue
				end
				v93[v84] = true
			end
			v101 = v87.noticeFor
			v79 = v_u_25(p_u_56, "ServerClock")
			if v79 == nil then
				v102 = 5
			else
				v102 = 13
			end
		elseif v102 == 11 then
			v80 = os.time()
			v102 = 15
		elseif v102 == 12 then
			v80 = os.time()
			v102 = 15
		elseif v102 == 13 then
			v94 = v79.now
			if type(v94) == "function" then
				v95 = v79.now
				v96, v80 = pcall(v95)
				if not v96 or type(v80) ~= "number" then
					v80 = os.time()
				end
			else
				v80 = os.time()
			end
			v102 = 15
		elseif v102 == 14 then
			v80 = os.time()
			v102 = 15
		elseif v102 == 15 then
			v_u_97 = v101(v80, v91, v93)
			if v_u_97 == nil then
				return nil
			end
			if not v_u_97.first and v_u_98 then
				return nil
			end
			if not v_u_97.first then
				v_u_98 = true
			end
			pcall(function()
				-- upvalues: (copy) p_u_56, (copy) v_u_97
				p_u_56.ui.toast("Stash wipe is coming", v_u_97.stage <= 3 and "danger" or "warn", v_u_97.text, 9)
			end)
			if v_u_97.first and v92 ~= nil then
				v99 = v92.markSeen
				if type(v99) == "function" then
					v85 = v92.markSeen
					v86 = v_u_97.id
					pcall(v85, p_u_56, v86)
				end
			end
			return v_u_97
		else
			if not v_u_10.enabled() then
				return nil
			end
			v87 = v_u_18(p_u_56, "StashWipeRules")
			v_u_88 = v_u_2.LocalPlayer
			if v87 == nil or v_u_88 == nil then
				return nil
			end
			v_u_89 = nil
			if v_u_88 ~= nil then
				v90 = function()
					-- upvalues: (ref) v_u_89, (copy) v_u_88, (ref) v_u_10
					v_u_89 = v_u_88:GetAttribute(v_u_10.ATTR)
				end
				pcall(v90)
			end
			v91 = (type(v_u_89) ~= "number" or v_u_89 <= 0) and 0 or v_u_89
			if v91 <= 0 then
				return nil
			end
			v92 = v_u_25(p_u_56, "MenuTipOnce")
			v93 = {}
			if v92 == nil then
				v102 = 7
			else
				v102 = 6
			end
		end
	end
end
return v_u_10