-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MailGuide

local v_u_1 = game:GetService("GuiService")
local v_u_2 = {
	["TEXT"] = {
		["title"] = "Your purchase is in your mail",
		["lines"] = "Open your mail and press TO STASH to move it into your stash. Your stash can be full, the item waits for you.",
		["bm"] = "Blackmarket deliveries expire after {days} days.",
		["open"] = "Open mail",
		["hide"] = "Don\'t show this again",
		["later"] = "Later",
		["waiting"] = " is waiting in your mail",
		["sub"] = "Waiting in your mail",
		["cargoTitle"] = "Your cargo is in your mail",
		["cargoLines"] = "Your pilot sent your loot to your mail. Open your mail and press TO STASH to move it into your stash. It waits 7 days, then it is gone.",
		["cargoSub"] = "Cargo package, waiting 7 days"
	},
	["KEYS"] = {
		["store"] = "mailStore",
		["bm"] = "mailBm",
		["lift"] = "mailLift"
	},
	["POPOFF"] = "mailPopOff"
}
local v_u_3 = game:GetService("Players").LocalPlayer
local v_u_4 = {
	["conn"] = nil,
	["mc"] = nil,
	["shown"] = nil,
	["queued"] = nil,
	["last"] = nil,
	["open"] = nil,
	["pumping"] = false,
	["sent"] = nil,
	["noteOff"] = nil,
	["heldSeq"] = nil,
	["lastMailMsg"] = nil,
	["heldWait"] = nil,
	["shown"] = {},
	["queued"] = {},
	["last"] = {},
	["sent"] = {}
}
local v_u_5 = nil
local function v_u_12(p6) -- name: cleanTitle
	if type(p6) ~= "string" then
		return ""
	end
	local v7 = string.gsub(p6, "[%c]", " ")
	local v8 = string.gsub(v7, "^%s+", "")
	local v9 = string.gsub(v8, "%s+$", "")
	if utf8.len(v9) == nil or utf8.len(v9) <= 60 then
		if #v9 > 240 then
			v9 = string.sub(v9, 1, 60)
		end
	else
		local v10 = utf8.offset(v9, 61)
		if v10 then
			local v11 = v10 - 1
			return string.sub(v9, 1, v11)
		end
	end
	return v9
end
function v_u_2.read(p13) -- name: read
	-- upvalues: (copy) v_u_12, (copy) v_u_2
	if type(p13) ~= "table" or p13.ok ~= true then
		return nil
	end
	local v14 = p13.data
	local v15
	if type(v14) == "table" then
		v15 = v14.toMail
	else
		v15 = nil
	end
	if v15 == nil then
		v15 = p13.toMail
	end
	if v15 ~= true then
		return nil
	end
	local v16 = p13.op or ""
	local v17 = tostring(v16)
	local v18
	if type(v14) == "table" then
		v18 = v14.mailSrc
	else
		v18 = nil
	end
	if v18 == nil then
		v18 = p13.mailSrc
	end
	if v18 ~= "store" and v18 ~= "bm" then
		if v17 == "storeGrant" or v17 == "storeBuy" then
			v18 = "store"
		else
			if v17 ~= "bmBuy" and v17 ~= "bmBuyBest" then
				return nil
			end
			v18 = "bm"
		end
	end
	local v19 = v_u_12
	local v20
	if type(v14) == "table" then
		v20 = v14.mailTitle
	else
		v20 = nil
	end
	if v20 == nil then
		v20 = p13.mailTitle
	end
	local v21 = v19(v20)
	local v22 = v21 == "" and "Your purchase" or v21
	local v23 = {
		["src"] = v18,
		["key"] = v_u_2.KEYS[v18],
		["title"] = v22
	}
	local v24
	if type(v14) == "table" then
		v24 = v14.mailFirst
	else
		v24 = nil
	end
	if v24 == nil then
		v24 = p13.mailFirst
	end
	v23.first = v24 == true
	v23.op = v17
	v23.req = p13.req
	local v25 = p13.msg
	local v26
	if type(v25) == "string" then
		v26 = p13.msg ~= ""
	else
		v26 = false
	end
	v23.hasMsg = v26
	return v23
end
function v_u_2.shouldGuide(p27, p28, p29, p30) -- name: shouldGuide
	-- upvalues: (copy) v_u_2
	local v31 = v_u_2.read(p27)
	if not v31 then
		return "none"
	end
	local v32
	if type(p28) == "table" then
		v32 = p28[v31.key] == true
	else
		v32 = false
	end
	return (v32 or v31.first ~= true) and ((type(p28) == "table" and p28[v_u_2.POPOFF] == true or p29) and "toast" or (p30 and "queuepop" or "popup")) or (p29 and "none" or (p30 and "queue" or "guide"))
end
function v_u_2.toastText(p33) -- name: toastText
	-- upvalues: (copy) v_u_2
	return p33 .. v_u_2.TEXT.waiting
end
local v_u_34 = nil
local function v_u_47(p_u_35) -- name: tipsNow
	-- upvalues: (copy) v_u_4
	local v36, v37 = pcall(function()
		-- upvalues: (copy) p_u_35
		return p_u_35.cctx.lib.MenuRail
	end)
	if not v36 or type(v37) ~= "table" then
		v37 = nil
	end
	local v38 = {}
	if v37 then
		local v39 = v37.tips
		if type(v39) == "function" then
			local v40 = v37.tips
			local v41, v42 = pcall(v40)
			if v41 and type(v42) == "table" then
				for v43, v44 in v42 do
					v38[v43] = v44
				end
			end
		end
	end
	for v45, v46 in v_u_4.shown do
		if not v46 then
			continue
		end
		v38[v45] = true
	end
	return v38
end
local function v_u_55(p_u_48) -- name: openMail
	local v49, v50 = pcall(function()
		-- upvalues: (copy) p_u_48
		return p_u_48.cctx.lib.MenuMail
	end)
	if v49 and type(v50) == "table" then
		local v51 = v50.open
		if type(v51) == "function" then
			local v52 = v50.open
			local v53, v54 = pcall(v52, p_u_48, nil, {
				["view"] = "deliveries"
			})
			if not v53 then
				warn("[MailGuide] could not open the mail window:", v54)
			end
		end
	end
end
local function v_u_94(p_u_56, p_u_57, p_u_58) -- name: showGuide
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_2, (copy) v_u_55
	local v_u_59 = p_u_56.ui
	local v_u_60 = p_u_56.theme.color
	if v_u_4.open then
		return false
	else
		local v61, v_u_62 = pcall(function()
			-- upvalues: (copy) p_u_56
			return p_u_56.cctx.lib.MenuRail
		end)
		if not v61 or type(v_u_62) ~= "table" then
			v_u_62 = nil
		end
		local v_u_63
		if v_u_59.device() == "Gamepad" then
			v_u_63 = v_u_1.SelectedObject
		else
			v_u_63 = nil
		end
		local v_u_64 = false
		local v_u_65 = false
		local function v_u_68() -- name: sendHide
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (copy) p_u_58, (copy) p_u_56
			v_u_4.sent[v_u_2.POPOFF] = (v_u_4.sent[v_u_2.POPOFF] or 0) + 1
			if not p_u_58 then
				v_u_4.shown[v_u_2.POPOFF] = true
				local v66 = p_u_56.op
				local v67 = {
					["op"] = "mailTip",
					["key"] = nil,
					["key"] = v_u_2.POPOFF
				}
				pcall(v66, v67)
			end
		end
		local function v_u_71() -- name: sendTip
			-- upvalues: (copy) p_u_57, (ref) v_u_64, (ref) v_u_4, (copy) p_u_58, (copy) p_u_56
			if p_u_57.popup == true then
				return
			elseif not v_u_64 then
				v_u_64 = true
				v_u_4.sent[p_u_57.key] = (v_u_4.sent[p_u_57.key] or 0) + 1
				if not p_u_58 then
					local v69 = p_u_56.op
					local v70 = {
						["op"] = "mailTip",
						["key"] = nil,
						["key"] = p_u_57.key
					}
					pcall(v69, v70)
				end
			end
		end
		local v_u_72 = 14
		if v_u_62 then
			local v73 = v_u_62.bmDays
			if type(v73) == "function" then
				local v74 = v_u_62.bmDays
				local v75, v76 = pcall(v74)
				if v75 and (type(v76) == "number" and v76 >= 1) then
					v_u_72 = math.floor(v76)
				end
			end
		end
		local v_u_77 = nil
		local function v78()
			-- upvalues: (ref) v_u_77
			v_u_77 = require((script.Parent:WaitForChild("MailRows", 5)))
		end
		pcall(v78)
		local v_u_79 = nil
		local function v91()
			-- upvalues: (ref) v_u_79, (copy) v_u_59, (copy) p_u_57, (ref) v_u_2, (copy) v_u_60, (copy) v_u_62, (ref) v_u_77, (ref) v_u_65, (ref) v_u_72, (ref) v_u_55, (copy) p_u_56, (ref) v_u_4, (copy) v_u_71, (copy) v_u_68, (ref) v_u_63, (ref) v_u_1
			v_u_79 = v_u_59.modal({
				["title"] = nil,
				["body"] = nil,
				["width"] = 460,
				["build"] = nil,
				["buttons"] = nil,
				["onClose"] = nil,
				["title"] = p_u_57.heading or v_u_2.TEXT.title,
				["body"] = p_u_57.lines or v_u_2.TEXT.lines,
				["build"] = function(p80) -- name: build
					-- upvalues: (ref) v_u_59, (ref) v_u_60, (ref) v_u_62, (ref) p_u_57, (ref) v_u_77, (ref) v_u_2, (ref) v_u_65, (ref) v_u_72
					local v81 = v_u_59.new("Frame", {
						["Name"] = "Purchase",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = 1,
						["BackgroundColor3"] = v_u_60.raised,
						["Size"] = UDim2.new(1, 0, 0, 64)
					}, p80)
					v_u_59.stroke(v81, v_u_60.line)
					v_u_59.new("Frame", {
						["Name"] = "Edge",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["ZIndex"] = 3,
						["BackgroundColor3"] = v_u_60.accent,
						["Size"] = UDim2.new(0, 3, 1, 0)
					}, v81)
					if v_u_62 then
						local v82 = v_u_62.glyph
						if type(v82) == "function" then
							v_u_62.glyph("mail", v81, 30, v_u_60.accent).Position = UDim2.fromOffset(18, 17)
						end
					end
					v_u_59.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["textSize"] = 16,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v81,
						["text"] = p_u_57.title,
						["position"] = UDim2.fromOffset(64, 10),
						["size"] = UDim2.new(1, -78, 0, 22)
					}).TextTruncate = Enum.TextTruncate.AtEnd
					local v83
					if v_u_77 then
						v83 = v_u_77.chipText(p_u_57.src)
					else
						v83 = string.upper(p_u_57.src)
					end
					v_u_59.label({
						["parent"] = nil,
						["name"] = "Where",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v81,
						["text"] = v83 .. "  \194\183  " .. (p_u_57.sub or v_u_2.TEXT.sub),
						["color"] = v_u_60.text2,
						["position"] = UDim2.fromOffset(64, 34),
						["size"] = UDim2.new(1, -78, 0, 18)
					})
					if p_u_57.popup == true then
						local v84 = v_u_59.toggle
						if type(v84) == "function" then
							local v86 = v_u_59.toggle({
								["name"] = "HideNext",
								["label"] = nil,
								["width"] = 340,
								["value"] = false,
								["onChange"] = nil,
								["label"] = v_u_2.TEXT.hide,
								["onChange"] = function(p85) -- name: onChange
									-- upvalues: (ref) v_u_65
									v_u_65 = p85 == true
								end
							})
							v86.LayoutOrder = 3
							v86.Parent = p80
						end
					end
					if p_u_57.src == "bm" then
						local v87 = v_u_59.label
						local v88 = {
							["parent"] = nil,
							["name"] = "Expiry",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["order"] = 2,
							["parent"] = p80
						}
						local v89 = v_u_72
						v88.text = v_u_2.TEXT.bm:gsub("{days}", (tostring(v89)))
						v88.color = v_u_60.text2
						v87(v88)
					end
				end,
				["buttons"] = {
					{
						["text"] = nil,
						["kind"] = "secondary",
						["text"] = v_u_2.TEXT.later
					},
					{
						["text"] = nil,
						["kind"] = "primary",
						["onClick"] = nil,
						["text"] = v_u_2.TEXT.open,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_55, (ref) p_u_56
							task.defer(v_u_55, p_u_56)
						end
					}
				},
				["onClose"] = function() -- name: onClose
					-- upvalues: (ref) v_u_4, (ref) v_u_71, (ref) p_u_57, (ref) v_u_65, (ref) v_u_68, (ref) v_u_63, (ref) v_u_59, (ref) v_u_1
					v_u_4.open = nil
					v_u_71()
					if p_u_57.popup == true and v_u_65 then
						v_u_68()
					end
					local v_u_90 = v_u_63
					if v_u_90 and v_u_59.device() == "Gamepad" then
						task.delay(0.2, function()
							-- upvalues: (copy) v_u_90, (ref) v_u_59, (ref) v_u_1
							if v_u_90.Parent and (v_u_90.Visible and v_u_59.modalCount() == 0) then
								v_u_1.SelectedObject = v_u_90
							end
						end)
					end
				end
			})
		end
		local v92, v93 = pcall(v91)
		if v92 then
			v_u_4.open = v_u_79
			return true
		else
			warn("[MailGuide] guide failed:", v93)
			return false
		end
	end
end
function v_u_2.onResult(p_u_95, p96, p97) -- name: onResult
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_47, (ref) v_u_34, (copy) v_u_3, (copy) v_u_94
	local v_u_98 = p97 or {}
	local v99 = v_u_2.read(p96)
	if not v99 then
		return "none"
	end
	local v100 = os.clock()
	if v_u_98.fake ~= true then
		local v101 = v99.op
		local v102 = v99.req or ""
		local v103 = ("%s/%s/%s"):format(v101, tostring(v102), v99.title)
		local v104 = v_u_4.last[v103]
		if v104 and v100 - v104 < 3 then
			return "dup"
		end
		v_u_4.last[v103] = v100
		for v105, v106 in v_u_4.last do
			if v100 - v106 <= 30 then
				continue
			end
			v_u_4.last[v105] = nil
		end
	end
	local v107, v108 = pcall(function()
		-- upvalues: (copy) p_u_95
		return p_u_95.cctx.lib.MenuRail
	end)
	if not v107 or type(v108) ~= "table" then
		v108 = nil
	end
	if v108 then
		local v109 = v108.flagDelivery
		if type(v109) == "function" then
			local v110 = v108.flagDelivery
			pcall(v110, p_u_95)
		end
	end
	local v_u_111 = v_u_98.fake == true and {} or v_u_47(p_u_95)
	local function v112()
		-- upvalues: (copy) v_u_98, (copy) p_u_95, (copy) v_u_111, (ref) v_u_2
		if v_u_98.fake ~= true and p_u_95.cctx.config.flag("MailPopup") == false then
			v_u_111[v_u_2.POPOFF] = true
		end
	end
	pcall(v112)
	local v113
	if v_u_34 then
		v113 = v_u_34()
	elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
		v113 = v_u_3:GetAttribute("LoadingVisible") ~= true
	else
		v113 = false
	end
	local v114 = v_u_2.shouldGuide(p96, v_u_111, not v113, p_u_95.ui.modalCount() > 0 and true or v_u_4.open ~= nil)
	if v114 == "popup" or v114 == "queuepop" then
		v114 = (v_u_4.open ~= nil or v_u_4.queued.pop ~= nil) and "toast" or v114
	end
	if v114 == "guide" then
		if v_u_98.fake ~= true then
			v_u_4.shown[v99.key] = true
		end
		if not v_u_94(p_u_95, v99, v_u_98.fake == true) then
			v_u_4.shown[v99.key] = nil
			return "none"
		end
		return v114
	end
	if v114 == "queue" then
		if v_u_98.fake ~= true then
			v_u_4.shown[v99.key] = true
		end
		v99.fake = v_u_98.fake == true
		v_u_4.queued[v99.key] = v99
		if v_u_4.pumping then
			return v114
		end
		v_u_4.pumping = true
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_95, (ref) v_u_34, (ref) v_u_3, (ref) v_u_94
			local v115 = os.clock()
			while next(v_u_4.queued) ~= nil and os.clock() - v115 < 600 do
				task.wait(0.5)
				if v_u_4.open ~= nil or p_u_95.ui.modalCount() ~= 0 then
					continue
				end
				local v116
				if v_u_34 then
					v116 = v_u_34()
				elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
					v116 = v_u_3:GetAttribute("LoadingVisible") ~= true
				else
					v116 = false
				end
				if not v116 then
					continue
				end
				local v117, v118 = next(v_u_4.queued)
				v_u_4.queued[v117] = nil
				if v_u_94(p_u_95, v118, v118.fake == true) then
					continue
				end
				v_u_4.shown[v117] = nil
			end
			for v119 in v_u_4.queued do
				v_u_4.shown[v119] = nil
			end
			table.clear(v_u_4.queued)
			v_u_4.pumping = false
		end)
		return v114
	end
	if v114 ~= "popup" then
		if v114 == "queuepop" then
			v99.popup = true
			v99.fake = v_u_98.fake == true
			v_u_4.queued.pop = v99
			if v_u_4.pumping then
				return v114
			end
			v_u_4.pumping = true
			task.spawn(function()
				-- upvalues: (ref) v_u_4, (copy) p_u_95, (ref) v_u_34, (ref) v_u_3, (ref) v_u_94
				local v120 = os.clock()
				while next(v_u_4.queued) ~= nil and os.clock() - v120 < 600 do
					task.wait(0.5)
					if v_u_4.open ~= nil or p_u_95.ui.modalCount() ~= 0 then
						continue
					end
					local v121
					if v_u_34 then
						v121 = v_u_34()
					elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
						v121 = v_u_3:GetAttribute("LoadingVisible") ~= true
					else
						v121 = false
					end
					if not v121 then
						continue
					end
					local v122, v123 = next(v_u_4.queued)
					v_u_4.queued[v122] = nil
					if v_u_94(p_u_95, v123, v123.fake == true) then
						continue
					end
					v_u_4.shown[v122] = nil
				end
				for v124 in v_u_4.queued do
					v_u_4.shown[v124] = nil
				end
				table.clear(v_u_4.queued)
				v_u_4.pumping = false
			end)
			return v114
		end
		if v114 ~= "toast" then
			return v114
		end
		local v125, v126
		if v99.hasMsg then
			local v127
			if v_u_34 then
				v127 = v_u_34()
			elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
				v127 = v_u_3:GetAttribute("LoadingVisible") ~= true
			else
				v127 = false
			end
			if v127 and v_u_98.fake ~= true then
				return v114
			end
			v125 = p_u_95.ui.toast
			v126 = v_u_2.toastText(v99.title)
			pcall(v125, v126, "success")
		else
			v125 = p_u_95.ui.toast
			v126 = v_u_2.toastText(v99.title)
			pcall(v125, v126, "success")
		end
		return v114
	end
	v99.popup = true
	if v_u_94(p_u_95, v99, v_u_98.fake == true) then
		return v114
	end
	v114 = "toast"
	if not v99.hasMsg then
		v129 = p_u_95.ui.toast
		v130 = v_u_2.toastText(v99.title)
		pcall(v129, v130, "success")
		return v114
	end
	local v128
	if v_u_34 then
		v128 = v_u_34()
	elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
		v128 = v_u_3:GetAttribute("LoadingVisible") ~= true
	else
		v128 = false
	end
	if v128 and v_u_98.fake ~= true then
		return v114
	end
	local v129 = p_u_95.ui.toast
	local v130 = v_u_2.toastText(v99.title)
	pcall(v129, v130, "success")
	return v114
end
function v_u_2.cargoInfo(p131) -- name: cargoInfo
	-- upvalues: (copy) v_u_12, (copy) v_u_2
	local v132
	if type(p131) == "table" then
		v132 = p131.cargo
	else
		v132 = nil
	end
	if type(v132) == "table" then
		local v133 = v132.id
		if type(v133) == "string" and v132.id ~= "" then
			local v134 = v132.expLeft
			if type(v134) == "number" and v132.expLeft <= 0 then
				return nil
			end
			local v135 = v_u_12(v132.title)
			return {
				["src"] = "lift",
				["key"] = nil,
				["title"] = nil,
				["first"] = true,
				["op"] = "cargo",
				["heading"] = nil,
				["lines"] = nil,
				["sub"] = nil,
				["key"] = v_u_2.KEYS.lift,
				["title"] = v135 == "" and "Cargo package" or v135,
				["heading"] = v_u_2.TEXT.cargoTitle,
				["lines"] = v_u_2.TEXT.cargoLines,
				["sub"] = v_u_2.TEXT.cargoSub
			}
		end
	end
	return nil
end
function v_u_2.shouldGuideCargo(p136, p137, p138, p139) -- name: shouldGuideCargo
	-- upvalues: (copy) v_u_2
	if not v_u_2.cargoInfo(p136) then
		return "none"
	end
	local v140
	if type(p137) == "table" and p137.mailLift == true then
		v140 = true
	elseif type(p136) == "table" then
		local v141 = p136.tips
		if type(v141) == "table" then
			v140 = p136.tips.mailLift == true
		else
			v140 = false
		end
	else
		v140 = false
	end
	return v140 and "none" or (p138 and "none" or (p139 and "queue" or "guide"))
end
function v_u_2.onMailData(p_u_142, p143, p144) -- name: onMailData
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_47, (ref) v_u_34, (copy) v_u_3, (copy) v_u_94
	local v145 = p144 or {}
	local v146 = v_u_2.cargoInfo(p143)
	if not v146 then
		return "none"
	end
	if v145.fake ~= true and (v_u_4.shown[v146.key] or v_u_4.queued[v146.key]) then
		return "none"
	end
	local v147 = v145.fake == true and {} or v_u_47(p_u_142)
	if v145.fake == true and type(p143) == "table" then
		local v148 = p143.tips
		if type(v148) == "table" then
			p143 = table.clone(p143)
			p143.tips = nil
		end
	end
	local v149 = v_u_2.shouldGuideCargo
	local v150
	if v_u_34 then
		v150 = v_u_34()
	elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
		v150 = v_u_3:GetAttribute("LoadingVisible") ~= true
	else
		v150 = false
	end
	local v151 = v149(p143, v147, not v150, p_u_142.ui.modalCount() > 0 and true or v_u_4.open ~= nil)
	if v151 == "guide" then
		if v145.fake ~= true then
			v_u_4.shown[v146.key] = true
		end
		if not v_u_94(p_u_142, v146, v145.fake == true) then
			v_u_4.shown[v146.key] = nil
			return "none"
		end
	elseif v151 == "queue" then
		if v145.fake ~= true then
			v_u_4.shown[v146.key] = true
		end
		v146.fake = v145.fake == true
		v_u_4.queued[v146.key] = v146
		if v_u_4.pumping then
			return v151
		end
		v_u_4.pumping = true
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_142, (ref) v_u_34, (ref) v_u_3, (ref) v_u_94
			local v152 = os.clock()
			while next(v_u_4.queued) ~= nil and os.clock() - v152 < 600 do
				task.wait(0.5)
				if v_u_4.open ~= nil or p_u_142.ui.modalCount() ~= 0 then
					continue
				end
				local v153
				if v_u_34 then
					v153 = v_u_34()
				elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
					v153 = v_u_3:GetAttribute("LoadingVisible") ~= true
				else
					v153 = false
				end
				if not v153 then
					continue
				end
				local v154, v155 = next(v_u_4.queued)
				v_u_4.queued[v154] = nil
				if v_u_94(p_u_142, v155, v155.fake == true) then
					continue
				end
				v_u_4.shown[v154] = nil
			end
			for v156 in v_u_4.queued do
				v_u_4.shown[v156] = nil
			end
			table.clear(v_u_4.queued)
			v_u_4.pumping = false
		end)
	end
	return v151
end
function v_u_2.onNote(p_u_157, p_u_158) -- name: onNote
	-- upvalues: (ref) v_u_34, (copy) v_u_3, (copy) v_u_2, (copy) v_u_47, (copy) v_u_4
	if type(p_u_158) ~= "table" or p_u_158.k ~= "orderFilled" and p_u_158.k ~= "orderFilledMail" then
		return "none"
	end
	local v159
	if v_u_34 then
		v159 = v_u_34()
	elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
		v159 = v_u_3:GetAttribute("LoadingVisible") ~= true
	else
		v159 = false
	end
	if not v159 then
		return "none"
	end
	local v160 = p_u_158.id
	local v_u_161 = type(v160) ~= "string" and "Your order" or p_u_158.id
	local function v164()
		-- upvalues: (copy) p_u_157, (copy) p_u_158, (ref) v_u_161
		local v162 = p_u_157.cctx.shared.Items.get(p_u_158.id)
		if type(v162) == "table" then
			local v163 = v162.name
			if type(v163) == "string" then
				v_u_161 = v162.name
			end
		end
	end
	pcall(v164)
	local v165 = p_u_158.n
	if type(v165) == "number" and (p_u_158.n > 1 and p_u_158.id ~= nil) then
		local v166 = p_u_158.n
		v_u_161 = ("%d x %s"):format(math.floor(v166), v_u_161)
	end
	local v167 = {
		["op"] = "bmOrderFill",
		["ok"] = true,
		["req"] = nil,
		["data"] = nil,
		["req"] = p_u_158.ref,
		["data"] = {
			["toMail"] = true,
			["mailSrc"] = "bm",
			["mailTitle"] = nil,
			["mailFirst"] = false,
			["mailTitle"] = v_u_161
		}
	}
	local v168 = v_u_2.shouldGuide(v167, v_u_47(p_u_157), false, p_u_157.ui.modalCount() > 0 and true or v_u_4.open ~= nil)
	return v168 ~= "popup" and v168 ~= "queuepop" and "none" or v_u_2.onResult(p_u_157, v167)
end
function v_u_2.heldAction(p169, p170, p171, p172, p173) -- name: heldAction
	-- upvalues: (ref) v_u_5
	if v_u_5 == nil then
		local v175, v176 = pcall(function()
			local v174 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
			return require(v174:FindFirstChild("OverflowMailRules") or v174:WaitForChild("OverflowMailRules", 2))
		end)
		if not v175 or type(v176) ~= "table" then
			v176 = false
		end
		v_u_5 = v176
	end
	local v177 = v_u_5 or nil
	return v177 == nil and "none" or v177.heldAction(p169, p170, p171, p172, p173)
end
function v_u_2.onHeld(p_u_178, p179, p180) -- name: onHeld
	-- upvalues: (ref) v_u_34, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (ref) v_u_5
	local v_u_181
	if type(p179) == "table" then
		v_u_181 = p179.mailHeld
	else
		v_u_181 = nil
	end
	if type(v_u_181) ~= "table" then
		return "none"
	end
	local v182 = p180 or {}
	local v183
	if v182.ready == nil then
		if v_u_34 then
			v183 = v_u_34()
		elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
			v183 = v_u_3:GetAttribute("LoadingVisible") ~= true
		else
			v183 = false
		end
	else
		v183 = v182.ready == true
	end
	local v184 = v_u_2.heldAction
	local v185 = v_u_4.heldSeq
	local v186 = v_u_4.lastMailMsg
	local v187
	if v182.clock == nil then
		v187 = os.clock()
	else
		v187 = v182.clock
	end
	local v188 = v184(v_u_181, v185, v186, v187, not v183)
	if v188 == "none" then
		return v188
	end
	local v189 = v_u_4
	local v190 = v_u_181.seq
	v189.heldSeq = tonumber(v190)
	local v191 = v_u_181.moved
	if (tonumber(v191) or 0) > 0 then
		local v192, v193 = pcall(function()
			-- upvalues: (copy) p_u_178
			return p_u_178.cctx.lib.MenuRail
		end)
		if not v192 or type(v193) ~= "table" then
			v193 = nil
		end
		if v193 then
			local v194 = v193.flagDelivery
			if type(v194) == "function" then
				local v195 = v193.flagDelivery
				pcall(v195, p_u_178)
			end
		end
	end
	if v188 ~= "toast" then
		if v183 or v182.noWait == true then
			return v188
		end
		v_u_4.heldWait = v_u_181
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_181, (ref) v_u_34, (ref) v_u_3, (copy) p_u_178, (ref) v_u_5
			local v196 = os.clock()
			if v_u_4.heldWait == v_u_181 and os.clock() - v196 < 120 then
				task.wait(0.5)
				if v_u_4.heldWait ~= v_u_181 then
					continue
				end
				local v197
				if v_u_34 then
					v197 = v_u_34()
				elseif v_u_3 and (v_u_3:GetAttribute("MenuOpen") == true and (v_u_3:GetAttribute("Place") or "Menu") == "Menu") then
					v197 = v_u_3:GetAttribute("LoadingVisible") ~= true
				else
					v197 = false
				end
				if not v197 or v_u_4.open ~= nil then
					continue
				end
				v_u_4.heldWait = nil
				local v198 = p_u_178
				local v199 = v_u_181
				if v_u_5 == nil then
					local v201, v202 = pcall(function()
						local v200 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
						return require(v200:FindFirstChild("OverflowMailRules") or v200:WaitForChild("OverflowMailRules", 2))
					end)
					if not v201 or type(v202) ~= "table" then
						v202 = false
					end
					v_u_5 = v202
				end
				local v203 = v_u_5 or nil
				local v204 = not v203 and "" or v203.noteText(v199)
				if v204 ~= "" then
					local v205 = v198.ui.toast
					pcall(v205, v204, "warn")
				end
			elseif v_u_4.heldWait == v_u_181 then
				v_u_4.heldWait = nil
			end
		end)
		return "wait"
	end
	if v_u_5 == nil then
		local v207, v208 = pcall(function()
			local v206 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
			return require(v206:FindFirstChild("OverflowMailRules") or v206:WaitForChild("OverflowMailRules", 2))
		end)
		if not v207 or type(v208) ~= "table" then
			v208 = false
		end
		v_u_5 = v208
	end
	local v209 = v_u_5 or nil
	local v210 = not v209 and "" or v209.noteText(v_u_181)
	if v210 ~= "" then
		local v211 = p_u_178.ui.toast
		pcall(v211, v210, "warn")
	end
	return "toast"
end
function v_u_2.attach(p_u_212) -- name: attach
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (copy) v_u_2
	if v_u_4.conn and v_u_4.mc == p_u_212 then
		return
	else
		if v_u_4.conn then
			v_u_4.conn:Disconnect()
			v_u_4.conn = nil
		end
		v_u_4.mc = p_u_212
		if type(p_u_212) == "table" and p_u_212.changed ~= nil then
			v_u_4.conn = p_u_212.changed:Connect(function(p213, p_u_214)
				-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (copy) p_u_212
				if p213 == "result" then
					local function v220()
						-- upvalues: (ref) v_u_5, (copy) p_u_214, (ref) v_u_4
						if v_u_5 == nil then
							local v216, v217 = pcall(function()
								local v215 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
								return require(v215:FindFirstChild("OverflowMailRules") or v215:WaitForChild("OverflowMailRules", 2))
							end)
							if not v216 or type(v217) ~= "table" then
								v217 = false
							end
							v_u_5 = v217
						end
						local v218 = v_u_5 or nil
						if v218 then
							local v219 = p_u_214
							if type(v219) == "table" and v218.saysMail(p_u_214.msg) then
								v_u_4.lastMailMsg = os.clock()
							end
						end
					end
					pcall(v220)
					local v221 = v_u_2.onResult
					local v222 = p_u_212
					local v223, v224 = pcall(v221, v222, p_u_214)
					if not v223 then
						warn("[MailGuide] result failed:", v224)
						return
					end
				elseif p213 == "profile" then
					local v225 = v_u_2.onHeld
					local v226 = p_u_212
					local v227 = p_u_212.profile
					local v228, v229 = pcall(v225, v226, v227)
					if not v228 then
						warn("[MailGuide] overflow note failed:", v229)
					end
				end
			end)
			local v230 = p_u_212.profile
			if type(v230) == "table" then
				local v231 = p_u_212.profile.mailHeld
				if type(v231) == "table" then
					local v232 = v_u_2.onHeld
					local v233 = p_u_212.profile
					local v234, v235 = pcall(v232, p_u_212, v233)
					if not v234 then
						warn("[MailGuide] overflow note failed:", v235)
					end
				end
			end
			if v_u_4.noteOff then
				local v236 = v_u_4.noteOff
				pcall(v236)
				v_u_4.noteOff = nil
			end
			local function v244()
				-- upvalues: (copy) p_u_212, (ref) v_u_4, (ref) v_u_2
				local v237 = p_u_212.cctx.controllers.BmNotes
				if v237 then
					local v238 = v237.subscribe
					if type(v238) == "function" then
						v_u_4.noteOff = v237.subscribe(function(p239)
							-- upvalues: (ref) v_u_2, (ref) p_u_212
							local v240 = v_u_2.onNote
							local v241 = p_u_212
							local v242, v243 = pcall(v240, v241, p239)
							if not v242 then
								warn("[MailGuide] note failed:", v243)
							end
						end)
					end
				end
			end
			pcall(v244)
		end
	end
end
function v_u_2.detach() -- name: detach
	-- upvalues: (copy) v_u_4
	if v_u_4.noteOff then
		local v245 = v_u_4.noteOff
		pcall(v245)
		v_u_4.noteOff = nil
	end
	if v_u_4.conn then
		v_u_4.conn:Disconnect()
		v_u_4.conn = nil
	end
	v_u_4.mc = nil
end
function v_u_2.demo(p246, p247, p248) -- name: demo
	-- upvalues: (copy) v_u_2
	local v249 = p247 == "bm"
	local v250 = {
		["op"] = nil,
		["ok"] = true,
		["data"] = nil,
		["op"] = v249 and "bmBuy" or "storeGrant",
		["data"] = {
			["toMail"] = true,
			["mailSrc"] = nil,
			["mailTitle"] = nil,
			["mailFirst"] = nil,
			["mailSrc"] = v249 and "bm" or "store",
			["mailTitle"] = v249 and "5.56x45mm AP x 60" or "Survivor Starter Pack",
			["mailFirst"] = p248 ~= false
		}
	}
	return v_u_2.onResult(p246, v250, {
		["fake"] = true
	})
end
function v_u_2.demoCargo(p251) -- name: demoCargo
	-- upvalues: (copy) v_u_2
	local v252 = {
		["cargo"] = {
			["id"] = "cdemo",
			["title"] = "Cargo package",
			["expLeft"] = 518400,
			["items"] = nil,
			["items"] = {}
		}
	}
	return v_u_2.onMailData(p251, v252, {
		["fake"] = true
	})
end
function v_u_2.close() -- name: close
	-- upvalues: (copy) v_u_4
	local v253 = v_u_4.open
	if v253 and v253.close then
		v253.close()
	end
end
function v_u_2.state() -- name: state
	-- upvalues: (copy) v_u_4
	local v254 = 0
	for _ in v_u_4.queued do
		v254 = v254 + 1
	end
	return {
		["open"] = v_u_4.open ~= nil,
		["queued"] = v254,
		["shown"] = v_u_4.shown,
		["sent"] = v_u_4.sent
	}
end
function v_u_2._setReady(p255) -- name: _setReady
	-- upvalues: (ref) v_u_34
	v_u_34 = p255
end
function v_u_2._reset() -- name: _reset
	-- upvalues: (copy) v_u_4
	local v256 = v_u_4
	local v257 = v_u_4
	v_u_4.heldSeq = nil
	v256.lastMailMsg = nil
	v257.heldWait = nil
	table.clear(v_u_4.shown)
	table.clear(v_u_4.queued)
	table.clear(v_u_4.last)
	table.clear(v_u_4.sent)
end
return v_u_2