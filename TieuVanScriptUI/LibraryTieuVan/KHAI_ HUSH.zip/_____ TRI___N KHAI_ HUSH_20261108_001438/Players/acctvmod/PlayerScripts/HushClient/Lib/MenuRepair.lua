-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRepair

local v_u_1 = {}
local v_u_2 = {
	["mc"] = nil,
	["installed"] = false,
	["lastOpen"] = 0,
	["modal"] = nil,
	["mainRun"] = nil
}
function v_u_1.workbenchLevel(p3) -- name: workbenchLevel
	local v4
	if type(p3) == "table" then
		local v5 = p3.hideout
		v4 = type(v5) == "table" and p3.hideout.workbench or nil
	else
		v4 = nil
	end
	if type(v4) ~= "table" then
		return 0
	end
	local v6 = v4.lvl
	return tonumber(v6) or 0
end
function v_u_1.targets(p7, p8, p_u_9) -- name: targets
	-- upvalues: (copy) v_u_2
	local v_u_10 = {}
	local v_u_11 = "Items"
	local function v12()
		-- upvalues: (ref) v_u_2, (copy) v_u_11
		return v_u_2.mc.cctx.shared[v_u_11]
	end
	local v13, v_u_14 = pcall(v12)
	if not v13 then
		v_u_14 = nil
	end
	local v_u_15 = "AttachWear"
	local function v16()
		-- upvalues: (ref) v_u_2, (copy) v_u_15
		return v_u_2.mc.cctx.shared[v_u_15]
	end
	local v17, v_u_18 = pcall(v16)
	if not v17 then
		v_u_18 = nil
	end
	local v_u_19 = "HideoutModules"
	local function v20()
		-- upvalues: (ref) v_u_2, (copy) v_u_19
		return v_u_2.mc.cctx.shared[v_u_19]
	end
	local v21, v22 = pcall(v20)
	if not v21 then
		v22 = nil
	end
	if type(p7) ~= "table" or not v_u_14 then
		return v_u_10
	end
	local v_u_23 = 0.85
	if v22 and p8 > 0 then
		local v24 = v22.effectsAt
		local v25, v26 = pcall(v24, "workbench", p8)
		if v25 and type(v26) == "table" then
			local v27 = v26.repairQuality
			if tonumber(v27) then
				v_u_23 = v26.repairQuality
			end
		end
	end
	local function v41(p28) -- name: add
		-- upvalues: (copy) v_u_14, (copy) v_u_18, (ref) v_u_23, (copy) p_u_9, (copy) v_u_10
		local v29
		if type(p28) == "table" then
			local v30 = p28.id
			if type(v30) == "string" then
				v29 = v_u_14.get(p28.id) or nil
			else
				v29 = nil
			end
		else
			v29 = nil
		end
		if v29 and p28.uid then
			local v31 = v29.value
			local v32 = tonumber(v31) or 0
			local v33 = nil
			if v_u_18 and v_u_18.wears(v29) then
				local v34 = v_u_18.durOf(p28)
				v33 = v34 < 0.999 and {
					["inst"] = nil,
					["def"] = nil,
					["wear"] = true,
					["dur"] = nil,
					["to"] = 1,
					["cost"] = nil,
					["inst"] = p28,
					["def"] = v29,
					["dur"] = v34,
					["cost"] = v_u_18.repairCost(v32, v34)
				} or v33
			else
				local v35 = p28.dur
				if type(v35) == "number" and (p28.dur < 0.999 and not v29.uses) then
					local v36 = v32 * 0.12 * (v_u_23 - p28.dur) / 5 + 0.5
					local v37 = math.floor(v36) * 5
					local v38 = math.max(50, v37)
					v33 = {
						["inst"] = nil,
						["def"] = nil,
						["wear"] = false,
						["dur"] = nil,
						["to"] = nil,
						["cost"] = nil,
						["inst"] = p28,
						["def"] = v29,
						["dur"] = p28.dur,
						["to"] = v_u_23,
						["cost"] = v38
					}
					if p28.dur >= v_u_23 - 0.001 then
						local v39 = v_u_23 * 100 + 0.5
						v33.block = ("Already in good condition. Your workbench repairs to %d %%."):format((math.floor(v39)))
					end
				end
			end
			if v33 then
				if not v33.block and (p_u_9 and p_u_9 < v33.cost) then
					v33.block = "Not enough cash"
				end
				local v40 = v_u_10
				table.insert(v40, v33)
			end
		end
	end
	v41(p7)
	local v42 = p7.mods
	if type(v42) == "table" then
		for _, v43 in p7.mods do
			v41(v43)
		end
	end
	return v_u_10
end
function v_u_1.repairable(p44) -- name: repairable
	-- upvalues: (copy) v_u_1
	return #v_u_1.targets(p44, 1, nil) > 0
end
local function v_u_52(p45) -- name: sendRepair
	-- upvalues: (copy) v_u_2
	local v_u_46 = v_u_2.mc
	if v_u_46 then
		local v47 = v_u_46.op
		if type(v47) == "function" then
			v_u_46.op({
				["op"] = "repair",
				["uid"] = nil,
				["uid"] = p45.inst.uid
			})
			local v48 = p45.inst.uid
			local v_u_49 = tostring(v48)
			local v_u_50 = "MenuRepairSent"
			local function v51()
				-- upvalues: (ref) v_u_2, (copy) v_u_50, (copy) v_u_49
				v_u_2.mc.cctx.player:SetAttribute(v_u_50, v_u_49)
			end
			pcall(v51)
			pcall(function()
				-- upvalues: (copy) v_u_46
				v_u_46.ui.sound(v_u_46.theme.sounds.confirm)
			end)
			return
		end
	end
end
function v_u_1.open(p_u_53) -- name: open
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_52
	local v54 = v_u_2.mc
	if v54 and type(p_u_53) == "table" then
		local v_u_55 = v54.ui
		local v_u_56 = v54.theme
		local v_u_57 = v_u_56.color
		local v_u_58 = v54.kit
		local v59 = v54.profile
		local v_u_60 = v_u_1.workbenchLevel(v59)
		if v_u_60 <= 0 then
			v_u_55.toast("Build a workbench in your hideout", "warn", "Repairs need the workbench. Build it in the hideout, then repair right here from the stash.")
			v_u_55.sound(v_u_56.sounds.error)
			local v61 = p_u_53.id
			local v_u_62 = "nobench " .. tostring(v61)
			local v_u_63 = "MenuRepair"
			local function v64()
				-- upvalues: (ref) v_u_2, (copy) v_u_63, (copy) v_u_62
				v_u_2.mc.cctx.player:SetAttribute(v_u_63, v_u_62)
			end
			pcall(v64)
			return
		else
			local v65
			if type(v59) == "table" then
				v65 = v59.cash
			else
				v65 = false
			end
			local v_u_66 = tonumber(v65) or 0
			local v_u_67 = v_u_1.targets(p_u_53, v_u_60, v_u_66)
			if #v_u_67 == 0 then
				v_u_55.toast("Nothing to repair", "info", "This item is in full condition.")
				local v68 = p_u_53.id
				local v_u_69 = ("%s lvl=%d rows=0 main=- block=-"):format(tostring(v68), v_u_60)
				local v_u_70 = "MenuRepair"
				local function v71()
					-- upvalues: (ref) v_u_2, (copy) v_u_70, (copy) v_u_69
					v_u_2.mc.cctx.player:SetAttribute(v_u_70, v_u_69)
				end
				pcall(v71)
				return
			else
				if v_u_2.modal then
					local v72 = v_u_2.modal.close
					pcall(v72)
					v_u_2.modal = nil
				end
				local v_u_73 = nil
				for _, v74 in v_u_67 do
					if v74.block then
						continue
					end
					v_u_73 = v74
				end
				local v_u_75 = 0.85
				for _, v76 in v_u_67 do
					if v76.wear then
						continue
					end
					v_u_75 = v76.to
				end
				local v_u_77 = nil
				local v_u_78 = {}
				if v_u_73 then
					table.insert(v_u_78, {
						["text"] = "Cancel",
						["kind"] = "ghost"
					})
					local v79 = {
						["text"] = nil,
						["kind"] = "primary",
						["onClick"] = nil
					}
					local v80 = string.upper
					local v81 = v_u_73.def.short or v_u_73.def.name
					v79.text = ("Repair %s  \194\183  %s"):format(v80((tostring(v81))), v_u_58.money(v_u_73.cost))
					function v79.onClick() -- name: onClick
						-- upvalues: (ref) v_u_52, (ref) v_u_73
						v_u_52(v_u_73)
					end
					table.insert(v_u_78, v79)
				else
					table.insert(v_u_78, {
						["text"] = "Close",
						["kind"] = "primary"
					})
				end
				local function v114()
					-- upvalues: (ref) v_u_77, (copy) v_u_55, (copy) v_u_60, (ref) v_u_75, (copy) v_u_58, (copy) v_u_66, (copy) v_u_67, (copy) v_u_57, (ref) v_u_73, (copy) v_u_56, (copy) p_u_53, (ref) v_u_52, (copy) v_u_78, (ref) v_u_2
					local v82 = v_u_55.modal
					local v83 = {
						["title"] = "Workbench repair",
						["width"] = 560,
						["body"] = nil,
						["build"] = nil,
						["buttons"] = nil,
						["onClose"] = nil
					}
					local v84 = v_u_60
					local v85 = v_u_75 * 100 + 0.5
					v83.body = ("Workbench LV %d restores weapons and armor to %d %%. A suppressor gets new baffles: 100 %%. Cash: %s."):format(v84, math.floor(v85), v_u_58.money(v_u_66))
					function v83.build(p86) -- name: build
						-- upvalues: (ref) v_u_67, (ref) v_u_55, (ref) v_u_57, (ref) v_u_73, (ref) v_u_58, (ref) v_u_56, (ref) p_u_53, (ref) v_u_52, (ref) v_u_77
						for v87, v_u_88 in v_u_67 do
							local v89 = v_u_55.new
							local v90 = {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.2,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil
							}
							local v91 = v_u_88.inst.uid
							v90.Name = "Repair_" .. tostring(v91)
							v90.BackgroundColor3 = v_u_57.raised
							v90.Size = UDim2.new(1, 0, 0, 68)
							v90.LayoutOrder = v87
							local v92 = v89("Frame", v90, p86)
							local v93 = v_u_55.stroke
							local v94
							if v_u_88 == v_u_73 then
								v94 = v_u_57.accent
							else
								v94 = v_u_57.line
							end
							v93(v92, v94)
							local v95 = v_u_88.def.w
							local v96 = tonumber(v95) or 1
							local v97 = v_u_88.def.h
							local v98 = (tonumber(v97) or 1) < v96
							v_u_58.itemCell(v92, v_u_88.inst.id, {
								["size"] = 56,
								["w"] = nil,
								["h"] = 1,
								["wish"] = nil,
								["w"] = v98 and 2 or 1,
								["wish"] = not v_u_56.isPhone()
							}).Position = UDim2.fromOffset(6, 6)
							local v99 = (v98 and 2 or 1) * 56 + 6 + 12
							local v100 = (v_u_88 == v_u_73 or v_u_88.block) and 0 or 132
							v_u_55.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = nil,
								["style"] = "bodyStrong",
								["textSize"] = 14,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v92,
								["text"] = v_u_58.itemName(v_u_88.inst.id) .. (v_u_88.wear and v_u_88.inst ~= p_u_53 and "  (fitted)" or ""),
								["position"] = UDim2.fromOffset(v99, 6),
								["size"] = UDim2.new(1, -v99 - v100 - 96, 0, 20)
							})
							local v101 = v_u_55.label
							local v102 = {
								["parent"] = nil,
								["name"] = "Cost",
								["text"] = nil,
								["style"] = "mono",
								["color"] = nil,
								["align"] = "right",
								["anchor"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v92,
								["text"] = v_u_58.money(v_u_88.cost)
							}
							local v103
							if v_u_88.block then
								v103 = v_u_57.muted
							else
								v103 = v_u_57.accent
							end
							v102.color = v103
							v102.anchor = Vector2.new(1, 0)
							v102.position = UDim2.new(1, -v100 - 12, 0, 6)
							v102.size = UDim2.fromOffset(84, 20)
							v101(v102)
							local v104
							if v_u_88.block then
								v104 = v_u_88.block
							else
								local v105 = v_u_88.dur * 100
								local v106 = math.floor(v105)
								local v107 = v_u_88.to * 100 + 0.5
								v104 = ("%d %%  to  %d %%"):format(v106, (math.floor(v107)))
							end
							local v108 = v_u_55.label
							local v109 = {
								["parent"] = nil,
								["name"] = "Condition",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v92,
								["text"] = v104
							}
							local v110
							if v_u_88.block then
								v110 = v_u_57.text2
							elseif v_u_88.dur < 0.5 then
								v110 = v_u_57.danger
							else
								v110 = v_u_57.text2
							end
							v109.color = v110
							v109.position = UDim2.fromOffset(v99, 28)
							v109.size = UDim2.new(1, -v99 - v100 - 12, 0, 16)
							v108(v109)
							local v111 = v_u_55.progress
							local v112 = {
								["parent"] = v92,
								["size"] = UDim2.new(1, -v99 - v100 - 12, 0, 4),
								["position"] = UDim2.new(0, v99, 1, -10),
								["value"] = v_u_88.dur,
								["ghost"] = v_u_88.to
							}
							local v113
							if v_u_88.dur < 0.5 then
								v113 = v_u_57.danger
							else
								v113 = v_u_57.accent
							end
							v112.color = v113
							v111(v112)
							if v100 <= 0 then
								continue
							end
							v_u_55.button({
								["parent"] = nil,
								["name"] = "RepairBtn",
								["text"] = "Repair",
								["kind"] = "secondary",
								["width"] = nil,
								["height"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["onClick"] = nil,
								["parent"] = v92,
								["width"] = v100 - 12,
								["height"] = v_u_56.touch(36),
								["position"] = UDim2.new(1, -6, 0.5, 0),
								["anchor"] = Vector2.new(1, 0.5),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_52, (copy) v_u_88, (ref) v_u_77
									v_u_52(v_u_88)
									if v_u_77 then
										v_u_77.close()
									end
								end
							})
						end
					end
					v83.buttons = v_u_78
					function v83.onClose() -- name: onClose
						-- upvalues: (ref) v_u_2, (ref) v_u_77
						if v_u_2.modal == v_u_77 then
							v_u_2.modal = nil
							v_u_2.mainRun = nil
						end
					end
					v_u_77 = v82(v83)
				end
				if pcall(v114) and v_u_77 then
					v_u_2.modal = v_u_77
					v_u_2.mainRun = v_u_73 and function()
						-- upvalues: (ref) v_u_52, (ref) v_u_73, (ref) v_u_77
						v_u_52(v_u_73)
						v_u_77.close()
					end or nil
					local v115 = "%s lvl=%d rows=%d main=%s block=%s"
					local v116 = p_u_53.id
					local v117 = tostring(v116)
					local v118 = #v_u_67
					local v119
					if v_u_73 then
						local v120 = v_u_73.cost
						v119 = tostring(v120)
					else
						v119 = "-"
					end
					local v121
					if v_u_73 then
						v121 = "-"
					else
						local v122 = v_u_67[1].block
						v121 = tostring(v122)
					end
					local v_u_123 = v115:format(v117, v_u_60, v118, v119, v121)
					local v_u_124 = "MenuRepair"
					local function v125()
						-- upvalues: (ref) v_u_2, (copy) v_u_124, (copy) v_u_123
						v_u_2.mc.cctx.player:SetAttribute(v_u_124, v_u_123)
					end
					pcall(v125)
				end
			end
		end
	else
		return
	end
end
function v_u_1.devCommand(p126) -- name: devCommand
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v127 = v_u_2.mc
	if not v127 then
		return "not installed"
	end
	local v128 = p126[1] or ""
	local v_u_129 = tostring(v128)
	if v_u_129 == "go" then
		if not v_u_2.mainRun then
			return "no repair button"
		end
		v_u_2.mainRun()
		return "sent"
	end
	local v130 = v127.profile
	local v131
	if type(v130) == "table" then
		v131 = v130.inv or nil
	else
		v131 = nil
	end
	local v_u_132 = nil
	local function v135(p133) -- name: scan
		-- upvalues: (ref) v_u_132, (copy) v_u_129
		for _, v134 in type(p133) ~= "table" and {} or p133 do
			if type(v134) ~= "table" or (v_u_132 or v134.uid ~= v_u_129 and v134.id ~= v_u_129) then
				continue
			end
			v_u_132 = v134
		end
	end
	if type(v131) == "table" then
		local v136 = v131.containers
		for _, v137 in type(v136) ~= "table" and {} or v131.containers do
			local v138
			if type(v137) == "table" then
				v138 = v137.items
			else
				v138 = false
			end
			v135(v138)
		end
		local v139 = v131.kit
		if type(v139) == "table" then
			local v140 = v131.kit.slots
			if type(v140) == "table" then
				for _, v141 in v131.kit.slots do
					v135({ v141 })
				end
			end
		end
	end
	if not v_u_132 then
		return "no item " .. v_u_129
	end
	v_u_1.open(v_u_132)
	local v142 = v_u_132.uid
	local v143 = tostring(v142)
	local v144 = v127.cctx.player
	return v143 .. " -> " .. tostring(v144:GetAttribute("MenuRepair"))
end
function v_u_1.install(p_u_145) -- name: install
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	v_u_2.mc = p_u_145
	if not v_u_2.installed then
		local v146, v147 = pcall(function()
			-- upvalues: (copy) p_u_145
			return p_u_145.cctx.lib.InvUIAmmo
		end)
		if v146 and type(v147) == "table" then
			local v148 = v147.stackActs
			if type(v148) == "function" then
				local v149 = v147.stripActs
				if type(v149) == "function" then
					local v150 = v147.opFor
					if type(v150) == "function" then
						v_u_2.installed = true
						if not v147._menuRepair then
							v147._menuRepair = true
							local v_u_151 = v147.stackActs
							local v_u_152 = v147.stripActs
							local v_u_153 = v147.opFor
							function v147.stackActs(p154, p155, p156, p157)
								-- upvalues: (copy) v_u_151, (ref) v_u_1
								local v158 = v_u_151(p154, p155, p156, p157)
								if p155 ~= "raid" and (type(p156) == "table" and (p156.item and (p156.container ~= "ground" and v_u_1.repairable(p156.item)))) then
									table.insert(v158, {
										["id"] = "repair",
										["text"] = "Repair"
									})
								end
								return v158
							end
							function v147.stripActs(p159, p160, p161, p162, p163, p164)
								-- upvalues: (copy) v_u_152, (ref) v_u_1
								local v165 = v_u_152(p159, p160, p161, p162, p163, p164)
								if p160 ~= "raid" and (not p163 and (not p164 and (type(p161) == "table" and (p161.item and v_u_1.repairable(p161.item))))) then
									table.insert(v165, {
										["id"] = "repair",
										["text"] = "Repair",
										["icon"] = "repair"
									})
								end
								return v165
							end
							function v147.opFor(p166, p167, p168)
								-- upvalues: (ref) v_u_2, (ref) v_u_1, (copy) v_u_153
								if p166 ~= "repair" then
									return v_u_153(p166, p167, p168)
								end
								local v169 = os.clock()
								if v169 - v_u_2.lastOpen > 0.3 then
									v_u_2.lastOpen = v169
									task.defer(v_u_1.open, p168)
								end
								return nil
							end
							local function v172()
								-- upvalues: (copy) p_u_145, (ref) v_u_1
								if game:GetService("RunService"):IsStudio() then
									local v170 = p_u_145.cctx.command
									if type(v170) == "function" then
										p_u_145.cctx.command("menu.repair", function(p171)
											-- upvalues: (ref) v_u_1
											return v_u_1.devCommand(p171)
										end)
									end
								end
							end
							pcall(v172)
						end
					end
				end
			end
		end
		warn("[MenuRepair] InvUIAmmo missing: no REPAIR entry in the stash")
	end
end
return v_u_1