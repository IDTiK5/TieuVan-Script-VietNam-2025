-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanBoard

local v_u_1 = {}
local v_u_2 = {}
function v_u_1.rowParts(p3) -- name: rowParts
	local v4 = {
		["rankX"] = 12,
		["nameX"] = 72,
		["ptsW"] = 96,
		["nameW"] = nil
	}
	local v5 = p3 - 72 - 96 - 20
	v4.nameW = math.max(60, v5)
	return v4
end
function v_u_1.resultModal(p_u_6, p_u_7) -- name: resultModal
	-- upvalues: (copy) v_u_2
	local v_u_8 = p_u_6.UI
	local v_u_9 = p_u_6.C
	local v10 = p_u_6.M
	local v_u_11 = p_u_6.Kit
	if type(p_u_7) == "table" then
		local v12 = p_u_7.week
		local v13 = tonumber(v12) or 0
		local v_u_14 = math.floor(v13)
		local v_u_16 = v10.rewardLines(p_u_7, function(p15)
			-- upvalues: (copy) v_u_11
			return v_u_11.itemName(p15)
		end, p_u_6.U.cosName)
		local v24 = {
			["title"] = "WEEK RESULT",
			["width"] = 460,
			["build"] = nil,
			["buttons"] = nil,
			["onClose"] = nil,
			["build"] = function(p17) -- name: build
				-- upvalues: (copy) p_u_7, (copy) v_u_8, (copy) p_u_6, (copy) v_u_9, (copy) v_u_16
				local v18 = p_u_7.rank
				local v19 = tonumber(v18) or 0
				local v20 = math.floor(v19)
				v_u_8.label({
					["parent"] = nil,
					["name"] = "Place",
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = 1,
					["parent"] = p17,
					["text"] = v20 <= 0 and "Thank you for playing" or ("%s finished in place %d"):format(p_u_6.U.label(p_u_7.tag, ""), v20),
					["color"] = v_u_9.accent,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
				if #v_u_16 == 0 then
					v_u_8.label({
						["parent"] = nil,
						["name"] = "None",
						["text"] = "No rewards this week.",
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["size"] = nil,
						["order"] = 2,
						["parent"] = p17,
						["color"] = v_u_9.text2,
						["size"] = UDim2.new(1, 0, 0, 0)
					})
				else
					v_u_8.label({
						["parent"] = nil,
						["name"] = "Head",
						["text"] = "YOUR REWARDS",
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["order"] = 2,
						["parent"] = p17,
						["color"] = v_u_9.text2,
						["size"] = UDim2.new(1, 0, 0, 16)
					})
					for v21, v22 in v_u_16 do
						v_u_8.label({
							["parent"] = nil,
							["name"] = nil,
							["text"] = nil,
							["style"] = "body",
							["wrap"] = true,
							["autoY"] = true,
							["size"] = nil,
							["order"] = nil,
							["parent"] = p17,
							["name"] = "Line" .. v21,
							["text"] = v22,
							["size"] = UDim2.new(1, 0, 0, 0),
							["order"] = 2 + v21
						})
					end
				end
			end,
			["buttons"] = {
				{
					["text"] = "CLOSE",
					["kind"] = "primary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick end
				}
			},
			["onClose"] = function() -- name: onClose
				-- upvalues: (copy) p_u_7, (copy) v_u_14, (ref) v_u_2, (copy) p_u_6
				if p_u_7.seen == false and (v_u_14 > 0 and not v_u_2[v_u_14]) then
					v_u_2[v_u_14] = true
					local v23 = {
						["week"] = v_u_14
					}
					p_u_6.send("clanSeen", v23, function() end, 15)
				end
			end
		}
		v_u_8.modal(v24)
	end
end
function v_u_1.mount(p_u_25, p26) -- name: mount
	-- upvalues: (copy) v_u_1
	local v_u_27 = p_u_25.UI
	local v28 = p_u_25.Theme
	local v_u_29 = p_u_25.C
	local v_u_30 = p_u_25.Kit
	local v_u_31 = p_u_25.U
	local v_u_32 = p_u_25.M
	local v_u_33 = p_u_25.m
	local v_u_34 = p_u_25.lib("MenuClanPlan")
	local v_u_35 = p_u_25.lib("MenuClanLook")
	local v_u_36 = {}
	local v_u_37 = true
	local v_u_38 = "week"
	local v_u_39 = nil
	local v_u_40 = "loading"
	local v_u_41 = false
	local v_u_42 = 0
	local v_u_43 = false
	local _, _ = v_u_27.tabs({
		["parent"] = nil,
		["name"] = "Mode",
		["tabs"] = nil,
		["selected"] = nil,
		["position"] = nil,
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = p26,
		["tabs"] = {
			{
				["id"] = "week",
				["text"] = "This week"
			},
			{
				["id"] = "last",
				["text"] = "Last week"
			}
		},
		["selected"] = v_u_38,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(0.6, 0, 0, v28.touch(40)),
		["onChange"] = function(p44) -- name: onChange
			-- upvalues: (ref) v_u_38, (copy) v_u_36
			v_u_38 = p44
			v_u_36.draw()
		end
	})
	local v_u_45 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Reset",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = p26,
		["position"] = UDim2.fromScale(0.6, 0),
		["size"] = UDim2.new(0.4, 0, 0, v28.touch(40))
	})
	local v46 = v28.touch(40) + 8
	local v_u_47, v_u_48, v49 = v_u_34.boardSplit(v_u_33.inner, v_u_33.twoCol)
	local v50 = v_u_31.frame(p26, "Left", UDim2.new(0, v_u_47, 1, -v46), UDim2.fromOffset(0, v46))
	local v_u_51 = v_u_27.list({
		["parent"] = nil,
		["name"] = "List",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 6,
		["padding"] = nil,
		["parent"] = v50,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(1, 0, 1, -68),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local v_u_52
	if v_u_33.twoCol then
		v_u_52 = v_u_27.list({
			["parent"] = nil,
			["name"] = "Side",
			["position"] = nil,
			["size"] = nil,
			["gap"] = 6,
			["padding"] = nil,
			["parent"] = p26,
			["position"] = UDim2.fromOffset(v_u_47 + v49, v46),
			["size"] = UDim2.new(0, v_u_48, 1, -v46),
			["padding"] = {
				0,
				6,
				0,
				8
			}
		})
	else
		v_u_52 = nil
	end
	local v_u_53 = v_u_31.card(v50, "Me", {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = 60,
		["w"] = v_u_47 - 6
	}, {
		["fill"] = nil,
		["transparency"] = 0.2,
		["stroke"] = nil,
		["strokeTransparency"] = 0,
		["fill"] = v_u_29.accentDeep,
		["stroke"] = v_u_29.accent
	})
	v_u_53.AnchorPoint = Vector2.new(0, 1)
	v_u_53.Position = UDim2.new(0, 0, 1, 0)
	v_u_53.Size = UDim2.new(1, -6, 0, 60)
	local v_u_54 = v_u_34.boardCard(v_u_47 - 6, 60, true)
	local v_u_55 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Rank",
		["text"] = "",
		["style"] = "monoL",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_53,
		["color"] = v_u_29.accent,
		["position"] = UDim2.fromOffset(v_u_54.place.x, v_u_54.place.y),
		["size"] = UDim2.fromOffset(v_u_54.place.w, v_u_54.place.h)
	})
	local v_u_56 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = "",
		["style"] = "bodyStrong",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_53,
		["position"] = UDim2.fromOffset(v_u_54.tag.x, v_u_54.name.y),
		["size"] = UDim2.fromOffset(v_u_54.name.x + v_u_54.name.w - v_u_54.tag.x, v_u_54.name.h)
	})
	local v_u_57 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Note",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_53,
		["color"] = v_u_29.text2,
		["position"] = UDim2.fromOffset(v_u_54.tag.x, v_u_54.sub.y),
		["size"] = UDim2.fromOffset(v_u_54.sub.x + v_u_54.sub.w - v_u_54.tag.x, v_u_54.sub.h)
	})
	local v_u_58 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Pts",
		["text"] = "",
		["style"] = "monoL",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_53,
		["position"] = UDim2.fromOffset(v_u_54.pts.x, v_u_54.pts.y),
		["size"] = UDim2.fromOffset(v_u_54.pts.w, v_u_54.pts.h)
	})
	local function v_u_66(p59) -- name: tagColor
		-- upvalues: (copy) p_u_25, (copy) v_u_29
		local v_u_60 = nil
		local function v61()
			-- upvalues: (ref) v_u_60, (ref) p_u_25
			v_u_60 = p_u_25.cctx.shared.ClanTag
		end
		pcall(v61)
		if v_u_60 then
			local v62 = v_u_60.color
			if type(v62) == "function" and type(p59) == "string" then
				local v63 = v_u_60.color
				local v64, v65 = pcall(v63, p59, 0.55, 0.95)
				if v64 and typeof(v65) == "Color3" then
					return v65
				end
			end
		end
		return v_u_29.accent
	end
	local function v_u_110(p67, p68, p_u_69, p70) -- name: boardRow
		-- upvalues: (copy) v_u_33, (copy) v_u_51, (copy) v_u_47, (copy) v_u_48, (copy) v_u_31, (copy) v_u_29, (copy) v_u_34, (copy) v_u_27, (copy) v_u_66, (copy) v_u_32
		local v71 = p_u_69.rank
		local v72 = tonumber(v71) or p68
		local v73 = v72 <= 3
		local v74
		if v73 then
			v74 = v_u_33.kind == "phone" and 56 or 64
		else
			v74 = v_u_33.boardRowH + 4
		end
		local v75
		if p67 == v_u_51 then
			v75 = v_u_47
		else
			v75 = v_u_48
		end
		local v76 = v75 - 6
		local v77 = v_u_31.card
		local v78 = "B" .. p68
		local v79 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v76,
			["h"] = v74
		}
		local v80 = {}
		local v81
		if p70 then
			v81 = v_u_29.accentDeep
		else
			v81 = v_u_29.raised
		end
		v80.fill = v81
		v80.transparency = p70 and 0.3 or 0.25
		local v82
		if p70 then
			v82 = v_u_29.accent
		else
			v82 = v_u_29.line
		end
		v80.stroke = v82
		v80.order = p68
		local v83 = v77(p67, v78, v79, v80)
		v83.Size = UDim2.new(1, -6, 0, v74)
		local v84 = v_u_34.boardCard(v76, v74, v73)
		local v85
		if v72 == 1 then
			v85 = v_u_29.accent
		elseif v72 == 2 then
			v85 = Color3.fromRGB(200, 206, 216)
		elseif v72 == 3 then
			v85 = Color3.fromRGB(205, 140, 90)
		else
			v85 = nil
		end
		if v85 then
			v_u_27.new("Frame", {
				["Name"] = "Medal",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v85,
				["Position"] = UDim2.fromOffset(v84.medal.x, v84.medal.y),
				["Size"] = UDim2.fromOffset(v84.medal.w, v84.medal.h)
			}, v83)
		end
		v_u_27.label({
			["parent"] = nil,
			["name"] = "Rank",
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83,
			["text"] = ("#%d"):format(v72),
			["color"] = v85 or v_u_29.text2,
			["position"] = UDim2.fromOffset(v84.place.x, v84.place.y),
			["size"] = UDim2.fromOffset(v84.place.w, v84.place.h)
		})
		local v86 = v_u_66(p_u_69.id)
		local v87 = v_u_31.card(v83, "TagBadge", v84.tag, {
			["fill"] = nil,
			["transparency"] = 0.1,
			["stroke"] = nil,
			["strokeTransparency"] = 0.2,
			["fill"] = v_u_29.bg,
			["stroke"] = v86
		})
		local v88 = v_u_27.label
		local v89 = {
			["parent"] = nil,
			["name"] = "Tag",
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["track"] = false,
			["parent"] = v87
		}
		local v90 = p_u_69.tag or "????"
		v89.text = tostring(v90)
		v89.style = v73 and "bodyStrong" or "small"
		v89.color = v86
		v89.size = UDim2.fromScale(1, 1)
		v88(v89)
		local v91 = v_u_27.label
		local v92 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v83
		}
		local v93 = p_u_69.name or "?"
		v92.text = tostring(v93)
		local v94
		if p70 then
			v94 = v_u_29.accent
		else
			v94 = v_u_29.text
		end
		v92.color = v94
		v92.position = UDim2.fromOffset(v84.name.x, v84.name.y)
		v92.size = UDim2.fromOffset(v84.name.w, v84.name.h)
		v91(v92)
		local v95 = p_u_69.count
		local v_u_96 = tonumber(v95) or 0
		local v97 = v_u_32.boardSub(p_u_69.count, p_u_69.act)
		v_u_27.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83,
			["text"] = v97,
			["color"] = v_u_29.text2,
			["position"] = UDim2.fromOffset(v84.sub.x, v84.sub.y),
			["size"] = UDim2.fromOffset(v84.sub.w, v84.sub.h)
		})
		local v98 = v_u_27.label
		local v99 = {
			["parent"] = nil,
			["name"] = "Pts",
			["text"] = nil,
			["style"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83
		}
		local v100 = v_u_27.commas
		local v101 = p_u_69.pts
		v99.text = v100(tonumber(v101) or 0)
		v99.style = v73 and "monoL" or "mono"
		v99.position = UDim2.fromOffset(v84.pts.x, v84.pts.y)
		v99.size = UDim2.fromOffset(v84.pts.w, v84.pts.h)
		v98(v99)
		v_u_27.tooltip(v83, function()
			-- upvalues: (copy) p_u_69, (ref) v_u_27, (copy) v_u_96
			local v102 = {}
			local v103 = p_u_69.name or ""
			v102.title = tostring(v103)
			local v104 = {}
			local v105 = {
				["label"] = "Points",
				["value"] = nil
			}
			local v106 = v_u_27.commas
			local v107 = p_u_69.pts
			v105.value = v106(tonumber(v107) or 0)
			local v108 = {
				["label"] = "Members",
				["value"] = nil
			}
			local v109 = v_u_96
			v108.value = tostring(v109)
			__set_list(v104, 1, {v105, v108})
			v102.lines = v104
			return v102
		end)
	end
	local function v_u_128(p111, p112) -- name: rewardsBlock
		-- upvalues: (ref) v_u_39, (copy) v_u_30, (copy) v_u_32, (copy) v_u_51, (copy) v_u_47, (copy) v_u_48, (copy) v_u_31, (copy) v_u_34, (copy) v_u_29, (copy) v_u_27
		local v113
		if v_u_39 then
			local v114 = v_u_39.rewards
			if type(v114) == "table" then
				v113 = v_u_39.rewards
			else
				v113 = nil
			end
		else
			v113 = nil
		end
		if v113 and #v113 ~= 0 then
			v_u_30.section(p111, v_u_32.UI.REWARDS_HEAD, p112)
			local v115
			if p111 == v_u_51 then
				v115 = v_u_47
			else
				v115 = v_u_48
			end
			local v116 = v115 - 6
			for v117, v_u_118 in v113 do
				if type(v_u_118) ~= "table" then
					continue
				end
				local v_u_120 = table.concat(v_u_32.rewardLines(v_u_118, function(p119)
					-- upvalues: (ref) v_u_30
					return v_u_30.itemName(p119)
				end, v_u_31.cosName), ", ")
				local v121 = v_u_120 == "" and "Supplies" or v_u_120
				local v122 = 16 + v_u_34.lines(v121, v116 - 150 - 12, v_u_34.BODY_CHAR_W * 0.9) * 16
				local v123 = math.max(44, v122)
				local v124 = v_u_31.card(p111, "Reward" .. v117, {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v116,
					["h"] = v123
				}, {
					["order"] = p112 + v117
				})
				v124.Size = UDim2.new(1, -6, 0, v123)
				local v125 = v_u_118.from
				local v126 = tonumber(v125) or 99
				local v127
				if v126 == 1 then
					v127 = v_u_29.accent
				elseif v126 == 2 then
					v127 = Color3.fromRGB(200, 206, 216)
				elseif v126 == 3 then
					v127 = Color3.fromRGB(205, 140, 90)
				else
					v127 = nil
				end
				v_u_27.label({
					["parent"] = nil,
					["name"] = "Place",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v124,
					["text"] = v_u_32.placeText(v_u_118.from, v_u_118.to),
					["color"] = v127 or v_u_29.text,
					["position"] = UDim2.fromOffset(12, 0),
					["size"] = UDim2.fromOffset(130, v123)
				})
				v_u_27.label({
					["parent"] = nil,
					["name"] = "What",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["valign"] = "center",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v124,
					["text"] = v121,
					["color"] = v_u_29.text2,
					["position"] = UDim2.fromOffset(150, 4),
					["size"] = UDim2.fromOffset(v116 - 150 - 12, v123 - 8)
				})
				v_u_27.tooltip(v124, function()
					-- upvalues: (ref) v_u_32, (copy) v_u_118, (copy) v_u_120
					return {
						["title"] = v_u_32.placeText(v_u_118.from, v_u_118.to):upper(),
						["body"] = v_u_120
					}
				end)
			end
		end
	end
	local function v_u_140(p129, p_u_130, p131) -- name: myResult
		-- upvalues: (copy) v_u_51, (copy) v_u_47, (copy) v_u_48, (copy) v_u_34, (copy) v_u_31, (copy) v_u_27, (copy) v_u_29, (ref) v_u_1, (copy) p_u_25
		local v132 = p_u_130.me
		if type(v132) == "table" then
			local v133
			if p129 == v_u_51 then
				v133 = v_u_47
			else
				v133 = v_u_48
			end
			local v134 = v133 - 6
			local v135 = v_u_34.resultCard(v134)
			local v136 = v_u_31.card(p129, "MyResultCard", {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v134,
				["h"] = v135.h
			}, {
				["order"] = p131
			})
			v136.Size = UDim2.new(1, -6, 0, v135.h)
			local v137 = p_u_130.me.rank
			local v138 = tonumber(v137) or 0
			local v139 = math.floor(v138)
			v_u_27.label({
				["parent"] = nil,
				["name"] = "Head",
				["text"] = "YOUR RESULT",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v136,
				["color"] = v_u_29.text2,
				["position"] = UDim2.fromOffset(14, 10),
				["size"] = UDim2.fromOffset(v134 - 28, 16)
			})
			v_u_27.label({
				["parent"] = nil,
				["name"] = "Place",
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v136,
				["text"] = v139 <= 0 and "Thank you for playing" or ("Place %d"):format(v139),
				["position"] = UDim2.fromOffset(14, 28),
				["size"] = UDim2.fromOffset(v134 - 28, 24)
			})
			v_u_31.btn({
				["parent"] = nil,
				["text"] = "VIEW MY RESULT",
				["kind"] = "secondary",
				["width"] = 160,
				["name"] = "MyResult",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v136,
				["position"] = UDim2.fromOffset(v135.btn.x, v135.btn.y),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_1, (ref) p_u_25, (copy) p_u_130
					v_u_1.resultModal(p_u_25, p_u_130.me)
				end
			})
		end
	end
	function v_u_36.draw() -- name: draw
		-- upvalues: (ref) v_u_37, (copy) p_u_25, (copy) v_u_27, (copy) v_u_51, (copy) v_u_30, (ref) v_u_52, (ref) v_u_39, (ref) v_u_40, (copy) v_u_32, (copy) v_u_31, (copy) v_u_36, (copy) v_u_33, (copy) v_u_55, (copy) v_u_56, (copy) v_u_57, (copy) v_u_58, (ref) v_u_38, (copy) v_u_47, (copy) v_u_29, (copy) v_u_110, (copy) v_u_128, (copy) v_u_140, (copy) v_u_53, (copy) v_u_35, (copy) v_u_34, (copy) v_u_54
		if v_u_37 then
			local v_u_141
			if p_u_25.clan() then
				v_u_141 = p_u_25.clan().id
			else
				v_u_141 = nil
			end
			v_u_27.keepScroll(v_u_51, function()
				-- upvalues: (ref) v_u_30, (ref) v_u_51, (ref) v_u_52, (ref) v_u_39, (ref) v_u_40, (ref) v_u_32, (ref) v_u_31, (ref) v_u_36, (ref) v_u_33, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57, (ref) v_u_58, (ref) v_u_38, (ref) v_u_47, (ref) v_u_27, (ref) v_u_29, (ref) v_u_110, (copy) v_u_141, (ref) v_u_128, (ref) v_u_140
				v_u_30.clear(v_u_51)
				if v_u_52 then
					v_u_30.clear(v_u_52)
				end
				if v_u_39 == nil then
					if v_u_40 == "gave_up" then
						v_u_30.empty(v_u_51, v_u_32.UI.LOAD_FAIL, 1)
						local v142 = {
							["parent"] = nil,
							["text"] = "RETRY",
							["kind"] = "secondary",
							["width"] = 140,
							["order"] = 2,
							["name"] = "Retry",
							["onClick"] = nil,
							["parent"] = v_u_51,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_36
								v_u_36.load(true)
							end
						}
						v_u_31.btn(v142)
					elseif v_u_40 == "retry" then
						v_u_30.empty(v_u_51, v_u_32.UI.LOAD_RETRY, 1)
					else
						v_u_31.skeleton(v_u_51, 4, v_u_33.boardRowH)
					end
					local v143 = v_u_56
					local v144 = v_u_57
					local v145 = v_u_58
					v_u_55.Text = ""
					v143.Text = ""
					v144.Text = ""
					v145.Text = ""
					return
				else
					local v146
					if v_u_52 then
						v146 = v_u_52
					else
						v146 = v_u_51
					end
					if v_u_38 == "week" then
						local v147 = v_u_39.rows
						local v148 = type(v147) ~= "table" and {} or v_u_39.rows
						if #v148 == 0 then
							local v149 = v_u_31.card(v_u_51, "BoardEmpty", {
								["x"] = 0,
								["y"] = 0,
								["w"] = nil,
								["h"] = 96,
								["w"] = v_u_47 - 6
							}, {
								["transparency"] = 0.5,
								["order"] = 1
							})
							v149.Size = UDim2.new(1, -6, 0, 96)
							v_u_27.label({
								["parent"] = nil,
								["name"] = "Hint",
								["text"] = "Nobody is on the board yet. Extract with your clan to be the first.",
								["style"] = "body",
								["color"] = nil,
								["wrap"] = true,
								["valign"] = "center",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v149,
								["color"] = v_u_29.text2,
								["position"] = UDim2.fromOffset(16, 8),
								["size"] = UDim2.new(1, -32, 1, -16)
							})
						end
						for v150, v151 in v148 do
							if type(v151) ~= "table" then
								continue
							end
							v_u_110(v_u_51, v150, v151, v151.id == v_u_141)
						end
						if v_u_39.live == false then
							v_u_30.empty(v_u_51, "Showing the last known board.", 500)
						end
						v_u_128(v146, v_u_52 and 1 or 1000)
					else
						local v152 = v_u_39.last
						local v153 = type(v152) ~= "table" and {} or v_u_39.last
						local v154 = v153.top3
						local v155 = type(v154) ~= "table" and {} or v153.top3
						if #v155 == 0 then
							v_u_30.empty(v_u_51, "Last week\'s board is not final yet.", 1)
						end
						for v156, v157 in v155 do
							if type(v157) ~= "table" then
								continue
							end
							v_u_110(v_u_51, v156, v157, v157.id == v_u_141)
						end
						v_u_140(v146, v153, v_u_52 and 1 or 100)
					end
				end
			end)
			local v158 = p_u_25.clan()
			local v159 = v_u_39
			local v160
			if type(v159) == "table" then
				local v161 = v_u_39.mine
				v160 = type(v161) ~= "table" and {} or v_u_39.mine
			else
				v160 = {}
			end
			local v162
			if v_u_38 == "week" then
				v162 = v158 ~= nil
			else
				v162 = false
			end
			if v162 and not v_u_33.twoCol then
				local v163 = v_u_39
				if type(v163) == "table" then
					local v164 = v_u_39.rows
					if type(v164) == "table" then
						for _, v165 in v_u_39.rows do
							if type(v165) ~= "table" or v165.id ~= v_u_141 then
								continue
							end
							v162 = false
						end
					end
				end
			end
			v_u_53.Visible = v162
			local v166 = v_u_51
			local v167
			if v162 or v_u_33.twoCol then
				v167 = UDim2.new(1, 0, 1, -68)
			else
				v167 = UDim2.fromScale(1, 1)
			end
			v166.Size = v167
			local v168 = v_u_53:FindFirstChild("MyRankChip")
			if v168 then
				v168:Destroy()
			end
			if v158 then
				v_u_56.Text = v_u_31.label(v158.tag, v158.name)
				local v169 = v_u_55
				local v170
				if v160.rank then
					local v171 = v160.rank
					v170 = ("#%d"):format(tonumber(v171) or 0)
				else
					v170 = "-"
				end
				v169.Text = v170
				local v172 = v_u_57
				local v173
				if v160.needActive then
					v173 = v_u_32.UI.NEEDS_ACTIVE
				else
					v173 = v160.rank and "Your clan" or "Not ranked yet"
				end
				v172.Text = v173
				local v174 = v_u_58
				local v175 = v_u_27.commas
				local v176 = v160.pts
				v174.Text = v175(tonumber(v176) or 0)
				local v177 = v_u_35.rankChipText(v158, v158.rank)
				local v178 = v_u_34.chipW(v177)
				local v179 = v_u_54.name.x + v_u_54.name.w - v_u_54.tag.x
				local v180 = v_u_54.sub.x + v_u_54.sub.w - v_u_54.tag.x
				v_u_56.Size = UDim2.fromOffset(v179, v_u_54.name.h)
				v_u_57.Size = UDim2.fromOffset(v180, v_u_54.sub.h)
				if v_u_54.name.x + 120 + v178 + 8 < v_u_54.pts.x then
					local v181 = v_u_54.pts.x - v178 - 12 - v_u_54.tag.x
					v_u_56.Size = UDim2.fromOffset(math.min(v179, v181), v_u_54.name.h)
					v_u_57.Size = UDim2.fromOffset(math.min(v180, v181), v_u_54.sub.h)
					v_u_31.pill(v_u_53, "MyRankChip", v177, v_u_35.rankColor(v158.rank), {
						["x"] = nil,
						["y"] = 19,
						["w"] = nil,
						["h"] = 22,
						["x"] = v_u_54.pts.x - v178 - 8,
						["w"] = v178
					})
				end
			end
		end
	end
	function v_u_36.load(_) -- name: load
		-- upvalues: (ref) v_u_41, (ref) v_u_37, (ref) v_u_39, (ref) v_u_40, (copy) v_u_36, (copy) p_u_25, (ref) v_u_42
		if not v_u_41 and v_u_37 then
			v_u_41 = true
			if v_u_39 == nil then
				v_u_40 = "loading"
				v_u_36.draw()
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_37, (ref) v_u_41, (ref) p_u_25, (ref) v_u_39, (ref) v_u_40, (ref) v_u_36, (ref) v_u_42
				local v182 = nil
				for v183 = 0, 3 do
					if v183 > 0 then
						task.wait(2 ^ (v183 - 1) * 3)
						if not v_u_37 then
							v_u_41 = false
							return
						end
					end
					v182 = p_u_25.fetch("clanBoard", nil, 0)
					if v182 ~= nil then
						break
					end
					if v_u_39 ~= nil then
						continue
					end
					v_u_40 = v183 < 3 and "retry" or "gave_up"
					v_u_36.draw()
				end
				v_u_41 = false
				if v_u_37 then
					if v182 ~= nil then
						v_u_39 = v182
						v_u_40 = nil
						local v184 = os.clock()
						local v185 = v182.resetIn
						v_u_42 = v184 + (tonumber(v185) or 0)
					end
					v_u_36.draw()
				end
			end)
		end
	end
	function v_u_36.show() -- name: show
		-- upvalues: (ref) v_u_43, (copy) v_u_36
		v_u_43 = true
		v_u_36.draw()
		v_u_36.load()
	end
	function v_u_36.hide() -- name: hide
		-- upvalues: (ref) v_u_43
		v_u_43 = false
	end
	function v_u_36.refresh(p186) -- name: refresh
		-- upvalues: (copy) v_u_36
		if p186 == "state" then
			v_u_36.draw()
		end
	end
	function v_u_36.tick() -- name: tick
		-- upvalues: (ref) v_u_45, (ref) v_u_39, (ref) v_u_42, (ref) v_u_38, (copy) v_u_32
		local v187 = v_u_45
		if v187 and (v_u_39 and (v_u_42 > 0 and v_u_38 == "week")) then
			local v188 = v_u_32.timeText
			local v189 = v_u_42 - os.clock()
			v187.Text = "Resets in " .. v188((math.max(0, v189)))
		elseif v187 then
			v187.Text = ""
		end
	end
	function v_u_36.destroy() -- name: destroy
		-- upvalues: (ref) v_u_37
		v_u_37 = false
	end
	return v_u_36
end
return v_u_1