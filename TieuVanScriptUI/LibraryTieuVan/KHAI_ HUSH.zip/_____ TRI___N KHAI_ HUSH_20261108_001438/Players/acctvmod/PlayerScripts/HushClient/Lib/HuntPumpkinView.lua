-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntPumpkinView

local v_u_12 = {
	["MAX"] = 24,
	["SPARKS"] = 10,
	["SPARK_LIFE"] = 0.55,
	["TURN"] = 0.7,
	["BOB"] = 0.22,
	["WIDTH"] = 3.1,
	["LOOK_DROP"] = 1.3,
	["diff"] = function(p1, p2) -- name: diff
		local v3 = {}
		local v4 = {}
		local v5 = {}
		if type(p2) == "table" then
			for _, v6 in p2 do
				if type(v6) ~= "table" then
					continue
				end
				local v7 = v6.i
				if type(v7) ~= "number" or (v6.i ~= v6.i or v3[v6.i] ~= nil) then
					continue
				end
				v3[v6.i] = true
				if p1[v6.i] ~= nil then
					continue
				end
				local v8 = v6.i
				table.insert(v4, v8)
			end
		end
		for v9 in p1 do
			if v3[v9] ~= nil then
				continue
			end
			table.insert(v5, v9)
		end
		table.sort(v4)
		table.sort(v5)
		return v4, v5
	end,
	["alpha"] = function(p10) -- name: alpha
		local v11 = (type(p10) ~= "number" or p10 ~= p10) and 1 or p10
		return 1 - math.clamp(v11, 0, 1)
	end
}
local v_u_13 = Color3.fromRGB(226, 104, 18)
local v_u_14 = Color3.fromRGB(176, 72, 12)
local v_u_15 = Color3.fromRGB(70, 92, 38)
local v_u_16 = Color3.fromRGB(255, 190, 70)
local function v_u_23(p17, p18, p19, p20, p21) -- name: part
	local v22 = Instance.new("Part")
	v22.Name = p18
	v22.Size = p19
	v22.Color = p20
	v22.Material = p21 or Enum.Material.SmoothPlastic
	v22.Anchored = true
	v22.CanCollide = false
	v22.CanQuery = false
	v22.CanTouch = false
	v22.CastShadow = false
	v22.TopSurface = Enum.SurfaceType.Smooth
	v22.BottomSurface = Enum.SurfaceType.Smooth
	v22.Parent = p17
	return v22
end
local function v_u_55(p24, p25, p26) -- name: build
	-- upvalues: (copy) v_u_12, (copy) v_u_23, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16
	local v27 = Instance.new("Model")
	v27.Name = "HuntPumpkin" .. tostring(p25)
	local v28 = {}
	if p26 ~= nil then
		local v29 = p26:Clone()
		v29.Name = "Look"
		for _, v30 in v29:GetDescendants() do
			if v30:IsA("BasePart") then
				v30.Anchored = true
				v30.CanCollide = false
				v30.CanQuery = false
				v30.CanTouch = false
				v30.CastShadow = false
				local v31 = {
					["part"] = v30,
					["off"] = CFrame.new(),
					["glow"] = v30.Material == Enum.Material.Neon
				}
				table.insert(v28, v31)
			else
				if not (v30:IsA("Script") or (v30:IsA("LocalScript") or v30:IsA("ProximityPrompt"))) then
					continue
				end
				v30:Destroy()
			end
		end
		local v32 = nil
		if v29:IsA("Model") then
			local v33 = tonumber(v29:GetAttribute("HuntScale"))
			if v33 == nil or (v33 ~= v33 or v33 <= 0) then
				local _, v34 = v29:GetBoundingBox()
				local v35 = v_u_12.WIDTH
				local v36 = v34.X
				local v37 = v34.Z
				v33 = v35 / math.max(0.1, v36, v37)
			end
			v29:ScaleTo(v29:GetScale() * math.clamp(v33, 0.2, 8))
			v32 = v29
		elseif v29:IsA("BasePart") then
			v29.Anchored = true
			v29.CanCollide = false
			v29.CanQuery = false
			v29.CanTouch = false
			v29.CastShadow = false
			local v38 = {
				["part"] = nil,
				["off"] = nil,
				["glow"] = false,
				["part"] = v29,
				["off"] = CFrame.new()
			}
			table.insert(v28, v38)
		end
		v29.Parent = v27
		local v39 = v29:FindFirstChild("Body", true)
		local v40
		if v39 == nil or not v39:IsA("BasePart") then
			v40 = nil
		else
			local v41 = Instance.new("Attachment")
			v41.Name = "CandleAt"
			local v42 = -(v39.Size.Z * 0.5 + 0.4)
			v41.Position = Vector3.new(0, 0, v42)
			v41.Parent = v39
			v40 = Instance.new("PointLight")
			v40.Color = Color3.fromRGB(255, 150, 50)
			v40.Range = 12
			v40.Brightness = 1.4
			v40.Shadows = false
			v40.Parent = v41
		end
		v27.Parent = p24
		return {
			["model"] = nil,
			["parts"] = nil,
			["light"] = nil,
			["template"] = true,
			["look"] = nil,
			["model"] = v27,
			["parts"] = v28,
			["light"] = v40,
			["look"] = v32
		}
	end
	local v43 = v_u_23(v27, "Body", Vector3.new(3.1, 2.6, 3.1), v_u_13)
	v43.Shape = Enum.PartType.Ball
	local v44 = {
		["part"] = nil,
		["off"] = nil,
		["glow"] = false,
		["part"] = v43,
		["off"] = CFrame.new()
	}
	table.insert(v28, v44)
	for v45, v46 in { 0, 1.0471975511965976, 2.0943951023931953 } do
		local v47 = v_u_23(v27, "Ridge" .. v45, Vector3.new(3.14, 2.5, 0.5), v_u_14)
		v47.Shape = Enum.PartType.Ball
		local v48 = {
			["part"] = nil,
			["off"] = nil,
			["glow"] = false,
			["part"] = v47,
			["off"] = CFrame.Angles(0, v46, 0)
		}
		table.insert(v28, v48)
	end
	local v49 = {
		["part"] = nil,
		["off"] = nil,
		["glow"] = false,
		["part"] = v_u_23(v27, "Stem", Vector3.new(0.45, 0.9, 0.45), v_u_15),
		["off"] = CFrame.new(0.1, 1.45, 0) * CFrame.Angles(0, 0, 0.20943951023931956)
	}
	table.insert(v28, v49)
	for v50, v51 in { -0.7, 0.7 } do
		local v52 = {
			["part"] = nil,
			["off"] = nil,
			["glow"] = true,
			["part"] = v_u_23(v27, "Eye" .. v50, Vector3.new(0.55, 0.55, 0.3), v_u_16, Enum.Material.Neon),
			["off"] = CFrame.new(v51, 0.35, -1.45)
		}
		table.insert(v28, v52)
	end
	local v53 = {
		["part"] = nil,
		["off"] = nil,
		["glow"] = true,
		["part"] = v_u_23(v27, "Mouth", Vector3.new(1.5, 0.35, 0.3), v_u_16, Enum.Material.Neon),
		["off"] = CFrame.new(0, -0.45, -1.42)
	}
	table.insert(v28, v53)
	local v54 = Instance.new("PointLight")
	v54.Color = Color3.fromRGB(255, 150, 50)
	v54.Range = 12
	v54.Brightness = 1.4
	v54.Shadows = false
	v54.Parent = v43
	v27.PrimaryPart = v43
	v27.Parent = p24
	return {
		["model"] = nil,
		["parts"] = nil,
		["light"] = nil,
		["template"] = false,
		["model"] = v27,
		["parts"] = v28,
		["light"] = v54
	}
end
function v_u_12.new(p_u_56) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_23, (copy) v_u_16, (copy) v_u_13, (copy) v_u_55
	local v_u_57 = {}
	local v_u_58 = Instance.new("Folder")
	v_u_58.Name = "HuntPumpkinsLocal"
	v_u_58.Parent = p_u_56.parent or workspace
	local v_u_59 = {}
	local v_u_60 = {}
	local v_u_61 = true
	local v_u_62 = 0
	local function v_u_78(p63) -- name: burst
		-- upvalues: (ref) v_u_12, (copy) v_u_60, (ref) v_u_23, (copy) v_u_58, (ref) v_u_16, (ref) v_u_13
		for v64 = 1, v_u_12.SPARKS do
			if #v_u_60 >= 40 then
				break
			end
			local v65 = v_u_23
			local v66 = v_u_58
			local v67 = "Spark"
			local v68 = Vector3.new(0.3, 0.3, 0.3)
			local v69
			if v64 % 2 == 0 then
				v69 = v_u_16
			else
				v69 = v_u_13
			end
			local v70 = v65(v66, v67, v68, v69, Enum.Material.Neon)
			v70.Shape = Enum.PartType.Ball
			local v71 = v64 / v_u_12.SPARKS * 3.141592653589793 * 2
			local v72 = math.cos(v71) * 7
			local v73 = v64 % 3 * 2 + 8
			local v74 = math.sin(v71) * 7
			local v75 = Vector3.new(v72, v73, v74)
			v70.Position = p63
			local v76 = v_u_60
			local v77 = {
				["part"] = v70,
				["vel"] = v75,
				["life"] = v_u_12.SPARK_LIFE
			}
			table.insert(v76, v77)
		end
	end
	function v_u_57.apply(p79) -- name: apply
		-- upvalues: (ref) v_u_61, (ref) v_u_12, (copy) v_u_59, (copy) v_u_57, (ref) v_u_55, (copy) v_u_58, (copy) p_u_56, (ref) v_u_62, (copy) v_u_78
		if not v_u_61 or type(p79) ~= "table" then
			return
		end
		local v80, v81 = v_u_12.diff(v_u_59, p79.list)
		for _, v82 in v81 do
			local v83 = v_u_59[v82]
			if v83 == nil then
				continue
			end
			v_u_59[v82] = nil
			if not v83.model then
				continue
			end
			v83.model:Destroy()
		end
		local v84 = {}
		local v85 = p79.list
		if type(v85) == "table" then
			for _, v86 in p79.list do
				if type(v86) ~= "table" then
					continue
				end
				local v87 = v86.i
				if type(v87) ~= "number" then
					continue
				end
				v84[v86.i] = v86
			end
		end
		for _, v88 in v80 do
			if v_u_57.count() >= v_u_12.MAX then
				break
			end
			local v89 = v84[v88]
			if not v89 then
				continue
			end
			local v90 = v89.x
			if type(v90) ~= "number" then
				continue
			end
			local v91 = v89.y
			if type(v91) ~= "number" then
				continue
			end
			local v92 = v89.z
			if type(v92) ~= "number" then
				continue
			end
			local v93 = v_u_55(v_u_58, v88, p_u_56.template)
			local v94 = v89.x
			local v95 = v89.y
			local v96 = v89.z
			v93.pos = Vector3.new(v94, v95, v96)
			v93.born = v_u_62
			v93.vis = 0
			v93.yaw = v88 * 1.7 % 6.283185307179586
			v_u_59[v88] = v93
		end
		local v97 = p79.got
		if type(v97) == "table" then
			local v98 = p79.got.x
			if type(v98) == "number" then
				local v99 = p79.got.z
				if type(v99) == "number" then
					local v100 = p79.got.x
					local v101 = p79.got.y
					local v102 = tonumber(v101) or 0
					local v103 = p79.got.z
					local v104 = Vector3.new(v100, v102, v103)
					v_u_78(v104)
					local v105 = p_u_56.play
					if type(v105) == "function" then
						local v106 = p_u_56.play
						pcall(v106, v104)
					end
				end
			end
		end
	end
	function v_u_57.step(p107) -- name: step
		-- upvalues: (ref) v_u_61, (ref) v_u_62, (copy) v_u_59, (copy) p_u_56, (ref) v_u_12, (copy) v_u_60
		if v_u_61 then
			v_u_62 = v_u_62 + p107
			for _, v108 in v_u_59 do
				local v109 = 1
				local v110 = p_u_56.vis
				local v111
				if type(v110) == "function" then
					local v112 = p_u_56.vis
					local v113 = v108.pos
					local v114
					v114, v111 = pcall(v112, v113)
					if v114 then
						if type(v111) ~= "number" then
							v111 = v109
						end
					else
						v111 = v109
					end
				else
					v111 = v109
				end
				local v115 = (v_u_62 - v108.born) / 0.25
				local v116 = math.clamp(v115, 0, 1)
				local v117 = v_u_12.alpha(v111 * v116)
				local v118 = v_u_62 * 2 + v108.yaw
				local v119 = math.sin(v118) * v_u_12.BOB
				local v120 = CFrame.new
				local v121 = v108.pos
				local v122 = v119 - 0.1
				local v123 = v120(v121 + Vector3.new(0, v122, 0)) * CFrame.Angles(0, v108.yaw + v_u_62 * v_u_12.TURN, 0)
				if v108.template then
					if v108.look ~= nil and v108.look.Parent ~= nil then
						v108.look:PivotTo(v123 * CFrame.new(0, -v_u_12.LOOK_DROP, 0))
					end
					for _, v124 in v108.parts do
						if v124.part.Parent == nil then
							continue
						end
						if v108.look == nil then
							v124.part.CFrame = v123 * v124.off
						end
						v124.part.LocalTransparencyModifier = v117
					end
				else
					for _, v125 in v108.parts do
						if v125.part.Parent == nil then
							continue
						end
						v125.part.CFrame = v123 * v125.off
						v125.part.Transparency = v117
					end
				end
				if not v108.light then
					continue
				end
				v108.light.Brightness = 1.4 * (1 - v117)
			end
			local v126 = 1
			while v126 <= #v_u_60 do
				local v127 = v_u_60[v126]
				v127.life = v127.life - p107
				if v127.life <= 0 or v127.part.Parent == nil then
					v127.part:Destroy()
					table.remove(v_u_60, v126)
				else
					local v128 = v127.vel
					local v129 = p107 * -26
					v127.vel = v128 + Vector3.new(0, v129, 0)
					local v130 = v127.part
					v130.Position = v130.Position + v127.vel * p107
					local v131 = v127.part
					local v132 = v127.life / v_u_12.SPARK_LIFE
					v131.Transparency = 1 - math.clamp(v132, 0, 1)
					v126 = v126 + 1
				end
			end
		end
	end
	function v_u_57.count() -- name: count
		-- upvalues: (copy) v_u_59
		local v133 = 0
		for _ in v_u_59 do
			v133 = v133 + 1
		end
		return v133
	end
	function v_u_57.ids() -- name: ids
		-- upvalues: (copy) v_u_59
		local v134 = {}
		for v135 in v_u_59 do
			table.insert(v134, v135)
		end
		table.sort(v134)
		return v134
	end
	function v_u_57.sparks() -- name: sparks
		-- upvalues: (copy) v_u_60
		return #v_u_60
	end
	function v_u_57.clear() -- name: clear
		-- upvalues: (copy) v_u_59, (copy) v_u_60
		for v136 in v_u_59 do
			local v137 = v_u_59[v136]
			if v137 == nil then
				continue
			end
			v_u_59[v136] = nil
			if not v137.model then
				continue
			end
			v137.model:Destroy()
		end
		for _, v138 in v_u_60 do
			v138.part:Destroy()
		end
		table.clear(v_u_60)
	end
	function v_u_57.destroy() -- name: destroy
		-- upvalues: (ref) v_u_61, (copy) v_u_57, (copy) v_u_58
		v_u_61 = false
		v_u_57.clear()
		v_u_58:Destroy()
	end
	v_u_57.folder = v_u_58
	return v_u_57
end
return v_u_12