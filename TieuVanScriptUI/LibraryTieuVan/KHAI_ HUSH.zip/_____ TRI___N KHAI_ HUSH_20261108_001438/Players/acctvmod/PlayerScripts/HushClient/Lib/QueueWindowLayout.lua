-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / QueueWindowLayout

local v_u_62 = {
	["WIDTH"] = 520,
	["PAD"] = 24,
	["TOP"] = 24,
	["TITLE"] = 32,
	["TITLE_GAP"] = 16,
	["GAP"] = 8,
	["BULLET"] = 18,
	["BODY"] = 15,
	["LINE"] = 20,
	["RULE"] = 1,
	["BODY_BOTTOM"] = 3,
	["FOOT_TOP"] = 13,
	["FOOT_BOTTOM"] = 24,
	["BTN_W"] = 140,
	["BTN_GAP"] = 8,
	["MIN_PANEL"] = 280,
	["limits"] = function(p1, p2, p3, p4) -- name: limits
		local v5 = p4 or {
			["l"] = 0,
			["r"] = 0,
			["t"] = 0,
			["b"] = 0
		}
		local v6 = p2 - v5.l - v5.r - 32
		local v7 = math.min(p1, v6)
		local v8 = p3 * 0.9
		local v9 = p3 - v5.t - v5.b - 16
		local v10 = math.min(v8, v9)
		return v7, math.floor(v10)
	end,
	["bodyWidth"] = function(p11, p12, p13, p14) -- name: bodyWidth
		-- upvalues: (copy) v_u_62
		return v_u_62.limits(p11, p12, p13, p14) - 2 * v_u_62.PAD
	end,
	["lines"] = function(p15, p16, p17) -- name: lines
		local v18 = (utf8.len(p15) or #p15) * p16 * 0.6
		local v19 = p17 * 0.92
		local v20 = v18 / math.max(40, v19)
		local v21 = math.ceil(v20)
		return math.max(1, v21)
	end,
	["layout"] = function(p22, p23, p24) -- name: layout
		-- upvalues: (copy) v_u_62
		local v25 = p24.width
		local v26
		if type(v25) == "number" then
			v26 = p24.width
		else
			v26 = v_u_62.WIDTH
		end
		local v27, v28 = v_u_62.limits(v26, p22, p23, p24.safe)
		local v29 = v27 - 2 * v_u_62.PAD
		local v30 = v_u_62.TOP
		local v31 = {
			["w"] = v27,
			["maxH"] = v28,
			["bodyW"] = v29,
			["title"] = {
				["x"] = v_u_62.PAD,
				["y"] = v30,
				["w"] = v29,
				["h"] = v_u_62.TITLE
			}
		}
		local v32 = v30 + (v_u_62.TITLE + v_u_62.TITLE_GAP)
		local v33 = v32
		local v34 = v29 - v_u_62.BULLET
		v31.bullets = {}
		v31.lines = {}
		for _, v35 in p24.bullets do
			local v36 = v_u_62.lines(v35, v_u_62.BODY, v34)
			local v37 = v31.lines
			table.insert(v37, v36)
			local v38 = v31.bullets
			local v39 = v36 * v_u_62.LINE
			local v40 = {
				["x"] = v_u_62.PAD,
				["y"] = v32,
				["w"] = v29,
				["h"] = v39
			}
			v32 = v32 + (v39 + v_u_62.GAP)
			table.insert(v38, v40)
		end
		local v41 = p24.optionsH
		if type(v41) == "function" then
			v41 = v41(v29)
		end
		local v42 = (type(v41) ~= "number" or v41 <= 0) and 0 or v41
		local v43 = p24.inputH
		if type(v43) == "function" then
			v43 = v43(v29)
		end
		local v44 = (type(v43) ~= "number" or v43 <= 0) and 0 or v43
		if v42 > 0 or v44 > 0 then
			local v45 = v_u_62.RULE
			local v46 = {
				["x"] = v_u_62.PAD,
				["y"] = v32,
				["w"] = v29,
				["h"] = v45
			}
			v32 = v32 + (v45 + v_u_62.GAP)
			v31.rule = v46
		end
		if v42 > 0 then
			local v47 = {
				["x"] = v_u_62.PAD,
				["y"] = v32,
				["w"] = v29,
				["h"] = v42
			}
			v32 = v32 + (v42 + v_u_62.GAP)
			v31.options = v47
		end
		if v44 > 0 then
			local v48 = {
				["x"] = v_u_62.PAD,
				["y"] = v32,
				["w"] = v29,
				["h"] = v44
			}
			v32 = v32 + (v44 + v_u_62.GAP)
			v31.input = v48
		end
		v31.contentH = v32 - v_u_62.GAP - v33
		v31.canvasH = v32 - v_u_62.GAP + v_u_62.BODY_BOTTOM
		local v49 = p24.buttonH
		local v50 = type(v49) ~= "number" and 40 or p24.buttonH
		v31.footH = v_u_62.FOOT_TOP + v50 + v_u_62.FOOT_BOTTOM
		v31.natural = v31.canvasH + v31.footH
		v31.scroll = v28 < v31.natural
		local v51 = v31.natural
		v31.h = math.min(v51, v28)
		v31.bodyH = v31.h - v31.footH
		local v52 = p24.buttons
		local v53
		if type(v52) == "number" then
			local v54 = p24.buttons
			local v55 = math.floor(v54)
			v53 = math.max(0, v55)
		else
			v53 = 1
		end
		v31.buttons = {}
		local v56 = v53 * v_u_62.BTN_W
		local v57 = v53 - 1
		local v58 = v56 + math.max(0, v57) * v_u_62.BTN_GAP
		for v59 = 1, v53 do
			local v60 = v31.buttons
			local v61 = {
				["x"] = v27 - v_u_62.PAD - v58 + (v59 - 1) * (v_u_62.BTN_W + v_u_62.BTN_GAP),
				["y"] = v31.h - v_u_62.FOOT_BOTTOM - v50,
				["w"] = v_u_62.BTN_W,
				["h"] = v50
			}
			table.insert(v60, v61)
		end
		return v31
	end
}
return v_u_62