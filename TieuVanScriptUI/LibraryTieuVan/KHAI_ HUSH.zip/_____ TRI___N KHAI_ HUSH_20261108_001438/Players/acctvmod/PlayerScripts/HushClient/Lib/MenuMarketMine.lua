-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketMine

local v_u_517 = {
	["EVERY"] = 20,
	["VERBS"] = {
		["l"] = "Listed",
		["b"] = "Bought",
		["s"] = "Sold",
		["c"] = "Cancelled",
		["e"] = "Expired",
		["r"] = "Refunded",
		["x"] = "Not listed"
	},
	["new"] = function(p_u_1, p2) -- name: new
		-- upvalues: (copy) v_u_517
		local v_u_3 = p_u_1.ui
		local _ = p_u_1.theme
		local v_u_4 = p_u_1.C
		local v_u_5 = p_u_1.Data
		local v_u_6 = p_u_1.data
		local v_u_7 = p_u_1.h
		local v_u_8 = p_u_1.kit
		local v9 = p_u_1.compact
		local v_u_10 = {}
		local v_u_11 = true
		local v_u_12 = false
		local v_u_13 = nil
		local v_u_14 = "loading"
		local v_u_15 = 0
		local v_u_16 = {}
		local v_u_17 = {}
		local v_u_18 = false
		local v_u_19 = 0
		local v20 = p_u_1.controlFrame("mine")
		local _, _ = v_u_7.button(v20, "Refresh", "secondary", function()
			-- upvalues: (copy) v_u_10
			v_u_10.load(true)
		end, {
			["name"] = "Refresh",
			["height"] = 40,
			["width"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 100,
			["width"] = v9 and 92 or 120,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, 0, 0.5, 0)
		})
		local _, v_u_21 = v_u_7.button(v20, "Claim all", "primary", function()
			-- upvalues: (copy) v_u_10
			v_u_10.claimAll()
		end, {
			["name"] = "ClaimAll",
			["height"] = 40,
			["width"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 140,
			["width"] = v9 and 104 or 150,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -((v9 and 92 or 120) + 8), 0.5, 0)
		})
		v_u_21.setEnabled(false)
		local v_u_22 = v_u_3.list({
			["parent"] = nil,
			["name"] = "Rows",
			["size"] = nil,
			["gap"] = 8,
			["padding"] = nil,
			["parent"] = p2,
			["size"] = UDim2.fromScale(1, 1),
			["padding"] = {
				0,
				8,
				0,
				10
			}
		})
		local v_u_23 = v9 and 64 or 60
		local function v_u_25() -- name: clear
			-- upvalues: (copy) v_u_22, (copy) v_u_17
			for _, v24 in v_u_22:GetChildren() do
				if v24:IsA("UIListLayout") or v24:IsA("UIPadding") then
					continue
				end
				v24:Destroy()
			end
			table.clear(v_u_17)
		end
		local function v_u_27(p26) -- name: nameOf
			-- upvalues: (copy) v_u_8
			return v_u_8.itemName(p26)
		end
		local function v_u_31(p28, p29) -- name: row
			-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_23, (copy) v_u_22
			local v30 = v_u_3.new("Frame", {
				["Name"] = "Row",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_4.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_23),
				["LayoutOrder"] = p28
			}, v_u_22)
			v_u_3.stroke(v30, p29 or v_u_4.line)
			return v30
		end
		local function v_u_43(p32, p33, p34, p35, p36) -- name: texts
			-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_23
			local v37 = v_u_3.label
			local v38 = {
				["parent"] = nil,
				["name"] = "L1",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = p32,
				["text"] = p33,
				["color"] = p35 or v_u_4.text
			}
			local v39 = UDim2.fromOffset
			local v40 = 12
			local v41
			if p34 then
				v41 = 6
			else
				local v42 = (v_u_23 - 22) / 2
				v41 = math.floor(v42)
			end
			v38.position = v39(v40, v41)
			v38.size = UDim2.new(1, -(p36 + 12), 0, 22)
			v37(v38)
			if p34 then
				v_u_3.label({
					["parent"] = nil,
					["name"] = "L2",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = p32,
					["text"] = p34,
					["color"] = v_u_4.text2,
					["position"] = UDim2.fromOffset(12, 30),
					["size"] = UDim2.new(1, -(p36 + 12), 0, 18)
				})
			end
		end
		local function v_u_52(p44) -- name: claimedToast
			-- upvalues: (copy) v_u_3, (copy) v_u_5
			if p44.ok and p44.data then
				local v45 = p44.data.cash or 0
				local v46 = p44.data.items or 0
				if v45 > 0 then
					local v47 = v_u_3.toast
					local v48 = ("Claimed %s."):format(v_u_5.money(v45))
					pcall(v47, v48, "success")
					return
				end
				if v46 > 0 then
					local v49 = v_u_3.toast
					pcall(v49, "Your items are back in your stash.", "success")
					return
				end
			elseif not p44.ok then
				local v50 = v_u_3.toast
				local v51 = p44.text
				pcall(v50, v51, "warn")
			end
		end
		function v_u_10.claimAll() -- name: claimAll
			-- upvalues: (copy) v_u_6, (copy) v_u_52, (ref) v_u_18, (ref) v_u_11, (copy) p_u_1, (copy) v_u_10
			local function v_u_53()
				-- upvalues: (ref) v_u_6
				return v_u_6:claim({})
			end
			local v_u_54 = v_u_52
			if not v_u_18 then
				v_u_18 = true
				task.spawn(function()
					-- upvalues: (copy) v_u_53, (ref) v_u_18, (ref) v_u_11, (copy) v_u_54, (ref) p_u_1, (ref) v_u_10
					local v55 = v_u_53()
					v_u_18 = false
					if v_u_11 then
						if v_u_54 then
							v_u_54(v55)
						end
						p_u_1.refreshState(true)
						v_u_10.load(true)
					end
				end)
			end
		end
		function v_u_10.claimOne(p_u_56) -- name: claimOne
			-- upvalues: (copy) v_u_6, (copy) v_u_52, (ref) v_u_18, (ref) v_u_11, (copy) p_u_1, (copy) v_u_10
			local function v_u_57()
				-- upvalues: (ref) v_u_6, (copy) p_u_56
				return v_u_6:claim({
					["lid"] = p_u_56
				})
			end
			local v_u_58 = v_u_52
			if not v_u_18 then
				v_u_18 = true
				task.spawn(function()
					-- upvalues: (copy) v_u_57, (ref) v_u_18, (ref) v_u_11, (copy) v_u_58, (ref) p_u_1, (ref) v_u_10
					local v59 = v_u_57()
					v_u_18 = false
					if v_u_11 then
						if v_u_58 then
							v_u_58(v59)
						end
						p_u_1.refreshState(true)
						v_u_10.load(true)
					end
				end)
			end
		end
		function v_u_10.cancel(p_u_60) -- name: cancel
			-- upvalues: (ref) v_u_13, (copy) v_u_6, (copy) v_u_3, (copy) v_u_10, (ref) v_u_18, (ref) v_u_11, (copy) p_u_1, (copy) v_u_5, (copy) v_u_27, (copy) v_u_8, (copy) v_u_4
			local v_u_61 = nil
			for _, v62 in v_u_13 and v_u_13.live or {} do
				if v62.lid ~= p_u_60 then
					continue
				end
				v_u_61 = v62
			end
			if v_u_61 then
				local v69 = {
					{
						["text"] = "Keep listing",
						["kind"] = "secondary"
					},
					{
						["text"] = "Cancel listing",
						["kind"] = "danger",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_6, (copy) p_u_60, (ref) v_u_3, (ref) v_u_10, (ref) v_u_18, (ref) v_u_11, (ref) p_u_1
							local function v_u_63()
								-- upvalues: (ref) v_u_6, (ref) p_u_60
								return v_u_6:cancel({
									["lid"] = p_u_60
								})
							end
							local function v_u_67(p64)
								-- upvalues: (ref) v_u_3, (ref) v_u_10, (ref) p_u_60
								if p64.ok then
									v_u_10.dropLive(p_u_60)
								else
									local v65 = v_u_3.toast
									local v66 = p64.text
									pcall(v65, v66, "warn")
								end
							end
							if not v_u_18 then
								v_u_18 = true
								task.spawn(function()
									-- upvalues: (copy) v_u_63, (ref) v_u_18, (ref) v_u_11, (copy) v_u_67, (ref) p_u_1, (ref) v_u_10
									local v68 = v_u_63()
									v_u_18 = false
									if v_u_11 then
										if v_u_67 then
											v_u_67(v68)
										end
										p_u_1.refreshState(true)
										v_u_10.load(true)
									end
								end)
							end
							return false
						end
					}
				}
				local v70 = p_u_1.state
				local v71
				if type(v70) == "table" then
					v71 = v70.allow
				else
					v71 = nil
				end
				local v_u_72 = "when the next day starts (00:00 UTC)"
				if type(v71) == "table" then
					local v73 = v71.resetIn
					if type(v73) == "number" then
						local v74 = v_u_5.left({
							["resetIn"] = v71.resetIn,
							["_at"] = v70._at
						}, "resetIn", v_u_6:clock())
						v_u_72 = ("when the next day starts, in %s (00:00 UTC)"):format(v_u_5.duration(v74))
					end
				end
				local v_u_75
				if type(v70) == "table" and v_u_5.listOn(v70.list) then
					v_u_75 = v_u_5.TEXT.cancelFeeNote
				else
					v_u_75 = nil
				end
				v_u_10.cancelButtons = v69
				local v83 = {
					["title"] = "Cancel listing",
					["width"] = 480,
					["build"] = nil,
					["buttons"] = nil,
					["build"] = function(p76) -- name: build
						-- upvalues: (ref) v_u_3, (ref) v_u_61, (ref) v_u_27, (ref) v_u_8, (ref) v_u_4, (ref) v_u_72, (copy) v_u_75
						local v77 = v_u_3.label
						local v78 = {
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 1,
							["parent"] = p76
						}
						local v79 = "Cancel the listing of %s?"
						local v80 = v_u_61.id
						local v81 = v_u_61.n
						local v82
						if v81 > 1 then
							v82 = ("%d x %s"):format(v81, v_u_27(v80))
						else
							v82 = v_u_8.itemName(v80)
						end
						v78.text = v79:format(v82)
						v78.color = v_u_4.text
						v77(v78)
						v_u_3.label({
							["parent"] = nil,
							["text"] = "The item comes back to your stash.",
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["parent"] = p76,
							["color"] = v_u_4.text2
						})
						v_u_3.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 3,
							["parent"] = p76,
							["text"] = ("This listing slot is used up for today and does NOT come back. You get new slots %s."):format(v_u_72),
							["color"] = v_u_4.text
						})
						if v_u_75 ~= nil then
							v_u_3.label({
								["parent"] = nil,
								["name"] = "FeeNote",
								["text"] = nil,
								["style"] = "body",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 4,
								["parent"] = p76,
								["text"] = v_u_75,
								["color"] = v_u_4.text2
							})
						end
					end,
					["buttons"] = v69
				}
				v_u_10.cancelApi = v_u_3.modal(v83)
			end
		end
		local function v_u_245() -- name: draw
			-- upvalues: (copy) v_u_25, (ref) v_u_14, (copy) v_u_31, (copy) v_u_3, (copy) v_u_4, (ref) v_u_13, (copy) v_u_22, (copy) v_u_5, (copy) v_u_7, (copy) v_u_10, (copy) v_u_6, (ref) v_u_517, (copy) v_u_21, (copy) p_u_1, (copy) v_u_8, (copy) v_u_43, (copy) v_u_27, (copy) v_u_17, (copy) v_u_23
			v_u_25()
			if v_u_14 == "loading" then
				for v84 = 1, 3 do
					local v85 = v_u_31(v84)
					v_u_3.new("Frame", {
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.6,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_4.lineStrong,
						["Position"] = UDim2.fromOffset(12, 12),
						["Size"] = UDim2.fromOffset(200, 14)
					}, v85)
					v_u_3.new("Frame", {
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.7,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_4.lineStrong,
						["Position"] = UDim2.fromOffset(12, 34),
						["Size"] = UDim2.fromOffset(120, 10)
					}, v85)
				end
				return
			elseif v_u_14 == "error" or not v_u_13 then
				local v86 = v_u_3.new("Frame", {
					["Name"] = "Message",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_22)
				v_u_3.layout(v86, "v", 10, "center")
				v_u_3.pad(v86, {
					8,
					8,
					20,
					10
				})
				v_u_3.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["align"] = "center",
					["order"] = 1,
					["parent"] = v86,
					["text"] = v_u_13 and v_u_13.text or v_u_5.TEXT.storeDown,
					["color"] = v_u_4.text2
				})
				v_u_7.button(v86, "Retry", "primary", function()
					-- upvalues: (ref) v_u_10
					v_u_10.load(true)
				end, {
					["order"] = 2,
					["name"] = "Retry"
				})
				return
			else
				local v87 = v_u_5.serverNow(v_u_13, v_u_6:clock())
				local v88 = v_u_13.sold
				local v89 = {}
				local v90 = {}
				local v91 = {}
				local v92 = {}
				for _, v93 in type(v88) ~= "table" and {} or v_u_13.sold do
					local v94
					if v93.done == true then
						v94 = v90
					else
						v94 = v89
					end
					table.insert(v94, v93)
				end
				local v95 = v_u_13.back
				for _, v96 in type(v95) ~= "table" and {} or v_u_13.back do
					local v97
					if v96.done == true then
						v97 = v92
					else
						v97 = v91
					end
					table.insert(v97, v96)
				end
				local v98 = #v90 + #v92
				local v99 = v_u_13.tx
				local v100 = {}
				for _, v101 in type(v99) ~= "table" and {} or v_u_13.tx do
					if v_u_517.isOrderTx(v101) then
						continue
					end
					table.insert(v100, v101)
				end
				local v102 = v_u_13.live
				local v103 = type(v102) ~= "table" and {} or v_u_13.live
				local v104 = v_u_13.rc
				local v105 = {}
				for _, v106 in type(v104) ~= "table" and {} or v_u_13.rc do
					if v_u_517.isOrderReceipt(v106) then
						continue
					end
					table.insert(v105, v106)
				end
				local v107 = 0
				v_u_21.setEnabled(#v89 > 0 and true or #v91 > 0)
				if #v89 + #v91 + v98 + #v100 + #v103 + #v105 == 0 then
					local v108 = v_u_3.new("Frame", {
						["Name"] = "Empty",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}, v_u_22)
					v_u_3.layout(v108, "v", 12, "center")
					v_u_3.pad(v108, {
						8,
						8,
						40,
						10
					})
					v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["align"] = "center",
						["order"] = 1,
						["parent"] = v108,
						["text"] = v_u_5.TEXT.noMine,
						["color"] = v_u_4.text2
					})
					v_u_7.button(v108, "Open sell", "secondary", function()
						-- upvalues: (ref) p_u_1
						p_u_1.nav.sub("sell")
					end, {
						["order"] = 2,
						["name"] = "OpenSell"
					})
				else
					local v109
					if #v89 + #v91 > 0 then
						local v110 = v_u_8.section
						local v111 = v_u_22
						v107 = v107 + 1
						local v112 = v107
						local v113 = #v89 + #v91
						v110(v111, "Needs attention", v112, (tostring(v113)))
						v109 = v107
						for _, v_u_114 in v89 do
							local v115 = v_u_31
							v107 = v109 + 1
							local v116 = v115(v107, v_u_4.success)
							local v117
							if v87 then
								local v118 = v_u_114.sa
								if type(v118) == "number" then
									local v119 = v_u_5.ago
									local v120 = v87 - v_u_114.sa
									v117 = "  \194\183  " .. v119((math.max(0, v120)))
								else
									v117 = ""
								end
							else
								v117 = ""
							end
							local v121 = v_u_43
							local v122 = "Sold: %s"
							local v123 = v_u_114.id
							local v124 = v_u_114.n
							local v125
							if v124 > 1 then
								v125 = ("%d x %s"):format(v124, v_u_27(v123))
							else
								v125 = v_u_8.itemName(v123)
							end
							v121(v116, v122:format(v125), ("for %s, you receive %s%s"):format(v_u_5.money(v_u_114.p), v_u_5.money(v_u_114.net), v117), v_u_4.text, 150)
							local v126 = v_u_7.button(v116, "Claim", "primary", function()
								-- upvalues: (ref) v_u_10, (copy) v_u_114
								v_u_10.claimOne(v_u_114.lid)
							end, {
								["name"] = "Claim",
								["height"] = 36,
								["width"] = 120,
								["anchor"] = nil,
								["position"] = nil,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, -10, 0.5, 0)
							})
							v126:SetAttribute("Lid", v_u_114.lid)
							v116:SetAttribute("Kind", "sold")
							local v127 = v_u_17
							local v128 = {
								["kind"] = "sold",
								["lid"] = nil,
								["frame"] = nil,
								["btn"] = nil,
								["lid"] = v_u_114.lid,
								["frame"] = v116,
								["btn"] = v126
							}
							table.insert(v127, v128)
							v109 = v107
						end
						for _, v_u_129 in v91 do
							local v130 = v_u_31
							v107 = v109 + 1
							local v131 = v130(v107, v_u_4.accent)
							local v132 = v_u_43
							local v133 = "Your listing ended. The item is waiting."
							local v134 = v_u_129.id
							local v135 = v_u_129.n
							local v136
							if v135 > 1 then
								v136 = ("%d x %s"):format(v135, v_u_27(v134))
							else
								v136 = v_u_8.itemName(v134)
							end
							v132(v131, v133, v136, v_u_4.text, 150)
							local v137 = v_u_7.button(v131, "Collect", "primary", function()
								-- upvalues: (ref) v_u_10, (copy) v_u_129
								v_u_10.claimOne(v_u_129.lid)
							end, {
								["name"] = "Collect",
								["height"] = 36,
								["width"] = 120,
								["anchor"] = nil,
								["position"] = nil,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, -10, 0.5, 0)
							})
							v137:SetAttribute("Lid", v_u_129.lid)
							v131:SetAttribute("Kind", "back")
							local v138 = v_u_17
							local v139 = {
								["kind"] = "back",
								["lid"] = nil,
								["frame"] = nil,
								["btn"] = nil,
								["lid"] = v_u_129.lid,
								["frame"] = v131,
								["btn"] = v137
							}
							table.insert(v138, v139)
							v109 = v107
						end
					else
						v109 = v107
					end
					if #v100 > 0 then
						local v140 = v_u_8.section
						local v141 = v_u_22
						v107 = v109 + 1
						local v142 = v107
						local v143 = #v100
						v140(v141, "In progress", v142, (tostring(v143)))
						v109 = v107
						for _, v144 in v100 do
							local v145 = v144.review == true and true or v144.st == 9
							local v146 = v_u_31
							v107 = v109 + 1
							local v147 = v107
							local v148
							if v145 then
								v148 = v_u_4.accent
							else
								v148 = v_u_4.info
							end
							local v149 = v146(v147, v148)
							local v150
							if v144.k == "L" then
								local v151 = "Listing %s ... working"
								local v152 = v144.id
								local v153 = v144.n
								local v154
								if v153 > 1 then
									v154 = ("%d x %s"):format(v153, v_u_27(v152))
								else
									v154 = v_u_8.itemName(v152)
								end
								v150 = v151:format(v154)
							else
								local v155 = "Buying %s ... %s held"
								local v156 = v144.id
								local v157 = v144.n
								local v158
								if v157 > 1 then
									v158 = ("%d x %s"):format(v157, v_u_27(v156))
								else
									v158 = v_u_8.itemName(v156)
								end
								v150 = v155:format(v158, v_u_5.money(v144.p))
							end
							local v159 = v_u_5.duration(v144.age or 0)
							if v145 then
								local v160 = v_u_43
								local v161 = v_u_5.TEXT.inReview
								local v162 = v144.id
								local v163 = v144.n
								local v164
								if v163 > 1 then
									v164 = ("%d x %s"):format(v163, v_u_27(v162))
								else
									v164 = v_u_8.itemName(v162)
								end
								v160(v149, v161, v164, v_u_4.accent, 90)
							else
								local v165 = v_u_4.text
								local v166 = v_u_3.label
								local v167 = {
									["parent"] = nil,
									["name"] = "L1",
									["text"] = nil,
									["style"] = "bodyStrong",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v149,
									["text"] = v150,
									["color"] = v165 or v_u_4.text
								}
								local v168 = UDim2.fromOffset
								local v169 = (v_u_23 - 22) / 2
								v167.position = v168(12, (math.floor(v169)))
								v167.size = UDim2.new(1, -102, 0, 22)
								v166(v167)
							end
							v_u_3.label({
								["parent"] = nil,
								["name"] = "Age",
								["text"] = nil,
								["style"] = "monoS",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["fit"] = true,
								["parent"] = v149,
								["text"] = v159,
								["color"] = v_u_4.muted,
								["position"] = UDim2.new(1, -86, 0, 0),
								["size"] = UDim2.fromOffset(76, v_u_23)
							})
							v149:SetAttribute("Kind", v145 and "review" or "tx")
							local v170 = v_u_17
							table.insert(v170, {
								["kind"] = v145 and "review" or "tx",
								["frame"] = v149
							})
							v109 = v107
						end
					end
					if #v103 > 0 then
						local v171 = v_u_8.section
						local v172 = v_u_22
						v107 = v109 + 1
						local v173 = v107
						local v174 = #v103
						v171(v172, "Live", v173, (tostring(v174)))
						v109 = v107
						for _, v_u_175 in v103 do
							local v176 = v_u_31
							v107 = v109 + 1
							local v177 = v107
							local v178
							if v_u_175.hidden then
								v178 = v_u_4.accent
							else
								v178 = v_u_4.line
							end
							local v179 = v176(v177, v178)
							local v180 = v_u_175.n <= 1 and "" or (" (%s each)"):format(v_u_5.unitMoney(v_u_175.p / v_u_175.n))
							local v181
							if v87 then
								local v182 = v_u_175.e - v87
								v181 = math.max(0, v182)
							else
								v181 = 0
							end
							local v183 = ("ends in %s"):format(v_u_5.duration(v181))
							if v_u_175.hidden then
								v183 = v_u_5.TEXT.notShown
							end
							local v184 = v_u_43
							local v185 = "%s for %s%s"
							local v186 = v_u_175.id
							local v187 = v_u_175.n
							local v188
							if v187 > 1 then
								v188 = ("%d x %s"):format(v187, v_u_27(v186))
							else
								v188 = v_u_8.itemName(v186)
							end
							v184(v179, v185:format(v188, v_u_5.money(v_u_175.p), v180), v183, v_u_4.text, 150)
							if v_u_175.hidden and v179:FindFirstChild("L2") then
								v179.L2.TextColor3 = v_u_4.accent
							end
							local v189 = v_u_7.paidOf(v_u_175.pk)
							if v189.paid then
								v179.Size = UDim2.new(1, 0, 0, v_u_23 + 24)
								local v190 = v_u_3.new("Frame", {
									["Name"] = "PaidStrip",
									["BackgroundTransparency"] = 1,
									["Position"] = nil,
									["Size"] = nil,
									["Position"] = UDim2.fromOffset(12, v_u_23 - 6),
									["Size"] = UDim2.new(1, -154, 0, 20)
								}, v179)
								v_u_3.layout(v190, "h", 8)
								v_u_7.paidPill(v190, v189, {
									["order"] = 1,
									["h"] = 18
								})
								if v189.hint ~= nil then
									v_u_3.label({
										["parent"] = nil,
										["name"] = "PaidHint",
										["text"] = nil,
										["style"] = "small",
										["color"] = nil,
										["size"] = nil,
										["autoX"] = true,
										["track"] = false,
										["order"] = 2,
										["parent"] = v190,
										["text"] = v189.hint,
										["color"] = v_u_4.text2,
										["size"] = UDim2.fromOffset(0, 18)
									})
								end
								v179:SetAttribute("Paid", true)
								v179:SetAttribute("Insurable", v189.insurable == true)
							end
							local v191 = v_u_7.button(v179, "Cancel", "danger", function()
								-- upvalues: (ref) v_u_10, (copy) v_u_175
								v_u_10.cancel(v_u_175.lid)
							end, {
								["name"] = "Cancel",
								["height"] = 36,
								["width"] = 120,
								["anchor"] = nil,
								["position"] = nil,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, -10, 0.5, 0)
							})
							v191:SetAttribute("Lid", v_u_175.lid)
							v179:SetAttribute("Kind", "live")
							local v192 = v_u_17
							local v193 = {
								["kind"] = "live",
								["lid"] = nil,
								["frame"] = nil,
								["btn"] = nil,
								["hidden"] = nil,
								["lid"] = v_u_175.lid,
								["frame"] = v179,
								["btn"] = v191,
								["hidden"] = v_u_175.hidden == true
							}
							table.insert(v192, v193)
							v109 = v107
						end
					end
					if v98 > 0 then
						local v194 = v_u_8.section
						local v195 = v_u_22
						v107 = v109 + 1
						v194(v195, "Recently finished", v107, (tostring(v98)))
						v109 = v107
						for _, v196 in v90 do
							local v197 = v_u_31
							v107 = v109 + 1
							local v198 = v197(v107, v_u_4.line)
							local v199
							if v87 then
								local v200 = v196.sa
								if type(v200) == "number" then
									local v201 = v_u_5.ago
									local v202 = v87 - v196.sa
									v199 = "  \194\183  " .. v201((math.max(0, v202)))
								else
									v199 = ""
								end
							else
								v199 = ""
							end
							local v203 = v_u_43
							local v204 = "Sold: %s"
							local v205 = v196.id
							local v206 = v196.n
							local v207
							if v206 > 1 then
								v207 = ("%d x %s"):format(v206, v_u_27(v205))
							else
								v207 = v_u_8.itemName(v205)
							end
							v203(v198, v204:format(v207), ("%s added to your Cash%s"):format(v_u_5.money(v196.net), v199), v_u_4.text, 12)
							v198:SetAttribute("Kind", "soldDone")
							local v208 = v_u_17
							local v209 = {
								["kind"] = "soldDone",
								["lid"] = nil,
								["frame"] = nil,
								["lid"] = v196.lid,
								["frame"] = v198
							}
							table.insert(v208, v209)
							v109 = v107
						end
						for _, v210 in v92 do
							local v211 = v_u_31
							v107 = v109 + 1
							local v212 = v211(v107, v_u_4.line)
							local v213 = v210.rs == 2 and "Expired. Back in your stash." or "Cancelled. Back in your stash."
							local v214 = v_u_43
							local v215 = v210.id
							local v216 = v210.n
							local v217
							if v216 > 1 then
								v217 = ("%d x %s"):format(v216, v_u_27(v215))
							else
								v217 = v_u_8.itemName(v215)
							end
							v214(v212, v213, v217, v_u_4.text, 12)
							v212:SetAttribute("Kind", "backDone")
							local v218 = v_u_17
							local v219 = {
								["kind"] = "backDone",
								["lid"] = nil,
								["frame"] = nil,
								["lid"] = v210.lid,
								["frame"] = v212
							}
							table.insert(v218, v219)
							v109 = v107
						end
					end
					if #v105 > 0 then
						local v220 = v_u_8.section
						local v221 = v_u_22
						v107 = v109 + 1
						local v222 = v107
						local v223 = #v105
						v220(v221, "History", v222, (tostring(v223)))
						local v224 = v107
						for _, v225 in v105 do
							local v226 = v_u_3.new
							local v227 = {
								["Name"] = "Receipt",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.5,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["BackgroundColor3"] = v_u_4.raised,
								["Size"] = UDim2.new(1, 0, 0, 40)
							}
							v107 = v224 + 1
							v227.LayoutOrder = v107
							local v228 = v226("Frame", v227, v_u_22)
							local v229 = v_u_517.VERBS[v225.k] or "Done"
							local v230 = (v225.p or 0) <= 0 and "" or " for " .. v_u_5.money(v225.p)
							local v231
							if v87 then
								local v232 = v225.t
								if type(v232) == "number" then
									local v233 = v_u_5.ago
									local v234 = v87 - v225.t
									v231 = v233((math.max(0, v234)))
								else
									v231 = ""
								end
							else
								v231 = ""
							end
							local v235 = v_u_3.label
							local v236 = {
								["parent"] = nil,
								["name"] = "What",
								["text"] = nil,
								["style"] = "body",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["track"] = false,
								["parent"] = v228
							}
							local v237 = "%s: %s%s"
							local v238 = v225.id
							local v239 = v225.n or 1
							local v240
							if v239 > 1 then
								v240 = ("%d x %s"):format(v239, v_u_27(v238))
							else
								v240 = v_u_8.itemName(v238)
							end
							v236.text = v237:format(v229, v240, v230)
							v236.color = v_u_4.text
							v236.position = UDim2.fromOffset(12, 0)
							v236.size = UDim2.new(1, -202, 1, 0)
							v235(v236)
							v_u_3.label({
								["parent"] = nil,
								["name"] = "Ago",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["fit"] = true,
								["parent"] = v228,
								["text"] = v231,
								["color"] = v_u_4.text2,
								["position"] = UDim2.new(1, -184, 0, 0),
								["size"] = UDim2.fromOffset(96, 40)
							})
							local v241 = v225.ref
							local v242
							if type(v241) == "string" then
								local v243 = v225.ref
								v242 = string.sub(v243, -6)
							else
								v242 = ""
							end
							v_u_3.label({
								["parent"] = nil,
								["name"] = "Ref",
								["text"] = nil,
								["style"] = "monoS",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v228,
								["text"] = v242,
								["color"] = v_u_4.muted,
								["position"] = UDim2.new(1, -84, 0, 0),
								["size"] = UDim2.fromOffset(76, 40)
							})
							v228:SetAttribute("Kind", "receipt")
							local v244 = v_u_17
							table.insert(v244, {
								["kind"] = "receipt",
								["frame"] = nil,
								["frame"] = v228
							})
							v224 = v107
						end
					end
				end
			end
		end
		function v_u_10.dropLive(p246) -- name: dropLive
			-- upvalues: (ref) v_u_14, (ref) v_u_13, (copy) v_u_245
			if v_u_14 == "ok" then
				local v247 = v_u_13
				if type(v247) == "table" then
					local v248 = v_u_13.live
					if type(v248) == "table" then
						local v249 = {}
						for _, v250 in v_u_13.live do
							if v250.lid == p246 then
								continue
							end
							table.insert(v249, v250)
						end
						if #v249 ~= #v_u_13.live then
							local v251 = table.clone(v_u_13)
							v251.live = v249
							v_u_13 = v251
							v_u_245()
						end
					end
				end
			end
		end
		function v_u_10.load(p_u_252) -- name: load
			-- upvalues: (ref) v_u_15, (ref) v_u_14, (copy) v_u_245, (copy) v_u_6, (ref) v_u_11, (ref) v_u_13, (ref) v_u_19, (ref) v_u_12, (copy) v_u_10
			v_u_15 = v_u_15 + 1
			local v_u_253 = v_u_15
			if v_u_14 ~= "ok" then
				v_u_14 = "loading"
				v_u_245()
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (copy) p_u_252, (copy) v_u_253, (ref) v_u_15, (ref) v_u_11, (ref) v_u_14, (ref) v_u_13, (ref) v_u_19, (ref) v_u_12, (ref) v_u_10, (ref) v_u_245
				local v254 = v_u_6:mine(p_u_252 == true)
				if v_u_253 == v_u_15 and v_u_11 then
					if v254.ok or (v_u_14 ~= "ok" or (not v_u_13 or v254.code ~= "RATE" and (v254.code ~= "COOLDOWN" and v254.code ~= "BUSY"))) or v_u_19 >= 3 then
						v_u_13 = v254
						if v254.ok then
							v_u_14 = "ok"
							v_u_19 = 0
						else
							v_u_14 = "error"
						end
						v_u_245()
					else
						v_u_19 = v_u_19 + 1
						task.delay(4, function()
							-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_253, (ref) v_u_15, (ref) v_u_10
							if v_u_11 and (v_u_12 and v_u_253 == v_u_15) then
								v_u_10.load(false)
							end
						end)
					end
				else
					return
				end
			end)
		end
		local v_u_255 = 0
		local v256 = {
			["Disconnect"] = p_u_1.onTick(function()
				-- upvalues: (ref) v_u_12, (ref) v_u_255, (ref) v_u_517, (copy) v_u_10, (ref) v_u_14, (copy) v_u_245
				if v_u_12 then
					v_u_255 = v_u_255 + 1
					if v_u_255 % v_u_517.EVERY == 0 then
						v_u_10.load(false)
					elseif v_u_14 == "ok" and v_u_255 % 5 == 0 then
						v_u_245()
					end
				else
					return
				end
			end)
		}
		table.insert(v_u_16, v256)
		function v_u_10.show() -- name: show
			-- upvalues: (ref) v_u_12, (copy) v_u_10
			v_u_12 = true
			v_u_10.load(false)
		end
		function v_u_10.hide() -- name: hide
			-- upvalues: (ref) v_u_12
			v_u_12 = false
		end
		function v_u_10.refresh(_) -- name: refresh end
		function v_u_10.reload() -- name: reload
			-- upvalues: (copy) v_u_6, (copy) v_u_10
			v_u_6:invalidate("mine")
			v_u_10.load(true)
		end
		function v_u_10.onNote(_) -- name: onNote
			-- upvalues: (ref) v_u_12, (copy) v_u_6, (copy) v_u_10
			if v_u_12 then
				v_u_6:invalidate("mine")
				v_u_10.load(true)
			end
		end
		function v_u_10.pressCancel(p257) -- name: pressCancel
			-- upvalues: (copy) v_u_10
			for _, v_u_258 in v_u_10.cancelButtons or {} do
				if v_u_258.text ~= p257 then
					continue
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_258, (ref) v_u_10
					local v259, v260
					if v_u_258.onClick then
						local v261 = v_u_258.onClick
						v259, v260 = pcall(v261)
					else
						v259 = true
						v260 = nil
					end
					if (not v259 or v260 ~= true) and v_u_10.cancelApi then
						v_u_10.cancelApi.close()
					end
				end)
				return true
			end
			return false
		end
		function v_u_10.rows() -- name: rows
			-- upvalues: (copy) v_u_17
			return v_u_17
		end
		function v_u_10.preview(p262) -- name: preview
			-- upvalues: (ref) v_u_15, (ref) v_u_14, (copy) v_u_245
			v_u_15 = v_u_15 + 1
			v_u_14 = p262 == "error" and "error" or "loading"
			v_u_245()
		end
		function v_u_10.state() -- name: state
			-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_17, (copy) v_u_22
			local v263 = 0
			for _, v264 in { v_u_13 and v_u_13.sold or {}, v_u_13 and v_u_13.back or {} } do
				for _, v265 in v264 do
					if v265.done == true then
						continue
					end
					v263 = v263 + 1
				end
			end
			return {
				["status"] = v_u_14,
				["rows"] = #v_u_17,
				["claimEnabled"] = v263 > 0,
				["list"] = v_u_22,
				["body"] = v_u_13
			}
		end
		function v_u_10.destroy() -- name: destroy
			-- upvalues: (ref) v_u_11, (copy) v_u_16
			v_u_11 = false
			for _, v_u_266 in v_u_16 do
				pcall(function()
					-- upvalues: (copy) v_u_266
					v_u_266:Disconnect()
				end)
			end
		end
		v_u_10.frame = p2
		return v_u_10
	end,
	["ORDER_VERBS"] = {
		["o"] = "Order placed",
		["f"] = "Sold to an order",
		["g"] = "Order delivered",
		["n"] = "Order ended",
		["x"] = "Not completed"
	},
	["ORDER_TEXT"] = {
		["empty"] = "You have no buy orders. Open an item and choose PLACE ORDER.",
		["waitMail"] = "Waiting for your mail",
		["mailFull"] = "Your mail is full. Collect some deliveries first.",
		["back"] = "The order ended. The unused Cash is coming back.",
		["notShown"] = "Not shown yet",
		["paused"] = "Paused until you collect",
		["collect"] = "Collect",
		["collectAll"] = "Collect all",
		["cancel"] = "Cancel",
		["keep"] = "Keep order",
		["cancelOrder"] = "Cancel order",
		["cancelAsk"] = "Cancel the order for {lot}?",
		["cancelBack"] = "The unused {cash} comes back to your Cash."
	},
	["isOrderTx"] = function(p267) -- name: isOrderTx
		local v268
		if type(p267) == "table" then
			v268 = p267.k == "O" and true or p267.k == "F"
		else
			v268 = false
		end
		return v268
	end,
	["isOrderReceipt"] = function(p269) -- name: isOrderReceipt
		if type(p269) == "table" then
			local v270 = p269.k
			if type(v270) == "string" then
				if p269.k == "o" or (p269.k == "f" or (p269.k == "g" or p269.k == "n")) then
					return true
				end
				local v271
				if p269.k == "x" then
					local v272 = p269.ref
					if type(v272) == "string" then
						local v273 = p269.ref
						if string.sub(v273, 1, 1) == "o" then
							v271 = true
						else
							local v274 = p269.ref
							v271 = string.sub(v274, 1, 1) == "f"
						end
					else
						v271 = false
					end
				else
					v271 = false
				end
				return v271
			end
		end
		return false
	end,
	["newOrders"] = function(p_u_275, p276) -- name: newOrders
		-- upvalues: (copy) v_u_517
		local v_u_277 = p_u_275.ui
		local _ = p_u_275.theme
		local v_u_278 = p_u_275.C
		local v_u_279 = p_u_275.Data
		local v_u_280 = p_u_275.data
		local v_u_281 = p_u_275.h
		local v_u_282 = p_u_275.kit
		local v283 = p_u_275.compact
		local v_u_284 = v_u_517.ORDER_TEXT
		local v_u_285 = {}
		local v_u_286 = true
		local v_u_287 = false
		local v_u_288 = nil
		local v_u_289 = "loading"
		local v_u_290 = 0
		local v_u_291 = {}
		local v_u_292 = {}
		local v_u_293 = false
		local v_u_294 = 0
		local v295 = p_u_275.controlFrame("orders")
		v_u_281.button(v295, "Refresh", "secondary", function()
			-- upvalues: (copy) v_u_285
			v_u_285.load(true)
		end, {
			["name"] = "Refresh",
			["height"] = 40,
			["width"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 100,
			["width"] = v283 and 92 or 120,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, 0, 0.5, 0)
		})
		local _, v_u_296 = v_u_281.button(v295, v_u_284.collectAll, "primary", function()
			-- upvalues: (copy) v_u_285
			v_u_285.collect()
		end, {
			["name"] = "CollectAll",
			["height"] = 40,
			["width"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 140,
			["width"] = v283 and 104 or 150,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -((v283 and 92 or 120) + 8), 0.5, 0)
		})
		v_u_296.setEnabled(false)
		local v_u_297 = v_u_277.list({
			["parent"] = nil,
			["name"] = "Rows",
			["size"] = nil,
			["gap"] = 8,
			["padding"] = nil,
			["parent"] = p276,
			["size"] = UDim2.fromScale(1, 1),
			["padding"] = {
				0,
				8,
				0,
				10
			}
		})
		local v_u_298 = v283 and 64 or 60
		local function v_u_300() -- name: clear
			-- upvalues: (copy) v_u_297, (copy) v_u_292
			for _, v299 in v_u_297:GetChildren() do
				if v299:IsA("UIListLayout") or v299:IsA("UIPadding") then
					continue
				end
				v299:Destroy()
			end
			table.clear(v_u_292)
		end
		local function v_u_302(p301) -- name: nameOf
			-- upvalues: (copy) v_u_282
			return v_u_282.itemName(p301)
		end
		local function v_u_306(p303, p304) -- name: row
			-- upvalues: (copy) v_u_277, (copy) v_u_278, (copy) v_u_298, (copy) v_u_297
			local v305 = v_u_277.new("Frame", {
				["Name"] = "Row",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_278.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_298),
				["LayoutOrder"] = p303
			}, v_u_297)
			v_u_277.stroke(v305, p304 or v_u_278.line)
			return v305
		end
		local function v_u_318(p307, p308, p309, p310, p311) -- name: texts
			-- upvalues: (copy) v_u_277, (copy) v_u_278, (copy) v_u_298
			local v312 = v_u_277.label
			local v313 = {
				["parent"] = nil,
				["name"] = "L1",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = p307,
				["text"] = p308,
				["color"] = v_u_278.text
			}
			local v314 = UDim2.fromOffset
			local v315 = 12
			local v316
			if p309 then
				v316 = 6
			else
				local v317 = (v_u_298 - 22) / 2
				v316 = math.floor(v317)
			end
			v313.position = v314(v315, v316)
			v313.size = UDim2.new(1, -(p311 + 12), 0, 22)
			v312(v313)
			if p309 then
				v_u_277.label({
					["parent"] = nil,
					["name"] = "L2",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = p307,
					["text"] = p309,
					["color"] = p310 or v_u_278.text2,
					["position"] = UDim2.fromOffset(12, 30),
					["size"] = UDim2.new(1, -(p311 + 12), 0, 18)
				})
			end
		end
		local function v_u_324(p319, p320, p321, p322, p323) -- name: rightButton
			-- upvalues: (copy) v_u_281
			return v_u_281.button(p319, p320, p321, p323, {
				["name"] = nil,
				["height"] = 36,
				["width"] = 120,
				["anchor"] = nil,
				["position"] = nil,
				["name"] = p322,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -10, 0.5, 0)
			})
		end
		function v_u_285.collect() -- name: collect
			-- upvalues: (copy) v_u_280, (copy) v_u_277, (ref) v_u_293, (ref) v_u_286, (copy) p_u_275, (copy) v_u_285
			local function v_u_325()
				-- upvalues: (ref) v_u_280
				return v_u_280:claim({})
			end
			local function v_u_331(p326)
				-- upvalues: (ref) v_u_277
				if p326.ok then
					local v327 = v_u_277.toast
					local v328 = p326.text == "" and "Collected." or p326.text
					pcall(v327, v328, "success")
				else
					local v329 = v_u_277.toast
					local v330 = p326.text
					pcall(v329, v330, "warn")
				end
			end
			if not v_u_293 then
				v_u_293 = true
				task.spawn(function()
					-- upvalues: (copy) v_u_325, (ref) v_u_293, (ref) v_u_286, (copy) v_u_331, (ref) p_u_275, (ref) v_u_285
					local v332 = v_u_325()
					v_u_293 = false
					if v_u_286 then
						if v_u_331 then
							v_u_331(v332)
						end
						p_u_275.refreshState(true)
						v_u_285.load(true)
					end
				end)
			end
		end
		function v_u_285.cancel(p_u_333) -- name: cancel
			-- upvalues: (ref) v_u_288, (copy) v_u_284, (copy) v_u_280, (copy) v_u_277, (copy) v_u_285, (ref) v_u_293, (ref) v_u_286, (copy) p_u_275, (copy) v_u_279, (copy) v_u_302, (copy) v_u_282, (copy) v_u_278
			local v_u_334 = nil
			for _, v335 in v_u_288 and v_u_288.orders or {} do
				if v335.oid ~= p_u_333 then
					continue
				end
				v_u_334 = v335
			end
			if v_u_334 and v_u_334.st == 1 then
				local v344 = {
					{
						["text"] = nil,
						["kind"] = "secondary",
						["text"] = v_u_284.keep
					},
					{
						["text"] = nil,
						["kind"] = "danger",
						["onClick"] = nil,
						["text"] = v_u_284.cancelOrder,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_280, (copy) p_u_333, (ref) v_u_277, (ref) v_u_285, (ref) v_u_293, (ref) v_u_286, (ref) p_u_275
							local function v_u_336()
								-- upvalues: (ref) v_u_280, (ref) p_u_333
								return v_u_280:orderCancel({
									["oid"] = p_u_333
								})
							end
							local function v_u_342(p337)
								-- upvalues: (ref) v_u_277, (ref) v_u_285, (ref) p_u_333
								if p337.ok then
									local v338 = v_u_277.toast
									local v339 = p337.text
									pcall(v338, v339, "success")
									v_u_285.dropOrder(p_u_333)
								else
									local v340 = v_u_277.toast
									local v341 = p337.text
									pcall(v340, v341, "warn")
								end
							end
							if not v_u_293 then
								v_u_293 = true
								task.spawn(function()
									-- upvalues: (copy) v_u_336, (ref) v_u_293, (ref) v_u_286, (copy) v_u_342, (ref) p_u_275, (ref) v_u_285
									local v343 = v_u_336()
									v_u_293 = false
									if v_u_286 then
										if v_u_342 then
											v_u_342(v343)
										end
										p_u_275.refreshState(true)
										v_u_285.load(true)
									end
								end)
							end
							return false
						end
					}
				}
				v_u_285.cancelButtons = v344
				local v356 = {
					["title"] = "Cancel order",
					["width"] = 480,
					["build"] = nil,
					["buttons"] = nil,
					["build"] = function(p345) -- name: build
						-- upvalues: (ref) v_u_277, (ref) v_u_279, (ref) v_u_284, (ref) v_u_334, (ref) v_u_302, (ref) v_u_282, (ref) v_u_278
						local v346 = v_u_277.label
						local v347 = {
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 1,
							["parent"] = p345
						}
						local v348 = v_u_279.fill
						local v349 = v_u_284.cancelAsk
						local v350 = {}
						local v351 = v_u_334.id
						local v352 = v_u_334.rem
						local v353
						if v352 > 1 then
							v353 = ("%d x %s"):format(v352, v_u_302(v351))
						else
							v353 = v_u_282.itemName(v351)
						end
						v350.lot = v353
						v347.text = v348(v349, v350)
						v347.color = v_u_278.text
						v346(v347)
						local v354 = v_u_277.label
						local v355 = {
							["parent"] = nil,
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["parent"] = p345,
							["text"] = v_u_279.fill(v_u_284.cancelBack, {
								["cash"] = v_u_279.money(v_u_334.h)
							}),
							["color"] = v_u_278.text2
						}
						v354(v355)
					end,
					["buttons"] = v344
				}
				v_u_285.cancelApi = v_u_277.modal(v356)
			end
		end
		local function v_u_497() -- name: draw
			-- upvalues: (copy) v_u_300, (ref) v_u_289, (copy) v_u_306, (copy) v_u_277, (copy) v_u_278, (ref) v_u_288, (copy) v_u_297, (copy) v_u_279, (copy) v_u_281, (copy) v_u_285, (ref) v_u_517, (copy) v_u_280, (copy) v_u_296, (copy) v_u_284, (copy) p_u_275, (copy) v_u_282, (copy) v_u_302, (copy) v_u_318, (copy) v_u_324, (copy) v_u_292, (copy) v_u_298
			v_u_300()
			if v_u_289 == "loading" then
				for v357 = 1, 3 do
					local v358 = v_u_306(v357)
					v_u_277.new("Frame", {
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.6,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_278.lineStrong,
						["Position"] = UDim2.fromOffset(12, 12),
						["Size"] = UDim2.fromOffset(200, 14)
					}, v358)
				end
				return
			elseif v_u_289 == "error" or not v_u_288 then
				local v359 = v_u_277.new("Frame", {
					["Name"] = "Message",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_297)
				v_u_277.layout(v359, "v", 10, "center")
				v_u_277.pad(v359, {
					8,
					8,
					20,
					10
				})
				v_u_277.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["align"] = "center",
					["order"] = 1,
					["parent"] = v359,
					["text"] = v_u_288 and v_u_288.text or v_u_279.TEXT.storeDown,
					["color"] = v_u_278.text2
				})
				v_u_281.button(v359, "Retry", "primary", function()
					-- upvalues: (ref) v_u_285
					v_u_285.load(true)
				end, {
					["order"] = 2,
					["name"] = "Retry"
				})
				return
			else
				local v360 = v_u_288.orders
				local v361 = type(v360) ~= "table" and {} or v_u_288.orders
				local v362 = v_u_288.tx
				local v363 = {}
				for _, v364 in type(v362) ~= "table" and {} or v_u_288.tx do
					local v365
					if type(v364) == "table" then
						v365 = v364.k == "O" and true or v364.k == "F"
					else
						v365 = false
					end
					if not v365 then
						continue
					end
					table.insert(v363, v364)
				end
				local v366 = v_u_288.rc
				local v367 = {}
				for _, v368 in type(v366) ~= "table" and {} or v_u_288.rc do
					if not v_u_517.isOrderReceipt(v368) then
						continue
					end
					table.insert(v367, v368)
				end
				local v369 = {}
				local v370 = {}
				local v371 = {}
				for _, v372 in v361 do
					if (v372.wait or 0) > 0 or v372.back == true then
						table.insert(v369, v372)
					end
					if v372.st == 1 and v372.ended ~= true then
						table.insert(v371, v372)
					else
						if v372.ended ~= true and (v372.st ~= 2 and v372.st ~= 3) then
							continue
						end
						table.insert(v370, v372)
					end
				end
				local v373 = v_u_279.serverNow(v_u_288, v_u_280:clock())
				local v374 = 0
				v_u_296.setEnabled(#v369 > 0)
				if #v361 + #v363 + #v367 == 0 then
					local v375 = v_u_277.new("Frame", {
						["Name"] = "Empty",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}, v_u_297)
					v_u_277.layout(v375, "v", 12, "center")
					v_u_277.pad(v375, {
						8,
						8,
						40,
						10
					})
					v_u_277.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["align"] = "center",
						["order"] = 1,
						["parent"] = v375,
						["text"] = v_u_284.empty,
						["color"] = v_u_278.text2
					})
					v_u_281.button(v375, "Open browse", "secondary", function()
						-- upvalues: (ref) p_u_275
						p_u_275.nav.sub("browse")
					end, {
						["order"] = 2,
						["name"] = "OpenBrowse"
					})
				else
					local v376
					if #v369 > 0 then
						local v377 = v_u_282.section
						local v378 = v_u_297
						v374 = v374 + 1
						local v379 = v374
						local v380 = #v369
						v377(v378, "Needs attention", v379, (tostring(v380)))
						v376 = v374
						for _, v381 in v369 do
							local v382 = v_u_306
							v374 = v376 + 1
							local v383 = v382(v374, v_u_278.accent)
							if (v381.wait or 0) > 0 then
								local v384 = "%s bought for %s"
								local v385 = v381.id
								local v386 = v381.wait
								local v387
								if v386 > 1 then
									v387 = ("%d x %s"):format(v386, v_u_302(v385))
								else
									v387 = v_u_282.itemName(v385)
								end
								local v388 = v384:format(v387, v_u_279.money(v381.wait * v381.u))
								local v389
								if v381.mail == "full" then
									v389 = v_u_284.mailFull
								else
									v389 = v_u_284.waitMail
								end
								v_u_318(v383, v388, v389, v_u_278.accent, 150)
								v383:SetAttribute("Kind", "fill")
								v383:SetAttribute("Mail", v381.mail or "wait")
							else
								local v390 = v_u_318
								local v391 = v_u_284.back
								local v392 = v381.id
								local v393 = v381.q
								local v394
								if v393 > 1 then
									v394 = ("%d x %s"):format(v393, v_u_302(v392))
								else
									v394 = v_u_282.itemName(v392)
								end
								v390(v383, v391, v394, v_u_278.text2, 150)
								v383:SetAttribute("Kind", "back")
							end
							local v395 = v_u_324(v383, v_u_284.collect, "primary", "Collect", function()
								-- upvalues: (ref) v_u_285
								v_u_285.collect()
							end)
							v395:SetAttribute("Oid", v381.oid)
							local v396 = v_u_292
							local v397 = {
								["kind"] = v383:GetAttribute("Kind"),
								["oid"] = v381.oid,
								["frame"] = v383,
								["btn"] = v395,
								["mail"] = v381.mail
							}
							table.insert(v396, v397)
							v376 = v374
						end
					else
						v376 = v374
					end
					if #v363 > 0 then
						local v398 = v_u_282.section
						local v399 = v_u_297
						v374 = v376 + 1
						local v400 = v374
						local v401 = #v363
						v398(v399, "In progress", v400, (tostring(v401)))
						v376 = v374
						for _, v402 in v363 do
							local v403 = v402.review == true and true or v402.st == 9
							local v404 = v_u_306
							v374 = v376 + 1
							local v405 = v374
							local v406
							if v403 then
								v406 = v_u_278.accent
							else
								v406 = v_u_278.info
							end
							local v407 = v404(v405, v406)
							if v403 then
								local v408 = v_u_318
								local v409 = v_u_279.TEXT.inReview
								local v410 = v402.id
								local v411 = v402.n
								local v412
								if v411 > 1 then
									v412 = ("%d x %s"):format(v411, v_u_302(v410))
								else
									v412 = v_u_282.itemName(v410)
								end
								v408(v407, v409, v412, v_u_278.accent, 90)
							elseif v402.k == "O" then
								local v413 = "Placing order for %s ... %s set aside"
								local v414 = v402.id
								local v415 = v402.n
								local v416
								if v415 > 1 then
									v416 = ("%d x %s"):format(v415, v_u_302(v414))
								else
									v416 = v_u_282.itemName(v414)
								end
								local v417 = v413:format(v416, v_u_279.money(v402.p))
								local v418 = v_u_277.label
								local v419 = {
									["parent"] = nil,
									["name"] = "L1",
									["text"] = nil,
									["style"] = "bodyStrong",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v407,
									["text"] = v417,
									["color"] = v_u_278.text
								}
								local v420 = UDim2.fromOffset
								local v421 = (v_u_298 - 22) / 2
								v419.position = v420(12, (math.floor(v421)))
								v419.size = UDim2.new(1, -102, 0, 22)
								v418(v419)
							else
								local v422 = v_u_277.label
								local v423 = {
									["parent"] = nil,
									["name"] = "L1",
									["text"] = "Selling into buy orders ... working",
									["style"] = "bodyStrong",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v407,
									["color"] = v_u_278.text
								}
								local v424 = UDim2.fromOffset
								local v425 = (v_u_298 - 22) / 2
								v423.position = v424(12, (math.floor(v425)))
								v423.size = UDim2.new(1, -102, 0, 22)
								v422(v423)
							end
							v_u_277.label({
								["parent"] = nil,
								["name"] = "Age",
								["text"] = nil,
								["style"] = "monoS",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["fit"] = true,
								["parent"] = v407,
								["text"] = v_u_279.duration(v402.age or 0),
								["color"] = v_u_278.muted,
								["position"] = UDim2.new(1, -86, 0, 0),
								["size"] = UDim2.fromOffset(76, v_u_298)
							})
							v407:SetAttribute("Kind", v403 and "review" or "tx")
							local v426 = v_u_292
							table.insert(v426, {
								["kind"] = v403 and "review" or "tx",
								["frame"] = v407
							})
							v376 = v374
						end
					end
					if #v371 > 0 then
						local v427 = v_u_282.section
						local v428 = v_u_297
						v374 = v376 + 1
						local v429 = v374
						local v430 = #v371
						v427(v428, "Open", v429, (tostring(v430)))
						v376 = v374
						for _, v_u_431 in v371 do
							local v432 = v_u_306
							v374 = v376 + 1
							local v433 = v374
							local v434
							if v_u_431.shown == false then
								v434 = v_u_278.accent
							else
								v434 = v_u_278.line
							end
							local v435 = v432(v433, v434)
							local v436 = v_u_431.left
							local v437
							if type(v436) == "number" then
								local v438 = v_u_431.left - (v_u_280:clock() - (v_u_288._at or v_u_280:clock()))
								v437 = math.max(0, v438)
							else
								v437 = 0
							end
							local v439 = ("Set aside %s  \194\183  ends in %s"):format(v_u_279.money(v_u_431.h), v_u_279.duration(v437))
							local v440 = nil
							if v_u_431.shown == false then
								v439 = v_u_284.notShown
								v440 = v_u_278.accent
							elseif v_u_431.paused == true then
								v439 = v_u_284.paused
								v440 = v_u_278.accent
							end
							local v441 = nil
							local v442
							if p_u_275.rs == nil then
								v442 = v441
							else
								local v443 = p_u_275.rs.cheapest
								if type(v443) == "function" then
									local v444 = v_u_279.rsOrderCheaper
									if type(v444) == "function" then
										local function v445()
											-- upvalues: (ref) v_u_279, (copy) v_u_431, (ref) p_u_275
											return v_u_279.rsOrderCheaper(v_u_431.u, p_u_275.rs.cheapest(v_u_431.id))
										end
										local v446
										v446, v442 = pcall(v445)
										if v446 then
											if type(v442) ~= "string" then
												v442 = v441
											end
										else
											v442 = v441
										end
									else
										v442 = v441
									end
								else
									v442 = v441
								end
							end
							if v442 ~= nil and (v_u_431.shown ~= false and v_u_431.paused ~= true) then
								v440 = v_u_278.accent
								v439 = v442
							end
							local v447 = v_u_318
							local v448 = v_u_431.id
							v447(v435, ("%s: %d of %d left at %s each"):format(v_u_282.itemName(v448), v_u_431.rem, v_u_431.q, v_u_279.unitMoney(v_u_431.u)), v439, v440, 150)
							v435:SetAttribute("Cheaper", v442 ~= nil)
							local v449 = v_u_324(v435, v_u_284.cancel, "danger", "Cancel", function()
								-- upvalues: (ref) v_u_285, (copy) v_u_431
								v_u_285.cancel(v_u_431.oid)
							end)
							v449:SetAttribute("Oid", v_u_431.oid)
							v435:SetAttribute("Kind", "open")
							local v450 = v_u_292
							local v451 = {
								["kind"] = "open",
								["oid"] = nil,
								["frame"] = nil,
								["btn"] = nil,
								["hidden"] = nil,
								["paused"] = nil,
								["oid"] = v_u_431.oid,
								["frame"] = v435,
								["btn"] = v449,
								["hidden"] = v_u_431.shown == false,
								["paused"] = v_u_431.paused == true
							}
							table.insert(v450, v451)
							v376 = v374
						end
					end
					if #v370 > 0 then
						local v452 = v_u_282.section
						local v453 = v_u_297
						v374 = v376 + 1
						local v454 = v374
						local v455 = #v370
						v452(v453, "Ended", v454, (tostring(v455)))
						v376 = v374
						for _, v456 in v370 do
							local v457 = v_u_306
							v374 = v376 + 1
							local v458 = v457(v374, v_u_278.line)
							local v459 = v456.st == 2
							local v460 = v_u_318
							local v461
							if v459 then
								local v462 = "Filled: %s at %s each"
								local v463 = v456.id
								local v464 = v456.q
								local v465
								if v464 > 1 then
									v465 = ("%d x %s"):format(v464, v_u_302(v463))
								else
									v465 = v_u_282.itemName(v463)
								end
								v461 = v462:format(v465, v_u_279.unitMoney(v456.u))
							else
								local v466 = "Ended: %s"
								local v467 = v456.id
								local v468 = v456.q
								local v469
								if v468 > 1 then
									v469 = ("%d x %s"):format(v468, v_u_302(v467))
								else
									v469 = v_u_282.itemName(v467)
								end
								v461 = v466:format(v469)
							end
							v460(v458, v461, not v459 and "The unused Cash is back in your Cash." or nil, nil, 12)
							v458:SetAttribute("Kind", "ended")
							local v470 = v_u_292
							local v471 = {
								["kind"] = "ended",
								["oid"] = nil,
								["frame"] = nil,
								["oid"] = v456.oid,
								["frame"] = v458
							}
							table.insert(v470, v471)
							v376 = v374
						end
					end
					if #v367 > 0 then
						local v472 = v_u_282.section
						local v473 = v_u_297
						v374 = v376 + 1
						local v474 = v374
						local v475 = #v367
						v472(v473, "History", v474, (tostring(v475)))
						local v476 = v374
						for _, v477 in v367 do
							local v478 = v_u_277.new
							local v479 = {
								["Name"] = "Receipt",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.5,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["BackgroundColor3"] = v_u_278.raised,
								["Size"] = UDim2.new(1, 0, 0, 40)
							}
							v374 = v476 + 1
							v479.LayoutOrder = v374
							local v480 = v478("Frame", v479, v_u_297)
							local v481 = v_u_517.ORDER_VERBS[v477.k] or "Done"
							local v482 = (v477.p or 0) <= 0 and "" or " at " .. v_u_279.unitMoney(v477.p) .. " each"
							local v483
							if v373 then
								local v484 = v477.t
								if type(v484) == "number" then
									local v485 = v_u_279.ago
									local v486 = v373 - v477.t
									v483 = v485((math.max(0, v486)))
								else
									v483 = ""
								end
							else
								v483 = ""
							end
							local v487 = v_u_277.label
							local v488 = {
								["parent"] = nil,
								["name"] = "What",
								["text"] = nil,
								["style"] = "body",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["track"] = false,
								["parent"] = v480
							}
							local v489 = "%s: %s%s"
							local v490 = v477.id
							local v491 = v477.n or 1
							local v492
							if v491 > 1 then
								v492 = ("%d x %s"):format(v491, v_u_302(v490))
							else
								v492 = v_u_282.itemName(v490)
							end
							v488.text = v489:format(v481, v492, v482)
							v488.color = v_u_278.text
							v488.position = UDim2.fromOffset(12, 0)
							v488.size = UDim2.new(1, -202, 1, 0)
							v487(v488)
							v_u_277.label({
								["parent"] = nil,
								["name"] = "Ago",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["fit"] = true,
								["parent"] = v480,
								["text"] = v483,
								["color"] = v_u_278.text2,
								["position"] = UDim2.new(1, -184, 0, 0),
								["size"] = UDim2.fromOffset(96, 40)
							})
							local v493 = v477.ref
							local v494
							if type(v493) == "string" then
								local v495 = v477.ref
								v494 = string.sub(v495, -6)
							else
								v494 = ""
							end
							v_u_277.label({
								["parent"] = nil,
								["name"] = "Ref",
								["text"] = nil,
								["style"] = "monoS",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v480,
								["text"] = v494,
								["color"] = v_u_278.muted,
								["position"] = UDim2.new(1, -84, 0, 0),
								["size"] = UDim2.fromOffset(76, 40)
							})
							v480:SetAttribute("Kind", "receipt")
							local v496 = v_u_292
							table.insert(v496, {
								["kind"] = "receipt",
								["frame"] = nil,
								["frame"] = v480
							})
							v476 = v374
						end
					end
				end
			end
		end
		function v_u_285.dropOrder(p498) -- name: dropOrder
			-- upvalues: (ref) v_u_289, (ref) v_u_288, (copy) v_u_497
			if v_u_289 == "ok" then
				local v499 = v_u_288
				if type(v499) == "table" then
					local v500 = v_u_288.orders
					if type(v500) == "table" then
						local v501 = {}
						for _, v502 in v_u_288.orders do
							if v502.oid == p498 then
								continue
							end
							table.insert(v501, v502)
						end
						if #v501 ~= #v_u_288.orders then
							local v503 = table.clone(v_u_288)
							v503.orders = v501
							v_u_288 = v503
							v_u_497()
						end
					end
				end
			end
		end
		function v_u_285.load(p_u_504) -- name: load
			-- upvalues: (ref) v_u_290, (ref) v_u_289, (copy) v_u_497, (copy) v_u_280, (ref) v_u_286, (ref) v_u_288, (ref) v_u_294, (ref) v_u_287, (copy) v_u_285
			v_u_290 = v_u_290 + 1
			local v_u_505 = v_u_290
			if v_u_289 ~= "ok" then
				v_u_289 = "loading"
				v_u_497()
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_280, (copy) p_u_504, (copy) v_u_505, (ref) v_u_290, (ref) v_u_286, (ref) v_u_289, (ref) v_u_288, (ref) v_u_294, (ref) v_u_287, (ref) v_u_285, (ref) v_u_497
				local v506 = v_u_280:mine(p_u_504 == true)
				if v_u_505 == v_u_290 and v_u_286 then
					if v506.ok or (v_u_289 ~= "ok" or (not v_u_288 or v506.code ~= "RATE" and (v506.code ~= "COOLDOWN" and v506.code ~= "BUSY"))) or v_u_294 >= 3 then
						v_u_288 = v506
						if v506.ok then
							v_u_289 = "ok"
							v_u_294 = 0
						else
							v_u_289 = "error"
						end
						v_u_497()
					else
						v_u_294 = v_u_294 + 1
						task.delay(4, function()
							-- upvalues: (ref) v_u_286, (ref) v_u_287, (ref) v_u_505, (ref) v_u_290, (ref) v_u_285
							if v_u_286 and (v_u_287 and v_u_505 == v_u_290) then
								v_u_285.load(false)
							end
						end)
					end
				else
					return
				end
			end)
		end
		local v_u_507 = 0
		local v508 = {
			["Disconnect"] = p_u_275.onTick(function()
				-- upvalues: (ref) v_u_287, (ref) v_u_507, (ref) v_u_517, (copy) v_u_285, (ref) v_u_289, (copy) v_u_497
				if v_u_287 then
					v_u_507 = v_u_507 + 1
					if v_u_507 % v_u_517.EVERY == 0 then
						v_u_285.load(false)
					elseif v_u_289 == "ok" and v_u_507 % 5 == 0 then
						v_u_497()
					end
				else
					return
				end
			end)
		}
		table.insert(v_u_291, v508)
		function v_u_285.show() -- name: show
			-- upvalues: (ref) v_u_287, (copy) v_u_285
			v_u_287 = true
			v_u_285.load(false)
		end
		function v_u_285.hide() -- name: hide
			-- upvalues: (ref) v_u_287
			v_u_287 = false
		end
		function v_u_285.refresh(_) -- name: refresh end
		function v_u_285.reload() -- name: reload
			-- upvalues: (copy) v_u_280, (copy) v_u_285
			v_u_280:invalidate("mine")
			v_u_285.load(true)
		end
		function v_u_285.onNote(_) -- name: onNote
			-- upvalues: (ref) v_u_287, (copy) v_u_280, (copy) v_u_285
			if v_u_287 then
				v_u_280:invalidate("mine")
				v_u_285.load(true)
			end
		end
		function v_u_285.pressCancel(p509) -- name: pressCancel
			-- upvalues: (copy) v_u_285
			for _, v_u_510 in v_u_285.cancelButtons or {} do
				if v_u_510.text ~= p509 then
					continue
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_510, (ref) v_u_285
					local v511, v512
					if v_u_510.onClick then
						local v513 = v_u_510.onClick
						v511, v512 = pcall(v513)
					else
						v511 = true
						v512 = nil
					end
					if (not v511 or v512 ~= true) and v_u_285.cancelApi then
						v_u_285.cancelApi.close()
					end
				end)
				return true
			end
			return false
		end
		function v_u_285.rows() -- name: rows
			-- upvalues: (copy) v_u_292
			return v_u_292
		end
		function v_u_285.state() -- name: state
			-- upvalues: (ref) v_u_288, (ref) v_u_289, (copy) v_u_292, (copy) v_u_297
			local v514 = 0
			for _, v515 in v_u_288 and v_u_288.orders or {} do
				if (v515.wait or 0) <= 0 and v515.back ~= true then
					continue
				end
				v514 = v514 + 1
			end
			return {
				["status"] = v_u_289,
				["rows"] = #v_u_292,
				["collectEnabled"] = v514 > 0,
				["list"] = v_u_297,
				["body"] = v_u_288
			}
		end
		function v_u_285.destroy() -- name: destroy
			-- upvalues: (ref) v_u_286, (copy) v_u_291
			v_u_286 = false
			for _, v_u_516 in v_u_291 do
				pcall(function()
					-- upvalues: (copy) v_u_516
					v_u_516:Disconnect()
				end)
			end
		end
		v_u_285.frame = p276
		return v_u_285
	end
}
return v_u_517