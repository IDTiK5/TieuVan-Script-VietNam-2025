-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSquads

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("GuiService")
local v_u_4 = {}
local v_u_7 = (function() -- name: loadWhy
	local v5, v6 = pcall(function()
		return require((script.Parent:WaitForChild("SquadsWhy", 5)))
	end)
	if v5 and type(v6) == "table" then
		return v6
	end
	warn("[MenuSquads] lib missing: SquadsWhy")
	return {}
end)()
local v8, v_u_9 = pcall(function()
	return require((script.Parent:WaitForChild("SquadsHint", 5)))
end)
if not v8 or type(v_u_9) ~= "table" then
	v_u_9 = nil
end
local v10, v_u_11 = pcall(function()
	return require((script.Parent:WaitForChild("MenuFriendsJoin", 5)))
end)
if not v10 or type(v_u_11) ~= "table" then
	v_u_11 = nil
end
local v12, v_u_13 = pcall(function()
	return require((script.Parent:WaitForChild("ClanTagText", 5)))
end)
if not v12 or type(v_u_13) ~= "table" then
	v_u_13 = nil
end
local v14, v_u_15 = pcall(function()
	return require((script.Parent:WaitForChild("MenuRotationLayout", 5)))
end)
if not v14 or type(v_u_15) ~= "table" then
	v_u_15 = nil
end
local v_u_16 = v1.LocalPlayer
local v_u_17 = {
	"Any",
	"Normal",
	"Hard",
	"Nightmare"
}
local v18, v19 = pcall(function()
	return require((script.Parent:WaitForChild("MenuPlayPvpve", 5)))
end)
if v18 and type(v19) == "table" then
	v_u_17 = v19.squadFilter(v_u_17)
end
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = {
	["diff"] = "Any",
	["voice"] = false,
	["region"] = false,
	["friends"] = false
}
local v_u_24 = {
	["squads"] = 1,
	["players"] = 1
}
local v_u_25 = false
local v_u_26 = false
local v_u_27 = nil
function v_u_4.visText(p28) -- name: visText
	return p28 == "public" and "Public" or (p28 == "private" and "Private" or "Friends")
end
function v_u_4.ageText(p29) -- name: ageText
	if type(p29) ~= "number" then
		return "?"
	end
	local v30 = p29 + 0.5
	return ("%d %%"):format((math.floor(v30)))
end
local v_u_31 = v_u_7.VIS_HELP or {
	["private"] = "",
	["friends"] = "",
	["public"] = ""
}
local function v_u_36(p32) -- name: request
	-- upvalues: (copy) v_u_2, (copy) v_u_24, (copy) v_u_23
	local v33 = v_u_2:FindFirstChild("HushNet")
	if v33 then
		v33 = v33:FindFirstChild("party.op")
	end
	if not (v33 and v33:IsA("RemoteEvent")) then
		v33 = nil
	end
	if v33 then
		if p32 == "squads" then
			local v34 = {
				["op"] = "browse",
				["page"] = nil,
				["diff"] = nil,
				["voice"] = nil,
				["region"] = nil,
				["friends"] = nil,
				["page"] = v_u_24.squads
			}
			local v35
			if v_u_23.diff == "Any" then
				v35 = nil
			else
				v35 = v_u_23.diff
			end
			v34.diff = v35
			v34.voice = v_u_23.voice
			v34.region = v_u_23.region
			v34.friends = v_u_23.friends
			v33:FireServer(v34)
		else
			v33:FireServer({
				["op"] = "players",
				["page"] = nil,
				["page"] = v_u_24.players
			})
		end
	else
		return
	end
end
local function v_u_42(p37) -- name: onList
	-- upvalues: (copy) v_u_22, (copy) v_u_24, (ref) v_u_27
	if type(p37) == "table" then
		local v38 = p37.kind
		if type(v38) == "string" then
			local v39 = p37.rows
			if type(v39) == "table" then
				v_u_22[p37.kind] = p37
				local v40 = p37.page
				if type(v40) == "number" then
					v_u_24[p37.kind] = p37.page
				end
				if v_u_27 and (v_u_27.alive and v_u_27.kind == p37.kind) then
					local v41 = v_u_27.repaint
					pcall(v41)
				end
				return
			end
		end
	end
end
function v_u_4.bind(p_u_43) -- name: bind
	-- upvalues: (ref) v_u_25, (copy) v_u_2, (copy) v_u_42, (ref) v_u_27, (ref) v_u_26, (copy) v_u_4, (copy) v_u_24, (copy) v_u_36, (copy) v_u_23, (ref) v_u_17, (copy) v_u_22
	if not v_u_25 then
		local v44 = v_u_2:FindFirstChild("HushNet")
		if v44 then
			v44 = v44:FindFirstChild("party.list")
		end
		if not (v44 and v44:IsA("RemoteEvent")) then
			v44 = nil
		end
		if v44 then
			v_u_25 = true
			v44.OnClientEvent:Connect(v_u_42)
		else
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_25, (ref) v_u_42
				local v45 = v_u_2:WaitForChild("HushNet", 60)
				if v45 then
					v45 = v45:WaitForChild("party.list", 60)
				end
				if v45 and (v45:IsA("RemoteEvent") and not v_u_25) then
					v_u_25 = true
					v45.OnClientEvent:Connect(v_u_42)
				end
			end)
		end
	end
	if p_u_43.changed and not p_u_43._squadsHooked then
		p_u_43._squadsHooked = true
		p_u_43.changed:Connect(function(p46)
			-- upvalues: (ref) v_u_27
			if p46 == "party" and (v_u_27 and (v_u_27.alive and (v_u_27.kind == "squads" and v_u_27.mine))) then
				local v47 = v_u_27.mine
				pcall(v47)
			end
		end)
	end
	if not v_u_26 and p_u_43.cctx then
		local v48 = p_u_43.cctx.command
		if type(v48) == "function" then
			v_u_26 = true
			local v49 = p_u_43.cctx
			v49.command("squads.open", function()
				-- upvalues: (ref) v_u_4, (copy) p_u_43
				v_u_4.open(p_u_43)
				return "open"
			end)
			v49.command("squads.invite", function()
				-- upvalues: (ref) v_u_4, (copy) p_u_43
				v_u_4.openInvite(p_u_43)
				return "open"
			end)
			v49.command("squads.maprow", function(p50)
				-- upvalues: (ref) v_u_4, (copy) p_u_43
				local v51, v52, v53 = v_u_4.rowMap(p_u_43, {
					["mapId"] = p50[1] or "hollow",
					["diff"] = p50[2] or "Normal"
				})
				local v54 = "map=%s join=%s tod=%s"
				if v51 then
					v51 = v51.id
				end
				return v54:format(tostring(v51), v52 and "open" or "LOCKED", (tostring(v53)))
			end)
			v49.command("squads.close", function()
				-- upvalues: (ref) v_u_4
				v_u_4.close()
				return "closed"
			end)
			v49.command("squads.page", function(p55)
				-- upvalues: (ref) v_u_27, (ref) v_u_24, (ref) v_u_36
				local v56 = p55[1]
				local v57 = tonumber(v56) or 1
				if v_u_27 and v_u_27.alive then
					v_u_24[v_u_27.kind] = v57
					v_u_36(v_u_27.kind)
				end
				return "page " .. v57
			end)
			v49.command("squads.filter", function(p58)
				-- upvalues: (ref) v_u_23, (ref) v_u_17, (ref) v_u_24, (ref) v_u_2, (ref) v_u_27
				local v59 = p58[1]
				local v60 = p58[2]
				if v59 == "diff" then
					v_u_23.diff = not (v60 and table.find(v_u_17, v60)) and "Any" or v60
				elseif v59 == "voice" or (v59 == "region" or v59 == "friends") then
					v_u_23[v59] = v60 == "on"
				end
				v_u_24.squads = 1
				local v61 = v_u_2:FindFirstChild("HushNet")
				if v61 then
					v61 = v61:FindFirstChild("party.op")
				end
				if not (v61 and v61:IsA("RemoteEvent")) then
					v61 = nil
				end
				if v61 then
					local v62 = {
						["op"] = "browse",
						["page"] = nil,
						["diff"] = nil,
						["voice"] = nil,
						["region"] = nil,
						["friends"] = nil,
						["page"] = v_u_24.squads
					}
					local v63
					if v_u_23.diff == "Any" then
						v63 = nil
					else
						v63 = v_u_23.diff
					end
					v62.diff = v63
					v62.voice = v_u_23.voice
					v62.region = v_u_23.region
					v62.friends = v_u_23.friends
					v61:FireServer(v62)
				end
				if v_u_27 and (v_u_27.alive and v_u_27.filters) then
					local v64 = v_u_27.filters
					pcall(v64)
				end
				local v65 = v_u_23.diff
				local v66 = v_u_23.voice
				local v67 = tostring(v66)
				local v68 = v_u_23.region
				local v69 = tostring(v68)
				local v70 = v_u_23.friends
				return ("diff=%s voice=%s region=%s friends=%s"):format(v65, v67, v69, (tostring(v70)))
			end)
			v49.command("squads.state", function()
				-- upvalues: (ref) v_u_27, (ref) v_u_22, (copy) p_u_43
				local v71 = {}
				local v72 = "open="
				local v73 = v_u_27 and v_u_27.alive
				if v73 then
					v73 = v_u_27.kind
				end
				__set_list(v71, 1, {v72 .. tostring(v73)})
				for v74, v75 in v_u_22 do
					local v76 = {}
					for _, v77 in v75.rows do
						local v78 = v77.leader or v77.displayName
						local v79 = tostring(v78)
						local v80
						if v77.age == nil then
							v80 = ""
						else
							local v81 = v77.age
							v80 = "(" .. tostring(v81) .. "%)"
						end
						local v82 = v79 .. v80 .. (v77.friend and "[F]" or "")
						table.insert(v76, v82)
					end
					local v83 = v75.page
					local v84 = tostring(v83)
					local v85 = v75.pages
					local v86 = tostring(v85)
					local v87 = v75.total
					local v88 = tostring(v87)
					local v89 = table.concat
					table.insert(v71, ("%s p%s/%s total=%s: %s"):format(v74, v84, v86, v88, v89(v76, ", ")))
					if v74 ~= "players" then
						break
					end
					local v90 = v75.friendsElsewhere
					local v91 = "elsewhere="
					local v92
					if type(v90) == "table" then
						local v93 = v90.rows
						if type(v93) == "table" then
							local v94 = #v90.rows
							v92 = tostring(v94) .. (v90.loaded and "" or " (looking)")
						else
							v92 = "none"
						end
					else
						v92 = "none"
					end
					local v95 = v91 .. v92
					table.insert(v71, v95)
				end
				local v96 = p_u_43.party
				local v97
				if type(v96) == "table" then
					v97 = v96.party
				else
					v97 = false
				end
				local v98 = "vis=%s age=%s voiceLobby=%s voicePlace=%s myVoice=%s region=%s lobby=%s"
				local v99
				if v97 then
					v99 = v97.visibility
				else
					v99 = v97
				end
				local v100 = tostring(v99)
				if v97 then
					v97 = v97.ageShare
				end
				local v101 = tostring(v97)
				local v102
				if type(v96) == "table" then
					v102 = v96.voiceLobby
				else
					v102 = false
				end
				local v103 = tostring(v102)
				local v104
				if type(v96) == "table" then
					v104 = v96.voicePlace
				else
					v104 = false
				end
				local v105 = tostring(v104)
				local v106
				if type(v96) == "table" then
					v106 = v96.myVoice
				else
					v106 = false
				end
				local v107 = tostring(v106)
				local v108
				if type(v96) == "table" then
					v108 = v96.region
				else
					v108 = false
				end
				local v109 = tostring(v108)
				local v110
				if type(v96) == "table" then
					v110 = v96.lobbyCount
				else
					v110 = false
				end
				local v111 = tostring(v110)
				table.insert(v71, v98:format(v100, v101, v103, v105, v107, v109, v111))
				return table.concat(v71, " || ")
			end)
		end
	end
end
function v_u_4.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_27
	if v_u_27 and v_u_27.alive then
		return v_u_27.kind
	else
		return nil
	end
end
function v_u_4.close() -- name: close
	-- upvalues: (ref) v_u_27
	if v_u_27 and (v_u_27.alive and v_u_27.api) then
		v_u_27.api.close()
	end
end
local function v_u_133(p_u_112, p113, p114, p_u_115, p116, p117) -- name: pager
	-- upvalues: (copy) v_u_24, (copy) v_u_36
	local v118
	if p117 and p117.isPhone() == true then
		local v119 = p117.touch
		v118 = math.max(36, v119(36))
	else
		v118 = 36
	end
	local v120 = p_u_112.new("Frame", {
		["Name"] = "Pager",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v118),
		["LayoutOrder"] = p116
	}, p114)
	local v_u_121 = p_u_112.label({
		["parent"] = nil,
		["name"] = "Info",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v120,
		["color"] = p113.text2,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(1, -260, 1, 0)
	})
	v_u_121.TextTruncate = Enum.TextTruncate.AtEnd
	local _, v_u_125 = p_u_112.button({
		["parent"] = nil,
		["name"] = "Prev",
		["text"] = "Prev",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 96,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v120,
		["position"] = UDim2.new(1, -164, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_24, (copy) p_u_115, (ref) v_u_36
			local v122 = v_u_24
			local v123 = p_u_115
			local v124 = (v_u_24[p_u_115] or 1) - 1
			v122[v123] = math.max(1, v124)
			v_u_36(p_u_115)
		end
	})
	local v_u_126 = p_u_112.label({
		["parent"] = nil,
		["name"] = "Page",
		["text"] = "1 / 1",
		["style"] = "bodyStrong",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v120,
		["position"] = UDim2.new(1, -112, 0, 0),
		["size"] = UDim2.new(0, 56, 1, 0)
	})
	v_u_126.TextXAlignment = Enum.TextXAlignment.Center
	local _, v_u_127 = p_u_112.button({
		["parent"] = nil,
		["name"] = "Next",
		["text"] = "Next",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 96,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v120,
		["position"] = UDim2.new(1, 0, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_24, (copy) p_u_115, (ref) v_u_36
			v_u_24[p_u_115] = (v_u_24[p_u_115] or 1) + 1
			v_u_36(p_u_115)
		end
	})
	return {
		["paint"] = function(p128, p129) -- name: paint
			-- upvalues: (copy) p_u_112, (copy) v_u_126, (copy) v_u_121, (copy) v_u_125, (copy) v_u_127
			local v130
			if p128 then
				v130 = p128.page
			else
				v130 = p128
			end
			local v131 = tonumber(v130) or 1
			if p128 then
				p128 = p128.pages
			end
			local v132 = tonumber(p128) or 1
			p_u_112.setText(v_u_126, ("%d / %d"):format(v131, v132))
			p_u_112.setText(v_u_121, p129)
			v_u_125.setEnabled(v131 > 1)
			v_u_127.setEnabled(v131 < v132)
		end
	}
end
function v_u_4.rowMap(p_u_134, p_u_135) -- name: rowMap
	-- upvalues: (ref) v_u_15, (copy) v_u_16
	local v_u_136 = nil
	local v_u_137 = true
	local v_u_138
	if v_u_15 then
		v_u_138 = v_u_15.rotationOf(p_u_134)
	else
		v_u_138 = nil
	end
	local function v143()
		-- upvalues: (copy) p_u_134, (ref) v_u_136, (copy) v_u_138, (copy) p_u_135, (ref) v_u_137, (ref) v_u_16
		local v139 = p_u_134.cctx.shared.Maps
		local v140 = v139.get
		local v141
		if v_u_138 then
			v141 = v_u_138.map
		else
			v141 = p_u_135.mapId or p_u_135.map
		end
		v_u_136 = v140(v141)
		if v_u_136 then
			local v142 = v139.isOpenFor
			if type(v142) == "function" then
				v_u_137 = v139.isOpenFor(v_u_136, v_u_16) == true
			end
		end
	end
	pcall(v143)
	local v144 = nil
	if v_u_136 then
		local v145 = v_u_136.fixedTime
		if type(v145) == "table" then
			local v146 = v_u_136.fixedTime
			local v147 = p_u_135.diff or "Normal"
			v144 = v146[tostring(v147)] or v_u_136.fixedTime.Normal
			if type(v144) ~= "string" then
				v144 = nil
			end
		end
	end
	return v_u_136, v_u_137, v144
end
local function v_u_224(p_u_148, p149, p_u_150, p151, p152) -- name: squadRowUi
	-- upvalues: (ref) v_u_13, (copy) v_u_4, (copy) v_u_7, (ref) v_u_15, (copy) v_u_21, (copy) v_u_16
	local v153 = p_u_148.ui
	local v154 = p_u_148.theme.color
	local v155 = p152 < 760
	local v156 = v155 and 66 or 72
	local v157 = v153.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "S" .. p151,
		["BackgroundColor3"] = v154.raised,
		["Size"] = UDim2.new(1, -8, 0, v156),
		["LayoutOrder"] = p151
	}, p149)
	local v158 = v153.stroke
	local v159
	if p_u_150.friend then
		v159 = v154.accentDim
	else
		v159 = v154.line
	end
	v158(v157, v159)
	if p_u_150.friend then
		v153.new("Frame", {
			["Name"] = "FriendBar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v154.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v157)
	end
	local v160 = v155 and 214 or 268
	local v161 = false
	local v162
	if v_u_13 then
		if v_u_13.leaderTitleRich then
			v162, v161 = v_u_13.leaderTitleRich(p_u_150)
		else
			v162 = v_u_13.leaderTitle(p_u_150)
		end
	else
		local v163 = p_u_150.leader or "?"
		v162 = tostring(v163) .. "\'s squad"
	end
	v153.label({
		["parent"] = nil,
		["name"] = "Leader",
		["text"] = nil,
		["rich"] = nil,
		["style"] = "bodyStrong",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v157,
		["text"] = v162,
		["rich"] = v161,
		["position"] = UDim2.fromOffset(16, 8),
		["size"] = UDim2.new(1, -(v160 + 24), 0, 20)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	local v164 = {}
	if p_u_150.friend then
		table.insert(v164, "FRIEND")
	end
	if p_u_150.remote then
		table.insert(v164, "OTHER SERVER")
	end
	local v165
	if p_u_150.region then
		local v166 = p_u_150.region
		v165 = tostring(v166)
	else
		v165 = "?"
	end
	local v167 = v165 .. (p_u_150.sameRegion and " (YOUR REGION)" or "")
	table.insert(v164, v167)
	local v168 = p_u_150.voiceN
	local v169 = tonumber(v168) or 0
	local v170 = p_u_150.n
	local v171 = tonumber(v170) or 0
	table.insert(v164, ("VOICE %d/%d"):format(v169, v171))
	local v172 = p_u_150.tod
	local v173 = (type(v172) ~= "string" or p_u_150.tod == "") and "Any time" or p_u_150.tod
	local v_u_174, v175, v176 = v_u_4.rowMap(p_u_148, p_u_150)
	local v177 = v176 or v173
	if not v175 then
		table.insert(v164, 1, "MAP LOCKED")
	end
	for v178, v179 in v_u_7.rowTags(p_u_150) do
		local v180 = v178 + (v175 and 0 or 1)
		table.insert(v164, v180, v179)
	end
	local v181 = "%s  \194\183  %s  \194\183  %s  \194\183  %s"
	local v182 = p_u_150.diff or "Normal"
	local v183 = tostring(v182)
	local v184
	if v_u_15 then
		v184 = v_u_15.squadMapText(p_u_150.map, v_u_15.rotationOf(p_u_148))
	else
		local v185 = p_u_150.map or "Stillwater"
		v184 = tostring(v185)
	end
	local v186 = p_u_150.exp or "Rookie"
	local v187 = v181:format(v183, v184, v177, (tostring(v186)))
	v153.label({
		["parent"] = nil,
		["name"] = "Info",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v157,
		["text"] = v187,
		["color"] = v154.text2,
		["position"] = UDim2.fromOffset(16, 30),
		["size"] = UDim2.new(1, -(v160 + 24), 0, 16)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	local v188 = table.concat(v164, "  \194\183  ")
	if not v155 then
		local v189 = p_u_150.names
		if type(v189) == "table" then
			v188 = v188 .. "  \194\183  " .. table.concat(p_u_150.names, ", ")
		end
	end
	local v190 = v153.label
	local v191 = {
		["parent"] = nil,
		["name"] = "Tags",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v157,
		["text"] = v188
	}
	local v192
	if p_u_150.friend then
		v192 = v154.accent
	else
		v192 = v154.muted
	end
	v191.color = v192
	v191.position = UDim2.fromOffset(16, v155 and 47 or 50)
	v191.size = UDim2.new(1, -(v160 + 24), 0, 14)
	v190(v191).TextTruncate = Enum.TextTruncate.AtEnd
	local v193 = v153.new("Frame", {
		["Name"] = "Age",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -(v155 and 118 or 132), 0.5, 0),
		["Size"] = UDim2.fromOffset(v155 and 92 or 128, v156 - 12)
	}, v157)
	local v194 = p_u_150.age
	local v195
	if type(v194) == "number" then
		if p_u_150.age >= 75 then
			v195 = v154.success
		elseif p_u_150.age >= 40 then
			v195 = v154.accent
		else
			v195 = v154.text2
		end
	else
		v195 = v154.muted
	end
	v153.label({
		["parent"] = nil,
		["name"] = "Pct",
		["text"] = nil,
		["style"] = "h3",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v193,
		["text"] = v_u_4.ageText(p_u_150.age),
		["color"] = v195,
		["position"] = UDim2.fromOffset(0, 2),
		["size"] = UDim2.new(1, 0, 0, 24)
	}).TextXAlignment = Enum.TextXAlignment.Right
	local v196 = v153.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v193,
		["text"] = v155 and "SAME AGE" or "SAME AGE GROUP",
		["color"] = v154.text2,
		["position"] = UDim2.fromOffset(0, 28),
		["size"] = UDim2.new(1, 0, 0, 12)
	})
	v196.TextXAlignment = Enum.TextXAlignment.Right
	v196.TextTruncate = Enum.TextTruncate.AtEnd
	local v197 = v153.label
	local v198 = {
		["parent"] = nil,
		["name"] = "Size",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v193
	}
	local v199 = p_u_150.n
	local v200 = tonumber(v199) or 0
	local v201 = p_u_150.max
	v198.text = ("%d / %d"):format(v200, tonumber(v201) or 4)
	v198.color = v154.text
	v198.position = UDim2.fromOffset(0, 42)
	v198.size = UDim2.new(1, 0, 0, 12)
	v197(v198).TextXAlignment = Enum.TextXAlignment.Right
	v153.tooltip(v193, function()
		return {
			["title"] = "SAME AGE GROUP",
			["body"] = "Share of this squad\'s players who are in an age group that can chat with you. ? = Roblox has not told us yet."
		}
	end)
	local v202 = p_u_150.id
	local v_u_203 = tostring(v202)
	local v_u_204 = nil
	local v_u_205 = nil
	local v208, v209 = v153.button({
		["parent"] = nil,
		["name"] = "Join",
		["text"] = "Join",
		["kind"] = "secondary",
		["height"] = 36,
		["width"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v157,
		["width"] = v155 and 104 or 116,
		["position"] = UDim2.new(1, -10, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_21, (copy) v_u_203, (ref) v_u_204, (copy) p_u_148, (ref) v_u_205
			local v206 = v_u_21[v_u_203]
			if not v206 or os.clock() - v206 >= 3 then
				v_u_21[v_u_203] = os.clock()
				v_u_204.setText("Joining")
				v_u_204.setEnabled(false)
				local v207 = {
					["op"] = "join",
					["partyId"] = nil,
					["partyId"] = v_u_203
				}
				p_u_148.partyOp(v207)
				task.delay(3, function()
					-- upvalues: (ref) v_u_205, (ref) v_u_204
					if v_u_205.Parent then
						v_u_204.setText("Join")
						v_u_204.setEnabled(true)
					end
				end)
			end
		end
	})
	local v210 = v208
	local v211 = v209
	local v212 = v_u_21[v_u_203]
	if v212 and os.clock() - v212 < 3 then
		v211.setText("Joining")
		v211.setEnabled(false)
	end
	local v_u_213
	if v175 then
		v_u_213 = v_u_7.joinState(p_u_150)
	else
		v_u_213 = nil
	end
	if v_u_213 then
		v211.setText(v_u_213.text)
		v211.setEnabled(false)
		v210:SetAttribute("JoinState", v_u_213.text)
		v153.tooltip(v210, function()
			-- upvalues: (copy) v_u_213
			return {
				["title"] = v_u_213.title,
				["body"] = v_u_213.body
			}
		end)
	end
	if not v175 then
		v211.setText("Locked")
		v211.setEnabled(false)
		v210:SetAttribute("MapLocked", true)
		v153.tooltip(v210, function()
			-- upvalues: (copy) p_u_148, (copy) v_u_174, (ref) v_u_16, (copy) p_u_150
			local function v214()
				-- upvalues: (ref) p_u_148, (ref) v_u_174, (ref) v_u_16
				return p_u_148.cctx.shared.Maps.accessFor(v_u_174, v_u_16)
			end
			local v215, v216 = pcall(v214)
			if v215 and (type(v216) == "table" and (v216.why == "raids" and v216.need)) then
				local v217 = {
					["title"] = "MAP LOCKED",
					["body"] = nil
				}
				local v218 = v_u_174 and v_u_174.name or p_u_150.map
				v217.body = ("This squad deploys to %s. Finish %d raids to join it (%d / %d)."):format(tostring(v218), v216.need, v216.have or 0, v216.need)
				return v217
			end
			if v215 and (type(v216) == "table" and v216.why == "quest") then
				local function v219()
					-- upvalues: (ref) p_u_148
					return p_u_148.cctx.shared.MapUnlock
				end
				local v220, v221 = pcall(v219)
				if v220 and v221 then
					return {
						["title"] = "MAP LOCKED",
						["body"] = nil,
						["body"] = ("This squad deploys to %s. Finish %s to join it. %s."):format(v221.mapLabel(v_u_174 and v_u_174.name or p_u_150.map), v221.missionList(v216.missing, false, "and"), v221.whereLine(v216.missing))
					}
				end
			end
			local v222 = {
				["title"] = "MAP LOCKED",
				["body"] = nil
			}
			local v223 = v_u_174 and v_u_174.name or p_u_150.map
			v222.body = ("This squad deploys to %s, which is still closed."):format((tostring(v223)))
			return v222
		end)
	end
	return v210
end
local function v_u_230(p_u_225) -- name: openLobbyHop
	local v226 = p_u_225.ui
	local v227 = p_u_225.party
	local v228
	if type(v227) == "table" then
		v228 = v227.voiceLobby == true
	else
		v228 = false
	end
	local v229
	if type(v227) == "table" then
		v229 = v227.voicePlace == true
	else
		v229 = false
	end
	if v228 then
		v226.modal({
			["title"] = "Back to the normal lobby?",
			["body"] = "You leave this server and your squad. Your profile and stash come with you.",
			["buttons"] = nil,
			["buttons"] = {
				{
					["text"] = "Stay"
				},
				{
					["text"] = "Normal lobby",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) p_u_225
						p_u_225.partyOp({
							["op"] = "normalLobby"
						})
					end
				}
			}
		})
		return
	elseif v229 then
		if type(v227) == "table" and v227.myVoice == false then
			v226.modal({
				["title"] = "Voice chat needed",
				["body"] = "The voice lobby is only for players with Roblox voice chat enabled. Turn it on in your Roblox settings, then try again.",
				["buttons"] = nil,
				["buttons"] = {
					{
						["text"] = "Got it"
					}
				}
			})
		else
			v226.modal({
				["title"] = "Go to the voice lobby?",
				["body"] = "Everybody there has voice chat on. You leave this server and your squad. Your profile and stash come with you.",
				["buttons"] = nil,
				["buttons"] = {
					{
						["text"] = "Stay"
					},
					{
						["text"] = "Voice lobby",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) p_u_225
							p_u_225.partyOp({
								["op"] = "voiceLobby"
							})
						end
					}
				}
			})
		end
	else
		v226.modal({
			["title"] = "Voice lobby: coming soon",
			["body"] = "A second lobby where every survivor has voice chat on, so squads can talk from the first minute. Its squad browser will only list players with voice. It opens soon.",
			["buttons"] = nil,
			["buttons"] = {
				{
					["text"] = "Got it"
				}
			}
		})
		return
	end
end
local function v_u_240(p_u_231) -- name: hintKindOf
	-- upvalues: (ref) v_u_9
	if v_u_9 == nil then
		return nil, false
	end
	local v_u_232 = false
	local function v233()
		-- upvalues: (ref) v_u_232, (copy) p_u_231
		v_u_232 = p_u_231.cctx.shared.GameMode.rule("pvp") == true
	end
	pcall(v233)
	local v_u_234 = false
	if not v_u_232 then
		pcall(function()
			-- upvalues: (copy) p_u_231, (ref) v_u_234
			local v235 = require((script.Parent:WaitForChild("MenuPvpveDoor", 5)))
			local v236, v237 = p_u_231.cctx.shared.PvpveDoorRules.visible(v235.facts(p_u_231))
			local v238
			if v236 == true then
				v238 = v237 == "ok"
			else
				v238 = false
			end
			v_u_234 = v238
		end)
	end
	local v239 = {
		["pvp"] = v_u_232,
		["door"] = v_u_234
	}
	return v_u_9.kind(v239), v_u_232
end
function v_u_4.open(p_u_241) -- name: open
	-- upvalues: (copy) v_u_4, (ref) v_u_27, (copy) v_u_240, (copy) v_u_31, (ref) v_u_9, (ref) v_u_17, (copy) v_u_23, (copy) v_u_24, (copy) v_u_2, (copy) v_u_133, (copy) v_u_22, (copy) v_u_7, (copy) v_u_224, (copy) v_u_3, (copy) v_u_230, (copy) v_u_36
	v_u_4.bind(p_u_241)
	if v_u_27 and v_u_27.alive then
		if v_u_27.kind == "squads" then
			return
		end
		v_u_4.close()
	end
	local v_u_242, v_u_243 = v_u_240(p_u_241)
	local v_u_244 = p_u_241.ui
	local v_u_245 = p_u_241.theme
	local v_u_246 = v_u_245.color
	local v_u_247 = v_u_245.refSize()
	local v248 = v_u_247.X - 32
	local v249 = math.min(940, v248)
	local v_u_250 = v249 - 2 * v_u_245.space.l
	local v251 = v_u_247.Y - 470
	local v_u_252 = math.clamp(v251, 150, 420)
	local v_u_253 = {
		["kind"] = "squads",
		["alive"] = true
	}
	v_u_27 = v_u_253
	local v254 = p_u_241.party
	local v255
	if type(v254) == "table" then
		v255 = v254.voiceLobby == true
	else
		v255 = false
	end
	local v256 = v_u_244.modal
	local v350 = {
		["title"] = nil,
		["body"] = nil,
		["width"] = nil,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["title"] = v255 and "Squads \194\183 Voice lobby" or "Squads",
		["width"] = v249,
		["build"] = function(p257) -- name: build
			-- upvalues: (copy) v_u_244, (copy) v_u_246, (ref) v_u_4, (copy) p_u_241, (ref) v_u_31, (copy) v_u_250, (copy) v_u_253, (copy) v_u_252, (ref) v_u_9, (copy) v_u_242, (copy) v_u_245, (copy) v_u_247, (ref) v_u_17, (ref) v_u_23, (ref) v_u_24, (ref) v_u_2, (ref) v_u_133, (ref) v_u_22, (ref) v_u_7, (ref) v_u_224, (copy) v_u_243, (ref) v_u_3
			local v258 = v_u_244.new("Frame", {
				["Name"] = "Mine",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["BackgroundColor3"] = v_u_246.raised,
				["Size"] = UDim2.new(1, 0, 0, 84)
			}, p257)
			v_u_244.stroke(v258, v_u_246.line)
			v_u_244.label({
				["parent"] = nil,
				["text"] = "YOUR SQUAD",
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v258,
				["color"] = v_u_246.accent,
				["position"] = UDim2.fromOffset(14, 8),
				["size"] = UDim2.fromOffset(160, 16)
			})
			local v_u_259 = v_u_244.label({
				["parent"] = nil,
				["name"] = "Help",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v258,
				["color"] = v_u_246.text2,
				["position"] = UDim2.fromOffset(14, 58),
				["size"] = UDim2.new(1, -28, 0, 18)
			})
			v_u_259.TextTruncate = Enum.TextTruncate.AtEnd
			local v260 = v_u_244.new("Frame", {
				["Name"] = "Visibility",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(14, 26),
				["Size"] = UDim2.new(0, 360, 0, 32)
			}, v258)
			v_u_244.layout(v260, "h", 6)
			local v_u_261 = {}
			for v262, v_u_263 in { "private", "friends", "public" } do
				local _, v267 = v_u_244.button({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["kind"] = "ghost",
					["height"] = 32,
					["width"] = 112,
					["order"] = nil,
					["onClick"] = nil,
					["parent"] = v260,
					["name"] = "Vis_" .. v_u_263,
					["text"] = v_u_4.visText(v_u_263),
					["order"] = v262,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_241, (copy) v_u_261, (copy) v_u_263, (ref) v_u_244, (copy) v_u_259, (ref) v_u_31
						if p_u_241.isLeader() then
							for v264, v265 in v_u_261 do
								v265.setSelected(v264 == v_u_263)
							end
							v_u_244.setText(v_u_259, v_u_31[v_u_263])
							local v266 = {
								["op"] = "visibility",
								["value"] = nil,
								["value"] = v_u_263
							}
							p_u_241.partyOp(v266)
						end
					end
				})
				v_u_261[v_u_263] = v267
			end
			local v268 = v_u_244.new
			local v269 = {
				["Name"] = "Right",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -14, 0, 8)
			}
			local v270 = UDim2.fromOffset
			local v271 = v_u_250 - 400
			v269.Size = v270(math.max(200, v271), 50)
			local v272 = v268("Frame", v269, v258)
			local v_u_273 = v_u_244.label({
				["parent"] = nil,
				["name"] = "Age",
				["text"] = "",
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v272,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(1, 0, 0, 20)
			})
			v_u_273.TextXAlignment = Enum.TextXAlignment.Right
			v_u_273.TextTruncate = Enum.TextTruncate.AtEnd
			local v_u_274 = v_u_244.button({
				["parent"] = nil,
				["name"] = "CreatePublic",
				["text"] = "Create public squad",
				["kind"] = "primary",
				["height"] = 32,
				["width"] = 220,
				["position"] = nil,
				["anchor"] = nil,
				["onClick"] = nil,
				["parent"] = v272,
				["position"] = UDim2.new(1, 0, 0, 20),
				["anchor"] = Vector2.new(1, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_241
					p_u_241.partyOp({
						["op"] = "createPublic"
					})
				end
			})
			function v_u_253.mine()
				-- upvalues: (ref) p_u_241, (copy) v_u_261, (ref) v_u_244, (copy) v_u_259, (ref) v_u_31, (copy) v_u_273, (ref) v_u_4, (copy) v_u_274
				local v275 = p_u_241.party
				local v276 = type(v275) == "table" and v275.party or nil
				local v277
				if v276 then
					local v278 = v276.visibility
					v277 = type(v278) ~= "string" and "public" or v276.visibility
				else
					v277 = "public"
				end
				local v279 = p_u_241.isLeader()
				for v280, v281 in v_u_261 do
					v281.setSelected(v280 == v277)
					v281.setEnabled(v279)
				end
				local v282
				if v276 then
					local v283 = v276.members
					v282 = type(v283) == "table" and #v276.members or 1
				else
					v282 = 1
				end
				v_u_244.setText(v_u_259, not v279 and "Only the squad leader decides who may join." or v_u_31[v277])
				if v282 > 1 then
					local v284 = v_u_244.setText
					local v285 = v_u_273
					local v286 = "%s of your squad in your age group"
					local v287 = v_u_4.ageText
					local v288
					if v276 then
						v288 = v276.ageShare
					else
						v288 = v276
					end
					v284(v285, v286:format(v287(v288)))
				else
					v_u_244.setText(v_u_273, "Solo")
				end
				local v289 = v_u_274
				if v279 then
					v279 = false
					local v290
					if v276 then
						v290 = v276.maxSize
					else
						v290 = v276
					end
					if v282 < (tonumber(v290) or 4) then
						v279 = v276 == nil and true or v277 ~= "public"
					end
				end
				v289.Visible = v279
			end
			local v291 = v_u_253.mine
			pcall(v291)
			local v292 = v_u_252
			if v_u_9 ~= nil and v_u_242 ~= nil then
				local function v293()
					-- upvalues: (ref) v_u_245, (ref) v_u_9
					return v_u_245.phoneText(v_u_9.SIZE_FULL, "caption"), v_u_245.phoneText(v_u_9.SIZE_SHORT, "caption")
				end
				local v294, v295, v296 = pcall(v293)
				local v297 = v_u_9.layout(v_u_250, {
					["kind"] = v_u_242,
					["refY"] = v_u_247.Y,
					["sizes"] = v294 and {
						["full"] = v295,
						["short"] = v296
					} or nil
				})
				if v297.mode ~= "none" then
					local v298 = v_u_247.Y - 470 - (v297.h + 8)
					v292 = math.clamp(v298, 110, 420)
					local v299 = v_u_244.new("Frame", {
						["Name"] = "FriendsHint",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.5,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = 2,
						["BackgroundColor3"] = v_u_246.raised,
						["Size"] = UDim2.new(1, 0, 0, v297.h)
					}, p257)
					v_u_244.new("Frame", {
						["Name"] = "HintBar",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_246.accent,
						["Size"] = UDim2.fromOffset(v297.bar.w, v297.bar.h)
					}, v299)
					v_u_244.label({
						["parent"] = nil,
						["name"] = "HintText",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = nil,
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v299,
						["text"] = v297.text,
						["textSize"] = v297.size,
						["color"] = v_u_246.text2,
						["position"] = UDim2.fromOffset(v297.label.x, v297.label.y),
						["size"] = UDim2.new(1, -(v297.label.x + v297.padX), 0, v297.label.h)
					})
				end
			end
			local v300 = v_u_244.new("Frame", {
				["Name"] = "Filters",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 3,
				["Size"] = UDim2.new(1, 0, 0, 34)
			}, p257)
			v_u_244.layout(v300, "h", 6)
			local v305 = {
				["parent"] = nil,
				["name"] = "Diff",
				["text"] = "",
				["kind"] = "ghost",
				["height"] = 32,
				["width"] = 168,
				["order"] = 1,
				["onClick"] = nil,
				["parent"] = v300,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_17, (ref) v_u_23, (ref) v_u_24, (ref) v_u_253, (ref) v_u_2
					v_u_23.diff = v_u_17[(table.find(v_u_17, v_u_23.diff) or 1) % #v_u_17 + 1]
					v_u_24.squads = 1
					local v301 = v_u_253.filters
					pcall(v301)
					local v302 = v_u_2:FindFirstChild("HushNet")
					if v302 then
						v302 = v302:FindFirstChild("party.op")
					end
					if not (v302 and v302:IsA("RemoteEvent")) then
						v302 = nil
					end
					if v302 then
						local v303 = {
							["op"] = "browse",
							["page"] = nil,
							["diff"] = nil,
							["voice"] = nil,
							["region"] = nil,
							["friends"] = nil,
							["page"] = v_u_24.squads
						}
						local v304
						if v_u_23.diff == "Any" then
							v304 = nil
						else
							v304 = v_u_23.diff
						end
						v303.diff = v304
						v303.voice = v_u_23.voice
						v303.region = v_u_23.region
						v303.friends = v_u_23.friends
						v302:FireServer(v303)
					end
				end
			}
			local _, v_u_306 = v_u_244.button(v305)
			local v_u_307 = {}
			for v308, v_u_309 in { "voice", "region", "friends" } do
				local _, v314 = v_u_244.button({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["kind"] = "ghost",
					["height"] = 32,
					["width"] = nil,
					["order"] = nil,
					["onClick"] = nil,
					["parent"] = v300,
					["name"] = "F_" .. v_u_309,
					["text"] = v_u_309 == "voice" and "Voice" or (v_u_309 == "region" and "My region" or "Friends"),
					["width"] = v_u_309 == "region" and 124 or 104,
					["order"] = 1 + v308,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_23, (copy) v_u_309, (ref) v_u_24, (ref) v_u_253, (ref) v_u_2
						v_u_23[v_u_309] = not v_u_23[v_u_309]
						v_u_24.squads = 1
						local v310 = v_u_253.filters
						pcall(v310)
						local v311 = v_u_2:FindFirstChild("HushNet")
						if v311 then
							v311 = v311:FindFirstChild("party.op")
						end
						if not (v311 and v311:IsA("RemoteEvent")) then
							v311 = nil
						end
						if v311 then
							local v312 = {
								["op"] = "browse",
								["page"] = nil,
								["diff"] = nil,
								["voice"] = nil,
								["region"] = nil,
								["friends"] = nil,
								["page"] = v_u_24.squads
							}
							local v313
							if v_u_23.diff == "Any" then
								v313 = nil
							else
								v313 = v_u_23.diff
							end
							v312.diff = v313
							v312.voice = v_u_23.voice
							v312.region = v_u_23.region
							v312.friends = v_u_23.friends
							v311:FireServer(v312)
						end
					end
				})
				v_u_307[v_u_309] = v314
			end
			local v318 = {
				["parent"] = nil,
				["name"] = "Refresh",
				["icon"] = "search",
				["kind"] = "ghost",
				["size"] = 32,
				["order"] = 9,
				["tooltip"] = "Refresh the list",
				["onClick"] = nil,
				["parent"] = v300,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_2, (ref) v_u_24, (ref) v_u_23
					local v315 = v_u_2:FindFirstChild("HushNet")
					if v315 then
						v315 = v315:FindFirstChild("party.op")
					end
					if not (v315 and v315:IsA("RemoteEvent")) then
						v315 = nil
					end
					if v315 then
						local v316 = {
							["op"] = "browse",
							["page"] = nil,
							["diff"] = nil,
							["voice"] = nil,
							["region"] = nil,
							["friends"] = nil,
							["page"] = v_u_24.squads
						}
						local v317
						if v_u_23.diff == "Any" then
							v317 = nil
						else
							v317 = v_u_23.diff
						end
						v316.diff = v317
						v316.voice = v_u_23.voice
						v316.region = v_u_23.region
						v316.friends = v_u_23.friends
						v315:FireServer(v316)
					end
				end
			}
			v_u_244.iconButton(v318)
			function v_u_253.filters()
				-- upvalues: (copy) v_u_306, (ref) v_u_23, (copy) v_u_307
				v_u_306.setText(v_u_23.diff == "Any" and "Any difficulty" or v_u_23.diff)
				v_u_306.setSelected(v_u_23.diff ~= "Any")
				for v319, v320 in v_u_307 do
					v320.setSelected(v_u_23[v319] == true)
				end
			end
			local v321 = v_u_253.filters
			pcall(v321)
			local v_u_322 = v_u_244.list({
				["parent"] = nil,
				["name"] = "SquadList",
				["size"] = nil,
				["gap"] = 6,
				["parent"] = p257,
				["size"] = UDim2.new(1, 0, 0, v292)
			})
			v_u_322.LayoutOrder = 4
			local v_u_323 = v_u_133(v_u_244, v_u_246, p257, "squads", 5, p_u_241.theme)
			local v_u_324 = ""
			local v_u_325 = true
			function v_u_253.repaint()
				-- upvalues: (ref) v_u_22, (copy) v_u_323, (ref) v_u_7, (ref) v_u_324, (ref) v_u_244, (copy) v_u_322, (ref) p_u_241, (ref) v_u_224, (ref) v_u_250, (ref) v_u_9, (ref) v_u_243, (ref) v_u_23, (ref) v_u_325, (ref) v_u_253, (ref) v_u_3
				local v_u_326 = v_u_22.squads
				local v_u_327 = not v_u_326 and {} or v_u_326.rows
				local v328 = ""
				for _, v329 in v_u_327 do
					local v330 = v329.id
					local v331 = tostring(v330)
					local v332 = v329.n
					local v333 = tostring(v332)
					local v334 = v329.age
					local v335 = tostring(v334)
					local v336 = v329.friend
					local v337 = tostring(v336)
					local v338 = v329.diff
					local v339 = tostring(v338)
					local v340 = v329.voiceN
					local v341 = tostring(v340)
					local v342 = v329.searching
					local v343 = tostring(v342)
					local v344 = v329.diffLocked
					v328 = v328 .. v331 .. v333 .. v335 .. v337 .. v339 .. v341 .. v343 .. tostring(v344) .. ";"
				end
				v_u_323.paint(v_u_326, not v_u_326 and "Looking for squads" or v_u_7.openHeader(v_u_326))
				if v328 ~= v_u_324 or not v_u_326 then
					v_u_324 = v328
					v_u_244.keepScroll(v_u_322, function()
						-- upvalues: (ref) p_u_241, (ref) v_u_322, (copy) v_u_327, (ref) v_u_224, (ref) v_u_250, (ref) v_u_9, (copy) v_u_326, (ref) v_u_243, (ref) v_u_23, (ref) v_u_325, (ref) v_u_244, (ref) v_u_253, (ref) v_u_3
						p_u_241.kit.clear(v_u_322)
						local v_u_345 = nil
						for v346, v347 in v_u_327 do
							v_u_345 = v_u_345 or v_u_224(p_u_241, v_u_322, v347, v346, v_u_250)
						end
						if #v_u_327 == 0 then
							local v348
							if v_u_9 == nil then
								v348 = v_u_326 and (v_u_23.diff == "Any" and not (v_u_23.voice or (v_u_23.region or v_u_23.friends)) and "No open squads right now. Open yours as PUBLIC and survivors who play solo can find you." or "No squad matches these filters. Turn a filter off, or open your squad as PUBLIC so others find you.") or "Loading"
							else
								v348 = v_u_9.emptyText({
									["loaded"] = v_u_326 ~= nil,
									["pvp"] = v_u_243,
									["filters"] = v_u_23
								})
							end
							p_u_241.kit.empty(v_u_322, v348)
						end
						if v_u_325 and (v_u_345 and v_u_244.device() == "Gamepad") then
							v_u_325 = false
							task.delay(0.15, function()
								-- upvalues: (ref) v_u_253, (ref) v_u_345, (ref) v_u_3
								if v_u_253.alive and v_u_345.Parent then
									v_u_3.SelectedObject = v_u_345
								end
							end)
						end
					end)
				end
			end
			local v349 = v_u_253.repaint
			pcall(v349)
		end
	}
	local v351 = {}
	local v352 = {
		["text"] = nil,
		["kind"] = "secondary",
		["onClick"] = nil
	}
	local v353 = v_u_7.voiceButton
	local v354
	if type(v254) == "table" then
		v354 = v254.voicePlace == true
	else
		v354 = false
	end
	v352.text = v353(v255, v354)
	function v352.onClick() -- name: onClick
		-- upvalues: (ref) v_u_230, (copy) p_u_241
		v_u_230(p_u_241)
		return true
	end
	__set_list(v351, 1, {v352, {
	["text"] = "Close"
}})
	v350.buttons = v351
	function v350.onClose() -- name: onClose
		-- upvalues: (copy) v_u_253, (ref) v_u_27
		v_u_253.alive = false
		if v_u_27 == v_u_253 then
			v_u_27 = nil
		end
	end
	v_u_253.api = v256(v350)
	local v355 = v_u_2:FindFirstChild("HushNet")
	if v355 then
		v355 = v355:FindFirstChild("party.op")
	end
	if not (v355 and v355:IsA("RemoteEvent")) then
		v355 = nil
	end
	if v355 then
		local v356 = {
			["op"] = "browse",
			["page"] = nil,
			["diff"] = nil,
			["voice"] = nil,
			["region"] = nil,
			["friends"] = nil,
			["page"] = v_u_24.squads
		}
		local v357
		if v_u_23.diff == "Any" then
			v357 = nil
		else
			v357 = v_u_23.diff
		end
		v356.diff = v357
		v356.voice = v_u_23.voice
		v356.region = v_u_23.region
		v356.friends = v_u_23.friends
		v355:FireServer(v356)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_253, (ref) v_u_36
		while v_u_253.alive do
			task.wait(5)
			if not v_u_253.alive then
				continue
			end
			v_u_36(v_u_253.kind)
		end
	end)
end
function v_u_4.openInvite(p_u_358) -- name: openInvite
	-- upvalues: (copy) v_u_4, (ref) v_u_27, (copy) v_u_24, (copy) v_u_7, (copy) v_u_133, (ref) v_u_11, (copy) v_u_22, (ref) v_u_13, (copy) v_u_20, (copy) v_u_2, (copy) v_u_36
	v_u_4.bind(p_u_358)
	if v_u_27 and v_u_27.alive then
		v_u_4.close()
	end
	local v_u_359 = p_u_358.ui
	local v_u_360 = p_u_358.theme
	local v_u_361 = v_u_360.color
	local v362 = v_u_360.refSize()
	local v363 = v362.Y - 420
	local v_u_364 = math.clamp(v363, 160, 420)
	local v365 = v362.X - 32
	local v366 = math.min(560, v365)
	local v_u_367 = v366 - 2 * v_u_360.space.l
	local v_u_368
	if v_u_360.isPhone() == true then
		local v369 = v_u_360.touch(32) + 4
		v_u_368 = math.max(48, v369)
	else
		v_u_368 = 48
	end
	local v_u_370 = {
		["kind"] = "players",
		["alive"] = true
	}
	v_u_27 = v_u_370
	v_u_24.players = 1
	v_u_370.api = v_u_359.modal({
		["title"] = "Invite to squad",
		["body"] = nil,
		["width"] = nil,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["body"] = v_u_7.INVITE_BODY,
		["width"] = v366,
		["build"] = function(p371) -- name: build
			-- upvalues: (copy) v_u_359, (copy) v_u_364, (ref) v_u_133, (copy) v_u_361, (copy) v_u_360, (ref) v_u_11, (copy) p_u_358, (copy) v_u_367, (copy) v_u_370, (ref) v_u_22, (copy) v_u_368, (ref) v_u_13, (ref) v_u_20, (ref) v_u_7
			local v_u_372 = v_u_359.list({
				["parent"] = nil,
				["name"] = "PlayerList",
				["size"] = nil,
				["gap"] = 4,
				["parent"] = p371,
				["size"] = UDim2.new(1, 0, 0, v_u_364)
			})
			v_u_372.LayoutOrder = 1
			local v_u_373 = v_u_133(v_u_359, v_u_361, p371, "players", 2, v_u_360)
			if v_u_11 ~= nil then
				local v374 = v_u_11.new
				local v375 = p_u_358
				local v376 = {
					["order"] = 3,
					["width"] = nil,
					["list"] = nil,
					["width"] = v_u_367,
					["list"] = v_u_372
				}
				local v377, v378 = pcall(v374, v375, p371, v376)
				if v377 and type(v378) == "table" then
					v_u_370.friends = v378
				else
					warn("[MenuSquads] friends block failed:", v378)
				end
			end
			local v_u_379 = ""
			local v_u_380 = false
			function v_u_370.repaint()
				-- upvalues: (ref) v_u_22, (copy) v_u_373, (ref) v_u_370, (ref) v_u_379, (ref) v_u_380, (ref) v_u_359, (copy) v_u_372, (ref) p_u_358, (ref) v_u_361, (ref) v_u_368, (ref) v_u_13, (ref) v_u_20, (ref) v_u_7
				local v_u_381 = v_u_22.players
				local v_u_382 = not v_u_381 and {} or v_u_381.rows
				local v383 = v_u_373.paint
				local v384
				if v_u_381 then
					local v385 = v_u_381.total
					v384 = ("%d survivor%s here"):format(tonumber(v385) or 0, v_u_381.total == 1 and "" or "s")
				else
					v384 = "Loading"
				end
				v383(v_u_381, v384)
				if v_u_370.friends ~= nil then
					local v386 = v_u_370.friends.repaint
					pcall(v386, v_u_381)
				end
				local v387 = ""
				for _, v388 in v_u_382 do
					local v389 = v388.userId
					local v390 = tostring(v389)
					local v391 = v388.where
					local v392 = tostring(v391)
					local v393 = v388.inParty
					local v394 = tostring(v393)
					local v395 = v388.sameParty
					v387 = v387 .. v390 .. v392 .. v394 .. tostring(v395) .. ";"
				end
				if v387 ~= v_u_379 or not (v_u_381 and v_u_380) then
					v_u_379 = v387
					v_u_380 = v_u_381 ~= nil
					v_u_359.keepScroll(v_u_372, function()
						-- upvalues: (ref) p_u_358, (ref) v_u_372, (copy) v_u_382, (ref) v_u_359, (ref) v_u_361, (ref) v_u_368, (ref) v_u_13, (ref) v_u_20, (ref) v_u_7, (copy) v_u_381
						p_u_358.kit.clear(v_u_372)
						local v396 = false
						for v397, v_u_398 in v_u_382 do
							if type(v_u_398) ~= "table" or v_u_398.sameParty then
								continue
							end
							v396 = true
							local v_u_399 = v_u_359.new("Frame", {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["Name"] = "P" .. v397,
								["BackgroundColor3"] = v_u_361.raised,
								["Size"] = UDim2.new(1, -8, 0, v_u_368),
								["LayoutOrder"] = v397
							}, v_u_372)
							local v400 = v_u_359.stroke
							local v401
							if v_u_398.friend then
								v401 = v_u_361.accentDim
							else
								v401 = v_u_361.line
							end
							v400(v_u_399, v401)
							local v402 = false
							local v403
							if v_u_13 then
								if v_u_13.playerRowRich then
									v403, v402 = v_u_13.playerRowRich(v_u_398)
								else
									v403 = v_u_13.playerRowName(v_u_398)
								end
							else
								local v404 = v_u_398.displayName or v_u_398.name
								v403 = tostring(v404)
							end
							v_u_359.label({
								["parent"] = nil,
								["text"] = nil,
								["rich"] = nil,
								["style"] = "bodyStrong",
								["position"] = nil,
								["size"] = nil,
								["parent"] = v_u_399,
								["text"] = v403,
								["rich"] = v402,
								["position"] = UDim2.fromOffset(14, 5),
								["size"] = UDim2.new(1, -150, 0, 20)
							}).TextTruncate = Enum.TextTruncate.AtEnd
							local v405 = v_u_398.place or "Menu"
							local v_u_406 = tostring(v405)
							local v407 = v_u_359.label
							local v408 = {
								["parent"] = nil,
								["text"] = nil,
								["style"] = "micro",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["parent"] = v_u_399,
								["text"] = (v_u_398.friend and "Friend \194\183 " or "") .. (v_u_398.inParty and "In a squad \194\183 " or "") .. (v_u_406 == "Raid" and "In a raid" or (v_u_406 == "Hideout" and "In the hideout" or (v_u_406 == "Transit" and "Travelling" or "In the menu")))
							}
							local v409
							if v_u_398.friend then
								v409 = v_u_361.accent
							else
								v409 = v_u_361.text2
							end
							v408.color = v409
							v408.position = UDim2.fromOffset(14, 26)
							v408.size = UDim2.new(1, -150, 0, 14)
							v407(v408).TextTruncate = Enum.TextTruncate.AtEnd
							local v410 = v_u_398.userId
							local v_u_411 = tonumber(v410) or 0
							local v_u_412 = nil
							local _, v440 = v_u_359.button({
								["parent"] = nil,
								["name"] = "Invite",
								["text"] = "Invite",
								["kind"] = "secondary",
								["height"] = 32,
								["width"] = 110,
								["position"] = nil,
								["anchor"] = nil,
								["onClick"] = nil,
								["parent"] = v_u_399,
								["position"] = UDim2.new(1, -8, 0.5, 0),
								["anchor"] = Vector2.new(1, 0.5),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_20, (copy) v_u_411, (ref) p_u_358, (copy) v_u_398, (ref) v_u_412, (ref) v_u_7, (copy) v_u_406, (copy) v_u_399
									local v413 = v_u_20[v_u_411]
									local v414
									if v413 then
										local v415 = 10 - (os.clock() - v413)
										v414 = math.max(0, v415)
									else
										v414 = 0
									end
									if v414 <= 0 then
										v_u_20[v_u_411] = os.clock()
										p_u_358.partyOp({
											["op"] = "invite",
											["userId"] = nil,
											["userId"] = v_u_398.userId
										})
										if v_u_412 then
											local v416 = v_u_7.inviteButton
											local v417 = v_u_406
											local v418 = v_u_20[v_u_411]
											local v419
											if v418 then
												local v420 = 10 - (os.clock() - v418)
												v419 = math.max(0, v420)
											else
												v419 = 0
											end
											local v421, v422 = v416(v417, v419)
											v_u_412.setEnabled(v422)
											v_u_412.setText(v421)
										end
										task.spawn(function()
											-- upvalues: (ref) v_u_399, (ref) v_u_20, (ref) v_u_411, (ref) v_u_412, (ref) v_u_7, (ref) v_u_406
											while v_u_399.Parent do
												local v423 = v_u_20[v_u_411]
												local v424
												if v423 then
													local v425 = 10 - (os.clock() - v423)
													v424 = math.max(0, v425)
												else
													v424 = 0
												end
												if v424 <= 0 then
													break
												end
												task.wait(0.5)
												if not v_u_412 then
													continue
												end
												local v426 = v_u_7.inviteButton
												local v427 = v_u_406
												local v428 = v_u_20[v_u_411]
												local v429
												if v428 then
													local v430 = 10 - (os.clock() - v428)
													v429 = math.max(0, v430)
												else
													v429 = 0
												end
												local v431, v432 = v426(v427, v429)
												v_u_412.setEnabled(v432)
												v_u_412.setText(v431)
											end
											if v_u_412 then
												local v433 = v_u_7.inviteButton
												local v434 = v_u_406
												local v435 = v_u_20[v_u_411]
												local v436
												if v435 then
													local v437 = 10 - (os.clock() - v435)
													v436 = math.max(0, v437)
												else
													v436 = 0
												end
												local v438, v439 = v433(v434, v436)
												v_u_412.setEnabled(v439)
												v_u_412.setText(v438)
											end
										end)
									end
								end
							})
							v_u_412 = v440
							if v_u_412 then
								local v441 = v_u_7.inviteButton
								local v442 = v_u_20[v_u_411]
								local v443
								if v442 then
									local v444 = 10 - (os.clock() - v442)
									v443 = math.max(0, v444)
								else
									v443 = 0
								end
								local v445, v446 = v441(v_u_406, v443)
								v_u_412.setEnabled(v446)
								v_u_412.setText(v445)
							end
							local v447 = v_u_20[v_u_411]
							local v448
							if v447 then
								local v449 = 10 - (os.clock() - v447)
								v448 = math.max(0, v449)
							else
								v448 = 0
							end
							if v448 <= 0 then
								continue
							end
							task.spawn(function()
								-- upvalues: (copy) v_u_399, (ref) v_u_20, (copy) v_u_411, (ref) v_u_412, (ref) v_u_7, (copy) v_u_406
								while v_u_399.Parent do
									local v450 = v_u_20[v_u_411]
									local v451
									if v450 then
										local v452 = 10 - (os.clock() - v450)
										v451 = math.max(0, v452)
									else
										v451 = 0
									end
									if v451 <= 0 then
										break
									end
									task.wait(0.5)
									if not v_u_412 then
										continue
									end
									local v453 = v_u_7.inviteButton
									local v454 = v_u_406
									local v455 = v_u_20[v_u_411]
									local v456
									if v455 then
										local v457 = 10 - (os.clock() - v455)
										v456 = math.max(0, v457)
									else
										v456 = 0
									end
									local v458, v459 = v453(v454, v456)
									v_u_412.setEnabled(v459)
									v_u_412.setText(v458)
								end
								if v_u_412 then
									local v460 = v_u_7.inviteButton
									local v461 = v_u_406
									local v462 = v_u_20[v_u_411]
									local v463
									if v462 then
										local v464 = 10 - (os.clock() - v462)
										v463 = math.max(0, v464)
									else
										v463 = 0
									end
									local v465, v466 = v460(v461, v463)
									v_u_412.setEnabled(v466)
									v_u_412.setText(v465)
								end
							end)
						end
						if not v396 then
							p_u_358.kit.empty(v_u_372, not v_u_381 and "Loading" or v_u_7.inviteEmpty())
						end
					end)
				end
			end
			local v467 = v_u_370.repaint
			pcall(v467)
		end,
		["buttons"] = {
			{
				["text"] = "Close"
			}
		},
		["onClose"] = function() -- name: onClose
			-- upvalues: (copy) v_u_370, (ref) v_u_27
			v_u_370.alive = false
			if v_u_370.friends ~= nil then
				local v468 = v_u_370.friends.destroy
				pcall(v468)
			end
			if v_u_27 == v_u_370 then
				v_u_27 = nil
			end
		end
	})
	local v469 = v_u_2:FindFirstChild("HushNet")
	if v469 then
		v469 = v469:FindFirstChild("party.op")
	end
	if not (v469 and v469:IsA("RemoteEvent")) then
		v469 = nil
	end
	if v469 then
		v469:FireServer({
			["op"] = "players",
			["page"] = nil,
			["page"] = v_u_24.players
		})
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_370, (ref) v_u_36
		while v_u_370.alive do
			task.wait(5)
			if not v_u_370.alive then
				continue
			end
			v_u_36(v_u_370.kind)
		end
	end)
end
return v_u_4