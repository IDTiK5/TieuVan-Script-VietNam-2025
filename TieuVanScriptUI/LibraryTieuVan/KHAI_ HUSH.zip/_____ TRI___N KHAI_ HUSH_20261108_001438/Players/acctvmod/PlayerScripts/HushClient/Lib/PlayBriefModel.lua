-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayBriefModel

local v_u_1 = {
	["T"] = {
		["brief"] = "Raid brief",
		["solo"] = "Solo",
		["squad"] = "Squad %d of %d",
		["setBy"] = "Set by %s",
		["searching"] = "Searching",
		["difficulty"] = "Difficulty",
		["timeOfDay"] = "Time of day",
		["time"] = "Time",
		["kit"] = "Kit",
		["raid"] = "Raid",
		["mode"] = "Mode",
		["yourKit"] = "Your kit",
		["freeRaid"] = "Free raid",
		["public"] = "Public",
		["private"] = "Private",
		["privateFriends"] = "Private and friends",
		["friends"] = "Friends",
		["anyTime"] = "Any time",
		["day"] = "Day",
		["dusk"] = "Dusk",
		["night"] = "Night",
		["atStake"] = "%s at stake",
		["randomKit"] = "Random kit, nothing at stake",
		["othersMayJoin"] = "Other squads may join",
		["onlySquad"] = "Only your squad",
		["friendsMayJoin"] = "Friends\' squads may join",
		["alwaysPublic"] = "Always public in PVPVE",
		["onlyDiffHere"] = "The only difficulty here",
		["setByMap"] = "Set by the map",
		["nightmareNight"] = "Nightmare is night only",
		["raidSetup"] = "Raid setup",
		["setup"] = "Setup",
		["needed"] = "Needed",
		["noTask"] = "No active task",
		["pickJob"] = "Pick a job in TASKS.",
		["loadingTasks"] = "Loading tasks",
		["tasksFailed"] = "Tasks did not load",
		["tryAgain"] = "Open the card to try again.",
		["whyMember"] = "Set by %s. Only the squad leader can change it.",
		["whySearching"] = "Locked while searching. Stop the search to change it.",
		["whyPublic"] = "PvP raids are always public.",
		["whyDiff"] = "The only difficulty in PVPVE.",
		["sheetSolo"] = "Your raid deploys with this setup.",
		["sheetSquad"] = "Your squad deploys with this setup.",
		["sheetMap"] = "Map",
		["sheetDifficulty"] = "Difficulty",
		["sheetTime"] = "Time",
		["sheetKit"] = "Kit",
		["sheetRaid"] = "Raid",
		["sheetMode"] = "Mode",
		["sheetSoloFp"] = "Your raid deploys with this setup, in FP / TP.",
		["sheetSquadFp"] = "Your squad deploys with this setup, in FP / TP.",
		["moreBelow"] = "More below",
		["close"] = "Close",
		["coach"] = "Your raid at a glance. Open RAID SETUP to change map, difficulty and kit, then DEPLOY. New here? Start with the tutorial at the top.",
		["tip"] = "Change map, difficulty and kit here."
	}
}
local v_u_2 = {
	["diffLine"] = {
		["Normal"] = "The town as it is",
		["Hard"] = "More, faster infected",
		["Nightmare"] = "Night only, fast bites"
	},
	["timeOdds"] = {
		["Any"] = "Random",
		["Day"] = "Clear view",
		["Dusk"] = "Fading light",
		["Night"] = "Pitch dark"
	}
}
local v_u_5 = {
	["TEXT"] = {
		["classicSub"] = "Top down view",
		["fptpSub"] = "Switch views any time",
		["classicCard"] = "The top down view you know.",
		["fptpCard"] = "Free camera, aim down sights, switch views any time.",
		["queueNote"] = "Squads queue separately for each mode."
	},
	["label"] = function(p3) -- name: label
		return p3 == "fptp" and "FIRST / THIRD PERSON" or "CLASSIC"
	end,
	["short"] = function(p4) -- name: short
		return p4 == "fptp" and "FP / TP" or "CLASSIC"
	end
}
v_u_1.VIEW_FALLBACK = v_u_5
local v_u_6 = nil
function v_u_1.upper(p7) -- name: upper
	return string.upper(p7)
end
local function v_u_9(p8, ...) -- name: fmt
	return string.format(p8, ...)
end
function v_u_1.view(p10, p11) -- name: view
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_9, (ref) v_u_6, (copy) v_u_5
	local v12 = v_u_1.T
	local v13 = p10 or {}
	local v14 = p11 or {}
	local v15 = v14.diffLine or v_u_2.diffLine
	local v16 = v14.timeOdds or v_u_2.timeOdds
	local v17 = v13.difficulty ~= "Hard" and v13.difficulty ~= "Nightmare" and "Normal" or v13.difficulty
	local v18 = v13.pvpve == true and "Hard" or v17
	local v19 = v13.timeOfDay ~= "Day" and (v13.timeOfDay ~= "Dusk" and v13.timeOfDay ~= "Night") and "Any" or v13.timeOfDay
	local v20 = v13.searching == true and true or v13.member == true
	local v21 = v13.partySize
	local v22 = tonumber(v21) or 1
	local v23 = v13.partyMax
	local v24 = tonumber(v23) or 4
	local v25
	if v13.searching == true then
		v25 = {
			["left"] = nil,
			["right"] = nil,
			["tone"] = "accent",
			["lock"] = true,
			["left"] = v12.brief,
			["right"] = v12.searching
		}
	elseif v13.member == true then
		v25 = {
			["left"] = nil,
			["right"] = nil,
			["tone"] = "accent",
			["lock"] = true,
			["left"] = v12.brief
		}
		local v26 = v_u_9
		local v27 = v12.setBy
		local v28 = v13.memberName
		if type(v28) ~= "string" or v28 == "" then
			v28 = nil
		end
		v25.right = v26(v27, v28 or "leader")
	elseif v22 > 1 then
		v25 = {
			["left"] = nil,
			["right"] = nil,
			["tone"] = "text2",
			["lock"] = false,
			["left"] = v12.brief,
			["right"] = v_u_9(v12.squad, v22, v24)
		}
	else
		v25 = {
			["left"] = nil,
			["right"] = nil,
			["tone"] = "text2",
			["lock"] = false,
			["left"] = v12.brief,
			["right"] = v12.solo
		}
	end
	local v29 = v13.map or {}
	local v30 = {}
	local v31 = v29.name
	if type(v31) ~= "string" or v31 == "" then
		v31 = nil
	end
	v30.name = v31 or "Operation area"
	local v32 = v29.act
	if type(v32) ~= "string" or v32 == "" then
		v32 = nil
	end
	v30.act = v32
	local v33 = v29.tag
	if type(v33) ~= "string" or v33 == "" then
		v33 = nil
	end
	v30.tag = v33
	local v34 = v29.tagline
	if type(v34) ~= "string" or v34 == "" then
		v34 = nil
	end
	v30.tagline = v34
	local v35 = v29.stats
	if type(v35) ~= "string" or v35 == "" then
		v35 = nil
	end
	v30.stats = v35
	local v36 = v29.minutes
	v30.minutes = tonumber(v36)
	v30.fixed = v20
	local v37 = v12.whyDiff
	local v38 = v_u_1.T
	if v13.pvpve ~= true or v37 == nil then
		if v13.searching == true then
			v37 = v38.whySearching
		elseif v13.member == true then
			local v39 = v_u_9
			local v40 = v38.whyMember
			local v41 = v13.memberName
			if type(v41) ~= "string" or v41 == "" then
				v41 = nil
			end
			v37 = v39(v40, v41 or "the leader")
		else
			v37 = nil
		end
	end
	local v42 = v15[v18] or ""
	if v13.pvpve == true then
		v42 = v12.onlyDiffHere
	else
		local v43 = v13.nextLock
		if type(v43) == "table" then
			local v44 = v13.nextLock.short
			if type(v44) ~= "string" or v44 == "" then
				v44 = nil
			end
			if v44 then
				local v45 = v_u_9
				local v46 = "%s: %s"
				local v47 = v13.nextLock.name
				if type(v47) ~= "string" or v47 == "" then
					v47 = nil
				end
				v42 = v45(v46, v47 or "Next", v13.nextLock.short)
			end
		end
	end
	local v48 = {
		["id"] = "difficulty",
		["label"] = nil,
		["short"] = nil,
		["value"] = nil,
		["shortValue"] = nil,
		["sub"] = nil,
		["tone"] = nil,
		["fixed"] = nil,
		["why"] = nil,
		["label"] = v12.difficulty,
		["short"] = v12.difficulty,
		["value"] = v18,
		["shortValue"] = v18,
		["sub"] = v42,
		["tone"] = v18,
		["fixed"] = v37 ~= nil and true or v13.pvpve == true,
		["why"] = v37
	}
	local v49
	if v19 == "Any" then
		v49 = v12.anyTime
	elseif v19 == "Day" then
		v49 = v12.day
	elseif v19 == "Dusk" then
		v49 = v12.dusk
	else
		v49 = v12.night
	end
	local v50 = v16[v19] or ""
	local v51 = v13.fixedTime
	if type(v51) ~= "string" or v51 == "" then
		v51 = nil
	end
	local v52 = nil
	if v51 == nil then
		if v18 == "Nightmare" then
			v49 = v12.night
			v50 = v12.nightmareNight
			v52 = v12.nightmareNight .. "."
		end
	else
		v50 = v12.setByMap
		v52 = v12.setByMap .. "."
		v49 = v51
	end
	local v53 = v_u_1.T
	local _ = v13.pvpve == true
	local v54
	if v13.searching == true then
		v54 = v53.whySearching
	elseif v13.member == true then
		local v55 = v_u_9
		local v56 = v53.whyMember
		local v57 = v13.memberName
		if type(v57) ~= "string" or v57 == "" then
			v57 = nil
		end
		v54 = v55(v56, v57 or "the leader")
	else
		v54 = nil
	end
	local v58 = v54 or v52
	local v59 = (v49 == v12.dusk or (v49 == v12.night or string.lower(v49) == "dusk")) and true or string.lower(v49) == "night"
	local v60 = {
		["id"] = "time",
		["label"] = nil,
		["short"] = nil,
		["value"] = nil,
		["shortValue"] = nil,
		["sub"] = nil,
		["tone"] = nil,
		["fixed"] = nil,
		["why"] = nil,
		["label"] = v12.timeOfDay,
		["short"] = v12.time,
		["value"] = v49,
		["shortValue"] = v49,
		["sub"] = v50,
		["tone"] = v59 and "time" or "text",
		["fixed"] = v58 ~= nil,
		["why"] = v58
	}
	local v61 = v13.freeRaid == true
	local v62 = v13.kitValue
	if type(v62) ~= "string" or v62 == "" then
		v62 = nil
	end
	local v63
	if v61 then
		v63 = v12.randomKit
	else
		v63 = v62 == nil and "" or v_u_9(v12.atStake, v62)
	end
	local v64 = v_u_1.T
	local _ = v13.pvpve == true
	local v65
	if v13.searching == true then
		v65 = v64.whySearching
	elseif v13.member == true then
		local v66 = v_u_9
		local v67 = v64.whyMember
		local v68 = v13.memberName
		if type(v68) ~= "string" or v68 == "" then
			v68 = nil
		end
		v65 = v66(v67, v68 or "the leader")
	else
		v65 = nil
	end
	local v69 = {
		["id"] = "kit",
		["label"] = nil,
		["short"] = nil,
		["value"] = nil,
		["shortValue"] = nil,
		["sub"] = nil,
		["tone"] = nil,
		["fixed"] = nil,
		["why"] = nil,
		["label"] = v12.kit,
		["short"] = v12.kit
	}
	local v70
	if v61 then
		v70 = v12.freeRaid
	else
		v70 = v12.yourKit
	end
	v69.value = v70
	local v71
	if v61 then
		v71 = v12.freeRaid
	else
		v71 = v12.yourKit
	end
	v69.shortValue = v71
	v69.sub = v63
	v69.tone = v61 and "info" or "text"
	v69.fixed = v65 ~= nil
	v69.why = v65
	local v72 = v12.public
	local v73 = v12.public
	local v74 = v12.othersMayJoin
	local v75 = "text"
	if v13.pvpve == true then
		v74 = v12.alwaysPublic
	elseif v13.privateRaid == true and v13.privateFriends == true then
		v72 = v12.privateFriends
		v73 = v12.friends
		v74 = v12.friendsMayJoin
		v75 = "accent"
	elseif v13.privateRaid == true then
		v72 = v12.private
		v73 = v12.private
		v74 = v12.onlySquad
		v75 = "accent"
	end
	local v76 = v12.whyPublic
	local v77 = v_u_1.T
	if v13.pvpve ~= true or v76 == nil then
		if v13.searching == true then
			v76 = v77.whySearching
		elseif v13.member == true then
			local v78 = v_u_9
			local v79 = v77.whyMember
			local v80 = v13.memberName
			if type(v80) ~= "string" or v80 == "" then
				v80 = nil
			end
			v76 = v78(v79, v80 or "the leader")
		else
			v76 = nil
		end
	end
	local v81 = {
		v48,
		v60,
		v69,
		{
			["id"] = "raid",
			["label"] = nil,
			["short"] = nil,
			["value"] = nil,
			["shortValue"] = nil,
			["sub"] = nil,
			["tone"] = nil,
			["fixed"] = nil,
			["why"] = nil,
			["label"] = v12.raid,
			["short"] = v12.raid,
			["value"] = v72,
			["shortValue"] = v73,
			["sub"] = v74,
			["tone"] = v75,
			["fixed"] = v76 ~= nil and true or v13.pvpve == true,
			["why"] = v76
		}
	}
	local v82 = v13.showMode == true and (v13.pvpve ~= true and v13.viewMode == "fptp") and "fptp" or "classic"
	local v83
	if v13.showMode == true then
		v83 = v13.pvpve ~= true
	else
		v83 = false
	end
	local v84
	if type(v14) == "table" then
		v84 = v14.viewMode
	else
		v84 = nil
	end
	local v85
	if type(v84) == "table" then
		local v86 = v84.label
		if type(v86) == "function" then
			local v87 = v84.short
			if type(v87) == "function" then
				local v88 = v84.TEXT
				v85 = type(v88) == "table"
			else
				v85 = false
			end
		else
			v85 = false
		end
	else
		v85 = false
	end
	if not v85 then
		local v89
		if v_u_6 == nil then
			local v90
			v90, v89 = pcall(function()
				local v91 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				local v92
				if v91 then
					v92 = v91:FindFirstChild("Shared")
				else
					v92 = nil
				end
				local v93
				if v92 then
					v93 = v92:FindFirstChild("ViewMode")
				else
					v93 = nil
				end
				if v93 == nil then
					return nil
				else
					return require(v93)
				end
			end)
			if v90 then
				local v94
				if type(v89) == "table" then
					local v95 = v89.label
					if type(v95) == "function" then
						local v96 = v89.short
						if type(v96) == "function" then
							local v97 = v89.TEXT
							v94 = type(v97) == "table"
						else
							v94 = false
						end
					else
						v94 = false
					end
				else
					v94 = false
				end
				if v94 then
					v_u_6 = v89
				else
					v89 = nil
				end
			else
				v89 = nil
			end
		else
			v89 = v_u_6
		end
		v84 = v89 or v_u_5
	end
	if v83 then
		local v98 = v_u_1.T
		local _ = v13.pvpve == true
		local v99
		if v13.searching == true then
			v99 = v98.whySearching
		elseif v13.member == true then
			local v100 = v_u_9
			local v101 = v98.whyMember
			local v102 = v13.memberName
			if type(v102) ~= "string" or v102 == "" then
				v102 = nil
			end
			v99 = v100(v101, v102 or "the leader")
		else
			v99 = nil
		end
		local v103 = {
			["id"] = "mode",
			["label"] = nil,
			["short"] = nil,
			["value"] = nil,
			["shortValue"] = nil,
			["sub"] = nil,
			["tone"] = nil,
			["fixed"] = nil,
			["why"] = nil,
			["label"] = v12.mode,
			["short"] = v12.mode,
			["value"] = v84.label(v82),
			["shortValue"] = v84.short(v82)
		}
		local v104
		if v82 == "fptp" then
			v104 = v84.TEXT.fptpSub
		else
			v104 = v84.TEXT.classicSub
		end
		v103.sub = v104
		v103.tone = v82 == "fptp" and "accent" or "text"
		v103.fixed = v99 ~= nil
		v103.why = v99
		table.insert(v81, v103)
	end
	local v105 = {}
	for _, v106 in v81 do
		if v106.id == "mode" and v82 ~= "fptp" then
			continue
		end
		local v107 = string.upper
		local v108 = v106.shortValue
		table.insert(v105, v107(v108))
	end
	return {
		["header"] = v25,
		["map"] = v30,
		["tiles"] = v81,
		["summary"] = string.upper(v30.name .. ", " .. v18 .. ", " .. v49 .. (v82 ~= "fptp" and "" or ", " .. v84.short(v82))),
		["values"] = table.concat(v105, " . "),
		["difficulty"] = v18,
		["time"] = v19,
		["mode"] = v82,
		["showMode"] = v83
	}
end
function v_u_1.modeCards(p109, p110) -- name: modeCards
	-- upvalues: (copy) v_u_1, (ref) v_u_6, (copy) v_u_5, (copy) v_u_9
	local v111 = v_u_1.T
	local v112 = p109 or {}
	local v113
	if type(p110) == "table" then
		v113 = p110.viewMode
	else
		v113 = nil
	end
	local v114
	if type(v113) == "table" then
		local v115 = v113.label
		if type(v115) == "function" then
			local v116 = v113.short
			if type(v116) == "function" then
				local v117 = v113.TEXT
				v114 = type(v117) == "table"
			else
				v114 = false
			end
		else
			v114 = false
		end
	else
		v114 = false
	end
	if not v114 then
		local v118
		if v_u_6 == nil then
			local v119
			v119, v118 = pcall(function()
				local v120 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				local v121
				if v120 then
					v121 = v120:FindFirstChild("Shared")
				else
					v121 = nil
				end
				local v122
				if v121 then
					v122 = v121:FindFirstChild("ViewMode")
				else
					v122 = nil
				end
				if v122 == nil then
					return nil
				else
					return require(v122)
				end
			end)
			if v119 then
				local v123
				if type(v118) == "table" then
					local v124 = v118.label
					if type(v124) == "function" then
						local v125 = v118.short
						if type(v125) == "function" then
							local v126 = v118.TEXT
							v123 = type(v126) == "table"
						else
							v123 = false
						end
					else
						v123 = false
					end
				else
					v123 = false
				end
				if v123 then
					v_u_6 = v118
				else
					v118 = nil
				end
			else
				v118 = nil
			end
		else
			v118 = v_u_6
		end
		v113 = v118 or v_u_5
	end
	local v127
	if v112.showMode == true then
		v127 = v112.pvpve ~= true
	else
		v127 = false
	end
	local v128 = v112.showMode == true and (v112.pvpve ~= true and v112.viewMode == "fptp") and "fptp" or "classic"
	local v129 = v_u_1.T
	local _ = v112.pvpve == true
	local v130
	if v112.searching == true then
		v130 = v129.whySearching
	elseif v112.member == true then
		local v131 = v_u_9
		local v132 = v129.whyMember
		local v133 = v112.memberName
		if type(v133) ~= "string" or v133 == "" then
			v133 = nil
		end
		v130 = v131(v132, v133 or "the leader")
	else
		v130 = nil
	end
	local v134 = {
		["show"] = v127,
		["mode"] = v128,
		["title"] = v111.sheetMode,
		["cards"] = {
			{
				["id"] = "classic",
				["title"] = nil,
				["body"] = nil,
				["selected"] = nil,
				["title"] = v113.label("classic"),
				["body"] = v113.TEXT.classicCard,
				["selected"] = v128 == "classic"
			},
			{
				["id"] = "fptp",
				["title"] = nil,
				["body"] = nil,
				["selected"] = nil,
				["title"] = v113.label("fptp"),
				["body"] = v113.TEXT.fptpCard,
				["selected"] = v128 == "fptp"
			}
		},
		["note"] = v113.TEXT.queueNote,
		["locked"] = v130 ~= nil,
		["why"] = v130
	}
	return v134
end
function v_u_1.sheetLine(p135) -- name: sheetLine
	-- upvalues: (copy) v_u_1, (copy) v_u_9
	local v136 = v_u_1.T
	local v137 = p135 or {}
	if v137.closed == true then
		local v138 = v137.closedText
		if type(v138) ~= "string" or v138 == "" then
			v138 = nil
		end
		if v138 then
			return v137.closedText
		end
	end
	if v137.searching == true then
		return v136.whySearching
	elseif v137.member == true then
		local v139 = v_u_9
		local v140 = v136.whyMember
		local v141 = v137.memberName
		if type(v141) ~= "string" or v141 == "" then
			v141 = nil
		end
		return v139(v140, v141 or "the leader")
	else
		local v142 = (v137.showMode == true and (v137.pvpve ~= true and v137.viewMode == "fptp") and "fptp" or "classic") == "fptp"
		local v143 = v137.partySize
		if (tonumber(v143) or 1) > 1 then
			if v142 then
				return v136.sheetSquadFp
			else
				return v136.sheetSquad
			end
		elseif v142 then
			return v136.sheetSoloFp
		else
			return v136.sheetSolo
		end
	end
end
function v_u_1.taskView(p144) -- name: taskView
	-- upvalues: (copy) v_u_1
	local v145 = v_u_1.T
	local v146 = p144 or {}
	if v146.failed == true then
		return {
			["kicker"] = "TASKS",
			["title"] = nil,
			["left"] = nil,
			["right"] = "",
			["frac"] = 0,
			["empty"] = false,
			["failed"] = true,
			["loading"] = false,
			["title"] = v145.tasksFailed,
			["left"] = v145.tryAgain
		}
	end
	if v146.loading == true then
		return {
			["kicker"] = "TASKS",
			["title"] = nil,
			["left"] = "",
			["right"] = "",
			["frac"] = 0,
			["empty"] = false,
			["failed"] = false,
			["loading"] = true,
			["title"] = v145.loadingTasks
		}
	end
	if v146.empty == true then
		return {
			["kicker"] = "TASKS",
			["title"] = nil,
			["left"] = nil,
			["right"] = "",
			["frac"] = 0,
			["empty"] = true,
			["failed"] = false,
			["loading"] = false,
			["title"] = v145.noTask,
			["left"] = v145.pickJob
		}
	end
	local v147 = {
		["kicker"] = nil,
		["title"] = nil,
		["left"] = nil,
		["right"] = nil,
		["frac"] = nil,
		["empty"] = false,
		["failed"] = false,
		["loading"] = false
	}
	local v148 = v146.kicker
	if type(v148) ~= "string" or v148 == "" then
		v148 = nil
	end
	v147.kicker = v148 or "CURRENT TASK"
	local v149 = v146.title
	if type(v149) ~= "string" or v149 == "" then
		v149 = nil
	end
	v147.title = v149 or v145.noTask
	local v150 = v146.left
	if type(v150) ~= "string" or v150 == "" then
		v150 = nil
	end
	v147.left = v150 or ""
	local v151 = v146.right
	if type(v151) ~= "string" or v151 == "" then
		v151 = nil
	end
	v147.right = v151 or ""
	local v152 = v146.frac
	local v153 = tonumber(v152) or 0
	v147.frac = math.clamp(v153, 0, 1)
	return v147
end
function v_u_1.allTexts() -- name: allTexts
	-- upvalues: (copy) v_u_1
	local v154 = {}
	for _, v155 in v_u_1.T do
		table.insert(v154, v155)
	end
	return v154
end
return v_u_1