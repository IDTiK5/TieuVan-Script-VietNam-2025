-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / AvatarHint

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = {
	["name"] = "AvatarHint",
	["order"] = 95
}
local v_u_4 = nil
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = ""
local v_u_11 = 0
local v_u_12 = os.clock()
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local function v_u_30() -- name: currentState
	-- upvalues: (copy) v_u_5, (ref) v_u_4, (ref) v_u_15
	local v17 = v_u_5:GetAttribute("AvatarState")
	local function v18()
		-- upvalues: (ref) v_u_4
		return v_u_4.shared.AvatarRules
	end
	local v19, v20 = pcall(v18)
	if not v19 then
		v20 = nil
	end
	if not (v20 and v20.effectiveState) then
		return v17
	end
	local v21 = v20.effectiveState
	local v22 = v_u_5:GetAttribute("MenuHeroFault")
	local function v23()
		-- upvalues: (ref) v_u_4
		return v_u_4.shared.AvatarRules
	end
	local v24, v25 = pcall(v23)
	if not v24 then
		v25 = nil
	end
	local v26
	if v25 == nil then
		v26 = false
	else
		v26 = v25.isHome(v_u_5:GetAttribute("Place")) == true
	end
	local v27 = v_u_5:GetAttribute("MenuHeroFault")
	local v28
	if type(v27) == "string" and v27 ~= "" then
		local v29 = os.clock()
		if v_u_15 == nil then
			v_u_15 = v29
		end
		v28 = v29 - v_u_15
	else
		v_u_15 = nil
		v28 = 0
	end
	return v21(v17, v22, v26, v28)
end
local function v_u_32() -- name: suppressed
	-- upvalues: (copy) v_u_5
	if v_u_5:GetAttribute("FilmOpen") == true or v_u_5:GetAttribute("FilmClean") == true then
		return true
	end
	if v_u_5:GetAttribute("HudVisible") == false then
		return true
	end
	if v_u_5:GetAttribute("EntryActive") == true then
		return true
	end
	local v31 = v_u_5:GetAttribute("IntroState")
	return v31 ~= nil and (v31 ~= "off" and v31 ~= "done")
end
local function v_u_39() -- name: build
	-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
	local v33 = v_u_4.lib.HushUI
	local v34 = v33.Theme
	local v35 = v34.color
	local v36, v37 = v33.screen("HushAvatarHint", v34.layer.toast - 1)
	v36.Enabled = false
	local v38 = v33.new("Frame", {
		["Name"] = "Pill",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 128),
		["Size"] = UDim2.fromOffset(0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.XY,
		["BackgroundColor3"] = v35.bg
	}, v37)
	v33.stroke(v38, v35.line)
	v33.pad(v38, {
		16,
		16,
		8,
		8
	})
	v_u_9 = v33.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoX"] = true,
		["autoY"] = true,
		["maxSize"] = nil,
		["parent"] = v38,
		["color"] = v35.text2,
		["size"] = UDim2.fromOffset(0, 0),
		["maxSize"] = Vector2.new(780, (1 / 0))
	})
	v_u_6 = v36
	v_u_7 = v37
	v_u_8 = v38
end
local function v_u_71() -- name: layout
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (copy) v_u_5, (ref) v_u_7
	if v_u_8 and v_u_9 then
		local v_u_40 = v_u_4.lib.HushUI
		local v44, v45 = pcall(function()
			-- upvalues: (copy) v_u_40
			local v41 = v_u_40.Theme.refSize()
			local v42 = v_u_40.safeInsets()
			local v43 = (v41.X - v42.l - v42.r) * 0.9 - 32
			return math.min(780, v43)
		end)
		local v46 = v44 and (type(v45) == "number" and (v45 > 120 and v_u_9:FindFirstChildOfClass("UISizeConstraint")))
		if v46 then
			v46.MaxSize = Vector2.new(v45, (1 / 0))
		end
		local v_u_47 = 128
		local v48 = v_u_5:GetAttribute("LiveCopyNoteText")
		if type(v48) == "string" and v48 ~= "" then
			v_u_47 = v_u_47 + 42
		end
		local v_u_49 = v_u_8
		v_u_49.Position = UDim2.new(0.5, 0, 0, v_u_47)
		local function v70()
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (copy) v_u_49, (ref) v_u_47
			local v50 = v_u_7:FindFirstChildOfClass("UIScale")
			local v51 = (not v50 or v50.Scale <= 0) and 1 or v50.Scale
			local v52 = v_u_5:FindFirstChildOfClass("PlayerGui")
			if not v52 then
				return
			end
			local v53 = {}
			local v54 = v52:FindFirstChild("HushToast")
			if v54 then
				v54 = v54:FindFirstChild("Root")
			end
			if v54 then
				v54 = v54:FindFirstChild("Toasts")
			end
			if v54 then
				for _, v55 in v54:GetChildren() do
					if not v55:IsA("GuiObject") or (not v55.Visible or v55.AbsoluteSize.Y <= 0) then
						continue
					end
					table.insert(v53, v55)
				end
			end
			local v56 = v52:FindFirstChild("HushEventCard")
			local v57
			if v56 then
				v57 = v56:FindFirstChild("Root")
			else
				v57 = v56
			end
			if v57 and (v56:IsA("ScreenGui") and v56.Enabled) then
				for _, v58 in v57:GetChildren() do
					if not v58:IsA("GuiObject") or (not v58.Visible or v58.AbsoluteSize.Y <= 0) then
						continue
					end
					table.insert(v53, v58)
				end
			end
			for _ = 1, 6 do
				local v59 = v_u_49.AbsolutePosition.Y
				local v60 = v59 + v_u_49.AbsoluteSize.Y
				local v61 = v_u_49.AbsolutePosition.X
				local v62 = v61 + v_u_49.AbsoluteSize.X
				local v63 = nil
				for _, v64 in v53 do
					local v65 = v64.AbsolutePosition.Y
					local v66 = v64.AbsolutePosition.Y + v64.AbsoluteSize.Y
					local v67 = v64.AbsolutePosition.X
					local v68 = v64.AbsolutePosition.X + v64.AbsoluteSize.X
					if v59 >= v66 or (v65 >= v60 or (v61 >= v68 or v67 >= v62)) then
						continue
					end
					local v69 = v66 + v51 * 8
					v63 = math.max(v63 or 0, v69)
				end
				if not v63 then
					break
				end
				v_u_47 = v_u_47 + (v63 - v59) / v51
				v_u_49.Position = UDim2.new(0.5, 0, 0, v_u_47)
			end
		end
		if not pcall(v70) then
			v_u_49.Position = UDim2.new(0.5, 0, 0, v_u_47)
		end
	end
end
local function v_u_101() -- name: wanted
	-- upvalues: (ref) v_u_4, (copy) v_u_5, (ref) v_u_15, (ref) v_u_12, (ref) v_u_16, (copy) v_u_32
	local function v72()
		-- upvalues: (ref) v_u_4
		return v_u_4.shared.AvatarRules
	end
	local v73, v74 = pcall(v72)
	if not v73 then
		v74 = nil
	end
	if not v74 then
		return nil
	end
	local v75 = v_u_5:GetAttribute("AvatarState")
	local function v76()
		-- upvalues: (ref) v_u_4
		return v_u_4.shared.AvatarRules
	end
	local v77, v78 = pcall(v76)
	if not v77 then
		v78 = nil
	end
	if v78 and v78.effectiveState then
		local v79 = v78.effectiveState
		local v80 = v_u_5:GetAttribute("MenuHeroFault")
		local function v81()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v82, v83 = pcall(v81)
		if not v82 then
			v83 = nil
		end
		local v84
		if v83 == nil then
			v84 = false
		else
			v84 = v83.isHome(v_u_5:GetAttribute("Place")) == true
		end
		local v85 = v_u_5:GetAttribute("MenuHeroFault")
		local v86
		if type(v85) == "string" and v85 ~= "" then
			local v87 = os.clock()
			if v_u_15 == nil then
				v_u_15 = v87
			end
			v86 = v87 - v_u_15
		else
			v_u_15 = nil
			v86 = 0
		end
		v75 = v79(v75, v80, v84, v86)
	end
	local v88 = v_u_12
	if v_u_16 and os.clock() < v_u_16.untilT then
		v75 = v_u_16.state
		v88 = v_u_16.since
	else
		v_u_16 = nil
	end
	if not v_u_32() then
		local v89 = v_u_4
		if v89 then
			v89 = v_u_4.config
		end
		local v90
		if v89 and v89.flag then
			local v91 = v89.flag
			local v92, v93 = pcall(v91, "AvatarHint")
			v90 = (not v92 or v93 ~= false) and true or false
		else
			v90 = true
		end
		if v90 then
			local v94 = v74.hintText
			local v95 = os.clock() - v88
			local v96 = true
			local function v97()
				-- upvalues: (ref) v_u_4
				return v_u_4.shared.AvatarRules
			end
			local v98, v99 = pcall(v97)
			if not v98 then
				v99 = nil
			end
			local v100
			if v99 == nil then
				v100 = false
			else
				v100 = v99.isHome(v_u_5:GetAttribute("Place")) == true
			end
			return v94(v75, v95, v96, v100)
		end
	end
	return nil
end
local v_u_102 = os.clock()
local function v_u_125() -- name: render
	-- upvalues: (ref) v_u_6, (ref) v_u_9, (copy) v_u_32, (ref) v_u_12, (ref) v_u_102, (copy) v_u_5, (ref) v_u_4, (ref) v_u_15, (ref) v_u_13, (ref) v_u_14, (copy) v_u_101, (ref) v_u_10, (ref) v_u_11, (copy) v_u_71
	if v_u_6 and v_u_9 then
		local v103 = os.clock()
		if v_u_32() then
			v_u_12 = v_u_12 + (v103 - v_u_102)
		end
		v_u_102 = v103
		local v104 = v_u_5:GetAttribute("AvatarState")
		local function v105()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v106, v107 = pcall(v105)
		if not v106 then
			v107 = nil
		end
		if v107 and v107.effectiveState then
			local v108 = v107.effectiveState
			local v109 = v_u_5:GetAttribute("MenuHeroFault")
			local function v110()
				-- upvalues: (ref) v_u_4
				return v_u_4.shared.AvatarRules
			end
			local v111, v112 = pcall(v110)
			if not v111 then
				v112 = nil
			end
			local v113
			if v112 == nil then
				v113 = false
			else
				v113 = v112.isHome(v_u_5:GetAttribute("Place")) == true
			end
			local v114 = v_u_5:GetAttribute("MenuHeroFault")
			local v115
			if type(v114) == "string" and v114 ~= "" then
				local v116 = os.clock()
				if v_u_15 == nil then
					v_u_15 = v116
				end
				v115 = v116 - v_u_15
			else
				v_u_15 = nil
				v115 = 0
			end
			v104 = v108(v104, v109, v113, v115)
		end
		if v104 ~= v_u_13 then
			v_u_13 = v104
			v_u_12 = os.clock()
		end
		local function v117()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v118, v119 = pcall(v117)
		if not v118 then
			v119 = nil
		end
		local v120
		if v119 == nil then
			v120 = false
		else
			v120 = v119.isHome(v_u_5:GetAttribute("Place")) == true
		end
		local function v121()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v122, v123 = pcall(v121)
		if not v122 then
			v123 = nil
		end
		if v123 and (v123.restartAge and v123.restartAge(v104, v_u_14, v120)) then
			v_u_12 = os.clock()
		end
		v_u_14 = v120
		local v124 = v_u_101() or ""
		if v124 ~= v_u_10 then
			v_u_10 = v124
			if v124 ~= "" then
				v_u_4.lib.HushUI.setText(v_u_9, v124)
			end
			v_u_5:SetAttribute("AvatarHintText", v124)
			if v124 ~= "" then
				v_u_11 = v_u_11 + 1
				v_u_5:SetAttribute("AvatarHintShows", v_u_11)
			end
		end
		if v124 ~= "" then
			v_u_71()
		end
		v_u_6.Enabled = v124 ~= ""
	end
end
function v3.init(p126) -- name: init
	-- upvalues: (ref) v_u_4, (copy) v_u_2, (ref) v_u_16, (copy) v_u_125, (ref) v_u_10, (copy) v_u_5, (copy) v_u_30, (ref) v_u_15, (ref) v_u_6, (ref) v_u_12, (copy) v_u_32
	v_u_4 = p126
	p126.command("avatarhint.show", function(p127)
		-- upvalues: (ref) v_u_2, (ref) v_u_16, (ref) v_u_125, (ref) v_u_10
		if v_u_2:IsStudio() then
			local v128 = p127[1] or "retry"
			if v128 == "off" then
				v_u_16 = nil
				v_u_125()
				return "preview off"
			else
				v_u_16 = {
					["state"] = v128,
					["untilT"] = os.clock() + 10,
					["since"] = os.clock() - (v128 == "retry" and 2 or 0)
				}
				v_u_125()
				return "preview " .. v128 .. ": " .. v_u_10
			end
		else
			return "Studio only"
		end
	end)
	p126.command("avatarhint.state", function()
		-- upvalues: (ref) v_u_5, (ref) v_u_30, (ref) v_u_15, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6, (ref) v_u_12, (ref) v_u_32
		local v129 = "state=%s effective=%s fault=%s faultage=%.1f place=%s home=%s line=%q enabled=%s since=%.1f suppressed=%s flag=%s"
		local v130 = v_u_5
		local v131 = tostring(v130:GetAttribute("AvatarState"))
		local v132 = v_u_30
		local v133 = tostring(v132())
		local v134 = v_u_5
		local v135 = tostring(v134:GetAttribute("MenuHeroFault"))
		local v136 = v_u_5:GetAttribute("MenuHeroFault")
		local v137
		if type(v136) == "string" and v136 ~= "" then
			local v138 = os.clock()
			if v_u_15 == nil then
				v_u_15 = v138
			end
			v137 = v138 - v_u_15
		else
			v_u_15 = nil
			v137 = 0
		end
		local v139 = v_u_5
		local v140 = tostring(v139:GetAttribute("Place"))
		local function v141()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v142, v143 = pcall(v141)
		if not v142 then
			v143 = nil
		end
		local v144
		if v143 == nil then
			v144 = false
		else
			v144 = v143.isHome(v_u_5:GetAttribute("Place")) == true
		end
		local v145 = tostring(v144)
		local v146 = v_u_10
		local v147 = v_u_6
		if v147 then
			v147 = v_u_6.Enabled
		end
		local v148 = tostring(v147)
		local v149 = os.clock() - v_u_12
		local v150 = v_u_32()
		local v151 = tostring(v150)
		local v152 = v_u_4
		if v152 then
			v152 = v_u_4.config
		end
		local v153
		if v152 and v152.flag then
			local v154 = v152.flag
			local v155, v156 = pcall(v154, "AvatarHint")
			v153 = (not v155 or v156 ~= false) and true or false
		else
			v153 = true
		end
		return v129:format(v131, v133, v135, v137, v140, v145, v146, v148, v149, v151, (tostring(v153)))
	end)
end
function v3.start() -- name: start
	-- upvalues: (ref) v_u_4, (copy) v_u_39, (copy) v_u_5, (copy) v_u_125, (ref) v_u_13, (ref) v_u_15, (ref) v_u_14
	v_u_4.lib.HushUI.bind(v_u_4)
	local v157 = v_u_39
	local v158, v159 = pcall(v157)
	if v158 then
		v_u_5:GetAttributeChangedSignal("AvatarState"):Connect(v_u_125)
		for _, v160 in {
			"FilmOpen",
			"FilmClean",
			"HudVisible",
			"EntryActive",
			"IntroState",
			"Place",
			"MenuHeroFault"
		} do
			v_u_5:GetAttributeChangedSignal(v160):Connect(v_u_125)
		end
		local v161 = v_u_5:GetAttribute("AvatarState")
		local function v162()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v163, v164 = pcall(v162)
		if not v163 then
			v164 = nil
		end
		if v164 and v164.effectiveState then
			local v165 = v164.effectiveState
			local v166 = v_u_5:GetAttribute("MenuHeroFault")
			local function v167()
				-- upvalues: (ref) v_u_4
				return v_u_4.shared.AvatarRules
			end
			local v168, v169 = pcall(v167)
			if not v168 then
				v169 = nil
			end
			local v170
			if v169 == nil then
				v170 = false
			else
				v170 = v169.isHome(v_u_5:GetAttribute("Place")) == true
			end
			local v171 = v_u_5:GetAttribute("MenuHeroFault")
			local v172
			if type(v171) == "string" and v171 ~= "" then
				local v173 = os.clock()
				if v_u_15 == nil then
					v_u_15 = v173
				end
				v172 = v173 - v_u_15
			else
				v_u_15 = nil
				v172 = 0
			end
			v161 = v165(v161, v166, v170, v172)
		end
		v_u_13 = v161
		local function v174()
			-- upvalues: (ref) v_u_4
			return v_u_4.shared.AvatarRules
		end
		local v175, v176 = pcall(v174)
		if not v175 then
			v176 = nil
		end
		local v177
		if v176 == nil then
			v177 = false
		else
			v177 = v176.isHome(v_u_5:GetAttribute("Place")) == true
		end
		v_u_14 = v177
		v_u_125()
		task.spawn(function()
			-- upvalues: (ref) v_u_125
			while true do
				task.wait(0.25)
				v_u_125()
			end
		end)
	else
		warn("[AvatarHint] build failed:", v159)
		v_u_5:SetAttribute("ClientError", "AvatarHint: " .. tostring(v159))
	end
end
return v3