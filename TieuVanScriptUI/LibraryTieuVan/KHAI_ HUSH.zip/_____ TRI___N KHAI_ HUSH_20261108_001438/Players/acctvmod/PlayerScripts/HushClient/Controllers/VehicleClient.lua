-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / VehicleClient

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = {
	["name"] = "VehicleClient",
	["order"] = 57
}
local v_u_5 = v_u_1.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = {
	["kind"] = "none"
}
local v_u_11 = ""
local v_u_12 = 0
local v_u_13 = 0
local v_u_14 = false
local v_u_15 = {}
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = {}
local v_u_19 = {
	["ops"] = 0,
	["opsDropped"] = 0,
	["events"] = 0,
	["eventsBad"] = 0,
	["fx"] = 0,
	["leanBeats"] = 0,
	["sessions"] = 0,
	["cancels"] = 0,
	["hotwire"] = 0,
	["toasts"] = 0
}
local v_u_20 = {
	["gas"] = false,
	["brake"] = false,
	["handbrake"] = false,
	["horn"] = false,
	["aim"] = false,
	["fire"] = false
}
local v_u_21 = false
local v_u_22 = false
local v_u_23 = {
	["latched"] = false
}
local v_u_24 = {}
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = {
	["open"] = false,
	["id"] = nil,
	["pending"] = nil,
	["pendingAt"] = 0
}
local v_u_29 = -1000000000
local v_u_30 = false
local v_u_31 = false
local v_u_32 = false
local v_u_33 = false
local v_u_34 = {}
local v_u_35 = {}
local v_u_36 = 0
local v_u_37 = 0
local v_u_38 = false
local v_u_39 = false
local v_u_40 = nil
local v_u_41 = false
local v_u_42 = {
	["moveUp"] = { "W", "Up" },
	["moveDown"] = { "S", "Down" },
	["moveLeft"] = { "A", "Left" },
	["moveRight"] = { "D", "Right" }
}
local function v_u_48(p_u_43) -- name: lib
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (ref) v_u_6
	local v44 = v_u_8[p_u_43]
	if v44 == nil then
		if v_u_9[p_u_43] then
			return nil
		else
			v_u_9[p_u_43] = true
			local function v45()
				-- upvalues: (ref) v_u_6, (copy) p_u_43
				return v_u_6.lib[p_u_43]
			end
			local v46, v47 = pcall(v45)
			if v46 and v47 ~= nil then
				v_u_8[p_u_43] = v47
				return v47
			else
				warn("[VehicleClient] lib " .. p_u_43 .. " missing: " .. tostring(v47))
				return nil
			end
		end
	else
		return v44
	end
end
local function v_u_55(p_u_49) -- name: sharedMod
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (ref) v_u_6
	local v50 = "shared." .. p_u_49
	local v51 = v_u_8[v50]
	if v51 == nil then
		if v_u_9[v50] then
			return nil
		else
			v_u_9[v50] = true
			local function v52()
				-- upvalues: (ref) v_u_6, (copy) p_u_49
				return v_u_6.shared[p_u_49]
			end
			local v53, v54 = pcall(v52)
			if v53 and v54 ~= nil then
				v_u_8[v50] = v54
				return v54
			else
				warn("[VehicleClient] shared " .. p_u_49 .. " missing: " .. tostring(v54))
				return nil
			end
		end
	else
		return v51
	end
end
local function v_u_69(p56) -- name: findModel
	-- upvalues: (ref) v_u_7, (copy) v_u_5
	local v57 = workspace:FindFirstChild("Raid")
	local v58
	if v57 == nil then
		v58 = nil
	else
		v58 = v57:FindFirstChild("Vehicles")
	end
	if v58 == nil then
		return nil
	end
	if p56 ~= nil then
		local v59 = v_u_7.vehicleModelName(p56)
		local v60
		if v59 then
			v60 = v58:FindFirstChild(v59)
		else
			v60 = nil
		end
		if v60 ~= nil then
			return v60
		end
		for _, v61 in v58:GetChildren() do
			if v61:GetAttribute("VehId") ~= p56 then
				continue
			end
			return v61
		end
		return nil
	end
	local v62 = v_u_5.Character
	local v63
	if v62 then
		v63 = v62:FindFirstChild("HumanoidRootPart")
	else
		v63 = nil
	end
	if v63 == nil then
		return nil
	end
	local v64 = 14
	local v65 = nil
	for _, v66 in v58:GetChildren() do
		local v67 = v66:FindFirstChild("Chassis")
		if v67 == nil or not v67:IsA("BasePart") then
			continue
		end
		local v68 = (v67.Position - v63.Position).Magnitude
		if v68 >= v64 then
			continue
		end
		v65 = v66
		v64 = v68
	end
	return v65
end
local function v_u_82(p70, p71) -- name: sendOp
	-- upvalues: (ref) v_u_7, (copy) v_u_19, (copy) v_u_18, (copy) v_u_3, (ref) v_u_6
	local v72 = v_u_7.opFor(p70, p71)
	if v72 == nil then
		local v73 = v_u_19
		v73.opsDropped = v73.opsDropped + 1
		return false
	end
	local v74 = os.clock()
	if (p70 == "exit" or p70 == "board_cancel") and v74 - (v_u_18[p70] or -1000000000) < v_u_7.TUNE.OP_GAP then
		return false
	end
	local v75 = v_u_7.REMOTE.OP
	local v76 = v_u_3:FindFirstChild("HushNet")
	local v77
	if v76 == nil then
		v77 = false
	else
		v77 = v76:FindFirstChild(v75) ~= nil
	end
	if not v77 then
		local v78 = v_u_19
		v78.opsDropped = v78.opsDropped + 1
		return false
	end
	v_u_18[p70] = v74
	local v79 = v_u_19
	v79.ops = v79.ops + 1
	local v80 = v_u_6.net.fire
	local v81 = v_u_7.REMOTE.OP
	return pcall(v80, v81, v72)
end
local function v_u_90(p83) -- name: sendLean
	-- upvalues: (ref) v_u_7, (copy) v_u_3, (copy) v_u_19, (ref) v_u_6
	local v84 = v_u_7.REMOTE.LEAN
	local v85 = v_u_3:FindFirstChild("HushNet")
	local v86
	if v85 == nil then
		v86 = false
	else
		v86 = v85:FindFirstChild(v84) ~= nil
	end
	if v86 then
		local v87 = v_u_19
		v87.leanBeats = v87.leanBeats + 1
		local v88 = v_u_6.net.fire
		local v89 = v_u_7.REMOTE.LEAN
		pcall(v88, v89, {
			["on"] = p83
		})
	end
end
local function v_u_102(p91) -- name: keysFor
	-- upvalues: (copy) v_u_24, (ref) v_u_6, (copy) v_u_42
	local v92 = v_u_24[p91]
	if v92 ~= nil then
		return v92
	end
	local v93
	if v_u_6 == nil or v_u_6.controllers == nil then
		v93 = nil
	else
		v93 = v_u_6.controllers.Input
	end
	local v94 = v_u_42[p91] or {}
	local v95
	if v93 == nil or not v93.keyBinding then
		v95 = v94
	else
		local v96 = v93.keyBinding
		local v97
		v97, v95 = pcall(v96, p91)
		if v97 then
			if type(v95) ~= "table" then
				v95 = v94
			end
		else
			v95 = v94
		end
	end
	local v98 = {}
	for _, v_u_99 in v95 do
		local v100, v101 = pcall(function()
			-- upvalues: (copy) v_u_99
			return Enum.KeyCode[v_u_99]
		end)
		if not v100 or v101 == nil then
			continue
		end
		table.insert(v98, v101)
	end
	v_u_24[p91] = v98
	return v98
end
local function v_u_111() -- name: padState
	-- upvalues: (copy) v_u_2
	local v103 = {
		["trigR"] = 0,
		["trigL"] = 0,
		["stickX"] = 0,
		["stickY"] = 0,
		["b"] = false,
		["up"] = false,
		["lb"] = false
	}
	if not v_u_2.GamepadEnabled then
		return v103
	end
	local function v104()
		-- upvalues: (ref) v_u_2
		return v_u_2:GetGamepadState(Enum.UserInputType.Gamepad1)
	end
	local v105, v106 = pcall(v104)
	if not v105 or type(v106) ~= "table" then
		return v103
	end
	for _, v107 in v106 do
		local v108 = v107.KeyCode
		if v108 == Enum.KeyCode.ButtonR2 then
			v103.trigR = v107.Position.Z
		elseif v108 == Enum.KeyCode.ButtonL2 then
			v103.trigL = v107.Position.Z
		elseif v108 == Enum.KeyCode.Thumbstick1 then
			local v109 = v107.Position.X
			local v110 = v107.Position.Y
			v103.stickX = v109
			v103.stickY = v110
		elseif v108 == Enum.KeyCode.ButtonB then
			v103.b = v107.Position.Z > 0.5
		elseif v108 == Enum.KeyCode.DPadUp then
			v103.up = v107.Position.Z > 0.5
		else
			if v108 ~= Enum.KeyCode.ButtonL1 then
				continue
			end
			v103.lb = v107.Position.Z > 0.5
		end
	end
	return v103
end
local function v_u_131(p112, p113, p114) -- name: driveRaw
	-- upvalues: (copy) v_u_48, (copy) v_u_2, (ref) v_u_6, (copy) v_u_102, (copy) v_u_20
	local v115 = v_u_48("VehicleHud")
	local v116 = (v115 == nil or not v115.steer) and 0 or v115.steer()
	local v117
	if v_u_2:GetFocusedTextBox() ~= nil then
		v117 = true
	else
		local v118
		if v_u_6 == nil or v_u_6.controllers == nil then
			v118 = nil
		else
			v118 = v_u_6.controllers.Input
		end
		if v118 == nil or not v118.gameBlocked then
			v117 = false
		else
			local v119 = v118.gameBlocked
			local v120
			v117, v120 = pcall(v119)
			if v117 then
				v117 = v120 == true
			end
		end
	end
	local v121 = not v117
	if v121 then
		v121 = v_u_2:IsKeyDown(Enum.KeyCode.Space)
	end
	local v122 = {}
	local v123 = not v117
	if v123 then
		for _, v124 in v_u_102("moveUp") do
			if not v_u_2:IsKeyDown(v124) then
				continue
			end
			v123 = true
		end
		v123 = false
	end
	v122.up = v123
	local v125 = not v117
	if v125 then
		for _, v126 in v_u_102("moveDown") do
			if not v_u_2:IsKeyDown(v126) then
				continue
			end
			v125 = true
		end
		v125 = false
	end
	v122.down = v125
	local v127 = not v117
	if v127 then
		for _, v128 in v_u_102("moveLeft") do
			if not v_u_2:IsKeyDown(v128) then
				continue
			end
			v127 = true
		end
		v127 = false
	end
	v122.left = v127
	local v129 = not v117
	if v129 then
		for _, v130 in v_u_102("moveRight") do
			if not v_u_2:IsKeyDown(v130) then
				continue
			end
			v129 = true
		end
		v129 = false
	end
	v122.right = v129
	v122.trigR = p112.trigR
	v122.trigL = p112.trigL
	v122.stickX = p112.stickX
	v122.gas = v_u_20.gas
	v122.brake = v_u_20.brake
	v122.touchSteer = v116
	v122.handbrake = v121 or (p112.b or v_u_20.handbrake)
	v122.engineOn = p114
	v122.hotwire = p113
	return v122
end
local function v_u_146(p132) -- name: openHotwire
	-- upvalues: (copy) v_u_48, (ref) v_u_10, (copy) v_u_28, (copy) v_u_82, (copy) v_u_19
	local v133 = v_u_48("HotwireUI")
	local v134 = v_u_48("VehicleHud")
	if v133 == nil then
		return
	elseif v_u_10.kind == "ride" and v_u_10.role == "driver" then
		v_u_28.pending = nil
		v_u_28.id = p132.id
		if v133.isOpen() then
			v133.server(p132)
		else
			local v137 = v133.open({
				["seed"] = p132.seed,
				["startAt"] = p132.startAt,
				["spec"] = v_u_10.spec,
				["onPress"] = function(p135) -- name: onPress
					-- upvalues: (ref) v_u_82, (ref) v_u_28
					v_u_82("hw_press", {
						["id"] = v_u_28.id,
						["at"] = p135.at
					})
				end,
				["onClose"] = function(p136) -- name: onClose
					-- upvalues: (ref) v_u_28, (ref) v_u_10, (ref) v_u_82
					if v_u_28.open and (p136 ~= "end" and v_u_10.kind == "ride") then
						v_u_82("hw_cancel", {
							["id"] = v_u_28.id
						})
					end
					v_u_28.open = false
				end,
				["onExit"] = function(_) -- name: onExit
					-- upvalues: (ref) v_u_82
					v_u_82("exit")
				end
			})
			v_u_28.open = v137 == true
			if v137 then
				local v138 = v_u_19
				v138.hotwire = v138.hotwire + 1
				local v139
				if v134 == nil or not v134.layout then
					v139 = nil
				else
					v139 = v134.layout()
				end
				if v139 ~= nil then
					local v140 = v133.setAvoid
					local v141 = v139.topYMax
					local v142 = v139.interval
					pcall(v140, v141, v142)
				end
			end
		end
	else
		local v143 = v_u_28
		local v144 = v_u_28
		local v145 = os.clock()
		v143.pending = p132
		v144.pendingAt = v145
		return
	end
end
local function v_u_151() -- name: startLights
	-- upvalues: (ref) v_u_38, (copy) v_u_48, (ref) v_u_6
	if v_u_38 then
		return
	else
		local v147 = v_u_48("VehicleLights")
		if v147 ~= nil then
			v_u_38 = true
			local v_u_148
			if v_u_6 == nil or v_u_6.controllers == nil then
				v_u_148 = nil
			else
				v_u_148 = v_u_6.controllers.Atmosphere
			end
			local v149 = v147.start
			pcall(v149, {
				["onSwitch"] = function(p150) -- name: onSwitch
					-- upvalues: (copy) v_u_148
					if v_u_148 ~= nil and v_u_148.setFlashlight then
						v_u_148.setFlashlight(p150)
					end
				end
			})
		end
	end
end
local function v_u_161() -- name: pushLightsDefault
	-- upvalues: (copy) v_u_151, (copy) v_u_48, (copy) v_u_55, (copy) v_u_8, (ref) v_u_10, (copy) v_u_3, (copy) v_u_5, (ref) v_u_41
	v_u_151()
	local v152 = v_u_48("VehicleLightsPlan")
	local v153 = v_u_55("VehicleLightsRules")
	local v154 = v_u_8.VehicleLights
	local v155 = v_u_10.model
	if v152 ~= nil and (v153 ~= nil and (v154 ~= nil and v155 ~= nil)) then
		local v156 = v152.pushDefault
		local v157 = v_u_3:FindFirstChild("HushRuntime")
		local v158
		if v157 then
			v158 = v157:FindFirstChild("Raid")
		else
			v158 = nil
		end
		local v159
		if v158 then
			v159 = v158:GetAttribute("TimeOfDay")
		else
			v159 = nil
		end
		if type(v159) ~= "string" then
			v159 = nil
		end
		if v156(v159, v155:GetAttribute(v153.ATTR.HEADLIGHTS), v153.defaultOn) then
			local v160 = v_u_5:GetAttribute("AtmoFlashlight") == true
			if v154.setSwitch(true) and not v160 then
				v_u_41 = true
			end
		end
	end
end
local function v_u_169(p162) -- name: toggleLights
	-- upvalues: (ref) v_u_10, (copy) v_u_28, (copy) v_u_8, (copy) v_u_55, (copy) v_u_48, (copy) v_u_19
	if v_u_10.kind == "ride" and (v_u_10.role == "driver" and not v_u_28.open) then
		local v163 = v_u_8.VehicleLights
		local v164 = v_u_55("VehicleLightsRules")
		if v163 == nil or v164 == nil then
			return
		elseif p162 and not v164.touchAllowed(v_u_10.speed or 0) then
			local v165 = v164.texts.standStill
			local v166 = v_u_48("HushUI")
			if v166 ~= nil and v166.toast then
				local v167 = v_u_19
				v167.toasts = v167.toasts + 1
				local v168 = v166.toast
				pcall(v168, v165, "info")
			end
		else
			v163.toggle()
		end
	else
		return
	end
end
local function v_u_178() -- name: lightsHudFrame
	-- upvalues: (copy) v_u_8, (copy) v_u_55, (ref) v_u_10, (ref) v_u_7, (copy) v_u_28, (copy) v_u_169
	local v170 = v_u_8.VehicleLightsPlan
	local v171 = v_u_8.VehicleLightsHud
	local v172 = v_u_8.VehicleHud
	local v173 = v_u_8.VehicleLights
	local v174 = v_u_55("VehicleLightsRules")
	if v170 == nil or v171 == nil then
		return
	elseif v170.active(v_u_10.kind, v_u_10.role, v_u_7.phaseOf(v_u_10.kind), v_u_28.open) and (v172 ~= nil and (v172.layout ~= nil and (v173 ~= nil and v174 ~= nil))) then
		local v_u_175 = v_u_8.VehicleHudLayout
		v171.update({
			["lay"] = v172.layout(),
			["on"] = v173.hint().on,
			["speed"] = v_u_10.speed or 0,
			["texts"] = v174.texts,
			["touchAllowed"] = v174.touchAllowed,
			["onPress"] = function() -- name: onPress
				-- upvalues: (ref) v_u_169
				v_u_169(true)
			end,
			["measure"] = function(p176, p177) -- name: measure
				-- upvalues: (copy) v_u_175
				if v_u_175 == nil then
					return #p176 * p177 * 0.6
				else
					return v_u_175.textW(p176, p177, false)
				end
			end
		})
	elseif v171.isShown() then
		v171.hide()
	end
end
local function v_u_185(p179, p180) -- name: onButton
	-- upvalues: (copy) v_u_20, (ref) v_u_10, (copy) v_u_82, (copy) v_u_19, (ref) v_u_6
	if p179 == "gas" or (p179 == "brake" or (p179 == "handbrake" or p179 == "horn")) then
		v_u_20[p179] = p180
	elseif p179 == "exit" then
		if p180 and v_u_10.kind == "ride" then
			v_u_82("exit")
			return
		end
	elseif p179 == "cancel" then
		if p180 and v_u_10.kind == "board" then
			local v181 = v_u_19
			v181.cancels = v181.cancels + 1
			v_u_82("board_cancel")
			return
		end
	elseif p179 == "aim" or (p179 == "fire" or p179 == "reload") then
		if p179 == "aim" or p179 == "fire" then
			v_u_20[p179] = p180
		end
		if v_u_10.role == "passenger" and v_u_10.kind == "ride" then
			local v182
			if v_u_6 == nil or v_u_6.controllers == nil then
				v182 = nil
			else
				v182 = v_u_6.controllers.Input
			end
			if v182 ~= nil then
				local v183 = v182._onAction
				if type(v183) == "function" then
					local v184 = v182._onAction
					pcall(v184, p179, p180)
				end
			end
		end
	end
end
local function v_u_190(p186) -- name: showEjected
	-- upvalues: (copy) v_u_35
	local v187 = v_u_35[p186]
	v_u_35[p186] = nil
	if v187 ~= nil then
		for v_u_188, v_u_189 in v187.saved do
			if v_u_188.Parent == nil then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_188, (copy) v_u_189
				v_u_188.LocalTransparencyModifier = v_u_189
			end)
		end
	end
end
local function v_u_197(p191, p192, p193) -- name: hideEjected
	-- upvalues: (copy) v_u_35
	local v194 = v_u_35[p191]
	if v194 == nil then
		v194 = {
			["uid"] = nil,
			["saved"] = nil,
			["refreshAt"] = 0,
			["uid"] = p192,
			["saved"] = {}
		}
		v_u_35[p191] = v194
	end
	if v194.refreshAt <= p193 then
		v194.refreshAt = p193 + 0.25
		for _, v195 in p191:GetDescendants() do
			if not v195:IsA("BasePart") or v194.saved[v195] ~= nil then
				continue
			end
			v194.saved[v195] = v195.LocalTransparencyModifier
		end
	end
	for v_u_196 in v194.saved do
		if v_u_196.Parent == nil or v_u_196.LocalTransparencyModifier >= 1 then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_196
			v_u_196.LocalTransparencyModifier = 1
		end)
	end
end
local function v_u_202(p198) -- name: onEjectHandoff
	-- upvalues: (copy) v_u_1, (copy) v_u_34, (copy) v_u_190
	local v199 = v_u_1:GetPlayerByUserId(p198)
	local v200
	if v199 then
		v200 = v199.Character
	else
		v200 = nil
	end
	if v200 ~= nil then
		local v201 = v200:GetAttribute("VehEject")
		if type(v201) == "number" then
			v_u_34[p198] = v201
		end
		v_u_190(v200)
	end
end
local function v_u_213(p203) -- name: ejectHideFrame
	-- upvalues: (ref) v_u_36, (ref) v_u_37, (copy) v_u_35, (copy) v_u_1, (copy) v_u_34, (ref) v_u_7, (copy) v_u_48, (ref) v_u_33, (copy) v_u_202, (copy) v_u_197, (copy) v_u_190
	if p203 >= v_u_36 or (v_u_37 > p203 or next(v_u_35) ~= nil) then
		v_u_36 = p203 + 0.1
		local v204 = workspace:GetServerTimeNow()
		local v205 = {}
		for _, v206 in v_u_1:GetPlayers() do
			local v207 = v206.Character
			if v207 == nil then
				continue
			end
			local v208 = v207:GetAttribute("VehEject")
			if v208 == nil then
				v_u_34[v206.UserId] = nil
			end
			if not v_u_7.ejectHidden(v208, v204, v_u_34[v206.UserId]) then
				continue
			end
			v205[v207] = true
			if v_u_35[v207] == nil then
				local v209 = v_u_48("EjectRagdoll")
				if v209 ~= nil and not v_u_33 then
					v_u_33 = true
					local v210 = v209.onHandoff
					local v211 = v_u_202
					pcall(v210, v211)
				end
			end
			v_u_197(v207, v206.UserId, p203)
		end
		for v212 in v_u_35 do
			if v205[v212] then
				continue
			end
			v_u_190(v212)
		end
	end
end
local function v_u_231() -- name: bindStatic
	-- upvalues: (copy) v_u_48, (ref) v_u_30, (copy) v_u_185, (ref) v_u_6, (ref) v_u_31, (ref) v_u_21, (ref) v_u_10, (copy) v_u_28, (copy) v_u_2, (copy) v_u_82, (copy) v_u_169, (ref) v_u_32, (ref) v_u_33, (copy) v_u_202
	local v214 = v_u_48("VehicleHud")
	if v214 ~= nil and not v_u_30 then
		v_u_30 = true
		v214.onButton(v_u_185)
	end
	local v_u_215
	if v_u_6 == nil or v_u_6.controllers == nil then
		v_u_215 = nil
	else
		v_u_215 = v_u_6.controllers.Input
	end
	if v_u_215 ~= nil and (v_u_215.bind and not v_u_31) then
		v_u_31 = true
		v_u_215.bind("interact", function()
			-- upvalues: (ref) v_u_21, (ref) v_u_10, (copy) v_u_215, (ref) v_u_28, (ref) v_u_2, (ref) v_u_6, (ref) v_u_82
			v_u_21 = true
			if v_u_10.kind == "ride" then
				local v216 = not v_u_215.device and "Keyboard" or v_u_215.device()
				if not v_u_28.open or v216 ~= "Gamepad" then
					local v217
					if v_u_2:GetFocusedTextBox() ~= nil then
						v217 = true
					else
						local v218
						if v_u_6 == nil or v_u_6.controllers == nil then
							v218 = nil
						else
							v218 = v_u_6.controllers.Input
						end
						if v218 == nil or not v218.gameBlocked then
							v217 = false
						else
							local v219 = v218.gameBlocked
							local v220
							v217, v220 = pcall(v219)
							if v217 then
								v217 = v220 == true
							end
						end
					end
					if not v217 then
						v_u_82("exit")
					end
				end
			end
		end)
		v_u_215.bind("flashlight", function()
			-- upvalues: (ref) v_u_10, (ref) v_u_2, (ref) v_u_6, (ref) v_u_169
			if v_u_10.kind == "ride" and v_u_10.role == "driver" then
				local v221
				if v_u_2:GetFocusedTextBox() ~= nil then
					v221 = true
				else
					local v222
					if v_u_6 == nil or v_u_6.controllers == nil then
						v222 = nil
					else
						v222 = v_u_6.controllers.Input
					end
					if v222 == nil or not v222.gameBlocked then
						v221 = false
					else
						local v223 = v222.gameBlocked
						local v224
						v221, v224 = pcall(v223)
						if v221 then
							v221 = v224 == true
						end
					end
				end
				if not v221 then
					task.defer(v_u_169, false)
				end
			end
		end)
	end
	local v_u_225 = v_u_48("EjectRagdoll")
	if v_u_225 ~= nil and not v_u_32 then
		v_u_32 = true
		if v_u_225 ~= nil and not v_u_33 then
			v_u_33 = true
			local v226 = v_u_225.onHandoff
			local v227 = v_u_202
			pcall(v226, v227)
		end
		local v228 = v_u_225.bind
		local v229 = v_u_6
		pcall(v228, v229)
		local v230 = v_u_48("RideCam")
		if v230 ~= nil then
			v230.setEject(function()
				-- upvalues: (copy) v_u_225
				return v_u_225.focus()
			end)
		end
	end
end
local function v_u_251() -- name: leaveSession
	-- upvalues: (ref) v_u_10, (ref) v_u_40, (copy) v_u_8, (ref) v_u_25, (copy) v_u_90, (copy) v_u_48, (copy) v_u_28, (ref) v_u_41, (ref) v_u_6, (copy) v_u_20, (ref) v_u_11, (ref) v_u_26, (ref) v_u_27
	if v_u_10.kind ~= "none" then
		v_u_40 = nil
		local v232 = v_u_8.VehicleDrive
		local v233 = v_u_8.VehicleHud
		local v234 = v_u_8.RideCam
		if v232 ~= nil then
			v232.stop()
		end
		local v235 = v_u_8.BreakablePredict
		if v235 ~= nil then
			local v236 = v235.stop
			pcall(v236)
		end
		if v_u_25 ~= nil and v_u_25.on then
			v_u_90(false)
		end
		local v237 = v_u_48("HotwireUI")
		if v237 ~= nil and (v237.isOpen and v237.isOpen()) then
			local v238 = v237.close
			pcall(v238, "leave")
		end
		local v239 = v_u_28
		v_u_28.open = false
		v239.id = nil
		if v_u_28.pending ~= nil and os.clock() - (v_u_28.pendingAt or 0) > 3 then
			v_u_28.pending = nil
		end
		if v233 ~= nil then
			local v240 = v233.hide
			pcall(v240)
		end
		if v_u_8.VehicleLightsHud ~= nil then
			local v241 = v_u_8.VehicleLightsHud.hide
			pcall(v241)
		end
		if v_u_41 then
			v_u_41 = false
			local v242
			if v_u_6 == nil or v_u_6.controllers == nil then
				v242 = nil
			else
				v242 = v_u_6.controllers.Atmosphere
			end
			if v242 ~= nil and v242.setFlashlight then
				local v243 = v242.setFlashlight
				pcall(v243, nil)
			end
		end
		if v234 ~= nil then
			v234.clear()
		end
		if v_u_20.aim then
			local v244
			if v_u_6 == nil or v_u_6.controllers == nil then
				v244 = nil
			else
				v244 = v_u_6.controllers.Input
			end
			if v244 ~= nil then
				local v245 = v244._onAction
				if type(v245) == "function" then
					local v246 = v244._onAction
					pcall(v246, "aim", false)
				end
			end
		end
		if v_u_20.fire then
			local v247
			if v_u_6 == nil or v_u_6.controllers == nil then
				v247 = nil
			else
				v247 = v_u_6.controllers.Input
			end
			if v247 ~= nil then
				local v248 = v247._onAction
				if type(v248) == "function" then
					local v249 = v247._onAction
					pcall(v249, "fire", false)
				end
			end
		end
		for v250 in v_u_20 do
			v_u_20[v250] = false
		end
		v_u_10 = {
			["kind"] = "none"
		}
		v_u_11 = ""
		v_u_25 = nil
		v_u_26 = nil
		v_u_27 = nil
	end
end
local function v_u_266(p252) -- name: describe
	-- upvalues: (copy) v_u_69, (copy) v_u_55, (ref) v_u_7, (copy) v_u_5
	local v253 = v_u_69(p252.vehId)
	if v253 == nil then
		return nil
	end
	local v254 = v253:GetAttribute("VehType")
	local v255 = v_u_55("VehicleSpec")
	local v256
	if v255 == nil or type(v254) ~= "string" then
		v256 = nil
	else
		v256 = v255.get(v254)
	end
	if v256 == nil then
		return nil
	end
	local v257
	if p252.seat then
		v257 = v255.seatOf(v254, p252.seat)
	else
		v257 = nil
	end
	local v258 = {}
	for _, v259 in v256.seats do
		local v260 = v259.name
		table.insert(v258, v260)
	end
	local v261 = nil
	local v262
	if v257 == nil then
		local v263
		if v253 == nil then
			v263 = nil
		else
			v263 = v253:FindFirstChild("Chassis")
			if v263 == nil or not v263:IsA("BasePart") then
				v263 = nil
			end
		end
		local v264
		if v_u_5.Character then
			v264 = v_u_5.Character:FindFirstChild("HumanoidRootPart")
		else
			v264 = nil
		end
		v262 = v263 ~= nil and v264 ~= nil and (v263.CFrame:PointToObjectSpace(v264.Position).X < 0 and "L" or "R") or v261
	else
		local v265 = v256.att
		if v265 then
			v265 = v256.att[v257.att or v257.name]
		end
		v262 = v_u_7.sideOfSeat(v257, not v265 and 0 or v265[1])
	end
	return {
		["model"] = v253,
		["typeId"] = v254,
		["spec"] = v256,
		["seatDef"] = v257,
		["seatNames"] = v258,
		["side"] = v262 or "L",
		["variant"] = v253:GetAttribute("VehVariant")
	}
end
local function v_u_272() -- name: noticeBand
	-- upvalues: (ref) v_u_6
	local v267
	if v_u_6 == nil or v_u_6.controllers == nil then
		v267 = nil
	else
		v267 = v_u_6.controllers.HUD
	end
	if v267 ~= nil then
		local v268 = v267.centerColumn
		if type(v268) == "function" then
			local v269 = v267.centerColumn
			local v270, v271 = pcall(v269, true)
			if v270 then
				return v271
			else
				return nil
			end
		end
	end
	return nil
end
local function v_u_284(p273, p274) -- name: enterSession
	-- upvalues: (copy) v_u_48, (copy) v_u_272, (ref) v_u_10, (copy) v_u_19, (ref) v_u_25, (ref) v_u_7, (ref) v_u_26, (ref) v_u_27, (copy) v_u_231, (copy) v_u_161
	local v275 = v_u_48("VehicleHud")
	local v276 = v_u_48("VehicleDrive")
	if v275 ~= nil then
		local v277 = v275.setBandSource
		if type(v277) == "function" then
			v275.setBandSource(v_u_272)
		end
	end
	v_u_10 = p273
	for v278, v279 in p274 do
		v_u_10[v278] = v279
	end
	v_u_10.speed = 0
	v_u_10.startedAt = os.clock()
	local v280 = v_u_19
	v280.sessions = v280.sessions + 1
	v_u_25 = v_u_7.leanNew()
	v_u_26 = v_u_7.hornNew()
	v_u_27 = v_u_7.cancelNew()
	v_u_231()
	if v275 ~= nil and p273.kind ~= "eject" then
		v275.show(v_u_7.hudInfo(p274.spec, p273.role, p273.seat))
	end
	if p273.kind == "ride" and (p273.role == "driver" and v276 ~= nil) then
		v276.start(p274.model, p274.spec)
		local v281 = v_u_48("BreakablePredict")
		if v281 ~= nil then
			local v282 = v281.start
			local v283 = p274.model
			pcall(v282, v283)
		end
	end
	if p273.kind == "ride" and p273.role == "driver" then
		v_u_161()
	end
end
local function v_u_291(p285) -- name: carAtExtract
	-- upvalues: (ref) v_u_7
	local v286 = workspace:FindFirstChild("Raid")
	local v287
	if v286 then
		v287 = v286:FindFirstChild("Extracts")
	else
		v287 = nil
	end
	if v287 == nil then
		return false
	end
	local v288 = p285:GetPivot().Position
	for _, v289 in v287:GetChildren() do
		if not v289:IsA("BasePart") or v289:GetAttribute("Open") ~= true then
			continue
		end
		local v290 = v289.CFrame:PointToObjectSpace(v288)
		if not v_u_7.nearExtractBox(v290.X, v290.Y, v290.Z, v289.Size.X, v289.Size.Y, v289.Size.Z) then
			continue
		end
		return true
	end
	return false
end
local function v_u_309(p292) -- name: updateHud
	-- upvalues: (ref) v_u_17, (ref) v_u_7, (copy) v_u_8, (ref) v_u_10, (copy) v_u_291, (copy) v_u_178
	v_u_17 = v_u_17 + p292
	if v_u_17 < 1 / v_u_7.TUNE.HUD_HZ then
		return
	else
		v_u_17 = 0
		local v293 = v_u_8.VehicleHud
		local v294 = v_u_10.model
		if v293 ~= nil and v294 ~= nil then
			local v295 = v_u_8.HotwireUI
			local v296 = v293.update
			local v297 = {
				["speed"] = v_u_10.speed or 0,
				["fuel"] = v_u_7.num(v294:GetAttribute("Fuel"), 1, 0, 1)
			}
			local v298 = v_u_7.num(v294:GetAttribute("Hp"), 1)
			local v299 = v_u_7.num
			local v300 = v294:GetAttribute("HpMax")
			v297.health = v298 / math.max(1, v299(v300, 1))
			v297.state = v_u_7.hudState(v294:GetAttribute("State"), v294:GetAttribute("Hp"), v294:GetAttribute("HpMax"))
			v297.taken = v_u_7.takenFromMask(v294:GetAttribute("SeatsTaken"), v_u_10.seatNames)
			v297.phase = v_u_7.phaseOf(v_u_10.kind)
			local v301
			if v295 == nil then
				v301 = false
			else
				v301 = v295.isOpen() or false
			end
			v297.hotwire = v301
			v297.stashItems = v_u_7.num(v294:GetAttribute("StashItems"), 0, 0, 999)
			local v302 = workspace:FindFirstChild("Raid")
			local v303
			if v302 then
				v303 = v302:GetAttribute("EndsAt")
			else
				v303 = nil
			end
			local v304
			if type(v303) == "number" then
				v304 = v303 - workspace:GetServerTimeNow()
			else
				v304 = nil
			end
			v297.secondsToEnd = v304
			v297.atExtract = v_u_291(v294)
			v297.role = v_u_10.role
			v296(v297)
			if v295 ~= nil and (v295.isOpen() and v293.layout) then
				local v305 = v293.layout()
				if v305 ~= nil then
					local v306 = v295.setAvoid
					local v307 = v305.topYMax
					local v308 = v305.interval
					pcall(v306, v307, v308)
				end
			end
			v_u_178()
		end
	end
end
local function v_u_328(p310) -- name: onEv
	-- upvalues: (copy) v_u_19, (ref) v_u_7, (copy) v_u_146, (copy) v_u_28, (copy) v_u_8, (ref) v_u_6, (copy) v_u_48
	local v311 = v_u_19
	v311.events = v311.events + 1
	local v312 = v_u_7.normalizeEvent(p310)
	if v312 == nil then
		local v313 = v_u_19
		v313.eventsBad = v313.eventsBad + 1
		return
	else
		local v314 = v312.kind
		if v314 == "hw_start" then
			v_u_146(v312)
		elseif v314 == "hw_res" or v314 == "hw_end" then
			if v314 == "hw_end" then
				v_u_28.pending = nil
			end
			local v315 = v_u_8.HotwireUI
			if v315 ~= nil and v315.isOpen() then
				local v316 = v315.server
				pcall(v316, v312)
			end
			if v314 == "hw_end" and (v315 == nil or not v315.isOpen()) then
				local v317 = v_u_28
				v_u_28.open = false
				v317.id = nil
				return
			end
		elseif v314 == "ram" or (v314 == "bump" or v314 == "drag") then
			local v318 = v_u_8.VehicleDrive
			if v318 ~= nil then
				v318.push(v314, v312)
			end
			if v314 ~= "drag" then
				local v319
				if v_u_6 == nil or v_u_6.controllers == nil then
					v319 = nil
				else
					v319 = v_u_6.controllers.Camera
				end
				if v319 ~= nil and v319.shake then
					local v320 = v319.shake
					local v321 = v314 == "bump" and 0.45 or 0.25
					pcall(v320, v321, 0.3)
					return
				end
			end
		elseif v314 == "note" then
			local v322 = v312.text
			local v323 = v_u_48("HushUI")
			if v323 ~= nil and v323.toast then
				local v324 = v_u_19
				v324.toasts = v324.toasts + 1
				local v325 = v323.toast
				pcall(v325, v322, "warn")
				return
			end
		elseif v314 == "refuse" then
			local v326 = v_u_8.VehAnimPlay
			if v326 ~= nil then
				local v327 = v326.deny
				pcall(v327, nil)
			end
		end
	end
end
local function v_u_350(p329) -- name: onFx
	-- upvalues: (copy) v_u_19, (copy) v_u_48, (ref) v_u_33, (copy) v_u_202, (ref) v_u_36, (ref) v_u_37, (ref) v_u_7, (ref) v_u_6, (copy) v_u_8, (ref) v_u_39
	local v330 = v_u_19
	v330.fx = v330.fx + 1
	if type(p329) == "table" then
		if p329.kind == "eject" or p329.k == "eject" then
			local v331 = v_u_48("EjectRagdoll")
			if v331 ~= nil then
				if p329.kind == nil then
					p329.kind = "eject"
				end
				if v331 ~= nil and not v_u_33 then
					v_u_33 = true
					local v332 = v331.onHandoff
					local v333 = v_u_202
					pcall(v332, v333)
				end
				v_u_36 = 0
				v_u_37 = os.clock() + v_u_7.TUNE.EJECT_FAST_S
				local v334 = v331.play
				local v335
				if v_u_6 == nil or v_u_6.controllers == nil then
					v335 = nil
				else
					v335 = v_u_6.controllers.Atmosphere
				end
				local v336
				if v335 and v335.quality then
					local v337 = v335.quality
					local v338, v339 = pcall(v337)
					v336 = (not v338 or type(v339) ~= "number") and 3 or v339
				else
					v336 = 3
				end
				pcall(v334, p329, v336)
			end
		else
			if p329.kind == "boom" then
				local v340 = v_u_8.VehicleWreckFx or v_u_48("VehicleWreckFx")
				if v340 ~= nil then
					local v341 = v340.start
					local v342 = v_u_6
					pcall(v341, v342)
					local v343 = v340.boom
					local v344, v345 = pcall(v343, p329)
					if not v344 then
						warn("[VehicleClient] wreck fx: " .. tostring(v345))
					end
				end
			end
			local v346 = v_u_8.VehicleAudio
			if v346 ~= nil and v_u_39 then
				local v347 = v346.fx
				local v348, v349 = pcall(v347, p329)
				if not v348 then
					warn("[VehicleClient] audio fx: " .. tostring(v349))
				end
			end
		end
	else
		return
	end
end
local function v_u_359() -- name: pollRemotes
	-- upvalues: (ref) v_u_16, (copy) v_u_3, (copy) v_u_15, (ref) v_u_7, (ref) v_u_6, (copy) v_u_328, (copy) v_u_350
	local v351 = os.clock()
	if v351 < v_u_16 then
		return
	else
		v_u_16 = v351 + 1.5
		local v352 = v_u_3:FindFirstChild("HushNet")
		if v352 ~= nil then
			if not v_u_15[v_u_7.REMOTE.EV] and v352:FindFirstChild(v_u_7.REMOTE.EV) ~= nil then
				v_u_15[v_u_7.REMOTE.EV] = true
				local v353 = v_u_6.net.listen
				local v354 = v_u_7.REMOTE.EV
				local v355 = v_u_328
				pcall(v353, v354, v355)
			end
			if not v_u_15[v_u_7.REMOTE.FX] and v352:FindFirstChild(v_u_7.REMOTE.FX) ~= nil then
				v_u_15[v_u_7.REMOTE.FX] = true
				local v356 = v_u_6.net.listen
				local v357 = v_u_7.REMOTE.FX
				local v358 = v_u_350
				pcall(v356, v357, v358)
			end
		end
	end
end
local function v_u_361(p360) -- name: attrsOfCharacter
	-- upvalues: (copy) v_u_5
	return {
		["RideVehicle"] = p360:GetAttribute("RideVehicle"),
		["RideSeat"] = p360:GetAttribute("RideSeat"),
		["RideRole"] = p360:GetAttribute("RideRole"),
		["RideLean"] = p360:GetAttribute("RideLean"),
		["Action"] = p360:GetAttribute("Action"),
		["VehAnim"] = p360:GetAttribute("VehAnim"),
		["PredVehAnim"] = v_u_5:GetAttribute("PredVehAnim")
	}
end
local function v_u_407(p362) -- name: rideFrame
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (copy) v_u_111, (copy) v_u_131, (ref) v_u_29, (ref) v_u_7, (copy) v_u_48, (copy) v_u_19, (ref) v_u_40, (copy) v_u_23, (ref) v_u_26, (copy) v_u_2, (ref) v_u_6, (copy) v_u_20, (copy) v_u_82, (ref) v_u_39, (ref) v_u_25, (copy) v_u_5, (copy) v_u_90
	local v363 = v_u_8.VehicleDrive
	local v364 = v_u_8.VehicleDrivePlan
	local v365 = v_u_10.model
	local v366
	if v365 == nil then
		v366 = nil
	else
		v366 = v365:FindFirstChild("Chassis")
		if v366 == nil or not v366:IsA("BasePart") then
			v366 = nil
		end
	end
	local v367 = v_u_111()
	local v368 = os.clock()
	local v369
	if v_u_8.HotwireUI == nil then
		v369 = false
	else
		v369 = v_u_8.HotwireUI.isOpen() or false
	end
	if v_u_10.role == "driver" and (v363 ~= nil and v364 ~= nil) then
		local v370 = v_u_131(v367, v369, v365:GetAttribute("Engine") == "on")
		local v371 = v364.axis(v370)
		if v364.holdOn(v365:GetAttribute("Boarding")) and (v371.throttle ~= 0 and v368 - v_u_29 > 2) then
			v_u_29 = v368
			local v372 = v_u_7.texts.holdOn
			local v373 = v_u_48("HushUI")
			if v373 ~= nil and v373.toast then
				local v374 = v_u_19
				v374.toasts = v374.toasts + 1
				local v375 = v373.toast
				pcall(v375, v372, "info")
			end
		end
		local v376 = v363.step(p362, {
			["throttle"] = nil,
			["steer"] = nil,
			["handbrake"] = nil,
			["hold"] = false,
			["throttle"] = v371.throttle,
			["steer"] = v371.steer,
			["handbrake"] = v371.handbrake
		})
		if v376 ~= nil then
			v_u_10.speed = v376.speed
		end
		v_u_40 = {
			["id"] = v365,
			["throttle"] = v371.throttle,
			["handbrake"] = v371.handbrake == true,
			["info"] = v376
		}
	elseif v366 ~= nil then
		local v377 = v366.AssemblyLinearVelocity
		local v378 = v_u_10
		local v379 = v377.X * v377.X + v377.Z * v377.Z
		v378.speed = math.sqrt(v379)
		v_u_40 = {
			["id"] = v365
		}
	end
	local v380 = v_u_10.speed or 0
	if v366 ~= nil then
		local v381 = v366.CFrame.LookVector
		local v382 = v366.AssemblyLinearVelocity
		local v383 = v381.X * v381.X + v381.Z * v381.Z
		local v384 = math.sqrt(v383)
		if v384 > 0.0001 then
			v380 = (v382.X * v381.X + v382.Z * v381.Z) / v384
		end
	end
	local v385 = v_u_8.VehicleLightsPlan
	local v386
	if v385 == nil then
		if v367.up == true then
			v386 = v367.lb ~= true
		else
			v386 = false
		end
	else
		v386 = v385.padHorn(v_u_23, v367.up, v367.lb)
	end
	if v_u_10.role == "driver" and (v_u_26 ~= nil and not v369) then
		local v387
		if v_u_2:GetFocusedTextBox() ~= nil then
			v387 = true
		else
			local v388
			if v_u_6 == nil or v_u_6.controllers == nil then
				v388 = nil
			else
				v388 = v_u_6.controllers.Input
			end
			if v388 == nil or not v388.gameBlocked then
				v387 = false
			else
				local v389 = v388.gameBlocked
				local v390
				v387, v390 = pcall(v389)
				if v387 then
					v387 = v390 == true
				end
			end
		end
		local v391 = not v387 and v_u_2:IsKeyDown(Enum.KeyCode.H) or (v386 or v_u_20.horn)
		local v392 = v_u_10.variant == "police"
		local v393 = v_u_7.hornStep(v_u_26, v391 == true, v368, v392)
		if v393 ~= nil then
			v_u_82(v393)
			if v393 == "horn" and (v_u_39 and v_u_8.VehicleAudio ~= nil) then
				local v394 = v_u_8.VehicleAudio.horn
				pcall(v394, v365)
			end
		end
	end
	if v_u_25 ~= nil then
		local v395
		if v_u_6 == nil or v_u_6.controllers == nil then
			v395 = nil
		else
			v395 = v_u_6.controllers.Input
		end
		local v396 = v_u_20.aim
		if not v396 then
			if v395 == nil or v395.isAiming == nil then
				v396 = false
			else
				v396 = v395.isAiming() == true
			end
		end
		local v397 = v_u_7.canLean
		local v398 = v_u_10.role
		local v399 = v_u_10.seatDef
		local v400 = v_u_10.kind
		local v401 = v_u_5:GetAttribute("ViewMode") == "fptp"
		local function v402()
			-- upvalues: (ref) v_u_6
			return v_u_6.config.flag("RideLeanClassic")
		end
		local v403, v404 = pcall(v402)
		local v405 = v397(v398, v399, v400, v401, not v403 or v404 ~= false)
		if v405 then
			v405 = v396 == true
		end
		local v406 = v_u_7.leanStep(v_u_25, v405, v368)
		if v406 == "beat" then
			v_u_90(true)
			return v380
		end
		if v406 == "off" then
			v_u_90(false)
		end
	end
	return v380
end
local function v_u_423(p408) -- name: doorFrame
	-- upvalues: (ref) v_u_10, (ref) v_u_27, (copy) v_u_111, (copy) v_u_2, (ref) v_u_6, (copy) v_u_102, (ref) v_u_22, (ref) v_u_21, (ref) v_u_7, (copy) v_u_19, (copy) v_u_82
	if v_u_10.kind == "board" and (not v_u_10.abort and (v_u_27 ~= nil and not v_u_27.done)) then
		local v409 = v_u_111()
		local v410
		if v_u_2:GetFocusedTextBox() ~= nil then
			v410 = true
		else
			local v411
			if v_u_6 == nil or v_u_6.controllers == nil then
				v411 = nil
			else
				v411 = v_u_6.controllers.Input
			end
			if v411 == nil or not v411.gameBlocked then
				v410 = false
			else
				local v412 = v411.gameBlocked
				local v413
				v410, v413 = pcall(v412)
				if v410 then
					v410 = v413 == true
				end
			end
		end
		local v414 = not v410
		if v414 then
			for _, v415 in v_u_102("moveUp") do
				if not v_u_2:IsKeyDown(v415) then
					continue
				end
				v414 = true
			end
			v414 = false
			if not v414 then
				for _, v416 in v_u_102("moveDown") do
					if not v_u_2:IsKeyDown(v416) then
						continue
					end
					v414 = true
				end
				v414 = false
				if not v414 then
					for _, v417 in v_u_102("moveLeft") do
						if not v_u_2:IsKeyDown(v417) then
							continue
						end
						v414 = true
					end
					v414 = false
					if not v414 then
						for _, v418 in v_u_102("moveRight") do
							if not v_u_2:IsKeyDown(v418) then
								continue
							end
							v414 = true
						end
						v414 = false
					end
				end
			end
		end
		local v419 = v409.b
		if v419 then
			v419 = not v_u_22
		end
		local v420 = {
			["interact"] = v_u_21,
			["padB"] = v419,
			["moveKey"] = v414
		}
		local v421 = v409.stickX * v409.stickX + v409.stickY * v409.stickY
		v420.stick = math.sqrt(v421)
		v_u_22 = v409.b
		v_u_21 = false
		if v_u_7.cancelStep(v_u_27, p408, v420) then
			local v422 = v_u_19
			v422.cancels = v422.cancels + 1
			v_u_27.done = true
			v_u_82("board_cancel")
		end
	end
end
function v4.init(p424) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_8, (ref) v_u_10, (copy) v_u_28, (copy) v_u_19, (copy) v_u_15
	v_u_6 = p424
	v_u_7 = p424.lib.VehicleClientPlan
	p424.command("vehclient.status", function()
		-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) v_u_28, (ref) v_u_19, (ref) v_u_15, (ref) v_u_7
		local v425 = v_u_8.VehicleDrive
		local v426 = v425 == nil and {} or v425.stats()
		local v427 = v_u_8.RideCam
		local v428 = v427 == nil and {} or v427.stats()
		local v429 = v_u_8.VehicleHud
		local v430 = "session=%s role=%s seat=%s type=%s speed=%.1f hud=%s hotwire=%s | ops=%d dropped=%d events=%d bad=%d fx=%d lean=%d cancels=%d | drive frames=%d clipped=%d notOwner=%d anim=%d errors=%d | cam mode=%s wall=%d classic=%s | listen ev=%s fx=%s"
		local v431 = v_u_10.kind
		local v432 = tostring(v431)
		local v433 = v_u_10.role
		local v434 = tostring(v433)
		local v435 = v_u_10.seat
		local v436 = tostring(v435)
		local v437 = v_u_10.typeId
		local v438 = tostring(v437)
		local v439 = v_u_10.speed or 0
		local v440
		if v429 == nil then
			v440 = false
		else
			v440 = v429.isShown()
		end
		local v441 = tostring(v440)
		local v442 = v_u_28.open
		local v443 = tostring(v442)
		local v444 = v_u_19.ops
		local v445 = v_u_19.opsDropped
		local v446 = v_u_19.events
		local v447 = v_u_19.eventsBad
		local v448 = v_u_19.fx
		local v449 = v_u_19.leanBeats
		local v450 = v_u_19.cancels
		local v451 = v426.frames or 0
		local v452 = v426.clipped or 0
		local v453 = v426.notOwner or 0
		local v454 = v426.animFrames or 0
		local v455 = v426.errors or 0
		local v456 = v428.mode
		local v457 = tostring(v456)
		local v458 = v428.wallPulls or 0
		local v459 = v428.classicLive
		local v460 = tostring(v459)
		local v461 = v_u_15[v_u_7.REMOTE.EV] == true
		local v462 = tostring(v461)
		local v463 = v_u_15[v_u_7.REMOTE.FX] == true
		return v430:format(v432, v434, v436, v438, v439, v441, v443, v444, v445, v446, v447, v448, v449, v450, v451, v452, v453, v454, v455, v457, v458, v460, v462, (tostring(v463)))
	end)
end
function v4.start() -- name: start end
function v4.step(p464) -- name: step
	-- upvalues: (copy) v_u_359, (copy) v_u_5, (ref) v_u_7, (ref) v_u_13, (ref) v_u_14, (copy) v_u_8, (copy) v_u_48, (ref) v_u_38, (copy) v_u_151, (ref) v_u_39, (ref) v_u_6, (ref) v_u_40, (copy) v_u_19, (copy) v_u_213, (ref) v_u_10, (copy) v_u_251, (copy) v_u_361, (ref) v_u_11, (copy) v_u_231, (ref) v_u_12, (copy) v_u_266, (copy) v_u_284, (copy) v_u_407, (copy) v_u_423, (copy) v_u_28, (copy) v_u_146, (copy) v_u_309
	v_u_359()
	local v465 = v_u_5.Character
	local v466
	if v465 == nil then
		v466 = false
	else
		local v467 = v465:GetAttribute("Action")
		v466 = (v465:GetAttribute("RideVehicle") ~= nil or v467 == "Eject") and true or v_u_7.DOOR_ACTIONS[v467] ~= nil
	end
	local v468 = not v466 and v_u_5:GetAttribute("PredVehAnim") ~= nil and true or v466
	local v469 = os.clock()
	if v_u_13 <= v469 then
		v_u_13 = v469 + 0.5
		local v470 = workspace:FindFirstChild("Raid")
		local v471
		if v470 == nil then
			v471 = nil
		else
			v471 = v470:FindFirstChild("Vehicles")
		end
		v_u_14 = v471 ~= nil
	end
	local v472 = v_u_8.VehicleDrive
	if v_u_14 and v472 == nil then
		v472 = v_u_48("VehicleDrive")
	end
	if v472 ~= nil and v_u_14 then
		v472.animate(p464)
	end
	if v_u_14 and not v_u_38 then
		v_u_151()
	end
	local v473 = v_u_8.VehicleAudio
	if v_u_14 and v473 == nil then
		v473 = v_u_48("VehicleAudio")
	end
	if v473 ~= nil then
		if v_u_14 and not v_u_39 then
			v_u_39 = true
			local v474 = v473.init
			local v475 = v_u_6
			pcall(v474, v475)
		end
		if v_u_14 then
			v473.step(p464, v_u_40)
		elseif v_u_39 then
			v_u_39 = false
			local v476 = v473.stopAll
			pcall(v476, "no vehicles")
		end
	end
	local v477 = v_u_8.VehicleWreckFx
	if v_u_14 and v477 == nil then
		v477 = v_u_48("VehicleWreckFx")
	end
	if v477 ~= nil then
		if v_u_14 then
			if not v_u_19.wfOn then
				v_u_19.wfOn = true
				local v478 = v477.start
				local v479 = v_u_6
				pcall(v478, v479)
			end
			local v480 = v477.step
			pcall(v480, p464)
		elseif v_u_19.wfOn then
			v_u_19.wfOn = false
			local v481 = v477.stop
			pcall(v481)
		end
	end
	local v482 = v_u_8.VehAnimPlay
	if v_u_14 and v482 == nil then
		v482 = v_u_48("VehAnimPlay")
	end
	if v482 ~= nil and v_u_14 then
		v482.step(p464)
	end
	local v483 = v_u_8.EjectRagdoll
	if v483 ~= nil then
		v483.step(p464)
	end
	v_u_213(v469)
	if v468 and v465 ~= nil then
		local v484 = v_u_7.sessionOf((v_u_361(v465)))
		if v484.kind == "none" then
			if v_u_10.kind ~= "none" then
				v_u_251()
			end
		else
			local v485 = v484.kind
			local v486 = v484.vehId
			local v487 = tostring(v486)
			local v488 = v484.seat
			local v489 = tostring(v488)
			local v490 = v484.role
			local v491 = v485 .. "|" .. v487 .. "|" .. v489 .. "|" .. tostring(v490)
			if v491 ~= v_u_11 then
				v_u_251()
				v_u_48("VehicleDrivePlan")
				v_u_48("VehicleDrive")
				v_u_48("VehicleHud")
				v_u_48("HotwireUI")
				v_u_48("RideCam")
				v_u_48("EjectRagdoll")
				v_u_48("HushUI")
				if v484.role == "driver" then
					v_u_48("VehicleHudLayout")
					v_u_48("VehicleLightsPlan")
					v_u_48("VehicleLightsHud")
				end
				if v484.kind == "eject" then
					v_u_10 = v484
					v_u_11 = v491
					v_u_10.seatNames = {}
					v_u_231()
				else
					if os.clock() < v_u_12 then
						return
					end
					local v492 = v_u_266(v484)
					if v492 == nil then
						v_u_12 = os.clock() + 0.25
						return
					end
					v_u_11 = v491
					v_u_284(v484, v492)
				end
			end
			v_u_10.lean = v484.lean
			v_u_10.abort = v484.abort
			local v493 = v_u_8.VehicleHud
			local v494 = v_u_8.RideCam
			local v495 = v_u_8.HotwireUI
			local v496 = v_u_10.speed or 0
			if v_u_10.kind == "ride" then
				v496 = v_u_407(p464)
			elseif v_u_10.kind == "board" or v_u_10.kind == "unboard" then
				v_u_423(p464)
				local v497 = v_u_10.model
				local v498
				if v497 == nil then
					v498 = nil
				else
					v498 = v497:FindFirstChild("Chassis")
					if v498 == nil or not v498:IsA("BasePart") then
						v498 = nil
					end
				end
				if v498 ~= nil then
					local v499 = v498.AssemblyLinearVelocity
					local v500 = v_u_10
					local v501 = v499.X * v499.X + v499.Z * v499.Z
					v500.speed = math.sqrt(v501)
				end
			end
			if v_u_28.pending ~= nil then
				if v_u_10.kind == "ride" and v_u_10.role == "driver" then
					v_u_146(v_u_28.pending)
				elseif os.clock() - v_u_28.pendingAt > 3 then
					v_u_28.pending = nil
				end
			end
			if v_u_10.kind ~= "eject" then
				v_u_309(p464)
			end
			if v493 ~= nil then
				v493.step(p464)
			end
			if v495 ~= nil then
				v495.step(p464)
			end
			if v494 ~= nil then
				v494.set({
					["kind"] = v_u_10.kind,
					["model"] = v_u_10.model,
					["typeId"] = v_u_10.typeId,
					["spec"] = v_u_10.spec,
					["seat"] = v_u_10.seat,
					["seatDef"] = v_u_10.seatDef,
					["role"] = v_u_10.role,
					["lean"] = v_u_10.lean == true,
					["speed"] = v496,
					["side"] = v_u_10.side
				})
			end
		end
	else
		if v_u_10.kind ~= "none" then
			v_u_251()
		end
		local v502 = v_u_8.RideCam
		if v502 ~= nil and v502.mode() ~= "none" then
			v502.clear()
		end
		return
	end
end
function v4.riding() -- name: riding
	-- upvalues: (ref) v_u_10
	return v_u_10.kind ~= "none"
end
function v4.role() -- name: role
	-- upvalues: (ref) v_u_10
	if v_u_10.kind == "none" then
		return nil
	else
		return v_u_10.role
	end
end
function v4.phase() -- name: phase
	-- upvalues: (ref) v_u_7, (ref) v_u_10
	return v_u_7.phaseOf(v_u_10.kind)
end
function v4.session() -- name: session
	-- upvalues: (ref) v_u_10
	return v_u_10
end
function v4.stats() -- name: stats
	-- upvalues: (copy) v_u_19
	return table.clone(v_u_19)
end
return v4