-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCharacter

local v_u_1 = {}
local v_u_2 = {
	{ "primary", "Primary" },
	{ "secondary", "Sidearm" },
	{ "melee", "Melee" },
	{ "armor", "Armor" },
	{ "helmet", "Helmet" },
	{ "bag", "Backpack" },
	{ "legs", "Legs" },
	{ "boots", "Boots" },
	{ "ears", "Headset" },
	{ "secure", "Secure" }
}
local function v_u_9(p3, p4) -- name: fmtEffect
	if p3.kind == "add" then
		local v5 = p4 + 0.5
		return ("+%d %s"):format(math.floor(v5), p3.unit or "")
	end
	local v6 = (p4 - 1) * 100
	local v7 = v6 >= 0 and "+" or ""
	local v8 = v6 + (v6 >= 0 and 0.5 or -0.5)
	return ("%s%d%%"):format(v7, (math.floor(v8)))
end
function v_u_1.titleListMax(p10, p11) -- name: titleListMax
	local v12 = p11 * 2 + 6
	local v13 = p10 - 232
	local v14 = math.min(340, v13)
	return math.max(v12, v14)
end
function v_u_1.new(p_u_15, p_u_16) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_9
	local v_u_17 = p_u_15.ui
	local v_u_18 = p_u_15.theme
	local v_u_19 = v_u_18.color
	local v_u_20 = p_u_15.kit
	local v_u_21 = p_u_15.compact()
	local v_u_22 = {}
	local v_u_23 = "inventory"
	local v_u_24 = {
		["primary"] = "primary",
		["secondary"] = "secondary",
		["melee"] = "meleeSlot"
	}
	local function v_u_37(p25) -- name: weaponKey
		-- upvalues: (copy) v_u_24, (copy) p_u_15
		local v26 = v_u_24[p25]
		local v27 = p_u_15.cctx and p_u_15.cctx.controllers
		if v27 then
			v27 = p_u_15.cctx.controllers.Input
		end
		if v26 and v27 then
			local v28 = v27.hint
			if type(v28) == "function" then
				local v29 = v27.device
				if type(v29) == "function" then
					local v30 = v27.device
					local v31, v32 = pcall(v30)
					if not v31 or v32 == "Touch" then
						return ""
					end
					local v33 = v27.hint
					local v34 = v32 == "Gamepad" and "swap" or v26
					local v35, v36 = pcall(v33, v34)
					return (not v35 or type(v36) ~= "string") and "" or string.upper(v36)
				end
			end
		end
		return ""
	end
	local v_u_38 = nil
	local v_u_39 = false
	pcall(function()
		-- upvalues: (copy) p_u_15
		local v40 = p_u_15.cctx.lib.MenuRepair
		if v40 then
			local v41 = v40.install
			if type(v41) == "function" then
				v40.install(p_u_15)
			end
		end
	end)
	local v42 = v_u_21 and 0 or 0.34
	local v_u_43 = v_u_17.new("Frame", {
		["Name"] = "Area",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.new(v42, v_u_21 and 24 or 0, 0, 0),
		["Size"] = UDim2.new(1 - v42, v_u_21 and -48 or -24, 1, 0)
	}, p_u_16)
	local v_u_44 = nil
	local v_u_45 = v_u_18.isTouch() and not v_u_21 and 4 or 0
	local v_u_46 = false
	local function v47()
		-- upvalues: (ref) v_u_46, (copy) p_u_15
		v_u_46 = p_u_15.cctx.shared.GameMode.rule("killCardCosmetics") == true
	end
	pcall(v47)
	local v48 = {
		{
			["id"] = "inventory",
			["text"] = "Inventory"
		},
		{
			["id"] = "skills",
			["text"] = "Skills"
		},
		{
			["id"] = "skins",
			["text"] = "Skins"
		}
	}
	if v_u_46 then
		table.insert(v48, {
			["id"] = "killcards",
			["text"] = "Kill Cards"
		})
	end
	local v_u_51, v52 = v_u_17.tabs({
		["parent"] = nil,
		["tabs"] = nil,
		["selected"] = "inventory",
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_43,
		["tabs"] = v48,
		["size"] = UDim2.new(1, -(v_u_21 and 150 or 0), 0, v_u_18.touch(40)),
		["onChange"] = function(p49) -- name: onChange
			-- upvalues: (copy) v_u_22, (ref) v_u_44, (ref) v_u_23, (copy) p_u_15
			if p49 == "skins" and not v_u_22.gridOn() then
				if v_u_44 then
					v_u_44.select(v_u_23, true)
				end
				local function v50()
					-- upvalues: (ref) p_u_15
					p_u_15.openSkins()
				end
				pcall(v50)
			else
				v_u_23 = p49
				v_u_22.paintSub()
			end
		end
	})
	local v_u_53 = v52
	v_u_51.Position = UDim2.fromOffset(0, v_u_45)
	function v_u_22.gridOn() -- name: gridOn
		-- upvalues: (copy) p_u_15
		local v_u_54 = true
		local function v55()
			-- upvalues: (ref) v_u_54, (ref) p_u_15
			v_u_54 = p_u_15.cctx.config.flag("SkinsGrid") ~= false
		end
		pcall(v55)
		return v_u_54
	end
	local function v_u_59() -- name: paintSkinsBtn
		-- upvalues: (copy) p_u_15, (copy) v_u_43
		local v_u_56 = false
		local function v57()
			-- upvalues: (ref) v_u_56, (ref) p_u_15
			v_u_56 = p_u_15.skinsListed() == true
		end
		pcall(v57)
		local v58 = v_u_43:FindFirstChild("Tab_skins", true)
		if v58 and v58:IsA("GuiObject") then
			v58.Visible = v_u_56
		end
	end
	v_u_59()
	local v_u_60 = v_u_17.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_18.touch(40) + 10 + v_u_45),
		["Size"] = UDim2.new(1, 0, 1, -(v_u_18.touch(40) + 10 + v_u_45))
	}, v_u_43)
	local v_u_61 = v_u_17.new("Frame", {
		["Name"] = "Plate",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 24, 1, -8),
		["Size"] = UDim2.new(v42, -48, 0, 110),
		["Visible"] = not v_u_21
	}, p_u_16)
	v_u_17.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h1",
		["textSize"] = nil,
		["size"] = nil,
		["parent"] = v_u_61,
		["text"] = p_u_15.cctx.player.DisplayName,
		["textSize"] = v_u_21 and 26 or 34,
		["size"] = UDim2.new(1, 0, 0, 40)
	})
	local v_u_62 = v_u_17.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_61,
		["color"] = v_u_19.accent,
		["position"] = UDim2.fromOffset(0, 40),
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_63 = v_u_17.label({
		["parent"] = nil,
		["name"] = "Stats",
		["text"] = "",
		["style"] = "monoS",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_61,
		["position"] = UDim2.fromOffset(0, 62),
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_64 = nil
	local function v65()
		-- upvalues: (ref) v_u_64, (copy) p_u_15
		v_u_64 = p_u_15.cctx.lib.MenuTipOnce
	end
	pcall(v65)
	local v_u_66 = nil
	local v_u_67 = false
	local function v131() -- name: openTitles
		-- upvalues: (ref) v_u_64, (copy) p_u_15, (copy) v_u_17, (copy) v_u_18, (ref) v_u_1, (copy) v_u_19
		if v_u_64 then
			local v68 = v_u_64.markSeen
			local v69 = p_u_15
			pcall(v68, v69, "titlechg")
		end
		local v70 = p_u_15.profile
		local v_u_71
		if type(v70) == "table" then
			local v72 = v70.derived
			if type(v72) == "table" then
				local v73 = v70.derived.titles
				v_u_71 = type(v73) ~= "table" and {} or v70.derived.titles
			else
				v_u_71 = {}
			end
		else
			v_u_71 = {}
		end
		local v_u_74
		if type(v70) == "table" then
			local v75 = v70.cosmetics
			if type(v75) == "table" then
				local v76 = v70.cosmetics.equipped
				if type(v76) == "table" then
					v_u_74 = v70.cosmetics.equipped.title
				else
					v_u_74 = nil
				end
			else
				v_u_74 = nil
			end
		else
			v_u_74 = nil
		end
		local v_u_77 = nil
		local v_u_78 = nil
		local v_u_79 = nil
		local function v80()
			-- upvalues: (ref) p_u_15, (ref) v_u_79
			if p_u_15.cctx.config.flag("TitleRarity") ~= false then
				v_u_79 = p_u_15.cctx.shared.TitleRarity
			end
		end
		pcall(v80)
		local _ = v_u_17.modal({
			["title"] = "Your title",
			["body"] = nil,
			["width"] = 440,
			["build"] = nil,
			["buttons"] = nil,
			["body"] = #v_u_71 <= 0 and "You have no titles yet. Titles come from tasks, collections, badges, the weekly leaderboard, faction wars and passes." or (not v_u_18.isPhone() and "It shows under your name in your squad. Pick the one you want to wear." or nil),
			["build"] = function(p81) -- name: build
				-- upvalues: (ref) v_u_79, (copy) v_u_71, (ref) p_u_15, (ref) v_u_18, (ref) v_u_17, (ref) v_u_1, (ref) v_u_77, (ref) v_u_78, (ref) v_u_19, (copy) v_u_74
				local v82
				if v_u_79 then
					v82 = v_u_79.groups(v_u_71, v_u_79.namesFrom(p_u_15.cctx.shared))
				else
					v82 = nil
				end
				local v83 = v_u_18.phoneText(16, "text")
				local v84 = v83 * 1.4
				local v85 = math.ceil(v84)
				local v86 = #v_u_71 + 1
				local v87
				if v_u_17.modalLimits and v_u_17.safeInsets then
					local _, v88 = v_u_17.modalLimits(440, v_u_18.refSize(), v_u_17.safeInsets())
					v87 = v_u_1.titleListMax(v88, v_u_18.touch(44))
					if #v_u_71 > 0 and v_u_18.isPhone() then
						local v89 = v87 + 48
						v87 = math.min(340, v89)
					end
				else
					v87 = 340
				end
				if v82 then
					v86 = v86 + #v82 * (v85 + 6) / (v_u_18.touch(44) + 6)
				end
				local v90 = v_u_17.list
				local v91 = {
					["parent"] = nil,
					["name"] = "TitleList",
					["size"] = nil,
					["gap"] = 6,
					["padding"] = nil,
					["parent"] = p81
				}
				local v92 = UDim2.new
				local v93 = v86 * (v_u_18.touch(44) + 6)
				v91.size = v92(1, 0, 0, (math.min(v93, v87)))
				v91.padding = {
					0,
					0,
					0,
					0
				}
				local v_u_94 = v90(v91)
				local v_u_95 = true
				local function v101(p_u_96, p97, p98) -- name: row
					-- upvalues: (ref) v_u_17, (copy) v_u_94, (ref) v_u_18, (ref) p_u_15, (ref) v_u_77, (ref) v_u_78, (ref) v_u_95
					local v100 = v_u_17.button({
						["parent"] = v_u_94,
						["text"] = p97,
						["kind"] = p98 and "primary" or "secondary",
						["size"] = UDim2.new(1, -8, 0, v_u_18.touch(44)),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) p_u_15, (copy) p_u_96, (ref) v_u_77
							local v99 = {
								["op"] = "setTitle",
								["title"] = nil,
								["title"] = p_u_96
							}
							p_u_15.op(v99)
							if v_u_77 then
								v_u_77.close()
							end
						end
					})
					if p98 then
						v_u_78 = v100
					end
					if p98 or v_u_95 then
						v100:SetAttribute("PadDefault", p98 or nil)
					end
					v_u_95 = false
				end
				local function v121(p102, p_u_103, p_u_104) -- name: rarityRow
					-- upvalues: (ref) v_u_79, (ref) v_u_18, (ref) v_u_17, (ref) v_u_19, (copy) v_u_94, (ref) p_u_15, (ref) v_u_77, (ref) v_u_78
					local v105 = v_u_79.color(p_u_103.rarity, v_u_18)
					local v_u_106 = v_u_79.textColor(p_u_103.rarity, v_u_18)
					local v107 = v_u_18.touch(44)
					local v108 = v_u_17.new
					local v109 = "TextButton"
					local v110 = {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Selectable"] = true,
						["Name"] = "Title_" .. p_u_103.id
					}
					local v111
					if p_u_104 then
						v111 = v_u_19.accentDeep
					else
						v111 = v_u_19.raised
					end
					v110.BackgroundColor3 = v111
					v110.Size = UDim2.new(1, -8, 0, v107)
					v110.LayoutOrder = p102
					local v112 = v108(v109, v110, v_u_94)
					v112:SetAttribute("Rarity", p_u_103.rarity)
					v112.SelectionImageObject = v_u_17.selectionImage()
					local v113 = v_u_17.stroke
					local v114
					if p_u_104 then
						v114 = v_u_106
					else
						v114 = v_u_19.line
					end
					local v_u_115 = v113(v112, v114, 1, 0)
					v_u_17.new("Frame", {
						["Name"] = "Stripe",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["BackgroundColor3"] = v105,
						["Size"] = UDim2.new(0, 4, 1, 0)
					}, v112)
					v_u_17.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "h3",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v112,
						["text"] = p_u_103.name,
						["color"] = v_u_106,
						["position"] = UDim2.fromOffset(18, 0),
						["size"] = UDim2.new(1, -((p_u_104 and 76 or 12) + 18), 1, 0)
					})
					if p_u_104 then
						v_u_17.label({
							["parent"] = nil,
							["name"] = "Worn",
							["text"] = "WORN",
							["style"] = "micro",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["anchor"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v112,
							["color"] = v_u_19.accent,
							["position"] = UDim2.new(1, -12, 0, 0),
							["anchor"] = Vector2.new(1, 0),
							["size"] = UDim2.fromOffset(56, v107)
						})
					end
					v112.MouseEnter:Connect(function()
						-- upvalues: (copy) v_u_115, (copy) v_u_106
						v_u_115.Color = v_u_106
					end)
					v112.MouseLeave:Connect(function()
						-- upvalues: (copy) v_u_115, (copy) p_u_104, (copy) v_u_106, (ref) v_u_19
						local v116 = v_u_115
						local v117
						if p_u_104 then
							v117 = v_u_106
						else
							v117 = v_u_19.line
						end
						v116.Color = v117
					end)
					v112.SelectionGained:Connect(function()
						-- upvalues: (copy) v_u_115, (copy) v_u_106
						v_u_115.Color = v_u_106
					end)
					v112.SelectionLost:Connect(function()
						-- upvalues: (copy) v_u_115, (copy) p_u_104, (copy) v_u_106, (ref) v_u_19
						local v118 = v_u_115
						local v119
						if p_u_104 then
							v119 = v_u_106
						else
							v119 = v_u_19.line
						end
						v118.Color = v119
					end)
					v112.Activated:Connect(function()
						-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) p_u_15, (copy) p_u_103, (ref) v_u_77
						local function v120()
							-- upvalues: (ref) v_u_17, (ref) v_u_18
							v_u_17.sound(v_u_18.sounds.click)
						end
						pcall(v120)
						p_u_15.op({
							["op"] = "setTitle",
							["title"] = nil,
							["title"] = p_u_103.id
						})
						if v_u_77 then
							v_u_77.close()
						end
					end)
					if p_u_104 then
						v_u_78 = v112
						v112:SetAttribute("PadDefault", true)
					end
				end
				v101("", "Survivor (no title)", v_u_74 == nil and true or v_u_74 == "")
				if v82 then
					local v122 = 0
					for _, v123 in v82 do
						v122 = v122 + 1
						local v124 = v_u_17.new("Frame", {
							["Name"] = nil,
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Name"] = "Group_" .. v123.label,
							["Size"] = UDim2.new(1, -8, 0, v85),
							["LayoutOrder"] = v122
						}, v_u_94)
						v_u_17.label({
							["parent"] = nil,
							["name"] = "GroupName",
							["text"] = nil,
							["style"] = "caps",
							["textSize"] = nil,
							["color"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v124,
							["text"] = ("%s  \194\183  %d"):format(v123.label, #v123.items),
							["textSize"] = v83,
							["color"] = v_u_79.textColor(v123.rarity, v_u_18),
							["size"] = UDim2.new(1, 0, 1, 0)
						})
						v_u_17.new("Frame", {
							["Name"] = "Rule",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.45,
							["BorderSizePixel"] = 0,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = v_u_79.color(v123.rarity, v_u_18),
							["AnchorPoint"] = Vector2.new(0, 1),
							["Position"] = UDim2.fromScale(0, 1),
							["Size"] = UDim2.new(1, 0, 0, 1)
						}, v124)
						for _, v125 in v123.items do
							v122 = v122 + 1
							v121(v122, v125, v125.id == v_u_74)
						end
					end
				else
					for _, v126 in v_u_71 do
						local v127 = v126.id
						local v128 = tostring(v127)
						local v129 = v126.name
						v101(v128, tostring(v129), v126.id == v_u_74)
					end
				end
			end,
			["buttons"] = {
				{
					["text"] = "Close"
				}
			}
		})
		if v_u_17.device and v_u_17.device() == "Gamepad" then
			task.delay(0.1, function()
				-- upvalues: (ref) v_u_78
				local v130 = v_u_78
				if v130 and v130.Parent then
					game:GetService("GuiService").SelectedObject = v130
				end
			end)
		end
	end
	local v_u_132 = v_u_17.new("TextButton", {
		["Name"] = "ChangeTitle",
		["Text"] = "CHANGE TITLE",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["Font"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Selectable"] = true,
		["Font"] = Enum.Font.GothamMedium,
		["TextColor3"] = v_u_19.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, 0, 0, 49),
		["Size"] = UDim2.fromOffset(130, v_u_18.touch(18))
	}, v_u_61)
	v_u_132.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_132, (copy) v_u_19
		v_u_132.TextColor3 = v_u_19.accent
	end)
	v_u_132.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_132, (copy) v_u_19
		v_u_132.TextColor3 = v_u_19.text2
	end)
	v_u_132.MouseButton1Click:Connect(v131)
	local v_u_133
	if v_u_21 then
		v_u_133 = v_u_17.button({
			["parent"] = nil,
			["name"] = "TitleButton",
			["text"] = "Title",
			["kind"] = "secondary",
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_43,
			["size"] = UDim2.fromOffset(140, v_u_18.touch(40)),
			["position"] = UDim2.new(1, 0, 0, 0),
			["anchor"] = Vector2.new(1, 0),
			["onClick"] = v131
		})
	else
		v_u_133 = nil
	end
	local function v_u_140() -- name: showTip
		-- upvalues: (ref) v_u_64, (ref) v_u_67, (copy) p_u_15, (copy) p_u_16, (copy) v_u_61, (copy) v_u_132, (ref) v_u_133, (copy) v_u_21, (ref) v_u_66
		if v_u_64 and v_u_67 then
			local v134 = v_u_64.show
			local v135 = p_u_15
			local v137 = {
				["host"] = p_u_16,
				["target"] = function() -- name: target
					-- upvalues: (ref) v_u_61, (ref) v_u_132, (ref) v_u_133
					if v_u_61.Visible then
						return v_u_132
					else
						return v_u_133
					end
				end,
				["active"] = function() -- name: active
					-- upvalues: (ref) v_u_67, (ref) p_u_16
					local v136 = v_u_67 and p_u_16.Visible
					if v136 then
						v136 = p_u_16.Parent ~= nil
					end
					return v136
				end,
				["sides"] = v_u_21 and { "left", "below" } or { "above", "left" },
				["confine"] = function() -- name: confine
					-- upvalues: (ref) v_u_61
					if v_u_61.Visible then
						return v_u_61
					else
						return nil
					end
				end
			}
			local v138, v139 = pcall(v134, v135, "titlechg", v137)
			if v138 then
				v_u_66 = v139
			else
				warn("[MenuCharacter] tip failed:", v139)
			end
		else
			return
		end
	end
	local v_u_141 = v_u_17.new("Frame", {
		["Name"] = "Inventory",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_60)
	local v_u_142 = nil
	local v_u_143 = 0
	local v_u_144 = 0
	local v_u_145 = false
	local v_u_146 = true
	local function v_u_149() -- name: clearPartialMount
		-- upvalues: (copy) v_u_141
		local v147 = 0
		for _, v148 in v_u_141:GetChildren() do
			if v148.Name ~= "HushInventoryUI" then
				continue
			end
			v148:Destroy()
			v147 = v147 + 1
		end
		return v147
	end
	local v_u_150 = nil
	local v_u_151 = nil
	local function v_u_173(p_u_152, _, p153) -- name: inspectTape
		-- upvalues: (copy) p_u_15, (copy) v_u_17, (copy) v_u_19
		if type(p_u_152) == "string" and (string.match(p_u_152, "^tape_%d%d$") and typeof(p153) == "Instance") then
			if p_u_15.cctx.player:GetAttribute("Place") == "Raid" then
				return
			else
				local v_u_154 = nil
				local function v155()
					-- upvalues: (ref) v_u_154, (ref) p_u_15
					v_u_154 = p_u_15.cctx.shared.Tasks
				end
				pcall(v155)
				local v156 = v_u_154 and v_u_154.tapes
				if v156 then
					v156 = v_u_154.tapes[p_u_152]
				end
				if type(v156) == "table" then
					local v157 = v_u_17.new("Frame", {
						["Name"] = "Tape",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.3,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = -100,
						["ZIndex"] = 63,
						["BackgroundColor3"] = v_u_19.raised,
						["Size"] = UDim2.new(1, -6, 0, 112)
					}, p153)
					v_u_17.new("Frame", {
						["Name"] = "Bar",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["ZIndex"] = 64,
						["BackgroundColor3"] = v_u_19.accent,
						["Size"] = UDim2.new(0, 2, 1, 0)
					}, v157)
					v_u_17.label({
						["parent"] = nil,
						["name"] = "Kicker",
						["text"] = "Log disc",
						["style"] = "caps",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["zindex"] = 64,
						["parent"] = v157,
						["color"] = v_u_19.accent,
						["position"] = UDim2.fromOffset(12, 6),
						["size"] = UDim2.new(1, -24, 0, 16)
					})
					local v158 = v_u_17.label
					local v159 = {
						["parent"] = nil,
						["name"] = "TapeTitle",
						["text"] = nil,
						["style"] = "bodyStrong",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["zindex"] = 64,
						["parent"] = v157
					}
					local v160 = v156.title or p_u_152
					v159.text = tostring(v160)
					v159.position = UDim2.fromOffset(12, 24)
					v159.size = UDim2.new(1, -24, 0, 20)
					v158(v159)
					local v_u_161 = v_u_17.label({
						["parent"] = nil,
						["name"] = "Speaker",
						["text"] = "Loading...",
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["zindex"] = 64,
						["parent"] = v157,
						["color"] = v_u_19.text2,
						["position"] = UDim2.fromOffset(12, 46),
						["size"] = UDim2.new(1, -24, 0, 16)
					})
					v_u_17.button({
						["parent"] = nil,
						["name"] = "PlayTape",
						["text"] = "Read disc",
						["kind"] = "secondary",
						["icon"] = "eye",
						["height"] = 36,
						["width"] = 180,
						["position"] = nil,
						["zindex"] = 64,
						["onClick"] = nil,
						["parent"] = v157,
						["position"] = UDim2.fromOffset(12, 68),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) p_u_15, (copy) p_u_152
							local v162 = p_u_15.cctx.lib.MenuTasks
							if v162 then
								local v163 = v162.showTape
								if type(v163) == "function" then
									v162.showTape(p_u_15, p_u_152)
								end
							end
						end
					})
					task.spawn(function()
						-- upvalues: (ref) p_u_15, (copy) p_u_152, (copy) v_u_161, (ref) v_u_17
						local v164 = p_u_15.fetch
						local v165 = {
							["id"] = p_u_152
						}
						local v166, v167 = pcall(v164, "tape", v165, 600)
						if v_u_161.Parent then
							if v166 and type(v167) == "table" then
								local v168 = v167.speaker
								if type(v168) == "string" then
									local v169 = v_u_17.setText
									local v170 = v_u_161
									local v171 = v167.speaker
									local v172 = v167.date or ""
									v169(v170, ("%s  \194\183  %s"):format(v171, (tostring(v172))))
									return
								end
							end
							v_u_17.setText(v_u_161, "Transcript unavailable")
						end
					end)
				end
			end
		else
			return
		end
	end
	local function v_u_176() -- name: scheduleRetry
		-- upvalues: (ref) v_u_145, (ref) v_u_143, (ref) v_u_144, (ref) v_u_146, (ref) v_u_39, (ref) v_u_23, (copy) p_u_16, (ref) v_u_150, (ref) v_u_151
		if not v_u_145 and v_u_143 <= 5 then
			v_u_145 = true
			local v174 = task.delay
			local v175 = v_u_144 - os.clock() + 0.05
			v174(math.max(0.1, v175), function()
				-- upvalues: (ref) v_u_145, (ref) v_u_146, (ref) v_u_39, (ref) v_u_23, (ref) p_u_16, (ref) v_u_150, (ref) v_u_151
				v_u_145 = false
				if v_u_146 and (not v_u_39 and (v_u_23 == "inventory" and p_u_16.Parent)) then
					if p_u_16.Visible then
						if not v_u_150() then
							v_u_151()
						end
					end
				else
					return
				end
			end)
		end
	end
	v_u_150 = function()
		-- upvalues: (ref) v_u_39, (ref) v_u_144, (copy) v_u_176, (copy) p_u_15, (copy) v_u_141, (copy) v_u_149, (copy) v_u_173, (ref) v_u_38, (ref) v_u_143, (copy) v_u_21, (ref) v_u_142
		if v_u_39 then
			return true
		end
		if os.clock() < v_u_144 then
			v_u_176()
			return false
		end
		local v177 = p_u_15.cctx.controllers.InventoryUI
		local v178 = v_u_141:FindFirstAncestorWhichIsA("CanvasGroup")
		if v178 then
			warn("[MenuCharacter] InventoryUI mount is inside a CanvasGroup (icons will not render):", v178:GetFullName())
			p_u_15.cctx.player:SetAttribute("ClientError", "menu character: inventory inside CanvasGroup " .. v178.Name)
		end
		if v177 then
			local v179 = v177.mount
			if type(v179) == "function" then
				v_u_149()
				local v180 = v177.mount
				local v181 = v_u_141
				local v182, v183 = pcall(v180, v181, "menu")
				if v182 then
					v177.inspectExtra = v_u_173
					v_u_38 = v183
					v_u_39 = true
					v_u_143 = 0
					if v_u_21 and type(v183) == "table" then
						local v184 = v183.setSection
						if type(v184) == "function" and p_u_15.cctx.player:GetAttribute("InvUISection") == nil then
							local v185 = v183.isNarrow
							local v186
							if type(v185) == "function" then
								local v187 = v183.isNarrow
								local v188
								v186, v188 = pcall(v187)
								if v186 then
									v186 = v188 == true
								end
							else
								v186 = true
							end
							if v186 then
								local v189 = v183.setSection
								pcall(v189, "gear")
							end
						end
					end
					if v_u_142 then
						v_u_142:Destroy()
						v_u_142 = nil
					end
					return true
				end
				local v190 = v_u_149()
				v_u_143 = v_u_143 + 1
				local v191 = os.clock()
				local v192 = 2 ^ (v_u_143 - 1) * 4
				v_u_144 = v191 + math.min(v192, 60)
				warn("[MenuCharacter] InventoryUI.mount failed (attempt " .. v_u_143 .. ", removed " .. v190 .. " partial root):", v183)
				p_u_15.cctx.player:SetAttribute("ClientError", "menu character: InventoryUI.mount failed: " .. tostring(v183))
				p_u_15.cctx.player:SetAttribute("MenuInvMountFails", v_u_143)
				v_u_176()
			end
		end
		return false
	end
	v_u_151 = function()
		-- upvalues: (ref) v_u_39, (copy) v_u_149, (ref) v_u_142, (copy) v_u_17, (copy) v_u_141, (copy) p_u_15, (copy) v_u_21, (copy) v_u_18, (ref) v_u_2, (copy) v_u_19, (copy) v_u_37, (copy) v_u_20
		if v_u_39 then
			return
		else
			v_u_149()
			if v_u_142 then
				v_u_142:Destroy()
			end
			local v193 = v_u_17.new("Frame", {
				["Name"] = "Fallback",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.fromScale(1, 1)
			}, v_u_141)
			v_u_142 = v193
			local v194 = p_u_15.profile
			local v195
			if type(v194) == "table" then
				v195 = v194.inv or nil
			else
				v195 = nil
			end
			local v196 = v_u_21 and 230 or 300
			local v197, v198 = v_u_17.panel({
				["parent"] = nil,
				["size"] = nil,
				["title"] = "Equipment",
				["subtitle"] = "On the body",
				["layout"] = "v",
				["gap"] = 6,
				["parent"] = v193,
				["size"] = UDim2.new(0, v196, 1, 0)
			})
			v197.Name = "Equipment"
			if v_u_18.isPhone() then
				v198 = v_u_17.list({
					["parent"] = nil,
					["name"] = "Rows",
					["gap"] = 6,
					["padding"] = false,
					["parent"] = v198
				})
			end
			local v199 = p_u_15.slots()
			for v200, v201 in v_u_2 do
				local v202 = v_u_17.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.15,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = v201[1],
					["BackgroundColor3"] = v_u_19.raised,
					["Size"] = UDim2.new(1, 0, 0, v_u_21 and 34 or 44),
					["LayoutOrder"] = v200
				}, v198)
				v_u_17.stroke(v202, v_u_19.line)
				local v203 = v199[v201[1]]
				local v204 = v_u_37(v201[1])
				local v205
				if v204 == "" then
					v205 = 10
				else
					local v206 = #v204 * 7 + 2
					local v207 = v_u_17.new
					local v208 = "TextLabel"
					local v209 = {
						["Name"] = "Key",
						["BackgroundTransparency"] = 1,
						["FontFace"] = nil,
						["TextSize"] = 11,
						["TextColor3"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["TextXAlignment"] = nil,
						["Text"] = nil,
						["FontFace"] = v_u_18.font.monoBold
					}
					local v210
					if type(v203) == "table" then
						v210 = v_u_19.accent
					else
						v210 = v_u_19.muted
					end
					v209.TextColor3 = v210
					v209.Position = UDim2.fromOffset(10, 3)
					v209.Size = UDim2.fromOffset(v206, 14)
					v209.TextXAlignment = Enum.TextXAlignment.Left
					v209.Text = v204
					v207(v208, v209, v202)
					v205 = v206 + 10 + 5
				end
				v_u_17.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v202,
					["text"] = v201[2],
					["position"] = UDim2.fromOffset(v205, 3),
					["size"] = UDim2.new(1, -v205 - 10, 0, 14)
				})
				local v211
				if type(v203) == "table" then
					v211 = v_u_20.itemDef(v203.id) or nil
				else
					v211 = nil
				end
				local v212 = v_u_17.label
				local v213 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["textSize"] = 14,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v202,
					["text"] = type(v203) ~= "table" and "Empty" or v_u_20.itemName(v203.id)
				}
				local v214
				if v203 then
					v214 = v_u_19.text
				else
					v214 = v_u_19.muted
				end
				v213.color = v214
				v213.position = UDim2.fromOffset(10, v_u_21 and 15 or 19)
				v213.size = UDim2.new(1, -20, 0, 18)
				v212(v213)
				if not v211 then
					continue
				end
				v_u_17.new("Frame", {
					["Name"] = "Rarity",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_18.rarityColor(v211.shown or v211.rarity),
					["Size"] = UDim2.new(0, 3, 1, 0)
				}, v202)
			end
			local v215, v216 = v_u_17.panel({
				["parent"] = nil,
				["position"] = nil,
				["size"] = nil,
				["title"] = "Stash",
				["subtitle"] = "The inventory is not ready yet. It retries by itself.",
				["padding"] = 8,
				["parent"] = v193,
				["position"] = UDim2.fromOffset(v196 + 12, 0),
				["size"] = UDim2.new(1, -v196 - 12, 1, 0)
			})
			v215.Name = "Stash"
			local v217
			if type(v195) == "table" then
				local v218 = v195.containers
				if type(v218) == "table" then
					v217 = v195.containers.stash or nil
				else
					v217 = nil
				end
			else
				v217 = nil
			end
			if type(v217) == "table" then
				local v219 = v_u_17.new("ScrollingFrame", {
					["Name"] = "Grid",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["CanvasSize"] = nil,
					["ScrollBarThickness"] = nil,
					["ScrollBarImageColor3"] = nil,
					["ScrollingDirection"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["CanvasSize"] = UDim2.new(),
					["ScrollBarThickness"] = v_u_18.scrollBar,
					["ScrollBarImageColor3"] = v_u_19.lineStrong,
					["ScrollingDirection"] = Enum.ScrollingDirection.Y
				}, v216)
				local v220 = v217.w
				local v221 = tonumber(v220) or 10
				local v222 = v217.h
				local v223 = tonumber(v222) or 30
				local v224 = (v216.AbsoluteSize.X > 10 and v216.AbsoluteSize.X / v_u_18.uiScale() - 16 or (v_u_21 and 420 or 640)) / v221
				local v225 = math.min(56, v224)
				local v226 = math.floor(v225)
				local v227 = math.max(v226, 30)
				local v228 = v_u_17.new("Frame", {
					["Name"] = "Cells",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_19.bgDeep,
					["Size"] = UDim2.fromOffset(v227 * v221, v227 * v223)
				}, v219)
				v219.CanvasSize = UDim2.fromOffset(0, v227 * v223)
				for v229 = 1, v221 - 1 do
					v_u_17.new("Frame", {
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.6,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_19.line,
						["Position"] = UDim2.fromOffset(v229 * v227, 0),
						["Size"] = UDim2.new(0, 1, 1, 0)
					}, v228)
				end
				for v230 = 1, v223 - 1 do
					v_u_17.new("Frame", {
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.6,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_19.line,
						["Position"] = UDim2.fromOffset(0, v230 * v227),
						["Size"] = UDim2.new(1, 0, 0, 1)
					}, v228)
				end
				local v231 = v217.items
				for _, v232 in type(v231) == "table" and (v217.items or {}) or {} do
					if type(v232) ~= "table" or not v232.id then
						continue
					end
					local v233 = v_u_20.itemDef(v232.id)
					local v234 = v233 and (v233.w or 1) or 1
					local v235 = v233 and v233.h or 1
					if not v232.r then
						local v236 = v234
						v234 = v235
						v235 = v236
					end
					local v237 = v_u_20.itemCell(v228, v232.id, {
						["size"] = v227,
						["w"] = v235,
						["h"] = v234,
						["count"] = v232.n
					})
					local v238 = UDim2.fromOffset
					local v239 = v232.x
					local v240 = (tonumber(v239) or 0) * v227
					local v241 = v232.y
					v237.Position = v238(v240, (tonumber(v241) or 0) * v227)
				end
			else
				v_u_20.empty(v216, "Loading your stash...")
			end
		end
	end
	local v_u_242 = v_u_17.list({
		["parent"] = nil,
		["name"] = "Skills",
		["gap"] = 8,
		["parent"] = v_u_60
	})
	v_u_242.Visible = false
	local v_u_243 = "training"
	local function v244()
		-- upvalues: (copy) p_u_15, (ref) v_u_243
		if p_u_15.cctx.player:GetAttribute("SkillsMode") == "perks" then
			v_u_243 = "perks"
		end
	end
	pcall(v244)
	local v_u_245 = v_u_18.touch(34)
	local v_u_246 = v_u_17.new("Frame", {
		["Name"] = "SkillMode",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, v_u_245)
	}, v_u_60)
	local v_u_247 = v_u_17.new("Frame", {
		["Name"] = "PerksFrame",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Position"] = UDim2.fromOffset(0, v_u_245 + 8),
		["Size"] = UDim2.new(1, 0, 1, -(v_u_245 + 8))
	}, v_u_60)
	v_u_242.Position = UDim2.fromOffset(0, v_u_245 + 8)
	v_u_242.Size = UDim2.new(1, 0, 1, -(v_u_245 + 8))
	local v_u_248 = nil
	local v_u_249 = false
	local v_u_250 = false
	local function v_u_265(p251) -- name: applyDeep
		-- upvalues: (copy) v_u_18, (ref) v_u_250, (copy) v_u_45, (copy) v_u_51, (ref) v_u_133, (copy) v_u_60, (copy) v_u_246, (ref) v_u_23, (copy) v_u_245, (copy) v_u_247
		if p251 and not v_u_18.isPhone() then
			p251 = false
		end
		if p251 ~= v_u_250 then
			v_u_250 = p251
			local v252 = v_u_18.touch(40) + 10 + v_u_45
			v_u_51.Visible = not p251
			if v_u_133 ~= nil then
				v_u_133.Visible = not p251
			end
			local v253 = v_u_60
			local v254 = UDim2.fromOffset
			local v255 = 0
			local v256
			if p251 then
				v256 = v_u_45
			else
				v256 = v252
			end
			v253.Position = v254(v255, v256)
			local v257 = v_u_60
			local v258 = UDim2.new
			local v259 = 1
			local v260 = 0
			local v261 = 1
			if p251 then
				v252 = v_u_45
			end
			v257.Size = v258(v259, v260, v261, -v252)
			local v262 = v_u_246
			local v263
			if v_u_23 == "skills" then
				v263 = not p251
			else
				v263 = false
			end
			v262.Visible = v263
			local v264 = p251 and 0 or v_u_245 + 8
			v_u_247.Position = UDim2.fromOffset(0, v264)
			v_u_247.Size = UDim2.new(1, 0, 1, -v264)
		end
	end
	local function v_u_276() -- name: ensureTree
		-- upvalues: (ref) v_u_248, (ref) v_u_249, (copy) p_u_15, (copy) v_u_247, (copy) v_u_265, (copy) v_u_20
		if v_u_248 or v_u_249 then
			return v_u_248
		end
		local function v266()
			-- upvalues: (ref) p_u_15
			return p_u_15.cctx.lib.MenuTree
		end
		local v267, v268 = pcall(v266)
		local v269
		if v267 and type(v268) == "table" then
			local v270 = v268.mount
			if type(v270) == "function" then
				v269 = v268.mount
			else
				v269 = v268.new
			end
		else
			v269 = nil
		end
		local v271, v272
		if v269 then
			local v273 = p_u_15
			local v274 = v_u_247
			v271, v272 = pcall(v269, v273, v274)
		else
			v271 = false
			v272 = nil
		end
		if v271 and type(v272) == "table" then
			v_u_248 = v272
			function v272.onPage(p275)
				-- upvalues: (ref) v_u_265
				v_u_265(p275 == "B" and true or p275 == "F")
			end
		else
			v_u_249 = true
			warn("[MenuCharacter] the perks page failed: " .. tostring(v272))
			v_u_20.empty(v_u_247, "Perks are not available right now.")
		end
		return v_u_248
	end
	local function v_u_281() -- name: paintMode
		-- upvalues: (copy) v_u_246, (copy) v_u_17, (ref) v_u_243, (copy) v_u_245, (copy) p_u_15, (copy) v_u_22
		for _, v277 in v_u_246:GetChildren() do
			v277:Destroy()
		end
		v_u_17.layout(v_u_246, "h", 8)
		for v278, v_u_279 in {
			{ "training", "Training" },
			{ "perks", "Perks" }
		} do
			v_u_17.button({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["kind"] = nil,
				["height"] = nil,
				["width"] = 150,
				["onClick"] = nil,
				["parent"] = v_u_246,
				["name"] = "Mode_" .. v_u_279[1],
				["text"] = v_u_279[2],
				["kind"] = v_u_243 == v_u_279[1] and "primary" or "secondary",
				["height"] = v_u_245,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_279, (ref) v_u_243, (ref) p_u_15, (ref) v_u_22
					if v_u_279[1] ~= v_u_243 then
						v_u_243 = v_u_279[1]
						local function v280()
							-- upvalues: (ref) p_u_15, (ref) v_u_279
							p_u_15.cctx.player:SetAttribute("SkillsMode", v_u_279[1])
						end
						pcall(v280)
						v_u_22.paintSub()
					end
				end
			}).LayoutOrder = v278
		end
	end
	local v_u_282 = v_u_17.new("Frame", {
		["Name"] = "SkinsPage",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_60)
	local v_u_283 = nil
	local v_u_284 = v_u_17.new("Frame", {
		["Name"] = "KillCardsPage",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_60)
	local v_u_285 = nil
	local v_u_286 = false
	local function v_u_296() -- name: ensureKc
		-- upvalues: (ref) v_u_285, (ref) v_u_286, (ref) v_u_46, (copy) p_u_15, (copy) v_u_284, (copy) v_u_20
		if v_u_285 or (v_u_286 or not v_u_46) then
			return v_u_285
		end
		local function v287()
			-- upvalues: (ref) p_u_15
			return p_u_15.cctx.lib.MenuKillCard
		end
		local v288, v289 = pcall(v287)
		local v290
		if v288 and type(v289) == "table" then
			local v291 = v289.mount
			if type(v291) == "function" then
				v290 = v289.mount
			else
				v290 = v289.new
			end
		else
			v290 = nil
		end
		local v292, v293
		if v290 then
			local v294 = p_u_15
			local v295 = v_u_284
			v292, v293 = pcall(v290, v294, v295)
		else
			v292 = false
			v293 = nil
		end
		if v292 and type(v293) == "table" then
			v_u_285 = v293
		else
			v_u_286 = true
			warn("[MenuCharacter] the kill cards page failed: " .. tostring(v293))
			v_u_20.empty(v_u_284, "Kill Cards are not available right now.")
		end
		return v_u_285
	end
	local function v_u_309() -- name: ensureGrid
		-- upvalues: (ref) v_u_283, (copy) p_u_15, (copy) v_u_18, (copy) v_u_21, (copy) v_u_282
		if v_u_283 then
			return v_u_283
		end
		local function v297()
			-- upvalues: (ref) p_u_15
			return p_u_15.cctx.lib.MenuSkinsGrid
		end
		local v298, v299 = pcall(v297)
		if not v298 or type(v299) ~= "table" then
			return nil
		end
		local v300 = v299.new
		local v301 = p_u_15
		local v306 = {
			["phone"] = v_u_18.isPhone(),
			["compact"] = v_u_21,
			["busy"] = function() -- name: busy
				-- upvalues: (ref) p_u_15
				local function v302()
					-- upvalues: (ref) p_u_15
					return p_u_15.cctx.lib.CrateWindow
				end
				local v303, v304 = pcall(v302)
				if v303 then
					if v304 == nil then
						v303 = false
					else
						local v305 = v304.opening
						if type(v305) == "function" then
							v303 = v304.opening() == true
						else
							v303 = false
						end
					end
				end
				return v303
			end
		}
		local v307, v308 = pcall(v300, v301, v306)
		if not v307 then
			warn("[MenuCharacter] the skins grid failed: " .. tostring(v308))
			return nil
		end
		v_u_283 = v308
		v_u_283.frame.Parent = v_u_282
		return v_u_283
	end
	local function v_u_336() -- name: drawSkills
		-- upvalues: (copy) v_u_20, (copy) v_u_242, (copy) p_u_15, (copy) v_u_17, (copy) v_u_19, (copy) v_u_21, (ref) v_u_9
		v_u_20.clear(v_u_242)
		local v_u_310 = nil
		local function v311()
			-- upvalues: (ref) v_u_310, (ref) p_u_15
			v_u_310 = p_u_15.cctx.shared.Skills
		end
		pcall(v311)
		local v312 = p_u_15.derived()
		local v313 = v312.skills
		local v314 = type(v313) == "table" and (v312.skills or {}) or {}
		local v315 = not (v_u_310 and v_u_310.IDS) and {
			"aim",
			"reload",
			"sneak",
			"endurance",
			"strength",
			"firstaid",
			"looting",
			"melee"
		} or v_u_310.IDS
		v_u_17.label({
			["parent"] = nil,
			["text"] = "Skills grow by doing and stay with you after death.",
			["style"] = "small",
			["order"] = 0,
			["size"] = nil,
			["parent"] = v_u_242,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v316 = v_u_310
		for v317, v318 in v315 do
			local v319 = v316 and v316.defs[v318] or {
				["name"] = nil,
				["desc"] = "",
				["from"] = "",
				["kind"] = "mul",
				["max"] = 0,
				["sign"] = 1,
				["unit"] = "%",
				["name"] = v318
			}
			local v320 = v314[v318] or {}
			local v321 = v320.level
			local v322 = tonumber(v321) or 0
			local v323 = v320.progress
			local v324 = tonumber(v323) or 0
			local v325 = v_u_17.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = v318,
				["BackgroundColor3"] = v_u_19.raised,
				["Size"] = UDim2.new(1, -6, 0, v_u_21 and 62 or 74),
				["LayoutOrder"] = v317
			}, v_u_242)
			v_u_17.stroke(v325, v_u_19.line)
			v_u_17.pad(v325, {
				16,
				16,
				8,
				10
			})
			v_u_17.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["size"] = nil,
				["parent"] = v325,
				["text"] = v319.name,
				["size"] = UDim2.new(0.3, 0, 0, 22)
			})
			v_u_17.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v325,
				["text"] = v319.desc,
				["position"] = UDim2.fromScale(0.3, 0),
				["size"] = UDim2.new(0.42, 0, 0, 22)
			})
			local v326
			if v316 then
				local v327 = v316.effect
				local v328, v329 = pcall(v327, v318, v322)
				v326 = not v328 and 0 or v329
			else
				v326 = 0
			end
			local v330 = v_u_17.label
			local v331 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "mono",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v325,
				["text"] = ("LV %d  \194\183  %s"):format(v322, v_u_9(v319, v326))
			}
			local v332
			if v322 > 0 then
				v332 = v_u_19.accent
			else
				v332 = v_u_19.text2
			end
			v331.color = v332
			v331.position = UDim2.fromScale(0.72, 0)
			v331.size = UDim2.new(0.28, 0, 0, 22)
			v330(v331)
			v_u_17.progress({
				["parent"] = nil,
				["value"] = 0,
				["segments"] = 10,
				["size"] = nil,
				["position"] = nil,
				["parent"] = v325,
				["size"] = UDim2.new(1, 0, 0, 6),
				["position"] = UDim2.new(0, 0, 1, -18)
			}).set((v322 + v324) / 10)
			local v333 = v_u_17.label
			local v334 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v325
			}
			local v335 = v319.from or ""
			v334.text = "Rises by: " .. tostring(v335)
			v334.color = v_u_19.muted
			v334.position = UDim2.new(0, 0, 1, -10)
			v334.size = UDim2.new(1, 0, 0, 12)
			v333(v334)
		end
	end
	function v_u_22.paintSub() -- name: paintSub
		-- upvalues: (ref) v_u_250, (ref) v_u_23, (ref) v_u_243, (copy) v_u_265, (copy) v_u_141, (copy) v_u_242, (copy) v_u_247, (copy) v_u_246, (copy) v_u_282, (copy) v_u_284, (ref) v_u_248, (ref) v_u_283, (ref) v_u_285, (copy) v_u_281, (copy) v_u_276, (copy) v_u_336, (copy) v_u_309, (copy) v_u_296, (ref) v_u_150, (ref) v_u_151
		if v_u_250 and (v_u_23 ~= "skills" or v_u_243 ~= "perks") then
			v_u_265(false)
		end
		v_u_141.Visible = v_u_23 == "inventory"
		local v337 = v_u_242
		local v338
		if v_u_23 == "skills" then
			v338 = v_u_243 == "training"
		else
			v338 = false
		end
		v337.Visible = v338
		local v339 = v_u_247
		local v340
		if v_u_23 == "skills" then
			v340 = v_u_243 == "perks"
		else
			v340 = false
		end
		v339.Visible = v340
		local v341 = v_u_246
		local v342
		if v_u_23 == "skills" then
			v342 = not v_u_250
		else
			v342 = false
		end
		v341.Visible = v342
		v_u_282.Visible = v_u_23 == "skins"
		v_u_284.Visible = v_u_23 == "killcards"
		if (v_u_23 ~= "skills" or v_u_243 ~= "perks") and v_u_248 then
			local v343 = v_u_248.hide
			pcall(v343)
		end
		if v_u_23 ~= "skins" and v_u_283 then
			local v344 = v_u_283.hide
			pcall(v344)
		end
		if v_u_23 ~= "killcards" and v_u_285 then
			local v345 = v_u_285.hide
			pcall(v345)
		end
		if v_u_23 == "skills" then
			v_u_281()
			if v_u_243 ~= "perks" then
				v_u_336()
				return
			end
			local v346 = v_u_276()
			if v346 then
				local v347 = v346.show
				pcall(v347)
				return
			end
		elseif v_u_23 == "skins" then
			local v348 = v_u_309()
			if v348 then
				v348.show()
				return
			end
		elseif v_u_23 == "killcards" then
			local v349 = v_u_296()
			if v349 then
				local v350 = v349.show
				pcall(v350)
				return
			end
		elseif not v_u_150() then
			v_u_151()
		end
	end
	function v_u_22.showSkins(p351) -- name: showSkins
		-- upvalues: (copy) v_u_22, (ref) v_u_23, (ref) v_u_53, (copy) v_u_309
		if v_u_22.gridOn() then
			v_u_23 = "skins"
			if v_u_53 then
				v_u_53.select("skins", true)
			end
			v_u_22.paintSub()
			local v352 = v_u_309()
			if v352 then
				v352.focusWeapon(p351)
			end
		end
	end
	function v_u_22.showKillCards() -- name: showKillCards
		-- upvalues: (ref) v_u_46, (ref) v_u_23, (ref) v_u_53, (copy) v_u_22
		if not v_u_46 then
			return false
		end
		v_u_23 = "killcards"
		if v_u_53 then
			v_u_53.select("killcards", true)
		end
		v_u_22.paintSub()
		return true
	end
	function v_u_22.showPerks() -- name: showPerks
		-- upvalues: (ref) v_u_23, (ref) v_u_243, (ref) v_u_53, (copy) p_u_15, (copy) v_u_22
		v_u_23 = "skills"
		v_u_243 = "perks"
		if v_u_53 then
			v_u_53.select("skills", true)
		end
		local function v353()
			-- upvalues: (ref) p_u_15
			p_u_15.cctx.player:SetAttribute("SkillsMode", "perks")
		end
		pcall(v353)
		v_u_22.paintSub()
		return true
	end
	function v_u_22.onBack() -- name: onBack
		-- upvalues: (ref) v_u_23, (ref) v_u_243, (ref) v_u_248, (ref) v_u_39, (copy) p_u_15
		if v_u_23 == "skills" and (v_u_243 == "perks" and v_u_248) then
			local v354 = v_u_248.onBack
			if type(v354) == "function" then
				local v355 = v_u_248.onBack
				local v356, v357 = pcall(v355)
				local v358 = v356
				if v358 then
					v358 = v357 == true
				end
				return v358
			end
		end
		if v_u_23 ~= "inventory" or not v_u_39 then
			return false
		end
		local v_u_359 = false
		local function v366()
			-- upvalues: (ref) p_u_15, (ref) v_u_359
			local v360 = p_u_15.cctx.controllers.InventoryUI
			if v360 then
				local v361 = v360.closeTopLayer
				if type(v361) == "function" then
					v_u_359 = v360.closeTopLayer({
						["visibleOnly"] = true
					}) == true
					local v362 = game:GetService("Players").LocalPlayer
					if v362 then
						local v363 = v360.lastLayer
						if type(v363) == "function" then
							local v364 = "MenuBackLayer"
							local v365
							if v_u_359 then
								v365 = v360.lastLayer()
							else
								v365 = nil
							end
							v362:SetAttribute(v364, v365)
						end
					end
				end
			end
		end
		pcall(v366)
		return v_u_359
	end
	function v_u_22.showSub(p367) -- name: showSub
		-- upvalues: (copy) v_u_22, (ref) v_u_23, (ref) v_u_53
		if p367 == "skins" then
			if not v_u_22.gridOn() then
				return false
			end
			v_u_22.showSkins(nil)
			return true
		end
		if p367 == "killcards" then
			return v_u_22.showKillCards()
		end
		if p367 ~= "inventory" and p367 ~= "skills" then
			return false
		end
		v_u_23 = p367
		if v_u_53 then
			v_u_53.select(p367, true)
		end
		v_u_22.paintSub()
		return true
	end
	local function v_u_386() -- name: paintPlate
		-- upvalues: (copy) p_u_15, (copy) v_u_17, (copy) v_u_62, (copy) v_u_18, (copy) v_u_19, (copy) v_u_63
		local v368 = p_u_15.profile
		local v369
		if type(v368) == "table" then
			local v370 = v368.stats
			v369 = type(v370) == "table" and (v368.stats or {}) or {}
		else
			v369 = {}
		end
		local v_u_371 = type(v368) == "table" and (v368.cosmetics and v368.cosmetics.equipped)
		if v_u_371 then
			v_u_371 = v368.cosmetics.equipped.title
		end
		local v_u_372 = nil
		local function v373()
			-- upvalues: (ref) v_u_372, (ref) p_u_15
			v_u_372 = p_u_15.cctx.shared.Tasks.titles
		end
		pcall(v373)
		local v374 = v_u_17.setText
		local v375 = v_u_62
		local v376
		if type(v_u_371) == "string" and v_u_371 ~= "" then
			if v_u_372 then
				v376 = v_u_372[v_u_371] or v_u_371
			else
				v376 = v_u_371
			end
		else
			v376 = "Survivor"
		end
		v374(v375, v376)
		local function v379()
			-- upvalues: (ref) p_u_15, (ref) v_u_62, (copy) v_u_371, (ref) v_u_18, (ref) v_u_19
			if p_u_15.cctx.config.flag("TitleRarity") == false then
				v_u_62.TextColor3 = v_u_19.accent
			else
				local v377 = p_u_15.cctx.shared.TitleRarity
				local v378 = v_u_371
				v_u_62.TextColor3 = v377.textColor((type(v378) ~= "string" or v_u_371 == "") and 1 or v377.rarityOf(v_u_371), v_u_18)
			end
		end
		pcall(v379)
		local v380 = v_u_63
		local v381 = v369.raids
		local v382 = tonumber(v381) or 0
		local v383 = v369.extracts
		local v384 = tonumber(v383) or 0
		local v385 = v369.kills
		v380.Text = ("RAIDS %d   EXTRACTS %d   KILLS %d"):format(v382, v384, tonumber(v385) or 0)
	end
	function v_u_22.show() -- name: show
		-- upvalues: (ref) v_u_67, (copy) v_u_59, (copy) v_u_386, (copy) v_u_22, (ref) v_u_39, (ref) v_u_38, (copy) v_u_140
		v_u_67 = true
		v_u_59()
		v_u_386()
		v_u_22.paintSub()
		if v_u_39 and v_u_38 then
			local function v389()
				-- upvalues: (ref) v_u_38
				local v387 = v_u_38
				if type(v387) == "table" then
					local v388 = v_u_38.show
					if type(v388) == "function" then
						v_u_38.show()
					end
				end
			end
			pcall(v389)
		end
		v_u_140()
	end
	function v_u_22.hide() -- name: hide
		-- upvalues: (ref) v_u_67, (ref) v_u_283, (ref) v_u_285, (ref) v_u_248, (ref) v_u_66, (copy) v_u_17, (ref) v_u_39, (ref) v_u_38
		v_u_67 = false
		if v_u_283 then
			local v390 = v_u_283.hide
			pcall(v390)
		end
		if v_u_285 then
			local v391 = v_u_285.hide
			pcall(v391)
		end
		if v_u_248 then
			local v392 = v_u_248.hide
			pcall(v392)
		end
		if v_u_66 then
			local v393 = v_u_66.dismiss
			pcall(v393, "left")
			v_u_66 = nil
		end
		local v394 = v_u_17.hideTooltip
		if type(v394) == "function" then
			local v395 = v_u_17.hideTooltip
			pcall(v395)
		end
		if v_u_39 then
			local v396 = v_u_38
			if type(v396) == "table" then
				local v397 = v_u_38.close
				if type(v397) == "function" then
					local v398 = v_u_38.close
					pcall(v398)
				end
			end
		end
	end
	function v_u_22.refresh(p399) -- name: refresh
		-- upvalues: (copy) v_u_386, (copy) v_u_59, (ref) v_u_23, (ref) v_u_243, (ref) v_u_248, (copy) v_u_336, (ref) v_u_283, (ref) v_u_285, (ref) v_u_150, (ref) v_u_151, (ref) v_u_67, (copy) v_u_140
		if p399 == "profile" then
			v_u_386()
			v_u_59()
			if v_u_23 == "skills" then
				if v_u_243 == "perks" then
					if v_u_248 then
						local v400 = v_u_248.refresh
						pcall(v400, p399)
					end
				else
					v_u_336()
				end
			elseif v_u_23 == "skins" then
				if v_u_283 then
					local v401 = v_u_283.refresh
					pcall(v401, p399)
				end
			elseif v_u_23 == "killcards" then
				if v_u_285 then
					local v402 = v_u_285.refresh
					pcall(v402, p399)
				end
			elseif not v_u_150() then
				v_u_151()
			end
			if v_u_67 then
				v_u_140()
			end
		end
	end
	function v_u_22.destroy() -- name: destroy
		-- upvalues: (ref) v_u_146, (ref) v_u_67, (ref) v_u_283, (ref) v_u_285, (ref) v_u_248, (ref) v_u_66, (ref) v_u_38
		v_u_146 = false
		v_u_67 = false
		if v_u_283 then
			local v403 = v_u_283.destroy
			pcall(v403)
			v_u_283 = nil
		end
		if v_u_285 then
			local v404 = v_u_285.destroy
			pcall(v404)
			v_u_285 = nil
		end
		if v_u_248 then
			local v405 = v_u_248.destroy
			pcall(v405)
			v_u_248 = nil
		end
		if v_u_66 then
			local v406 = v_u_66.detach
			pcall(v406)
			v_u_66 = nil
		end
		if v_u_38 then
			local function v411()
				-- upvalues: (ref) v_u_38
				local v407 = v_u_38
				if type(v407) == "table" then
					local v408 = v_u_38.destroy
					if type(v408) == "function" then
						v_u_38.destroy()
						return
					end
					local v409 = v_u_38.Destroy
					if type(v409) == "function" then
						v_u_38:Destroy()
						return
					end
				else
					local v410 = v_u_38
					if typeof(v410) == "Instance" then
						v_u_38:Destroy()
					end
				end
			end
			pcall(v411)
		end
		v_u_38 = nil
	end
	return v_u_22
end
return v_u_1