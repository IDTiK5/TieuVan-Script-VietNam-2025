-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / HideoutWorld

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("Lighting")
local v_u_5 = {
	["name"] = "HideoutWorld",
	["order"] = 55
}
local v_u_6 = nil
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = "Menu"
local v_u_16 = 0
local v_u_17 = false
local v_u_18 = Vector3.new(0, 0, 0)
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = {}
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = {}
local v_u_29 = nil
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = {}
local v_u_33 = {}
local v_u_34 = 0
local v_u_35 = false
local v_u_36 = -1
local v_u_37 = -1
local v_u_38 = nil
local v_u_39 = nil
local v_u_40 = false
local v_u_41 = false
local v_u_42 = (-1 / 0)
local v_u_43 = {}
local function v_u_48(p44) -- name: paintBack
	-- upvalues: (copy) v_u_43
	for _, v45 in v_u_43 do
		if not v45 then
			continue
		end
		local v46 = v45.setText
		if type(v46) ~= "function" then
			continue
		end
		local v47 = v45.setText
		pcall(v47, p44 and "LEAVING..." or "BACK TO MENU")
	end
end
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = false
local v_u_54 = nil
local v_u_55 = false
local v_u_56 = nil
local v_u_57 = nil
local v_u_58 = CFrame.new(34.3, 0, 0.5) * CFrame.Angles(0, 1.5707963267948966, 0)
local v_u_59 = {
	["prop"] = nil,
	["win"] = nil,
	["row"] = nil,
	["door"] = nil
}
local v_u_60 = {
	["frame"] = nil,
	["rows"] = nil,
	["W"] = 60,
	["ICONS"] = nil,
	["rows"] = {},
	["ICONS"] = {
		["terminal"] = "trade",
		["generator"] = "settings",
		["stash_rack"] = "backpack",
		["workbench"] = "weapon",
		["med_station"] = "health",
		["shooting_range"] = "ping",
		["radio"] = "map",
		["trophy_wall"] = "star"
	}
}
local v_u_61 = {
	["touch"] = false,
	["used"] = nil,
	["headX"] = 24,
	["listW"] = 260,
	["edge"] = 24
}
local function v_u_76() -- name: touchClear
	-- upvalues: (ref) v_u_6, (ref) v_u_9
	local v62 = v_u_6
	if v62 then
		v62 = v_u_6.controllers.Input
	end
	if not v62 or v62._broken then
		v62 = nil
	end
	if v62 then
		local v63 = v62.touchRects
		if type(v63) == "function" then
			local v64 = v62.touchRects
			local v65, v66 = pcall(v64)
			if not v65 or type(v66) ~= "table" then
				return nil
			end
			local v67 = v66.leftColumn
			local v68 = v66.rightColumn
			local v69 = v66.rightCluster
			if typeof(v67) ~= "Rect" or (typeof(v68) ~= "Rect" or typeof(v69) ~= "Rect") then
				return nil
			end
			local v70 = v_u_9.uiScale()
			local v71 = v_u_9.viewport()
			if v70 <= 0 then
				return nil
			end
			local v72 = {}
			local v73 = v67.Max.X / v70
			v72.left = math.ceil(v73) + 16
			local v74 = (v71.X - v68.Min.X) / v70
			v72.right = math.ceil(v74) + 12
			local v75 = v69.Min.Y / v70
			v72.bottom = math.floor(v75) - 12
			return v72
		end
	end
	return nil
end
local function v_u_82(p77) -- name: setInputLock
	-- upvalues: (ref) v_u_40, (ref) v_u_6
	if v_u_40 ~= p77 then
		v_u_40 = p77
		local v78 = v_u_6
		if v78 then
			v78 = v_u_6.controllers.Input
		end
		if not v78 or v78._broken then
			v78 = nil
		end
		if v78 and v78.setEnabled then
			local v79 = v78.setEnabled
			pcall(v79, not p77)
		end
		local v80 = v_u_6
		if v80 then
			v80 = v_u_6.controllers.Prompts
		end
		if not v80 or v80._broken then
			v80 = nil
		end
		if v80 and v80.setEnabled then
			local v81 = v80.setEnabled
			pcall(v81, not p77)
		end
	end
end
local function v_u_87() -- name: fetchView
	-- upvalues: (ref) v_u_6, (ref) v_u_11
	local v83 = v_u_6.net.invoke
	local v84, v85 = pcall(v83, "menu.get", {
		["what"] = "hideout"
	})
	if not (v84 and v_u_11.viewOk(v85)) then
		return nil
	end
	local v86 = v85.now
	v85.offset = (tonumber(v86) or os.time()) - os.time()
	return v85
end
local function v_u_90() -- name: emptyView
	-- upvalues: (ref) v_u_10
	local v88 = {}
	for _, v89 in v_u_10.ORDER do
		v88[v89] = {
			["lvl"] = 0,
			["maxLevel"] = nil,
			["maxLevel"] = v_u_10.maxLevel(v89)
		}
	end
	return {
		["now"] = nil,
		["offset"] = 0,
		["effects"] = nil,
		["modules"] = nil,
		["trophies"] = nil,
		["offline"] = true,
		["now"] = os.time(),
		["effects"] = {},
		["modules"] = v88,
		["trophies"] = {}
	}
end
local function v_u_94(p91) -- name: removeStation
	-- upvalues: (copy) v_u_22, (ref) v_u_50
	for _, v92 in p91.fx do
		if type(v92) == "table" and v92.stop then
			local v93 = v92.stop
			pcall(v93, v92, 0.5)
		else
			if typeof(v92) ~= "Instance" then
				continue
			end
			v92:Destroy()
		end
	end
	p91.model:Destroy()
	p91.hitbox:Destroy()
	if p91.collider then
		p91.collider:Destroy()
	end
	v_u_22[p91.id] = nil
	v_u_50 = nil
end
local function v_u_104(p95, p96) -- name: makeLabel
	-- upvalues: (ref) v_u_9, (ref) v_u_10
	local v97 = Instance.new("BillboardGui")
	v97.Name = "StationLabel"
	v97.Size = UDim2.fromOffset(220, 46)
	v97.StudsOffsetWorldSpace = p96 and p96.label or Vector3.new(0, 6, 0)
	v97.LightInfluence = 0
	v97.MaxDistance = 26
	v97.AlwaysOnTop = false
	v97.ResetOnSpawn = false
	local v98 = Instance.new("TextLabel")
	v98.BackgroundTransparency = 1
	v98.Size = UDim2.new(1, 0, 0, 24)
	v98.FontFace = v_u_9.font.heading
	v98.TextSize = 20
	v98.TextColor3 = v_u_9.color.text
	v98.TextStrokeTransparency = 0.55
	v98.TextStrokeColor3 = v_u_9.color.bgDeep
	local v99 = p95.id
	local v100 = v_u_10
	if v100 then
		v100 = v_u_10.get(v99)
	end
	local v101
	if v100 then
		v101 = v100.name
	else
		v101 = string.upper(v99)
	end
	v98.Text = v101
	v98.Parent = v97
	local v102 = Instance.new("TextLabel")
	v102.BackgroundTransparency = 1
	v102.Position = UDim2.fromOffset(0, 24)
	v102.Size = UDim2.new(1, 0, 0, 18)
	v102.FontFace = v_u_9.font.mono
	v102.TextSize = 14
	local v103
	if p95.lvl > 0 then
		v103 = v_u_9.color.accent
	else
		v103 = v_u_9.color.muted
	end
	v102.TextColor3 = v103
	v102.TextStrokeTransparency = 0.6
	v102.Text = p95.lvl <= 0 and "NOT BUILT" or ("LEVEL %d / %d"):format(p95.lvl, v_u_10.maxLevel(p95.id))
	v102.Parent = v97
	v97.Adornee = p95.hitbox
	v97.Parent = p95.hitbox
	p95.label = v97
end
local function v_u_125(p105) -- name: addStationFx
	-- upvalues: (ref) v_u_6
	local v106 = v_u_6
	if v106 then
		v106 = v_u_6.controllers.Audio
	end
	if not v106 or v106._broken then
		v106 = nil
	end
	local v107 = p105.id
	for _, v108 in p105.model:GetDescendants() do
		if not v108:IsA("Attachment") or v108.Name ~= "Lamp" then
			continue
		end
		local v109 = Instance.new("SpotLight")
		v109.Face = Enum.NormalId.Bottom
		v109.Angle = 70
		v109.Range = 12
		v109.Brightness = 1.4
		v109.Color = Color3.fromHex("FFD29A")
		v109.Shadows = true
		v109.Parent = v108.Parent
		local v110 = p105.fx
		table.insert(v110, v109)
	end
	if v107 == "generator" and p105.lvl > 0 then
		local v111 = p105.model:FindFirstChild("Exhaust", true)
		if v111 and v111:IsA("Attachment") then
			local v112 = Instance.new("ParticleEmitter")
			v112.Texture = "rbxasset://textures/particles/smoke_main.dds"
			v112.Color = ColorSequence.new(Color3.fromHex("5A5E62"), Color3.fromHex("2E3033"))
			v112.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.75), NumberSequenceKeypoint.new(1, 1) })
			v112.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(1, 2.4) })
			v112.Lifetime = NumberRange.new(1.2, 2)
			v112.Rate = 6
			v112.Speed = NumberRange.new(1, 2)
			v112.SpreadAngle = Vector2.new(20, 20)
			v112.LightInfluence = 1
			v112.Parent = v111
			local v113 = p105.fx
			table.insert(v113, v112)
		end
		if v106 and v106.loop then
			local v114 = v106.loop
			local v115 = p105.hitbox
			local v116 = {
				["volume"] = nil,
				["pitch"] = 0.5,
				["roll"] = nil,
				["volume"] = p105.lvl * 0.1 + 0.55,
				["roll"] = { 6, 60 }
			}
			local v117, v118 = pcall(v114, "amb_fan", v115, v116)
			if v117 and v118 then
				local v119 = p105.fx
				table.insert(v119, v118)
				return
			end
		end
	elseif v107 == "radio" and (p105.lvl > 0 and (v106 and v106.loop)) then
		local v120 = v106.loop
		local v121 = p105.hitbox
		local v122, v123 = pcall(v120, "amb_radio", v121, {
			["volume"] = 0.4,
			["roll"] = nil,
			["roll"] = { 4, 30 }
		})
		if v122 and v123 then
			local v124 = p105.fx
			table.insert(v124, v123)
		end
	end
end
local function v_u_152(p_u_126) -- name: hangTrophies
	-- upvalues: (ref) v_u_23, (ref) v_u_6, (ref) v_u_12
	local v127 = v_u_23 and v_u_23.trophies or {}
	local v128 = v_u_23
	if v128 then
		v128 = v_u_23.effects
	end
	if v128 then
		v128 = v128.trophySlots
	end
	local v129 = v128 == nil and 0 or v128
	local v130 = tonumber(v129) or 0
	if p_u_126.lvl <= 0 or v130 <= 0 then
		return
	end
	local function v131()
		-- upvalues: (ref) v_u_6, (copy) p_u_126, (ref) v_u_23
		v_u_6.lib.HideoutTrophy.hang(p_u_126.model, v_u_23)
	end
	local v132, v133 = pcall(v131)
	if v132 then
		return
	end
	warn("[HideoutWorld] trophy wall:", v133)
	local v_u_134 = v_u_6.shared.Items
	local v135 = 0
	for _, v_u_136 in v127 do
		v135 = v135 + 1
		if v130 < v135 then
			break
		end
		local v137 = p_u_126.model:FindFirstChild("Slot_" .. v135, true)
		if not (v137 and v137:IsA("Attachment")) then
			continue
		end
		local v_u_138 = false
		local function v139()
			-- upvalues: (ref) v_u_138, (copy) v_u_134, (copy) v_u_136
			v_u_138 = v_u_134.get(v_u_136) ~= nil
		end
		pcall(v139)
		local v140 = nil
		local v_u_141
		if v_u_138 then
			local v142 = v_u_12.get
			local v143
			v143, v_u_141 = pcall(v142, "Item", v_u_136)
			if not v143 then
				v_u_141 = v140
			end
		else
			v_u_141 = v140
		end
		if v_u_141 and v_u_141:IsA("Model") then
			local v144, _, v145 = pcall(function()
				-- upvalues: (copy) v_u_141
				return v_u_141:GetBoundingBox()
			end)
			if not v144 then
				v_u_141:GetPivot()
				v145 = Vector3.new(4, 4, 4)
			end
			local v146 = v145.X
			local v147 = v145.Y
			local v148 = v145.Z
			local v_u_149 = math.max(v146, v147, v148)
			if v_u_149 > 1.1 then
				pcall(function()
					-- upvalues: (copy) v_u_141, (copy) v_u_149
					v_u_141:ScaleTo(1.1 / v_u_149)
				end)
			end
			for _, v150 in v_u_141:GetDescendants() do
				if not v150:IsA("BasePart") then
					continue
				end
				v150.Anchored = true
				v150.CanCollide = false
				v150.CanQuery = false
				v150.CanTouch = false
			end
			v_u_141:PivotTo(v137.WorldCFrame * CFrame.new(0, 0, -0.35))
			v_u_141.Parent = p_u_126.model
		else
			local v151 = Instance.new("Part")
			v151.Name = "Trophy"
			v151.Anchored = true
			v151.CanCollide = false
			v151.CanQuery = false
			v151.CanTouch = false
			v151.Size = Vector3.new(1, 0.7, 0.08)
			v151.Color = Color3.fromHex("9C7A3C")
			v151.Material = Enum.Material.Metal
			v151.CFrame = v137.WorldCFrame * CFrame.new(0, 0, -0.2)
			v151.Parent = p_u_126.model
		end
	end
end
local function v_u_153(_) -- name: openStation end
local function v_u_160() -- name: stationParams
	-- upvalues: (ref) v_u_50, (copy) v_u_22, (copy) v_u_59
	local v154 = v_u_50
	if v154 then
		return v154
	end
	local v155 = {}
	for _, v156 in v_u_22 do
		local v157 = v156.hitbox
		table.insert(v155, v157)
	end
	if v_u_59.prop then
		local v158 = v_u_59.prop.hitbox
		table.insert(v155, v158)
	end
	local v159 = RaycastParams.new()
	v159.FilterType = Enum.RaycastFilterType.Include
	v159.FilterDescendantsInstances = v155
	v_u_50 = v159
	return v159
end
local function v_u_165() -- name: shootingInLane
	-- upvalues: (copy) v_u_7, (ref) v_u_14, (ref) v_u_18
	local v161 = v_u_7.Character
	local v162
	if v161 then
		v162 = v161:GetAttribute("Weapon")
	else
		v162 = v161
	end
	if type(v162) ~= "string" or v162 == "" then
		return false
	end
	if v161 then
		v161 = v161:FindFirstChild("HumanoidRootPart")
	end
	if not (v161 and (v161:IsA("BasePart") and v_u_14)) then
		return false
	end
	local v163 = v161.Position - v_u_18
	local v164
	if v163.X < v_u_14.lane.x1 + 2 then
		v164 = v163.Z > v_u_14.lane.fenceZ1 - 6
	else
		v164 = false
	end
	return v164
end
local function v_u_199(p_u_166) -- name: buildStation
	-- upvalues: (copy) v_u_22, (copy) v_u_94, (ref) v_u_14, (ref) v_u_19, (ref) v_u_23, (ref) v_u_12, (ref) v_u_18, (ref) v_u_52, (ref) v_u_10, (ref) v_u_153, (ref) v_u_50, (copy) v_u_104, (copy) v_u_125, (copy) v_u_152, (ref) v_u_21, (copy) v_u_28, (ref) v_u_8
	local v167 = v_u_22[p_u_166]
	if v167 then
		v_u_94(v167)
	end
	local v168 = v_u_14.stations[p_u_166]
	if v168 and v_u_19 then
		local v169 = v_u_23 and v_u_23.modules
		if v169 then
			v169 = v_u_23.modules[p_u_166]
		end
		local v170
		if v169 then
			local v171 = v169.lvl
			v170 = tonumber(v171) or 0
		else
			v170 = 0
		end
		local v172 = v_u_12.get
		local v173 = p_u_166 .. "_" .. v170
		local v174, v175 = pcall(v172, "Hideout", v173)
		local v176 = v170 - 1
		while (not v174 or (typeof(v175) ~= "Instance" or not v175:IsA("Model"))) and v176 >= 0 do
			local v177 = v_u_12.get
			local v178 = p_u_166 .. "_" .. v176
			v174, v175 = pcall(v177, "Hideout", v178)
			v176 = v176 - 1
		end
		if v174 and (typeof(v175) == "Instance" and v175:IsA("Model")) then
			v175.Name = "Station_" .. p_u_166
			local v179 = CFrame.new(v_u_18) * v168.cf
			v175:PivotTo(v179)
			for _, v180 in v175:GetDescendants() do
				if v180:IsA("BasePart") then
					v180.Anchored = true
					v180.CanTouch = false
				else
					if not (v180:IsA("Script") or v180:IsA("LocalScript")) then
						continue
					end
					v180:Destroy()
				end
			end
			v175:SetAttribute("HideoutModule", p_u_166)
			v175:SetAttribute("Level", v170)
			v175.Parent = v_u_52 or v_u_19
			local v181 = v168.size or Vector3.new(6, 5, 4)
			local v182 = Instance.new("Part")
			v182.Name = "Hitbox_" .. p_u_166
			v182.Anchored = true
			v182.CanCollide = false
			v182.CanQuery = true
			v182.CanTouch = false
			v182.CastShadow = false
			v182.Transparency = 1
			v182.Size = v181
			v182.CFrame = v179 * CFrame.new(0, v181.Y / 2, 0)
			v182:SetAttribute("HideoutModule", p_u_166)
			v182.Parent = v_u_52 or v_u_19
			local v183 = {
				["id"] = nil,
				["lvl"] = nil,
				["model"] = nil,
				["hitbox"] = nil,
				["collider"] = nil,
				["prompt"] = nil,
				["label"] = nil,
				["fx"] = nil,
				["id"] = p_u_166,
				["lvl"] = v170,
				["model"] = v175,
				["hitbox"] = v182,
				["fx"] = {}
			}
			if p_u_166 ~= "trophy_wall" and p_u_166 ~= "shooting_range" then
				local v184 = Instance.new("Part")
				v184.Name = "Collider_" .. p_u_166
				v184.Anchored = true
				v184.CanCollide = true
				v184.CanQuery = false
				v184.CanTouch = false
				v184.Transparency = 1
				local v185 = v181.X * 0.92
				local v186 = v181.Y
				local v187 = math.min(v186, 4.5)
				local v188 = v181.Z * 0.8
				v184.Size = Vector3.new(v185, v187, v188)
				v184.CFrame = v179 * CFrame.new(0, v184.Size.Y / 2, 0)
				v184.Parent = v_u_52 or v_u_19
				v183.collider = v184
			end
			local v189 = Instance.new("Attachment")
			v189.Name = "PromptAt"
			local v190 = v181.Y / 2
			local v191 = math.min(v190, 2) - v181.Y / 2 + 2
			local v192 = -v181.Z / 2
			v189.Position = Vector3.new(0, v191, v192)
			v189.Parent = v182
			local v193 = Instance.new("ProximityPrompt")
			v193.Name = "HideoutPrompt"
			v193.Style = Enum.ProximityPromptStyle.Custom
			v193.ActionText = v170 > 0 and "Open" or "Build"
			local v194 = v_u_10
			if v194 then
				v194 = v_u_10.get(p_u_166)
			end
			local v195
			if v194 then
				v195 = v194.name
			else
				v195 = string.upper(p_u_166)
			end
			v193.ObjectText = v195
			v193.MaxActivationDistance = 9
			v193.RequiresLineOfSight = false
			v193.HoldDuration = 0
			v193:SetAttribute("Priority", 5)
			v193.Triggered:Connect(function()
				-- upvalues: (ref) v_u_153, (copy) p_u_166
				v_u_153(p_u_166)
			end)
			v193.Parent = v189
			v183.prompt = v193
			v_u_22[p_u_166] = v183
			v_u_50 = nil
			v_u_104(v183, v168)
			v_u_125(v183)
			if p_u_166 == "trophy_wall" then
				v_u_152(v183)
			end
			if p_u_166 == "shooting_range" and v_u_21 then
				local v196 = v175:FindFirstChild("HitMap", true)
				local v197 = v_u_21.setHitMap
				if not (v196 and v196:IsA("BasePart")) then
					v196 = nil
				end
				v197(v196)
			end
			local v198 = v_u_28[p_u_166]
			if v198 then
				v_u_8.setText(v198.lvl, v170 <= 0 and "NOT BUILT" or ("LVL %d"):format(v170))
			end
		end
	else
		return
	end
end
local function v_u_200(_) -- name: openTerminal end
local function v_u_228() -- name: buildTerminal
	-- upvalues: (copy) v_u_59, (ref) v_u_19, (ref) v_u_18, (copy) v_u_58, (ref) v_u_6, (ref) v_u_52, (ref) v_u_200, (ref) v_u_9, (ref) v_u_50
	local v201 = v_u_59.prop
	if v201 then
		v201.model:Destroy()
		v201.hitbox:Destroy()
		v201.collider:Destroy()
		v_u_59.prop = nil
	end
	if v_u_19 then
		local v202 = CFrame.new(v_u_18) * v_u_58
		local v203 = v_u_6.lib.HideoutTerminal.buildProp
		local v204 = v_u_52 or v_u_19
		local v205, v206, v207 = pcall(v203, v204, v202)
		if v205 and typeof(v206) == "Instance" then
			local v208 = typeof(v207) ~= "Vector3" and Vector3.new(5.4, 4.4, 3) or v207
			v206:SetAttribute("HideoutModule", "terminal")
			local v209 = Instance.new("Part")
			v209.Name = "Hitbox_terminal"
			v209.Anchored = true
			v209.CanCollide = false
			v209.CanQuery = true
			v209.CanTouch = false
			v209.CastShadow = false
			v209.Transparency = 1
			v209.Size = v208
			v209.CFrame = v202 * CFrame.new(0, v208.Y / 2, 0.2)
			v209:SetAttribute("HideoutModule", "terminal")
			v209.Parent = v_u_52 or v_u_19
			local v210 = Instance.new("Part")
			v210.Name = "Collider_terminal"
			v210.Anchored = true
			v210.CanCollide = true
			v210.CanQuery = false
			v210.CanTouch = false
			v210.Transparency = 1
			local v211 = v208.X * 0.92
			local v212 = v208.Y
			local v213 = math.min(v212, 4.5)
			local v214 = v208.Z * 0.8
			v210.Size = Vector3.new(v211, v213, v214)
			v210.CFrame = v202 * CFrame.new(0, v210.Size.Y / 2, 0.3)
			v210.Parent = v_u_52 or v_u_19
			local v215 = Instance.new("Attachment")
			v215.Name = "PromptAt"
			local v216 = 2 - v208.Y / 2
			local v217 = -v208.Z / 2
			v215.Position = Vector3.new(0, v216, v217)
			v215.Parent = v209
			local v218 = Instance.new("ProximityPrompt")
			v218.Name = "HideoutPrompt"
			v218.Style = Enum.ProximityPromptStyle.Custom
			local function v219()
				-- upvalues: (ref) v_u_6
				return v_u_6.shared.GameMode.rule("clans") == true
			end
			local v220, v221 = pcall(v219)
			if v220 then
				v220 = v221 == true
			end
			v218.ActionText = v220 and "Traders, tasks & clan" or "Traders & tasks"
			v218.ObjectText = "Terminal"
			v218.MaxActivationDistance = 9
			v218.RequiresLineOfSight = false
			v218.HoldDuration = 0
			v218:SetAttribute("Priority", 5)
			v218.Triggered:Connect(function()
				-- upvalues: (ref) v_u_200
				v_u_200(nil)
			end)
			v218.Parent = v215
			local v222 = Instance.new("BillboardGui")
			v222.Name = "StationLabel"
			v222.Size = UDim2.fromOffset(220, 46)
			v222.StudsOffsetWorldSpace = Vector3.new(0, 6.5, 0)
			v222.LightInfluence = 0
			v222.MaxDistance = 26
			v222.AlwaysOnTop = false
			v222.ResetOnSpawn = false
			local v223 = Instance.new("TextLabel")
			v223.BackgroundTransparency = 1
			v223.Size = UDim2.new(1, 0, 0, 24)
			v223.FontFace = v_u_9.font.heading
			v223.TextSize = 20
			v223.TextColor3 = v_u_9.color.text
			v223.TextStrokeTransparency = 0.55
			v223.TextStrokeColor3 = v_u_9.color.bgDeep
			v223.Text = "TERMINAL"
			v223.Parent = v222
			local v224 = Instance.new("TextLabel")
			v224.BackgroundTransparency = 1
			v224.Position = UDim2.fromOffset(0, 24)
			v224.Size = UDim2.new(1, 0, 0, 18)
			v224.FontFace = v_u_9.font.mono
			v224.TextSize = 14
			v224.TextColor3 = v_u_9.color.accent
			v224.TextStrokeTransparency = 0.6
			local function v225()
				-- upvalues: (ref) v_u_6
				return v_u_6.shared.GameMode.rule("clans") == true
			end
			local v226, v227 = pcall(v225)
			if v226 then
				v226 = v227 == true
			end
			v224.Text = v226 and "TRADERS  /  TASKS  /  CLAN" or "TRADERS  /  TASKS"
			v224.Parent = v222
			v222.Adornee = v209
			v222.Parent = v209
			v_u_59.prop = {
				["model"] = v206,
				["hitbox"] = v209,
				["collider"] = v210,
				["prompt"] = v218
			}
			v_u_50 = nil
		else
			warn("[HideoutWorld] terminal prop failed:", v206)
		end
	else
		return
	end
end
local function v_u_234(p229) -- name: stationStatus
	-- upvalues: (ref) v_u_23, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8
	local v230 = v_u_23 and v_u_23.modules
	if v230 then
		v230 = v_u_23.modules[p229]
	end
	if v230 then
		local v231 = os.time() + (v_u_23 and v_u_23.offset or 0)
		local v232, v233 = v_u_11.listState(v230, v231)
		if v232 == "building" then
			return v_u_8.clock(v233 or 0), v_u_9.color.accent
		elseif v232 == "ready" then
			return v_u_11.LIST_WORD.ready, v_u_9.color.success
		elseif v232 == "crafting" then
			return v_u_8.clock(v233 or 0), v_u_9.color.info
		elseif v232 == "build" or v232 == "upgrade" then
			return v_u_11.LIST_WORD[v232], v_u_9.color.success
		else
			return "", v_u_9.color.muted
		end
	else
		return "", v_u_9.color.muted
	end
end
local function v_u_253(p235, p236) -- name: paintLevel
	-- upvalues: (ref) v_u_23, (copy) v_u_234, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9
	local v237 = v_u_23 and v_u_23.modules
	if v237 then
		v237 = v_u_23.modules[p236]
	end
	local v238
	if v237 then
		local v239 = v237.lvl
		v238 = tonumber(v239) or 0
	else
		v238 = 0
	end
	local v240, v241 = v_u_234(p236)
	local v242
	if v_u_23 == nil then
		v242 = false
	else
		v242 = v_u_23.offline == true
	end
	local v243 = v238 <= 0 and v240 == "" and true or v242
	local v244 = v_u_8.setText
	local v245 = p235.lvl
	local v246
	if v242 then
		v246 = v_u_11.LOAD_CHIP
	elseif v238 > 0 then
		v246 = ("LVL %d"):format(v238)
	else
		v246 = v243 and "NOT BUILT" or ""
	end
	v244(v245, v246)
	local v247 = p235.lvl
	local v248
	if v238 > 0 then
		v248 = v_u_9.color.text2
	else
		v248 = v_u_9.color.muted
	end
	v247.TextColor3 = v248
	local v249 = p235.lvl
	local v250
	if v243 then
		v250 = UDim2.new(0.44, -6, 1, 0)
	else
		v250 = UDim2.new(0.18, 0, 1, 0)
	end
	v249.Size = v250
	local v251 = p235.lvl
	local v252
	if v243 then
		v252 = Enum.TextXAlignment.Right
	else
		v252 = Enum.TextXAlignment.Left
	end
	v251.TextXAlignment = v252
	v_u_8.setText(p235.status, v240)
	p235.status.TextColor3 = v241
end
local function v_u_254() -- name: leave end
local function v_u_270() -- name: syncChrome
	-- upvalues: (ref) v_u_25, (ref) v_u_57, (copy) v_u_59, (copy) v_u_28, (ref) v_u_53, (ref) v_u_9, (copy) v_u_60, (ref) v_u_54, (ref) v_u_56, (ref) v_u_55
	local v255
	if v_u_25 and v_u_25.isOpen() then
		v255 = v_u_25.module()
	else
		v255 = nil
	end
	v_u_57 = v255
	local v256
	if v_u_59.win == nil then
		v256 = false
	else
		v256 = v_u_59.win.isOpen()
	end
	local v257 = v255 ~= nil and true or v256
	for v258, v259 in v_u_28 do
		local v260 = v258 == v255
		v259.mark.Visible = v260
		v259.button.BackgroundTransparency = v260 and 0.3 or 1
		v259.button.Selectable = not v257
	end
	local v261 = v_u_59.row
	if v261 then
		v261.mark.Visible = v256
		v261.button.BackgroundTransparency = v256 and 0.3 or 1
		v261.button.Selectable = not v257
	end
	local v262 = not v_u_53
	if v262 then
		if v255 == nil or v_u_9.refSize().X >= 1600 then
			v262 = false
		else
			v262 = v_u_60.frame ~= nil
		end
	end
	local v263 = v_u_60.frame
	if v263 then
		v263.Visible = v262
		for v264, v265 in v_u_60.rows do
			local v266
			if v264 == v255 then
				v266 = true
			elseif v264 == "terminal" then
				v266 = v256
			else
				v266 = false
			end
			v265.mark.Visible = v266
			v265.button.BackgroundTransparency = v266 and 0.3 or 1
			v265.button.Selectable = false
		end
	end
	if not v_u_53 and v_u_54 then
		v_u_54.Visible = not v262
	end
	local v267 = v_u_56
	if v267 then
		local v268 = v_u_53
		if v268 then
			v268 = v255 ~= nil
		end
		v267.Visible = not v268
	end
	if v_u_53 and (v255 ~= nil and v_u_55) then
		v_u_55 = false
		local v269 = v_u_54
		if v269 then
			v269.Visible = not v_u_53
		end
	end
end
local function v_u_285(p271, p_u_272, p273, p274) -- name: stationRow
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_57, (ref) v_u_10, (ref) v_u_53, (ref) v_u_55, (ref) v_u_54, (ref) v_u_153, (copy) v_u_28
	local v_u_275 = Instance.new("TextButton")
	v_u_275.Name = p_u_272
	v_u_275.AutoButtonColor = false
	v_u_275.Text = ""
	v_u_275.BackgroundColor3 = v_u_9.color.raised
	v_u_275.BackgroundTransparency = 1
	v_u_275.BorderSizePixel = 0
	v_u_275.Size = UDim2.new(1, 0, 0, p274)
	v_u_275.LayoutOrder = p273 + 10
	local function v276()
		-- upvalues: (copy) v_u_275, (ref) v_u_8
		v_u_275.SelectionImageObject = v_u_8.selectionImage()
	end
	pcall(v276)
	local v277 = Instance.new("Frame")
	v277.Name = "Open"
	v277.BorderSizePixel = 0
	v277.BackgroundColor3 = v_u_9.color.accent
	v277.Size = UDim2.new(0, 2, 1, -8)
	v277.Position = UDim2.fromOffset(0, 4)
	v277.Visible = v_u_57 == p_u_272
	v277.Parent = v_u_275
	if v_u_57 == p_u_272 then
		v_u_275.BackgroundTransparency = 0.3
	end
	local v278 = v_u_8.label
	local v279 = {
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_275
	}
	local v280 = v_u_10
	if v280 then
		v280 = v_u_10.get(p_u_272)
	end
	local v281
	if v280 then
		v281 = v280.name
	else
		v281 = string.upper(p_u_272)
	end
	v279.text = v281
	v279.size = UDim2.new(0.56, -8, 1, 0)
	v279.position = UDim2.fromOffset(8, 0)
	v278(v279)
	local v282 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Lvl",
		["text"] = "-",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["track"] = false,
		["parent"] = v_u_275,
		["color"] = v_u_9.color.text2,
		["size"] = UDim2.new(0.18, 0, 1, 0),
		["position"] = UDim2.fromScale(0.56, 0)
	})
	local v283 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["align"] = "right",
		["track"] = false,
		["parent"] = v_u_275,
		["color"] = v_u_9.color.accent,
		["size"] = UDim2.new(0.26, -6, 1, 0),
		["position"] = UDim2.fromScale(0.74, 0)
	})
	v_u_275.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_275, (ref) v_u_8
		v_u_275.BackgroundTransparency = 0.3
		v_u_8.sound("hover")
	end)
	v_u_275.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_275, (ref) v_u_57, (copy) p_u_272
		v_u_275.BackgroundTransparency = v_u_57 == p_u_272 and 0.3 or 1
	end)
	v_u_275.Activated:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_53, (ref) v_u_55, (ref) v_u_54, (ref) v_u_153, (copy) p_u_272
		v_u_8.sound("click")
		if v_u_53 then
			v_u_55 = false
			local v284 = v_u_54
			if v284 then
				v284.Visible = not v_u_53
			end
		end
		v_u_153(p_u_272)
	end)
	v_u_275.Parent = p271
	v_u_28[p_u_272] = {
		["lvl"] = v282,
		["status"] = v283,
		["button"] = v_u_275,
		["mark"] = v277
	}
end
local function v_u_297(p286, p287) -- name: terminalRow
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_6, (copy) v_u_59, (ref) v_u_53, (ref) v_u_55, (ref) v_u_54, (ref) v_u_200
	local v_u_288 = Instance.new("TextButton")
	v_u_288.Name = "terminal"
	v_u_288.AutoButtonColor = false
	v_u_288.Text = ""
	v_u_288.BackgroundColor3 = v_u_9.color.raised
	v_u_288.BackgroundTransparency = 1
	v_u_288.BorderSizePixel = 0
	v_u_288.Size = UDim2.new(1, 0, 0, p287)
	v_u_288.LayoutOrder = 5
	local function v289()
		-- upvalues: (copy) v_u_288, (ref) v_u_8
		v_u_288.SelectionImageObject = v_u_8.selectionImage()
	end
	pcall(v289)
	local v290 = Instance.new("Frame")
	v290.Name = "Open"
	v290.BorderSizePixel = 0
	v290.BackgroundColor3 = v_u_9.color.accent
	v290.Size = UDim2.new(0, 2, 1, -8)
	v290.Position = UDim2.fromOffset(0, 4)
	v290.Visible = false
	v290.Parent = v_u_288
	v_u_8.icon("trade", {
		["parent"] = nil,
		["size"] = 16,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v_u_288,
		["color"] = v_u_9.color.accent,
		["position"] = UDim2.new(0, 6, 0.5, 0),
		["anchor"] = Vector2.new(0, 0.5)
	}).Name = "Icon"
	local v291 = v_u_8.label
	local v292 = {
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_288
	}
	local function v293()
		-- upvalues: (ref) v_u_6
		return v_u_6.shared.GameMode.rule("clans") == true
	end
	local v294, v295 = pcall(v293)
	if v294 then
		v294 = v295 == true
	end
	v292.text = v294 and "TRADERS, TASKS & CLAN" or "TRADERS & TASKS"
	v292.color = v_u_9.color.text
	v292.size = UDim2.new(0.74, -30, 1, 0)
	v292.position = UDim2.fromOffset(30, 0)
	v291(v292)
	v_u_8.label({
		["parent"] = nil,
		["text"] = "TERMINAL",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["align"] = "right",
		["track"] = false,
		["fit"] = true,
		["parent"] = v_u_288,
		["color"] = v_u_9.color.text2,
		["size"] = UDim2.new(0.26, -6, 1, 0),
		["position"] = UDim2.fromScale(0.74, 0)
	})
	v_u_288.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_288, (ref) v_u_8
		v_u_288.BackgroundTransparency = 0.3
		v_u_8.sound("hover")
	end)
	v_u_288.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_288, (ref) v_u_59
		v_u_288.BackgroundTransparency = v_u_59.win and v_u_59.win.isOpen() and 0.3 or 1
	end)
	v_u_288.Activated:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_53, (ref) v_u_55, (ref) v_u_54, (ref) v_u_200
		v_u_8.sound("click")
		if v_u_53 then
			v_u_55 = false
			local v296 = v_u_54
			if v296 then
				v296.Visible = not v_u_53
			end
		end
		v_u_200(nil)
	end)
	v_u_288.Parent = p286
	v_u_59.row = {
		["button"] = v_u_288,
		["mark"] = v290
	}
end
local function v_u_331(p298, p299, p300) -- name: buildRail
	-- upvalues: (copy) v_u_60, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_23, (ref) v_u_6, (ref) v_u_57, (ref) v_u_200, (ref) v_u_153
	table.clear(v_u_60.rows)
	v_u_60.W = (not p300 and 44 or v_u_9.touch(44)) + 16
	local v301, v302 = v_u_8.panel({
		["parent"] = nil,
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["autoY"] = true,
		["padding"] = 8,
		["gap"] = 4,
		["layout"] = "v",
		["transparency"] = 0.25,
		["parent"] = p298,
		["size"] = UDim2.fromOffset(v_u_60.W, 0),
		["position"] = UDim2.new(1, -24, 0, p299 + 16),
		["anchor"] = Vector2.new(1, 0)
	})
	v301.Name = "StationRail"
	v301.Visible = false
	local v303 = { "terminal" }
	for _, v304 in v_u_10.ORDER do
		table.insert(v303, v304)
	end
	for v305, v_u_306 in v303 do
		local v_u_307 = Instance.new("TextButton")
		v_u_307.Name = v_u_306
		v_u_307.AutoButtonColor = false
		v_u_307.Text = ""
		v_u_307.BackgroundColor3 = v_u_9.color.raised
		v_u_307.BackgroundTransparency = 1
		v_u_307.BorderSizePixel = 0
		v_u_307.Size = UDim2.fromOffset(v_u_60.W - 16, v_u_9.touch(40))
		v_u_307.LayoutOrder = v305
		v_u_307.Selectable = false
		local v308 = Instance.new("Frame")
		v308.Name = "Open"
		v308.BorderSizePixel = 0
		v308.BackgroundColor3 = v_u_9.color.accent
		v308.Size = UDim2.new(0, 2, 1, -8)
		v308.Position = UDim2.fromOffset(0, 4)
		v308.Visible = false
		v308.Parent = v_u_307
		local v309
		if v_u_306 == "terminal" then
			v309 = 1
		else
			local v310 = v_u_23 and v_u_23.modules
			if v310 then
				v310 = v_u_23.modules[v_u_306]
			end
			if v310 then
				local v311 = v310.lvl
				v309 = tonumber(v311) or 0
			else
				v309 = 0
			end
		end
		local v312 = v_u_8.icon
		local v313 = v_u_60.ICONS[v_u_306] or "hideout"
		local v314 = {
			["parent"] = nil,
			["size"] = 18,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v_u_307
		}
		local v315
		if v_u_306 == "terminal" then
			v315 = v_u_9.color.accent
		elseif v309 > 0 then
			v315 = v_u_9.color.text
		else
			v315 = v_u_9.color.muted
		end
		v314.color = v315
		v314.position = UDim2.fromScale(0.5, 0.5)
		v314.anchor = Vector2.new(0.5, 0.5)
		v312(v313, v314).Name = "Icon"
		v_u_8.tooltip(v_u_307, function()
			-- upvalues: (copy) v_u_306, (ref) v_u_6, (ref) v_u_23, (ref) v_u_10
			if v_u_306 == "terminal" then
				local v316 = {}
				local function v317()
					-- upvalues: (ref) v_u_6
					return v_u_6.shared.GameMode.rule("clans") == true
				end
				local v318, v319 = pcall(v317)
				if v318 then
					v318 = v319 == true
				end
				v316.title = v318 and "TRADERS, TASKS & CLAN" or "TRADERS & TASKS"
				local function v320()
					-- upvalues: (ref) v_u_6
					return v_u_6.shared.GameMode.rule("clans") == true
				end
				local v321, v322 = pcall(v320)
				if v321 then
					v321 = v322 == true
				end
				v316.body = v321 and "The terminal: buy, sell, hand in tasks, and your clan." or "The terminal: buy, sell, hand in tasks."
				return v316
			end
			local v323 = v_u_306
			local v324 = v_u_23 and v_u_23.modules
			if v324 then
				v324 = v_u_23.modules[v323]
			end
			local v325
			if v324 then
				local v326 = v324.lvl
				v325 = tonumber(v326) or 0
			else
				v325 = 0
			end
			local v327 = {}
			local v328 = v_u_306
			local v329 = v_u_10
			if v329 then
				v329 = v_u_10.get(v328)
			end
			local v330
			if v329 then
				v330 = v329.name
			else
				v330 = string.upper(v328)
			end
			v327.title = v330
			v327.body = v325 <= 0 and "Not built" or ("Level %d"):format(v325)
			return v327
		end)
		v_u_307.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_307, (ref) v_u_8
			v_u_307.BackgroundTransparency = 0.3
			v_u_8.sound("hover")
		end)
		v_u_307.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_307, (ref) v_u_57, (copy) v_u_306
			v_u_307.BackgroundTransparency = v_u_57 == v_u_306 and 0.3 or 1
		end)
		v_u_307.Activated:Connect(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_306, (ref) v_u_200, (ref) v_u_153
			v_u_8.sound("click")
			if v_u_306 == "terminal" then
				v_u_200(nil)
			else
				v_u_153(v_u_306)
			end
		end)
		v_u_307.Parent = v302
		v_u_60.rows[v_u_306] = {
			["button"] = v_u_307,
			["mark"] = v308
		}
	end
	v_u_60.frame = v301
end
local function v_u_390() -- name: buildScreen
	-- upvalues: (ref) v_u_26, (copy) v_u_28, (copy) v_u_59, (ref) v_u_54, (copy) v_u_60, (ref) v_u_55, (ref) v_u_56, (copy) v_u_61, (ref) v_u_8, (ref) v_u_9, (ref) v_u_27, (ref) v_u_53, (ref) v_u_6, (ref) v_u_254, (copy) v_u_43, (ref) v_u_10, (copy) v_u_297, (copy) v_u_285, (copy) v_u_76, (copy) v_u_331, (ref) v_u_29, (copy) v_u_253, (copy) v_u_270
	if v_u_26 then
		v_u_26:Destroy()
	end
	table.clear(v_u_28)
	v_u_59.row = nil
	v_u_54 = nil
	v_u_60.frame = nil
	v_u_55 = false
	v_u_56 = nil
	local v332 = v_u_61
	local v333 = v_u_61
	local v334 = v_u_61
	local v335 = v_u_61
	v_u_61.touch = false
	v332.used = nil
	v333.headX = 24
	v334.listW = 260
	v335.edge = 24
	local v336, v337 = v_u_8.screen("HushHideout", v_u_9.layer.hud)
	v_u_26 = v336
	v_u_27 = v337
	local v338 = v_u_8.topInset()
	v_u_53 = v_u_6.lib.HideoutPanel.compact(v_u_9)
	local v339 = v_u_9.isPhone and v_u_9.isPhone() or v_u_8.device() == "Touch"
	local v340 = not v339 and 28 or v_u_9.touch(30)
	local v341 = v_u_9.touch(40)
	if v_u_53 then
		local v342 = Instance.new("Frame")
		v342.Name = "Head"
		v342.BackgroundTransparency = 1
		v342.AnchorPoint = Vector2.new(0.5, 0)
		v342.Position = UDim2.new(0.5, 0, 0, v338 + 4)
		v342.Size = UDim2.fromOffset(0, v341)
		v342.AutomaticSize = Enum.AutomaticSize.X
		v342:SetAttribute("HushPointerZone", true)
		v342.Parent = v337
		v_u_56 = v342
		v_u_8.layout(v342, "h", 10).VerticalAlignment = Enum.VerticalAlignment.Center
		local v343 = v339 and 176 or 208
		v_u_8.label({
			["parent"] = nil,
			["text"] = "HIDEOUT",
			["style"] = "h3",
			["size"] = nil,
			["order"] = 1,
			["parent"] = v342,
			["size"] = UDim2.fromOffset(104, v341)
		})
		local v344, v345 = v_u_8.button({
			["parent"] = nil,
			["text"] = "BACK TO MENU",
			["kind"] = "secondary",
			["hint"] = nil,
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v342,
			["hint"] = not v339 and "menu" or nil,
			["size"] = UDim2.fromOffset(v343, v341),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_254
				v_u_254()
			end
		})
		v344.LayoutOrder = 2
		local v346 = v_u_43
		table.insert(v346, v345)
		v_u_8.button({
			["parent"] = nil,
			["text"] = "STATIONS",
			["kind"] = "secondary",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v342,
			["size"] = UDim2.fromOffset(150, v341),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_55, (ref) v_u_54, (ref) v_u_53
				local v347 = not v_u_55
				v_u_55 = v347
				local v348 = v_u_54
				if v348 then
					v348.Visible = v347 or not v_u_53
				end
			end
		}).LayoutOrder = 3
		local v349 = v338 + 4 + v341 + 8
		local v350 = v340 * 3
		local v351 = v_u_9.refSize().Y - v349 - 12
		local v352 = math.max(v350, v351)
		local v353 = 24 + (#v_u_10.ORDER + 1) * (v340 + 2)
		local v354 = v343 + 114 + 10 + 150
		local v355 = v_u_8.panel
		local v356 = {
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["padding"] = 12,
			["transparency"] = 0.1,
			["parent"] = v337,
			["size"] = UDim2.fromOffset(300, (math.min(v353, v352)))
		}
		local v357 = UDim2.new
		local v358 = v354 / 2
		v356.position = v357(0.5, math.floor(v358), 0, v349)
		v356.anchor = Vector2.new(1, 0)
		local v359, v360 = v355(v356)
		v359.Name = "Stations"
		v359.Visible = false
		local v361 = v_u_8.list({
			["parent"] = nil,
			["gap"] = 2,
			["parent"] = v360
		})
		v_u_297(v361, v340)
		for v362, v363 in v_u_10.ORDER do
			v_u_285(v361, v363, v362, v340)
		end
		v_u_54 = v359
	else
		local v364
		if v339 then
			v364 = v_u_76()
		else
			v364 = nil
		end
		local v365 = #v_u_10.ORDER + 1
		local v366
		if v364 == nil then
			v366 = false
		else
			v366 = v338 + 16 + 44 + 24 + v365 * v340 + (v365 - 1) * 2 > v364.bottom
		end
		v_u_61.touch = v339
		v_u_61.used = v364
		local v367 = v_u_61
		local v368
		if v364 then
			local v369 = v364.left
			v368 = math.max(24, v369)
		else
			v368 = 24
		end
		v367.headX = v368
		local v370 = v_u_61
		local v371
		if v364 then
			local v372 = v364.right
			v371 = math.max(112, v372)
		else
			v371 = v339 and 112 or 24
		end
		v370.edge = v371
		v_u_61.listW = v366 and 500 or 260
		local v373 = Instance.new("Frame")
		v373.Name = "Head"
		v373.BackgroundTransparency = 1
		v373.Position = UDim2.fromOffset(v_u_61.headX, v338 + 16)
		v373.Size = UDim2.fromOffset(340, 120)
		v373:SetAttribute("HushPointerZone", true)
		v373.Parent = v337
		v_u_8.label({
			["parent"] = nil,
			["text"] = "HIDEOUT",
			["style"] = "h1",
			["size"] = nil,
			["parent"] = v373,
			["size"] = UDim2.new(1, 0, 0, 38)
		})
		v_u_8.label({
			["parent"] = nil,
			["text"] = "BASEMENT  /  GAS STATION ON ROUTE 9",
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v373,
			["color"] = v_u_9.color.text2,
			["position"] = UDim2.fromOffset(0, 38),
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		v_u_8.divider({
			["parent"] = v373,
			["position"] = UDim2.fromOffset(0, 60),
			["size"] = UDim2.fromOffset(48, 2),
			["color"] = v_u_9.color.accent
		})
		local _, v374 = v_u_8.button({
			["parent"] = nil,
			["text"] = "BACK TO MENU",
			["kind"] = "secondary",
			["hint"] = nil,
			["size"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v373,
			["hint"] = not v339 and "menu" or nil,
			["size"] = UDim2.fromOffset(240, v341),
			["position"] = UDim2.fromOffset(0, v339 and 58 or 72),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_254
				v_u_254()
			end
		})
		local v375 = v_u_43
		table.insert(v375, v374)
		local v376, v377 = v_u_8.panel({
			["parent"] = nil,
			["title"] = "STATIONS",
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["autoY"] = true,
			["padding"] = 12,
			["gap"] = 2,
			["layout"] = nil,
			["transparency"] = 0.25,
			["parent"] = v337,
			["size"] = UDim2.fromOffset(v_u_61.listW, 0),
			["position"] = UDim2.new(1, -v_u_61.edge, 0, v338 + 16),
			["anchor"] = Vector2.new(1, 0),
			["layout"] = not v366 and "v" or nil
		})
		v376.Name = "Stations"
		if v366 then
			local v378 = Instance.new("UIGridLayout")
			v378.CellSize = UDim2.fromOffset(236, v340)
			v378.CellPadding = UDim2.fromOffset(4, 2)
			v378.FillDirection = Enum.FillDirection.Horizontal
			v378.SortOrder = Enum.SortOrder.LayoutOrder
			v378.Parent = v377
		end
		v_u_297(v377, v340)
		for v379, v380 in v_u_10.ORDER do
			v_u_285(v377, v380, v379, v340)
		end
		v_u_54 = v376
		v_u_331(v337, v338, v339)
	end
	local v381 = v_u_8.panel
	local v382 = {
		["parent"] = nil,
		["title"] = nil,
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["autoY"] = true,
		["padding"] = nil,
		["gap"] = nil,
		["layout"] = "v",
		["accent"] = true,
		["transparency"] = 0.25,
		["parent"] = v337,
		["title"] = not v_u_53 and "RANGE" or nil,
		["size"] = UDim2.fromOffset(v_u_53 and 440 or 300, 0)
	}
	local v383
	if v_u_53 then
		v383 = UDim2.new(0.5, 0, 0, v338 + 4 + v341 + 8)
	else
		v383 = UDim2.new(1, -24, 1, -24)
	end
	v382.position = v383
	local v384
	if v_u_53 then
		v384 = Vector2.new(0.5, 0)
	else
		v384 = Vector2.new(1, 1)
	end
	v382.anchor = v384
	v382.padding = v_u_53 and 8 or 12
	v382.gap = v_u_53 and 2 or 4
	local v385, v386 = v381(v382)
	v385.Name = "RangeHud"
	v385.Visible = false
	local v387 = {
		["parent"] = nil,
		["text"] = "",
		["style"] = nil,
		["order"] = 2,
		["track"] = false,
		["parent"] = v386,
		["style"] = v_u_53 and "small" or "bodyStrong"
	}
	v_u_29 = {
		["frame"] = v385,
		["weapon"] = v_u_8.label(v387),
		["ammo"] = v_u_8.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = nil,
			["color"] = nil,
			["order"] = 3,
			["track"] = false,
			["parent"] = v386,
			["style"] = v_u_53 and "mono" or "monoL",
			["color"] = v_u_9.color.text
		}),
		["stats"] = v_u_8.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["order"] = 4,
			["track"] = false,
			["parent"] = v386,
			["color"] = v_u_9.color.text2
		})
	}
	for v388, v389 in v_u_28 do
		v_u_253(v389, v388)
	end
	v_u_270()
end
local function v_u_412() -- name: updateRangeHud
	-- upvalues: (ref) v_u_29, (copy) v_u_7, (ref) v_u_21, (ref) v_u_23, (ref) v_u_18, (ref) v_u_14, (ref) v_u_53, (ref) v_u_55, (ref) v_u_57, (ref) v_u_8, (ref) v_u_6
	local v391 = v_u_29
	if v391 then
		local v392 = v_u_7.Character
		if v392 then
			v392 = v392:FindFirstChild("HumanoidRootPart")
		end
		if not (v392 and v392:IsA("BasePart")) then
			v392 = nil
		end
		local v393 = false
		if v392 and v_u_21 then
			local v394 = v_u_23 and v_u_23.modules
			if v394 then
				v394 = v_u_23.modules.shooting_range
			end
			local v395
			if v394 then
				local v396 = v394.lvl
				v395 = tonumber(v396) or 0
			else
				v395 = 0
			end
			if v395 > 0 then
				local v397 = v392.Position - v_u_18
				if v397.X < v_u_14.lane.x1 + 2 then
					v393 = v397.Z > v_u_14.lane.fenceZ1 - 4
				else
					v393 = false
				end
			end
		end
		local v398 = v391.frame
		local v399
		if v393 then
			local v400 = v_u_53
			if v400 then
				v400 = v_u_55 or v_u_57 ~= nil
			end
			v399 = not v400
		else
			v399 = v393
		end
		v398.Visible = v399
		if v393 then
			local v401 = v_u_7.Character
			local v402
			if v401 then
				v402 = v401:GetAttribute("WeaponName")
			else
				v402 = v401
			end
			local v403
			if v401 then
				v403 = v401:GetAttribute("Weapon")
			else
				v403 = v401
			end
			if type(v402) ~= "string" or v402 == "" then
				if type(v403) == "string" and v403 ~= "" then
					v402 = string.upper(v403)
				else
					v402 = nil
				end
			end
			if v402 then
				v_u_8.setText(v391.weapon, v402)
				local v404
				if v401 then
					v404 = v401:GetAttribute("Ammo")
				else
					v404 = v401
				end
				local v405
				if v401 then
					v405 = v401:GetAttribute("MagSize")
				else
					v405 = v401
				end
				if v401 then
					v401 = v401:GetAttribute("AmmoReserve")
				end
				v_u_8.setText(v391.ammo, ("%s / %s   +%s"):format(tostring(v404 or "-"), tostring(v405 or "-"), (tostring(v401 or 0))))
			else
				local v406 = v_u_6
				if v406 then
					v406 = v_u_6.controllers.Input
				end
				if not v406 or v406._broken then
					v406 = nil
				end
				local v407
				if v406 and v406.hint then
					local v408 = v406.hint
					local v409, v410 = pcall(v408, "swap")
					v407 = (not v409 or type(v410) ~= "string") and "" or v410
				else
					v407 = ""
				end
				v_u_8.setText(v391.weapon, v407 == "" and "Draw a weapon to shoot" or "Draw a weapon: " .. v407)
				v_u_8.setText(v391.ammo, "")
			end
			local v411 = v_u_21.stats()
			v_u_8.setText(v391.stats, ("SHOTS %d   HITS %d   ACC %d%%   SCORE %d   LAST %d"):format(v411.shots, v411.hits, v411.accuracy, v411.score, v411.last))
		end
	else
		return
	end
end
local function v_u_417(p413, p414) -- name: act
	-- upvalues: (ref) v_u_6
	local v415 = table.clone(p414)
	v415.op = p413
	local v416 = os.clock
	v415.req = "hideout_" .. p413 .. "_" .. tostring(v416())
	v_u_6.net.fire("menu.op", v415)
end
local function v_u_426() -- name: stashOpen
	-- upvalues: (ref) v_u_38, (ref) v_u_6
	if not v_u_38 then
		return false
	end
	local v418 = v_u_38
	if type(v418) == "table" and v_u_38.isOpen then
		local v419 = v_u_38.isOpen
		local v420, v421 = pcall(v419)
		if v420 then
			v420 = v421 == true
		end
		return v420
	end
	local v422 = v_u_6
	if v422 then
		v422 = v_u_6.controllers.InventoryUI
	end
	if not v422 or v422._broken then
		v422 = nil
	end
	if not (v422 and v422.isOpen) then
		return false
	end
	local v423 = v422.isOpen
	local v424, v425 = pcall(v423)
	if v424 then
		v424 = v425 == true
	end
	return v424
end
local function v_u_430() -- name: closeStash
	-- upvalues: (ref) v_u_38, (ref) v_u_51, (ref) v_u_8, (ref) v_u_25, (copy) v_u_59, (copy) v_u_82
	local v427 = v_u_38
	if type(v427) == "table" and v_u_38.close then
		local v428 = v_u_38.close
		pcall(v428)
	end
	local v429 = v_u_51
	if v429 and v429.Visible then
		v429.Visible = false
		v_u_8.sound("close")
	end
	if not (v_u_25 and v_u_25.isOpen() or v_u_59.win and v_u_59.win.isOpen()) then
		v_u_82(false)
	end
end
local function v_u_446() -- name: stashShell
	-- upvalues: (ref) v_u_51, (ref) v_u_8, (ref) v_u_9, (ref) v_u_39, (ref) v_u_6, (copy) v_u_430
	if v_u_51 and v_u_51.Parent then
		return v_u_51
	end
	local v431, v432 = v_u_8.screen("HushHideoutStash", v_u_9.layer.inventory)
	v_u_39 = v431
	local v433 = v_u_8.topInset()
	local v434 = Instance.new("Frame")
	v434.Name = "Stash"
	v434.AnchorPoint = Vector2.new(0.5, 0.5)
	local v435 = UDim2.new
	local v436 = v433 / 2
	v434.Position = v435(0.5, 0, 0.5, (math.floor(v436)))
	v434.Size = UDim2.new(1, -32, 1, -(v433 + 32))
	v434.BackgroundColor3 = v_u_9.color.bg
	v434.BackgroundTransparency = v_u_9.alpha.panel
	v434.BorderSizePixel = 0
	v434.Visible = false
	v_u_8.stroke(v434, v_u_9.color.line)
	local v437 = Instance.new("UISizeConstraint")
	v437.MaxSize = Vector2.new(1500, 900)
	v437.Parent = v434
	local v438 = Instance.new("Frame")
	v438.Name = "Accent"
	v438.BackgroundColor3 = v_u_9.color.accent
	v438.BorderSizePixel = 0
	v438.Size = UDim2.fromOffset(48, 2)
	v438.Parent = v434
	local v439 = Instance.new("Frame")
	v439.Name = "Header"
	v439.BackgroundTransparency = 1
	v439.Size = UDim2.new(1, 0, 0, 56)
	v439.Parent = v434
	v_u_8.label({
		["parent"] = nil,
		["text"] = "STASH RACK",
		["style"] = "h2",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v439,
		["position"] = UDim2.fromOffset(20, 10),
		["size"] = UDim2.new(1, -96, 0, 26)
	})
	local v440 = v_u_6
	if v440 then
		v440 = v_u_6.controllers.Input
	end
	if not v440 or v440._broken then
		v440 = nil
	end
	local v441
	if v440 and v440.hint then
		local v442 = v440.hint
		local v443, v444 = pcall(v442, "menu")
		v441 = (not v443 or type(v444) ~= "string") and "" or v444
	else
		v441 = ""
	end
	v_u_8.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v439,
		["text"] = v441 == "" and "HIDEOUT  /  LOADOUT AND STASH" or "HIDEOUT  /  LOADOUT AND STASH  /  CLOSE " .. v441,
		["color"] = v_u_9.color.text2,
		["position"] = UDim2.fromOffset(20, 36),
		["size"] = UDim2.new(1, -96, 0, 14)
	})
	v_u_8.closeIcon({
		["parent"] = nil,
		["size"] = 40,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v439,
		["position"] = UDim2.new(1, -10, 0, 8),
		["anchor"] = Vector2.new(1, 0),
		["onClick"] = v_u_430
	}).Name = "Close"
	v_u_8.divider({
		["parent"] = v434,
		["position"] = UDim2.fromOffset(0, 56),
		["size"] = UDim2.new(1, 0, 0, 1)
	})
	local v445 = Instance.new("Frame")
	v445.Name = "Body"
	v445.BackgroundTransparency = 1
	v445.Position = UDim2.fromOffset(0, 57)
	v445.Size = UDim2.new(1, 0, 1, -57)
	v445.ClipsDescendants = false
	v445.Parent = v434
	v434.Parent = v432
	v_u_51 = v434
	return v434
end
local function v_u_458() -- name: openStash
	-- upvalues: (ref) v_u_25, (copy) v_u_59, (ref) v_u_6, (ref) v_u_8, (copy) v_u_446, (ref) v_u_38, (copy) v_u_82
	if v_u_25 then
		v_u_25.close()
	end
	if v_u_59.win and v_u_59.win.isOpen() then
		v_u_59.win.close()
	end
	local v447 = v_u_6
	if v447 then
		v447 = v_u_6.controllers.InventoryUI
	end
	if not v447 or v447._broken then
		v447 = nil
	end
	if v447 and v447.mount then
		local v448 = v_u_446()
		local v449
		if v448 then
			v449 = v448:FindFirstChild("Body")
		else
			v449 = v448
		end
		if v448 and v449 then
			v448.Visible = true
			if not v_u_38 then
				local v450 = v447.mount
				local v451, v452 = pcall(v450, v449, "menu")
				if not v451 or type(v452) ~= "table" then
					warn("[HideoutWorld] InventoryUI.mount failed:", v452)
					v448.Visible = false
					if v_u_8 and v_u_8.toast then
						local v453 = v_u_8.toast
						pcall(v453, "Stash unavailable", "warn", "Open it from the main menu: CHARACTER")
					end
					return
				end
				v_u_38 = v452
			end
			local v454
			if v_u_38.open then
				local v455 = v_u_38.open
				v454 = pcall(v455)
			else
				v454 = true
			end
			if v454 then
				v_u_8.sound("open")
				v_u_82(true)
			else
				v448.Visible = false
				if v_u_8 and v_u_8.toast then
					local v456 = v_u_8.toast
					pcall(v456, "Stash unavailable", "warn", "Open it from the main menu: CHARACTER")
				end
			end
		else
			return
		end
	else
		if v_u_8 and v_u_8.toast then
			local v457 = v_u_8.toast
			pcall(v457, "Stash unavailable", "warn", "Open it from the main menu: CHARACTER")
		end
		return
	end
end
local function v_u_498() -- name: repairables
	-- upvalues: (ref) v_u_24, (ref) v_u_6, (ref) v_u_10, (ref) v_u_23
	local v_u_459 = {}
	local v460 = v_u_24
	if v460 then
		v460 = v_u_24.inv
	end
	if type(v460) ~= "table" then
		return v_u_459
	end
	local v_u_461 = v_u_6
	if v_u_461 then
		v_u_461 = v_u_6.shared.Items
	end
	local v_u_462 = v_u_6
	if v_u_462 then
		v_u_462 = v_u_6.shared.AttachWear
	end
	local v_u_463 = 0.85
	local function v470()
		-- upvalues: (ref) v_u_463, (ref) v_u_10, (ref) v_u_23
		local v464 = v_u_10.effectsAt
		local v465 = "workbench"
		local v466 = v_u_23 and v_u_23.modules
		if v466 then
			v466 = v_u_23.modules.workbench
		end
		local v467
		if v466 then
			local v468 = v466.lvl
			v467 = tonumber(v468) or 0
		else
			v467 = 0
		end
		local v469 = v464(v465, v467).repairQuality
		v_u_463 = tonumber(v469) or 0.85
	end
	pcall(v470)
	local function v_u_478(p471) -- name: repairable
		-- upvalues: (copy) v_u_461, (copy) v_u_462, (ref) v_u_463
		if type(p471) == "table" and p471.uid then
			local v472 = p471.dur
			if type(v472) == "number" then
				local v473 = v_u_461
				if v473 then
					v473 = v_u_461.get(p471.id)
				end
				if v473 and v473.uses then
					return false
				else
					local v_u_474 = p471.id
					local v475
					if v_u_461 and v_u_462 then
						local function v476()
							-- upvalues: (ref) v_u_462, (ref) v_u_461, (copy) v_u_474
							return v_u_462.wears(v_u_461.get(v_u_474))
						end
						local v477
						v475, v477 = pcall(v476)
						if v475 then
							v475 = v477 == true
						end
					else
						v475 = false
					end
					if v475 then
						return p471.dur < 0.999
					else
						return p471.dur < v_u_463 - 0.001
					end
				end
			end
		end
		return false
	end
	local function v488(p479) -- name: consider
		-- upvalues: (copy) v_u_478, (copy) v_u_459, (copy) v_u_461, (copy) v_u_462
		if type(p479) == "table" then
			if v_u_478(p479) then
				local v480 = v_u_459
				table.insert(v480, p479)
			end
			local v481 = p479.mods
			if type(v481) == "table" then
				for _, v482 in p479.mods do
					if type(v482) ~= "table" then
						continue
					end
					local v_u_483 = v482.id
					local v484
					if v_u_461 and v_u_462 then
						local function v485()
							-- upvalues: (ref) v_u_462, (ref) v_u_461, (copy) v_u_483
							return v_u_462.wears(v_u_461.get(v_u_483))
						end
						local v486
						v484, v486 = pcall(v485)
						if v484 then
							v484 = v486 == true
						end
					else
						v484 = false
					end
					if not (v484 and v_u_478(v482)) then
						continue
					end
					local v487 = v_u_459
					table.insert(v487, v482)
				end
			end
		end
	end
	local v489 = v460.kit
	if type(v489) == "table" then
		local v490 = v460.kit.slots
		if type(v490) == "table" then
			for _, v491 in v460.kit.slots do
				v488(v491)
			end
		end
	end
	local v492 = v460.containers
	if type(v492) == "table" then
		for _, v493 in v460.containers do
			if type(v493) ~= "table" then
				continue
			end
			local v494 = v493.items
			if type(v494) ~= "table" then
				continue
			end
			for _, v495 in v493.items do
				v488(v495)
			end
		end
	end
	table.sort(v_u_459, function(p496, p497)
		return p496.dur < p497.dur
	end)
	return v_u_459
end
local function v_u_544() -- name: ownedWeapons
	-- upvalues: (ref) v_u_24, (ref) v_u_6
	local v_u_499 = {}
	local v500 = v_u_24
	if v500 then
		v500 = v_u_24.inv
	end
	if type(v500) ~= "table" then
		return v_u_499
	end
	local function v501()
		-- upvalues: (ref) v_u_6
		return v_u_6.shared.Weapons
	end
	local v502, v_u_503 = pcall(v501)
	local function v504()
		-- upvalues: (ref) v_u_6
		return v_u_6.shared.Items
	end
	local v_u_505, v_u_506 = pcall(v504)
	if not (v502 and v_u_503) then
		return v_u_499
	end
	local v_u_507 = {}
	local function v_u_529(p508, p509) -- name: consider
		-- upvalues: (copy) v_u_507, (copy) v_u_503, (copy) v_u_505, (copy) v_u_506, (copy) v_u_499
		if type(p508) == "table" then
			local v510 = p508.id
			if type(v510) == "string" then
				local v511 = p508.uid
				if type(v511) == "string" and not v_u_507[p508.uid] then
					local v512 = nil
					if v_u_503.get(p508.id) then
						v512 = p508.id
					elseif v_u_505 and v_u_506 then
						local v513 = v_u_506.get
						local v514 = p508.id
						local v515, v516 = pcall(v513, v514)
						if v515 and type(v516) == "table" then
							local v517 = v516.weaponId
							if type(v517) == "string" and v_u_503.get(v516.weaponId) then
								v512 = v516.weaponId
							end
						end
					end
					if v512 then
						local v518 = v_u_503.get(v512)
						if v518 and v518.kind == "firearm" then
							v_u_507[p508.uid] = true
							local v519 = p508.id
							if v_u_505 and v_u_506 then
								local v520 = v_u_506.get
								local v521 = p508.id
								local v522, v523 = pcall(v520, v521)
								if v522 and type(v523) == "table" then
									local v524 = v523.name
									if type(v524) == "string" then
										v519 = v523.name
									end
								end
							end
							local v525 = 0
							local v526 = p508.mods
							if type(v526) == "table" then
								for _ in p508.mods do
									v525 = v525 + 1
								end
							end
							local v527 = v_u_499
							local v528 = {
								["uid"] = p508.uid,
								["id"] = p508.id,
								["name"] = v519,
								["where"] = p509,
								["mods"] = v525,
								["inst"] = p508
							}
							table.insert(v527, v528)
						end
					else
						return
					end
				end
			end
		end
	end
	local function v_u_535(p530, p531, p532) -- name: walk
		-- upvalues: (copy) v_u_529, (copy) v_u_535
		if type(p530) == "table" and p532 <= 3 then
			for _, v533 in p530 do
				v_u_529(v533, p531)
				if type(v533) ~= "table" then
					continue
				end
				local v534 = v533.items
				if type(v534) ~= "table" then
					continue
				end
				v_u_535(v533.items, p531, p532 + 1)
			end
		end
	end
	local v536 = v500.kit
	if type(v536) == "table" then
		local v537 = v500.kit.slots
		if type(v537) == "table" then
			for _, v538 in { "primary", "secondary" } do
				v_u_529(v500.kit.slots[v538], "LOADOUT")
			end
		end
	end
	local v539 = v500.containers
	if type(v539) == "table" then
		for v540, v541 in v500.containers do
			if type(v541) ~= "table" then
				continue
			end
			v_u_535(v541.items, v540 == "stash" and "STASH" or "LOADOUT", 0)
		end
	end
	table.sort(v_u_499, function(p542, p543)
		if p542.where == p543.where then
			return p542.name < p543.name
		else
			return p542.where == "LOADOUT"
		end
	end)
	return v_u_499
end
local function v_u_553(p545, p546) -- name: hideoutOp
	-- upvalues: (ref) v_u_6
	local v_u_547 = not p546 and {} or table.clone(p546)
	v_u_547.op = p545
	local v548 = os.clock
	v_u_547.req = "hideout_" .. p545 .. "_" .. tostring(v548())
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (copy) v_u_547
		local v549 = v_u_6.net.fire
		local v550 = v_u_547
		local v551, v552 = pcall(v549, "hideout.op", v550)
		if not v551 then
			warn("[HideoutWorld] hideout.op failed:", v552)
		end
	end)
end
local function v_u_642(p554, p_u_555, p_u_556, p_u_557, p558, p559) -- name: extra
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_8, (copy) v_u_458, (ref) v_u_21, (ref) v_u_25, (ref) v_u_23, (copy) v_u_544, (copy) v_u_7, (copy) v_u_553, (copy) v_u_498, (ref) v_u_11, (ref) v_u_6, (copy) v_u_417
	local v560 = v_u_9.color
	if p554 == "stash_rack" then
		local v561 = p558(p_u_555, "STASH", p_u_556)
		local v562 = p_u_557.effects
		if v562 then
			v562 = p_u_557.effects.stashRows
		end
		local v563 = tonumber(v562) or v_u_10.BASE_STASH_ROWS
		p559(v561, "Stash size", ("%d x %d"):format(v_u_10.STASH_WIDTH, v563), v560.text, 2)
		v_u_8.button({
			["parent"] = nil,
			["text"] = "OPEN STASH",
			["kind"] = "primary",
			["hint"] = "inventory",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v561,
			["size"] = UDim2.new(1, 0, 0, v_u_9.touch(44)),
			["onClick"] = v_u_458
		}).LayoutOrder = 5
		return
	end
	if p554 == "shooting_range" then
		local v564 = p558(p_u_555, "RANGE", p_u_556)
		local v565 = p_u_557.effects
		if v565 then
			v565 = p_u_557.effects.rangeTier
		end
		local v566 = tonumber(v565) or 0
		if v566 <= 0 then
			v_u_8.label({
				["parent"] = nil,
				["text"] = "Clear the lane and put up targets to train without waking the town.",
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v564,
				["color"] = v560.text2
			})
			return
		end
		local v567 = v_u_21 and v_u_21.stats() or {
			["shots"] = 0,
			["hits"] = 0,
			["accuracy"] = 0,
			["score"] = 0,
			["head"] = 0
		}
		p559(v564, "Shots / hits", ("%d / %d"):format(v567.shots, v567.hits), v560.text, 2)
		p559(v564, "Accuracy", ("%d %%"):format(v567.accuracy), v560.text, 3)
		p559(v564, "Score / head hits", ("%d / %d"):format(v567.score, v567.head), v560.text, 4)
		p559(v564, "Targets", v566 >= 3 and "10 / 25 (moving) / 50 (long range)" or (v566 >= 2 and "10 / 25 (moving) / 50" or "10 / 25 / 50"), v560.text2, 5)
		v_u_8.label({
			["parent"] = nil,
			["text"] = "Free ammo. Nothing you fire here is taken from your stash.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 6,
			["track"] = false,
			["parent"] = v564,
			["color"] = v560.muted
		})
		v_u_8.button({
			["parent"] = nil,
			["text"] = "RESET TARGETS",
			["kind"] = "secondary",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v564,
			["size"] = UDim2.new(1, 0, 0, v_u_9.touch(40)),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_21, (ref) v_u_25, (ref) v_u_23
				if v_u_21 then
					v_u_21.reset()
				end
				if v_u_25 then
					v_u_25.update(v_u_23)
				end
			end
		}).LayoutOrder = 7
		local v568 = p558(p_u_555, "WEAPONS", p_u_556 + 1)
		local v569 = v_u_544()
		local v570 = v_u_7.Character
		if v570 then
			v570 = v570:GetAttribute("Weapon")
		end
		if #v569 == 0 then
			v_u_8.label({
				["parent"] = nil,
				["text"] = "No firearms in your loadout or stash yet.",
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v568,
				["color"] = v560.text2
			})
		end
		local v571 = v_u_9.touch(32)
		for v572, v_u_573 in v569 do
			if v572 > 12 then
				break
			end
			local v574 = Instance.new("Frame")
			v574.BackgroundTransparency = 1
			v574.Size = UDim2.new(1, 0, 0, v571 + 4)
			v574.LayoutOrder = v572 + 1
			v_u_8.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["size"] = nil,
				["track"] = false,
				["parent"] = v574,
				["text"] = v_u_573.name,
				["size"] = UDim2.new(1, -230, 1, 0)
			})
			local v575 = v_u_573.where .. (v_u_573.mods <= 0 and "" or ("  +%d MOD%s"):format(v_u_573.mods, v_u_573.mods > 1 and "S" or ""))
			local v576 = v_u_8.label
			local v577 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["align"] = "right",
				["track"] = false,
				["parent"] = v574,
				["text"] = v575
			}
			local v578
			if v_u_573.where == "LOADOUT" then
				v578 = v560.accent
			else
				v578 = v560.text2
			end
			v577.color = v578
			v577.size = UDim2.new(0, 110, 1, 0)
			v577.position = UDim2.new(1, -224, 0, 0)
			v576(v577)
			v_u_8.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["onClick"] = nil,
				["parent"] = v574,
				["text"] = v570 == v_u_573.id and "AGAIN" or "TRY",
				["size"] = UDim2.fromOffset(104, v571),
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["anchor"] = Vector2.new(1, 0.5),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_553, (copy) v_u_573
					v_u_553("tryWeapon", {
						["uid"] = v_u_573.uid
					})
				end
			})
			v574.Parent = v568
		end
		v_u_8.button({
			["parent"] = nil,
			["text"] = "OWN LOADOUT",
			["kind"] = "ghost",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v568,
			["size"] = UDim2.new(1, 0, 0, v_u_9.touch(36)),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_553
				v_u_553("ownWeapons")
			end
		}).LayoutOrder = 40
		return
	end
	if p554 == "workbench" then
		local v579 = p558(p_u_555, "REPAIRS", p_u_556)
		local v580 = v_u_23 and v_u_23.modules
		if v580 then
			v580 = v_u_23.modules.workbench
		end
		local v581
		if v580 then
			local v582 = v580.lvl
			v581 = tonumber(v582) or 0
		else
			v581 = 0
		end
		if v581 <= 0 then
			v_u_8.label({
				["parent"] = nil,
				["text"] = "Build the workbench to repair weapons and armor.",
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v579,
				["color"] = v560.text2
			})
			return
		end
		local v583 = v_u_498()
		local v584 = v_u_10.effectsAt
		local v585 = "workbench"
		local v586 = v_u_23 and v_u_23.modules
		if v586 then
			v586 = v_u_23.modules.workbench
		end
		local v587
		if v586 then
			local v588 = v586.lvl
			v587 = tonumber(v588) or 0
		else
			v587 = 0
		end
		local v589 = v584(v585, v587).repairQuality or 0.85
		if #v583 == 0 then
			v_u_8.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v579,
				["text"] = v_u_11.repairEmpty(v589, nil) .. " " .. v_u_11.REPAIR_HINT,
				["color"] = v560.text2
			})
			return
		end
		local v_u_590 = v_u_6.shared.Items
		for v591, v_u_592 in v583 do
			if v_u_11.LIST_MAX < v591 then
				return
			end
			local v593 = Instance.new("Frame")
			v593.BackgroundTransparency = 1
			v593.Size = UDim2.new(1, 0, 0, v_u_9.touch(32) + 4)
			v593.LayoutOrder = v591 + 1
			local v_u_594 = v_u_592.id
			local function v596()
				-- upvalues: (copy) v_u_590, (copy) v_u_592, (ref) v_u_594
				local v595 = v_u_590.get(v_u_592.id)
				v_u_594 = v595 and v595.name or v_u_592.id
			end
			pcall(v596)
			v_u_8.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["size"] = nil,
				["track"] = false,
				["parent"] = v593,
				["text"] = v_u_594,
				["size"] = UDim2.new(1, -200, 1, 0)
			})
			local v597 = v_u_8.label
			local v598 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "mono",
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["align"] = "right",
				["track"] = false,
				["parent"] = v593
			}
			local v599 = v_u_592.dur * 100
			v598.text = ("%d %%"):format((math.floor(v599)))
			local v600
			if v_u_592.dur < 0.5 then
				v600 = v560.danger
			else
				v600 = v560.accent
			end
			v598.color = v600
			v598.size = UDim2.new(0, 60, 1, 0)
			v598.position = UDim2.new(1, -176, 0, 0)
			v597(v598)
			v_u_8.button({
				["parent"] = nil,
				["text"] = "REPAIR",
				["kind"] = "secondary",
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["onClick"] = nil,
				["parent"] = v593,
				["size"] = UDim2.fromOffset(104, v_u_9.touch(32)),
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["anchor"] = Vector2.new(1, 0.5),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_592, (ref) v_u_6
					local v601 = {
						["uid"] = v_u_592.uid
					}
					local v602 = table.clone(v601)
					v602.op = "repair"
					local v603 = os.clock
					v602.req = "hideout_" .. "repair" .. "_" .. tostring(v603())
					v_u_6.net.fire("menu.op", v602)
				end
			})
			v593.Parent = v579
		end
	else
		if p554 == "radio" then
			local v604 = p558(p_u_555, "INTEL", p_u_556)
			local v605 = p_u_557.effects
			if v605 then
				v605 = p_u_557.effects.radioIntel
			end
			local v606 = tonumber(v605) or 0
			local v607 = {
				"Static. Build the radio to listen in before a raid.",
				v_u_11.radioText(v_u_10.get("radio"), 1),
				v_u_11.radioText(v_u_10.get("radio"), 2),
				v_u_11.radioText(v_u_10.get("radio"), 3)
			}
			for v608 = v606 <= 0 and 0 or 1, 3 do
				local v609
				if v608 > 0 then
					v609 = v608 <= v606
				else
					v609 = false
				end
				local v610 = Instance.new("Frame")
				v610.BackgroundTransparency = 1
				v610.Size = UDim2.new(1, 0, 0, 0)
				v610.AutomaticSize = Enum.AutomaticSize.Y
				v610.LayoutOrder = v608 + 2
				local v611 = v_u_8.label
				local v612 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["track"] = false,
					["parent"] = v610,
					["text"] = v607[v608 + 1]
				}
				local v613
				if v609 or v608 == 0 then
					v613 = v560.text
				else
					v613 = v560.muted
				end
				v612.color = v613
				v612.size = UDim2.new(1, -86, 0, 0)
				v611(v612)
				if v608 > 0 then
					local v614 = v_u_8.label
					local v615 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["size"] = nil,
						["position"] = nil,
						["align"] = "right",
						["track"] = false,
						["parent"] = v610,
						["text"] = v609 and "ACTIVE" or "LVL " .. v608
					}
					local v616
					if v609 then
						v616 = v560.success
					else
						v616 = v560.muted
					end
					v615.color = v616
					v615.size = UDim2.new(0, 80, 0, 22)
					v615.position = UDim2.new(1, -80, 0, 0)
					v614(v615)
				end
				v610.Parent = v604
			end
			return
		end
		if p554 == "trophy_wall" then
			if p_u_555:FindFirstChild("TrophyBlock") then
				return
			end
			local function v618()
				-- upvalues: (ref) v_u_6, (copy) p_u_555, (copy) p_u_556, (copy) p_u_557, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_417
				local v617 = {
					["HushUI"] = v_u_8,
					["Theme"] = v_u_9,
					["HM"] = v_u_10,
					["act"] = v_u_417
				}
				v_u_6.lib.HideoutTrophy.render(p_u_555, p_u_556, p_u_557, v617)
			end
			local v619, v620 = pcall(v618)
			if v619 then
				return
			end
			warn("[HideoutWorld] trophy window:", v620)
			local v621 = p558(p_u_555, "TROPHIES", p_u_556)
			local v622 = p_u_557.effects
			if v622 then
				v622 = p_u_557.effects.trophySlots
			end
			local v623 = tonumber(v622) or 0
			local v624 = p_u_557.trophies or {}
			local v625 = #v624
			p559(v621, "On display", ("%d / %d"):format(math.min(v625, v623), v623), v560.text, 2)
			local v_u_626 = v_u_6.shared.Items
			for v627, v_u_628 in v624 do
				local v_u_629 = v_u_628
				local function v633()
					-- upvalues: (copy) v_u_626, (copy) v_u_628, (ref) v_u_629
					local v630 = v_u_626.get(v_u_628)
					if v630 then
						v_u_629 = v630.name
					else
						local v631 = v_u_628
						if string.sub(v631, 1, 7) == "zombie_" then
							local v632 = v_u_628
							v_u_629 = string.upper(string.gsub(string.sub(v632, 8), "_", " "))
						end
					end
				end
				pcall(v633)
				p559(v621, v_u_629, v627 <= v623 and "SHOWN" or "", v560.accent, 2 + v627)
			end
			if #v624 == 0 then
				v_u_8.label({
					["parent"] = nil,
					["text"] = "Rare finds and boss kills end up here. Nothing worth hanging up yet.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 3,
					["track"] = false,
					["parent"] = v621,
					["color"] = v560.muted
				})
				return
			end
		elseif p554 == "generator" then
			local v634 = p558(p_u_555, "POWER", p_u_556)
			local v635 = p_u_557.effects
			if v635 then
				v635 = p_u_557.effects.lightLevel
			end
			local v636 = tonumber(v635) or 0
			local v637 = p_u_557.effects
			if v637 then
				v637 = p_u_557.effects.craftSpeed
			end
			local v638 = tonumber(v637) or 1
			local v639 = "Lights"
			local v640 = v636 <= 0 and "BATTERY" or ("LEVEL %d"):format(v636)
			local v641
			if v636 > 0 then
				v641 = v560.success
			else
				v641 = v560.accent
			end
			p559(v634, v639, v640, v641, 2)
			p559(v634, "Crafting speed", ("x%.2f"):format(v638), v560.text, 3)
		end
	end
end
local function v_u_654() -- name: stationHooks
	-- upvalues: (copy) v_u_458, (ref) v_u_24, (ref) v_u_21, (ref) v_u_25, (ref) v_u_23, (copy) v_u_544, (copy) v_u_7, (copy) v_u_553, (copy) v_u_498, (copy) v_u_5, (ref) v_u_53, (ref) v_u_9, (ref) v_u_8, (copy) v_u_61, (copy) v_u_60
	return {
		["openStash"] = v_u_458,
		["dismantleItems"] = function() -- name: dismantleItems
			-- upvalues: (ref) v_u_24
			local v643 = v_u_24
			if v643 then
				v643 = v_u_24.inv
			end
			local v644
			if type(v643) == "table" then
				local v645 = v643.containers
				if type(v645) == "table" then
					v644 = v643.containers.stash
				else
					v644 = false
				end
			else
				v644 = false
			end
			if type(v644) == "table" then
				local v646 = v644.items
				if type(v646) == "table" then
					return v644.items
				end
			end
			return {}
		end,
		["rangeStats"] = function() -- name: rangeStats
			-- upvalues: (ref) v_u_21
			if v_u_21 then
				return v_u_21.stats()
			else
				return nil
			end
		end,
		["rangeReset"] = function() -- name: rangeReset
			-- upvalues: (ref) v_u_21, (ref) v_u_25, (ref) v_u_23
			if v_u_21 then
				v_u_21.reset()
			end
			if v_u_25 then
				v_u_25.update(v_u_23)
			end
		end,
		["ownedWeapons"] = v_u_544,
		["inHands"] = function() -- name: inHands
			-- upvalues: (ref) v_u_7
			local v647 = v_u_7.Character
			if v647 then
				v647 = v647:GetAttribute("Weapon")
			end
			return v647
		end,
		["tryWeapon"] = function(p648) -- name: tryWeapon
			-- upvalues: (ref) v_u_553
			v_u_553("tryWeapon", {
				["uid"] = p648
			})
		end,
		["ownWeapons"] = function() -- name: ownWeapons
			-- upvalues: (ref) v_u_553
			v_u_553("ownWeapons")
		end,
		["repairables"] = v_u_498,
		["retry"] = function() -- name: retry
			-- upvalues: (ref) v_u_5
			v_u_5.retryView()
		end,
		["chrome"] = function() -- name: chrome
			-- upvalues: (ref) v_u_53, (ref) v_u_9, (ref) v_u_8, (ref) v_u_61, (ref) v_u_60
			if v_u_53 then
				return {
					["right"] = 0,
					["headBottom"] = 0,
					["headRight"] = 0
				}
			end
			local v649 = v_u_9.isPhone and v_u_9.isPhone() or v_u_8.device() == "Touch"
			local v650 = v_u_9.refSize().X < 1600
			local v651 = v650 and 24 or v_u_61.edge
			local v652
			if v650 then
				v652 = v_u_60.W
			else
				v652 = v_u_61.listW
			end
			local v653 = v_u_8.topInset()
			return {
				["right"] = v651 + v652 + 16,
				["headBottom"] = v653 + 16 + (v649 and 58 or 72) + v_u_9.touch(40),
				["headRight"] = v_u_61.headX + 240
			}
		end
	}
end
v_u_153 = function(p655)
	-- upvalues: (ref) v_u_17, (ref) v_u_10, (copy) v_u_59, (ref) v_u_25, (ref) v_u_6, (ref) v_u_8, (ref) v_u_9, (ref) v_u_27, (copy) v_u_417, (copy) v_u_642, (copy) v_u_654, (copy) v_u_7, (copy) v_u_270, (ref) v_u_51, (copy) v_u_82, (ref) v_u_23, (copy) v_u_90
	if v_u_17 and v_u_10.get(p655) then
		if v_u_59.win and v_u_59.win.isOpen() then
			v_u_59.win.close()
		end
		if not v_u_25 then
			local v656 = v_u_6.lib.HideoutPanel.new
			local v657 = {
				["HushUI"] = v_u_8,
				["Theme"] = v_u_9,
				["HM"] = v_u_10
			}
			local function v658()
				-- upvalues: (ref) v_u_6
				return v_u_6.shared.Items
			end
			local v659, v660 = pcall(v658)
			if not v659 then
				v660 = nil
			end
			v657.Items = v660
			v657.root = v_u_27
			v657.act = v_u_417
			v657.extra = v_u_642
			v657.hooks = v_u_654()
			v657.cctx = v_u_6
			function v657.onClosed() -- name: onClosed
				-- upvalues: (ref) v_u_7, (ref) v_u_270, (ref) v_u_51, (ref) v_u_59, (ref) v_u_82
				v_u_7:SetAttribute("HideoutPanel", "")
				v_u_270()
				if not (v_u_51 and v_u_51.Visible or v_u_59.win and v_u_59.win.isOpen()) then
					v_u_82(false)
				end
			end
			v_u_25 = v656(v657)
		end
		v_u_25.show(p655, v_u_23 or v_u_90())
		v_u_7:SetAttribute("HideoutPanel", p655)
		v_u_82(true)
		v_u_270()
	end
end
function v_u_5.openStation(p661) -- name: openStation
	-- upvalues: (ref) v_u_153
	v_u_153(p661)
end
v_u_200 = function(p662)
	-- upvalues: (ref) v_u_17, (ref) v_u_25, (copy) v_u_426, (ref) v_u_51, (copy) v_u_430, (copy) v_u_59, (ref) v_u_6, (ref) v_u_26, (copy) v_u_270, (copy) v_u_82, (copy) v_u_7, (ref) v_u_8
	if v_u_17 then
		if v_u_25 and v_u_25.isOpen() then
			v_u_25.close()
		end
		if v_u_426() or v_u_51 and v_u_51.Visible then
			v_u_430()
		end
		if not v_u_59.win then
			local v663 = v_u_6.lib.HideoutTerminal.new
			local v664 = v_u_6
			local v666 = {
				["onClosed"] = function() -- name: onClosed
					-- upvalues: (ref) v_u_26, (ref) v_u_270, (ref) v_u_25, (ref) v_u_51, (ref) v_u_82
					local v665 = v_u_26
					if v665 then
						v665.Enabled = true
					end
					v_u_270()
					if not (v_u_25 and v_u_25.isOpen() or v_u_51 and v_u_51.Visible) then
						v_u_82(false)
					end
				end
			}
			local v667, v668 = pcall(v663, v664, v666)
			if not v667 then
				warn("[HideoutWorld] terminal failed:", v668)
				v_u_7:SetAttribute("ClientError", "HideoutWorld terminal: " .. tostring(v668))
				if v_u_8 and v_u_8.toast then
					local v669 = v_u_8.toast
					pcall(v669, "Terminal unavailable", "warn", "Use TRADERS and TASKS in the main menu.")
				end
				return
			end
			v_u_59.win = v668
		end
		v_u_59.win.open(p662)
		v_u_82(true)
		v_u_270()
		local v670 = v_u_26
		if v670 then
			v670.Enabled = false
		end
	end
end
function v_u_5.openTerminal(p671) -- name: openTerminal
	-- upvalues: (ref) v_u_200
	v_u_200(p671)
end
function v_u_5.closePanel() -- name: closePanel
	-- upvalues: (ref) v_u_25
	if v_u_25 then
		v_u_25.close()
	end
end
local function v_u_688(p672) -- name: applyView
	-- upvalues: (ref) v_u_23, (ref) v_u_17, (ref) v_u_10, (copy) v_u_22, (copy) v_u_199, (ref) v_u_20, (ref) v_u_36, (ref) v_u_37, (ref) v_u_21, (copy) v_u_7, (copy) v_u_28, (copy) v_u_253, (ref) v_u_25
	v_u_23 = p672
	if v_u_17 then
		for _, v673 in v_u_10.ORDER do
			local v674 = v_u_22[v673]
			local v675 = v_u_23 and v_u_23.modules
			if v675 then
				v675 = v_u_23.modules[v673]
			end
			local v676
			if v675 then
				local v677 = v675.lvl
				v676 = tonumber(v677) or 0
			else
				v676 = 0
			end
			if v674 and (v674.lvl == v676 and v673 ~= "trophy_wall") then
				continue
			end
			v_u_199(v673)
		end
		local v678 = v_u_23
		if v678 then
			v678 = v_u_23.effects
		end
		if v678 then
			v678 = v678.lightLevel
		end
		local v679 = v678 == nil and 0 or v678
		local v680 = tonumber(v679) or 0
		local v681 = v_u_23 and v_u_23.modules
		if v681 then
			v681 = v_u_23.modules.shooting_range
		end
		local v682
		if v681 then
			local v683 = v681.lvl
			v682 = tonumber(v683) or 0
		else
			v682 = 0
		end
		if v_u_20 and (v680 ~= v_u_36 or v682 > 0 ~= (v_u_37 > 0)) then
			v_u_20.setLightLevel(v680, v682 > 0)
		end
		v_u_36 = v680
		if v_u_21 and v682 ~= v_u_37 then
			v_u_21.setLevel(v682)
			local v684 = v_u_22.shooting_range
			if v684 then
				v684 = v684.model:FindFirstChild("HitMap", true)
			end
			local v685 = v_u_21.setHitMap
			if not (v684 and v684:IsA("BasePart")) then
				v684 = nil
			end
			v685(v684)
		end
		v_u_37 = v682
		v_u_7:SetAttribute("HideoutLight", v680)
		for v686, v687 in v_u_28 do
			v_u_253(v687, v686)
		end
		if v_u_25 then
			v_u_25.update(v_u_23)
		end
	end
end
local v_u_689 = 0
function v_u_5.retryView() -- name: retryView
	-- upvalues: (ref) v_u_689, (ref) v_u_11, (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (copy) v_u_87, (copy) v_u_688
	v_u_689 = os.clock() + v_u_11.RETRY_EVERY
	if not v_u_35 then
		if v_u_15 ~= "Hideout" then
			return
		end
		v_u_35 = true
		task.delay(0.3, function()
			-- upvalues: (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
			v_u_35 = false
			if v_u_15 == "Hideout" then
				v_u_34 = v_u_34 + 1
				local v690 = v_u_34
				local v691 = v_u_87()
				if v691 and (v690 == v_u_34 and v_u_15 == "Hideout") then
					v_u_688(v691)
				end
			end
		end)
	end
end
local function v_u_693() -- name: applyFallbackLighting
	-- upvalues: (ref) v_u_6, (ref) v_u_49, (copy) v_u_4
	local v692 = v_u_6
	if v692 then
		v692 = v_u_6.controllers.Atmosphere
	end
	if not v692 or v692._broken then
		v692 = nil
	end
	if not v692 then
		v_u_49 = {
			["Brightness"] = v_u_4.Brightness,
			["ClockTime"] = v_u_4.ClockTime,
			["Ambient"] = v_u_4.Ambient,
			["OutdoorAmbient"] = v_u_4.OutdoorAmbient
		}
		v_u_4.Brightness = 0
		v_u_4.ClockTime = 0
		v_u_4.Ambient = Color3.fromHex("2C313A")
		v_u_4.OutdoorAmbient = Color3.fromHex("08090B")
	end
end
local function v_u_698() -- name: restoreFallbackLighting
	-- upvalues: (ref) v_u_49, (copy) v_u_4
	local v694 = v_u_49
	if v694 then
		v_u_49 = nil
		for v_u_695, v_u_696 in v694 do
			local function v697()
				-- upvalues: (ref) v_u_4, (copy) v_u_695, (copy) v_u_696
				v_u_4[v_u_695] = v_u_696
			end
			pcall(v697)
		end
	end
end
local function v_u_715() -- name: teardown
	-- upvalues: (ref) v_u_17, (ref) v_u_41, (ref) v_u_6, (copy) v_u_43, (copy) v_u_32, (copy) v_u_33, (ref) v_u_25, (copy) v_u_59, (ref) v_u_38, (ref) v_u_39, (ref) v_u_51, (copy) v_u_22, (copy) v_u_94, (ref) v_u_50, (ref) v_u_21, (ref) v_u_20, (ref) v_u_19, (ref) v_u_26, (ref) v_u_27, (ref) v_u_30, (ref) v_u_29, (ref) v_u_54, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57, (ref) v_u_52, (copy) v_u_28, (ref) v_u_31, (ref) v_u_36, (ref) v_u_37, (copy) v_u_82, (copy) v_u_698, (copy) v_u_7
	v_u_17 = false
	v_u_41 = false
	local function v699()
		-- upvalues: (ref) v_u_6
		v_u_6.lib.VhsStation.destroy()
		v_u_6.lib.VhsPlayer.close()
	end
	pcall(v699)
	local function v700()
		-- upvalues: (ref) v_u_6
		v_u_6.lib.HideoutClan.destroy()
	end
	pcall(v700)
	table.clear(v_u_43)
	for _, v701 in v_u_32 do
		v701:Disconnect()
	end
	table.clear(v_u_32)
	for _, v702 in v_u_33 do
		pcall(v702)
	end
	table.clear(v_u_33)
	if v_u_25 then
		local v703 = v_u_25.destroy
		pcall(v703)
		v_u_25 = nil
	end
	if v_u_59.win then
		local v704 = v_u_59.win.destroy
		pcall(v704)
		v_u_59.win = nil
	end
	v_u_59.prop = nil
	v_u_59.door = nil
	v_u_59.row = nil
	if v_u_38 then
		local v705 = v_u_38
		if type(v705) == "table" and v_u_38.destroy then
			local v706 = v_u_38.destroy
			pcall(v706)
		else
			local v707 = v_u_38
			if type(v707) == "table" and v_u_38.close then
				local v708 = v_u_38.close
				pcall(v708)
			end
		end
		v_u_38 = nil
	end
	if v_u_39 then
		v_u_39:Destroy()
		v_u_39 = nil
	end
	v_u_51 = nil
	for _, v709 in v_u_22 do
		local v710 = v_u_94
		pcall(v710, v709)
	end
	table.clear(v_u_22)
	v_u_50 = nil
	if v_u_21 then
		local v711 = v_u_21.destroy
		pcall(v711)
		v_u_21 = nil
	end
	if v_u_20 then
		local v712 = v_u_20.destroy
		pcall(v712)
		v_u_20 = nil
	end
	if v_u_19 then
		v_u_19:Destroy()
		v_u_19 = nil
	end
	if v_u_26 then
		v_u_26:Destroy()
		v_u_26 = nil
		v_u_27 = nil
	end
	if v_u_30 then
		v_u_30:Destroy()
		v_u_30 = nil
	end
	v_u_29 = nil
	v_u_54 = nil
	v_u_55 = false
	v_u_56 = nil
	v_u_57 = nil
	v_u_52 = nil
	local v713 = v_u_6
	if v713 then
		v713 = v_u_6.controllers.Vision
	end
	if not v713 or v713._broken then
		v713 = nil
	end
	if v713 and v713.setLoose then
		local v714 = v713.setLoose
		pcall(v714, nil)
	end
	table.clear(v_u_28)
	v_u_31 = nil
	v_u_36 = -1
	v_u_37 = -1
	v_u_82(false)
	v_u_698()
	v_u_7:SetAttribute("HideoutBuilt", false)
	v_u_7:SetAttribute("HideoutPanel", "")
end
local function v_u_727(p716, p717) -- name: reportDarkRoom
	-- upvalues: (ref) v_u_6, (copy) v_u_7
	local v718 = v_u_6
	if v718 then
		v718 = v_u_6.controllers.Atmosphere
	end
	if not v718 or v718._broken then
		v718 = nil
	end
	local v719 = "none"
	if v718 and v718.health then
		local v720 = v718.health
		local v721, v722 = pcall(v720)
		if v721 then
			v719 = tostring(v722)
		end
	end
	local v723 = v_u_7
	local v724 = v_u_7
	local v_u_725 = ("hideout lights off: lit %d/%d atmo.lamps %s stage %s | %s"):format(p716, p717, tostring(v723:GetAttribute("AtmoLamps")), tostring(v724:GetAttribute("CrateStageOn")), v719)
	warn("[HideoutWorld]", v_u_725)
	v_u_7:SetAttribute("ClientError", (string.sub(v_u_725, 1, 200)))
	local function v726()
		-- upvalues: (ref) v_u_6, (copy) v_u_725
		v_u_6.lib.MoveWatch.fault("hideout lights", v_u_725)
	end
	pcall(v726)
end
local v_u_728 = nil
local function v_u_733(p729, p730, p731) -- name: waitFor
	-- upvalues: (ref) v_u_16
	local v732 = os.clock()
	while os.clock() - v732 < p730 do
		if v_u_16 ~= p731 then
			return false
		end
		if p729() then
			return true
		end
		task.wait(0.1)
	end
	return p729()
end
local function v_u_859(p_u_734) -- name: build
	-- upvalues: (copy) v_u_733, (copy) v_u_7, (ref) v_u_16, (ref) v_u_18, (ref) v_u_6, (copy) v_u_87, (ref) v_u_24, (copy) v_u_2, (ref) v_u_19, (ref) v_u_52, (ref) v_u_12, (ref) v_u_14, (ref) v_u_20, (ref) v_u_21, (ref) v_u_23, (copy) v_u_90, (ref) v_u_17, (copy) v_u_390, (copy) v_u_688, (copy) v_u_228, (ref) v_u_254, (copy) v_u_59, (copy) v_u_417, (copy) v_u_693, (ref) v_u_9, (ref) v_u_30, (copy) v_u_33, (ref) v_u_8, (ref) v_u_25, (copy) v_u_426, (ref) v_u_51, (copy) v_u_430, (copy) v_u_458, (copy) v_u_32, (copy) v_u_3, (ref) v_u_31, (ref) v_u_200, (ref) v_u_153, (copy) v_u_160, (copy) v_u_22, (ref) v_u_728, (copy) v_u_727, (ref) v_u_42, (ref) v_u_10
	local v736 = v_u_733(function()
		-- upvalues: (ref) v_u_7
		local v735 = v_u_7
		return typeof(v735:GetAttribute("HideoutOrigin")) == "Vector3"
	end, 15, p_u_734)
	if v_u_16 == p_u_734 then
		if v736 then
			v_u_18 = v_u_7:GetAttribute("HideoutOrigin")
		else
			local v737 = v_u_7
			local v738 = tonumber(v737:GetAttribute("HideoutSlot")) or 0
			local v739 = v_u_6.config.HIDEOUT_ORIGIN
			local v740 = v738 % 12 * 1600
			local v741 = -4000 - v738 // 12 * 1600
			v_u_18 = v739 + Vector3.new(v740, 0, v741)
		end
		local v_u_742 = nil
		local v_u_743 = false
		task.spawn(function()
			-- upvalues: (ref) v_u_742, (ref) v_u_87, (ref) v_u_743
			v_u_742 = v_u_87()
			v_u_743 = true
		end)
		if v_u_24 == nil then
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_24, (ref) v_u_16, (copy) p_u_734
				local v744 = v_u_6.net.invoke
				local v745, v746 = pcall(v744, "menu.get", {
					["what"] = "profile"
				})
				if v745 and (type(v746) == "table" and (not v746.error and (v_u_24 == nil and v_u_16 == p_u_734))) then
					v_u_24 = v746
				end
			end)
		end
		local v747 = v_u_2:FindFirstChild("HushLocal")
		if not v747 then
			v747 = Instance.new("Folder")
			v747.Name = "HushLocal"
			v747.Parent = v_u_2
		end
		local v748 = Instance.new("Folder")
		v748.Name = "Hideout"
		v748.Parent = v747
		v_u_19 = v748
		local v749 = Instance.new("Folder")
		v749.Name = "Stations"
		v749.Parent = v748
		v_u_52 = v749
		local v750 = nil
		local v751 = v_u_12.hasImported("Hideout", "Room")
		local v752 = v_u_6.lib.HideoutRoom.build
		local v753 = v_u_18
		local v754 = v_u_14
		local v755 = {
			["shell"] = not v751,
			["wallExt"] = v_u_6.config.flag("Hideout4") == true
		}
		local v756, v757 = pcall(v752, v748, v753, v754, v755)
		if v756 then
			v_u_20 = v757
		else
			warn("[HideoutWorld] room build failed:", v757)
		end
		local v758
		if v751 then
			local v759 = v_u_12.get
			local v760
			v760, v758 = pcall(v759, "Hideout", "Room")
			if v760 and (typeof(v758) == "Instance" and v758:IsA("Model")) then
				v758:PivotTo(CFrame.new(v_u_18))
				v758.Parent = v748
			else
				v758 = v750
			end
		else
			v758 = v750
		end
		local v761 = v_u_6.lib.HideoutRange.new
		local v762 = v_u_18
		local v763 = v_u_14
		local v764 = v_u_12
		local v765, v766 = pcall(v761, v748, v762, v763, v764)
		if v765 then
			v_u_21 = v766
		else
			warn("[HideoutWorld] range failed:", v766)
		end
		v_u_733(function()
			-- upvalues: (ref) v_u_743
			return v_u_743
		end, 10, p_u_734)
		if v_u_16 == p_u_734 then
			v_u_23 = v_u_742 or v_u_90()
			v_u_17 = true
			v_u_390()
			v_u_688(v_u_23)
			local v767 = v_u_228
			local v768, v769 = pcall(v767)
			if not v768 then
				warn("[HideoutWorld] terminal build failed:", v769)
			end
			local function v795()
				-- upvalues: (ref) v_u_19, (ref) v_u_14, (ref) v_u_18, (ref) v_u_52, (ref) v_u_254, (ref) v_u_59
				local v770 = nil
				for _, v771 in v_u_19:GetDescendants() do
					if not v771:IsA("BasePart") or v771.Name ~= "DoorLeaf" then
						continue
					end
					v770 = v771
				end
				local v772 = v_u_14 and v_u_14.half or Vector3.new(36, 0, 30)
				local v773
				if v770 then
					v773 = v770.Position
				else
					local v774 = v_u_18
					local v775 = -v772.Z + 0.35
					v773 = v774 + Vector3.new(26, 4.6, v775)
				end
				local v776 = v_u_18.X - v773.X
				local v777 = v_u_18.Z - v773.Z
				local v778 = Vector3.new(v776, 0, v777)
				local v779 = not v770 and Vector3.new(0, 0, 1) or v770.CFrame.LookVector
				local v780 = v779.X
				local v781 = v779.Z
				local v782 = Vector3.new(v780, 0, v781)
				local v783 = (v782.Magnitude < 0.1 and Vector3.new(0, 0, 1) or v782).Unit
				if v778.Magnitude > 0.1 and v783:Dot(v778.Unit) < 0 then
					v783 = -v783
				end
				local v784 = Instance.new("Part")
				v784.Name = "Hitbox_door"
				v784.Anchored = true
				v784.CanCollide = false
				v784.CanQuery = false
				v784.CanTouch = false
				v784.CastShadow = false
				v784.Transparency = 1
				v784.Size = Vector3.new(4, 6, 0.6)
				local v785 = CFrame.lookAt
				local v786 = v773.X
				local v787 = v_u_18.Y + 3
				local v788 = v773.Z
				local v789 = Vector3.new(v786, v787, v788) + v783 * 0.9
				local v790 = v773.X
				local v791 = v_u_18.Y + 3
				local v792 = v773.Z
				v784.CFrame = v785(v789, Vector3.new(v790, v791, v792) + v783 * 2)
				v784.Parent = v_u_52 or v_u_19
				local v793 = Instance.new("Attachment")
				v793.Name = "PromptAt"
				v793.Position = Vector3.new(0, -1, 0)
				v793.Parent = v784
				local v794 = Instance.new("ProximityPrompt")
				v794.Name = "HideoutPrompt"
				v794.Style = Enum.ProximityPromptStyle.Custom
				v794.ActionText = "Leave hideout"
				v794.ObjectText = "Cellar door"
				v794.MaxActivationDistance = 4
				v794.RequiresLineOfSight = false
				v794.HoldDuration = 0.4
				v794:SetAttribute("Priority", 5)
				v794:SetAttribute("Kind", "hideoutDoor")
				v794.Triggered:Connect(function()
					-- upvalues: (ref) v_u_254
					v_u_254()
				end)
				v794.Parent = v793
				v_u_59.door = v794
			end
			pcall(v795)
			local function v796()
				-- upvalues: (ref) v_u_6, (ref) v_u_52, (ref) v_u_19, (ref) v_u_18, (ref) v_u_417
				v_u_6.lib.VhsStation.build(v_u_6, v_u_52 or v_u_19, v_u_18, v_u_417)
			end
			pcall(v796)
			local function v797()
				-- upvalues: (ref) v_u_6, (ref) v_u_52, (ref) v_u_19, (ref) v_u_18, (ref) v_u_417
				v_u_6.lib.HideoutClan.build(v_u_6, v_u_52 or v_u_19, v_u_18, v_u_417)
			end
			pcall(v797)
			v_u_733(function()
				-- upvalues: (ref) v_u_7
				local v798 = v_u_7.Character
				if v798 then
					v798 = v798:FindFirstChild("HumanoidRootPart")
				end
				if not (v798 and v798:IsA("BasePart")) then
					v798 = nil
				end
				return v798 ~= nil
			end, 15, p_u_734)
			if v_u_16 == p_u_734 then
				v_u_693()
				local v799 = v_u_6
				if v799 then
					v799 = v_u_6.controllers.Vision
				end
				if not v799 or v799._broken then
					v799 = nil
				end
				if v799 and v799.setLoose then
					local v800 = v799.setLoose
					local v801 = v758 or v_u_52
					local v802 = { v_u_7.Character }
					pcall(v800, v801, v802)
				end
				local v803 = Instance.new("Highlight")
				v803.Name = "HideoutHover"
				v803.FillTransparency = 1
				v803.OutlineColor = v_u_9.color.accent
				v803.OutlineTransparency = 0.15
				v803.DepthMode = Enum.HighlightDepthMode.Occluded
				v803.Enabled = false
				v803.Parent = v748
				v_u_30 = v803
				local v804 = v_u_33
				local v805 = v_u_6.on
				local function v808(p806, p807)
					-- upvalues: (ref) v_u_21, (ref) v_u_17, (ref) v_u_8
					if v_u_21 and (v_u_17 and v_u_21.onHit(p806, p807)) then
						v_u_8.sound("tick")
					end
				end
				table.insert(v804, v805("weapon.hit", v808))
				local v809 = v_u_33
				local v810 = v_u_6.on
				local function v813()
					-- upvalues: (ref) v_u_7, (ref) v_u_21, (ref) v_u_18, (ref) v_u_14
					local v811 = v_u_7.Character
					if v811 then
						v811 = v811:FindFirstChild("HumanoidRootPart")
					end
					if not (v811 and v811:IsA("BasePart")) then
						v811 = nil
					end
					if v_u_21 and v811 then
						local v812 = v811.Position - v_u_18
						if v812.X < v_u_14.lane.x1 + 2 and v812.Z > v_u_14.lane.fenceZ1 - 6 then
							v_u_21.onShot()
						end
					end
				end
				table.insert(v809, v810("weapon.fired", v813))
				local v814 = v_u_6
				if v814 then
					v814 = v_u_6.controllers.Input
				end
				if not v814 or v814._broken then
					v814 = nil
				end
				if v814 and v814.bind then
					local v815 = v814.bind
					local function v816()
						-- upvalues: (ref) v_u_59, (ref) v_u_25, (ref) v_u_426, (ref) v_u_51, (ref) v_u_430, (ref) v_u_254
						if v_u_59.win and v_u_59.win.isOpen() then
							v_u_59.win.close()
							return
						elseif v_u_25 and v_u_25.isOpen() then
							v_u_25.close()
							return
						elseif v_u_426() or v_u_51 and v_u_51.Visible then
							v_u_430()
						else
							v_u_254()
						end
					end
					local v817, v818 = pcall(v815, "menu", v816)
					if v817 and type(v818) == "function" then
						local v819 = v_u_33
						table.insert(v819, v818)
					end
					local v820 = v814.bind
					local function v821()
						-- upvalues: (ref) v_u_17, (ref) v_u_59, (ref) v_u_51, (ref) v_u_430, (ref) v_u_25, (ref) v_u_458
						if v_u_17 and not (v_u_59.win and v_u_59.win.isOpen()) then
							if v_u_51 and v_u_51.Visible then
								v_u_430()
							elseif not (v_u_25 and v_u_25.isOpen()) then
								v_u_458()
							end
						else
							return
						end
					end
					local v822, v823 = pcall(v820, "inventory", v821)
					if v822 and type(v823) == "function" then
						local v824 = v_u_33
						table.insert(v824, v823)
					end
				end
				local v825 = v_u_32
				local v826 = v_u_3.InputBegan
				local function v837(p827, p828)
					-- upvalues: (ref) v_u_17, (ref) v_u_59, (ref) v_u_31, (ref) v_u_25, (ref) v_u_51, (ref) v_u_200, (ref) v_u_153, (ref) v_u_2, (ref) v_u_160, (ref) v_u_7, (ref) v_u_22
					if not p828 and v_u_17 then
						if p827.UserInputType == Enum.UserInputType.MouseButton1 or p827.UserInputType == Enum.UserInputType.Touch then
							local v829
							if v_u_59.win == nil then
								v829 = false
							else
								v829 = v_u_59.win.isOpen()
							end
							if v_u_31 and not (v_u_25 and v_u_25.isOpen()) and not (v_u_51 and v_u_51.Visible or v829) then
								local v830 = v_u_31
								if v830 == "terminal" then
									v_u_200(nil)
								else
									v_u_153(v830)
								end
							end
							if p827.UserInputType == Enum.UserInputType.Touch and not v829 then
								local v831 = v_u_2.CurrentCamera
								local v832
								if v831 then
									local v833 = v831:ScreenPointToRay(p827.Position.X, p827.Position.Y)
									v832 = v_u_2:Raycast(v833.Origin, v833.Direction * 600, (v_u_160()))
									if v832 then
										v832 = v832.Instance:GetAttribute("HideoutModule")
									end
								else
									v832 = nil
								end
								local v834 = v_u_7.Character
								if v834 then
									v834 = v834:FindFirstChild("HumanoidRootPart")
								end
								if not (v834 and v834:IsA("BasePart")) then
									v834 = nil
								end
								local v835
								if type(v832) == "string" then
									if v832 == "terminal" then
										if v_u_59.prop then
											v835 = v_u_59.prop.hitbox
										else
											v835 = nil
										end
									else
										local v836
										if v832 then
											v836 = v_u_22[v832]
										else
											v836 = v832
										end
										if v836 then
											v835 = v836.hitbox
										else
											v835 = nil
										end
									end
								else
									v835 = nil
								end
								if type(v832) == "string" and (v834 and (v835 and (v835.Position - v834.Position).Magnitude <= 40)) then
									if v832 == "terminal" then
										v_u_200(nil)
										return
									end
									v_u_153(v832)
								end
							end
						end
					end
				end
				table.insert(v825, v826:Connect(v837))
				v_u_7:SetAttribute("HideoutBuilt", true)
				local v_u_838 = v_u_6.lib.HideoutLightGuard
				local v_u_839 = v_u_838.new()
				v_u_728 = v_u_839
				task.spawn(function()
					-- upvalues: (ref) v_u_16, (copy) p_u_734, (ref) v_u_17, (copy) v_u_838, (ref) v_u_20, (copy) v_u_839, (ref) v_u_727
					while v_u_16 == p_u_734 and v_u_17 do
						task.wait(v_u_838.INTERVAL)
						local v840 = v_u_20
						if v_u_16 ~= p_u_734 or not (v_u_17 and (v840 and v840.tubes)) then
							continue
						end
						local v841 = v_u_838.step
						local v842 = v_u_839
						local v843 = os.clock()
						local v844 = v840.tubes
						local v845, v846, v847, v848 = pcall(v841, v842, v843, v844)
						if not v845 or (v846 ~= "fix" or v_u_839.reported) then
							continue
						end
						v_u_839.reported = true
						v_u_727(v847, v848)
					end
				end)
				v_u_42 = os.clock()
				v_u_6.emit("place.ready", "Hideout")
				task.delay(2.5, function()
					-- upvalues: (ref) v_u_16, (copy) p_u_734, (ref) v_u_17, (ref) v_u_10, (ref) v_u_23, (ref) v_u_8
					if v_u_16 == p_u_734 and v_u_17 then
						local v849 = nil
						for _, v850 in v_u_10.ORDER do
							local v851 = v_u_23 and v_u_23.modules
							if v851 then
								v851 = v_u_23.modules[v850]
							end
							if not (v851 and (v851.next and v851.next.canBuild)) then
								continue
							end
							local v852 = v_u_10
							if v852 then
								v852 = v_u_10.get(v850)
							end
							local v853
							if v852 then
								v853 = v852.name
							else
								v853 = string.upper(v850)
							end
							v849 = v853 .. " can be upgraded now."
						end
						if not v849 then
							local v854 = v_u_23 and v_u_23.modules
							if v854 then
								v854 = v_u_23.modules.generator
							end
							local v855
							if v854 then
								local v856 = v854.lvl
								v855 = tonumber(v856) or 0
							else
								v855 = 0
							end
							v849 = v855 <= 0 and "Bring fuel and wires from a raid to start the generator." or v849
						end
						local v857 = v849 or "Traders and tasks: the terminal by the radio, or the first row of the station list."
						if v_u_8 and v_u_8.toast then
							local v858 = v_u_8.toast
							pcall(v858, "HIDEOUT", "info", v857)
						end
					end
				end)
				v_u_6.log("HideoutWorld", "built at", v_u_18)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_5.enter() -- name: enter
	-- upvalues: (ref) v_u_15, (ref) v_u_6
	if v_u_15 == "Menu" then
		v_u_6.emit("transit.info", {
			["kind"] = "hideout"
		})
		v_u_6.net.fire("menu.op", {
			["op"] = "enterHideout"
		})
	end
end
v_u_254 = function()
	-- upvalues: (ref) v_u_15, (ref) v_u_41, (ref) v_u_42, (copy) v_u_48, (ref) v_u_25, (ref) v_u_8, (ref) v_u_6, (ref) v_u_16
	if v_u_15 == "Hideout" and (not v_u_41 and os.clock() - v_u_42 >= 1.5) then
		v_u_41 = true
		v_u_48(true)
		if v_u_25 then
			v_u_25.close()
		end
		v_u_8.sound("click")
		v_u_6.emit("transit.info", {
			["kind"] = "menu"
		})
		v_u_6.net.fire("menu.op", {
			["op"] = "leaveHideout"
		})
		local v_u_860 = v_u_16
		task.delay(4, function()
			-- upvalues: (ref) v_u_16, (copy) v_u_860, (ref) v_u_41, (ref) v_u_48
			if v_u_16 == v_u_860 and v_u_41 then
				v_u_41 = false
				v_u_48(false)
			end
		end)
	end
end
function v_u_5.leave() -- name: leave
	-- upvalues: (ref) v_u_254
	v_u_254()
end
function v_u_5.isBuilt() -- name: isBuilt
	-- upvalues: (ref) v_u_17
	return v_u_17
end
local function v_u_867(p861, _) -- name: onPlace
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (copy) v_u_715, (copy) v_u_859, (copy) v_u_7, (ref) v_u_6
	if p861 ~= v_u_15 or not v_u_17 and p861 == "Hideout" then
		v_u_15 = p861
		v_u_16 = v_u_16 + 1
		v_u_715()
		if p861 == "Hideout" then
			local v_u_862 = v_u_16
			task.spawn(function()
				-- upvalues: (ref) v_u_859, (copy) v_u_862, (ref) v_u_7, (ref) v_u_16, (ref) v_u_6
				local v863 = v_u_859
				local v864 = v_u_862
				local v865, v866 = pcall(v863, v864)
				if not v865 then
					warn("[HideoutWorld] build failed:", v866)
					v_u_7:SetAttribute("ClientError", "HideoutWorld build: " .. tostring(v866))
					if v_u_16 == v_u_862 then
						v_u_6.emit("place.ready", "Hideout")
					end
				end
			end)
		end
	end
end
function v_u_5.init(p_u_868) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_7, (copy) v_u_59, (ref) v_u_17, (ref) v_u_18, (ref) v_u_15, (copy) v_u_22, (ref) v_u_36, (ref) v_u_25, (ref) v_u_19, (ref) v_u_23, (ref) v_u_153, (copy) v_u_5, (ref) v_u_254, (ref) v_u_20, (ref) v_u_728, (copy) v_u_87, (copy) v_u_688, (ref) v_u_21, (ref) v_u_200, (ref) v_u_40, (copy) v_u_430, (copy) v_u_458, (copy) v_u_426, (ref) v_u_55, (ref) v_u_54, (ref) v_u_53, (ref) v_u_51, (ref) v_u_26, (copy) v_u_390, (ref) v_u_39, (ref) v_u_38, (copy) v_u_270, (ref) v_u_24, (ref) v_u_35, (ref) v_u_34, (ref) v_u_41, (copy) v_u_48
	v_u_6 = p_u_868
	v_u_8 = p_u_868.lib.HushUI
	v_u_8.bind(p_u_868)
	v_u_9 = p_u_868.shared.Theme
	v_u_10 = p_u_868.shared.HideoutModules
	v_u_11 = p_u_868.shared.HideoutWhy
	v_u_12 = p_u_868.shared.Assets
	local v869 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Fallbacks")
	v_u_13 = require((v869:WaitForChild("Hideout")))
	v_u_14 = v_u_13.LAYOUT
	v_u_7:SetAttribute("HideoutBuilt", false)
	v_u_7:SetAttribute("HideoutPanel", "")
	v_u_7:SetAttribute("HideoutTerminal", "")
	p_u_868.command("vhs.open", function(p870)
		-- upvalues: (copy) p_u_868
		local v871 = p_u_868.lib.VhsPlayer.open(p_u_868, {
			["tape"] = p870[1] ~= "free" and p870[1] or p870[2],
			["station"] = p870[1] ~= "free"
		})
		return "open=" .. tostring(v871) .. " " .. game:GetService("HttpService"):JSONEncode(p_u_868.lib.VhsPlayer.state())
	end)
	p_u_868.command("vhs.state", function()
		-- upvalues: (copy) p_u_868
		return game:GetService("HttpService"):JSONEncode(p_u_868.lib.VhsPlayer.state())
	end)
	p_u_868.command("vhs.close", function()
		-- upvalues: (copy) p_u_868
		p_u_868.lib.VhsPlayer.close()
		return "closed"
	end)
	p_u_868.command("vhs.station", function()
		-- upvalues: (copy) p_u_868
		p_u_868.lib.VhsStation.trigger()
		return "triggered"
	end)
	p_u_868.command("hideout.door", function(p872)
		-- upvalues: (ref) v_u_59, (ref) v_u_17, (ref) v_u_7, (ref) v_u_18
		local v_u_873 = v_u_59.door
		if not (v_u_873 and v_u_873.Parent) then
			local v874 = v_u_17
			return "no door prompt (built=" .. tostring(v874) .. ")"
		end
		local v875 = v_u_873.Parent.WorldPosition
		local v876 = v_u_7.Character
		if v876 then
			v876 = v876:FindFirstChild("HumanoidRootPart")
		end
		if not (v876 and v876:IsA("BasePart")) then
			v876 = nil
		end
		local v877
		if v876 then
			local v878 = v876.Position.X
			local v879 = v876.Position.Z
			local v880 = Vector3.new(v878, 0, v879)
			local v881 = v875.X
			local v882 = v875.Z
			v877 = (v880 - Vector3.new(v881, 0, v882)).Magnitude
		else
			v877 = -1
		end
		if p872 and p872[1] == "use" then
			v_u_873:InputHoldBegin()
			task.delay(v_u_873.HoldDuration + 0.15, function()
				-- upvalues: (copy) v_u_873
				v_u_873:InputHoldEnd()
			end)
		end
		local v883 = string.format
		local v884 = v_u_873.ActionText
		local v885 = v_u_873.ObjectText
		local v886 = v875.X
		local v887 = v875.Y
		local v888 = v875.Z
		local v889 = v875.X - v_u_18.X
		local v890 = v875.Z - v_u_18.Z
		local v891 = v_u_873.MaxActivationDistance
		local v892 = v_u_873.HoldDuration
		local v893 = v_u_873.Enabled
		return v883("action=%s object=%s at=%.1f,%.1f,%.1f rel=%.1f,%.1f dist=%.1f max=%.1f hold=%.1f enabled=%s", v884, v885, v886, v887, v888, v889, v890, v877, v891, v892, (tostring(v893)))
	end)
	p_u_868.command("hideout.state", function()
		-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_18, (ref) v_u_10, (ref) v_u_22, (ref) v_u_36, (ref) v_u_25, (ref) v_u_19, (ref) v_u_23
		local v894 = {}
		local v895 = v_u_17
		local v896 = v_u_18
		__set_list(v894, 1, {("place=%s built=%s origin=%s"):format(v_u_15, tostring(v895), (tostring(v896)))})
		for _, v897 in v_u_10.ORDER do
			local v898 = v_u_22[v897]
			local v899 = "%s=%s"
			local v900
			if v898 then
				local v901 = v898.lvl
				v900 = tostring(v901)
			else
				v900 = "-"
			end
			table.insert(v894, v899:format(v897, v900))
		end
		local v902 = v_u_36
		local v903 = "light=" .. tostring(v902)
		table.insert(v894, v903)
		local v904 = "panel="
		local v905 = v_u_25
		if v905 then
			v905 = v_u_25.module()
		end
		local v906 = v904 .. tostring(v905)
		table.insert(v894, v906)
		local v907 = 0
		if v_u_19 then
			for _, v908 in v_u_19:GetDescendants() do
				if not v908:IsA("BasePart") then
					continue
				end
				v907 = v907 + 1
			end
		end
		local v909 = "parts=" .. v907
		table.insert(v894, v909)
		if v_u_23 and v_u_23.offline then
			table.insert(v894, "OFFLINE-VIEW")
		end
		return table.concat(v894, " ")
	end)
	p_u_868.command("hideout.open", function(p910)
		-- upvalues: (ref) v_u_10, (ref) v_u_153, (ref) v_u_25
		local v911 = p910[1] or "workbench"
		if not v_u_10.get(v911) then
			return "unknown module " .. v911
		end
		v_u_153(v911)
		local v912 = "open "
		local v913 = " -> "
		local v914 = v_u_25
		if v914 then
			v914 = v_u_25.isOpen()
		end
		return v912 .. v911 .. v913 .. tostring(v914)
	end)
	p_u_868.command("hideout.close", function()
		-- upvalues: (ref) v_u_5
		v_u_5.closePanel()
		return "closed"
	end)
	p_u_868.command("hideout.leave", function()
		-- upvalues: (ref) v_u_254
		v_u_254()
		return "leaving"
	end)
	p_u_868.command("hideout.enter", function()
		-- upvalues: (ref) v_u_5
		v_u_5.enter()
		return "requested"
	end)
	p_u_868.command("hideout.tubes", function()
		-- upvalues: (ref) v_u_20, (ref) v_u_6, (ref) v_u_728, (ref) v_u_7
		if not v_u_20 then
			return "no room"
		end
		local v915, v916 = v_u_6.lib.HideoutLightGuard.lit(v_u_20.tubes)
		local v917 = "tubes %d/%d fixes=%d reported=%s atmoLamps=%s stage=%s level=%s"
		local v918 = not v_u_728 and -1 or v_u_728.fixes
		local v919
		if v_u_728 == nil then
			v919 = false
		else
			v919 = v_u_728.reported
		end
		local v920 = v_u_7
		local v921 = v_u_7
		local v922 = v_u_7
		return v917:format(v915, v916, v918, tostring(v919), tostring(v920:GetAttribute("AtmoLamps")), tostring(v921:GetAttribute("CrateStageOn")), (tostring(v922:GetAttribute("HideoutLight"))))
	end)
	p_u_868.command("hideout.light", function(p923)
		-- upvalues: (ref) v_u_20
		if not v_u_20 then
			return "no room"
		end
		local v924 = p923[1]
		local v925 = tonumber(v924) or 0
		local v926 = math.floor(v925)
		local v927 = math.clamp(v926, 0, 3)
		v_u_20.setLightLevel(v927, p923[2] ~= "norange")
		return "light level " .. v927
	end)
	p_u_868.command("hideout.refresh", function()
		-- upvalues: (ref) v_u_87, (ref) v_u_688
		local v928 = v_u_87()
		if not v928 then
			return "fetch failed"
		end
		v_u_688(v928)
		return "ok"
	end)
	p_u_868.command("hideout.range", function()
		-- upvalues: (ref) v_u_21
		if not v_u_21 then
			return "no range"
		end
		local v929 = v_u_21.stats()
		return ("shots=%d hits=%d acc=%d score=%d head=%d targets=%d"):format(v929.shots, v929.hits, v929.accuracy, v929.score, v929.head, #v_u_21.targets())
	end)
	p_u_868.command("hideout.hit", function(p930)
		-- upvalues: (ref) v_u_21, (ref) v_u_17, (ref) v_u_8
		if not v_u_21 then
			return "no range"
		end
		local v931 = p930[1] or "10"
		for _, v932 in v_u_21.targets() do
			if v932.Name ~= "Target_" .. v931 then
				continue
			end
			local v933 = v932:FindFirstChild("Face", true)
			if not (v933 and v933:IsA("BasePart")) then
				continue
			end
			local v934 = v933.Position + (p930[2] ~= "head" and Vector3.new(0, 0, 0) or v933.CFrame.UpVector * v933.Size.Y * 0.33)
			v_u_21.onShot()
			if v_u_21 and (v_u_17 and v_u_21.onHit(v933, v934)) then
				v_u_8.sound("tick")
			end
			local v935 = v_u_21.stats()
			return ("hit %s score=%d total=%d"):format(v931, v935.last, v935.score)
		end
		return "no target " .. v931
	end)
	p_u_868.command("hideout.terminal", function(p936)
		-- upvalues: (ref) v_u_59, (ref) v_u_200, (ref) v_u_40, (ref) v_u_7
		local v937 = p936[1] or "traders"
		if v937 == "close" then
			if v_u_59.win then
				v_u_59.win.close()
			end
		elseif v937 ~= "state" then
			v_u_200(v937)
		end
		local v938 = v_u_59.win
		local v939 = "terminal open=%s tab=%s prop=%s row=%s locked=%s attr=%s"
		local v940
		if v938 == nil then
			v940 = false
		else
			v940 = v938.isOpen()
		end
		local v941 = tostring(v940)
		if v938 then
			v938 = v938.tab()
		end
		local v942 = tostring(v938)
		local v943 = v_u_59.prop ~= nil
		local v944 = tostring(v943)
		local v945 = v_u_59.row ~= nil
		local v946 = v_u_40
		local v947 = v_u_7
		return v939:format(v941, v942, v944, tostring(v945), tostring(v946), (tostring(v947:GetAttribute("HideoutTerminal"))))
	end)
	p_u_868.command("hideout.tp", function(p948)
		-- upvalues: (ref) v_u_59, (ref) v_u_22, (ref) v_u_7, (ref) v_u_18
		local v949 = p948[1] or "workbench"
		local v950
		if v949 == "terminal" then
			if v_u_59.prop then
				v950 = v_u_59.prop.hitbox
			else
				v950 = nil
			end
		else
			local v951
			if v949 then
				v951 = v_u_22[v949]
			else
				v951 = v949
			end
			if v951 then
				v950 = v951.hitbox
			else
				v950 = nil
			end
		end
		local v952 = v_u_7.Character
		if v952 then
			v952 = v952:FindFirstChild("HumanoidRootPart")
		end
		if not (v952 and v952:IsA("BasePart")) then
			v952 = nil
		end
		if not (v950 and v952) then
			return "no station/character"
		end
		local v953 = v950.CFrame * CFrame.new(0, 0, -(v950.Size.Z / 2 + 3))
		v952.CFrame = CFrame.new(v953.Position.X, v_u_18.Y + 3.2, v953.Position.Z)
		return "moved to " .. v949
	end)
	p_u_868.command("hideout.stash", function(p954)
		-- upvalues: (ref) v_u_430, (ref) v_u_458, (ref) v_u_426
		if p954 and p954[1] == "close" then
			v_u_430()
		else
			v_u_458()
		end
		local v955 = v_u_426()
		return "stash open=" .. tostring(v955)
	end)
	p_u_868.command("hideout.bench", function(p956)
		-- upvalues: (ref) v_u_25
		if not (v_u_25 and v_u_25.isOpen()) then
			return "no station window open"
		end
		v_u_25.bench(p956 and (p956[1] or "craft") or "craft")
		local v957 = p956 and p956[1] or "craft"
		return "bench tab " .. tostring(v957)
	end)
	p_u_868.command("hideout.list", function(p958)
		-- upvalues: (ref) v_u_55, (ref) v_u_54, (ref) v_u_53
		if p958 then
			p958 = p958[1] == "close"
		end
		local v959 = not p958
		v_u_55 = v959
		local v960 = v_u_54
		if v960 then
			v960.Visible = v959 or not v_u_53
		end
		local v961 = v_u_55
		local v962 = v_u_53
		return "list open=" .. tostring(v961) .. " compact=" .. tostring(v962)
	end)
	p_u_868.on("inventory.padBack", function()
		-- upvalues: (ref) v_u_17, (ref) v_u_15, (ref) v_u_51, (ref) v_u_25, (ref) v_u_59, (ref) v_u_26, (ref) v_u_430
		if v_u_17 and (v_u_15 == "Hideout" and (v_u_51 and v_u_51.Visible)) then
			if not (v_u_25 and v_u_25.isOpen() or v_u_59.win and v_u_59.win.isOpen()) then
				local v963 = v_u_26 and v_u_26.Parent
				if v963 then
					v963 = v_u_26.Parent:FindFirstChild("HushModal")
				end
				if v963 and (v963:IsA("ScreenGui") and v963.Enabled) then
					for _, v964 in v963:GetChildren() do
						if v964.Name ~= "Modal" or not (v964:IsA("GuiObject") and v964.Visible) then
							continue
						end
						return
					end
				end
				v_u_430()
			end
		else
			return
		end
	end)
	p_u_868.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_17, (ref) v_u_15, (ref) v_u_25, (ref) v_u_7, (ref) v_u_390, (ref) v_u_153, (ref) v_u_39, (ref) v_u_426, (ref) v_u_38, (ref) v_u_51, (ref) v_u_458, (ref) v_u_59, (ref) v_u_270, (ref) v_u_26
		if v_u_17 and v_u_15 == "Hideout" then
			local v965
			if v_u_25 and v_u_25.isOpen() then
				v965 = v_u_25.module()
			else
				v965 = nil
			end
			if v_u_25 then
				local v966 = v_u_25.destroy
				pcall(v966)
				v_u_25 = nil
				v_u_7:SetAttribute("HideoutPanel", "")
			end
			v_u_390()
			if v965 then
				v_u_153(v965)
			end
			if v_u_39 then
				local v967 = v_u_426()
				local v968 = v_u_38
				if type(v968) == "table" and v_u_38.destroy then
					local v969 = v_u_38.destroy
					pcall(v969)
				end
				v_u_38 = nil
				v_u_39:Destroy()
				v_u_39 = nil
				v_u_51 = nil
				if v967 then
					v_u_458()
				end
			end
			if v_u_59.win then
				local v970 = v_u_59.win.rebuild
				pcall(v970)
				v_u_270()
				local v971 = v_u_26
				if v971 and v_u_59.win.isOpen() then
					v971.Enabled = false
				end
			end
		end
	end)
	v_u_7:GetAttributeChangedSignal("TransitTo"):Connect(function()
		-- upvalues: (ref) v_u_7, (copy) p_u_868, (ref) v_u_15
		local v972 = v_u_7:GetAttribute("TransitTo")
		if v972 == "Hideout" then
			p_u_868.emit("transit.info", {
				["kind"] = "hideout"
			})
		elseif v972 == "Menu" and v_u_15 == "Hideout" then
			p_u_868.emit("transit.info", {
				["kind"] = "menu"
			})
		end
	end)
	p_u_868.net.listen("menu.state", function(p973)
		-- upvalues: (ref) v_u_24, (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
		if type(p973) == "table" then
			local v974 = p973.profile
			if type(v974) == "table" then
				v_u_24 = p973.profile
			end
		end
		if not v_u_35 then
			if v_u_15 ~= "Hideout" then
				return
			end
			v_u_35 = true
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
				v_u_35 = false
				if v_u_15 == "Hideout" then
					v_u_34 = v_u_34 + 1
					local v975 = v_u_34
					local v976 = v_u_87()
					if v976 and (v975 == v_u_34 and v_u_15 == "Hideout") then
						v_u_688(v976)
					end
				end
			end)
		end
	end)
	p_u_868.net.listen("menu.result", function(p977)
		-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_35, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688, (ref) v_u_41, (ref) v_u_48
		if type(p977) == "table" and v_u_15 == "Hideout" then
			local v978 = p977.op
			if v978 == "hideoutBuild" or (v978 == "craft" or (v978 == "hideoutCollect" or (v978 == "repair" or (v978 == "dismantle" or (v978 == "enterHideout" or (v978 == "leaveHideout" or (v978 == "tryWeapon" or v978 == "ownWeapons"))))))) then
				if p977.msg and p977.msg ~= "" then
					local v979 = p977.msg
					local v980 = tostring(v979)
					local v981 = p977.ok and "success" or "danger"
					if v_u_8 and v_u_8.toast then
						local v982 = v_u_8.toast
						pcall(v982, v980, v981 or "info", nil)
					end
				end
				if p977.ok then
					if v978 == "hideoutBuild" or v978 == "hideoutCollect" then
						v_u_8.sound("unlock")
					end
				else
					v_u_8.sound("error")
				end
				if not v_u_35 and v_u_15 == "Hideout" then
					v_u_35 = true
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
						v_u_35 = false
						if v_u_15 == "Hideout" then
							v_u_34 = v_u_34 + 1
							local v983 = v_u_34
							local v984 = v_u_87()
							if v984 and (v983 == v_u_34 and v_u_15 == "Hideout") then
								v_u_688(v984)
							end
						end
					end)
				end
			end
			if v978 == "leaveHideout" and not p977.ok then
				v_u_41 = false
				v_u_48(false)
			end
		end
	end)
end
function v_u_5.start() -- name: start
	-- upvalues: (ref) v_u_6, (copy) v_u_867
	v_u_6.session.onPlaceChanged(v_u_867)
end
local v_u_985 = 0
local v_u_986 = 0
local v_u_987 = 8
function v_u_5.step(p988) -- name: step
	-- upvalues: (ref) v_u_17, (ref) v_u_21, (ref) v_u_25, (copy) v_u_59, (ref) v_u_51, (ref) v_u_38, (copy) v_u_426, (copy) v_u_430, (ref) v_u_40, (copy) v_u_82, (ref) v_u_985, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_165, (copy) v_u_160, (copy) v_u_22, (ref) v_u_6, (ref) v_u_31, (ref) v_u_30, (ref) v_u_8, (ref) v_u_987, (ref) v_u_986, (ref) v_u_9, (ref) v_u_53, (copy) v_u_390, (copy) v_u_61, (copy) v_u_76, (copy) v_u_28, (copy) v_u_253, (copy) v_u_412, (ref) v_u_23, (ref) v_u_689, (ref) v_u_11, (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (copy) v_u_87, (copy) v_u_688
	if v_u_17 then
		if v_u_21 then
			v_u_21.step(p988)
		end
		if v_u_25 then
			v_u_25.step(p988)
		end
		local v989
		if v_u_59.win == nil then
			v989 = false
		else
			v989 = v_u_59.win.isOpen()
		end
		if v989 then
			v_u_59.win.step(p988)
		end
		if v_u_51 and (v_u_51.Visible and (v_u_38 and not v_u_426())) then
			v_u_430()
		elseif v_u_40 and not (v_u_25 and v_u_25.isOpen()) and not (v_u_51 and v_u_51.Visible or v989) then
			v_u_82(false)
		end
		v_u_985 = v_u_985 + p988
		if v_u_985 >= 0.08 then
			v_u_985 = 0
			local v990 = nil
			local v991 = v_u_2.CurrentCamera
			local v992 = v_u_7.Character
			local v993 = v992
			if v993 then
				v993 = v992:FindFirstChild("HumanoidRootPart")
			end
			if not (v993 and v993:IsA("BasePart")) then
				v993 = nil
			end
			local v994
			if v991 and (v993 and (not v_u_40 and (v_u_3.MouseEnabled and not v_u_165()))) then
				local v995 = v_u_3:GetMouseLocation()
				local v996 = v991:ViewportPointToRay(v995.X, v995.Y)
				local v997 = v_u_2:Raycast(v996.Origin, v996.Direction * 600, (v_u_160()))
				v994 = v997
				if v994 then
					v994 = v997.Instance:GetAttribute("HideoutModule")
				end
				local v998
				if type(v994) == "string" then
					if v994 == "terminal" then
						if v_u_59.prop then
							v998 = v_u_59.prop.hitbox
						else
							v998 = nil
						end
					else
						local v999
						if v994 then
							v999 = v_u_22[v994]
						else
							v999 = v994
						end
						if v999 then
							v998 = v999.hitbox
						else
							v998 = nil
						end
					end
				else
					v998 = nil
				end
				if type(v994) == "string" and v998 then
					if (v998.Position - v993.Position).Magnitude > 40 then
						v994 = v990
					end
				else
					v994 = v990
				end
			else
				v994 = v990
			end
			local v_u_1000 = true
			local function v1001()
				-- upvalues: (ref) v_u_1000, (ref) v_u_6, (ref) v_u_7
				v_u_1000 = v_u_6.lib.HideUiRules.outlinesOn(v_u_7:GetAttribute("ObjectOutlines"), v_u_7:GetAttribute("UiHidden")) == true
			end
			pcall(v1001)
			if v994 == v_u_31 then
				if v_u_30 and v_u_31 ~= nil then
					local v1002
					if v_u_30.Adornee == nil then
						v1002 = false
					else
						v1002 = v_u_1000
					end
					if v_u_30.Enabled ~= v1002 then
						v_u_30.Enabled = v1002
					end
				end
			else
				v_u_31 = v994
				local v1003 = v_u_30
				if v1003 then
					local v1004
					if v994 then
						v1004 = v_u_22[v994]
					else
						v1004 = v994
					end
					local v1005
					if v1004 then
						v1005 = v1004.model
					elseif v994 == "terminal" and v_u_59.prop then
						v1005 = v_u_59.prop.model
					else
						v1005 = nil
					end
					v1003.Adornee = v1005
					local v1006
					if v1005 == nil then
						v1006 = false
					else
						v1006 = v_u_1000
					end
					v1003.Enabled = v1006
					if v1005 then
						v_u_8.sound("hover")
					end
				end
			end
		end
		v_u_987 = v_u_987 - p988
		if v_u_987 <= 0 then
			v_u_987 = 14 + math.random() * 26
			local v1007 = v_u_22.radio
			local v1008 = v_u_6
			if v1008 then
				v1008 = v_u_6.controllers.Audio
			end
			if not v1008 or v1008._broken then
				v1008 = nil
			end
			if v1007 and (v1007.lvl > 0 and (v1008 and v1008.play3D)) then
				local v1009 = v1008.play3D
				local v1010 = v1007.hitbox.Position
				pcall(v1009, "ev_radio_burst", v1010, {
					["volume"] = 0.35
				})
			end
		end
		v_u_986 = v_u_986 + p988
		if v_u_986 >= 0.5 then
			v_u_986 = 0
			if v_u_6.lib.HideoutPanel.compact(v_u_9) == v_u_53 then
				if v_u_61.touch and not (v_u_53 or v_u_25 and v_u_25.isOpen()) and not (v_u_59.win and v_u_59.win.isOpen() or v_u_51 and v_u_51.Visible) then
					local v1011 = v_u_76()
					local v1012 = v_u_61.used
					if v1011 and (v1012 == nil or (v1011.left ~= v1012.left or (v1011.right ~= v1012.right or v1011.bottom ~= v1012.bottom))) then
						if v_u_25 then
							local v1013 = v_u_25.destroy
							pcall(v1013)
							v_u_25 = nil
							v_u_7:SetAttribute("HideoutPanel", "")
						end
						v_u_390()
					end
				end
			else
				if v_u_25 then
					local v1014 = v_u_25.destroy
					pcall(v1014)
					v_u_25 = nil
					v_u_7:SetAttribute("HideoutPanel", "")
				end
				v_u_390()
			end
			for v1015, v1016 in v_u_28 do
				v_u_253(v1016, v1015)
			end
			v_u_412()
			if v_u_23 and (v_u_23.offline == true and v_u_689 <= os.clock()) then
				v_u_689 = os.clock() + v_u_11.RETRY_EVERY
				if not v_u_35 and v_u_15 == "Hideout" then
					v_u_35 = true
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
						v_u_35 = false
						if v_u_15 == "Hideout" then
							v_u_34 = v_u_34 + 1
							local v1017 = v_u_34
							local v1018 = v_u_87()
							if v1018 and (v1017 == v_u_34 and v_u_15 == "Hideout") then
								v_u_688(v1018)
							end
						end
					end)
				end
			end
			if v_u_23 and v_u_23.modules then
				local v1019 = os.time() + (v_u_23.offset or 0)
				for _, v1020 in v_u_23.modules do
					if not v1020.building or (not v1020.building.untilAt or v1020.building.untilAt + 6 > v1019) then
						continue
					end
					if not v_u_35 then
						if v_u_15 == "Hideout" then
							v_u_35 = true
							task.delay(0.3, function()
								-- upvalues: (ref) v_u_35, (ref) v_u_15, (ref) v_u_34, (ref) v_u_87, (ref) v_u_688
								v_u_35 = false
								if v_u_15 == "Hideout" then
									v_u_34 = v_u_34 + 1
									local v1021 = v_u_34
									local v1022 = v_u_87()
									if v1022 and (v1021 == v_u_34 and v_u_15 == "Hideout") then
										v_u_688(v1022)
									end
								end
							end)
						end
					end
					return
				end
			end
		end
	end
end
return v_u_5