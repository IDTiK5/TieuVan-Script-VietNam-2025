-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntRagdoll

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("PhysicsService")
local v_u_3 = {
	["SPEED"] = 38,
	["LIFT"] = 14,
	["FREEZE_AFTER"] = 2.5,
	["MAX_SIM"] = 3,
	["MAX_COPIES"] = 12,
	["GROUPS"] = { "HuntRagdoll", "HushSurvivor" },
	["PATH_TIME"] = 0.55,
	["PATH_ARC"] = 1.5,
	["WALL_GAP"] = 1,
	["IMPACT_DROP"] = 16,
	["IMPACT_FRAC"] = 0.45,
	["IMPACT_MIN"] = 4,
	["WALL_LOOK"] = 2.5,
	["WALL_SLOW"] = 0.6,
	["SHAKE_RADIUS"] = 25,
	["MAX_AGE"] = 600
}
local v_u_4 = {}
local v_u_5 = {
	["made"] = 0,
	["joints"] = 0,
	["path"] = 0,
	["refused"] = 0,
	["impacts"] = 0
}
local v_u_6 = false
local v_u_7 = nil
local v_u_8 = nil
function v_u_3.cleanPower(p9) -- name: cleanPower
	local v10 = (type(p9) ~= "number" or p9 ~= p9) and 0.4 or p9
	return math.clamp(v10, 0.4, 1)
end
function v_u_3.cleanDir(p11) -- name: cleanDir
	if typeof(p11) == "Vector3" then
		local v12 = p11.X
		local v13 = p11.Z
		local v14 = Vector3.new(v12, 0, v13)
		if v14.Magnitude == v14.Magnitude and (v14.Magnitude > 0.001 and v14.Magnitude < 1000000) then
			return v14.Unit
		end
	end
	return Vector3.new(0, 0, -1)
end
function v_u_3.velocity(p15, p16) -- name: velocity
	-- upvalues: (copy) v_u_3
	local v17 = v_u_3.cleanPower(p16)
	local v18 = v_u_3.cleanDir(p15) * (v_u_3.SPEED * v17)
	local v19 = v_u_3.LIFT * v17
	return v18 + Vector3.new(0, v19, 0)
end
function v_u_3.distOfPower(p20) -- name: distOfPower
	-- upvalues: (copy) v_u_3
	local v21 = (1 - v_u_3.cleanPower(p20)) / 0.075
	return math.clamp(v21, 0, 8)
end
function v_u_3.fallbackDistance(p22) -- name: fallbackDistance
	local v23 = 12 - p22 * 0.875
	return math.clamp(v23, 5, 12)
end
function v_u_3.mode(p24, p25) -- name: mode
	return p24 >= 3 and p25 >= 4 and "joints" or "path"
end
local function v_u_29() -- name: folder
	-- upvalues: (ref) v_u_8
	local v26 = v_u_8
	if v26 and v26.Parent then
		return v26
	end
	local v27 = workspace:FindFirstChild("HushLocal")
	if not v27 then
		v27 = Instance.new("Folder")
		v27.Name = "HushLocal"
		v27.Parent = workspace
	end
	local v28 = v27:FindFirstChild("HuntRagdolls")
	if not v28 then
		v28 = Instance.new("Folder")
		v28.Name = "HuntRagdolls"
		v28.Parent = v27
	end
	v_u_8 = v28
	return v_u_8
end
local function v_u_34() -- name: pickGroup
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_2, (copy) v_u_3
	if v_u_6 and (v_u_7 ~= nil and v_u_2:IsCollisionGroupRegistered(v_u_7)) then
		return v_u_7
	end
	for _, v_u_30 in v_u_3.GROUPS do
		local function v31()
			-- upvalues: (ref) v_u_2, (copy) v_u_30
			return v_u_2:IsCollisionGroupRegistered(v_u_30)
		end
		local v32, v33 = pcall(v31)
		if not (v32 and v33) then
			continue
		end
		v_u_6 = true
		v_u_7 = v_u_30
		return v_u_30
	end
	return nil
end
local function v_u_40(p35) -- name: sourceOf
	-- upvalues: (copy) v_u_1
	local v36 = p35.uid
	if type(v36) == "number" then
		local v37 = v_u_1:GetPlayerByUserId(p35.uid)
		if v37 then
			v37 = v37.Character
		end
		if v37 and v37.Parent then
			return v37
		else
			return nil
		end
	else
		local v38 = p35.dummy
		if type(v38) == "string" then
			local v39 = workspace:FindFirstChild("HuntDummies")
			if v39 then
				v39 = v39:FindFirstChild(p35.dummy)
			end
			if v39 and v39:IsA("Model") then
				return v39
			end
		end
		return nil
	end
end
local function v_u_44(p41) -- name: strip
	for _, v42 in p41:GetDescendants() do
		if not (v42:IsA("LuaSourceContainer") or (v42:IsA("BillboardGui") or (v42:IsA("SurfaceGui") or (v42:IsA("Light") or (v42:IsA("Highlight") or (v42:IsA("ForceField") or (v42:IsA("Sound") or (v42:IsA("ParticleEmitter") or (v42:IsA("Beam") or (v42:IsA("Trail") or (v42:IsA("ProximityPrompt") or (v42:IsA("Fire") or (v42:IsA("Smoke") or v42:IsA("Sparkles")))))))))))))) then
			continue
		end
		v42:Destroy()
	end
	local v_u_43 = p41:FindFirstChildOfClass("Humanoid")
	if v_u_43 then
		v_u_43.EvaluateStateMachine = false
		v_u_43.BreakJointsOnDeath = false
		v_u_43.RequiresNeck = false
		v_u_43.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v_u_43.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		pcall(function()
			-- upvalues: (copy) v_u_43
			v_u_43:ChangeState(Enum.HumanoidStateType.Physics)
		end)
	end
end
local function v_u_48(p45, p46) -- name: setParts
	for _, v47 in p45:GetDescendants() do
		if not v47:IsA("BasePart") then
			continue
		end
		p46(v47)
	end
end
local function v_u_52(p49, p50) -- name: insideWeapon
	local v51 = p49.Parent
	while v51 and v51 ~= p50 do
		if v51.Name == "HeldWeapon" or (v51:IsA("Tool") or v51:IsA("Accessory")) then
			return true
		end
		v51 = v51.Parent
	end
	return false
end
local function v_u_66(p53) -- name: makeJoints
	-- upvalues: (copy) v_u_52
	local v54 = {}
	for _, v55 in p53:GetDescendants() do
		if not v55:IsA("Motor6D") then
			continue
		end
		table.insert(v54, v55)
	end
	local v56 = 0
	for _, v57 in v54 do
		local v58 = v57.Part0
		local v59 = v57.Part1
		if v58 and v59 then
			if v_u_52(v57, p53) or v_u_52(v59, p53) then
				local v60 = Instance.new("WeldConstraint")
				v60.Part0 = v58
				v60.Part1 = v59
				v60.Parent = v59
			else
				local v61 = Instance.new("Attachment")
				v61.Name = "HuntRagA"
				v61.CFrame = v57.C0
				v61.Parent = v58
				local v62 = Instance.new("Attachment")
				v62.Name = "HuntRagB"
				v62.CFrame = v57.C1
				v62.Parent = v59
				local v63 = Instance.new("BallSocketConstraint")
				v63.Name = "HuntRagJoint"
				v63.Attachment0 = v61
				v63.Attachment1 = v62
				v63.LimitsEnabled = true
				v63.TwistLimitsEnabled = true
				local v64 = string.lower(v59.Name)
				local v65 = string.find(v64, "head", 1, true) ~= nil
				v63.UpperAngle = v65 and 35 or 55
				v63.TwistLowerAngle = v65 and -30 or -40
				v63.TwistUpperAngle = v65 and 30 or 40
				v63.Parent = v58
				v56 = v56 + 1
			end
		end
		v57:Destroy()
	end
	return v56
end
local function v_u_77(p_u_67, p_u_68) -- name: impactFx
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_29, (copy) v_u_3
	local v69 = v_u_5
	v69.impacts = v69.impacts + 1
	local v70 = v_u_1.LocalPlayer.Character
	if v70 then
		v70 = v70:FindFirstChild("HumanoidRootPart")
	end
	local v_u_71 = not v70 and (1 / 0) or (v70.Position - p_u_67).Magnitude
	local v_u_72 = Instance.new("Part")
	v_u_72.Name = "HuntDust"
	v_u_72.Anchored = true
	v_u_72.CanCollide = false
	v_u_72.CanQuery = false
	v_u_72.CanTouch = false
	v_u_72.Transparency = 1
	v_u_72.Size = Vector3.new(0.5, 0.5, 0.5)
	v_u_72.CFrame = CFrame.new(p_u_67)
	v_u_72.Parent = v_u_29()
	local v73 = Instance.new("ParticleEmitter")
	v73.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v73.Color = ColorSequence.new(Color3.fromRGB(150, 140, 126))
	v73.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
	v73.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.8), NumberSequenceKeypoint.new(1, 3.2) })
	v73.Lifetime = NumberRange.new(0.5, 1)
	v73.Speed = NumberRange.new(3, 7)
	v73.SpreadAngle = Vector2.new(180, 180)
	v73.Rate = 0
	v73.LightEmission = 0
	v73.Parent = v_u_72
	v73:Emit(10)
	task.delay(1.6, function()
		-- upvalues: (copy) v_u_72
		v_u_72:Destroy()
	end)
	local function v76()
		-- upvalues: (ref) v_u_3, (copy) p_u_67, (copy) v_u_71, (copy) p_u_68
		local v74 = v_u_3._ctx
		if v74 then
			v74 = v_u_3._ctx.controllers
		end
		local v75
		if v74 then
			v75 = v74.Audio
		else
			v75 = v74
		end
		if v75 and v75.play3D then
			v75.play3D("impact_wall", p_u_67, {
				["volume"] = 0.9,
				["pitch"] = 0.8
			})
		end
		if v_u_71 <= v_u_3.SHAKE_RADIUS then
			if v74 then
				v74 = v74.Camera
			end
			if v74 and v74.shake then
				v74.shake(0.16 + p_u_68 * 0.16 * (1 - v_u_71 / v_u_3.SHAKE_RADIUS), 0.3)
			end
		end
	end
	pcall(v76)
end
v_u_3._ctx = nil
local function v_u_97(p78, p79, p80, _, p81) -- name: startPath
	-- upvalues: (copy) v_u_3, (copy) v_u_29, (copy) v_u_48, (copy) v_u_1, (copy) v_u_4, (copy) v_u_5
	local v82 = v_u_3.fallbackDistance(p81)
	p78.Parent = v_u_29()
	v_u_48(p78, function(p83)
		p83.Anchored = true
		p83.CanCollide = false
		p83.CanQuery = false
		p83.CanTouch = false
	end)
	local v84 = p79.Position
	local v85 = v84 + p80 * v82
	local v86 = RaycastParams.new()
	v86.FilterType = Enum.RaycastFilterType.Exclude
	local v87 = { p78, (v_u_29()) }
	for _, v88 in v_u_1:GetPlayers() do
		if not v88.Character then
			continue
		end
		local v89 = v88.Character
		table.insert(v87, v89)
	end
	local v90 = workspace:FindFirstChild("HuntDummies")
	if v90 then
		table.insert(v87, v90)
	end
	v86.FilterDescendantsInstances = v87
	local v91 = workspace:Raycast(v84 + Vector3.new(0, 1.5, 0), p80 * (v82 + v_u_3.WALL_GAP), v86)
	if v91 then
		local v92 = (v91.Position - (v84 + Vector3.new(0, 1.5, 0))).Magnitude - v_u_3.WALL_GAP
		local v93 = math.max(0, v92)
		v85 = v84 + p80 * math.min(v82, v93)
	end
	local v94 = {
		["model"] = nil,
		["kind"] = "path",
		["t0"] = nil,
		["frozen"] = false,
		["root"] = nil,
		["lastSpeed"] = 0,
		["impacts"] = 0,
		["from"] = nil,
		["to"] = nil,
		["pathDone"] = false,
		["model"] = p78,
		["t0"] = os.clock(),
		["root"] = p79,
		["from"] = v84,
		["to"] = v85
	}
	local v95 = v_u_4
	table.insert(v95, v94)
	local v96 = v_u_5
	v96.path = v96.path + 1
	return v94
end
local function v_u_122(p98, p_u_99, p100, p101, p_u_102) -- name: startJoints
	-- upvalues: (copy) v_u_29, (copy) v_u_48, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	p98.Parent = v_u_29()
	v_u_48(p98, function(p103)
		-- upvalues: (copy) p_u_99, (copy) p_u_102
		p103.Anchored = false
		p103.CanTouch = false
		p103.CanQuery = false
		p103.CanCollide = p103 ~= p_u_99
		p103.CollisionGroup = p_u_102
		p103.CustomPhysicalProperties = PhysicalProperties.new(0.7, 0.5, 0.1, 1, 1)
	end)
	local v_u_104 = v_u_3.velocity(p100, p101)
	local v105 = p100.Z
	local v106 = -p100.X
	local v_u_107 = Vector3.new(v105, 0, v106) * (p101 * 5)
	v_u_48(p98, function(p108)
		-- upvalues: (copy) v_u_104, (copy) v_u_107
		p108.AssemblyLinearVelocity = v_u_104
		p108.AssemblyAngularVelocity = v_u_107
	end)
	local v109 = p98:FindFirstChild("UpperTorso") or (p98:FindFirstChild("Torso") or p98:FindFirstChild("LowerTorso"))
	if v109 == nil or not v109:IsA("BasePart") then
		v109 = p_u_99
	end
	local v110 = {
		["model"] = nil,
		["kind"] = "joints",
		["t0"] = nil,
		["frozen"] = false,
		["root"] = nil,
		["lastSpeed"] = nil,
		["lastFlat"] = nil,
		["flat0"] = nil,
		["dir0"] = nil,
		["impacts"] = 0,
		["model"] = p98,
		["t0"] = os.clock(),
		["root"] = v109,
		["lastSpeed"] = v_u_104.Magnitude
	}
	local v111 = v_u_104.X
	local v112 = v_u_104.Z
	v110.lastFlat = Vector3.new(v111, 0, v112).Magnitude
	local v113 = v_u_104.X
	local v114 = v_u_104.Z
	v110.flat0 = Vector3.new(v113, 0, v114).Magnitude
	local v115 = v_u_104.X
	local v116 = v_u_104.Z
	local v117
	if Vector3.new(v115, 0, v116).Magnitude > 0.01 then
		local v118 = v_u_104.X
		local v119 = v_u_104.Z
		v117 = Vector3.new(v118, 0, v119).Unit
	else
		v117 = nil
	end
	v110.dir0 = v117
	local v120 = v_u_4
	table.insert(v120, v110)
	local v121 = v_u_5
	v121.joints = v121.joints + 1
	return v110
end
function v_u_3.fling(p123, p124) -- name: fling
	-- upvalues: (copy) v_u_40, (copy) v_u_4, (copy) v_u_3, (copy) v_u_44, (copy) v_u_5, (copy) v_u_34, (copy) v_u_66, (copy) v_u_122, (copy) v_u_97
	if type(p123) ~= "table" then
		return "bad"
	end
	local v_u_125 = v_u_40(p123)
	if v_u_125 == nil then
		return "far"
	end
	while #v_u_4 >= v_u_3.MAX_COPIES do
		local v126 = table.remove(v_u_4, 1)
		if not v126 then
			continue
		end
		v126.model:Destroy()
	end
	local v127 = type(p124) ~= "number" and 3 or p124
	local v128 = v_u_3.cleanPower(p123.power)
	local v129 = v_u_3.cleanDir(p123.dir)
	local v130 = v_u_125.Archivable
	v_u_125.Archivable = true
	local v131, v132 = pcall(function()
		-- upvalues: (copy) v_u_125
		return v_u_125:Clone()
	end)
	v_u_125.Archivable = v130
	if v131 and v132 then
		v132.Name = "HuntRagdoll"
		v_u_44(v132)
	else
		v132 = nil
	end
	if v132 == nil then
		local v133 = v_u_5
		v133.refused = v133.refused + 1
		return "refused"
	end
	local v134 = v132:FindFirstChild("HumanoidRootPart")
	if not (v134 and v134:IsA("BasePart")) then
		if v132.PrimaryPart then
			v134 = v132.PrimaryPart
		else
			v134 = v132:FindFirstChildWhichIsA("BasePart", true)
		end
	end
	if v134 == nil then
		v132:Destroy()
		local v135 = v_u_5
		v135.refused = v135.refused + 1
		return "refused"
	end
	local v136 = 0
	for _, v137 in v132:GetDescendants() do
		if not v137:IsA("Motor6D") then
			continue
		end
		v136 = v136 + 1
	end
	local v138 = v_u_3.mode(v127, v136)
	local v139 = v_u_34()
	if v138 == "joints" then
		local v140 = 0
		for _, v141 in v_u_4 do
			if v141.frozen then
				continue
			end
			v140 = v140 + 1
		end
		if v_u_3.MAX_SIM <= v140 or v139 == nil then
			v138 = "path"
		end
	end
	local v142 = v_u_5
	v142.made = v142.made + 1
	if v138 ~= "joints" then
		v_u_97(v132, v134, v129, v128, v_u_3.distOfPower(v128))
		return "path"
	end
	v_u_66(v132)
	v_u_122(v132, v134, v129, v128, v139)
	return "joints"
end
function v_u_3.stats() -- name: stats
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v143 = 0
	for _, v144 in v_u_4 do
		if not v144.frozen then
			continue
		end
		v143 = v143 + 1
	end
	local v145 = 0
	local v146 = {}
	for _, v147 in v_u_4 do
		if v147.frozen then
			continue
		end
		v145 = v145 + 1
	end
	v146.simulating = v145
	v146.frozen = v143
	v146.made = v_u_5.made
	v146.joints = v_u_5.joints
	v146.path = v_u_5.path
	v146.refused = v_u_5.refused
	v146.impacts = v_u_5.impacts
	return v146
end
function v_u_3.clear() -- name: clear
	-- upvalues: (copy) v_u_4, (ref) v_u_8
	for _, v148 in v_u_4 do
		v148.model:Destroy()
	end
	table.clear(v_u_4)
	local v149 = v_u_8
	if v149 and v149.Parent then
		v149:ClearAllChildren()
	end
end
function v_u_3.step(_) -- name: step
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_48, (copy) v_u_77
	local v150 = os.clock()
	for v151 = #v_u_4, 1, -1 do
		local v_u_152 = v_u_4[v151]
		if v_u_152.model.Parent == nil then
			table.remove(v_u_4, v151)
		else
			local v153 = v150 - v_u_152.t0
			if v_u_3.MAX_AGE < v153 then
				table.remove(v_u_4, v151)
				v_u_152.model:Destroy()
			else
				if v_u_152.frozen then
					continue
				end
				local v_u_154 = v_u_152.root
				if v_u_152.kind == "path" then
					local v155 = v153 / v_u_3.PATH_TIME
					local v156 = math.clamp(v155, 0, 1)
					if v_u_154 and (v_u_152.from and v_u_152.to) then
						local v157 = v_u_152.from:Lerp(v_u_152.to, v156)
						local v158 = v_u_3.PATH_ARC * 4 * v156 * (1 - v156)
						local v_u_159 = v157 + Vector3.new(0, v158, 0)
						pcall(function()
							-- upvalues: (copy) v_u_152, (copy) v_u_154, (copy) v_u_159
							v_u_152.model:PivotTo(v_u_152.model:GetPivot() - (v_u_154.Position - v_u_159))
						end)
					end
					if v156 < 1 then
						continue
					end
					if not v_u_152.frozen then
						v_u_152.frozen = true
						v_u_48(v_u_152.model, function(p160)
							p160.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
							p160.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
							p160.Anchored = true
							p160.CanCollide = false
						end)
					end
					if not v_u_152.to then
						continue
					end
					v_u_77(v_u_152.to, 0.6)
				else
					if v_u_154 then
						local v161 = v_u_154.AssemblyLinearVelocity
						local v162 = v161.Magnitude
						local v163 = v161.X
						local v164 = v161.Z
						local v165 = Vector3.new(v163, 0, v164).Magnitude
						local v166 = v_u_152.lastSpeed - v162
						local v167 = (v_u_152.lastFlat or v165) - v165
						local v168 = v_u_3.IMPACT_FRAC * (v_u_152.flat0 or 0)
						local v169 = v_u_3.IMPACT_MIN
						local v170 = v_u_3.IMPACT_DROP
						local v171 = math.clamp(v168, v169, v170)
						local v_u_172 = nil
						local function v177() -- name: hasWall
							-- upvalues: (ref) v_u_172, (copy) v_u_152, (copy) v_u_154, (ref) v_u_3
							if v_u_172 == nil then
								v_u_172 = false
								if v_u_152.dir0 ~= nil then
									local v173 = RaycastParams.new()
									v173.FilterType = Enum.RaycastFilterType.Exclude
									v173.FilterDescendantsInstances = { v_u_152.model }
									local v174 = workspace:Raycast(v_u_154.Position, v_u_152.dir0 * v_u_3.WALL_LOOK, v173)
									if v174 then
										v174 = v174.Instance
									end
									if v174 and v174.CanCollide then
										local v175 = v174:FindFirstAncestorOfClass("Model")
										local v176
										if v175 == nil then
											v176 = false
										else
											v176 = v175:FindFirstChildOfClass("Humanoid") ~= nil
										end
										v_u_172 = not v176
									end
								end
							end
							return v_u_172 == true
						end
						if (v_u_3.IMPACT_DROP < v166 or v171 < v167) and (v_u_152.impacts < 3 and v177()) then
							v_u_152.impacts = v_u_152.impacts + 1
							local v178 = v_u_77
							local v179 = v_u_154.Position
							local v180 = math.max(v166, v167) / 40
							v178(v179, (math.clamp(v180, 0.3, 1)))
						end
						if not v_u_152.wallHit and (v_u_152.impacts < 3 and (v_u_152.dir0 ~= nil and ((v_u_152.flat0 or 0) > 0 and (v165 < v_u_3.WALL_SLOW * v_u_152.flat0 and (v153 > 0.05 and v177()))))) then
							v_u_152.wallHit = true
							if v_u_152.impacts == 0 then
								v_u_152.impacts = v_u_152.impacts + 1
								local v181 = v_u_77
								local v182 = v_u_154.Position
								local v183 = v_u_152.flat0 / 40
								v181(v182, (math.clamp(v183, 0.3, 1)))
							end
						end
						v_u_152.lastSpeed = v162
						v_u_152.lastFlat = v165
						if v_u_154.Position.Y < workspace.FallenPartsDestroyHeight + 20 and not v_u_152.frozen then
							v_u_152.frozen = true
							v_u_48(v_u_152.model, function(p184)
								p184.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
								p184.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
								p184.Anchored = true
								p184.CanCollide = false
							end)
						end
					end
					if v_u_3.FREEZE_AFTER > v153 then
						continue
					end
					if v_u_152.frozen then
						continue
					end
					v_u_152.frozen = true
					v_u_48(v_u_152.model, function(p185)
						p185.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
						p185.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
						p185.Anchored = true
						p185.CanCollide = false
					end)
				end
			end
		end
	end
end
return v_u_3