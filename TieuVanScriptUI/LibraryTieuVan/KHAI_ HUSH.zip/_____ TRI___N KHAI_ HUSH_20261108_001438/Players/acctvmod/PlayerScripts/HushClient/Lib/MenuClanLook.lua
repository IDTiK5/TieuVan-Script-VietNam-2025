-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanLook

local v_u_76 = {
	["RANK_RGB"] = {
		["owner"] = { 255, 196, 64 },
		["officer"] = { 236, 102, 92 },
		["veteran"] = { 94, 168, 255 },
		["member"] = { 112, 206, 150 },
		["recruit"] = { 160, 168, 182 }
	},
	["EXTRA"] = {
		{ 190, 132, 255 },
		{ 255, 150, 90 },
		{ 80, 208, 214 },
		{ 240, 130, 190 }
	},
	["ORDER"] = {
		["owner"] = 0,
		["officer"] = 1,
		["veteran"] = 2,
		["member"] = 3,
		["recruit"] = 4
	},
	["rankRgb"] = function(p1) -- name: rankRgb
		-- upvalues: (copy) v_u_76
		local v2 = type(p1) ~= "string" and "" or p1
		local v3 = v_u_76.RANK_RGB[v2]
		if v3 then
			return v3
		end
		local v4 = v_u_76.EXTRA
		local v5 = 7
		for v6 = 1, #v2 do
			v5 = (v5 * 31 + string.byte(v2, v6)) % 1000003
		end
		return v4[v5 % #v_u_76.EXTRA + 1]
	end,
	["rankColor"] = function(p7) -- name: rankColor
		-- upvalues: (copy) v_u_76
		if Color3 == nil then
			return nil
		end
		local v8 = v_u_76.rankRgb(p7)
		return Color3.fromRGB(v8[1], v8[2], v8[3])
	end,
	["fillRgb"] = function(p9) -- name: fillRgb
		local v10 = {}
		local v11 = p9[1] * 0.16 + 12
		local v12 = math.floor(v11)
		local v13 = p9[2] * 0.16 + 12
		local v14 = math.floor(v13)
		local v15 = p9[3] * 0.16 + 14
		__set_list(v10, 1, {v12, v14, (math.floor(v15))})
		return v10
	end,
	["rgbColor"] = function(p16) -- name: rgbColor
		if Color3 == nil then
			return nil
		else
			return Color3.fromRGB(p16[1], p16[2], p16[3])
		end
	end,
	["rankChipText"] = function(p17, p18) -- name: rankChipText
		local v19
		if type(p17) == "table" then
			v19 = p17.ranks
		else
			v19 = nil
		end
		if type(v19) == "table" then
			for _, v20 in v19 do
				if type(v20) ~= "table" or v20.id ~= p18 then
					continue
				end
				local v21 = v20.name
				if type(v21) ~= "string" or v20.name == "" then
					continue
				end
				return string.upper(v20.name)
			end
		end
		return string.upper((tostring(p18 or "?")))
	end,
	["MODES"] = {
		["open"] = {
			"OPEN",
			{ 112, 206, 150 }
		},
		["request"] = {
			"REQUEST",
			{ 255, 196, 64 }
		},
		["private"] = {
			"PRIVATE",
			{ 160, 168, 182 }
		}
	},
	["modeLook"] = function(p22) -- name: modeLook
		-- upvalues: (copy) v_u_76
		local v23 = v_u_76.MODES[type(p22) ~= "string" and "" or p22]
		if v23 then
			return v23[1], v23[2]
		else
			return "REQUEST", v_u_76.MODES.request[2]
		end
	end,
	["headshotUrl"] = function(p24, p25) -- name: headshotUrl
		if type(p24) == "number" then
			p24 = string.format("%d", p24)
		elseif type(p24) ~= "string" then
			p24 = nil
		end
		if p24 == nil or (#p24 < 1 or (#p24 > 17 or (string.find(p24, "^%d+$") == nil or string.find(p24, "^0+$") ~= nil))) then
			return nil
		end
		local v26 = tonumber(p25) or 150
		local v27 = math.floor(v26)
		local v28 = v27 ~= 48 and (v27 ~= 60 and (v27 ~= 100 and (v27 ~= 150 and (v27 ~= 180 and (v27 ~= 352 and v27 ~= 420))))) and 150 or v27
		return ("rbxthumb://type=AvatarHeadShot&id=%s&w=%d&h=%d"):format(p24, v28, v28)
	end,
	["glyph"] = function(p29) -- name: glyph
		if type(p29) == "string" then
			local v30 = string.match(p29, "%a")
			if v30 then
				return string.upper(v30)
			end
			local v31 = string.match(p29, "%d")
			if v31 then
				return v31
			end
		end
		return "?"
	end,
	["rankOrder"] = function(p32) -- name: orderOf
		-- upvalues: (copy) v_u_76
		return v_u_76.ORDER[type(p32) ~= "string" and "" or p32] or 50
	end,
	["sortMembers"] = function(p33) -- name: sortMembers
		-- upvalues: (copy) v_u_76
		local v34 = {}
		if type(p33) ~= "table" then
			return v34
		end
		for _, v35 in p33 do
			if type(v35) ~= "table" then
				continue
			end
			table.insert(v34, v35)
		end
		table.sort(v34, function(p36, p37)
			-- upvalues: (ref) v_u_76
			local v38 = p36.rank
			local v39 = v_u_76.ORDER[type(v38) ~= "string" and "" or v38] or 50
			local v40 = p37.rank
			local v41 = v_u_76.ORDER[type(v40) ~= "string" and "" or v40] or 50
			if v39 ~= v41 then
				return v39 < v41
			end
			local v42 = string.lower
			local v43 = p36.name or ""
			local v44 = v42((tostring(v43)))
			local v45 = string.lower
			local v46 = p37.name or ""
			local v47 = v45((tostring(v46)))
			if v44 ~= v47 then
				return v44 < v47
			end
			local v48 = p36.uid or ""
			local v49 = tostring(v48)
			local v50 = p37.uid or ""
			return v49 < tostring(v50)
		end)
		return v34
	end,
	["logUid"] = function(p51) -- name: logUid
		if type(p51) == "table" then
			local v52 = p51.uid
			if type(v52) == "number" then
				v52 = string.format("%d", v52)
			end
			if type(v52) == "string" and (#v52 >= 1 and (#v52 <= 17 and string.find(v52, "^%d+$") ~= nil)) then
				return v52
			else
				return nil
			end
		else
			return nil
		end
	end,
	["standing"] = function(p53, p54) -- name: standing
		if type(p53) ~= "table" or type(p54) ~= "string" then
			return nil
		end
		local v55 = 0
		local v56 = nil
		local v57 = nil
		for v58, v59 in p53 do
			if type(v59) ~= "table" then
				continue
			end
			v55 = v55 + 1
			if v59.id ~= p54 then
				continue
			end
			v57 = v58
			v56 = v59
		end
		if v56 == nil then
			return nil
		end
		local v60 = {}
		local v61 = v56.rank
		v60.place = tonumber(v61) or v57
		v60.total = v55
		local v62 = v56.pts
		v60.pts = tonumber(v62) or 0
		local v63 = p53[v57 - 1]
		local v64 = p53[v57 + 1]
		if type(v63) == "table" then
			local v65 = {}
			local v66 = v63.rank
			v65.place = tonumber(v66) or v57 - 1
			local v67 = v63.pts
			v65.pts = tonumber(v67) or 0
			local v68 = v63.pts
			local v69 = (tonumber(v68) or 0) - v60.pts
			v65.gap = math.max(0, v69)
			v60.ahead = v65
		end
		if type(v64) == "table" then
			local v70 = {}
			local v71 = v64.rank
			v70.place = tonumber(v71) or v57 + 1
			local v72 = v64.pts
			v70.pts = tonumber(v72) or 0
			local v73 = v60.pts
			local v74 = v64.pts
			local v75 = v73 - (tonumber(v74) or 0)
			v70.gap = math.max(0, v75)
			v60.behind = v70
		end
		return v60
	end
}
return v_u_76