-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPhotoPoses

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent:WaitForChild("AnimPoses"))
local v_u_3 = require(script.Parent:WaitForChild("ZombieAnimPose"))
local v4 = require(v1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ZombieTypes"))
local v_u_5 = {}
local v_u_6 = math.rad
local v_u_7 = Vector3.new
v_u_5.ACTOR_POSES = {
	["idle"] = {
		["fk"] = {
			["LeftShoulder"] = { 4, 0, -4 },
			["RightShoulder"] = { 4, 0, 4 },
			["LeftElbow"] = { 10, 0, 0 },
			["RightElbow"] = { 10, 0, 0 }
		}
	},
	["raise_flare"] = {
		["drop"] = 0.18,
		["fk"] = nil,
		["fk"] = {
			["Root"] = { -4, -8, 0 },
			["Waist"] = { -6, 12, 0 },
			["Neck"] = { 2, -6, 0 },
			["RightShoulder"] = { 170, 0, 10 },
			["RightElbow"] = { 6, 0, 0 },
			["LeftShoulder"] = { 48, 0, -28 },
			["LeftElbow"] = { 95, 0, 0 },
			["LeftWrist"] = { -10, 0, 0 },
			["LeftHip"] = { 14, 0, -9 },
			["LeftKnee"] = { -24, 0, 0 },
			["LeftAnkle"] = { 10, 0, 0 },
			["RightHip"] = { -12, 0, 9 },
			["RightKnee"] = { -10, 0, 0 },
			["RightAnkle"] = { 14, 0, 0 }
		}
	},
	["hold_flare_low"] = {
		["fk"] = {
			["Waist"] = { -4, 0, 0 },
			["Neck"] = { -4, 0, 0 },
			["RightShoulder"] = { 42, 0, 14 },
			["RightElbow"] = { 38, 0, 0 },
			["LeftShoulder"] = { 8, 0, -6 },
			["LeftElbow"] = { 18, 0, 0 }
		}
	},
	["shush"] = {
		["fk"] = {
			["Waist"] = { -3, -6, 0 },
			["Neck"] = { -10, 4, 0 },
			["LeftShoulder"] = { 12, 0, -6 },
			["LeftElbow"] = { 28, 0, 0 }
		},
		["right"] = {
			["at"] = Vector3.new(0.05, 1.05, -0.62),
			["hand"] = "up",
			["head"] = true
		}
	},
	["aim_pistol"] = {
		["fk"] = {
			["Waist"] = { 0, 6, 0 },
			["Neck"] = { -2, -4, 0 },
			["LeftHip"] = { 6, 0, -5 },
			["RightHip"] = { -6, 0, 5 },
			["LeftKnee"] = { -8, 0, 0 }
		},
		["hold"] = {
			["type"] = "pistol",
			["pose"] = "aim"
		}
	},
	["aim_rifle"] = {
		["fk"] = nil,
		["drop"] = 0.1,
		["hold"] = nil,
		["fk"] = {
			["Root"] = { -3, 0, 0 },
			["Waist"] = { -2, 18, 0 },
			["Neck"] = { -4, -16, 6 },
			["LeftHip"] = { 10, 0, -6 },
			["RightHip"] = { -10, 0, 6 },
			["LeftKnee"] = { -14, 0, 0 }
		},
		["hold"] = {
			["type"] = "rifle",
			["pose"] = "aim"
		}
	},
	["run_frozen"] = {
		["drop"] = 0.12,
		["fk"] = nil,
		["fk"] = {
			["Root"] = { -14, 0, 0 },
			["Waist"] = { -6, 0, 0 },
			["Neck"] = { 12, 0, 0 },
			["LeftHip"] = { 48, 0, 0 },
			["LeftKnee"] = { -38, 0, 0 },
			["LeftAnkle"] = { 10, 0, 0 },
			["RightHip"] = { -34, 0, 0 },
			["RightKnee"] = { -78, 0, 0 },
			["RightAnkle"] = { -18, 0, 0 },
			["LeftShoulder"] = { -42, 0, -8 },
			["LeftElbow"] = { 72, 0, 0 },
			["RightShoulder"] = { 55, 0, 8 },
			["RightElbow"] = { 80, 0, 0 }
		}
	},
	["crouch_flashlight"] = {
		["drop"] = 1.05,
		["fk"] = nil,
		["hold"] = nil,
		["fk"] = {
			["Root"] = { -16, 0, 0 },
			["Waist"] = { -4, 0, 0 },
			["Neck"] = { 14, 0, 0 },
			["LeftHip"] = { 92, 0, -6 },
			["LeftKnee"] = { -100, 0, 0 },
			["LeftAnkle"] = { 8, 0, 0 },
			["RightHip"] = { 18, 0, 8 },
			["RightKnee"] = { -112, 0, 0 },
			["RightAnkle"] = { -40, 0, 0 }
		},
		["hold"] = {
			["type"] = "pistol",
			["pose"] = "aim",
			["pitch"] = -4
		}
	},
	["back_to_back_ready"] = {
		["fk"] = nil,
		["drop"] = 0.08,
		["hold"] = nil,
		["fk"] = {
			["Waist"] = { -2, 10, 0 },
			["Neck"] = { -2, -12, 0 },
			["LeftHip"] = { 8, 0, -7 },
			["RightHip"] = { -6, 0, 7 },
			["LeftKnee"] = { -10, 0, 0 }
		},
		["hold"] = {
			["type"] = "rifle",
			["pose"] = "ready"
		}
	},
	["look_back"] = {
		["fk"] = {
			["Root"] = { 0, 10, 0 },
			["Waist"] = { 0, 32, 0 },
			["Neck"] = { -4, 48, 0 },
			["LeftHip"] = { -18, 0, 0 },
			["RightHip"] = { 20, 0, 0 },
			["RightKnee"] = { -16, 0, 0 }
		},
		["hold"] = {
			["type"] = "pistol",
			["pose"] = "ready"
		}
	},
	["kneel_loot"] = {
		["drop"] = 1.25,
		["fk"] = nil,
		["right"] = nil,
		["left"] = nil,
		["fk"] = {
			["Root"] = { -8, 0, 0 },
			["Waist"] = { -24, 0, 0 },
			["Neck"] = { -20, 0, 0 },
			["LeftHip"] = { 88, 0, -4 },
			["LeftKnee"] = { -92, 0, 0 },
			["LeftAnkle"] = { 4, 0, 0 },
			["RightHip"] = { -6, 0, 6 },
			["RightKnee"] = { -95, 0, 0 },
			["RightAnkle"] = { -10, 0, 0 }
		},
		["right"] = {
			["at"] = Vector3.new(0.3, -1.05, -1.2),
			["posed"] = true
		},
		["left"] = {
			["at"] = Vector3.new(-0.4, -1, -1.1),
			["posed"] = true
		}
	}
}
local function v_u_15(p8) -- name: deg3
	-- upvalues: (copy) v_u_6
	if type(p8) ~= "table" then
		return CFrame.identity
	end
	local v9 = CFrame.fromEulerAnglesYXZ
	local v10 = p8[1]
	local v11 = v_u_6(tonumber(v10) or 0)
	local v12 = p8[2]
	local v13 = v_u_6(tonumber(v12) or 0)
	local v14 = p8[3]
	return v9(v11, v13, (v_u_6(tonumber(v14) or 0)))
end
local function v_u_28(p16) -- name: resolve
	-- upvalues: (copy) v_u_5
	if type(p16) == "string" then
		return v_u_5.ACTOR_POSES[p16] or v_u_5.ACTOR_POSES.idle
	end
	if type(p16) ~= "table" then
		return v_u_5.ACTOR_POSES.idle
	end
	local v17 = v_u_5.ACTOR_POSES[p16.base or "idle"] or v_u_5.ACTOR_POSES.idle
	local v18 = {}
	for v19, v20 in v17 do
		v18[v19] = v20
	end
	local v21 = {}
	for v22, v23 in v17.fk or {} do
		v21[v22] = v23
	end
	for v24, v25 in p16.fk or {} do
		v21[v24] = v25
	end
	for v26, v27 in p16 do
		if v26 == "fk" or v26 == "base" then
			continue
		end
		v18[v26] = v27
	end
	v18.fk = v21
	return v18
end
local function v_u_33(p29, p30) -- name: gripInv
	local v31 = p29:FindFirstChild(p30, true)
	local v32 = CFrame.new(0, -0.15, 0) * CFrame.Angles(-1.5707963267948966, 0, 0)
	if v31 and v31:IsA("Attachment") then
		v32 = v31.CFrame
	end
	return v32:Inverse()
end
function v_u_5.handFrame(p34, p35) -- name: handFrame
	-- upvalues: (copy) v_u_33
	local v36 = p35 .. "Hand"
	local v37 = p34.part[v36]
	if v37 then
		return v37 * v_u_33(p34.model, p35 .. "GripAttachment"):Inverse()
	else
		return CFrame.identity
	end
end
function v_u_5.forearm(p38, p39) -- name: forearm
	local v40 = p38:pivot(p39 .. "Elbow").Position
	local v41 = p38:pivot(p39 .. "Wrist").Position - v40
	return v41.Magnitude <= 0.001 and Vector3.new(0, -1, 0) or v41.Unit
end
local function v_u_47(p42, p43, p44, p45) -- name: handTo
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v46 = p43 == "Right" and 1 or -1
	p42:solve2(p43 .. "Shoulder", p43 .. "Elbow", p43 .. "Wrist", p44, v_u_7(v46 * 0.55, -1, 0.45), Vector3.new(0, 0, 1))
	if p45 == "up" then
		p42:orientEnd(p43 .. "Wrist", CFrame.Angles(3.141592653589793, 0, 0) * CFrame.Angles(0, v_u_6(v46 * -80), 0))
	elseif p45 == "fist" then
		p42:orientEnd(p43 .. "Wrist", CFrame.Angles(-1.5707963267948966, 0, 0))
	end
end
function v_u_5.actorPose(p48, p49, p50) -- name: actorPose
	-- upvalues: (copy) v_u_28, (copy) v_u_15, (copy) v_u_2, (copy) v_u_7, (copy) v_u_6, (copy) v_u_33, (copy) v_u_47
	local v51 = v_u_28(p49)
	p48:reset()
	local v52 = v51.fk or {}
	local v53 = v51.drop
	local v54 = (tonumber(v53) or 0) * p50
	for _, v55 in p48.order do
		local v56 = v_u_15(v52[v55.name])
		if v55.name == "Root" and v54 ~= 0 then
			v56 = CFrame.new(0, -v54, 0) * v56
		end
		p48:setT(v55.name, v56)
	end
	local v57 = {}
	local v58 = v51.hold
	if type(v58) == "table" then
		local v59 = v58.type or "pistol"
		local v60 = tostring(v59)
		local v61 = p48:bindPivot("RightShoulder").Position
		local v62 = v_u_2.grip
		local v63 = v58.pose or "aim"
		local v64 = v62(v60, tostring(v63), v61)
		local v65 = p50 - 1
		if math.abs(v65) > 0.02 then
			v64 = CFrame.new(v61 + (v64.Position - v61) * p50) * v64.Rotation
		end
		local v66
		if p48.part.UpperTorso and p48.bind.UpperTorso then
			v66 = p48.part.UpperTorso * p48.bind.UpperTorso:Inverse()
		else
			v66 = CFrame.identity
		end
		local v67 = v66 * v64
		if v58.pose == "aim" or v58.pose == nil then
			local v68 = v67.LookVector
			local v69 = v_u_7(v68.X, 0, v68.Z)
			if v69.Magnitude > 0.2 then
				v67 = CFrame.lookAt(v67.Position, v67.Position + v69.Unit)
			end
		end
		local v70 = CFrame.Angles
		local v71 = v58.yaw
		local v72 = v67 * v70(0, v_u_6(tonumber(v71) or 0), 0)
		local v73 = CFrame.Angles
		local v74 = v58.pitch
		local v75 = v72 * v73(v_u_6(tonumber(v74) or 0), 0, 0)
		local v76 = v75 * v_u_33(p48.model, "RightGripAttachment")
		local v77 = p48.joints.RightWrist
		local v78
		if v77 then
			v78 = (v76 * v77.c1).Position
		else
			v78 = v76.Position
		end
		p48:solve2("RightShoulder", "RightElbow", "RightWrist", v78, Vector3.new(0.55, -1, 0.45), Vector3.new(0, 0, 1))
		if v77 then
			p48:orientEnd("RightWrist", v76)
		end
		local v79 = v_u_2.twoHanded
		local v80 = v58.pose or "aim"
		if v79(v60, (tostring(v80))) and not v51.left then
			local v81 = v_u_2.support(v60) or CFrame.new(-0.2, 0, 0.1)
			local v82 = v75 * CFrame.new(v81.Position * p50)
			local v83 = CFrame.new(v82.Position) * v75.Rotation * v_u_2.leftRoll(v60) * v_u_33(p48.model, "LeftGripAttachment")
			local v84 = p48.joints.LeftWrist
			local v85
			if v84 then
				v85 = (v83 * v84.c1).Position
			else
				v85 = v83.Position
			end
			p48:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v85, Vector3.new(-0.55, -1, 0.35), Vector3.new(0, 0, 1))
			if v84 then
				p48:orientEnd("LeftWrist", v83)
			end
		end
		v57.grip = v75
		v57.holdType = v60
	end
	for _, v86 in { "Right", "Left" } do
		local v87 = v51[string.lower(v86)]
		if type(v87) ~= "table" then
			continue
		end
		local v88 = v87.at
		if typeof(v88) ~= "Vector3" then
			continue
		end
		local v89 = v87.at * p50
		local v90
		if v87.head and (p48.part.Head and p48.bind.Head) then
			v90 = p48.part.Head.Position + v_u_7(v87.at.X * p50, (v87.at.Y - 1.05) * p50, v87.at.Z * p50)
		elseif v87.posed then
			v90 = p48:pivot(v86 .. "Shoulder").Position + v89
		else
			v90 = p48:bindPivot(v86 .. "Shoulder").Position + v89
		end
		v_u_47(p48, v86, v90, v87.hand)
	end
	p48:apply()
	return v57
end
local v_u_91 = v4.STATE or {}
v_u_5.ZOMBIE_POSES = {
	["idle"] = {
		["state"] = "IDLE",
		["speed"] = 0
	},
	["walk"] = {
		["state"] = "WANDER",
		["speed"] = 2.6
	},
	["shamble"] = {
		["state"] = "WANDER",
		["speed"] = 3.6
	},
	["chase"] = {
		["state"] = "CHASE",
		["speed"] = 6.5
	},
	["run"] = {
		["state"] = "CHASE",
		["speed"] = 14
	},
	["reach"] = {
		["state"] = "CHASE",
		["speed"] = 1.4,
		["style"] = 0,
		["notice"] = 0.32
	},
	["notice"] = {
		["state"] = "IDLE",
		["speed"] = 0,
		["notice"] = 0.3
	},
	["lunge"] = {
		["state"] = "ATTACK",
		["speed"] = 0,
		["variant"] = 1,
		["act"] = 0.74,
		["actDur"] = 0.8
	},
	["grab"] = {
		["state"] = "ATTACK",
		["speed"] = 0,
		["variant"] = 1,
		["act"] = 0.86,
		["actDur"] = 0.8
	},
	["swipe"] = {
		["state"] = "ATTACK",
		["speed"] = 0,
		["variant"] = 0,
		["act"] = 0.78,
		["actDur"] = 0.8
	},
	["smash"] = {
		["state"] = "ATTACK",
		["speed"] = 0,
		["variant"] = 2,
		["act"] = 0.7,
		["actDur"] = 0.8
	},
	["scream"] = {
		["state"] = "SCREAM",
		["speed"] = 0,
		["act"] = 0.9,
		["actDur"] = 2.2
	},
	["crawl"] = {
		["state"] = "CHASE",
		["speed"] = 1.4,
		["legless"] = true
	},
	["feed"] = {
		["state"] = "FEED",
		["speed"] = 0
	},
	["dormant"] = {
		["state"] = "DORMANT",
		["speed"] = 0
	},
	["stagger"] = {
		["state"] = "STAGGER",
		["speed"] = 0,
		["act"] = 0.12,
		["actDur"] = 0.7,
		["flinch"] = 0.8
	}
}
local v_u_92 = {
	["IDLE"] = 0,
	["WANDER"] = 1,
	["CHASE"] = 3,
	["ATTACK"] = 4,
	["STAGGER"] = 6,
	["SCREAM"] = 8,
	["DORMANT"] = 11,
	["FEED"] = 14
}
function v_u_5.zombiePose(p93, p94, p95) -- name: zombiePose
	-- upvalues: (copy) v_u_5, (copy) v_u_92, (copy) v_u_91, (copy) v_u_3
	local v96 = type(p95) ~= "table" and {
		["pose"] = p95
	} or p95
	local v97 = v_u_5.ZOMBIE_POSES
	local v98 = v96.pose or "idle"
	local v99 = v97[tostring(v98)] or v_u_5.ZOMBIE_POSES.idle
	local v100 = v96.seed
	local v101 = tonumber(v100) or math.random()
	local v102 = {
		["state"] = nil,
		["speed"] = nil,
		["kind"] = nil,
		["style"] = nil,
		["seed"] = nil,
		["t"] = nil,
		["act"] = nil,
		["actDur"] = nil,
		["flinch"] = nil,
		["flinchX"] = 0,
		["flinchZ"] = 0,
		["deathSign"] = 1,
		["wasLying"] = false,
		["legless"] = nil,
		["human"] = false,
		["riseFromLying"] = false,
		["variant"] = nil,
		["notice"] = nil
	}
	local v103 = v99.state
	local v104 = v_u_92[v99.state] or 0
	local v105 = v_u_91[string.lower(v103)]
	if type(v105) == "number" then
		v104 = v105
	end
	v102.state = v104
	v102.speed = v99.speed or 0
	v102.kind = p94
	local v106 = v96.style
	local v107 = tonumber(v106) or v99.style
	if not v107 then
		local v108 = v101 * 4
		v107 = math.floor(v108) % 4
	end
	v102.style = v107
	v102.seed = v101
	local v109 = v96.t
	v102.t = tonumber(v109) or v101 * 20
	local v110 = v96.act
	v102.act = tonumber(v110) or (v99.act or 0)
	local v111 = v96.actDur
	v102.actDur = tonumber(v111) or (v99.actDur or 1)
	v102.flinch = v99.flinch or 0
	v102.legless = v99.legless == true and true or p94 == "crawler"
	v102.variant = v99.variant
	v102.notice = v99.notice
	local v112 = p93.pose
	v_u_3.reset(v112)
	local v113 = v96.phase
	v112.phase = (tonumber(v113) or v101) % 1 * 3.141592653589793 * 2
	v_u_3.update(v112, v102, 0)
	v_u_3.snap(v112)
	v_u_3.apply(v112, 0)
end
return v_u_5