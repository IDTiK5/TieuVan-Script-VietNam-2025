-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TakedownZombiePose

local v_u_1 = {
	["KICK_AT"] = 0.3,
	["STAB_AT"] = 1.05,
	["FOLD_TIME"] = 0.18,
	["END"] = 1.4,
	["LIFE"] = 2.2,
	["WAIST"] = -1.15,
	["NECK"] = -0.1,
	["SHOULDER"] = 0.75,
	["ELBOW"] = 1.4,
	["DIP"] = 0.2,
	["JERK"] = 0.75,
	["n"] = 0
}
local v_u_2 = {}
function v_u_1.sample(p3) -- name: sample
	-- upvalues: (copy) v_u_1
	if type(p3) ~= "number" or (p3 ~= p3 or (p3 < v_u_1.KICK_AT or v_u_1.END < p3)) then
		return nil
	end
	local v4 = (p3 - v_u_1.KICK_AT) / v_u_1.FOLD_TIME
	local v5 = 1 - math.clamp(v4, 0, 1)
	local v6 = 1 - v5 * v5 * v5
	local v7
	if v_u_1.KICK_AT + v_u_1.FOLD_TIME < p3 then
		local v8 = p3 * 38
		local v9 = math.sin(v8) * 0.02
		local v10 = (p3 - v_u_1.KICK_AT - v_u_1.FOLD_TIME) / 0.1
		v7 = v9 * math.min(1, v10)
	else
		v7 = 0
	end
	local v11
	if v_u_1.STAB_AT - 0.06 <= p3 then
		local v12 = v_u_1.JERK
		local v13 = (p3 - (v_u_1.STAB_AT - 0.06)) / 0.06
		v11 = v12 * math.clamp(v13, 0, 1)
		if v_u_1.STAB_AT + 0.1 < p3 then
			local v14 = 1 - (p3 - v_u_1.STAB_AT - 0.1) / 0.2
			v11 = v11 * math.clamp(v14, 0, 1)
		end
	else
		v11 = 0
	end
	return {
		["waist"] = v_u_1.WAIST * v6 + v7,
		["neck"] = v_u_1.NECK * v6 + v11,
		["shoulder"] = v_u_1.SHOULDER * v6,
		["elbow"] = v_u_1.ELBOW * v6,
		["dip"] = v_u_1.DIP * v6
	}
end
function v_u_1.headHeight(p15) -- name: headHeight
	-- upvalues: (copy) v_u_1
	local v16 = v_u_1.sample(p15)
	local v17
	if v16 then
		local v18 = v16.waist / v_u_1.WAIST
		v17 = math.clamp(v18, 0, 1)
	else
		v17 = 0
	end
	return 0.9 - v17 * 1.3
end
function v_u_1.note(p19, p20, _) -- name: note
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if type(p19) == "number" and (type(p20) == "number" and p20 == p20) then
		local v21 = v_u_2[p19]
		if v21 == nil then
			local v22 = v_u_1
			v22.n = v22.n + 1
			v_u_2[p19] = {
				["at"] = p20
			}
		else
			v21.at = p20
		end
	else
		return
	end
end
function v_u_1.prune(p23) -- name: prune
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if type(p23) == "number" then
		for v24, v25 in v_u_2 do
			if p23 - v25.at <= v_u_1.LIFE and v25.at - p23 <= 5 then
				continue
			end
			v_u_2[v24] = nil
			local v26 = v_u_1
			v26.n = v26.n - 1
		end
	end
end
function v_u_1.elapsed(p27, p28) -- name: elapsed
	-- upvalues: (copy) v_u_2
	local v29 = v_u_2[p27]
	if v29 == nil or type(p28) ~= "number" then
		return nil
	else
		return p28 - v29.at
	end
end
function v_u_1.clear() -- name: clear
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	table.clear(v_u_2)
	v_u_1.n = 0
end
function v_u_1.apply(p30, p31, p32) -- name: apply
	-- upvalues: (copy) v_u_1
	local v33 = v_u_1.elapsed(p30, p32)
	if v33 == nil then
		return false
	end
	local v34 = v_u_1.sample(v33)
	if v34 ~= nil and type(p31) == "table" then
		local v35 = p31.joints
		if type(v35) == "table" then
			local v36 = p31.cx
			local v37 = p31.cy
			local v38 = p31.cz
			local v39 = p31.wx
			local v40 = p31.joints[1]
			if v40 then
				local v41 = v36[1] + 0
				local v42 = v37[1] + 0
				local v43 = v38[1] + 0
				v40.Transform = CFrame.new(0, p31.cRootY - v34.dip, p31.cRootZ) * CFrame.fromEulerAnglesYXZ(v41, v42, v43)
				v39[1] = 1000000000
			end
			local v44 = v34.waist
			local v45 = p31.joints[2]
			if v45 then
				local v46 = v36[2] + v44
				local v47 = v37[2] + 0
				local v48 = v38[2] + 0
				v45.Transform = CFrame.fromEulerAnglesYXZ(v46, v47, v48)
				v39[2] = 1000000000
			end
			local v49 = v34.neck
			local v50 = p31.joints[3]
			if v50 then
				local v51 = v36[3] + v49
				local v52 = v37[3] + 0
				local v53 = v38[3] + 0
				v50.Transform = CFrame.fromEulerAnglesYXZ(v51, v52, v53)
				v39[3] = 1000000000
			end
			local v54 = v34.shoulder
			local v55 = p31.joints[4]
			if v55 then
				local v56 = v36[4] + v54
				local v57 = v37[4] + 0
				local v58 = v38[4] + 0
				v55.Transform = CFrame.fromEulerAnglesYXZ(v56, v57, v58)
				v39[4] = 1000000000
			end
			local v59 = v34.shoulder
			local v60 = p31.joints[7]
			if v60 then
				local v61 = v36[7] + v59
				local v62 = v37[7] + 0
				local v63 = v38[7] + 0
				v60.Transform = CFrame.fromEulerAnglesYXZ(v61, v62, v63)
				v39[7] = 1000000000
			end
			local v64 = v34.elbow
			local v65 = p31.joints[5]
			if v65 then
				local v66 = v36[5] + v64
				local v67 = v37[5] + 0
				local v68 = v38[5] + 0
				v65.Transform = CFrame.fromEulerAnglesYXZ(v66, v67, v68)
				v39[5] = 1000000000
			end
			local v69 = v34.elbow
			local v70 = p31.joints[8]
			if v70 then
				local v71 = v36[8] + v69
				local v72 = v37[8] + 0
				local v73 = v38[8] + 0
				v70.Transform = CFrame.fromEulerAnglesYXZ(v71, v72, v73)
				v39[8] = 1000000000
			end
			return true
		end
	end
	return false
end
return v_u_1