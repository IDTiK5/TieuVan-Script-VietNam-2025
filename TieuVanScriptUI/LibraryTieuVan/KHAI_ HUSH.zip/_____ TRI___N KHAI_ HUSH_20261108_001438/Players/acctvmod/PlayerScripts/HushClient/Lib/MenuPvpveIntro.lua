-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPvpveIntro

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_25 = {
	["ID"] = "pvpintro",
	["ATTR"] = "PvpIntro",
	["OP"] = "introAccept",
	["enabled"] = function(p5) -- name: enabled
		-- upvalues: (copy) v_u_1
		if p5 == nil then
			local function v6()
				-- upvalues: (ref) v_u_1
				return require((v_u_1:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
			end
			local v7, v8 = pcall(v6)
			if v7 and type(v8) == "table" then
				local v9 = v8.rule
				if type(v9) == "function" then
					p5 = v8.rule
				else
					p5 = nil
				end
			else
				p5 = nil
			end
		end
		if type(p5) ~= "function" then
			return false
		end
		local v10, v11 = pcall(p5, "pvp")
		if v10 then
			v10 = v11 == true
		end
		return v10
	end,
	["start"] = function(p_u_12, p13, p14, p15, p16) -- name: start
		-- upvalues: (copy) v_u_25
		if not v_u_25.enabled(p16) then
			return nil
		end
		local v_u_17 = nil
		local function v18()
			-- upvalues: (ref) v_u_17, (copy) p_u_12
			v_u_17 = p_u_12.cctx.lib.MenuTipOnce
		end
		pcall(v18)
		local v19 = v_u_17
		if type(v19) == "table" then
			local v20 = v_u_17.show
			if type(v20) == "function" then
				local v21 = v_u_17.show
				local v22 = v_u_25.ID
				local v23, v24 = pcall(v21, p_u_12, v22, {
					["host"] = p13,
					["target"] = p14,
					["active"] = p15,
					["sides"] = { "below", "above" }
				})
				if v23 then
					return v24
				else
					return nil
				end
			end
		end
		return nil
	end
}
local function v_u_33(p_u_26, p_u_27) -- name: sharedMod
	-- upvalues: (copy) v_u_1
	local v28, v29 = pcall(function()
		-- upvalues: (copy) p_u_26, (copy) p_u_27
		return p_u_26.cctx.shared[p_u_27]
	end)
	if v28 and type(v29) == "table" then
		return v29
	else
		local function v30()
			-- upvalues: (ref) v_u_1, (copy) p_u_27
			return require((v_u_1:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild(p_u_27, 5)))
		end
		local v31, v32 = pcall(v30)
		if v31 then
			return v32
		else
			return nil
		end
	end
end
function v_u_25.needed(p_u_34, p35, p36) -- name: needed
	-- upvalues: (copy) v_u_25
	if not v_u_25.enabled(p36) then
		return false
	end
	local v_u_37 = nil
	if p_u_34 ~= nil then
		local function v38()
			-- upvalues: (ref) v_u_37, (copy) p_u_34, (ref) v_u_25
			v_u_37 = p_u_34:GetAttribute(v_u_25.ATTR)
		end
		pcall(v38)
	end
	if v_u_37 == "pending" then
		return true
	end
	if v_u_37 == "ok" then
		return false
	end
	if type(p35) == "table" then
		local v39 = p35.settings
		if type(v39) == "table" then
			local v40 = p35.introAccepted
			if type(v40) ~= "table" then
				return true
			end
			local v41 = v40.v
			local v42 = tonumber(v41)
			local v43 = v40.at
			local v44 = tonumber(v43)
			local v45
			if v42 == nil or (v42 < 1 or v44 == nil) then
				v45 = false
			else
				v45 = v44 > 0
			end
			return not v45
		end
	end
	return false
end
function v_u_25.gate(p46, p47, p48) -- name: gate
	-- upvalues: (copy) v_u_25
	if v_u_25.needed(p46, p47, p48) then
		return false, "Accept the first visit card before you deploy."
	else
		return true, nil
	end
end
function v_u_25.holdController(p_u_49) -- name: holdController
	local v_u_56 = {
		["st"] = nil,
		["down"] = false,
		["done"] = false,
		["progress"] = 0,
		["st"] = {
			["since"] = nil,
			["done"] = false
		},
		["press"] = function() -- name: press
			-- upvalues: (copy) v_u_56
			v_u_56.down = true
		end,
		["release"] = function() -- name: release
			-- upvalues: (copy) v_u_56
			v_u_56.down = false
		end,
		["step"] = function(p50, p51) -- name: step
			-- upvalues: (copy) v_u_56, (copy) p_u_49
			local v52
			if v_u_56.down == true then
				v52 = p51 ~= false
			else
				v52 = false
			end
			local v53, v54, v55 = p_u_49.holdStep(v_u_56.st, p50, v52)
			v_u_56.st = v53
			v_u_56.progress = v55
			if v54 then
				v_u_56.done = true
			end
			return v55
		end
	}
	return v_u_56
end
function v_u_25.cardTexts(p57, p58) -- name: cardTexts
	local v59 = p58.TEXT
	return {
		["title"] = v59.INTRO_TITLE,
		["bullets"] = v59.INTRO,
		["button"] = v59.INTRO_BUTTON,
		["done"] = v59.INTRO_BUTTON_DONE,
		["hold"] = p57.HOLD_SEC
	}
end
local function v_u_67(p60, p61, p62, p63) -- name: bulletRow
	local v64 = p60.ui
	local v65 = p60.theme.color
	local v66 = v64.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Bullet" .. p63,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p63
	}, p61)
	v64.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = false,
		["BackgroundColor3"] = v65.accent,
		["Position"] = UDim2.fromOffset(2, 7),
		["Size"] = UDim2.fromOffset(6, 6)
	}, v66)
	v64.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v66,
		["text"] = p62,
		["color"] = v65.text2,
		["position"] = UDim2.fromOffset(18, 0),
		["size"] = UDim2.new(1, -18, 0, 0)
	})
end
local v_u_68 = {
	["handle"] = nil
}
function v_u_25.showCard(p_u_69, p_u_70) -- name: showCard
	-- upvalues: (copy) v_u_25, (copy) v_u_68, (copy) v_u_33, (copy) v_u_67, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	if not v_u_25.enabled(p_u_70) then
		return nil
	end
	if v_u_68.handle ~= nil and v_u_68.handle.alive() then
		return v_u_68.handle
	end
	local v_u_71 = v_u_33(p_u_69, "StashWipeRules")
	local v72 = v_u_33(p_u_69, "PaidRules")
	if v_u_71 == nil or v72 == nil then
		return nil
	end
	local v_u_73 = p_u_69.ui
	local v_u_74 = p_u_69.theme
	local v_u_75 = v_u_74.color
	local v_u_76 = v_u_25.cardTexts(v_u_71, v72)
	local v_u_77 = v_u_25.holdController(v_u_71)
	local v_u_78 = {}
	local v_u_79 = nil
	local v_u_80 = nil
	local v_u_81 = nil
	local v_u_82 = true
	local v_u_83 = false
	local v_u_84 = {
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_82
			return v_u_82
		end,
		["controller"] = function() -- name: controller
			-- upvalues: (copy) v_u_77
			return v_u_77
		end
	}
	local function v_u_86() -- name: finish
		-- upvalues: (ref) v_u_82, (ref) v_u_78, (ref) v_u_68, (copy) v_u_84
		v_u_82 = false
		for _, v_u_85 in v_u_78 do
			pcall(function()
				-- upvalues: (copy) v_u_85
				v_u_85:Disconnect()
			end)
		end
		v_u_78 = {}
		if v_u_68.handle == v_u_84 then
			v_u_68.handle = nil
		end
	end
	local function v_u_101() -- name: send
		-- upvalues: (ref) v_u_83, (copy) p_u_69, (ref) v_u_25, (copy) v_u_71, (copy) p_u_70
		if not v_u_83 then
			v_u_83 = true
			local v_u_87 = nil
			local function v88()
				-- upvalues: (ref) v_u_87, (ref) p_u_69, (ref) v_u_25
				v_u_87 = p_u_69.op({
					["op"] = v_u_25.OP
				})
			end
			pcall(v88)
			local function v93()
				-- upvalues: (ref) p_u_69, (ref) v_u_71
				local v89 = p_u_69.profile
				if type(v89) == "table" then
					local v90 = p_u_69.profile
					local v91 = {
						["v"] = v_u_71.INTRO_VERSION
					}
					local v92 = os.time()
					v91.at = math.floor(v92)
					v90.introAccepted = v91
				end
			end
			pcall(v93)
			local v94 = p_u_69.changed
			if type(v94) == "table" then
				local v95 = p_u_69.changed.Connect
				if type(v95) == "function" then
					local v_u_96 = nil
					v_u_96 = p_u_69.changed:Connect(function(p97, p98)
						-- upvalues: (ref) v_u_25, (ref) v_u_87, (ref) v_u_96, (ref) p_u_69, (ref) p_u_70
						if p97 == "result" and (type(p98) == "table" and (p98.op == v_u_25.OP and (v_u_87 == nil or p98.req == v_u_87))) then
							v_u_96:Disconnect()
							if p98.ok == false then
								local function v100()
									-- upvalues: (ref) p_u_69
									local v99 = p_u_69.profile
									if type(v99) == "table" then
										p_u_69.profile.introAccepted = nil
									end
								end
								pcall(v100)
								task.defer(function()
									-- upvalues: (ref) v_u_25, (ref) p_u_69, (ref) p_u_70
									v_u_25.showCard(p_u_69, p_u_70)
								end)
							end
						end
					end)
				end
			end
		end
	end
	local function v109()
		-- upvalues: (copy) v_u_73, (copy) v_u_76, (ref) v_u_67, (copy) p_u_69, (copy) v_u_74, (copy) v_u_71, (ref) v_u_79, (copy) v_u_75, (ref) v_u_80, (ref) v_u_81
		return v_u_73.modal({
			["title"] = nil,
			["width"] = 520,
			["dismissable"] = false,
			["build"] = nil,
			["title"] = v_u_76.title,
			["build"] = function(p102) -- name: build
				-- upvalues: (ref) v_u_76, (ref) v_u_67, (ref) p_u_69, (ref) v_u_74, (ref) v_u_71, (ref) v_u_73, (ref) v_u_79, (ref) v_u_75, (ref) v_u_80, (ref) v_u_81
				for v103, v104 in v_u_76.bullets do
					v_u_67(p_u_69, p102, v104, v103)
				end
				local v105 = v_u_74.isTouch()
				local v106 = v_u_71.holdLayout(520 - 2 * v_u_74.space.l, v_u_74.uiScale(), v105, 0)
				local v107 = v_u_73.new("Frame", {
					["Name"] = "HoldBox",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 100,
					["Size"] = UDim2.new(1, 0, 0, v106.height)
				}, p102)
				v_u_79 = v_u_73.new("TextButton", {
					["Name"] = "HoldAccept",
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Selectable"] = true,
					["BackgroundColor3"] = v_u_75.raised,
					["Size"] = UDim2.new(1, 0, 0, v106.btn.h)
				}, v107)
				v_u_79:SetAttribute("PadDefault", true)
				v_u_73.new("UICorner", {
					["CornerRadius"] = UDim.new(0, 6)
				}, v_u_79)
				v_u_73.stroke(v_u_79, v_u_75.lineStrong)
				v_u_80 = v_u_73.new("Frame", {
					["Name"] = "Fill",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Active"] = false,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v_u_75.accent,
					["Size"] = UDim2.fromScale(0, 1)
				}, v_u_79)
				v_u_73.new("UICorner", {
					["CornerRadius"] = UDim.new(0, 6)
				}, v_u_80)
				v_u_81 = v_u_73.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["size"] = nil,
					["align"] = "center",
					["parent"] = v_u_79,
					["text"] = string.upper(v_u_76.button),
					["color"] = v_u_75.text,
					["size"] = UDim2.fromScale(1, 1)
				})
				local function v108()
					-- upvalues: (ref) v_u_81
					v_u_81.ZIndex = 3
				end
				pcall(v108)
				v_u_73.label({
					["parent"] = nil,
					["name"] = "HoldHint",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v107,
					["text"] = v_u_71.holdHint(v_u_73.device()),
					["color"] = v_u_75.muted,
					["position"] = UDim2.fromOffset(0, v106.hint.y),
					["size"] = UDim2.new(1, 0, 0, v106.hint.h)
				})
			end
		})
	end
	local v110, v111 = pcall(v109)
	if not v110 then
		warn("[MenuPvpveIntro] first visit card failed:", v111)
		return nil
	end
	local v_u_112 = v111
	v_u_68.handle = v_u_84
	if v_u_79 ~= nil then
		local v113 = v_u_78
		local v114 = v_u_79.InputBegan
		table.insert(v113, v114:Connect(function(p115)
			-- upvalues: (copy) v_u_77
			if p115.UserInputType == Enum.UserInputType.MouseButton1 or p115.UserInputType == Enum.UserInputType.Touch then
				v_u_77.press()
			end
		end))
		local v116 = v_u_78
		local v117 = v_u_79.MouseLeave
		table.insert(v116, v117:Connect(function()
			-- upvalues: (copy) v_u_77
			v_u_77.release()
		end))
	end
	local v118 = v_u_78
	local v119 = v_u_3.InputBegan
	local function v121(p120)
		-- upvalues: (ref) v_u_79, (ref) v_u_4, (copy) v_u_77
		if p120.KeyCode == Enum.KeyCode.ButtonA and (v_u_79 ~= nil and v_u_4.SelectedObject == v_u_79) then
			v_u_77.press()
		end
	end
	table.insert(v118, v119:Connect(v121))
	local v122 = v_u_78
	local v123 = v_u_3.InputEnded
	table.insert(v122, v123:Connect(function(p124)
		-- upvalues: (copy) v_u_77
		if p124.KeyCode == Enum.KeyCode.ButtonA or (p124.UserInputType == Enum.UserInputType.MouseButton1 or p124.UserInputType == Enum.UserInputType.Touch) then
			v_u_77.release()
		end
	end))
	local v125 = v_u_78
	local v126 = v_u_2.Heartbeat
	local function v131()
		-- upvalues: (ref) v_u_82, (ref) v_u_79, (ref) v_u_3, (copy) v_u_77, (ref) v_u_80, (ref) v_u_81, (copy) v_u_76, (copy) v_u_101, (ref) v_u_112, (copy) v_u_86
		if v_u_82 then
			local v127
			if v_u_79 == nil or v_u_79.Parent == nil then
				v127 = false
			else
				v127 = v_u_3.WindowFocused ~= false
			end
			local v128 = v_u_77.step(os.clock(), v127)
			if v_u_80 ~= nil and v_u_80.Parent then
				v_u_80.Size = UDim2.fromScale(v128, 1)
			end
			if v_u_77.done then
				v_u_77.done = false
				v_u_82 = false
				local function v129()
					-- upvalues: (ref) v_u_81, (ref) v_u_76
					v_u_81.Text = string.upper(v_u_76.done)
				end
				pcall(v129)
				v_u_101()
				task.delay(0.35, function()
					-- upvalues: (ref) v_u_112, (ref) v_u_86
					local function v130()
						-- upvalues: (ref) v_u_112
						v_u_112.close()
					end
					pcall(v130)
					v_u_86()
				end)
			end
		end
	end
	table.insert(v125, v126:Connect(v131))
	function v_u_84.close() -- name: close
		-- upvalues: (ref) v_u_112, (copy) v_u_86
		local function v132()
			-- upvalues: (ref) v_u_112
			v_u_112.close()
		end
		pcall(v132)
		v_u_86()
	end
	return v_u_84
end
return v_u_25