-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TaskPlaceNames

local v_u_1 = {}
local v_u_2 = utf8.char(183)
v_u_1.STILLWATER_ROOMS = {
	["HOSPITAL"] = "hospital",
	["TOWNHALL"] = "townhall",
	["GUNSTORE"] = "gunstore",
	["CHURCH"] = "church",
	["FREIGHT"] = "dispatch",
	["CHECKPOINT"] = "cp"
}
local v_u_3 = {
	["stillwater"] = "MapData",
	["hollow"] = "HollowMapData",
	["kestrel"] = "KestrelMapData",
	["overture"] = "OvertureMapData",
	["unknown5"] = "AshgroveMapData",
	["tokyo"] = "TokyoMapData"
}
local v_u_4 = nil
local v_u_5 = nil
function v_u_1.setMods(p6) -- name: setMods
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	v_u_4 = p6
	v_u_5 = nil
end
function v_u_1.mods() -- name: mods
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_3
	if v_u_4 then
		return v_u_4
	end
	if v_u_5 then
		return v_u_5
	end
	local v7 = {}
	local v8
	if script then
		v8 = script.Parent
	else
		v8 = nil
	end
	if v8 then
		for v9, v10 in v_u_3 do
			local v11 = v8:FindFirstChild(v10)
			if not v11 then
				continue
			end
			local v12 = require
			local v13, v14 = pcall(v12, v11)
			if not v13 or type(v14) ~= "table" then
				continue
			end
			v7[v9] = v14
		end
	end
	v_u_5 = v7
	return v7
end
local function v_u_23(p15, p16) -- name: stillwater
	-- upvalues: (copy) v_u_1
	local v17 = v_u_1.STILLWATER_ROOMS[string.upper(p16)] or string.lower(p16)
	local v18 = p15.BUILDINGS
	if type(v18) ~= "table" then
		return nil
	end
	for _, v19 in p15.BUILDINGS do
		if v19[2] ~= v17 then
			continue
		end
		local v20 = p15.LANDMARKS
		local v21
		if type(v20) == "table" then
			v21 = p15.LANDMARKS[v17]
		else
			v21 = nil
		end
		if type(v21) == "string" and v21 ~= "" then
			return v21
		else
			local v22 = v19[8]
			if type(v22) == "string" and v19[8] ~= "" then
				return v19[8]
			else
				return nil
			end
		end
	end
	return nil
end
local function v_u_31(p24, p25) -- name: hollow
	local v26 = p24.ROOMS
	if type(v26) ~= "table" then
		return nil
	end
	local v27 = string.upper(p25)
	for _, v28 in p24.ROOMS do
		for _, v29 in v28 do
			if v29.id ~= v27 then
				continue
			end
			local v30 = v29.name
			if type(v30) ~= "string" or v29.name == "" then
				continue
			end
			return v29.name
		end
	end
	return nil
end
function v_u_1.place(p32, p33, p34) -- name: place
	-- upvalues: (copy) v_u_1, (copy) v_u_23, (copy) v_u_31
	if type(p32) ~= "string" or (type(p33) ~= "string" or p33 == "") then
		return nil
	end
	local v35 = (p34 or v_u_1.mods())[p32]
	if type(v35) ~= "table" then
		return nil
	end
	if p32 == "stillwater" then
		return v_u_23(v35, p33)
	end
	if p32 == "hollow" then
		return v_u_31(v35, p33)
	end
	local v36 = string.lower(p33)
	local v37 = v35.LOTS
	if type(v37) == "table" then
		for _, v38 in v35.LOTS do
			if type(v38) ~= "table" then
				continue
			end
			local v39 = string.lower
			local v40 = v38[1]
			if v39((tostring(v40))) ~= v36 then
				continue
			end
			local v41 = v35.LANDMARKS
			local v42
			if type(v41) == "table" then
				v42 = v35.LANDMARKS[v38[1]]
			else
				v42 = nil
			end
			local v43 = v35.NAMES
			local v44
			if type(v43) == "table" then
				v44 = v35.NAMES[v38[1]]
			else
				v44 = nil
			end
			local v45 = v35.LANDMARK_KINDS
			local v46
			if type(v45) == "table" then
				v46 = v35.LANDMARK_KINDS[v38[2]]
			else
				v46 = nil
			end
			for _, v47 in {
				v42,
				v44,
				v46,
				v38[9]
			} do
				if type(v47) ~= "string" or v47 == "" then
					continue
				end
				return v47
			end
		end
	end
	local v48 = v35.PLACES
	if type(v48) ~= "table" then
		return nil
	end
	local v49 = v48[v36]
	if type(v49) == "table" then
		local v50 = v49[3]
		if type(v50) == "string" and v49[3] ~= "" then
			return v49[3]
		end
	end
	return nil
end
function v_u_1.tag(p51, p52, p53, p54) -- name: tag
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v55 = v_u_1.place(p52, p53, p54)
	if v55 then
		return p51 .. "  " .. v_u_2 .. "  " .. string.upper(v55)
	else
		return p51
	end
end
return v_u_1