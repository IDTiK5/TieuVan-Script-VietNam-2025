-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayModeSel

local v_u_39 = {
	["WAIT"] = 2,
	["shown"] = function(p1, p2, p3) -- name: shown
		local v4
		if p1 == true and p2 ~= false then
			v4 = p3 ~= true
		else
			v4 = false
		end
		return v4
	end,
	["liveShown"] = function(p_u_5) -- name: liveShown
		-- upvalues: (copy) v_u_39
		local v_u_6 = false
		local v_u_7 = true
		local function v8()
			-- upvalues: (ref) v_u_6, (copy) p_u_5
			v_u_6 = p_u_5.shared.GameMode.rule("viewModes")
		end
		pcall(v8)
		local function v9()
			-- upvalues: (ref) v_u_7, (copy) p_u_5
			v_u_7 = p_u_5.shared.Config.flag("FpTpMode")
		end
		pcall(v9)
		return v_u_39.shown(v_u_6, v_u_7, false)
	end,
	["normalise"] = function(p10) -- name: normalise
		return p10 == "fptp" and "fptp" or "classic"
	end,
	["step"] = function(p11, p12, p13) -- name: step
		-- upvalues: (copy) v_u_39
		if p12.shown ~= true then
			p11.viewMode = nil
			p11.modeSeen = nil
			p11.modeTouched = nil
			p11.modeAt = nil
			return nil, false
		end
		local v14 = v_u_39.normalise(p12.profileMode)
		local v15
		if p11.modeSeen == nil or (p11.viewMode == nil or p11.viewMode == p11.modeSeen) then
			v15 = false
		else
			p11.viewMode = v_u_39.normalise(p11.viewMode)
			p11.modeTouched = true
			p11.modeAt = p13
			v15 = true
		end
		if p12.inParty == true then
			local v16
			if p12.partyMode == "classic" or p12.partyMode == "fptp" then
				v16 = p12.partyMode
			else
				v16 = p12.leader == false and "classic" or v14
			end
			if p11.modeTouched == true and p11.viewMode ~= v16 then
				local v17 = p11.modeAt
				if p13 - (tonumber(v17) or -1000000000) < v_u_39.WAIT then
					p11.modeSeen = p11.viewMode
					return p11.viewMode, v15
				end
			end
			p11.viewMode = v16
			p11.modeTouched = nil
			p11.modeAt = nil
		elseif p11.modeTouched == true then
			if v14 == p11.viewMode then
				p11.modeTouched = nil
				p11.modeAt = nil
			end
		else
			p11.viewMode = v14
		end
		if p11.viewMode ~= "classic" and p11.viewMode ~= "fptp" then
			p11.viewMode = "classic"
		end
		p11.modeSeen = p11.viewMode
		return p11.viewMode, v15
	end,
	["payload"] = function(p18) -- name: payload
		return (p18 == nil or p18.viewMode ~= "classic" and p18.viewMode ~= "fptp") and {} or {
			["viewMode"] = p18.viewMode
		}
	end,
	["sync"] = function(p_u_19, p_u_20, p21, p22, p23) -- name: sync
		-- upvalues: (copy) v_u_39
		local v_u_24 = true
		local function v25()
			-- upvalues: (ref) v_u_24, (copy) p_u_19
			v_u_24 = p_u_19.isLeader() ~= false
		end
		pcall(v25)
		local v_u_26 = false
		local v_u_27 = true
		local function v28()
			-- upvalues: (ref) v_u_26, (copy) p_u_19
			v_u_26 = p_u_19.cctx.shared.GameMode.rule("viewModes")
		end
		pcall(v28)
		local function v29()
			-- upvalues: (ref) v_u_27, (copy) p_u_19
			v_u_27 = p_u_19.cctx.shared.Config.flag("FpTpMode")
		end
		pcall(v29)
		local v_u_30 = nil
		local function v33()
			-- upvalues: (copy) p_u_19, (ref) v_u_30
			local v31 = p_u_19.profile
			if type(v31) == "table" then
				local v32 = v31.settings
				if type(v32) == "table" then
					v_u_30 = v31.settings.raidView
				end
			end
		end
		pcall(v33)
		local v34
		if type(p21) == "table" then
			v34 = p21.viewMode
		else
			v34 = nil
		end
		local v35 = v_u_39.step
		local v36 = {
			["shown"] = v_u_39.shown(v_u_26, v_u_27, p23)
		}
		local v37
		if p22 == true then
			v37 = type(p21) == "table"
		else
			v37 = false
		end
		v36.inParty = v37
		v36.leader = v_u_24
		v36.partyMode = v34
		v36.profileMode = v_u_30
		local _, v38 = v35(p_u_20, v36, os.clock())
		if v38 then
			pcall(function()
				-- upvalues: (copy) p_u_19, (copy) p_u_20
				p_u_19.op({
					["op"] = "setting",
					["key"] = "raidView",
					["value"] = nil,
					["value"] = p_u_20.viewMode
				})
			end)
		end
	end
}
return v_u_39