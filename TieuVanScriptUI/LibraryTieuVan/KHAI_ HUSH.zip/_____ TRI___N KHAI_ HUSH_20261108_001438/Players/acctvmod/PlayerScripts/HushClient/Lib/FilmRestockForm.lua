-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmRestockForm

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
local v_u_1038 = nil
v_u_4.WINDOWS = {
	{ 900, "15 MIN" },
	{ 3600, "1 H" },
	{ 21600, "6 H" },
	{ 86400, "24 H" },
	{ 0, "WHOLE" }
}
v_u_4.DURATIONS = {
	{ 1800, "30 MIN" },
	{ 3600, "1 H" },
	{ 10800, "3 H" },
	{ 21600, "6 H" },
	{ 86400, "24 H" },
	{ 259200, "3 D" },
	{ 604800, "7 D" }
}
v_u_4.QUICK = {
	{ 600, "+10 MIN" },
	{ 1800, "+30 MIN" },
	{ 3600, "+1 H" },
	{ 7200, "+2 H" }
}
v_u_4.TIMERS = {
	{ 24, "24 H" },
	{ 72, "3 D" },
	{ 168, "7 D" },
	{ 0, "FROM SAVE" }
}
v_u_4.SHOWS = {
	{ 0, "TIMER ONLY" },
	{ 1, "ITEMS AND PRICES" },
	{ 2, "EVERYTHING" }
}
v_u_4.CONFIRM_SECONDS = 6
v_u_4.CONFIRM_GUARD = 0.4
v_u_4.PREVIEW_QUIET = 1.2
v_u_4.LIGHT_GAP = 1.1
v_u_4.MAX_ROWS = 16
v_u_4.SUGGEST_MAX = 10
local function v_u_11(p7) -- name: copy
	-- upvalues: (copy) v_u_11
	if type(p7) ~= "table" then
		return p7
	end
	local v8 = {}
	for v9, v10 in p7 do
		v8[v9] = v_u_11(v10)
	end
	return v8
end
local function v_u_18(p12) -- name: commas
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	if v_u_1038 == nil then
		local v_u_13 = "BmRs"
		local function v14()
			-- upvalues: (ref) v_u_3, (copy) v_u_13
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_13, 5)))
		end
		local v15, v16 = pcall(v14)
		if not v15 then
			v16 = nil
		end
		v_u_1038 = v16
	end
	local v17 = v_u_1038
	if v17 and v17.commas then
		return v17.commas(p12)
	else
		return tostring(p12)
	end
end
function v_u_4.parseNumber(p19) -- name: parseNumber
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	if v_u_1038 == nil then
		local v_u_20 = "BmRs"
		local function v21()
			-- upvalues: (ref) v_u_3, (copy) v_u_20
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_20, 5)))
		end
		local v22, v23 = pcall(v21)
		if not v22 then
			v23 = nil
		end
		v_u_1038 = v23
	end
	local v24 = v_u_1038
	if type(p19) == "number" then
		local v25
		if type(p19) == "number" and (p19 == p19 and p19 ~= (1 / 0)) then
			v25 = p19 ~= (-1 / 0)
		else
			v25 = false
		end
		if v25 and (p19 == math.floor(p19) and (p19 >= 0 and p19 <= 10000000000)) then
			return p19
		else
			return nil
		end
	else
		if type(p19) == "string" then
			local v26
			if type(p19) == "string" then
				local v27 = string.gsub(p19, "^%s+", "")
				v26 = string.gsub(v27, "%s+$", "")
			else
				v26 = ""
			end
			if v26 ~= "" then
				if v24 and v24.parseCount then
					return v24.parseCount(p19)
				end
				local v28
				if type(p19) == "string" then
					local v29 = string.gsub(p19, "^%s+", "")
					v28 = string.gsub(v29, "%s+$", "")
				else
					v28 = ""
				end
				local v30 = tonumber(v28)
				if v30 ~= nil then
					local v31
					if type(v30) == "number" and (v30 == v30 and v30 ~= (1 / 0)) then
						v31 = v30 ~= (-1 / 0)
					else
						v31 = false
					end
					if v31 and (v30 == math.floor(v30) and v30 >= 0) then
						return v30
					end
				end
				return nil
			end
		end
		return nil
	end
end
function v_u_4.parseHours(p32) -- name: parseHours
	if type(p32) == "number" then
		local v33
		if type(p32) == "number" and (p32 == p32 and p32 ~= (1 / 0)) then
			v33 = p32 ~= (-1 / 0)
		else
			v33 = false
		end
		if not v33 or (p32 <= 0 or p32 > 336) then
			return nil
		end
		local v34 = p32 * 3600 + 0.5
		return math.floor(v34)
	end
	local v35
	if type(p32) == "string" then
		local v36 = string.gsub(p32, "^%s+", "")
		v35 = string.gsub(v36, "%s+$", "")
	else
		v35 = ""
	end
	if v35 == "" or (#v35 > 12 or not string.match(v35, "^%d+%.?%d*$")) then
		return nil
	end
	local v37 = tonumber(v35)
	if v37 == nil or (v37 <= 0 or v37 > 336) then
		return nil
	end
	local v38 = v37 * 3600 + 0.5
	return math.floor(v38)
end
function v_u_4.parseDuration(p39) -- name: parseDuration
	local v40 = string.lower
	local v41
	if type(p39) == "string" then
		local v42 = string.gsub(p39, "^%s+", "")
		v41 = string.gsub(v42, "%s+$", "")
	else
		v41 = ""
	end
	local v43 = v40(v41)
	if v43 == "" or #v43 > 16 then
		return nil
	else
		local v44, v45 = string.match(v43, "^(%d+%.?%d*)%s*([a-z]*)$")
		if v44 then
			local v46 = tonumber(v44)
			if v46 == nil or v46 <= 0 then
				return nil
			else
				local v47
				if v45 == "" or (v45 == "m" or (v45 == "min" or (v45 == "mins" or (v45 == "minute" or v45 == "minutes")))) then
					v47 = 60
				elseif v45 == "h" or (v45 == "hr" or (v45 == "hrs" or (v45 == "hour" or v45 == "hours"))) then
					v47 = 3600
				elseif v45 == "d" or (v45 == "day" or v45 == "days") then
					v47 = 86400
				else
					if v45 ~= "s" and v45 ~= "sec" then
						return nil
					end
					v47 = 1
				end
				local v48 = v46 * v47 + 0.5
				local v49 = math.floor(v48)
				if v49 < 1 or v49 > 2678400 then
					return nil
				else
					return v49
				end
			end
		else
			return nil
		end
	end
end
function v_u_4.durationText(p50) -- name: durationText
	local v51
	if type(p50) == "number" and (p50 == p50 and p50 ~= (1 / 0)) then
		v51 = p50 ~= (-1 / 0)
	else
		v51 = false
	end
	if v51 and p50 > 0 then
		local v52 = math.floor(p50)
		local v53 = v52 // 86400
		local v54 = v52 % 86400 // 3600
		local v55 = v52 % 3600 // 60
		local v56 = {}
		if v53 > 0 then
			local v57 = v53 .. " d"
			table.insert(v56, v57)
		end
		if v54 > 0 then
			local v58 = v54 .. " h"
			table.insert(v56, v58)
		end
		if v55 > 0 then
			local v59 = v55 .. " min"
			table.insert(v56, v59)
		end
		if #v56 == 0 then
			return v52 .. " s"
		else
			return table.concat(v56, " ")
		end
	else
		return "none"
	end
end
function v_u_4.formatTime(p60, p61) -- name: formatTime
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	local v62
	if type(p60) == "number" and (p60 == p60 and p60 ~= (1 / 0)) then
		v62 = p60 ~= (-1 / 0)
	else
		v62 = false
	end
	if not v62 then
		return ""
	end
	if v_u_1038 == nil then
		local v_u_63 = "BmRs"
		local function v64()
			-- upvalues: (ref) v_u_3, (copy) v_u_63
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_63, 5)))
		end
		local v65, v66 = pcall(v64)
		if not v65 then
			v66 = nil
		end
		v_u_1038 = v66
	end
	local v67 = v_u_1038
	if p61 ~= "utc" and (v67 and v67.berlin) then
		local v68 = v67.berlin(p60)
		return string.format("%04d-%02d-%02d %02d:%02d", v68.year, v68.month, v68.day, v68.hour, v68.min)
	end
	local v69 = os.date
	local v70 = p60 + 0
	return v69("!%Y-%m-%d %H:%M", (math.floor(v70)))
end
function v_u_4.newRow() -- name: newRow
	return {
		["id"] = "",
		["u"] = "",
		["s"] = "",
		["q1"] = "",
		["q2"] = "",
		["c"] = "",
		["w"] = 3600,
		["every"] = "",
		["times"] = "",
		["typed"] = nil,
		["stack"] = nil,
		["typed"] = {}
	}
end
function v_u_4.newState() -- name: newState
	-- upvalues: (copy) v_u_4
	return {
		["v"] = 1,
		["name"] = "",
		["startText"] = "",
		["zone"] = "berlin",
		["dur"] = nil,
		["durText"] = "",
		["mr"] = "",
		["ma"] = "",
		["mc"] = "",
		["mx"] = "",
		["pe"] = "",
		["wd"] = "",
		["al"] = 24,
		["rv"] = 2,
		["lk"] = "",
		["rows"] = nil,
		["typed"] = nil,
		["replace"] = nil,
		["contRid"] = nil,
		["rows"] = { v_u_4.newRow() },
		["typed"] = {}
	}
end
function v_u_4.rowFromItem(p71, p72, p73) -- name: rowFromItem
	-- upvalues: (ref) v_u_1038, (copy) v_u_3, (copy) v_u_4
	if v_u_1038 == nil then
		local v_u_74 = "BmRs"
		local function v75()
			-- upvalues: (ref) v_u_3, (copy) v_u_74
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_74, 5)))
		end
		local v76, v77 = pcall(v75)
		if not v76 then
			v77 = nil
		end
		v_u_1038 = v77
	end
	local v78 = v_u_1038.defaultRow(p71, p72)
	local v79 = p73 or v_u_4.newRow()
	local v80, v81, v82, v83, v84, v85, v86
	if type(p71) == "table" then
		local v87 = p71.id
		if type(v87) == "string" then
			v80 = p71.id
			v79.id = v80
			if type(p71) == "table" then
				v81 = p71.stack
			else
				v81 = nil
			end
			v79.stack = v81
			if v78.u == nil then
				v82 = ""
			else
				v83 = v78.u
				v82 = tostring(v83)
			end
			v79.u = v82
			v84 = v78.q1
			v79.q1 = tostring(v84)
			v85 = v78.q2
			v79.q2 = tostring(v85)
			v86 = v78.c
			v79.c = tostring(v86)
			v79.w = v78.w
			v79.typed = {}
			return v79
		else
			v80 = v79.id
			v79.id = v80
			if type(p71) == "table" then
				v81 = p71.stack
			else
				v81 = nil
			end
			v79.stack = v81
			if v78.u == nil then
				v82 = ""
			else
				v83 = v78.u
				v82 = tostring(v83)
			end
			v79.u = v82
			v84 = v78.q1
			v79.q1 = tostring(v84)
			v85 = v78.q2
			v79.q2 = tostring(v85)
			v86 = v78.c
			v79.c = tostring(v86)
			v79.w = v78.w
			v79.typed = {}
			return v79
		end
	else
		v80 = v79.id
		v79.id = v80
		if type(p71) == "table" then
			v81 = p71.stack
		else
			v81 = nil
		end
		v79.stack = v81
		if v78.u == nil then
			v82 = ""
		else
			v83 = v78.u
			v82 = tostring(v83)
		end
		v79.u = v82
		v84 = v78.q1
		v79.q1 = tostring(v84)
		v85 = v78.q2
		v79.q2 = tostring(v85)
		v86 = v78.c
		v79.c = tostring(v86)
		v79.w = v78.w
		v79.typed = {}
		return v79
	end
end
function v_u_4.searchItems(p88, p89, p90, p91) -- name: searchItems
	-- upvalues: (ref) v_u_1038, (copy) v_u_3, (copy) v_u_4
	if v_u_1038 == nil then
		local v_u_92 = "BmRs"
		local function v93()
			-- upvalues: (ref) v_u_3, (copy) v_u_92
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_92, 5)))
		end
		local v94, v95 = pcall(v93)
		if not v94 then
			v95 = nil
		end
		v_u_1038 = v95
	end
	local v96 = v_u_1038
	local v_u_97 = "AdminItems"
	local function v98()
		-- upvalues: (ref) v_u_3, (copy) v_u_97
		return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_97, 5)))
	end
	local v99, v100 = pcall(v98)
	if not v99 then
		v100 = nil
	end
	if v96 == nil or v100 == nil then
		return {}, {
			["total"] = 0,
			["more"] = 0,
			["blocked"] = nil,
			["blockedTotal"] = 0,
			["blocked"] = {}
		}
	end
	local v101 = type(p91) ~= "table" and {} or p91
	return v100.search(p88, {
		["tool"] = "restock",
		["okFn"] = nil,
		["cat"] = nil,
		["rarity"] = nil,
		["max"] = nil,
		["items"] = nil,
		["okFn"] = v96.itemOk,
		["cat"] = v101.cat,
		["rarity"] = v101.rarity,
		["max"] = p89 or v_u_4.SUGGEST_MAX,
		["items"] = p90
	})
end
function v_u_4.countsText() -- name: countsText
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	if v_u_1038 == nil then
		local v_u_102 = "BmRs"
		local function v103()
			-- upvalues: (ref) v_u_3, (copy) v_u_102
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_102, 5)))
		end
		local v104, v105 = pcall(v103)
		if not v104 then
			v105 = nil
		end
		v_u_1038 = v105
	end
	local v106 = v_u_1038
	local v_u_107 = "AdminItems"
	local function v108()
		-- upvalues: (ref) v_u_3, (copy) v_u_107
		return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_107, 5)))
	end
	local v109, v110 = pcall(v108)
	if not v109 then
		v110 = nil
	end
	return (v106 == nil or v110 == nil) and "" or v110.countsText("restock", v106.itemOk)
end
function v_u_4.hitLabel(p111) -- name: hitLabel
	local v112 = p111.name
	local v113 = tostring(v112)
	local v114 = p111.id
	local v115 = tostring(v114)
	local v116 = string.upper
	local v117 = p111.rarityName or ""
	local v118 = v116((tostring(v117)))
	local v119 = p111.label or ""
	return ("%s  \194\183  %s  \194\183  %s %s"):format(v113, v115, v118, (tostring(v119)))
end
function v_u_4.rareNote(p120) -- name: rareNote
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	if type(p120) == "table" then
		local v121 = p120.ix
		if type(v121) == "table" then
			if v_u_1038 == nil then
				local v_u_122 = "BmRs"
				local function v123()
					-- upvalues: (ref) v_u_3, (copy) v_u_122
					return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_122, 5)))
				end
				local v124, v125 = pcall(v123)
				if not v124 then
					v125 = nil
				end
				v_u_1038 = v125
			end
			local v126 = v_u_1038
			local v_u_127 = "Items"
			local function v128()
				-- upvalues: (ref) v_u_3, (copy) v_u_127
				return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_127, 5)))
			end
			local v129, v130 = pcall(v128)
			if not v129 then
				v130 = nil
			end
			if v126 == nil or v130 == nil then
				return ""
			end
			local v131 = {}
			for _, v132 in p120.ix do
				if type(v132) ~= "table" or v132.bad == true then
					continue
				end
				local v133 = v132.id
				if type(v133) ~= "string" then
					continue
				end
				local v134 = v130.get
				local v135 = v132.id
				local v136, v137 = pcall(v134, v135)
				if not v136 or type(v137) ~= "table" then
					continue
				end
				local v138 = v126.shownRarityOf(v137)
				if v126.RS.rareRarity > v138 then
					continue
				end
				v131[v138] = (v131[v138] or 0) + 1
			end
			local v139 = {}
			for v140 = 9, v126.RS.rareRarity, -1 do
				local v141 = v131[v140]
				if v141 == nil then
					continue
				end
				local v142 = v130.RARITY_NAMES
				local v143
				if type(v142) == "table" then
					local v144 = v130.RARITY_NAMES[v140]
					v143 = type(v144) ~= "string" and "Rare" or v130.RARITY_NAMES[v140]
				else
					v143 = "Rare"
				end
				local v145 = v141 == 1 and "row" or "rows"
				table.insert(v139, ("%d %s %s"):format(v141, v143, v145))
			end
			return #v139 == 0 and "" or table.concat(v139, ", ") .. "."
		end
	end
	return ""
end
function v_u_4.buildDraft(p146, _) -- name: buildDraft
	-- upvalues: (ref) v_u_1038, (copy) v_u_3, (copy) v_u_4
	if v_u_1038 == nil then
		local v_u_147 = "BmRs"
		local function v148()
			-- upvalues: (ref) v_u_3, (copy) v_u_147
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_147, 5)))
		end
		local v149, v150 = pcall(v148)
		if not v149 then
			v150 = nil
		end
		v_u_1038 = v150
	end
	local v151 = v_u_1038
	local v152 = {}
	local v153 = {}
	local v154 = p146.name
	local v155
	if type(v154) == "string" then
		local v156 = string.gsub(v154, "^%s+", "")
		v155 = string.gsub(v156, "%s+$", "")
	else
		v155 = ""
	end
	if v155 ~= "" then
		v153.n = v155
	end
	local v157 = nil
	local v158 = p146.startText
	local v159
	if type(v158) == "string" then
		local v160 = string.gsub(v158, "^%s+", "")
		v159 = string.gsub(v160, "%s+$", "")
	else
		v159 = ""
	end
	if v159 == "" then
		table.insert(v152, "Enter the start time.")
	else
		v157 = v151.parseTime(v159, p146.zone)
		if v157 == nil then
			table.insert(v152, "The start time must look like 2026-10-16 21:00 and exist in that time zone.")
		end
	end
	local v161 = p146.dur
	local v162
	if type(v161) == "number" and (v161 == v161 and v161 ~= (1 / 0)) then
		v162 = v161 ~= (-1 / 0)
	else
		v162 = false
	end
	if v162 and p146.dur > 0 then
		if v157 ~= nil then
			v153.t0 = v157
			v153.t1 = v157 + p146.dur
		end
	else
		table.insert(v152, "Pick a duration.")
	end
	v153.rv = p146.rv
	v153.al = p146.al
	local v163 = p146.mr
	local v164
	if type(v163) == "string" then
		local v165 = string.gsub(v163, "^%s+", "")
		v164 = string.gsub(v165, "%s+$", "")
	else
		v164 = ""
	end
	local v166
	if v164 == "" then
		v166 = nil
	else
		v166 = v_u_4.parseNumber(v164)
		if v166 == nil then
			table.insert(v152, "MIN RAIDS is not a number.")
		end
	end
	v153.mr = v166
	local v167 = p146.ma
	local v168
	if type(v167) == "string" then
		local v169 = string.gsub(v167, "^%s+", "")
		v168 = string.gsub(v169, "%s+$", "")
	else
		v168 = ""
	end
	local v170
	if v168 == "" then
		v170 = nil
	else
		v170 = v_u_4.parseNumber(v168)
		if v170 == nil then
			table.insert(v152, "MIN ACCOUNT AGE is not a number.")
		end
	end
	v153.ma = v170
	local v171 = p146.mc
	local v172
	if type(v171) == "string" then
		local v173 = string.gsub(v171, "^%s+", "")
		v172 = string.gsub(v173, "%s+$", "")
	else
		v172 = ""
	end
	local v174
	if v172 == "" then
		v174 = nil
	else
		v174 = v_u_4.parseNumber(v172)
		if v174 == nil then
			table.insert(v152, "MIN PLAYED DAYS is not a number.")
		end
	end
	v153.mc = v174
	local v175 = p146.mx
	local v176
	if type(v175) == "string" then
		local v177 = string.gsub(v175, "^%s+", "")
		v176 = string.gsub(v177, "%s+$", "")
	else
		v176 = ""
	end
	local v178
	if v176 == "" then
		v178 = nil
	else
		v178 = v_u_4.parseNumber(v176)
		if v178 == nil then
			table.insert(v152, "MIN EXTRACTIONS is not a number.")
		end
	end
	v153.mx = v178
	local v179 = p146.pe
	local v180
	if type(v179) == "string" then
		local v181 = string.gsub(v179, "^%s+", "")
		v180 = string.gsub(v181, "%s+$", "")
	else
		v180 = ""
	end
	local v182
	if v180 == "" then
		v182 = nil
	else
		v182 = v_u_4.parseNumber(v180)
		if v182 == nil then
			table.insert(v152, "EXPECTED PLAYERS is not a number.")
		end
	end
	v153.pe = v182
	local v183 = p146.wd
	local v184
	if type(v183) == "string" then
		local v185 = string.gsub(v183, "^%s+", "")
		v184 = string.gsub(v185, "%s+$", "")
	else
		v184 = ""
	end
	local v186
	if v184 == "" then
		v186 = nil
	else
		v186 = v_u_4.parseNumber(v184)
		if v186 == nil then
			table.insert(v152, "DRAW WINDOW is not a number.")
		end
	end
	v153.wd = v186
	local v187 = p146.lk
	local v188
	if type(v187) == "string" then
		local v189 = string.gsub(v187, "^%s+", "")
		v188 = string.gsub(v189, "%s+$", "")
	else
		v188 = ""
	end
	local v190
	if v188 == "" then
		v190 = nil
	else
		v190 = v_u_4.parseNumber(v188)
		if v190 == nil then
			table.insert(v152, "RESALE LOCK is not a number.")
		end
	end
	v153.lk = v190
	local v191 = {}
	for v192, v193 in p146.rows do
		local v194 = string.lower
		local v195 = v193.id
		local v196
		if type(v195) == "string" then
			local v197 = string.gsub(v195, "^%s+", "")
			v196 = string.gsub(v197, "%s+$", "")
		else
			v196 = ""
		end
		local v198 = v194(v196)
		local v199
		if v198 == "" then
			v199 = false
			local v200 = v193.u
			local v201
			if type(v200) == "string" then
				local v202 = string.gsub(v200, "^%s+", "")
				v201 = string.gsub(v202, "%s+$", "")
			else
				v201 = ""
			end
			if v201 == "" then
				local v203 = v193.s
				local v204
				if type(v203) == "string" then
					local v205 = string.gsub(v203, "^%s+", "")
					v204 = string.gsub(v205, "%s+$", "")
				else
					v204 = ""
				end
				v199 = v204 == ""
			end
		else
			v199 = false
		end
		if v199 then
			continue
		end
		local v206 = {
			["id"] = v198
		}
		if v198 == "" or not string.match(v198, "^[a-z0-9_]+$") then
			table.insert(v152, ("Row %d: pick an item."):format(v192))
		end
		local v207 = v193.u
		local v208
		if type(v207) == "string" then
			local v209 = string.gsub(v207, "^%s+", "")
			v208 = string.gsub(v209, "%s+$", "")
		else
			v208 = ""
		end
		local v210
		if v208 == "" then
			v210 = nil
		else
			v210 = v_u_4.parseNumber(v208)
			if v210 == nil then
				local v211 = (not v192 and "" or ("Row %d: "):format(v192)) .. "PRICE EACH is not a number."
				table.insert(v152, v211)
			end
		end
		v206.u = v210
		local v212 = v193.s
		local v213
		if type(v212) == "string" then
			local v214 = string.gsub(v212, "^%s+", "")
			v213 = string.gsub(v214, "%s+$", "")
		else
			v213 = ""
		end
		local v215
		if v213 == "" then
			v215 = nil
		else
			v215 = v_u_4.parseNumber(v213)
			if v215 == nil then
				local v216 = (not v192 and "" or ("Row %d: "):format(v192)) .. "TOTAL AMOUNT is not a number."
				table.insert(v152, v216)
			end
		end
		v206.s = v215
		local v217 = v193.q1
		local v218
		if type(v217) == "string" then
			local v219 = string.gsub(v217, "^%s+", "")
			v218 = string.gsub(v219, "%s+$", "")
		else
			v218 = ""
		end
		local v220
		if v218 == "" then
			v220 = nil
		else
			v220 = v_u_4.parseNumber(v218)
			if v220 == nil then
				local v221 = (not v192 and "" or ("Row %d: "):format(v192)) .. "MIN PER BUY is not a number."
				table.insert(v152, v221)
			end
		end
		v206.q1 = v220
		local v222 = v193.q2
		local v223
		if type(v222) == "string" then
			local v224 = string.gsub(v222, "^%s+", "")
			v223 = string.gsub(v224, "%s+$", "")
		else
			v223 = ""
		end
		local v225
		if v223 == "" then
			v225 = nil
		else
			v225 = v_u_4.parseNumber(v223)
			if v225 == nil then
				local v226 = (not v192 and "" or ("Row %d: "):format(v192)) .. "MAX PER BUY is not a number."
				table.insert(v152, v226)
			end
		end
		v206.q2 = v225
		local v227 = v193.c
		local v228
		if type(v227) == "string" then
			local v229 = string.gsub(v227, "^%s+", "")
			v228 = string.gsub(v229, "%s+$", "")
		else
			v228 = ""
		end
		local v230
		if v228 == "" then
			v230 = nil
		else
			v230 = v_u_4.parseNumber(v228)
			if v230 == nil then
				local v231 = (not v192 and "" or ("Row %d: "):format(v192)) .. "LIMIT PER PLAYER is not a number."
				table.insert(v152, v231)
			end
		end
		v206.c = v230
		v206.w = v193.w
		local v232 = v193.every
		local v233
		if type(v232) == "string" then
			local v234 = string.gsub(v232, "^%s+", "")
			v233 = string.gsub(v234, "%s+$", "")
		else
			v233 = ""
		end
		local v235 = v193.times
		local v236
		if type(v235) == "string" then
			local v237 = string.gsub(v235, "^%s+", "")
			v236 = string.gsub(v237, "%s+$", "")
		else
			v236 = ""
		end
		if v233 ~= "" or v236 ~= "" then
			local v238 = v_u_4.parseHours(v233)
			local v239 = v_u_4.parseNumber(v236)
			if v238 == nil then
				table.insert(v152, ("Row %d: REPEAT EVERY is a number of hours."):format(v192))
			end
			if v239 == nil or (v239 < 1 or v_u_4.MAX_ROWS < v239) then
				local v240 = v_u_4.MAX_ROWS
				table.insert(v152, ("Row %d: FOR N DROPS is a number from 1 to %d."):format(v192, v240))
			end
			if v238 ~= nil and v239 ~= nil then
				v206.rp = {
					["every"] = v238,
					["times"] = v239
				}
			end
		end
		local v241 = v193.typed
		if type(v241) == "table" then
			local v242 = {}
			local v243 = false
			for v244, v245 in v193.typed do
				if v245 ~= true then
					continue
				end
				v242[v244] = true
				v243 = true
			end
			if v243 then
				v206.typed = v242
			end
		end
		table.insert(v191, v206)
	end
	v153.ix = v191
	if #v191 == 0 then
		table.insert(v152, "Add at least one item.")
	end
	if #v191 > v_u_4.MAX_ROWS then
		table.insert(v152, "A restock holds at most 16 rows.")
	end
	local v246 = p146.typed
	if type(v246) == "table" then
		local v247 = {}
		local v248 = false
		for v249, v250 in p146.typed do
			if v250 ~= true then
				continue
			end
			v247[v249] = true
			v248 = true
		end
		if v248 then
			v153.typed = v247
		end
	end
	if #v152 > 0 then
		return nil, v152, v157
	else
		return v153, v152, v157
	end
end
function v_u_4.rowMap(p251) -- name: rowMap
	-- upvalues: (copy) v_u_4
	local v252 = {}
	if type(p251) == "table" then
		local v253 = p251.rows
		if type(v253) == "table" then
			for v254, v255 in p251.rows do
				local v256 = string.lower
				local v257 = v255.id
				local v258
				if type(v257) == "string" then
					local v259 = string.gsub(v257, "^%s+", "")
					v258 = string.gsub(v259, "%s+$", "")
				else
					v258 = ""
				end
				local v260
				if v256(v258) == "" then
					v260 = false
					local v261 = v255.u
					local v262
					if type(v261) == "string" then
						local v263 = string.gsub(v261, "^%s+", "")
						v262 = string.gsub(v263, "%s+$", "")
					else
						v262 = ""
					end
					if v262 == "" then
						local v264 = v255.s
						local v265
						if type(v264) == "string" then
							local v266 = string.gsub(v264, "^%s+", "")
							v265 = string.gsub(v266, "%s+$", "")
						else
							v265 = ""
						end
						v260 = v265 == ""
					end
				else
					v260 = false
				end
				if v260 then
					continue
				end
				local v267 = 1
				local v268 = v255.every
				local v269
				if type(v268) == "string" then
					local v270 = string.gsub(v268, "^%s+", "")
					v269 = string.gsub(v270, "%s+$", "")
				else
					v269 = ""
				end
				local v271 = v255.times
				local v272
				if type(v271) == "string" then
					local v273 = string.gsub(v271, "^%s+", "")
					v272 = string.gsub(v273, "%s+$", "")
				else
					v272 = ""
				end
				local v274
				if v269 == "" and v272 == "" then
					v274 = v267
				else
					local v275 = v_u_4.parseHours(v269)
					v274 = v_u_4.parseNumber(v272)
					if v275 == nil or (v274 == nil or v274 < 1) then
						v274 = v267
					elseif v274 > v_u_4.MAX_ROWS then
						v274 = v267
					end
				end
				for _ = 1, v274 do
					table.insert(v252, v254)
				end
			end
			return v252
		end
	end
	return v252
end
function v_u_4.signature(p276, p277, p278) -- name: signature
	-- upvalues: (copy) v_u_4
	local v279 = v_u_4.buildDraft(p276, nil)
	if v279 == nil then
		return ""
	end
	local function v_u_288(p280) -- name: ser
		-- upvalues: (copy) v_u_288
		if type(p280) ~= "table" then
			return tostring(p280)
		end
		local v281 = {}
		for v282 in p280 do
			local v283 = tostring(v282)
			table.insert(v281, v283)
		end
		table.sort(v281)
		local v284 = {}
		for _, v285 in v281 do
			local v286 = p280[v285]
			if v286 == nil then
				v286 = p280[tonumber(v285)]
			end
			local v287 = v285 .. "=" .. v_u_288(v286)
			table.insert(v284, v287)
		end
		return "{" .. table.concat(v284, ",") .. "}"
	end
	return v_u_288(v279) .. "|" .. tostring(p277) .. "|" .. tostring(p278)
end
function v_u_4.stateFromPlan(p289, _) -- name: stateFromPlan
	-- upvalues: (copy) v_u_4
	local v290 = v_u_4.newState()
	if type(p289) ~= "table" then
		return v290
	end
	v290.zone = "berlin"
	local v291 = p289.n
	v290.name = type(v291) ~= "string" and "" or p289.n
	local v292 = p289.t0
	local v293
	if type(v292) == "number" and (v292 == v292 and v292 ~= (1 / 0)) then
		v293 = v292 ~= (-1 / 0)
	else
		v293 = false
	end
	if v293 then
		v290.startText = v_u_4.formatTime(p289.t0, "berlin")
	end
	local v294 = p289.t0
	local v295
	if type(v294) == "number" and (v294 == v294 and v294 ~= (1 / 0)) then
		v295 = v294 ~= (-1 / 0)
	else
		v295 = false
	end
	if v295 then
		local v296 = p289.t1
		local v297
		if type(v296) == "number" and (v296 == v296 and v296 ~= (1 / 0)) then
			v297 = v296 ~= (-1 / 0)
		else
			v297 = false
		end
		if v297 then
			v290.dur = p289.t1 - p289.t0
			v290.durText = v_u_4.durationText(v290.dur)
		end
	end
	local v298 = p289.mr
	local v299
	if type(v298) == "number" and (v298 == v298 and v298 ~= (1 / 0)) then
		v299 = v298 ~= (-1 / 0)
	else
		v299 = false
	end
	local v300 = not v299 and "" or tostring(v298)
	local v301 = p289.ma
	local v302
	if type(v301) == "number" and (v301 == v301 and v301 ~= (1 / 0)) then
		v302 = v301 ~= (-1 / 0)
	else
		v302 = false
	end
	local v303 = not v302 and "" or tostring(v301)
	local v304 = p289.mc
	local v305
	if type(v304) == "number" and (v304 == v304 and v304 ~= (1 / 0)) then
		v305 = v304 ~= (-1 / 0)
	else
		v305 = false
	end
	local v306 = not v305 and "" or tostring(v304)
	local v307 = p289.mx
	local v308
	if type(v307) == "number" and (v307 == v307 and v307 ~= (1 / 0)) then
		v308 = v307 ~= (-1 / 0)
	else
		v308 = false
	end
	local v309 = not v308 and "" or tostring(v307)
	v290.mr = v300
	v290.ma = v303
	v290.mc = v306
	v290.mx = v309
	local v310 = p289.pe
	local v311
	if type(v310) == "number" and (v310 == v310 and v310 ~= (1 / 0)) then
		v311 = v310 ~= (-1 / 0)
	else
		v311 = false
	end
	local v312 = not v311 and "" or tostring(v310)
	local v313 = p289.wd
	local v314
	if type(v313) == "number" and (v313 == v313 and v313 ~= (1 / 0)) then
		v314 = v313 ~= (-1 / 0)
	else
		v314 = false
	end
	local v315 = not v314 and "" or tostring(v313)
	local v316 = p289.lk
	local v317
	if type(v316) == "number" and (v316 == v316 and v316 ~= (1 / 0)) then
		v317 = v316 ~= (-1 / 0)
	else
		v317 = false
	end
	local v318 = not v317 and "" or tostring(v316)
	v290.pe = v312
	v290.wd = v315
	v290.lk = v318
	local v319 = p289.al
	local v320
	if type(v319) == "number" and (v319 == v319 and v319 ~= (1 / 0)) then
		v320 = v319 ~= (-1 / 0)
	else
		v320 = false
	end
	v290.al = not v320 and 24 or p289.al
	local v321 = p289.rv
	local v322
	if type(v321) == "number" and (v321 == v321 and v321 ~= (1 / 0)) then
		v322 = v321 ~= (-1 / 0)
	else
		v322 = false
	end
	v290.rv = not v322 and 2 or p289.rv
	v290.rows = {}
	local v323 = {}
	local v324 = p289.ix
	if type(v324) == "table" then
		for v325 = 1, #p289.ix do
			local v326 = p289.ix[v325]
			if type(v326) ~= "table" or (v326.bad == true or v326.off == true) then
				continue
			end
			local v327 = v326.id
			if type(v327) ~= "string" or v326.id == "" then
				continue
			end
			local v328 = false
			local v329 = v326.dr
			if type(v329) == "table" then
				local v330 = v326.id
				local v331 = v326.dr.n
				local v332 = v330 .. "|" .. tostring(v331)
				if v326.dr.i > 1 and v323[v332] then
					v328 = true
				elseif v326.dr.i == 1 then
					v323[v332] = true
				end
			end
			if v328 then
				continue
			end
			local v333 = v_u_4.newRow()
			v333.id = v326.id
			local v334 = v326.u
			local v335
			if type(v334) == "number" and (v334 == v334 and v334 ~= (1 / 0)) then
				v335 = v334 ~= (-1 / 0)
			else
				v335 = false
			end
			local v336 = not v335 and "" or tostring(v334)
			local v337 = v326.s
			local v338
			if type(v337) == "number" and (v337 == v337 and v337 ~= (1 / 0)) then
				v338 = v337 ~= (-1 / 0)
			else
				v338 = false
			end
			local v339 = not v338 and "" or tostring(v337)
			local v340 = v326.q1
			local v341
			if type(v340) == "number" and (v340 == v340 and v340 ~= (1 / 0)) then
				v341 = v340 ~= (-1 / 0)
			else
				v341 = false
			end
			local v342 = not v341 and "" or tostring(v340)
			local v343 = v326.q2
			local v344
			if type(v343) == "number" and (v343 == v343 and v343 ~= (1 / 0)) then
				v344 = v343 ~= (-1 / 0)
			else
				v344 = false
			end
			local v345 = not v344 and "" or tostring(v343)
			local v346 = v326.c
			local v347
			if type(v346) == "number" and (v346 == v346 and v346 ~= (1 / 0)) then
				v347 = v346 ~= (-1 / 0)
			else
				v347 = false
			end
			local v348 = not v347 and "" or tostring(v346)
			v333.u = v336
			v333.s = v339
			v333.q1 = v342
			v333.q2 = v345
			v333.c = v348
			local v349 = v326.w
			local v350
			if type(v349) == "number" and (v349 == v349 and v349 ~= (1 / 0)) then
				v350 = v349 ~= (-1 / 0)
			else
				v350 = false
			end
			v333.w = not v350 and 3600 or v326.w
			local v351 = v326.dr
			if type(v351) == "table" then
				local v352 = v326.a
				local v353
				if type(v352) == "number" and (v352 == v352 and v352 ~= (1 / 0)) then
					v353 = v352 ~= (-1 / 0)
				else
					v353 = false
				end
				if v353 then
					local v354 = v326.b
					local v355
					if type(v354) == "number" and (v354 == v354 and v354 ~= (1 / 0)) then
						v355 = v354 ~= (-1 / 0)
					else
						v355 = false
					end
					if v355 and v326.dr.i == 1 then
						local v356 = (v326.b - v326.a) / 3600
						v333.every = tostring(v356)
						local v357 = v326.dr.n
						v333.times = tostring(v357)
					end
				end
			end
			local v358 = v290.rows
			table.insert(v358, v333)
		end
	end
	if #v290.rows == 0 then
		v290.rows = { v_u_4.newRow() }
	end
	local v359 = p289.r
	local v360
	if type(v359) == "string" then
		v360 = p289.r
	else
		v360 = nil
	end
	v290.replace = v360
	return v290
end
function v_u_4.neededWords(p361) -- name: neededWords
	local v362 = {}
	local v363 = {}
	if type(p361) == "table" then
		for _, v364 in p361 do
			if type(v364) ~= "table" then
				continue
			end
			local v365 = v364.need
			if type(v365) ~= "string" then
				continue
			end
			local v366 = v364.need
			local v367 = v364.row
			local v368 = v366 .. "|" .. tostring(v367)
			if v363[v368] then
				continue
			end
			v363[v368] = true
			local v369 = {
				["word"] = v364.need,
				["row"] = v364.row
			}
			table.insert(v362, v369)
		end
	end
	return v362
end
function v_u_4.loadBars(p370) -- name: loadBars
	local v_u_371 = {}
	if type(p370) == "table" then
		local function v379(p372, p373) -- name: bar
			-- upvalues: (copy) v_u_371
			local v374
			if type(p373) == "number" and (p373 == p373 and p373 ~= (1 / 0)) then
				v374 = p373 ~= (-1 / 0)
			else
				v374 = false
			end
			local v375 = not v374 and 0 or p373
			local v376 = v_u_371
			local v377 = {
				["name"] = p372,
				["pct"] = v375
			}
			local v378 = v375 * 100 + 0.5
			v377.text = ("%d percent"):format((math.floor(v378)))
			table.insert(v376, v377)
		end
		v379("Server budget", p370.server)
		v379("Ring", p370.ring)
		v379("Game budget", p370.universe)
		local v380 = p370.level
		if type(v380) == "string" then
			return v_u_371, p370.level
		else
			return v_u_371, "ok"
		end
	else
		return v_u_371, "ok"
	end
end
function v_u_4.rowEcho(p381, p382) -- name: rowEcho
	-- upvalues: (ref) v_u_1038, (copy) v_u_3, (copy) v_u_4
	if v_u_1038 == nil then
		local v_u_383 = "BmRs"
		local function v384()
			-- upvalues: (ref) v_u_3, (copy) v_u_383
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_383, 5)))
		end
		local v385, v386 = pcall(v384)
		if not v385 then
			v386 = nil
		end
		v_u_1038 = v386
	end
	local v387 = v_u_1038
	local v388 = v_u_4.parseNumber(p381.u)
	local v389 = v_u_4.parseNumber(p381.s)
	if v389 == nil or v387 == nil then
		return ""
	end
	local v390
	if type(p382) == "table" then
		local v391 = p382[p381.id]
		if type(v391) == "table" then
			v390 = p382[p381.id]
		else
			v390 = nil
		end
	else
		v390 = nil
	end
	local v392 = v387.echo
	local v393 = {
		["s"] = v389,
		["u"] = v388
	}
	local v394 = {
		["weekQty"] = nil,
		["unit"] = "units"
	}
	local v395
	if v390 then
		v395 = v390.weekQty
	else
		v395 = nil
	end
	v394.weekQty = v395
	return v392(v393, v394)
end
function v_u_4.rowInfo(p396, p397) -- name: rowInfo
	-- upvalues: (copy) v_u_4
	local v398
	if type(p397) == "table" then
		local v399 = p397[p396.id]
		if type(v399) == "table" then
			v398 = p397[p396.id]
		else
			v398 = nil
		end
	else
		v398 = nil
	end
	if v398 == nil then
		return ""
	end
	local v400 = {}
	local v401 = v398.avg7
	local v402
	if type(v401) == "number" and (v401 == v401 and v401 ~= (1 / 0)) then
		v402 = v401 ~= (-1 / 0)
	else
		v402 = false
	end
	if v402 then
		local v403 = "7 day average $" .. string.format("%.2f", v398.avg7)
		table.insert(v400, v403)
	end
	local v404 = v398.cheapest
	local v405
	if type(v404) == "number" and (v404 == v404 and v404 ~= (1 / 0)) then
		v405 = v404 ~= (-1 / 0)
	else
		v405 = false
	end
	if v405 then
		local v406 = "cheapest listing $" .. string.format("%.2f", v398.cheapest)
		table.insert(v400, v406)
	end
	local v407 = v398.value
	local v408
	if type(v407) == "number" and (v407 == v407 and v407 ~= (1 / 0)) then
		v408 = v407 ~= (-1 / 0)
	else
		v408 = false
	end
	if v408 then
		local v409 = "item value $" .. string.format("%.2f", v398.value)
		table.insert(v400, v409)
	end
	local v410 = v398.floor
	local v411
	if type(v410) == "number" and (v410 == v410 and v410 ~= (1 / 0)) then
		v411 = v410 ~= (-1 / 0)
	else
		v411 = false
	end
	if v411 and v398.floor > 0 then
		local v412 = "trader floor $" .. string.format("%.2f", v398.floor)
		table.insert(v400, v412)
	end
	local v413 = v_u_4.parseNumber(p396.u)
	if v413 ~= nil then
		local v414 = v398.ref
		local v415
		if type(v414) == "number" and (v414 == v414 and v414 ~= (1 / 0)) then
			v415 = v414 ~= (-1 / 0)
		else
			v415 = false
		end
		if v415 and v398.ref > 0 then
			local v416 = (v413 / v398.ref - 1) * 100 + 0.5
			local v417 = math.floor(v416)
			local v418 = "your price "
			local v419
			if v417 > 0 then
				v419 = "is " .. v417 .. " percent above"
			else
				v419 = v417 >= 0 and "equals" or "is " .. math.abs(v417) .. " percent below"
			end
			local v420 = v418 .. v419 .. " the reference"
			table.insert(v400, v420)
		end
	end
	return table.concat(v400, "  \194\183  ")
end
function v_u_4.saveGate(p421, p422, p423, p424, p425) -- name: saveGate
	if p425 == true then
		return false, "A save is running."
	elseif type(p424) == "table" and #p424 > 0 then
		return false, p424[1]
	elseif type(p421) == "table" then
		if p422 == nil or (p422 == "" or p422 ~= p423) then
			return false, "The preview is out of date."
		elseif p421.ok == true then
			local v426 = p421.load
			if type(v426) == "table" and p421.load.level == "error" then
				return false, "The load is too high."
			else
				return true, nil
			end
		else
			local v427 = p421.errors
			local v428
			if type(v427) == "table" then
				local v429 = p421.errors[1]
				if type(v429) == "table" then
					v428 = p421.errors[1].text
				else
					v428 = nil
				end
			else
				v428 = nil
			end
			return false, tostring(v428 or "The plan has errors.")
		end
	else
		return false, "No preview yet."
	end
end
function v_u_4.etaText(p430, p431) -- name: etaText
	if type(p430) ~= "table" then
		return ""
	end
	local v432 = p430.done
	local v433
	if type(v432) == "number" and (v432 == v432 and v432 ~= (1 / 0)) then
		v433 = v432 ~= (-1 / 0)
	else
		v433 = false
	end
	local v434 = not v433 and 0 or p430.done
	local v435 = p430.total
	local v436
	if type(v435) == "number" and (v435 == v435 and v435 ~= (1 / 0)) then
		v436 = v435 ~= (-1 / 0)
	else
		v436 = false
	end
	local v437 = not v436 and 0 or p430.total
	local v438 = "Preparing stock records"
	if v437 > 0 then
		v438 = v438 .. (" %d / %d"):format(v434, v437)
		if v434 > 0 then
			local v439 = p430.startedAt
			local v440
			if type(v439) == "number" and (v439 == v439 and v439 ~= (1 / 0)) then
				v440 = v439 ~= (-1 / 0)
			else
				v440 = false
			end
			if v440 then
				local v441
				if type(p431) == "number" and (p431 == p431 and p431 ~= (1 / 0)) then
					v441 = p431 ~= (-1 / 0)
				else
					v441 = false
				end
				if v441 and (p430.startedAt < p431 and v434 < v437) then
					local v442 = p431 - p430.startedAt
					local v443 = v434 / math.max(1, v442)
					if v443 > 0 then
						local v444 = (v437 - v434) / v443
						v438 = v438 .. (", about %d s left"):format((math.ceil(v444)))
					end
				end
			end
		end
	end
	return v438 .. ". Stay on this server."
end
function v_u_4.summaryText(p445, p446) -- name: summaryText
	-- upvalues: (ref) v_u_1038, (copy) v_u_3, (copy) v_u_4
	if v_u_1038 == nil then
		local v_u_447 = "BmRs"
		local function v448()
			-- upvalues: (ref) v_u_3, (copy) v_u_447
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_447, 5)))
		end
		local v449, v450 = pcall(v448)
		if not v449 then
			v450 = nil
		end
		v_u_1038 = v450
	end
	local v451 = v_u_1038
	if type(p445) == "table" then
		local v452 = p445.ix
		if type(v452) == "table" then
			local v453 = 0
			local v454 = {}
			local v455 = 0
			for _, v456 in p445.ix do
				if type(v456) ~= "table" or v456.bad == true then
					continue
				end
				v453 = v453 + 1
				v454[v456.id] = true
				local v457 = v456.s
				local v458
				if type(v457) == "number" and (v457 == v457 and v457 ~= (1 / 0)) then
					v458 = v457 ~= (-1 / 0)
				else
					v458 = false
				end
				if not v458 then
					continue
				end
				local v459 = v456.u
				local v460
				if type(v459) == "number" and (v459 == v459 and v459 ~= (1 / 0)) then
					v460 = v459 ~= (-1 / 0)
				else
					v460 = false
				end
				if not v460 then
					continue
				end
				v455 = v455 + v456.s * v456.u
			end
			local v461 = 0
			for _ in v454 do
				v461 = v461 + 1
			end
			local v462 = p445.t0
			local v463
			if type(v462) == "number" and (v462 == v462 and v462 ~= (1 / 0)) then
				v463 = v462 ~= (-1 / 0)
			else
				v463 = false
			end
			local v464
			if v463 then
				local v465 = p445.t1
				local v466
				if type(v465) == "number" and (v465 == v465 and v465 ~= (1 / 0)) then
					v466 = v465 ~= (-1 / 0)
				else
					v466 = false
				end
				v464 = not v466 and 0 or p445.t1 - p445.t0
			else
				v464 = 0
			end
			local v467 = "%d %s, value %s, starts %s, %s"
			local v468 = v461 == 1 and "item" or "items"
			if v_u_1038 == nil then
				local v_u_469 = "BmRs"
				local function v470()
					-- upvalues: (ref) v_u_3, (copy) v_u_469
					return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_469, 5)))
				end
				local v471, v472 = pcall(v470)
				if not v471 then
					v472 = nil
				end
				v_u_1038 = v472
			end
			local v473 = v_u_1038
			local v474
			if v473 and v473.money then
				v474 = v473.money(v455)
			else
				v474 = "$" .. tostring(v455)
			end
			return v467:format(v461, v468, v474, v451.fmtStart(p445.t0, p446), v_u_4.durationText(v464))
		end
	end
	return ""
end
function v_u_4.localLoad(p475, p476) -- name: localLoad
	-- upvalues: (ref) v_u_1038, (copy) v_u_3
	if v_u_1038 == nil then
		local v_u_477 = "BmRs"
		local function v478()
			-- upvalues: (ref) v_u_3, (copy) v_u_477
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_477, 5)))
		end
		local v479, v480 = pcall(v478)
		if not v479 then
			v480 = nil
		end
		v_u_1038 = v480
	end
	local v481 = v_u_1038
	if v481 ~= nil and type(p475) == "table" then
		local v482 = p475.pe
		local v483
		if type(v482) == "number" and (v482 == v482 and v482 ~= (1 / 0)) then
			v483 = v482 ~= (-1 / 0)
		else
			v483 = false
		end
		if v483 and p475.pe >= 1 then
			local v484 = p475.ix
			if type(v484) == "table" then
				local v485 = {}
				for _, v486 in v481.expandRows(p475.ix) do
					if type(v486) ~= "table" then
						continue
					end
					local v487 = v486.s
					local v488
					if type(v487) == "number" and (v487 == v487 and v487 ~= (1 / 0)) then
						v488 = v487 ~= (-1 / 0)
					else
						v488 = false
					end
					if not v488 then
						continue
					end
					local v489 = v486.q2
					local v490
					if type(v489) == "number" and (v489 == v489 and v489 ~= (1 / 0)) then
						v490 = v489 ~= (-1 / 0)
					else
						v490 = false
					end
					if not v490 or (v486.s <= 0 or v486.q2 <= 0) then
						continue
					end
					local v491 = {
						["id"] = nil,
						["s"] = nil,
						["q1"] = nil,
						["q2"] = nil,
						["c"] = nil,
						["w"] = nil,
						["a"] = nil,
						["off"] = false,
						["id"] = v486.id,
						["s"] = v486.s,
						["q1"] = v486.q1 or 1,
						["q2"] = v486.q2,
						["c"] = v486.c or 0,
						["w"] = v486.w or 0,
						["a"] = v486.a or 0
					}
					table.insert(v485, v491)
				end
				if #v485 == 0 then
					return nil
				end
				local v492 = v481.loadPlan
				local v493 = {
					["pe"] = p475.pe,
					["ix"] = v485
				}
				local v494 = {
					["pe"] = p475.pe,
					["budgetPerPlayer"] = p476
				}
				local v495, v496 = pcall(v492, v493, v494)
				return v495 and type(v496) == "table" and {
					["level"] = nil,
					["server"] = nil,
					["ring"] = nil,
					["universe"] = nil,
					["lane"] = nil,
					["servers"] = nil,
					["estimate"] = true,
					["level"] = v496.level,
					["server"] = v496.server,
					["ring"] = v496.ring,
					["universe"] = v496.universe,
					["lane"] = v496.lane,
					["servers"] = v496.servers
				} or nil
			end
		end
	end
	return nil
end
function v_u_4.encodeState(p_u_497) -- name: encodeState
	-- upvalues: (copy) v_u_2
	local function v498()
		-- upvalues: (ref) v_u_2, (copy) p_u_497
		return v_u_2:JSONEncode(p_u_497)
	end
	local v499, v500 = pcall(v498)
	if v499 and (type(v500) == "string" and #v500 < 150000) then
		return v500
	else
		return nil
	end
end
function v_u_4.decodeState(p_u_501) -- name: decodeState
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	if type(p_u_501) ~= "string" or (p_u_501 == "" or #p_u_501 > 150000) then
		return nil
	end
	local function v502()
		-- upvalues: (ref) v_u_2, (copy) p_u_501
		return v_u_2:JSONDecode(p_u_501)
	end
	local v503, v504 = pcall(v502)
	if v503 and (type(v504) == "table" and v504.v == 1) then
		local v505 = v504.rows
		if type(v505) == "table" then
			local v506 = v_u_4.newState()
			for _, v507 in {
				"name",
				"startText",
				"zone",
				"durText",
				"mr",
				"ma",
				"mc",
				"mx",
				"pe",
				"wd",
				"lk"
			} do
				local v508 = v504[v507]
				if type(v508) ~= "string" then
					continue
				end
				v506[v507] = v504[v507]
			end
			if v504.zone ~= "utc" then
				v506.zone = "berlin"
			end
			local v509 = v504.dur
			local v510
			if type(v509) == "number" and (v509 == v509 and v509 ~= (1 / 0)) then
				v510 = v509 ~= (-1 / 0)
			else
				v510 = false
			end
			if v510 then
				v506.dur = v504.dur
			end
			local v511 = v504.al
			local v512
			if type(v511) == "number" and (v511 == v511 and v511 ~= (1 / 0)) then
				v512 = v511 ~= (-1 / 0)
			else
				v512 = false
			end
			if v512 then
				v506.al = v504.al
			end
			local v513 = v504.rv
			local v514
			if type(v513) == "number" and (v513 == v513 and v513 ~= (1 / 0)) then
				v514 = v513 ~= (-1 / 0)
			else
				v514 = false
			end
			if v514 then
				v506.rv = v504.rv
			end
			local v515 = v504.replace
			if type(v515) == "string" then
				v506.replace = v504.replace
			end
			local v516 = v504.contRid
			if type(v516) == "string" then
				v506.contRid = v504.contRid
			end
			local v517 = v504.typed
			if type(v517) == "table" then
				for v518, v519 in v504.typed do
					if v519 ~= true or (type(v518) ~= "string" or #v518 > 12) then
						continue
					end
					v506.typed[v518] = true
				end
			end
			v506.rows = {}
			for _, v520 in v504.rows do
				if type(v520) ~= "table" or #v506.rows >= v_u_4.MAX_ROWS then
					continue
				end
				local v521 = v_u_4.newRow()
				for _, v522 in {
					"id",
					"u",
					"s",
					"q1",
					"q2",
					"c",
					"every",
					"times"
				} do
					local v523 = v520[v522]
					if type(v523) ~= "string" then
						continue
					end
					v521[v522] = v520[v522]
				end
				local v524 = v520.w
				local v525
				if type(v524) == "number" and (v524 == v524 and v524 ~= (1 / 0)) then
					v525 = v524 ~= (-1 / 0)
				else
					v525 = false
				end
				if v525 then
					v521.w = v520.w
				end
				local v526 = v520.stack
				local v527
				if type(v526) == "number" and (v526 == v526 and v526 ~= (1 / 0)) then
					v527 = v526 ~= (-1 / 0)
				else
					v527 = false
				end
				if v527 then
					v521.stack = v520.stack
				end
				local v528 = v520.typed
				if type(v528) == "table" then
					for v529, v530 in v520.typed do
						if v530 ~= true or (type(v529) ~= "string" or #v529 > 12) then
							continue
						end
						v521.typed[v529] = true
					end
				end
				local v531 = v506.rows
				table.insert(v531, v521)
			end
			if #v506.rows == 0 then
				v506.rows = { v_u_4.newRow() }
			end
			return v506
		end
	end
	return nil
end
function v_u_4.kit(p532) -- name: kit
	local v_u_533 = require(script.Parent:WaitForChild("HushUI"))
	local v_u_534 = v_u_533.Theme
	local v_u_535 = v_u_534.color
	local v_u_536 = p532.body
	local v_u_537 = {
		["HushUI"] = v_u_533,
		["Theme"] = v_u_534,
		["C"] = v_u_535
	}
	local v_u_538 = 0
	function v_u_537.nextOrder() -- name: nextOrder
		-- upvalues: (ref) v_u_538
		v_u_538 = v_u_538 + 1
		return v_u_538
	end
	function v_u_537.section(p539) -- name: section
		-- upvalues: (copy) v_u_533, (copy) v_u_536, (copy) v_u_535, (copy) v_u_537
		local v540 = v_u_533.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_536,
			["text"] = p539,
			["color"] = v_u_535.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v540.LayoutOrder = v_u_537.nextOrder()
		return v540
	end
	function v_u_537.note(p541, p542, p543) -- name: note
		-- upvalues: (copy) v_u_533, (copy) v_u_536, (copy) v_u_535, (copy) v_u_537
		local v544 = v_u_533.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_536,
			["name"] = p543,
			["text"] = p541,
			["color"] = p542 or v_u_535.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v544.RichText = false
		v544.LayoutOrder = v_u_537.nextOrder()
		return v544
	end
	function v_u_537.caption(p545) -- name: caption
		-- upvalues: (copy) v_u_533, (copy) v_u_536, (copy) v_u_535, (copy) v_u_537
		local v546 = v_u_533.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v_u_536,
			["text"] = p545,
			["color"] = v_u_535.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v546.LayoutOrder = v_u_537.nextOrder()
		return v546
	end
	function v_u_537.btn(p547, p548, p549, p550, p551) -- name: btn
		-- upvalues: (copy) v_u_533
		local v552, v553 = v_u_533.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = p547,
			["text"] = p548,
			["kind"] = p549,
			["width"] = p550,
			["onClick"] = p551,
			["maxTextWidth"] = (p550 or 160) - 12
		})
		return v552, v553
	end
	function v_u_537.row(p554, p555, p556) -- name: row
		-- upvalues: (copy) v_u_533, (ref) v_u_538, (copy) v_u_534, (copy) v_u_536, (copy) v_u_537
		local v557 = v_u_533.new
		local v558 = "Frame"
		local v559 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil
		}
		if not p555 then
			local v560 = v_u_538 + 1
			p555 = "RsRow" .. tostring(v560)
		end
		v559.Name = p555
		v559.Size = UDim2.new(1, 0, 0, p554 or v_u_534.touch(34))
		local v561 = v557(v558, v559, p556 or v_u_536)
		v561.LayoutOrder = v_u_537.nextOrder()
		v_u_533.layout(v561, "h", 6)
		return v561
	end
	return v_u_537
end
function v_u_4.build(p_u_562) -- name: build
	-- upvalues: (copy) v_u_4, (ref) v_u_1038, (copy) v_u_3, (copy) v_u_5, (copy) v_u_18
	local v_u_563 = v_u_4.kit(p_u_562)
	local v_u_564 = v_u_563.HushUI
	local v_u_565 = v_u_563.Theme
	local v_u_566 = v_u_563.C
	local v567 = p_u_562.body
	local v_u_568 = p_u_562.inner
	local v_u_569 = p_u_562.call
	local v_u_570 = true
	p_u_562.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_570
		v_u_570 = false
	end)
	if v_u_1038 == nil then
		local v_u_571 = "BmRs"
		local function v572()
			-- upvalues: (ref) v_u_3, (copy) v_u_571
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_571, 5)))
		end
		local v573, v574 = pcall(v572)
		if not v573 then
			v574 = nil
		end
		v_u_1038 = v574
	end
	local v_u_575 = v_u_1038
	local v576 = v_u_4.newState()
	local v_u_577
	if v_u_5 then
		v_u_577 = v_u_4.decodeState(v_u_5:GetAttribute("FilmRestockDraft"))
	else
		v_u_577 = nil
	end
	if v_u_577 == nil then
		v_u_577 = v576
	end
	local v_u_578 = {}
	local v_u_579 = nil
	local v_u_580 = ""
	local v_u_581 = false
	local v_u_582 = nil
	local v_u_583 = {}
	local v_u_584 = {}
	local v_u_585 = false
	local v_u_586 = nil
	local v_u_587 = 0
	local v_u_588 = nil
	local v_u_589 = nil
	local v_u_590 = false
	local v_u_591 = nil
	local v_u_592 = {}
	local v_u_593 = nil
	local v_u_594 = {}
	local v_u_595 = {}
	local v_u_596 = {}
	local v_u_597 = nil
	local function v_u_598() end
	local function v_u_599() end
	local function v_u_600() end
	local v_u_601 = 0
	local function v610(p602, p603, p604, p605, p_u_606, p_u_607) -- name: addField
		-- upvalues: (copy) v_u_564, (copy) v_u_565, (ref) v_u_601, (copy) v_u_595, (ref) v_u_590, (ref) v_u_598
		local v608, v_u_609 = v_u_564.input({
			["parent"] = p602,
			["name"] = "Rs_" .. p603,
			["size"] = UDim2.fromOffset(p605, v_u_565.touch(34)),
			["placeholder"] = p604
		})
		v_u_601 = v_u_601 + 1
		v608.LayoutOrder = v_u_601
		v_u_595[p603] = v_u_609
		v_u_609.Text = p_u_606()
		v_u_609:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_590, (copy) v_u_609, (copy) p_u_606, (copy) p_u_607, (ref) v_u_598
			if not v_u_590 and v_u_609.Text ~= p_u_606() then
				p_u_607(v_u_609.Text)
				v_u_598()
			end
		end)
		return v_u_609
	end
	local function v627(p_u_611, p612, p613, p614, p_u_615, p_u_616) -- name: choices
		-- upvalues: (copy) v_u_596, (copy) v_u_563, (ref) v_u_598
		v_u_596[p_u_611] = {}
		local v617 = #p613
		local v618 = (p614 - (v617 - 1) * 6) / v617
		local v619 = math.floor(v618)
		for v620, v_u_621 in p613 do
			local v624, v625 = v_u_563.btn(p612, v_u_621[2], "secondary", v619, function()
				-- upvalues: (copy) p_u_616, (copy) v_u_621, (ref) v_u_596, (copy) p_u_611, (copy) p_u_615, (ref) v_u_598
				p_u_616(v_u_621[1])
				for v622, v623 in v_u_596[p_u_611] do
					v623.setKind(v622 == p_u_615() and "primary" or "secondary")
				end
				v_u_598()
			end)
			v624.LayoutOrder = v620
			local v626 = v_u_621[1]
			v624.Name = "Rs_" .. p_u_611 .. "_" .. tostring(v626)
			v_u_596[p_u_611][v_u_621[1]] = v625
			v625.setKind(v_u_621[1] == p_u_615() and "primary" or "secondary")
		end
	end
	v_u_563.section("Plan a restock")
	v_u_563.caption("NAME  (empty = MARKET RESTOCK, up to 24 characters)")
	v610(v_u_563.row(nil, "RsNameRow"), "name", "MARKET RESTOCK", v_u_568, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.name
	end, function(p628)
		-- upvalues: (ref) v_u_577
		v_u_577.name = p628
	end)
	v_u_563.caption("START  (type 2026-10-16 21:00 or use the buttons, the time zone is the switch)")
	local v629 = v_u_563.row(nil, "RsQuickRow")
	local v630 = (v_u_568 - 18) / 4
	local v631 = math.floor(v630)
	local v_u_632 = v_u_570
	local v633 = v_u_601
	local v_u_634 = v_u_590
	local v_u_635 = v_u_598
	local function v_u_640(p636, p637) -- name: repaintChoices
		-- upvalues: (copy) v_u_596
		for v638, v639 in v_u_596[p636] or {} do
			v639.setKind(v638 == p637 and "primary" or "secondary")
		end
	end
	local function v_u_645() -- name: serverNow
		-- upvalues: (copy) p_u_562
		if p_u_562.now then
			local v641 = p_u_562.now
			local v642, v643 = pcall(v641)
			if v642 then
				local v644
				if type(v643) == "number" and (v643 == v643 and v643 ~= (1 / 0)) then
					v644 = v643 ~= (-1 / 0)
				else
					v644 = false
				end
				if v644 then
					return v643
				end
			end
		end
		return os.time()
	end
	for v646, v_u_647 in v_u_4.QUICK do
		local v653 = v_u_563.btn(v629, v_u_647[2], "secondary", v631, function()
			-- upvalues: (copy) p_u_562, (copy) v_u_647, (ref) v_u_577, (ref) v_u_4, (ref) v_u_634, (copy) v_u_595, (ref) v_u_600, (ref) v_u_635
			local v648, v649
			if p_u_562.now then
				local v650 = p_u_562.now
				local v651
				v651, v648 = pcall(v650)
				if v651 then
					local v652
					if type(v648) == "number" and (v648 == v648 and v648 ~= (1 / 0)) then
						v652 = v648 ~= (-1 / 0)
					else
						v652 = false
					end
					if v652 then
						v649 = v648 + v_u_647[1]
						v_u_577.startText = v_u_4.formatTime(v649, v_u_577.zone)
						v_u_634 = true
						v_u_595.start.Text = v_u_577.startText
						v_u_634 = false
						v_u_600()
						v_u_635()
					else
						v648 = os.time()
						v649 = v648 + v_u_647[1]
						v_u_577.startText = v_u_4.formatTime(v649, v_u_577.zone)
						v_u_634 = true
						v_u_595.start.Text = v_u_577.startText
						v_u_634 = false
						v_u_600()
						v_u_635()
					end
				else
					v648 = os.time()
					v649 = v648 + v_u_647[1]
					v_u_577.startText = v_u_4.formatTime(v649, v_u_577.zone)
					v_u_634 = true
					v_u_595.start.Text = v_u_577.startText
					v_u_634 = false
					v_u_600()
					v_u_635()
					return
				end
			else
				v648 = os.time()
				v649 = v648 + v_u_647[1]
				v_u_577.startText = v_u_4.formatTime(v649, v_u_577.zone)
				v_u_634 = true
				v_u_595.start.Text = v_u_577.startText
				v_u_634 = false
				v_u_600()
				v_u_635()
				return
			end
		end)
		v653.LayoutOrder = v646
		local v654 = v_u_647[1]
		v653.Name = "Rs_Quick_" .. tostring(v654)
	end
	local v_u_655 = nil
	local v656 = v_u_563.row(nil, "RsStartRow")
	v610(v656, "start", "YYYY-MM-DD HH:MM", v_u_568 - 126, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.startText
	end, function(p657)
		-- upvalues: (ref) v_u_577, (ref) v_u_600
		v_u_577.startText = p657
		v_u_600()
	end)
	local v659, v660 = v_u_563.btn(v656, v_u_577.zone == "utc" and "UTC" or "BERLIN", "ghost", 120, function()
		-- upvalues: (copy) v_u_575, (ref) v_u_577, (ref) v_u_4, (ref) v_u_634, (copy) v_u_595, (ref) v_u_655, (ref) v_u_600, (ref) v_u_635
		local v658 = v_u_575.parseTime(v_u_577.startText, v_u_577.zone)
		v_u_577.zone = v_u_577.zone == "utc" and "berlin" or "utc"
		if v658 ~= nil then
			v_u_577.startText = v_u_4.formatTime(v658, v_u_577.zone)
			v_u_634 = true
			v_u_595.start.Text = v_u_577.startText
			v_u_634 = false
		end
		v_u_655.setText(v_u_577.zone == "utc" and "UTC" or "BERLIN")
		v_u_600()
		v_u_635()
	end)
	v659.Name = "Rs_Zone"
	v659.LayoutOrder = v633 + 1
	local v661 = v660
	local v_u_662 = v_u_563.note("", v_u_566.text2, "RsStartBoth")
	local function v673()
		-- upvalues: (copy) v_u_575, (ref) v_u_577, (copy) v_u_662, (copy) v_u_566, (copy) v_u_645, (ref) v_u_4
		local v663 = v_u_575.parseTime(v_u_577.startText, v_u_577.zone)
		if v663 == nil then
			local v664 = v_u_662
			local v665 = v_u_577.startText
			local v666
			if type(v665) == "string" then
				local v667 = string.gsub(v665, "^%s+", "")
				v666 = string.gsub(v667, "%s+$", "")
			else
				v666 = ""
			end
			v664.Text = v666 == "" and "Enter the start time." or "That is not a time that exists. Use YYYY-MM-DD HH:MM."
			local v668 = v_u_662
			local v669 = v_u_577.startText
			local v670
			if type(v669) == "string" then
				local v671 = string.gsub(v669, "^%s+", "")
				v670 = string.gsub(v671, "%s+$", "")
			else
				v670 = ""
			end
			local v672
			if v670 == "" then
				v672 = v_u_566.muted
			else
				v672 = v_u_566.danger
			end
			v668.TextColor3 = v672
		else
			v_u_662.Text = v_u_575.fmtBoth(v663) .. "  \194\183  " .. v_u_575.fmtStart(v663, v_u_645())
			v_u_662.TextColor3 = v_u_566.text2
			if v_u_577.zone ~= "utc" and v_u_4.formatTime(v663 + 3600, v_u_577.zone) == v_u_4.formatTime(v663, v_u_577.zone) then
				v_u_662.Text = v_u_662.Text .. "\nThis hour exists twice that night. The first one is used; switch to UTC to choose."
				v_u_662.TextColor3 = v_u_566.accent
			end
		end
	end
	v_u_563.caption("DURATION  (buttons, or type 90 min, 5 h, 2 d; longer than 24 hours needs the word LONG)")
	v627("dur", v_u_563.row(nil, "RsDurRow"), v_u_4.DURATIONS, v_u_568, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.dur
	end, function(p674)
		-- upvalues: (ref) v_u_577, (ref) v_u_4, (ref) v_u_634, (copy) v_u_595
		v_u_577.dur = p674
		v_u_577.durText = v_u_4.durationText(p674)
		v_u_634 = true
		v_u_595.dur.Text = v_u_577.durText
		v_u_634 = false
	end)
	v610(v_u_563.row(nil, "RsDurTypeRow"), "dur", "or type: 90 min, 5 h, 2 d", v_u_568, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.durText
	end, function(p675)
		-- upvalues: (ref) v_u_577, (ref) v_u_4, (copy) v_u_640
		v_u_577.durText = p675
		local v676 = v_u_4.parseDuration(p675)
		v_u_577.dur = v676
		v_u_640("dur", v676)
	end)
	v_u_563.section("Who can buy")
	v_u_563.caption("MIN RAIDS  \194\183  MIN ACCOUNT AGE (days)  \194\183  MIN PLAYED DAYS  \194\183  MIN EXTRACTIONS   (empty = 3, 7, 3, 1)")
	local v677 = v_u_563.row(nil, "RsGatesRow")
	local v678 = (v_u_568 - 18) / 4
	local v679 = math.floor(v678)
	local v_u_680 = v673
	local v_u_681 = v661
	for _, v_u_682 in {
		{ "mr", "Raids" },
		{ "ma", "Age days" },
		{ "mc", "Played days" },
		{ "mx", "Extractions" }
	} do
		v610(v677, v_u_682[1], v_u_682[2], v679, function()
			-- upvalues: (ref) v_u_577, (copy) v_u_682
			return v_u_577[v_u_682[1]]
		end, function(p683)
			-- upvalues: (ref) v_u_577, (copy) v_u_682
			v_u_577[v_u_682[1]] = p683
		end)
	end
	v_u_563.section("Players and timing")
	v_u_563.caption("EXPECTED PLAYERS (required)  \194\183  DRAW WINDOW seconds  \194\183  RESALE LOCK hours")
	v_u_563.caption("Players: the most online at once. Draw window: empty = 4, 0 = off. Resale lock: empty = 0.")
	local v684 = v_u_563.row(nil, "RsPlayersRow")
	local v685 = (v_u_568 - 12) / 3
	local v686 = math.floor(v685)
	v610(v684, "pe", "Expected players", v686, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.pe
	end, function(p687)
		-- upvalues: (ref) v_u_577
		v_u_577.pe = p687
	end)
	v610(v684, "wd", "Draw window s", v686, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.wd
	end, function(p688)
		-- upvalues: (ref) v_u_577
		v_u_577.wd = p688
	end)
	v610(v684, "lk", "Resale lock h", v686, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.lk
	end, function(p689)
		-- upvalues: (ref) v_u_577
		v_u_577.lk = p689
	end)
	local v690 = v_u_563.row(nil, "RsPeUseRow")
	local v697, v698 = v_u_563.btn(v690, "Use the proposal", "ghost", 200, function()
		-- upvalues: (copy) p_u_562, (ref) v_u_577, (ref) v_u_634, (copy) v_u_595, (ref) v_u_635
		local v691
		if p_u_562.status then
			v691 = p_u_562.status()
		else
			v691 = nil
		end
		local v692
		if type(v691) == "table" then
			v692 = v691.fleet
		else
			v692 = nil
		end
		if type(v692) == "table" then
			local v693 = v692.suggestPe
			local v694
			if type(v693) == "number" and (v693 == v693 and v693 ~= (1 / 0)) then
				v694 = v693 ~= (-1 / 0)
			else
				v694 = false
			end
			if v694 then
				local v695 = v_u_577
				local v696 = v692.suggestPe
				v695.pe = tostring(v696)
				v_u_634 = true
				v_u_595.pe.Text = v_u_577.pe
				v_u_634 = false
				v_u_635()
			end
		end
	end)
	v697.Name = "Rs_PeUse"
	local v_u_699 = v698
	local v_u_700 = v_u_564.label({
		["parent"] = nil,
		["name"] = "RsPeNote",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["track"] = false,
		["parent"] = v690,
		["color"] = v_u_566.muted,
		["size"] = UDim2.new(1, -206, 1, 0)
	})
	v_u_700.RichText = false
	v_u_563.caption("SHOW TIMER FROM  (how long before the start the market shows the timer)")
	v627("al", v_u_563.row(nil, "RsTimerRow"), v_u_4.TIMERS, v_u_568, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.al
	end, function(p701)
		-- upvalues: (ref) v_u_577
		v_u_577.al = p701
	end)
	v_u_563.caption("SHOW TO PLAYERS")
	v627("rv", v_u_563.row(nil, "RsShowRow"), v_u_4.SHOWS, v_u_568, function()
		-- upvalues: (ref) v_u_577
		return v_u_577.rv
	end, function(p702)
		-- upvalues: (ref) v_u_577
		v_u_577.rv = p702
	end)
	v_u_563.section("Items  \194\183  1 to 12 different items, up to 16 rows")
	local v_u_703 = v_u_564.new("Frame", {
		["Name"] = "RsRows",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v567)
	v_u_703.LayoutOrder = v_u_563.nextOrder()
	v_u_564.layout(v_u_703, "v", 8)
	local v_u_704 = {}
	local v_u_705 = nil
	local function v_u_712(p706) -- name: wordNeeded
		-- upvalues: (ref) v_u_4, (ref) v_u_577, (ref) v_u_579
		local v707 = {}
		local v708 = v_u_4.rowMap(v_u_577)
		if v_u_579 then
			local v709 = v_u_579.errors
			if type(v709) == "table" then
				for _, v710 in v_u_4.neededWords(v_u_579.errors) do
					if v710.row == nil or v708[v710.row] ~= p706 then
						continue
					end
					local v711 = v710.word
					table.insert(v707, v711)
				end
			end
		end
		return v707
	end
	local function v_u_719() -- name: refsOf
		-- upvalues: (ref) v_u_579, (copy) v_u_584
		local v713 = {}
		if v_u_579 then
			local v714 = v_u_579.refs
			if type(v714) == "table" then
				for v715, v716 in v_u_579.refs do
					v713[v715] = v716
				end
			end
		end
		for v717, v718 in v_u_584 do
			if v713[v717] ~= nil then
				continue
			end
			v713[v717] = v718
		end
		return v713
	end
	local function v_u_749(p720) -- name: paintRowView
		-- upvalues: (copy) v_u_704, (ref) v_u_577, (copy) v_u_719, (ref) v_u_4, (ref) v_u_579, (copy) v_u_566, (copy) v_u_712
		local v721 = v_u_704[p720]
		local v722 = v_u_577.rows[p720]
		if v721 and v722 then
			local v723 = v_u_719()
			local v724 = v_u_4.rowInfo(v722, v723)
			local v725 = v_u_4.rowEcho(v722, v723)
			v721.info.Text = v724 == "" and v725 == "" and "" or v724 .. ((v724 == "" or v725 == "") and "" or "\n") .. v725
			v721.info.Visible = v721.info.Text ~= ""
			local v726 = {}
			local v727 = false
			local v728 = v_u_4.rowMap(v_u_577)
			if v_u_579 then
				for _, v729 in v_u_579.errors or {} do
					if type(v729) ~= "table" or (v729.row == nil or v728[v729.row] ~= p720) then
						continue
					end
					local v730 = v729.text
					local v731 = tostring(v730)
					table.insert(v726, v731)
					v727 = true
				end
				for _, v732 in v_u_579.warnings or {} do
					if type(v732) ~= "table" or (v732.row == nil or v728[v732.row] ~= p720) then
						continue
					end
					local v733 = v732.text
					local v734 = "Warning: " .. tostring(v733)
					table.insert(v726, v734)
				end
				local v735 = {}
				local v736 = v_u_579.market
				if type(v736) == "table" then
					for v737, v738 in v_u_579.market do
						if type(v737) ~= "number" or (v728[v737] ~= p720 or type(v738) ~= "table") then
							continue
						end
						local v739 = v738.texts
						if type(v739) ~= "table" then
							continue
						end
						for _, v740 in v738.texts do
							if v735[v740] then
								continue
							end
							v735[v740] = true
							local v741 = tostring(v740)
							table.insert(v726, v741)
						end
					end
				end
			end
			v721.msg.Text = table.concat(v726, "\n")
			local v742 = v721.msg
			local v743
			if v727 then
				v743 = v_u_566.danger
			else
				v743 = v_u_566.accent
			end
			v742.TextColor3 = v743
			v721.msg.Visible = #v726 > 0
			local v744 = v_u_712(p720)
			for v745, v746 in v721.words do
				local v747 = v722.typed[v745] == true
				for _, v748 in v744 do
					if v748 ~= v745 then
						continue
					end
					v747 = true
				end
				v746.frame.Visible = v747
			end
		end
	end
	local function v_u_758(p750) -- name: filterOf
		-- upvalues: (copy) v_u_594, (ref) v_u_3
		local v751 = v_u_594[p750]
		if v751 == nil then
			return {}
		end
		local v_u_752 = "AdminItems"
		local function v753()
			-- upvalues: (ref) v_u_3, (copy) v_u_752
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_752, 5)))
		end
		local v754, v755 = pcall(v753)
		if not v754 then
			v755 = nil
		end
		local v756
		if v755 then
			v756 = v755.facets()
		else
			v756 = nil
		end
		local v757 = {}
		if v756 and (v751.cat ~= nil and v756.cats[v751.cat] ~= nil) then
			v757.cat = v756.cats[v751.cat].cat
		end
		if v756 and (v751.rar ~= nil and v756.rarities[v751.rar] ~= nil) then
			v757.rarity = v756.rarities[v751.rar].r
		end
		return v757
	end
	local function v_u_781(p_u_759) -- name: suggestionsFor
		-- upvalues: (copy) v_u_704, (ref) v_u_591, (ref) v_u_593, (ref) v_u_592, (copy) v_u_563, (ref) v_u_4, (copy) v_u_568, (copy) v_u_578, (copy) v_u_564, (copy) v_u_566
		local v760 = v_u_704[p_u_759]
		if v760 then
			for _, v761 in v760.sugg:GetChildren() do
				if not v761:IsA("GuiObject") then
					continue
				end
				v761:Destroy()
			end
			if v_u_591 == p_u_759 then
				local v762 = v_u_593
				local v763
				if type(v762) == "table" then
					local v764 = v762.blocked
					v763 = type(v764) ~= "table" and {} or v762.blocked
				else
					v763 = {}
				end
				v760.sugg.Visible = #v_u_592 > 0 and true or #v763 > 0
				local v765 = 0
				for _, v_u_766 in v_u_592 do
					v765 = v765 + 1
					local v767 = v_u_563.btn(v760.sugg, v_u_4.hitLabel(v_u_766), "secondary", v_u_568 - 20, function()
						-- upvalues: (ref) v_u_578, (copy) p_u_759, (copy) v_u_766
						v_u_578.pickItem(p_u_759, v_u_766.id)
					end)
					v767.Name = "Rs_Suggest_" .. v_u_766.id
					v767.LayoutOrder = v765
				end
				if type(v762) == "table" then
					local v768 = v762.more
					if type(v768) == "number" and v762.more > 0 then
						v765 = v765 + 1
						local v769 = v_u_564.label({
							["parent"] = nil,
							["name"] = "Rs_More",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["size"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v760.sugg,
							["text"] = ("+%d more. Type more letters or use the filters."):format(v762.more),
							["color"] = v_u_566.muted,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v769.RichText = false
						v769.LayoutOrder = v765
					end
				end
				for _, v770 in v763 do
					v765 = v765 + 1
					local v771 = v_u_564.label
					local v772 = {
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v760.sugg
					}
					local v773 = v770.id
					v772.name = "Rs_Blocked_" .. tostring(v773)
					local v774 = v770.name
					local v775 = tostring(v774)
					local v776 = v770.reason
					v772.text = ("%s  \194\183  %s"):format(v775, (tostring(v776)))
					v772.color = v_u_566.muted
					v772.size = UDim2.new(1, 0, 0, 0)
					local v777 = v771(v772)
					v777.RichText = false
					v777.LayoutOrder = v765
				end
				if type(v762) == "table" then
					local v778 = v762.blockedTotal
					if type(v778) == "number" and v762.blockedTotal > #v763 then
						local v779 = v765 + 1
						local v780 = v_u_564.label({
							["parent"] = nil,
							["name"] = "Rs_BlockedMore",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["size"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v760.sugg,
							["text"] = ("+%d more that are not possible."):format(v762.blockedTotal - #v763),
							["color"] = v_u_566.muted,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v780.RichText = false
						v780.LayoutOrder = v779
					end
				end
			else
				v760.sugg.Visible = false
			end
		else
			return
		end
	end
	local function v_u_887(p_u_782) -- name: buildRow
		-- upvalues: (ref) v_u_577, (copy) v_u_564, (copy) v_u_566, (copy) v_u_703, (copy) v_u_704, (copy) v_u_568, (copy) v_u_565, (ref) v_u_634, (ref) v_u_635, (copy) v_u_749, (copy) v_u_578, (copy) v_u_563, (ref) v_u_3, (copy) v_u_594, (ref) v_u_4
		local v_u_783 = v_u_577.rows[p_u_782]
		local v_u_784 = v_u_564.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "RsRow" .. p_u_782,
			["BackgroundColor3"] = v_u_566.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p_u_782
		}, v_u_703)
		v_u_564.stroke(v_u_784, v_u_566.line)
		v_u_564.pad(v_u_784, {
			10,
			10,
			8,
			10
		})
		v_u_564.layout(v_u_784, "v", 6)
		local v_u_785 = {
			["card"] = v_u_784,
			["words"] = {}
		}
		v_u_704[p_u_782] = v_u_785
		local v786 = v_u_568 - 20
		local v_u_787 = 0
		local function v791(p788, p789) -- name: crow
			-- upvalues: (ref) v_u_787, (ref) v_u_564, (ref) v_u_565, (copy) v_u_784
			v_u_787 = v_u_787 + 1
			local v790 = v_u_564.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = p789,
				["Size"] = UDim2.new(1, 0, 0, p788 or v_u_565.touch(34)),
				["LayoutOrder"] = v_u_787
			}, v_u_784)
			v_u_564.layout(v790, "h", 6)
			return v790
		end
		local function v793(p792) -- name: ccap
			-- upvalues: (ref) v_u_787, (ref) v_u_564, (copy) v_u_784, (ref) v_u_566
			v_u_787 = v_u_787 + 1
			v_u_564.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_784,
				["text"] = p792,
				["color"] = v_u_566.muted,
				["size"] = UDim2.new(1, 0, 0, 14)
			}).LayoutOrder = v_u_787
		end
		local v794 = v791(nil, "Top")
		local v795 = v786 - 96
		local v_u_796 = 0
		local function v808(p797, p798, p799, p800, p_u_801, p_u_802) -- name: mk
			-- upvalues: (ref) v_u_564, (copy) p_u_782, (ref) v_u_565, (ref) v_u_796, (ref) v_u_634, (copy) v_u_785, (copy) v_u_783, (ref) v_u_635, (ref) v_u_749
			local v803, v_u_804 = v_u_564.input({
				["parent"] = p797,
				["name"] = "Rs_" .. p798 .. "_" .. p_u_782,
				["size"] = UDim2.fromOffset(p800, v_u_565.touch(34)),
				["placeholder"] = p799
			})
			v_u_796 = v_u_796 + 1
			v803.LayoutOrder = v_u_796
			v_u_804.Text = p_u_801()
			v_u_804:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_634, (copy) v_u_804, (copy) p_u_801, (copy) p_u_802, (ref) v_u_785, (ref) v_u_783, (ref) v_u_635, (ref) v_u_749, (ref) p_u_782
				if not v_u_634 and v_u_804.Text ~= p_u_801() then
					p_u_802(v_u_804.Text)
					for v805, v806 in v_u_785.words do
						v_u_783.typed[v805] = nil
						if v806.box.Text == "" then
							continue
						end
						local v807 = v806.box
						v_u_634 = true
						v807.Text = ""
						v_u_634 = false
					end
					v_u_635()
					v_u_749(p_u_782)
				end
			end)
			return v_u_804
		end
		v_u_785.boxes = {}
		v_u_785.boxes.id = v808(v794, "id", "Item: type a name or id, e.g. 9mm", v795, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.id
		end, function(p809)
			-- upvalues: (copy) v_u_783, (ref) v_u_578, (copy) p_u_782
			local v810 = v_u_783
			local v811 = string.lower
			local v812
			if type(p809) == "string" then
				local v813 = string.gsub(p809, "^%s+", "")
				v812 = string.gsub(v813, "%s+$", "")
			else
				v812 = ""
			end
			v810.id = v811(v812)
			v_u_578.search(p_u_782, p809)
		end)
		local v814 = v_u_563.btn(v794, "Remove", "ghost", 90, function()
			-- upvalues: (ref) v_u_578, (copy) p_u_782
			v_u_578.removeRow(p_u_782)
		end)
		v814.Name = "Rs_Remove_" .. p_u_782
		v814.LayoutOrder = 99
		local v815 = v791(nil, "Filter")
		local v_u_816 = nil
		local v_u_817 = nil
		local function v_u_824() -- name: paintFilterButtons
			-- upvalues: (ref) v_u_3, (ref) v_u_594, (copy) p_u_782, (ref) v_u_816, (ref) v_u_817
			local v_u_818 = "AdminItems"
			local function v819()
				-- upvalues: (ref) v_u_3, (copy) v_u_818
				return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_818, 5)))
			end
			local v820, v821 = pcall(v819)
			if not v820 then
				v821 = nil
			end
			local v822 = not v821 and {
				["cats"] = {},
				["rarities"] = {}
			} or v821.facets()
			local v823 = v_u_594[p_u_782] or {}
			v_u_816.setText((v823.cat == nil or v822.cats[v823.cat] == nil) and "All types" or "Type: " .. v822.cats[v823.cat].label)
			v_u_817.setText((v823.rar == nil or v822.rarities[v823.rar] == nil) and "Any rarity" or "Rarity: " .. v822.rarities[v823.rar].name)
			v_u_816.setKind(v823.cat == nil and "secondary" or "primary")
			v_u_817.setKind(v823.rar == nil and "secondary" or "primary")
		end
		local v825 = (v786 - 6) / 2
		local v826 = math.floor(v825)
		local v834, v835 = v_u_563.btn(v815, "All types", "secondary", v826, function()
			-- upvalues: (ref) v_u_3, (ref) v_u_594, (copy) p_u_782, (copy) v_u_824, (ref) v_u_578, (copy) v_u_785
			local v_u_827 = "AdminItems"
			local function v828()
				-- upvalues: (ref) v_u_3, (copy) v_u_827
				return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_827, 5)))
			end
			local v829, v830 = pcall(v828)
			if not v829 then
				v830 = nil
			end
			local v831 = not v830 and {
				["cats"] = {},
				["rarities"] = {}
			} or v830.facets()
			local v832 = v_u_594[p_u_782] or {}
			v_u_594[p_u_782] = v832
			local v833 = (v832.cat or 0) + 1
			if #v831.cats < v833 then
				v833 = nil
			end
			v832.cat = v833
			v_u_824()
			v_u_578.search(p_u_782, v_u_785.boxes.id.Text)
		end)
		v_u_816 = v835
		v834.Name = "Rs_Cat_" .. p_u_782
		v834.LayoutOrder = 1
		local v843, v844 = v_u_563.btn(v815, "Any rarity", "secondary", v826, function()
			-- upvalues: (ref) v_u_3, (ref) v_u_594, (copy) p_u_782, (copy) v_u_824, (ref) v_u_578, (copy) v_u_785
			local v_u_836 = "AdminItems"
			local function v837()
				-- upvalues: (ref) v_u_3, (copy) v_u_836
				return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_836, 5)))
			end
			local v838, v839 = pcall(v837)
			if not v838 then
				v839 = nil
			end
			local v840 = not v839 and {
				["cats"] = {},
				["rarities"] = {}
			} or v839.facets()
			local v841 = v_u_594[p_u_782] or {}
			v_u_594[p_u_782] = v841
			local v842 = (v841.rar or 0) + 1
			if #v840.rarities < v842 then
				v842 = nil
			end
			v841.rar = v842
			v_u_824()
			v_u_578.search(p_u_782, v_u_785.boxes.id.Text)
		end)
		v_u_817 = v844
		v843.Name = "Rs_Rar_" .. p_u_782
		v843.LayoutOrder = 2
		v_u_824()
		v_u_785.filterRow = v815
		v_u_787 = v_u_787 + 1
		v_u_785.counts = v_u_564.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_784,
			["name"] = "Rs_Counts_" .. p_u_782,
			["text"] = v_u_4.countsText(),
			["color"] = v_u_566.muted,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_785.counts.LayoutOrder = v_u_787
		v_u_785.counts.RichText = false
		v_u_787 = v_u_787 + 1
		v_u_785.sugg = v_u_564.new("Frame", {
			["Name"] = "Suggestions",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = v_u_787
		}, v_u_784)
		v_u_564.layout(v_u_785.sugg, "v", 4)
		v793("PRICE EACH  \194\183  TOTAL AMOUNT (5k, 2m, 5.000)  \194\183  MIN PER BUY  \194\183  MAX PER BUY")
		local v845 = v791(nil, "Nums")
		local v846 = (v786 - 18) / 4
		local v847 = math.floor(v846)
		v_u_785.boxes.u = v808(v845, "u", "Price $", v847, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.u
		end, function(p848)
			-- upvalues: (copy) v_u_783
			v_u_783.u = p848
		end)
		v_u_785.boxes.s = v808(v845, "s", "Total", v847, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.s
		end, function(p849)
			-- upvalues: (copy) v_u_783
			v_u_783.s = p849
		end)
		v_u_785.boxes.q1 = v808(v845, "q1", "Min buy", v847, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.q1
		end, function(p850)
			-- upvalues: (copy) v_u_783
			v_u_783.q1 = p850
		end)
		v_u_785.boxes.q2 = v808(v845, "q2", "Max buy", v847, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.q2
		end, function(p851)
			-- upvalues: (copy) v_u_783
			v_u_783.q2 = p851
		end)
		v793("LIMIT PER PLAYER  \194\183  PER (tap to change)  \194\183  REPEAT EVERY (hours)  \194\183  FOR N DROPS")
		local v852 = v791(nil, "Limit")
		local v853 = (v786 - 18 - 0) / 4
		local v854 = math.floor(v853)
		v_u_785.boxes.c = v808(v852, "c", "Limit", v854, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.c
		end, function(p855)
			-- upvalues: (copy) v_u_783
			v_u_783.c = p855
		end)
		local v856 = v_u_563.btn
		local v857 = v_u_783.w
		local v858 = v_u_787
		local v859 = v852
		local v_u_860 = nil
		for _, v861 in v_u_4.WINDOWS do
			if v861[1] ~= v857 then
				continue
			end
			v862 = "per " .. v861[2]
		end
		local v862 = "per 1 H"
		local v873, v874 = v856(v852, v862, "secondary", v854, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_783, (copy) v_u_785, (ref) v_u_634, (ref) v_u_860, (ref) v_u_635
			local v863 = 1
			for v864, v865 in v_u_4.WINDOWS do
				if v865[1] ~= v_u_783.w then
					continue
				end
				v863 = v864
			end
			local v866 = v863 % #v_u_4.WINDOWS + 1
			v_u_783.w = v_u_4.WINDOWS[v866][1]
			v_u_783.typed = {}
			for _, v867 in v_u_785.words do
				local v868 = v867.box
				v_u_634 = true
				v868.Text = ""
				v_u_634 = false
			end
			local v869 = v_u_860.setText
			local v870 = v_u_783.w
			for _, v871 in v_u_4.WINDOWS do
				if v871[1] ~= v870 then
					continue
				end
				v872 = "per " .. v871[2]
			end
			local v872 = "per 1 H"
			v869(v872)
			v_u_635()
		end)
		local v875 = v874
		v873.Name = "Rs_Window_" .. p_u_782
		v873.LayoutOrder = 2
		v_u_785.windowApi = v875
		v_u_785.boxes.every = v808(v859, "every", "Every h", v854, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.every
		end, function(p876)
			-- upvalues: (copy) v_u_783
			v_u_783.every = p876
		end)
		v_u_785.boxes.times = v808(v859, "times", "Drops", v854, function()
			-- upvalues: (copy) v_u_783
			return v_u_783.times
		end, function(p877)
			-- upvalues: (copy) v_u_783
			v_u_783.times = p877
		end)
		v_u_787 = v858 + 1
		v_u_785.info = v_u_564.label({
			["parent"] = nil,
			["name"] = "Info",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_784,
			["color"] = v_u_566.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_785.info.LayoutOrder = v_u_787
		v_u_785.info.RichText = false
		v_u_785.info.Visible = false
		v_u_787 = v_u_787 + 1
		v_u_785.msg = v_u_564.label({
			["parent"] = nil,
			["name"] = "Msg",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_784,
			["color"] = v_u_566.danger,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_785.msg.LayoutOrder = v_u_787
		v_u_785.msg.RichText = false
		v_u_785.msg.Visible = false
		local v878 = v_u_787
		for _, v_u_879 in { "PRICE", "AMOUNT", "RARE" } do
			v_u_787 = v878 + 1
			local v880 = v_u_564.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Name"] = "Word_" .. v_u_879,
				["Size"] = UDim2.new(1, 0, 0, v_u_565.touch(34)),
				["LayoutOrder"] = v_u_787
			}, v_u_784)
			v_u_564.layout(v880, "h", 6)
			local _, v_u_881 = v_u_564.input({
				["parent"] = v880,
				["name"] = "Rs_Word_" .. v_u_879 .. "_" .. p_u_782,
				["size"] = UDim2.fromOffset(v786, v_u_565.touch(34)),
				["placeholder"] = "Type " .. v_u_879 .. " to allow this"
			})
			v_u_881.Text = v_u_783.typed[v_u_879] ~= true and "" or v_u_879
			v_u_881:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_634, (copy) v_u_881, (copy) v_u_879, (copy) v_u_783, (ref) v_u_635
				if v_u_634 then
					return
				else
					local v882 = string.upper
					local v883 = v_u_881.Text
					local v884
					if type(v883) == "string" then
						local v885 = string.gsub(v883, "^%s+", "")
						v884 = string.gsub(v885, "%s+$", "")
					else
						v884 = ""
					end
					local v886 = v882(v884) == v_u_879
					if v886 ~= (v_u_783.typed[v_u_879] == true) then
						v_u_783.typed[v_u_879] = v886 and true or nil
						v_u_635(true)
					end
				end
			end)
			v_u_785.words[v_u_879] = {
				["frame"] = v880,
				["box"] = v_u_881
			}
			v878 = v_u_787
		end
		v_u_749(p_u_782)
	end
	local function v_u_896()
		-- upvalues: (copy) v_u_703, (copy) v_u_704, (ref) v_u_577, (copy) v_u_887, (ref) v_u_591, (ref) v_u_705, (ref) v_u_4
		for _, v888 in v_u_703:GetChildren() do
			if not v888:IsA("GuiObject") then
				continue
			end
			v888:Destroy()
		end
		table.clear(v_u_704)
		for v889 = 1, #v_u_577.rows do
			v_u_887(v889)
			local v890 = v_u_704[v889]
			local v891 = v_u_577.rows[v889]
			if not (v890 and v891) then
				continue
			end
			if not v890.filterRow then
				continue
			end
			local v892
			if v_u_591 == v889 then
				v892 = true
			else
				local v893 = v891.id
				local v894
				if type(v893) == "string" then
					local v895 = string.gsub(v893, "^%s+", "")
					v894 = string.gsub(v895, "%s+$", "")
				else
					v894 = ""
				end
				v892 = v894 == ""
			end
			v890.filterRow.Visible = v892
			v890.counts.Visible = v892
		end
		if v_u_705 then
			v_u_705.setEnabled(#v_u_577.rows < v_u_4.MAX_ROWS)
		end
	end
	local v897 = v_u_563.row(nil, "RsAddRow")
	local v898, v899 = v_u_563.btn(v897, "Add item", "secondary", 160, function()
		-- upvalues: (copy) v_u_578
		v_u_578.addRow()
	end)
	v898.Name = "Rs_AddItem"
	v_u_705 = v899
	v_u_563.section("Check")
	local v_u_900 = v_u_563.note("Fill in the form. The check runs by itself and writes nothing.", v_u_566.text2, "RsPreviewStatus")
	local v_u_901 = v_u_563.note("", v_u_566.danger, "RsProblems")
	v_u_901.Visible = false
	local v_u_902 = v_u_563.note("", v_u_566.danger, "RsErrors")
	v_u_902.Visible = false
	local v_u_903 = v_u_563.note("", v_u_566.accent, "RsWarnings")
	v_u_903.Visible = false
	local v_u_904 = {}
	for _, v_u_905 in { "LOAD", "LONG" } do
		local v906 = v_u_564.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Visible"] = false,
			["Name"] = "Word_" .. v_u_905,
			["Size"] = UDim2.new(1, 0, 0, v_u_565.touch(34))
		}, v567)
		v906.LayoutOrder = v_u_563.nextOrder()
		v_u_564.layout(v906, "h", 6)
		local _, v_u_907 = v_u_564.input({
			["parent"] = v906,
			["name"] = "Rs_Word_" .. v_u_905,
			["size"] = UDim2.fromOffset(v_u_568, v_u_565.touch(34)),
			["placeholder"] = "Type " .. v_u_905 .. " to allow this plan"
		})
		v_u_907.Text = v_u_577.typed[v_u_905] ~= true and "" or v_u_905
		v_u_907:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_634, (copy) v_u_907, (copy) v_u_905, (ref) v_u_577, (ref) v_u_635
			if v_u_634 then
				return
			else
				local v908 = string.upper
				local v909 = v_u_907.Text
				local v910
				if type(v909) == "string" then
					local v911 = string.gsub(v909, "^%s+", "")
					v910 = string.gsub(v911, "%s+$", "")
				else
					v910 = ""
				end
				local v912 = v908(v910) == v_u_905
				if v912 ~= (v_u_577.typed[v_u_905] == true) then
					v_u_577.typed[v_u_905] = v912 and true or nil
					v_u_635(true)
				end
			end
		end)
		v_u_904[v_u_905] = {
			["frame"] = v906,
			["box"] = v_u_907
		}
	end
	local v_u_913 = v_u_563.note("", v_u_566.text, "RsSummary")
	v_u_913.Visible = false
	local v_u_914 = v_u_564.new("Frame", {
		["Name"] = "RsLoad",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_566.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v567)
	v_u_914.LayoutOrder = v_u_563.nextOrder()
	v_u_564.stroke(v_u_914, v_u_566.line)
	v_u_564.pad(v_u_914, {
		10,
		10,
		8,
		10
	})
	v_u_564.layout(v_u_914, "v", 4)
	local v_u_915 = v_u_564.label({
		["parent"] = nil,
		["name"] = "LoadTitle",
		["text"] = "LOAD",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_914,
		["color"] = v_u_566.accent,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v_u_915.LayoutOrder = 0
	local v_u_916 = {}
	for v917 = 1, 3 do
		local v918 = v_u_564.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v_u_914,
			["name"] = "LoadBarText" .. v917,
			["color"] = v_u_566.text2,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v918.LayoutOrder = v917 * 2 - 1
		v918.RichText = false
		local v919 = v_u_564.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "LoadTrack" .. v917,
			["BackgroundColor3"] = v_u_566.line,
			["Size"] = UDim2.new(1, 0, 0, 6),
			["LayoutOrder"] = v917 * 2
		}, v_u_914)
		v_u_916[v917] = {
			["label"] = v918,
			["fill"] = v_u_564.new("Frame", {
				["Name"] = "Fill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_566.success,
				["Size"] = UDim2.fromScale(0, 1)
			}, v919)
		}
	end
	local v_u_920 = v_u_564.label({
		["parent"] = nil,
		["name"] = "LoadNote",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_914,
		["color"] = v_u_566.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_920.LayoutOrder = 10
	v_u_920.RichText = false
	v_u_563.section("Save")
	local v_u_921 = v_u_563.note("", v_u_566.text2, "RsSaveInfo")
	local v_u_922 = v_u_563.note("", v_u_566.success, "RsSaveResult")
	v_u_922.Visible = false
	v_u_597 = v_u_563.note("", v_u_566.danger, "RsError")
	v_u_597.Visible = false
	local v923 = v_u_563.row(nil, "RsSaveRow")
	local v_u_924 = nil
	local v_u_925 = nil
	local v_u_926 = nil
	local function v_u_928() -- name: ready
		-- upvalues: (ref) v_u_4, (ref) v_u_577, (ref) v_u_579, (ref) v_u_580, (ref) v_u_583, (ref) v_u_585
		local v927 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
		return v_u_4.saveGate(v_u_579, v_u_580, v927, v_u_583, v_u_585)
	end
	local function v_u_936() -- name: paintSave
		-- upvalues: (ref) v_u_4, (ref) v_u_577, (ref) v_u_579, (ref) v_u_580, (ref) v_u_583, (ref) v_u_585, (ref) v_u_924, (ref) v_u_586, (copy) v_u_921, (copy) v_u_645, (copy) v_u_566, (ref) v_u_925, (ref) v_u_926
		local v929 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
		local v930, v931 = v_u_4.saveGate(v_u_579, v_u_580, v929, v_u_583, v_u_585)
		v_u_924.setEnabled(v930 or v_u_586 ~= nil)
		local v932
		if v_u_586 == nil then
			v932 = false
		else
			v932 = os.clock() - v_u_586 < v_u_4.CONFIRM_SECONDS
		end
		if v_u_586 ~= nil and not v932 then
			v_u_586 = nil
		end
		if v_u_585 then
			v_u_924.setText("Saving ...")
		elseif v932 then
			v_u_924.setText("PRESS AGAIN TO SAVE")
		else
			v_u_924.setText(v_u_577.replace and "Save changed plan" or "Save plan")
		end
		if not v_u_585 then
			if v932 and (v_u_579 and v_u_579.plan) then
				v_u_921.Text = v_u_4.summaryText(v_u_579.plan, v_u_645())
				local v933 = v_u_4.rareNote(v_u_579.plan)
				if v933 ~= "" then
					local v934 = v_u_921
					v934.Text = v934.Text .. "\n" .. v933
				end
				v_u_921.TextColor3 = v_u_566.text
			elseif v930 then
				v_u_921.Text = "The check is good. Press SAVE to prepare the restock."
				v_u_921.TextColor3 = v_u_566.text2
			else
				v_u_921.Text = tostring(v931 or "")
				v_u_921.TextColor3 = v_u_566.muted
			end
		end
		if v_u_925 then
			local v935
			if v_u_926 == nil then
				v935 = false
			else
				v935 = os.clock() - v_u_926 < v_u_4.CONFIRM_SECONDS
			end
			if v_u_926 ~= nil and not v935 then
				v_u_926 = nil
			end
			v_u_925.setText(v935 and "PRESS AGAIN TO DISCARD" or "Discard form")
		end
	end
	local function v_u_937()
		-- upvalues: (ref) v_u_680, (ref) v_u_599, (copy) v_u_936
		v_u_680()
		v_u_599()
		v_u_936()
	end
	local v938, v939 = v_u_563.btn(v923, "Save plan", "primary", v_u_568 - 150, function()
		-- upvalues: (copy) v_u_578
		v_u_578.savePress()
	end)
	v_u_924 = v939
	v938.Name = "Rs_Save"
	local v940, v941 = v_u_563.btn(v923, "Discard form", "ghost", 144, function()
		-- upvalues: (copy) v_u_578
		v_u_578.discardPress()
	end)
	v_u_925 = v941
	v940.Name = "Rs_Discard"
	local v_u_942 = 0
	local function v_u_961() -- name: doPreview
		-- upvalues: (ref) v_u_581, (ref) v_u_632, (ref) v_u_4, (ref) v_u_577, (ref) v_u_583, (ref) v_u_579, (ref) v_u_580, (ref) v_u_937, (copy) v_u_900, (copy) v_u_566, (copy) v_u_569, (ref) v_u_582, (ref) v_u_5, (copy) v_u_928, (ref) v_u_585, (ref) v_u_589, (copy) v_u_749
		if v_u_581 or not v_u_632 then
			return
		else
			local v_u_943, v944 = v_u_4.buildDraft(v_u_577, nil)
			v_u_583 = v944
			if v_u_943 == nil then
				v_u_579 = nil
				v_u_580 = ""
				v_u_937()
			else
				local v_u_945 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
				v_u_581 = true
				v_u_900.Text = "Checking ..."
				v_u_900.TextColor3 = v_u_566.muted
				v_u_569("preview", {
					["draft"] = v_u_943,
					["replace"] = v_u_577.replace,
					["contRid"] = v_u_577.contRid
				}, function(p946)
					-- upvalues: (ref) v_u_581, (ref) v_u_632, (ref) v_u_579, (ref) v_u_580, (copy) v_u_945, (ref) v_u_582, (ref) v_u_4, (copy) v_u_943, (ref) v_u_5, (ref) v_u_928, (ref) v_u_585, (ref) v_u_577, (ref) v_u_589, (ref) v_u_749, (ref) v_u_937
					v_u_581 = false
					if not v_u_632 then
						return
					end
					local v947, v948, v949, v950, v951, v952, v953, v954, v955
					if type(p946) == "table" then
						local v956 = p946.data
						if type(v956) == "table" then
							v_u_579 = p946.data
							v_u_580 = v_u_945
							local v957 = p946.msg or ""
							v_u_582 = tostring(v957)
							if v_u_579.load == nil then
								v_u_579.load = v_u_4.localLoad(v_u_943, nil)
							end
							if v_u_5 then
								if v_u_579 then
									v947 = v_u_579.errors
									v948 = type(v947) == "table" and #v_u_579.errors or 0
								else
									v948 = 0
								end
								if v_u_579 then
									v949 = v_u_579.warnings
									v950 = type(v949) == "table" and #v_u_579.warnings or 0
								else
									v950 = 0
								end
								v951 = v_u_5
								v952 = select
								v953 = v_u_928
								v954 = v_u_585
								v951:SetAttribute("FilmRestockForm", ("%d|%d|%s|%s"):format(v948, v950, tostring(v952(1, v953())), (tostring(v954))))
							end
							if v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid) ~= v_u_945 then
								v_u_589 = os.clock()
							end
							for v960 = 1, #v_u_577.rows do
								v_u_749(v960)
							end
							v_u_937()
						else
							v_u_579 = nil
							v_u_580 = ""
							v955 = p946 and p946.msg or "The server did not answer."
							v_u_582 = tostring(v955)
							if v_u_5 then
								if v_u_579 then
									v947 = v_u_579.errors
									v948 = type(v947) == "table" and #v_u_579.errors or 0
								else
									v948 = 0
								end
								if v_u_579 then
									v949 = v_u_579.warnings
									v950 = type(v949) == "table" and #v_u_579.warnings or 0
								else
									v950 = 0
								end
								v951 = v_u_5
								v952 = select
								v953 = v_u_928
								v954 = v_u_585
								v951:SetAttribute("FilmRestockForm", ("%d|%d|%s|%s"):format(v948, v950, tostring(v952(1, v953())), (tostring(v954))))
							end
							if v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid) ~= v_u_945 then
								v_u_589 = os.clock()
							end
							for v960 = 1, #v_u_577.rows do
								v_u_749(v960)
							end
							v_u_937()
						end
					else
						v_u_579 = nil
						v_u_580 = ""
						v955 = p946 and p946.msg or "The server did not answer."
						v_u_582 = tostring(v955)
						if v_u_5 then
							if v_u_579 then
								v947 = v_u_579.errors
								v948 = type(v947) == "table" and #v_u_579.errors or 0
							else
								v948 = 0
							end
							if v_u_579 then
								v949 = v_u_579.warnings
								v950 = type(v949) == "table" and #v_u_579.warnings or 0
							else
								v950 = 0
							end
							v951 = v_u_5
							v952 = select
							v953 = v_u_928
							v954 = v_u_585
							v951:SetAttribute("FilmRestockForm", ("%d|%d|%s|%s"):format(v948, v950, tostring(v952(1, v953())), (tostring(v954))))
						end
						if v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid) ~= v_u_945 then
							v_u_589 = os.clock()
						end
						for v960 = 1, #v_u_577.rows do
							v_u_749(v960)
						end
						v_u_937()
						return
					end
				end, "light")
			end
		end
	end
	v_u_598 = function(p962)
		-- upvalues: (copy) v_u_904, (ref) v_u_577, (ref) v_u_634, (ref) v_u_589, (ref) v_u_5, (ref) v_u_4, (ref) v_u_586, (ref) v_u_585, (copy) v_u_922, (ref) v_u_583, (ref) v_u_579, (ref) v_u_580, (ref) v_u_937
		if p962 ~= true then
			for v963, v964 in v_u_904 do
				v_u_577.typed[v963] = nil
				if v964.box.Text == "" then
					continue
				end
				local v965 = v964.box
				v_u_634 = true
				v965.Text = ""
				v_u_634 = false
			end
		end
		v_u_589 = os.clock()
		if v_u_5 then
			v_u_5:SetAttribute("FilmRestockDraft", v_u_4.encodeState(v_u_577))
		end
		v_u_586 = nil
		if not v_u_585 then
			v_u_922.Visible = false
		end
		local v966, v967 = v_u_4.buildDraft(v_u_577, nil)
		v_u_583 = v967
		if v966 == nil then
			v_u_579 = nil
			v_u_580 = ""
		end
		v_u_937()
	end
	local function v_u_1061()
		-- upvalues: (ref) v_u_583, (copy) v_u_901, (ref) v_u_579, (ref) v_u_580, (ref) v_u_4, (ref) v_u_577, (copy) v_u_900, (copy) v_u_566, (ref) v_u_581, (ref) v_u_582, (copy) v_u_902, (copy) v_u_903, (copy) v_u_904, (copy) v_u_913, (copy) v_u_914, (copy) v_u_916, (copy) v_u_915, (copy) v_u_920, (copy) p_u_562, (ref) v_u_699, (ref) v_u_18, (ref) v_u_700, (ref) v_u_1038, (ref) v_u_3
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v_u_1010, v1011, v1012, v1013, v1014, v1015, v1016, v1017, v1018, v1019, v1020, v1021, v1022, v1023, v1024, v1025, v1026, v1027, v1028, v1029, v1030, v1031, v1032, v1033, v1034, v1035, v1036, v1037, v1039, v1040, v1041, v1042, v1043, v1044, v1045, v1046, v1047, v1048, v1049, v1050, v1051, v1052
		local v_u_1010, v1011, v1012, v1013, v1014, v1015, v1016, v1017, v1018, v1019, v1020, v1021, v1022, v1023, v1024, v1025, v1026, v1027, v1028, v1029, v1030, v1031, v1032, v1033, v1034, v1035, v1036, v1037, v_u_1038, v1039, v1040, v1041, v1042, v1043, v1044, v1045, v1046, v1047, v1048, v1049, v1050, v1051, v1052
		local v1053 = 10
		while true do
			if v1053 == 1 then
				v_u_913.Visible = false
				if v_u_579 then
					v1053 = 7
				else
					v1053 = 2
				end
			elseif v1053 == 2 then
				v_u_914.Visible = false
				v1053 = 9
			elseif v1053 == 3 then
				v_u_914.Visible = false
				v1053 = 9
			elseif v1053 == 4 then
				v1036 = v_u_579.lines
				if type(v1036) == "table" and #v_u_579.lines > 0 then
					v1053 = 6
				else
					v1053 = 1
				end
			elseif v1053 == 5 then
				v_u_913.Visible = false
				if v_u_579 then
					v1053 = 7
				else
					v1053 = 8
				end
			elseif v1053 == 6 then
				v_u_913.Text = table.concat(v_u_579.lines, "\n")
				v_u_913.Visible = true
				if v_u_579 then
					v1053 = 7
				else
					v1053 = 3
				end
			elseif v1053 == 7 then
				v1037 = v_u_579.load
				if type(v1037) == "table" then
					v1045, v1046 = v_u_4.loadBars(v_u_579.load)
					v_u_914.Visible = true
					if v1046 == "ok" then
						v1047 = v_u_566.success
					elseif v1046 == "error" then
						v1047 = v_u_566.danger
					else
						v1047 = v_u_566.accent
					end
					for v1054, v1055 in v1045 do
						v_u_916[v1054].label.Text = ("%s  %s"):format(v1055.name, v1055.text)
						v1048 = v_u_916[v1054].fill
						v1049 = UDim2.fromScale
						v1050 = v1055.pct
						v1048.Size = v1049(math.clamp(v1050, 0, 1), 1)
						v_u_916[v1054].fill.BackgroundColor3 = v1047
					end
					v_u_915.Text = "LOAD  \194\183  " .. (({
						["ok"] = "LOW",
						["warn"] = "NOTICEABLE",
						["high"] = "HIGH, the word LOAD is needed",
						["error"] = "TOO HIGH, SAVE is off"
					})[v1046] or v1046) .. (v_u_579.load.estimate == true and "  \194\183  estimate" or "")
					v_u_915.TextColor3 = v1047
					v1030 = v_u_920
					v1031 = v_u_579.load.servers
					v1030.Text = type(v1031) ~= "number" and "" or ("About %d lobby servers, %d lane requests per server in the busiest minute."):format(v_u_579.load.servers, v_u_579.load.lane or 0)
				else
					v_u_914.Visible = false
				end
				v1053 = 9
			elseif v1053 == 8 then
				v_u_914.Visible = false
				v1053 = 9
			elseif v1053 == 9 then
				if p_u_562.status then
					v1032 = p_u_562.status()
				else
					v1032 = nil
				end
				if type(v1032) == "table" then
					v1033 = v1032.fleet
				else
					v1033 = nil
				end
				if type(v1033) == "table" then
					v1034 = v1033.suggestPe
					if type(v1034) == "number" and (v1034 == v1034 and v1034 ~= (1 / 0)) then
						v1035 = v1034 ~= (-1 / 0)
					else
						v1035 = false
					end
					if v1035 then
						v_u_699.setText(("Use %s"):format(v_u_18(v1033.suggestPe)))
						v1051 = v1033.age
						if type(v1051) == "number" and (v1051 == v1051 and v1051 ~= (1 / 0)) then
							v1052 = v1051 ~= (-1 / 0)
						else
							v1052 = false
						end
						v1014 = not v1052 and "" or (", measured %s ago"):format(v_u_4.durationText(v1033.age))
						v1015 = v1033.coverage
						if type(v1015) == "number" and (v1015 == v1015 and v1015 ~= (1 / 0)) then
							v1016 = v1015 ~= (-1 / 0)
						else
							v1016 = false
						end
						if v1016 then
							v1017 = v1033.coverage * 100 + 0.5
							v1026 = (", covers %d percent of the servers"):format((math.floor(v1017)))
						else
							v1026 = ""
						end
						v1027 = v_u_700
						v1028 = "1.2 x the last measurement of %s players%s%s."
						v1029 = v1033.players or 0
						if v_u_1038 == nil then
							v_u_1010 = "BmRs"
							v1011 = function()
								-- upvalues: (ref) v_u_3, (copy) v_u_1010
								return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_1010, 5)))
							end
							v1012, v1013 = pcall(v1011)
							if not v1012 then
								v1013 = nil
							end
							v_u_1038 = v1013
						end
						v1039 = v_u_1038
						if v1039 and v1039.commas then
							v1040 = v1039.commas(v1029)
						else
							v1040 = tostring(v1029)
						end
						v1027.Text = v1028:format(v1040, v1014, v1026)
						return
					end
				end
				v_u_700.Text = "No measurement yet. Type the number."
				return
			else
				if #v_u_583 > 0 then
					v_u_901.Text = table.concat(v_u_583, "\n")
					v_u_901.Visible = true
				else
					v_u_901.Visible = false
				end
				if v_u_579 == nil then
					v1041 = false
				else
					v1041 = v_u_580 == v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
				end
				if #v_u_583 > 0 then
					v_u_900.Text = "Finish the form first."
					v_u_900.TextColor3 = v_u_566.muted
				elseif v_u_581 then
					v_u_900.Text = "Checking ..."
					v_u_900.TextColor3 = v_u_566.muted
				elseif v_u_579 == nil then
					v1018 = v_u_582 or "Fill in the form. The check runs by itself and writes nothing."
					v_u_900.Text = tostring(v1018)
					v_u_900.TextColor3 = v_u_566.muted
				elseif v1041 then
					v_u_900.Text = v_u_579.ok == true and "The plan is valid." or "The plan has errors."
					v1019 = v_u_900
					if v_u_579.ok == true then
						v1020 = v_u_566.success
					else
						v1020 = v_u_566.danger
					end
					v1019.TextColor3 = v1020
				else
					v_u_900.Text = "The form changed. Checking again in a moment."
					v_u_900.TextColor3 = v_u_566.muted
				end
				v1021 = {}
				v1022 = {}
				v1023 = v_u_4.rowMap(v_u_577)
				if v_u_579 then
					for _, v1056 in v_u_579.errors or {} do
						if type(v1056) ~= "table" or v1056.row ~= nil and v1023[v1056.row] ~= nil then
							continue
						end
						v1024 = v1056.text
						v1025 = tostring(v1024)
						table.insert(v1021, v1025)
					end
					for _, v1057 in v_u_579.warnings or {} do
						if type(v1057) ~= "table" or v1057.row ~= nil and v1023[v1057.row] ~= nil then
							continue
						end
						v1042 = v1057.text
						v1043 = tostring(v1042)
						table.insert(v1022, v1043)
					end
				end
				v_u_902.Text = table.concat(v1021, "\n")
				v_u_902.Visible = #v1021 > 0
				v_u_903.Text = table.concat(v1022, "\n")
				v_u_903.Visible = #v1022 > 0
				v1044 = {}
				if v_u_579 then
					for _, v1058 in v_u_4.neededWords(v_u_579.errors) do
						if v1058.row ~= nil and v1023[v1058.row] ~= nil then
							continue
						end
						v1044[v1058.word] = true
					end
				end
				for v1059, v1060 in v_u_904 do
					v1060.frame.Visible = v1044[v1059] == true and true or v_u_577.typed[v1059] == true
				end
				if v_u_579 then
					v1053 = 4
				else
					v1053 = 5
				end
			end
		end
	end
	function v_u_578.search(p1062, p1063) -- name: search
		-- upvalues: (ref) v_u_591, (ref) v_u_592, (ref) v_u_593, (ref) v_u_4, (copy) v_u_758, (ref) v_u_577, (copy) v_u_578, (copy) v_u_781, (copy) v_u_704
		v_u_591 = p1062
		local v1064, v1065 = v_u_4.searchItems(p1063, v_u_4.SUGGEST_MAX, nil, (v_u_758(p1062)))
		v_u_592 = v1064
		v_u_593 = v1065
		local v1066 = string.lower
		local v1067
		if type(p1063) == "string" then
			local v1068 = string.gsub(p1063, "^%s+", "")
			v1067 = string.gsub(v1068, "%s+$", "")
		else
			v1067 = ""
		end
		local v1069 = v1066(v1067)
		local v1070 = v_u_577.rows[p1062]
		if v1070 then
			local v1071 = v1070.u
			local v1072
			if type(v1071) == "string" then
				local v1073 = string.gsub(v1071, "^%s+", "")
				v1072 = string.gsub(v1073, "%s+$", "")
			else
				v1072 = ""
			end
			if v1072 == "" then
				local v1074 = v1070.s
				local v1075
				if type(v1074) == "string" then
					local v1076 = string.gsub(v1074, "^%s+", "")
					v1075 = string.gsub(v1076, "%s+$", "")
				else
					v1075 = ""
				end
				if v1075 == "" then
					for _, v1077 in v_u_592 do
						if v1077.id ~= v1069 then
							continue
						end
						v_u_578.pickItem(p1062, v1077.id)
						return
					end
				end
			end
		end
		v_u_781(p1062)
		for v1078 = 1, #v_u_704 do
			local v1079 = v1078 ~= p1062 and v_u_704[v1078]
			if v1079 then
				v1079.sugg.Visible = false
			end
			local v1080 = v_u_704[v1078]
			local v1081 = v_u_577.rows[v1078]
			if not (v1080 and v1081) then
				continue
			end
			if not v1080.filterRow then
				continue
			end
			local v1082
			if v_u_591 == v1078 then
				v1082 = true
			else
				local v1083 = v1081.id
				local v1084
				if type(v1083) == "string" then
					local v1085 = string.gsub(v1083, "^%s+", "")
					v1084 = string.gsub(v1085, "%s+$", "")
				else
					v1084 = ""
				end
				v1082 = v1084 == ""
			end
			v1080.filterRow.Visible = v1082
			v1080.counts.Visible = v1082
		end
	end
	function v_u_578.pickItem(p_u_1086, p_u_1087) -- name: pickItem
		-- upvalues: (ref) v_u_3, (ref) v_u_577, (ref) v_u_591, (ref) v_u_592, (ref) v_u_593, (copy) v_u_584, (ref) v_u_4, (copy) v_u_704, (ref) v_u_634, (copy) v_u_781, (ref) v_u_598, (copy) v_u_569, (copy) v_u_749
		local v_u_1088 = "Items"
		local function v1089()
			-- upvalues: (ref) v_u_3, (copy) v_u_1088
			return require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_1088, 5)))
		end
		local v1090, v1091 = pcall(v1089)
		if not v1090 then
			v1091 = nil
		end
		local v1092
		if v1091 then
			v1092 = v1091.get(p_u_1087)
		else
			v1092 = nil
		end
		local v1093 = v_u_577.rows[p_u_1086]
		if v1093 and v1092 then
			v_u_591 = nil
			v_u_592 = {}
			v_u_593 = nil
			local v1094 = v_u_584[p_u_1087]
			local v1095
			if type(v1094) == "table" then
				v1095 = v1094.ref
			else
				v1095 = nil
			end
			v_u_4.rowFromItem(v1092, v1095, v1093)
			v1093.typed = {}
			local v1096 = v_u_704[p_u_1086]
			if v1096 then
				for _, v1097 in v1096.words do
					local v1098 = v1097.box
					v_u_634 = true
					v1098.Text = ""
					v_u_634 = false
				end
				for _, v1099 in {
					"id",
					"u",
					"q1",
					"q2",
					"c"
				} do
					local v1100 = v1096.boxes[v1099]
					local v1101 = v1093[v1099]
					local v1102 = tostring(v1101)
					v_u_634 = true
					v1100.Text = v1102
					v_u_634 = false
				end
				v1096.windowApi.setText("per 1 H")
				v_u_781(p_u_1086)
				local v1103 = v_u_704[p_u_1086]
				local v1104 = v_u_577.rows[p_u_1086]
				if v1103 and (v1104 and v1103.filterRow) then
					local v1105
					if v_u_591 == p_u_1086 then
						v1105 = true
					else
						local v1106 = v1104.id
						local v1107
						if type(v1106) == "string" then
							local v1108 = string.gsub(v1106, "^%s+", "")
							v1107 = string.gsub(v1108, "%s+$", "")
						else
							v1107 = ""
						end
						v1105 = v1107 == ""
					end
					v1103.filterRow.Visible = v1105
					v1103.counts.Visible = v1105
				end
			end
			v_u_598()
			if not v1094 then
				v_u_569("check", {
					["ids"] = { p_u_1087 }
				}, function(p1109)
					-- upvalues: (copy) p_u_1087, (ref) v_u_584, (ref) v_u_577, (copy) p_u_1086, (ref) v_u_704, (ref) v_u_634, (ref) v_u_598, (ref) v_u_749
					if type(p1109) == "table" then
						local v1110 = p1109.data
						if type(v1110) == "table" then
							local v1111 = p1109.data.items
							if type(v1111) == "table" then
								local v1112 = p1109.data.items[p_u_1087]
								if type(v1112) == "table" then
									v_u_584[p_u_1087] = v1112
									local v1113 = v_u_577.rows[p_u_1086]
									if v1113 and v1113.id == p_u_1087 then
										local v1114 = v1112.ref
										local v1115
										if type(v1114) == "number" and (v1114 == v1114 and v1114 ~= (1 / 0)) then
											v1115 = v1114 ~= (-1 / 0)
										else
											v1115 = false
										end
										if v1115 and v1112.ref >= 1 then
											local v1116 = v1113.u
											local v1117
											if type(v1116) == "string" then
												local v1118 = string.gsub(v1116, "^%s+", "")
												v1117 = string.gsub(v1118, "%s+$", "")
											else
												v1117 = ""
											end
											if v1117 == "" or v1113.u == "0" then
												local v1119 = v1112.ref + 0.5
												local v1120 = math.floor(v1119)
												v1113.u = tostring(v1120)
												local v1121 = v_u_704[p_u_1086]
												if v1121 then
													local v1122 = v1121.boxes.u
													local v1123 = v1113.u
													v_u_634 = true
													v1122.Text = v1123
													v_u_634 = false
												end
												v_u_598()
											end
										end
									end
									v_u_749(p_u_1086)
								end
							end
						end
					end
				end, "light")
			end
		end
	end
	function v_u_578.addRow() -- name: addRow
		-- upvalues: (ref) v_u_577, (ref) v_u_4, (ref) v_u_896, (ref) v_u_598
		if #v_u_577.rows < v_u_4.MAX_ROWS then
			local v1124 = v_u_577.rows
			local v1125 = v_u_4.newRow
			table.insert(v1124, v1125())
			v_u_896()
			v_u_598()
		end
	end
	function v_u_578.removeRow(p1126) -- name: removeRow
		-- upvalues: (ref) v_u_577, (ref) v_u_4, (ref) v_u_591, (ref) v_u_592, (ref) v_u_593, (copy) v_u_594, (ref) v_u_896, (ref) v_u_598
		if #v_u_577.rows <= 1 then
			v_u_577.rows[1] = v_u_4.newRow()
		else
			table.remove(v_u_577.rows, p1126)
		end
		v_u_591 = nil
		v_u_592 = {}
		v_u_593 = nil
		table.clear(v_u_594)
		v_u_896()
		v_u_598()
	end
	local function v_u_1129() -- name: pushStateToBoxes
		-- upvalues: (ref) v_u_634, (copy) v_u_595, (ref) v_u_577, (copy) v_u_904, (ref) v_u_681, (copy) v_u_640, (ref) v_u_896
		v_u_634 = true
		v_u_595.name.Text = v_u_577.name
		v_u_595.start.Text = v_u_577.startText
		v_u_595.dur.Text = v_u_577.durText
		for _, v1127 in {
			"mr",
			"ma",
			"mc",
			"mx",
			"pe",
			"wd",
			"lk"
		} do
			v_u_595[v1127].Text = v_u_577[v1127]
		end
		for _, v1128 in { "LOAD", "LONG" } do
			v_u_904[v1128].box.Text = v_u_577.typed[v1128] ~= true and "" or v1128
		end
		v_u_634 = false
		v_u_681.setText(v_u_577.zone == "utc" and "UTC" or "BERLIN")
		v_u_640("dur", v_u_577.dur)
		v_u_640("al", v_u_577.al)
		v_u_640("rv", v_u_577.rv)
		v_u_896()
	end
	function v_u_578.setState(p1130) -- name: setState
		-- upvalues: (ref) v_u_577, (ref) v_u_579, (ref) v_u_580, (ref) v_u_582, (ref) v_u_586, (copy) v_u_1129, (ref) v_u_598
		v_u_577 = p1130
		v_u_579 = nil
		v_u_580 = ""
		v_u_582 = nil
		v_u_586 = nil
		v_u_1129()
		v_u_598(true)
	end
	function v_u_578.getState() -- name: getState
		-- upvalues: (ref) v_u_577
		return v_u_577
	end
	function v_u_578.draft() -- name: draft
		-- upvalues: (ref) v_u_4, (ref) v_u_577
		return v_u_4.buildDraft(v_u_577, nil)
	end
	function v_u_578.problems() -- name: problems
		-- upvalues: (ref) v_u_583
		return v_u_583
	end
	function v_u_578.preview() -- name: preview
		-- upvalues: (ref) v_u_589, (copy) v_u_961
		v_u_589 = nil
		v_u_961()
	end
	function v_u_578.edit(p1131) -- name: edit
		-- upvalues: (copy) v_u_578, (ref) v_u_4, (copy) v_u_645
		v_u_578.setState(v_u_4.stateFromPlan(p1131, v_u_645()))
	end
	function v_u_578.discardPress() -- name: discardPress
		-- upvalues: (ref) v_u_926, (ref) v_u_4, (copy) v_u_578, (copy) v_u_936
		local v1132 = os.clock()
		if v_u_926 == nil or (v1132 - v_u_926 >= v_u_4.CONFIRM_SECONDS or v1132 - v_u_926 <= v_u_4.CONFIRM_GUARD) then
			if v_u_926 == nil or v1132 - v_u_926 >= v_u_4.CONFIRM_SECONDS then
				v_u_926 = v1132
			end
			v_u_936()
		else
			v_u_926 = nil
			v_u_578.discard()
		end
	end
	function v_u_578.discard() -- name: discard
		-- upvalues: (ref) v_u_5, (ref) v_u_597, (copy) v_u_922, (copy) v_u_578, (ref) v_u_4
		if v_u_5 then
			v_u_5:SetAttribute("FilmRestockDraft", nil)
		end
		if v_u_597 then
			v_u_597.Text = ""
			v_u_597.Visible = false
		end
		if v_u_5 then
			v_u_5:SetAttribute("FilmRestockError", "")
		end
		v_u_922.Visible = false
		v_u_578.setState(v_u_4.newState())
	end
	local function v_u_1146(p1133) -- name: finishSave
		-- upvalues: (ref) v_u_585, (copy) p_u_562, (ref) v_u_588, (copy) v_u_922, (copy) v_u_566, (ref) v_u_597, (ref) v_u_5, (ref) v_u_577, (ref) v_u_4, (ref) v_u_579, (ref) v_u_580, (copy) v_u_1129, (ref) v_u_937
		v_u_585 = false
		p_u_562.setFast(false)
		local v1134
		if type(p1133) == "table" then
			local v1135 = p1133.jobs
			if type(v1135) == "table" then
				v1134 = p1133.jobs.lastSave
			else
				v1134 = nil
			end
		else
			v1134 = nil
		end
		if type(v1134) == "table" and v1134.ok == true then
			local v1136 = v1134.text or "Restock saved."
			v_u_588 = tostring(v1136)
			if p_u_562.handle then
				local v1137 = p_u_562.handle.status
				if type(v1137) == "function" then
					local v1138 = p_u_562.handle.status
					local v1139 = v_u_588
					pcall(v1138, v1139)
				end
			end
			v_u_922.Text = v_u_588
			v_u_922.TextColor3 = v_u_566.success
			v_u_922.Visible = true
			if v_u_597 then
				v_u_597.Text = ""
				v_u_597.Visible = false
			end
			if v_u_5 then
				v_u_5:SetAttribute("FilmRestockError", "")
			end
			if v_u_5 then
				v_u_5:SetAttribute("FilmRestockDraft", nil)
			end
			v_u_577 = v_u_4.newState()
			v_u_579 = nil
			v_u_580 = ""
			v_u_1129()
			if v_u_5 then
				v_u_5:SetAttribute("FilmRestockDraft", v_u_4.encodeState(v_u_577))
			end
			if p_u_562.onSaved then
				p_u_562.onSaved()
			end
		elseif type(v1134) == "table" then
			local v1140 = v1134.text or "The save failed. Nothing was announced."
			local v1141 = tostring(v1140) or ""
			if v_u_597 then
				v_u_597.Text = v1141
				v_u_597.Visible = v1141 ~= ""
			end
			if v_u_5 then
				v_u_5:SetAttribute("FilmRestockError", v1141)
			end
			if p_u_562.handle then
				local v1142 = p_u_562.handle.status
				if type(v1142) == "function" then
					local v1143 = p_u_562.handle.status
					local v1144 = v1134.text or "The save failed."
					local v1145 = tostring(v1144)
					pcall(v1143, v1145, "error")
				end
			end
			v_u_922.Visible = false
		end
		v_u_937()
	end
	function v_u_578.savePress() -- name: savePress
		-- upvalues: (ref) v_u_585, (ref) v_u_4, (ref) v_u_577, (ref) v_u_579, (ref) v_u_580, (ref) v_u_583, (ref) v_u_586, (ref) v_u_597, (ref) v_u_5, (copy) v_u_936, (copy) v_u_922, (ref) v_u_587, (ref) v_u_632, (copy) v_u_578, (copy) p_u_562, (copy) v_u_921, (copy) v_u_569, (ref) v_u_937, (copy) v_u_749
		local v1147 = os.clock()
		if v_u_585 then
			return
		else
			local v1148 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
			local v1149, v1150 = v_u_4.saveGate(v_u_579, v_u_580, v1148, v_u_583, v_u_585)
			local v1151
			if v_u_586 == nil then
				v1151 = false
			else
				v1151 = v1147 - v_u_586 < v_u_4.CONFIRM_SECONDS
			end
			if v1151 then
				if v1147 - v_u_587 < v_u_4.CONFIRM_GUARD then
					return
				elseif v1149 then
					v_u_586 = nil
					local v1152 = v_u_4.buildDraft(v_u_577, nil)
					if v1152 ~= nil then
						v_u_585 = true
						v_u_578.jobStarted = os.clock()
						local v1153
						if p_u_562.status then
							v1153 = p_u_562.status()
						else
							v1153 = nil
						end
						local v1154
						if type(v1153) == "table" then
							local v1155 = v1153.jobs
							if type(v1155) == "table" then
								v1154 = v1153.jobs.lastSave
							else
								v1154 = nil
							end
						else
							v1154 = nil
						end
						local v1156 = v_u_578
						local v1157
						if type(v1154) == "table" then
							v1157 = v1154.at
						else
							v1157 = nil
						end
						v1156.prevSaveAt = v1157
						if v_u_597 then
							v_u_597.Text = ""
							v_u_597.Visible = false
						end
						if v_u_5 then
							v_u_5:SetAttribute("FilmRestockError", "")
						end
						p_u_562.setFast(true)
						v_u_921.Text = v_u_4.etaText({
							["done"] = 0,
							["total"] = 0
						}, nil)
						v_u_936()
						v_u_569("save", {
							["draft"] = v1152,
							["replace"] = v_u_577.replace,
							["contRid"] = v_u_577.contRid
						}, function(p1158)
							-- upvalues: (ref) v_u_585, (ref) p_u_562, (ref) v_u_597, (ref) v_u_5, (ref) v_u_579, (ref) v_u_580, (ref) v_u_4, (ref) v_u_577, (ref) v_u_937, (ref) v_u_749
							if type(p1158) == "table" and p1158.ok == true then
								v_u_937()
							else
								v_u_585 = false
								p_u_562.setFast(false)
								local v1159 = p1158 and (p1158.msg or "The server did not answer.") or "The server did not answer."
								local v1160 = tostring(v1159) or ""
								if v_u_597 then
									v_u_597.Text = v1160
									v_u_597.Visible = v1160 ~= ""
								end
								if v_u_5 then
									v_u_5:SetAttribute("FilmRestockError", v1160)
								end
								if type(p1158) == "table" then
									local v1161 = p1158.data
									if type(v1161) == "table" then
										local v1162 = p1158.data.errors
										if type(v1162) == "table" then
											v_u_579 = {
												["ok"] = false,
												["errors"] = nil,
												["warnings"] = nil,
												["refs"] = nil,
												["errors"] = p1158.data.errors,
												["warnings"] = p1158.data.warnings or {},
												["refs"] = v_u_579 and v_u_579.refs or nil
											}
											v_u_580 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
										end
									end
								end
								v_u_937()
								for v1163 = 1, #v_u_577.rows do
									v_u_749(v1163)
								end
							end
						end, "write")
					end
				else
					v_u_586 = nil
					local v1164 = tostring(v1150 or "Not ready.") or ""
					if v_u_597 then
						v_u_597.Text = v1164
						v_u_597.Visible = v1164 ~= ""
					end
					if v_u_5 then
						v_u_5:SetAttribute("FilmRestockError", v1164)
					end
					v_u_936()
					return
				end
			elseif v1149 then
				if v_u_597 then
					v_u_597.Text = ""
					v_u_597.Visible = false
				end
				if v_u_5 then
					v_u_5:SetAttribute("FilmRestockError", "")
				end
				v_u_922.Visible = false
				v_u_586 = v1147
				v_u_587 = v1147
				v_u_936()
				task.delay(v_u_4.CONFIRM_SECONDS + 0.2, function()
					-- upvalues: (ref) v_u_632, (ref) v_u_936
					if v_u_632 then
						v_u_936()
					end
				end)
			else
				local v1165 = tostring(v1150 or "Not ready.") or ""
				if v_u_597 then
					v_u_597.Text = v1165
					v_u_597.Visible = v1165 ~= ""
				end
				if v_u_5 then
					v_u_5:SetAttribute("FilmRestockError", v1165)
				end
				v_u_936()
			end
		end
	end
	function v_u_578.onStatus(p1166) -- name: onStatus
		-- upvalues: (ref) v_u_585, (copy) v_u_921, (ref) v_u_4, (copy) v_u_566, (copy) v_u_578, (copy) v_u_1146, (copy) p_u_562, (ref) v_u_597, (ref) v_u_5, (ref) v_u_937, (ref) v_u_1061
		if type(p1166) == "table" then
			local v1167 = p1166.jobs
			local v1168
			if type(v1167) == "table" then
				v1168 = p1166.jobs.save
			else
				v1168 = nil
			end
			if v_u_585 then
				if type(v1168) == "table" then
					v_u_921.Text = v_u_4.etaText(v1168, p1166.now)
					v_u_921.TextColor3 = v_u_566.accent
				elseif os.clock() - (v_u_578.jobStarted or 0) > 1.5 then
					local v1169 = p1166.jobs
					local v1170
					if type(v1169) == "table" then
						v1170 = p1166.jobs.lastSave
					else
						v1170 = nil
					end
					if type(v1170) == "table" and v1170.at ~= v_u_578.prevSaveAt then
						v_u_1146(p1166)
					elseif os.clock() - (v_u_578.jobStarted or 0) > 30 then
						v_u_585 = false
						p_u_562.setFast(false)
						if v_u_597 then
							v_u_597.Text = "The server gave no result for the save. Check the status line, nothing was announced unless it shows a restock."
							v_u_597.Visible = true
						end
						if v_u_5 then
							v_u_5:SetAttribute("FilmRestockError", "The server gave no result for the save. Check the status line, nothing was announced unless it shows a restock.")
						end
						v_u_937()
					end
				end
			elseif type(v1168) == "table" and not v_u_585 then
				local v1171 = p1166.jobs
				if type(v1171) == "table" then
					v_u_921.Text = v_u_4.etaText(v1168, p1166.now)
					v_u_921.TextColor3 = v_u_566.accent
				end
			end
			v_u_1061()
		end
	end
	function v_u_578.formState() -- name: formState
		-- upvalues: (ref) v_u_4, (ref) v_u_577, (ref) v_u_579, (ref) v_u_580, (ref) v_u_583, (ref) v_u_585, (ref) v_u_586, (ref) v_u_597, (copy) v_u_922, (ref) v_u_924
		local v1172 = v_u_4.signature(v_u_577, v_u_577.replace, v_u_577.contRid)
		local v1173, v1174 = v_u_4.saveGate(v_u_579, v_u_580, v1172, v_u_583, v_u_585)
		local v1175 = {
			["ready"] = v1173,
			["why"] = v1174,
			["saving"] = v_u_585,
			["confirm"] = v_u_586 ~= nil,
			["problems"] = #v_u_583
		}
		local v1176
		if v_u_579 then
			local v1177 = v_u_579.errors
			v1176 = type(v1177) == "table" and #v_u_579.errors or 0
		else
			v1176 = 0
		end
		v1175.errors = v1176
		local v1178
		if v_u_579 then
			local v1179 = v_u_579.warnings
			v1178 = type(v1179) == "table" and #v_u_579.warnings or 0
		else
			v1178 = 0
		end
		v1175.warnings = v1178
		v1175.preview = v_u_579 ~= nil
		v1175.rows = #v_u_577.rows
		v1175.error = not v_u_597 and "" or v_u_597.Text
		v1175.result = v_u_922.Text
		v1175.saveText = v_u_924 and (v_u_924.label and v_u_924.label.Text or "") or ""
		return v1175
	end
	function v_u_578.pv() -- name: pv
		-- upvalues: (ref) v_u_579
		return v_u_579
	end
	function v_u_578.suggestions() -- name: suggestions
		-- upvalues: (ref) v_u_592
		return v_u_592
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_632, (ref) v_u_589, (ref) v_u_4, (ref) v_u_942, (ref) v_u_581, (ref) v_u_585, (copy) v_u_961, (ref) v_u_586, (ref) v_u_926, (copy) v_u_936
		while v_u_632 do
			if v_u_589 ~= nil and (os.clock() - v_u_589 >= v_u_4.PREVIEW_QUIET and (os.clock() - v_u_942 >= v_u_4.LIGHT_GAP and not (v_u_581 or v_u_585))) then
				v_u_589 = nil
				v_u_942 = os.clock()
				v_u_961()
			end
			if v_u_586 ~= nil or v_u_926 ~= nil then
				v_u_936()
			end
			task.wait(0.25)
		end
	end)
	v_u_1129()
	if v_u_5 and v_u_4.decodeState(v_u_5:GetAttribute("FilmRestockDraft")) ~= nil then
		local _ = os.clock()
	end
	v_u_937()
	return v_u_578
end
return v_u_4