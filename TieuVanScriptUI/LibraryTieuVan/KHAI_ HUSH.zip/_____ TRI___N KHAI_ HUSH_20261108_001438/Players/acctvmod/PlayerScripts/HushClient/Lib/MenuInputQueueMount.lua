-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuInputQueueMount

local v_u_31 = {
	["SEP"] = "  \194\183  ",
	["SIZE"] = 13,
	["hintTexts"] = function(p1, p2) -- name: hintTexts
		if type(p1) == "table" then
			local v3 = p1.squadLine
			if type(v3) == "function" then
				local v4 = p1.squadLine(p2, false)
				if type(v4) ~= "string" or v4 == "" then
					return nil
				end
				local v5 = p1.squadLine(p2, true)
				return type(v5) == "string" and (v5 ~= "" and v5 ~= v4) and { v4, v5 } or { v4 }
			end
		end
		return nil
	end,
	["tag"] = function(p6, p7, p8) -- name: tag
		if type(p6) == "table" then
			local v9 = p6.chipText
			if type(v9) == "function" then
				local v10 = p6.chipText("x", p7, p8)
				if type(v10) == "string" then
					return string.match(v10, "^x %((.+)%)$")
				else
					return nil
				end
			end
		end
		return nil
	end,
	["titleWith"] = function(p11, p12, p13, p14, p15) -- name: titleWith
		-- upvalues: (copy) v_u_31
		if type(p12) == "string" and type(p11) == "table" then
			local v16 = p11.textW
			if type(v16) == "function" and type(p14) == "number" then
				local v17 = p15 or v_u_31.SIZE
				for _, v18 in { false, true } do
					local v19 = v_u_31.tag(p11, p13, v18)
					if v19 == nil then
						continue
					end
					local v20 = p12 .. v_u_31.SEP .. v19
					if p11.textW(v20, v17, true) > p14 then
						continue
					end
					return v20
				end
				return p12
			end
		end
		return p12
	end,
	["title"] = function(p_u_21, p22, p23) -- name: title
		-- upvalues: (copy) v_u_31
		local v24
		if type(p_u_21) == "table" then
			local v25 = p_u_21.myParty
			if type(v25) == "function" then
				v24 = p_u_21.myParty()
			else
				v24 = nil
			end
		else
			v24 = nil
		end
		local v26
		if type(v24) == "table" then
			v26 = v24.input
		else
			v26 = nil
		end
		if type(v26) ~= "table" then
			return p22
		end
		local v27 = p_u_21.cctx.lib.MenuInputQueue
		local v28 = 1
		local v29, v30 = pcall(function()
			-- upvalues: (copy) p_u_21
			return p_u_21.theme.uiScale()
		end)
		if v29 and type(v30) == "number" then
			if v30 <= 0.01 then
				v30 = v28
			end
		else
			v30 = v28
		end
		return v_u_31.titleWith(v27, p22, v26, (tonumber(p23) or 0) / v30, v_u_31.SIZE)
	end
}
return v_u_31