-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewFollowBar

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = false
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = ""
local v_u_10 = 0
local v_u_11 = ""
local function v_u_17() -- name: fireStop
	-- upvalues: (ref) v_u_5, (copy) v_u_2
	local v12 = v_u_5
	local v13 = {
		["op"] = "reviewStopFollow"
	}
	if v12 and v12.net then
		local v14 = v12.net.fire
		if type(v14) == "function" then
			local v15 = v12.net.fire
			pcall(v15, "menu.op", v13)
			return
		end
	end
	local v16 = v_u_2:FindFirstChild("HushNet")
	if v16 then
		v16 = v16:FindFirstChild("menu.op")
	end
	if v16 and v16:IsA("RemoteEvent") then
		v16:FireServer(v13)
	end
end
local function v_u_61() -- name: render
	-- upvalues: (copy) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_5, (copy) v_u_17, (copy) v_u_61
	local v18 = v_u_4:GetAttribute("OverwatchFollowText")
	local v_u_19
	if type(v18) == "string" then
		v_u_19 = v18 ~= ""
	else
		v_u_19 = false
	end
	local v20
	if v_u_9 == "" then
		v20 = false
	else
		v20 = os.clock() < v_u_10
	end
	if v_u_19 or v20 then
		if not v_u_19 then
			v18 = v_u_9
		end
		local function v21()
			-- upvalues: (ref) v_u_5
			return {
				["HushUI"] = v_u_5.lib.HushUI,
				["Layout"] = v_u_5.lib.ReviewFollowLayout
			}
		end
		local v22, v23 = pcall(v21)
		if not v22 then
			v23 = nil
		end
		if v23 == nil then
			return
		else
			local v24 = v23.HushUI
			local v25 = v24.Theme
			if v_u_7 == nil then
				local v26, v27 = v24.screen("ReviewFollowBar", 46)
				v_u_7 = v26
				v_u_8 = v27
			end
			local v28 = v25.uiScale()
			local v29 = math.max(v28, 0.1)
			local v30 = v_u_8.AbsoluteSize.X / v29
			local v31 = math.floor(v30)
			local v32 = v_u_8.AbsoluteSize.Y / v29
			local v33 = math.floor(v32)
			local v34 = v24.safeInsets()
			local v35 = v34.l / v29
			local v36 = math.floor(v35)
			local v37 = v34.t / v29
			local v38 = math.floor(v37)
			local v39 = v34.r / v29
			local v40 = math.floor(v39)
			local v41 = v23.Layout.opts(v29, v25.isTouch(), v25.isPhone())
			local v42 = v23.Layout.bar
			local v43 = v31 - v36 - v40
			local v44 = v42(math.max(v43, 200), math.max(v33, 160), v41, {
				["text"] = v18,
				["button"] = v_u_19 and "STOP FOLLOWING" or "OK"
			})
			local v45 = v18 .. "|" .. v31 .. "x" .. v33 .. "|" .. tostring(v_u_19)
			if v45 ~= v_u_11 then
				v_u_11 = v45
				v_u_8:ClearAllChildren()
				local v46 = v25.color
				local v47 = v24.new
				local v48 = {
					["Name"] = "Holder",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(v36, v38)
				}
				local v49 = UDim2.fromOffset
				local v50 = v31 - v36 - v40
				local v51 = math.max(v50, 200)
				local v52 = v33 - v38
				v48.Size = v49(v51, (math.max(v52, 160)))
				local v53 = v47("Frame", v48, v_u_8)
				local v54 = v44.panel
				local v55 = v24.new("Frame", {
					["Name"] = "Panel",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.15,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["BackgroundColor3"] = v46.bg,
					["Position"] = UDim2.fromOffset(v54.x, v54.y),
					["Size"] = UDim2.fromOffset(v54.w, v54.h)
				}, v53)
				v24.stroke(v55, v46.accent, 1, 0)
				local v56 = v44.text.rect
				v24.new("TextLabel", {
					["Name"] = "Text",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["Text"] = nil,
					["TextTruncate"] = nil,
					["TextXAlignment"] = nil,
					["TextYAlignment"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ClipsDescendants"] = true,
					["ZIndex"] = 3,
					["FontFace"] = v25.font.headingBold,
					["TextSize"] = v44.text.size,
					["TextColor3"] = v46.accent,
					["Text"] = v44.text.str,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["TextXAlignment"] = Enum.TextXAlignment.Center,
					["TextYAlignment"] = Enum.TextYAlignment.Center,
					["Position"] = UDim2.fromOffset(v56.x, v56.y),
					["Size"] = UDim2.fromOffset(v56.w, v56.h)
				}, v53)
				local v57 = v44.button.rect
				local v58 = v24.new("TextButton", {
					["Name"] = "Stop",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Text"] = "",
					["Position"] = nil,
					["Size"] = nil,
					["Selectable"] = true,
					["ZIndex"] = 3,
					["BackgroundColor3"] = v46.raised,
					["Position"] = UDim2.fromOffset(v57.x, v57.y),
					["Size"] = UDim2.fromOffset(v57.w, v57.h)
				}, v53)
				v24.stroke(v58, v46.line, 1, 0)
				v24.new("TextLabel", {
					["Name"] = "Text",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["Text"] = nil,
					["TextXAlignment"] = nil,
					["TextYAlignment"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["FontFace"] = v25.font.heading,
					["TextSize"] = v44.button.size,
					["TextColor3"] = v46.text,
					["Text"] = v44.button.label,
					["TextXAlignment"] = Enum.TextXAlignment.Center,
					["TextYAlignment"] = Enum.TextYAlignment.Center,
					["Size"] = UDim2.fromScale(1, 1)
				}, v58)
				v58.Activated:Connect(function()
					-- upvalues: (copy) v_u_19, (ref) v_u_17, (ref) v_u_9, (ref) v_u_61
					if v_u_19 then
						v_u_17()
					else
						v_u_9 = ""
						v_u_61()
					end
				end)
				local function v59()
					-- upvalues: (ref) v_u_4
					v_u_4:SetAttribute("ReviewFollowBar", "shown=1")
				end
				pcall(v59)
			end
		end
	else
		if v_u_7 then
			v_u_7:Destroy()
		end
		v_u_7 = nil
		v_u_8 = nil
		v_u_11 = ""
		local function v60()
			-- upvalues: (ref) v_u_4
			v_u_4:SetAttribute("ReviewFollowBar", "shown=0")
		end
		pcall(v60)
		return
	end
end
function v3.init(p62) -- name: init
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (ref) v_u_5, (copy) v_u_61, (ref) v_u_9, (ref) v_u_10
	if not v_u_6 and v_u_4 ~= nil then
		v_u_6 = true
		v_u_5 = p62
		v_u_4:GetAttributeChangedSignal("OverwatchFollowText"):Connect(function()
			-- upvalues: (ref) v_u_61
			v_u_61()
		end)
		if p62 and p62.net then
			local v63 = p62.net.listen
			if type(v63) == "function" then
				local v64 = p62.net.listen
				local function v68(p65)
					-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_61
					if type(p65) == "table" and (p65.op == "reviewFollow" or p65.op == "reviewStopFollow") then
						local v66 = p65.msg
						if type(v66) == "string" and p65.msg ~= "" then
							local v67 = p65.msg
							v_u_9 = string.sub(v67, 1, 80)
							v_u_10 = os.clock() + 6
							v_u_61()
							task.delay(6.2, v_u_61)
						end
					end
				end
				pcall(v64, "menu.result", v68)
			end
		end
		task.defer(v_u_61)
	end
end
return v3