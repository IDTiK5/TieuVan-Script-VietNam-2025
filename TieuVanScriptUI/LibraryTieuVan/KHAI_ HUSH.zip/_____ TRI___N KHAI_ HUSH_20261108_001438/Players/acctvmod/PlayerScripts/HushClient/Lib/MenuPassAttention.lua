-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassAttention

local v_u_1 = game:GetService("TweenService")
local v_u_22 = {
	["TUNE"] = {
		["thickness"] = 2,
		["low"] = 0.15,
		["high"] = 0.8,
		["still"] = 0.35,
		["period"] = 0.9
	},
	["attach"] = function(p2, p3, p4) -- name: attach
		-- upvalues: (copy) v_u_22, (copy) v_u_1
		local v_u_5 = v_u_22.TUNE
		local v6
		if type(p4) == "table" then
			local v7 = p4.thickness
			if type(v7) == "number" then
				v6 = p4.thickness
			else
				v6 = v_u_5.thickness
			end
		else
			v6 = v_u_5.thickness
		end
		local v8 = {}
		local v_u_9 = Instance.new("UIStroke")
		v_u_9.Name = "AttnPulse"
		v_u_9.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v_u_9.Color = p3
		v_u_9.Thickness = v6
		v_u_9.Transparency = 1
		v_u_9.Enabled = false
		v_u_9.Parent = p2
		local v_u_10 = nil
		local v_u_11 = false
		local v_u_12 = false
		function v8.set(p13, p14) -- name: set
			-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_10, (copy) v_u_9, (copy) v_u_5, (ref) v_u_1
			local v15 = p14 == true
			if p13 == v_u_11 and v15 == v_u_12 then
				return
			else
				v_u_11 = p13
				v_u_12 = v15
				if v_u_10 ~= nil then
					local function v16()
						-- upvalues: (ref) v_u_10
						v_u_10:Cancel()
					end
					pcall(v16)
					v_u_10 = nil
				end
				if p13 then
					v_u_9.Enabled = true
					if v15 then
						v_u_9.Transparency = v_u_5.still
					else
						v_u_9.Transparency = v_u_5.high
						local function v17()
							-- upvalues: (ref) v_u_1, (ref) v_u_9, (ref) v_u_5
							return v_u_1:Create(v_u_9, TweenInfo.new(v_u_5.period, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
								["Transparency"] = v_u_5.low
							})
						end
						local v18, v19 = pcall(v17)
						if v18 and v19 ~= nil then
							v_u_10 = v19
							v19:Play()
						end
					end
				else
					v_u_9.Enabled = false
					v_u_9.Transparency = 1
					return
				end
			end
		end
		function v8.isOn() -- name: isOn
			-- upvalues: (ref) v_u_11
			return v_u_11
		end
		function v8.destroy() -- name: destroy
			-- upvalues: (ref) v_u_10, (ref) v_u_11, (copy) v_u_9
			if v_u_10 ~= nil then
				local function v20()
					-- upvalues: (ref) v_u_10
					v_u_10:Cancel()
				end
				pcall(v20)
				v_u_10 = nil
			end
			v_u_11 = false
			local function v21()
				-- upvalues: (ref) v_u_9
				v_u_9:Destroy()
			end
			pcall(v21)
		end
		v8.stroke = v_u_9
		return v8
	end
}
return v_u_22