-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRotationLayout

local v_u_1 = {
	["SLOT_SEC"] = 2700,
	["SKEW_SEC"] = 120,
	["GAP"] = 8,
	["BADGE_W"] = 120,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["TEXT"] = {
		["now"] = "NOW",
		["byHand"] = "SET BY HAND",
		["waiting"] = "Waiting for the map",
		["moment"] = "in a moment",
		["tipTitle"] = "MAP ROTATION",
		["f8Reading"] = "Reading the map rotation ...",
		["f8Rotate"] = "Rotate again"
	}
}
local function v_u_6(p2) -- name: clean
	if type(p2) == "string" then
		local v3 = string.gsub(p2, "%c", "")
		local v4 = string.gsub(v3, "^%s+", "")
		local v5 = string.gsub(v4, "%s+$", "")
		if v5 == "" then
			return nil
		else
			return v5
		end
	else
		return nil
	end
end
local v_u_7 = nil
local function v_u_12(p8) -- name: liveRule
	-- upvalues: (ref) v_u_7
	if v_u_7 == nil then
		local v10, v11 = pcall(function()
			local v9 = game:GetService("ReplicatedStorage")
			return require((v9:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
		end)
		if not v10 or type(v11) ~= "table" then
			v11 = false
		end
		v_u_7 = v11
	end
	if v_u_7 then
		return v_u_7.rule(p8)
	else
		return nil
	end
end
function v_u_1.enabled(p13) -- name: enabled
	-- upvalues: (copy) v_u_12
	local v14 = p13 or v_u_12
	local v15, v16 = pcall(v14, "mapRotation")
	if v15 and type(v16) == "boolean" then
		return v16
	end
	local v17, v18 = pcall(v14, "pvp")
	if v17 then
		v17 = v18 == true
	end
	return v17
end
function v_u_1.view(p19) -- name: view
	-- upvalues: (copy) v_u_6
	if type(p19) ~= "table" then
		return nil
	end
	local v20 = v_u_6(p19.map)
	if v20 == nil then
		return nil
	end
	local v21 = v_u_6(p19.nextMap)
	local v22 = {
		["map"] = v20,
		["mapName"] = v_u_6(p19.mapName) or v20,
		["nextMap"] = v21,
		["nextName"] = v_u_6(p19.nextName) or (v21 or "")
	}
	local v23 = p19.endsAt
	if type(v23) ~= "number" or (v23 ~= v23 or (v23 == (1 / 0) or v23 == (-1 / 0))) then
		v23 = nil
	end
	v22.endsAt = v23
	local v24 = p19.secondsLeft
	if type(v24) ~= "number" or (v24 ~= v24 or (v24 == (1 / 0) or v24 == (-1 / 0))) then
		v24 = nil
	end
	v22.secondsLeft = v24
	v22.forced = p19.forced == true
	return v22
end
function v_u_1.localize(p25, p26) -- name: localize
	if type(p25) ~= "table" or type(p26) ~= "function" then
		return p25
	end
	local v27 = table.clone(p25)
	local v28 = p25.map
	local v29 = p25.mapName
	local v30, v31 = pcall(p26, v28, v29)
	if v30 and (type(v31) == "string" and v31 ~= "") then
		v27.mapName = v31
	end
	local v32 = p25.nextMap
	if type(v32) == "string" then
		local v33 = p25.nextMap
		local v34 = p25.nextName
		local v35, v36 = pcall(p26, v33, v34)
		if v35 and (type(v36) == "string" and v36 ~= "") then
			v27.nextName = v36
		end
	end
	return v27
end
function v_u_1.sig(p37) -- name: sig
	if type(p37) ~= "table" then
		return "none"
	end
	local v38 = table.concat
	local v39 = {}
	local v40 = p37.map
	local v41 = tostring(v40)
	local v42 = p37.nextMap
	local v43 = tostring(v42)
	local v44 = p37.forced
	local v45 = tostring(v44)
	local v46 = p37.endsAt
	local v47 = tostring(v46)
	local v48 = p37.secondsLeft
	local v49 = tostring(v48)
	local v50 = p37.mapName
	local v51 = tostring(v50)
	local v52 = p37.nextName
	__set_list(v39, 1, {v41, v43, v45, v47, v49, v51, (tostring(v52))})
	return v38(v39, "|")
end
function v_u_1.remaining(p53, p54, p55) -- name: remaining
	-- upvalues: (copy) v_u_1
	if type(p53) == "table" then
		if type(p54) ~= "number" or (p54 ~= p54 or (p54 == (1 / 0) or p54 == (-1 / 0))) then
			p54 = nil
		end
		local v56 = nil
		if p54 ~= nil then
			local v57 = p53.endsAt
			if type(v57) ~= "number" or (v57 ~= v57 or (v57 == (1 / 0) or v57 == (-1 / 0))) then
				v57 = nil
			end
			if v57 ~= nil then
				v56 = p53.endsAt - p54
			end
		end
		local v58 = nil
		if type(p55) ~= "number" or (p55 ~= p55 or (p55 == (1 / 0) or p55 == (-1 / 0))) then
			p55 = nil
		end
		if p54 ~= nil and p55 ~= nil then
			local v59 = p53.secondsLeft
			if type(v59) ~= "number" or (v59 ~= v59 or (v59 == (1 / 0) or v59 == (-1 / 0))) then
				v59 = nil
			end
			if v59 ~= nil then
				v58 = p53.secondsLeft - (p54 - p55)
			end
		end
		if v56 ~= nil then
			if v58 == nil then
				v58 = v56
			else
				local v60 = v56 - v58
				if math.abs(v60) <= v_u_1.SKEW_SEC then
					v58 = v56
				end
			end
		end
		if v58 == nil then
			v58 = p53.secondsLeft
			if type(v58) ~= "number" or (v58 ~= v58 or (v58 == (1 / 0) or v58 == (-1 / 0))) then
				v58 = nil
			end
		end
		if v58 == nil then
			return nil
		else
			return math.max(0, v58)
		end
	else
		return nil
	end
end
function v_u_1.countdownText(p61) -- name: countdownText
	-- upvalues: (copy) v_u_1
	if type(p61) ~= "number" or (p61 ~= p61 or (p61 == (1 / 0) or p61 == (-1 / 0))) then
		p61 = nil
	end
	if p61 == nil or p61 <= 0 then
		return v_u_1.TEXT.moment
	else
		local v62 = math.ceil(p61)
		if v62 < 60 then
			return ("in %d s"):format(v62)
		else
			local v63 = v62 / 60
			local v64 = math.ceil(v63)
			if v64 < 60 then
				return ("in %d min"):format(v64)
			else
				local v65 = v64 / 60
				local v66 = math.floor(v65)
				local v67 = v64 - v66 * 60
				if v67 == 0 then
					return ("in %d h"):format(v66)
				else
					return ("in %d h %02d min"):format(v66, v67)
				end
			end
		end
	end
end
function v_u_1.nextLine(p68, p69) -- name: nextLine
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	if type(p68) == "table" and p68.forced ~= true then
		if p69 == nil then
			p69 = p68.secondsLeft
		end
		local v70 = v_u_6(p68.nextName)
		if v70 == nil then
			return "NEXT MAP " .. v_u_1.countdownText(p69)
		else
			return ("NEXT: %s %s"):format(string.upper(v70), v_u_1.countdownText(p69))
		end
	else
		return ""
	end
end
function v_u_1.badgeText(p71) -- name: badgeText
	-- upvalues: (copy) v_u_1
	return (type(p71) ~= "table" or p71.forced ~= true) and "" or v_u_1.TEXT.byHand
end
function v_u_1.fill(p72, p73) -- name: fill
	-- upvalues: (copy) v_u_1
	if type(p72) ~= "table" or p72.forced == true then
		return 0
	end
	if type(p73) ~= "number" or (p73 ~= p73 or (p73 == (1 / 0) or p73 == (-1 / 0))) then
		p73 = nil
	end
	if p73 == nil then
		p73 = p72.secondsLeft
		if type(p73) ~= "number" or (p73 ~= p73 or (p73 == (1 / 0) or p73 == (-1 / 0))) then
			p73 = nil
		end
	end
	if p73 == nil then
		return 0
	end
	local v74 = 1 - p73 / v_u_1.SLOT_SEC
	return math.clamp(v74, 0, 1)
end
function v_u_1.rotatesLine() -- name: rotatesLine
	-- upvalues: (copy) v_u_1
	local v75 = v_u_1.SLOT_SEC / 60
	return ("Rotates every %d min"):format((math.floor(v75)))
end
function v_u_1.tooltip(p76) -- name: tooltip
	-- upvalues: (copy) v_u_1
	if type(p76) == "table" and p76.forced == true then
		return {
			["title"] = nil,
			["body"] = "The map was set by hand and stays until the normal rotation starts again.",
			["title"] = v_u_1.TEXT.tipTitle
		}
	end
	local v77 = {
		["title"] = v_u_1.TEXT.tipTitle
	}
	local v78 = v_u_1.SLOT_SEC / 60
	v77.body = ("Everyone in PVP deploys to the same map. It changes every %d minutes, always in the same order."):format((math.floor(v78)))
	return v77
end
function v_u_1.titleCase(p79) -- name: titleCase
	if string.find(p79, "%l") ~= nil then
		return p79
	end
	local v80 = string.lower(p79)
	return string.gsub(v80, "(%a)(%a*)", function(p81, p82)
		return string.upper(p81) .. p82
	end)
end
function v_u_1.squadMapText(p83, p84) -- name: squadMapText
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	if type(p84) == "table" then
		local v85 = v_u_6(p84.mapName)
		if v85 ~= nil then
			return v_u_1.titleCase(v85)
		end
	end
	return tostring(p83 or "Stillwater")
end
function v_u_1.rotationOf(p86) -- name: rotationOf
	-- upvalues: (copy) v_u_1
	if type(p86) ~= "table" then
		return nil
	end
	local v87 = nil
	local v88 = p86.myParty
	if type(v88) == "function" then
		local v89 = p86.myParty
		local v90, v91 = pcall(v89)
		if v90 and type(v91) == "table" then
			v87 = v91.rotation
		end
	end
	if v87 == nil then
		local v92 = p86.party
		if type(v92) == "table" then
			v87 = p86.party.rotation
		end
	end
	return v_u_1.view(v87)
end
local v_u_93 = {
	["full"] = {
		["h"] = 62,
		["pad"] = 14,
		["nowY"] = 10,
		["nowW"] = 40,
		["nameX"] = 60,
		["nameY"] = 4,
		["nameH"] = 28,
		["nameMax"] = 26,
		["nameMin"] = 16,
		["nextY"] = 35,
		["nextH"] = 18,
		["nextSize"] = 14,
		["barY"] = 56
	},
	["compact"] = {
		["h"] = 58,
		["pad"] = 12,
		["nowY"] = 8,
		["nowW"] = 38,
		["nameX"] = 56,
		["nameY"] = 3,
		["nameH"] = 26,
		["nameMax"] = 24,
		["nameMin"] = 15,
		["nextY"] = 32,
		["nextH"] = 17,
		["nextSize"] = 14,
		["barY"] = 52
	},
	["slim"] = {
		["h"] = 52,
		["pad"] = 10,
		["nowY"] = 7,
		["nowW"] = 36,
		["nameX"] = 50,
		["nameY"] = 3,
		["nameH"] = 24,
		["nameMax"] = 20,
		["nameMin"] = 14,
		["nextY"] = 28,
		["nextH"] = 18,
		["nextSize"] = 14,
		["barY"] = 47
	}
}
v_u_1.NOW_SIZE = 13
v_u_1.BADGE_SIZE = 12
v_u_1.BAR_H = 3
v_u_1.EDGE_W = 3
function v_u_1.density(p94) -- name: density
	local v95 = p94 or {}
	return v95.phone == true and "slim" or (v95.compact == true and "compact" or "full")
end
function v_u_1.height(p96) -- name: height
	-- upvalues: (copy) v_u_93, (copy) v_u_1
	return v_u_93[v_u_1.density(p96)].h
end
function v_u_1.band(p97) -- name: band
	-- upvalues: (copy) v_u_1
	return v_u_1.height(p97) + v_u_1.GAP
end
function v_u_1.textW(p98, p99, p100) -- name: textW
	-- upvalues: (copy) v_u_1
	local v101 = (utf8.len(p98) or #p98) * p99
	local v102
	if p100 == true then
		v102 = v_u_1.CHAR_CAPS
	else
		v102 = v_u_1.CHAR
	end
	local v103 = v101 * v102 + 2
	return math.ceil(v103)
end
function v_u_1.nameFit(p104, p105, p106, p107) -- name: nameFit
	-- upvalues: (copy) v_u_1
	local v108 = math.max(p106, p107)
	local v109 = math.floor(v108)
	local v110 = math.min(p106, p107)
	local v111 = math.floor(v110)
	while v111 <= v109 do
		if v_u_1.textW(p104, v109, true) <= p105 then
			return v109, true
		end
		v109 = v109 - 1
	end
	return v111, false
end
function v_u_1.layout(p112, p113) -- name: layout
	-- upvalues: (copy) v_u_1, (copy) v_u_93
	local v114 = v_u_1.density(p113)
	local v115 = v_u_93[v114]
	local v116 = 280
	if type(p112) ~= "number" or (p112 ~= p112 or (p112 == (1 / 0) or p112 == (-1 / 0))) then
		p112 = nil
	end
	local v117 = math.floor(p112 or 0)
	local v118 = math.max(v116, v117)
	local v119 = v118 - 2 * v115.pad
	return {
		["density"] = v114,
		["w"] = v118,
		["h"] = v115.h,
		["pad"] = v115.pad,
		["edge"] = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v_u_1.EDGE_W,
			["h"] = v115.h
		},
		["now"] = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 16,
			["x"] = v115.pad,
			["y"] = v115.nowY,
			["w"] = v115.nowW
		},
		["name"] = {
			["x"] = v115.nameX,
			["y"] = v115.nameY,
			["w"] = v118 - v115.nameX - v115.pad,
			["h"] = v115.nameH
		},
		["next"] = {
			["x"] = v115.pad,
			["y"] = v115.nextY,
			["w"] = v119,
			["h"] = v115.nextH
		},
		["badge"] = {
			["x"] = v115.pad,
			["y"] = v115.nextY,
			["w"] = v_u_1.BADGE_W,
			["h"] = v115.nextH
		},
		["bar"] = {
			["x"] = v115.pad,
			["y"] = v115.barY,
			["w"] = v119,
			["h"] = v_u_1.BAR_H
		},
		["sizes"] = {
			["now"] = v_u_1.NOW_SIZE,
			["name"] = v115.nameMax,
			["nameMin"] = v115.nameMin,
			["next"] = v115.nextSize,
			["badge"] = v_u_1.BADGE_SIZE
		}
	}
end
function v_u_1.fillRect(p120, p121) -- name: fillRect
	if type(p121) ~= "number" or (p121 ~= p121 or (p121 == (1 / 0) or p121 == (-1 / 0))) then
		p121 = nil
	end
	local v122 = math.clamp(p121 or 0, 0, 1)
	local v123 = p120.bar.x
	local v124 = p120.bar.y
	local v125 = p120.bar.w * v122 + 0.5
	return {
		["x"] = v123,
		["y"] = v124,
		["w"] = math.floor(v125),
		["h"] = p120.bar.h
	}
end
v_u_1.F8_GAP = 8
v_u_1.F8_COLS = 2
function v_u_1.orderIds(p126, p127) -- name: orderIds
	local v128 = {}
	local v129 = {}
	local v130 = nil
	local v131
	if type(p126) == "table" then
		local v132 = p126.ORDER
		if type(v132) == "table" then
			v131 = p126.ORDER
		else
			local v133 = p126.order
			if type(v133) == "function" then
				local v134 = p126.order
				local v135
				v135, v131 = pcall(v134)
				if v135 then
					if type(v131) ~= "table" then
						v131 = v130
					end
				else
					v131 = v130
				end
			else
				v131 = v130
			end
		end
	else
		v131 = v130
	end
	if type(v131) == "table" then
		for _, v137 in v131 do
			if type(v137) == "table" then
				local v137 = v137.id
			end
			if type(v137) ~= "string" or (v137 == "" or v129[v137]) then
				continue
			end
			v129[v137] = true
			table.insert(v128, v137)
		end
	end
	if #v128 == 0 and type(p127) == "table" then
		local v138 = p127.LIST
		if type(v138) == "table" then
			for _, v140 in p127.LIST do
				if type(v140) == "table" then
					local v140 = v140.id
				end
				if type(v140) ~= "string" or (v140 == "" or v129[v140]) then
					continue
				end
				v129[v140] = true
				table.insert(v128, v140)
			end
		end
	end
	return v128
end
function v_u_1.f8Layout(p141, p142, p143) -- name: f8Layout
	-- upvalues: (copy) v_u_1
	local v144 = 320
	if type(p141) ~= "number" or (p141 ~= p141 or (p141 == (1 / 0) or p141 == (-1 / 0))) then
		p141 = nil
	end
	local v145 = math.floor(p141 or 0)
	local v146 = math.max(v144, v145)
	local v147 = 34
	if type(p142) ~= "number" or (p142 ~= p142 or (p142 == (1 / 0) or p142 == (-1 / 0))) then
		p142 = nil
	end
	local v148 = math.floor(p142 or 0)
	local v149 = math.max(v147, v148)
	local v150 = 0
	if type(p143) ~= "number" or (p143 ~= p143 or (p143 == (1 / 0) or p143 == (-1 / 0))) then
		p143 = nil
	end
	local v151 = math.floor(p143 or 0)
	local v152 = math.max(v150, v151)
	local v153 = v_u_1.F8_GAP
	local v154 = v_u_1.F8_COLS
	local v155 = (v146 - v153 * (v154 - 1)) / v154
	local v156 = math.floor(v155)
	local v157 = v152 / v154
	local v158 = math.ceil(v157)
	local v159 = {}
	for v160 = 1, v152 do
		local v161 = (v160 - 1) % v154
		local v162 = (v160 - 1) / v154
		local v163 = math.floor(v162)
		local v164 = v161 * (v156 + v153)
		local v165
		if v161 == v154 - 1 then
			v165 = v146 - v164
		else
			v165 = v156
		end
		local v166 = {
			["x"] = v164,
			["y"] = v163 * (v149 + v153),
			["w"] = v165,
			["h"] = v149
		}
		table.insert(v159, v166)
	end
	local v167 = v158 * (v149 + v153)
	return {
		["w"] = v146,
		["h"] = v167 + v149,
		["gap"] = v153,
		["cols"] = v154,
		["rows"] = v158,
		["maps"] = v159,
		["rotate"] = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v167,
			["w"] = v146,
			["h"] = v149
		}
	}
end
function v_u_1.f8Status(p168, p169) -- name: f8Status
	-- upvalues: (copy) v_u_1, (copy) v_u_6
	if type(p168) ~= "table" then
		return v_u_1.TEXT.f8Reading
	end
	local v170 = string.upper(v_u_6(p168.mapName) or (v_u_6(p168.map) or "?"))
	local v171 = string.upper(v_u_6(p168.nextName) or (v_u_6(p168.nextMap) or "?"))
	if p168.forced == true then
		return ("%s: %s, rotation next: %s"):format(v_u_1.TEXT.byHand, v170, v171)
	end
	if p169 == nil then
		p169 = p168.secondsLeft
	end
	return ("NOW: %s, NEXT: %s %s"):format(v170, v171, v_u_1.countdownText(p169))
end
return v_u_1