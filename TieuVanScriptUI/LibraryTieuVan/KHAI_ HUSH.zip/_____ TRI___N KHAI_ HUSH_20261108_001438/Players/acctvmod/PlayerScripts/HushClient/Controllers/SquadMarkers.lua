-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / SquadMarkers

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v3 = script.Parent and script.Parent.Parent
if v3 then
	v3 = script.Parent.Parent:FindFirstChild("Lib")
end
if v3 then
	v3 = v3:FindFirstChild("ServerClock") or v3:WaitForChild("ServerClock", 5)
end
local v_u_4 = not v3 and {
	["now"] = function() -- name: now
		return workspace:GetServerTimeNow()
	end
} or require(v3)
local v_u_5 = {
	["name"] = "SquadMarkers",
	["order"] = 43
}
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = v_u_1.LocalPlayer
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = false
local v_u_19 = 1
local v_u_20 = 1
local v_u_21 = 0
local v_u_22 = {
	["mates"] = 0,
	["tags"] = 0,
	["edges"] = 0
}
local function v_u_23() -- name: tagParent
	-- upvalues: (copy) v_u_13
	return v_u_13:WaitForChild("PlayerGui")
end
local function v_u_33(p24, p25, p26) -- name: newMate
	-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_8, (copy) v_u_23, (ref) v_u_10, (ref) v_u_17, (ref) v_u_16, (copy) v_u_14
	local v27 = {
		["id"] = nil,
		["name"] = nil,
		["char"] = nil,
		["tag"] = nil,
		["edge"] = nil,
		["fake"] = nil,
		["id"] = p24,
		["name"] = p25,
		["tag"] = v_u_9.new(v_u_7, v_u_8, p24, v_u_23())
	}
	local v28 = v_u_10.new
	local v29 = v_u_7
	local v30 = v_u_8
	local v31
	if v_u_17 and (v_u_17.Parent and (v_u_16 and v_u_16.Parent)) then
		v31 = v_u_17
	else
		local v32
		v32, v31 = v_u_7.screen("HushSquadEdge", v_u_8.layer.world, {
			["insets"] = "None"
		})
		v_u_16 = v32
		v_u_17 = v31
	end
	v27.edge = v28(v29, v30, v31)
	v27.fake = p26
	v_u_14[p24] = v27
	return v27
end
local function v_u_46() -- name: touchRects
	-- upvalues: (ref) v_u_6, (ref) v_u_7
	local v34 = {}
	local v35 = v_u_6.controllers.Input
	if not v35 or (not v35.touchRects or v_u_7.device() ~= "Touch") then
		return v34
	end
	local v36 = v35.touchRects
	local v37, v38 = pcall(v36)
	if not v37 or type(v38) ~= "table" then
		return v34
	end
	local v39 = Vector2.zero
	local v40 = v35.touch
	if v40 then
		v40 = v35.touch()
	end
	if v40 then
		v40 = v40.root
	end
	if v40 and v40:IsA("GuiObject") then
		v39 = v40.AbsolutePosition
	end
	for v41, v42 in v38 do
		if typeof(v42) ~= "Rect" or v41 == "moveZone" then
			continue
		end
		local v43 = v_u_7.absToOverlay(v39 + v42.Min)
		local v44 = v_u_7.absToOverlay(v39 + v42.Max)
		local v45 = {
			v43.X,
			v43.Y,
			v44.X,
			v44.Y
		}
		table.insert(v34, v45)
	end
	return v34
end
local function v_u_53(p47, p48) -- name: tagSafeBox
	-- upvalues: (copy) v_u_2
	local v49 = p47.ViewportSize
	local v_u_50 = 0
	local function v51()
		-- upvalues: (ref) v_u_50, (ref) v_u_2
		v_u_50 = v_u_2.TopbarInset.Max.Y
	end
	pcall(v51)
	local v52 = p48 and 44 or 10
	return {
		v52,
		(v_u_50 <= 0 and 58 or v_u_50) + 6,
		v49.X - v52,
		v49.Y - 10
	}
end
local function v_u_78() -- name: scan
	-- upvalues: (copy) v_u_13, (ref) v_u_18, (copy) v_u_1, (ref) v_u_12, (copy) v_u_15, (copy) v_u_14, (copy) v_u_33
	local v54 = v_u_13:GetAttribute("SquadId")
	if type(v54) ~= "string" or v54 == "" then
		v54 = v_u_13.Character
		if v54 then
			v54 = v54:GetAttribute("SquadId")
		end
	end
	if type(v54) ~= "string" or v54 == "" then
		v54 = nil
	end
	local v55 = {}
	if v_u_18 and v54 then
		for _, v56 in v_u_1:GetPlayers() do
			if v56 == v_u_13 then
				continue
			end
			local v57 = v56:GetAttribute("SquadId")
			if type(v57) ~= "string" or v57 == "" then
				v57 = v56.Character
				if v57 then
					v57 = v57:GetAttribute("SquadId")
				end
			end
			if type(v57) ~= "string" or v57 == "" then
				v57 = nil
			end
			if v57 ~= v54 then
				continue
			end
			local v58
			if v_u_12 then
				local v59 = v_u_12.mateTag
				local v60 = v56:GetAttribute("SquadId")
				if type(v60) ~= "string" or v60 == "" then
					v60 = v56.Character
					if v60 then
						v60 = v60:GetAttribute("SquadId")
					end
				end
				if type(v60) ~= "string" or v60 == "" then
					v60 = nil
				end
				v58 = v59(v56, v54, v60)
			else
				v58 = nil
			end
			local v61 = v56.UserId
			local v62 = {
				["name"] = nil,
				["clan"] = nil,
				["cstyle"] = nil,
				["char"] = nil,
				["fake"] = false,
				["name"] = v56.DisplayName,
				["clan"] = v58
			}
			local v63
			if v58 and (v_u_12 and v_u_12.mateStyle) then
				local v64 = v_u_12.mateStyle
				local v65 = v56:GetAttribute("SquadId")
				if type(v65) ~= "string" or v65 == "" then
					v65 = v56.Character
					if v65 then
						v65 = v65:GetAttribute("SquadId")
					end
				end
				if type(v65) ~= "string" or v65 == "" then
					v65 = nil
				end
				v63 = v64(v56, v54, v65)
			else
				v63 = nil
			end
			v62.cstyle = v63
			v62.char = v56.Character
			v55[v61] = v62
		end
	end
	for v66 = #v_u_15, 1, -1 do
		local v67 = v_u_15[v66]
		if v67.model.Parent then
			if not v_u_18 then
				continue
			end
			v55[v67.id] = {
				["name"] = nil,
				["char"] = nil,
				["fake"] = true,
				["name"] = v67.name,
				["char"] = v67.model
			}
		else
			table.remove(v_u_15, v66)
		end
	end
	for v68 in table.clone(v_u_14) do
		if v55[v68] then
			continue
		end
		local v69 = v_u_14[v68]
		if not v69 then
			continue
		end
		local v70 = v69.tag.destroy
		local v71 = v69.tag
		pcall(v70, v71)
		local v72 = v69.edge.destroy
		local v73 = v69.edge
		pcall(v72, v73)
		v_u_14[v68] = nil
	end
	for v74, v75 in v55 do
		local v76 = v_u_14[v74] or v_u_33(v74, v75.name, v75.fake)
		v76.name = v75.name
		v76.clan = v75.clan
		v76.cstyle = v75.cstyle
		local v77
		if v_u_12 and v76.clan then
			if v_u_12.richFor then
				v77 = v_u_12.richFor(v76.clan, v76.cstyle, nil)
			else
				v77 = v_u_12.prefixRich(v76.clan, nil, nil)
			end
		else
			v77 = nil
		end
		v76.clanRich = v77
		v76.char = v75.char
	end
end
local v_u_79 = nil
local function v_u_86(p80, p81) -- name: tallyFor
	-- upvalues: (ref) v_u_79, (ref) v_u_6, (copy) v_u_1
	if v_u_79 == nil then
		local function v82()
			-- upvalues: (ref) v_u_6
			return v_u_6.lib.TallyMark
		end
		local v83, v84 = pcall(v82)
		v_u_79 = v83 and v84 and v84 or false
	end
	if v_u_79 then
		local v85 = v_u_1:GetPlayerByUserId(p80)
		if v85 == nil then
			return nil
		else
			return v_u_79.mateText(v85:GetAttribute("SkinsTally"), p81:GetAttribute("Weapon"))
		end
	else
		return nil
	end
end
local function v_u_152(p87) -- name: update
	-- upvalues: (ref) v_u_21, (ref) v_u_19, (copy) v_u_78, (copy) v_u_14, (copy) v_u_22, (ref) v_u_18, (ref) v_u_6, (ref) v_u_20, (copy) v_u_4, (copy) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_10, (copy) v_u_46, (ref) v_u_12, (ref) v_u_11, (copy) v_u_86, (copy) v_u_53
	v_u_21 = v_u_21 + p87
	v_u_19 = v_u_19 + p87
	if v_u_19 >= 0.25 then
		v_u_19 = 0
		v_u_78()
	end
	local v88 = 0
	local v89 = 0
	local v90 = 0
	if next(v_u_14) == nil then
		local v91 = v_u_22
		local v92 = v_u_22
		v_u_22.mates = 0
		v91.tags = 0
		v92.edges = 0
		return
	end
	local v93 = v_u_18
	if v93 then
		local v94 = v_u_6
		if v94 then
			v94 = v_u_6.controllers.HUD
		end
		if v94 and v94.isVisible then
			local v95 = v94.isVisible
			local v96, v97 = pcall(v95)
			v93 = (not v96 or v97 ~= false) and true or false
		else
			v93 = true
		end
	end
	local v98 = false
	v_u_20 = v_u_20 + p87
	if v_u_20 >= 0.1 then
		v_u_20 = 0
		v98 = true
	end
	local v99 = v_u_4.now()
	local v100 = { v_u_13.UserId }
	for v101 in v_u_14 do
		table.insert(v100, v101)
	end
	local v102 = v_u_13.Character
	if v102 then
		v102 = v102:FindFirstChild("HumanoidRootPart")
	end
	local v103 = v_u_8.refSize()
	local v104 = v_u_7.device() == "Touch"
	local v105 = v_u_8.uiScale()
	local v106 = v_u_7.topInset() + (v104 and 76 or 78)
	local v107 = v_u_10.safeBox(v103, v_u_7.safeInsets(), v106, v104 and 40 or 132, nil, v_u_8.isPhone())
	local v108 = not v104 and {} or v_u_46()
	local v109 = {}
	for _, v110 in v_u_14 do
		v88 = v88 + 1
		local v111 = v110.char
		local v112, v113
		if v111 and (v111.Parent and v111:GetAttribute("Dead") ~= true) then
			v112 = v111:FindFirstChild("Head") or v111:FindFirstChild("HumanoidRootPart")
			v113 = v111:FindFirstChild("HumanoidRootPart") or v112
		else
			v113 = nil
			v112 = nil
		end
		local v114
		if v93 and (v112 and (v113 and v111)) then
			local v115 = v112.Position + Vector3.new(0, 1.5, 0)
			local v116, _, v117 = v_u_7.worldToScreen(v115, true)
			local v118
			if v117 > 0 and (v116.X >= 12 and (v116.X <= v103.X - 12 and v116.Y >= 12)) then
				v118 = v116.Y <= v103.Y - 12
			else
				v118 = false
			end
			v114 = not v118
		else
			v114 = false
		end
		v110.tag:setScale(v105)
		v110.tag:setAdornee(v93 and v112 and v112 or nil)
		local v119
		if v93 and (v112 and (v111 and not v114)) then
			local v120, v121, v122, v123, v124
			if v98 then
				local v125 = v110.tag
				local v126 = {
					["name"] = v110.name,
					["clanRich"] = v110.clanRich,
					["clanAlpha"] = not (v110.clanRich and (v_u_12 and v_u_12.animAlpha)) and 0 or v_u_12.animAlpha(v110.cstyle, v_u_21)
				}
				local v127
				if v110.clanRich and (v_u_12 and v_u_12.outline) then
					v127 = v_u_12.outline(v110.cstyle)
				else
					v127 = nil
				end
				v126.clanStroke = v127
				local v128 = v110.id
				local v129
				if v_u_11 and v_u_11.colorFor then
					local v130 = v_u_11.colorFor
					local v131
					v131, v129 = pcall(v130, v128, v100)
					if v131 and typeof(v129) == "Color3" then
						v126.color = v129
						v126.now = v99
						v126.t = v_u_21
						v126.tally = v_u_86(v110.id, v111)
						v125:update(v111, v126)
					else
						v129 = v_u_8.color.info
						v126.color = v129
						v126.now = v99
						v126.t = v_u_21
						v126.tally = v_u_86(v110.id, v111)
						v125:update(v111, v126)
					end
				else
					v129 = v_u_8.color.info
					v126.color = v129
					v126.now = v99
					v126.t = v_u_21
					v126.tally = v_u_86(v110.id, v111)
					v125:update(v111, v126)
				end
				v120 = workspace.CurrentCamera
				v121 = nil
				if v120 then
					v122 = v120:WorldToViewportPoint(v112.Position + v110.tag.gui.StudsOffsetWorldSpace)
					if v122.Z > 0 then
						v121 = Vector2.new(v122.X, v122.Y)
					end
				end
				v123 = v110.tag
				if v120 then
					v124 = v_u_53(v120, v104)
				else
					v124 = nil
				end
				v123:clamp(v121, v124)
				v110.tag:setShown(true)
				v89 = v89 + 1
				if v93 and (v112 and (v113 and (v111 and v114))) then
					goto l92
				end
				v119 = false
				v110.edge:setShown(v119)
			else
				v120 = workspace.CurrentCamera
				v121 = nil
				if v120 then
					v122 = v120:WorldToViewportPoint(v112.Position + v110.tag.gui.StudsOffsetWorldSpace)
					if v122.Z > 0 then
						v121 = Vector2.new(v122.X, v122.Y)
					end
				end
				v123 = v110.tag
				if v120 then
					v124 = v_u_53(v120, v104)
				else
					v124 = nil
				end
				v123:clamp(v121, v124)
				v110.tag:setShown(true)
				v89 = v89 + 1
				if v93 and (v112 and (v113 and (v111 and v114))) then
					::l92::
					local v132, v133 = v_u_7.screenMarker(v113.Position, v107[1], v107[2], v107[3], v107[4], true)
					if #v108 > 0 then
						v132 = v_u_10.avoid(v132, v108, v107, 36)
					end
					local v134
					if v102 then
						local v135 = v113.Position - v102.Position
						local v136 = v135.X
						local v137 = v135.Z
						local v138 = Vector3.new(v136, 0, v137).Magnitude * 0.28 + 0.5
						local v139 = math.floor(v138)
						v134 = tostring(v139) .. " m"
					else
						v134 = "-"
					end
					local v140 = v110.edge
					local v141 = {}
					local v142
					if v104 then
						v142 = v_u_10.short(v110.name)
					else
						v142 = v110.name
					end
					v141.label = v142
					v141.clanRich = v110.clanRich
					local v143
					if v110.clanRich and (v_u_12 and v_u_12.outline) then
						v143 = v_u_12.outline(v110.cstyle)
					else
						v143 = nil
					end
					v141.clanStroke = v143
					local v144 = v110.id
					local v145
					if v_u_11 and v_u_11.colorFor then
						local v146 = v_u_11.colorFor
						local v147
						v147, v145 = pcall(v146, v144, v100)
						if not v147 or typeof(v145) ~= "Color3" then
							v145 = v_u_8.color.info
						end
					else
						v145 = v_u_8.color.info
					end
					v141.color = v145
					v141.meters = v134
					v141.downed = v111:GetAttribute("Downed") == true
					v141.bleeding = (tonumber(v111:GetAttribute("Bleeding")) or 0) > 0
					v141.t = v_u_21
					v140:set(v141)
					v110.edge:setTouch(v104)
					local v148 = {
						["m"] = v110,
						["pos"] = v132,
						["dir"] = v133,
						["ext"] = v110.edge:extent()
					}
					table.insert(v109, v148)
					v90 = v90 + 1
					v119 = true
					v110.edge:setShown(v119)
				else
					v119 = false
					v110.edge:setShown(v119)
				end
			end
		else
			v110.tag:setShown(false)
			if v93 and (v112 and (v113 and (v111 and v114))) then
				goto l92
			end
			v119 = false
			v110.edge:setShown(v119)
		end
	end
	if #v109 > 1 then
		v_u_10.stack(v109, v107, 6)
	end
	for _, v149 in v109 do
		v149.m.edge:place(v149.pos, v149.dir)
	end
	local v150 = v_u_22
	local v151 = v_u_22
	v_u_22.mates = v88
	v150.tags = v89
	v151.edges = v90
end
local v_u_153 = {
	["edge"] = nil,
	["target"] = nil,
	["pickAcc"] = 1,
	["hintAcc"] = 1,
	["hint"] = "",
	["mode"] = "off",
	["dist"] = 0
}
function v_u_5.exitCompass() -- name: exitCompass
	-- upvalues: (copy) v_u_13
	local v154
	if v_u_13:GetAttribute("TutorialStep") == nil and v_u_13:GetAttribute("Tutorial") ~= true then
		local v155 = v_u_13
		local v156 = tonumber(v155:GetAttribute("ExtractCoach")) or 0
		v154 = v156 ~= 1 and v156 ~= 2 and 0 or v156
	else
		v154 = 0
	end
	local v157 = v154 > 0
	local v158 = v_u_13:GetAttribute("ExitCompassPref")
	if type(v158) == "boolean" then
		return v158, v157
	else
		return v157, v157
	end
end
function v_u_5.setExitCompass(p_u_159, p160) -- name: setExitCompass
	-- upvalues: (copy) v_u_13, (copy) v_u_153, (ref) v_u_6
	v_u_13:SetAttribute("ExitCompassPref", p_u_159)
	v_u_153.pickAcc = 0.25
	if not p160 and (v_u_6 and v_u_6.net) then
		local v161 = v_u_6.net.fire
		if type(v161) == "function" then
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (copy) p_u_159
				local v162 = v_u_6.net.fire
				local v163 = {
					["op"] = "setting",
					["key"] = "exitCompass",
					["value"] = nil,
					["value"] = p_u_159
				}
				pcall(v162, "menu.op", v163)
			end)
		end
	end
end
local function v_u_167() -- name: openExits
	-- upvalues: (ref) v_u_6
	local v164 = {}
	local v165 = v_u_6
	if v165 then
		v165 = v_u_6.runtime
	end
	if v165 then
		v165 = v165:FindFirstChild("Raid")
	end
	if v165 then
		v165 = v165:FindFirstChild("Extracts")
	end
	if v165 then
		for _, v166 in v165:GetChildren() do
			if not v166:IsA("BasePart") or (v166:GetAttribute("Open") ~= true or v166:GetAttribute("Personal") == true) then
				continue
			end
			table.insert(v164, v166)
		end
	end
	return v164
end
local function v_u_169(p168) -- name: hideExit
	-- upvalues: (copy) v_u_153
	v_u_153.mode = p168
	if v_u_153.edge then
		v_u_153.edge:setShown(false)
	end
end
local function v_u_240(p170) -- name: updateExit
	-- upvalues: (copy) v_u_5, (copy) v_u_169, (ref) v_u_18, (ref) v_u_6, (copy) v_u_13, (copy) v_u_153, (copy) v_u_167, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_17, (ref) v_u_16, (copy) v_u_46, (ref) v_u_21
	if not v_u_5.exitCompass() then
		return v_u_169("off")
	end
	if v_u_18 then
		local v171 = v_u_6
		if v171 then
			v171 = v_u_6.controllers.HUD
		end
		local v172
		if v171 and v171.isVisible then
			local v173 = v171.isVisible
			local v174, v175 = pcall(v173)
			v172 = (not v174 or v175 ~= false) and true or false
		else
			v172 = true
		end
		if v172 and v_u_13:GetAttribute("RaidSettingsOpen") ~= true then
			local v176 = v_u_13:GetAttribute("RaidStatus")
			if v176 ~= nil and (v176 ~= "Alive" and v176 ~= "Downed") then
				return v_u_169("out")
			end
			local v177 = v_u_6.controllers.Comms
			if v177 then
				local v178 = v177.extractPing
				if type(v178) == "function" then
					local v179 = v177.extractPing
					local v180, v181 = pcall(v179)
					if v180 and v181 then
						return v_u_169("ping")
					end
				end
			end
			local v182 = v_u_13.Character
			if v182 then
				v182 = v182:FindFirstChild("HumanoidRootPart")
			end
			if not v182 then
				return v_u_169("nochar")
			end
			local v183 = v182.Position
			local v184 = v_u_153
			v184.pickAcc = v184.pickAcc + p170
			local v185 = v_u_153.target
			if v185 and (not v185.Parent or v185:GetAttribute("Open") ~= true) then
				v_u_153.target = nil
				v185 = nil
			end
			local v186
			if v_u_153.pickAcc >= 0.25 or not v185 then
				v_u_153.pickAcc = 0
				local v187 = (1 / 0)
				v186 = nil
				for _, v188 in v_u_167() do
					local v189 = v188.Position
					local v190 = v189.X - v183.X
					local v191 = v189.Z - v183.Z
					local v192 = Vector3.new(v190, 0, v191).Magnitude
					if v192 >= v187 then
						continue
					end
					v186 = v188
					v187 = v192
				end
				if v186 then
					if v185 and v186 ~= v185 then
						local v193 = v187 + 15
						local v194 = v185.Position
						local v195 = v194.X - v183.X
						local v196 = v194.Z - v183.Z
						if v193 >= Vector3.new(v195, 0, v196).Magnitude then
							v186 = v185
						end
					end
				else
					v186 = v185
				end
				v_u_153.target = v186
			else
				v186 = v185
			end
			if not v186 then
				return v_u_169("none")
			end
			local v197 = v186.CFrame:PointToObjectSpace(v183)
			local v198 = v197.X
			if math.abs(v198) <= v186.Size.X / 2 + 6 then
				local v199 = v197.Z
				if math.abs(v199) <= v186.Size.Z / 2 + 6 then
					return v_u_169("near")
				end
			end
			if not v_u_153.edge then
				local v200 = v_u_153
				local v201 = v_u_10.new
				local v202 = v_u_7
				local v203 = v_u_8
				local v204
				if v_u_17 and (v_u_17.Parent and (v_u_16 and v_u_16.Parent)) then
					v204 = v_u_17
				else
					local v205
					v205, v204 = v_u_7.screen("HushSquadEdge", v_u_8.layer.world, {
						["insets"] = "None"
					})
					v_u_16 = v205
					v_u_17 = v204
				end
				v200.edge = v201(v202, v203, v204)
				v_u_153.edge.holder.Name = "ExitCompass"
			end
			local v206 = v_u_7.device() == "Touch"
			local v207 = v_u_153
			v207.hintAcc = v207.hintAcc + p170
			if v_u_153.hintAcc >= 1 then
				v_u_153.hintAcc = 0
				local v208 = ""
				if not v206 then
					local v209 = v_u_6
					if v209 then
						v209 = v_u_6.controllers.Input
					end
					local v210
					if v209 then
						local v211 = v209.hint
						if type(v211) == "function" then
							local v212 = v209.hint
							local v213, v214 = pcall(v212, "map")
							v210 = (not v213 or type(v214) ~= "string") and "" or v214
						else
							v210 = ""
						end
					else
						v210 = ""
					end
					local v215 = v_u_6
					if v215 then
						v215 = v_u_6.controllers.Input
					end
					local v216
					if v215 then
						local v217 = v215.hint
						if type(v217) == "function" then
							local v218 = v215.hint
							local v219, v220 = pcall(v218, "extracts")
							v216 = (not v219 or type(v220) ~= "string") and "" or v220
						else
							v216 = ""
						end
					else
						v216 = ""
					end
					if v210 ~= "" and v216 ~= "" then
						v208 = ("%s: map  \194\183  %s: exits"):format(v210, v216)
					end
				end
				v_u_153.hint = v208
			end
			local v221 = v_u_8.refSize()
			local v222 = v_u_7.topInset() + (v206 and 76 or 78)
			local v223 = v_u_10.safeBox(v221, v_u_7.safeInsets(), v222, v206 and 40 or 132, nil, v_u_8.isPhone())
			local v224 = v186.Position
			local v225 = v186.Size.Y / 2 - 2
			local v226 = v224 - Vector3.new(0, v225, 0)
			local v227, _, v228 = v_u_7.worldToScreen(v226, true)
			local v229, v230
			if v228 > 0 and (v227.X >= v223[1] and (v227.X <= v223[3] and (v227.Y >= v223[2] + 70 and v227.Y <= v223[4]))) then
				v229 = Vector2.new(v227.X, v227.Y - 14)
				v230 = Vector2.new(0, 1)
				v_u_153.mode = "screen"
			else
				v229, v230 = v_u_7.screenMarker(v226, v223[1], v223[2], v223[3], v223[4], true)
				if v206 then
					local v231 = v_u_46()
					if #v231 > 0 then
						v229 = v_u_10.avoid(v229, v231, v223, 36)
					end
				end
				v_u_153.mode = "edge"
			end
			local v232 = v186.Position
			local v233 = v232.X - v183.X
			local v234 = v232.Z - v183.Z
			local v235 = Vector3.new(v233, 0, v234).Magnitude
			v_u_153.dist = v235
			local v236 = v186:GetAttribute("Name")
			local v237 = v_u_153.edge
			local v238 = {
				["label"] = nil,
				["color"] = nil,
				["meters"] = nil,
				["hint"] = nil,
				["nameColor"] = nil,
				["downed"] = false,
				["bleeding"] = false,
				["t"] = nil,
				["label"] = (type(v236) ~= "string" or v236 == "") and "Exit" or v236,
				["color"] = v_u_8.color.success
			}
			local v239 = v235 * 0.28 + 0.5
			v238.meters = ("EXIT  %d m"):format((math.floor(v239)))
			v238.hint = v_u_153.hint
			v238.nameColor = v_u_8.color.success
			v238.t = v_u_21
			v237:set(v238)
			v_u_153.edge:setTouch(true)
			v_u_153.edge:setShown(true)
			v_u_153.edge:place(v229, v230)
			return
		end
	end
	return v_u_169("hud")
end
local function v_u_253() -- name: exitState
	-- upvalues: (copy) v_u_5, (copy) v_u_153, (copy) v_u_13
	local v241, v242 = v_u_5.exitCompass()
	local v243 = v_u_153.target
	local v244 = v_u_13:GetAttribute("ExitCompassPref")
	local v245 = "on=%s auto=%s pref=%s mode=%s target=%s %dm hint=%s"
	local v246 = tostring(v241)
	local v247 = tostring(v242)
	local v248 = tostring(v244)
	local v249 = v_u_153.mode
	local v250
	if v243 then
		local v251 = v243:GetAttribute("Name") or v243.Name
		v250 = tostring(v251)
	else
		v250 = "-"
	end
	local v252 = v_u_153.dist * 0.28 + 0.5
	return v245:format(v246, v247, v248, v249, v250, math.floor(v252), v_u_153.hint)
end
local function v_u_260(p254, p255, p256) -- name: placeFake
	-- upvalues: (copy) v_u_13
	local v257 = v_u_13.Character
	if v257 then
		v257 = v257:FindFirstChild("HumanoidRootPart")
	end
	if v257 then
		v257 = v257.Position
	end
	if v257 then
		local v258 = p254:FindFirstChild("HumanoidRootPart")
		local v259 = CFrame.new(v257 + Vector3.new(p255, 0, p256)) * CFrame.Angles(0, 3.141592653589793, 0)
		if v258 then
			p254.PrimaryPart = v258
		end
		p254:PivotTo(v259)
	end
end
local function v_u_276(p261, p262) -- name: addFake
	-- upvalues: (copy) v_u_13, (copy) v_u_15, (copy) v_u_260, (ref) v_u_19
	local v_u_263 = v_u_13.Character
	if not v_u_263 then
		return "no character"
	end
	local v264 = v_u_263.Archivable
	v_u_263.Archivable = true
	local v265, v266 = pcall(function()
		-- upvalues: (copy) v_u_263
		return v_u_263:Clone()
	end)
	v_u_263.Archivable = v264
	if not (v265 and v266) then
		return "clone failed: " .. tostring(v266)
	end
	for _, v267 in v266:GetDescendants() do
		if v267:IsA("LuaSourceContainer") or (v267:IsA("Sound") or (v267:IsA("BillboardGui") or v267:IsA("ProximityPrompt"))) then
			v267:Destroy()
		else
			if not v267:IsA("BasePart") then
				continue
			end
			v267.Anchored = true
			v267.CanCollide = false
			v267.CanQuery = false
			v267.CanTouch = false
		end
	end
	local v268 = v266:FindFirstChildOfClass("Humanoid")
	if v268 then
		v268.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v268.PlatformStand = true
	end
	local v269 = #v_u_15 + 1
	local v270 = -1000 - v269
	local v271 = "Fake Mate " .. v269
	v266.Name = "HushSquadFake" .. v269
	for v272 in v266:GetAttributes() do
		v266:SetAttribute(v272, nil)
	end
	v266:SetAttribute("Hp", 100)
	v266:SetAttribute("MaxHp", 100)
	local v273 = "SquadId"
	local v274 = v_u_13:GetAttribute("SquadId")
	if type(v274) ~= "string" or v274 == "" then
		v274 = v_u_13.Character
		if v274 then
			v274 = v274:GetAttribute("SquadId")
		end
	end
	if type(v274) ~= "string" or v274 == "" then
		v274 = nil
	end
	v266:SetAttribute(v273, v274 or "FAKE")
	v266:SetAttribute("Bleeding", 0)
	v266:SetAttribute("Fracture", false)
	v266:SetAttribute("Infected", false)
	v266:SetAttribute("Downed", false)
	v266:SetAttribute("Dead", false)
	v266:SetAttribute("Exhausted", false)
	v266.Parent = workspace
	v_u_260(v266, p261, p262)
	local v275 = v_u_15
	table.insert(v275, {
		["id"] = v270,
		["name"] = v271,
		["model"] = v266
	})
	v_u_19 = 0.25
	return "fake " .. v269 .. " added at " .. p261 .. "," .. p262
end
function v_u_5.mates() -- name: mates
	-- upvalues: (copy) v_u_14
	local v277 = {}
	for v278, v279 in v_u_14 do
		local v280 = {
			["userId"] = v278,
			["name"] = v279.name,
			["char"] = v279.char
		}
		table.insert(v277, v280)
	end
	return v277
end
function v_u_5.init(p_u_281) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_15, (ref) v_u_19, (copy) v_u_276, (copy) v_u_4, (copy) v_u_260, (ref) v_u_18, (copy) v_u_22, (copy) v_u_14, (copy) v_u_5, (copy) v_u_253, (copy) v_u_153, (ref) v_u_16, (ref) v_u_17
	v_u_6 = p_u_281
	v_u_7 = p_u_281.lib.HushUI
	v_u_7.bind(p_u_281)
	v_u_8 = p_u_281.shared.Theme
	v_u_9 = p_u_281.lib.SquadMarkersTag
	v_u_10 = p_u_281.lib.SquadMarkersEdge
	local v282, v283 = pcall(function()
		-- upvalues: (copy) p_u_281
		return p_u_281.lib.HUDSquad
	end)
	if not v282 then
		v283 = nil
	end
	v_u_11 = v283
	local v284, v285 = pcall(function()
		-- upvalues: (copy) p_u_281
		return p_u_281.lib.ClanTagText
	end)
	if not v284 or type(v285) ~= "table" then
		v285 = nil
	end
	v_u_12 = v285
	p_u_281.command("squadmarkers.fake", function(p286)
		-- upvalues: (ref) v_u_15, (ref) v_u_19, (ref) v_u_276
		if p286[1] == "off" then
			for _, v287 in v_u_15 do
				v287.model:Destroy()
			end
			table.clear(v_u_15)
			v_u_19 = 0.25
			return "fakes removed"
		end
		local v288 = v_u_276
		local v289 = p286[2]
		local v290 = tonumber(v289) or 14
		local v291 = p286[3]
		return v288(v290, tonumber(v291) or 0)
	end)
	p_u_281.command("squadmarkers.set", function(p292)
		-- upvalues: (ref) v_u_15, (ref) v_u_4
		local v293 = v_u_15
		local v294 = p292[1]
		local v295 = v293[tonumber(v294) or 0]
		if not v295 then
			local v296 = p292[1]
			return "no fake " .. tostring(v296)
		end
		local v297 = p292[2]
		if not v297 then
			return "usage: squadmarkers.set <i> <Attr> <value>"
		end
		local v298 = p292[3]
		local v299
		if v298 == nil then
			v299 = nil
		elseif v298 == "true" then
			v299 = true
		elseif v298 == "false" then
			v299 = false
		elseif string.sub(v298, 1, 1) == "+" then
			local v300 = v_u_4.now()
			local v301 = string.sub(v298, 2)
			v299 = v300 + (tonumber(v301) or 0)
		else
			v299 = tonumber(v298) or v298
		end
		v295.model:SetAttribute(v297, v299)
		local v302 = v_u_4.now()
		if v297 == "Downed" and v299 == true then
			v295.model:SetAttribute("DownedAt", v302)
			local v303 = v295.model
			if (tonumber(v303:GetAttribute("DownedUntil")) or 0) <= v302 then
				v295.model:SetAttribute("DownedUntil", v302 + 30)
			end
			v295.model:SetAttribute("Hp", 0)
		elseif v297 == "Infected" and v299 == true then
			v295.model:SetAttribute("InfectedAt", v302)
			local v304 = v295.model
			if (tonumber(v304:GetAttribute("InfectionEndsAt")) or 0) <= v302 then
				v295.model:SetAttribute("InfectionEndsAt", v302 + 300)
			end
		end
		return v297 .. "=" .. tostring(v299)
	end)
	p_u_281.command("squadmarkers.move", function(p305)
		-- upvalues: (ref) v_u_15, (ref) v_u_260
		local v306 = v_u_15
		local v307 = p305[1]
		local v308 = v306[tonumber(v307) or 0]
		if not v308 then
			local v309 = p305[1]
			return "no fake " .. tostring(v309)
		end
		local v310 = v_u_260
		local v311 = v308.model
		local v312 = p305[2]
		local v313 = tonumber(v312) or 0
		local v314 = p305[3]
		v310(v311, v313, tonumber(v314) or 0)
		return "moved"
	end)
	p_u_281.command("squadmarkers.state", function()
		-- upvalues: (ref) v_u_18, (ref) v_u_22, (ref) v_u_14
		local v315 = {}
		local v316 = v_u_18
		__set_list(v315, 1, {string.format("inRaid=%s mates=%d tags=%d edges=%d", tostring(v316), v_u_22.mates, v_u_22.tags, v_u_22.edges)})
		for v317, v318 in v_u_14 do
			local v319 = v318.tag.shift or Vector2.zero
			local v320 = string.format
			local v321 = v318.name
			local v322 = table.concat(v318.tag.active or {}, ",")
			local v323 = v318.edge.holder.Visible and " edge" or ""
			local v324 = v319.X + 0.5
			local v325 = math.floor(v324)
			local v326 = v319.Y + 0.5
			local v327 = math.floor(v326)
			table.insert(v315, v320("%d:%s[%s]%s shift=%d,%d", v317, v321, v322, v323, v325, v327))
		end
		return table.concat(v315, " | ")
	end)
	p_u_281.command("exitcompass", function(p328)
		-- upvalues: (ref) v_u_5, (ref) v_u_253
		local v329 = p328[1] or "state"
		if v329 == "on" then
			v_u_5.setExitCompass(true)
		elseif v329 == "off" then
			v_u_5.setExitCompass(false)
		elseif v329 == "auto" then
			v_u_5.setExitCompass(nil)
		end
		return v_u_253()
	end)
	p_u_281.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_14, (ref) v_u_153, (ref) v_u_16, (ref) v_u_17, (ref) v_u_19
		for v330 in table.clone(v_u_14) do
			local v331 = v_u_14[v330]
			if not v331 then
				continue
			end
			local v332 = v331.tag.destroy
			local v333 = v331.tag
			pcall(v332, v333)
			local v334 = v331.edge.destroy
			local v335 = v331.edge
			pcall(v334, v335)
			v_u_14[v330] = nil
		end
		if v_u_153.edge then
			local v336 = v_u_153.edge.destroy
			local v337 = v_u_153.edge
			pcall(v336, v337)
			v_u_153.edge = nil
		end
		if v_u_16 then
			v_u_16:Destroy()
		end
		v_u_16 = nil
		v_u_17 = nil
		v_u_19 = 0.25
	end)
end
function v_u_5.start() -- name: start
	-- upvalues: (ref) v_u_18, (copy) v_u_14, (ref) v_u_19, (ref) v_u_6, (copy) v_u_13
	local function v345(p338) -- name: onPlace
		-- upvalues: (ref) v_u_18, (ref) v_u_14, (ref) v_u_19
		v_u_18 = p338 == "Raid"
		if not v_u_18 then
			for v339 in table.clone(v_u_14) do
				local v340 = v_u_14[v339]
				if not v340 then
					continue
				end
				local v341 = v340.tag.destroy
				local v342 = v340.tag
				pcall(v341, v342)
				local v343 = v340.edge.destroy
				local v344 = v340.edge
				pcall(v343, v344)
				v_u_14[v339] = nil
			end
		end
		v_u_19 = 0.25
	end
	local function v352()
		-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_18, (ref) v_u_14, (ref) v_u_19
		v_u_18 = v_u_6.session.place(v_u_13) == "Raid"
		if not v_u_18 then
			for v346 in table.clone(v_u_14) do
				local v347 = v_u_14[v346]
				if not v347 then
					continue
				end
				local v348 = v347.tag.destroy
				local v349 = v347.tag
				pcall(v348, v349)
				local v350 = v347.edge.destroy
				local v351 = v347.edge
				pcall(v350, v351)
				v_u_14[v346] = nil
			end
		end
		v_u_19 = 0.25
	end
	pcall(v352)
	v_u_6.session.onPlaceChanged(v345)
end
local v_u_353 = 0
function v_u_5.step(p354) -- name: step
	-- upvalues: (copy) v_u_152, (copy) v_u_240, (ref) v_u_353, (copy) v_u_22, (copy) v_u_13, (copy) v_u_253
	v_u_152(p354)
	v_u_240(p354)
	v_u_353 = v_u_353 + p354
	if v_u_353 >= 1 then
		v_u_353 = 0
		local v355 = string.format("mates=%d tags=%d edges=%d", v_u_22.mates, v_u_22.tags, v_u_22.edges)
		if v_u_13:GetAttribute("SquadMarkersState") ~= v355 then
			v_u_13:SetAttribute("SquadMarkersState", v355)
		end
		local v356 = v_u_253()
		if v_u_13:GetAttribute("ExitCompassState") ~= v356 then
			v_u_13:SetAttribute("ExitCompassState", v356)
		end
	end
end
return v_u_5