-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmTest

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = v_u_3.Theme
local v_u_5 = v_u_4.color
local v_u_6 = {}
local v_u_7 = v1.LocalPlayer
function v_u_6.agoText(p8) -- name: agoText
	local v9 = math.floor(p8)
	local v10 = math.max(0, v9)
	if v10 < 10 then
		return "just now"
	elseif v10 < 60 then
		return ("%d s ago"):format(v10)
	elseif v10 < 3600 then
		return ("%d min ago"):format(v10 // 60)
	elseif v10 < 86400 then
		return ("%d h ago"):format(v10 // 3600)
	else
		return ("%d d ago"):format(v10 // 86400)
	end
end
function v_u_6.epochText(p11, p12) -- name: epochText
	-- upvalues: (copy) v_u_6
	local v13
	if type(p11) == "table" then
		local v14 = p11.n
		v13 = tonumber(v14) or 0
	else
		v13 = 0
	end
	local v15
	if type(p11) == "table" then
		local v16 = p11.at
		v15 = tonumber(v16) or 0
	else
		v15 = 0
	end
	if v15 <= 0 then
		return ("Epoch %d  \194\183  never refreshed"):format(v13)
	end
	local v17 = p11.byName
	local v18
	if type(v17) == "string" and p11.byName ~= "" then
		v18 = p11.byName
	else
		local v19 = p11.by
		if (tonumber(v19) or 0) > 0 then
			local v20 = p11.by
			v18 = "user " .. tostring(v20)
		else
			v18 = nil
		end
	end
	return ("Epoch %d  \194\183  set %s%s"):format(v13, v_u_6.agoText(p12 - v15), not v18 and "" or " by " .. v18)
end
function v_u_6.playerState(p21) -- name: playerState
	local v22 = p21.status or ""
	local v23 = tostring(v22)
	if string.sub(v23, 1, 6) == "failed" then
		return "Copy failed", "danger"
	elseif v23 == "copying" then
		return "Copying ...", "accent"
	elseif p21.loaded == true then
		if p21.current == true then
			return p21.none == true and "Up to date (no live save)" or "Up to date", "success"
		else
			return "Old copy", "warn"
		end
	else
		return "Loading", "muted"
	end
end
function v_u_6.resultText(p24, p25) -- name: resultText
	-- upvalues: (copy) v_u_6
	local v26 = p24.status or ""
	local v27 = tostring(v26)
	local v28
	if v27 == "failed" then
		local v29 = p24.reason or "?"
		v28 = "failed: " .. tostring(v29)
	else
		v28 = v27 == "none" and "no live save" or v27
	end
	local v30 = p24.name
	local v31 = tostring(v30)
	local v32 = p24.seconds
	local v33 = tonumber(v32) or 0
	local v34 = v_u_6.agoText
	local v35 = p24.at
	local v36 = ("%s  \194\183  %s  \194\183  %.1f s  \194\183  %s"):format(v31, v28, v33, v34(p25 - (tonumber(v35) or p25)))
	if v27 == "failed" then
		return v36, "danger"
	elseif v27 == "none" then
		return v36, "muted"
	else
		return v36, "success"
	end
end
function v_u_6.build(p_u_37) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2
	local v_u_38 = p_u_37.body
	local v_u_39 = p_u_37.api
	local v_u_40 = true
	p_u_37.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_40
		v_u_40 = false
	end)
	local v_u_41 = 0
	local function v44(p42) -- name: section
		-- upvalues: (ref) v_u_3, (copy) v_u_38, (ref) v_u_5, (ref) v_u_41
		local v43 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_38,
			["text"] = p42,
			["color"] = v_u_5.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_41 = v_u_41 + 1
		v43.LayoutOrder = v_u_41
		return v43
	end
	local function v48(p45, p46) -- name: note
		-- upvalues: (ref) v_u_3, (copy) v_u_38, (ref) v_u_5, (ref) v_u_41
		local v47 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_38,
			["text"] = p45,
			["color"] = p46 or v_u_5.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_41 = v_u_41 + 1
		v47.LayoutOrder = v_u_41
		return v47
	end
	local function v52(p49, p50) -- name: row
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_38, (ref) v_u_41
		local v51 = v_u_3.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = p50,
			["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(p49))
		}, v_u_38)
		v_u_3.layout(v51, "h", 6)
		v_u_41 = v_u_41 + 1
		v51.LayoutOrder = v_u_41
		return v51
	end
	local v_u_53 = nil
	local v_u_54 = nil
	local v_u_55 = false
	local v_u_56 = {}
	local function v_u_57(_) end
	local v58 = v52(32, "TestHeadRow")
	local v_u_59 = v_u_3.label({
		["parent"] = nil,
		["name"] = "TestTitle",
		["text"] = "Test game",
		["style"] = "bodyStrong",
		["size"] = nil,
		["parent"] = v58,
		["size"] = UDim2.fromOffset(p_u_37.inner - 126, v_u_4.touch(32))
	})
	v_u_59.LayoutOrder = 1
	local v60 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v58,
		["onClick"] = function()
			-- upvalues: (ref) v_u_57
			v_u_57(false)
		end
	}
	local v61 = v_u_3.button(v60)
	v61.Name = "TestRefreshView"
	v61.LayoutOrder = 2
	local function v64(p62) -- name: line
		-- upvalues: (ref) v_u_3, (copy) v_u_38, (ref) v_u_5, (ref) v_u_41
		local v63 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = "...",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_38,
			["name"] = p62,
			["color"] = v_u_5.text2,
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		v_u_41 = v_u_41 + 1
		v63.LayoutOrder = v_u_41
		return v63
	end
	local v_u_65 = v64("TestEnv")
	local v_u_66 = v64("TestEpoch")
	local v_u_67 = v64("TestUpToDate")
	local v68 = v52(32, "TestKeyRow")
	local v_u_69 = v_u_3.label({
		["parent"] = nil,
		["name"] = "TestKey",
		["text"] = "Read key: not checked",
		["style"] = "bodyStrong",
		["size"] = nil,
		["parent"] = v68,
		["size"] = UDim2.fromOffset(p_u_37.inner - 126, v_u_4.touch(32))
	})
	v_u_69.LayoutOrder = 1
	local v70, v_u_71 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Check key",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v68,
		["onClick"] = function() end
	})
	v70.Name = "TestCheckKey"
	v70.LayoutOrder = 2
	local v_u_72 = v48("")
	v_u_72.Name = "TestKeyNote"
	v_u_72.Visible = false
	local v_u_73 = v_u_3.label({
		["parent"] = nil,
		["name"] = "TestBusy",
		["text"] = "Working ... this can take a few seconds.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_38,
		["color"] = v_u_5.accent,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_41 = v_u_41 + 1
	v_u_73.LayoutOrder = v_u_41
	v_u_73.Visible = false
	local v_u_74 = v_u_3.label({
		["parent"] = nil,
		["name"] = "TestError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_38,
		["color"] = v_u_5.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_41 = v_u_41 + 1
	v_u_74.LayoutOrder = v_u_41
	v_u_74.Visible = false
	v44("Refresh live copies")
	v48("Every tester\'s NEXT join replaces his test progress with a fresh copy of his live save. Players online right now are not touched and keep playing.")
	local v_u_75 = nil
	local v_u_76 = nil
	local v_u_77 = nil
	local v_u_78 = nil
	local v79 = {}
	local function v_u_82(p80) -- name: setBusy
		-- upvalues: (ref) v_u_55, (copy) v_u_73, (ref) v_u_7, (ref) v_u_76, (ref) v_u_78, (copy) v_u_71, (ref) v_u_54
		v_u_55 = p80
		v_u_73.Visible = p80
		v_u_7:SetAttribute("FilmTestBusy", p80)
		for _, v81 in { v_u_76, v_u_78, v_u_71 } do
			if not v81 then
				continue
			end
			v81.setEnabled(not p80)
		end
		if not p80 and (v_u_78 and v_u_54 == nil) then
			v_u_78.setEnabled(false)
		end
	end
	local function v_u_83(_) end
	local function v_u_93(p_u_84, p_u_85, p_u_86, p87, p_u_88) -- name: arm
		-- upvalues: (copy) v_u_56, (ref) v_u_3, (ref) v_u_5, (ref) v_u_40
		v_u_56[p_u_84] = os.clock()
		p_u_85.setText(p87)
		if not p_u_88:FindFirstChild("ConfirmStroke") then
			v_u_3.stroke(p_u_88, v_u_5.danger).Name = "ConfirmStroke"
		end
		task.delay(5.2, function()
			-- upvalues: (ref) v_u_40, (ref) v_u_56, (copy) p_u_84, (copy) p_u_85, (copy) p_u_86, (copy) p_u_88
			if v_u_40 and (v_u_56[p_u_84] ~= nil and os.clock() - v_u_56[p_u_84] >= 5) then
				local v89 = p_u_85
				local v90 = p_u_86
				local v91 = p_u_88
				v_u_56[p_u_84] = nil
				v89.setText(v90)
				local v92 = v91:FindFirstChild("ConfirmStroke")
				if v92 then
					v92:Destroy()
				end
			end
		end)
	end
	local function v_u_125(p94) -- name: apply
		-- upvalues: (ref) v_u_53, (copy) v_u_65, (copy) v_u_66, (ref) v_u_6, (copy) v_u_67, (copy) v_u_69, (ref) v_u_5, (copy) v_u_72, (copy) v_u_59, (ref) v_u_7, (ref) v_u_83
		if type(p94) == "table" then
			local v95 = p94.epoch
			if type(v95) == "table" then
				v_u_53 = p94
				local v96 = p94.epoch
				local v97 = v_u_65
				local v98 = p94.env
				local v99 = tostring(v98)
				local v100 = p94.liveUniverse
				v97.Text = ("Environment: %s  \194\183  live universe %s (read only)"):format(v99, (tostring(v100)))
				local v101 = v_u_66
				local v102 = v_u_6.epochText
				local v103 = p94.now
				v101.Text = v102(v96, tonumber(v103) or os.time())
				local v104 = v_u_67
				local v105 = p94.upToDate
				local v106 = tonumber(v105) or 0
				local v107 = p94.online
				v104.Text = ("Up to date on this server: %d of %d player%s"):format(v106, tonumber(v107) or 0, p94.online == 1 and "" or "s")
				local v108 = p94.key
				local v109 = type(v108) ~= "table" and {
					["state"] = "unknown",
					["text"] = "not checked yet"
				} or p94.key
				v_u_69.Text = "Read key: " .. (v109.state == "ok" and "ok" or (v109.state == "missing" and "missing" or (v109.state == "rejected" and "rejected" or (v109.state == "error" and "error" or "not checked"))))
				local v110 = v_u_69
				local v111
				if v109.state == "ok" then
					v111 = v_u_5.success
				elseif v109.state == "unknown" then
					v111 = v_u_5.text2
				else
					v111 = v_u_5.danger
				end
				v110.TextColor3 = v111
				local v112 = v_u_72
				local v113 = v109.text or ""
				v112.Text = tostring(v113)
				local v114 = v_u_72
				local v115
				if v109.state == "ok" or v109.state == "unknown" then
					v115 = false
				else
					local v116 = v109.text or ""
					v115 = tostring(v116) ~= ""
				end
				v114.Visible = v115
				if p94.fake == true then
					v_u_59.Text = "Test game  \194\183  FAKE Open Cloud (Studio)"
				else
					v_u_59.Text = "Test game"
				end
				local v117 = v_u_7
				local v118 = v96.n
				local v119 = tonumber(v118) or 0
				local v120 = p94.upToDate
				local v121 = tonumber(v120) or 0
				local v122 = p94.online
				local v123 = tonumber(v122) or 0
				local v124 = v109.state
				v117:SetAttribute("FilmTest", ("%d|%d|%d|%s"):format(v119, v121, v123, (tostring(v124))))
				v_u_83()
				return
			end
		end
	end
	local v126 = p_u_37.inner
	local function v135()
		-- upvalues: (ref) v_u_55, (copy) v_u_56, (copy) v_u_93, (ref) v_u_76, (ref) v_u_75, (copy) v_u_74, (ref) v_u_7, (copy) v_u_82, (copy) v_u_39, (copy) v_u_125
		if v_u_55 then
			return
		else
			local v127 = v_u_56.all
			local v128
			if v127 == nil then
				v128 = false
			else
				v128 = os.clock() - v127 < 5
			end
			if v128 then
				local v129 = v_u_76
				local v130 = v_u_75
				v_u_56.all = nil
				v129.setText("Refresh live copies")
				local v131 = v130:FindFirstChild("ConfirmStroke")
				if v131 then
					v131:Destroy()
				end
				v_u_74.Text = ""
				v_u_74.Visible = false
				v_u_7:SetAttribute("FilmTestError", "")
				v_u_82(true)
				v_u_39.call("livecopy.bump", {
					["confirm"] = true
				}, function(p132)
					-- upvalues: (ref) v_u_82, (ref) v_u_125, (ref) v_u_74, (ref) v_u_7
					v_u_82(false)
					if p132 and p132.ok then
						v_u_125(p132.data)
					else
						local v133 = p132 and p132.msg or "The server did not answer."
						local v134 = tostring(v133) or ""
						v_u_74.Text = v134
						v_u_74.Visible = v134 ~= ""
						v_u_7:SetAttribute("FilmTestError", v134)
					end
				end)
			else
				v_u_93("all", v_u_76, "Refresh live copies", "Click again to confirm", v_u_75)
			end
		end
	end
	local v136, v137 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Refresh live copies",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_38,
		["width"] = v126,
		["onClick"] = v135,
		["maxTextWidth"] = (v126 or 160) - 12
	})
	v_u_75 = v136
	v_u_76 = v137
	v_u_75.Name = "TestRefreshAll"
	v_u_41 = v_u_41 + 1
	v_u_75.LayoutOrder = v_u_41
	local v138 = v_u_76
	table.insert(v79, v138)
	v70.Activated:Connect(function()
		-- upvalues: (ref) v_u_55, (copy) v_u_74, (ref) v_u_7, (copy) v_u_82, (copy) v_u_39, (copy) v_u_125
		if not v_u_55 then
			v_u_74.Text = ""
			v_u_74.Visible = false
			v_u_7:SetAttribute("FilmTestError", "")
			v_u_82(true)
			v_u_39.call("livecopy.checkkey", {}, function(p139)
				-- upvalues: (ref) v_u_82, (ref) v_u_125, (ref) v_u_74, (ref) v_u_7
				v_u_82(false)
				if p139 then
					local v140 = p139.data
					if type(v140) == "table" then
						v_u_125(p139.data)
						return
					end
				end
				if p139 and not p139.ok then
					local v141 = p139.msg or "The server did not answer."
					local v142 = tostring(v141) or ""
					v_u_74.Text = v142
					v_u_74.Visible = v142 ~= ""
					v_u_7:SetAttribute("FilmTestError", v142)
				end
			end)
		end
	end)
	v44("Copy now (one player)")
	v48("Marks the selected player: he is sent back to the join screen and gets a fresh copy of his live save when he rejoins. In a raid he is only marked.")
	local v_u_143 = v_u_3.new("Frame", {
		["Name"] = "TestPlayers",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_38)
	v_u_3.layout(v_u_143, "v", 4)
	v_u_41 = v_u_41 + 1
	v_u_143.LayoutOrder = v_u_41
	local v_u_144 = v_u_3.label({
		["parent"] = nil,
		["name"] = "TestNoPlayers",
		["text"] = "No players yet.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_143,
		["color"] = v_u_5.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_144.LayoutOrder = 0
	local v_u_145 = {}
	local v_u_146 = ""
	local function v_u_159() -- name: paintRows
		-- upvalues: (copy) v_u_145, (ref) v_u_54, (ref) v_u_5, (ref) v_u_78, (ref) v_u_53, (ref) v_u_55, (ref) v_u_7
		for v147, v148 in v_u_145 do
			local v149 = v147 == v_u_54
			local v150 = v148.btn
			local v151
			if v149 then
				v151 = v_u_5.accentDeep
			else
				v151 = v_u_5.raised
			end
			v150.BackgroundColor3 = v151
			local v152 = v148.stroke
			local v153
			if v149 then
				v153 = v_u_5.accent
			else
				v153 = v_u_5.line
			end
			v152.Color = v153
		end
		if v_u_78 then
			local v154 = "a player"
			if v_u_53 and v_u_54 then
				for _, v155 in v_u_53.players do
					if v155.userId ~= v_u_54 then
						continue
					end
					local v156 = v155.displayName or v155.name
					v154 = tostring(v156)
				end
			end
			v_u_78.setText(not v_u_54 and "Copy now" or "Copy now: " .. v154)
			local v157 = v_u_78.setEnabled
			local v158
			if v_u_54 == nil then
				v158 = false
			else
				v158 = not v_u_55
			end
			v157(v158)
		end
		v_u_7:SetAttribute("FilmTestSelected", v_u_54)
	end
	v_u_83 = function(p160)
		-- upvalues: (ref) v_u_53, (ref) v_u_54, (copy) v_u_56, (ref) v_u_6, (ref) v_u_146, (copy) v_u_145, (copy) v_u_144, (ref) v_u_3, (ref) v_u_5, (copy) v_u_143, (ref) v_u_7, (ref) v_u_4, (copy) v_u_159, (copy) v_u_38
		local v161
		if v_u_53 then
			local v162 = v_u_53.players
			v161 = type(v162) ~= "table" and {} or v_u_53.players
		else
			v161 = {}
		end
		local v163 = {}
		local v164 = v_u_54
		local v165 = tostring(v164)
		local v166 = v_u_56.copy
		local v167
		if v166 == nil then
			v167 = false
		else
			v167 = os.clock() - v166 < 5
		end
		__set_list(v163, 1, {v165, (tostring(v167))})
		for _, v168 in v161 do
			local v169 = v_u_6.playerState(v168)
			local v170 = v168.userId
			local v171 = tostring(v170)
			local v172 = v168.name
			local v173 = tostring(v172)
			table.insert(v163, ("%s:%s:%s"):format(v171, v173, v169))
		end
		local v174
		if v_u_53 then
			local v175 = v_u_53.results
			v174 = type(v175) ~= "table" and {} or v_u_53.results
		else
			v174 = {}
		end
		for _, v176 in v174 do
			local v177 = v176.name
			local v178 = tostring(v177)
			local v179 = v176.status
			local v180 = tostring(v179)
			local v181 = v176.seconds
			local v182 = tostring(v181)
			local v183 = v176.at
			local v184 = tostring(v183)
			table.insert(v163, ("%s:%s:%s:%s"):format(v178, v180, v182, v184))
		end
		local v185
		if v_u_53 then
			local v186 = v_u_53.now
			v185 = tonumber(v186) or 0
		else
			v185 = 0
		end
		local v187 = v185 // 30
		local v188 = tostring(v187)
		table.insert(v163, v188)
		local v189 = table.concat(v163, "|")
		if v189 ~= v_u_146 or p160 == true then
			v_u_146 = v189
			for _, v190 in v_u_145 do
				v190.btn:Destroy()
			end
			table.clear(v_u_145)
			v_u_144.Visible = #v161 == 0
			local v191 = false
			for v192, v193 in v161 do
				local v194 = v193.userId
				local v_u_195 = tonumber(v194) or 0
				v191 = v_u_195 == v_u_54 and true or v191
				local v196 = v_u_3.new("TextButton", {
					["Name"] = nil,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "TestPlayer_" .. v_u_195,
					["BackgroundColor3"] = v_u_5.raised,
					["Size"] = UDim2.new(1, 0, 0, 40),
					["LayoutOrder"] = v192
				}, v_u_143)
				local v197 = v_u_3.stroke(v196, v_u_5.line)
				local v198 = v_u_3.label
				local v199 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v196
				}
				local v200 = v193.displayName or v193.name
				v199.text = tostring(v200) .. (v_u_195 == v_u_7.UserId and "  (you)" or "")
				v199.position = UDim2.fromOffset(10, 2)
				v199.size = UDim2.new(1, -190, 0, 20)
				v198(v199).TextTruncate = Enum.TextTruncate.AtEnd
				local v201 = v_u_3.label
				local v202 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v196
				}
				local v203 = v193.name
				v202.text = "@" .. tostring(v203) .. (v193.place == "Raid" and "  \194\183  in a raid" or "")
				v202.color = v_u_5.muted
				v202.position = UDim2.fromOffset(10, 21)
				v202.size = UDim2.new(1, -190, 0, 16)
				v201(v202).TextTruncate = Enum.TextTruncate.AtEnd
				local v204, v205 = v_u_6.playerState(v193)
				local v206 = v_u_3.label({
					["parent"] = nil,
					["name"] = "Chip",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v196,
					["text"] = v204,
					["color"] = v_u_4.kindColor(v205),
					["position"] = UDim2.new(1, -10, 0, 0),
					["size"] = UDim2.new(0, 170, 1, 0)
				})
				v206.AnchorPoint = Vector2.new(1, 0)
				v206.TextTruncate = Enum.TextTruncate.AtEnd
				v196.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_3, (ref) v_u_4
					v_u_3.sound(v_u_4.sounds.hover)
				end)
				v196.Activated:Connect(function()
					-- upvalues: (ref) v_u_54, (copy) v_u_195, (ref) v_u_56, (ref) v_u_3, (ref) v_u_4, (ref) v_u_159
					v_u_54 = v_u_195
					v_u_56.copy = nil
					v_u_3.sound(v_u_4.sounds.click)
					v_u_159()
				end)
				v_u_145[v_u_195] = {
					["btn"] = v196,
					["stroke"] = v197
				}
			end
			if not v191 then
				v_u_54 = nil
			end
			v_u_159()
			local v207 = v_u_38:FindFirstChild("TestResults")
			if v207 then
				for _, v208 in v207:GetChildren() do
					if not v208:IsA("GuiObject") or v208.Name == "TestNoResults" then
						continue
					end
					v208:Destroy()
				end
				local v209
				if v_u_53 then
					local v210 = v_u_53.results
					v209 = type(v210) ~= "table" and {} or v_u_53.results
				else
					v209 = {}
				end
				local v211 = v207:FindFirstChild("TestNoResults")
				if v211 and v211:IsA("GuiObject") then
					v211.Visible = #v209 == 0
				end
				for v212, v213 in v209 do
					local v214 = v_u_6.resultText
					local v215 = v_u_53.now
					local v216, v217 = v214(v213, tonumber(v215) or os.time())
					local v218 = v_u_3.label({
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["parent"] = v207,
						["name"] = "Result_" .. v212,
						["text"] = v216,
						["color"] = v_u_4.kindColor(v217),
						["size"] = UDim2.new(1, 0, 0, 18)
					})
					v218.TextTruncate = Enum.TextTruncate.AtEnd
					v218.LayoutOrder = v212
				end
			end
		end
	end
	local v219 = p_u_37.inner
	local function v230()
		-- upvalues: (ref) v_u_55, (ref) v_u_54, (copy) v_u_56, (copy) v_u_93, (ref) v_u_78, (ref) v_u_77, (copy) v_u_159, (copy) v_u_74, (ref) v_u_7, (copy) v_u_82, (copy) v_u_39, (copy) v_u_125
		if v_u_55 or v_u_54 == nil then
			return
		else
			local v220 = v_u_56.copy
			local v221
			if v220 == nil then
				v221 = false
			else
				v221 = os.clock() - v220 < 5
			end
			if v221 then
				local v222 = v_u_78
				local v223 = v_u_77
				v_u_56.copy = nil
				v222.setText("Copy now")
				local v224 = v223:FindFirstChild("ConfirmStroke")
				if v224 then
					v224:Destroy()
				end
				v_u_74.Text = ""
				v_u_74.Visible = false
				v_u_7:SetAttribute("FilmTestError", "")
				v_u_82(true)
				local v225 = {
					["userId"] = v_u_54
				}
				v_u_39.call("livecopy.copynow", v225, function(p226)
					-- upvalues: (ref) v_u_82, (ref) v_u_125, (ref) v_u_74, (ref) v_u_7, (ref) v_u_159
					v_u_82(false)
					if p226 and p226.ok then
						v_u_125(p226.data)
					else
						local v227 = p226 and (p226.msg or "The server did not answer.") or "The server did not answer."
						local v228 = tostring(v227) or ""
						v_u_74.Text = v228
						v_u_74.Visible = v228 ~= ""
						v_u_7:SetAttribute("FilmTestError", v228)
						if p226 then
							local v229 = p226.data
							if type(v229) == "table" then
								v_u_125(p226.data)
							end
						end
					end
					v_u_159()
				end)
			else
				v_u_93("copy", v_u_78, "Copy now", "Click again to confirm", v_u_77)
				v_u_159()
			end
		end
	end
	local v231, v232 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Copy now",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_38,
		["width"] = v219,
		["onClick"] = v230,
		["maxTextWidth"] = (v219 or 160) - 12
	})
	v_u_77 = v231
	v_u_78 = v232
	v_u_77.Name = "TestCopyNow"
	v_u_41 = v_u_41 + 1
	v_u_77.LayoutOrder = v_u_41
	local v233 = v_u_78
	table.insert(v79, v233)
	v_u_78.setEnabled(false)
	v44("Last copies on this server")
	local v234 = v_u_3.new("Frame", {
		["Name"] = "TestResults",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_38)
	v_u_3.layout(v234, "v", 2)
	v_u_41 = v_u_41 + 1
	v234.LayoutOrder = v_u_41
	v_u_3.label({
		["parent"] = nil,
		["name"] = "TestNoResults",
		["text"] = "No copy has run on this server yet.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v234,
		["color"] = v_u_5.muted,
		["size"] = UDim2.new(1, 0, 0, 20)
	}).LayoutOrder = 0
	v_u_57 = function(p_u_235)
		-- upvalues: (copy) v_u_125, (copy) v_u_74, (ref) v_u_7, (copy) v_u_39
		local function v239(p236) -- name: done
			-- upvalues: (ref) v_u_125, (copy) p_u_235, (ref) v_u_74, (ref) v_u_7
			if p236 and p236.ok then
				v_u_125(p236.data)
			elseif not p_u_235 then
				local v237 = p236 and p236.msg or "The server did not answer."
				local v238 = tostring(v237) or ""
				v_u_74.Text = v238
				v_u_74.Visible = v238 ~= ""
				v_u_7:SetAttribute("FilmTestError", v238)
			end
		end
		if p_u_235 then
			v_u_39.callQuiet("livecopy.status", {}, v239)
		else
			v_u_39.call("livecopy.status", {}, v239)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_40, (copy) p_u_37, (copy) v_u_38, (ref) v_u_57
		local v240 = false
		local v241 = 0
		while v_u_40 do
			local v242 = p_u_37.gui.Enabled
			if v242 then
				v242 = v_u_38.Visible
			end
			if v242 and (not v240 or os.clock() - v241 >= 5) then
				v241 = os.clock()
				v_u_57(true)
			end
			task.wait(0.3)
			v240 = v242
		end
	end)
	return {
		["refresh"] = function() -- name: refresh
			-- upvalues: (ref) v_u_57
			v_u_57(false)
		end,
		["summary"] = function() -- name: summary
			-- upvalues: (ref) v_u_53
			return v_u_53
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_54, (ref) v_u_55, (copy) v_u_145, (copy) v_u_74, (copy) v_u_69, (copy) v_u_66, (ref) v_u_53, (ref) v_u_2
			local v243 = {
				["selected"] = v_u_54,
				["busy"] = v_u_55
			}
			local v244 = 0
			for _ in v_u_145 do
				v244 = v244 + 1
			end
			v243.rows = v244
			v243.error = v_u_74.Text
			v243.key = v_u_69.Text
			v243.epoch = v_u_66.Text
			v243.json = not v_u_53 and "" or v_u_2:JSONEncode({ v_u_53.epoch, v_u_53.upToDate, v_u_53.online })
			return v243
		end
	}
end
return v_u_6