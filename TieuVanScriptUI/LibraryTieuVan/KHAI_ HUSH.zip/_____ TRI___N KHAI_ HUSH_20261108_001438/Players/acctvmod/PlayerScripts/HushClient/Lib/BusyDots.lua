-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / BusyDots

local v_u_56 = {
	["STEP"] = 0.4,
	["MAX"] = 3,
	["strip"] = function(p1) -- name: strip
		local v2 = type(p1) ~= "string" and "" or p1
		for _ = 1, 4 do
			local v3 = string.gsub(v2, "%s+$", "")
			local v4 = string.gsub(v3, "%.+$", "")
			if string.sub(v4, -3) == "\226\128\166" then
				local v5 = #v4 - 3
				v4 = string.sub(v4, 1, v5)
			end
			if v4 == v2 then
				v2 = v4
				break
			end
			v2 = v4
		end
		return v2
	end,
	["count"] = function(p6) -- name: count
		-- upvalues: (copy) v_u_56
		local v7 = 0
		if type(p6) == "number" and (p6 == p6 and p6 >= 0) then
			if p6 >= 1000000000 then
				p6 = v7
			end
		else
			p6 = v7
		end
		local v8 = p6 / v_u_56.STEP
		return math.floor(v8) % (v_u_56.MAX + 1)
	end,
	["escape"] = function(p9) -- name: escape
		local v10 = type(p9) ~= "string" and "" or p9
		local v11 = string.gsub(v10, "&", "&amp;")
		local v12 = string.gsub(v11, "<", "&lt;")
		return string.gsub(v12, ">", "&gt;")
	end,
	["split"] = function(p13) -- name: split
		-- upvalues: (copy) v_u_56
		local v14 = type(p13) ~= "string" and "" or p13
		local v15 = string.find(v14, "... ", 1, true)
		if v15 ~= nil then
			local v16 = v_u_56.strip
			local v17 = v15 - 1
			local v18 = v16((string.sub(v14, 1, v17)))
			local v19 = v15 + 3
			return v18, string.sub(v14, v19)
		end
		local v20 = string.find(v14, "\226\128\166 ", 1, true)
		if v20 == nil then
			return v_u_56.strip(v14), ""
		end
		local v21 = v_u_56.strip
		local v22 = v20 - 1
		local v23 = v21((string.sub(v14, 1, v22)))
		local v24 = v20 + 3
		return v23, string.sub(v14, v24)
	end,
	["plain"] = function(p25, p26) -- name: plain
		-- upvalues: (copy) v_u_56
		local v27 = type(p25) ~= "string" and "" or p25
		local v28 = string.rep
		local v29 = (type(p26) ~= "number" or p26 ~= p26) and 0 or math.floor(p26)
		local v30 = v_u_56.MAX
		return v27 .. v28(".", (math.clamp(v29, 0, v30)))
	end,
	["rich"] = function(p31, p32, p33, p34) -- name: rich
		-- upvalues: (copy) v_u_56
		local v35 = type(p31) ~= "string" and "" or p31
		local v36
		if p33 then
			local v37
			v37, v36 = pcall(p33, v35)
			if v37 then
				if type(v36) ~= "string" then
					v36 = v35
				end
			else
				v36 = v35
			end
		else
			v36 = v35
		end
		local v38 = (type(p32) ~= "number" or p32 ~= p32) and 0 or math.floor(p32)
		local v39 = v_u_56.MAX
		local v40 = math.clamp(v38, 0, v39)
		local v41 = v_u_56.escape(v36) .. string.rep(".", v40)
		local v42 = type(p34) ~= "string" and "" or v_u_56.escape(p34)
		if v_u_56.MAX <= v40 then
			return v41 .. v42
		else
			return v41 .. "<font transparency=\"1\">" .. string.rep(".", v_u_56.MAX - v40) .. "</font>" .. v42
		end
	end,
	["animate"] = function(p_u_43, p44, p45) -- name: animate
		-- upvalues: (copy) v_u_56
		local v_u_46 = p45 or {}
		local v_u_47 = type(p44) ~= "string" and "" or p44
		local v_u_48 = p_u_43.RichText
		local v_u_49 = false
		local v_u_50 = os.clock()
		local v_u_51 = -1
		p_u_43.RichText = true
		local v52 = v_u_56.count(os.clock() - v_u_50)
		if v52 ~= v_u_51 then
			v_u_51 = v52
			p_u_43.Text = v_u_56.rich(v_u_47, v52, v_u_46.transform, v_u_46.suffix)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_49, (copy) p_u_43, (ref) v_u_56, (copy) v_u_50, (ref) v_u_51, (copy) v_u_47, (copy) v_u_46
			while not v_u_49 and p_u_43.Parent ~= nil do
				local v53 = task.wait(v_u_56.STEP / 2)
				if type(v53) ~= "number" or (v53 <= 0 or v_u_49) then
					break
				end
				local v54 = v_u_56.count(os.clock() - v_u_50)
				if v54 == v_u_51 then
					continue
				end
				v_u_51 = v54
				p_u_43.Text = v_u_56.rich(v_u_47, v54, v_u_46.transform, v_u_46.suffix)
			end
		end)
		return function()
			-- upvalues: (ref) v_u_49, (copy) p_u_43, (copy) v_u_48
			if not v_u_49 then
				v_u_49 = true
				local function v55()
					-- upvalues: (ref) p_u_43, (ref) v_u_48
					p_u_43.RichText = v_u_48
				end
				pcall(v55)
			end
		end
	end
}
return v_u_56