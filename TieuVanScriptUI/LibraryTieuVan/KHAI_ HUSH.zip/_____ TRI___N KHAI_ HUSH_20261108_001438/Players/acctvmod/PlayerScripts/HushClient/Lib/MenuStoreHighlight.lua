-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreHighlight

local v_u_1 = {}
local v_u_2 = Color3.fromRGB(176, 138, 62)
local v_u_3 = Color3.fromRGB(255, 227, 163)
function v_u_1.spec(p4, p5) -- name: spec
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if type(p4) ~= "table" or p4.highlight ~= true then
		return nil
	end
	local v6 = p4.highlightBadge
	local v7 = (type(v6) ~= "string" or p4.highlightBadge == "") and "TOP PICK" or p4.highlightBadge
	return {
		["badge"] = nil,
		["badgeRect"] = nil,
		["stroke"] = 3,
		["barH"] = 4,
		["gold"] = nil,
		["light"] = nil,
		["cardW"] = nil,
		["badge"] = v7,
		["badgeRect"] = {
			["x"] = 10,
			["y"] = 30,
			["w"] = nil,
			["h"] = 16,
			["w"] = #v7 * 7 + 16
		},
		["gold"] = v_u_2,
		["light"] = v_u_3,
		["cardW"] = p5
	}
end
function v_u_1.layoutOrder(p8, p9) -- name: layoutOrder
	if type(p8) == "table" and p8.highlight == true then
		return p9 - 1000
	else
		return p9
	end
end
function v_u_1.apply(p10, p11, p12, p13, p14) -- name: apply
	-- upvalues: (copy) v_u_1
	local v15 = v_u_1.spec(p11, p12)
	if v15 == nil or (p10 == nil or p13 == nil) then
		return false
	end
	local v16
	if p14 == nil then
		v16 = nil
	else
		v16 = p14.color
	end
	local v17 = p13.new("Frame", {
		["Name"] = "HighlightFrame",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}, p10)
	local v18 = p10:FindFirstChildOfClass("UICorner")
	if v18 then
		p13.new("UICorner", {
			["CornerRadius"] = v18.CornerRadius
		}, v17)
	end
	local v19 = p13.stroke(v17, Color3.new(1, 1, 1), v15.stroke, 0)
	p13.new("UIGradient", {
		["Color"] = nil,
		["Rotation"] = 35,
		["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v15.gold), ColorSequenceKeypoint.new(0.5, v15.light), ColorSequenceKeypoint.new(1, v15.gold) })
	}, v19)
	p13.new("Frame", {
		["Name"] = "HighlightBar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 5,
		["BackgroundColor3"] = v15.gold,
		["Size"] = UDim2.new(1, 0, 0, v15.barH)
	}, p10)
	local v20 = p10:FindFirstChild("LimitedGlow")
	if v20 and (v16 ~= nil and v16.raised ~= nil) then
		v20.BackgroundColor3 = v15.gold:Lerp(v16.raised, 0.7)
	end
	local v21 = v15.badgeRect
	p13.badge(v15.badge, "accent", {
		["parent"] = nil,
		["name"] = "HighlightBadge",
		["position"] = nil,
		["height"] = nil,
		["zindex"] = 6,
		["parent"] = p10,
		["position"] = UDim2.fromOffset(v21.x, v21.y),
		["height"] = v21.h
	})
	return true
end
return v_u_1