-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / ReconnectGate

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v3 = {
	["name"] = "ReconnectGate",
	["order"] = 7
}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = 0
local v_u_14 = 0
local v_u_15 = 0
local v_u_16 = ""
local function v_u_18(p17) -- name: clock
	if p17 >= 3600 then
		return ("%d:%02d:%02d"):format(p17 // 3600, p17 % 3600 // 60, p17 % 60)
	else
		return ("%d:%02d"):format(p17 // 60, p17 % 60)
	end
end
local function v_u_37() -- name: build
	-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_6, (copy) v_u_9, (ref) v_u_4, (ref) v_u_12, (ref) v_u_14, (ref) v_u_11, (ref) v_u_10
	if not (v_u_8 and v_u_8.Parent) then
		local v19, v20 = v_u_5.screen("ReconnectGate", 2000, {
			["insets"] = "None"
		})
		v_u_8 = v19
		local v21 = v_u_5.new("TextButton", {
			["Name"] = "Backdrop",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Selectable"] = false,
			["Modal"] = true,
			["BackgroundColor3"] = Color3.new(0, 0, 0),
			["Size"] = UDim2.fromScale(1, 1)
		}, v20)
		local v22 = v_u_5.safeInsets()
		local v23 = v_u_6.refSize().X
		local v24 = v22.l
		local v25 = v22.r
		local v26 = v23 - math.max(v24, v25) * 2 - 32
		local v27 = math.min(760, v26)
		local v28 = v_u_6.refSize().Y < 480
		local v29 = v_u_5.new("Frame", {
			["Name"] = "Column",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(v27, v28 and 350 or 410)
		}, v21)
		v_u_5.layout(v29, "v", v28 and 8 or 14, "center")
		v_u_9.caps = v_u_5.label({
			["parent"] = nil,
			["text"] = "RAID IN PROGRESS",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["align"] = "center",
			["parent"] = v29,
			["color"] = v_u_6.color.accent,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v_u_9.title = v_u_5.label({
			["parent"] = nil,
			["text"] = "YOUR RAID IS STILL RUNNING",
			["style"] = "display",
			["size"] = nil,
			["align"] = "center",
			["fit"] = true,
			["parent"] = v29,
			["size"] = UDim2.new(1, 0, 0, v28 and 44 or 60)
		})
		v_u_9.body = v_u_5.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["size"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["parent"] = v29,
			["color"] = v_u_6.color.text2,
			["size"] = UDim2.new(1, 0, 0, v28 and 56 or 70)
		})
		v_u_9.timer = v_u_5.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoL",
			["color"] = nil,
			["size"] = nil,
			["align"] = "center",
			["parent"] = v29,
			["color"] = v_u_6.color.text,
			["size"] = UDim2.new(1, 0, 0, v28 and 28 or 36)
		})
		v_u_9.hint = v_u_5.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["parent"] = v29,
			["color"] = v_u_6.color.text2,
			["size"] = UDim2.new(1, 0, 0, v28 and 30 or 34)
		})
		local v30 = v_u_5.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 56)
		}, v29)
		v_u_5.layout(v30, "h", 16, "center")
		local v31 = {
			["parent"] = nil,
			["text"] = "RECONNECT",
			["kind"] = "primary",
			["width"] = 300,
			["height"] = 52,
			["onClick"] = nil,
			["parent"] = v30,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_4, (ref) v_u_12
				v_u_4.net.fire("ghost.op", {
					["op"] = v_u_12.state == "parked" and "continue" or "reconnect"
				})
			end
		}
		local v32, v33 = v_u_5.button(v31)
		local v34 = {
			["parent"] = nil,
			["text"] = "ABORT",
			["kind"] = "danger",
			["width"] = 240,
			["height"] = 52,
			["onClick"] = nil,
			["parent"] = v30,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_4
				if os.clock() - v_u_14 > 4 then
					v_u_14 = os.clock()
					if v_u_11 then
						v_u_11.api.setText("PRESS AGAIN TO ABORT")
					end
					task.delay(4.2, function()
						-- upvalues: (ref) v_u_11, (ref) v_u_14
						if v_u_11 and os.clock() - v_u_14 >= 4 then
							v_u_11.api.setText("ABORT")
						end
					end)
				else
					v_u_14 = 0
					v_u_4.net.fire("ghost.op", {
						["op"] = "abort"
					})
				end
			end
		}
		local v35, v36 = v_u_5.button(v34)
		v_u_10 = {
			["btn"] = v32,
			["api"] = v33
		}
		v_u_11 = {
			["btn"] = v35,
			["api"] = v36
		}
		v_u_9.note = v_u_5.label({
			["parent"] = nil,
			["text"] = "ABORT gives up the raid: everything you carried is lost. Your secure case stays safe.",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["parent"] = v29,
			["color"] = v_u_6.color.muted,
			["size"] = UDim2.new(1, 0, 0, v28 and 32 or 40)
		})
	end
end
local function v_u_65() -- name: render
	-- upvalues: (ref) v_u_8, (ref) v_u_12, (copy) v_u_7, (ref) v_u_13, (ref) v_u_4, (ref) v_u_16, (ref) v_u_15, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_18, (copy) v_u_2
	if v_u_8 and v_u_8.Parent then
		local v38 = v_u_12.state
		local v39 = v_u_12.name or v_u_7.DisplayName
		local v40 = tostring(v39)
		local v41 = v_u_12.expAt
		local v42 = tonumber(v41)
		local v43
		if v42 then
			local v44 = v42 - (os.time() + v_u_13)
			v43 = math.max(0, v44)
		else
			v43 = 0
		end
		local v45 = v38 == "parked"
		local function v46()
			-- upvalues: (ref) v_u_4
			return v_u_4.lib.MenuWhy
		end
		local v47, v48 = pcall(v46)
		if not v47 or type(v48) ~= "table" then
			v48 = nil
		end
		if tostring(v38) ~= v_u_16 then
			v_u_16 = tostring(v38)
			v_u_15 = os.clock()
		end
		local v49 = os.clock() - v_u_15
		local v50 = math.floor(v49)
		v_u_9.caps.Text = v45 and "RAID SAVED" or "RAID IN PROGRESS"
		local v51 = v_u_9.title
		local v52
		if v48 then
			v52 = v48.gateTitle(v38)
		else
			v52 = v45 and "YOUR RAID WAITS" or "YOUR RAID IS STILL RUNNING"
		end
		v51.Text = v52
		v_u_9.hint.Text = not v48 and "" or v48.gateHint(v38)
		v_u_10.api.setText(v45 and "CONTINUE" or "RECONNECT")
		v_u_9.note.Text = v45 and "ABORT gives up the saved raid: what you carried may be lost. Your secure case stays safe." or "ABORT gives up the raid: everything you carried is lost. Your secure case stays safe."
		if v38 == "checking" then
			v_u_9.body.Text = "Checking what became of your survivor ..."
			v_u_9.timer.Text = ""
			v_u_10.api.setEnabled(false)
			v_u_11.api.setEnabled(false)
		elseif v38 == "open" then
			v_u_9.body.Text = ("%s is still standing in the raid. Zombies can reach the body. Reconnect now, or give the raid up."):format(v40)
			local v53 = v_u_9.timer
			local v54
			if v48 then
				v54 = v48.gateTimer(v38, v43, v_u_18(v43))
			elseif v43 > 0 then
				local v55 = "YOUR SURVIVOR WAITS  "
				local v56
				if v43 >= 3600 then
					v56 = ("%d:%02d:%02d"):format(v43 // 3600, v43 % 3600 // 60, v43 % 60)
				else
					v56 = ("%d:%02d"):format(v43 // 60, v43 % 60)
				end
				v54 = v55 .. v56
			else
				v54 = "WAITING FOR THE RAID SERVER"
			end
			v53.Text = v54
			v_u_10.api.setEnabled(true)
			v_u_11.api.setEnabled(true)
		elseif v45 then
			v_u_9.body.Text = "The server closed, so your raid was saved exactly as it was: zombies, loot and doors. Press CONTINUE to go back in on a new server."
			local v57 = v_u_9.timer
			local v58
			if v48 then
				v58 = v48.gateTimer(v38, v43, v_u_18(v43))
			elseif v43 > 0 then
				local v59 = "SAVED FOR  "
				local v60
				if v43 >= 3600 then
					v60 = ("%d:%02d:%02d"):format(v43 // 3600, v43 % 3600 // 60, v43 % 60)
				else
					v60 = ("%d:%02d"):format(v43 // 60, v43 % 60)
				end
				v58 = v59 .. v60
			else
				v58 = "WAITING FOR THE SAVED RAID"
			end
			v57.Text = v58
			v_u_10.api.setEnabled(true)
			v_u_11.api.setEnabled(true)
		elseif v38 == "connecting" then
			v_u_9.body.Text = "Connecting to your raid ..."
			v_u_9.timer.Text = ""
			v_u_10.api.setEnabled(false)
			v_u_11.api.setEnabled(false)
		elseif v38 == "unknown" then
			v_u_9.body.Text = "The raid service cannot be reached right now. This screen retries on its own. You can also give the raid up."
			v_u_9.timer.Text = ""
			v_u_10.api.setEnabled(false)
			v_u_11.api.setEnabled(true)
		end
		if (v38 == "checking" or v38 == "connecting") and v48 then
			v_u_9.hint.Text = v48.gateStill(v50)
		end
		local v61 = v_u_12.msg
		if type(v61) == "string" and (v_u_12.msg ~= "" and v38 ~= "closed") then
			v_u_9.body.Text = v_u_12.msg
		end
		local v_u_62
		if v38 == "open" or v45 then
			v_u_62 = v_u_10.btn
		elseif v38 == "unknown" then
			v_u_62 = v_u_11.btn
		else
			v_u_62 = nil
		end
		local v63 = v_u_2.SelectedObject
		if v_u_62 and (v_u_8 and (v63 == nil or not v63:IsDescendantOf(v_u_8))) then
			local function v64()
				-- upvalues: (ref) v_u_2, (copy) v_u_62
				v_u_2.SelectedObject = v_u_62
			end
			pcall(v64)
		end
	end
end
local function v_u_71(p66) -- name: onState
	-- upvalues: (ref) v_u_13, (ref) v_u_12, (ref) v_u_8, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (copy) v_u_37, (copy) v_u_65
	if type(p66) == "table" then
		local v67 = p66.serverNow
		if type(v67) == "number" then
			v_u_13 = p66.serverNow - os.time()
		end
		if p66.state == "closed" then
			v_u_12 = {}
			local v68 = p66.msg
			if v_u_8 then
				v_u_8:Destroy()
				v_u_8 = nil
			end
			table.clear(v_u_9)
			v_u_10 = nil
			v_u_11 = nil
			if v68 and v68 ~= "" then
				v_u_5.toast(v68, "warn")
			end
		else
			for v69, v70 in p66 do
				v_u_12[v69] = v70
			end
			if p66.msg == nil then
				v_u_12.msg = nil
			end
			v_u_37()
			v_u_65()
		end
	else
		return
	end
end
function v3.init(p72) -- name: init
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (copy) v_u_71
	v_u_4 = p72
	v_u_5 = p72.lib.HushUI
	v_u_5.bind(p72)
	v_u_6 = v_u_5.Theme
	p72.net.listen("ghost.state", v_u_71)
end
function v3.start() -- name: start
	-- upvalues: (copy) v_u_7, (ref) v_u_4
	task.delay(4, function()
		-- upvalues: (ref) v_u_7, (ref) v_u_4
		if v_u_7:GetAttribute("ReconnectGate") ~= nil then
			v_u_4.net.fire("ghost.op", {
				["op"] = "state"
			})
		end
	end)
end
local v_u_73 = 0
function v3.step(p74) -- name: step
	-- upvalues: (ref) v_u_73, (ref) v_u_8, (ref) v_u_12, (copy) v_u_65
	v_u_73 = v_u_73 + p74
	if v_u_73 >= 0.5 then
		v_u_73 = 0
		if v_u_8 and (v_u_12.state == "open" or (v_u_12.state == "parked" or (v_u_12.state == "checking" or v_u_12.state == "connecting"))) then
			v_u_65()
		end
	end
end
return v3