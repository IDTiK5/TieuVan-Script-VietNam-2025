-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuFriendsJoin

local v_u_1 = game:GetService("RunService")
return {
	["new"] = function(p_u_2, p3, p4) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_5 = p_u_2.ui
		local v_u_6 = p_u_2.theme
		local v_u_7 = v_u_6.color
		local v_u_8 = type(p4) ~= "table" and {} or p4
		local v_u_9 = {
			["sent"] = {},
			["ov"] = {}
		}
		local v_u_10 = "FriendsJoinRules"
		local v11, v_u_12 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_10
			return p_u_2.cctx.shared[v_u_10]
		end)
		if not v11 or type(v_u_12) ~= "table" then
			v_u_12 = nil
		end
		local v_u_13 = "PvpveDoorRules"
		local v14, v_u_15 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_13
			return p_u_2.cctx.shared[v_u_13]
		end)
		if not v14 or type(v_u_15) ~= "table" then
			v_u_15 = nil
		end
		local v16, v_u_17 = pcall(function()
			return require((script.Parent:WaitForChild("FriendsJoinLayout", 5)))
		end)
		if v_u_12 == nil or (not v16 or type(v_u_17) ~= "table") then
			function v_u_9.repaint() end
			function v_u_9.destroy() end
			function v_u_9.press() end
			function v_u_9.feed() end
			function v_u_9.state()
				return "none"
			end
			return v_u_9
		end
		local v_u_18 = nil
		local function v19()
			-- upvalues: (ref) v_u_18
			v_u_18 = require((script.Parent:WaitForChild("MenuPvpveDoor", 5)))
		end
		pcall(v19)
		local v_u_20 = true
		local v_u_21 = {}
		local v_u_22 = nil
		local v_u_23 = {}
		local v_u_24 = ""
		local v_u_25 = nil
		local v_u_26 = "none"
		local v_u_27 = v_u_17.layout(0, {
			["state"] = "none"
		})
		local v_u_28 = {}
		local v_u_29 = v_u_12.TEXT
		local v_u_30 = v_u_5.new("Frame", {
			["Name"] = "FriendsElsewhere",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["LayoutOrder"] = v_u_8.order or 3
		}, p3)
		v_u_9.frame = v_u_30
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Heading",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_30,
			["text"] = v_u_29.heading,
			["color"] = v_u_7.accent,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.new(1, 0, 0, v_u_17.HEAD_H)
		})
		local v_u_31 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Message",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_30,
			["color"] = v_u_7.text2,
			["position"] = UDim2.fromOffset(0, v_u_17.HEAD_H + v_u_17.HEAD_GAP),
			["size"] = UDim2.new(1, 0, 0, v_u_17.MESSAGE_H)
		})
		v_u_31.Visible = false
		local function v_u_36() -- name: door
			-- upvalues: (copy) v_u_9, (ref) v_u_18, (copy) p_u_2, (copy) v_u_15, (copy) v_u_12
			if v_u_9.ov.door ~= nil then
				return v_u_9.ov.door
			end
			local v32
			if v_u_9.ov.facts == nil then
				if v_u_18 == nil then
					v32 = nil
				else
					local v33 = v_u_18.facts
					local v34 = p_u_2
					local v35
					v35, v32 = pcall(v33, v34, nil)
					if not v35 then
						v32 = nil
					end
				end
			else
				v32 = v_u_9.ov.facts
			end
			return (v32 == nil or v_u_15 == nil) and {
				["dest"] = nil,
				["open"] = true
			} or v_u_12.doorState(v_u_15, v32)
		end
		local function v_u_79(p37, p_u_38, p39) -- name: buildRow
			-- upvalues: (ref) v_u_27, (copy) v_u_12, (copy) v_u_21, (copy) v_u_17, (copy) v_u_5, (copy) v_u_7, (copy) v_u_30, (copy) v_u_23, (copy) v_u_29, (copy) v_u_9
			local v40 = v_u_27.rows[p37]
			local v_u_41 = v_u_12.rowState(p_u_38, p39)
			local v42 = v_u_21[p_u_38.userId]
			local v43
			if v42 == nil then
				v43 = false
			else
				v43 = os.clock() - v42 < v_u_12.JOIN_HOLD
			end
			local v44 = v_u_17.RIGHT + v_u_17.BTN_W
			local v45 = v44 + v_u_17.GAP + v_u_17.TAG_W + v_u_17.GAP
			local v46 = v_u_5.new
			local v47 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil
			}
			local v48 = p_u_38.userId
			v47.Name = "F" .. tostring(v48)
			v47.BackgroundColor3 = v_u_7.raised
			v47.Position = UDim2.fromOffset(0, v40.box.y)
			v47.Size = UDim2.new(1, -v_u_17.SCROLL, 0, v40.box.h)
			local v_u_49 = v46("Frame", v47, v_u_30)
			local v50 = v_u_5.stroke
			local v51
			if v_u_41.closed then
				v51 = v_u_7.line
			else
				v51 = v_u_7.accentDim
			end
			v50(v_u_49, v51)
			local v52 = v_u_23
			table.insert(v52, v_u_49)
			local v53 = v_u_5.label
			local v54 = {
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_49
			}
			local v55 = p_u_38.displayName or p_u_38.name
			v54.text = tostring(v55)
			v54.position = UDim2.fromOffset(v40.name.x, v40.name.y)
			v54.size = UDim2.new(1, -(v_u_17.PAD + v45), 0, v40.name.h)
			v53(v54).TextTruncate = Enum.TextTruncate.AtEnd
			local v56
			if v_u_41.tone == "danger" then
				v56 = v_u_7.danger
			else
				v56 = v_u_7.text2
			end
			v_u_5.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_49,
				["text"] = v_u_41.line,
				["color"] = v56,
				["position"] = UDim2.fromOffset(v40.sub.x, v40.sub.y),
				["size"] = UDim2.new(1, -(v_u_17.PAD + v45), 0, v40.sub.h)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			local v57 = p_u_38.lobby == "pvp"
			local v58 = v_u_5.new
			local v59 = "Frame"
			local v60 = {
				["Name"] = "Chip",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil
			}
			local v61
			if v57 then
				v61 = v_u_7.dangerDeep
			else
				v61 = v_u_7.accentDeep
			end
			v60.BackgroundColor3 = v61
			v60.Position = UDim2.new(1, -(v44 + v_u_17.GAP + v_u_17.TAG_W), 0, v40.chip.y)
			v60.Size = UDim2.fromOffset(v_u_17.TAG_W, v_u_17.TAG_H)
			local v62 = v58(v59, v60, v_u_49)
			local v63 = v_u_5.label
			local v64 = {
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["textSize"] = 11,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v62
			}
			local v65 = p_u_38.tag
			v64.text = tostring(v65)
			local v66
			if v57 then
				v66 = v_u_7.danger
			else
				v66 = v_u_7.accent
			end
			v64.color = v66
			v64.size = UDim2.fromScale(1, 1)
			v63(v64)
			local v67 = v_u_5.button
			local v68 = {
				["parent"] = nil,
				["name"] = "Join",
				["text"] = nil,
				["kind"] = "secondary",
				["size"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_49
			}
			local v69
			if v43 then
				v69 = v_u_29.joining
			else
				v69 = v_u_29.join
			end
			v68.text = v69
			v68.size = UDim2.fromOffset(v_u_17.BTN_W, v40.button.h)
			v68.position = UDim2.new(1, -v44, 0, v40.button.y)
			function v68.onClick() -- name: onClick
				-- upvalues: (ref) v_u_9, (copy) p_u_38
				v_u_9.press(p_u_38)
			end
			local v70, v71 = v67(v68)
			local v72 = v70:FindFirstChild("Inner")
			local v73
			if v72 then
				v73 = v72:FindFirstChildOfClass("UIPadding")
			else
				v73 = nil
			end
			if v73 then
				v73.PaddingLeft = UDim.new(0, 6)
				v73.PaddingRight = UDim.new(0, 6)
			end
			local v74 = v71.setEnabled
			local v75 = v_u_41.enabled
			if v75 then
				v75 = not v43
			end
			v74(v75)
			if not v_u_17.fits(v_u_41.line, 12, v40.sub.w) then
				local function v78()
					-- upvalues: (ref) v_u_5, (copy) v_u_49, (copy) p_u_38, (copy) v_u_41
					v_u_5.tooltip(v_u_49, function()
						-- upvalues: (ref) p_u_38, (ref) v_u_41
						local v76 = {}
						local v77 = p_u_38.displayName or p_u_38.name
						v76.title = tostring(v77)
						v76.body = v_u_41.line
						return v76
					end)
				end
				pcall(v78)
			end
		end
		function v_u_9.repaint(p80) -- name: repaint
			-- upvalues: (ref) v_u_20, (copy) v_u_30, (ref) v_u_25, (copy) v_u_36, (copy) v_u_12, (copy) v_u_21, (ref) v_u_24, (ref) v_u_26, (copy) v_u_6, (ref) v_u_27, (copy) v_u_17, (copy) v_u_8, (copy) v_u_23, (copy) v_u_31, (copy) v_u_5, (copy) v_u_29, (copy) v_u_79
			if v_u_20 and v_u_30.Parent ~= nil then
				v_u_25 = p80
				local v81
				if type(p80) == "table" then
					v81 = p80.friendsElsewhere
				else
					v81 = nil
				end
				local v82, v83
				if type(v81) == "table" and v81.off ~= true then
					local v84 = v81.rows
					v82 = type(v84) ~= "table" and {} or v81.rows
					if #v82 > 0 then
						v83 = "rows"
					elseif v81.loaded == true then
						v83 = "empty"
					else
						v83 = "loading"
					end
				else
					v83 = "none"
					v82 = {}
				end
				local v85 = v_u_36()
				local v86 = v83 .. "|"
				for _, v87 in v82 do
					local v88 = v_u_12.rowState(v87, v85)
					local v89 = "%d:%s:%s:%s:%s:%s;"
					local v90 = v87.userId
					local v91 = tonumber(v90) or 0
					local v92 = v87.displayName
					local v93 = tostring(v92)
					local v94 = v87.lobby
					local v95 = tostring(v94)
					local v96 = v87.other
					local v97 = tostring(v96)
					local v98 = v88.enabled
					local v99 = tostring(v98)
					local v100 = v_u_21[v87.userId]
					local v101
					if v100 == nil then
						v101 = false
					else
						v101 = os.clock() - v100 < v_u_12.JOIN_HOLD
					end
					local v102 = v99 .. tostring(v101)
					local v103 = v88.line
					v86 = v86 .. v89:format(v91, v93, v95, v97, v102, (tostring(v103)))
				end
				if v86 ~= v_u_24 then
					v_u_24 = v86
					v_u_26 = v83
					local v104 = v_u_6.refSize()
					v_u_27 = v_u_17.layout(v_u_8.width or 500, {
						["state"] = v83,
						["n"] = #v82,
						["btnH"] = v_u_6.touch(32),
						["refY"] = v104.Y
					})
					for _, v105 in v_u_23 do
						v105:Destroy()
					end
					table.clear(v_u_23)
					v_u_30.Visible = v83 ~= "none"
					v_u_30.Size = UDim2.new(1, 0, 0, v_u_27.h)
					v_u_30.LayoutOrder = v_u_27.first == true and 0 or (v_u_8.order or 3)
					v_u_31.Visible = v_u_27.message ~= nil
					if v_u_27.message ~= nil then
						local v106 = v_u_5.setText
						local v107 = v_u_31
						local v108
						if v83 == "loading" then
							v108 = v_u_29.loading
						else
							v108 = v_u_29.empty
						end
						v106(v107, v108)
					end
					if v83 == "rows" then
						for v109, v110 in v82 do
							v_u_79(v109, v110, v85)
						end
					end
					if v_u_8.list ~= nil then
						v_u_8.list.Size = UDim2.new(1, 0, 0, v_u_27.listH)
					end
				end
			else
				return
			end
		end
		local function v_u_114(p111) -- name: go
			-- upvalues: (copy) v_u_21, (copy) v_u_9, (copy) p_u_2, (ref) v_u_24, (ref) v_u_25
			v_u_21[p111.userId] = os.clock()
			local v112 = v_u_9.sent
			local v113 = {
				["op"] = "friendJoin",
				["userId"] = nil,
				["userId"] = p111.userId
			}
			table.insert(v112, v113)
			p_u_2.op({
				["op"] = "friendJoin",
				["userId"] = nil,
				["userId"] = p111.userId
			})
			v_u_24 = ""
			if v_u_25 ~= nil then
				v_u_9.repaint(v_u_25)
			end
		end
		function v_u_9.press(p_u_115) -- name: press
			-- upvalues: (ref) v_u_20, (copy) v_u_21, (copy) v_u_12, (copy) v_u_36, (copy) p_u_2, (copy) v_u_9, (copy) v_u_114, (ref) v_u_22, (ref) v_u_18, (copy) v_u_5, (copy) v_u_29
			if v_u_20 and type(p_u_115) == "table" then
				local v116 = p_u_115.userId
				if type(v116) == "number" then
					local v117 = v_u_21[p_u_115.userId]
					local v118
					if v117 == nil then
						v118 = false
					else
						v118 = os.clock() - v117 < v_u_12.JOIN_HOLD
					end
					if not v118 then
						if v_u_12.rowState(p_u_115, v_u_36()).enabled then
							local v_u_119 = false
							local function v123()
								-- upvalues: (ref) p_u_2, (ref) v_u_119
								local v120 = p_u_2.myParty()
								local v121
								if type(v120) == "table" then
									local v122 = v120.members
									if type(v122) == "table" then
										v121 = #v120.members > 1
									else
										v121 = false
									end
								else
									v121 = false
								end
								v_u_119 = v121
							end
							pcall(v123)
							if v_u_9.ov.autoConfirm == true then
								v_u_114(p_u_115)
								return
							elseif v_u_22 == nil then
								local v124 = v_u_12.confirm
								local v125 = {
									["name"] = p_u_115.displayName or p_u_115.name
								}
								local v126
								if v_u_9.ov.from == nil then
									local v127
									if v_u_9.ov.facts == nil then
										if v_u_18 == nil then
											v127 = nil
										else
											local v128 = v_u_18.facts
											local v129 = p_u_2
											local v130
											v130, v127 = pcall(v128, v129, nil)
											if not v130 then
												v127 = nil
											end
										end
									else
										v127 = v_u_9.ov.facts
									end
									v126 = (v127 == nil or v127.dest ~= "pve") and "pve" or "pvp"
								else
									v126 = v_u_9.ov.from
								end
								v125.from = v126
								v125.to = p_u_115.lobby
								v125.inSquad = v_u_119
								local v131 = v124(v125)
								v_u_22 = v_u_5.modal({
									["title"] = nil,
									["body"] = nil,
									["width"] = 480,
									["buttons"] = nil,
									["onClose"] = nil,
									["title"] = v131.title,
									["body"] = v131.body,
									["buttons"] = {
										{
											["text"] = nil,
											["kind"] = "ghost",
											["text"] = v_u_29.confirmStay
										},
										{
											["text"] = nil,
											["kind"] = "primary",
											["onClick"] = nil,
											["text"] = v_u_29.confirmGo,
											["onClick"] = function() -- name: onClick
												-- upvalues: (ref) v_u_22, (ref) v_u_114, (copy) p_u_115
												v_u_22 = nil
												v_u_114(p_u_115)
											end
										}
									},
									["onClose"] = function() -- name: onClose
										-- upvalues: (ref) v_u_22
										v_u_22 = nil
									end
								})
							end
						else
							return
						end
					end
				end
			end
		end
		function v_u_9.feed(p132) -- name: feed
			-- upvalues: (copy) v_u_21, (ref) v_u_24, (ref) v_u_25, (copy) v_u_9
			if type(p132) == "table" and p132.op == "friendJoin" then
				if p132.ok == false then
					table.clear(v_u_21)
					v_u_24 = ""
					if v_u_25 ~= nil then
						v_u_9.repaint(v_u_25)
					end
				end
			end
		end
		if p_u_2.changed ~= nil then
			local v133 = p_u_2.changed
			table.insert(v_u_28, v133:Connect(function(p134, p135)
				-- upvalues: (copy) v_u_9
				if p134 == "result" then
					v_u_9.feed(p135)
				end
			end))
		end
		local v136 = v_u_1.Heartbeat
		local v_u_137 = 0
		local function v139(p138)
			-- upvalues: (ref) v_u_20, (ref) v_u_26, (ref) v_u_137, (copy) v_u_9, (ref) v_u_25
			if v_u_20 and v_u_26 == "rows" then
				v_u_137 = v_u_137 + p138
				if v_u_137 >= 1 then
					v_u_137 = 0
					v_u_9.repaint(v_u_25)
				end
			end
		end
		table.insert(v_u_28, v136:Connect(v139))
		function v_u_9.state() -- name: state
			-- upvalues: (ref) v_u_26
			return v_u_26
		end
		function v_u_9.layout() -- name: layout
			-- upvalues: (ref) v_u_27
			return v_u_27
		end
		function v_u_9.destroy() -- name: destroy
			-- upvalues: (ref) v_u_20, (copy) v_u_28, (copy) v_u_23, (ref) v_u_22, (copy) v_u_30
			v_u_20 = false
			for _, v140 in v_u_28 do
				v140:Disconnect()
			end
			table.clear(v_u_28)
			for _, v141 in v_u_23 do
				v141:Destroy()
			end
			table.clear(v_u_23)
			if v_u_22 ~= nil then
				local function v142()
					-- upvalues: (ref) v_u_22
					v_u_22.close()
				end
				pcall(v142)
				v_u_22 = nil
			end
			v_u_30:Destroy()
		end
		return v_u_9
	end
}