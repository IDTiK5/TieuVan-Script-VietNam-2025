-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuDirector

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("Workspace")
local v_u_3, v_u_4
if script == nil then
	v_u_3 = nil
	v_u_4 = nil
else
	v_u_3 = require(script.Parent.MenuShotMath)
	v_u_4 = require(script.Parent.MenuDirectorState)
end
local function v_u_7(p5, p6) -- name: vdist
	return (p5 - p6).Magnitude
end
local function v_u_9(p8) -- name: vanchor
	return p8.subject + (p8.pos - p8.subject) * 0.45 + Vector3.new(0, 2, 0)
end
local function v_u_13(p10, p11, p12) -- name: pose
	-- upvalues: (ref) v_u_3
	return v_u_3.frame(p10, p12) * v_u_3.drift(p11, p10.drift)
end
local function v_u_15(p14) -- name: originCF
	return CFrame.new(p14)
end
local function v_u_17(p16) -- name: focusCF
	if p16 == nil then
		return nil
	else
		return CFrame.new(p16)
	end
end
local v_u_18 = {}
v_u_18.__index = v_u_18
v_u_18.MAX_SETS = 3
v_u_18.SMOOTH = 6
function v_u_18._bind(p19) -- name: _bind
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_13, (ref) v_u_15, (ref) v_u_17
	if p19.sm then
		v_u_3 = p19.sm
	end
	if p19.state then
		v_u_4 = p19.state
	end
	if p19.dist then
		v_u_7 = p19.dist
	end
	if p19.anchor then
		v_u_9 = p19.anchor
	end
	if p19.pose then
		v_u_13 = p19.pose
	end
	if p19.origin then
		v_u_15 = p19.origin
	end
	if p19.focus then
		v_u_17 = p19.focus
	end
end
local v_u_20 = {
	"street",
	"character",
	"wide",
	"debrief",
	"intro",
	"hideout",
	"play"
}
function v_u_18.streetDef(p_u_21) -- name: streetDef
	-- upvalues: (copy) v_u_20
	return {
		["id"] = "street",
		["kind"] = "set",
		["slot"] = 0,
		["keep"] = true,
		["build"] = nil,
		["onGo"] = nil,
		["build"] = function(_, _, _) -- name: build
			-- upvalues: (copy) p_u_21, (ref) v_u_20
			p_u_21.externalCamera = true
			local v22 = {}
			for _, v_u_23 in v_u_20 do
				v22[v_u_23] = function(p24)
					-- upvalues: (ref) p_u_21, (copy) v_u_23
					return p_u_21:shot(v_u_23, p24)
				end
			end
			return {
				["shots"] = nil,
				["atmo"] = "Menu",
				["destroy"] = nil,
				["shots"] = v22,
				["destroy"] = function() -- name: destroy
					-- upvalues: (ref) p_u_21
					p_u_21.externalCamera = false
				end
			}
		end,
		["onGo"] = function(p25) -- name: onGo
			-- upvalues: (copy) p_u_21
			local v26 = p_u_21.setShot
			if type(v26) == "function" then
				p_u_21:setShot(p25)
			end
		end
	}
end
function v_u_18.new(p27) -- name: new
	-- upvalues: (copy) v_u_18, (ref) v_u_4, (ref) v_u_3, (copy) v_u_2
	local v28 = v_u_18
	local v_u_29 = setmetatable({}, v28)
	v_u_29.cctx = p27.cctx
	v_u_29.base = p27.base
	v_u_29.legacy = p27.legacy
	v_u_29.getPlayer = p27.getPlayer
	v_u_29.getCamera = p27.getCamera
	v_u_29.defs = {}
	v_u_29.recs = {}
	v_u_29.state = v_u_4.new(v_u_3)
	v_u_29.clock = 0
	v_u_29.useN = 0
	v_u_29.destroyed = false
	v_u_29.lastShot = nil
	v_u_29.startShot = nil
	v_u_29.seq = -1
	v_u_29.camCF = nil
	v_u_29.fov = 40
	v_u_29.lastFocus = -1
	v_u_29.atmoNow = nil
	v_u_29.atmoSet = false
	v_u_29.readyDone = true
	v_u_29.phase = "idle"
	v_u_29.phaseT = 1
	v_u_29.camName = ""
	v_u_29.stageWas = false
	v_u_29.camModeTaken = false
	v_u_29.camModeOld = nil
	local v30 = v_u_29.cctx
	if v30 then
		v30 = v_u_29.cctx.shared
	end
	local v31 = {
		["cctx"] = v_u_29.cctx
	}
	local v32
	if v30 then
		v32 = v30.Assets
	else
		v32 = v30
	end
	v31.Assets = v32
	if v30 then
		v30 = v30.Theme
	end
	v31.Theme = v30
	v31.director = v_u_29
	v_u_29.env = v31
	local v33 = v_u_2:FindFirstChild("HushLocal")
	if not v33 then
		v33 = Instance.new("Folder")
		v33.Name = "HushLocal"
		v33.Parent = v_u_2
	end
	local v34 = v33:FindFirstChild("MenuSets")
	if v34 then
		v34:Destroy()
	end
	local v35 = Instance.new("Folder")
	v35.Name = "MenuSets"
	v35.Parent = v33
	v_u_29.setsRoot = v35
	pcall(function()
		-- upvalues: (copy) v_u_29
		local v36 = v_u_29.env.Theme
		local v37 = v_u_29.cctx.lib
		if v37 then
			v37 = v_u_29.cctx.lib.HushUI
		end
		if v37 and (v37.screen and v36) then
			local v38 = v37.screen("HushMenuFade", v36.layer.menu - 1, {
				["insets"] = "None"
			})
			local v39 = Instance.new("Frame")
			v39.Name = "Fade"
			v39.BackgroundColor3 = v36.color.bgDeep
			v39.BackgroundTransparency = 1
			v39.BorderSizePixel = 0
			v39.Size = UDim2.fromScale(1, 1)
			v39.Active = false
			v39.Visible = false
			v39.ZIndex = 1
			v39.Parent = v38
			v_u_29.fadeGui = v38
			v_u_29.fade = v39
		end
	end)
	if v_u_29.legacy then
		v_u_29:register(v_u_18.streetDef(v_u_29.legacy))
	end
	return v_u_29
end
function v_u_18._player(p40) -- name: _player
	-- upvalues: (copy) v_u_1
	if p40.getPlayer then
		return p40.getPlayer()
	else
		return v_u_1.LocalPlayer
	end
end
function v_u_18._cam(p41) -- name: _cam
	-- upvalues: (copy) v_u_2
	if p41.getCamera then
		return p41.getCamera()
	else
		return v_u_2.CurrentCamera
	end
end
function v_u_18._setAttr(p42, p_u_43, p_u_44) -- name: _setAttr
	local v_u_45 = p42:_player()
	if v_u_45 then
		pcall(function()
			-- upvalues: (copy) v_u_45, (copy) p_u_43, (copy) p_u_44
			v_u_45:SetAttribute(p_u_43, p_u_44)
		end)
	end
end
function v_u_18._claimCamMode(p46) -- name: _claimCamMode
	local v47 = p46:_player()
	if v47 then
		local v48 = v47:GetAttribute("CamMode")
		if v48 ~= "menu" then
			p46.camModeTaken = true
			p46.camModeOld = v48
			p46:_setAttr("CamMode", "menu")
		end
	else
		return
	end
end
function v_u_18.register(p49, p50) -- name: register
	local v51
	if type(p50) == "table" then
		local v52 = p50.id
		if type(v52) == "string" then
			v51 = p50.id ~= ""
		else
			v51 = false
		end
	else
		v51 = false
	end
	assert(v51, "MenuDirector.register: def.id")
	local v53 = p50.kind == "set" and true or p50.kind == "vista"
	assert(v53, "MenuDirector.register: kind set or vista")
	local v54 = p50.build
	local v55 = type(v54) == "function"
	assert(v55, "MenuDirector.register: build")
	if p49.recs[p50.id] then
		warn("[MenuDirector] scene already built, register ignored:", p50.id)
	else
		p49.defs[p50.id] = p50
	end
end
function v_u_18._aspect(p56) -- name: _aspect
	local v57 = p56:_cam()
	return (not v57 or (v57.ViewportSize.X <= 2 or v57.ViewportSize.Y <= 2)) and 1.7777777777777777 or v57.ViewportSize.X / v57.ViewportSize.Y
end
function v_u_18._touch(p58, p59) -- name: _touch
	p58.useN = p58.useN + 1
	p59.used = p58.useN
end
function v_u_18._drop(p60, p61) -- name: _drop
	if p61.handle then
		local v62 = p61.handle.destroy
		if type(v62) == "function" then
			local v63 = p61.handle.destroy
			local v64, v65 = pcall(v63)
			if not v64 then
				warn("[MenuDirector] destroy", p61.id, v65)
			end
		end
	end
	if p61.root then
		p61.root:Destroy()
	end
	p60.recs[p61.id] = nil
end
function v_u_18._makeRoom(p66) -- name: _makeRoom
	-- upvalues: (ref) v_u_4, (copy) v_u_18
	local v67, _ = v_u_4.target(p66.state)
	for _ = 1, 8 do
		local v68 = 0
		local v69 = nil
		for _, v70 in p66.recs do
			if v70.def.kind ~= "set" or v70.def.keep then
				continue
			end
			v68 = v68 + 1
			if v70.id == v67 or (v70.id == p66.shown or v69 ~= nil and v70.used >= v69.used) then
				continue
			end
			v69 = v70
		end
		if v68 < v_u_18.MAX_SETS or v69 == nil then
			return
		end
		p66:_drop(v69)
	end
end
function v_u_18._ensure(p71, p72) -- name: _ensure
	-- upvalues: (ref) v_u_15, (ref) v_u_3
	local v73 = p71.recs[p72]
	if v73 then
		return v73
	end
	local v74 = p71.defs[p72]
	if not v74 then
		return nil
	end
	if v74.kind == "set" and not v74.keep then
		p71:_makeRoom()
	end
	local v75 = Instance.new("Folder")
	v75.Name = p72
	v75.Parent = p71.setsRoot
	local v76
	if v74.kind == "set" then
		v76 = v_u_15(v_u_3.slotOrigin(p71.base, v74.slot or 0))
	else
		v76 = CFrame.new()
	end
	local v77 = v74.build
	local v78 = p71.env
	local v79, v80 = pcall(v77, v78, v75, v76)
	if v79 and type(v80) == "table" then
		local v81 = v80.shots
		if type(v81) == "table" then
			local v82 = {
				["id"] = nil,
				["def"] = nil,
				["handle"] = nil,
				["root"] = nil,
				["used"] = 0,
				["id"] = p72,
				["def"] = v74,
				["handle"] = v80,
				["root"] = v75
			}
			p71.recs[p72] = v82
			p71:_touch(v82)
			return v82
		end
	end
	warn("[MenuDirector] build failed:", p72, v79 and "no handle with shots" or v80)
	v75:Destroy()
	return nil
end
function v_u_18._reduced(p_u_83) -- name: _reduced
	local v84, v85 = pcall(function()
		-- upvalues: (copy) p_u_83
		return p_u_83.env.Theme.reduced()
	end)
	if v84 then
		v84 = v85 == true
	end
	return v84
end
function v_u_18.go(p86, p87, p88, p89) -- name: go
	-- upvalues: (ref) v_u_7, (ref) v_u_4
	if p86.destroyed then
		return false
	end
	local v90 = p89 or {}
	local v91 = p86:_ensure(p87)
	if not v91 then
		warn("[MenuDirector] unknown or unbuildable scene:", p87)
		return false
	end
	local v92 = p86:_aspect()
	local v93 = v91.handle.shots[p88]
	if type(v93) == "function" then
		local v94
		v94, v93 = pcall(v93, v92)
		if not v94 or type(v93) ~= "table" then
			v93 = nil
		end
	elseif type(v93) ~= "table" then
		v93 = nil
	end
	if not v93 then
		warn("[MenuDirector] unknown shot:", p87, p88)
		return false
	end
	local v95 = v91.def.onGo
	if type(v95) == "function" then
		local v96 = v91.def.onGo
		local v97, v98 = pcall(v96, p88)
		if not v97 then
			warn("[MenuDirector] onGo", p87, v98)
		end
	end
	p86:_touch(v91)
	local v99
	if p86.lastShot and (p86.lastShot.pos and v93.pos) then
		v99 = v_u_7(p86.lastShot.pos, v93.pos)
	else
		v99 = nil
	end
	if v_u_4.request(p86.state, p87, p88, v91.def.kind, p86.clock, p86:_reduced(), {
		["dist"] = v99,
		["cut"] = v90.cut == true,
		["instant"] = v90.instant == true
	}) then
		p86.readyDone = false
		p86:_checkReady()
		if v90.instant == true then
			local v100 = p86._frame
			local v101, v102 = pcall(v100, p86, 0)
			if not (v101 or p86.frameWarned) then
				p86.frameWarned = true
				warn("[MenuDirector] frame:", v102)
			end
		end
	end
	return true
end
function v_u_18.current(p103) -- name: current
	-- upvalues: (ref) v_u_4
	return v_u_4.target(p103.state)
end
function v_u_18.busy(p104) -- name: busy
	-- upvalues: (ref) v_u_4
	return v_u_4.busy(p104.state, p104.clock)
end
function v_u_18.progress(p105) -- name: progress
	return p105.phase, p105.phaseT
end
function v_u_18.handle(p106, p107) -- name: handle
	local v108 = p106.recs[p107]
	if v108 then
		return v108.handle
	else
		return nil
	end
end
function v_u_18._checkReady(p109) -- name: _checkReady
	-- upvalues: (ref) v_u_4
	if not p109.readyDone then
		local v110, _ = v_u_4.target(p109.state)
		local v111
		if v110 then
			v111 = p109.recs[v110]
		else
			v111 = nil
		end
		local v112 = true
		if v111 then
			local v113 = v111.handle.ready
			if type(v113) == "function" then
				local v114 = v111.handle.ready
				local v115, v116 = pcall(v114)
				v112 = not v115 or v116 == true
			end
		end
		if v112 then
			p109.readyDone = true
			v_u_4.setReady(p109.state, p109.clock)
		end
	end
end
function v_u_18._setFade(p117, p118) -- name: _setFade
	local v119 = p117.fade
	if v119 then
		v119.BackgroundTransparency = 1 - math.clamp(p118, 0, 1)
		v119.Visible = p118 > 0.002
	end
end
function v_u_18._applyAtmo(p120, p121, p122) -- name: _applyAtmo
	p120.atmoNow = p121
	local v123
	if p121 == "World" and p122 then
		v123 = p122.handle.atmoTime
	else
		v123 = nil
	end
	p120.atmoTimeNow = v123
	local v124 = p120.cctx and p120.cctx.controllers
	if v124 then
		v124 = p120.cctx.controllers.Atmosphere
	end
	if v124 then
		if type(v123) == "string" and v124.setOverride then
			local v125 = v124.setOverride
			pcall(v125, "Raid", v123, nil, 1.2)
			p120.atmoSet = true
		elseif p120.atmoSet then
			p120.atmoSet = false
			if v124.clearOverride then
				local v126 = v124.clearOverride
				pcall(v126, 1.2)
			end
		end
	else
		return
	end
end
function v_u_18._frame(p_u_127, p128) -- name: _frame
	-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (copy) v_u_18, (ref) v_u_17, (ref) v_u_7, (ref) v_u_9
	local v129 = p_u_127:_cam()
	if not v129 then
		return
	end
	if v_u_4.target(p_u_127.state) == nil then
		return
	end
	local v130 = p_u_127.clock
	p_u_127:_checkReady()
	local v_u_131 = v_u_4.step(p_u_127.state, v130)
	local v132 = p_u_127:_aspect()
	local v133 = p_u_127.recs[v_u_131.to.scene]
	local v134 = p_u_127.recs[v_u_131.from.scene]
	if not v133 then
		return
	end
	if v_u_131.seq ~= p_u_127.seq then
		p_u_127.seq = v_u_131.seq
		p_u_127.startShot = p_u_127.lastShot
	end
	local v135 = v_u_131.phase
	local v136
	if v135 == "glide" then
		local v137 = p_u_127.startShot
		if v137 then
			v134 = v137
		elseif v134 then
			local v138 = v_u_131.from.shot
			v134 = v134.handle.shots[v138]
			if type(v134) == "function" then
				local v139
				v139, v134 = pcall(v134, v132)
				if not v139 or type(v134) ~= "table" then
					v134 = nil
				end
			elseif type(v134) ~= "table" then
				v134 = nil
			end
		end
		local v140 = v_u_131.to.shot
		local v141 = v133.handle.shots[v140]
		if type(v141) == "function" then
			local v142
			v142, v141 = pcall(v141, v132)
			if not v142 or type(v141) ~= "table" then
				v141 = nil
			end
		elseif type(v141) ~= "table" then
			v141 = nil
		end
		if v134 and v141 then
			v136 = v_u_3.blend(v134, v141, v_u_131.t, "cubicInOut", v_u_3.lift(v134, v141))
		else
			v136 = v141 or v134
		end
	elseif v135 == "fadeOut" then
		v136 = p_u_127.startShot
		if not v136 then
			local v143, v144
			if v134 then
				local v145 = v_u_131.from.shot
				v136 = v134.handle.shots[v145]
				if type(v136) == "function" then
					local v146
					v146, v136 = pcall(v136, v132)
					if not v146 or type(v136) ~= "table" then
						v136 = nil
					end
				elseif type(v136) ~= "table" then
					v136 = nil
				end
				if not v136 then
					v143 = v_u_131.to.shot
					v136 = v133.handle.shots[v143]
					if type(v136) == "function" then
						v144, v136 = pcall(v136, v132)
						if not v144 or type(v136) ~= "table" then
							v136 = nil
						end
					elseif type(v136) ~= "table" then
						v136 = nil
					end
				end
			else
				v143 = v_u_131.to.shot
				v136 = v133.handle.shots[v143]
				if type(v136) == "function" then
					v144, v136 = pcall(v136, v132)
					if not v144 or type(v136) ~= "table" then
						v136 = nil
					end
				elseif type(v136) ~= "table" then
					v136 = nil
				end
			end
		end
	else
		local v147 = v_u_131.to.shot
		v136 = v133.handle.shots[v147]
		if type(v136) == "function" then
			local v148
			v148, v136 = pcall(v136, v132)
			if not v148 or type(v136) ~= "table" then
				v136 = nil
			end
		elseif type(v136) ~= "table" then
			v136 = nil
		end
	end
	local v149 = v136 or p_u_127.lastShot
	if v149 then
		p_u_127.lastShot = v149
		p_u_127.phase = v135
		p_u_127.phaseT = v_u_131.t
		local v150
		if v135 == "fadeOut" and p_u_127.atmoNow then
			v150 = p_u_127.atmoNow
		else
			v150 = v133.handle.atmo or "Menu"
		end
		if v150 ~= p_u_127.atmoNow or v150 == "World" and (v135 ~= "fadeOut" and v133.handle.atmoTime ~= p_u_127.atmoTimeNow) then
			p_u_127:_applyAtmo(v150, v133)
		end
		local v151 = v_u_13(v149, v130, v132)
		if v135 == "idle" and (p_u_127.camCF and p128 > 0) then
			local v152 = -p128 * v_u_18.SMOOTH
			local v153 = 1 - math.exp(v152)
			p_u_127.camCF = p_u_127.camCF:Lerp(v151, v153)
			local v154 = p_u_127.fov
			p_u_127.fov = v154 + (v149.fov - v154) * v153
		else
			p_u_127.camCF = v151
			p_u_127.fov = v149.fov
		end
		if v129.CameraType ~= Enum.CameraType.Scriptable then
			v129.CameraType = Enum.CameraType.Scriptable
			v129.CameraSubject = nil
		end
		v129.CFrame = p_u_127.camCF
		v129.FieldOfView = p_u_127.fov
		local v155 = v_u_17(v149.subject)
		if v155 ~= nil then
			v129.Focus = v155
		end
		p_u_127:_claimCamMode()
		local v156
		if v149.subject == nil then
			v156 = p_u_127.lastFocus
		else
			v156 = v_u_7(v149.subject, v149.pos)
		end
		if v149.subject ~= nil then
			local v157 = v156 - p_u_127.lastFocus
			if math.abs(v157) > 0.75 then
				p_u_127.lastFocus = v156
				local v158 = p_u_127.cctx and p_u_127.cctx.controllers
				if v158 then
					v158 = p_u_127.cctx.controllers.Atmosphere
				end
				if v158 and v158.setFocus then
					local v159 = v158.setFocus
					local v160 = v156 * 0.4
					local v161 = math.clamp(v160, 5, 30)
					pcall(v159, v156, v161)
				end
				if v158 and v158.setFxAnchor then
					local v162 = v158.setFxAnchor
					local v163 = v_u_9
					pcall(v162, v163(v149))
				end
			end
		end
		p_u_127:_setFade(v_u_131.alpha)
		if v_u_131.cam ~= p_u_127.camName then
			p_u_127.camName = v_u_131.cam
			p_u_127:_setAttr("MenuCam", v_u_131.cam)
		end
		if v_u_131.arrived then
			p_u_127.shown = v_u_131.to.scene
			p_u_127:_touch(v133)
			p_u_127:_setAttr("MenuScene", v_u_131.to.scene)
			p_u_127:_setAttr("MenuShot", v_u_131.to.shot)
			pcall(function()
				-- upvalues: (copy) p_u_127, (copy) v_u_131
				p_u_127.cctx.emit("menu.shot", v_u_131.to.scene, v_u_131.to.shot)
			end)
		end
	end
end
function v_u_18.step(p164, p165) -- name: step
	-- upvalues: (ref) v_u_4
	if p164.destroyed then
		return
	else
		p164.clock = p164.clock + p165
		local v166, _ = v_u_4.target(p164.state)
		local v167
		if v166 then
			v167 = p164.recs[v166]
		else
			v167 = nil
		end
		if v167 and v167.handle.step then
			local v168 = v167.handle.step
			local v169, v170 = pcall(v168, p165)
			if not v169 then
				warn("[MenuDirector] step", v167.id, v170)
			end
		end
		if p164.phase == "fadeOut" and (p164.shown and p164.shown ~= v166) then
			local v171 = p164.recs[p164.shown]
			if v171 and v171.handle.step then
				local v172 = v171.handle.step
				pcall(v172, p165)
			end
		end
		local v173 = p164:_player()
		if v173 and v173:GetAttribute("CrateStageOn") == true then
			p164.stageWas = true
			p164:_setFade(0)
		else
			if p164.stageWas then
				p164.stageWas = false
				p164.camCF = nil
			end
			local v174 = p164._frame
			local v175, v176 = pcall(v174, p164, p165)
			if not (v175 or p164.frameWarned) then
				p164.frameWarned = true
				warn("[MenuDirector] frame:", v176)
			end
		end
	end
end
function v_u_18.destroy(p177) -- name: destroy
	if not p177.destroyed then
		p177.destroyed = true
		if p177.legacy and p177.camCF then
			p177.legacy.camCF = p177.camCF
			p177.legacy.fov = p177.fov
		end
		if p177.legacy then
			p177.legacy.lastFocus = -1
		end
		local v178 = {}
		for v179 in p177.recs do
			table.insert(v178, v179)
		end
		for _, v180 in v178 do
			local v181 = p177.recs[v180]
			if not v181 then
				continue
			end
			p177:_drop(v181)
		end
		if p177.setsRoot then
			p177.setsRoot:Destroy()
			p177.setsRoot = nil
		end
		if p177.fadeGui then
			p177.fadeGui:Destroy()
			p177.fadeGui = nil
			p177.fade = nil
		end
		local v182 = p177.cctx and p177.cctx.controllers
		if v182 then
			v182 = p177.cctx.controllers.Atmosphere
		end
		if v182 then
			if p177.atmoSet and v182.clearOverride then
				local v183 = v182.clearOverride
				pcall(v183, 0.5)
			end
			if v182.setFocus then
				local v184 = v182.setFocus
				pcall(v184, nil)
			end
			if v182.setFxAnchor then
				local v185 = v182.setFxAnchor
				pcall(v185, nil)
			end
		end
		p177:_setAttr("MenuScene", nil)
		p177:_setAttr("MenuShot", nil)
		p177:_setAttr("MenuCam", nil)
		if p177.camModeTaken then
			p177.camModeTaken = false
			local v186 = p177:_player()
			if v186 and v186:GetAttribute("CamMode") == "menu" then
				p177:_setAttr("CamMode", p177.camModeOld)
			end
		end
	end
end
return v_u_18