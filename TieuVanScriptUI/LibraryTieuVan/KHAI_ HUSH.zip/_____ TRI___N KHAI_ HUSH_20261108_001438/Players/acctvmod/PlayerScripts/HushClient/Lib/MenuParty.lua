-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuParty

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
v_u_4.__index = v_u_4
local v_u_5 = v_u_2.LocalPlayer
local v6, v_u_7 = pcall(function()
	return require((script.Parent:WaitForChild("SquadsWhy", 5)))
end)
if not v6 or type(v_u_7) ~= "table" then
	warn("[MenuParty] lib missing: SquadsWhy")
	v_u_7 = {}
end
local v_u_8 = {
	{ "p", "Primary" },
	{ "s", "Sidearm" },
	{ "m", "Melee" },
	{ "v", "Armor" },
	{ "h", "Helmet" },
	{ "b", "Backpack" },
	{ "l", "Legs" },
	{ "f", "Boots" },
	{ "e", "Headset" }
}
local function v_u_16(p_u_9, p_u_10, p11) -- name: itemName
	local v13, v14 = pcall(function()
		-- upvalues: (copy) p_u_9, (copy) p_u_10
		local v12 = p_u_9
		if v12 then
			v12 = p_u_9.get(p_u_10)
		end
		return v12
	end)
	if v13 and type(v14) == "table" then
		local v15
		if p11 then
			v15 = v14.short or v14.name
		else
			v15 = v14.name
		end
		if type(v15) == "string" and v15 ~= "" then
			return v15
		end
	end
	return p_u_10
end
local function v_u_32(p17, p18) -- name: gearRows
	-- upvalues: (copy) v_u_8, (copy) v_u_16
	local v19
	if type(p17) == "table" then
		local v20 = p17.kit
		if type(v20) == "table" then
			v19 = p17.kit
		else
			v19 = nil
		end
	else
		v19 = nil
	end
	local v21 = {}
	local v22 = {}
	for _, v23 in v_u_8 do
		local v24
		if v19 then
			v24 = v19[v23[1]]
		else
			v24 = v19
		end
		local v25
		if type(v24) == "string" then
			v25 = string.upper((v_u_16(p18, v24, true)))
			local v26 = v19[v23[1] .. "a"]
			if type(v26) == "table" and #v26 > 0 then
				v25 = v25 .. " +" .. #v26
				local v27 = {}
				for _, v28 in v26 do
					if type(v28) ~= "string" then
						continue
					end
					local v29 = v_u_16(p18, v28, false)
					table.insert(v27, v29)
				end
				local v30 = v_u_16(p18, v24, true) .. ": " .. table.concat(v27, ", ")
				table.insert(v22, v30)
			end
		else
			v25 = "-"
		end
		local v31 = { v23[2], v25 }
		table.insert(v21, v31)
	end
	return v21, v22, v19 ~= nil
end
function v_u_4.gearContent(p33, p34) -- name: gearContent
	-- upvalues: (copy) v_u_32
	if type(p33) ~= "table" then
		return nil
	end
	local v35, v36, v37 = v_u_32(p33, p34)
	local v38 = {}
	for _, v39 in v35 do
		local v40 = {
			["label"] = v39[1],
			["value"] = v39[2]
		}
		table.insert(v38, v40)
	end
	local v41 = {}
	local v42 = string.upper
	local v43 = p33.displayName or (p33.name or "?")
	v41.title = v42((tostring(v43)))
	local v44
	if v37 then
		if #v36 > 0 then
			v44 = table.concat(v36, "\n")
		else
			v44 = nil
		end
	else
		v44 = "No gear equipped."
	end
	v41.body = v44
	v41.lines = v38
	return v41
end
function v_u_4.gearText(p45, p46) -- name: gearText
	-- upvalues: (copy) v_u_32
	local v47, v48, v49 = v_u_32(p45, p46)
	if not v49 then
		return "No gear equipped."
	end
	local v50 = {}
	for _, v51 in v47 do
		if v51[2] == "-" then
			continue
		end
		local v52 = v51[1] .. ": " .. v51[2]
		table.insert(v50, v52)
	end
	for _, v53 in v48 do
		table.insert(v50, v53)
	end
	return table.concat(v50, "\n")
end
function v_u_4.memberMayEnter(p_u_54, p55, p_u_56) -- name: memberMayEnter
	-- upvalues: (copy) v_u_2
	local v_u_57
	if type(p55) == "table" then
		local v58 = p55.settings
		if type(v58) == "table" then
			v_u_57 = p55.settings.mapId or nil
		else
			v_u_57 = nil
		end
	else
		v_u_57 = nil
	end
	if type(v_u_57) ~= "string" then
		return true
	end
	local function v66()
		-- upvalues: (copy) p_u_54, (copy) v_u_57, (ref) v_u_2, (copy) p_u_56
		local v59 = p_u_54.cctx.shared.Maps
		local v60 = v59.get(v_u_57)
		if v60 then
			local v61 = v60.gate
			if type(v61) == "string" then
				local v62 = v59.isOpenFor
				if type(v62) == "function" then
					local v63 = v_u_2
					local v64 = p_u_56.userId
					local v65 = v63:GetPlayerByUserId(tonumber(v64) or 0)
					return not v65 and true or v59.isOpenFor(v60, v65) == true
				end
			end
		end
		return true
	end
	local v67, v68 = pcall(v66)
	return not v67 or v68 ~= false
end
function v_u_4.memberRaids(p_u_69, p70, p_u_71) -- name: memberRaids
	-- upvalues: (copy) v_u_2
	local v_u_72
	if type(p70) == "table" then
		local v73 = p70.settings
		if type(v73) == "table" then
			v_u_72 = p70.settings.mapId or nil
		else
			v_u_72 = nil
		end
	else
		v_u_72 = nil
	end
	if type(v_u_72) == "string" then
		local function v80()
			-- upvalues: (copy) p_u_69, (ref) v_u_2, (copy) p_u_71, (copy) v_u_72
			local v74 = p_u_69.cctx.shared.Maps
			local v75 = v_u_2
			local v76 = p_u_71.userId
			local v77 = v75:GetPlayerByUserId(tonumber(v76) or 0)
			if v77 then
				local v78 = v74.accessFor
				if type(v78) == "function" then
					local v79 = v74.accessFor(v_u_72, v77)
					if v79 and (v79.ok ~= true and v79.why == "raids") then
						return v79.have, v79.need
					else
						return nil, nil
					end
				end
			end
			return nil, nil
		end
		local v81, v82, v83 = pcall(v80)
		if v81 then
			return v82, v83
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_4.memberQuest(p_u_84, p85, p_u_86) -- name: memberQuest
	-- upvalues: (copy) v_u_2
	local v_u_87
	if type(p85) == "table" then
		local v88 = p85.settings
		if type(v88) == "table" then
			v_u_87 = p85.settings.mapId or nil
		else
			v_u_87 = nil
		end
	else
		v_u_87 = nil
	end
	if type(v_u_87) == "string" then
		local function v96()
			-- upvalues: (copy) p_u_84, (ref) v_u_2, (copy) p_u_86, (copy) v_u_87
			local v89 = p_u_84.cctx.shared.Maps
			local v90 = p_u_84.cctx.shared.MapUnlock
			local v91 = v_u_2
			local v92 = p_u_86.userId
			local v93 = v91:GetPlayerByUserId(tonumber(v92) or 0)
			if v93 then
				local v94 = v89.accessFor
				if type(v94) == "function" and v90 then
					local v95 = v89.accessFor(v_u_87, v93)
					if v95 and (v95.ok ~= true and v95.why == "quest") then
						return v90.slotLabel(v95.missing)
					else
						return nil
					end
				end
			end
			return nil
		end
		local v97, v98 = pcall(v96)
		if v97 then
			return v98
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_4.memberDiff(p_u_99, p_u_100, p_u_101) -- name: memberDiff
	-- upvalues: (copy) v_u_2
	local function v102()
		-- upvalues: (copy) p_u_99, (copy) p_u_100, (copy) p_u_101, (ref) v_u_2
		return p_u_99.cctx.lib.PlayLadder.memberLack(p_u_99, p_u_100, p_u_101, v_u_2)
	end
	local v103, v104 = pcall(v102)
	if v103 and type(v104) == "string" then
		return v104
	else
		return nil
	end
end
function v_u_4.whereText(p105) -- name: whereText
	if type(p105) ~= "table" then
		return ""
	end
	local v106 = p105.where
	if type(v106) == "string" and p105.where ~= "" then
		return p105.where
	end
	local v107 = p105.place or "Menu"
	local v108 = tostring(v107)
	return v108 == "Raid" and "IN RAID" or (v108 == "Hideout" and "HIDEOUT" or (v108 == "Transit" and "TRAVELLING" or "MENU"))
end
function v_u_4.barPlan(p109, p110, p111) -- name: barPlan
	local v112 = p109 - p111 * 2 - 108 - 24
	local v113 = v112 * 0.34
	local v114 = math.floor(v113)
	local v115 = math.clamp(v114, 84, 128)
	local v116 = (v112 - v115) / 3
	local v117 = math.floor(v116)
	local v118 = math.clamp(v117, p111, 88)
	if v115 + v118 * 3 + 108 + p111 + p111 + 24 <= p110 then
		return {
			["slotW1"] = nil,
			["slotW"] = nil,
			["sqW"] = 108,
			["mic"] = true,
			["collapse"] = false,
			["slotW1"] = v115,
			["slotW"] = v118
		}
	end
	if v115 + v118 * 3 + 108 + 0 + p111 + 20 <= p110 then
		return {
			["slotW1"] = nil,
			["slotW"] = nil,
			["sqW"] = 108,
			["mic"] = false,
			["collapse"] = false,
			["slotW1"] = v115,
			["slotW"] = v118
		}
	end
	local v119 = (p110 - 108 - p111 - 20) / 4
	local v120 = math.floor(v119)
	local v121 = math.min(88, v120)
	if p111 <= v121 then
		return {
			["slotW1"] = nil,
			["slotW"] = nil,
			["sqW"] = 108,
			["mic"] = false,
			["collapse"] = false,
			["slotW1"] = v121,
			["slotW"] = v121
		}
	end
	local v122 = (p110 - p111 - p111 - 20) / 4
	local v123 = math.floor(v122)
	local v124 = math.min(88, v123)
	local v125 = math.max(p111, v124)
	return {
		["slotW1"] = nil,
		["slotW"] = nil,
		["sqW"] = 108,
		["mic"] = false,
		["collapse"] = true,
		["slotW1"] = v125,
		["slotW"] = v125
	}
end
function v_u_4.rowWidth(p126, p127, p128) -- name: rowWidth
	local v129 = p126.n or 4
	if p126.soloWords == true and not p128 then
		local v130 = p126.soloN or 2
		v129 = math.min(v129, v130)
	end
	local v131 = p126.slotW1 + (v129 - 1) * p126.slotW
	if p126.hideInParty ~= true or not p128 then
		local v132
		if p126.iconOnly == true or p126.collapse == true and p128 then
			v132 = p127
		else
			v132 = p126.sqW
		end
		v131 = v131 + v132
		v129 = v129 + 1
	end
	if p126.mic then
		v131 = v131 + p127
		v129 = v129 + 1
	end
	if p128 then
		v131 = v131 + p127
		v129 = v129 + 1
	end
	return v131 + (v129 - 1) * 4
end
function v_u_4.fitPlan(p133, p134, p135) -- name: fitPlan
	-- upvalues: (copy) v_u_4
	local v136 = tonumber(p133) or 0
	local v137 = math.floor(v136)
	local v138 = v_u_4.barPlan
	local v139 = v137 - 14
	local v140 = v138(math.max(260, v139), v137, p134)
	v140.n = 4
	if not v140.collapse then
		v140.fits = true
		return v140
	end
	local v141
	if type(p135) == "table" then
		v141 = p135.soloWords == true
	else
		v141 = false
	end
	for v142 = 4, 1, -1 do
		for _, v143 in v141 and v142 >= 3 and {
			"words",
			"solo",
			"icon",
			"none"
		} or { "words", "icon", "none" } do
			local v144 = {
				["n"] = nil,
				["slotW1"] = 0,
				["slotW"] = 0,
				["sqW"] = 108,
				["mic"] = false,
				["collapse"] = nil,
				["iconOnly"] = nil,
				["hideInParty"] = nil,
				["n"] = v142,
				["collapse"] = v143 == "words",
				["iconOnly"] = v143 == "icon" and true or v143 == "none",
				["hideInParty"] = v143 == "none" and true or v143 == "solo"
			}
			local v145
			if v143 == "solo" then
				v144.soloWords = true
				v144.soloN = 2
				local v146 = (v137 - v_u_4.rowWidth(v144, p134, false)) / 2
				local v147 = math.floor(v146)
				local v148 = (v137 - v_u_4.rowWidth(v144, p134, true)) / v142
				local v149 = math.floor(v148)
				v145 = math.min(v147, v149)
			else
				local v150 = v_u_4.rowWidth(v144, p134, false)
				local v151 = v_u_4.rowWidth
				local v152 = (v137 - math.max(v150, v151(v144, p134, true))) / v142
				v145 = math.floor(v152)
			end
			if p134 > v145 then
				continue
			end
			local v153 = math.min(v145, 88)
			v144.slotW1 = v153
			v144.slotW = v153
			v144.fits = true
			return v144
		end
	end
	return {
		["n"] = 1,
		["slotW1"] = nil,
		["slotW"] = nil,
		["sqW"] = 108,
		["mic"] = false,
		["collapse"] = false,
		["iconOnly"] = true,
		["hideInParty"] = true,
		["fits"] = false,
		["slotW1"] = p134,
		["slotW"] = p134
	}
end
function v_u_4.new(p_u_154, p155, p156, p157) -- name: new
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (copy) v_u_7, (copy) v_u_3
	local v158 = v_u_4
	local v_u_159 = setmetatable({}, v158)
	v_u_159.mc = p_u_154
	if v_u_5 == nil then
		v_u_5 = p_u_154.player
	end
	local v_u_160 = p_u_154.ui
	local v_u_161 = p_u_154.theme
	local v_u_162 = v_u_161.color
	v_u_159.UI = v_u_160
	v_u_159.C = v_u_162
	local v_u_163
	if type(p157) == "table" then
		local v164 = p157.fit
		if type(v164) == "number" and p157.fit > 0 then
			v_u_163 = p157.fit
		else
			v_u_163 = nil
		end
	else
		v_u_163 = nil
	end
	local v_u_165 = v_u_163 ~= nil and true or p_u_154.compact()
	v_u_159.compact = v_u_165
	local v166 = v_u_161.touch(36)
	local v_u_167 = v_u_161.touch(44)
	local v168 = 156
	local v169 = 116
	local v170 = 640
	local v171 = v_u_165 and 108 or 132
	local v172 = nil
	if v_u_163 == nil then
		if v_u_165 then
			local v173 = p_u_154.playColW
			local v174 = type(v173) ~= "function" and 440 or p_u_154.playColW()
			local v175 = v_u_161.safeRefSize().X
			local v176 = v175 - v174 - 24 - 24 - 24
			v_u_163 = math.max(260, v176)
			local v177 = v_u_4.barPlan(v_u_163, v175 - v174 - 58, v166)
			v168 = v177.slotW1
			v169 = v177.slotW
			local v178 = v175 - v174 - 24 - 24 - 16
			if v178 < v_u_163 then
				v172 = v_u_4.fitPlan(v178, v166, {
					["soloWords"] = true
				})
				if v172.fits == false then
					v172 = v177
				else
					v_u_163 = v178
					v168 = v172.slotW1
					v169 = v172.slotW
					if v172.iconOnly == true then
						v171 = v166
					end
				end
			else
				v172 = v177
			end
		else
			v_u_163 = v170
		end
	else
		v172 = v_u_4.fitPlan(v_u_163, v166)
		v168 = v172.slotW1
		v169 = v172.slotW
		if v172.iconOnly == true then
			v171 = v166
		end
	end
	v_u_159.plan = v172
	v_u_159.H = v166
	v_u_159.SH = v_u_167
	local v179 = v_u_160.new
	local v180 = "Frame"
	local v181 = {
		["Name"] = "PartyBar",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5
	}
	local v182
	if v_u_165 then
		v182 = Vector2.new(0, 0)
	else
		v182 = Vector2.new(1, 0)
	end
	v181.AnchorPoint = v182
	local v183
	if v_u_165 then
		v183 = UDim2.fromOffset(24, p156 + 8)
	else
		v183 = UDim2.new(1, -24, 0, p156 + 6)
	end
	v181.Position = v183
	v181.Size = UDim2.new(0, v_u_163, 0, v_u_167)
	local v_u_184 = v179(v180, v181, p155)
	v_u_159.frame = v_u_184
	v_u_159.fits = v172 == nil and true or v172.fits ~= false
	if not v_u_159.fits then
		v_u_184.Visible = false
	end
	local v185 = v_u_160.new("Frame", {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_184)
	v_u_160.layout(v185, "h", v_u_165 and 4 or 8, v_u_165 and "left" or "right")
	v_u_159.row = v185
	v_u_160.label({
		["parent"] = nil,
		["name"] = "Caption",
		["text"] = "Squad",
		["style"] = "micro",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 0,
		["visible"] = nil,
		["parent"] = v185,
		["color"] = v_u_162.text2,
		["size"] = UDim2.fromOffset(0, v166),
		["visible"] = not v_u_165
	})
	v_u_159.slots = {}
	for v186 = 1, 4 do
		local v187 = v_u_160.new
		local v188 = "TextButton"
		local v189 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Visible"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["Name"] = "Slot" .. v186,
			["BackgroundColor3"] = v_u_162.raised,
			["LayoutOrder"] = v186,
			["Visible"] = (v172 == nil or v172.n == nil) and true or v186 <= v172.n
		}
		local v190 = UDim2.fromOffset
		local v191
		if v186 == 1 then
			v191 = v168
		else
			v191 = v169
		end
		v189.Size = v190(v191, v_u_167)
		local v_u_192 = v187(v188, v189, v185)
		v_u_192.SelectionImageObject = v_u_160.selectionImage()
		local v_u_193 = v_u_160.stroke(v_u_192, v_u_162.line)
		local v194
		if v186 == 1 then
			v194 = v168
		else
			v194 = v169
		end
		local v195 = v194 < 84 and 8 or 22
		local v196 = v_u_160.new
		local v197 = "Frame"
		local v198 = {
			["Name"] = "Ready",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_162.muted,
			["AnchorPoint"] = Vector2.new(0, v195 < 22 and 0 or 0.5)
		}
		local v199
		if v195 < 22 then
			v199 = UDim2.fromOffset(4, 2)
		else
			v199 = UDim2.new(0, 10, 0.5, 0)
		end
		v198.Position = v199
		v198.Size = UDim2.fromOffset(6, 6)
		local v200 = v196(v197, v198, v_u_192)
		local v201 = v_u_160.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = "",
			["style"] = "bodyStrong",
			["textSize"] = 13,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_192,
			["position"] = UDim2.new(0, v195, 0.5, -20),
			["size"] = UDim2.new(1, -(v195 + 12), 0, 16)
		})
		local v202 = v_u_160.label({
			["parent"] = nil,
			["name"] = "Where",
			["text"] = "",
			["style"] = "micro",
			["textSize"] = 10,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_192,
			["color"] = v_u_162.text2,
			["position"] = UDim2.new(0, v195, 0.5, -4),
			["size"] = UDim2.new(1, -(v195 + 8), 0, 12)
		})
		local v203 = v_u_160.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "micro",
			["textSize"] = 10,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_192,
			["position"] = UDim2.new(0, v195, 0.5, 8),
			["size"] = UDim2.new(1, -(v195 + 8), 0, 12)
		})
		v202.TextTruncate = Enum.TextTruncate.AtEnd
		v203.TextTruncate = Enum.TextTruncate.AtEnd
		v201.TextTruncate = Enum.TextTruncate.AtEnd
		local v_u_204 = {
			["btn"] = nil,
			["stroke"] = nil,
			["dot"] = nil,
			["name"] = nil,
			["where"] = nil,
			["sub"] = nil,
			["plus"] = nil,
			["crown"] = nil,
			["member"] = nil,
			["two"] = false,
			["x0"] = nil,
			["btn"] = v_u_192,
			["stroke"] = v_u_193,
			["dot"] = v200,
			["name"] = v201,
			["where"] = v202,
			["sub"] = v203,
			["plus"] = v_u_160.icon("plus", {
				["parent"] = nil,
				["size"] = 14,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v_u_192,
				["color"] = v_u_162.text2,
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			}),
			["crown"] = v_u_160.icon("star", {
				["parent"] = nil,
				["size"] = 11,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v_u_192,
				["color"] = v_u_162.accent,
				["position"] = UDim2.new(1, -8, 0, 6),
				["anchor"] = Vector2.new(1, 0)
			}),
			["x0"] = v195
		}
		v_u_192.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_160, (copy) v_u_161, (copy) v_u_193, (copy) v_u_162
			v_u_160.sound(v_u_161.sounds.hover)
			v_u_193.Color = v_u_162.lineStrong
		end)
		v_u_192.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_193, (copy) v_u_204, (ref) v_u_5, (copy) v_u_162
			local v205 = v_u_193
			local v206
			if v_u_204.member and v_u_204.member.userId == v_u_5.UserId then
				v206 = v_u_162.accentDim
			else
				v206 = v_u_162.line
			end
			v205.Color = v206
		end)
		v_u_192.Activated:Connect(function()
			-- upvalues: (copy) v_u_159, (copy) v_u_204
			v_u_159:_slotClicked(v_u_204)
		end)
		v_u_160.tooltip(v_u_192, function()
			-- upvalues: (copy) v_u_159, (copy) v_u_204
			return v_u_159:_gearTip(v_u_204)
		end)
		v_u_192.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_159, (copy) v_u_204, (copy) v_u_192, (copy) v_u_160, (ref) v_u_5
			if v_u_159:_gearTip(v_u_204) ~= nil then
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_192, (ref) v_u_160, (ref) v_u_5
					local v207 = game:GetService("GuiService").SelectedObject
					local v208, v209
					if v207 == v_u_192 then
						local v210 = v_u_160.showTooltip
						local v211 = v_u_192
						v208, v209 = pcall(v210, v211)
					else
						v208 = false
						v209 = false
					end
					local v212 = v_u_5
					local v213 = "PartyGearPad"
					local v214 = "%s sel=%s shown=%s"
					local v215 = v_u_192.Name
					if v207 then
						v207 = v207.Name
					end
					v212:SetAttribute(v213, v214:format(v215, tostring(v207), (tostring(v208 and v209))))
				end)
			end
		end)
		v_u_192.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_160
			local v216 = v_u_160.hideTooltip
			pcall(v216)
		end)
		v_u_159.slots[v186] = v_u_204
	end
	local v217 = v_u_160.new("TextButton", {
		["Name"] = "Squads",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 9,
		["Size"] = nil,
		["Selectable"] = true,
		["BackgroundColor3"] = v_u_162.raised,
		["Size"] = UDim2.fromOffset(v171, v_u_167)
	}, v185)
	v217.SelectionImageObject = v_u_160.selectionImage()
	local v_u_218 = v_u_160.stroke(v217, v_u_162.accentDim)
	v_u_159.sqIcon = v_u_160.icon("squad", {
		["parent"] = nil,
		["size"] = 14,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v217,
		["color"] = v_u_162.accent,
		["position"] = UDim2.new(0, 10, 0.5, -7),
		["anchor"] = Vector2.new(0, 0.5)
	})
	local v219 = v_u_160.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Squads",
		["style"] = "bodyStrong",
		["textSize"] = 13,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v217,
		["position"] = UDim2.new(0, 30, 0.5, -14),
		["size"] = UDim2.new(1, -36, 0, 16)
	})
	v219.TextTruncate = Enum.TextTruncate.AtEnd
	local v220 = v_u_160.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = "",
		["style"] = "micro",
		["textSize"] = 10,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v217,
		["color"] = v_u_162.text2,
		["position"] = UDim2.new(0, 10, 0.5, 4),
		["size"] = UDim2.new(1, -16, 0, 12)
	})
	v220.TextTruncate = Enum.TextTruncate.AtEnd
	v217.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_160, (copy) v_u_161, (copy) v_u_218, (copy) v_u_162
		v_u_160.sound(v_u_161.sounds.hover)
		v_u_218.Color = v_u_162.accent
	end)
	v217.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_218, (copy) v_u_162
		v_u_218.Color = v_u_162.accentDim
	end)
	v217.Activated:Connect(function()
		-- upvalues: (copy) v_u_160, (copy) v_u_161, (copy) v_u_159, (copy) p_u_154
		v_u_160.sound(v_u_161.sounds.click or v_u_161.sounds.hover)
		v_u_159:_squadsUsed()
		local v221, v222 = pcall(function()
			return require((script.Parent:WaitForChild("MenuSquads", 5)))
		end)
		if not v221 or type(v222) ~= "table" then
			v222 = nil
		end
		if v222 then
			v222.open(p_u_154)
		end
	end)
	v_u_160.tooltip(v217, function()
		-- upvalues: (copy) p_u_154, (ref) v_u_7
		local function v223()
			-- upvalues: (ref) p_u_154
			return p_u_154.cctx.lib.MenuPlayPvpve.publicOnly() == true
		end
		local v224, v225 = pcall(v223)
		local v226 = {
			["title"] = "SQUADS",
			["body"] = nil
		}
		local v227
		if v224 and v225 then
			v227 = v_u_7.SQUADS_TIP_PVPVE
		else
			v227 = v_u_7.SQUADS_TIP
		end
		v226.body = v227
		return v226
	end)
	v_u_159.sqSub = v220
	v_u_159.sqTitle = v219
	v_u_159.sqStroke = v_u_218
	v_u_159.sq = v217
	v_u_159.sqW = v171
	v_u_159.barW = v_u_163
	v_u_159:_buildHint(v_u_184, v_u_167)
	pcall(function()
		-- upvalues: (copy) v_u_159, (copy) p_u_154, (copy) v_u_184, (copy) v_u_167, (ref) v_u_163, (copy) v_u_165
		v_u_159.paidHint = p_u_154.cctx.lib.MenuPaidQueue.attachHint(p_u_154, v_u_184, v_u_167, v_u_163, v_u_165)
	end)
	local v228 = v_u_160.new("Frame", {
		["Name"] = "SearchTrack",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_162.line,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 3)
	}, v217)
	v_u_159.sqFill = v_u_160.new("Frame", {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_162.accent,
		["Size"] = UDim2.fromScale(1, 1)
	}, v228)
	v_u_159.sqTrack = v228
	v_u_159.sqTarget = -1
	local v229, v230 = pcall(function()
		return require((script.Parent:WaitForChild("MenuSquads", 5)))
	end)
	if not v229 or type(v230) ~= "table" then
		v230 = nil
	end
	if v230 then
		local v231 = v230.bind
		pcall(v231, p_u_154)
	end
	local v234, v235 = v_u_160.button({
		["parent"] = nil,
		["text"] = "Ready",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 132,
		["maxTextWidth"] = 92,
		["order"] = 10,
		["onClick"] = nil,
		["parent"] = v185,
		["height"] = v166,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_154
			local v232 = p_u_154.myParty()
			if v232 then
				local v233 = v232.searching
				if type(v233) == "table" then
					p_u_154.partyOp({
						["op"] = "cancelSearch"
					})
					return
				end
			end
			p_u_154.partyOp({
				["op"] = "ready"
			})
		end
	})
	v_u_159.readyBtn = v234
	v_u_159.readyApi = v235
	local v236 = v_u_160.new("Frame", {
		["Name"] = "MicBox",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 11,
		["BackgroundColor3"] = v_u_162.raised,
		["Size"] = UDim2.fromOffset(v166, v166)
	}, v185)
	v_u_160.stroke(v236, v_u_162.line)
	v236.Visible = v172 == nil and true or v172.mic
	local v237 = p_u_154.kit.mic(v236, 20, v_u_162.muted)
	v237.AnchorPoint = Vector2.new(0.5, 0.5)
	v237.Position = UDim2.fromScale(0.5, 0.5)
	v_u_160.new("Frame", {
		["Name"] = "Slash",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = v_u_162.muted,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(0, 2, 0.7, 0)
	}, v236)
	v_u_160.tooltip(v236, function()
		-- upvalues: (ref) v_u_7
		return {
			["title"] = "PARTY VOICE",
			["body"] = nil,
			["body"] = v_u_7.MIC_TIP
		}
	end)
	v236.InputBegan:Connect(function(p238)
		-- upvalues: (copy) v_u_160, (ref) v_u_7
		if p238.UserInputType == Enum.UserInputType.Touch or p238.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_160.toast(v_u_7.MIC_TOAST_TITLE, "info", v_u_7.MIC_TOAST_SUB)
		end
	end)
	local _, v240 = v_u_160.iconButton({
		["parent"] = nil,
		["icon"] = "close",
		["kind"] = "ghost",
		["size"] = nil,
		["order"] = 12,
		["tooltip"] = "Leave squad",
		["onClick"] = nil,
		["parent"] = v185,
		["size"] = v166,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_160, (copy) p_u_154
			local v239 = {
				["title"] = "Leave squad?",
				["body"] = "You will go back to solo. Your squad keeps its settings.",
				["kind"] = "danger",
				["buttons"] = nil,
				["buttons"] = {
					{
						["text"] = "Stay"
					},
					{
						["text"] = "Leave",
						["kind"] = "danger",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) p_u_154
							p_u_154.partyOp({
								["op"] = "leave"
							})
						end
					}
				}
			}
			v_u_160.modal(v239)
		end
	})
	v_u_159.leaveApi = v240
	v_u_159.leaveBtn = v185:FindFirstChildWhichIsA("TextButton", false)
	for _, v241 in v185:GetChildren() do
		if not v241:IsA("TextButton") or v241.LayoutOrder ~= 12 then
			continue
		end
		v_u_159.leaveBtn = v241
	end
	local v242 = v_u_160.new("Frame", {
		["Name"] = "Invites",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 20,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -24, 0, p156 + v_u_167 + 14),
		["Size"] = UDim2.fromOffset(340, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p155)
	v_u_160.layout(v242, "v", 6)
	v_u_159.invites = v242
	v_u_159.inviteKeys = {}
	v_u_159.inviteClock = {}
	v_u_159.inviteDead = {}
	v_u_159:refresh()
	v_u_159:_linkTabs()
	v_u_159.hb = v_u_3.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_159
		local v243 = v_u_159.mc.myParty()
		local v244, v245, v246, v247
		if v_u_159.sqOn then
			v244 = v_u_159._searchLine
			v245 = v_u_159
			pcall(v244, v245)
			if v_u_159.pulseOn or v_u_159.hintOn then
				v246 = v_u_159._pulseStep
				v247 = v_u_159
				pcall(v246, v247)
			end
			return
		elseif v243 then
			local v248 = v243.searching
			if type(v248) == "table" then
				v244 = v_u_159._searchLine
				v245 = v_u_159
				pcall(v244, v245)
				if v_u_159.pulseOn or v_u_159.hintOn then
					v246 = v_u_159._pulseStep
					v247 = v_u_159
					pcall(v246, v247)
				end
			elseif v_u_159.pulseOn or v_u_159.hintOn then
				v246 = v_u_159._pulseStep
				v247 = v_u_159
				pcall(v246, v247)
			end
		else
			if v_u_159.pulseOn or v_u_159.hintOn then
				v246 = v_u_159._pulseStep
				v247 = v_u_159
				pcall(v246, v247)
			end
			return
		end
	end)
	return v_u_159
end
function v_u_4._buildHint(p_u_249, p250, p251) -- name: _buildHint
	local v252 = p_u_249.UI
	local v253 = p_u_249.C
	local v254 = v252.new("Frame", {
		["Name"] = "SquadHint",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 30,
		["BackgroundColor3"] = v253.bg,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, p251 + 12),
		["Size"] = UDim2.fromOffset(300, 134)
	}, p250)
	v252.stroke(v254, v253.accent)
	v252.pad(v254, {
		16,
		14,
		10,
		12
	})
	v252.layout(v254, "v", 6)
	v252.label({
		["parent"] = nil,
		["name"] = "Kicker",
		["text"] = "Play together",
		["style"] = "caps",
		["color"] = nil,
		["order"] = 1,
		["size"] = nil,
		["parent"] = v254,
		["color"] = v253.accent,
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	v252.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = "Find other survivors to raid with, or set who can join your squad.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["order"] = 2,
		["size"] = nil,
		["parent"] = v254,
		["color"] = v253.text,
		["size"] = UDim2.new(1, 0, 0, 48)
	})
	local v255 = v252.new("Frame", {
		["Name"] = "Buttons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 3,
		["Size"] = UDim2.new(1, 0, 0, 36)
	}, v254)
	local v258 = v252.button({
		["parent"] = nil,
		["name"] = "Find",
		["text"] = "Find squad",
		["kind"] = "primary",
		["height"] = 34,
		["width"] = 150,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v255,
		["position"] = UDim2.fromScale(1, 0.5),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_249
			p_u_249:_squadsUsed()
			local v256, v257 = pcall(function()
				return require((script.Parent:WaitForChild("MenuSquads", 5)))
			end)
			if not v256 or type(v257) ~= "table" then
				v257 = nil
			end
			if v257 then
				v257.open(p_u_249.mc)
			end
		end
	})
	local v259 = v252.button({
		["parent"] = nil,
		["name"] = "GotIt",
		["text"] = "Got it",
		["kind"] = "ghost",
		["height"] = 34,
		["width"] = 100,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v255,
		["position"] = UDim2.new(1, -158, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_249
			p_u_249:_hintDone()
		end
	})
	local v260 = v252.new("Frame", {
		["Name"] = "Arrow",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 29,
		["BackgroundColor3"] = v253.accent,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(1, -40, 0, 0),
		["Size"] = UDim2.fromOffset(9, 9)
	}, v254)
	for _, v261 in v254:GetDescendants() do
		if not v261:IsA("GuiObject") or v261 == v260 then
			continue
		end
		v261.ZIndex = 31
	end
	p_u_249.hint = v254
	p_u_249.hintY0 = nil
	p_u_249.hintArrow = v260
	p_u_249.hintFind = v258
	p_u_249.hintGot = v259
end
function v_u_4._squadsUsed(p262) -- name: _squadsUsed
	local v263 = p262.mc
	p262.usedLocal = true
	p262.hintLocal = true
	if p262.forceHint == true then
		p262.forceHint = nil
	end
	local v264 = v263.profile
	local v265
	if type(v264) == "table" then
		local v266 = v264.settings
		if type(v266) == "table" then
			v265 = v264.settings.squadsUsed == true
		else
			v265 = false
		end
	else
		v265 = false
	end
	if not v265 then
		local v267 = v263.op
		pcall(v267, {
			["op"] = "setting",
			["key"] = "squadsUsed",
			["value"] = true
		})
	end
	local v268 = v263.profile
	local v269
	if type(v268) == "table" then
		local v270 = v268.settings
		if type(v270) == "table" then
			v269 = v268.settings.squadsHintSeen == true
		else
			v269 = false
		end
	else
		v269 = false
	end
	if not v269 then
		local v271 = v263.op
		pcall(v271, {
			["op"] = "setting",
			["key"] = "squadsHintSeen",
			["value"] = true
		})
	end
	p262:_soloLook()
end
function v_u_4._hintDone(p272) -- name: _hintDone
	p272.hintLocal = true
	if p272.forceHint == true then
		p272.forceHint = nil
	end
	local v273 = p272.mc.profile
	local v274
	if type(v273) == "table" then
		local v275 = v273.settings
		if type(v275) == "table" then
			v274 = v273.settings.squadsHintSeen == true
		else
			v274 = false
		end
	else
		v274 = false
	end
	if not v274 then
		local v276 = p272.mc.op
		pcall(v276, {
			["op"] = "setting",
			["key"] = "squadsHintSeen",
			["value"] = true
		})
	end
	p272:_soloLook()
end
function v_u_4.hintCmd(p277, p278) -- name: hintCmd
	local v279 = string.lower(p278 or "")
	if v279 == "reset" then
		p277.usedLocal = nil
		p277.hintLocal = nil
		p277.forceHint = true
	elseif v279 == "show" then
		p277.forceHint = true
	elseif v279 == "hide" then
		p277.forceHint = false
	elseif v279 == "auto" then
		p277.forceHint = nil
	end
	p277:_soloLook()
	local v280 = "solo=%s pulse=%s hint=%s title=%s used=%s hintSeen=%s tourSeen=%s"
	local v281 = p277.solo
	local v282 = tostring(v281)
	local v283 = p277.pulseOn
	local v284 = tostring(v283)
	local v285 = p277.hintOn
	local v286 = tostring(v285)
	local v287 = p277.sqTitle
	if v287 then
		v287 = p277.sqTitle.Text
	end
	local v288 = tostring(v287)
	local v289 = p277.mc.profile
	local v290
	if type(v289) == "table" then
		local v291 = v289.settings
		if type(v291) == "table" then
			v290 = v289.settings.squadsUsed == true
		else
			v290 = false
		end
	else
		v290 = false
	end
	local v292 = tostring(v290)
	local v293 = p277.mc.profile
	local v294
	if type(v293) == "table" then
		local v295 = v293.settings
		if type(v295) == "table" then
			v294 = v293.settings.squadsHintSeen == true
		else
			v294 = false
		end
	else
		v294 = false
	end
	local v296 = tostring(v294)
	local v297 = p277.mc.profile
	local v298
	if type(v297) == "table" then
		local v299 = v297.settings
		if type(v299) == "table" then
			v298 = v297.settings.menuTourSeen == true
		else
			v298 = false
		end
	else
		v298 = false
	end
	return v280:format(v282, v284, v286, v288, v292, v296, (tostring(v298)))
end
function v_u_4._soloLook(p300) -- name: _soloLook
	-- upvalues: (ref) v_u_5
	local v301 = p300.mc
	local v302 = p300.C
	if p300.sq then
		local v303 = v301.myParty()
		local v304
		if v303 == nil then
			v304 = false
		else
			local v305 = v303.members
			if type(v305) == "table" then
				v304 = #v303.members > 1
			else
				v304 = false
			end
		end
		local v306 = not v304
		local v307
		if v303 == nil then
			v307 = false
		else
			local v308 = v303.searching
			v307 = type(v308) == "table"
		end
		p300.solo = v306
		if not v307 and p300.sqTitle then
			local v309 = v306 and "Find squad" or "Squads"
			if p300.sqTitleText ~= v309 then
				p300.sqTitleText = v309
				p300.UI.setText(p300.sqTitle, v309)
			end
		end
		local v310 = v301.profile
		local v311 = type(v310) == "table"
		local v312
		if p300.usedLocal == true then
			v312 = true
		else
			local v313 = v301.profile
			if type(v313) == "table" then
				local v314 = v313.settings
				if type(v314) == "table" then
					v312 = v313.settings.squadsUsed == true
				else
					v312 = false
				end
			else
				v312 = false
			end
		end
		local v315 = v306 and not v307
		if v315 then
			if v311 then
				v315 = not v312
			else
				v315 = v311
			end
		end
		if p300.forceHint ~= nil then
			if p300.forceHint == true then
				if v306 then
					v315 = not v307
				else
					v315 = v306
				end
			else
				v315 = false
			end
		end
		if v315 ~= p300.pulseOn then
			p300.pulseOn = v315
			if not v315 and (not v307 and p300.sqStroke) then
				p300.sqStroke.Color = v302.accentDim
				p300.sqStroke.Thickness = 1
				p300.sq.BackgroundColor3 = v302.raised
			end
		end
		local v316
		if p300.hintLocal == true then
			v316 = true
		else
			local v317 = v301.profile
			if type(v317) == "table" then
				local v318 = v317.settings
				if type(v318) == "table" then
					v316 = v317.settings.squadsHintSeen == true
				else
					v316 = false
				end
			else
				v316 = false
			end
		end
		local v319 = v_u_5:GetAttribute("MenuTab")
		local v320 = (v319 == nil or v319 == "") and true or string.lower((tostring(v319))) == "play"
		local v321 = v306 and (not v307 and (v311 and not v316))
		if v321 then
			local v322 = v301.profile
			if type(v322) == "table" then
				local v323 = v322.settings
				if type(v323) == "table" then
					v321 = v322.settings.menuTourSeen == true
				else
					v321 = false
				end
			else
				v321 = false
			end
			if v321 then
				v321 = p300.frame.Visible
				if v321 then
					v321 = v320
				end
			end
		end
		if p300.forceHint == nil then
			v320 = v321
		else
			local v324 = p300.forceHint == true and (v306 and not v307)
			if v324 then
				local v325 = p300.frame.Visible
				if not v325 then
					v320 = v325
				end
			else
				v320 = v324
			end
		end
		if v320 ~= p300.hintOn and p300.hint then
			p300.hintOn = v320
			p300.hint.Visible = v320
			if v320 then
				local v326 = p300._pulseStep
				pcall(v326, p300)
				return
			end
			local v327 = game:GetService("GuiService")
			local v328 = v327.SelectedObject
			if v328 and v328:IsDescendantOf(p300.hint) then
				v327.SelectedObject = p300.sq
			end
		end
	end
end
function v_u_4._pulseStep(p329) -- name: _pulseStep
	-- upvalues: (ref) v_u_5
	local v330 = p329.C
	if p329.pulseOn and p329.sqStroke then
		local v331 = os.clock() * 3.141592653589793 * 2 / 1.6
		local v332 = 0.5 - math.cos(v331) * 0.5
		p329.sqStroke.Color = v330.accentDim:Lerp(v330.accent, v332)
		p329.sqStroke.Thickness = v332 + 1
		p329.sq.BackgroundColor3 = v330.raised:Lerp(v330.accent, v332 * 0.12)
	end
	if p329.hintOn and (p329.hint and p329.sq) then
		local v333 = p329.frame
		local v334 = (not p329.barW or p329.barW <= 0) and 1 or v333.AbsoluteSize.X / p329.barW
		if v334 > 0 then
			local v335 = p329.sqW or 132
			local v336 = (p329.sq.AbsolutePosition.X - v333.AbsolutePosition.X) / v334 + v335
			local v337 = math.max(300, v336) + 0.5
			local v338 = math.floor(v337)
			local v339 = v333.Parent
			local v340
			if v339 then
				v340 = v339:FindFirstChild("Pages")
			else
				v340 = v339
			end
			if v340 then
				v340 = v340:FindFirstChild("Page_play")
			end
			local v341
			if v340 then
				v341 = v340:FindFirstChild("Column")
			else
				v341 = v340
			end
			local v342
			if v341 and (v341:IsA("GuiObject") and v340.Visible) then
				local v343 = (v341.AbsolutePosition.X - 10 - v333.AbsolutePosition.X) / v334
				v342 = math.floor(v343)
				if v342 >= v338 then
					v342 = v338
				end
			else
				v342 = v338
			end
			local v344 = 300
			if v339 and v339:IsA("GuiObject") then
				local v345 = (v339.AbsolutePosition.X - v333.AbsolutePosition.X) / v334
				local v346 = math.ceil(v345) + 8
				if v342 - v346 < 300 then
					local v347 = v342 - v346
					v344 = math.max(v347, 232)
				end
				local v348 = v344 + v346
				v342 = math.max(v342, v348)
			end
			if p329.hintW ~= v344 then
				p329.hintW = v344
				p329.hint.Size = UDim2.fromOffset(v344, 134)
				local v349 = v344 < 300 and 120 or 150
				p329.hintFind.Size = UDim2.new(0, v349, p329.hintFind.Size.Y.Scale, p329.hintFind.Size.Y.Offset)
				p329.hintGot.Size = UDim2.new(0, v344 < 300 and 84 or 100, p329.hintGot.Size.Y.Scale, p329.hintGot.Size.Y.Offset)
				p329.hintGot.Position = UDim2.new(1, -(v349 + 8), 0.5, 0)
			end
			local v350 = p329.hintY0 or p329.hint.Position.Y.Offset
			p329.hintY0 = v350
			local v351 = v_u_5:FindFirstChildOfClass("PlayerGui")
			if v351 then
				v351 = v351:FindFirstChild("HushDeployBanner")
			end
			local v352 = v351 and (v351:IsA("ScreenGui") and v351.Enabled)
			if v352 then
				v352 = v351:FindFirstChild("DeployBanner", true)
			end
			if v352 and (v352:IsA("GuiObject") and (v352.Visible and v352.AbsoluteSize.Y > 0)) then
				local v353 = (v352.AbsolutePosition.Y + v352.AbsoluteSize.Y + 8 - v333.AbsolutePosition.Y) / v334
				local v354 = math.ceil(v353)
				v350 = math.max(v350, v354)
			end
			if p329.hint.Position.X.Offset ~= v342 or (p329.hint.Position.X.Scale ~= 0 or p329.hint.Position.Y.Offset ~= v350) then
				p329.hint.Position = UDim2.new(0, v342, 0, v350)
			end
			local v355 = v336 - v335 / 2 - (v342 - v344)
			local v356 = p329.hintArrow
			local v357
			if v355 >= 14 then
				v357 = v355 <= v344 - 14
			else
				v357 = false
			end
			v356.Visible = v357
			local v358 = p329.hintArrow
			local v359 = UDim2.new
			local v360 = v344 - 14
			local v361 = math.clamp(v355, 14, v360) + 0.5
			v358.Position = v359(0, math.floor(v361), 0, 0)
		end
	end
end
function v_u_4._linkTabs(p362) -- name: _linkTabs
	local v363 = p362.frame
	local v364 = p362.slots and p362.slots[1]
	if v364 then
		v364 = p362.slots[1].btn
	end
	local v365 = v363 and v363.Parent
	if v365 then
		v365 = v363.Parent:FindFirstChild("TopBar")
	end
	if v365 then
		v365 = v365:FindFirstChild("Tabs")
	end
	if v364 and v365 then
		local v366 = nil
		for _, v367 in v365:GetChildren() do
			if not (v367:IsA("GuiButton") and v367.Visible) then
				continue
			end
			local v368 = v367.Name
			if string.sub(v368, 1, 4) ~= "Tab_" or v366 and v367.LayoutOrder <= v366.LayoutOrder then
				continue
			end
			v366 = v367
		end
		if v366 then
			local v369 = v363.Visible
			if p362.linkedTab and (p362.linkedTab ~= v366 and p362.linkedTab.NextSelectionRight == v364) then
				p362.linkedTab.NextSelectionRight = nil
			end
			local v370
			if v369 then
				v370 = v364
			else
				v370 = nil
			end
			if v366.NextSelectionRight ~= v370 then
				v366.NextSelectionRight = v370
			end
			local v371
			if v369 then
				v371 = v366
			else
				v371 = nil
			end
			if v364.NextSelectionLeft ~= v371 then
				v364.NextSelectionLeft = v371
			end
			p362.linkedTab = v366
		end
	else
		return
	end
end
function v_u_4._members(p372) -- name: _members
	-- upvalues: (ref) v_u_5
	local v373 = p372.mc.myParty()
	if v373 then
		local v374 = v373.members
		if type(v374) == "table" then
			local v375 = {}
			for _, v376 in v373.members do
				if v376.userId == v_u_5.UserId then
					table.insert(v375, 1, v376)
				else
					table.insert(v375, v376)
				end
			end
			p372:_fakeMembers(v375)
			return v375
		end
	end
	local v377 = v_u_5:GetAttribute("MenuTab")
	local v378 = (type(v377) ~= "string" or v377 == "") and "PLAY" or string.upper(v377)
	local v379 = {
		{
			["userId"] = nil,
			["name"] = nil,
			["displayName"] = nil,
			["ready"] = true,
			["place"] = "Menu",
			["leader"] = true,
			["where"] = nil,
			["userId"] = v_u_5.UserId,
			["name"] = v_u_5.Name,
			["displayName"] = v_u_5.DisplayName,
			["where"] = v378
		}
	}
	p372:_fakeMembers(v379)
	return v379
end
function v_u_4._fakeMembers(p380, p381) -- name: _fakeMembers
	local v382 = p380.mc.scene
	local v383
	if type(v382) == "function" then
		v383 = p380.mc.scene()
	else
		v383 = nil
	end
	if v383 then
		local v384 = v383.fakeRows
		if type(v384) == "function" then
			local v385 = v383.fakeRows
			local v386, v387 = pcall(v385, v383)
			if not v386 or type(v387) ~= "table" then
				return
			end
			for _, v388 in v387 do
				if #p381 >= 4 then
					break
				end
				table.insert(p381, v388)
			end
			return
		end
	end
end
function v_u_4._slotSearch(p389, p390, p391, p392) -- name: _slotSearch
	local v393 = p389.UI
	local v394 = p389.C
	if p391 then
		if not p390.two then
			p390.two = true
			p390.name.Position = UDim2.new(0, p390.x0, 0.5, -15)
			p390.where.Position = UDim2.new(0, p390.x0, 0.5, 2)
		end
		p390.sub.Visible = false
		v393.setText(p390.where, p392 or (p389.slotWord or "Searching"))
		p390.where.TextColor3 = v394.accent
		p390.dot.BackgroundColor3 = v394.accent
	elseif p390.two then
		p390.two = false
		p390.name.Position = UDim2.new(0, p390.x0, 0.5, -20)
		p390.where.Position = UDim2.new(0, p390.x0, 0.5, -4)
		p390.sub.Visible = p390.member ~= nil
		p390.dot.BackgroundTransparency = 0
	end
end
function v_u_4._items(p_u_395) -- name: _items
	local v396, v397 = pcall(function()
		-- upvalues: (copy) p_u_395
		return p_u_395.mc.cctx.shared.Items
	end)
	if v396 then
		return v397
	else
		return nil
	end
end
function v_u_4._gearTip(p398, p399) -- name: _gearTip
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v400 = p399.member
	if type(v400) ~= "table" or v400.userId == v_u_5.UserId and not v400.fake then
		return nil
	end
	local v401 = v_u_4.gearContent(v400, p398:_items())
	if v401 then
		local v402 = {}
		for _, v403 in v401.lines do
			local v404 = v403.label .. "=" .. v403.value
			table.insert(v402, v404)
		end
		local v405 = v_u_5
		local v406 = v400.displayName or v400.name
		v405:SetAttribute("PartyGearTip", tostring(v406) .. "|" .. table.concat(v402, ","))
	end
	return v401
end
function v_u_4._slotClicked(p407, p408) -- name: _slotClicked
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v_u_409 = p407.mc
	local v410 = p407.UI
	if p408.member then
		local v_u_411 = p408.member
		if v_u_411.userId ~= v_u_5.UserId or v_u_411.fake then
			local v412 = v_u_4.gearText(v_u_411, p407:_items())
			local v413 = "Squad member. " .. ((v_u_411.ready or v_u_411.leader) and "Ready." or "Not ready yet.") .. "\n\n" .. v412
			local v414 = v_u_5
			local v415 = v_u_411.displayName or v_u_411.name
			v414:SetAttribute("PartyGearTip", tostring(v415) .. "|modal|" .. string.gsub(v412, "\n", ","))
			local v416 = nil
			local v417 = script.Parent:FindFirstChild("MenuReport")
			if v417 then
				local v418 = require
				local v419, v420 = pcall(v418, v417)
				if v419 and type(v420) == "table" then
					local v421 = v420.partyButton
					if type(v421) == "function" then
						v416 = v420.partyButton(v_u_409, v_u_411)
					end
				end
			end
			if v_u_409.isLeader() and (v_u_409.myParty() and not v_u_411.fake) then
				local v422 = v410.modal
				local v423 = {}
				local v424 = v_u_411.displayName or v_u_411.name
				v423.title = tostring(v424)
				v423.body = v413
				local v425 = {
					{
						["text"] = "Close"
					},
					{
						["text"] = "Make leader",
						["kind"] = "secondary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_409, (copy) v_u_411
							v_u_409.partyOp({
								["op"] = "promote",
								["userId"] = nil,
								["userId"] = v_u_411.userId
							})
						end
					},
					{
						["text"] = "Kick",
						["kind"] = "danger",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_409, (copy) v_u_411
							v_u_409.partyOp({
								["op"] = "kick",
								["userId"] = nil,
								["userId"] = v_u_411.userId
							})
						end
					}
				}
				if v416 then
					local v426 = v416
					table.insert(v425, 1, v426)
				end
				v423.buttons = v425
				v422(v423)
			else
				local v427 = v410.modal
				local v428 = {}
				local v429 = v_u_411.displayName or v_u_411.name
				v428.title = tostring(v429)
				v428.body = v413
				local v430 = {
					{
						["text"] = "Close"
					}
				}
				if v416 then
					local v431 = v416
					table.insert(v430, 1, v431)
				end
				v428.buttons = v430
				v427(v428)
			end
		end
	else
		p407:_inviteDialog()
		return
	end
end
function v_u_4._inviteDialog(p432) -- name: _inviteDialog
	local v433, v434 = pcall(function()
		return require((script.Parent:WaitForChild("MenuSquads", 5)))
	end)
	if not v433 or type(v434) ~= "table" then
		v434 = nil
	end
	if v434 then
		v434.openInvite(p432.mc)
	end
end
function v_u_4._renderInvites(p435) -- name: _renderInvites
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v_u_436 = p435.mc
	local v437 = p435.UI
	local v438 = p435.C
	local v439 = v_u_436.party
	local v440
	if type(v439) == "table" then
		local v441 = v439.invites
		v440 = type(v441) == "table" and (v439.invites or {}) or {}
	else
		v440 = {}
	end
	local v442 = {}
	for _, v_u_443 in v440 do
		if type(v_u_443) ~= "table" or not v_u_443.partyId then
			continue
		end
		local v444 = v_u_443.partyId
		local v445 = tostring(v444)
		v442[v445] = true
		if p435.inviteKeys[v445] or p435.inviteDead[v445] then
			continue
		end
		local v446 = v437.new("Frame", {
			["Name"] = "Invite",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.04,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v438.bg,
			["Size"] = UDim2.new(1, 0, 0, 92)
		}, p435.invites)
		v437.stroke(v446, v438.lineStrong)
		v437.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v438.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v446)
		v437.label({
			["parent"] = nil,
			["text"] = "Squad invite",
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v446,
			["color"] = v438.accent,
			["position"] = UDim2.fromOffset(16, 8),
			["size"] = UDim2.new(1, -24, 0, 16)
		})
		local v447 = v437.label
		local v448 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v446
		}
		local v449 = v_u_443.fromName or "?"
		v448.text = tostring(v449) .. " wants you in their squad"
		v448.position = UDim2.fromOffset(16, 26)
		v448.size = UDim2.new(1, -24, 0, 20)
		v447(v448)
		local v450 = v437.label({
			["parent"] = nil,
			["name"] = "Expires",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v446,
			["text"] = v_u_7.inviteExpiry(v_u_443.expires, v_u_1.now()) or "",
			["color"] = v438.text2,
			["position"] = UDim2.fromOffset(16, 48),
			["size"] = UDim2.new(1, -260, 0, 16)
		})
		local v451 = p435.inviteClock
		local v452 = {
			["label"] = v450
		}
		local v453 = v_u_443.expires
		v452.expires = tonumber(v453)
		v451[v445] = v452
		v437.button({
			["parent"] = nil,
			["text"] = "Join",
			["kind"] = "primary",
			["height"] = 32,
			["width"] = 110,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v446,
			["position"] = UDim2.new(1, -12, 1, -10),
			["anchor"] = Vector2.new(1, 1),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_436, (copy) v_u_443
				v_u_436.partyOp({
					["op"] = "accept",
					["partyId"] = nil,
					["partyId"] = v_u_443.partyId
				})
			end
		})
		v437.button({
			["parent"] = nil,
			["text"] = "Decline",
			["kind"] = "ghost",
			["height"] = 32,
			["width"] = 110,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v446,
			["position"] = UDim2.new(1, -130, 1, -10),
			["anchor"] = Vector2.new(1, 1),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_436, (copy) v_u_443
				v_u_436.partyOp({
					["op"] = "decline",
					["partyId"] = nil,
					["partyId"] = v_u_443.partyId
				})
			end
		})
		v437.fade(v446, 0, "slow", {
			["from"] = 1
		})
		v437.sound(v_u_436.theme.sounds.toast)
		p435.inviteKeys[v445] = v446
	end
	for v454 in p435.inviteDead do
		if v442[v454] then
			continue
		end
		p435.inviteDead[v454] = nil
	end
	for v455, v456 in p435.inviteKeys do
		if v442[v455] then
			continue
		end
		v456:Destroy()
		p435.inviteKeys[v455] = nil
		p435.inviteClock[v455] = nil
	end
end
function v_u_4.refresh(p457) -- name: refresh
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v_u_458 = p457.mc
	local v459 = p457.C
	local v460 = p457.UI
	local v461 = p457:_members()
	local v462 = v_u_458.myParty()
	local v463 = v_u_458.isLeader()
	for v464, v465 in p457.slots do
		local v466 = v461[v464]
		v465.member = v466
		if v466 then
			local v467 = v466.userId == v_u_5.UserId
			v465.plus.Visible = false
			v465.name.Visible = true
			v465.sub.Visible = true
			v465.where.Visible = true
			v465.dot.Visible = true
			local v468 = v460.setText
			local v469 = v465.name
			local v470 = v466.displayName or (v466.name or "?")
			v468(v469, (tostring(v470)))
			local v471 = v466.place or "Menu"
			local v472 = tostring(v471)
			v460.setText(v465.where, v_u_4.whereText(v466))
			local v473 = v465.where
			local v474
			if v472 == "Raid" or v472 == "Transit" then
				v474 = v459.info
			else
				v474 = v459.text2
			end
			v473.TextColor3 = v474
			local v475 = v466.ready == true and true or v466.leader == true
			v460.setText(v465.sub, v475 and "Ready" or "Not ready")
			local v476 = v465.sub
			local v477
			if v466.leader and (v462 ~= nil and #v462.members > 1) then
				v477 = v459.accent
			elseif v475 then
				v477 = v459.success
			else
				v477 = v459.muted
			end
			v476.TextColor3 = v477
			if v462 == nil or (#v462.members <= 1 or v_u_4.memberMayEnter(v_u_458, v462, v466)) then
				local v478 = v462 ~= nil and #v462.members > 1 and v_u_4.memberDiff(v_u_458, v462, v466)
				if v478 then
					v460.setText(v465.sub, v478)
					v465.sub.TextColor3 = v459.danger
				end
			else
				local v479, v480 = v_u_4.memberRaids(v_u_458, v462, v466)
				local v481
				if v479 == nil then
					v481 = v_u_4.memberQuest(v_u_458, v462, v466)
				else
					v481 = nil
				end
				v460.setText(v465.sub, not (v479 and v480) and (v481 or "No access") or ("%d/%d raids"):format(v479, v480))
				v465.sub.TextColor3 = v459.danger
			end
			local v482 = v465.dot
			local v483
			if v472 == "Raid" then
				v483 = v459.info
			elseif v466.ready or v466.leader then
				v483 = v459.success
			else
				v483 = v459.muted
			end
			v482.BackgroundColor3 = v483
			local v484
			if v462 == nil then
				v484 = false
			else
				local v485 = v462.searching
				v484 = type(v485) == "table"
			end
			p457:_slotSearch(v465, v484)
			local v486 = v465.crown
			local v487
			if v466.leader == true and v462 ~= nil then
				v487 = #v462.members > 1
			else
				v487 = false
			end
			v486.Visible = v487
			local v488 = v465.stroke
			local v489
			if v467 then
				v489 = v459.accentDim
			else
				v489 = v459.line
			end
			v488.Color = v489
			v465.btn.BackgroundTransparency = 0.2
		else
			v465.plus.Visible = v463
			v465.name.Visible = false
			v465.sub.Visible = false
			v465.where.Visible = false
			v465.dot.Visible = false
			v465.crown.Visible = false
			v465.stroke.Color = v459.line
			v465.btn.BackgroundTransparency = 0.6
			p457:_slotSearch(v465, false)
		end
	end
	local v490
	if v462 == nil then
		v490 = false
	else
		v490 = #v462.members > 1
	end
	local v491 = nil
	if p457.plan and p457.plan.soloWords == true then
		for v492, v493 in p457.slots do
			local v494 = v493.btn
			local v495
			if v490 then
				v495 = p457.plan.n or 4
			else
				local v496 = p457.plan.n or 4
				local v497 = p457.plan.soloN or 2
				v495 = math.min(v496, v497)
			end
			v494.Visible = v492 <= v495
		end
	end
	for _, v498 in v461 do
		if v498.userId ~= v_u_5.UserId then
			continue
		end
		v491 = v498
	end
	local v499
	if v462 == nil then
		v499 = false
	else
		local v500 = v462.searching
		v499 = type(v500) == "table"
	end
	local v501 = v_u_5:GetAttribute("MenuTab") == "play"
	local v502 = p457.readyBtn
	local v503 = v499 and not v501 or not v499 and (v490 and not v463)
	if v503 then
		v503 = not p457.compact
	end
	v502.Visible = v503
	if v499 then
		p457.readyApi.setText("Stop search")
		p457.readyApi.setKind("secondary")
	elseif v491 and (v490 and not v463) then
		p457.readyApi.setText(v491.ready and "Ready" or "Ready up")
		p457.readyApi.setKind(v491.ready and "primary" or "secondary")
	end
	if p457.leaveBtn then
		p457.leaveBtn.Visible = v490
	end
	local v504 = p457.plan
	if v504 and (p457.sq and (v504.collapse or v504.iconOnly)) then
		local v505 = v504.iconOnly == true and true or v490
		if v505 ~= p457.sqCollapsed then
			p457.sqCollapsed = v505
			local v506 = p457.sq
			local v507 = UDim2.fromOffset
			local v508
			if v505 then
				v508 = p457.H
			else
				v508 = p457.sqW
			end
			v506.Size = v507(v508, p457.SH)
			p457.sqTitle.Visible = not v505
			p457.sqSub.Visible = not v505
			local v509 = p457.sqIcon
			if v509 then
				local v510
				if v505 then
					v510 = Vector2.new(0.5, 0.5)
				else
					v510 = Vector2.new(0, 0.5)
				end
				v509.AnchorPoint = v510
				local v511
				if v505 then
					v511 = UDim2.fromScale(0.5, 0.5)
				else
					v511 = UDim2.new(0, 10, 0.5, -7)
				end
				v509.Position = v511
			end
		end
	end
	if v504 and (p457.sq and (v504.hideInParty == true and p457.sq.Visible == v490)) then
		p457.sq.Visible = not v490
	end
	if p457.sqSub then
		local v512
		if v462 then
			local v513 = v462.visibility
			v512 = type(v513) ~= "string" and "public" or v462.visibility
		else
			v512 = "public"
		end
		local v514
		if v462 then
			v514 = v512
		else
			local v515 = v_u_458.profile
			if type(v515) == "table" then
				local v516 = v515.settings
				if type(v516) == "table" then
					v514 = v515.settings.squadVisibility or nil
				else
					v514 = nil
				end
			else
				v514 = nil
			end
			if v514 ~= "private" and (v514 ~= "friends" and v514 ~= "public") then
				v514 = v512
			end
		end
		local v517 = v514 == "public" and "Public" or (v514 == "private" and "Private" or "Friends")
		local v518
		if v462 then
			v518 = v462.ageShare
		else
			v518 = nil
		end
		if v490 then
			local v519 = " \194\183 "
			local v520
			if type(v518) == "number" then
				local v521 = v518 + 0.5
				v520 = ("%d%% age"):format((math.floor(v521)))
			else
				v520 = "? age"
			end
			v517 = v517 .. v519 .. v520
		end
		v460.setText(p457.sqSub, string.upper(v517))
		local v522 = p457.sqSub
		local v523
		if v514 == "public" then
			v523 = v459.accent
		else
			v523 = v459.text2
		end
		v522.TextColor3 = v523
	end
	p457.sqTitleText = nil
	p457:_searchLine(true)
	local v524 = p457._soloLook
	pcall(v524, p457)
	p457:_renderInvites()
	local v525 = v_u_458.scene
	local v526
	if type(v525) == "function" then
		v526 = v_u_458.scene()
	else
		v526 = nil
	end
	if v526 and (v526.setSearchSource and p457.searchScene ~= v526) then
		p457.searchScene = v526
		local v527, v_u_528 = pcall(function()
			return require((script.Parent:WaitForChild("MenuSearch", 5)))
		end)
		if not v527 or type(v_u_528) ~= "table" then
			v_u_528 = nil
		end
		local v529 = v526.setSearchSource
		pcall(v529, v526, function()
			-- upvalues: (copy) v_u_528, (copy) v_u_458
			if v_u_528 then
				return v_u_528.state(v_u_458.myParty())
			else
				return nil
			end
		end)
	end
	if v526 and v526.setSquad then
		local v530 = v526.setSquad
		local v531, v532 = pcall(v530, v526, not v490 and {} or v461)
		if not v531 then
			warn("[MenuParty] squad lineup failed:", v532)
		end
	end
end
function v_u_4._searchLine(p533, p534) -- name: _searchLine
	-- upvalues: (copy) v_u_1
	local v535 = p533.mc.myParty()
	local v536
	if v535 then
		local v537 = v535.searching
		if type(v537) == "table" then
			v536 = v535.searching
		else
			v536 = nil
		end
	else
		v536 = nil
	end
	local v538
	if v536 == nil then
		v538 = false
	else
		v538 = p533.sqSub ~= nil
	end
	if v538 ~= p533.sqOn or p534 then
		p533.sqOn = v538
		p533.sqText = nil
		if p533.sqTrack then
			p533.sqTrack.Visible = v538
		end
		if p533.sqTitle then
			p533.UI.setText(p533.sqTitle, v538 and "SEARCHING" or (p533.solo == false and "Squads" or "Find squad"))
			p533.sqTitleText = nil
			local v539 = p533.sqTitle
			local v540
			if v538 then
				v540 = p533.C.accent
			else
				v540 = p533.C.text
			end
			v539.TextColor3 = v540
		end
		if p533.sqStroke then
			local v541 = p533.sqStroke
			local v542
			if v538 then
				v542 = p533.C.accent
			else
				v542 = p533.C.accentDim
			end
			v541.Color = v542
		end
		if not v538 then
			p533.slotWord = nil
			for _, v543 in p533.slots do
				v543.dot.BackgroundTransparency = 0
			end
		end
	end
	if v538 then
		local v544, v545 = pcall(function()
			return require((script.Parent:WaitForChild("MenuSearch", 5)))
		end)
		if not v544 or type(v545) ~= "table" then
			v545 = nil
		end
		local v546
		if v545 then
			v546 = v545.state(v535)
		else
			v546 = nil
		end
		if v546 then
			local v547 = v546.phase == "starting"
			local v548 = v545.clock(v546.remaining)
			local v549 = v545.found(v546)
			if v547 then
				v548 = "DEPLOYING"
			elseif not p533.compact then
				if v549 then
					v548 = v548 .. "  \194\183  " .. v549
				else
					v548 = v548 .. "  \194\183  AT THE LATEST"
				end
			end
			if v548 ~= p533.sqText then
				p533.sqText = v548
				p533.UI.setText(p533.sqSub, v548)
				p533.sqSub.TextColor3 = p533.C.accent
				local v550 = v547 and "Deploying" or "Searching"
				if v550 ~= p533.slotWord then
					p533.slotWord = v550
					for _, v551 in p533.slots do
						if not v551.member then
							continue
						end
						p533:_slotSearch(v551, true, v550)
					end
				end
			end
			p533.sqFill.Size = UDim2.fromScale(v546.frac, 1)
			local v552 = os.clock() * 3.141592653589793 * 2 / 1.4
			local v553 = 0.45 - math.cos(v552) * 0.45
			for _, v554 in p533.slots do
				if not v554.member then
					continue
				end
				v554.dot.BackgroundTransparency = v553
			end
		else
			local v555 = v536.since
			local v556 = tonumber(v555) or v_u_1.now()
			local v557 = v_u_1.now() - v556
			local v558 = math.floor(v557)
			local v559 = math.max(0, v558)
			p533.UI.setText(p533.sqSub, ("SEARCHING %d:%02d"):format(v559 // 60, v559 % 60))
			p533.sqSub.TextColor3 = p533.C.accent
		end
	else
		return
	end
end
function v_u_4._inviteClock(p560) -- name: _inviteClock
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	local v561 = v_u_1.now()
	for v562, v563 in p560.inviteClock do
		if v563.expires == nil then
			continue
		end
		local v564 = p560.inviteKeys[v562]
		local v565
		if v564 and v564.Parent then
			v565 = v_u_7.inviteExpiry(v563.expires, v561)
		else
			v565 = nil
		end
		if v565 == nil then
			if v564 then
				v564:Destroy()
			end
			p560.inviteKeys[v562] = nil
			p560.inviteClock[v562] = nil
			p560.inviteDead[v562] = true
		else
			if v563.label.Text == v565 then
				continue
			end
			v563.label.Text = v565
		end
	end
end
function v_u_4.tick(p566) -- name: tick
	-- upvalues: (copy) v_u_3, (ref) v_u_5
	p566:_searchLine()
	p566:_inviteClock()
	p566:_linkTabs()
	local v567
	if v_u_3:IsStudio() then
		v567 = v_u_5:GetAttribute("DevSquadHint")
	else
		v567 = nil
	end
	if type(v567) == "string" and v567 ~= p566.devHint then
		p566.devHint = v567
		local v568 = p566.hintCmd
		local _, v569 = pcall(v568, p566, v567)
		v_u_5:SetAttribute("DevSquadHintResult", (tostring(v569)))
	end
	local v570 = p566._soloLook
	pcall(v570, p566)
	local v571 = p566.mc.party
	if type(v571) == "table" then
		local v572 = v571.invites
		if type(v572) == "table" then
			local v573 = os.time()
			local v574 = false
			for v575 = #v571.invites, 1, -1 do
				local v576 = v571.invites[v575]
				if type(v576) ~= "table" then
					continue
				end
				local v577 = v576.expires
				if not tonumber(v577) or v576.expires >= v573 then
					continue
				end
				table.remove(v571.invites, v575)
				v574 = true
			end
			if v574 then
				p566:_renderInvites()
			end
		end
	end
end
function v_u_4.destroy(p578) -- name: destroy
	if p578.hb then
		p578.hb:Disconnect()
		p578.hb = nil
	end
	if p578.frame then
		p578.frame:Destroy()
	end
	if p578.invites then
		p578.invites:Destroy()
	end
end
return v_u_4