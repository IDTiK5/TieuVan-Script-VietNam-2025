-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanModel

local v_u_20 = {
	["LINES_MAX"] = 16,
	["NAME_MIN"] = 3,
	["NAME_MAX"] = 20,
	["TAG_MIN"] = 3,
	["TAG_MAX"] = 4,
	["DESC_MAX"] = 60,
	["RANK_NAME_MAX"] = 12,
	["SEARCH_MAX"] = 20,
	["PAGE"] = 20,
	["POLL_SEC"] = 3,
	["POLL_MAX_SEC"] = 90,
	["REQ_TIMEOUT"] = 25,
	["FOUND_TIMEOUT"] = 40,
	["CODES"] = {
		"NOT_READY",
		"UNAVAILABLE",
		"BUSY",
		"TRY_AGAIN",
		"NEED_PASS",
		"NEED_PASS_LEAD",
		"FOUNDER_HELD",
		"NO_OFFER",
		"IN_CLAN",
		"NO_CLAN",
		"COOLDOWN",
		"TAG_BAD",
		"NAME_BAD",
		"NAME_DUP",
		"TAG_TAKEN",
		"NAME_TAKEN",
		"NOT_FOUND",
		"CLOSED",
		"FULL",
		"NOT_OPEN",
		"NO_INVITE",
		"CRITERIA",
		"REQ_PENDING",
		"REQ_FULL",
		"INV_FULL",
		"BANNED",
		"DENIED",
		"RANK_ORDER",
		"NOT_MEMBER",
		"TARGET_OWNER",
		"TOO_NEW",
		"OWNER_LEAVE",
		"BAD_ARGS",
		"STASH_BUSY",
		"STASH_FULL",
		"STASH_SYNC",
		"STASH_REVIEW",
		"ITEM_NOT_ALLOWED",
		"LIMIT",
		"CHANGED",
		"DEPLOY_BLOCK",
		"DISBANDING",
		"STALE"
	},
	["TEXT"] = {
		["NOT_READY"] = "Your profile is still loading. Please wait a moment.",
		["UNAVAILABLE"] = "Clan features are not available right now. Please try again later.",
		["BUSY"] = "Please wait a moment and try again.",
		["TRY_AGAIN"] = "The clan service is busy right now. Please try again.",
		["NEED_PASS"] = "You need the Clan Founder pass to found a clan.",
		["NEED_PASS_LEAD"] = "You need the Clan Founder pass to take over this clan.",
		["FOUNDER_HELD"] = "Your Clan Founder pass already supports another active clan.",
		["NO_OFFER"] = "That offer is no longer available.",
		["IN_CLAN"] = "You are already in a clan.",
		["NO_CLAN"] = "You are not in a clan.",
		["COOLDOWN"] = "You can do this again in {time}.",
		["TAG_BAD"] = "The tag needs 3 or 4 letters or digits, with at least one letter.",
		["NAME_BAD"] = "That name is not allowed. Please choose another one.",
		["NAME_DUP"] = "Two ranks cannot share one name.",
		["TAG_TAKEN"] = "That clan tag is already taken.",
		["NAME_TAKEN"] = "That clan name is already taken.",
		["NOT_FOUND"] = "That clan or request no longer exists.",
		["CLOSED"] = "This clan is closing.",
		["FULL"] = "That clan is full.",
		["NOT_OPEN"] = "That clan is not open for joining this way.",
		["NO_INVITE"] = "You need an invitation or an approved request to join this clan.",
		["CRITERIA"] = "You do not meet this clan\'s requirements.",
		["REQ_PENDING"] = "You already asked to join this clan.",
		["REQ_FULL"] = "This clan cannot take more requests right now.",
		["INV_FULL"] = "Too many open invitations. Cancel old ones on the Invite tab.",
		["BANNED"] = "You cannot join this clan right now.",
		["DENIED"] = "Your rank does not allow this.",
		["RANK_ORDER"] = "You can only manage members below your rank.",
		["NOT_MEMBER"] = "That player is not in your clan.",
		["TARGET_OWNER"] = "The owner cannot be changed this way.",
		["TOO_NEW"] = "That member has not been in the clan long enough.",
		["OWNER_LEAVE"] = "Owners must hand over the clan or disband it first.",
		["BAD_ARGS"] = "That did not work. Please check what you entered.",
		["STASH_BUSY"] = "Your last clan stash transfer is still completing.",
		["STASH_FULL"] = "The clan stash is full.",
		["STASH_SYNC"] = "The clan stash is still syncing. Try again in a moment.",
		["STASH_REVIEW"] = "A clan stash transfer needs review.",
		["ITEM_NOT_ALLOWED"] = "This item cannot go into the clan stash.",
		["LIMIT"] = "Your rank can take {left} more stacks today.",
		["CHANGED"] = "The stash changed. Please look again and retry.",
		["DEPLOY_BLOCK"] = "Finish your clan stash transfer first.",
		["DISBANDING"] = "Your clan is being closed. This takes a moment.",
		["STALE"] = "The clan changed. Refresh and try again."
	},
	["UI"] = {
		["COMPLETING"] = "Completing... This takes a few seconds.",
		["COMPLETING_LONG"] = "Still completing. You can leave this screen.",
		["SYNCING"] = "Syncing...",
		["STASH_DONE"] = "Done.",
		["LOADING"] = "Loading...",
		["STASH_EMPTY"] = "The clan stash is empty. Use TO CLAN to add items.",
		["STASH_WIPED"] = "The clan storage was wiped with the PVP wipe.",
		["STASH_CLOSED"] = "This clan is closing.",
		["STASH_NO_TAKE"] = "Your rank cannot take items.",
		["STASH_NO_PUT"] = "Your rank cannot add items.",
		["STASH_REVIEW"] = "A clan stash transfer needs review.",
		["STASH_FIR"] = "Found in raid marks are removed in the clan stash.",
		["MY_EMPTY"] = "Your stash is empty. Bring items home from a raid.",
		["LOAD_FAIL"] = "Could not load this. Please try again.",
		["LOAD_RETRY"] = "Could not load this. Retrying...",
		["NO_CLANS"] = "No clans match. Try another search or found your own.",
		["NO_INVITES"] = "No invitations yet.",
		["NEEDS_ACTIVE"] = "Needs 3 active members to rank.",
		["NO_REQUESTS"] = "No requests right now.",
		["ACCEPT_FULL"] = "Your clan has no free place for more players right now.",
		["INV_HEAD"] = "OPEN INVITATIONS %d / %d",
		["OK_HEAD"] = "ACCEPTED, NOT JOINED YET %d",
		["SLOTS"] = "MEMBERS %d / %d",
		["INV_LIST"] = "INVITED PLAYERS",
		["NO_OPEN_INV"] = "No open invitations.",
		["CANCEL"] = "CANCEL",
		["CANCEL_OLDEST"] = "CANCEL OLDEST %d",
		["INV_SUB_OK"] = "Request accepted, ends in %s",
		["INV_SUB_INV"] = "Invited, ends in %s",
		["INV_NONAME"] = "Invited player",
		["OK_NONAME"] = "Accepted player",
		["NO_LOG"] = "Nothing happened yet.",
		["NO_MEMBERS"] = "No members to show.",
		["NO_PASS"] = "The Clan Founder pass lets you found your own clan.",
		["OPEN_STORE"] = "Open the store from the main menu.",
		["PASS_NEEDED_ACCEPT"] = "You need the Clan Founder pass and no other active clan.",
		["CLOSING"] = "Closing clan...",
		["FOUNDING"] = "Founding...",
		["LEAVING"] = "Leaving",
		["DISBANDING"] = "Disbanding",
		["JOINING"] = "Joining",
		["SENDING"] = "Sending",
		["WITHDRAWING"] = "Withdrawing",
		["SAVING"] = "Saving",
		["VALIDATING"] = "Validating",
		["MOVING"] = "Moving",
		["WORKING"] = "Working",
		["REFRESH"] = "REFRESH",
		["REFRESHING"] = "Refreshing",
		["LEAVING_CLAN"] = "Leaving the clan",
		["DISBANDING_CLAN"] = "Disbanding the clan",
		["TRANSIT_SLOW"] = "This takes a little longer than usual.",
		["TRANSIT_DONE_LEFT"] = "You left the clan.",
		["TRANSIT_DONE_DISBANDED"] = "The clan is disbanded.",
		["GOT_KICKED"] = "You were removed from [%s].",
		["GOT_DISBANDED"] = "[%s] was disbanded.",
		["REWARDS_HEAD"] = "Weekly rewards",
		["NOTHING_YET"] = "Nothing counted yet."
	},
	["JOIN_DELAY_SEC"] = 21600,
	["joinDelayHours"] = function() -- name: joinDelayHours
		-- upvalues: (copy) v_u_20
		local v1 = v_u_20.JOIN_DELAY_SEC
		local v2 = v_u_20.rules
		local v3
		if type(v2) == "table" then
			local v4 = v2.TUNE
			if type(v4) == "table" then
				local v5 = v2.TUNE.weekly
				if type(v5) == "table" then
					local v6 = v2.TUNE.weekly.joinPointDelaySec
					v3 = tonumber(v6)
					if v3 == nil then
						v3 = v1
					elseif v3 <= 0 then
						v3 = v1
					end
				else
					v3 = v1
				end
			else
				v3 = v1
			end
		else
			v3 = v1
		end
		return v3 / 3600
	end,
	["joinDelayText"] = function() -- name: joinDelayText
		-- upvalues: (copy) v_u_20
		local v7 = v_u_20.joinDelayHours()
		if v7 == math.floor(v7) then
			return v7 == 1 and "1 hour" or ("%d hours"):format(v7)
		end
		local v8 = v7 * 60 + 0.5
		local v9 = math.floor(v8)
		local v10 = math.max(1, v9)
		return v10 == 1 and "1 minute" or ("%d minutes"):format(v10)
	end,
	["hintMembers"] = function() -- name: hintMembers
		-- upvalues: (copy) v_u_20
		return ("New members score clan points %s after joining."):format(v_u_20.joinDelayText())
	end,
	["hintOverview"] = function() -- name: hintOverview
		-- upvalues: (copy) v_u_20
		return ("Clan points count from %s after you join. The founder starts at once."):format(v_u_20.joinDelayText())
	end,
	["waitText"] = function(p11) -- name: waitText
		local v12 = p11 / 60
		local v13 = math.ceil(v12)
		local v14 = math.max(1, v13)
		if v14 >= 120 then
			local v15 = v14 / 60
			return ("%d hours"):format((math.ceil(v15)))
		elseif v14 >= 60 then
			return ("1 hour %d min"):format(v14 - 60)
		else
			return ("%d min"):format(v14)
		end
	end,
	["hintOverviewFor"] = function(p16, p17) -- name: hintOverviewFor
		-- upvalues: (copy) v_u_20
		local v18 = tonumber(p16)
		local v19 = tonumber(p17)
		if v18 == nil or (v19 == nil or v18 <= v19) then
			return v_u_20.hintOverview()
		else
			return ("Your clan points start to count in %s."):format(v_u_20.waitText(v18 - v19))
		end
	end
}
v_u_20.CONFIRM = {
	["leave"] = function(p21) -- name: leave
		return ("Leave [%s]? You can join another clan after a short wait."):format(p21)
	end,
	["kick"] = function(p22) -- name: kick
		return ("Remove %s from the clan?"):format(p22)
	end,
	["kickMany"] = function(p23) -- name: kickMany
		return ("Remove %d members from the clan?"):format(p23)
	end,
	["offer"] = function(p24) -- name: offer
		return ("Offer %s the leadership? They must accept, and you become an officer then."):format(p24)
	end,
	["disband"] = function(p25, p26) -- name: disband
		if p26 == true then
			return ("Disband [%s]? Everything in the clan stash returns to you. Type the tag to confirm."):format(p25)
		else
			return ("Disband [%s]? Everything in the clan stash returns to you. Clan coins and shop items are lost for good. Type the tag to confirm."):format(p25)
		end
	end,
	["accept"] = function() -- name: accept
		-- upvalues: (copy) v_u_20
		return "Take over the clan? " .. v_u_20.UI.PASS_NEEDED_ACCEPT
	end
}
function v_u_20.idText(p27) -- name: idText
	local v28 = tostring(p27 or "")
	local v29 = ""
	if string.sub(v28, 1, 6) == "frame_" then
		v28 = string.sub(v28, 7)
		v29 = " Frame"
	elseif string.sub(v28, 1, 3) == "bg_" then
		v28 = string.sub(v28, 4)
		v29 = " Background"
	elseif string.sub(v28, 1, 6) == "title_" then
		v28 = string.sub(v28, 7)
	end
	local v30 = string.gsub(v28, "[^%w]+", " ")
	local v31 = {}
	for v32 in string.gmatch(v30, "%S+") do
		local v33 = string.upper((string.sub(v32, 1, 1))) .. string.lower((string.sub(v32, 2)))
		table.insert(v31, v33)
	end
	return table.concat(v31, " ") .. v29
end
function v_u_20.placeText(p34, p35) -- name: placeText
	local v36 = tonumber(p34) or 1
	local v37 = math.floor(v36)
	local v38 = math.max(1, v37)
	local v39 = tonumber(p35) or v38
	local v40 = math.floor(v39)
	local v41 = math.max(v38, v40)
	if v38 == v41 then
		return ("Place %d"):format(v38)
	else
		return ("Places %d to %d"):format(v38, v41)
	end
end
function v_u_20.cosText(p42) -- name: cosText
	if type(p42) == "table" then
		local v43 = p42.name
		if type(v43) == "string" and p42.name ~= "" then
			local v44 = {}
			for v45 in string.gmatch(p42.name, "%S+") do
				local v46 = string.upper((string.sub(v45, 1, 1))) .. string.lower((string.sub(v45, 2)))
				table.insert(v44, v46)
			end
			local v47 = ({
				["anim"] = "animation",
				["bg"] = "background",
				["frame"] = "frame"
			})[p42.kind]
			return table.concat(v44, " ") .. (not v47 and "" or " " .. v47)
		end
	end
	return nil
end
function v_u_20.rewardLines(p48, p49, p50) -- name: rewardLines
	-- upvalues: (copy) v_u_20
	local v51 = {}
	if type(p48) ~= "table" then
		return v51
	end
	local v52 = p48.title
	if type(v52) == "string" and p48.title ~= "" then
		local v53 = "Title: " .. v_u_20.idText(p48.title)
		table.insert(v51, v53)
	end
	local v54 = p48.it
	local v55
	if type(v54) == "table" then
		v55 = p48.it
	else
		local v56 = p48.items
		if type(v56) == "table" then
			v55 = p48.items
		else
			v55 = nil
		end
	end
	if v55 then
		for _, v57 in v55 do
			if type(v57) ~= "table" then
				continue
			end
			local v58 = v57.id
			if type(v58) ~= "string" then
				continue
			end
			local v59
			if p49 then
				v59 = p49(v57.id)
			else
				v59 = v_u_20.idText(v57.id)
			end
			local v60 = v57.n
			local v61 = tonumber(v60) or 1
			local v62 = math.floor(v61)
			local v63 = math.max(1, v62)
			table.insert(v51, ("%s x%d"):format(v59, v63))
		end
	end
	local v64 = p48.cos
	if type(v64) == "table" then
		for _, v65 in p48.cos do
			local v66
			if p50 then
				v66 = p50(v65)
			else
				v66 = nil
			end
			local v67 = v66 or v_u_20.idText(v65)
			table.insert(v51, v67)
		end
	end
	local v68 = p48.xp
	local v69 = tonumber(v68) or 0
	local v70 = math.floor(v69)
	if v70 > 0 then
		table.insert(v51, ("%d pass XP"):format(v70))
	end
	return v51
end
function v_u_20.boardSub(p71, p72) -- name: boardSub
	local v73 = tonumber(p71) or 0
	local v74 = math.floor(v73)
	local v75 = math.max(0, v74)
	local v76 = v75 == 1 and "1 member" or ("%d members"):format(v75)
	local v77 = tonumber(p72)
	if v77 ~= nil and (v77 == v77 and (v77 ~= (1 / 0) and v77 ~= (-1 / 0))) then
		local v78 = math.floor(v77)
		local v79 = math.max(0, v78)
		if tonumber(p71) ~= nil then
			v79 = math.min(v79, v75)
		end
		v76 = v76 .. (", %d active"):format(v79)
	end
	return v76
end
function v_u_20.agoText(p80) -- name: agoText
	-- upvalues: (copy) v_u_20
	local v81 = tonumber(p80) or 0
	local v82 = math.floor(v81)
	local v83 = math.max(0, v82)
	return v83 < 60 and "just now" or v_u_20.timeText(v83) .. " ago"
end
function v_u_20.timeText(p84) -- name: timeText
	local v85 = tonumber(p84) or 0
	local v86 = math.floor(v85)
	local v87 = v86 < 1 and 1 or v86
	if v87 >= 86400 then
		local v88 = v87 // 86400
		local v89 = v87 % 86400 // 3600
		if v89 > 0 then
			return ("%dd %dh"):format(v88, v89)
		else
			return ("%dd"):format(v88)
		end
	elseif v87 >= 3600 then
		local v90 = v87 // 3600
		local v91 = v87 % 3600 // 60
		if v91 > 0 then
			return ("%dh %dm"):format(v90, v91)
		else
			return ("%dh"):format(v90)
		end
	elseif v87 >= 60 then
		return ("%dm"):format(v87 // 60)
	else
		return ("%ds"):format(v87)
	end
end
v_u_20.rules = nil
function v_u_20.text(p92, p93) -- name: text
	-- upvalues: (copy) v_u_20
	local v_u_94 = type(p93) ~= "table" and {} or p93
	local v95 = type(p92) ~= "string" and "" or p92
	local v96 = nil
	local v97 = v_u_20.rules
	local v98
	if v97 then
		local v99 = v97.text
		if type(v99) == "function" then
			local v100 = v97.text
			local v101 = {
				["time"] = v_u_94.sec or (v_u_94.time or v_u_94.cooldownIn),
				["left"] = v_u_94.left
			}
			local v102
			v102, v98 = pcall(v100, v95, v101)
			if v102 and (type(v98) == "string" and v98 ~= "") then
				if v98 == v95 then
					v98 = v96
				end
			else
				v98 = v96
			end
		else
			v98 = v96
		end
	else
		v98 = v96
	end
	if v98 == nil then
		local v103 = v_u_20.TEXT[v95]
		if v103 == nil then
			return v_u_20.TEXT.BAD_ARGS
		end
		local v104 = string.gsub(v103, "{time}", function()
			-- upvalues: (ref) v_u_20, (copy) v_u_94
			return v_u_20.timeText(v_u_94.sec or (v_u_94.time or v_u_94.cooldownIn))
		end)
		v98 = string.gsub(v104, "{left}", function()
			-- upvalues: (copy) v_u_94
			local v105 = v_u_94.left
			local v106 = tonumber(v105) or 0
			local v107 = math.floor(v106)
			local v108 = math.max(0, v107)
			return tostring(v108)
		end)
	end
	if v95 == "ITEM_NOT_ALLOWED" then
		local v109 = v_u_94.text
		if type(v109) == "string" and v_u_94.text ~= "" then
			return v98 .. " " .. v_u_94.text
		end
	end
	if v95 == "CRITERIA" then
		local v110 = v_u_94.need
		if type(v110) == "number" then
			local v111 = v_u_94.have
			if type(v111) == "number" then
				return v98 .. (" It needs %d, you have %d."):format(v_u_94.need, v_u_94.have)
			end
		end
	end
	return v98
end
function v_u_20.reasonFor(p112) -- name: reasonFor
	-- upvalues: (copy) v_u_20
	local v113 = type(p112) ~= "table" and {} or p112
	local v114 = v113.data
	local v115 = type(v114) ~= "table" and {} or v113.data
	local v116 = v115.code
	if type(v116) == "string" and v_u_20.TEXT[v115.code] ~= nil then
		return v_u_20.text(v115.code, v115)
	else
		local v117 = v113.msg
		if type(v117) == "string" and v113.msg ~= "" then
			return v113.msg
		else
			return v_u_20.TEXT.BAD_ARGS
		end
	end
end
function v_u_20.answerText(p118, p119) -- name: answerText
	-- upvalues: (copy) v_u_20
	if p118 == "FULL" then
		return v_u_20.UI.ACCEPT_FULL
	else
		return v_u_20.text(p118, p119)
	end
end
function v_u_20.invRows(p120, p121) -- name: invRows
	-- upvalues: (copy) v_u_20
	local v122 = {}
	local v123
	if type(p120) == "table" then
		v123 = p120.inv
	else
		v123 = nil
	end
	local v124
	if type(v123) == "table" then
		v124 = v123.rows
	else
		v124 = nil
	end
	if type(v124) ~= "table" then
		return v122
	end
	local v125 = tonumber(p121) or 0
	for _, v126 in v124 do
		if type(v126) ~= "table" or v126.uid == nil then
			continue
		end
		local v127 = v126.k == "ok"
		local v128 = v126.ex
		local v129 = tonumber(v128) or 0
		local v130 = v126.name
		local v131
		if type(v130) == "string" and v126.name ~= "" then
			v131 = v126.name
		elseif v127 then
			v131 = v_u_20.UI.OK_NONAME
		else
			v131 = v_u_20.UI.INV_NONAME
		end
		local v132 = {}
		local v133 = v126.uid
		v132.uid = tostring(v133)
		v132.name = v131
		v132.k = v127 and "ok" or "invite"
		local v134 = v126.at
		v132.at = tonumber(v134) or 0
		v132.ex = v129
		local v135
		if v127 then
			v135 = v_u_20.UI.INV_SUB_OK
		else
			v135 = v_u_20.UI.INV_SUB_INV
		end
		local v136 = v_u_20.timeText
		local v137 = v129 - v125
		v132.sub = v135:format(v136((math.max(1, v137))))
		table.insert(v122, v132)
	end
	table.sort(v122, function(p138, p139)
		if p138.at == p139.at then
			return p138.uid < p139.uid
		else
			return p138.at < p139.at
		end
	end)
	return v122
end
function v_u_20.invSummary(p140) -- name: invSummary
	-- upvalues: (copy) v_u_20
	local v141 = {}
	if type(p140) ~= "table" then
		return v141
	end
	local v142 = p140.slots
	if type(v142) == "table" then
		local v143 = v142.count
		local v144 = tonumber(v143) or 0
		local v145 = math.floor(v144)
		local v146 = v142.cap
		local v147 = tonumber(v146) or 0
		local v148 = math.floor(v147)
		local v149 = v142.ok
		local v150 = tonumber(v149) or 0
		local v151 = math.floor(v150)
		v141.count = v145
		v141.cap = v148
		v141.ok = v151
		v141.slots = v_u_20.UI.SLOTS:format(v141.count, v141.cap)
		if v141.ok > 0 then
			v141.okHead = v_u_20.UI.OK_HEAD:format(v141.ok)
		end
	end
	local v152 = p140.inv
	if type(v152) == "table" then
		local v153 = v152.open
		local v154 = tonumber(v153) or 0
		local v155 = math.floor(v154)
		local v156 = v152.max
		local v157 = tonumber(v156) or 0
		local v158 = math.floor(v157)
		v141.open = v155
		v141.max = v158
		v141.invHead = v_u_20.UI.INV_HEAD:format(v141.open, v141.max)
	end
	return v141
end
function v_u_20.cancelOldestText(p159) -- name: cancelOldestText
	-- upvalues: (copy) v_u_20
	local v160 = tonumber(p159) or 0
	local v161 = math.floor(v160)
	return v161 < 1 and "CANCEL OLDEST" or v_u_20.UI.CANCEL_OLDEST:format(v161)
end
v_u_20.CANCEL_MAX = 5
function v_u_20.oldestCancel(p162, p163) -- name: oldestCancel
	-- upvalues: (copy) v_u_20
	local v164 = {}
	if type(p162) ~= "table" then
		return v164
	end
	local v165 = v_u_20.CANCEL_MAX
	local v166 = tonumber(p163) or v_u_20.CANCEL_MAX
	local v167 = math.floor(v166)
	local v168 = math.min(v165, v167)
	local v169 = math.max(0, v168)
	local v170 = {}
	for _, v171 in p162 do
		if type(v171) ~= "table" or (v171.uid == nil or v171.k == "ok") then
			continue
		end
		table.insert(v170, v171)
	end
	table.sort(v170, function(p172, p173)
		local v174 = p172.at
		local v175 = tonumber(v174) or 0
		local v176 = p173.at
		local v177 = tonumber(v176) or 0
		if v175 ~= v177 then
			return v175 < v177
		end
		local v178 = p172.uid
		local v179 = tostring(v178)
		local v180 = p173.uid
		return v179 < tostring(v180)
	end)
	local v181 = #v170
	for v182 = 1, math.min(v169, v181) do
		local v183 = v170[v182].uid
		local v184 = tostring(v183)
		table.insert(v164, v184)
	end
	return v164
end
v_u_20.RANKS = {
	"owner",
	"officer",
	"veteran",
	"member",
	"recruit"
}
local v_u_185 = {
	["owner"] = 0,
	["officer"] = 1,
	["veteran"] = 2,
	["member"] = 3,
	["recruit"] = 4
}
v_u_20.PERMS = {
	"invite",
	"handleRequests",
	"kick",
	"promote",
	"editSettings",
	"deposit",
	"withdraw",
	"viewLog",
	"useShop"
}
v_u_20.PERM_TEXT = {
	["invite"] = "Invite players",
	["handleRequests"] = "Answer join requests",
	["kick"] = "Remove members",
	["promote"] = "Promote and demote",
	["editSettings"] = "Change clan settings",
	["deposit"] = "Add to the clan stash",
	["withdraw"] = "Take from the clan stash",
	["viewLog"] = "See the clan log",
	["useShop"] = "Use the clan shop"
}
function v_u_20.rankOrder(p186) -- name: rankOrder
	-- upvalues: (copy) v_u_185
	return v_u_185[p186] or 99
end
function v_u_20.rankLess(p187, p188) -- name: rankLess
	-- upvalues: (copy) v_u_20
	return v_u_20.rankOrder(p187) < v_u_20.rankOrder(p188)
end
function v_u_20.can(p189, p190) -- name: can
	if type(p189) ~= "table" then
		return false
	end
	if p189.rank == "owner" then
		return true
	end
	local v191 = p189.perm
	local v192
	if type(v191) == "table" then
		v192 = p189.perm[p190] == true
	else
		v192 = false
	end
	return v192
end
function v_u_20.canManage(p193) -- name: canManage
	-- upvalues: (copy) v_u_20
	if type(p193) ~= "table" then
		return false
	end
	if p193.rank == "owner" then
		return true
	end
	for _, v194 in {
		"invite",
		"handleRequests",
		"kick",
		"promote",
		"editSettings"
	} do
		if not v_u_20.can(p193, v194) then
			continue
		end
		return true
	end
	return false
end
function v_u_20.subTabs(p195, p196, p197) -- name: subTabs
	-- upvalues: (copy) v_u_20
	local v198 = type(p195) ~= "table" and {} or p195
	if v198.has ~= true then
		local v199 = tonumber(p196) or 0
		local v200 = math.floor(v199)
		return {
			{
				["id"] = "browse",
				["text"] = "Browse"
			},
			{
				["id"] = "invites",
				["text"] = nil,
				["text"] = v200 <= 0 and "Invites" or ("Invites %d"):format((math.min(v200, 99)))
			},
			{
				["id"] = "found",
				["text"] = "Found"
			}
		}
	end
	local v201 = {
		{
			["id"] = "overview",
			["text"] = "Overview"
		},
		{
			["id"] = "members",
			["text"] = "Members"
		},
		{
			["id"] = "stash",
			["text"] = "Stash"
		}
	}
	if p197 ~= false then
		table.insert(v201, {
			["id"] = "shop",
			["text"] = "Shop"
		})
	end
	table.insert(v201, {
		["id"] = "board",
		["text"] = "Board"
	})
	local v202 = v198.clan
	if v_u_20.can(v202, "viewLog") then
		table.insert(v201, {
			["id"] = "log",
			["text"] = "Log"
		})
	end
	if v_u_20.canManage(v202) then
		table.insert(v201, {
			["id"] = "manage",
			["text"] = "Manage"
		})
	end
	return v201
end
function v_u_20.sameTabs(p203, p204) -- name: sameTabs
	if type(p203) ~= "table" or (type(p204) ~= "table" or #p203 ~= #p204) then
		return false
	end
	for v205, v206 in p203 do
		if v206.id == p204[v205].id and v206.text == p204[v205].text then
			continue
		end
		return false
	end
	return true
end
function v_u_20.rankName(p207, p208) -- name: rankName
	local v209
	if type(p207) == "table" then
		v209 = p207.ranks
	else
		v209 = nil
	end
	if type(v209) == "table" then
		for _, v210 in v209 do
			if type(v210) ~= "table" or v210.id ~= p208 then
				continue
			end
			local v211 = v210.name
			if type(v211) ~= "string" or v210.name == "" then
				continue
			end
			return v210.name
		end
	end
	return p208 == "owner" and "OWNER" or string.upper((tostring(p208 or "")))
end
function v_u_20.sortMembers(p212) -- name: sortMembers
	-- upvalues: (copy) v_u_20
	local v213 = {}
	if type(p212) ~= "table" then
		return v213
	end
	for _, v214 in p212 do
		if type(v214) ~= "table" then
			continue
		end
		table.insert(v213, v214)
	end
	table.sort(v213, function(p215, p216)
		-- upvalues: (ref) v_u_20
		local v217 = v_u_20.rankOrder(p215.rank)
		local v218 = v_u_20.rankOrder(p216.rank)
		if v217 ~= v218 then
			return v217 < v218
		end
		local v219 = p215.pts
		local v220 = tonumber(v219) or 0
		local v221 = p216.pts
		local v222 = tonumber(v221) or 0
		if v220 ~= v222 then
			return v222 < v220
		end
		local v223 = string.lower
		local v224 = p215.name or ""
		local v225 = v223((tostring(v224)))
		local v226 = string.lower
		local v227 = p216.name or ""
		return v225 < v226((tostring(v227)))
	end)
	return v213
end
function v_u_20.memberActions(p228, p229, p230) -- name: memberActions
	-- upvalues: (copy) v_u_20
	local v231 = {
		["promote"] = nil,
		["demote"] = nil,
		["kick"] = false,
		["ranks"] = nil,
		["ranks"] = {}
	}
	if type(p228) ~= "table" or type(p229) ~= "table" then
		return v231
	end
	local v232 = v_u_20.rankOrder(p228.rank)
	local v233 = v_u_20.rankOrder(p229.rank)
	local v234 = p229.uid
	if tostring(v234) == tostring(p230) or (p229.rank == "owner" or v233 <= v232) then
		return v231
	end
	local v235 = {
		["promote"] = nil,
		["demote"] = nil,
		["kick"] = false,
		["ranks"] = nil,
		["ranks"] = {}
	}
	if v_u_20.can(p228, "kick") then
		v235.kick = true
	end
	if v_u_20.can(p228, "promote") then
		for _, v236 in v_u_20.RANKS do
			if v236 == "owner" or v232 >= v_u_20.rankOrder(v236) then
				continue
			end
			local v237 = v235.ranks
			table.insert(v237, v236)
		end
		local v238 = v_u_20.RANKS[v233]
		if v238 and (v238 ~= "owner" and v232 < v_u_20.rankOrder(v238)) then
			v235.promote = v238
		end
		local v239 = v_u_20.RANKS[v233 + 2]
		if v239 and v232 < v_u_20.rankOrder(v239) then
			v235.demote = v239
		end
	end
	return v235
end
function v_u_20.critText(p240, p241) -- name: critText
	local v242 = tonumber(p240) or 0
	local v243 = math.floor(v242)
	local v244 = math.max(0, v243)
	local v245 = tonumber(p241) or 0
	local v246 = math.floor(v245)
	local v247 = math.max(0, v246)
	if v244 == 0 and v247 == 0 then
		return "No requirements"
	end
	local v248 = {}
	if v244 > 0 then
		local v249 = v244 == 1 and "1 raid" or ("%d raids"):format(v244)
		table.insert(v248, v249)
	end
	if v247 > 0 then
		table.insert(v248, ("%d%%"):format(v247))
	end
	return table.concat(v248, ", ")
end
function v_u_20.mineFromStats(p250) -- name: mineFromStats
	if type(p250) ~= "table" then
		return nil, nil
	end
	local v251 = p250.raids
	local v252 = tonumber(v251)
	if v252 == nil then
		return nil, nil
	end
	local v253 = p250.extracts
	local v254 = tonumber(v253) or 0
	local v255 = math.floor(v252)
	if v252 <= 0 then
		return v255, 0
	end
	local v256 = 100 * v254 / v252
	return v255, math.floor(v256)
end
function v_u_20.needText(p257, p258, p259) -- name: needText
	local v260
	if p257 then
		v260 = p257.minRaids
	else
		v260 = p257
	end
	local v261 = tonumber(v260) or 0
	local v262 = math.floor(v261)
	if p257 then
		p257 = p257.minPct
	end
	local v263 = tonumber(p257) or 0
	local v264 = math.floor(v263)
	local v265 = tonumber(p258)
	local v266 = tonumber(p259)
	if v262 > 0 and (v265 == nil or v265 < v262) then
		return ("Needs %d raids"):format(v262)
	elseif v264 > 0 and (v266 == nil or v266 < v264) then
		return ("Needs %d percent extraction rate"):format(v264)
	elseif v262 > 0 then
		return ("Needs %d raids"):format(v262)
	else
		return v264 <= 0 and "" or ("Needs %d percent extraction rate"):format(v264)
	end
end
function v_u_20.rowAction(p267, p268) -- name: rowAction
	if type(p267) ~= "table" then
		return "none"
	end
	if p267.mine == true then
		return "none"
	end
	local v269 = type(p268) ~= "table" and {} or p268
	local v270 = v269.myRequests
	local v271 = p267.id
	local v272
	if type(v270) == "table" then
		for _, v273 in v270 do
			if v273 ~= v271 then
				continue
			end
			v272 = true
		end
		v272 = false
	else
		v272 = false
	end
	if v272 then
		return "cancel"
	end
	local v274 = false
	local v275 = v269.invites
	if type(v275) == "table" then
		for _, v276 in v269.invites do
			if type(v276) ~= "table" or v276.cid ~= p267.id then
				continue
			end
			v274 = true
		end
	end
	local v277 = p267.count
	local v278 = tonumber(v277) or 0
	local v279 = p267.cap
	return (tonumber(v279) or 30) <= v278 and "full" or (v274 and "join" or (p267.fits == false and "locked" or (p267.mode == "open" and "join" or (p267.mode == "request" and "request" or "none"))))
end
v_u_20.ROW_BUTTON = {
	["join"] = "JOIN",
	["request"] = "REQUEST",
	["cancel"] = "CANCEL REQUEST",
	["locked"] = "LOCKED",
	["full"] = "FULL"
}
v_u_20.MODE_TEXT = {
	["open"] = "OPEN",
	["request"] = "ON REQUEST",
	["private"] = "PRIVATE"
}
v_u_20.MODE_HELP = {
	["open"] = "Anyone who meets the requirements can join.",
	["request"] = "Players ask to join. A member with the right answers.",
	["private"] = "Only invited players can join."
}
v_u_20.SORTS = {
	{
		["id"] = "members",
		["text"] = "Most members"
	},
	{
		["id"] = "week",
		["text"] = "Top last week"
	},
	{
		["id"] = "new",
		["text"] = "Newest"
	},
	{
		["id"] = "fit",
		["text"] = "Fits me"
	}
}
function v_u_20.listArgs(p280, p281, p282, p283) -- name: listArgs
	-- upvalues: (copy) v_u_20
	local v284 = {}
	local v285
	if type(p280) == "string" then
		local v286 = v_u_20.SEARCH_MAX
		v285 = string.sub(p280, 1, v286)
	else
		v285 = ""
	end
	local v287 = string.gsub(v285, "[%c]", "")
	if v287 ~= "" then
		v284.q = v287
	end
	local v288 = false
	for _, v289 in v_u_20.SORTS do
		if v289.id ~= p281 then
			continue
		end
		v288 = true
	end
	v284.sort = not v288 and "members" or p281
	local v290 = type(p282) ~= "table" and {} or p282
	if v290.open and not v290.request then
		v284.mode = "open"
	elseif v290.request and not v290.open then
		v284.mode = "request"
	end
	if p281 == "fit" then
		v284.fit = true
	end
	local v291 = tonumber(p283) or 1
	local v292 = math.floor(v291)
	v284.page = math.max(1, v292)
	return v284
end
function v_u_20.normTag(p293) -- name: normTag
	-- upvalues: (copy) v_u_20
	local v294 = string.upper(type(p293) ~= "string" and "" or p293)
	local v295 = string.gsub(v294, "[^A-Z0-9]", "")
	local v296 = v_u_20.TAG_MAX
	return string.sub(v295, 1, v296)
end
function v_u_20.tagOk(p297) -- name: tagOk
	-- upvalues: (copy) v_u_20
	local v298
	if type(p297) == "string" and (#p297 >= v_u_20.TAG_MIN and (#p297 <= v_u_20.TAG_MAX and string.find(p297, "^[A-Z0-9]+$") ~= nil)) then
		v298 = string.find(p297, "[A-Z]") ~= nil
	else
		v298 = false
	end
	return v298
end
function v_u_20.normName(p299) -- name: normName
	-- upvalues: (copy) v_u_20
	local v300 = type(p299) ~= "string" and "" or p299
	local v301 = string.gsub(v300, "[^%w ]", "")
	local v302 = string.gsub(v301, " +", " ")
	local v303 = string.gsub(v302, "^ ", "")
	local v304 = v_u_20.NAME_MAX
	return string.sub(v303, 1, v304)
end
function v_u_20.nameOk(p305) -- name: nameOk
	-- upvalues: (copy) v_u_20
	local v306
	if type(p305) == "string" and (#p305 >= v_u_20.NAME_MIN and (#p305 <= v_u_20.NAME_MAX and (string.find(p305, "^[%w]+[%w ]*$") ~= nil and string.find(p305, "  ", 1, true) == nil))) then
		v306 = string.sub(p305, -1) ~= " "
	else
		v306 = false
	end
	return v306
end
function v_u_20.descOk(p307) -- name: descOk
	-- upvalues: (copy) v_u_20
	local v308
	if type(p307) == "string" and #p307 <= v_u_20.DESC_MAX then
		v308 = string.find(p307, "[%c]") == nil
	else
		v308 = false
	end
	return v308
end
function v_u_20.cleanDesc(p309) -- name: cleanDesc
	-- upvalues: (copy) v_u_20
	local v310 = type(p309) ~= "string" and "" or p309
	local v311 = string.gsub(v310, "[%c]", " ")
	local v312 = v_u_20.DESC_MAX
	return string.sub(v311, 1, v312)
end
function v_u_20.foundField(p313, p314) -- name: foundField
	local v315 = type(p314) ~= "table" and {} or p314
	if v315.field == "tag" or v315.field == "name" then
		return v315.field
	else
		return (p313 == "TAG_BAD" or p313 == "TAG_TAKEN") and "tag" or ((p313 == "NAME_BAD" or p313 == "NAME_TAKEN") and "name" or nil)
	end
end
function v_u_20.foundState(p316) -- name: foundState
	-- upvalues: (copy) v_u_20
	local v317 = type(p316) ~= "table" and {} or p316
	if v317.passOwned == true or v317.canFound == true then
		if v317.founderHeld == true then
			return "held", v_u_20.TEXT.FOUNDER_HELD
		else
			local v318 = v317.foundIn
			local v319 = tonumber(v318) or 0
			if v319 > 0 then
				return "cooldown", v_u_20.text("COOLDOWN", {
					["sec"] = v319
				})
			else
				return "ok", ""
			end
		end
	else
		return "nopass", v_u_20.UI.NO_PASS
	end
end
function v_u_20.limitText(p320) -- name: limitText
	-- upvalues: (copy) v_u_20
	if type(p320) ~= "table" or p320.canWithdraw == false then
		return v_u_20.UI.STASH_NO_TAKE
	end
	local v321 = p320.perDay
	local v322 = tonumber(v321) or 0
	local v323 = math.floor(v322)
	if v323 <= 0 then
		return "Unlimited"
	end
	local v324 = p320.used
	local v325 = tonumber(v324) or 0
	local v326 = math.floor(v325)
	local v327 = math.max(0, v326)
	return ("%d of %d stacks today"):format(math.min(v327, v323), v323)
end
function v_u_20.stashStatus(p328) -- name: stashStatus
	-- upvalues: (copy) v_u_20
	local v329 = type(p328) ~= "table" and {} or p328
	local v330 = v329.view
	if type(v330) ~= "table" then
		return v329.failed == "retry" and {
			["id"] = "error",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "warn",
			["text"] = v_u_20.UI.LOAD_RETRY
		} or (v329.failed == "gave_up" and {
			["id"] = "error",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "danger",
			["text"] = v_u_20.UI.LOAD_FAIL
		} or {
			["id"] = "loading",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "info",
			["text"] = v_u_20.UI.LOADING
		})
	end
	if v330.closed == true then
		return {
			["id"] = "closed",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "warn",
			["text"] = v_u_20.UI.STASH_CLOSED
		}
	end
	local v331
	if v329.sending == true then
		v331 = true
	else
		local v332 = v330.tx
		if type(v332) == "table" then
			v331 = true
		else
			local v333 = v329.stateTx
			if type(v333) == "table" then
				v331 = v329.stateTx.kind == "stash"
			else
				v331 = false
			end
		end
	end
	if v331 then
		local v334 = v329.pollSec
		return (tonumber(v334) or 0) >= v_u_20.POLL_MAX_SEC and {
			["id"] = "completing_long",
			["text"] = nil,
			["lock"] = false,
			["kind"] = "info",
			["text"] = v_u_20.UI.COMPLETING_LONG
		} or {
			["id"] = "completing",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "info",
			["text"] = v_u_20.UI.COMPLETING
		}
	end
	if v330.stashReady == false then
		return {
			["id"] = "syncing",
			["text"] = nil,
			["lock"] = true,
			["kind"] = "info",
			["text"] = v_u_20.UI.SYNCING
		}
	end
	local v335 = v330.rows
	return type(v335) == "table" and #v335 ~= 0 and {
		["id"] = "ok",
		["text"] = "",
		["lock"] = false,
		["kind"] = "info"
	} or {
		["id"] = "empty",
		["text"] = nil,
		["lock"] = false,
		["kind"] = "info",
		["text"] = v_u_20.stashEmptyText(v330)
	}
end
function v_u_20.stashEmptyText(p336) -- name: stashEmptyText
	-- upvalues: (copy) v_u_20
	if type(p336) == "table" and p336.wiped == true then
		return v_u_20.UI.STASH_WIPED
	else
		return v_u_20.UI.STASH_EMPTY
	end
end
function v_u_20.eligibleKey(p337) -- name: eligibleKey
	return type(p337) ~= "string" and "" or p337
end
local v_u_338 = {}
v_u_338.__index = v_u_338
function v_u_20.newSel(p339) -- name: newSel
	-- upvalues: (copy) v_u_20, (copy) v_u_338
	local v340 = {
		["n"] = {},
		["order"] = {},
		["max"] = p339 or v_u_20.LINES_MAX
	}
	local v341 = v_u_338
	return setmetatable(v340, v341)
end
v_u_20.Sel = v_u_338
function v_u_338.count(p342) -- name: count
	return #p342.order
end
function v_u_338.has(p343, p344) -- name: has
	return p343.n[p344] ~= nil
end
function v_u_338.get(p345, p346) -- name: get
	return p345.n[p346] or 0
end
function v_u_338.toggle(p347, p348, p349) -- name: toggle
	if p347.n[p348] ~= nil then
		p347.n[p348] = nil
		local v350 = table.find(p347.order, p348)
		if v350 then
			table.remove(p347.order, v350)
		end
		return true
	end
	if #p347.order >= p347.max or p349 < 1 then
		return false
	end
	p347.n[p348] = 1
	local v351 = p347.order
	table.insert(v351, p348)
	return true
end
function v_u_338.step(p352, p353, p354, p355) -- name: step
	local v356 = p352.n[p353]
	if v356 == nil then
		if p354 <= 0 or (#p352.order >= p352.max or p355 < 1) then
			return 0
		end
		p352.n[p353] = 1
		local v357 = p352.order
		table.insert(v357, p353)
		return 1
	else
		local v358 = v356 + p354
		if v358 < 1 then
			p352.n[p353] = nil
			local v359 = table.find(p352.order, p353)
			if v359 then
				table.remove(p352.order, v359)
			end
			return 0
		else
			local v360 = p352.n
			local v361 = math.max(1, p355)
			v360[p353] = math.min(v358, v361)
			return p352.n[p353]
		end
	end
end
function v_u_338.all(p362, p363, p364) -- name: all
	if p364 < 1 then
		return 0
	end
	if p362.n[p363] == nil then
		if #p362.order >= p362.max then
			return 0
		end
		local v365 = p362.order
		table.insert(v365, p363)
	end
	p362.n[p363] = p364
	return p364
end
function v_u_338.clear(p366) -- name: clear
	p366.n = {}
	p366.order = {}
end
function v_u_338.prune(p367, p368) -- name: prune
	for _, v369 in table.clone(p367.order) do
		local v370 = p368(v369)
		if v370 < 1 then
			p367.n[v369] = nil
			local v371 = table.find(p367.order, v369)
			if not v371 then
				continue
			end
			table.remove(p367.order, v371)
		else
			if v370 >= p367.n[v369] then
				continue
			end
			p367.n[v369] = v370
		end
	end
end
function v_u_338.lines(p372, p373) -- name: lines
	local v374 = {}
	for _, v375 in p372.order do
		local v376 = {
			["n"] = p372.n[v375],
			[p373] = v375
		}
		table.insert(v374, v376)
	end
	return v374
end
function v_u_20.stacksOf(p377) -- name: stacksOf
	return not p377 and 0 or p377:count()
end
return v_u_20