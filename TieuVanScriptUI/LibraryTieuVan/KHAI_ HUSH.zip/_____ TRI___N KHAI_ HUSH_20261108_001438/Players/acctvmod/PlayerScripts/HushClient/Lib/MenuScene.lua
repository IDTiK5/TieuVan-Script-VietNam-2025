-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuScene

local v_u_1 = game:GetService("Workspace")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("CollectionService")
local v_u_4 = {}
v_u_4.__index = v_u_4
local v_u_5 = math.rad
local v_u_6 = nil
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_8 = 0
local v_u_9 = game:GetService("ContentProvider")
local v_u_10 = {
	"Head",
	"UpperTorso",
	"LowerTorso",
	"LeftUpperArm",
	"LeftLowerArm",
	"LeftHand",
	"RightUpperArm",
	"RightLowerArm",
	"RightHand",
	"LeftUpperLeg",
	"LeftLowerLeg",
	"LeftFoot",
	"RightUpperLeg",
	"RightLowerLeg",
	"RightFoot"
}
v_u_4.assetGrace = 5
v_u_4.arriveGrace = 20
local v_u_11 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_12 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_13 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_14 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_15 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_16 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("AvatarTemplate"))
function v_u_4.fetchStatus(p_u_17)
	-- upvalues: (copy) v_u_9
	local function v18()
		-- upvalues: (ref) v_u_9, (copy) p_u_17
		return v_u_9:GetAssetFetchStatus(p_u_17)
	end
	local v19, v20 = pcall(v18)
	return not v19 and "None" or v20.Name
end
function v_u_4.preloadAsync(p21, p22)
	-- upvalues: (copy) v_u_9
	v_u_9:PreloadAsync(p21, p22)
end
function v_u_4.avatarComplete(p23) -- name: avatarComplete
	-- upvalues: (copy) v_u_10
	if not (p23 and p23:IsA("Model")) then
		return false, "no model"
	end
	local v24 = p23:FindFirstChild("HumanoidRootPart")
	if not (v24 and v24:IsA("BasePart")) then
		return false, "no HumanoidRootPart"
	end
	if not p23:FindFirstChildOfClass("Humanoid") then
		return false, "no Humanoid"
	end
	for _, v25 in v_u_10 do
		local v26 = p23:FindFirstChild(v25)
		if v26 and v26:IsA("BasePart") then
			continue
		end
		return false, "no " .. v25
	end
	return true, nil
end
function v_u_4.heroIntact(p27) -- name: heroIntact
	-- upvalues: (copy) v_u_4, (copy) v_u_10
	if not (p27 and p27.Parent) then
		return false, "gone"
	end
	local v28, v29 = v_u_4.avatarComplete(p27)
	if not v28 then
		return false, v29
	end
	local v30 = p27:FindFirstChild("HumanoidRootPart")
	for _, v31 in v_u_10 do
		if (p27:FindFirstChild(v31).Position - v30.Position).Magnitude <= 12 then
			continue
		end
		return false, v31 .. " away"
	end
	return true, nil
end
function v_u_4.avatarLoad(p32) -- name: avatarLoad
	-- upvalues: (copy) v_u_4, (copy) v_u_11
	local v_u_33 = {}
	local v_u_34 = {}
	local v35 = {}
	for _, v36 in p32:GetChildren() do
		if not v36:IsA("MeshPart") then
			continue
		end
		table.insert(v_u_33, v36)
		for _, v37 in { v36.MeshId, v36.TextureID } do
			if v37 == "" or v_u_34[v37] then
				continue
			end
			v_u_34[v37] = true
			table.insert(v35, v37)
		end
	end
	local v38 = 0
	local v39 = 0
	for _, v40 in v35 do
		local v41 = v_u_4.fetchStatus(v40)
		if v41 == "Failure" or v41 == "TimedOut" then
			v38 = v38 + 1
		else
			if v41 == "Success" then
				continue
			end
			v39 = v39 + 1
		end
	end
	if v39 == 0 then
		return "ready", v38
	else
		local v_u_42 = v_u_11[p32]
		if not v_u_42 then
			v_u_42 = {
				["at"] = nil,
				["done"] = false,
				["fails"] = 0,
				["at"] = os.clock()
			}
			v_u_11[p32] = v_u_42
			task.spawn(function()
				-- upvalues: (ref) v_u_4, (copy) v_u_33, (copy) v_u_34, (copy) v_u_42
				local v_u_43 = 0
				local function v46()
					-- upvalues: (ref) v_u_4, (ref) v_u_33, (ref) v_u_34, (ref) v_u_43
					v_u_4.preloadAsync(v_u_33, function(p44, p45)
						-- upvalues: (ref) v_u_34, (ref) v_u_43
						if v_u_34[p44] and (p45 == Enum.AssetFetchStatus.Failure or p45 == Enum.AssetFetchStatus.TimedOut) then
							v_u_43 = v_u_43 + 1
						end
					end)
				end
				pcall(v46)
				v_u_42.fails = v_u_43
				v_u_42.done = true
			end)
		end
		if v_u_42.done then
			return "ready", v_u_42.fails
		else
			return "loading", v38
		end
	end
end
function v_u_4.avatarSource(p47) -- name: avatarSource
	-- upvalues: (copy) v_u_12, (copy) v_u_4, (copy) v_u_16, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15
	if not (p47 and (p47:IsA("Model") and p47:FindFirstChild("HumanoidRootPart"))) then
		return nil, nil
	end
	local v48 = os.clock()
	local v49 = v_u_12[p47]
	if not v49 then
		v_u_12[p47] = v48
		v49 = v48
	end
	local v50 = v48 - v49 >= v_u_4.arriveGrace
	local v51, v52 = v_u_16.ready(p47, v50)
	if not v51 then
		return nil, (v50 and "incomplete: " or "arriving: ") .. tostring(v52)
	end
	local v53 = v_u_13[p47]
	if not v53 then
		v_u_13[p47] = v48
		v53 = v48
	end
	if not v_u_14[p47] then
		if v48 - v53 >= v_u_4.assetGrace then
			v_u_14[p47] = true
			local v54, v55 = v_u_4.avatarLoad(p47)
			v_u_15[p47] = v54 == "loading" and "late" or (v55 <= 0 and "ok" or "failed:" .. tostring(v55))
			if v54 == "loading" then
				local v56 = warn
				local v57 = v_u_4.assetGrace
				v56("[MenuScene] avatar assets still loading after " .. tostring(v57) .. " s, showing the avatar anyway")
			end
		else
			local v58, v59 = v_u_4.avatarLoad(p47)
			if v58 == "loading" then
				return nil, "loading"
			end
			v_u_14[p47] = true
			v_u_15[p47] = v59 <= 0 and "ok" or "failed:" .. tostring(v59)
		end
	end
	return p47, nil
end
function v_u_4.assetNote(p60) -- name: assetNote
	-- upvalues: (copy) v_u_15
	if p60 then
		return v_u_15[p60]
	else
		return nil
	end
end
local v_u_61 = {
	["asphalt"] = Color3.fromHex("#2B2D30"),
	["concrete"] = Color3.fromHex("#6B6E70"),
	["curb"] = Color3.fromHex("#5A5D60"),
	["grass"] = Color3.fromHex("#4F5A3A"),
	["dirt"] = Color3.fromHex("#4A3F33"),
	["metal"] = Color3.fromHex("#3B3F44"),
	["sodium"] = Color3.fromHex("#FFB36B"),
	["tape"] = Color3.fromHex("#D9B23A"),
	["silhouette"] = Color3.fromHex("#1B1E23"),
	["silhouette2"] = Color3.fromHex("#23272D"),
	["window"] = Color3.fromHex("#FFB36B"),
	["paint"] = Color3.fromHex("#B8B2A0"),
	["puddle"] = Color3.fromHex("#14171B"),
	["fire"] = Color3.fromHex("#FF7A2E")
}
local v_u_62 = {
	{
		["pos"] = Vector3.new(3.8, 0, -0.9),
		["yaw"] = -0.3141592653589793,
		["phase"] = 1.7,
		["mirror"] = true
	},
	{
		["pos"] = Vector3.new(-2.9, 0, -2.3),
		["yaw"] = -0.10471975511965978,
		["phase"] = 3.9,
		["mirror"] = false
	},
	{
		["pos"] = Vector3.new(7.5, 0, -1.7),
		["yaw"] = -0.4886921905584123,
		["phase"] = 5.3,
		["mirror"] = false
	}
}
local v_u_63 = #v_u_62
local function v_u_73(p64, p65, p66, p67, p68, p69, p70) -- name: part
	local v71 = p70 or {}
	local v72 = Instance.new("Part")
	v72.Name = p65
	v72.Anchored = true
	v72.CanCollide = false
	v72.CanTouch = false
	v72.CanQuery = v71.query == true
	v72.CastShadow = v71.shadow ~= false
	v72.Size = p66
	v72.CFrame = p67
	v72.Color = p68
	v72.Material = p69
	v72.TopSurface = Enum.SurfaceType.Smooth
	v72.BottomSurface = Enum.SurfaceType.Smooth
	if v71.shape then
		v72.Shape = v71.shape
	end
	if v71.t then
		v72.Transparency = v71.t
	end
	if v71.refl then
		v72.Reflectance = v71.refl
	end
	v72.Parent = p64
	return v72
end
local function v_u_77(p74, p75) -- name: prep
	for _, v76 in p74:GetDescendants() do
		if v76:IsA("BasePart") then
			v76.Anchored = p75
			v76.CanCollide = false
			v76.CanTouch = false
			v76.CanQuery = false
			if p75 then
				continue
			end
			v76.Massless = true
		elseif v76:IsA("Script") or v76:IsA("LocalScript") then
			v76:Destroy()
		else
			if not v76:IsA("ProximityPrompt") then
				continue
			end
			v76:Destroy()
		end
	end
end
local function v_u_92(p78) -- name: bodyBottom
	local v79 = (1 / 0)
	for _, v80 in p78:GetDescendants() do
		if not v80:IsA("BasePart") or (v80.Name == "HumanoidRootPart" or (v80.Transparency >= 0.99 or v80.Parent ~= p78)) then
			continue
		end
		local v81 = v80.CFrame
		local v82 = v80.Size
		local v83 = v81.RightVector.Y
		local v84 = math.abs(v83) * v82.X
		local v85 = v81.UpVector.Y
		local v86 = v84 + math.abs(v85) * v82.Y
		local v87 = v81.LookVector.Y
		local v88 = 0.5 * (v86 + math.abs(v87) * v82.Z)
		local v89 = v81.Position.Y - v88
		v79 = math.min(v79, v89)
	end
	if v79 ~= (1 / 0) then
		return v79
	end
	local v90, v91 = p78:GetBoundingBox()
	return v90.Position.Y - v91.Y / 2
end
local function v_u_102(p93, p94, p95, p96) -- name: placeOnGround
	if p93:IsA("Model") then
		p93:PivotTo(CFrame.new(p94) * CFrame.Angles(0, p95, 0) * (p96 or CFrame.identity))
		local v97, v98 = p93:GetBoundingBox()
		local v99 = v97.Position.Y - v98.Y / 2
		local v100 = p93:GetPivot()
		local v101 = p94.Y - v99
		p93:PivotTo(v100 + Vector3.new(0, v101, 0))
	end
end
local function v_u_116(p103) -- name: prober
	-- upvalues: (copy) v_u_1
	local v104 = {}
	local v_u_105 = {}
	local v106 = p103:GetDescendants()
	if p103:IsA("BasePart") then
		table.insert(v106, p103)
	end
	for _, v107 in v106 do
		if not v107:IsA("BasePart") or v107.Transparency >= 0.9 then
			continue
		end
		table.insert(v104, v107)
		v_u_105[v107] = v107.CanQuery
		v107.CanQuery = true
	end
	local v_u_108 = RaycastParams.new()
	v_u_108.FilterType = Enum.RaycastFilterType.Include
	v_u_108.FilterDescendantsInstances = v104
	return function(p_u_109, p_u_110) -- name: cast
		-- upvalues: (ref) v_u_1, (copy) v_u_108
		local function v111()
			-- upvalues: (ref) v_u_1, (copy) p_u_109, (copy) p_u_110, (ref) v_u_108
			return v_u_1:Raycast(p_u_109, p_u_110, v_u_108)
		end
		local v112, v113 = pcall(v111)
		if v112 then
			return v113
		else
			return nil
		end
	end, function() -- name: done
		-- upvalues: (copy) v_u_105
		for v114, v115 in v_u_105 do
			v114.CanQuery = v115
		end
	end
end
local function v_u_141(p117, p118, p119, p120, p121, p122) -- name: lens
	-- upvalues: (copy) v_u_73
	local v123
	if p122 then
		v123 = Enum.PartType.Cylinder
	else
		v123 = nil
	end
	local v124
	if p122 then
		v124 = CFrame.Angles(0, 1.5707963267948966, 0)
	else
		v124 = CFrame.identity
	end
	local v125 = v_u_73
	local v126 = p118 .. "Lens"
	local v127
	if p122 then
		local v128 = p119.Z
		local v129 = p119.Y
		local v130 = p119.Y
		v127 = Vector3.new(v128, v129, v130)
	else
		v127 = p119
	end
	local v131 = v125(p117, v126, v127, p120 * v124, p121:Lerp(Color3.new(0, 0, 0), 0.2), Enum.Material.Glass, {
		["shadow"] = false,
		["t"] = 0.3,
		["refl"] = 0.08,
		["shape"] = nil,
		["shape"] = v123
	})
	local v132 = v_u_73
	local v133 = p118 .. "Core"
	local v134 = p119.X * 0.72
	local v135 = p119.Y * 0.55
	local v136 = p119.Z * 0.4
	local v137 = Vector3.new(v134, v135, v136)
	if p122 then
		local v138 = v137.Z
		local v139 = v137.Y
		local v140 = v137.Y
		v137 = Vector3.new(v138, v139, v140)
	end
	return v131, v132(p117, v133, v137, p120 * v124, p121, Enum.Material.Neon, {
		["shadow"] = false,
		["t"] = 0.72,
		["shape"] = nil,
		["shape"] = v123
	})
end
function v_u_4.new(p142) -- name: new
	-- upvalues: (copy) v_u_4, (ref) v_u_6, (copy) v_u_63, (copy) v_u_1
	local v143 = v_u_4
	local v_u_144 = setmetatable({}, v143)
	v_u_144.cctx = p142.cctx
	v_u_144.origin = p142.origin
	v_u_144.t = 0
	v_u_144.lamp = nil
	v_u_144.shotName = "intro"
	v_u_144.camCF = nil
	v_u_144.externalCamera = false
	v_u_144.fov = 40
	v_u_144.lastFocus = -1
	v_u_144.equipKey = ""
	v_u_144.equipped = {}
	v_u_144.flick = {
		["next"] = 2,
		["off"] = 0,
		["pattern"] = nil,
		["pattern"] = {}
	}
	v_u_144.police = {}
	v_u_144.beacons = {}
	v_u_144.fires = {}
	v_u_144.headTurn = 0
	v_u_144.headTarget = 0
	v_u_144.nextHead = 4
	v_u_144.squadRows = {}
	v_u_144.fakeN = 0
	v_u_144.mates = {}
	v_u_144.heroRow = nil
	v_u_144.gearConns = nil
	v_u_6 = v_u_144
	local function v192()
		-- upvalues: (copy) v_u_144, (ref) v_u_6, (ref) v_u_63
		v_u_144.cctx.command("menu.squadfake", function(p145)
			-- upvalues: (ref) v_u_6, (ref) v_u_63
			local v146 = v_u_6
			if not (v146 and v146.root) then
				return "no menu scene"
			end
			local v147 = p145[1]
			local v148 = tonumber(v147) or 3
			local v149 = math.floor(v148)
			local v150 = v_u_63
			v146.fakeN = math.clamp(v149, 0, v150)
			v146:_applySquad()
			local v151 = 0
			for _ in v146.mates do
				v151 = v151 + 1
			end
			local v152 = v146.fakeN
			local v153 = #v146.squadRows
			local v154 = v146.shotName
			return ("fake=%d mates=%d rows=%d shot=%s"):format(v152, v151, v153, (tostring(v154)))
		end)
		v_u_144.cctx.command("menu.searchfake", function(p155)
			-- upvalues: (ref) v_u_6
			local v156 = v_u_6
			if not (v156 and v156.root) then
				return "no menu scene"
			end
			local v157 = p155[1] or "searching"
			if v157 == "off" then
				v156.searchFake = nil
				return "search fake off"
			end
			if v157 ~= "searching" and (v157 ~= "found" and v157 ~= "deploying") then
				return "phase must be searching|found|deploying|off"
			end
			local v158 = p155[2]
			local v159 = tonumber(v158) or 25
			local v160 = math.max(0, v159)
			local v161 = {
				["phase"] = v157,
				["until_"] = os.clock() + v160,
				["total"] = math.max(1, v160)
			}
			local v162 = p155[3]
			v161.found = tonumber(v162)
			v156.searchFake = v161
			local v163 = p155[3]
			local v164 = tostring(v163)
			local v165 = v156.shotName
			return ("search fake %s %ds found=%s shot=%s"):format(v157, v160, v164, (tostring(v165)))
		end)
		v_u_144.cctx.command("menu.gearfake", function(p166)
			-- upvalues: (ref) v_u_6
			local v167 = v_u_6
			if not (v167 and v167.root) then
				return "no menu scene"
			end
			if p166[1] == nil or p166[1] == "off" then
				local v168 = v167.realSlots
				v167.realSlots = nil
				if v168 ~= nil then
					if v168 == false then
						v168 = nil
					end
					v167:setLoadout(v168)
				end
				return "real loadout"
			end
			if v167.realSlots == nil then
				local v169
				if v167.lastSlots == nil then
					v169 = false
				else
					v169 = v167.lastSlots
				end
				v167.realSlots = v169
			end
			local v170 = {}
			local v171 = p166[1]
			v170.primary = v171 and v171 ~= "-" and {
				["id"] = v171
			} or nil
			local v172 = p166[2]
			v170.secondary = v172 and v172 ~= "-" and {
				["id"] = v172
			} or nil
			local v173 = p166[3]
			v170.melee = v173 and v173 ~= "-" and {
				["id"] = v173
			} or nil
			local v174 = p166[4]
			v170.armor = v174 and v174 ~= "-" and {
				["id"] = v174
			} or nil
			local v175 = p166[5]
			v170.helmet = v175 and v175 ~= "-" and {
				["id"] = v175
			} or nil
			v167:setLoadout(v170)
			local v176 = 0
			for _, v177 in v167.equipped do
				if v177:GetAttribute("WeaponScale") == nil then
					continue
				end
				v176 = v176 + 1
			end
			local v178 = v167.equipKey
			local v179 = tostring(v178)
			local v180 = v167.gunScale
			return ("gear key=%s scaledGuns=%d gunScale=%s"):format(v179, v176, (tostring(v180)))
		end)
		v_u_144.cctx.command("menu.mategear", function()
			-- upvalues: (ref) v_u_6
			local v181 = v_u_6
			if not (v181 and v181.root) then
				return "no menu scene"
			end
			local v182 = {}
			for v183, v184 in v181.mates do
				local v185 = 0
				local v186 = 0
				for _, v187 in v184.equipped or {} do
					if not v187.Parent then
						continue
					end
					v185 = v185 + 1
					if v187:GetAttribute("WeaponScale") == nil then
						continue
					end
					v186 = v186 + 1
				end
				local v188 = (v184.row or {}).displayName
				local v189 = tostring(v188)
				local v190 = v184.equipKey
				local v191 = tostring(v190)
				table.insert(v182, ("%d:%s pieces=%d guns=%d key=%s"):format(v183, v189, v185, v186, v191))
			end
			return #v182 == 0 and "no mates" or table.concat(v182, " ; ")
		end)
	end
	pcall(v192)
	local v193 = v_u_1:FindFirstChild("HushLocal")
	if not v193 then
		v193 = Instance.new("Folder")
		v193.Name = "HushLocal"
		v193.Parent = v_u_1
	end
	local v194 = v193:FindFirstChild("MenuScene")
	if v194 then
		v194:Destroy()
	end
	local v195 = Instance.new("Folder")
	v195.Name = "MenuScene"
	v_u_144.root = v195
	v195.Parent = v193
	local v196, v197 = pcall(function()
		-- upvalues: (copy) v_u_144
		v_u_144:_mountRoof()
		if not v_u_144.tokyoRoof then
			v_u_144:_buildStreet()
			v_u_144:_buildTown()
			v_u_144:_buildProps()
		end
		v_u_144:_buildSurvivor()
		if not v_u_144.tokyoRoof then
			v_u_144:_buildImported()
		end
	end)
	if not v196 then
		warn("[MenuScene] build error:", v197)
	end
	v_u_144:_startSound()
	if not v_u_144.tokyoRoof then
		local v198, v199 = pcall(function()
			-- upvalues: (copy) v_u_144
			v_u_144.halloween = v_u_144.cctx.lib.MenuHalloween.new(v_u_144)
		end)
		if not v198 then
			warn("[MenuScene] halloween:", v199)
		end
	end
	pcall(function()
		-- upvalues: (copy) v_u_144
		v_u_144.story = v_u_144.cctx.lib.MenuStory.new(v_u_144)
	end)
	local v200 = game:GetService("Players").LocalPlayer
	if v200 then
		v_u_144.titleConn = v200:GetAttributeChangedSignal("Title"):Connect(function()
			-- upvalues: (copy) v_u_144
			if v_u_144.survivor then
				v_u_144:_plates()
			end
		end)
		v_u_144.titleKeyConn = v200:GetAttributeChangedSignal("TitleKey"):Connect(function()
			-- upvalues: (copy) v_u_144
			if v_u_144.survivor then
				v_u_144:_plates()
			end
		end)
	end
	v_u_144:_watchHeadwear()
	v_u_144:_watchGear()
	return v_u_144
end
function v_u_4.W(p201, p202) -- name: W
	return p201.origin + p202
end
function v_u_4.CF(p203, p204, p205) -- name: CF
	return CFrame.new(p203.origin + p204) * CFrame.Angles(0, p205 or 0, 0)
end
function v_u_4._asset(p_u_206, p_u_207, p_u_208) -- name: _asset
	local v209, v210 = pcall(function()
		-- upvalues: (copy) p_u_206, (copy) p_u_207, (copy) p_u_208
		return p_u_206.cctx.shared.Assets.get(p_u_207, p_u_208)
	end)
	if v209 and typeof(v210) == "Instance" then
		return v210
	else
		return nil
	end
end
function v_u_4._mountRoof(p_u_211) -- name: _mountRoof
	local v212, v213, v214 = pcall(function()
		-- upvalues: (copy) p_u_211
		return p_u_211.cctx.lib.MenuTokyoRoof.new(p_u_211)
	end)
	if v212 and v213 then
		p_u_211.tokyoRoof = v213
		return
	elseif v212 then
		if v214 ~= "switch off" then
			warn("[MenuScene] roof scene not mounted (" .. tostring(v214) .. "), the old street is built")
		end
	else
		warn("[MenuScene] roof scene failed, the old street is built:", v213)
	end
end
function v_u_4._buildStreet(p215) -- name: _buildStreet
	-- upvalues: (copy) v_u_73, (copy) v_u_61
	local v216 = Instance.new("Folder")
	v216.Name = "Street"
	v216.Parent = p215.root
	v_u_73(v216, "Road", Vector3.new(700, 1, 30), p215:CF(Vector3.new(0, -0.5, -17)), v_u_61.asphalt, Enum.Material.Asphalt, {
		["refl"] = 0.04,
		["shadow"] = false
	})
	for v217 = -346, 346, 14 do
		v_u_73(v216, "Line", Vector3.new(8, 0.05, 0.35), p215:CF((Vector3.new(v217, 0.02, -16.6))), v_u_61.tape:Lerp(v_u_61.asphalt, 0.55), Enum.Material.Asphalt, {
			["shadow"] = false
		})
		v_u_73(v216, "Line", Vector3.new(8, 0.05, 0.35), p215:CF((Vector3.new(v217, 0.02, -17.4))), v_u_61.tape:Lerp(v_u_61.asphalt, 0.55), Enum.Material.Asphalt, {
			["shadow"] = false
		})
	end
	v_u_73(v216, "Sidewalk", Vector3.new(700, 0.5, 11), p215:CF(Vector3.new(0, 0.25, 3.5)), v_u_61.concrete, Enum.Material.Concrete, {
		["refl"] = 0.02,
		["shadow"] = false
	})
	v_u_73(v216, "Curb", Vector3.new(700, 0.55, 0.6), p215:CF(Vector3.new(0, 0.27, -2.2)), v_u_61.curb, Enum.Material.Concrete, {
		["shadow"] = false
	})
	for v218 = -350, 350, 8 do
		v_u_73(v216, "Joint", Vector3.new(0.12, 0.02, 11), p215:CF((Vector3.new(v218, 0.51, 3.5))), v_u_61.curb:Lerp(v_u_61.asphalt, 0.5), Enum.Material.Concrete, {
			["shadow"] = false
		})
	end
	v_u_73(v216, "Verge", Vector3.new(700, 0.4, 40), p215:CF(Vector3.new(0, 0.2, 29)), v_u_61.grass, Enum.Material.Grass, {
		["shadow"] = false
	})
	v_u_73(v216, "FarWalk", Vector3.new(700, 0.5, 9), p215:CF(Vector3.new(0, 0.25, -36.5)), v_u_61.concrete, Enum.Material.Concrete, {
		["shadow"] = false
	})
	v_u_73(v216, "FarCurb", Vector3.new(700, 0.55, 0.6), p215:CF(Vector3.new(0, 0.27, -32.2)), v_u_61.curb, Enum.Material.Concrete, {
		["shadow"] = false
	})
	v_u_73(v216, "Field", Vector3.new(1400, 0.4, 700), p215:CF(Vector3.new(0, 0.1, -391)), v_u_61.dirt:Lerp(v_u_61.grass, 0.4), Enum.Material.Ground, {
		["shadow"] = false
	})
	local v219 = Random.new(41)
	for v220 = 1, 16 do
		local v221 = v219:NextNumber(-60, 60)
		local v222 = v219:NextNumber(-30, -3)
		local v223 = v219:NextNumber(3, 9)
		v_u_73(v216, "Puddle", Vector3.new(0.04, v223, v223), p215:CF((Vector3.new(v221, 0.02, v222))) * CFrame.Angles(0, v219:NextNumber(0, 3.141592653589793), 1.5707963267948966), v_u_61.puddle, Enum.Material.Glass, {
			["t"] = 0.25,
			["refl"] = 0.35,
			["shadow"] = false,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		}).Name = "Puddle" .. v220
	end
	v_u_73(v216, "Drain", Vector3.new(3, 0.06, 1.4), p215:CF(Vector3.new(4.5, 0.03, -3)), Color3.fromHex("#1A1B1D"), Enum.Material.DiamondPlate, {
		["shadow"] = false
	})
	for v224 = 1, 22 do
		local v225 = v219:NextNumber(-30, 30)
		local v226 = v219:NextNumber(-28, 7)
		local v227 = v226 > -2 and 0.52 or 0.03
		local v228 = v_u_73
		local v229 = v219:NextNumber(0.6, 1.2)
		v228(v216, "Paper", Vector3.new(v229, 0.03, v219:NextNumber(0.7, 1.4)), p215:CF(Vector3.new(v225, v227, v226), v219:NextNumber(0, 6.28)), v_u_61.paint:Lerp(v_u_61.concrete, v219:NextNumber(0.2, 0.7)), Enum.Material.Fabric, {
			["shadow"] = false
		}).Name = "Paper" .. v224
	end
end
function v_u_4._buildTown(p230) -- name: _buildTown
	-- upvalues: (copy) v_u_61, (copy) v_u_73, (copy) v_u_77, (copy) v_u_102
	local v231 = Instance.new("Folder")
	v231.Name = "Town"
	v231.Parent = p230.root
	local v232 = Random.new(7)
	for v233, v234 in {
		{
			["z"] = -70,
			["h0"] = 7,
			["h1"] = 15,
			["gap"] = 4
		},
		{
			["z"] = -140,
			["h0"] = 12,
			["h1"] = 26
		},
		{
			["z"] = -230,
			["h0"] = 18,
			["h1"] = 40
		},
		{
			["z"] = -360,
			["h0"] = 24,
			["h1"] = 60
		}
	} do
		local v235 = -420
		while v235 < 420 do
			local v236 = v232:NextNumber(18, 44) + v233 * 6
			local v237 = v232:NextNumber(v234.h0, v234.h1)
			local v238 = v232:NextNumber(16, 30)
			local v239 = v235 + v236 / 2
			local v240
			if v233 == 1 then
				v240 = v_u_61.silhouette2
			else
				v240 = v_u_61.silhouette
			end
			local v241 = v_u_73
			local v242 = "Block"
			local v243 = Vector3.new(v236, v237, v238)
			local v244 = v237 / 2
			local v245 = v234.z - v238 / 2
			local v246 = p230:CF((Vector3.new(v239, v244, v245)))
			local v247
			if v233 == 1 then
				v247 = Enum.Material.Brick
			else
				v247 = Enum.Material.Concrete
			end
			v241(v231, v242, v243, v246, v240, v247, {
				["shadow"] = v233 <= 2
			}).Name = "Block" .. v233
			if v233 <= 2 and v232:NextNumber() < 0.6 then
				local v248 = Instance.new("WedgePart")
				v248.Anchored = true
				v248.CanCollide = false
				v248.CanQuery = false
				v248.CanTouch = false
				v248.Color = Color3.fromHex("#15171A")
				v248.Material = Enum.Material.Slate
				local v249 = v238 / 2
				v248.Size = Vector3.new(v236, 6, v249)
				local v250 = v237 + 3
				local v251 = v234.z - v238 * 0.25
				v248.CFrame = p230:CF((Vector3.new(v239, v250, v251)))
				v248.Parent = v231
				local v252 = v248:Clone()
				local v253 = v237 + 3
				local v254 = v234.z - v238 * 0.75
				v252.CFrame = p230:CF(Vector3.new(v239, v253, v254), 3.141592653589793)
				v252.Parent = v231
			end
			for _ = 1, v233 == 1 and 2 or (v233 == 2 and 2 or 1) do
				if v232:NextNumber() >= 0.45 then
					continue
				end
				local v255 = v239 + v232:NextNumber(-v236 / 2 + 2, v236 / 2 - 2)
				local v256 = v237 - 3
				local v257 = v232:NextNumber(4, (math.max(5, v256)))
				local v258 = v_u_61.window:Lerp(Color3.new(1, 0.4, 0.2), v232:NextNumber(0, 0.5))
				local v259 = v232:NextNumber(0.25, 0.6)
				local v260 = v234.z
				local v261 = p230:CF((Vector3.new(v255, v257, v260)))
				local v262 = Random.new
				local v263 = v255 * 7 + v257 * 131 + v233
				p230:_litWindow(v231, v261, v258, v259, v233, v262((math.floor(v263))))
			end
			v235 = v235 + (v236 + (v234.gap or v232:NextNumber(3, 14)))
		end
	end
	local v264 = p230:W(Vector3.new(-95, 0, -190))
	for v265 = 0, 3 do
		local v266 = v265 * 3.141592653589793 / 2 + 0.7853981633974483
		local v267 = math.cos(v266) * 7
		local v268 = math.sin(v266) * 7
		local v269 = Vector3.new(v267, 0, v268)
		v_u_73(v231, "Leg", Vector3.new(0.9, 34, 0.9), CFrame.new(v264 + v269 + Vector3.new(0, 17, 0)), v_u_61.silhouette, Enum.Material.Metal)
	end
	v_u_73(v231, "Tank", Vector3.new(12, 16, 16), CFrame.new(v264 + Vector3.new(0, 40, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_61.silhouette, Enum.Material.Metal, {
		["shape"] = Enum.PartType.Cylinder
	})
	v_u_73(v231, "Cap", Vector3.new(6, 20, 20), CFrame.new(v264 + Vector3.new(0, 48, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_61.silhouette, Enum.Material.Metal, {
		["shape"] = Enum.PartType.Cylinder
	}).Size = Vector3.new(3, 11, 11)
	local v270 = p230:W(Vector3.new(-2, 0, -165))
	v_u_73(v231, "Church", Vector3.new(20, 16, 30), CFrame.new(v270 + Vector3.new(0, 8, 0)), v_u_61.silhouette, Enum.Material.Brick)
	v_u_73(v231, "Tower", Vector3.new(7, 30, 7), CFrame.new(v270 + Vector3.new(0, 15, 16)), v_u_61.silhouette, Enum.Material.Brick)
	local v271 = Instance.new("WedgePart")
	v271.Anchored = true
	v271.CanCollide = false
	v271.CanQuery = false
	v271.Color = v_u_61.silhouette
	v271.Material = Enum.Material.Slate
	v271.Size = Vector3.new(7, 12, 3.5)
	v271.CFrame = CFrame.new(v270 + Vector3.new(0, 36, 17.75))
	v271.Parent = v231
	local v272 = v271:Clone()
	v272.CFrame = CFrame.new(v270 + Vector3.new(0, 36, 14.25)) * CFrame.Angles(0, 3.141592653589793, 0)
	v272.Parent = v231
	local v273 = p230:W(Vector3.new(20, 0, -440))
	v_u_73(v231, "Mast", Vector3.new(2, 90, 2), CFrame.new(v273 + Vector3.new(0, 45, 0)), v_u_61.silhouette, Enum.Material.Metal)
	for v274 = 15, 80, 13 do
		v_u_73(v231, "Truss", Vector3.new(6, 0.5, 0.5), CFrame.new(v273 + Vector3.new(0, v274, 0)) * CFrame.Angles(0, 0, 0.5235987755982988), v_u_61.silhouette, Enum.Material.Metal)
	end
	v_u_73(v231, "BeaconMount", Vector3.new(0.8, 1.6, 1.6), CFrame.new(v273 + Vector3.new(0, 90.4, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_61.silhouette, Enum.Material.Metal, {
		["shadow"] = false,
		["shape"] = nil,
		["shape"] = Enum.PartType.Cylinder
	})
	v_u_73(v231, "BeaconDome", Vector3.new(1.5, 1.5, 1.5), CFrame.new(v273 + Vector3.new(0, 91.2, 0)), Color3.fromHex("#7A1A16"), Enum.Material.Glass, {
		["shadow"] = false,
		["t"] = 0.35,
		["shape"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v275 = v_u_73(v231, "Beacon", Vector3.new(0.9, 0.9, 0.9), CFrame.new(v273 + Vector3.new(0, 91.2, 0)), Color3.fromHex("#FF3B30"), Enum.Material.Neon, {
		["shadow"] = false,
		["shape"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v276 = Instance.new("PointLight")
	v276.Color = Color3.fromHex("#FF3B30")
	v276.Range = 30
	v276.Brightness = 0
	v276.Shadows = false
	v276.Parent = v275
	local v277 = p230.beacons
	table.insert(v277, {
		["cores"] = nil,
		["light"] = nil,
		["period"] = 2.2,
		["phase"] = 0,
		["on"] = 2,
		["offT"] = 0.8,
		["cores"] = { v275 },
		["light"] = v276
	})
	for v278, v279 in { Vector3.new(-160, 6, -300), Vector3.new(10, 4, -280) } do
		local v280 = v_u_73(v231, "FireGlow" .. v278, Vector3.new(1, 1, 1), p230:CF(v279), v_u_61.fire, Enum.Material.Neon, {
			["t"] = 1,
			["shadow"] = false
		})
		local v281 = Instance.new("PointLight")
		v281.Color = v_u_61.fire
		v281.Range = 60
		v281.Brightness = 3
		v281.Shadows = false
		v281.Parent = v280
		local v282 = p230.fires
		table.insert(v282, v281)
	end
	local v283 = nil
	local v284 = nil
	for v285 = -140, 140, 46 do
		local v286 = p230:_asset("Prop", "PowerPole")
		local v287
		if v286 and v286:IsA("Model") then
			v_u_77(v286, true)
			v_u_102(v286, p230:W((Vector3.new(v285, 0.5, -38))), 0)
			v286.Parent = v231
			local v288, v289 = v286:GetBoundingBox()
			local v290 = v288.Position
			local v291 = v289.Y / 2 - 1.2
			v287 = v290 + Vector3.new(0, v291, 0)
		else
			v287 = v_u_73(v231, "Pole", Vector3.new(1, 34, 1), p230:CF((Vector3.new(v285, 17, -38))), Color3.fromHex("#3A3029"), Enum.Material.Wood).Position + Vector3.new(0, 16, 0)
		end
		local v292 = v_u_73(v231, "WireAnchor", Vector3.new(0.2, 0.2, 0.2), CFrame.new(v287), v_u_61.metal, Enum.Material.Metal, {
			["t"] = 1,
			["shadow"] = false
		})
		local v293 = Instance.new("Attachment")
		v293.Position = Vector3.new(0, 0, -1.6)
		v293.Axis = Vector3.new(0, -1, 0)
		v293.SecondaryAxis = Vector3.new(1, 0, 0)
		v293.Parent = v292
		local v294 = Instance.new("Attachment")
		v294.Position = Vector3.new(0, 0, 1.6)
		v294.Axis = Vector3.new(0, -1, 0)
		v294.SecondaryAxis = Vector3.new(1, 0, 0)
		v294.Parent = v292
		if v283 and v284 then
			for _, v295 in {
				{ v283, v293 },
				{ v284, v294 }
			} do
				local v296 = Instance.new("Beam")
				v296.Attachment0 = v295[1]
				v296.Attachment1 = v295[2]
				v296.Width0 = 0.12
				v296.Width1 = 0.12
				v296.Color = ColorSequence.new(Color3.fromHex("#0C0D0F"))
				v296.Transparency = NumberSequence.new(0.05)
				v296.CurveSize0 = 5
				v296.CurveSize1 = -5
				v296.Segments = 12
				v296.FaceCamera = true
				v296.LightInfluence = 1
				v296.Parent = v292
			end
		end
		v284 = v294
		v283 = v293
	end
end
function v_u_4._litWindow(_, p297, p298, p299, p300, p301, p302) -- name: _litWindow
	-- upvalues: (copy) v_u_73
	local v303 = Instance.new("Model")
	v303.Name = "LitWindow"
	v303.Parent = p297
	local v304 = Color3.fromHex("#2B2724")
	local v305 = v_u_73(v303, "Pane", Vector3.new(1.6, 2.4, 0.2), p298, p299:Lerp(Color3.fromHex("#2A1A10"), p300 * 0.45 + 0.3), Enum.Material.Neon, {
		["shadow"] = false
	})
	v_u_73(v303, "FrameTop", Vector3.new(2.04, 0.22, 0.45), p298 * CFrame.new(0, 1.31, 0.175), v304, Enum.Material.Wood, {
		["shadow"] = false
	})
	v_u_73(v303, "FrameBottom", Vector3.new(2.04, 0.22, 0.45), p298 * CFrame.new(0, -1.31, 0.175), v304, Enum.Material.Wood, {
		["shadow"] = false
	})
	v_u_73(v303, "FrameL", Vector3.new(0.22, 2.4, 0.45), p298 * CFrame.new(-0.91, 0, 0.175), v304, Enum.Material.Wood, {
		["shadow"] = false
	})
	v_u_73(v303, "FrameR", Vector3.new(0.22, 2.4, 0.45), p298 * CFrame.new(0.91, 0, 0.175), v304, Enum.Material.Wood, {
		["shadow"] = false
	})
	if p301 <= 2 then
		v_u_73(v303, "Mullion", Vector3.new(0.1, 2.4, 0.1), p298 * CFrame.new(0, 0, 0.16), v304, Enum.Material.Wood, {
			["shadow"] = false
		})
		v_u_73(v303, "Transom", Vector3.new(1.6, 0.1, 0.1), p298 * CFrame.new(0, 0.288, 0.16), v304, Enum.Material.Wood, {
			["shadow"] = false
		})
		v_u_73(v303, "Sill", Vector3.new(2.4, 0.18, 0.6), p298 * CFrame.new(0, -1.51, 0.25), Color3.fromHex("#4A4743"), Enum.Material.Concrete, {
			["shadow"] = false
		})
		if p302:NextNumber() < 0.55 then
			local v306 = 1.6 * p302:NextNumber(0.28, 0.5)
			local v307 = p302:NextNumber() < 0.5 and -1 or 1
			v_u_73(v303, "Curtain", Vector3.new(v306, 2.4, 0.04), p298 * CFrame.new(v307 * (1.6 - v306) / 2, 0, 0.13), p299:Lerp(Color3.new(0, 0, 0), 0.78), Enum.Material.Fabric, {
				["shadow"] = false,
				["t"] = 0.15
			})
		end
	end
	if p301 == 1 then
		local v308 = Instance.new("SurfaceLight")
		v308.Face = Enum.NormalId.Front
		v308.Angle = 110
		v308.Range = 6
		v308.Brightness = 0.5
		v308.Color = p299
		v308.Shadows = false
		v308.Parent = v305
	end
	return v303
end
function v_u_4._lightBarOn(p309, p310, p311) -- name: _lightBarOn
	-- upvalues: (copy) v_u_116, (copy) v_u_73
	local v312 = p310:GetPivot()
	local v313 = Vector3.new(inf, inf, inf)
	local v314 = -v313
	local v315 = p311.Size / 2
	for _, v316 in { -1, 1 } do
		for _, v317 in { -1, 1 } do
			for _, v318 in { -1, 1 } do
				local v319 = p311.CFrame
				local v320 = v315.X * v316
				local v321 = v315.Y * v317
				local v322 = v315.Z * v318
				local v323 = v312:PointToObjectSpace(v319:PointToWorldSpace((Vector3.new(v320, v321, v322))))
				v313 = v313:Min(v323)
				v314 = v314:Max(v323)
			end
		end
	end
	local v324 = (v313.Y + v314.Y) / 2
	local v325 = v314.Z - v313.Z + 1
	local v326 = v312:VectorToWorldSpace(Vector3.new(0, 0, 1))
	local v327, v328 = v_u_116(p311)
	local v329 = v313.X + 0.04
	local v330 = {}
	while v329 < v314.X do
		local v331 = v313.Z - 0.5
		local v332 = v327(v312:PointToWorldSpace((Vector3.new(v329, v324, v331))), v326 * v325)
		local v333 = v314.Z + 0.5
		local v334 = v327(v312:PointToWorldSpace((Vector3.new(v329, v324, v333))), -v326 * v325)
		if v332 and v334 then
			local v335 = {
				["x"] = v329,
				["f"] = v312:PointToObjectSpace(v332.Position).Z,
				["b"] = v312:PointToObjectSpace(v334.Position).Z
			}
			table.insert(v330, v335)
		end
		v329 = v329 + 0.08
	end
	v328()
	if #v330 < 4 then
		return false
	end
	local v336 = (v330[1].x + v330[#v330].x) / 2
	local v337 = {
		{},
		{}
	}
	for _, v338 in v330 do
		local v339 = v337[v338.x < v336 and 1 or 2]
		table.insert(v339, v338)
	end
	if #v337[1] < 2 or #v337[2] < 2 then
		return false
	end
	local v340 = Instance.new("Model")
	v340.Name = "LightBarLeds"
	v340.Parent = p309.root
	local v341 = (v314.Y - v313.Y) * 0.55
	local function v348(p342, p343) -- name: median
		local v344 = {}
		for _, v345 in p342 do
			local v346
			if p343 then
				v346 = v345.b
			else
				v346 = v345.f
			end
			table.insert(v344, v346)
		end
		table.sort(v344)
		local v347 = (#v344 + 1) / 2
		return v344[math.floor(v347)]
	end
	for v349, v350 in { Color3.fromHex("#D4231E"), Color3.fromHex("#2448D8") } do
		local v351 = v337[v349]
		local v352 = v351[1].x - 0.04
		local v353 = v351[#v351].x + 0.04
		local v354 = (v352 + v353) / 2
		local v355 = (v353 - v352) * 0.92
		for _, v356 in { -1, 1 } do
			local v357 = v348(v351, v356 > 0) + v356 * 0.027
			local v358 = v_u_73(v340, v349 == 1 and "RedCore" or "BlueCore", Vector3.new(v355, v341, 0.03), v312 * CFrame.new(v354, v324, v357), v350, Enum.Material.Neon, {
				["shadow"] = false,
				["t"] = 0.72
			})
			local v359 = Instance.new("SpotLight")
			local v360
			if v356 < 0 then
				v360 = Enum.NormalId.Front
			else
				v360 = Enum.NormalId.Back
			end
			v359.Face = v360
			v359.Color = v350
			v359.Angle = 120
			v359.Range = 18
			v359.Brightness = 0
			v359.Shadows = false
			v359.Parent = v358
			local v361 = p309.police
			table.insert(v361, {
				["cores"] = nil,
				["light"] = nil,
				["side"] = nil,
				["on"] = 1.4,
				["cores"] = { v358 },
				["light"] = v359,
				["side"] = v349
			})
		end
	end
	return true
end
function v_u_4._lightBar(p362, p363) -- name: _lightBar
	-- upvalues: (copy) v_u_116, (copy) v_u_73
	local v364 = p363:FindFirstChild("LightBar", true)
	if v364 and (v364:IsA("BasePart") and p362:_lightBarOn(p363, v364)) then
		return v364
	end
	local v365 = p363:GetPivot()
	local v366, v367 = p363:GetBoundingBox()
	local v368 = v366.Position.Y + v367.Y / 2
	local v369, v370 = v_u_116(p363)
	local v371 = v367.Z * 0.3
	local v372 = -v371 * 10
	local v373 = math.floor(v372)
	local v374 = v371 * 10
	local v375 = {}
	local v376 = (-1 / 0)
	for v377 = v373, math.ceil(v374) do
		local v378 = v377 / 10
		local v379 = (v365 * CFrame.new(0, 0, v378)).Position
		local v380 = v379.X
		local v381 = v368 + 3
		local v382 = v379.Z
		local v383 = Vector3.new(v380, v381, v382)
		local v384 = -(v367.Y + 6)
		local v385 = v369(v383, (Vector3.new(0, v384, 0)))
		local v386
		if v385 then
			v386 = v385.Position.Y
		else
			v386 = nil
		end
		if not v386 then
			continue
		end
		table.insert(v375, {
			["z"] = v378,
			["y"] = v386
		})
		v376 = math.max(v376, v386)
	end
	local v387, v388, v389, v390
	if #v375 > 0 then
		local v391 = (1 / 0)
		local v392 = (-1 / 0)
		for _, v393 in v375 do
			if v393.y < v376 - 0.12 then
				continue
			end
			local v394 = v393.z
			v391 = math.min(v391, v394)
			local v395 = v393.z
			v392 = math.max(v392, v395)
		end
		v387 = (v391 + v392) / 2
		local v396 = v391 - 0.35
		local v397 = (v365 * CFrame.new(0, 0, v396)).Position
		local v398 = v397.X
		local v399 = v368 + 3
		local v400 = v397.Z
		local v401 = Vector3.new(v398, v399, v400)
		local v402 = -(v367.Y + 6)
		local v403 = v369(v401, (Vector3.new(0, v402, 0)))
		local v404
		if v403 then
			v404 = v403.Position.Y
		else
			v404 = nil
		end
		if not v404 then
			local v405 = v392 + 0.35
			local v406 = (v365 * CFrame.new(0, 0, v405)).Position
			local v407 = v406.X
			local v408 = v368 + 3
			local v409 = v406.Z
			local v410 = Vector3.new(v407, v408, v409)
			local v411 = -(v367.Y + 6)
			local v412 = v369(v410, (Vector3.new(0, v411, 0)))
			local v413
			if v412 then
				v413 = v412.Position.Y
			else
				v413 = nil
			end
			v404 = v413 or v376
		end
		local v414 = (1 / 0)
		local v415 = (-1 / 0)
		for v416 = -40, 40 do
			local v417 = v416 / 10
			local v418 = (v365 * CFrame.new(v417, 0, v387)).Position
			local v419 = v418.X
			local v420 = v368 + 3
			local v421 = v418.Z
			local v422 = Vector3.new(v419, v420, v421)
			local v423 = -(v367.Y + 6)
			local v424 = v369(v422, (Vector3.new(0, v423, 0)))
			local v425
			if v424 then
				v425 = v424.Position.Y
			else
				v425 = nil
			end
			if not v425 or v376 - 0.15 > v425 then
				continue
			end
			local v426 = v416 / 10
			v414 = math.min(v414, v426)
			local v427 = v416 / 10
			v415 = math.max(v415, v427)
		end
		if v376 - v404 > 0.2 and (v414 < v415 and v392 - v391 < 2) then
			local v428 = v415 - v414 + 0.24
			local v429 = v367.X - 0.6
			v388 = math.clamp(v428, 2.6, v429)
			v389 = v392 - v391 + 0.24 + 0.1
			v368 = v404 - 0.1
			v390 = v376 + 0.08 - v368
			v387 = (v391 + v392) / 2
		else
			v388 = 3.8
			v389 = 0.7
			v390 = 0.45
			local v430 = (v365 * CFrame.new(0, 0, v387)).Position
			local v431 = v430.X
			local v432 = v368 + 3
			local v433 = v430.Z
			local v434 = Vector3.new(v431, v432, v433)
			local v435 = -(v367.Y + 6)
			local v436 = v369(v434, (Vector3.new(0, v435, 0)))
			local v437
			if v436 then
				v437 = v436.Position.Y
			else
				v437 = nil
			end
			v368 = (v437 or v376) - 0.05
		end
	else
		v389 = 0.7
		v387 = 0
		v390 = 0.45
		v388 = 3.8
	end
	v370()
	local v438 = v365 * CFrame.new(0, 0, v387)
	local v439 = CFrame.new(v438.Position.X, v368, v438.Position.Z) * v438.Rotation
	local v440 = Instance.new("Model")
	v440.Name = "LightBar"
	v440.Parent = p362.root
	local v441 = Color3.fromHex("#16181B")
	local v442 = v390 - 0.14
	v_u_73(v440, "Base", Vector3.new(v388, 0.14, v389), v439 * CFrame.new(0, 0.07, 0), v441, Enum.Material.Metal, {
		["refl"] = 0.05
	})
	local v443 = v439 * CFrame.new(0, 0.14 + v442 / 2, 0)
	v_u_73(v440, "Centre", Vector3.new(0.32, v442, v389), v443, v441, Enum.Material.Metal, {
		["shadow"] = false
	})
	for _, v444 in { -1, 1 } do
		v_u_73(v440, "EndCap", Vector3.new(0.1, v442, v389), v443 * CFrame.new(v444 * (v388 / 2 - 0.05), 0, 0), v441, Enum.Material.Metal, {
			["shadow"] = false
		})
	end
	local v445 = (v388 - 0.32 - 0.2) / 2
	for v446, v447 in { Color3.fromHex("#D4231E"), Color3.fromHex("#2448D8") } do
		local v448 = v446 == 1 and -1 or 1
		local v449 = v443 * CFrame.new(v448 * (0.16 + v445 / 2), 0, 0)
		v_u_73(v440, v446 == 1 and "RedLens" or "BlueLens", Vector3.new(v445, v442, v389), v449, v447:Lerp(Color3.new(0, 0, 0), 0.25), Enum.Material.Glass, {
			["shadow"] = false,
			["t"] = 0.35,
			["refl"] = 0.08
		})
		local v450 = {}
		for _, v451 in { -1, 1 } do
			local v452 = v_u_73
			local v453 = v446 == 1 and "RedCore" or "BlueCore"
			local v454 = v445 * 0.8
			local v455 = v442 * 0.45
			local v456 = v452(v440, v453, Vector3.new(v454, v455, 0.03), v449 * CFrame.new(0, 0, v451 * (v389 / 2 - 0.06)), v447, Enum.Material.Neon, {
				["shadow"] = false,
				["t"] = 0.72
			})
			table.insert(v450, v456)
			local v457 = Instance.new("SpotLight")
			local v458
			if v451 < 0 then
				v458 = Enum.NormalId.Front
			else
				v458 = Enum.NormalId.Back
			end
			v457.Face = v458
			v457.Color = v447
			v457.Angle = 120
			v457.Range = 18
			v457.Brightness = 0
			v457.Shadows = false
			v457.Parent = v456
			local v459 = p362.police
			table.insert(v459, {
				["cores"] = nil,
				["light"] = nil,
				["side"] = nil,
				["on"] = 1.4,
				["cores"] = { v456 },
				["light"] = v457,
				["side"] = v446
			})
		end
	end
	return v440
end
function v_u_4._hazard(p460, p461) -- name: _hazard
	-- upvalues: (copy) v_u_116, (copy) v_u_73, (copy) v_u_141
	local v462 = p461:GetPivot()
	local _, v463 = p461:GetBoundingBox()
	local v464 = p461:GetAttribute("Footprint")
	local v465
	if typeof(v464) == "Vector3" then
		v465 = v464.Z
	else
		v465 = v463.Z
	end
	for _, v466 in { -2.2, -1.8, -1.4 } do
		local v467 = v462 * CFrame.new(v466, 2.5, v465 / 2 + 3)
		local v468, v469 = v_u_116(p461)
		local v470 = v468(v467.Position, v462.LookVector * (v465 / 2 + 3))
		v469()
		if not v470 or v470.Normal:Dot(v462.LookVector) >= -0.5 then
			continue
		end
		local v471 = Color3.fromHex("#FF9A2E")
		local v472 = CFrame.lookAt(v470.Position, v470.Position - v470.Normal)
		local v473 = Instance.new("Model")
		v473.Name = "Hazard"
		v473.Parent = p460.root
		v_u_73(v473, "Housing", Vector3.new(0.66, 0.36, 0.16), v472 * CFrame.new(0, 0, 0.05), Color3.fromHex("#141414"), Enum.Material.Plastic, {
			["shadow"] = false
		})
		local _, v474 = v_u_141(v473, "Hazard", Vector3.new(0.54, 0.26, 0.1), v472 * CFrame.new(0, 0, 0.15), v471)
		local v475 = Instance.new("PointLight")
		v475.Color = v471
		v475.Range = 8
		v475.Brightness = 0
		v475.Shadows = false
		v475.Parent = v474
		local v476 = p460.beacons
		table.insert(v476, {
			["cores"] = nil,
			["light"] = nil,
			["period"] = 1.1,
			["phase"] = 0.3,
			["duty"] = 0.5,
			["on"] = 1.2,
			["cores"] = { v474 },
			["light"] = v475
		})
		return
	end
end
function v_u_4._warnLamp(p477, p478) -- name: _warnLamp
	-- upvalues: (copy) v_u_73, (copy) v_u_141
	local v479 = {}
	for _, v480 in p478:GetDescendants() do
		if not v480:IsA("BasePart") or v480.Material ~= Enum.Material.Neon then
			continue
		end
		table.insert(v479, v480)
	end
	for v481, v482 in v479 do
		local v483 = v482.CFrame * CFrame.new(0, -v482.Size.Y / 2, 0)
		v482:Destroy()
		v_u_73(p478, "LampBracket", Vector3.new(0.14, 0.32, 0.14), v483 * CFrame.new(0, 0.16, 0), Color3.fromHex("#2A2B2D"), Enum.Material.Metal, {
			["shadow"] = false
		})
		local v484 = v483 * CFrame.new(0, 0.62, 0)
		v_u_73(p478, "LampHousing", Vector3.new(0.3, 0.62, 0.62), v484 * CFrame.Angles(0, 1.5707963267948966, 0), Color3.fromHex("#9C7A1E"), Enum.Material.Plastic, {
			["shape"] = Enum.PartType.Cylinder
		})
		local v485 = Color3.fromHex("#FFA62B")
		local v486 = {}
		for _, v487 in { -1, 1 } do
			local _, v488 = v_u_141(p478, "Warn", Vector3.new(0.5, 0.5, 0.1), v484 * CFrame.new(0, 0, v487 * 0.18), v485, true)
			table.insert(v486, v488)
		end
		local v489 = Instance.new("PointLight")
		v489.Color = v485
		v489.Range = 7
		v489.Brightness = 0
		v489.Shadows = false
		v489.Parent = v486[1]
		local v490 = p477.beacons
		local v491 = {
			["cores"] = nil,
			["light"] = nil,
			["period"] = 1,
			["phase"] = nil,
			["duty"] = 0.35,
			["on"] = 0.9,
			["cores"] = v486,
			["light"] = v489,
			["phase"] = 0.45 * v481
		}
		table.insert(v490, v491)
	end
end
function v_u_4._prop(p492, p493, p494, p495, p496) -- name: _prop
	-- upvalues: (copy) v_u_77, (copy) v_u_102
	local v497 = p492:_asset("Prop", p493)
	if not (v497 and v497:IsA("Model")) then
		return nil
	end
	v_u_77(v497, true)
	v_u_102(v497, p492:W(p494), p495, p496)
	v497.Parent = p492.root
	return v497
end
function v_u_4._tape(p498, p499, p500, p501) -- name: _tape
	-- upvalues: (copy) v_u_73, (copy) v_u_61
	local v502 = v_u_73(p498.root, "TapeAnchor", Vector3.new(0.1, 0.1, 0.1), CFrame.new(p498:W(p499)), v_u_61.tape, Enum.Material.Plastic, {
		["t"] = 1,
		["shadow"] = false
	})
	local v503 = Instance.new("Attachment")
	v503.Parent = v502
	local v504 = Instance.new("Attachment")
	v504.Parent = v502
	v504.WorldPosition = p498:W(p500)
	for _, v505 in { v503, v504 } do
		v505.Axis = Vector3.new(0, -1, 0)
		v505.SecondaryAxis = Vector3.new(1, 0, 0)
	end
	local v506 = math.abs(p501)
	local v507 = Instance.new("Beam")
	v507.Attachment0 = v503
	v507.Attachment1 = v504
	v507.Width0 = 0.32
	v507.Width1 = 0.32
	v507.Color = ColorSequence.new(v_u_61.tape)
	v507.Transparency = NumberSequence.new(0)
	v507.LightInfluence = 1
	v507.Segments = 14
	v507.CurveSize0 = v506
	v507.CurveSize1 = -v506
	v507.FaceCamera = true
	v507.Parent = v502
	local v508 = v507:Clone()
	v508.Width0 = 0.1
	v508.Width1 = 0.1
	v508.Color = ColorSequence.new(Color3.fromHex("#141414"))
	v508.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.2, 0),
		NumberSequenceKeypoint.new(0.201, 1),
		NumberSequenceKeypoint.new(0.3, 1),
		NumberSequenceKeypoint.new(0.301, 0),
		NumberSequenceKeypoint.new(0.5, 0),
		NumberSequenceKeypoint.new(0.501, 1),
		NumberSequenceKeypoint.new(0.6, 1),
		NumberSequenceKeypoint.new(0.601, 0),
		NumberSequenceKeypoint.new(0.8, 0),
		NumberSequenceKeypoint.new(0.801, 1),
		NumberSequenceKeypoint.new(0.9, 1),
		NumberSequenceKeypoint.new(0.901, 0),
		NumberSequenceKeypoint.new(1, 0)
	})
	v508.ZOffset = 0.02
	v508.Parent = v502
end
function v_u_4._buildProps(p_u_509) -- name: _buildProps
	-- upvalues: (copy) v_u_77, (copy) v_u_73, (copy) v_u_61, (copy) v_u_3
	local v510 = p_u_509.root
	local v511 = Instance.new("Folder")
	v511.Name = "HeroLamp"
	v511.Parent = v510
	local v512 = nil
	local v513 = p_u_509:_asset("Prop", "StreetLamp")
	if v513 and (v513:IsA("Model") and v513:GetAttribute("Lamp") == "COBRA") then
		local v514 = v513:FindFirstChild("Lens")
		if v514 and v514:IsA("BasePart") then
			v_u_77(v513, true)
			v513.Name = "Lamp"
			v513:PivotTo(CFrame.new(p_u_509:W(Vector3.new(-3.6, 0.5, 1.6))))
			local v515 = p_u_509:W(Vector3.new(-3.6, 17.27, -3.6)) - v514.Position
			local v516 = v513:GetPivot()
			local v517 = v515.X
			local v518 = v515.Z
			v513:PivotTo(v516 + Vector3.new(v517, 0, v518))
			for _, v519 in v514:GetChildren() do
				if not v519:IsA("Light") then
					continue
				end
				v519:Destroy()
			end
			v513.Parent = v511
			v512 = v514
		else
			v513:Destroy()
		end
	end
	if v512 == nil then
		v_u_73(v511, "Pole", Vector3.new(18, 0.7, 0.7), p_u_509:CF(Vector3.new(-3.6, 9.5, 1.6)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_61.metal, Enum.Material.Metal, {
			["shape"] = Enum.PartType.Cylinder
		})
		v_u_73(v511, "Foot", Vector3.new(1.5, 1.4, 1.5), p_u_509:CF(Vector3.new(-3.6, 1.2, 1.6)), v_u_61.metal, Enum.Material.Metal)
		v_u_73(v511, "Arm", Vector3.new(0.4, 0.4, 5.6), p_u_509:CF(Vector3.new(-3.6, 18.1, -0.9999999)) * CFrame.Angles(-0.13962634015954636, 0, 0), v_u_61.metal, Enum.Material.Metal)
		v512 = v_u_73(v511, "Bulb", Vector3.new(1.2, 0.12, 2), v_u_73(v511, "Head", Vector3.new(1.6, 0.6, 2.6), p_u_509:CF(Vector3.new(-3.6, 17.6, -3.6)) * CFrame.Angles(-0.13962634015954636, 0, 0), v_u_61.metal:Lerp(Color3.new(0, 0, 0), 0.3), Enum.Material.Metal).CFrame * CFrame.new(0, -0.33, 0), v_u_61.sodium, Enum.Material.Neon, {
			["shadow"] = false
		})
	end
	local v520 = Instance.new("SpotLight")
	v520.Face = Enum.NormalId.Bottom
	v520.Color = v_u_61.sodium
	v520.Angle = 115
	v520.Range = 34
	v520.Brightness = 1.6
	v520.Shadows = true
	v520.Parent = v512
	local v521 = Instance.new("PointLight")
	v521.Color = v_u_61.sodium
	v521.Range = 12
	v521.Brightness = 0.25
	v521.Shadows = false
	v521.Parent = v512
	local v522 = Instance.new("Attachment")
	v522.Parent = v512
	v522.WorldPosition = v512.Position - Vector3.new(0, 0.2, 0)
	local v523 = Instance.new("Attachment")
	v523.Parent = v512
	v523.WorldPosition = p_u_509:W(Vector3.new(-4, 0.4, -3.6))
	local v524 = Instance.new("Beam")
	v524.Attachment0 = v522
	v524.Attachment1 = v523
	v524.Width0 = 1.4
	v524.Width1 = 13
	v524.FaceCamera = true
	v524.LightEmission = 1
	v524.LightInfluence = 0
	v524.Brightness = 1
	v524.Color = ColorSequence.new(v_u_61.sodium)
	v524.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.78), NumberSequenceKeypoint.new(0.5, 0.9), NumberSequenceKeypoint.new(1, 1) })
	v524.Segments = 1
	v524.Parent = v512
	local v525 = v_u_73(v511, "RimBounce", Vector3.new(0.2, 0.2, 0.2), p_u_509:CF(Vector3.new(-1.2, 5.4, -4.6)), v_u_61.sodium, Enum.Material.SmoothPlastic, {
		["t"] = 1,
		["shadow"] = false
	})
	local v526 = Instance.new("PointLight")
	v526.Name = "Rim"
	v526.Color = v_u_61.sodium
	v526.Range = 9
	v526.Brightness = 0.7
	v526.Shadows = false
	v526.Parent = v525
	local v527 = v_u_73(v511, "ForeRain", Vector3.new(18, 0.2, 14), p_u_509:CF(Vector3.new(3, 13, 10)), v_u_61.sodium, Enum.Material.SmoothPlastic, {
		["t"] = 1,
		["shadow"] = false
	})
	local v528 = Instance.new("ParticleEmitter")
	v528.Name = "ForeRain"
	v528.Texture = "rbxasset://textures/particles/SquareParticle.png"
	v528.EmissionDirection = Enum.NormalId.Bottom
	v528.Orientation = Enum.ParticleOrientation.VelocityParallel
	v528.Speed = NumberRange.new(58, 66)
	v528.Lifetime = NumberRange.new(0.2, 0.24)
	v528.Size = NumberSequence.new(0.14)
	v528.Squash = NumberSequence.new(3)
	v528.Rotation = NumberRange.new(90)
	v528.RotSpeed = NumberRange.new(0)
	v528.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.15, 0.6),
		NumberSequenceKeypoint.new(0.85, 0.65),
		NumberSequenceKeypoint.new(1, 1)
	})
	v528.Color = ColorSequence.new(Color3.fromRGB(214, 206, 196))
	v528.LightInfluence = 1
	v528.LightEmission = 0.25
	v528.Brightness = 1.6
	v528.Rate = 160
	v528.Shape = Enum.ParticleEmitterShape.Box
	v528.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v528.Parent = v527
	p_u_509.lamp = {
		["bulb"] = nil,
		["spot"] = nil,
		["fill"] = nil,
		["rim"] = nil,
		["shaft"] = nil,
		["base"] = 1.6,
		["lastSet"] = 1.6,
		["driven"] = false,
		["peak"] = 1.6,
		["bulb"] = v512,
		["spot"] = v520,
		["fill"] = v521,
		["rim"] = v526,
		["shaft"] = v524
	}
	v512:SetAttribute("Kind", "Flicker")
	v512:SetAttribute("Flicker", true)
	v512:SetAttribute("Dead", false)
	v_u_3:AddTag(v512, "HushLight")
	local v529, v530 = pcall(function()
		-- upvalues: (copy) p_u_509
		return p_u_509.cctx.shared.Assets.hasImported("Prop", "Car_Taxi")
	end)
	p_u_509:_prop(v529 and v530 and "Car_Taxi" or "Car_Wreck", Vector3.new(15.5, 0, -9.5), -0.4886921905584123)
	local v531 = p_u_509:_prop("Car_Police", Vector3.new(2, 0, -27), -0.3141592653589793)
	if v531 then
		p_u_509:_lightBar(v531)
	end
	p_u_509:_prop("JerseyBarrier", Vector3.new(24, 0, -12), 1.5707963267948966)
	p_u_509:_prop("JerseyBarrier", Vector3.new(26, 0, -24), 1.3962634015954636)
	local v532 = p_u_509:_prop("Barricade", Vector3.new(-13, 0, -6), 0.3141592653589793)
	if v532 then
		p_u_509:_warnLamp(v532)
	end
	p_u_509:_prop("TrafficCone", Vector3.new(-9, 0, -4.5), 0)
	p_u_509:_prop("TrafficCone", Vector3.new(-17.5, 0, -10), 0.6)
	p_u_509:_prop("TrafficCone", Vector3.new(3.5, 0, -6.2), 0.2)
	p_u_509:_tape(Vector3.new(-9, 2.3, -4.5), Vector3.new(-3.6, 3.4, 1.6), -0.6)
	p_u_509:_tape(Vector3.new(-17.5, 2.3, -10), Vector3.new(-9, 2.3, -4.5), -0.8)
	p_u_509:_tape(Vector3.new(3.5, 2.3, -6.2), Vector3.new(-9, 2.2, -4.6), -1.2)
	p_u_509:_prop("Hydrant", Vector3.new(18, 0.5, 5), 0.3490658503988659)
	p_u_509:_prop("TrashCanTipped", Vector3.new(-7.5, 0.5, 5.5), -0.6981317007977318)
	p_u_509:_prop("TrashBags", Vector3.new(-9.5, 0.5, 7.2), 0.17453292519943295)
	p_u_509:_prop("Mailbox", Vector3.new(14, 0.5, 6), -0.2617993877991494)
	p_u_509:_prop("NewsBox", Vector3.new(-12.5, 0.5, 7), 0.13962634015954636)
	p_u_509:_prop("Sign_Stop", Vector3.new(20, 0.5, 0.2), -1.7453292519943295, CFrame.Angles(0, 0, -0.10471975511965978))
	p_u_509:_prop("Tree_Dead", Vector3.new(-24, 0.4, 16), 0.5235987755982988)
	p_u_509:_prop("Tree_Dead", Vector3.new(34, 0.4, 20), 3.490658503988659)
	p_u_509:_prop("Tree_Dead", Vector3.new(-44, 0.5, -40), 1.5707963267948966)
	p_u_509:_prop("Tree_Dead", Vector3.new(58, 0.5, -41), 0.17453292519943295)
	p_u_509:_prop("ShoppingCart", Vector3.new(15.5, 0, -24), 2.0943951023931953, CFrame.Angles(0.13962634015954636, 0, 0))
	p_u_509:_prop("Sandbags", Vector3.new(34, 0, -14), 1.6580627893946132)
	p_u_509:_prop("FenceWood", Vector3.new(-40, 0.4, 12), 1.5707963267948966)
	for _, v533 in {
		-70,
		-30,
		48,
		96
	} do
		p_u_509:_prop("StreetLamp", Vector3.new(v533, 0.5, -34), 3.141592653589793)
	end
end
local v_u_534 = {
	["Root"] = CFrame.Angles(0, -0.10471975511965978, 0.026179938779914945),
	["Waist"] = CFrame.Angles(-0.03490658503988659, 0.13962634015954636, 0),
	["Neck"] = CFrame.Angles(-0.15707963267948966, 0.24434609527920614, 0),
	["RightShoulder"] = CFrame.Angles(0.06981317007977318, 0, 0.12217304763960307),
	["RightElbow"] = CFrame.Angles(0.2792526803190927, 0, 0),
	["RightWrist"] = CFrame.Angles(-0.10471975511965978, 0, 0),
	["LeftShoulder"] = CFrame.Angles(-0.05235987755982989, 0, -0.10471975511965978),
	["LeftElbow"] = CFrame.Angles(0.17453292519943295, 0, 0),
	["LeftWrist"] = CFrame.Angles(0, 0, 0),
	["LeftHip"] = CFrame.Angles(0.10471975511965978, -0.06981317007977318, -0.03490658503988659),
	["LeftKnee"] = CFrame.Angles(-0.12217304763960307, 0, 0),
	["LeftAnkle"] = CFrame.Angles(0.03490658503988659, 0, 0),
	["RightHip"] = CFrame.Angles(-0.03490658503988659, 0.10471975511965978, 0.05235987755982989),
	["RightKnee"] = CFrame.Angles(-0.017453292519943295, 0, 0),
	["RightAnkle"] = CFrame.Angles(0, 0, -0.05235987755982989)
}
local function v_u_539(p535) -- name: prepRig
	local v536 = p535:FindFirstChild("HumanoidRootPart")
	for _, v537 in p535:GetDescendants() do
		if v537:IsA("BasePart") then
			v537.Anchored = v537 == v536
			v537.CanCollide = false
			v537.CanTouch = false
			v537.CanQuery = false
			v537.Massless = true
		else
			if not (v537:IsA("Script") or v537:IsA("LocalScript")) then
				continue
			end
			v537:Destroy()
		end
	end
	local v_u_538 = p535:FindFirstChildOfClass("Humanoid")
	if v_u_538 then
		v_u_538.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v_u_538.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		v_u_538.PlatformStand = true
		v_u_538.BreakJointsOnDeath = false
		v_u_538.RequiresNeck = false
		pcall(function()
			-- upvalues: (copy) v_u_538
			v_u_538:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
		end)
	end
end
local function v_u_556(p540, p541, p542, p543) -- name: poseRig
	-- upvalues: (copy) v_u_534, (copy) v_u_5
	if p540 then
		local v544 = p541 * 1.55
		local v545 = math.sin(v544)
		local v546 = p541 * 0.37
		local v547 = math.sin(v546)
		local v548 = p543 and -1 or 1
		for v549, v550 in p540 do
			local v551 = v_u_534[v549]
			if p543 then
				local v552
				if string.sub(v549, 1, 4) == "Left" then
					v552 = "Right" .. string.sub(v549, 5)
				elseif string.sub(v549, 1, 5) == "Right" then
					v552 = "Left" .. string.sub(v549, 6)
				else
					v552 = v549
				end
				local v553, v554, v555 = (v_u_534[v552] or v551):ToEulerAnglesXYZ()
				v551 = CFrame.Angles(v553, -v554, -v555)
			end
			if v549 == "Waist" then
				v550.Transform = v551 * CFrame.Angles(v_u_5(v545 * 0.9), v_u_5(v547 * 1.2 * v548), 0)
			elseif v549 == "Neck" then
				v550.Transform = v551 * CFrame.Angles(v_u_5(-v545 * 0.5), v_u_5(p542), 0)
			elseif v549 == "RightShoulder" or v549 == "LeftShoulder" then
				v550.Transform = v551 * CFrame.Angles(v_u_5(v545 * 0.6), 0, 0)
			elseif v549 == "Root" then
				v550.Transform = v551 * CFrame.new(0, v545 * 0.02, 0) * CFrame.Angles(0, 0, (v_u_5(v547 * 0.6 * v548)))
			else
				v550.Transform = v551
			end
		end
	end
end
local function v_u_560(p557) -- name: motorsOf
	-- upvalues: (copy) v_u_534
	local v558 = {}
	for _, v559 in p557:GetDescendants() do
		if not (v559:IsA("Motor6D") and v_u_534[v559.Name]) then
			continue
		end
		v558[v559.Name] = v559
	end
	return v558
end
function v_u_4._looks(p_u_561) -- name: _looks
	local v562, v563 = pcall(function()
		-- upvalues: (copy) p_u_561
		return p_u_561.cctx.shared.Looks
	end)
	if v562 and type(v563) == "table" then
		return v563
	else
		return nil
	end
end
function v_u_4._avatarTemplate(p564) -- name: _avatarTemplate
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v565 = game:GetService("Players").LocalPlayer
	local v566 = v_u_2:FindFirstChild("HushAvatars")
	if v566 then
		if v565 then
			local v567 = v565.UserId
			v565 = v566:FindFirstChild((tostring(v567)))
		end
	else
		v565 = v566
	end
	local v568, v569 = v_u_4.avatarSource(v565)
	p564.heroWhy = v569
	local v570
	if v569 == "loading" then
		v570 = true
	elseif v569 == nil then
		v570 = false
	else
		v570 = string.sub(v569, 1, 8) == "arriving"
	end
	p564.heroPending = v570
	return v568
end
function v_u_4._heroNote(p_u_571, p_u_572, p_u_573) -- name: _heroNote
	local v574 = game:GetService("Players").LocalPlayer
	local v575
	if p_u_573 then
		v575 = p_u_572 .. ": " .. p_u_573
	else
		v575 = p_u_572
	end
	if p_u_571.heroNoteText ~= v575 then
		p_u_571.heroNoteText = v575
		if v574 then
			v574:SetAttribute("MenuHero", v575)
			local v576, v577 = pcall(function()
				-- upvalues: (copy) p_u_571, (copy) p_u_572, (copy) p_u_573
				return p_u_571.cctx.shared.AvatarRules.heroFault(p_u_572, p_u_573)
			end)
			local v578 = "MenuHeroFault"
			if not v576 then
				v577 = nil
			end
			v574:SetAttribute(v578, v577)
		end
		if p_u_572 == "block" and (p_u_573 and (p_u_573 ~= "loading" and string.sub(p_u_573, 1, 8) ~= "arriving")) then
			warn("[MenuScene] hero is the block survivor:", p_u_573)
			if v574 then
				v574:SetAttribute("ClientError", "menu hero: " .. p_u_573)
			end
		end
	end
end
function v_u_4._heroAssets(_, p579) -- name: _heroAssets
	-- upvalues: (copy) v_u_4
	local v580 = game:GetService("Players").LocalPlayer
	if v580 then
		local v581 = v_u_4.assetNote(p579)
		if v580:GetAttribute("MenuHeroAssets") ~= v581 then
			v580:SetAttribute("MenuHeroAssets", v581)
			if v581 ~= nil and v581 ~= "ok" then
				warn("[MenuScene] hero avatar assets: " .. v581 .. " (read AvatarState, HushLookSource, MenuHero on the player)")
			end
		end
	end
end
function v_u_4._blockSurvivor(p_u_582, p_u_583, p_u_584) -- name: _blockSurvivor
	local v586, v587 = pcall(function()
		-- upvalues: (copy) p_u_582, (copy) p_u_584, (copy) p_u_583
		local v585 = p_u_582.cctx.shared
		return v585.BlockRig.survivor(p_u_584 or v585.BlockRigSpec.variantFor(p_u_583))
	end)
	if v586 and (typeof(v587) == "Instance" and v587:IsA("Model")) then
		return v587
	end
	warn("[MenuScene] block rig failed:", v587)
	return nil
end
function v_u_4._buildSurvivor(p588) -- name: _buildSurvivor
	-- upvalues: (copy) v_u_4, (copy) v_u_539, (copy) v_u_92, (copy) v_u_560
	local v589 = nil
	local v590
	if p588.heroForceBlock then
		v590 = nil
	else
		v590 = p588:_avatarTemplate()
	end
	p588.heroAvatar = v590
	if v590 then
		v589 = v590:Clone()
		local v591, v592 = v_u_4.avatarComplete(v589)
		if not v591 then
			if v589 then
				v589:Destroy()
			end
			p588.heroWhy = "clone incomplete: " .. tostring(v592)
			v589 = nil
		end
	end
	if v589 then
		p588:_heroNote("avatar", nil)
		p588:_heroAssets(v590)
	else
		local v593 = game:GetService("Players").LocalPlayer
		v589 = p588:_blockSurvivor(v593 and v593.UserId or 0)
		local v594 = "block"
		local v595
		if p588.heroForceBlock then
			v595 = p588.heroWhy or "repair"
		else
			v595 = p588.heroWhy
		end
		p588:_heroNote(v594, v595)
		p588:_heroAssets(nil)
	end
	if v589 and v589:IsA("Model") then
		v589.Name = "MenuSurvivor"
		v_u_539(v589)
		v589:PivotTo(p588:CF(Vector3.new(0, 0.5, 0), -0.24434609527920614))
		local v596 = v_u_92(v589)
		local v597 = v589:GetPivot()
		local v598 = p588.origin.Y + 0.5 - v596
		v589:PivotTo(v597 + Vector3.new(0, v598, 0))
		p588.survivorBase = v589:GetPivot()
		v589.Parent = p588.root
		p588.survivor = v589
		p588.motors = v_u_560(v589)
		local v599 = v589:FindFirstChild("Head")
		local v600
		if v599 then
			v600 = v599.Position - Vector3.new(0, 1.6, 0)
		else
			v600 = p588:W(Vector3.new(0, 4, 0))
		end
		p588.chest = v600
		p588:_pose(0)
	end
end
function v_u_4._pose(p601, p602) -- name: _pose
	-- upvalues: (copy) v_u_556
	v_u_556(p601.motors, p602, p601.headTurn)
end
function v_u_4._mateRows(p603) -- name: _mateRows
	-- upvalues: (copy) v_u_63
	local v604 = game:GetService("Players").LocalPlayer
	local v605 = {}
	for _, v606 in p603.squadRows do
		if type(v606) ~= "table" then
			continue
		end
		local v607 = v606.userId
		local v608
		if v604 then
			v608 = v604.UserId
		else
			v608 = v604
		end
		if v607 == v608 then
			continue
		end
		table.insert(v605, v606)
	end
	for _, v609 in p603:fakeRows() do
		table.insert(v605, v609)
	end
	while v_u_63 < #v605 do
		table.remove(v605)
	end
	return v605
end
function v_u_4.fakeRows(p610) -- name: fakeRows
	local v611 = game:GetService("Players").LocalPlayer
	local v612 = {}
	for v613 = 1, p610.fakeN or 0 do
		local v614 = {
			["userId"] = nil,
			["variant"] = nil,
			["displayName"] = nil,
			["ready"] = nil,
			["leader"] = false,
			["place"] = "Menu",
			["where"] = nil,
			["region"] = nil,
			["fake"] = true,
			["userId"] = v611 and (v611.UserId or 0) or 0,
			["variant"] = (v613 - 1) % 4 + 1,
			["displayName"] = "Mate " .. v613,
			["ready"] = p610.searchWord ~= nil and true or v613 % 2 == 1,
			["where"] = p610.searchWord and "PLAY" or ({ "TRADERS", "CHARACTER", "HIDEOUT" })[(v613 - 1) % 3 + 1],
			["region"] = ({ "NA", "EU", "AS" })[(v613 - 1) % 3 + 1]
		}
		table.insert(v612, v614)
	end
	return v612
end
function v_u_4.setSquad(p615, p616) -- name: setSquad
	p615.squadRows = type(p616) ~= "table" and {} or table.clone(p616)
	p615:_applySquad()
end
function v_u_4._mateSource(p_u_617, p_u_618) -- name: _mateSource
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_7, (ref) v_u_8
	if p_u_618.fake then
		local v619 = p_u_618.variant or 1
		return "block:" .. tostring(v619), nil, nil
	end
	local v620 = v_u_2:FindFirstChild("HushAvatars")
	local v621 = v_u_4.avatarSource
	if v620 then
		local v622 = p_u_618.userId
		v620 = v620:FindFirstChild((tostring(v622)))
	end
	local v623 = v621(v620)
	if not v623 then
		local v624, v625 = pcall(function()
			-- upvalues: (copy) p_u_617, (copy) p_u_618
			return p_u_617.cctx.shared.BlockRigSpec.variantFor(p_u_618.userId)
		end)
		return "block:" .. tostring(not v624 and 1 or v625), nil, nil
	end
	local v626 = v_u_7[v623]
	if not v626 then
		v_u_8 = v_u_8 + 1
		v626 = v_u_8
		v_u_7[v623] = v626
	end
	local v627 = p_u_618.userId
	return "avatar:" .. tostring(v627) .. ":" .. v626, v623, nil
end
function v_u_4._buildMate(p628, p629, p630, p631, p632, p633) -- name: _buildMate
	-- upvalues: (copy) v_u_539, (copy) v_u_62, (copy) v_u_92, (copy) v_u_560, (copy) v_u_556
	local v634
	if p632 then
		v634 = p632:Clone()
	else
		local v635 = string.match
		local v636 = tonumber(v635(p631, "^block:(%d+)$"))
		v634 = p628:_blockSurvivor(p630.userId, v636)
	end
	if not (v634 and v634:IsA("Model")) then
		if v634 then
			v634:Destroy()
		end
		return nil
	end
	v634.Name = "SquadMate" .. p629
	v_u_539(v634)
	local v637 = v_u_62[p629]
	local v638 = v637.pos.X
	local v639 = v637.pos.Z
	v634:PivotTo(p628:CF(Vector3.new(v638, 0.5, v639), v637.yaw))
	local v640 = v_u_92(v634)
	local v641 = v634:GetPivot()
	local v642 = p628.origin.Y + 0.5 - v640
	v634:PivotTo(v641 + Vector3.new(0, v642, 0))
	local v643 = (v_u_92(v634) - (p628.origin.Y + 0.5)) * 100 + 0.5
	v634:SetAttribute("GroundGap", math.floor(v643) / 100)
	v634.Parent = p628.root
	local v644 = {
		["key"] = nil,
		["model"] = nil,
		["motors"] = nil,
		["row"] = nil,
		["phase"] = nil,
		["mirror"] = nil,
		["head"] = 0,
		["headTarget"] = 0,
		["nextHead"] = nil,
		["plateKey"] = "",
		["equipped"] = nil,
		["equipKey"] = "",
		["look"] = nil,
		["key"] = p631,
		["model"] = v634,
		["motors"] = v_u_560(v634),
		["row"] = p630,
		["phase"] = v637.phase,
		["mirror"] = v637.mirror,
		["nextHead"] = p629 * 1.3 + 2,
		["equipped"] = {},
		["look"] = p633
	}
	v_u_556(v644.motors, p628.t + v644.phase, 0, v644.mirror)
	p628:_dressMate(v644)
	return v644
end
function v_u_4._dressMate(p_u_645, p_u_646) -- name: _dressMate
	-- upvalues: (copy) v_u_4, (copy) v_u_556
	if type(p_u_646) == "table" and p_u_646.model then
		local v647 = p_u_646.row
		local v648 = v_u_4.kitSlots
		local v649
		if type(v647) == "table" then
			v649 = v647.kit
		else
			v649 = nil
		end
		local v650 = v648(v649)
		if v650 == nil and (type(v647) == "table" and v647.fake) then
			v650 = p_u_645.lastSlots
		end
		local v651 = p_u_645._dress
		local v652 = p_u_646.model
		local function v653()
			-- upvalues: (ref) v_u_556, (copy) p_u_646
			v_u_556(p_u_646.motors, 0, 0, p_u_646.mirror)
		end
		local function v654()
			-- upvalues: (ref) v_u_556, (copy) p_u_646, (copy) p_u_645
			v_u_556(p_u_646.motors, p_u_645.t + p_u_646.phase, p_u_646.head or 0, p_u_646.mirror)
		end
		local v655, v656 = pcall(v651, p_u_645, v652, v650, p_u_646, v653, v654)
		if not v655 then
			warn("[MenuScene] squad mate gear failed:", v656)
		end
	end
end
function v_u_4.gearHidden(p657, p658, p659) -- name: gearHidden
	if not p657 then
		p658 = p659
	end
	return p658 == true
end
function v_u_4.hideGearIds(p660) -- name: hideGearIds
	p660.armor = nil
	p660.boots = nil
	p660.legs = nil
	p660.bag = nil
	return p660
end
function v_u_4._watchGear(p_u_661) -- name: _watchGear
	local v662 = game:GetService("Players").LocalPlayer
	if v662 and not p_u_661.gearConns then
		local function v669() -- name: redress
			-- upvalues: (copy) p_u_661
			if p_u_661.lastSlots then
				local v663 = p_u_661.setLoadout
				local v664 = p_u_661
				local v665 = p_u_661.lastSlots
				pcall(v663, v664, v665)
			end
			for _, v666 in p_u_661.mates or {} do
				local v667 = p_u_661._dressMate
				local v668 = p_u_661
				pcall(v667, v668, v666)
			end
		end
		p_u_661.gearConns = { v662:GetAttributeChangedSignal("HideMyGear"):Connect(v669), v662:GetAttributeChangedSignal("HideOthersGear"):Connect(v669) }
	end
end
function v_u_4._syncHeadwear(p_u_670, p_u_671) -- name: _syncHeadwear
	if p_u_671 then
		pcall(function()
			-- upvalues: (copy) p_u_670, (copy) p_u_671
			local v672 = p_u_670.cctx.shared.WornArmor
			local v673 = p_u_671:FindFirstChild("HushWornArmor")
			local v674 = v672.syncHeadwear
			local v675 = p_u_671
			local v676
			if v673 == nil then
				v676 = false
			else
				v676 = v673:GetAttribute("HidesHeadwear") == true
			end
			v674(v675, v676)
		end)
	end
end
function v_u_4._watchHeadwear(p_u_677) -- name: _watchHeadwear
	local v678 = game:GetService("Players").LocalPlayer
	if v678 and not p_u_677.headwearConn then
		p_u_677.headwearConn = v678:GetAttributeChangedSignal("HideHeadwear"):Connect(function()
			-- upvalues: (copy) p_u_677
			p_u_677:_syncHeadwear(p_u_677.survivor)
			for _, v679 in p_u_677.mates or {} do
				p_u_677:_syncHeadwear(v679.model)
			end
		end)
	end
end
function v_u_4._applySquad(p680) -- name: _applySquad
	-- upvalues: (copy) v_u_63
	if p680.root then
		local v681 = p680:_mateRows()
		for v682 = 1, v_u_63 do
			local v683 = v681[v682]
			local v684 = p680.mates[v682]
			if v683 then
				local v685 = p680:_mateSource(v683)
				local v686 = v683.userId
				local v687 = tostring(v686) .. (not v683.fake and "" or "f" .. v682)
				if v684 and (v684.key ~= v685 or (v684.ident ~= v687 or not v684.model.Parent)) then
					v684.model:Destroy()
					p680.mates[v682] = nil
					v684 = nil
				end
				if v684 then
					v684.row = v683
					p680:_dressMate(v684)
				else
					local _, v688, v689 = p680:_mateSource(v683)
					local v690 = p680._buildMate
					local v691, v692 = pcall(v690, p680, v682, v683, v685, v688, v689)
					if v691 and v692 then
						v692.ident = v687
						p680.mates[v682] = v692
					else
						if v691 then
							continue
						end
						warn("[MenuScene] squad mate build failed:", v692)
					end
				end
			else
				if not v684 then
					continue
				end
				v684.model:Destroy()
				p680.mates[v682] = nil
			end
		end
		p680:_plates()
	end
end
function v_u_4._heroRow(p693) -- name: _heroRow
	local v694 = game:GetService("Players").LocalPlayer
	for _, v695 in p693.squadRows do
		if type(v695) ~= "table" or (not v694 or v695.userId ~= v694.UserId) then
			continue
		end
		return v695
	end
	local v696
	if v694 then
		v696 = v694:GetAttribute("Title")
	else
		v696 = nil
	end
	local v697
	if v694 then
		v697 = v694:GetAttribute("TitleKey")
	else
		v697 = nil
	end
	local v698 = {
		["userId"] = nil,
		["displayName"] = nil,
		["ready"] = true,
		["leader"] = true,
		["place"] = "Menu",
		["title"] = nil,
		["titleKey"] = nil,
		["userId"] = v694 and (v694.UserId or 0) or 0,
		["displayName"] = v694 and v694.DisplayName or "You"
	}
	if type(v696) ~= "string" or v696 == "" then
		v696 = nil
	end
	v698.title = v696
	if type(v697) ~= "string" then
		v697 = nil
	end
	v698.titleKey = v697
	return v698
end
function v_u_4._plates(p699) -- name: _plates
	local v700 = next(p699.mates) ~= nil
	local v701 = p699.survivor
	if v701 then
		local v702
		if v700 then
			v702 = p699:_heroRow()
		else
			v702 = nil
		end
		if not v700 then
			local v703 = game:GetService("Players").LocalPlayer
			local v704
			if v703 then
				v704 = v703:GetAttribute("Title")
			else
				v704 = v703
			end
			if type(v704) == "string" and v704 ~= "" then
				local v705 = v703:GetAttribute("TitleKey")
				v702 = {
					["displayName"] = nil,
					["title"] = nil,
					["titleKey"] = nil,
					["solo"] = true,
					["displayName"] = v703.DisplayName,
					["title"] = v704
				}
				if type(v705) ~= "string" then
					v705 = nil
				end
				v702.titleKey = v705
			end
		end
		p699:_plate(v701, v702, true)
	end
	for _, v706 in p699.mates do
		p699:_plate(v706.model, v706.row, false)
	end
end
function v_u_4._plate(p_u_707, p708, p_u_709, p710) -- name: _plate
	local v711 = p708:FindFirstChild("SquadPlate")
	if p_u_709 then
		local v712 = p_u_709.place or "Menu"
		local v713 = tostring(v712)
		local v714 = p_u_709.where
		local v715
		if type(v714) == "string" and p_u_709.where ~= "" then
			v715 = p_u_709.where
		else
			v715 = v713 == "Raid" and "IN RAID" or (v713 == "Transit" and "TRAVELLING" or (v713 == "Hideout" and "HIDEOUT" or "MENU"))
		end
		local v716 = (v713 == "Raid" or v713 == "Transit") and "info" or "muted"
		local v717, v_u_718
		if p_u_709.leader then
			v717 = "Ready"
			v_u_718 = "accent"
		elseif p_u_709.ready then
			v717 = "Ready"
			v_u_718 = "success"
		else
			v717 = "Not ready"
			v_u_718 = "muted"
		end
		local v719 = p_u_709.displayName or (p_u_709.name or "?")
		local v720 = tostring(v719)
		local v721 = nil
		local v722, v723 = pcall(function()
			-- upvalues: (copy) p_u_707
			return p_u_707.cctx.lib.ClanTagText
		end)
		if v722 and type(v723) == "table" then
			local v724 = v723.byUserId(p_u_709.userId)
			if v724 ~= nil and (v723.richFor ~= nil and v723.esc ~= nil) then
				v721 = v723.richFor(v724, v723.styleByUserId(p_u_709.userId), nil) .. v723.esc(v720)
			end
			v720 = v723.label(v724, v720)
		end
		local v725 = p_u_709.region
		local v726
		if type(v725) == "string" then
			v726 = p_u_709.region
		else
			v726 = nil
		end
		if not v726 and p710 then
			v726 = game:GetService("Players").LocalPlayer
			if v726 then
				v726 = v726:GetAttribute("DevRegion") or v726:GetAttribute("Region")
			end
			if type(v726) ~= "string" then
				v726 = nil
			end
		end
		if v726 and not string.match(v726, "^%u%u%u?$") then
			v726 = nil
		end
		local v727 = not v726 and "" or v726 .. "  \194\183  "
		local v728 = p_u_707.searchWord
		local v729 = p_u_709.title
		local v730
		if type(v729) == "string" and p_u_709.title ~= "" then
			v730 = p_u_709.title
		else
			v730 = nil
		end
		local v731 = p_u_709.solo == true
		local v_u_732 = 0
		local v_u_733 = nil
		if v730 then
			pcall(function()
				-- upvalues: (copy) p_u_707, (ref) v_u_732, (copy) p_u_709, (ref) v_u_733
				if p_u_707.cctx.config.flag("TitleRarity") ~= false then
					local v734 = p_u_707.cctx.shared.TitleRarity
					v_u_732 = v734.rarityOfRow(p_u_709, v734.namesFrom(p_u_707.cctx.shared))
					v_u_733 = v734
				end
			end)
		end
		local v735 = v720 .. "|" .. v715 .. "|" .. v717 .. "|" .. v_u_718 .. "|" .. tostring(p710) .. "|" .. tostring(v728) .. "|" .. v727 .. "|" .. tostring(v730) .. "|" .. tostring(v731) .. "|" .. tostring(v_u_732) .. "|" .. tostring(v721)
		if v711 and v711:GetAttribute("Key") == v735 then
			return
		else
			if v711 then
				v711:Destroy()
			end
			local v736 = p708:FindFirstChild("Head")
			if v736 or not (p710 and p_u_707.heroAvatar) then
				local v_u_737 = p_u_707.cctx.shared.Theme
				local v738 = v_u_737.color
				local v739 = v_u_737.uiScale
				local v740, v741 = pcall(v739)
				local v_u_742 = (not v740 or type(v741) ~= "number") and 1 or math.clamp(v741, 0.85, 1.2)
				local v_u_743 = v730 and 13 or 0
				local v744 = v_u_742 * 170
				local v745 = math.floor(v744)
				local v746
				if v731 then
					v746 = 38
				elseif v728 then
					v746 = v_u_743 + 38
				else
					v746 = v_u_743 + 52
				end
				local v747 = v746 * v_u_742
				local v748 = math.floor(v747)
				local v749 = v_u_737.isPhone
				local v750, v751 = pcall(v749)
				local v752 = Instance.new("BillboardGui")
				v752.Name = "SquadPlate"
				v752:SetAttribute("Key", v735)
				v752.Adornee = v736 or p708.PrimaryPart
				v752.Size = UDim2.fromOffset(v745, v748)
				v752.StudsOffsetWorldSpace = Vector3.new(0, v736 and 1.7 or 6, 0)
				v752.AlwaysOnTop = true
				v752.LightInfluence = 0
				v752.MaxDistance = 140
				v752.ResetOnSpawn = false
				v752.ClipsDescendants = false
				local v_u_753 = Instance.new("Frame")
				v_u_753.Name = "Panel"
				v_u_753.BackgroundColor3 = v738.bg
				v_u_753.BackgroundTransparency = 0.18
				v_u_753.BorderSizePixel = 0
				v_u_753.AnchorPoint = Vector2.new(0.5, 0.5)
				v_u_753.Position = UDim2.fromScale(0.5, 0.5)
				v_u_753.Size = UDim2.fromOffset(0, v748)
				v_u_753.AutomaticSize = Enum.AutomaticSize.X
				v_u_753.Parent = v752
				local v754 = Instance.new("UIPadding")
				local v755 = UDim.new
				local v756 = v_u_742 * 10
				v754.PaddingRight = v755(0, (math.floor(v756)))
				v754.Parent = v_u_753
				local v_u_757 = Instance.new("UIStroke")
				local v758
				if p710 then
					v758 = v738.accentDim
				else
					v758 = v738.line
				end
				v_u_757.Color = v758
				v_u_757.Thickness = 1
				v_u_757.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				pcall(function()
					-- upvalues: (copy) v_u_757
					v_u_757.BorderStrokePosition = Enum.BorderStrokePosition.Inner
				end)
				v_u_757.Parent = v_u_753
				local v759 = Instance.new("Frame")
				v759.Name = "Bar"
				local v760
				if v728 then
					v760 = v738.accent
				else
					v760 = v_u_737.kindColor(v_u_718)
				end
				v759.BackgroundColor3 = v760
				v759.BorderSizePixel = 0
				local v761 = UDim2.new
				local v762 = v_u_742 * 3
				local v763 = math.floor(v762)
				v759.Size = v761(0, math.max(2, v763), 1, 0)
				v759.Parent = v_u_753
				local function v775(p764, p765, p766, p767, p768, p769, p770, p771, p772) -- name: text
					-- upvalues: (copy) v_u_753
					local v773 = Instance.new("TextLabel")
					v773.Name = p764
					v773.BackgroundTransparency = 1
					v773.FontFace = p766
					v773.TextSize = p767
					v773.TextColor3 = p768
					v773.TextXAlignment = Enum.TextXAlignment.Left
					v773.TextTruncate = Enum.TextTruncate.AtEnd
					v773.Text = p765
					v773.Position = UDim2.fromOffset(p769, p770)
					v773.Size = UDim2.fromOffset(0, p771)
					v773.AutomaticSize = Enum.AutomaticSize.X
					local v774 = Instance.new("UISizeConstraint")
					v774.MaxSize = Vector2.new(p772, p771)
					v774.Parent = v773
					v773.Parent = v_u_753
					return v773
				end
				local v776 = "Name"
				local v777 = v_u_737.font.bodyMedium
				local v778 = v_u_742 * 14
				local v779 = math.floor(v778)
				local v780
				if p710 then
					v780 = v738.accent
				else
					v780 = v738.text
				end
				local v781 = v_u_742 * 11
				local v782 = math.floor(v781)
				local v783 = v_u_742 * 3
				local v784 = math.floor(v783)
				local v785 = v_u_742 * 18
				local v786 = math.floor(v785)
				local v787 = v_u_742 * 24
				local v788 = v775(v776, v720, v777, v779, v780, v782, v784, v786, v745 - math.floor(v787))
				if v721 ~= nil then
					v788.RichText = true
					v788.Text = v721
				end
				if v730 then
					local v789 = v775
					local v790 = "Title"
					local v791 = string.upper(v730)
					local v792 = v_u_737.font.heading
					local v793 = v_u_742 * 11
					local v794 = math.floor(v793)
					if v750 and v751 == true then
						v794 = math.max(v794, 10)
					end
					local v795
					if v_u_733 and v_u_732 > 0 then
						v795 = v_u_733.textColor(v_u_732, v_u_737)
					else
						v795 = v738.accent
					end
					local v796 = v_u_742 * 11
					local v797 = math.floor(v796)
					local v798 = v_u_742 * 21
					local v799 = math.floor(v798)
					local v800 = v_u_742 * 13
					local v801 = math.floor(v800)
					local v802 = v_u_742 * 24
					v789(v790, v791, v792, v794, v795, v797, v799, v801, v745 - math.floor(v802))
				end
				if v731 then
					v752.Parent = p708
					return
				elseif v728 then
					local v803 = v775
					local v804 = "Status"
					local v805 = v727 .. string.upper(v728)
					local v806 = v_u_737.font.heading
					local v807 = v_u_742 * 11
					local v808 = math.floor(v807)
					if v750 and v751 == true then
						v808 = math.max(v808, 10)
					end
					local v809 = v738.accent
					local v810 = v_u_742 * 11
					local v811 = math.floor(v810)
					local v812 = (v_u_743 + 21) * v_u_742
					local v813 = math.floor(v812)
					local v814 = v_u_742 * 13
					local v815 = math.floor(v814)
					local v816 = v_u_742 * 24
					v803(v804, v805, v806, v808, v809, v811, v813, v815, v745 - math.floor(v816))
					v752.Parent = p708
				else
					local v817 = v_u_718 == "success" and true or v_u_718 == "accent"
					local v818 = v775
					local v819 = "Where"
					local v820 = v727 .. string.upper(v715)
					local v821 = v_u_737.font.heading
					local v822 = v_u_742 * 11
					local v823 = math.floor(v822)
					if v750 and v751 == true then
						v823 = math.max(v823, 10)
					end
					local v824
					if v716 == "info" then
						v824 = v_u_737.kindColor("info")
					else
						v824 = v738.text2
					end
					local v825 = v_u_742 * 11
					local v826 = math.floor(v825)
					local v827 = (v_u_743 + 21) * v_u_742
					local v828 = math.floor(v827)
					local v829 = v_u_742 * 13
					local v830 = math.floor(v829)
					local v831 = v_u_742 * 24
					v818(v819, v820, v821, v823, v824, v826, v828, v830, v745 - math.floor(v831))
					local v832 = v775
					local v833 = "Status"
					local v834 = string.upper(v717)
					local v835 = v_u_737.font.heading
					local v836 = v_u_742 * 11
					local v837 = math.floor(v836)
					if v750 and v751 == true then
						v837 = math.max(v837, 10)
					end
					local v838 = v_u_737.kindColor(v_u_718)
					local v839 = (v817 and 25 or 11) * v_u_742
					local v840 = math.floor(v839)
					local v841 = (v_u_743 + 35) * v_u_742
					local v842 = math.floor(v841)
					local v843 = v_u_742 * 13
					local v844 = math.floor(v843)
					local v845 = v_u_742 * 38
					v832(v833, v834, v835, v837, v838, v840, v842, v844, v745 - math.floor(v845))
					local v_u_846 = nil
					local function v847()
						-- upvalues: (ref) v_u_846, (copy) p_u_707
						v_u_846 = p_u_707.cctx.lib.HushUI
					end
					pcall(v847)
					if v_u_846 and v817 then
						local function v856()
							-- upvalues: (ref) v_u_846, (ref) v_u_718, (copy) v_u_753, (copy) v_u_742, (copy) v_u_737, (copy) v_u_743
							local v848 = v_u_846.icon
							local v849 = v_u_718 == "success" and "check" or "star"
							local v850 = {
								["parent"] = v_u_753
							}
							local v851 = v_u_742 * 10
							v850.size = math.floor(v851)
							v850.color = v_u_737.kindColor(v_u_718)
							local v852 = UDim2.fromOffset
							local v853 = v_u_742 * 11
							local v854 = math.floor(v853)
							local v855 = (v_u_743 + 36) * v_u_742
							v850.position = v852(v854, (math.floor(v855)))
							v848(v849, v850)
						end
						pcall(v856)
					end
					v752.Parent = p708
				end
			else
				return
			end
		end
	else
		if v711 then
			v711:Destroy()
		end
		return
	end
end
v_u_4.PLATE_RAISE_GAP = 8
function v_u_4.plateRows(p_u_857, p858, p859) -- name: plateRows
	local v860 = {}
	for v861 = 1, #p_u_857 do
		v860[v861] = v861
	end
	table.sort(v860, function(p862, p863)
		-- upvalues: (copy) p_u_857
		return p_u_857[p862] < p_u_857[p863]
	end)
	local v864 = { (-1 / 0), (-1 / 0) }
	local v865 = {}
	for _, v866 in v860 do
		local v867 = p_u_857[v866] - p858[v866] / 2
		local v868 = p_u_857[v866] + p858[v866] / 2
		local v869 = v864[1] + p859 <= v867 and 0 or (v864[2] + p859 <= v867 and 1 or (v864[1] <= v864[2] and 0 or 1))
		v864[v869 + 1] = v868
		v865[v866] = v869
	end
	return v865
end
function v_u_4._stagger(p870) -- name: _stagger
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_4
	local v_u_871 = v_u_1.CurrentCamera
	local v872 = p870.cctx and p870.cctx.shared
	if v872 then
		v872 = p870.cctx.shared.Theme
	end
	if v_u_871 and v872 then
		local v873 = v872.isPhone
		local v874, v875 = pcall(v873)
		local v876 = Vector2.new(1920, 1080)
		local v877 = v872.viewport
		local v878, v_u_879 = pcall(v877)
		if not v878 or (typeof(v_u_879) ~= "Vector2" or v_u_879.X <= 1) then
			v_u_879 = v876
		end
		local v880 = v_u_5(v_u_871.FieldOfView / 2)
		local v_u_881 = math.tan(v880)
		local v_u_882 = v_u_879.X / v_u_879.Y
		local v_u_883 = {}
		local function v893(p884) -- name: add
			-- upvalues: (copy) v_u_871, (copy) v_u_883, (copy) v_u_881, (copy) v_u_882, (ref) v_u_879
			local v885
			if p884 then
				v885 = p884:FindFirstChild("SquadPlate")
			else
				v885 = nil
			end
			local v886
			if p884 then
				v886 = p884:FindFirstChild("Head")
			else
				v886 = nil
			end
			if v885 and v886 then
				local v887 = v_u_871.CFrame:PointToObjectSpace(v886.Position)
				if v887.Z < -0.05 then
					local v888 = v885:FindFirstChild("Panel")
					local v889
					if v888 and v888.AbsoluteSize.X > 4 then
						v889 = v888.AbsoluteSize.X
					else
						v889 = v885.Size.X.Offset
					end
					local v890 = v_u_883
					local v891 = {
						["bb"] = v885,
						["x"] = (v887.X / (-v887.Z * v_u_881 * v_u_882) + 1) / 2 * v_u_879.X
					}
					local v892 = v885.Size.X.Offset
					v891.w = math.min(v889, v892)
					table.insert(v890, v891)
				end
			else
				return
			end
		end
		v893(p870.survivor)
		for _, v894 in p870.mates do
			v893(v894.model)
		end
		local v895 = {}
		local v896 = {}
		for v897, v898 in v_u_883 do
			local v899 = v898.x
			local v900 = v898.w
			v895[v897] = v899
			v896[v897] = v900
		end
		local v901 = (not v874 or v875 ~= true) and {} or v_u_4.plateRows(v895, v896, 6)
		for v902, v903 in v_u_883 do
			local v904
			if v901[v902] == 1 then
				local v905 = Vector2.new
				local v906 = v_u_4.PLATE_RAISE_GAP
				local v907 = v903.bb.Size.Y.Offset
				v904 = v905(0, 1 + v906 / math.max(1, v907))
			else
				v904 = Vector2.zero
			end
			if v903.bb.SizeOffset == v904 then
				continue
			end
			v903.bb.SizeOffset = v904
		end
	end
end
function v_u_4._checkMates(p908) -- name: _checkMates
	for _, v909 in p908.mates do
		if p908:_mateSource(v909.row) == v909.key then
			continue
		end
		p908:_applySquad()
		return
	end
end
function v_u_4._stepMates(p910, p911) -- name: _stepMates
	-- upvalues: (copy) v_u_556
	for _, v912 in p910.mates do
		v912.nextHead = v912.nextHead - p911
		if v912.nextHead <= 0 then
			v912.nextHead = 4 + math.random() * 7
			v912.headTarget = math.random() < 0.4 and 0 or (math.random() < 0.5 and -18 or 14)
		end
		local v913 = v912.head
		local v914 = v912.headTarget - v912.head
		local v915 = -p911 * 1.2
		v912.head = v913 + v914 * (1 - math.exp(v915))
		v_u_556(v912.motors, p910.t + v912.phase, v912.head, v912.mirror)
	end
end
function v_u_4._lineup(p916) -- name: _lineup
	-- upvalues: (copy) v_u_62
	local v917 = p916.chest or p916:W(Vector3.new(0, 4, 0))
	local v918 = 0
	local v919 = 0
	local v920 = 0
	local v921 = 0
	local v922 = 1
	for v923 in p916.mates do
		local v924 = v_u_62[v923].pos
		local v925 = v924.X
		v918 = math.min(v918, v925)
		local v926 = v924.X
		v919 = math.max(v919, v926)
		v920 = v920 + v924.X
		v921 = v921 + v924.Z
		v922 = v922 + 1
	end
	local v927 = (v918 + v919) / 2
	local v928 = v921 / v922
	return v917 + Vector3.new(v927, 0, v928), v919 - v918, v922
end
function v_u_4._rebuildHero(p929) -- name: _rebuildHero
	if p929.root then
		if p929.survivor then
			p929.survivor:Destroy()
		end
		p929.survivor = nil
		p929.motors = nil
		table.clear(p929.equipped)
		p929.equipKey = ""
		p929:_buildSurvivor()
		if p929.lastSlots then
			p929:setLoadout(p929.lastSlots)
		end
		local v930 = p929._plates
		pcall(v930, p929)
	end
end
function v_u_4._checkAvatar(p931) -- name: _checkAvatar
	-- upvalues: (copy) v_u_4
	if p931.heroForceBlock then
		return
	else
		local v932 = p931:_avatarTemplate()
		local v933
		if v932 == nil and p931.heroAvatar ~= nil then
			v933 = p931.heroPending == true
		else
			v933 = false
		end
		if v932 == p931.heroAvatar or v933 then
			if v932 == nil and p931.heroAvatar == nil then
				p931:_heroNote("block", p931.heroWhy)
			end
			local v934 = p931.survivor
			if v934 and (p931.heroAvatar and p931.heroNoteText == "avatar") then
				local v935, v936 = v_u_4.heroIntact(v934)
				if not v935 then
					p931.heroRepairs = (p931.heroRepairs or 0) + 1
					local v937 = warn
					local v938 = tostring(v936)
					local v939 = p931.heroRepairs
					v937("[MenuScene] hero rig broken (" .. v938 .. "), rebuild " .. tostring(v939))
					local v940 = game:GetService("Players").LocalPlayer
					if v940 then
						v940:SetAttribute("MenuHeroHeals", p931.heroRepairs)
						v940:SetAttribute("ClientError", "menu hero healed: " .. tostring(v936))
					end
					if p931.heroRepairs >= 3 then
						p931.heroForceBlock = true
						p931.heroPending = false
						p931.heroWhy = "rig broken: " .. tostring(v936)
					end
					p931:_rebuildHero()
				end
			end
		else
			p931:_rebuildHero()
		end
	end
end
local function v_u_945(p941, p942) -- name: weldAll
	for _, v943 in p941:GetDescendants() do
		if not v943:IsA("BasePart") then
			continue
		end
		v943.Anchored = false
		v943.CanCollide = false
		v943.CanQuery = false
		v943.CanTouch = false
		v943.Massless = true
		local v944 = Instance.new("WeldConstraint")
		v944.Part0 = p942
		v944.Part1 = v943
		v944.Parent = v943
	end
end
local function v_u_956(p_u_946, p947) -- name: fitScale
	local _, v948 = p_u_946:GetBoundingBox()
	local v949 = v948.X
	local v950 = v948.Y
	local v951 = v948.Z
	local v952 = math.max(v949, v950, v951)
	if v952 > 0.01 then
		local v953 = p947 / v952
		local v_u_954 = math.clamp(v953, 0.3, 2.5)
		local v955 = v_u_954 - 1
		if math.abs(v955) > 0.05 then
			pcall(function()
				-- upvalues: (copy) p_u_946, (copy) v_u_954
				p_u_946:ScaleTo(p_u_946:GetScale() * v_u_954)
			end)
		end
	end
end
local function v_u_992(p957) -- name: worldSize
	local v958 = Vector3.new(1, 1, 1) * (1 / 0)
	local v959 = Vector3.new(-1, -1, -1) * (1 / 0)
	for _, v960 in p957:GetDescendants() do
		if not v960:IsA("BasePart") then
			continue
		end
		local v961 = v960.Size / 2
		local v962 = {}
		local v963 = v961.X
		local v964 = v961.Y
		local v965 = v961.Z
		local v966 = Vector3.new(v963, v964, v965)
		local v967 = -v961.X
		local v968 = v961.Y
		local v969 = v961.Z
		local v970 = Vector3.new(v967, v968, v969)
		local v971 = v961.X
		local v972 = -v961.Y
		local v973 = v961.Z
		local v974 = Vector3.new(v971, v972, v973)
		local v975 = v961.X
		local v976 = v961.Y
		local v977 = -v961.Z
		local v978 = Vector3.new(v975, v976, v977)
		local v979 = -v961.X
		local v980 = -v961.Y
		local v981 = v961.Z
		local v982 = Vector3.new(v979, v980, v981)
		local v983 = -v961.X
		local v984 = v961.Y
		local v985 = -v961.Z
		local v986 = Vector3.new(v983, v984, v985)
		local v987 = v961.X
		local v988 = -v961.Y
		local v989 = -v961.Z
		__set_list(v962, 1, {v966, v970, v974, v978, v982, v986, Vector3.new(v987, v988, v989), -v961})
		for _, v990 in v962 do
			local v991 = v960.CFrame:PointToWorldSpace(v990)
			v958 = v958:Min(v991)
			v959 = v959:Max(v991)
		end
	end
	return v959.X < v958.X and Vector3.new(1, 1, 1) or v959 - v958
end
local function v_u_996(p993) -- name: upright
	-- upvalues: (copy) v_u_992
	p993:PivotTo(CFrame.new())
	local v994 = v_u_992(p993)
	local v995 = CFrame.identity
	if v994.Y <= v994.X and v994.Y <= v994.Z then
		return CFrame.Angles(1.5707963267948966, 0, 0)
	end
	if v994.X <= v994.Y and v994.X <= v994.Z then
		v995 = CFrame.Angles(0, 1.5707963267948966, 0)
	end
	return v995
end
local _ = {
	["vest_light"] = Color3.fromHex("#4A4A3C"),
	["vest_police"] = Color3.fromHex("#1F2733"),
	["vest_platecarrier"] = Color3.fromHex("#3F4433"),
	["vest_military"] = Color3.fromHex("#4B4A36")
}
function v_u_4.kitSlots(p997) -- name: kitSlots
	if type(p997) ~= "table" then
		return nil
	end
	local v998 = {}
	local v999 = p997.p
	local v1000 = p997.pa
	local v1001
	if type(v999) == "string" then
		v1001 = {
			["id"] = v999
		}
		if type(v1000) ~= "table" or #v1000 <= 0 then
			v1000 = nil
		end
		v1001.mods = v1000
	else
		v1001 = nil
	end
	v998.primary = v1001
	local v1002 = p997.s
	local v1003 = p997.sa
	local v1004
	if type(v1002) == "string" then
		v1004 = {
			["id"] = v1002
		}
		if type(v1003) ~= "table" or #v1003 <= 0 then
			v1003 = nil
		end
		v1004.mods = v1003
	else
		v1004 = nil
	end
	v998.secondary = v1004
	local v1005 = p997.m
	v998.melee = type(v1005) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1005
	} or nil
	local v1006 = p997.v
	v998.armor = type(v1006) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1006
	} or nil
	local v1007 = p997.h
	v998.helmet = type(v1007) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1007
	} or nil
	local v1008 = p997.b
	v998.bag = type(v1008) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1008
	} or nil
	local v1009 = p997.f
	v998.boots = type(v1009) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1009
	} or nil
	local v1010 = p997.l
	v998.legs = type(v1010) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1010
	} or nil
	local v1011 = p997.e
	v998.ears = type(v1011) == "string" and {
		["id"] = nil,
		["mods"] = nil,
		["id"] = v1011
	} or nil
	return v998
end
function v_u_4.setLoadout(p_u_1012, p1013) -- name: setLoadout
	p_u_1012.lastSlots = p1013
	local v1014 = p_u_1012.survivor
	if v1014 and v1014.Parent then
		p_u_1012:_dress(v1014, p1013, p_u_1012, function()
			-- upvalues: (copy) p_u_1012
			p_u_1012:_pose(0)
		end, function()
			-- upvalues: (copy) p_u_1012
			p_u_1012:_pose(p_u_1012.t)
		end)
		for _, v1015 in p_u_1012.mates do
			local v1016 = v1015.row
			if type(v1016) ~= "table" or not v1015.row.fake then
				continue
			end
			p_u_1012:_dressMate(v1015)
		end
	end
end
function v_u_4._dress(p_u_1017, p_u_1018, p_u_1019, p_u_1020, p1021, p1022) -- name: _dress
	-- upvalues: (copy) v_u_4, (copy) v_u_77, (copy) v_u_956, (copy) v_u_945, (copy) v_u_996, (copy) v_u_992, (copy) v_u_5
	local v_u_1023 = {}
	local v1024
	if type(p_u_1019) == "table" then
		v1024 = p_u_1019.primary
	else
		v1024 = false
	end
	local v1025
	if type(v1024) == "table" then
		local v1026 = v1024.id
		if type(v1026) == "string" then
			v1025 = v1024.id
		else
			v1025 = nil
		end
	else
		v1025 = nil
	end
	v_u_1023.primary = v1025
	local v1027
	if type(p_u_1019) == "table" then
		v1027 = p_u_1019.secondary
	else
		v1027 = false
	end
	local v1028
	if type(v1027) == "table" then
		local v1029 = v1027.id
		if type(v1029) == "string" then
			v1028 = v1027.id
		else
			v1028 = nil
		end
	else
		v1028 = nil
	end
	v_u_1023.secondary = v1028
	local v1030
	if type(p_u_1019) == "table" then
		v1030 = p_u_1019.melee
	else
		v1030 = false
	end
	local v1031
	if type(v1030) == "table" then
		local v1032 = v1030.id
		if type(v1032) == "string" then
			v1031 = v1030.id
		else
			v1031 = nil
		end
	else
		v1031 = nil
	end
	v_u_1023.melee = v1031
	local v1033
	if type(p_u_1019) == "table" then
		v1033 = p_u_1019.armor
	else
		v1033 = false
	end
	local v1034
	if type(v1033) == "table" then
		local v1035 = v1033.id
		if type(v1035) == "string" then
			v1034 = v1033.id
		else
			v1034 = nil
		end
	else
		v1034 = nil
	end
	v_u_1023.armor = v1034
	local v1036
	if type(p_u_1019) == "table" then
		v1036 = p_u_1019.helmet
	else
		v1036 = false
	end
	local v1037
	if type(v1036) == "table" then
		local v1038 = v1036.id
		if type(v1038) == "string" then
			v1037 = v1036.id
		else
			v1037 = nil
		end
	else
		v1037 = nil
	end
	v_u_1023.helmet = v1037
	local v1039
	if type(p_u_1019) == "table" then
		v1039 = p_u_1019.bag
	else
		v1039 = false
	end
	local v1040
	if type(v1039) == "table" then
		local v1041 = v1039.id
		if type(v1041) == "string" then
			v1040 = v1039.id
		else
			v1040 = nil
		end
	else
		v1040 = nil
	end
	v_u_1023.bag = v1040
	local v1042
	if type(p_u_1019) == "table" then
		v1042 = p_u_1019.boots
	else
		v1042 = false
	end
	local v1043
	if type(v1042) == "table" then
		local v1044 = v1042.id
		if type(v1044) == "string" then
			v1043 = v1042.id
		else
			v1043 = nil
		end
	else
		v1043 = nil
	end
	v_u_1023.boots = v1043
	local v1045
	if type(p_u_1019) == "table" then
		v1045 = p_u_1019.legs
	else
		v1045 = false
	end
	local v1046
	if type(v1045) == "table" then
		local v1047 = v1045.id
		if type(v1047) == "string" then
			v1046 = v1045.id
		else
			v1046 = nil
		end
	else
		v1046 = nil
	end
	v_u_1023.legs = v1046
	local v1048
	if type(p_u_1019) == "table" then
		v1048 = p_u_1019.ears
	else
		v1048 = false
	end
	local v1049
	if type(v1048) == "table" then
		local v1050 = v1048.id
		if type(v1050) == "string" then
			v1049 = v1048.id
		else
			v1049 = nil
		end
	else
		v1049 = nil
	end
	v_u_1023.ears = v1049
	local function v1052()
		-- upvalues: (ref) v_u_4, (copy) p_u_1020, (copy) p_u_1017, (copy) v_u_1023
		local v1051 = game:GetService("Players").LocalPlayer
		if v1051 ~= nil and v_u_4.gearHidden(p_u_1020 == p_u_1017, v1051:GetAttribute("HideMyGear"), v1051:GetAttribute("HideOthersGear")) then
			v_u_4.hideGearIds(v_u_1023)
		end
	end
	pcall(v1052)
	local function v1056()
		-- upvalues: (copy) p_u_1017, (copy) p_u_1018, (ref) v_u_4, (copy) p_u_1020
		local v1053 = game:GetService("Players").LocalPlayer
		local v1054 = p_u_1017.cctx.controllers.GearVisibility
		if v1053 ~= nil and v1054 ~= nil then
			local v1055 = v1054.syncBack
			if type(v1055) == "function" then
				v1054.syncBack(p_u_1018, v_u_4.gearHidden(p_u_1020 == p_u_1017, v1053:GetAttribute("HideMyGear"), v1053:GetAttribute("HideOthersGear")))
			end
		end
	end
	pcall(v1056)
	local v_u_1057 = nil
	local function v1058()
		-- upvalues: (ref) v_u_1057, (copy) p_u_1017
		v_u_1057 = p_u_1017.cctx.shared.WeaponDress
	end
	pcall(v1058)
	local v_u_1059
	if v_u_1057 and v_u_1057.displayScale then
		local v1060 = v_u_1057.displayScale
		local v1061, v1062 = pcall(v1060)
		v_u_1059 = (not v1061 or type(v1062) ~= "number") and 1 or v1062
	else
		v_u_1059 = 1
	end
	p_u_1020.gunScale = v_u_1059
	local v_u_1063 = nil
	local function v1064()
		-- upvalues: (ref) v_u_1063, (copy) p_u_1017
		v_u_1063 = p_u_1017.cctx.shared.SkinApply
	end
	pcall(v1064)
	local function v_u_1075(p_u_1065) -- name: heroSkin
		-- upvalues: (copy) p_u_1020, (copy) p_u_1017, (ref) v_u_1063
		if p_u_1020 == p_u_1017 and (p_u_1065 and v_u_1063) then
			local v_u_1066 = p_u_1065
			local v_u_1067 = false
			local function v1070()
				-- upvalues: (ref) p_u_1017, (copy) p_u_1065, (ref) v_u_1066, (ref) v_u_1067
				local v1068 = p_u_1017.cctx.shared.Items.get(p_u_1065)
				if v1068 then
					local v1069 = v1068.weaponId
					if type(v1069) == "string" then
						v_u_1066 = v1068.weaponId
						v_u_1067 = v1068.gold == true
					end
				end
			end
			pcall(v1070)
			local v_u_1071 = v_u_1066
			if v_u_1067 then
				return nil
			else
				local function v1072()
					-- upvalues: (ref) p_u_1017, (copy) v_u_1071
					return p_u_1017.cctx.shared.SkinVisibility.equippedFor(game:GetService("Players").LocalPlayer, v_u_1071)
				end
				local v1073, v1074 = pcall(v1072)
				if v1073 and type(v1074) == "string" then
					return v1074
				else
					return nil
				end
			end
		else
			return nil
		end
	end
	local function v1098(p_u_1076) -- name: meleeModel
		-- upvalues: (copy) p_u_1017, (ref) v_u_1057, (copy) v_u_1075, (ref) v_u_1063
		local v_u_1077 = p_u_1017:_asset("Melee", p_u_1076)
		if v_u_1077 and (v_u_1077:IsA("Model") and (v_u_1057 and v_u_1057.fixMeleeGrip)) then
			local function v1086()
				-- upvalues: (ref) v_u_1057, (copy) v_u_1077, (copy) p_u_1076, (ref) p_u_1017
				local v1078 = v_u_1057.fixMeleeGrip
				local v1079 = v_u_1077
				local v_u_1080 = p_u_1076
				local v_u_1081 = v_u_1080
				local v_u_1082 = false
				local function v1085()
					-- upvalues: (ref) p_u_1017, (copy) v_u_1080, (ref) v_u_1081, (ref) v_u_1082
					local v1083 = p_u_1017.cctx.shared.Items.get(v_u_1080)
					if v1083 then
						local v1084 = v1083.weaponId
						if type(v1084) == "string" then
							v_u_1081 = v1083.weaponId
							v_u_1082 = v1083.gold == true
						end
					end
				end
				pcall(v1085)
				v1078(v1079, v_u_1081)
			end
			pcall(v1086)
		end
		if v_u_1077 and (v_u_1077:IsA("Model") and (v_u_1057 and (v_u_1057.applyScale and v_u_1057.scaleFor))) then
			local function v1094()
				-- upvalues: (copy) p_u_1076, (ref) p_u_1017, (ref) v_u_1057, (copy) v_u_1077
				local v_u_1087 = p_u_1076
				local v_u_1088 = v_u_1087
				local v_u_1089 = false
				local function v1092()
					-- upvalues: (ref) p_u_1017, (copy) v_u_1087, (ref) v_u_1088, (ref) v_u_1089
					local v1090 = p_u_1017.cctx.shared.Items.get(v_u_1087)
					if v1090 then
						local v1091 = v1090.weaponId
						if type(v1091) == "string" then
							v_u_1088 = v1090.weaponId
							v_u_1089 = v1090.gold == true
						end
					end
				end
				pcall(v1092)
				local v1093 = v_u_1088
				v_u_1057.applyScale(v_u_1077, v_u_1057.scaleFor(v1093))
			end
			pcall(v1094)
		end
		local v1095 = v_u_1075(p_u_1076)
		if v_u_1077 and (v1095 and (v_u_1057 and (v_u_1057.paintSkin and v_u_1077:IsA("Model")))) then
			local v1096 = v_u_1057.paintSkin
			pcall(v1096, v_u_1077, v1095, {
				["fx"] = true
			})
			local v1097 = v_u_1063.animate
			pcall(v1097, v_u_1077, v1095)
		end
		return v_u_1077
	end
	local function v1122(p1099, p_u_1100) -- name: gun
		-- upvalues: (copy) p_u_1017, (copy) p_u_1019, (copy) v_u_1075, (ref) v_u_1057, (ref) v_u_1063, (ref) v_u_1059
		local v_u_1101 = p_u_1100
		local v_u_1102 = false
		local function v1105()
			-- upvalues: (ref) p_u_1017, (copy) p_u_1100, (ref) v_u_1101, (ref) v_u_1102
			local v1103 = p_u_1017.cctx.shared.Items.get(p_u_1100)
			if v1103 then
				local v1104 = v1103.weaponId
				if type(v1104) == "string" then
					v_u_1101 = v1103.weaponId
					v_u_1102 = v1103.gold == true
				end
			end
		end
		pcall(v1105)
		local v1106 = v_u_1101
		local v1107 = v_u_1102
		local v1108 = p_u_1019
		local v1109
		if type(v1108) == "table" then
			v1109 = p_u_1019[p1099]
		else
			v1109 = false
		end
		local v1110
		if type(v1109) == "table" then
			local v1111 = v1109.mods
			if type(v1111) == "table" and next(v1109.mods) ~= nil then
				v1110 = v1109.mods
			else
				v1110 = nil
			end
		else
			v1110 = nil
		end
		local v1112 = v_u_1075(p_u_1100)
		local v1113 = nil
		local v1114
		if (v1110 or (v1107 or v1112)) and v_u_1057 then
			local v1115 = v_u_1057.build
			local v1116
			v1116, v1114 = pcall(v1115, v1106, v1110, v1107, v1112, {
				["fx"] = true
			})
			if v1116 and typeof(v1114) == "Instance" then
				if v1112 then
					local v1117 = v_u_1063.animate
					pcall(v1117, v1114, v1112)
				end
			else
				v1114 = v1113
			end
		else
			v1114 = v1113
		end
		if not v1114 then
			v1114 = p_u_1017:_asset("Weapon", v1106)
			if v1114 and (v_u_1057 and v_u_1057.stripOwn) then
				local v1118 = v_u_1057.stripOwn
				pcall(v1118, v1114)
			end
			if v1114 and (v1107 and (v_u_1057 and v_u_1057.goldify)) then
				local v1119 = v_u_1057.goldify
				pcall(v1119, v1114)
			end
		end
		if v1114 and (v1114:IsA("Model") and (v_u_1057 and v_u_1057.applyScale)) then
			local v1120 = v_u_1057.applyScale
			local v1121 = v_u_1059
			pcall(v1120, v1114, v1121)
		end
		return v1114
	end
	local v_u_1123 = nil
	local v_u_1124 = ""
	if p_u_1020 == p_u_1017 then
		pcall(function()
			-- upvalues: (copy) p_u_1017, (ref) v_u_1123, (ref) v_u_1124, (copy) v_u_1023
			local v1125 = p_u_1017.cctx.shared.WornArmor
			v_u_1123 = v1125.wearOf(game:GetService("Players").LocalPlayer)
			v_u_1124 = v1125.wearKeyFor(v_u_1123, v_u_1023.armor, v_u_1023.helmet, p_u_1017.cctx.shared.Items)
		end)
	end
	local v1126 = "%s|%s|%s|%s|%s|%s|%s|%s|%.3f|%s|%s"
	local v1127 = v_u_1023.primary or ""
	local v1128 = v_u_1023.secondary or ""
	local v1129 = v_u_1023.melee or ""
	local v1130 = v_u_1023.armor or ""
	local v1131 = v_u_1023.helmet or ""
	local v1132 = v_u_1023.bag or ""
	local v1133
	if type(p_u_1019) == "table" then
		v1133 = p_u_1019.primary
	else
		v1133 = false
	end
	local v1134
	if type(v1133) == "table" then
		local v1135 = v1133.mods
		if type(v1135) == "table" and next(v1133.mods) ~= nil then
			v1134 = v1133.mods
		else
			v1134 = nil
		end
	else
		v1134 = nil
	end
	local v1136
	if v1134 and v_u_1057 then
		local v1137 = v_u_1057.modsKey
		local v1138, v1139 = pcall(v1137, v1134)
		v1136 = (not v1138 or type(v1139) ~= "string") and "" or v1139
	else
		v1136 = ""
	end
	local v1140
	if type(p_u_1019) == "table" then
		v1140 = p_u_1019.secondary
	else
		v1140 = false
	end
	local v1141
	if type(v1140) == "table" then
		local v1142 = v1140.mods
		if type(v1142) == "table" and next(v1140.mods) ~= nil then
			v1141 = v1140.mods
		else
			v1141 = nil
		end
	else
		v1141 = nil
	end
	local v1143
	if v1141 and v_u_1057 then
		local v1144 = v_u_1057.modsKey
		local v1145, v1146 = pcall(v1144, v1141)
		v1143 = (not v1145 or type(v1146) ~= "string") and "" or v1146
	else
		v1143 = ""
	end
	local v1147 = v1126:format(v1127, v1128, v1129, v1130, v1131, v1132, v1136, v1143, v_u_1059, v_u_1023.boots or "", v_u_1023.legs or "") .. "|" .. (v_u_1023.ears or "") .. "|" .. (v_u_1075(v_u_1023.primary) or "") .. "|" .. (v_u_1075(v_u_1023.secondary) or "") .. "|" .. (v_u_1075(v_u_1023.melee) or "") .. "|" .. v_u_1124
	if v1147 ~= p_u_1020.equipKey then
		p_u_1020.equipKey = ""
		for _, v1148 in p_u_1020.equipped do
			v1148:Destroy()
		end
		table.clear(p_u_1020.equipped)
		p1021()
		local v1149 = p_u_1018:FindFirstChild("UpperTorso")
		local v1150 = p_u_1018:FindFirstChild("LowerTorso")
		local v1151 = p_u_1018:FindFirstChild("Head")
		local v1152 = p_u_1018:FindFirstChild("RightHand")
		local function v1158(p1153, p1154, p1155, p1156) -- name: add
			-- upvalues: (ref) v_u_77, (ref) v_u_956, (ref) v_u_945, (copy) p_u_1018, (copy) p_u_1020
			if p1153 and (p1154 and (p1155 and p1153:IsA("Model"))) then
				v_u_77(p1153, true)
				if p1156 then
					v_u_956(p1153, p1156)
				end
				p1153:PivotTo(p1154)
				v_u_945(p1153, p1155)
				p1153.Parent = p_u_1018
				local v1157 = p_u_1020.equipped
				table.insert(v1157, p1153)
			elseif p1153 then
				p1153:Destroy()
			end
		end
		local v1159 = not v1149 and 2 or v1149.Size.X
		if v1151 then
			local _ = v1151.Size.X
		end
		if v_u_1023.boots or v_u_1023.legs then
			local v_u_1160, v_u_1161 = pcall(function()
				-- upvalues: (copy) p_u_1017
				return p_u_1017.cctx.shared.WornGear
			end)
			local v1163, v1164 = pcall(function()
				-- upvalues: (copy) v_u_1160, (copy) v_u_1161, (copy) p_u_1018, (copy) v_u_1023
				local v1162 = v_u_1160 and v_u_1161
				if v1162 then
					v1162 = v_u_1161.dress(p_u_1018, v_u_1023.boots, v_u_1023.legs)
				end
				return v1162
			end)
			if v1163 and typeof(v1164) == "Instance" then
				local v1165 = p_u_1020.equipped
				table.insert(v1165, v1164)
			end
		end
		if v_u_1023.armor or (v_u_1023.helmet or (v_u_1023.ears or v_u_1124 ~= "")) then
			local v_u_1166, v_u_1167 = pcall(function()
				-- upvalues: (copy) p_u_1017
				return p_u_1017.cctx.shared.WornArmor
			end)
			local v1169, v1170 = pcall(function()
				-- upvalues: (copy) v_u_1166, (copy) v_u_1167, (copy) p_u_1018, (copy) v_u_1023, (copy) p_u_1017, (ref) v_u_1123
				local v1168 = v_u_1166 and v_u_1167
				if v1168 then
					v1168 = v_u_1167.dress(p_u_1018, v_u_1023.armor, v_u_1023.helmet, v_u_1023.ears, p_u_1017.cctx.shared.Items, v_u_1123)
				end
				return v1168
			end)
			if v1169 and typeof(v1170) == "Instance" then
				local v1171 = p_u_1020.equipped
				table.insert(v1171, v1170)
			end
		end
		p_u_1017:_syncHeadwear(p_u_1018)
		local v_u_1172 = false
		if v_u_1023.helmet then
			pcall(function()
				-- upvalues: (copy) p_u_1017, (copy) v_u_1023, (ref) v_u_1172
				local v1173 = p_u_1017.cctx.shared.Items.get(v_u_1023.helmet)
				local v1174
				if v1173 == nil then
					v1174 = false
				else
					v1174 = v1173.gasMask == true
				end
				v_u_1172 = v1174
			end)
		end
		if v_u_1172 and v1151 then
			local v_u_1175, v_u_1176 = pcall(function()
				-- upvalues: (copy) p_u_1017
				return p_u_1017.cctx.shared.WornMask
			end)
			local v1178, v1179 = pcall(function()
				-- upvalues: (copy) v_u_1175, (copy) v_u_1176, (copy) p_u_1018
				local v1177 = v_u_1175 and v_u_1176
				if v1177 then
					v1177 = v_u_1176.dress(p_u_1018, true)
				end
				return v1177
			end)
			if v1178 and typeof(v1179) == "Instance" then
				local v1180 = p_u_1020.equipped
				table.insert(v1180, v1179)
			end
		end
		local v1181
		if v1149 then
			v1181 = v1149:FindFirstChild("BodyBackAttachment")
		else
			v1181 = v1149
		end
		local v1182
		if v1149 then
			v1182 = v1149:FindFirstChild("BodyFrontAttachment")
		else
			v1182 = v1149
		end
		if v_u_1023.bag and v1149 then
			local v1183 = p_u_1017:_asset("Item", v_u_1023.bag)
			if v1183 and v1183:IsA("Model") then
				local v1184 = v_u_996(v1183)
				v_u_956(v1183, v1159 * 1.25)
				v1183:PivotTo(v1184)
				local v1185 = v_u_992(v1183)
				local v1186
				if v1181 then
					v1186 = v1181.WorldCFrame
				else
					v1186 = v1149.CFrame * CFrame.new(0, 0, 0.5)
				end
				v1158(v1183, v1186 * CFrame.new(0, -0.25, v1185.Z * 0.5 + 0.02) * v1184, v1149, nil)
				local v1187 = p_u_1017:_looks()
				if v1187 and v1183.Parent then
					local v1188 = v1187.tintPack
					local v1189 = v1187.DEFAULT_PACK_COLOR
					pcall(v1188, v1183, v1189)
				end
			end
		end
		local v1190 = nil
		if v_u_1023.primary and v1149 then
			local v1191 = v1122("primary", v_u_1023.primary)
			local v1192
			if v1191 == nil then
				v1192 = false
			else
				v1192 = v1191:GetAttribute("BackCarry") == "down"
			end
			if v_u_1023.bag then
				local v1193
				if v1182 then
					v1193 = v1182.WorldCFrame
				else
					v1193 = v1149.CFrame * CFrame.new(0, 0, -0.5)
				end
				local v1194
				if v1192 then
					v1194 = CFrame.new(-0.5, 1.3, -0.28)
				else
					v1194 = CFrame.new(0.1, -0.2, -0.28)
				end
				v1158(v1191, v1193 * v1194 * CFrame.Angles(0, 0, (v_u_5(v1192 and -135 or -38))) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v1149, nil)
			else
				local v1195
				if v1181 then
					v1195 = v1181.WorldCFrame
				else
					v1195 = v1149.CFrame * CFrame.new(0, 0, 0.5)
				end
				local v1196
				if v1192 then
					v1196 = CFrame.new(0.5, 0.95, 0.3)
				else
					v1196 = CFrame.new(0, 0, 0.3)
				end
				v1158(v1191, v1195 * v1196 * CFrame.Angles(0, 0, (v_u_5(v1192 and 135 or 35))) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v1149, nil)
			end
		end
		local v1197
		if v_u_1023.secondary and v1149 then
			local v1198
			v1197, v1198 = pcall(function()
				-- upvalues: (copy) v_u_1023
				return require(script.Parent:WaitForChild("InvUISlotHint")).isLongId(v_u_1023.secondary)
			end)
			if v1197 then
				v1197 = v1198 == true
			end
		else
			v1197 = false
		end
		if v1197 and (v_u_1023.secondary and v1149) then
			local v1199 = v1122("secondary", v_u_1023.secondary)
			local v1200
			if v1199 == nil then
				v1200 = false
			else
				v1200 = v1199:GetAttribute("BackCarry") == "down"
			end
			if v_u_1023.bag then
				local v1201
				if v1182 then
					v1201 = v1182.WorldCFrame
				else
					v1201 = v1149.CFrame * CFrame.new(0, 0, -0.5)
				end
				local v1202
				if v1200 then
					v1202 = CFrame.new(0.5, 1.3, -0.4)
				else
					v1202 = CFrame.new(-0.1, -0.2, -0.4)
				end
				v1158(v1199, v1201 * v1202 * CFrame.Angles(0, 0, (v_u_5(v1200 and 135 or 38))) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v1149, nil)
			else
				local v1203
				if v1181 then
					v1203 = v1181.WorldCFrame
				else
					v1203 = v1149.CFrame * CFrame.new(0, 0, 0.5)
				end
				local v1204
				if v1200 then
					v1204 = CFrame.new(-0.5, 0.95, 0.42)
				else
					v1204 = CFrame.new(0, 0, 0.42)
				end
				v1158(v1199, v1203 * v1204 * CFrame.Angles(0, 0, (v_u_5(v1200 and -135 or -35))) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966), v1149, nil)
			end
		end
		local v1205
		if v1152 then
			v1205 = v1152:FindFirstChild("RightGripAttachment")
		else
			v1205 = v1152
		end
		if v1152 and v1205 then
			if v_u_1023.secondary and not v1197 then
				v1190 = v_u_1023.secondary
				v1158(v1122("secondary", v_u_1023.secondary), v1205.WorldCFrame * CFrame.Angles(-0.20943951023931956, 0, 0), v1152, nil)
			elseif v_u_1023.melee then
				v1190 = v_u_1023.melee
				v1158(v1098(v_u_1023.melee), v1205.WorldCFrame * CFrame.Angles(-0.13962634015954636, 0, 0), v1152, nil)
			end
		end
		if v_u_1023.melee and (v1190 ~= v_u_1023.melee and v1150) then
			local v1206
			if v1150 then
				v1206 = v1150:FindFirstChild("WaistBackAttachment")
			else
				v1206 = v1150
			end
			local v1207
			if v1206 then
				v1207 = v1206.WorldCFrame
			else
				v1207 = v1150.CFrame * CFrame.new(0, 0, 0.5)
			end
			local v1208 = v1207 * CFrame.new(-0.55, -0.1, 0.12) * CFrame.Angles(-1.8325957145940461, 0, 0)
			v1158(v1098(v_u_1023.melee), v1208, v1150, nil)
		end
		p_u_1020.equipKey = v1147
		p1022()
	end
end
function v_u_4._buildImported(p1209) -- name: _buildImported
	-- upvalues: (copy) v_u_2, (copy) v_u_77
	local v1210 = v_u_2:FindFirstChild("HushAssets")
	if v1210 then
		v1210 = v1210:FindFirstChild("Menu")
	end
	if v1210 then
		v1210 = v1210:FindFirstChild("Backdrop")
	end
	if v1210 and v1210:IsA("Model") then
		local v1211 = v1210:Clone()
		v_u_77(v1211, true)
		v1211:PivotTo(CFrame.new(p1209.origin))
		v1211.Parent = p1209.root
	end
end
function v_u_4._startSound(p_u_1212) -- name: _startSound
	local v_u_1213 = p_u_1212.cctx
	if v_u_1213 then
		v_u_1213 = p_u_1212.cctx.controllers.Audio
	end
	if v_u_1213 and p_u_1212.lamp then
		pcall(function()
			-- upvalues: (copy) v_u_1213, (copy) p_u_1212
			if v_u_1213.loop then
				local v1214 = v_u_1213.loop("amb_hum", p_u_1212.lamp.bulb)
				if v1214 and v1214.SetVolume then
					v1214:SetVolume(0.35, 1)
				end
				p_u_1212.hum = v1214
			end
		end)
	end
end
function v_u_4.setStage(p1215, p1216, p1217, p1218) -- name: setStage
	p1215.stage = p1216 and (p1217 and p1216 < p1217) and {
		["x0"] = p1216,
		["x1"] = p1217,
		["top"] = p1218
	} or nil
end
function v_u_4.setGlobeStage(p1219, p1220, p1221, p1222, p1223) -- name: setGlobeStage
	local v1224 = (p1222 == "street" or p1222 == true) and "street" or "play"
	local v1225 = (type(p1223) ~= "number" or p1223 ~= p1223) and 1 or math.clamp(p1223, 1, 2)
	p1219.globeStage = p1220 and (p1221 and p1220 < p1221) and {
		["x0"] = p1220,
		["x1"] = p1221,
		["mode"] = v1224,
		["heroless"] = v1224 == "street",
		["pull"] = v1225
	} or nil
end
local function v_u_1246(p1226, p1227) -- name: stageSx
	local v1228 = p1226.globeStage
	if v1228 then
		local v1229 = p1226.cctx and p1226.cctx.shared
		if v1229 then
			v1229 = p1226.cctx.shared.Theme
		end
		local v1230 = v1229.viewport
		local v1231, v1232 = pcall(v1230)
		if not v1231 or (typeof(v1232) ~= "Vector2" or v1232.X < 2) then
			return p1227
		end
		local v1233 = v1232.X
		local v1234, v1235 = pcall(function()
			return workspace.CurrentCamera.ViewportSize.X
		end)
		if v1234 and type(v1235) == "number" then
			if v1235 <= 2 then
				v1235 = v1233
			end
		else
			v1235 = v1233
		end
		local v1236 = (v1228.x0 + v1228.x1) / 2 / v1235
		return math.clamp(v1236, 0.1, 0.5)
	end
	local v1237 = p1226.stage
	if not v1237 then
		return p1227
	end
	local v1238 = p1226.cctx and p1226.cctx.shared
	if v1238 then
		v1238 = p1226.cctx.shared.Theme
	end
	local v1239 = v1238.isPhone
	local v1240, v1241 = pcall(v1239)
	if not v1240 or v1241 ~= true then
		return p1227
	end
	local v1242 = v1238.viewport
	local v1243, v1244 = pcall(v1242)
	if not v1243 or (typeof(v1244) ~= "Vector2" or v1244.X < 2) then
		return p1227
	end
	local v1245 = (v1237.x0 + v1237.x1) / 2 / v1244.X
	return math.clamp(v1245, 0.2, 0.5)
end
function v_u_4.lineupSpanPx(p_u_1247, p1248) -- name: lineupSpanPx
	local _, v1249, v1250 = p_u_1247:_lineup()
	local v1251
	if v1250 > 1 then
		v1251 = 1 + 0.08 * (v1250 - 1) + v1249 * 0.03
		if v1250 >= 3 then
			v1251 = v1251 * 1.12
		end
	else
		v1251 = 1
	end
	local v1252 = v1251 * ((type(p1248) ~= "number" or p1248 < 1) and 1 or p1248)
	local v_u_1253 = 1080
	local function v1254()
		-- upvalues: (ref) v_u_1253, (copy) p_u_1247
		v_u_1253 = p_u_1247.cctx.shared.Theme.refSize().Y
	end
	pcall(v1254)
	local v1255 = v_u_1253 / (v1252 * 22.46 * 2 * 0.3838640350354158)
	return (v1249 + 2.2) * 0.9795752495993441 * v1255
end
local v_u_1256 = nil
local function v_u_1292(p_u_1257, p1258) -- name: shotFor
	-- upvalues: (ref) v_u_1256, (copy) v_u_1246
	local v1259 = p_u_1257.chest or p_u_1257:W(Vector3.new(0, 4, 0))
	local v1260 = p1258 == "play" and (p_u_1257.globeStage and p_u_1257.globeStage.heroless) and "street" or p1258
	if v1260 ~= "street" then
		if v1260 == "character" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.18,
				["sy"] = 0.6,
				["fov"] = 36,
				["drift"] = 0.25,
				["pos"] = v1259 + Vector3.new(11, -1.2, 21),
				["subject"] = v1259 + Vector3.new(0, 0.3, 0)
			}
		end
		if v1260 == "wide" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.46,
				["sy"] = 0.5,
				["fov"] = 44,
				["drift"] = 0.8,
				["pos"] = v1259 + Vector3.new(15, 7.5, 30),
				["subject"] = v1259 + Vector3.new(-2, 2.5, -30)
			}
		end
		if v1260 == "debrief" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.6,
				["sy"] = 0.5,
				["fov"] = 38,
				["drift"] = 0.2,
				["pos"] = v1259 + Vector3.new(-7.4, -2.9, 21),
				["subject"] = v1259 + Vector3.new(0, 1.4, 0)
			}
		end
		if v1260 == "intro" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.5,
				["sy"] = 0.5,
				["fov"] = 46,
				["drift"] = 0,
				["pos"] = v1259 + Vector3.new(26, 16, 44),
				["subject"] = v1259 + Vector3.new(-6, 4, -40)
			}
		end
		if v1260 == "hideout" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.45,
				["sy"] = 0.5,
				["fov"] = 40,
				["drift"] = 0.3,
				["pos"] = v1259 + Vector3.new(-6, 1.5, 12),
				["subject"] = v1259 + Vector3.new(4, 0, 0)
			}
		end
		if next(p_u_1257.mates) == nil or v1260 ~= "play" and v1260 ~= "wide" then
			return {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = nil,
				["sy"] = nil,
				["fov"] = 42,
				["drift"] = 0.5,
				["pos"] = v1259 + Vector3.new(7.6, -1.5, 21.5),
				["subject"] = v1259 + Vector3.new(0, 0.2, 0),
				["sx"] = v_u_1246(p_u_1257, 0.33),
				["sy"] = (p_u_1257.stage or p_u_1257.globeStage) and v_u_1246(p_u_1257, -1) >= 0 and (p_u_1257.globeStage and 0.66 or 0.54) or 0.66
			}
		end
		local v1261, v1262, v1263 = p_u_1257:_lineup()
		if v1260 == "wide" then
			local v1264 = {
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = 0.44,
				["sy"] = 0.5,
				["fov"] = 44,
				["drift"] = 0.8
			}
			local v1265 = 30 + v1262
			v1264.pos = v1261 + Vector3.new(15, 7.5, v1265)
			v1264.subject = v1261 + Vector3.new(-2, 2.5, -30)
			return v1264
		end
		local v1266 = 1 + 0.08 * (v1263 - 1) + v1262 * 0.03
		local v1267 = (p_u_1257.stage or p_u_1257.globeStage) and v_u_1246(p_u_1257, -1) >= 0 and (p_u_1257.globeStage and 0.64 or 0.54) or 0.64
		if v1263 >= 3 and (p_u_1257.stage or p_u_1257.globeStage) and v_u_1246(p_u_1257, -1) >= 0 then
			if p_u_1257.globeStage then
				v1266 = v1266 * 1.12
			else
				v1266 = v1266 * 1.2
				v1267 = 0.61
			end
		end
		if p_u_1257.globeStage and p_u_1257.globeStage.pull then
			v1266 = v1266 * p_u_1257.globeStage.pull
		end
		local v1268 = {
			["pos"] = nil,
			["subject"] = nil,
			["sx"] = nil,
			["sy"] = nil,
			["fov"] = 42,
			["drift"] = 0.45
		}
		local v1269 = 4.5 * v1266
		local v1270 = -1.5 + (v1266 - 1) * 2.5
		local v1271 = 22 * v1266
		v1268.pos = v1261 + Vector3.new(v1269, v1270, v1271)
		v1268.subject = v1261 + Vector3.new(0, 0.3, 0)
		v1268.sx = v_u_1246(p_u_1257, 0.36)
		v1268.sy = v1267
		return v1268
	end
	local v1272, v1273 = p_u_1257:_lineup()
	local v1274 = 30 + v1273
	local v1275 = v1272 + Vector3.new(15, 7.5, v1274)
	local v1276 = p_u_1257.globeStage
	local v1277, v1278 = pcall(function()
		-- upvalues: (copy) p_u_1257
		return p_u_1257.cctx.shared.Theme.viewport()
	end)
	local v1279
	if v1276 and (v1277 and (typeof(v1278) == "Vector2" and (v1278.X >= 2 and v1278.Y >= 2))) then
		local v1281, v1282 = pcall(function()
			local v1280 = workspace.CurrentCamera
			return v1280 and (v1280.ViewportSize.X > 2 and v1280.ViewportSize.Y > 2) and { v1280.ViewportSize.X / v1280.ViewportSize.Y, v1280.ViewportSize.X } or nil
		end)
		local v1283, v1284
		if v1281 and type(v1282) == "table" then
			v1283 = v1282[1]
			v1284 = v1282[2]
		else
			v1283 = v1278.X / v1278.Y
			v1284 = v1278.X
		end
		local v1285 = (v1276.x0 - 24) / v1284
		local v1286 = v1283 * 0.4040262258351568
		local v1287 = v1272 + Vector3.new(-2, 2.5, -30)
		local v1288 = v1273 / 2 + 1.6
		local v1289 = v1272 + Vector3.new(v1288, 2, 0)
		local v1290 = 0.44
		for _ = 1, 4 do
			local v1291 = v_u_1256({
				["pos"] = nil,
				["subject"] = nil,
				["sx"] = nil,
				["sy"] = 0.5,
				["fov"] = 44,
				["drift"] = 0,
				["pos"] = v1275,
				["subject"] = v1287,
				["sx"] = v1290
			}, v1283):PointToObjectSpace(v1289)
			if v1291.Z >= -0.1 then
				break
			end
			v1290 = v1290 + (v1285 - (0.5 + v1291.X / -v1291.Z / (v1286 * 2)))
		end
		v1279 = math.clamp(v1290, -2.5, 0.44)
	else
		v1279 = 0.44
	end
	return {
		["pos"] = nil,
		["subject"] = nil,
		["sx"] = nil,
		["sy"] = 0.5,
		["fov"] = 44,
		["drift"] = 0.8,
		["pos"] = v1275,
		["subject"] = v1272 + Vector3.new(-2, 2.5, -30),
		["sx"] = v1279
	}
end
v_u_1256 = function(p1293, p1294) -- name: frame
	-- upvalues: (copy) v_u_5
	local v1295 = v_u_5(p1293.fov / 2)
	local v1296 = math.tan(v1295)
	local v1297 = v1296 * p1294
	local v1298 = CFrame.lookAt(p1293.pos, p1293.subject)
	local v1299 = (0.5 - p1293.sx) * 2 * v1297
	local v1300 = -math.atan(v1299)
	local v1301 = (p1293.sy - 0.5) * 2 * v1296
	local v1302 = math.atan(v1301)
	return v1298 * CFrame.Angles(0, v1300, 0) * CFrame.Angles(v1302, 0, 0)
end
function v_u_4.setShot(p1303, p1304, p1305) -- name: setShot
	p1303.shotName = p1304
	if p1305 then
		p1303.camCF = nil
	end
end
function v_u_4.takeCamera(_) -- name: takeCamera
	-- upvalues: (copy) v_u_1
	local v1306 = v_u_1.CurrentCamera
	if v1306 then
		v1306.CameraType = Enum.CameraType.Scriptable
		v1306.CameraSubject = nil
	end
end
function v_u_4.shot(p1307, p1308, _) -- name: shot
	-- upvalues: (copy) v_u_1292
	return v_u_1292(p1307, p1308)
end
function v_u_4._camera(p1309, p1310) -- name: _camera
	-- upvalues: (copy) v_u_1, (copy) v_u_1292, (ref) v_u_1256, (copy) v_u_5
	if p1309.externalCamera then
		return
	else
		local v1311 = v_u_1.CurrentCamera
		if v1311 then
			local v1312, v1313 = pcall(function()
				return game:GetService("Players").LocalPlayer:GetAttribute("CrateStageOn")
			end)
			if not v1312 or v1313 ~= true then
				if v1311.CameraType ~= Enum.CameraType.Scriptable then
					v1311.CameraType = Enum.CameraType.Scriptable
				end
				local v1314 = Vector2.new(1920, 1080)
				local v1315 = p1309.cctx and p1309.cctx.shared
				if v1315 then
					v1315 = p1309.cctx.shared.Theme
				end
				local v1316
				if v1315 and v1315.viewport then
					local v1317 = v1315.viewport
					local v1318
					v1318, v1316 = pcall(v1317)
					if v1318 then
						if typeof(v1316) ~= "Vector2" then
							v1316 = v1314
						end
					else
						v1316 = v1314
					end
				else
					v1316 = v1314
				end
				local v1319
				if v1316.Y > 1 then
					local v1321, v1322 = pcall(function()
						local v1320 = workspace.CurrentCamera
						return v1320 and (v1320.ViewportSize.X > 2 and v1320.ViewportSize.Y > 2) and { v1320.ViewportSize.X / v1320.ViewportSize.Y, v1320.ViewportSize.X } or nil
					end)
					if v1321 and type(v1322) == "table" then
						v1319 = v1322[1]
						local _ = v1322[2]
					else
						v1319 = v1316.X / v1316.Y
						local _ = v1316.X
					end
				else
					v1319 = 1.7777777777777777
				end
				local v1323 = v_u_1292(p1309, p1309.shotName)
				local v1324 = v_u_1256(v1323, v1319)
				local v1325 = p1309.t
				local v1326 = v1323.drift
				local v1327 = CFrame.new
				local v1328 = v1325 * 0.13
				local v1329 = math.sin(v1328) * 0.7 * v1326
				local v1330 = v1325 * 0.087 + 1.3
				local v1331 = math.sin(v1330) * 0.28 * v1326
				local v1332 = v1325 * 0.11
				local v1333 = v1327(v1329, v1331, math.cos(v1332) * 0.45 * v1326)
				local v1334 = CFrame.Angles
				local v1335 = v1325 * 0.21
				local v1336 = v_u_5(math.sin(v1335) * 0.35 * v1326)
				local v1337 = v1325 * 0.17 + 0.5
				local v1338 = v_u_5(math.sin(v1337) * 0.5 * v1326)
				local v1339 = v1325 * 0.09
				local v1340 = v1324 * (v1333 * v1334(v1336, v1338, (v_u_5(math.sin(v1339) * 0.4 * v1326))))
				if p1309.camCF then
					local v1341 = p1309.shotName == "intro" and 0.9 or 2.4
					local v1342 = -p1310 * v1341
					local v1343 = 1 - math.exp(v1342)
					p1309.camCF = p1309.camCF:Lerp(v1340, v1343)
					p1309.fov = p1309.fov + (v1323.fov - p1309.fov) * v1343
				else
					p1309.camCF = v1340
					p1309.fov = v1323.fov
				end
				v1311.CFrame = p1309.camCF
				v1311.FieldOfView = p1309.fov
				v1311.Focus = CFrame.new(v1323.subject)
				local v1344 = (v1323.subject - v1323.pos).Magnitude
				local v1345 = v1344 - p1309.lastFocus
				if math.abs(v1345) > 0.75 then
					p1309.lastFocus = v1344
					local v1346 = p1309.cctx
					if v1346 then
						v1346 = p1309.cctx.controllers.Atmosphere
					end
					if v1346 and v1346.setFocus then
						local v1347 = v1346.setFocus
						local v1348 = v1344 * 0.4
						local v1349 = math.clamp(v1348, 5, 30)
						pcall(v1347, v1344, v1349)
					end
					if v1346 and v1346.setFxAnchor then
						local v1350 = v1346.setFxAnchor
						local v1351 = v1323.subject + (v1323.pos - v1323.subject) * 0.45 + Vector3.new(0, 2, 0)
						pcall(v1350, v1351)
					end
				end
			end
		else
			return
		end
	end
end
function v_u_4._lamp(p1352, p1353) -- name: _lamp
	local v1354 = p1352.lamp
	if not v1354 then
		return
	end
	local v1355 = p1352.t * 47
	local v1356 = math.sin(v1355) * 0.03 + 0.92
	local v1357 = p1352.t * 13.3
	local v1358 = v1356 + math.sin(v1357) * 0.03
	local v1359, v1360, v1361
	if v1354.driven then
		if v1354.driven then
			v1359 = not v1354.spot.Enabled and 0 or v1354.spot.Brightness
			if v1354.peak < v1359 then
				v1354.peak = v1359
			end
			v1360 = v1359 / v1354.peak
			v1361 = math.clamp(v1360, 0, 1) * v1358
			v1354.fill.Brightness = v1361 * 0.25
			v1354.shaft.Brightness = v1361
			if v1354.rim then
				v1354.rim.Brightness = v1361 * 0.7
			end
		else
			p1352:_handFlicker(p1353, v1354, v1358)
		end
		p1352:_beacons()
	else
		if v1354.spot.Enabled then
			local v1362 = v1354.spot.Brightness - v1354.lastSet
			if math.abs(v1362) <= 0.001 then
				if v1354.driven then
					v1359 = not v1354.spot.Enabled and 0 or v1354.spot.Brightness
					if v1354.peak < v1359 then
						v1354.peak = v1359
					end
					v1360 = v1359 / v1354.peak
					v1361 = math.clamp(v1360, 0, 1) * v1358
					v1354.fill.Brightness = v1361 * 0.25
					v1354.shaft.Brightness = v1361
					if v1354.rim then
						v1354.rim.Brightness = v1361 * 0.7
					end
				else
					p1352:_handFlicker(p1353, v1354, v1358)
				end
				p1352:_beacons()
				return
			end
			v1354.driven = true
			v1354.bulb.Transparency = 0
		else
			v1354.driven = true
			v1354.bulb.Transparency = 0
		end
		if v1354.driven then
			v1359 = not v1354.spot.Enabled and 0 or v1354.spot.Brightness
			if v1354.peak < v1359 then
				v1354.peak = v1359
			end
			v1360 = v1359 / v1354.peak
			v1361 = math.clamp(v1360, 0, 1) * v1358
			v1354.fill.Brightness = v1361 * 0.25
			v1354.shaft.Brightness = v1361
			if v1354.rim then
				v1354.rim.Brightness = v1361 * 0.7
			end
		else
			p1352:_handFlicker(p1353, v1354, v1358)
		end
		p1352:_beacons()
	end
end
function v_u_4._handFlicker(p1363, p1364, p1365, p1366) -- name: _handFlicker
	-- upvalues: (copy) v_u_61
	local v1367 = p1363.flick
	v1367.next = v1367.next - p1364
	local v1368 = 1
	if v1367.off > 0 then
		v1367.off = v1367.off - p1364
		v1368 = 0.04
	elseif #v1367.pattern > 0 then
		local v1369 = v1367.pattern
		v1369[1] = v1369[1] - p1364
		if v1367.pattern[1] <= 0 then
			table.remove(v1367.pattern, 1)
			if #v1367.pattern > 0 then
				v1367.off = 0.05 + math.random() * 0.08
			end
		end
	end
	if v1367.next <= 0 then
		v1367.next = 2.5 + math.random() * 7
		local v1370 = math.random(1, 4)
		v1367.off = 0.06 + math.random() * 0.1
		for _ = 1, v1370 - 1 do
			local v1371 = v1367.pattern
			local v1372 = 0.03 + math.random() * 0.12
			table.insert(v1371, v1372)
		end
		if math.random() < 0.15 then
			v1367.off = 0.6 + math.random() * 0.8
		end
		local v1373 = p1363.cctx
		if v1373 then
			v1373 = p1363.cctx.controllers.Audio
		end
		if v1373 and v1373.play3D then
			local v1374 = v1373.play3D
			local v1375 = p1365.bulb
			pcall(v1374, "light_flicker", v1375, {
				["volume"] = 0.5
			})
		end
	end
	local v1376 = v1368 * p1366
	p1365.spot.Brightness = p1365.base * v1376
	p1365.lastSet = p1365.spot.Brightness
	p1365.fill.Brightness = v1376 * 0.25
	if p1365.rim then
		p1365.rim.Brightness = v1376 * 0.7
	end
	p1365.bulb.Transparency = v1368 < 0.5 and 0.75 or 0
	local v1377 = p1365.bulb
	local v1378
	if v1368 < 0.5 then
		v1378 = v_u_61.sodium:Lerp(Color3.new(0.2, 0.1, 0.05), 0.6)
	else
		v1378 = v_u_61.sodium
	end
	v1377.Color = v1378
	p1365.shaft.Brightness = v1376
end
function v_u_4._beacons(p1379) -- name: _beacons
	for _, v1380 in p1379.beacons do
		local v1381 = (p1379.t + v1380.phase) % v1380.period / v1380.period < (v1380.duty or 0.18)
		v1380.light.Brightness = v1381 and (v1380.on or 2.2) or 0
		for _, v1382 in v1380.cores do
			v1382.Transparency = v1381 and 0 or (v1380.offT or 0.72)
		end
	end
	local v1383 = p1379.t % 1.2
	for _, v1384 in p1379.police do
		local v1385
		if v1384.side == 1 then
			v1385 = v1383 < 0.6
		else
			v1385 = v1383 >= 0.6
		end
		local v1386 = v1383 % 0.6
		if v1385 then
			if v1386 < 0.1 then
				v1385 = true
			elseif v1386 > 0.18 then
				v1385 = v1386 < 0.28
			else
				v1385 = false
			end
		end
		v1384.light.Brightness = v1385 and (v1384.on or 1.6) or 0
		for _, v1387 in v1384.cores do
			v1387.Transparency = v1385 and 0 or 0.72
		end
	end
	for v1388, v1389 in p1379.fires do
		local v1390 = p1379.t * (3.1 + v1388)
		local v1391 = math.sin(v1390) * 0.5 + 2.4
		local v1392 = p1379.t * 7.7 + v1388
		v1389.Brightness = v1391 + math.sin(v1392) * 0.35
	end
end
function v_u_4.setSearchSource(p1393, p1394) -- name: setSearchSource
	if type(p1394) ~= "function" then
		p1394 = nil
	end
	p1393.searchSource = p1394
end
function v_u_4._stepSearch(p_u_1395) -- name: _stepSearch
	-- upvalues: (copy) v_u_4
	local v_u_1396 = nil
	if p_u_1395.searchFake then
		local v1397 = p_u_1395.searchFake
		local v1398 = v1397.until_ - os.clock()
		local v1399 = math.max(0, v1398)
		v_u_1396 = {
			["phase"] = nil,
			["remaining"] = nil,
			["total"] = nil,
			["frac"] = nil,
			["found"] = nil,
			["seats"] = 12,
			["regionName"] = "Europe",
			["match"] = nil,
			["phase"] = v1397.phase == "searching" and v1399 <= 0 and "starting" or v1397.phase,
			["remaining"] = v1399,
			["total"] = v1397.total
		}
		local v1400 = v1399 / v1397.total
		v_u_1396.frac = math.clamp(v1400, 0, 1)
		v_u_1396.found = v1397.found
		v_u_1396.match = v1397.phase == "found" and {
			["k"] = "new",
			["t"] = nil,
			["s"] = 3,
			["region"] = "EU",
			["t"] = v1397.found
		} or nil
	elseif p_u_1395.searchSource then
		local v1401 = p_u_1395.searchSource
		local v1402
		v1402, v_u_1396 = pcall(v1401)
		if not v1402 then
			v_u_1396 = nil
		end
	end
	local v1403 = v_u_1396 and (v_u_1396.phase == "searching" and "Searching" or "Deploying") or nil
	if v1403 ~= p_u_1395.searchWord then
		local v1404 = v1403 == nil ~= (p_u_1395.searchWord == nil)
		p_u_1395.searchWord = v1403
		if v1404 and (p_u_1395.fakeN or 0) > 0 then
			local v1405 = p_u_1395._applySquad
			pcall(v1405, p_u_1395)
		else
			local v1406 = p_u_1395._plates
			pcall(v1406, p_u_1395)
		end
	end
	local v1407 = p_u_1395.shotName
	if v1407 ~= "play" and (v1407 ~= "wide" and v1407 ~= "intro") then
		v_u_1396 = nil
	end
	local v_u_1408 = p_u_1395.searchMarker
	if not v_u_1408 then
		local v1409
		v1409, v_u_1408 = pcall(function()
			-- upvalues: (copy) p_u_1395
			return p_u_1395.cctx.lib.MenuSearchMarker
		end)
		if not v1409 or type(v_u_1408) ~= "table" then
			return
		end
		p_u_1395.searchMarker = v_u_1408
	end
	local v_u_1410 = {
		["cctx"] = nil,
		["t"] = nil,
		["plateH"] = 0,
		["compact"] = false,
		["cctx"] = p_u_1395.cctx,
		["t"] = p_u_1395.t
	}
	p_u_1395.searchSpaceAt = (p_u_1395.searchSpaceAt or 0) - (p_u_1395.lastDt or 0)
	if v_u_1396 and p_u_1395.searchSpaceAt <= 0 then
		p_u_1395.searchSpaceAt = 0.25
		local v1411 = p_u_1395._markerSpacing
		local v1412, v1413 = pcall(v1411, p_u_1395, v_u_1408)
		if not v1412 then
			v1413 = nil
		end
		p_u_1395.searchCompact = v1413
		local v1414 = p_u_1395._markerFit
		local v1415 = p_u_1395.searchCompact
		local v1416, v1417 = pcall(v1414, p_u_1395, v_u_1408, v1415)
		if not v1416 then
			v1417 = nil
		end
		p_u_1395.markerOff = v1417
	end
	local v_u_1418
	if v_u_1396 then
		v_u_1418 = p_u_1395.searchCompact
	else
		v_u_1418 = nil
	end
	local v_u_1419
	if v_u_1396 then
		v_u_1419 = p_u_1395.markerOff
	else
		v_u_1419 = nil
	end
	local function v1424(p1420) -- name: one
		-- upvalues: (copy) v_u_1419, (ref) v_u_1408, (copy) v_u_1410, (ref) v_u_4, (copy) v_u_1418, (ref) v_u_1396
		if p1420 then
			if v_u_1419 and v_u_1419[p1420] then
				v_u_1408.clear(p1420)
			else
				local v1421 = p1420:FindFirstChild("SquadPlate")
				v_u_1410.plateH = not v1421 and 0 or v1421.Size.Y.Offset
				if v1421 and v1421.SizeOffset.Y > 0 then
					v_u_1410.plateH = v_u_1410.plateH * 3 + 2 * v_u_4.PLATE_RAISE_GAP
				end
				local v1422 = v_u_1410
				local v1423
				if v_u_1418 == nil or p1420 == nil then
					v1423 = false
				else
					v1423 = v_u_1418[p1420] == true
				end
				v1422.compact = v1423
				v_u_1408.update(p1420, v_u_1396, v_u_1410)
			end
		else
			return
		end
	end
	v1424(p_u_1395.survivor)
	for _, v1425 in p_u_1395.mates do
		v1424(v1425.model)
	end
	local v1426 = game:GetService("Players").LocalPlayer
	local v1427 = p_u_1395.survivor
	if v1427 then
		v1427 = p_u_1395.survivor:FindFirstChild("SearchMarker")
	end
	local v1428 = not v1427 and "" or tostring(v1427:GetAttribute("Key"))
	if v1426 and v1426:GetAttribute("SearchMarker") ~= v1428 then
		v1426:SetAttribute("SearchMarker", v1428)
	end
end
function v_u_4._markerSpacing(p1429, p1430) -- name: _markerSpacing
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v_u_1431 = v_u_1.CurrentCamera
	local v1432 = {}
	if v_u_1431 then
		local v1433 = p1430.width
		if type(v1433) == "function" then
			local v1434 = p1429.cctx.shared.Theme
			local v1435 = Vector2.new(1920, 1080)
			local v1436 = v1434.viewport
			local v1437, v_u_1438 = pcall(v1436)
			if not v1437 or (typeof(v_u_1438) ~= "Vector2" or v_u_1438.X <= 1) then
				v_u_1438 = v1435
			end
			local v1439 = v1434.uiScale
			local v1440, v1441 = pcall(v1439)
			local v1442 = (not v1440 or type(v1441) ~= "number") and 1 or math.clamp(v1441, 0.85, 1.2)
			local v1443 = v_u_5(v_u_1431.FieldOfView / 2)
			local v_u_1444 = math.tan(v1443)
			local v_u_1445 = v_u_1438.X / v_u_1438.Y
			local v_u_1446 = {}
			local function v1453(p1447, p1448) -- name: add
				-- upvalues: (copy) v_u_1431, (copy) v_u_1446, (copy) v_u_1444, (copy) v_u_1445, (ref) v_u_1438
				local v1449
				if p1447 then
					v1449 = p1447:FindFirstChild("Head")
				else
					v1449 = p1447
				end
				if v1449 and v1449:IsA("BasePart") then
					local v1450 = v_u_1431.CFrame:PointToObjectSpace(v1449.Position)
					if v1450.Z < -0.05 then
						local v1451 = v_u_1446
						local v1452 = {
							["m"] = p1447,
							["x"] = (v1450.X / (-v1450.Z * v_u_1444 * v_u_1445) + 1) / 2 * v_u_1438.X,
							["hero"] = p1448
						}
						table.insert(v1451, v1452)
					end
				else
					return
				end
			end
			v1453(p1429.survivor, true)
			for _, v1454 in p1429.mates do
				v1453(v1454.model, false)
			end
			table.sort(v_u_1446, function(p1455, p1456)
				return p1455.x < p1456.x
			end)
			local v1457 = v1442 * 8
			local v1458 = math.floor(v1457)
			for v1459 = 1, 2 do
				for v1460 = 1, #v_u_1446 - 1 do
					local v1461 = v_u_1446[v1460]
					local v1462 = v_u_1446[v1460 + 1]
					local v1463 = p1430.width(v1442, v1432[v1461.m] == true)
					local v1464 = p1430.width(v1442, v1432[v1462.m] == true)
					if v1462.x - v1461.x >= (v1463 + v1464) / 2 + v1458 then
						continue
					end
					for _, v1465 in { v1461, v1462 } do
						if v1465.hero and v1459 ~= 2 then
							continue
						end
						v1432[v1465.m] = true
					end
				end
			end
			return v1432
		end
	end
	return v1432
end
function v_u_4.markersFit(p1466, p1467, p1468, p1469, p1470) -- name: markersFit
	for v1471, v1472 in p1466 do
		if v1472[1] < 0 or (p1469 < v1472[3] or v1472[2] < p1468) then
			return false
		end
		for v1473 = v1471 + 1, #p1466 do
			local v1474 = p1466[v1473]
			if v1472[1] >= v1474[3] + p1470 or (v1474[1] >= v1472[3] + p1470 or (v1472[2] >= v1474[4] + p1470 or v1474[2] >= v1472[4] + p1470)) then
				continue
			end
			return false
		end
		for _, v1475 in p1467 do
			if v1472[1] >= v1475[3] or (v1475[1] >= v1472[3] or (v1472[2] >= v1475[4] or v1475[2] >= v1472[4])) then
				continue
			end
			return false
		end
	end
	return true
end
function v_u_4._markerFit(p1476, p_u_1477, p_u_1478) -- name: _markerFit
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_4
	local v1479 = {}
	local v1480 = p1476.stage
	local v_u_1481 = v_u_1.CurrentCamera
	local v1482 = p1476.cctx and p1476.cctx.shared
	if v1482 then
		v1482 = p1476.cctx.shared.Theme
	end
	if v1480 and (v1480.top and (v_u_1481 and v1482)) then
		local v1483 = p_u_1477.width
		if type(v1483) == "function" then
			local v1484 = v1482.isPhone
			local v1485, v1486 = pcall(v1484)
			if not v1485 or v1486 ~= true then
				return v1479
			end
			local v1487 = Vector2.new(1920, 1080)
			local v1488 = v1482.viewport
			local v1489, v_u_1490 = pcall(v1488)
			if not v1489 or (typeof(v_u_1490) ~= "Vector2" or v_u_1490.X <= 1) then
				v_u_1490 = v1487
			end
			local v1491 = v1482.uiScale
			local v1492, v1493 = pcall(v1491)
			local v_u_1494 = (not v1492 or type(v1493) ~= "number") and 1 or math.clamp(v1493, 0.85, 1.2)
			local v1495 = v_u_5(v_u_1481.FieldOfView / 2)
			local v_u_1496 = math.tan(v1495)
			local v_u_1497 = v_u_1490.X / v_u_1490.Y
			local v1498 = v_u_1494 * 50 + 0.5
			local v_u_1499 = math.floor(v1498)
			local v1500 = v_u_1494 * 6
			local v_u_1501 = math.floor(v1500)
			local v_u_1502 = {}
			local v_u_1503 = {}
			local v_u_1504 = {}
			local function v1529(p1505) -- name: add
				-- upvalues: (copy) v_u_1481, (copy) v_u_1496, (copy) v_u_1497, (ref) v_u_1490, (copy) v_u_1503, (ref) v_u_4, (copy) p_u_1477, (copy) v_u_1494, (copy) p_u_1478, (copy) v_u_1501, (copy) v_u_1499, (copy) v_u_1502, (copy) v_u_1504
				local v1506
				if p1505 then
					v1506 = p1505:FindFirstChild("Head")
				else
					v1506 = nil
				end
				if p1505 and v1506 then
					local v1507 = v_u_1481.CFrame:PointToObjectSpace(v1506.Position + Vector3.new(0, 1.7, 0))
					if v1507.Z < -0.05 then
						local v1508 = (v1507.X / (-v1507.Z * v_u_1496 * v_u_1497) + 1) / 2 * v_u_1490.X
						local v1509 = (1 - v1507.Y / (-v1507.Z * v_u_1496)) / 2 * v_u_1490.Y
						local v1510 = p1505:FindFirstChild("SquadPlate")
						local v1511
						if v1510 then
							v1511 = v1510.Size.Y.Offset
							local v1512 = v1510:FindFirstChild("Panel")
							local v1513
							if v1512 and v1512.AbsoluteSize.X > 4 then
								local v1514 = v1512.AbsoluteSize.X
								local v1515 = v1510.Size.X.Offset
								v1513 = math.min(v1514, v1515)
							else
								v1513 = v1510.Size.X.Offset
							end
							local v1516 = v1508 + v1510.SizeOffset.X * v1510.Size.X.Offset
							local v1517 = v1509 - v1510.SizeOffset.Y * v1511
							local v1518 = v_u_1503
							local v1519 = {
								v1516 - v1513 / 2,
								v1517 - v1511 / 2,
								v1516 + v1513 / 2,
								v1517 + v1511 / 2
							}
							table.insert(v1518, v1519)
							if v1510.SizeOffset.Y > 0 then
								v1511 = v1511 * 3 + 2 * v_u_4.PLATE_RAISE_GAP
							end
						else
							v1511 = 0
						end
						local v1520 = p_u_1477.width
						local v1521 = v_u_1494
						local v1522
						if p_u_1478 == nil then
							v1522 = false
						else
							v1522 = p_u_1478[p1505] == true
						end
						local v1523 = v1520(v1521, v1522)
						local v1524
						if v1511 > 0 then
							v1524 = v1511 / 2 + v_u_1501 + v_u_1499 / 2
						else
							v1524 = v_u_1499 / 2
						end
						local v1525 = v1509 - v1524
						local v1526 = v_u_1502
						local v1527 = {
							v1508 - v1523 / 2,
							v1525 - v_u_1499 / 2,
							v1508 + v1523 / 2,
							v1525 + v_u_1499 / 2
						}
						table.insert(v1526, v1527)
						local v1528 = v_u_1504
						table.insert(v1528, p1505)
					end
				else
					return
				end
			end
			v1529(p1476.survivor)
			for _, v1530 in p1476.mates do
				v1529(v1530.model)
			end
			if #v_u_1502 > 0 and not v_u_4.markersFit(v_u_1502, v_u_1503, v1480.top + 2, v_u_1490.X, 2) then
				for _, v1531 in v_u_1504 do
					v1479[v1531] = true
				end
			end
			return v1479
		end
	end
	return v1479
end
function v_u_4.step(p_u_1532, p1533) -- name: step
	if p_u_1532.root and p_u_1532.root.Parent then
		p_u_1532.lastDt = p1533
		p_u_1532.t = p_u_1532.t + p1533
		local v1534 = p_u_1532._stepSearch
		pcall(v1534, p_u_1532)
		p_u_1532.staggerAt = (p_u_1532.staggerAt or 0) - p1533
		if p_u_1532.staggerAt <= 0 then
			p_u_1532.staggerAt = 0.25
			local v1535 = p_u_1532._stagger
			pcall(v1535, p_u_1532)
		end
		if p_u_1532.halloween then
			p_u_1532.halloween:step(p1533)
		end
		if p_u_1532.tokyoRoof then
			local v1536 = p_u_1532.tokyoRoof.step
			local v1537 = p_u_1532.tokyoRoof
			pcall(v1536, v1537, p1533)
		end
		if p_u_1532.heroPending then
			p_u_1532.pendCheck = (p_u_1532.pendCheck or 0) - p1533
			if p_u_1532.pendCheck <= 0 then
				p_u_1532.pendCheck = 0.25
				local v1538 = p_u_1532._checkAvatar
				local v1539, v1540 = pcall(v1538, p_u_1532)
				if not v1539 then
					warn("[MenuScene] avatar check:", v1540)
				end
			end
		end
		p_u_1532.avatarCheck = (p_u_1532.avatarCheck or 0) - p1533
		if p_u_1532.avatarCheck <= 0 then
			p_u_1532.avatarCheck = 1
			local v1541 = p_u_1532._checkAvatar
			local v1542, v1543 = pcall(v1541, p_u_1532)
			if not v1542 then
				warn("[MenuScene] avatar check:", v1543)
			end
			local v1544 = p_u_1532._checkMates
			local v1545, v1546 = pcall(v1544, p_u_1532)
			if not v1545 then
				warn("[MenuScene] squad check:", v1546)
			end
			for _, v1547 in p_u_1532.mates do
				local v1548 = p_u_1532._dressMate
				pcall(v1548, p_u_1532, v1547)
			end
			if p_u_1532.lastSlots and p_u_1532.gunScale then
				local v1549, v1550 = pcall(function()
					-- upvalues: (copy) p_u_1532
					return p_u_1532.cctx.shared.WeaponDress.displayScale()
				end)
				if v1549 and type(v1550) == "number" then
					local v1551 = v1550 - p_u_1532.gunScale
					if math.abs(v1551) > 0.001 then
						local v1552 = p_u_1532.setLoadout
						local v1553 = p_u_1532.lastSlots
						pcall(v1552, p_u_1532, v1553)
					end
				end
			end
			local v1555, v1556 = pcall(function()
				local v1554 = game:GetService("Players").LocalPlayer
				return tostring(v1554:GetAttribute("SkinsEquipped")) .. "|" .. tostring(v1554:GetAttribute("WeaponSkins"))
			end)
			if v1555 and (p_u_1532.lastSlots and v1556 ~= p_u_1532.skinAttrSeen) then
				p_u_1532.skinAttrSeen = v1556
				local v1557 = p_u_1532.setLoadout
				local v1558 = p_u_1532.lastSlots
				pcall(v1557, p_u_1532, v1558)
			end
		end
		local v1559 = p_u_1532._stepMates
		pcall(v1559, p_u_1532, p1533)
		p_u_1532:_camera(p1533)
		p_u_1532:_lamp(p1533)
		p_u_1532.nextHead = p_u_1532.nextHead - p1533
		if p_u_1532.nextHead <= 0 then
			p_u_1532.nextHead = 5 + math.random() * 6
			p_u_1532.headTarget = math.random() < 0.5 and 0 or (math.random() < 0.5 and -22 or 16)
		end
		local v1560 = p_u_1532.headTurn
		local v1561 = p_u_1532.headTarget - p_u_1532.headTurn
		local v1562 = -p1533 * 1.4
		p_u_1532.headTurn = v1560 + v1561 * (1 - math.exp(v1562))
		p_u_1532:_pose(p_u_1532.t)
	end
end
function v_u_4.destroy(p_u_1563) -- name: destroy
	-- upvalues: (ref) v_u_6
	if p_u_1563.titleConn then
		p_u_1563.titleConn:Disconnect()
		p_u_1563.titleConn = nil
	end
	if p_u_1563.titleKeyConn then
		p_u_1563.titleKeyConn:Disconnect()
		p_u_1563.titleKeyConn = nil
	end
	if p_u_1563.headwearConn then
		p_u_1563.headwearConn:Disconnect()
		p_u_1563.headwearConn = nil
	end
	if p_u_1563.gearConns then
		for _, v1564 in p_u_1563.gearConns do
			v1564:Disconnect()
		end
		p_u_1563.gearConns = nil
	end
	if p_u_1563.hum and p_u_1563.hum.Stop then
		pcall(function()
			-- upvalues: (copy) p_u_1563
			p_u_1563.hum:Stop(0.5)
		end)
	end
	p_u_1563.hum = nil
	local v1565 = p_u_1563.cctx
	if v1565 then
		v1565 = p_u_1563.cctx.controllers.Atmosphere
	end
	if v1565 then
		if v1565.setFocus then
			local v1566 = v1565.setFocus
			pcall(v1566, nil)
		end
		if v1565.setFxAnchor then
			local v1567 = v1565.setFxAnchor
			pcall(v1567, nil)
		end
	end
	if p_u_1563.halloween then
		local v1568 = p_u_1563.halloween.destroy
		local v1569 = p_u_1563.halloween
		pcall(v1568, v1569)
		p_u_1563.halloween = nil
	end
	if p_u_1563.tokyoRoof then
		local v1570 = p_u_1563.tokyoRoof.destroy
		local v1571 = p_u_1563.tokyoRoof
		pcall(v1570, v1571)
		p_u_1563.tokyoRoof = nil
	end
	if p_u_1563.root then
		p_u_1563.root:Destroy()
		p_u_1563.root = nil
	end
	p_u_1563.survivor = nil
	p_u_1563.motors = nil
	p_u_1563.lamp = nil
	for _, v1572 in p_u_1563.mates do
		if not v1572.model then
			continue
		end
		v1572.model:Destroy()
	end
	table.clear(p_u_1563.mates)
	if v_u_6 == p_u_1563 then
		v_u_6 = nil
	end
	local v1573 = game:GetService("Players").LocalPlayer
	if v1573 then
		v1573:SetAttribute("MenuHeroFault", nil)
		v1573:SetAttribute("MenuHeroAssets", nil)
	end
end
return v_u_4