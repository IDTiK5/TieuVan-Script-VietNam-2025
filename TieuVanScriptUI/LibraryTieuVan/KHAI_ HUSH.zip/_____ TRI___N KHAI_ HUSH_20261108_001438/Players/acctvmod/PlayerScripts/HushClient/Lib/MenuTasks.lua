-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTasks

local v_u_1 = {}
local v_u_2
if script and (script.Parent and script.Parent:FindFirstChild("TaskPlaceNames")) then
	v_u_2 = require(script.Parent.TaskPlaceNames)
else
	v_u_2 = nil
end
local v_u_3 = {
	["ready"] = 1,
	["active"] = 2,
	["available"] = 3,
	["locked"] = 4,
	["done"] = 5
}
local v_u_4 = {
	["ready"] = "Ready to hand in",
	["active"] = "Active",
	["available"] = "Available",
	["locked"] = "Locked",
	["done"] = "Completed"
}
local function v_u_9(p_u_5, p6) -- name: traderName
	local v7, v8 = pcall(function()
		-- upvalues: (copy) p_u_5
		return p_u_5.cctx.shared.Traders
	end)
	if v7 and (type(v8) == "table" and (v8.defs and v8.defs[p6])) then
		return v8.defs[p6].name
	else
		return string.upper(p6)
	end
end
function v_u_1.hintsMod(p_u_10) -- name: hintsMod
	local v11, v12 = pcall(function()
		-- upvalues: (copy) p_u_10
		return p_u_10.cctx.shared.TraderHints
	end)
	if v11 and type(v12) == "table" then
		local v13 = v12.handoverExtra
		if type(v13) == "function" then
			return v12
		end
	end
	return nil
end
function v_u_1.repLine(p_u_14, p15, p16) -- name: repLine
	-- upvalues: (copy) v_u_9
	local v17, v18 = pcall(function()
		-- upvalues: (copy) p_u_14
		return p_u_14.cctx.shared.Traders
	end)
	if not v17 or type(v18) ~= "table" then
		v18 = nil
	end
	local v19 = p_u_14.profile
	if not v18 or type(v19) ~= "table" then
		return v_u_9(p_u_14, p15) .. " rep", 0
	end
	local v20 = v19.traders
	local v21
	if type(v20) == "table" then
		v21 = v19.traders[p15] or nil
	else
		v21 = nil
	end
	if not p16 then
		if type(v21) == "table" then
			local v22 = v21.rep
			p16 = tonumber(v22) or 0
		else
			p16 = 0
		end
	end
	local v23 = v19.stats
	local v24
	if type(v23) == "table" then
		local v25 = v19.stats.extracts
		v24 = tonumber(v25) or 0
	else
		v24 = 0
	end
	local v26
	if type(v21) == "table" then
		v26 = v21.partner == true
	else
		v26 = false
	end
	local v27 = v18.progress(p16, v24, v26)
	local v28, v29 = pcall(function()
		-- upvalues: (copy) p_u_14
		return p_u_14.cctx.shared.TaskConds
	end)
	if v28 and type(v29) == "table" then
		local v30 = v29.repText
		if type(v30) == "function" then
			return v29.repText(v_u_9(p_u_14, p15), v27)
		end
	end
	return v_u_9(p_u_14, p15) .. " rep", v27.frac
end
function v_u_1.itemChip(p_u_31, p_u_32) -- name: itemChip
	local v39, v40 = pcall(function()
		-- upvalues: (copy) p_u_31, (copy) p_u_32
		local v33 = p_u_31.cctx.shared.TaskItems
		local function v36(p34) -- name: nameOf
			-- upvalues: (ref) p_u_31
			local v35 = p_u_31.kit.itemDef(p34)
			if v35 then
				return v35.name
			else
				return nil
			end
		end
		local v37 = v33.chip(p_u_32, v36)
		if v37 == nil and v33.nameOrBring then
			local v38 = v33.nameOrBring(p_u_32, v36)
			if v38 then
				v37 = v33.chipFor(v38)
			end
		end
		return v37
	end)
	if v39 and type(v40) == "string" then
		return v40
	else
		return nil
	end
end
function v_u_1.objectiveLabel(p41) -- name: objectiveLabel
	local v42 = p41.desc or p41.event
	local v43 = tostring(v42)
	if p41.fir and not string.find(string.lower(v43), "found in raid", 1, true) then
		return v43 .. "  [found in raid]"
	else
		return v43
	end
end
function v_u_1.condsOn(p_u_44) -- name: condsOn
	local v45, v46 = pcall(function()
		-- upvalues: (copy) p_u_44
		return p_u_44.cctx.shared.TaskConds
	end)
	if not v45 or (type(v46) ~= "table" or not v46.enabled()) then
		v46 = nil
	end
	return v46 ~= nil
end
function v_u_1.nameCap(p47, p_u_48) -- name: nameCap
	local v_u_49 = p47.theme
	local v_u_50 = 0
	local function v54()
		-- upvalues: (copy) p_u_48, (ref) v_u_50, (copy) v_u_49
		local v51 = p_u_48
		if v51 and v51.AbsoluteSize.X > 100 then
			local v52 = v51.AbsoluteSize.X
			local v53 = v_u_49.uiScale
			v_u_50 = v52 / math.max(0.01, v53()) - 44
		end
	end
	pcall(v54)
	if v_u_50 < 100 then
		local v55, v56 = pcall(function()
			-- upvalues: (copy) v_u_49
			return v_u_49.refSize()
		end)
		if v55 and typeof(v56) == "Vector2" then
			v_u_50 = v56.X - 48 - (p47.compact() and 300 or 420) - 1 - 44
		else
			v_u_50 = 600
		end
	end
	local v57 = v_u_50
	local v58 = (math.min(v57, 980) - 8) * 0.6 / 6.8
	local v59 = math.floor(v58)
	return math.max(16, v59)
end
function v_u_1.condLabel(p_u_60, p61, p62) -- name: condLabel
	local v63
	if p62 then
		v63 = nil
	else
		local v64
		v64, v63 = pcall(function()
			-- upvalues: (copy) p_u_60
			return p_u_60.cctx.shared.TaskConds
		end)
		if not v64 or (type(v63) ~= "table" or not v63.enabled()) then
			v63 = nil
		end
	end
	if v63 then
		local v65 = v63.parts(p61)
		if v63.marked(v65) then
			return v63.richFor(v65, p_u_60.theme), v63.plain(v65)
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_1.condText(p_u_66, p67, p68, p69) -- name: condText
	local v70, v71 = pcall(function()
		-- upvalues: (copy) p_u_66
		return p_u_66.cctx.shared.TaskConds
	end)
	if not v70 or (type(v71) ~= "table" or not v71.enabled()) then
		v71 = nil
	end
	if v71 then
		local v72 = v71.textParts(p67, p68, p69)
		if v71.marked(v72) then
			return v71.richFor(v72, p_u_66.theme)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.starSpec(p73, p74, p75) -- name: starSpec
	local v76 = p73 or p74
	return {
		["size"] = v76 and 18 or 14,
		["hit"] = not v76 and 24 or p75(40),
		["y"] = v76 and -17 or -2
	}
end
function v_u_1.detail(p_u_77, p78, p_u_79, p80) -- name: detail
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_1, (copy) v_u_2
	local v_u_81 = p_u_77.ui
	local v_u_82 = p_u_77.theme
	local v_u_83 = v_u_82.color
	local v84 = p_u_77.kit
	local v85, v86 = pcall(function()
		-- upvalues: (copy) p_u_77
		return p_u_77.cctx.shared.Tasks
	end)
	if not v85 or type(v86) ~= "table" then
		v86 = nil
	end
	local v87
	if v86 then
		v87 = v86.get(p_u_79)
	else
		v87 = v86
	end
	local v88
	if type(p80) == "table" then
		local v89 = p80.tasks
		v88 = type(v89) == "table" and (p80.tasks[p_u_79] or {}) or {}
	else
		v88 = {}
	end
	local v90 = v88.state or "locked"
	local v91 = tostring(v90)
	local v92 = v_u_81.list({
		["parent"] = nil,
		["name"] = "Detail",
		["gap"] = 10,
		["parent"] = p78
	})
	v_u_81.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new(980, (1 / 0))
	}, v92)
	if not v87 then
		v84.empty(v92, "Unknown task.")
		return v92
	end
	local v93 = v_u_81.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, -8, 0, 64)
	}, v92)
	v_u_81.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v93,
		["text"] = v_u_9(p_u_77, v87.giver) .. (not v87.story and "" or ("  \194\183  Chapter %d"):format(v87.story)) .. (v87.side and "  \194\183  Side job" or "") .. (v87.squad and "  \194\183  Squad" or ""),
		["color"] = v_u_83.text2,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v_u_81.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h1",
		["textSize"] = 30,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v93,
		["text"] = v87.title,
		["position"] = UDim2.fromOffset(0, 18),
		["size"] = UDim2.new(1, -170, 0, 40)
	})
	v_u_81.badge(v_u_4[v91] or v91, v91 == "ready" and "success" or (v91 == "active" and "warn" or (v91 == "available" and "info" or "muted")), {
		["parent"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["height"] = 20,
		["parent"] = v93,
		["position"] = UDim2.new(1, 0, 0, 30),
		["anchor"] = Vector2.new(1, 0)
	})
	local v94 = v_u_81.new("Frame", {
		["Name"] = "Brief",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["BackgroundColor3"] = v_u_83.raised,
		["Size"] = UDim2.new(1, -8, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v92)
	v_u_81.pad(v94, {
		18,
		16,
		12,
		12
	})
	v_u_81.new("Frame", {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_83.accent,
		["Position"] = UDim2.fromOffset(-18, -12),
		["Size"] = UDim2.new(0, 2, 1, 24)
	}, v94)
	local v95, v96, v97, v98, v99, v100, v101, v102, v103, v104, v105, v106, v107, v108
	if v91 == "done" then
		local v109 = v88.doneText
		if type(v109) == "string" then
			v95 = v88.doneText
			if v95 then
				v_u_81.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v94,
					["text"] = v95,
					["color"] = v_u_83.text
				})
			else
				v_u_81.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v94,
					["text"] = v91 == "locked" and "The briefing opens when this job unlocks." or "Briefing loading...",
					["color"] = v_u_83.muted
				})
			end
			if v91 == "done" then
				v96 = false
			else
				v97 = v88.lockLine
				if type(v97) == "string" then
					v96 = v88.lockLine ~= ""
				else
					v96 = false
				end
			end
			if v91 == "done" then
				v98 = false
			else
				v99 = v88.how
				if type(v99) == "string" then
					v98 = v88.how ~= ""
				else
					v98 = false
				end
			end
			if v88.lock or (v96 or v98) then
				if v88.lock then
					v100 = v88.locks
					if type(v100) == "table" and #v88.locks > 0 then
						v101 = v88.locks
					else
						v101 = { v88.lock }
					end
				else
					v101 = {}
				end
				v102 = v_u_81.new("Frame", {
					["Name"] = "Locks",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 3,
					["Size"] = UDim2.new(1, -8, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v92)
				v_u_81.layout(v102, "v", 2)
				for v114, v115 in v101 do
					v_u_81.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["order"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v102,
						["text"] = "Locked: " .. tostring(v115),
						["color"] = v_u_83.danger,
						["order"] = v114
					})
				end
				if v96 then
					if v88.lock then
						v103 = string.find
						v104 = v88.lock
						if v103(tostring(v104), v88.lockLine, 1, true) then
							if v98 then
								v105 = v_u_81.label
								v106 = {
									["parent"] = nil,
									["name"] = "How",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["order"] = 91,
									["wrap"] = true,
									["autoY"] = true,
									["track"] = false,
									["parent"] = v102
								}
								v107 = v88.how
								v106.text = tostring(v107)
								v106.color = v_u_83.text2
								v105(v106)
							end
						else
							v_u_81.label({
								["parent"] = nil,
								["name"] = "NotPlayable",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["order"] = 90,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102,
								["text"] = "Not playable yet: " .. v88.lockLine .. ".",
								["color"] = v_u_83.accent
							})
							if v98 then
								v105 = v_u_81.label
								v106 = {
									["parent"] = nil,
									["name"] = "How",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["order"] = 91,
									["wrap"] = true,
									["autoY"] = true,
									["track"] = false,
									["parent"] = v102
								}
								v107 = v88.how
								v106.text = tostring(v107)
								v106.color = v_u_83.text2
								v105(v106)
							end
						end
					else
						v_u_81.label({
							["parent"] = nil,
							["name"] = "NotPlayable",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["order"] = 90,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v102,
							["text"] = "Not playable yet: " .. v88.lockLine .. ".",
							["color"] = v_u_83.accent
						})
						if v98 then
							v105 = v_u_81.label
							v106 = {
								["parent"] = nil,
								["name"] = "How",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["order"] = 91,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102
							}
							v107 = v88.how
							v106.text = tostring(v107)
							v106.color = v_u_83.text2
							v105(v106)
						end
					end
				elseif v98 then
					v105 = v_u_81.label
					v106 = {
						["parent"] = nil,
						["name"] = "How",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["order"] = 91,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v102
					}
					v107 = v88.how
					v106.text = tostring(v107)
					v106.color = v_u_83.text2
					v105(v106)
				end
			end
		else
			v108 = v88.text
			if type(v108) == "string" then
				v95 = v88.text
			else
				v95 = nil
			end
			if v95 then
				v_u_81.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v94,
					["text"] = v95,
					["color"] = v_u_83.text
				})
			else
				v_u_81.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v94,
					["text"] = v91 == "locked" and "The briefing opens when this job unlocks." or "Briefing loading...",
					["color"] = v_u_83.muted
				})
			end
			if v91 == "done" then
				v96 = false
			else
				v97 = v88.lockLine
				if type(v97) == "string" then
					v96 = v88.lockLine ~= ""
				else
					v96 = false
				end
			end
			if v91 == "done" then
				v98 = false
			else
				v99 = v88.how
				if type(v99) == "string" then
					v98 = v88.how ~= ""
				else
					v98 = false
				end
			end
			if v88.lock or (v96 or v98) then
				if v88.lock then
					v100 = v88.locks
					if type(v100) == "table" and #v88.locks > 0 then
						v101 = v88.locks
					else
						v101 = { v88.lock }
					end
				else
					v101 = {}
				end
				v102 = v_u_81.new("Frame", {
					["Name"] = "Locks",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 3,
					["Size"] = UDim2.new(1, -8, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v92)
				v_u_81.layout(v102, "v", 2)
				for v114, v115 in v101 do
					v_u_81.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["order"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v102,
						["text"] = "Locked: " .. tostring(v115),
						["color"] = v_u_83.danger,
						["order"] = v114
					})
				end
				if v96 then
					if v88.lock then
						v103 = string.find
						v104 = v88.lock
						if v103(tostring(v104), v88.lockLine, 1, true) then
							if v98 then
								v105 = v_u_81.label
								v106 = {
									["parent"] = nil,
									["name"] = "How",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["order"] = 91,
									["wrap"] = true,
									["autoY"] = true,
									["track"] = false,
									["parent"] = v102
								}
								v107 = v88.how
								v106.text = tostring(v107)
								v106.color = v_u_83.text2
								v105(v106)
							end
						else
							v_u_81.label({
								["parent"] = nil,
								["name"] = "NotPlayable",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["order"] = 90,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102,
								["text"] = "Not playable yet: " .. v88.lockLine .. ".",
								["color"] = v_u_83.accent
							})
							if v98 then
								v105 = v_u_81.label
								v106 = {
									["parent"] = nil,
									["name"] = "How",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["order"] = 91,
									["wrap"] = true,
									["autoY"] = true,
									["track"] = false,
									["parent"] = v102
								}
								v107 = v88.how
								v106.text = tostring(v107)
								v106.color = v_u_83.text2
								v105(v106)
							end
						end
					else
						v_u_81.label({
							["parent"] = nil,
							["name"] = "NotPlayable",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["order"] = 90,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v102,
							["text"] = "Not playable yet: " .. v88.lockLine .. ".",
							["color"] = v_u_83.accent
						})
						if v98 then
							v105 = v_u_81.label
							v106 = {
								["parent"] = nil,
								["name"] = "How",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["order"] = 91,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102
							}
							v107 = v88.how
							v106.text = tostring(v107)
							v106.color = v_u_83.text2
							v105(v106)
						end
					end
				elseif v98 then
					v105 = v_u_81.label
					v106 = {
						["parent"] = nil,
						["name"] = "How",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["order"] = 91,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v102
					}
					v107 = v88.how
					v106.text = tostring(v107)
					v106.color = v_u_83.text2
					v105(v106)
				end
			end
		end
	else
		v108 = v88.text
		if type(v108) == "string" then
			v95 = v88.text
		else
			v95 = nil
		end
		if v95 then
			v_u_81.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v94,
				["text"] = v95,
				["color"] = v_u_83.text
			})
		else
			v_u_81.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v94,
				["text"] = v91 == "locked" and "The briefing opens when this job unlocks." or "Briefing loading...",
				["color"] = v_u_83.muted
			})
		end
		if v91 == "done" then
			v96 = false
		else
			v97 = v88.lockLine
			if type(v97) == "string" then
				v96 = v88.lockLine ~= ""
			else
				v96 = false
			end
		end
		if v91 == "done" then
			v98 = false
		else
			v99 = v88.how
			if type(v99) == "string" then
				v98 = v88.how ~= ""
			else
				v98 = false
			end
		end
		if v88.lock or (v96 or v98) then
			if v88.lock then
				v100 = v88.locks
				if type(v100) == "table" and #v88.locks > 0 then
					v101 = v88.locks
				else
					v101 = { v88.lock }
				end
			else
				v101 = {}
			end
			v102 = v_u_81.new("Frame", {
				["Name"] = "Locks",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 3,
				["Size"] = UDim2.new(1, -8, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v92)
			v_u_81.layout(v102, "v", 2)
			for v114, v115 in v101 do
				v_u_81.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["order"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v102,
					["text"] = "Locked: " .. tostring(v115),
					["color"] = v_u_83.danger,
					["order"] = v114
				})
			end
			if v96 then
				if v88.lock then
					v103 = string.find
					v104 = v88.lock
					if v103(tostring(v104), v88.lockLine, 1, true) then
						if v98 then
							v105 = v_u_81.label
							v106 = {
								["parent"] = nil,
								["name"] = "How",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["order"] = 91,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102
							}
							v107 = v88.how
							v106.text = tostring(v107)
							v106.color = v_u_83.text2
							v105(v106)
						end
					else
						v_u_81.label({
							["parent"] = nil,
							["name"] = "NotPlayable",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["order"] = 90,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v102,
							["text"] = "Not playable yet: " .. v88.lockLine .. ".",
							["color"] = v_u_83.accent
						})
						if v98 then
							v105 = v_u_81.label
							v106 = {
								["parent"] = nil,
								["name"] = "How",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["order"] = 91,
								["wrap"] = true,
								["autoY"] = true,
								["track"] = false,
								["parent"] = v102
							}
							v107 = v88.how
							v106.text = tostring(v107)
							v106.color = v_u_83.text2
							v105(v106)
						end
					end
				else
					v_u_81.label({
						["parent"] = nil,
						["name"] = "NotPlayable",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["order"] = 90,
						["wrap"] = true,
						["autoY"] = true,
						["track"] = false,
						["parent"] = v102,
						["text"] = "Not playable yet: " .. v88.lockLine .. ".",
						["color"] = v_u_83.accent
					})
					if v98 then
						v105 = v_u_81.label
						v106 = {
							["parent"] = nil,
							["name"] = "How",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["order"] = 91,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["parent"] = v102
						}
						v107 = v88.how
						v106.text = tostring(v107)
						v106.color = v_u_83.text2
						v105(v106)
					end
				end
			elseif v98 then
				v105 = v_u_81.label
				v106 = {
					["parent"] = nil,
					["name"] = "How",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["order"] = 91,
					["wrap"] = true,
					["autoY"] = true,
					["track"] = false,
					["parent"] = v102
				}
				v107 = v88.how
				v106.text = tostring(v107)
				v106.color = v_u_83.text2
				v105(v106)
			end
		end
	end
	v84.section(v92, "Objectives", 4)
	local v116 = v_u_1.nameCap(p_u_77, p78)
	for v117, v118 in v87.objectives do
		local v119 = v88.progress
		local v120
		if type(v119) == "table" then
			local v121 = v88.progress[v117]
			v120 = tonumber(v121) or 0
		else
			v120 = 0
		end
		local v122 = v88.need
		local v123
		if type(v122) == "table" then
			local v124 = v88.need[v117]
			v123 = tonumber(v124)
			if not v123 then
				v123 = v118.count or 1
			end
		else
			v123 = v118.count or 1
		end
		if v91 == "done" then
			v120 = v123
		end
		local v125 = ""
		local v126 = false
		if v118.event == "handover" then
			local v127 = v88.stash
			if type(v127) == "table" then
				local v128 = v88.stash[v117]
				if tonumber(v128) then
					v125 = ("  (%d in stash)"):format(v88.stash[v117])
					local v129 = v88.stashAll
					local v130
					if type(v129) == "table" then
						local v131 = v88.stashAll[v117]
						v130 = tonumber(v131) or nil
					else
						v130 = nil
					end
					if v130 and v88.stash[v117] < v130 then
						v125 = ("  (%d in stash, %d not found in raid)"):format(v88.stash[v117], v130 - v88.stash[v117])
					end
					local v132 = v_u_1.hintsMod(p_u_77)
					if v132 and v118.fir == true then
						v125 = v132.handoverExtra(v88.stash[v117], v130, v123, true)
						if v91 == "done" or v120 >= v123 then
							v126 = false
						else
							local v133 = v88.how
							local v134
							if type(v133) == "string" then
								v134 = string.find(v88.how, v132.FIR_NOTE, 1, true) ~= nil
							else
								v134 = false
							end
							v126 = not v134
						end
					end
				end
			end
		end
		local v135, v136 = v_u_1.condLabel(p_u_77, v118, v123 <= v120)
		local v137 = v136 or v_u_1.objectiveLabel(v118)
		local v138 = v84.bar
		local v139 = {
			["label"] = nil,
			["right"] = nil,
			["value"] = nil,
			["color"] = nil,
			["order"] = nil,
			["labelStyle"] = "body",
			["label"] = v137,
			["right"] = ("%d / %d%s"):format(v120, v123, v125)
		}
		local v140 = v120 / math.max(1, v123)
		v139.value = math.clamp(v140, 0, 1)
		local v141
		if v123 <= v120 then
			v141 = v_u_83.success
		else
			v141 = v_u_83.accent
		end
		v139.color = v141
		v139.order = 4 + v117
		local v142 = v138(v92, v139)
		if v135 and v142.left then
			v142.left.RichText = true
			v142.left.Text = v135
		end
		local v143
		if v86 then
			local v144 = v86.objectiveMap
			if type(v144) == "function" then
				v143 = v86.objectiveMap(v118)
			else
				v143 = nil
			end
		else
			v143 = nil
		end
		local v145
		if v143 then
			local v146
			if v86 then
				local v147 = v86.MAP_TAGS
				if type(v147) == "table" and v86.MAP_TAGS[v143] then
					v145 = v86.MAP_TAGS[v143]
					if v_u_2 then
						v146 = v118.room
						if type(v146) == "string" then
							v145 = v_u_2.tag(v145, v143, v118.room)
						end
					end
				else
					v145 = string.upper(v143)
					if v_u_2 then
						v146 = v118.room
						if type(v146) == "string" then
							v145 = v_u_2.tag(v145, v143, v118.room)
						end
					end
				end
			else
				v145 = string.upper(v143)
				if v_u_2 then
					v146 = v118.room
					if type(v146) == "string" then
						v145 = v_u_2.tag(v145, v143, v118.room)
					end
				end
			end
		else
			v145 = nil
		end
		local v148 = v_u_82.isPhone()
		local v149 = v118.filter
		local v150
		if type(v149) == "table" then
			v150 = v118.filter.id or nil
		else
			v150 = nil
		end
		local v151
		if (v118.event == "handover" or v118.event == "found") and (type(v150) == "string" and v84.itemDef(v150) ~= nil) then
			local v152 = v84.wishStar
			v151 = type(v152) == "function"
		else
			v151 = false
		end
		local v153
		if v142.left == nil then
			v153 = false
		elseif v148 and #v137 > 28 then
			v153 = true
		elseif v135 == nil then
			v153 = false
		else
			v153 = v116 < #v137
		end
		local v154 = v153 and 36 or 20
		if v153 then
			v142.left.TextWrapped = true
			v142.left.Size = UDim2.new(0.6, 0, 0, v154)
		end
		local v155
		if v91 == "done" or v120 >= v123 then
			v155 = nil
		else
			v155 = v_u_1.itemChip(p_u_77, v118)
		end
		local v156 = v155 and v118.hint and 16 or 0
		local v157 = ((v118.hint or (v145 or v155)) and 58 or 40) + (v154 - 20) + v156
		local v158 = v118.tip
		local v159
		if type(v158) == "string" and (v118.tip ~= "" and (v91 ~= "done" and v120 < v123)) then
			v159 = v118.tip
		else
			v159 = nil
		end
		if v126 then
			local v160 = v_u_1.hintsMod(p_u_77)
			if v160 then
				if v159 then
					v159 = v159 .. " " .. v160.FIR_NOTE
				else
					v159 = v160.FIR_NOTE
				end
			end
		end
		local v161 = v159 and ((#v159 > 100 or v148) and 44 or 30) or 0
		local v162 = v154 + 2 + (v155 and 16 or 0) + ((v118.hint or v145) and 16 or 0)
		if v159 then
			local v163 = v162 + v161 + 2
			v157 = math.max(v157, v163)
		end
		if v148 and v151 then
			v157 = math.max(v157, 48)
		end
		local v164 = v_u_82.touch
		local v165 = math.max(v157, v164(40))
		v142.frame.Size = UDim2.new(1, -8, 0, v165)
		local v166
		if v145 then
			local v167 = #v145 * 8 + 8
			v166 = math.clamp(v167, 90, 190)
		else
			v166 = 0
		end
		if v155 then
			v_u_81.label({
				["parent"] = nil,
				["name"] = "ItemChip",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v142.frame,
				["text"] = v155,
				["color"] = v_u_83.accent,
				["position"] = UDim2.fromOffset(0, v154 + 2),
				["size"] = UDim2.new(1, -v166, 0, 16)
			})
		end
		if v118.hint and v91 ~= "done" then
			local v168 = v_u_1.condText(p_u_77, v118, v118.hint, "hint")
			local v169 = v_u_81.label
			local v170 = {
				["parent"] = nil,
				["name"] = "Hint",
				["text"] = nil,
				["rich"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v142.frame
			}
			local v171
			if v168 then
				v171 = v168
			else
				local v172 = v118.hint
				v171 = tostring(v172)
			end
			v170.text = v171
			v170.rich = v168 ~= nil
			v170.color = v_u_83.text2
			v170.position = UDim2.fromOffset(0, v154 + 2 + (v155 and 16 or 0))
			v170.size = UDim2.new(1, -v166, 0, 16)
			v169(v170)
		end
		if v159 then
			local v173 = v_u_1.condText(p_u_77, v118, v159, "tip")
			v_u_81.label({
				["parent"] = nil,
				["name"] = "Tip",
				["text"] = nil,
				["rich"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["valign"] = "top",
				["track"] = false,
				["parent"] = v142.frame,
				["text"] = v173 or v159,
				["rich"] = v173 ~= nil,
				["color"] = v_u_83.text2,
				["position"] = UDim2.fromOffset(0, v162),
				["size"] = UDim2.new(1, 0, 0, v161)
			})
		end
		if v145 then
			local v174 = v_u_81.label
			local v175 = {
				["parent"] = nil,
				["name"] = "MapTag",
				["text"] = nil,
				["style"] = "caps",
				["textSize"] = 11,
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v142.frame,
				["text"] = v145
			}
			local v176
			if v123 <= v120 then
				v176 = v_u_83.muted
			elseif v_u_1.condsOn(p_u_77) and v_u_82.cond then
				v176 = v_u_82.cond.map
			else
				v176 = v_u_83.info
			end
			v175.color = v176
			v175.position = UDim2.new(1, -v166, 0, v154 + 3)
			v175.size = UDim2.fromOffset(v166, 14)
			v174(v175)
		end
		if not v151 then
			continue
		end
		local v177 = v_u_1.starSpec(v148, v_u_82.isTouch(), v_u_82.touch)
		v84.wishStar(v142.frame, v150, {
			["size"] = v177.size,
			["hit"] = v177.hit,
			["position"] = UDim2.new(0.6, 0, 0, v177.y),
			["anchor"] = Vector2.new(0, 0)
		})
	end
	v84.section(v92, "Rewards", 20)
	local v_u_178 = v_u_81.new("Frame", {
		["Name"] = "Rewards",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 21,
		["Size"] = UDim2.new(1, -8, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v92)
	v_u_81.new("UIGridLayout", {
		["CellSize"] = UDim2.fromOffset(150, 56),
		["CellPadding"] = UDim2.fromOffset(8, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v_u_178)
	local v179 = v87.rewards or {}
	local function v185(p180, p181, p182, p183) -- name: chip
		-- upvalues: (copy) v_u_81, (copy) v_u_83, (copy) v_u_178, (copy) v_u_82
		local v184 = v_u_81.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_83.raised,
			["LayoutOrder"] = p183
		}, v_u_178)
		v_u_81.stroke(v184, v_u_83.line)
		v_u_81.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v184,
			["text"] = p180,
			["color"] = p182,
			["position"] = UDim2.fromOffset(10, 6),
			["size"] = UDim2.new(1, -20, 0, 22)
		})
		v_u_81.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["position"] = nil,
			["size"] = nil,
			["fit"] = nil,
			["parent"] = v184,
			["text"] = p181,
			["position"] = UDim2.fromOffset(10, 30),
			["size"] = UDim2.new(1, -20, 0, 16),
			["fit"] = v_u_82.isPhone()
		})
	end
	if v179.cash then
		v185(v84.money(v179.cash), "Cash", v_u_83.accent, 1)
	end
	if v179.rep then
		local v186, v187 = pcall(function()
			-- upvalues: (copy) p_u_77
			return p_u_77.cctx.shared.Traders
		end)
		if not v186 or type(v187) ~= "table" then
			v187 = nil
		end
		local v188
		if v187 then
			v188 = v187.gainText(v179.rep)
		else
			local v189 = v179.rep * 100 + 0.5
			v188 = ("+%d REP"):format((math.floor(v189)))
		end
		local v190 = v_u_1.repLine(p_u_77, v87.giver)
		local v191 = string.match(v190, "LV %d+ at %d+") or (string.find(v190, "LV 5 also needs", 1, true) and "LV 5: see PARTNER" or "rep")
		v185(v188, v_u_9(p_u_77, v87.giver) .. "  \194\183  " .. v191, v_u_83.info, 2)
	end
	for v192, v193 in v179.items or {} do
		v185(((v193.n or 1) <= 1 and "" or ("%dx "):format(v193.n)) .. v84.itemName(v193.id), "Item", v_u_83.text, 2 + v192)
	end
	if v179.unlock then
		v185(string.upper(v179.unlock), "Unlocks difficulty", v_u_83.danger, 20)
	end
	local v194, v195 = pcall(function()
		-- upvalues: (copy) p_u_77
		return p_u_77.cctx.shared.Traders
	end)
	if not v194 or type(v195) ~= "table" then
		v195 = nil
	end
	for v196, v197 in not (v195 and v195.unlocksFor) and {} or v195.unlocksFor(p_u_79) do
		local v198 = v197.name or v84.itemName(v197.id)
		if (v197.n or 1) > 1 then
			v198 = ("%dx %s"):format(v197.n, v198)
		end
		v185(v198, ("Unlock  \194\183  %s LV %d"):format(v_u_9(p_u_77, v197.trader), v197.lvl or 1), v_u_83.success, 22 + v196)
	end
	if v179.title then
		local v199 = string.upper(v86 and v86.titles and v86.titles[v179.title] or v179.title)
		local v200 = "Title"
		local v_u_201 = v179.title
		local v_u_202 = v_u_83.success
		local v204, v205 = pcall(function()
			-- upvalues: (copy) p_u_77, (copy) v_u_202, (copy) v_u_201
			if p_u_77.cctx.config.flag("TitleRarity") == false then
				return v_u_202
			end
			local v203 = p_u_77.cctx.shared.TitleRarity
			return v203.textColor(v203.rarityOf(v_u_201), p_u_77.theme)
		end)
		if v204 then
			if typeof(v205) ~= "Color3" then
				v205 = v_u_202
			end
		else
			v205 = v_u_202
		end
		v185(v199, v200, v205, 21)
	end
	local v206 = v_u_81.new("Frame", {
		["Name"] = "Actions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 30,
		["Size"] = UDim2.new(1, -8, 0, v_u_82.touch(48))
	}, v92)
	if v91 == "available" then
		v_u_81.label({
			["parent"] = nil,
			["text"] = "Starting. The task runs on its own.",
			["style"] = "small",
			["size"] = nil,
			["parent"] = v206,
			["size"] = UDim2.fromScale(1, 1)
		})
		return v92
	end
	if v91 == "ready" then
		v_u_81.button({
			["parent"] = nil,
			["text"] = "Complete",
			["kind"] = "primary",
			["icon"] = "check",
			["height"] = 48,
			["width"] = 260,
			["onClick"] = nil,
			["parent"] = v206,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_77, (copy) p_u_79
				local v207 = {
					["op"] = "taskHandIn",
					["task"] = nil,
					["task"] = p_u_79
				}
				p_u_77.op(v207)
			end
		})
		return v92
	end
	if v91 ~= "active" then
		return v92
	end
	local v208 = false
	for v209, v210 in v87.objectives do
		local v211 = v88.progress
		local v212
		if type(v211) == "table" then
			local v213 = v88.progress[v209]
			v212 = tonumber(v213) or 0
		else
			v212 = 0
		end
		local v214 = v88.need
		local v215
		if type(v214) == "table" then
			local v216 = v88.need[v209]
			v215 = tonumber(v216)
			if v215 then
				if v210.event ~= "handover" or v212 >= v215 then
					continue
				end
				v208 = true
			else
				v215 = v210.count or 1
				if v210.event ~= "handover" or v212 >= v215 then
					continue
				end
				v208 = true
			end
		else
			v215 = v210.count or 1
			if v210.event ~= "handover" or v212 >= v215 then
				continue
			end
			v208 = true
		end
	end
	if v208 then
		v_u_81.button({
			["parent"] = nil,
			["text"] = "Hand over items",
			["kind"] = "secondary",
			["icon"] = "hand",
			["height"] = 48,
			["width"] = 260,
			["onClick"] = nil,
			["parent"] = v206,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_77, (copy) p_u_79
				local v217 = {
					["op"] = "taskHandIn",
					["task"] = nil,
					["task"] = p_u_79
				}
				p_u_77.op(v217)
			end
		})
		return v92
	end
	v_u_81.label({
		["parent"] = nil,
		["text"] = "In progress. Raid events count automatically.",
		["style"] = "small",
		["size"] = nil,
		["parent"] = v206,
		["size"] = UDim2.fromScale(1, 1)
	})
	return v92
end
function v_u_1.rewardModal(p_u_218, p219) -- name: rewardModal
	-- upvalues: (copy) v_u_9, (copy) v_u_1
	local v220
	if type(p219) == "table" then
		v220 = p219.data or nil
	else
		v220 = nil
	end
	local v_u_221
	if type(v220) == "table" then
		v_u_221 = v220.rewards or nil
	else
		v_u_221 = nil
	end
	if type(v_u_221) == "table" then
		local v_u_222 = p_u_218.ui
		local v_u_223 = p_u_218.theme
		local v_u_224 = v_u_223.color
		local v_u_225 = p_u_218.kit
		local v226, v_u_227 = pcall(function()
			-- upvalues: (copy) p_u_218
			return p_u_218.cctx.shared.Tasks
		end)
		if not v226 or type(v_u_227) ~= "table" then
			v_u_227 = nil
		end
		local v228, v_u_229 = pcall(function()
			-- upvalues: (copy) p_u_218
			return p_u_218.cctx.shared.Traders
		end)
		if not v228 or type(v_u_229) ~= "table" then
			v_u_229 = nil
		end
		local v230 = v_u_221.task or (v220.task or "")
		local v231 = tostring(v230)
		local v232
		if v_u_227 then
			v232 = v_u_227.get(v231)
		else
			v232 = v_u_227
		end
		local v233 = v_u_221.giver or (v232 and (v232.giver or "") or "")
		local v_u_234 = tostring(v233)
		local v235 = v_u_221.next
		local v_u_236
		if type(v235) == "string" then
			v_u_236 = v_u_221.next
		else
			v_u_236 = nil
		end
		local v237 = {}
		if v_u_236 and (v_u_227 and v_u_227.get(v_u_236)) then
			table.insert(v237, {
				["text"] = "Close"
			})
			table.insert(v237, {
				["text"] = "Next task",
				["onClick"] = nil,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_218, (copy) v_u_236
					if p_u_218.openTask then
						p_u_218.openTask(v_u_236)
					end
				end
			})
		else
			table.insert(v237, {
				["text"] = "Continue"
			})
		end
		local v238 = v_u_222.modal
		local v239 = {
			["title"] = "Task complete",
			["body"] = nil,
			["width"] = 620,
			["build"] = nil,
			["buttons"] = nil
		}
		if v232 then
			v231 = v232.title or v231
		end
		v239.body = v231 .. "  \194\183  " .. v_u_9(p_u_218, v_u_234)
		function v239.build(p240) -- name: build
			-- upvalues: (copy) v_u_222, (copy) v_u_223, (copy) v_u_221, (copy) v_u_224, (copy) v_u_225, (copy) v_u_227, (copy) p_u_218, (copy) v_u_229, (ref) v_u_1, (copy) v_u_234, (ref) v_u_9
			local v241 = v_u_222.list({
				["parent"] = nil,
				["size"] = nil,
				["gap"] = 8,
				["parent"] = p240,
				["size"] = UDim2.new(1, 0, 0, v_u_223.isPhone() and 210 or 340)
			})
			local v242 = v_u_221.doneText
			if type(v242) == "string" and v_u_221.doneText ~= "" then
				local v243 = v_u_222.new("Frame", {
					["Name"] = "Quote",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["BackgroundColor3"] = v_u_224.raised,
					["Size"] = UDim2.new(1, -8, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v241)
				v_u_222.pad(v243, {
					14,
					12,
					10,
					10
				})
				v_u_222.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v243,
					["text"] = v_u_221.doneText,
					["color"] = v_u_224.text
				})
			end
			v_u_225.section(v241, "Rewards", 2)
			local v_u_244 = v_u_222.new("Frame", {
				["Name"] = "Rewards",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 3,
				["Size"] = UDim2.new(1, -8, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v241)
			v_u_222.new("UIGridLayout", {
				["CellSize"] = UDim2.fromOffset(176, 52),
				["CellPadding"] = UDim2.fromOffset(8, 8),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}, v_u_244)
			local function v250(p245, p246, p247, p248) -- name: chip
				-- upvalues: (ref) v_u_222, (ref) v_u_224, (copy) v_u_244
				local v249 = v_u_222.new("Frame", {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["LayoutOrder"] = nil,
					["BackgroundColor3"] = v_u_224.raised,
					["LayoutOrder"] = p248
				}, v_u_244)
				v_u_222.stroke(v249, v_u_224.line)
				v_u_222.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "mono",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v249,
					["text"] = p245,
					["color"] = p247,
					["position"] = UDim2.fromOffset(10, 5),
					["size"] = UDim2.new(1, -20, 0, 22)
				})
				v_u_222.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v249,
					["text"] = p246,
					["position"] = UDim2.fromOffset(10, 28),
					["size"] = UDim2.new(1, -20, 0, 16)
				})
			end
			local v251 = v_u_221.cash
			if (tonumber(v251) or 0) > 0 then
				v250(v_u_225.money(v_u_221.cash), "Cash", v_u_224.accent, 1)
			end
			local v252 = v_u_221.items
			for v253, v254 in type(v252) == "table" and (v_u_221.items or {}) or {} do
				v250(((v254.n or 1) <= 1 and "" or ("%dx "):format(v254.n)) .. v_u_225.itemName(v254.id), "Added to your stash", v_u_224.text, 1 + v253)
			end
			if v_u_221.title then
				local v255 = string.upper(v_u_227 and (v_u_227.titles and v_u_227.titles[v_u_221.title]) or v_u_221.title)
				local v256 = "Title unlocked"
				local v_u_257 = p_u_218
				local v_u_258 = v_u_221.title
				local v_u_259 = v_u_224.success
				local v261, v262 = pcall(function()
					-- upvalues: (copy) v_u_257, (copy) v_u_259, (copy) v_u_258
					if v_u_257.cctx.config.flag("TitleRarity") == false then
						return v_u_259
					end
					local v260 = v_u_257.cctx.shared.TitleRarity
					return v260.textColor(v260.rarityOf(v_u_258), v_u_257.theme)
				end)
				if v261 then
					if typeof(v262) ~= "Color3" then
						v262 = v_u_259
					end
				else
					v262 = v_u_259
				end
				v250(v255, v256, v262, 20)
			end
			if v_u_221.unlock then
				local v263 = string.upper
				local v264 = v_u_221.unlock
				v250(v263((tostring(v264))), "Difficulty unlocked", v_u_224.danger, 21)
			end
			local v265 = v_u_221.offers
			for v266, v267 in type(v265) == "table" and (v_u_221.offers or {}) or {} do
				local v268 = v267.name or (v267.id or "?")
				local v269 = tostring(v268)
				local v270 = v267.traderName or v267.trader
				local v271 = tostring(v270)
				local v272 = v267.lvl
				v250(v269, ("Now at %s LV %d"):format(v271, tonumber(v272) or 1), v_u_224.success, 30 + v266)
			end
			if v_u_229 then
				local v273 = v_u_221.rep
				if (tonumber(v273) or 0) > 0 then
					v_u_225.section(v241, "Reputation", 40)
					local v274 = v_u_1.repLine
					local v275 = p_u_218
					local v276 = v_u_234
					local v277 = v_u_221.repAfter
					local v278, v279 = v274(v275, v276, (tonumber(v277)))
					local v280 = v_u_229.points
					local v281 = v_u_221.repBefore
					local v282 = v280(tonumber(v281) or 0)
					local v283 = v_u_229.points
					local v284 = v_u_221.repAfter
					local v285 = v283(tonumber(v284) or 0)
					local v286 = v_u_221.lvlAfter
					local v287 = tonumber(v286) or 0
					local v288 = v_u_221.lvlBefore
					local v289 = (tonumber(v288) or 0) < v287
					local v290 = v_u_225.bar
					local v291 = {
						["label"] = nil,
						["right"] = "",
						["value"] = nil,
						["color"] = nil,
						["order"] = 41,
						["labelStyle"] = "body",
						["label"] = ("%s  (%d -> %d)"):format(v_u_229.gainText(v_u_221.rep), v282, v285) .. (not v289 and "" or ("  \194\183  %s is now LV %d"):format(v_u_9(p_u_218, v_u_234), v_u_221.lvlAfter)),
						["value"] = v279
					}
					local v292
					if v289 then
						v292 = v_u_224.success
					else
						v292 = v_u_224.info
					end
					v291.color = v292
					local v293 = v290(v241, v291)
					v293.frame.Size = UDim2.new(1, -8, 0, 40)
					if v293.left then
						v293.left.Size = UDim2.new(1, 0, 0, 20)
					end
					v_u_222.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["order"] = 42,
						["size"] = nil,
						["track"] = false,
						["parent"] = v241,
						["text"] = v278,
						["color"] = v_u_224.text2,
						["size"] = UDim2.new(1, -8, 0, 18)
					})
				end
			end
		end
		v239.buttons = v237
		v238(v239)
		v_u_222.sound(v_u_223.sounds.purchase)
	end
end
local v_u_294 = false
function v_u_1.showTape(p_u_295, p_u_296) -- name: showTape
	-- upvalues: (ref) v_u_294
	if not v_u_294 then
		v_u_294 = true
		task.spawn(function()
			-- upvalues: (copy) p_u_295, (copy) p_u_296, (ref) v_u_294
			local v_u_297 = p_u_295.ui
			local v_u_298 = p_u_295.theme
			local v_u_299 = v_u_298.color
			local v300 = p_u_295.fetch
			local v301 = {
				["id"] = p_u_296
			}
			local v302, v_u_303 = pcall(v300, "tape", v301, 600)
			v_u_294 = false
			if v302 and type(v_u_303) == "table" then
				local v304 = v_u_303.text
				if type(v304) ~= "string" then
					v_u_303 = nil
				end
			else
				v_u_303 = nil
			end
			if v_u_303 then
				v_u_297.sound(v_u_298.sounds.toggle)
				local v305 = v_u_297.modal
				local v306 = {
					["title"] = nil,
					["body"] = nil,
					["width"] = 640,
					["build"] = nil,
					["buttons"] = nil
				}
				local v307 = v_u_303.title or p_u_296
				v306.title = tostring(v307)
				local v308 = v_u_303.speaker or ""
				local v309 = tostring(v308)
				local v310 = v_u_303.date or ""
				v306.body = ("%s  \194\183  %s"):format(v309, (tostring(v310)))
				function v306.build(p311) -- name: build
					-- upvalues: (copy) v_u_297, (copy) v_u_298, (copy) v_u_303, (copy) v_u_299
					local v312 = v_u_297.list({
						["parent"] = p311,
						["size"] = UDim2.new(1, 0, 0, v_u_298.isPhone() and 210 or 300),
						["padding"] = {
							0,
							10,
							6,
							6
						}
					})
					local v313 = v_u_297.label
					local v314 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["textSize"] = 14,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = v312
					}
					local v315 = v_u_303.text or ""
					v314.text = tostring(v315)
					v314.color = v_u_299.text
					v313(v314)
				end
				v306.buttons = {
					{
						["text"] = "Close"
					}
				}
				v305(v306)
			else
				v_u_297.toast("Disc not found yet", "warn", "Find it in a raid and extract to read it")
			end
		end)
	end
end
v_u_1.TABS = {
	{
		["id"] = "tasks",
		["text"] = "TASKS"
	},
	{
		["id"] = "discs",
		["text"] = "LOG DISCS"
	},
	{
		["id"] = "cutscenes",
		["text"] = "CUTSCENES"
	}
}
function v_u_1.tabIds(p316) -- name: tabIds
	-- upvalues: (copy) v_u_1
	local v317 = {}
	if p316 == true then
		for _, v318 in v_u_1.TABS do
			local v319 = v318.id
			table.insert(v317, v319)
		end
	end
	return v317
end
function v_u_1.normalizeTab(p320, p321) -- name: normalizeTab
	-- upvalues: (copy) v_u_1
	if p321 == true and type(p320) == "string" then
		for _, v322 in v_u_1.TABS do
			if v322.id ~= p320 then
				continue
			end
			return p320
		end
	end
	return "tasks"
end
function v_u_1.sections(p323, p324) -- name: sections
	-- upvalues: (copy) v_u_1
	return p324 == true and { v_u_1.normalizeTab(p323, true) } or { "tasks", "discs" }
end
function v_u_1.rightFor(p325, p326) -- name: rightFor
	-- upvalues: (copy) v_u_1
	local v327 = v_u_1.normalizeTab(p325, p326)
	return v327 == "tasks" and "task" or (v327 == "discs" and "discs" or "cutscenes")
end
function v_u_1.new(p_u_328, p_u_329) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9
	local v_u_330 = p_u_328.ui
	local v_u_331 = p_u_328.theme
	local v_u_332 = v_u_331.color
	local v_u_333 = p_u_328.kit
	local v334 = p_u_328.compact()
	v_u_331.isPhone()
	local v_u_335 = {}
	local v_u_336 = nil
	local v_u_337 = nil
	local v_u_338 = false
	local v_u_339 = "tasks"
	local v_u_340 = false
	local v_u_341 = {
		["view"] = nil,
		["loading"] = false
	}
	local v_u_342 = {}
	local _, v343 = v_u_330.panel({
		["parent"] = nil,
		["name"] = "Tasks",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 0,
		["parent"] = p_u_329,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v_u_344 = v334 and 300 or 420
	local v345 = v_u_330.new("Frame", {
		["Name"] = "Left",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(0, v_u_344, 1, 0)
	}, v343)
	v_u_330.pad(v345, {
		16,
		8,
		16,
		16
	})
	local v_u_346 = v_u_331.touch(40)
	local v_u_347 = nil
	local v_u_349, v_u_350 = v_u_330.tabs({
		["parent"] = nil,
		["name"] = "TabBar",
		["tabs"] = nil,
		["selected"] = "tasks",
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = v345,
		["tabs"] = v_u_1.TABS,
		["size"] = UDim2.new(1, 0, 0, v_u_346),
		["onChange"] = function(p348) -- name: onChange
			-- upvalues: (ref) v_u_347
			v_u_347(p348)
		end
	})
	v_u_349.Visible = false
	local v_u_351 = v_u_330.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 56)
	}, v345)
	local v_u_352 = v_u_330.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Tasks",
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v_u_351,
		["size"] = UDim2.new(1, 0, 0, 30)
	})
	local v_u_353 = v_u_330.label({
		["parent"] = nil,
		["name"] = "Counts",
		["text"] = "",
		["style"] = "monoS",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_351,
		["position"] = UDim2.fromOffset(0, 32),
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v_u_354 = v_u_330.list({
		["parent"] = nil,
		["name"] = "List",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 4,
		["parent"] = v345,
		["position"] = UDim2.fromOffset(0, 60),
		["size"] = UDim2.new(1, 0, 1, -60)
	})
	v_u_330.divider({
		["parent"] = nil,
		["vertical"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v343,
		["position"] = UDim2.fromOffset(v_u_344, 0),
		["size"] = UDim2.new(0, 1, 1, 0)
	})
	local v_u_355 = v_u_330.new("Frame", {
		["Name"] = "Right",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_344 + 1, 0),
		["Size"] = UDim2.new(1, -v_u_344 - 1, 1, 0)
	}, v343)
	v_u_330.pad(v_u_355, {
		24,
		16,
		20,
		16
	})
	local function v_u_359() -- name: applyMode
		-- upvalues: (copy) p_u_328, (ref) v_u_340, (ref) v_u_339, (ref) v_u_1, (copy) v_u_349, (copy) v_u_350, (copy) v_u_352, (copy) v_u_351, (copy) v_u_346, (copy) v_u_353, (copy) v_u_354
		local function v356()
			-- upvalues: (ref) p_u_328
			return p_u_328.cctx.config.flag("StoryScenes")
		end
		local v357, v358 = pcall(v356)
		if v357 then
			v357 = v358 == true
		end
		v_u_340 = v357
		v_u_339 = v_u_1.normalizeTab(v_u_339, v357)
		v_u_349.Visible = v357
		if v357 then
			v_u_350.select(v_u_339, true)
			v_u_352.Visible = false
			v_u_351.Position = UDim2.fromOffset(0, v_u_346 + 6)
			v_u_351.Size = UDim2.new(1, 0, 0, 18)
			v_u_353.Position = UDim2.fromOffset(0, 0)
			v_u_354.Position = UDim2.fromOffset(0, v_u_346 + 28)
			v_u_354.Size = UDim2.new(1, 0, 1, -(v_u_346 + 28))
		else
			v_u_352.Visible = true
			v_u_351.Position = UDim2.fromOffset(0, 0)
			v_u_351.Size = UDim2.new(1, 0, 0, 56)
			v_u_353.Position = UDim2.fromOffset(0, 32)
			v_u_354.Position = UDim2.fromOffset(0, 60)
			v_u_354.Size = UDim2.new(1, 0, 1, -60)
		end
	end
	local v_u_360 = nil
	local function v_u_370() -- name: drawDiscsInfo
		-- upvalues: (copy) v_u_330, (copy) v_u_355, (copy) v_u_332, (copy) p_u_328, (ref) v_u_337
		local v361 = {
			["parent"] = nil,
			["name"] = "Detail",
			["gap"] = 10,
			["parent"] = v_u_355
		}
		local v362 = v_u_330.list(v361)
		v_u_330.new("UISizeConstraint", {
			["MaxSize"] = Vector2.new(980, (1 / 0))
		}, v362)
		local v363 = v_u_330.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, -8, 0, 64)
		}, v362)
		v_u_330.label({
			["parent"] = nil,
			["text"] = "Story",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v363,
			["color"] = v_u_332.text2,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v_u_330.label({
			["parent"] = nil,
			["text"] = "Log discs",
			["style"] = "h1",
			["textSize"] = 30,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v363,
			["position"] = UDim2.fromOffset(0, 18),
			["size"] = UDim2.new(1, -170, 0, 40)
		})
		local function v364()
			-- upvalues: (ref) p_u_328
			return p_u_328.cctx.shared.LogDiscs
		end
		local v365, v366 = pcall(v364)
		if v365 and type(v366) == "table" then
			local v367 = v_u_337
			if type(v367) == "table" then
				local v368 = v366.view(v_u_337.tapes)
				v_u_330.label({
					["parent"] = nil,
					["name"] = "Counts",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["parent"] = v363,
					["text"] = v368.count .. " FOUND",
					["color"] = v_u_332.text2,
					["position"] = UDim2.new(1, 0, 0, 30),
					["anchor"] = Vector2.new(1, 0),
					["size"] = UDim2.fromOffset(160, 16)
				})
			end
		end
		local v369 = v_u_330.new("Frame", {
			["Name"] = "Brief",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_332.raised,
			["Size"] = UDim2.new(1, -8, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v362)
		v_u_330.pad(v369, {
			18,
			16,
			12,
			12
		})
		v_u_330.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_332.accent,
			["Position"] = UDim2.fromOffset(-18, -12),
			["Size"] = UDim2.new(0, 2, 1, 24)
		}, v369)
		v_u_330.label({
			["parent"] = nil,
			["text"] = "Voice logs recorded around Stillwater, The Hollow and Kestrel Field. Select a disc to read its transcript. A disc you have not found yet is listed without its title.",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v369,
			["color"] = v_u_332.text
		})
	end
	local function v_u_376() -- name: drawRight
		-- upvalues: (ref) v_u_1, (ref) v_u_339, (ref) v_u_340, (copy) v_u_333, (copy) v_u_355, (ref) v_u_336, (copy) p_u_328, (ref) v_u_337, (ref) v_u_360, (copy) v_u_330, (copy) v_u_370, (copy) v_u_341
		local v371 = v_u_1.rightFor(v_u_339, v_u_340)
		if v371 == "task" then
			local function v372() -- name: rebuild
				-- upvalues: (ref) v_u_333, (ref) v_u_355, (ref) v_u_336, (ref) v_u_1, (ref) p_u_328, (ref) v_u_337
				v_u_333.clear(v_u_355)
				if v_u_336 then
					v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
				else
					v_u_333.empty(v_u_355, "Select a task.")
				end
			end
			if v_u_336 == nil or v_u_336 ~= v_u_360 then
				v_u_333.clear(v_u_355)
				if v_u_336 then
					v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
				else
					v_u_333.empty(v_u_355, "Select a task.")
				end
			else
				v_u_330.keepScroll(v_u_355, v372)
			end
			v_u_360 = v_u_336
			return
		else
			v_u_360 = nil
			v_u_333.clear(v_u_355)
			if v371 == "discs" then
				v_u_370()
				return
			else
				local function v373()
					-- upvalues: (ref) p_u_328
					return p_u_328.cctx.lib.MenuCutscenes
				end
				local v374, v375 = pcall(v373)
				if not v374 or type(v375) ~= "table" then
					v375 = nil
				end
				if v375 then
					v375.drawDetail(p_u_328, v_u_355, v_u_341)
				else
					v_u_333.empty(v_u_355, "Cutscenes are not available right now.")
				end
			end
		end
	end
	local v_u_377 = nil
	local function v_u_421(p378) -- name: drawTaskRows
		-- upvalues: (ref) v_u_337, (ref) v_u_3, (copy) v_u_333, (copy) v_u_354, (ref) v_u_4, (copy) v_u_330, (ref) v_u_336, (copy) v_u_332, (copy) v_u_331, (ref) v_u_9, (copy) p_u_328, (ref) v_u_377, (copy) v_u_355, (ref) v_u_1, (ref) v_u_360
		local v379 = v_u_337.order
		local v380 = {}
		for _, v381 in type(v379) == "table" and (v_u_337.order or {}) or {} do
			table.insert(v380, v381)
		end
		table.sort(v380, function(p382, p383)
			-- upvalues: (ref) v_u_3, (ref) v_u_337
			local v384 = v_u_3[(v_u_337.tasks[p382] or {}).state or "locked"] or 9
			local v385 = v_u_3[(v_u_337.tasks[p383] or {}).state or "locked"] or 9
			if v384 == v385 then
				return (table.find(v_u_337.order, p382) or 0) < (table.find(v_u_337.order, p383) or 0)
			else
				return v384 < v385
			end
		end)
		local v386 = ""
		local v387 = 0
		for _, v_u_388 in v380 do
			local v389 = p378.get(v_u_388)
			local v390 = v_u_337.tasks[v_u_388] or {}
			local v391 = v390.state or "locked"
			local v392 = tostring(v391)
			if not v389 then
				continue
			end
			if v392 ~= v386 then
				v387 = v387 + 1
				v_u_333.section(v_u_354, v_u_4[v392] or v392, v387)
				v386 = v392
			end
			v387 = v387 + 1
			local v393 = v_u_330.new
			local v394 = "TextButton"
			local v395 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Selectable"] = true,
				["Name"] = v_u_388
			}
			local v396
			if v_u_388 == v_u_336 then
				v396 = v_u_332.accentDeep
			else
				v396 = v_u_332.raised
			end
			v395.BackgroundColor3 = v396
			v395.BackgroundTransparency = v_u_388 == v_u_336 and 0 or 0.3
			v395.Size = UDim2.new(1, -6, 0, v_u_331.touch(50))
			v395.LayoutOrder = v387
			local v397 = v393(v394, v395, v_u_354)
			v397.SelectionImageObject = v_u_330.selectionImage()
			local v398 = v_u_330.stroke
			local v399
			if v_u_388 == v_u_336 then
				v399 = v_u_332.accent
			else
				v399 = v_u_332.line
			end
			local v_u_400 = v398(v397, v399)
			local v401 = v_u_330.new
			local v402 = "Frame"
			local v403 = {
				["Name"] = "State",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil
			}
			local v404 = v_u_332
			local v405
			if v392 == "ready" then
				v405 = v404.success
			elseif v392 == "active" then
				v405 = v404.accent
			elseif v392 == "available" then
				v405 = v404.info
			elseif v392 == "done" then
				v405 = v404.muted
			else
				v405 = v404.muted
			end
			v403.BackgroundColor3 = v405
			v403.Size = UDim2.new(0, 3, 1, 0)
			v401(v402, v403, v397)
			local v406 = v_u_330.label
			local v407 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v397,
				["text"] = v389.title
			}
			local v408
			if v392 == "locked" or v392 == "done" then
				v408 = v_u_332.text2
			else
				v408 = v_u_332.text
			end
			v407.color = v408
			v407.position = UDim2.fromOffset(14, 6)
			v407.size = UDim2.new(1, -24, 0, 20)
			v406(v407)
			local v409 = ""
			local v410 = v390.progress
			if type(v410) == "table" then
				local v411 = v390.need
				if type(v411) == "table" and (v392 == "active" or v392 == "ready") then
					local v412 = 0
					local v413 = 0
					for v414, v415 in v390.need do
						v412 = v412 + v415
						local v416 = v390.progress[v414]
						local v417 = tonumber(v416) or 0
						v413 = v413 + math.min(v417, v415)
					end
					v409 = ("  \194\183  %d/%d"):format(v413, v412)
				end
			end
			v_u_330.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v397,
				["text"] = v_u_9(p_u_328, v389.giver) .. (v389.side and "  \194\183  Side job" or "") .. v409,
				["color"] = v_u_332.text2,
				["position"] = UDim2.fromOffset(14, 28),
				["size"] = UDim2.new(1, -24, 0, 14)
			})
			v397.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_400, (ref) v_u_332, (ref) v_u_330, (ref) v_u_331
				v_u_400.Color = v_u_332.lineStrong
				v_u_330.sound(v_u_331.sounds.hover)
			end)
			v397.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_400, (copy) v_u_388, (ref) v_u_336, (ref) v_u_332
				local v418 = v_u_400
				local v419
				if v_u_388 == v_u_336 then
					v419 = v_u_332.accent
				else
					v419 = v_u_332.line
				end
				v418.Color = v419
			end)
			v397.Activated:Connect(function()
				-- upvalues: (ref) v_u_336, (copy) v_u_388, (ref) v_u_330, (ref) v_u_331, (ref) v_u_354, (ref) v_u_377, (ref) v_u_333, (ref) v_u_355, (ref) v_u_1, (ref) p_u_328, (ref) v_u_337, (ref) v_u_360
				v_u_336 = v_u_388
				v_u_330.sound(v_u_331.sounds.click)
				v_u_330.keepScroll(v_u_354, v_u_377)
				local function v420() -- name: rebuild
					-- upvalues: (ref) v_u_333, (ref) v_u_355, (ref) v_u_336, (ref) v_u_1, (ref) p_u_328, (ref) v_u_337
					v_u_333.clear(v_u_355)
					if v_u_336 then
						v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
					else
						v_u_333.empty(v_u_355, "Select a task.")
					end
				end
				if v_u_336 == nil or v_u_336 ~= v_u_360 then
					v_u_333.clear(v_u_355)
					if v_u_336 then
						v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
					else
						v_u_333.empty(v_u_355, "Select a task.")
					end
				else
					v_u_330.keepScroll(v_u_355, v420)
				end
				v_u_360 = v_u_336
			end)
		end
		return v387, v380
	end
	local function v_u_434(p422, p423) -- name: drawDiscRows
		-- upvalues: (copy) p_u_328, (ref) v_u_337, (copy) v_u_333, (copy) v_u_354, (copy) v_u_330, (copy) v_u_332, (copy) v_u_344, (ref) v_u_1
		local function v424()
			-- upvalues: (ref) p_u_328
			return p_u_328.cctx.shared.LogDiscs
		end
		local v425, v426 = pcall(v424)
		if not v425 or type(v426) ~= "table" then
			return p422, nil
		end
		local v427 = v426.view(v_u_337.tapes)
		if p423 then
			p422 = p422 + 1
			v_u_333.section(v_u_354, "Log discs", p422, v427.count)
		end
		for _, v428 in v427.groups do
			p422 = p422 + 1
			local v429 = v_u_330.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "DiscGroup_" .. v428.map,
				["Size"] = UDim2.new(1, -6, 0, 22),
				["LayoutOrder"] = p422
			}, v_u_354)
			v_u_330.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v429,
				["text"] = v428.name,
				["color"] = v_u_332.muted,
				["position"] = UDim2.fromOffset(12, 0),
				["size"] = UDim2.new(1, -90, 1, 0)
			})
			v_u_330.label({
				["parent"] = nil,
				["name"] = "Count",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v429,
				["text"] = v428.count,
				["color"] = v_u_332.muted,
				["position"] = UDim2.new(1, -78, 0, 0),
				["size"] = UDim2.fromOffset(78, 22)
			})
			for _, v_u_430 in v428.rows do
				p422 = p422 + 1
				local v432, _ = v_u_330.button({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["kind"] = "ghost",
					["icon"] = nil,
					["height"] = 34,
					["width"] = nil,
					["order"] = nil,
					["disabled"] = nil,
					["onClick"] = nil,
					["parent"] = v_u_354,
					["name"] = "Disc_" .. v_u_430.id,
					["text"] = v_u_430.text,
					["icon"] = v_u_430.found and "eye" or "lock",
					["width"] = v_u_344 - 40,
					["order"] = p422,
					["disabled"] = v_u_430.locked,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_430, (ref) v_u_1, (ref) p_u_328
						local v431 = v_u_430.id
						v_u_1.showTape(p_u_328, v431)
					end
				})
				local v433 = v432:FindFirstChild("Inner")
				if v433 then
					v433 = v433:FindFirstChildOfClass("UIListLayout")
				end
				if not v433 then
					continue
				end
				v433.HorizontalAlignment = Enum.HorizontalAlignment.Left
			end
		end
		return p422, v427.count
	end
	local function v_u_441(p435) -- name: startReplay
		-- upvalues: (copy) p_u_328, (copy) v_u_330
		local function v436()
			-- upvalues: (ref) p_u_328
			return p_u_328.cctx.lib.MenuCutscenes
		end
		local v437, v438 = pcall(v436)
		if not v437 or type(v438) ~= "table" then
			v438 = nil
		end
		if v438 then
			local v439, v440 = v438.play(p_u_328, p435)
			if not v439 then
				v_u_330.toast(v440 or "That scene cannot play now", "warn")
			end
		else
			v_u_330.toast("Cutscenes are not available right now", "warn", "Try again after the next menu open.")
		end
	end
	v_u_377 = function() -- name: drawListNow
		-- upvalues: (copy) v_u_333, (copy) v_u_354, (ref) v_u_1, (ref) v_u_339, (ref) v_u_340, (copy) p_u_328, (copy) v_u_341, (copy) v_u_335, (copy) v_u_441, (copy) v_u_349, (copy) v_u_353, (ref) v_u_337, (ref) v_u_338, (copy) v_u_330, (copy) v_u_421, (copy) v_u_434
		v_u_333.clear(v_u_354)
		local v442 = {}
		for _, v443 in v_u_1.sections(v_u_339, v_u_340) do
			v442[v443] = true
		end
		local v444 = ""
		if v442.cutscenes then
			local function v445()
				-- upvalues: (ref) p_u_328
				return p_u_328.cctx.lib.MenuCutscenes
			end
			local v446, v447 = pcall(v445)
			if not v446 or type(v447) ~= "table" then
				v447 = nil
			end
			if v447 then
				v447.drawList(p_u_328, v_u_354, {
					["view"] = v_u_341.view,
					["loading"] = v_u_341.loading,
					["onRetry"] = function() -- name: onRetry
						-- upvalues: (ref) v_u_335
						v_u_335.loadCutscenes(true)
					end,
					["onPlay"] = v_u_441,
					["up"] = v_u_349:FindFirstChild("Row") and v_u_349.Row:FindFirstChild("Tab_cutscenes") or nil
				})
			else
				v_u_333.empty(v_u_354, "Cutscenes are not available right now.")
			end
			v_u_353.Text = not v_u_341.view and "" or v_u_341.view.text
			return
		else
			local v_u_448 = p_u_328
			local v449, v450 = pcall(function()
				-- upvalues: (copy) v_u_448
				return v_u_448.cctx.shared.Tasks
			end)
			if not v449 or type(v450) ~= "table" then
				v450 = nil
			end
			if v450 then
				local v451 = v_u_337
				if type(v451) == "table" then
					local v452 = v_u_337.tasks
					if type(v452) == "table" then
						local v453, v454
						if v442.tasks then
							v453, v454 = v_u_421(v450)
						else
							v453 = 0
							v454 = {}
						end
						if v442.discs then
							local _, v455 = v_u_434(v453, v442.tasks == true)
							if not v442.tasks and v455 then
								v444 = v455 .. " FOUND"
							end
						end
						local v456 = v_u_337.counts or {}
						if v442.tasks then
							local v457 = v456.active
							local v458 = tonumber(v457) or 0
							local v459 = v456.ready
							local v460 = tonumber(v459) or 0
							local v461 = v456.done
							local v462 = tonumber(v461) or 0
							local v463 = v456.total
							v444 = ("ACTIVE %d   READY %d   DONE %d/%d"):format(v458, v460, v462, tonumber(v463) or 0)
						end
						v_u_353.Text = v444
						if v442.tasks and game:GetService("RunService"):IsStudio() then
							local v464 = {}
							local v_u_465 = {}
							for _, v466 in v454 do
								local v467 = (v_u_337.tasks[v466] or {}).state or "locked"
								local v468 = tostring(v467)
								if v464[v468] then
									continue
								end
								v464[v468] = true
								local v469 = v468 .. "=" .. v466
								table.insert(v_u_465, v469)
							end
							local function v470()
								-- upvalues: (ref) p_u_328, (copy) v_u_465
								p_u_328.cctx.player:SetAttribute("DevTaskStates", table.concat(v_u_465, " "))
							end
							pcall(v470)
						end
						return
					end
				end
			end
			local function v471()
				-- upvalues: (ref) p_u_328
				return p_u_328.cctx.shared.TaskConds
			end
			local v472, v473 = pcall(v471)
			local v474
			if v472 and type(v473) == "table" then
				local v475 = v473.loadText
				v474 = type(v475) ~= "function" and "Loading tasks..." or v473.loadText(v_u_338)
			else
				v474 = "Loading tasks..."
			end
			if v_u_338 then
				v_u_333.empty(v_u_354, v474)
				local v476 = {
					["parent"] = nil,
					["name"] = "RetryTasks",
					["text"] = "Try again",
					["kind"] = "secondary",
					["height"] = 44,
					["width"] = 220,
					["onClick"] = nil,
					["parent"] = v_u_354,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_335
						v_u_335.retryTasks()
					end
				}
				v_u_330.button(v476)
			else
				v_u_333.empty(v_u_354, v474)
			end
		end
	end
	local v_u_477 = 0
	function v_u_335.loadCutscenes(p_u_478) -- name: loadCutscenes
		-- upvalues: (copy) p_u_328, (copy) v_u_341, (copy) p_u_329, (ref) v_u_340, (ref) v_u_339, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_376
		local function v479()
			-- upvalues: (ref) p_u_328
			return p_u_328.cctx.lib.MenuCutscenes
		end
		local v480, v_u_481 = pcall(v479)
		if not v480 or type(v_u_481) ~= "table" then
			v_u_481 = nil
		end
		if v_u_481 then
			if v_u_341.view == nil then
				v_u_341.loading = true
			end
			task.spawn(function()
				-- upvalues: (ref) p_u_328, (copy) p_u_478, (ref) v_u_341, (copy) v_u_481, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376
				local v482 = p_u_328.fetch("cutscenes", nil, p_u_478 and 0 or 15)
				v_u_341.loading = false
				v_u_341.view = v_u_481.cleanView(v482)
				if p_u_329.Parent and (v_u_340 and v_u_339 == "cutscenes") then
					v_u_330.keepScroll(v_u_354, v_u_377)
					v_u_376()
				end
			end)
			if p_u_329.Parent and (v_u_340 and v_u_339 == "cutscenes") then
				v_u_330.keepScroll(v_u_354, v_u_377)
				v_u_376()
			end
		end
	end
	v_u_347 = function(p483) -- name: setTab
		-- upvalues: (ref) v_u_1, (ref) v_u_340, (ref) v_u_339, (copy) v_u_350, (copy) v_u_335, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_376
		local v484 = v_u_1.normalizeTab(p483, v_u_340)
		if v484 == v_u_339 then
			return
		else
			v_u_339 = v484
			v_u_350.select(v484, true)
			if v484 == "cutscenes" then
				v_u_335.loadCutscenes(false)
			else
				v_u_330.keepScroll(v_u_354, v_u_377)
				v_u_376()
			end
		end
	end
	function v_u_335.retryTasks() -- name: retryTasks
		-- upvalues: (ref) v_u_337, (ref) v_u_338, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) p_u_328, (copy) p_u_329, (ref) v_u_340, (ref) v_u_339, (copy) v_u_350, (ref) v_u_336, (ref) v_u_3, (copy) v_u_335, (copy) v_u_376, (ref) v_u_477
		v_u_337 = nil
		v_u_338 = false
		v_u_330.keepScroll(v_u_354, v_u_377)
		local v_u_485 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_337, (ref) p_u_328, (copy) v_u_485, (ref) v_u_338, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_350, (ref) v_u_336, (ref) v_u_3, (ref) v_u_335, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376, (ref) v_u_477
			v_u_337 = p_u_328.fetch("tasks", nil, v_u_485 and 0 or 15)
			v_u_338 = true
			if p_u_329.Parent then
				local v486 = false
				local v487 = p_u_328.focusTask
				if type(v487) == "string" and (v_u_340 and v_u_339 ~= "tasks") then
					v_u_339 = "tasks"
					v_u_350.select("tasks", true)
				end
				local v488 = p_u_328.focusTask
				if type(v488) == "string" then
					local v489 = v_u_337
					if type(v489) == "table" then
						local v490 = v_u_337.tasks
						if type(v490) == "table" and v_u_337.tasks[p_u_328.focusTask] then
							v_u_336 = p_u_328.focusTask
							p_u_328.focusTask = nil
							v486 = true
						end
					end
				end
				if not v_u_336 then
					local v491 = v_u_337
					if type(v491) == "table" then
						local v492 = v_u_337.tasks
						if type(v492) == "table" then
							local v493 = 99
							local v494 = nil
							for _, v495 in v_u_337.order or {} do
								local v496 = v_u_3[(v_u_337.tasks[v495] or {}).state or "locked"] or 9
								if v496 >= v493 then
									continue
								end
								v494 = v495
								v493 = v496
							end
							v_u_336 = v494
						end
					end
				end
				if v_u_340 and v_u_339 == "cutscenes" then
					v_u_335.loadCutscenes(v_u_485)
				else
					v_u_330.keepScroll(v_u_354, v_u_377)
					v_u_376()
				end
				if v486 then
					v_u_477 = v_u_477 + 1
					local v_u_497 = v_u_477
					local v_u_498 = v_u_336
					task.spawn(function()
						-- upvalues: (copy) v_u_497, (ref) v_u_477, (ref) v_u_336, (copy) v_u_498, (ref) v_u_354, (ref) v_u_330
						local v499 = game:GetService("RunService")
						for _ = 1, 45 do
							v499.Heartbeat:Wait()
							if v_u_497 ~= v_u_477 or (v_u_336 ~= v_u_498 or not v_u_354.Parent) then
								return
							end
							local v500 = v_u_498
							if v500 then
								v500 = v_u_354:FindFirstChild(v_u_498)
							end
							if not v500 or (not v500:IsA("GuiObject") or v_u_354.AbsoluteWindowSize.Y <= 1) then
								continue
							end
							local v501 = v500.AbsolutePosition.Y - v_u_354.AbsolutePosition.Y + v_u_354.CanvasPosition.Y
							local v502 = (v_u_354.AbsoluteWindowSize.Y - v500.AbsoluteSize.Y) / 2
							local v503 = v501 - math.floor(v502)
							local v504 = math.max(0, v503)
							local v505
							if v500.AbsolutePosition.Y >= v_u_354.AbsolutePosition.Y - 1 then
								v505 = v500.AbsolutePosition.Y + v500.AbsoluteSize.Y <= v_u_354.AbsolutePosition.Y + v_u_354.AbsoluteWindowSize.Y + 1
							else
								v505 = false
							end
							if v505 then
								if v_u_330.device and v_u_330.device() == "Gamepad" then
									local v506 = game:GetService("GuiService")
									if v506.SelectedObject ~= v500 then
										v506.SelectedObject = v500
									end
								end
							end
							v_u_354.CanvasPosition = Vector2.new(0, v504)
						end
					end)
				end
			end
		end)
	end
	if game:GetService("RunService"):IsStudio() then
		local function v512()
			-- upvalues: (copy) p_u_328, (copy) p_u_329, (ref) v_u_337, (ref) v_u_336, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_333, (copy) v_u_355, (ref) v_u_1, (ref) v_u_360
			local v_u_507 = p_u_328.cctx.player
			v_u_507:GetAttributeChangedSignal("DevTaskPick"):Connect(function()
				-- upvalues: (copy) v_u_507, (ref) p_u_329, (ref) v_u_337, (ref) v_u_336, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_333, (ref) v_u_355, (ref) v_u_1, (ref) p_u_328, (ref) v_u_360
				local v508 = v_u_507:GetAttribute("DevTaskPick")
				if type(v508) == "string" and (v508 ~= "" and p_u_329.Parent) then
					v_u_507:SetAttribute("DevTaskPick", nil)
					local v509 = v_u_337
					if type(v509) == "table" then
						local v510 = v_u_337.tasks
						if type(v510) == "table" and v_u_337.tasks[v508] then
							v_u_336 = v508
							v_u_330.keepScroll(v_u_354, v_u_377)
							local function v511() -- name: rebuild
								-- upvalues: (ref) v_u_333, (ref) v_u_355, (ref) v_u_336, (ref) v_u_1, (ref) p_u_328, (ref) v_u_337
								v_u_333.clear(v_u_355)
								if v_u_336 then
									v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
								else
									v_u_333.empty(v_u_355, "Select a task.")
								end
							end
							if v_u_336 == nil or v_u_336 ~= v_u_360 then
								v_u_333.clear(v_u_355)
								if v_u_336 then
									v_u_1.detail(p_u_328, v_u_355, v_u_336, v_u_337)
								else
									v_u_333.empty(v_u_355, "Select a task.")
								end
							else
								v_u_330.keepScroll(v_u_355, v511)
							end
							v_u_360 = v_u_336
						end
					end
				end
			end)
		end
		pcall(v512)
	end
	if game:GetService("RunService"):IsStudio() then
		local function v528()
			-- upvalues: (copy) v_u_341, (ref) v_u_340, (ref) v_u_339, (ref) v_u_336, (copy) p_u_328, (ref) v_u_347
			local function v_u_518() -- name: describe
				-- upvalues: (ref) v_u_341, (ref) v_u_340, (ref) v_u_339, (ref) v_u_336
				local v513 = {}
				for _, v514 in not v_u_341.view and {} or v_u_341.view.rows do
					local v515 = v514.id .. (v514.unlocked and ":open" or ":locked")
					table.insert(v513, v515)
				end
				local v516 = v_u_340
				local v517 = v_u_336
				return ("bar=%s current=%s selected=%s cutscenes=%s"):format(tostring(v516), v_u_339, tostring(v517), table.concat(v513, ","))
			end
			p_u_328.cctx.command("tasks.tab", function(p519)
				-- upvalues: (ref) v_u_347, (copy) v_u_518
				if p519[1] then
					v_u_347(p519[1])
				end
				return v_u_518()
			end)
			p_u_328.cctx.command("tasks.open", function(p520)
				-- upvalues: (ref) p_u_328, (copy) v_u_518
				if p_u_328.openTask then
					p_u_328.openTask(p520[1])
				end
				return v_u_518()
			end)
			p_u_328.cctx.command("cutscenes.play", function(p521)
				-- upvalues: (ref) v_u_341, (ref) p_u_328
				for _, v522 in not v_u_341.view and {} or v_u_341.view.rows do
					if v522.id ~= p521[1] then
						continue
					end
					local function v523()
						-- upvalues: (ref) p_u_328
						return p_u_328.cctx.lib.MenuCutscenes
					end
					local v524, v525 = pcall(v523)
					if not v524 or type(v525) ~= "table" then
						v525 = nil
					end
					local v526, v527 = v525.play(p_u_328, v522)
					return v526 and "started" or "refused: " .. tostring(v527)
				end
				return "no such row (open the CUTSCENES tab first)"
			end)
		end
		pcall(v528)
	end
	pcall(function()
		-- upvalues: (copy) p_u_328, (copy) p_u_329, (copy) v_u_359, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_376, (copy) v_u_342
		local v529 = p_u_328.cctx.config.watchFlag("StoryScenes", function()
			-- upvalues: (ref) p_u_329, (ref) v_u_359, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376
			if p_u_329.Parent then
				v_u_359()
				v_u_330.keepScroll(v_u_354, v_u_377)
				v_u_376()
			end
		end)
		if v529 then
			local v530 = v_u_342
			table.insert(v530, v529)
		end
	end)
	pcall(function()
		-- upvalues: (copy) p_u_328, (copy) v_u_342, (copy) p_u_329, (ref) v_u_340, (ref) v_u_339, (copy) v_u_335
		local v531 = v_u_342
		local v532 = p_u_328.cctx.player:GetAttributeChangedSignal("StoryStage")
		local function v533()
			-- upvalues: (ref) p_u_328, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_335
			p_u_328.invalidate("cutscenes")
			if p_u_329.Parent and (v_u_340 and v_u_339 == "cutscenes") then
				v_u_335.loadCutscenes(true)
			end
		end
		table.insert(v531, v532:Connect(v533))
	end)
	function v_u_335.show() -- name: show
		-- upvalues: (copy) v_u_359, (ref) v_u_337, (copy) p_u_328, (ref) v_u_338, (copy) p_u_329, (ref) v_u_340, (ref) v_u_339, (copy) v_u_350, (ref) v_u_336, (ref) v_u_3, (copy) v_u_335, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_376, (ref) v_u_477
		v_u_359()
		local v_u_534 = false
		task.spawn(function()
			-- upvalues: (ref) v_u_337, (ref) p_u_328, (copy) v_u_534, (ref) v_u_338, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_350, (ref) v_u_336, (ref) v_u_3, (ref) v_u_335, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376, (ref) v_u_477
			v_u_337 = p_u_328.fetch("tasks", nil, v_u_534 and 0 or 15)
			v_u_338 = true
			if p_u_329.Parent then
				local v535 = false
				local v536 = p_u_328.focusTask
				if type(v536) == "string" and (v_u_340 and v_u_339 ~= "tasks") then
					v_u_339 = "tasks"
					v_u_350.select("tasks", true)
				end
				local v537 = p_u_328.focusTask
				if type(v537) == "string" then
					local v538 = v_u_337
					if type(v538) == "table" then
						local v539 = v_u_337.tasks
						if type(v539) == "table" and v_u_337.tasks[p_u_328.focusTask] then
							v_u_336 = p_u_328.focusTask
							p_u_328.focusTask = nil
							v535 = true
						end
					end
				end
				if not v_u_336 then
					local v540 = v_u_337
					if type(v540) == "table" then
						local v541 = v_u_337.tasks
						if type(v541) == "table" then
							local v542 = 99
							local v543 = nil
							for _, v544 in v_u_337.order or {} do
								local v545 = v_u_3[(v_u_337.tasks[v544] or {}).state or "locked"] or 9
								if v545 >= v542 then
									continue
								end
								v543 = v544
								v542 = v545
							end
							v_u_336 = v543
						end
					end
				end
				if v_u_340 and v_u_339 == "cutscenes" then
					v_u_335.loadCutscenes(v_u_534)
				else
					v_u_330.keepScroll(v_u_354, v_u_377)
					v_u_376()
				end
				if v535 then
					v_u_477 = v_u_477 + 1
					local v_u_546 = v_u_477
					local v_u_547 = v_u_336
					task.spawn(function()
						-- upvalues: (copy) v_u_546, (ref) v_u_477, (ref) v_u_336, (copy) v_u_547, (ref) v_u_354, (ref) v_u_330
						local v548 = game:GetService("RunService")
						for _ = 1, 45 do
							v548.Heartbeat:Wait()
							if v_u_546 ~= v_u_477 or (v_u_336 ~= v_u_547 or not v_u_354.Parent) then
								return
							end
							local v549 = v_u_547
							if v549 then
								v549 = v_u_354:FindFirstChild(v_u_547)
							end
							if not v549 or (not v549:IsA("GuiObject") or v_u_354.AbsoluteWindowSize.Y <= 1) then
								continue
							end
							local v550 = v549.AbsolutePosition.Y - v_u_354.AbsolutePosition.Y + v_u_354.CanvasPosition.Y
							local v551 = (v_u_354.AbsoluteWindowSize.Y - v549.AbsoluteSize.Y) / 2
							local v552 = v550 - math.floor(v551)
							local v553 = math.max(0, v552)
							local v554
							if v549.AbsolutePosition.Y >= v_u_354.AbsolutePosition.Y - 1 then
								v554 = v549.AbsolutePosition.Y + v549.AbsoluteSize.Y <= v_u_354.AbsolutePosition.Y + v_u_354.AbsoluteWindowSize.Y + 1
							else
								v554 = false
							end
							if v554 then
								if v_u_330.device and v_u_330.device() == "Gamepad" then
									local v555 = game:GetService("GuiService")
									if v555.SelectedObject ~= v549 then
										v555.SelectedObject = v549
									end
								end
							end
							v_u_354.CanvasPosition = Vector2.new(0, v553)
						end
					end)
				end
			end
		end)
	end
	function v_u_335.hide() -- name: hide end
	function v_u_335.refresh(p556, p557) -- name: refresh
		-- upvalues: (ref) v_u_337, (copy) p_u_328, (ref) v_u_338, (copy) p_u_329, (ref) v_u_340, (ref) v_u_339, (copy) v_u_350, (ref) v_u_336, (ref) v_u_3, (copy) v_u_335, (copy) v_u_330, (copy) v_u_354, (ref) v_u_377, (copy) v_u_376, (ref) v_u_477
		if p556 == "profile" then
			local v_u_558 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_337, (ref) p_u_328, (copy) v_u_558, (ref) v_u_338, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_350, (ref) v_u_336, (ref) v_u_3, (ref) v_u_335, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376, (ref) v_u_477
				v_u_337 = p_u_328.fetch("tasks", nil, v_u_558 and 0 or 15)
				v_u_338 = true
				if p_u_329.Parent then
					local v559 = false
					local v560 = p_u_328.focusTask
					if type(v560) == "string" and (v_u_340 and v_u_339 ~= "tasks") then
						v_u_339 = "tasks"
						v_u_350.select("tasks", true)
					end
					local v561 = p_u_328.focusTask
					if type(v561) == "string" then
						local v562 = v_u_337
						if type(v562) == "table" then
							local v563 = v_u_337.tasks
							if type(v563) == "table" and v_u_337.tasks[p_u_328.focusTask] then
								v_u_336 = p_u_328.focusTask
								p_u_328.focusTask = nil
								v559 = true
							end
						end
					end
					if not v_u_336 then
						local v564 = v_u_337
						if type(v564) == "table" then
							local v565 = v_u_337.tasks
							if type(v565) == "table" then
								local v566 = 99
								local v567 = nil
								for _, v568 in v_u_337.order or {} do
									local v569 = v_u_3[(v_u_337.tasks[v568] or {}).state or "locked"] or 9
									if v569 >= v566 then
										continue
									end
									v567 = v568
									v566 = v569
								end
								v_u_336 = v567
							end
						end
					end
					if v_u_340 and v_u_339 == "cutscenes" then
						v_u_335.loadCutscenes(v_u_558)
					else
						v_u_330.keepScroll(v_u_354, v_u_377)
						v_u_376()
					end
					if v559 then
						v_u_477 = v_u_477 + 1
						local v_u_570 = v_u_477
						local v_u_571 = v_u_336
						task.spawn(function()
							-- upvalues: (copy) v_u_570, (ref) v_u_477, (ref) v_u_336, (copy) v_u_571, (ref) v_u_354, (ref) v_u_330
							local v572 = game:GetService("RunService")
							for _ = 1, 45 do
								v572.Heartbeat:Wait()
								if v_u_570 ~= v_u_477 or (v_u_336 ~= v_u_571 or not v_u_354.Parent) then
									return
								end
								local v573 = v_u_571
								if v573 then
									v573 = v_u_354:FindFirstChild(v_u_571)
								end
								if not v573 or (not v573:IsA("GuiObject") or v_u_354.AbsoluteWindowSize.Y <= 1) then
									continue
								end
								local v574 = v573.AbsolutePosition.Y - v_u_354.AbsolutePosition.Y + v_u_354.CanvasPosition.Y
								local v575 = (v_u_354.AbsoluteWindowSize.Y - v573.AbsoluteSize.Y) / 2
								local v576 = v574 - math.floor(v575)
								local v577 = math.max(0, v576)
								local v578
								if v573.AbsolutePosition.Y >= v_u_354.AbsolutePosition.Y - 1 then
									v578 = v573.AbsolutePosition.Y + v573.AbsoluteSize.Y <= v_u_354.AbsolutePosition.Y + v_u_354.AbsoluteWindowSize.Y + 1
								else
									v578 = false
								end
								if v578 then
									if v_u_330.device and v_u_330.device() == "Gamepad" then
										local v579 = game:GetService("GuiService")
										if v579.SelectedObject ~= v573 then
											v579.SelectedObject = v573
										end
									end
								end
								v_u_354.CanvasPosition = Vector2.new(0, v577)
							end
						end)
					end
				end
			end)
			return
		elseif p556 == "focus" then
			local v_u_580 = false
			task.spawn(function()
				-- upvalues: (ref) v_u_337, (ref) p_u_328, (copy) v_u_580, (ref) v_u_338, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_350, (ref) v_u_336, (ref) v_u_3, (ref) v_u_335, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376, (ref) v_u_477
				v_u_337 = p_u_328.fetch("tasks", nil, v_u_580 and 0 or 15)
				v_u_338 = true
				if p_u_329.Parent then
					local v581 = false
					local v582 = p_u_328.focusTask
					if type(v582) == "string" and (v_u_340 and v_u_339 ~= "tasks") then
						v_u_339 = "tasks"
						v_u_350.select("tasks", true)
					end
					local v583 = p_u_328.focusTask
					if type(v583) == "string" then
						local v584 = v_u_337
						if type(v584) == "table" then
							local v585 = v_u_337.tasks
							if type(v585) == "table" and v_u_337.tasks[p_u_328.focusTask] then
								v_u_336 = p_u_328.focusTask
								p_u_328.focusTask = nil
								v581 = true
							end
						end
					end
					if not v_u_336 then
						local v586 = v_u_337
						if type(v586) == "table" then
							local v587 = v_u_337.tasks
							if type(v587) == "table" then
								local v588 = 99
								local v589 = nil
								for _, v590 in v_u_337.order or {} do
									local v591 = v_u_3[(v_u_337.tasks[v590] or {}).state or "locked"] or 9
									if v591 >= v588 then
										continue
									end
									v589 = v590
									v588 = v591
								end
								v_u_336 = v589
							end
						end
					end
					if v_u_340 and v_u_339 == "cutscenes" then
						v_u_335.loadCutscenes(v_u_580)
					else
						v_u_330.keepScroll(v_u_354, v_u_377)
						v_u_376()
					end
					if v581 then
						v_u_477 = v_u_477 + 1
						local v_u_592 = v_u_477
						local v_u_593 = v_u_336
						task.spawn(function()
							-- upvalues: (copy) v_u_592, (ref) v_u_477, (ref) v_u_336, (copy) v_u_593, (ref) v_u_354, (ref) v_u_330
							local v594 = game:GetService("RunService")
							for _ = 1, 45 do
								v594.Heartbeat:Wait()
								if v_u_592 ~= v_u_477 or (v_u_336 ~= v_u_593 or not v_u_354.Parent) then
									return
								end
								local v595 = v_u_593
								if v595 then
									v595 = v_u_354:FindFirstChild(v_u_593)
								end
								if not v595 or (not v595:IsA("GuiObject") or v_u_354.AbsoluteWindowSize.Y <= 1) then
									continue
								end
								local v596 = v595.AbsolutePosition.Y - v_u_354.AbsolutePosition.Y + v_u_354.CanvasPosition.Y
								local v597 = (v_u_354.AbsoluteWindowSize.Y - v595.AbsoluteSize.Y) / 2
								local v598 = v596 - math.floor(v597)
								local v599 = math.max(0, v598)
								local v600
								if v595.AbsolutePosition.Y >= v_u_354.AbsolutePosition.Y - 1 then
									v600 = v595.AbsolutePosition.Y + v595.AbsoluteSize.Y <= v_u_354.AbsolutePosition.Y + v_u_354.AbsoluteWindowSize.Y + 1
								else
									v600 = false
								end
								if v600 then
									if v_u_330.device and v_u_330.device() == "Gamepad" then
										local v601 = game:GetService("GuiService")
										if v601.SelectedObject ~= v595 then
											v601.SelectedObject = v595
										end
									end
								end
								v_u_354.CanvasPosition = Vector2.new(0, v599)
							end
						end)
					end
				end
			end)
		elseif p556 == "result" and (type(p557) == "table" and (p557.op == "taskAccept" or p557.op == "taskHandIn")) then
			p_u_328.invalidate("tasks")
			p_u_328.invalidate("cutscenes")
			local v_u_602 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_337, (ref) p_u_328, (copy) v_u_602, (ref) v_u_338, (ref) p_u_329, (ref) v_u_340, (ref) v_u_339, (ref) v_u_350, (ref) v_u_336, (ref) v_u_3, (ref) v_u_335, (ref) v_u_330, (ref) v_u_354, (ref) v_u_377, (ref) v_u_376, (ref) v_u_477
				v_u_337 = p_u_328.fetch("tasks", nil, v_u_602 and 0 or 15)
				v_u_338 = true
				if p_u_329.Parent then
					local v603 = false
					local v604 = p_u_328.focusTask
					if type(v604) == "string" and (v_u_340 and v_u_339 ~= "tasks") then
						v_u_339 = "tasks"
						v_u_350.select("tasks", true)
					end
					local v605 = p_u_328.focusTask
					if type(v605) == "string" then
						local v606 = v_u_337
						if type(v606) == "table" then
							local v607 = v_u_337.tasks
							if type(v607) == "table" and v_u_337.tasks[p_u_328.focusTask] then
								v_u_336 = p_u_328.focusTask
								p_u_328.focusTask = nil
								v603 = true
							end
						end
					end
					if not v_u_336 then
						local v608 = v_u_337
						if type(v608) == "table" then
							local v609 = v_u_337.tasks
							if type(v609) == "table" then
								local v610 = 99
								local v611 = nil
								for _, v612 in v_u_337.order or {} do
									local v613 = v_u_3[(v_u_337.tasks[v612] or {}).state or "locked"] or 9
									if v613 >= v610 then
										continue
									end
									v611 = v612
									v610 = v613
								end
								v_u_336 = v611
							end
						end
					end
					if v_u_340 and v_u_339 == "cutscenes" then
						v_u_335.loadCutscenes(v_u_602)
					else
						v_u_330.keepScroll(v_u_354, v_u_377)
						v_u_376()
					end
					if v603 then
						v_u_477 = v_u_477 + 1
						local v_u_614 = v_u_477
						local v_u_615 = v_u_336
						task.spawn(function()
							-- upvalues: (copy) v_u_614, (ref) v_u_477, (ref) v_u_336, (copy) v_u_615, (ref) v_u_354, (ref) v_u_330
							local v616 = game:GetService("RunService")
							for _ = 1, 45 do
								v616.Heartbeat:Wait()
								if v_u_614 ~= v_u_477 or (v_u_336 ~= v_u_615 or not v_u_354.Parent) then
									return
								end
								local v617 = v_u_615
								if v617 then
									v617 = v_u_354:FindFirstChild(v_u_615)
								end
								if not v617 or (not v617:IsA("GuiObject") or v_u_354.AbsoluteWindowSize.Y <= 1) then
									continue
								end
								local v618 = v617.AbsolutePosition.Y - v_u_354.AbsolutePosition.Y + v_u_354.CanvasPosition.Y
								local v619 = (v_u_354.AbsoluteWindowSize.Y - v617.AbsoluteSize.Y) / 2
								local v620 = v618 - math.floor(v619)
								local v621 = math.max(0, v620)
								local v622
								if v617.AbsolutePosition.Y >= v_u_354.AbsolutePosition.Y - 1 then
									v622 = v617.AbsolutePosition.Y + v617.AbsoluteSize.Y <= v_u_354.AbsolutePosition.Y + v_u_354.AbsoluteWindowSize.Y + 1
								else
									v622 = false
								end
								if v622 then
									if v_u_330.device and v_u_330.device() == "Gamepad" then
										local v623 = game:GetService("GuiService")
										if v623.SelectedObject ~= v617 then
											v623.SelectedObject = v617
										end
									end
								end
								v_u_354.CanvasPosition = Vector2.new(0, v621)
							end
						end)
					end
				end
			end)
		end
	end
	function v_u_335.destroy() -- name: destroy
		-- upvalues: (copy) v_u_342
		for _, v624 in v_u_342 do
			v624:Disconnect()
		end
		table.clear(v_u_342)
	end
	function v_u_335.state() -- name: state
		-- upvalues: (ref) v_u_340, (ref) v_u_339, (copy) v_u_341
		return {
			["shown"] = v_u_340,
			["current"] = v_u_339,
			["cutscenes"] = v_u_341.view
		}
	end
	v_u_333.empty(v_u_354, "Loading tasks...")
	return v_u_335
end
return v_u_1