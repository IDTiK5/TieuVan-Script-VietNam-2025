-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / LiveCopyNote

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = {
	["name"] = "LiveCopyNote",
	["order"] = 94
}
local v_u_6 = nil
local v_u_7 = v3.LocalPlayer
function v_u_5.lineFor(p8, p9) -- name: lineFor
	return p8 == "copying" and p9 < 120 and "Copying your live save ..." or nil
end
function v_u_5.toastFor(p10) -- name: toastFor
	if type(p10) ~= "string" then
		return nil, nil, nil, nil
	end
	if p10 == "done" then
		return "Live save copied", "success", "Your progress here is a copy of your live save.", 6
	end
	if p10 == "none" then
		return "No live save found", "info", "You play on a new test save.", 6
	end
	if string.sub(p10, 1, 7) ~= "failed:" then
		return nil, nil, nil, nil
	end
	local v11 = string.gsub(string.sub(p10, 8), "^%s+", "")
	return "Could not copy your live save", "warn", ("%s. You play on a test save."):format(v11 == "" and "Unknown reason" or v11), 12
end
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = ""
local v_u_15 = nil
local v_u_16 = 0
local v_u_17 = 0
local function v_u_24() -- name: build
	-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_12
	local v18 = v_u_6.lib.HushUI
	local v19 = v18.Theme
	local v20 = v19.color
	local v21, v22 = v18.screen("HushLiveCopy", v19.layer.loading + 1, {
		["insets"] = "None"
	})
	v21.Enabled = false
	local v23 = v18.new("Frame", {
		["Name"] = "Pill",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 22),
		["Size"] = UDim2.fromOffset(0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.XY,
		["BackgroundColor3"] = v20.bg
	}, v22)
	v18.stroke(v23, v20.line)
	v18.pad(v23, {
		16,
		16,
		8,
		8
	})
	v_u_13 = v18.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoX"] = true,
		["autoY"] = true,
		["maxSize"] = nil,
		["parent"] = v23,
		["color"] = v20.text2,
		["size"] = UDim2.fromOffset(0, 0),
		["maxSize"] = Vector2.new(780, (1 / 0))
	})
	v_u_12 = v21
end
local function v_u_38() -- name: render
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) v_u_7, (copy) v_u_2, (ref) v_u_15, (copy) v_u_5, (ref) v_u_14, (ref) v_u_6, (ref) v_u_16, (ref) v_u_17
	if v_u_12 and v_u_13 then
		local v25 = v_u_7:GetAttribute("LiveCopyStatus")
		local v26 = v_u_7:GetAttribute("LiveCopyAt")
		local v27
		if type(v26) == "number" then
			local v28 = v_u_2.now() - v26
			v27 = math.max(0, v28)
		else
			v27 = 0
		end
		local v29
		if v_u_15 and os.clock() < v_u_15.untilT then
			v29 = v_u_15.text
		else
			v_u_15 = nil
			v29 = v_u_5.lineFor(v25, v27)
		end
		local v30 = v29 or ""
		if v30 ~= v_u_14 then
			v_u_14 = v30
			v_u_6.lib.HushUI.setText(v_u_13, v30)
			v_u_7:SetAttribute("LiveCopyNoteText", v30)
		end
		v_u_12.Enabled = v30 ~= ""
		if type(v26) == "number" and (v26 ~= v_u_16 and (v27 < 120 and v25 ~= "copying")) then
			local v31 = v_u_7:FindFirstChildOfClass("PlayerGui")
			local v32
			if v31 == nil then
				v32 = false
			else
				v32 = v31:FindFirstChild("HushLoading") ~= nil
			end
			if not v32 then
				v_u_16 = v26
				local v33, v34, v35, v36 = v_u_5.toastFor(v25)
				if not v33 then
					return
				end
				v_u_17 = v_u_17 + 1
				v_u_7:SetAttribute("LiveCopyNoteToasts", v_u_17)
				local v37 = v_u_6.lib.HushUI.toast
				pcall(v37, v33, v34, v35, v36)
			end
		end
	end
end
function v_u_5.init(p39) -- name: init
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (ref) v_u_15, (copy) v_u_38, (copy) v_u_5, (ref) v_u_17, (copy) v_u_7, (ref) v_u_14, (ref) v_u_12
	v_u_6 = p39
	if p39.config.IS_TEST == true then
		p39.command("livecopynote.show", function(p40)
			-- upvalues: (ref) v_u_4, (ref) v_u_15, (ref) v_u_38, (ref) v_u_5, (ref) v_u_17, (ref) v_u_7, (ref) v_u_6
			if not v_u_4:IsStudio() then
				return "Studio only"
			end
			local v41 = table.concat(p40, " ")
			if v41 == "copying" then
				v_u_15 = {
					["text"] = "Copying your live save ...",
					["untilT"] = nil,
					["untilT"] = os.clock() + 60
				}
				v_u_38()
				return "preview line"
			end
			v_u_15 = nil
			local v42 = v_u_5.toastFor(v41)
			if not v42 then
				v_u_38()
				return "preview off"
			end
			local v43, v44, v45, v46 = v_u_5.toastFor(v41)
			if v43 then
				v_u_17 = v_u_17 + 1
				v_u_7:SetAttribute("LiveCopyNoteToasts", v_u_17)
				local v47 = v_u_6.lib.HushUI.toast
				pcall(v47, v43, v44, v45, v46)
			end
			v_u_38()
			return "toast: " .. v42
		end)
		p39.command("livecopynote.state", function()
			-- upvalues: (ref) v_u_14, (ref) v_u_12, (ref) v_u_7, (ref) v_u_17
			local v48 = "line=%q enabled=%s status=%s toasts=%d card=%s"
			local v49 = v_u_14
			local v50 = v_u_12
			if v50 then
				v50 = v_u_12.Enabled
			end
			local v51 = tostring(v50)
			local v52 = v_u_7
			local v53 = tostring(v52:GetAttribute("LiveCopyStatus"))
			local v54 = v_u_17
			local v55 = v_u_7:FindFirstChildOfClass("PlayerGui")
			local v56
			if v55 == nil then
				v56 = false
			else
				v56 = v55:FindFirstChild("HushLoading") ~= nil
			end
			return v48:format(v49, v51, v53, v54, (tostring(v56)))
		end)
	end
end
function v_u_5.start() -- name: start
	-- upvalues: (ref) v_u_6, (copy) v_u_24, (copy) v_u_7, (copy) v_u_38
	if v_u_6.config.IS_TEST == true then
		v_u_6.lib.HushUI.bind(v_u_6)
		local v57 = v_u_24
		local v58, v59 = pcall(v57)
		if v58 then
			v_u_7:GetAttributeChangedSignal("LiveCopyStatus"):Connect(v_u_38)
			v_u_7:GetAttributeChangedSignal("LiveCopyAt"):Connect(v_u_38)
			v_u_38()
			task.spawn(function()
				-- upvalues: (ref) v_u_38
				while true do
					task.wait(0.5)
					v_u_38()
				end
			end)
		else
			warn("[LiveCopyNote] build failed:", v59)
			v_u_7:SetAttribute("ClientError", "LiveCopyNote: " .. tostring(v59))
		end
	else
		return
	end
end
return v_u_5