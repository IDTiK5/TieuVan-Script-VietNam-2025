-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStore

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("MarketplaceService")
local v_u_3 = {}
local v_u_4 = nil
local v_u_5 = utf8.char(57346)
local v_u_6 = {
	{
		["id"] = "all",
		["text"] = "All"
	},
	{
		["id"] = "SALE",
		["text"] = "Sale"
	},
	{
		["id"] = "PASSES",
		["text"] = "Passes"
	},
	{
		["id"] = "KITS",
		["text"] = "Kits"
	},
	{
		["id"] = "CASH",
		["text"] = "Cash"
	},
	{
		["id"] = "HIDEOUT",
		["text"] = "Hideout"
	},
	{
		["id"] = "GUARD",
		["text"] = "Guard"
	},
	{
		["id"] = "CRATES",
		["text"] = "Keys"
	},
	{
		["id"] = "SEASON",
		["text"] = "Season"
	},
	{
		["id"] = "COSMETICS",
		["text"] = "Styles"
	},
	{
		["id"] = "CLAN",
		["text"] = "Clan"
	},
	{
		["id"] = "UNLOCK",
		["text"] = "Unlock"
	},
	{
		["id"] = "DONATE",
		["text"] = "Donate"
	}
}
v_u_3.LOAD_FAILED = "The store could not be loaded. Close the menu and open it again."
v_u_3.OFF_SALE = "Not on sale right now"
v_u_3.OFF_SALE_FINE = "This item is not for sale at the moment."
v_u_3.OVER_LIMIT = "Over the limit"
v_u_3.UNLOCK_FULL = "Everything unlocked"
function v_u_3.packArt(p7, p8, p9) -- name: packArt
	if type(p7) == "table" then
		local v10 = p7.IMAGES
		if type(v10) == "table" and (type(p8) == "table" and p8.art == "crimson_pack") then
			if p9 == true then
				local v11 = p8.id == p7.TWIN_ID
				local v12
				if v11 then
					v12 = p7.IMAGES.iconTwin
				else
					v12 = p7.IMAGES.iconMain
				end
				if type(v12) == "string" and v12 ~= "" then
					return {
						["image"] = v12,
						["source"] = v11 and "art/r39_store_pack/banner/product_icon_pack_crimson_r.png" or "art/r39_store_pack/banner/product_icon_pack_crimson.png"
					}
				end
			end
			return {
				["image"] = nil,
				["source"] = "art/r39_store_pack/banner/card_crimson_pack.png",
				["image"] = p7.IMAGES.card
			}
		end
	end
	return nil
end
v_u_3.HEAD_PLAIN = "Every Robux goes back into HUSH. No loot boxes, no random paid items."
v_u_3.HEAD_KEYS = "Keys only. Cases are not sold here: get them on the Market or find them in raids. Every chance is listed."
v_u_3.HEAD_KEYS_PACK = "Keys only, plus the five cases in the %s. Other cases come from the Market or from raids. Every chance is listed."
function v_u_3.headLine(p13) -- name: headLine
	-- upvalues: (copy) v_u_3
	local v14 = false
	local v15 = nil
	if type(p13) == "table" then
		local v16 = p13.products
		if type(v16) == "table" then
			for _, v17 in p13.products do
				if type(v17) ~= "table" or v17.random ~= true then
					continue
				end
				v14 = true
				if v17.pack == nil then
					continue
				end
				local v18 = v17.name
				if type(v18) ~= "string" or v17.name == "" then
					continue
				end
				v15 = v17.name
			end
		end
	end
	if not v14 then
		return v_u_3.HEAD_PLAIN
	end
	if v15 == nil then
		return v_u_3.HEAD_KEYS
	end
	local v21 = string.gsub(string.lower(v15), "(%a)(%a*)", function(p19, p20)
		return string.upper(p19) .. p20
	end)
	return v_u_3.HEAD_KEYS_PACK:format(v21)
end
v_u_3.CASH_MIN_W = 236
function v_u_3.overLimitText(p22, p23) -- name: overLimitText
	local v24 = tonumber(p22) or 0
	local v25 = math.floor(v24)
	local v26 = math.max(0, v25)
	local v27 = tonumber(p23) or 99
	local v28 = math.floor(v27)
	return ("You hold %d of %d extra charges. This pack would take you over the limit."):format(v26, (math.max(1, v28)))
end
local v_u_29 = {
	["pass_stash"] = "rbxassetid://133729576259713",
	["pass_vip"] = "rbxassetid://120611477419915",
	["pass_insurance"] = "rbxassetid://131819904683585",
	["cash_s"] = "rbxassetid://79144862322825",
	["cash_m"] = "rbxassetid://77888548860885",
	["cash_l"] = "rbxassetid://138620577086165",
	["cash_xl"] = "rbxassetid://138620577086165",
	["hideout_rush"] = "rbxassetid://139569627627666",
	["guard_s"] = "rbxassetid://135013325221135",
	["guard_m"] = "rbxassetid://116219160498602",
	["guard_l"] = "rbxassetid://111064985535063",
	["pass_fixer"] = "rbxassetid://117323250334112",
	["season_premium"] = "rbxassetid://103244860474096",
	["season_skip_1"] = "rbxassetid://128371232623428",
	["season_skip_5"] = "rbxassetid://78694235143049",
	["season_skip_10"] = "rbxassetid://79635975094628",
	["pass_clan"] = "rbxassetid://124276398954201",
	["kc_tier_1"] = "rbxassetid://135686383154586",
	["kc_tier_2"] = "rbxassetid://124196880291438",
	["kc_tier_3"] = "rbxassetid://76421662427098",
	["kc_tier_4"] = "rbxassetid://78649069049574"
}
local v_u_30 = {}
local function v_u_37(p_u_31, p32) -- name: getInfo
	-- upvalues: (copy) v_u_2
	local v_u_33
	if p32 == "pass" then
		v_u_33 = Enum.InfoType.GamePass
	else
		v_u_33 = Enum.InfoType.Product
	end
	local function v34()
		-- upvalues: (ref) v_u_2, (copy) p_u_31, (copy) v_u_33
		return v_u_2:GetProductInfoAsync(p_u_31, v_u_33)
	end
	local v35, v36 = pcall(v34)
	if v35 then
		return v36
	else
		return v_u_2:GetProductInfo(p_u_31, v_u_33)
	end
end
function v_u_3.new(p_u_38, p_u_39) -- name: new
	-- upvalues: (ref) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_30, (copy) v_u_37, (copy) v_u_1, (copy) v_u_3, (copy) v_u_29
	local v_u_40 = p_u_38.ui
	local v_u_41 = p_u_38.theme
	local v_u_42 = v_u_41.color
	local v_u_43 = p_u_38.kit
	local v_u_44 = p_u_38.cctx
	v_u_4 = v_u_44.lib.MenuStoreLayout
	local v_u_45 = nil
	local function v46()
		-- upvalues: (ref) v_u_45, (copy) v_u_44
		v_u_45 = v_u_44.lib.UnlockChain
	end
	pcall(v46)
	local v_u_47 = v_u_44.shared.Items
	local v_u_48 = p_u_38.compact()
	local v_u_49 = v_u_41.isPhone()
	local v_u_50
	if v_u_49 then
		local v51 = v_u_41.phoneText
		v_u_50 = type(v51) ~= "function" and 13 or v_u_41.phoneText(13, "text")
	else
		v_u_50 = 13
	end
	local v_u_52 = {
		["api"] = {}
	}
	local v_u_53 = nil
	local v_u_54 = "all"
	local v_u_55 = nil
	local v_u_56 = nil
	local v_u_57 = false
	local v_u_58 = true
	local v_u_59 = {}
	local v_u_60 = {}
	local _, v61 = v_u_40.panel({
		["parent"] = nil,
		["name"] = "Store",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 16,
		["parent"] = p_u_39,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v_u_62 = v_u_40.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 62)
	}, v61)
	v_u_40.label({
		["parent"] = nil,
		["text"] = "Store",
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v_u_62,
		["size"] = UDim2.new(0.5, 0, 0, 30)
	})
	local v_u_63 = v_u_40.label({
		["parent"] = nil,
		["text"] = "Every Robux goes back into HUSH. No loot boxes, no random paid items.",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_62,
		["color"] = v_u_42.text2,
		["position"] = UDim2.fromOffset(0, 32),
		["size"] = UDim2.new(0.7, 0, 0, 28)
	})
	v_u_63.TextWrapped = true
	v_u_63.TextYAlignment = Enum.TextYAlignment.Top
	local v64 = v_u_40.new("Frame", {
		["Name"] = "Supporter",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 2),
		["Size"] = UDim2.fromOffset(330, 40)
	}, v_u_62)
	local v_u_65 = v_u_40.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v64,
		["color"] = v_u_42.text2,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(1, -30, 1, 0)
	})
	v_u_65.TextYAlignment = Enum.TextYAlignment.Center
	local v66 = v_u_40.icon("heart", {
		["size"] = 20,
		["color"] = nil,
		["color"] = v_u_42.accent
	})
	v66.AnchorPoint = Vector2.new(1, 0.5)
	v66.Position = UDim2.new(1, 0, 0.5, 0)
	v66.Parent = v64
	local v67 = v_u_41.touch(36)
	local v_u_69, v_u_70 = v_u_40.tabs({
		["parent"] = nil,
		["tabs"] = nil,
		["selected"] = "all",
		["position"] = nil,
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = v61,
		["tabs"] = v_u_6,
		["position"] = UDim2.fromOffset(0, 62),
		["size"] = UDim2.new(1, 0, 0, v67),
		["onChange"] = function(p68) -- name: onChange
			-- upvalues: (ref) v_u_54, (ref) v_u_55, (copy) v_u_52
			v_u_54 = p68
			v_u_55 = nil
			v_u_52.draw()
		end
	})
	local v_u_71 = 62 + v67 + 10
	local v_u_72 = v_u_40.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_71),
		["Size"] = UDim2.new(1, 0, 1, -v_u_71)
	}, v61)
	local v_u_73 = v_u_40.list({
		["parent"] = nil,
		["name"] = "List",
		["size"] = nil,
		["gap"] = 14,
		["padding"] = nil,
		["parent"] = v_u_72,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local v_u_74 = v_u_40.new("Frame", {
		["Name"] = "Detail",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_72)
	local v_u_75 = v_u_71
	local function v_u_83(p76) -- name: tripOf
		-- upvalues: (copy) p_u_38
		local function v77()
			-- upvalues: (ref) p_u_38
			return p_u_38.cctx.lib.CrateWindow
		end
		local v78, v79 = pcall(v77)
		if v78 and v79 then
			local v80 = v79.pending
			local v81, v82 = pcall(v80)
			if v81 and (type(v82) == "table" and (v82.kind or "key") == p76) then
				return v79, v82
			else
				return nil, nil
			end
		else
			return nil, nil
		end
	end
	local function v85(p84) -- name: priceRich
		-- upvalues: (ref) v_u_5, (copy) v_u_40
		return not p84 and "BUY" or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_5, v_u_40.commas(p84))
	end
	local function v_u_91(p86) -- name: repaintPrice
		-- upvalues: (ref) v_u_59, (ref) v_u_5, (copy) v_u_40, (ref) v_u_60
		for _, v87 in v_u_59[p86.id] or {} do
			if not v87.Parent then
				continue
			end
			local v88 = p86.price
			local v89 = tonumber(v88)
			v87.Text = not v89 and "BUY" or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_5, v_u_40.commas(v89))
		end
		for _, v90 in v_u_60[p86.id] or {} do
			pcall(v90)
		end
	end
	local v_u_92 = nil
	local v93, v94 = pcall(function()
		-- upvalues: (copy) v_u_44
		return v_u_44.lib.MenuStoreGive
	end)
	if v93 and v94 then
		local v95 = v94.new
		local v105 = {
			["clientPrice"] = function(p96, p97) -- name: clientPrice
				-- upvalues: (ref) v_u_30, (ref) v_u_37
				if p96 <= 0 then
					return nil
				end
				local v98 = tostring(p96)
				local v99 = v_u_30[v98]
				if not v99 or os.clock() - v99.t > 120 then
					local v100 = v_u_37
					local v101, v102 = pcall(v100, p96, p97)
					v99 = {}
					local v103
					if v101 and type(v102) == "table" then
						local v104 = v102.PriceInRobux
						v103 = tonumber(v104)
					else
						v103 = nil
					end
					v99.price = v103
					v99.t = os.clock()
					v_u_30[v98] = v99
				end
				return v99.price
			end,
			["priceRich"] = v85
		}
		local v106, v107 = pcall(v95, p_u_38, v105)
		if v106 then
			v_u_92 = v107
		else
			warn("[MenuStore] the gift and donate module failed to start: " .. tostring(v107))
		end
	end
	local v_u_108 = nil
	local function v_u_129(p_u_109) -- name: unlockOffer
		-- upvalues: (ref) v_u_45, (copy) p_u_38, (ref) v_u_1, (copy) v_u_44
		if v_u_45 == nil or (type(p_u_109) ~= "table" or p_u_109.art ~= "unlock") then
			return nil
		end
		local v_u_110 = v_u_45.nameFn(p_u_38)
		local v_u_111 = nil
		local function v124()
			-- upvalues: (ref) v_u_1, (ref) v_u_44, (copy) p_u_109, (ref) v_u_45, (ref) p_u_38, (ref) v_u_111, (copy) v_u_110
			local v_u_112 = nil
			local function v114()
				-- upvalues: (ref) v_u_1, (ref) v_u_112
				local v113 = v_u_1.LocalPlayer:GetAttribute("MenuPlayMap")
				if type(v113) == "string" then
					v_u_112 = string.match(v113, "deploy=(%S+)")
				end
			end
			pcall(v114)
			local v115 = v_u_112
			local v116 = v_u_44.shared.MapLadder
			local v117 = p_u_109.unlock
			if v115 ~= nil and type(v117) == "table" then
				local v118 = v117.target
				if type(v118) == "string" then
					local v119 = v117.levels
					local v120
					if type(v119) == "table" then
						v120 = v117.levels
					else
						v120 = v_u_45.levelsOf(p_u_38, v_u_1.LocalPlayer)
					end
					local v121 = v116.canon(v115)
					local v122 = v116.canon(v117.target)
					local v123
					if v121 == nil or v122 == nil then
						v123 = false
					else
						v123 = v121 == v122 and true or v116.FOLLOWS[v121] == v122
					end
					v_u_111 = {
						["name"] = v_u_110(v115),
						["here"] = v123,
						["has"] = v116.hasFromAttr(v120, v115, v117.difficulty) == true
					}
					return
				end
			end
		end
		pcall(v124)
		local v125 = v_u_45.offerFromProduct
		local v126 = v_u_111
		local v127, v128 = pcall(v125, p_u_109, v_u_110, v126)
		if not v127 then
			v128 = nil
		end
		return v128
	end
	local function v_u_134(p130, p131) -- name: unlockModel
		-- upvalues: (ref) v_u_45, (copy) p_u_38, (ref) v_u_1
		local v132, v133 = v_u_45.levelsForProduct(p130, p_u_38, v_u_1.LocalPlayer)
		if type(v132) == "table" and type(v133) == "table" then
			return v_u_45.model(v132, v133, v_u_45.nameFn(p_u_38), p131)
		else
			return nil
		end
	end
	local function v_u_158(p135, p_u_136, p137, p138, p139, p140, p141) -- name: buyControl
		-- upvalues: (copy) v_u_49, (copy) v_u_40, (ref) v_u_3, (copy) v_u_129, (ref) v_u_45, (copy) p_u_38, (copy) v_u_134, (ref) v_u_5, (ref) v_u_59, (copy) v_u_41, (copy) v_u_42
		local v142 = p137 and 52 or 40
		local v143 = p137 and 260 or ((v_u_49 or (p_u_136.rushIdle or p_u_136.unlockFull)) and 220 or 168)
		if p140 then
			if p140 >= v143 then
				p140 = v143
			end
		else
			p140 = v143
		end
		local v144 = p141 or p140
		if p_u_136.owned then
			local v145 = v_u_40.badge("OWNED", "success", {
				["parent"] = p135,
				["height"] = p137 and 30 or 22
			})
			if p138 then
				v145.Position = p138
				v145.AnchorPoint = p139 or Vector2.zero
			end
			return v145
		end
		if p_u_136.offSale then
			return v_u_40.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["disabled"] = true,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = p135,
				["text"] = v_u_3.OFF_SALE,
				["height"] = v142,
				["width"] = v144,
				["position"] = p138,
				["anchor"] = p139
			})
		end
		if not p_u_136.enabled then
			return v_u_40.button({
				["parent"] = nil,
				["text"] = "Coming soon",
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["disabled"] = true,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = p135,
				["height"] = v142,
				["width"] = v144,
				["position"] = p138,
				["anchor"] = p139
			})
		end
		if p_u_136.rushIdle then
			return v_u_40.button({
				["parent"] = nil,
				["text"] = "Nothing is being built",
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["disabled"] = true,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = p135,
				["height"] = v142,
				["width"] = v144,
				["position"] = p138,
				["anchor"] = p139
			})
		end
		if p_u_136.guardFull then
			return v_u_40.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["disabled"] = true,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = p135,
				["text"] = v_u_3.OVER_LIMIT,
				["height"] = v142,
				["width"] = v144,
				["position"] = p138,
				["anchor"] = p139
			})
		end
		if p_u_136.unlockFull then
			return v_u_40.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["disabled"] = true,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = p135,
				["text"] = v_u_3.UNLOCK_FULL,
				["height"] = v142,
				["width"] = v144,
				["position"] = p138,
				["anchor"] = p139
			})
		end
		local v147 = {
			["parent"] = nil,
			["text"] = "",
			["kind"] = "primary",
			["height"] = nil,
			["width"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = p135,
			["height"] = v142,
			["width"] = v144,
			["position"] = p138,
			["anchor"] = p139,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_129, (copy) p_u_136, (ref) v_u_45, (ref) p_u_38, (ref) v_u_134
				local v146 = v_u_129(p_u_136)
				if v146 == nil then
					p_u_38.op({
						["op"] = "storeBuy",
						["id"] = nil,
						["id"] = p_u_136.id
					})
				else
					v_u_45.confirm(p_u_38, v146, function()
						-- upvalues: (ref) p_u_38, (ref) p_u_136
						p_u_38.op({
							["op"] = "storeBuy",
							["id"] = nil,
							["id"] = p_u_136.id
						})
					end, v_u_134(p_u_136, v146))
				end
			end
		}
		local v148, v149 = v_u_40.button(v147)
		local v150 = v149.label
		v150.RichText = true
		local v151 = p_u_136.price
		local v152 = tonumber(v151)
		v150.Text = not v152 and "BUY" or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_5, v_u_40.commas(v152))
		local v153 = v_u_59[p_u_136.id]
		if not v153 then
			v153 = {}
			v_u_59[p_u_136.id] = v153
		end
		table.insert(v153, v150)
		if p_u_136.preview then
			local v154 = v_u_40.label
			local v155 = {
				["parent"] = nil,
				["text"] = "PREVIEW",
				["style"] = "micro",
				["textSize"] = nil,
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["parent"] = v148
			}
			local v156
			if v_u_49 then
				local v157 = v_u_41.phoneText
				if type(v157) == "function" then
					v156 = v_u_41.phoneText(11, "text")
				else
					v156 = nil
				end
			else
				v156 = nil
			end
			v155.textSize = v156
			v155.color = v_u_42.ink
			v155.size = UDim2.fromOffset(v_u_49 and 84 or 60, v_u_49 and 18 or 12)
			v155.position = UDim2.new(0, 4, 0, 2)
			v154(v155)
		end
		return v148
	end
	local v159, v160 = pcall(function()
		-- upvalues: (copy) v_u_44
		return v_u_44.lib.MenuStoreGuard
	end)
	if v159 and v160 then
		local v161 = v160.new
		local v171 = {
			["buy"] = function(p162, p163, p164, p165, p166) -- name: buy
				-- upvalues: (copy) v_u_158
				return v_u_158(p162, p163, false, p164, p165, nil, p166)
			end,
			["onPrice"] = function(p167, p168) -- name: onPrice
				-- upvalues: (ref) v_u_60
				local v169 = v_u_60[p167.id]
				if not v169 then
					v169 = {}
					v_u_60[p167.id] = v169
				end
				table.insert(v169, p168)
			end,
			["priceRich"] = v85,
			["icon"] = function(p170) -- name: icon
				-- upvalues: (ref) v_u_29
				return v_u_29[p170]
			end
		}
		local v172, v173 = pcall(v161, p_u_38, v171)
		if v172 then
			v_u_108 = v173
		else
			warn("[MenuStore] the Connection Guard group failed to start: " .. tostring(v173))
		end
	end
	local function v_u_185(p174, p175, p176, p177, p178, p179, p180, p181) -- name: cellGrid
		-- upvalues: (copy) v_u_40
		local v182 = v_u_40.new("Frame", {
			["Name"] = "Grid",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["Size"] = UDim2.fromOffset(p175 * (p177 + 2) - 2, p176 * (p177 + 2) - 2),
			["Position"] = p180 or UDim2.new(),
			["AnchorPoint"] = p181 or Vector2.zero
		}, p174)
		for v183 = 0, p176 - 1 do
			for v184 = 0, p175 - 1 do
				v_u_40.new("Frame", {
					["Name"] = "Cell",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = p178,
					["BackgroundTransparency"] = p179,
					["Position"] = UDim2.fromOffset(v184 * (p177 + 2), v183 * (p177 + 2)),
					["Size"] = UDim2.fromOffset(p177, p177)
				}, v182)
			end
		end
		return v182
	end
	local function v_u_218(p186, p187, p188, p189, p190, p191) -- name: itemIcon
		-- upvalues: (copy) v_u_44
		local v192 = p187.skin
		if type(v192) == "string" and (p191 ~= true and p188 <= 128) then
			local v193 = p187.mods
			if type(v193) ~= "table" or next(p187.mods) == nil then
				local function v194()
					-- upvalues: (ref) v_u_44
					return v_u_44.lib.SkinTile
				end
				local v195, v196 = pcall(v194)
				if v195 and type(v196) == "table" then
					local v197 = v196.icon
					if type(v197) == "function" then
						local v198 = v196.icon
						local v199 = p187.skin
						local v200 = {
							["weaponId"] = p187.id,
							["name"] = "Icon_" .. p187.id,
							["size"] = UDim2.fromOffset(p188, p188),
							["position"] = p189,
							["anchor"] = p190 or Vector2.zero
						}
						local v201, v202 = pcall(v198, p186, v199, v200)
						if v201 and typeof(v202) == "Instance" then
							return v202
						end
					end
				end
			end
		end
		local v203 = v_u_44.lib.ItemIcons
		local v204 = v203.get
		local v205 = p187.id
		local v206 = {
			["parent"] = p186,
			["size"] = UDim2.fromOffset(p188, p188),
			["position"] = p189,
			["anchor"] = p190 or Vector2.zero,
			["mods"] = p187.mods,
			["skin"] = p187.skin,
			["name"] = "Icon_" .. p187.id
		}
		local v207, v208 = pcall(v204, v205, false, v206)
		if not v207 then
			return nil
		end
		if p191 then
			local v209 = v203.spin
			pcall(v209, v208, true)
		end
		local v210 = p187.skin
		if type(v210) == "string" then
			local function v211()
				-- upvalues: (ref) v_u_44
				return v_u_44.lib.SkinTile
			end
			local v212, v213 = pcall(v211)
			if v212 and type(v213) == "table" then
				local v214 = v213.textureFor
				if type(v214) == "function" then
					local v215 = v213.textureFor
					local v216 = p187.skin
					local v217 = {
						["big"] = p191 == true
					}
					pcall(v215, v208, v216, v217)
				end
			end
		end
		return v208
	end
	local function v221(p219) -- name: itemName
		-- upvalues: (copy) v_u_47
		local v220 = v_u_47.get(p219)
		if v220 then
			return v220.name
		else
			return p219
		end
	end
	local function v_u_235(p222, p223) -- name: worthLine
		-- upvalues: (copy) v_u_44, (ref) v_u_53
		local v224 = v_u_44.shared.CrimsonPack
		if v224 ~= nil and type(p222) == "table" then
			local v225 = p222.worthOf
			if type(v225) == "table" then
				local v226 = {}
				for _, v227 in p222.worthOf do
					local v228 = v_u_53
					local v231
					if type(v228) == "table" then
						local v230 = v_u_53.products
						if type(v230) == "table" and v227 then
							for _, v231 in v_u_53.products do
								if v231.id ~= v227 then
									continue
								end
							end
							v231 = nil
						else
							v231 = nil
						end
					else
						v231 = nil
					end
					local v232
					if v231 then
						local v233 = v231.price
						v232 = tonumber(v233)
					else
						v232 = nil
					end
					if not v232 then
						continue
					end
					v226[v227] = v232
				end
				local v234 = v224.worth(v226, p222.worthOf)
				if v234 == nil then
					return nil
				elseif p223 then
					return ("Store value %s Robux."):format(v224.commas(v234))
				else
					return v224.worthLine(v234)
				end
			end
		end
		return nil
	end
	local function v_u_240(p236, p237) -- name: watchWorth
		-- upvalues: (ref) v_u_60
		for _, v238 in p236.worthOf or {} do
			local v239 = v_u_60[v238]
			if not v239 then
				v239 = {}
				v_u_60[v238] = v239
			end
			table.insert(v239, p237)
		end
	end
	local v_u_241 = nil
	local v_u_242 = false
	local v243, v244 = pcall(function()
		-- upvalues: (copy) v_u_44
		return v_u_44.lib.MenuStoreFeatured
	end)
	if v243 and v244 then
		local v245 = v244.new
		local v255, v256 = pcall(v245, p_u_38, {
			["buy"] = function(p246, p247, p248, p249, p250, p251) -- name: buy
				-- upvalues: (copy) v_u_158
				return v_u_158(p246, p247, p248, p249, p250, p251)
			end,
			["itemIcon"] = v_u_218,
			["itemName"] = v221,
			["worth"] = v_u_235,
			["watchWorth"] = v_u_240,
			["onRefresh"] = function() -- name: onRefresh
				-- upvalues: (ref) v_u_58, (ref) v_u_242, (copy) v_u_52
				if v_u_58 and v_u_242 then
					v_u_52.show()
				end
			end,
			["isVisible"] = function() -- name: isVisible
				-- upvalues: (ref) v_u_58, (ref) v_u_242, (copy) p_u_39
				local v252 = v_u_58 and v_u_242
				if v252 then
					if p_u_39.Parent == nil then
						v252 = false
					else
						v252 = p_u_39.Visible
					end
				end
				return v252
			end,
			["open"] = function(p253) -- name: open
				-- upvalues: (copy) v_u_52
				v_u_52.open(p253)
			end,
			["gift"] = function(p254) -- name: gift
				-- upvalues: (ref) v_u_92
				if v_u_92 then
					v_u_92.openGift(p254)
				end
			end
		})
		if v255 then
			v_u_241 = v256
		else
			warn("[MenuStore] the featured banner failed to start: " .. tostring(v256))
		end
	end
	local v257, v_u_258 = pcall(function()
		-- upvalues: (copy) v_u_44
		return v_u_44.lib.MenuStoreHighlight
	end)
	if not v257 or type(v_u_258) ~= "table" then
		v_u_258 = nil
	end
	local v_u_259 = nil
	local v260, v261 = pcall(function()
		-- upvalues: (copy) v_u_44
		return v_u_44.lib.MenuStoreSale
	end)
	if v260 and v261 then
		local v262 = v261.new
		local v268 = {
			["onPrice"] = function(p263, p264) -- name: onPrice
				-- upvalues: (ref) v_u_60
				local v265 = v_u_60[p263.id]
				if not v265 then
					v265 = {}
					v_u_60[p263.id] = v265
				end
				table.insert(v265, p264)
			end,
			["open"] = function(p266) -- name: open
				-- upvalues: (copy) v_u_52
				v_u_52.open(p266)
			end,
			["onExpired"] = function() -- name: onExpired
				-- upvalues: (ref) v_u_58, (ref) v_u_242, (copy) v_u_52
				if v_u_58 and v_u_242 then
					v_u_52.draw()
				end
			end,
			["isVisible"] = function() -- name: isVisible
				-- upvalues: (ref) v_u_58, (ref) v_u_242, (copy) p_u_39
				local v267 = v_u_58 and v_u_242
				if v267 then
					if p_u_39.Parent == nil then
						v267 = false
					else
						v267 = p_u_39.Visible
					end
				end
				return v267
			end
		}
		local v269, v270 = pcall(v262, p_u_38, v268)
		if v269 then
			v_u_259 = v270
		else
			warn("[MenuStore] the sale display failed to start: " .. tostring(v270))
		end
	end
	local function v_u_356(p271, p272, p273, p274, p275) -- name: art
		-- upvalues: (copy) v_u_40, (copy) v_u_44, (ref) v_u_3, (copy) v_u_218, (copy) v_u_42, (ref) v_u_29, (copy) v_u_185
		local v276 = v_u_40.new("Frame", {
			["Name"] = "Art",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(p273, p274)
		}, p271)
		local v277 = p272.showcase
		local v278 = v_u_44.shared.CrimsonPack
		local v279 = v_u_3.packArt(v278, p272, p275 == true)
		if v279 ~= nil then
			local v280 = math.min(p274, p273, p275 and 420 or 230)
			v_u_40.new("ImageLabel", {
				["Name"] = "StoreIcon",
				["BackgroundTransparency"] = 1,
				["Image"] = nil,
				["ScaleType"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = v279.image,
				["ScaleType"] = Enum.ScaleType.Fit,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(v280, v280)
			}, v276):SetAttribute("Source", v279.source)
			return v276
		end
		if type(v277) == "table" and #v277 > 0 then
			local v281 = #v277
			local v282 = p274 - 8
			local v283 = (p273 - 8) / v281
			local v284 = math.floor(v283) - 6
			local v285 = math.min(v282, v284, 230)
			if v281 == 1 then
				v285 = math.min(p274, p273, 420)
			end
			local v286 = (p273 - (v281 * v285 + (v281 - 1) * 6)) / 2
			local v287 = math.floor(v286)
			local v288 = (p274 - v285) / 2
			local v289 = math.floor(v288)
			for v290, v291 in v277 do
				v_u_218(v276, v291, v285, UDim2.fromOffset(v287 + (v290 - 1) * (v285 + 6), v289), nil, p275)
				if v281 <= 1 then
					continue
				end
				local v292 = v291.n
				if (tonumber(v292) or 1) <= 1 then
					continue
				end
				local v293 = v_u_40.label
				local v294 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["position"] = nil,
					["zindex"] = 5,
					["track"] = false,
					["parent"] = v276
				}
				local v295 = v291.n
				v294.text = "x" .. tostring(v295)
				v294.color = v_u_42.text
				v294.size = UDim2.fromOffset(v285 - 4, 14)
				v294.position = UDim2.fromOffset(v287 + (v290 - 1) * (v285 + 6), v289 + v285 - 16)
				v293(v294)
			end
			return v276
		end
		if v_u_29[p272.id] then
			local v296 = (p274 - 6) * 1.25
			local v297 = math.floor(v296)
			local v298 = (p273 - 6) * 1.25
			local v299 = math.floor(v298)
			local v300 = math.min(v297, v299, p275 and 300 or 140)
			v_u_40.new("ImageLabel", {
				["Name"] = "StoreIcon",
				["BackgroundTransparency"] = 1,
				["Image"] = nil,
				["ScaleType"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = v_u_29[p272.id],
				["ScaleType"] = Enum.ScaleType.Fit,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(v300, v300)
			}, v276):SetAttribute("Source", "art/store_icons/" .. p272.id .. ".png")
			return v276
		end
		if p272.art == "cash" then
			local v301 = p272.grants
			if v301 then
				v301 = p272.grants.cash
			end
			local v302 = tonumber(v301) or 0
			local v303 = v302 >= 650000 and 5 or (v302 >= 240000 and 3 or 1)
			local v304 = p274 - 10
			local v305 = math.min(v304, 56)
			local v306 = (p273 - (v303 * (v305 - 10) + 10)) / 2
			local v307 = math.floor(v306)
			for v308 = 1, v303 do
				local v309 = v_u_40.icon("cash", {
					["size"] = v305,
					["color"] = v_u_42.success
				})
				local v310 = UDim2.fromOffset
				local v311 = v307 + (v308 - 1) * (v305 - 10)
				local v312 = (p274 - v305) / 2
				v309.Position = v310(v311, math.floor(v312) + (v308 % 2 == 0 and -6 or 6))
				v309.Parent = v276
			end
			return v276
		end
		if p272.art ~= "stash" then
			if p272.art == "vip" then
				local v313 = p274 - 6
				local v314 = math.min(v313, 90)
				local v315 = v_u_40.icon("star", {
					["size"] = v314,
					["color"] = v_u_42.accent
				})
				v315.AnchorPoint = Vector2.new(0.5, 0.5)
				v315.Position = UDim2.fromScale(0.5, 0.5)
				v315.Parent = v276
				return v276
			end
			if p272.art == "insurance" then
				local v316 = p274 - 6
				local v317 = math.min(v316, 90)
				local v318 = v_u_40.icon("shield", {
					["size"] = nil,
					["color"] = nil,
					["thickness"] = 4,
					["size"] = v317,
					["color"] = v_u_42.accent
				})
				v318.AnchorPoint = Vector2.new(0.5, 0.5)
				v318.Position = UDim2.fromScale(0.5, 0.5)
				v318.Parent = v276
				return v276
			end
			if p272.art == "guard" then
				local v319 = p274 - 6
				local v320 = math.min(v319, 90)
				local v321 = v_u_40.icon("shield", {
					["size"] = nil,
					["color"] = nil,
					["thickness"] = 4,
					["size"] = v320,
					["color"] = v_u_42.info
				})
				v321.AnchorPoint = Vector2.new(0.5, 0.5)
				v321.Position = UDim2.fromScale(0.5, 0.5)
				v321.Parent = v276
				return v276
			end
			if p272.art ~= "rush" then
				if p272.art == "unlock" then
					local v322 = p274 - 6
					local v323 = math.min(v322, 90)
					local v324 = p272.grants
					local v325
					if type(v324) == "table" then
						v325 = p272.grants.mapUnlock == "Nightmare"
					else
						v325 = false
					end
					local v326 = v_u_40.icon
					local v327 = "skull"
					local v328 = {
						["size"] = nil,
						["color"] = nil,
						["thickness"] = 4,
						["size"] = v323
					}
					local v329
					if v325 then
						v329 = v_u_42.danger
					else
						v329 = v_u_42.accent
					end
					v328.color = v329
					local v330 = v326(v327, v328)
					v330.AnchorPoint = Vector2.new(0.5, 0.5)
					v330.Position = UDim2.fromScale(0.5, 0.5)
					v330.Parent = v276
					local v331 = v_u_40.icon
					local v332 = {
						["size"] = nil,
						["color"] = nil,
						["thickness"] = 3
					}
					local v333 = v323 * 0.42
					local v334 = math.floor(v333)
					v332.size = math.max(14, v334)
					v332.color = v_u_42.text
					local v335 = v331("lock", v332)
					v335.AnchorPoint = Vector2.new(0.5, 0.5)
					local v336 = UDim2.new
					local v337 = v323 * 0.36
					local v338 = math.floor(v337)
					local v339 = v323 * 0.3
					v335.Position = v336(0.5, v338, 0.5, (math.floor(v339)))
					v335.Parent = v276
				end
				return v276
			end
			local v340 = p274 - 6
			local v341 = math.min(v340, 90)
			local v342 = v_u_40.icon("hideout", {
				["size"] = v341,
				["color"] = v_u_42.info
			})
			v342.AnchorPoint = Vector2.new(0.5, 0.5)
			v342.Position = UDim2.fromScale(0.5, 0.5)
			v342.Parent = v276
			return v276
		end
		local v343 = (p273 - 20) / 12
		local v344 = (p274 - 14) / 6
		local v345 = math.min(v343, v344)
		local v346 = math.floor(v345) - 2
		local v347 = math.max(8, v346)
		local v348 = v_u_185
		local v349 = v_u_42.lineStrong
		local v350 = UDim2.fromOffset
		local v351 = p273 / 2
		local v352 = math.floor(v351)
		local v353 = p274 / 2
		for v354, v355 in v348(v276, 10, 5, v347, v349, 0.2, v350(v352, (math.floor(v353))), Vector2.new(0.5, 0.5)):GetChildren() do
			if not v355:IsA("Frame") or v354 <= 30 then
				continue
			end
			v355.BackgroundColor3 = v_u_42.accent
			v355.BackgroundTransparency = 0.05
		end
		return v276
	end
	local function v_u_386(p357, p358, p359, p360) -- name: secureCompare
		-- upvalues: (copy) v_u_40, (copy) v_u_49, (copy) v_u_42, (copy) v_u_47, (copy) v_u_185
		local v361 = v_u_40.new
		local v362 = "Frame"
		local v363 = {
			["Name"] = "Compare",
			["BackgroundTransparency"] = 1,
			["Size"] = nil
		}
		local v364 = UDim2.fromOffset
		local v365
		if p360 then
			v365 = p359 * 4 + 26
		else
			v365 = p359 * 4 + 60 + (v_u_49 and 18 or 0)
		end
		v363.Size = v364(p358, v365)
		local v366 = v361(v362, v363, p357)
		local v367 = {
			{
				["id"] = "secure_2x2",
				["label"] = nil,
				["sub"] = "2x2 = 4 cells",
				["col"] = nil,
				["a"] = 0.1,
				["label"] = v_u_49 and "STANDARD" or "STANDARD POUCH",
				["col"] = v_u_42.lineStrong
			},
			{
				["id"] = "secure_3x2",
				["label"] = nil,
				["sub"] = "3x2 = 6 cells, earned free",
				["col"] = nil,
				["a"] = 0.25,
				["label"] = v_u_49 and "VETERAN" or "VETERAN POUCH",
				["col"] = v_u_42.success
			},
			{
				["id"] = "secure_3x4",
				["label"] = "SECURE CASE",
				["sub"] = "3x4 = 12 cells",
				["col"] = nil,
				["a"] = 0.02,
				["col"] = v_u_42.accent
			}
		}
		local v368 = p358 / 3
		local v369 = math.floor(v368)
		for v370, v371 in v367 do
			local v372 = v_u_47.get(v371.id)
			local v373 = not (v372 and v372.grid) and 2 or v372.grid.w
			local v374 = not (v372 and v372.grid) and 2 or v372.grid.h
			local v375 = (v370 - 1) * v369
			local v376 = v374 * (p359 + 2) - 2
			local v377 = v373 * (p359 + 2) - 2
			local v378 = v_u_185
			local v379 = v371.col
			local v380 = v371.a
			local v381 = UDim2.fromOffset
			local v382 = (v369 - v377) / 2
			v378(v366, v373, v374, p359, v379, v380, v381(v375 + math.floor(v382), p359 * 4 + 4 - v376), nil)
			local v383 = v_u_40.label
			local v384 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["parent"] = v366,
				["text"] = v371.label
			}
			local v385
			if v370 == 3 then
				v385 = v_u_42.accent
			else
				v385 = v_u_42.text2
			end
			v384.color = v385
			v384.size = UDim2.fromOffset(v369, 14)
			v384.position = UDim2.fromOffset(v375, p359 * 4 + 10)
			v383(v384)
			if p360 then
				continue
			end
			v_u_40.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["wrap"] = nil,
				["fitWrap"] = false,
				["valign"] = nil,
				["parent"] = v366,
				["text"] = v371.sub,
				["color"] = v_u_42.muted,
				["size"] = UDim2.fromOffset(v369, v_u_49 and 32 or 14),
				["position"] = UDim2.fromOffset(v375, p359 * 4 + 26),
				["wrap"] = v_u_49,
				["valign"] = v_u_49 and "top" or nil
			})
		end
		return v366
	end
	local v_u_387 = 2
	local function v_u_440(p388, p_u_389, p390, p391, p392) -- name: card
		-- upvalues: (copy) v_u_40, (copy) v_u_42, (ref) v_u_258, (copy) v_u_41, (ref) v_u_4, (ref) v_u_92, (copy) v_u_49, (ref) v_u_387, (copy) v_u_50, (copy) v_u_356, (ref) v_u_45, (copy) v_u_158, (ref) v_u_241, (ref) v_u_259, (copy) v_u_52
		local v393 = v_u_40.new
		local v394 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["Selectable"] = true
		}
		local v395 = p_u_389.id
		v394.Name = tostring(v395)
		v394.BackgroundColor3 = v_u_42.raised
		v394.LayoutOrder = p392
		v394.Size = UDim2.fromOffset(p390, p391)
		local v396 = v393("TextButton", v394, p388)
		v396.SelectionImageObject = v_u_40.selectionImage()
		local v397 = p_u_389.limited
		local v398
		if type(v397) == "table" then
			v398 = p_u_389.limited.state == "running"
		else
			v398 = false
		end
		local v_u_399
		if v398 then
			v_u_399 = v_u_42.accent
		elseif p_u_389.enabled then
			v_u_399 = v_u_42.lineStrong
		else
			v_u_399 = v_u_42.line
		end
		local v_u_400
		if v398 then
			v_u_400 = v_u_40.stroke(v396, v_u_42.accent, 2, 0)
		else
			v_u_400 = v_u_40.stroke(v396, v_u_399)
		end
		local v401 = v_u_40.new
		local v402 = "Frame"
		local v403 = {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil
		}
		local v404
		if v398 or p_u_389.kind == "pass" then
			v404 = v_u_42.accent
		else
			v404 = v_u_42.info
		end
		v403.BackgroundColor3 = v404
		v403.Size = UDim2.new(1, 0, 0, v398 and 3 or 2)
		v401(v402, v403, v396)
		if v398 then
			local v405 = v_u_40.new("Frame", {
				["Name"] = "LimitedGlow",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 0,
				["BackgroundColor3"] = v_u_42.accentDeep,
				["Size"] = UDim2.fromScale(1, 1)
			}, v396)
			v_u_40.new("UIGradient", {
				["Rotation"] = 90,
				["Transparency"] = nil,
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(0.55, 0.9), NumberSequenceKeypoint.new(1, 1) })
			}, v405)
		end
		if v_u_258 ~= nil and p_u_389.highlight == true then
			local v406 = v_u_258.apply
			local v407 = v_u_40
			local v408 = v_u_41
			pcall(v406, v396, p_u_389, p390, v407, v408)
		end
		local v409 = p_u_389.category == "CASH"
		local v410
		if v409 then
			v410 = p390 < 270
		else
			v410 = v409
		end
		local v411 = v_u_4.card
		local v412 = p391
		local v413 = {
			["btnH"] = v_u_41.touch(40),
			["cash"] = v409,
			["narrowCash"] = v410
		}
		local v414 = p_u_389.giftable
		if v414 then
			if v_u_92 == nil then
				v414 = false
			else
				v414 = v_u_4.giftFits(p390)
			end
		end
		v413.gift = v414
		v413.giftH = v_u_41.touch(30)
		v413.phone = v_u_49
		v413.wideBuy = p_u_389.rushIdle == true and true or p_u_389.unlockFull == true
		v413.blurbLines = v_u_387
		v413.fs = v_u_50
		local v415 = v411(p390, v412, v413)
		v_u_356(v396, p_u_389, v415.art.w, v415.art.h, false).Position = UDim2.fromOffset(v415.art.x, v415.art.y)
		local v416
		if p_u_389.tag then
			local v417 = v_u_40.badge
			local v418 = p_u_389.tag
			v416 = v417(tostring(v418), "accent", {
				["parent"] = nil,
				["position"] = nil,
				["height"] = 16,
				["zindex"] = 6,
				["parent"] = v396,
				["position"] = UDim2.fromOffset(10, 10)
			})
		else
			v416 = nil
		end
		local v419 = v_u_40.label
		local v420 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v396
		}
		local v421 = p_u_389.name
		v420.text = tostring(v421)
		v420.position = UDim2.fromOffset(v415.name.x, v415.name.y)
		v420.size = UDim2.fromOffset(v415.name.w, v415.name.h)
		v419(v420)
		local v422 = v_u_40.label
		local v423 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["textSize"] = nil,
			["color"] = nil,
			["wrap"] = nil,
			["fit"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v396
		}
		local v424
		if v_u_45 == nil or (type(p_u_389) ~= "table" or p_u_389.art ~= "unlock") then
			local v425 = p_u_389.blurb or ""
			v424 = tostring(v425)
		else
			v424 = v_u_45.tileBlurb(p_u_389)
		end
		v423.text = v424
		local v426
		if v_u_50 > 13 then
			v426 = v_u_50
		else
			v426 = nil
		end
		v423.textSize = v426
		v423.color = v_u_42.text2
		v423.wrap = not v410
		v423.fit = v410
		v423.position = UDim2.fromOffset(v415.blurb.x, v415.blurb.y)
		v423.size = UDim2.fromOffset(v415.blurb.w, v415.blurb.h)
		v422(v423).TextYAlignment = Enum.TextYAlignment.Top
		if v415.note then
			local v427 = v_u_40.label
			local v428 = {
				["parent"] = nil,
				["name"] = "PveNote",
				["text"] = nil,
				["style"] = "micro",
				["textSize"] = nil,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v396,
				["text"] = v_u_49 and "PVE only. No cash packs in PVP." or "PVE only. PVP sells no cash packs."
			}
			local v429
			if v_u_50 > 13 then
				v429 = v_u_50
			else
				v429 = nil
			end
			v428.textSize = v429
			v428.color = v_u_42.accent
			v428.position = UDim2.fromOffset(v415.note.x, v415.note.y)
			v428.size = UDim2.fromOffset(v415.note.w, v415.note.h)
			v427(v428)
		end
		v_u_158(v396, p_u_389, false, UDim2.new(1, -12, 1, -10), Vector2.new(1, 1), v415.buy.w)
		local v430
		if p_u_389.limited and v_u_241 then
			v430 = v_u_241.timerLabel(v396, p_u_389, UDim2.new(1, -10, 0, 12), UDim2.new(1, -110, 0, 16), "micro")
			v430.AnchorPoint = Vector2.new(1, 0)
			v430.TextXAlignment = Enum.TextXAlignment.Right
		else
			v430 = nil
		end
		if v415.gift then
			v_u_40.button({
				["parent"] = nil,
				["text"] = "Gift",
				["kind"] = "ghost",
				["icon"] = "heart",
				["height"] = nil,
				["width"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["onClick"] = nil,
				["parent"] = v396,
				["height"] = v415.gift.h,
				["width"] = v415.gift.w,
				["position"] = UDim2.new(0, 12, 1, -10),
				["anchor"] = Vector2.new(0, 1),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_92, (copy) p_u_389
					v_u_92.openGift(p_u_389)
				end
			})
		end
		local v_u_431
		if v_u_259 == nil or p_u_389.sale == nil then
			v_u_431 = false
		else
			local v432 = v_u_259.decorateCard
			local v433 = {
				["art"] = v415.art,
				["buy"] = v415.buy,
				["gift"] = v415.gift,
				["w"] = p390,
				["h"] = p391
			}
			local v434 = {
				["tag"] = v416
			}
			local v435
			if p_u_389.tag then
				local v436 = p_u_389.tag
				v435 = #tostring(v436) * 7 + 16
			else
				v435 = nil
			end
			v434.tagW = v435
			v434.timer = v430
			local v437
			v_u_431, v437 = pcall(v432, v396, p_u_389, v433, v434)
			if v_u_431 then
				v_u_431 = v437 == true
			end
		end
		v396.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_52, (copy) p_u_389
			v_u_52.open(p_u_389.id)
		end)
		v396.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_400, (ref) v_u_42
			v_u_400.Color = v_u_42.accent
		end)
		v396.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_400, (ref) v_u_431, (ref) v_u_42, (copy) v_u_399
			local v438 = v_u_400
			local v439
			if v_u_431 then
				v439 = v_u_42.accent
			else
				v439 = v_u_399
			end
			v438.Color = v439
		end)
		return v396
	end
	local function v_u_487(p441, p_u_442, p443) -- name: hero
		-- upvalues: (copy) v_u_49, (copy) v_u_48, (copy) v_u_40, (copy) v_u_42, (copy) v_u_356, (copy) v_u_386, (ref) v_u_4, (copy) v_u_41, (ref) v_u_92, (ref) v_u_45, (copy) v_u_158, (ref) v_u_259, (copy) v_u_52
		local v444 = v_u_49 and 214 or (v_u_48 and 250 or 280)
		local v445 = v_u_40.new("TextButton", {
			["Name"] = "Hero",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = 1,
			["Size"] = nil,
			["Selectable"] = true,
			["BackgroundColor3"] = v_u_42.raised,
			["Size"] = UDim2.fromOffset(p443, v444)
		}, p441)
		v445.SelectionImageObject = v_u_40.selectionImage()
		local v_u_446 = v_u_40.stroke(v445, v_u_42.accent, 1, 0.3)
		v_u_40.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_42.accent,
			["Size"] = UDim2.new(1, 0, 0, 3)
		}, v445)
		v_u_40.new("Frame", {
			["Name"] = "Glow",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.4,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_42.accentDeep,
			["Size"] = UDim2.new(0.34, 0, 1, 0)
		}, v445)
		local v447 = v_u_356
		local v448 = p443 * 0.3
		v447(v445, p_u_442, math.floor(v448), v444 - 40, true).Position = UDim2.fromOffset(12, 20)
		local v449 = v_u_49 and 18 or (v_u_48 and 22 or 28)
		local v450 = p443 * 0.34
		local v451 = v_u_386(v445, math.floor(v450), v449)
		local v452 = UDim2.fromOffset
		local v453 = p443 * 0.33
		local v454 = math.floor(v453)
		local v455 = (v444 - v451.Size.Y.Offset) / 2
		v451.Position = v452(v454, (math.floor(v455)))
		local v456 = p443 * 0.69
		local v457 = math.floor(v456)
		local v458 = p443 - v457 - 20
		local v459 = v_u_4.hero
		local v460 = {
			["phone"] = v_u_49,
			["compact"] = v_u_48,
			["giftH"] = v_u_41.touch(30)
		}
		local v461
		if p_u_442.giftable == true then
			v461 = v_u_92 ~= nil
		else
			v461 = false
		end
		v460.gift = v461
		local v462 = p_u_442.bullets
		v460.bullets = type(v462) == "table" and #p_u_442.bullets or 0
		local v463 = v459(p443, v444, v460)
		if p_u_442.tag then
			local v464 = v_u_40.badge
			local v465 = p_u_442.tag
			v464(tostring(v465), "accent", {
				["parent"] = nil,
				["position"] = nil,
				["height"] = 18,
				["parent"] = v445,
				["position"] = UDim2.fromOffset(v457, 18)
			})
		end
		local v466 = v_u_40.label
		local v467 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h1",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v445
		}
		local v468 = p_u_442.name
		v467.text = tostring(v468)
		v467.position = UDim2.fromOffset(v457, 42)
		v467.size = UDim2.fromOffset(v458, 40)
		v466(v467)
		local v469 = v_u_40.label
		local v470 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v445
		}
		local v471
		if v_u_45 == nil or (type(p_u_442) ~= "table" or p_u_442.art ~= "unlock") then
			local v472 = p_u_442.blurb or ""
			v471 = tostring(v472)
		else
			v471 = v_u_45.tileBlurb(p_u_442)
		end
		v470.text = v471
		v470.color = v_u_42.text2
		v470.position = UDim2.fromOffset(v457, 88)
		v470.size = UDim2.fromOffset(v458, 44)
		v469(v470).TextYAlignment = Enum.TextYAlignment.Top
		if not v_u_48 then
			local v473 = p_u_442.bullets
			if type(v473) == "table" then
				for v474, v475 in p_u_442.bullets do
					local v476 = 138 + (v474 - 1) * 22
					local v477 = v_u_40.icon("check", {
						["size"] = 14,
						["color"] = nil,
						["color"] = v_u_42.accent
					})
					v477.Position = UDim2.fromOffset(v457, v476 + 3)
					v477.Parent = v445
					v_u_40.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v445,
						["text"] = tostring(v475),
						["color"] = v_u_42.text,
						["position"] = UDim2.fromOffset(v457 + 22, v476),
						["size"] = UDim2.fromOffset(v458 - 22, 18)
					})
				end
			end
		end
		local v478 = v_u_158
		local v479 = true
		local v480 = UDim2.fromOffset(v463.buy.x, v463.buy.y)
		local v481 = Vector2.zero
		if not v_u_49 then
			v458 = nil
		end
		local v482
		if v463.gift == nil then
			v482 = nil
		else
			v482 = v463.buy.w
		end
		v478(v445, p_u_442, v479, v480, v481, v458, v482)
		if v463.gift ~= nil then
			v_u_40.button({
				["parent"] = nil,
				["text"] = "Gift",
				["kind"] = "ghost",
				["icon"] = "heart",
				["height"] = nil,
				["width"] = nil,
				["position"] = nil,
				["name"] = "HeroGift",
				["onClick"] = nil,
				["parent"] = v445,
				["height"] = v463.gift.h,
				["width"] = v463.gift.w,
				["position"] = UDim2.fromOffset(v463.gift.x, v463.gift.y),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_92, (copy) p_u_442
					v_u_92.openGift(p_u_442)
				end
			})
		end
		if v_u_259 ~= nil and p_u_442.sale ~= nil then
			local v483 = v_u_259.decorateCard
			local v484 = {}
			local v485 = {
				["x"] = 12,
				["y"] = 20,
				["w"] = nil,
				["h"] = nil
			}
			local v486 = p443 * 0.3
			v485.w = math.floor(v486)
			v485.h = v444 - 40
			v484.art = v485
			v484.buy = {
				["x"] = v463.buy.x,
				["y"] = v463.buy.y,
				["w"] = v463.buy.w,
				["h"] = v463.buy.h
			}
			v484.w = p443
			v484.h = v444
			pcall(v483, v445, p_u_442, v484, {
				["force"] = true
			})
		end
		v445.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_52, (copy) p_u_442
			v_u_52.open(p_u_442.id)
		end)
		v445.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_446
			v_u_446.Transparency = 0
		end)
		v445.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_446
			v_u_446.Transparency = 0.3
		end)
		return v445
	end
	local function v_u_574() -- name: drawList
		-- upvalues: (ref) v_u_59, (ref) v_u_60, (ref) v_u_259, (copy) v_u_43, (copy) v_u_73, (copy) v_u_74, (ref) v_u_53, (ref) v_u_57, (ref) v_u_3, (copy) v_u_69, (ref) v_u_54, (copy) v_u_70, (copy) p_u_38, (copy) v_u_41, (ref) v_u_4, (copy) v_u_48, (ref) v_u_387, (ref) v_u_45, (copy) v_u_50, (copy) v_u_83, (copy) v_u_40, (copy) v_u_49, (copy) v_u_44, (ref) v_u_241, (copy) v_u_52, (copy) v_u_42, (copy) v_u_440, (copy) v_u_487, (ref) v_u_108, (ref) v_u_258
		v_u_59 = {}
		v_u_60 = {}
		if v_u_259 ~= nil then
			local v488 = v_u_259.reset
			pcall(v488)
		end
		v_u_43.clear(v_u_73)
		v_u_74.Visible = false
		v_u_73.Visible = true
		local v489 = v_u_53
		local v490
		if type(v489) == "table" then
			local v491 = v_u_53.products
			v490 = type(v491) == "table" and v_u_53.products or nil
		else
			v490 = nil
		end
		if v490 then
			local v492 = false
			for _, v493 in v490 do
				if v493.category ~= "GUARD" then
					continue
				end
				v492 = true
			end
			local v494 = v_u_69:FindFirstChild("Tab_GUARD", true)
			if v494 and v494:IsA("GuiObject") then
				v494.Visible = v492
			end
			if v_u_54 == "GUARD" and not v492 then
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			local v495 = false
			for _, v496 in v490 do
				if v496.category ~= "CRATES" then
					continue
				end
				v495 = true
			end
			local v497 = v_u_69:FindFirstChild("Tab_CRATES", true)
			if v497 and v497:IsA("GuiObject") then
				v497.Visible = v495
			end
			if v_u_54 == "CRATES" and not v495 then
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			for _, v498 in {
				"SEASON",
				"COSMETICS",
				"CLAN",
				"UNLOCK"
			} do
				local v499 = false
				for _, v500 in v490 do
					if v500.category ~= v498 then
						continue
					end
					v499 = true
				end
				local v501 = v_u_69:FindFirstChild("Tab_" .. v498, true)
				if v501 and v501:IsA("GuiObject") then
					v501.Visible = v499
				end
				if v_u_54 ~= v498 or v499 then
					break
				end
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			local v_u_502 = true
			local function v503()
				-- upvalues: (ref) v_u_502, (ref) p_u_38
				v_u_502 = p_u_38.config.flag("CashPacks") ~= false
			end
			pcall(v503)
			local v504
			if v_u_502 then
				local v505 = v_u_53
				if type(v505) == "table" then
					local v506 = v_u_53.products
					if type(v506) == "table" then
						for _, v507 in v_u_53.products do
							if v507.category ~= "CASH" then
								continue
							end
							v504 = true
						end
						v504 = false
					else
						v504 = false
					end
				else
					v504 = false
				end
			else
				v504 = false
			end
			local v508 = v_u_69:FindFirstChild("Tab_CASH", true)
			if v508 and v508:IsA("GuiObject") then
				v508.Visible = v504
			end
			if v_u_54 == "CASH" and not v504 then
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			local v509 = {}
			local v510
			if v_u_259 == nil then
				v510 = v509
			else
				local v511 = v_u_259.activeOf
				local v512
				v512, v510 = pcall(v511, v490)
				if v512 then
					if type(v510) ~= "table" then
						v510 = v509
					end
				else
					v510 = v509
				end
				local v513 = v_u_259.watchEnds
				pcall(v513, v490)
			end
			local v514 = {}
			for _, v515 in v510 do
				v514[v515.id] = true
			end
			local v516 = v_u_69:FindFirstChild("Tab_SALE", true)
			if v516 and v516:IsA("GuiObject") then
				v516.Visible = #v510 > 0
			end
			if v_u_54 == "SALE" and #v510 == 0 then
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			local v_u_517 = v_u_41.safeRefSize().X - 48 - 32 - 14
			local v518 = v_u_4.grid(v_u_41.safeRefSize().X, v_u_48, v_u_54 == "CASH", v_u_3.CASH_MIN_W)
			local v519 = v518.cardW
			v_u_387 = 2
			for _, v520 in v490 do
				if v520.id == "pass_secure" or v520.category == "GUARD" then
					continue
				end
				local v521
				if v_u_54 == "SALE" then
					v521 = v514[v520.id] == true
				else
					v521 = v_u_54 == "all" and true or v520.category == v_u_54
				end
				if not v521 then
					continue
				end
				local v522 = v_u_387
				local v523 = v_u_4.blurbLines
				local v524
				if v_u_45 == nil or (type(v520) ~= "table" or v520.art ~= "unlock") then
					local v525 = v520.blurb or ""
					v524 = tostring(v525)
				else
					v524 = v_u_45.tileBlurb(v520)
				end
				local v526 = v519 - 24
				local v527 = v_u_50
				v_u_387 = math.max(v522, v523(v524, v526, v527))
			end
			local v528 = v_u_387
			v_u_387 = math.min(v528, 3)
			local v529 = v_u_4.cardH
			local v530 = v518.cardH
			local v531 = {
				["btnH"] = v_u_41.touch(40),
				["cash"] = v_u_54 == "CASH"
			}
			local v532
			if v_u_54 == "CASH" then
				v532 = v519 < 270
			else
				v532 = false
			end
			v531.narrowCash = v532
			v531.gift = not v_u_48
			v531.giftH = v_u_41.touch(30)
			v531.blurbLines = v_u_387
			v531.fs = v_u_50
			local v533 = v529(v530, v531)
			if v_u_54 == "CASH" then
				local v_u_534, v535 = v_u_83("cash")
				if v_u_534 and v535 then
					local v536 = v_u_40.new("Frame", {
						["Name"] = "TripBack",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = -2,
						["Size"] = UDim2.new(1, 0, 0, v_u_41.touch(34))
					}, v_u_73)
					v_u_40.button({
						["parent"] = nil,
						["text"] = nil,
						["kind"] = "primary",
						["height"] = 34,
						["width"] = nil,
						["position"] = nil,
						["name"] = "BackToCrate",
						["onClick"] = nil,
						["parent"] = v536,
						["text"] = v_u_534.backText(v535.name, v_u_49),
						["width"] = v_u_49 and 156 or 250,
						["position"] = UDim2.fromOffset(0, 0),
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_534
							local v537 = v_u_534.back
							pcall(v537)
						end
					})
				end
			end
			local function v538()
				-- upvalues: (ref) v_u_44, (ref) p_u_38, (ref) v_u_73, (copy) v_u_517
				v_u_44.lib.MenuPaidQueue.storeStrip(p_u_38, v_u_73, v_u_517, -3)
			end
			pcall(v538)
			local v539 = false
			local v546
			if v_u_241 and v_u_54 == "all" then
				local v541 = v_u_53
				if type(v541) == "table" then
					local v542 = v_u_53.featured
					if type(v542) == "string" then
						local v543 = v_u_53.featured
						local v544 = v_u_53
						if type(v544) == "table" then
							local v545 = v_u_53.products
							if type(v545) == "table" and v543 then
								for _, v546 in v_u_53.products do
									if v546.id ~= v543 then
										continue
									end
								end
								v546 = nil
							else
								v546 = nil
							end
						else
							v546 = nil
						end
					else
						v546 = nil
					end
				else
					v546 = nil
				end
			else
				v546 = nil
			end
			if v546 then
				local v547 = v546.limited
				if type(v547) == "table" then
					local v548 = v_u_241.banner(v_u_73, v546, v_u_517, -1)
					v539 = true
					if v_u_52.newFeatured ~= nil and (v_u_52.newFeatured[v546.id] == true and typeof(v548) == "Instance") then
						v_u_40.new("Frame", {
							["Name"] = "NewDot",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 20,
							["BackgroundColor3"] = v_u_42.accent,
							["AnchorPoint"] = Vector2.new(1, 0),
							["Position"] = UDim2.new(1, -10, 0, 10),
							["Size"] = UDim2.fromOffset(10, 10)
						}, v548)
					end
				end
			end
			if v_u_259 ~= nil and (v_u_54 == "all" and #v510 > 0) then
				local v549 = v_u_259.saleRow
				local v550 = v_u_73
				local v551 = {
					["cols"] = v518.cols,
					["cardW"] = v519,
					["cardH"] = v533
				}
				local function v556(p552, p553, p554, p555)
					-- upvalues: (ref) v_u_440
					v_u_440(p552, p553, p554.w, p554.h, p555).Position = UDim2.fromOffset(p554.x, p554.y)
				end
				pcall(v549, v550, v510, v_u_517, v551, v556, 0)
			end
			local v557 = v_u_53
			local v560
			if type(v557) == "table" then
				local v559 = v_u_53.products
				if type(v559) == "table" then
					for _, v560 in v_u_53.products do
						if v560.id ~= "pass_secure" then
							continue
						end
					end
					v560 = nil
				else
					v560 = nil
				end
			else
				v560 = nil
			end
			local v561
			if v560 == nil then
				v561 = false
			elseif v_u_54 == "all" or v_u_54 == v560.category then
				v561 = true
			elseif v_u_54 == "SALE" then
				v561 = v514.pass_secure == true
			else
				v561 = false
			end
			if v560 and v561 then
				v_u_487(v_u_73, v560, v_u_517)
			end
			local v562 = false
			if v_u_108 and (v_u_54 == "all" or v_u_54 == "GUARD") then
				local v563 = {}
				for _, v564 in v490 do
					if v564.category ~= "GUARD" then
						continue
					end
					table.insert(v563, v564)
				end
				if #v563 > 0 then
					v_u_108.build(v_u_73, v563, v_u_53.guard, v_u_517, 3)
					v562 = true
				end
			end
			local v565 = v_u_40.new("Frame", {
				["Name"] = "Grid",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, 10),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v_u_73)
			v_u_40.new("UIGridLayout", {
				["CellSize"] = UDim2.fromOffset(v519, v533),
				["CellPadding"] = UDim2.fromOffset(12, 12),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}, v565)
			local v566 = 0
			if v_u_54 == "SALE" then
				v490 = v510
			end
			for _, v567 in v490 do
				if v567.id == "pass_secure" or (v567.category == "GUARD" or v539 and v567.id == v_u_53.featured) then
					continue
				end
				local v568
				if v_u_54 == "SALE" then
					v568 = v514[v567.id] == true
				else
					v568 = v_u_54 == "all" and true or v567.category == v_u_54
				end
				if not v568 or not v504 and v567.category == "CASH" then
					continue
				end
				v566 = v566 + 1
				local v569 = v_u_440
				local v570
				if v_u_258 == nil then
					v570 = v566
				else
					v570 = v_u_258.layoutOrder(v567, v566)
				end
				v569(v565, v567, v519, v533, v570)
			end
			if v566 == 0 and not (v562 or v560 and v561) then
				v_u_43.empty(v_u_73, "Nothing in this category yet.")
			end
			if v_u_54 == "all" then
				local v571 = v_u_53.ended
				if type(v571) == "table" then
					for v572, v573 in v_u_53.ended do
						v_u_40.label({
							["parent"] = nil,
							["name"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["size"] = nil,
							["track"] = false,
							["parent"] = v_u_73,
							["name"] = "Ended" .. v572,
							["text"] = tostring(v573),
							["color"] = v_u_42.muted,
							["size"] = UDim2.new(1, 0, 0, 22)
						}).LayoutOrder = 4
					end
				end
			end
		else
			v_u_43.empty(v_u_73, not v_u_57 and "Loading the store..." or v_u_3.LOAD_FAILED)
		end
	end
	local function v_u_805(p_u_575) -- name: drawDetail
		-- upvalues: (ref) v_u_59, (ref) v_u_60, (ref) v_u_259, (copy) v_u_43, (copy) v_u_74, (copy) v_u_73, (copy) v_u_40, (copy) v_u_49, (ref) v_u_55, (copy) v_u_52, (copy) v_u_83, (copy) v_u_41, (copy) v_u_129, (ref) v_u_45, (copy) p_u_38, (ref) v_u_1, (copy) v_u_42, (copy) v_u_48, (ref) v_u_75, (copy) v_u_356, (copy) v_u_386, (ref) v_u_92, (ref) v_u_4, (ref) v_u_241, (copy) v_u_235, (copy) v_u_240, (copy) v_u_44, (copy) v_u_218, (copy) v_u_47, (copy) v_u_158, (ref) v_u_53, (ref) v_u_3
		v_u_59 = {}
		v_u_60 = {}
		if v_u_259 ~= nil then
			local v576 = v_u_259.reset
			pcall(v576)
		end
		v_u_43.clear(v_u_74)
		v_u_73.Visible = false
		v_u_74.Visible = true
		v_u_40.button({
			["parent"] = nil,
			["text"] = "Back to the store",
			["kind"] = "close",
			["icon"] = "close",
			["height"] = 34,
			["width"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_74,
			["width"] = v_u_49 and 176 or 220,
			["position"] = UDim2.fromOffset(0, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_55, (ref) v_u_52
				v_u_55 = nil
				v_u_52.draw()
			end
		})
		local v_u_577, v578 = v_u_83(p_u_575.category == "CRATES" and "key" or (p_u_575.category == "CASH" and "cash" or "none"))
		if v_u_577 and v578 then
			v_u_40.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "primary",
				["height"] = 34,
				["width"] = nil,
				["position"] = nil,
				["name"] = "BackToCrate",
				["onClick"] = nil,
				["parent"] = v_u_74,
				["text"] = v_u_577.backText(v578.name, v_u_49),
				["width"] = v_u_49 and 156 or 250,
				["position"] = UDim2.fromOffset((v_u_49 and 176 or 220) + 10, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_577
					local v579 = v_u_577.back
					pcall(v579)
				end
			})
		end
		local v580
		if v_u_49 then
			local v581 = v_u_41.touch(34) + 8
			v580 = math.max(44, v581)
		else
			v580 = 44
		end
		local v582 = v_u_129(p_u_575)
		local v_u_583
		if v582 == nil then
			v_u_583 = nil
		else
			local v584, v585 = v_u_45.levelsForProduct(p_u_575, p_u_38, v_u_1.LocalPlayer)
			if type(v584) == "table" and type(v585) == "table" then
				v_u_583 = v_u_45.model(v584, v585, v_u_45.nameFn(p_u_38), v582)
			else
				v_u_583 = nil
			end
		end
		local v_u_586 = v_u_49
		if v_u_586 then
			v_u_586 = v_u_583 ~= nil
		end
		local v587 = v_u_40.new("Frame", {
			["Name"] = "Left",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_42.raised,
			["Position"] = UDim2.fromOffset(0, v580),
			["Size"] = UDim2.new(0.46, -8, 1, -v580)
		}, v_u_74)
		local v588 = v_u_40.stroke
		local v589
		if p_u_575.kind == "pass" then
			v589 = v_u_42.accent
		else
			v589 = v_u_42.lineStrong
		end
		v588(v587, v589, 1, 0.35)
		v_u_40.new("Frame", {
			["Name"] = "Glow",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.55,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_42.accentDeep,
			["Size"] = UDim2.fromScale(1, 1)
		}, v587)
		v587.Visible = not v_u_586
		local v590 = (v_u_41.safeRefSize().X - 48 - 32) * 0.46
		local v591 = math.floor(v590) - 8
		local v592 = v_u_41.safeRefSize().Y - 300
		local v593 = math.floor(v592)
		local v594 = p_u_575.id == "pass_secure" and 120 or 0
		if v_u_49 then
			local v595 = v_u_41.safeRefSize().Y - (v_u_48 and 64 or 120) - 30 - 8 - 32 - v_u_75 - v580
			if not v_u_586 then
				if p_u_575.id == "pass_secure" then
					local v596 = v595 - 12
					local v597 = v596 < 134
					local v598 = v_u_386
					local v599 = v587
					local v600 = v591 - 40
					local v601
					if v597 then
						local v602 = (v596 - 26) / 4
						local v603 = math.floor(v602)
						v601 = math.clamp(v603, 8, 14)
					else
						v601 = 14
					end
					local v604 = v598(v599, v600, v601, v597)
					v604.AnchorPoint = Vector2.new(0.5, 0.5)
					v604.Position = UDim2.fromScale(0.5, 0.5)
				else
					local v605 = v_u_356
					local v606 = v591 - 24
					local v607 = v595 - 16
					v605(v587, p_u_575, v606, math.max(100, v607), true).Position = UDim2.fromOffset(12, 8)
				end
			end
		else
			local v608 = v_u_356
			local v609 = v591 - 24
			local v610 = v593 - v594 - 110
			v608(v587, p_u_575, v609, math.max(160, v610), true).Position = UDim2.fromOffset(12, 8)
			if p_u_575.id == "pass_secure" then
				local v611 = v_u_48 and 20 or 26
				local v612 = v_u_386(v587, v591 - 40, v611)
				v612.AnchorPoint = Vector2.new(0.5, 1)
				v612.Position = UDim2.new(0.5, 0, 1, -14)
			end
		end
		local v613
		if p_u_575.giftable == true then
			v613 = v_u_92 ~= nil
		else
			v613 = false
		end
		local v_u_614
		if v613 then
			v_u_614 = v_u_4.BUYBOX_H_GIFT
		else
			v_u_614 = v_u_4.BUYBOX_H
		end
		local v615 = v_u_41.safeRefSize().X - 48 - 32
		local v616 = v_u_41.phoneText
		local v_u_617 = type(v616) ~= "function" and 14 or v_u_41.phoneText(14, "text")
		local v_u_618 = v582 == nil and "" or v_u_45.targetLine(v582)
		local v619
		if v_u_586 then
			local v620 = v_u_41.safeRefSize().Y - (v_u_48 and 64 or 120) - 30 - 8 - 32 - v_u_75 - v580
			local v621 = v_u_4.unlockPage
			local v622 = {
				["W"] = nil,
				["H"] = nil,
				["titleH"] = 34,
				["targetH"] = nil,
				["buyH"] = nil,
				["giftH"] = nil,
				["gift"] = nil,
				["minInfo"] = nil,
				["gridMin"] = nil,
				["targetHFor"] = nil,
				["W"] = v615,
				["H"] = v620
			}
			local v623 = v_u_45.lineCount(v_u_618, v615 - 16, v_u_617)
			local v624 = v_u_617 * 1.3
			v622.targetH = v623 * math.ceil(v624) + 8
			v622.buyH = v_u_41.touch(52)
			v622.giftH = v_u_41.touch(40)
			v622.gift = v613
			v622.minInfo = v_u_4.UP_MIN_INFO
			v622.gridMin = v_u_4.UP_GRID_MIN
			function v622.targetHFor(p625) -- name: targetHFor
				-- upvalues: (ref) v_u_45, (copy) v_u_618, (copy) v_u_617
				local v626 = v_u_45.lineCount(v_u_618, p625, v_u_617)
				local v627 = v_u_617 * 1.3
				return v626 * math.ceil(v627) + 8
			end
			v619 = v621(v622)
			v_u_614 = v619.box.h
		else
			v619 = nil
		end
		local v_u_628 = v_u_49
		if not v_u_628 then
			if v_u_583 == nil then
				local v629 = p_u_575.grants
				if type(v629) == "table" then
					local v630 = p_u_575.grants.skins
					if type(v630) == "table" then
						v_u_628 = #p_u_575.grants.skins > 0
					else
						v_u_628 = false
					end
				else
					v_u_628 = false
				end
			else
				v_u_628 = true
			end
		end
		local v631, v_u_632
		if v_u_586 then
			v631 = v_u_40.new("Frame", {
				["Name"] = "Right",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(0, v580),
				["Size"] = UDim2.new(1, 0, 1, -v580)
			}, v_u_74)
			if not v619.titleInScroll then
				local v633 = v_u_40.label
				local v634 = {
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "h1",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v631
				}
				local v635 = p_u_575.name
				v634.text = tostring(v635)
				v634.position = UDim2.fromOffset(v619.title.x, v619.title.y)
				v634.size = UDim2.fromOffset(v619.title.w, v619.title.h)
				v633(v634)
			end
			v_u_632 = v_u_40.new("ScrollingFrame", {
				["Name"] = "Info",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["ScrollBarThickness"] = nil,
				["ScrollBarImageColor3"] = nil,
				["ScrollBarImageTransparency"] = 0.2,
				["ScrollingDirection"] = nil,
				["VerticalScrollBarInset"] = nil,
				["ElasticBehavior"] = nil,
				["TopImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
				["BottomImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
				["Position"] = UDim2.fromOffset(v619.info.x, v619.info.y),
				["Size"] = UDim2.fromOffset(v619.info.w, v619.info.h),
				["CanvasSize"] = UDim2.new(),
				["ScrollBarThickness"] = v_u_41.scrollBar,
				["ScrollBarImageColor3"] = v_u_42.lineStrong,
				["ScrollingDirection"] = Enum.ScrollingDirection.Y,
				["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
				["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
			}, v631)
			v_u_40.pad(v_u_632, {
				0,
				6,
				0,
				0
			})
			if not v619.targetInBox then
				local v636 = v_u_40.new("Frame", {
					["Name"] = "TargetBacking",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_42.bg,
					["Position"] = UDim2.fromOffset(v619.target.x, v619.target.y),
					["Size"] = UDim2.fromOffset(v619.target.w, v619.target.h)
				}, v631)
				v_u_40.stroke(v636, v_u_42.accent, 1, 0.5)
				v_u_40.label({
					["parent"] = nil,
					["name"] = "TargetLine",
					["text"] = nil,
					["style"] = "bodyStrong",
					["textSize"] = nil,
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v636,
					["text"] = v_u_618,
					["textSize"] = v_u_617,
					["color"] = v_u_42.accent,
					["position"] = UDim2.fromOffset(8, 4),
					["size"] = UDim2.new(1, -16, 1, -8)
				}).TextYAlignment = Enum.TextYAlignment.Center
			end
		elseif v_u_628 then
			v631 = v_u_40.new("Frame", {
				["Name"] = "Right",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.new(0.46, 8, 0, v580),
				["Size"] = UDim2.new(0.54, -8, 1, -v580)
			}, v_u_74)
			v_u_632 = v_u_40.new("ScrollingFrame", {
				["Name"] = "Info",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["ScrollBarThickness"] = nil,
				["ScrollBarImageColor3"] = nil,
				["ScrollBarImageTransparency"] = 0.2,
				["ScrollingDirection"] = nil,
				["VerticalScrollBarInset"] = nil,
				["ElasticBehavior"] = nil,
				["TopImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
				["BottomImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
				["Size"] = UDim2.new(1, 0, 1, -(v_u_614 + 8)),
				["CanvasSize"] = UDim2.new(),
				["ScrollBarThickness"] = v_u_41.scrollBar,
				["ScrollBarImageColor3"] = v_u_42.lineStrong,
				["ScrollingDirection"] = Enum.ScrollingDirection.Y,
				["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
				["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
			}, v631)
			v_u_40.pad(v_u_632, {
				0,
				6,
				0,
				0
			})
		else
			v631 = v_u_40.new("Frame", {
				["Name"] = "Right",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.new(0.46, 8, 0, v580),
				["Size"] = UDim2.new(0.54, -8, 1, -v580)
			}, v_u_74)
			v_u_632 = v631
		end
		local v637 = 4
		if v_u_586 then
			v_u_737 = 2
		else
			local v638 = v_u_40.label
			local v639 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_632
			}
			local v640 = p_u_575.category
			v639.text = tostring(v640) .. (p_u_575.kind == "pass" and "  /  PERMANENT" or "")
			v639.color = v_u_42.text2
			v639.position = UDim2.fromOffset(0, v637)
			v639.size = UDim2.new(1, 0, 0, 14)
			v638(v639)
			if p_u_575.tag then
				local v641 = v_u_40.badge
				local v642 = p_u_575.tag
				v641(tostring(v642), "accent", {
					["parent"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["height"] = 18,
					["parent"] = v_u_632,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, 0, 0, v637 - 2)
				})
			end
			local v643 = v637 + 20
			local v644 = v_u_40.label
			local v645 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h1",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v_u_632
			}
			local v646 = p_u_575.name
			v645.text = tostring(v646)
			v645.position = UDim2.fromOffset(0, v643)
			v645.size = UDim2.new(1, 0, 0, 40)
			v644(v645)
			v_u_737 = v643 + 46
		end
		if p_u_575.limited and v_u_241 then
			v_u_241.timerLabel(v_u_632, p_u_575, UDim2.fromOffset(0, v_u_737 - 6), UDim2.new(1, 0, 0, 22), "bodyStrong")
			v_u_737 = v_u_737 + 22
		end
		if v_u_259 ~= nil and p_u_575.sale ~= nil then
			local v647 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
			local v648 = math.floor(v647) - 8 - (v_u_628 and 12 or 0)
			local v649 = v_u_259.detailStrip
			local v650 = v_u_737 - 4
			local v651, v652 = pcall(v649, v_u_632, p_u_575, v648, v650)
			if v651 and (type(v652) == "number" and v652 > 0) then
				v_u_737 = v_u_737 + (v652 + 6)
			end
		end
		local v653
		if v_u_586 then
			if v619 == nil then
				v653 = false
			else
				v653 = v619.short == true
			end
		else
			v653 = v_u_586
		end
		if v_u_586 and (v619 ~= nil and v619.titleInScroll) then
			local v654 = v_u_40.label
			local v655 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h1",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v_u_632
			}
			local v656 = p_u_575.name
			v655.text = tostring(v656)
			v655.position = UDim2.fromOffset(0, v_u_737)
			v655.size = UDim2.new(1, 0, 0, v619.title.h)
			v654(v655)
			v_u_737 = v_u_737 + (v619.title.h + 4)
		end
		local v_u_657
		if v_u_586 then
			local v658 = v_u_45.lineCount
			local v659 = p_u_575.desc or ""
			local v660 = v658(tostring(v659), v619.info.w - 12, v_u_617)
			local v661 = v_u_617 * 1.3
			v_u_657 = v660 * math.ceil(v661) + 6
		else
			v_u_657 = 78
		end
		local function v666() -- name: placeDesc
			-- upvalues: (ref) v_u_40, (ref) v_u_632, (copy) p_u_575, (copy) v_u_586, (copy) v_u_617, (ref) v_u_42, (ref) v_u_737, (copy) v_u_657
			local v662 = v_u_40.label
			local v663 = {
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = nil,
				["style"] = "body",
				["textSize"] = nil,
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_632
			}
			local v664 = p_u_575.desc or ""
			v663.text = tostring(v664)
			local v665
			if v_u_586 then
				v665 = v_u_617
			else
				v665 = nil
			end
			v663.textSize = v665
			v663.color = v_u_42.text2
			v663.position = UDim2.fromOffset(0, v_u_737)
			v663.size = UDim2.new(1, 0, 0, v_u_657)
			v662(v663).TextYAlignment = Enum.TextYAlignment.Top
			v_u_737 = v_u_737 + (v_u_657 + 6)
		end
		local v_u_667
		if v_u_586 then
			v_u_667 = v619.info.w - 12
		else
			local v668 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
			v_u_667 = math.floor(v668) - 8 - (v_u_628 and 12 or 0)
		end
		local function v672() -- name: placeChain
			-- upvalues: (copy) v_u_583, (ref) v_u_45, (ref) v_u_40, (ref) v_u_42, (ref) v_u_632, (copy) v_u_667, (ref) v_u_41, (ref) v_u_49, (ref) v_u_737
			if v_u_583 ~= nil then
				local v669 = {
					["width"] = nil,
					["name"] = "UnlockChain",
					["theme"] = nil,
					["width"] = v_u_667,
					["theme"] = v_u_41
				}
				local v670 = v_u_45.build(v_u_40, v_u_42, v_u_632, v669)
				local v671 = v670.set(v_u_583, v_u_49)
				v670.frame.Position = UDim2.fromOffset(0, v_u_737)
				v_u_737 = v_u_737 + (v671 + 8)
			end
		end
		if v653 then
			v672()
			v666()
		else
			v666()
			v672()
		end
		local v673 = p_u_575.bullets
		if type(v673) == "table" then
			for _, v674 in p_u_575.bullets do
				local v675 = v_u_40.icon("check", {
					["size"] = 16,
					["color"] = nil,
					["color"] = v_u_42.accent
				})
				v675.Position = UDim2.fromOffset(0, v_u_737 + 2)
				v675.Parent = v_u_632
				v_u_40.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v_u_632,
					["text"] = tostring(v674),
					["position"] = UDim2.fromOffset(26, v_u_737),
					["size"] = UDim2.new(1, -26, 0, 20)
				})
				v_u_737 = v_u_737 + 24
			end
		end
		local v676 = p_u_575.worthOf
		if type(v676) == "table" then
			v_u_737 = v_u_737 + 2
			local v_u_677 = v_u_40.label({
				["parent"] = nil,
				["name"] = "WorthLine",
				["text"] = "",
				["style"] = "bodyStrong",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_632,
				["color"] = v_u_42.accent,
				["position"] = UDim2.fromOffset(0, v_u_737),
				["size"] = UDim2.new(1, 0, 0, 42)
			})
			v_u_677.TextYAlignment = Enum.TextYAlignment.Top
			local function v679() -- name: paintWorth
				-- upvalues: (ref) v_u_235, (copy) p_u_575, (copy) v_u_677
				local v678 = v_u_235(p_u_575)
				v_u_677.Text = v678 or ""
				v_u_677.Visible = v678 ~= nil
			end
			local v680 = v_u_235(p_u_575)
			v_u_677.Text = v680 or ""
			v_u_677.Visible = v680 ~= nil
			v_u_240(p_u_575, v679)
			v_u_737 = v_u_737 + 46
		end
		local v681 = p_u_575.opens
		if type(v681) == "table" and #p_u_575.opens > 0 then
			v_u_737 = v_u_737 + 6
			v_u_40.button({
				["parent"] = nil,
				["text"] = "ODDS",
				["kind"] = "secondary",
				["icon"] = "info",
				["height"] = nil,
				["width"] = 160,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_632,
				["height"] = v_u_41.touch(34),
				["position"] = UDim2.fromOffset(0, v_u_737),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_44, (ref) p_u_38, (copy) p_u_575
					local function v682()
						-- upvalues: (ref) v_u_44
						return v_u_44.lib.MenuCratesOdds
					end
					local v683, v684 = pcall(v682)
					if v683 and v684 then
						v684.open(p_u_38, p_u_575.opens)
					end
				end
			})
			v_u_737 = v_u_737 + (v_u_41.touch(34) + 8)
		end
		local v685 = p_u_575.grants or {}
		local v686 = v685.skins
		if type(v686) == "table" and #v685.skins > 0 then
			v_u_737 = v_u_737 + 8
			v_u_40.label({
				["parent"] = nil,
				["text"] = "EXCLUSIVE TO THIS PACK",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_632,
				["color"] = v_u_42.accent,
				["position"] = UDim2.fromOffset(0, v_u_737),
				["size"] = UDim2.new(1, 0, 0, 14)
			})
			v_u_737 = v_u_737 + 20
			local v687 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
			local v688 = math.floor(v687) - 8
			local v689 = v_u_44.shared.Skins
			local v690 = {}
			local v691 = 0
			for _, v692 in v685.skins do
				table.insert(v690, {
					["kind"] = "skin",
					["id"] = nil,
					["id"] = v692
				})
			end
			local v693 = v685.title
			if type(v693) == "string" and v685.title ~= "" then
				local v694 = {
					["kind"] = "title",
					["id"] = nil,
					["id"] = v685.title
				}
				table.insert(v690, v694)
			end
			for _, v695 in v690 do
				if v691 > 0 and v688 < v691 + 120 then
					v691 = 0
					v_u_737 = v_u_737 + 104
				end
				local v696 = v_u_40.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Name"] = "Exclusive_" .. v695.id,
					["BackgroundColor3"] = v_u_42.raised,
					["Position"] = UDim2.fromOffset(v691, v_u_737),
					["Size"] = UDim2.fromOffset(120, 96)
				}, v_u_632)
				local v697
				if v695.kind == "skin" and v689 then
					v697 = v689.get(v695.id)
				else
					v697 = nil
				end
				local v698 = not v697 and 4 or v697.rarity
				if v695.kind == "title" then
					local v699 = v_u_44.shared.TitleRarity
					v698 = not v699 and 4 or v699.rarityOf(v695.id)
				end
				local v700 = v_u_41.rarityColor(v698)
				v_u_40.new("Frame", {
					["Name"] = "Tint",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v700,
					["BackgroundTransparency"] = v_u_41.alpha.rarity,
					["Size"] = UDim2.fromScale(1, 1)
				}, v696)
				v_u_40.stroke(v696, v700, 2)
				local v701 = v695.id
				local v702 = tostring(v701)
				if v695.kind == "title" then
					local v703 = v_u_44.shared.Tasks
					if v703 then
						v703 = v_u_44.shared.Tasks.titles
					end
					local v704
					if v703 then
						v704 = v703[v695.id]
					else
						v704 = nil
					end
					local v705 = v704 or string.upper(v702)
					v_u_40.label({
						["parent"] = nil,
						["text"] = "TITLE",
						["style"] = "micro",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["track"] = false,
						["parent"] = v696,
						["color"] = v700,
						["size"] = UDim2.new(1, -8, 0, 14),
						["position"] = UDim2.fromOffset(4, 22)
					})
					v_u_40.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v696,
						["text"] = v705,
						["color"] = v_u_42.text,
						["size"] = UDim2.new(1, -8, 0, 24),
						["position"] = UDim2.fromOffset(4, 40)
					})
				elseif v697 then
					local v706 = v689.displayName(v697)
					if v697.kind == "wear" then
						local v707 = nil
						local function v708()
							-- upvalues: (ref) v_u_44
							return v_u_44.lib.SkinTile
						end
						local v709, v710 = pcall(v708)
						local v711
						if v709 and type(v710) == "table" then
							local v712 = v710.icon
							if type(v712) == "function" then
								local v713 = v710.icon
								local v714 = v695.id
								local v715 = {
									["name"] = "WearTile",
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["size"] = UDim2.fromOffset(64, 64),
									["position"] = UDim2.new(0.5, 0, 0, 4),
									["anchor"] = Vector2.new(0.5, 0)
								}
								local v716
								v716, v711 = pcall(v713, v696, v714, v715)
								if v716 then
									if typeof(v711) ~= "Instance" then
										v711 = v707
									end
								else
									v711 = v707
								end
							else
								v711 = v707
							end
						else
							v711 = v707
						end
						local function v717()
							-- upvalues: (ref) v_u_44
							return v_u_44.lib.SkinPreview
						end
						local v718, v719 = pcall(v717)
						if v711 == nil and (v718 and v719) then
							local v720 = v719.wearView
							if type(v720) == "function" then
								local v721 = v719.wearView
								local v722 = v695.id
								local v723 = {
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["name"] = "WearTile",
									["size"] = UDim2.fromOffset(64, 64),
									["position"] = UDim2.new(0.5, 0, 0, 4),
									["anchor"] = Vector2.new(0.5, 0)
								}
								pcall(v721, v696, v722, v723)
							end
						end
					else
						v_u_218(v696, {
							["id"] = v697.weapon,
							["skin"] = v695.id
						}, 60, UDim2.new(0.5, 0, 0, 6), Vector2.new(0.5, 0), false)
					end
					v_u_40.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["wrap"] = true,
						["track"] = false,
						["parent"] = v696,
						["text"] = v706,
						["color"] = v_u_42.text,
						["size"] = UDim2.new(1, -8, 0, 24),
						["position"] = UDim2.fromOffset(4, 68)
					}).TextYAlignment = Enum.TextYAlignment.Top
				end
				v691 = v691 + 128
			end
			v_u_737 = v_u_737 + 100
		end
		local v724 = v685.items
		if type(v724) == "table" and #v685.items > 0 then
			v_u_737 = v_u_737 + 8
			v_u_40.label({
				["parent"] = nil,
				["text"] = "WHAT YOU GET",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_632,
				["color"] = v_u_42.text2,
				["position"] = UDim2.fromOffset(0, v_u_737),
				["size"] = UDim2.new(1, 0, 0, 14)
			})
			v_u_737 = v_u_737 + 20
			local v725 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
			local v726 = math.floor(v725) - 8
			local v727 = 0
			for _, v728 in v685.items do
				if v727 > 0 and v726 < v727 + 120 then
					v727 = 0
					v_u_737 = v_u_737 + 104
				end
				local v729 = v_u_40.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Name"] = "Item_" .. v728.id,
					["BackgroundColor3"] = v_u_42.raised,
					["Position"] = UDim2.fromOffset(v727, v_u_737),
					["Size"] = UDim2.fromOffset(120, 96)
				}, v_u_632)
				local v730 = v_u_47.get(v728.id)
				local v731 = v_u_41.rarityColor(not v730 and 1 or (v730.shown or v730.rarity))
				v_u_40.new("Frame", {
					["Name"] = "Tint",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v731,
					["BackgroundTransparency"] = v_u_41.alpha.rarity,
					["Size"] = UDim2.fromScale(1, 1)
				}, v729)
				if v730 and v730.gold then
					v_u_40.stroke(v729, v731, 2)
				else
					v_u_40.stroke(v729, v_u_42.line:Lerp(v731, 0.35))
				end
				v_u_218(v729, v728, 60, UDim2.new(0.5, 0, 0, 6), Vector2.new(0.5, 0), false)
				local v732 = v728.id
				local v733 = v_u_47.get(v732)
				if v733 then
					v732 = v733.name
				end
				local v734 = v728.n
				if (tonumber(v734) or 1) > 1 then
					local v735 = v728.n
					v732 = v732 .. " x" .. tostring(v735)
				end
				v_u_40.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["wrap"] = true,
					["track"] = false,
					["parent"] = v729,
					["text"] = v732,
					["color"] = v_u_42.text,
					["size"] = UDim2.new(1, -8, 0, 24),
					["position"] = UDim2.fromOffset(4, 68)
				}).TextYAlignment = Enum.TextYAlignment.Top
				v727 = v727 + 128
			end
			v_u_737 = v_u_737 + 100
		else
			local v736 = v685.cash
			if type(v736) == "number" then
				v_u_737 = v_u_737 + 8
				v_u_40.label({
					["parent"] = nil,
					["text"] = "ADDED TO YOUR CASH",
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_632,
					["color"] = v_u_42.text2,
					["position"] = UDim2.fromOffset(0, v_u_737),
					["size"] = UDim2.new(1, 0, 0, 14)
				})
				v_u_737 = v_u_737 + 18
				v_u_40.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoL",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v_u_632,
					["text"] = "$" .. v_u_40.commas(v685.cash),
					["color"] = v_u_42.success,
					["position"] = UDim2.fromOffset(0, v_u_737),
					["size"] = UDim2.new(1, 0, 0, 30)
				})
				v_u_737 = v_u_737 + 34
			end
		end
		local v_u_737 = v_u_737 + 22
		local v738 = v_u_40.new
		local v739 = "Frame"
		local v740 = {
			["Name"] = "BuyBox",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_42.raised
		}
		local v741
		if v_u_586 and v619.side then
			v741 = UDim2.new(1, -v619.box.w, 1, -v_u_614)
		elseif v_u_628 then
			v741 = UDim2.new(0, 0, 1, -v_u_614)
		else
			v741 = UDim2.fromOffset(0, v_u_737)
		end
		v740.Position = v741
		local v742
		if v_u_586 and v619.side then
			v742 = UDim2.fromOffset(v619.box.w, v_u_614)
		else
			v742 = UDim2.new(1, 0, 0, v_u_614)
		end
		v740.Size = v742
		local v743 = v738(v739, v740, v631)
		local v744 = v_u_40.stroke
		local v745
		if p_u_575.kind == "pass" then
			v745 = v_u_42.accent
		else
			v745 = v_u_42.lineStrong
		end
		v744(v743, v745, 1, 0.4)
		if v_u_586 then
			if v619.targetInBox then
				local v746 = v_u_40.new("Frame", {
					["Name"] = "TargetBacking",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_42.bg,
					["Position"] = UDim2.fromOffset(v619.target.x, v619.target.y),
					["Size"] = UDim2.fromOffset(v619.target.w, v619.target.h)
				}, v743)
				v_u_40.stroke(v746, v_u_42.accent, 1, 0.5)
				v_u_40.label({
					["parent"] = nil,
					["name"] = "TargetLine",
					["text"] = nil,
					["style"] = "bodyStrong",
					["textSize"] = nil,
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v746,
					["text"] = v_u_618,
					["textSize"] = v_u_617,
					["color"] = v_u_42.accent,
					["position"] = UDim2.fromOffset(8, 4),
					["size"] = UDim2.new(1, -16, 1, -8)
				}).TextYAlignment = Enum.TextYAlignment.Center
			end
			v_u_158(v743, p_u_575, true, UDim2.fromOffset(v619.buy.x, v619.buy.y), Vector2.zero, nil, v619.buy.w)
		else
			local v747 = v_u_158
			local v748 = true
			local v749
			if v613 then
				v749 = UDim2.fromOffset(v_u_4.BUYBOX_PAD, v_u_4.BUYBOX_BUY_Y)
			else
				v749 = UDim2.new(0, 16, 0.5, 0)
			end
			local v750
			if v613 then
				v750 = Vector2.zero
			else
				v750 = Vector2.new(0, 0.5)
			end
			local v751
			if v613 then
				local v752 = v_u_4.buyBox
				local v753 = {
					["gift"] = true,
					["w"] = nil
				}
				local v754 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
				v753.w = math.floor(v754) - 8
				v751 = v752(v753).buy.w
			else
				v751 = nil
			end
			v747(v743, p_u_575, v748, v749, v750, v751)
		end
		if v613 then
			local v755 = p_u_575.giftCredits
			local v756 = tonumber(v755) or 0
			local v757 = v_u_40.button
			local v758 = {
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["icon"] = "heart",
				["height"] = nil,
				["width"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v743,
				["text"] = v_u_44.shared.GiveRules.giftButtonText(p_u_575, v756),
				["height"] = v_u_41.touch(40)
			}
			local v759
			if v_u_586 then
				v759 = v619.gift.w
			else
				local v760 = v_u_4.buyBox
				local v761 = {
					["gift"] = true,
					["w"] = nil,
					["giftH"] = nil
				}
				local v762 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
				v761.w = math.floor(v762) - 8
				v761.giftH = v_u_41.touch(40)
				v759 = v760(v761).gift.w
			end
			v758.width = v759
			local v763
			if v_u_586 then
				v763 = UDim2.fromOffset(v619.gift.x, v619.gift.y)
			else
				v763 = UDim2.fromOffset(v_u_4.BUYBOX_PAD, v_u_4.BUYBOX_GIFT_Y)
			end
			v758.position = v763
			function v758.onClick() -- name: onClick
				-- upvalues: (ref) v_u_92, (copy) p_u_575
				v_u_92.openGift(p_u_575)
			end
			v757(v758)
		end
		local v764 = v_u_53
		local v765 = type(v764) == "table" and v_u_53.supporter ~= true and "Any purchase earns the SUPPORTER badge." or "Thank you for supporting HUSH."
		local v766
		if v_u_49 then
			local v767 = (v_u_41.safeRefSize().X - 48 - 32) * 0.54
			if math.floor(v767) - 8 < 460 then
				v766 = true
			else
				v766 = v_u_583 ~= nil
			end
		else
			v766 = v_u_583 ~= nil
		end
		local v768 = v_u_583 ~= nil
		local v769
		if v768 then
			local v770 = v_u_41.phoneText
			v769 = type(v770) ~= "function" and 13 or v_u_41.phoneText(13, "text")
		else
			v769 = 13
		end
		local v771 = 44
		local v_u_772 = v766 and 78 or 0
		local v773 = v_u_40.label
		local v774 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false
		}
		local v775
		if v766 then
			v775 = v_u_632
		else
			v775 = v743
		end
		v774.parent = v775
		v774.text = v765
		v774.color = v_u_42.accent
		local v776
		if v766 then
			v776 = UDim2.fromOffset(0, v_u_737 - 6)
		else
			v776 = UDim2.fromOffset(296, 16)
		end
		v774.position = v776
		local v777
		if v766 then
			v777 = UDim2.new(1, 0, 0, 22)
		else
			v777 = UDim2.new(1, -312, 0, 22)
		end
		v774.size = v777
		v773(v774)
		local v778 = v_u_53
		local v779 = type(v778) == "table" and v_u_53.test == true and "Test game: the price is only a suggestion. The purchase is simulated and nothing is charged." or "The price shown is your own Robux price. The purchase itself goes through Roblox."
		if p_u_575.offSale then
			v779 = v_u_3.OFF_SALE_FINE
		elseif p_u_575.soon then
			local v780 = p_u_575.soon
			v779 = tostring(v780)
		else
			local v781
			if p_u_575.guardFull then
				local v782 = v_u_53
				if type(v782) == "table" then
					local v783 = v_u_53.guard
					if type(v783) == "table" then
						v779 = v_u_3.overLimitText(v_u_53.guard.extra, v_u_53.guard.cap)
					elseif not v613 and p_u_575.giftNo then
						v781 = p_u_575.giftNo
						v779 = tostring(v781)
					end
				elseif not v613 and p_u_575.giftNo then
					v781 = p_u_575.giftNo
					v779 = tostring(v781)
				end
			elseif not v613 and p_u_575.giftNo then
				v781 = p_u_575.giftNo
				v779 = tostring(v781)
			end
		end
		if p_u_575.unlockFull then
			local v784 = p_u_575.blurb or v_u_3.UNLOCK_FULL
			v779 = tostring(v784)
		elseif v582 ~= nil then
			v779 = v_u_45.fineFor(v582)
		end
		if v768 then
			local v785 = v_u_45.lineCount(v779, v_u_667 - 16, v769)
			local v786 = v769 * 1.3
			v771 = v785 * math.ceil(v786) + 12
			v_u_772 = 28 + v771 + 8
		end
		local v787 = p_u_575.rushIdle and "Start a construction in the Hideout first. The rush finishes everything that is being built at that moment." or v779
		local v788 = p_u_575.rushCredit
		if (tonumber(v788) or 0) > 0 then
			v787 = ("You hold %d rush voucher%s: your next construction finishes at once."):format(p_u_575.rushCredit, p_u_575.rushCredit == 1 and "" or "s")
		end
		if v766 then
			v743 = v_u_632
		end
		if v768 then
			v743 = v_u_40.new("Frame", {
				["Name"] = "FineBacking",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_42.bg,
				["Position"] = UDim2.fromOffset(0, v_u_737 + 20),
				["Size"] = UDim2.new(1, 0, 0, v771)
			}, v_u_632)
			v_u_40.stroke(v743, v_u_42.line, 1, 0.35)
		end
		local v789 = v_u_40.label
		local v790 = {
			["parent"] = nil,
			["name"] = "FineText",
			["text"] = nil,
			["style"] = nil,
			["textSize"] = nil,
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v743,
			["text"] = v787,
			["style"] = v768 and "small" or "micro"
		}
		if not v768 then
			v769 = nil
		end
		v790.textSize = v769
		local v791
		if v768 then
			v791 = v_u_42.text2
		else
			v791 = v_u_42.muted
		end
		v790.color = v791
		local v792
		if v768 then
			v792 = UDim2.fromOffset(8, 6)
		elseif v766 then
			v792 = UDim2.fromOffset(0, v_u_737 + 18)
		else
			v792 = UDim2.fromOffset(296, 42)
		end
		v790.position = v792
		local v793
		if v768 then
			v793 = UDim2.new(1, -16, 1, -12)
		elseif v766 then
			v793 = UDim2.new(1, 0, 0, 44)
		else
			v793 = UDim2.new(1, -312, 0, 36)
		end
		v790.size = v793
		v789(v790).TextYAlignment = Enum.TextYAlignment.Top
		if p_u_575.category == "CASH" then
			local v794 = v_u_40.label
			local v795 = {
				["parent"] = nil,
				["name"] = "PveNote",
				["text"] = "Cash packs are for PVE mode only. The PVP mode does not sell cash.",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_632,
				["color"] = v_u_42.accent
			}
			local v796 = UDim2.fromOffset
			local v797 = 0
			local v798
			if v_u_628 then
				v798 = v_u_737 - 14 + v_u_772
			else
				v798 = v_u_737 + v_u_614 + 8
			end
			v795.position = v796(v797, v798)
			v795.size = UDim2.new(1, 0, 0, 34)
			v794(v795)
		end
		local v_u_799 = 0
		local function v804()
			-- upvalues: (ref) v_u_799, (ref) v_u_44, (ref) p_u_38, (ref) v_u_632, (copy) v_u_628, (ref) v_u_737, (ref) v_u_772, (ref) v_u_614
			local v800 = v_u_44.lib.MenuPaidQueue.detailNote
			local v801 = p_u_38
			local v802 = v_u_632
			local v803
			if v_u_628 then
				v803 = v_u_737 - 14 + v_u_772
			else
				v803 = v_u_737 + v_u_614 + 8
			end
			v_u_799 = v800(v801, v802, v803)
		end
		pcall(v804)
		if v_u_628 then
			v_u_632.CanvasSize = UDim2.fromOffset(0, v_u_737 - 14 + v_u_772 + (p_u_575.category == "CASH" and 42 or 0) + v_u_799)
		end
	end
	local function v_u_817() -- name: drawHead
		-- upvalues: (ref) v_u_53, (copy) v_u_63, (ref) v_u_3, (copy) v_u_42, (copy) v_u_65
		local v806 = v_u_53
		local v807
		if type(v806) == "table" then
			v807 = v_u_53.supporter == true
		else
			v807 = false
		end
		v_u_63.Text = v_u_3.headLine(v_u_53)
		v_u_63.TextColor3 = v_u_42.text2
		local v808 = v_u_53
		local v809, v810, v811, v812, v813
		if type(v808) == "table" then
			local v814 = v_u_53.gifted
			if type(v814) == "table" and #v_u_53.gifted > 0 then
				local v815 = v_u_63
				local v816 = v_u_53.gifted[#v_u_53.gifted]
				v815.Text = tostring(v816)
				v_u_63.TextColor3 = v_u_42.success
				v_u_65.Text = v807 and "SUPPORTER. Thank you." or "Any purchase earns the SUPPORTER badge."
				v809 = v_u_65
				if v807 then
					v810 = v_u_42.accent
				else
					v810 = v_u_42.text2
				end
				v809.TextColor3 = v810
				v811 = v_u_53
				if type(v811) == "table" and v_u_53.test == true then
					v_u_65.Text = "TEST GAME. Nothing is charged."
					v_u_65.TextColor3 = v_u_42.accent
				end
			else
				v812 = v_u_53
				if type(v812) == "table" then
					v813 = v_u_53.note
					if type(v813) == "string" and v_u_53.note ~= "" then
						v_u_63.Text = v_u_53.note
						v_u_63.TextColor3 = v_u_42.accent
					end
				end
				v_u_65.Text = v807 and "SUPPORTER. Thank you." or "Any purchase earns the SUPPORTER badge."
				v809 = v_u_65
				if v807 then
					v810 = v_u_42.accent
				else
					v810 = v_u_42.text2
				end
				v809.TextColor3 = v810
				v811 = v_u_53
				if type(v811) == "table" and v_u_53.test == true then
					v_u_65.Text = "TEST GAME. Nothing is charged."
					v_u_65.TextColor3 = v_u_42.accent
				end
			end
		else
			v812 = v_u_53
			if type(v812) == "table" then
				v813 = v_u_53.note
				if type(v813) == "string" and v_u_53.note ~= "" then
					v_u_63.Text = v_u_53.note
					v_u_63.TextColor3 = v_u_42.accent
				end
			end
			v_u_65.Text = v807 and "SUPPORTER. Thank you." or "Any purchase earns the SUPPORTER badge."
			v809 = v_u_65
			if v807 then
				v810 = v_u_42.accent
			else
				v810 = v_u_42.text2
			end
			v809.TextColor3 = v810
			v811 = v_u_53
			if type(v811) == "table" and v_u_53.test == true then
				v_u_65.Text = "TEST GAME. Nothing is charged."
				v_u_65.TextColor3 = v_u_42.accent
			end
			return
		end
	end
	function v_u_52.draw() -- name: draw
		-- upvalues: (ref) v_u_53, (ref) v_u_30, (copy) v_u_817, (ref) v_u_54, (ref) v_u_92, (ref) v_u_55, (ref) v_u_59, (ref) v_u_60, (copy) v_u_49, (copy) v_u_62, (copy) v_u_69, (ref) v_u_75, (copy) v_u_71, (copy) v_u_72, (copy) v_u_74, (copy) v_u_73, (copy) v_u_41, (copy) v_u_805, (copy) v_u_574, (ref) v_u_58, (ref) v_u_37, (copy) v_u_91
		local v818 = v_u_53
		if type(v818) == "table" then
			local v819 = v_u_53.products
			if type(v819) == "table" then
				for _, v820 in v_u_53.products do
					local v821 = v_u_30
					local v822 = v820.robloxId
					local v823 = tonumber(v822) or 0
					local v824 = v821[tostring(v823)]
					if not (v824 and v824.price) then
						continue
					end
					v820.price = v824.price
					v820.ownChecked = true
				end
			end
		end
		v_u_817()
		if v_u_54 == "DONATE" and v_u_92 then
			v_u_55 = nil
			v_u_59 = {}
			v_u_60 = {}
			local v825 = v_u_49 and false
			v_u_62.Visible = not v825
			v_u_69.Visible = not v825
			v_u_75 = v825 and 0 or v_u_71
			v_u_72.Position = UDim2.fromOffset(0, v_u_75)
			v_u_72.Size = UDim2.new(1, 0, 1, -v_u_75)
			v_u_74.Visible = false
			v_u_73.Visible = true
			v_u_92.showDonate(v_u_73, v_u_41.safeRefSize().X - 48 - 32 - 14)
		else
			local v826 = v_u_55
			local v827 = v_u_53
			local v830
			if type(v827) == "table" then
				local v829 = v_u_53.products
				if type(v829) == "table" and v826 then
					for _, v830 in v_u_53.products do
						if v830.id ~= v826 then
							continue
						end
					end
					v830 = nil
				else
					v830 = nil
				end
			else
				v830 = nil
			end
			if v830 then
				local v831 = v_u_49 and true
				v_u_62.Visible = not v831
				v_u_69.Visible = not v831
				v_u_75 = v831 and 0 or v_u_71
				v_u_72.Position = UDim2.fromOffset(0, v_u_75)
				v_u_72.Size = UDim2.new(1, 0, 1, -v_u_75)
				v_u_805(v830)
			else
				v_u_55 = nil
				local v832 = v_u_49 and false
				v_u_62.Visible = not v832
				v_u_69.Visible = not v832
				v_u_75 = v832 and 0 or v_u_71
				v_u_72.Position = UDim2.fromOffset(0, v_u_75)
				v_u_72.Size = UDim2.new(1, 0, 1, -v_u_75)
				v_u_574()
			end
		end
		local v833 = v_u_53
		if type(v833) == "table" then
			local v834 = v_u_53.products
			if type(v834) == "table" then
				for v_u_835, v_u_836 in v_u_53.products do
					task.spawn(function()
						-- upvalues: (ref) v_u_58, (copy) v_u_836, (ref) v_u_30, (copy) v_u_835, (ref) v_u_37, (ref) v_u_91
						if v_u_58 then
							local v837 = v_u_836.robloxId
							local v838 = tonumber(v837)
							if v838 and v838 > 0 then
								local v839 = tostring(v838)
								local v840 = v_u_30[v839]
								if not v840 or os.clock() - v840.t > 120 then
									task.wait((v_u_835 - 1) * 0.05)
									local v841 = v_u_37
									local v842 = v_u_836.kind
									local v843 = tostring(v842)
									local v844, v845 = pcall(v841, v838, v843)
									v840 = {}
									local v846
									if v844 and type(v845) == "table" then
										local v847 = v845.PriceInRobux
										v846 = tonumber(v847)
									else
										v846 = nil
									end
									v840.price = v846
									v840.t = os.clock()
									v_u_30[v839] = v840
								end
								if v_u_58 and v840.price then
									v_u_836.ownChecked = true
								end
								if v_u_58 and v840.price then
									local v848 = v840.price
									local v849 = v_u_836.price
									if v848 ~= tonumber(v849) then
										v_u_836.price = v840.price
										v_u_91(v_u_836)
									end
								end
							end
						end
					end)
				end
			end
		end
	end
	local function v_u_855() -- name: openSaleFilter
		-- upvalues: (ref) v_u_56, (ref) v_u_55, (ref) v_u_259, (ref) v_u_53, (ref) v_u_54, (copy) v_u_70, (copy) v_u_52
		v_u_56 = nil
		v_u_55 = nil
		local v850 = false
		if v_u_259 ~= nil then
			local v851 = v_u_53
			if type(v851) == "table" then
				local v852 = v_u_259.activeOf
				local v853 = v_u_53.products
				local v854
				v850, v854 = pcall(v852, v853)
				if v850 then
					if type(v854) == "table" then
						v850 = #v854 > 0
					else
						v850 = false
					end
				end
			end
		end
		v_u_54 = v850 and "SALE" or "all"
		v_u_70.select(v_u_54, true)
		v_u_52.draw()
	end
	function v_u_52.open(p856) -- name: open
		-- upvalues: (copy) v_u_70, (ref) v_u_53, (copy) p_u_38, (ref) v_u_56, (ref) v_u_55, (ref) v_u_54, (copy) v_u_52, (copy) v_u_855
		if p856 == "DONATE" then
			v_u_70.select("DONATE")
			return
		elseif p856 == "CASH" then
			local v857 = v_u_53
			if type(v857) ~= "table" then
				local v_u_858 = true
				local function v859()
					-- upvalues: (ref) v_u_858, (ref) p_u_38
					v_u_858 = p_u_38.config.flag("CashPacks") ~= false
				end
				pcall(v859)
				if v_u_858 then
					v_u_56 = "CASH"
					return
				end
			end
			v_u_56 = nil
			v_u_55 = nil
			local v_u_860 = true
			local function v861()
				-- upvalues: (ref) v_u_860, (ref) p_u_38
				v_u_860 = p_u_38.config.flag("CashPacks") ~= false
			end
			pcall(v861)
			local v862
			if v_u_860 then
				local v863 = v_u_53
				if type(v863) == "table" then
					local v864 = v_u_53.products
					if type(v864) == "table" then
						for _, v865 in v_u_53.products do
							if v865.category ~= "CASH" then
								continue
							end
							v862 = true
						end
						v862 = false
					else
						v862 = false
					end
				else
					v862 = false
				end
			else
				v862 = false
			end
			if v862 then
				v_u_54 = "CASH"
				v_u_70.select("CASH", true)
			else
				v_u_54 = "all"
				v_u_70.select("all", true)
			end
			v_u_52.draw()
			return
		elseif p856 == "SALE" then
			local v866 = v_u_53
			if type(v866) == "table" then
				v_u_855()
			else
				v_u_56 = "SALE"
			end
		else
			local v867 = v_u_53
			if type(v867) == "table" then
				local v868 = v_u_53
				local v871
				if type(v868) == "table" then
					local v870 = v_u_53.products
					if type(v870) == "table" and p856 then
						for _, v871 in v_u_53.products do
							if v871.id ~= p856 then
								continue
							end
						end
						v871 = nil
					else
						v871 = nil
					end
				else
					v871 = nil
				end
				if v871 then
					if v_u_54 == "DONATE" then
						v_u_54 = "all"
						v_u_70.select("all", true)
					end
					v_u_55 = p856
					v_u_52.draw()
					return
				end
			end
			v_u_56 = p856
			return
		end
	end
	v_u_52.api.open = v_u_52.open
	function v_u_52.api.gift(p872)
		-- upvalues: (ref) v_u_53, (ref) v_u_92
		local v873 = v_u_53
		local v876
		if type(v873) == "table" then
			local v875 = v_u_53.products
			if type(v875) == "table" and p872 then
				for _, v876 in v_u_53.products do
					if v876.id ~= p872 then
						continue
					end
				end
				v876 = nil
			else
				v876 = nil
			end
		else
			v876 = nil
		end
		if v876 and v_u_92 then
			v_u_92.openGift(v876)
		end
	end
	function v_u_52.show() -- name: show
		-- upvalues: (ref) v_u_242, (ref) v_u_57, (copy) p_u_38, (ref) v_u_53, (ref) v_u_241, (copy) v_u_44, (copy) v_u_52, (ref) v_u_58, (copy) p_u_39, (ref) v_u_56, (ref) v_u_55, (ref) v_u_54, (copy) v_u_70, (copy) v_u_855, (copy) v_u_63
		v_u_242 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_57, (ref) p_u_38, (ref) v_u_53, (ref) v_u_241, (ref) v_u_44, (ref) v_u_52, (ref) v_u_58, (ref) p_u_39, (ref) v_u_56, (ref) v_u_55, (ref) v_u_54, (ref) v_u_70, (ref) v_u_855
			v_u_57 = false
			local v877 = p_u_38.fetch("store", nil, 120)
			v_u_57 = v877 == nil
			v_u_53 = v877 or v_u_53
			if v_u_241 and v877 ~= nil then
				local v878 = p_u_38.cache.store
				local v879 = v_u_241.setView
				local v880 = v_u_53
				local v881
				if type(v878) == "table" then
					v881 = v878.at
				else
					v881 = nil
				end
				v879(v880, v881)
			end
			local function v891()
				-- upvalues: (ref) v_u_44, (ref) v_u_53, (ref) p_u_38, (ref) v_u_52
				local v882 = v_u_44.lib.MenuStoreFeaturedDot
				if v882 ~= nil then
					local v883 = v_u_53
					if type(v883) == "table" then
						local v884 = p_u_38.cache.store
						local v885 = v882.onStoreView
						local v886 = p_u_38
						local v887 = v_u_53
						local v888
						if type(v884) == "table" then
							v888 = v884.at
						else
							v888 = nil
						end
						local v889 = v885(v886, v887, v888)
						v_u_52.newFeatured = v_u_52.newFeatured or {}
						for v890 in v889 do
							v_u_52.newFeatured[v890] = true
						end
					end
				end
			end
			pcall(v891)
			if v_u_58 and p_u_39.Parent then
				if v_u_56 == "CASH" then
					v_u_56 = nil
					v_u_55 = nil
					local v_u_892 = true
					local function v893()
						-- upvalues: (ref) v_u_892, (ref) p_u_38
						v_u_892 = p_u_38.config.flag("CashPacks") ~= false
					end
					pcall(v893)
					local v894
					if v_u_892 then
						local v895 = v_u_53
						if type(v895) == "table" then
							local v896 = v_u_53.products
							if type(v896) == "table" then
								for _, v897 in v_u_53.products do
									if v897.category ~= "CASH" then
										continue
									end
									v894 = true
								end
								v894 = false
							else
								v894 = false
							end
						else
							v894 = false
						end
					else
						v894 = false
					end
					if v894 then
						v_u_54 = "CASH"
						v_u_70.select("CASH", true)
					else
						v_u_54 = "all"
						v_u_70.select("all", true)
					end
					v_u_52.draw()
					return
				end
				if v_u_56 == "SALE" then
					v_u_855()
					return
				end
				if v_u_56 then
					local v898 = v_u_56
					local v899 = v_u_53
					local v902
					if type(v899) == "table" then
						local v901 = v_u_53.products
						if type(v901) == "table" and v898 then
							for _, v902 in v_u_53.products do
								if v902.id ~= v898 then
									continue
								end
							end
							v902 = nil
						else
							v902 = nil
						end
					else
						v902 = nil
					end
					if v902 then
						if v_u_54 == "DONATE" then
							v_u_54 = "all"
							v_u_70.select("all", true)
						end
						v_u_55 = v_u_56
					end
				end
				v_u_56 = nil
				v_u_52.draw()
			end
		end)
		v_u_52.draw()
		local v_u_903 = nil
		local function v904()
			-- upvalues: (ref) v_u_903, (ref) p_u_38
			v_u_903 = p_u_38.cctx.lib.MenuTipOnce
		end
		pcall(v904)
		if v_u_903 then
			local v905 = v_u_903.show
			if type(v905) == "function" then
				local v906 = v_u_903.show
				local v907 = p_u_38
				local v909 = {
					["host"] = p_u_39,
					["target"] = function() -- name: target
						-- upvalues: (ref) v_u_63
						return v_u_63
					end,
					["active"] = function() -- name: active
						-- upvalues: (ref) v_u_58, (ref) v_u_242, (ref) p_u_39
						local v908 = v_u_58 and v_u_242
						if v908 then
							v908 = p_u_39.Parent ~= nil
						end
						return v908
					end,
					["sides"] = { "below", "right" }
				}
				pcall(v906, v907, "paidrestrict", v909)
			end
		end
	end
	function v_u_52.hide() -- name: hide
		-- upvalues: (ref) v_u_242, (copy) v_u_52
		v_u_242 = false
		v_u_52.newFeatured = nil
	end
	function v_u_52.refresh(p910, p911) -- name: refresh
		-- upvalues: (ref) v_u_92, (copy) p_u_38, (copy) v_u_52
		if p910 == "result" and type(p911) == "table" then
			if v_u_92 then
				v_u_92.onResult(p911)
			end
			if p911.op == "storeGrant" then
				p_u_38.invalidate("store")
				v_u_52.show()
			end
		end
	end
	local v912 = v_u_1.LocalPlayer
	local v_u_913, v_u_914
	if v912 then
		local function v915() -- name: again
			-- upvalues: (copy) p_u_38, (ref) v_u_58, (ref) v_u_242, (copy) v_u_52
			p_u_38.invalidate("store")
			if v_u_58 and v_u_242 then
				v_u_52.show()
			end
		end
		v_u_913 = v912:GetAttributeChangedSignal("PaidRandomOk"):Connect(v915)
		v_u_914 = v912:GetAttributeChangedSignal("PaidTrading"):Connect(v915)
	else
		v_u_913 = nil
		v_u_914 = nil
	end
	local v_u_916 = nil
	task.spawn(function()
		-- upvalues: (copy) p_u_38, (ref) v_u_58, (ref) v_u_242, (copy) v_u_52, (ref) v_u_916
		local v_u_917 = true
		local function v918()
			-- upvalues: (ref) v_u_917, (ref) p_u_38
			v_u_917 = p_u_38.config.flag("CashPacks") ~= false
		end
		pcall(v918)
		local v_u_919 = v_u_917
		local function v922()
			-- upvalues: (ref) p_u_38, (ref) v_u_919, (ref) v_u_58, (ref) v_u_242, (ref) v_u_52
			return p_u_38.config.watchFlag("CashPacks", function(p920)
				-- upvalues: (ref) v_u_919, (ref) p_u_38, (ref) v_u_58, (ref) v_u_242, (ref) v_u_52
				local v921 = p920 ~= false
				if v921 ~= v_u_919 then
					v_u_919 = v921
					p_u_38.invalidate("store")
					if v_u_58 and v_u_242 then
						v_u_52.show()
					end
				end
			end)
		end
		local v923, v924 = pcall(v922)
		if v923 and v924 then
			if v_u_58 then
				v_u_916 = v924
			else
				v924:Disconnect()
			end
		end
	end)
	local v_u_925 = nil
	task.spawn(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_925, (copy) p_u_38, (ref) v_u_242, (copy) v_u_52
		local v_u_926 = game:GetService("ReplicatedStorage"):WaitForChild("Config", 30)
		if v_u_926 ~= nil and v_u_58 then
			local v_u_927 = v_u_926:GetAttribute("StoreSaleV")
			v_u_925 = v_u_926:GetAttributeChangedSignal("StoreSaleV"):Connect(function()
				-- upvalues: (copy) v_u_926, (ref) v_u_927, (ref) v_u_58, (ref) p_u_38, (ref) v_u_242, (ref) v_u_52
				local v928 = v_u_926:GetAttribute("StoreSaleV")
				if v928 ~= v_u_927 then
					v_u_927 = v928
					task.delay(Random.new():NextNumber(2, 20), function()
						-- upvalues: (ref) v_u_58, (ref) p_u_38, (ref) v_u_242, (ref) v_u_52
						if v_u_58 then
							p_u_38.invalidate("store")
							if v_u_242 then
								v_u_52.show()
							end
						end
					end)
				end
			end)
		end
	end)
	function v_u_52.destroy() -- name: destroy
		-- upvalues: (ref) v_u_58, (ref) v_u_925, (ref) v_u_259, (ref) v_u_916, (ref) v_u_913, (ref) v_u_914, (ref) v_u_241, (ref) v_u_92
		v_u_58 = false
		if v_u_925 then
			v_u_925:Disconnect()
		end
		if v_u_259 then
			v_u_259.destroy()
		end
		if v_u_916 then
			v_u_916:Disconnect()
		end
		if v_u_913 then
			v_u_913:Disconnect()
		end
		if v_u_914 then
			v_u_914:Disconnect()
		end
		if v_u_241 then
			v_u_241.destroy()
		end
		if v_u_92 then
			v_u_92.destroy()
		end
	end
	return v_u_52
end
return v_u_3