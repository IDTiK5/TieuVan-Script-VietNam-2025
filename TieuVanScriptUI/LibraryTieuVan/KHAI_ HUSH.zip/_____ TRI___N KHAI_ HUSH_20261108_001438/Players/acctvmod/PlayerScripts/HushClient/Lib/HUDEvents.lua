-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDEvents

local v_u_1 = game:GetService("Players")
local v_u_2
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_2 = require(script.Parent.ServerClock)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = {}
local v_u_4 = {}
local v_u_5 = {
	["parachute"] = "Airdrop",
	["heli"] = "Air traffic",
	["flare"] = "Evacuation",
	["truck"] = "Evacuation",
	["horde"] = "Horde",
	["siren"] = "Raid clock"
}
function v3.new(p_u_6) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_5, (copy) v_u_4
	local v_u_7 = p_u_6.UI
	local v_u_8 = p_u_6.Theme
	local v_u_9 = v_u_8.color
	local v_u_10 = p_u_6.cctx
	local v_u_11 = v_u_1.LocalPlayer
	local v_u_12 = {}
	local v_u_13 = p_u_6.char
	local v_u_14 = false
	local v_u_15 = true
	local v_u_16 = nil
	local function v17()
		-- upvalues: (ref) v_u_16, (copy) v_u_10
		v_u_16 = v_u_10.lib.MapData
	end
	pcall(v17)
	local v_u_18 = nil
	local function v19()
		-- upvalues: (ref) v_u_18, (copy) v_u_10
		v_u_18 = v_u_10.lib.KestrelMapData
	end
	pcall(v19)
	local v_u_20 = nil
	local function v21()
		-- upvalues: (ref) v_u_20, (copy) v_u_10
		v_u_20 = v_u_10.lib.AshgroveMapData
	end
	pcall(v21)
	local v_u_22 = nil
	local function v23()
		-- upvalues: (ref) v_u_22, (copy) v_u_10
		v_u_22 = v_u_10.lib.OvertureMapData
	end
	pcall(v23)
	local v_u_24 = nil
	local function v25()
		-- upvalues: (ref) v_u_24, (copy) v_u_10
		v_u_24 = v_u_10.lib.TokyoMapData
	end
	pcall(v25)
	local v_u_26 = nil
	local function v27()
		-- upvalues: (ref) v_u_26, (copy) v_u_10
		v_u_26 = v_u_10.shared.Extracts
	end
	pcall(v27)
	local v_u_28 = nil
	local v_u_29 = nil
	local function v30()
		-- upvalues: (ref) v_u_28, (copy) v_u_10, (ref) v_u_29
		v_u_28 = v_u_10.lib.LiftClientRules
		v_u_29 = v_u_10.lib.LiftHeliFx
	end
	pcall(v30)
	local v_u_31 = nil
	local function v32()
		-- upvalues: (ref) v_u_31, (copy) v_u_10
		v_u_31 = v_u_10.lib.SquadMarkersEdge
	end
	pcall(v32)
	local v_u_33 = -1000000000
	local v_u_34 = true
	local function v_u_43() -- name: skyOk
		-- upvalues: (ref) v_u_33, (ref) v_u_34, (copy) v_u_10
		local v35 = os.clock()
		if v35 - v_u_33 < 2 then
			return v_u_34
		end
		v_u_33 = v35
		local function v40()
			-- upvalues: (ref) v_u_10
			local v36 = v_u_10.shared.AirdropRules
			local v37 = v_u_10.runtime
			if v37 then
				v37 = v_u_10.runtime:GetAttribute("MapId")
			end
			local v38 = v_u_10.shared.MapInfo.fromRuntime()
			local v39 = v36.skyOk
			if type(v37) ~= "string" or v37 == "" then
				if v38 then
					v37 = v38.id or v38.name
				else
					v37 = v38
				end
			end
			if v38 then
				v38 = v38.underground
			end
			return v39(v37, v38)
		end
		local v41, v42 = pcall(v40)
		v_u_34 = (not v41 or type(v42) ~= "boolean") and true or v42
		return v_u_34
	end
	local function v_u_67(p44) -- name: bearing
		-- upvalues: (ref) v_u_13, (copy) v_u_11
		local v45 = v_u_13 or v_u_11.Character
		if v45 then
			v45 = v45:FindFirstChild("HumanoidRootPart")
		end
		local v46
		if v45 then
			v46 = v45.Position
		else
			local v47 = workspace.CurrentCamera
			v46 = v47 and v47.Focus.Position or nil
		end
		if not v46 then
			return nil, nil
		end
		local v48 = p44 - v46
		local v49 = v48.X
		local v50 = v48.Z
		local v51 = Vector3.new(v49, 0, v50)
		local v52 = v51.Magnitude * 0.28
		local v53 = workspace.CurrentCamera
		local v54 = nil
		if v53 and v51.Magnitude > 0.1 then
			local v55 = v53.CFrame.LookVector
			local v56 = v55.X
			local v57 = v55.Z
			local v58 = Vector3.new(v56, 0, v57)
			if v58.Magnitude > 0.01 then
				local v59 = v58.Unit
				local v60 = -v59.Z
				local v61 = v59.X
				local v62 = Vector3.new(v60, 0, v61)
				local v63 = v51.Unit
				local v64 = v63:Dot(v62)
				local v65 = v63:Dot(v59)
				local v66 = math.atan2(v64, v65)
				v54 = math.deg(v66)
			end
		end
		return v52, v54
	end
	local function v_u_69() -- name: raidMapId
		local v68 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
		if v68 then
			v68 = v68:FindFirstChild("Raid")
		end
		if v68 then
			v68 = v68:GetAttribute("MapId")
		end
		return (type(v68) ~= "string" or v68 == "") and "stillwater" or v68
	end
	local function v_u_78(p70) -- name: placeOf
		-- upvalues: (copy) v_u_69, (ref) v_u_16, (ref) v_u_18, (ref) v_u_20, (ref) v_u_22, (ref) v_u_24
		local v71 = v_u_69()
		local v72
		if v71 == "stillwater" then
			v72 = v_u_16
		elseif v71 == "kestrel" then
			v72 = v_u_18
		elseif v71 == "unknown5" then
			v72 = v_u_20
		elseif v71 == "overture" then
			v72 = v_u_22
		elseif v71 == "tokyo" then
			v72 = v_u_24
		else
			v72 = nil
		end
		if v72 and v72.nearestLandmark then
			local v73 = v72.nearestLandmark
			local v74 = p70.X
			local v75 = p70.Z
			local v76, v77 = pcall(v73, v74, v75)
			if v76 and type(v77) == "string" then
				return v77
			end
		end
		return nil
	end
	local v_u_79 = {}
	local v_u_80 = {}
	local function v_u_142() -- name: collect
		-- upvalues: (copy) p_u_6, (copy) v_u_10, (ref) v_u_2, (copy) v_u_9, (copy) v_u_43, (copy) v_u_79, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (copy) v_u_78
		local v81 = {}
		local v82 = p_u_6.raid
		local v83 = not (v82 and v82.Parent) and v_u_10.runtime
		if v83 then
			v83 = v83:FindFirstChild("Raid")
		end
		if not v83 then
			return v81
		end
		local v84 = v_u_2.now()
		local v85 = v83:FindFirstChild("Events")
		if v85 then
			for _, v_u_86 in v85:GetChildren() do
				local v87 = v_u_86:GetAttribute("Kind")
				local v88 = tonumber(v_u_86:GetAttribute("StartAt")) or v84
				local v89 = tonumber(v_u_86:GetAttribute("EndAt")) or v88 + 120
				if v87 == "helicopter" then
					if v84 >= v89 then
						continue
					end
					local v90 = {
						["key"] = nil,
						["kind"] = nil,
						["icon"] = "heli",
						["short"] = "Helicopter",
						["detail"] = nil,
						["arrow"] = false,
						["edge"] = false,
						["color"] = nil,
						["order"] = 5,
						["startAt"] = nil,
						["key"] = v_u_86.Name,
						["kind"] = v87
					}
					local v91 = v89 - v84 + 0.5
					local v92 = math.floor(v91)
					local v93 = math.max(0, v92)
					v90.detail = string.format("%d:%02d", v93 // 60, v93 % 60)
					v90.color = v_u_9.accent
					v90.startAt = v88
					table.insert(v81, v90)
				elseif v87 == "airdrop" and v_u_43() then
					local v94 = v_u_86:GetAttribute("Position")
					local v95 = tonumber(v_u_86:GetAttribute("LandAt")) or v88
					local v96 = v_u_86:GetAttribute("Looted") == true
					local v97 = true
					local v98
					if v96 then
						local v99 = v_u_79[v_u_86]
						if not v99 then
							v99 = os.clock()
							v_u_79[v_u_86] = v99
						end
						v97 = os.clock() - v99 < 10
						v98 = "emptied"
					elseif v84 < v95 then
						local v100 = v95 - v84 + 0.5
						local v101 = math.floor(v100)
						local v102 = math.max(0, v101)
						v98 = "lands " .. string.format("%d:%02d", v102 // 60, v102 % 60)
					elseif v84 < v89 then
						local v103 = v89 - v84 + 0.5
						local v104 = math.floor(v103)
						local v105 = math.max(0, v104)
						v98 = "smoke " .. string.format("%d:%02d", v105 // 60, v105 % 60)
					else
						v98 = "loot left"
					end
					if not v97 or typeof(v94) ~= "Vector3" then
						continue
					end
					local v106 = {
						["key"] = nil,
						["kind"] = nil,
						["icon"] = "parachute",
						["short"] = "Supply drop",
						["detail"] = nil,
						["pos"] = nil,
						["arrow"] = nil,
						["edge"] = nil,
						["color"] = nil,
						["order"] = 3,
						["startAt"] = nil,
						["key"] = v_u_86.Name,
						["kind"] = v87,
						["detail"] = v98,
						["pos"] = v94,
						["arrow"] = not v96,
						["edge"] = not v96
					}
					local v107
					if v96 then
						v107 = v_u_9.muted
					else
						v107 = v_u_9.danger
					end
					v106.color = v107
					v106.startAt = v88
					table.insert(v81, v106)
				elseif v87 == "lift_heli" then
					if not (v_u_28 and v_u_29) then
						continue
					end
					local v109 = v_u_28.fromGetter(function(p108)
						-- upvalues: (copy) v_u_86
						return v_u_86:GetAttribute(p108)
					end)
					local v110
					if v109 then
						v110 = v_u_28.chipEntry(v109, v84, v_u_29.me())
					else
						v110 = nil
					end
					if not v110 then
						continue
					end
					local v111 = {
						["key"] = nil,
						["kind"] = nil,
						["icon"] = "heli",
						["short"] = nil,
						["detail"] = nil,
						["pos"] = nil,
						["arrow"] = true,
						["edge"] = false,
						["color"] = nil,
						["order"] = 0,
						["startAt"] = nil,
						["key"] = v_u_86.Name,
						["kind"] = v87,
						["short"] = v110.short,
						["detail"] = v110.detail
					}
					local v112 = v110.pos.x
					local v113 = v110.pos.y
					local v114 = v110.pos.z
					v111.pos = Vector3.new(v112, v113, v114)
					local v115
					if v110.tone == "danger" then
						v115 = v_u_9.danger
					elseif v110.tone == "muted" then
						v115 = v_u_9.muted
					else
						v115 = Color3.fromRGB(168, 96, 255)
					end
					v111.color = v115
					v111.startAt = v88
					table.insert(v81, v111)
				else
					if v87 ~= "horde" or (v84 >= v89 or not v_u_26) then
						continue
					end
					local v116 = v_u_26.decodePath((v_u_86:GetAttribute("Path")))
					local v117 = tonumber(v_u_86:GetAttribute("Speed")) or 6.5
					local v118
					if #v116 > 0 then
						v118 = v_u_26.pathSample(v116, (v84 - v88) * v117)
					else
						v118 = nil
					end
					local v119
					if v118 then
						v119 = v_u_78(v118)
					else
						v119 = nil
					end
					local v120 = {
						["key"] = nil,
						["kind"] = nil,
						["icon"] = "horde",
						["short"] = "Horde",
						["detail"] = nil,
						["arrow"] = false,
						["edge"] = false,
						["color"] = nil,
						["order"] = 4,
						["startAt"] = nil,
						["place"] = nil,
						["key"] = v_u_86.Name,
						["kind"] = v87,
						["detail"] = not v119 and "on the move" or "near " .. v119,
						["color"] = v_u_9.danger,
						["startAt"] = v88,
						["place"] = v119
					}
					table.insert(v81, v120)
				end
			end
		end
		local v121 = v83:FindFirstChild("Extracts")
		if v121 then
			for _, v122 in v121:GetChildren() do
				if not v122:IsA("BasePart") then
					continue
				end
				local v123 = v122:GetAttribute("ExtractId") or v122.Name
				local v124 = tostring(v123)
				local v125 = v122:GetAttribute("State")
				local v126 = (tonumber(v122:GetAttribute("StateEndsAt")) or 0) - v84
				local v127 = math.max(0, v126)
				local v128 = v122:GetAttribute("Kind")
				if (v124 == "helipad" or v128 == "Heli") and (v125 == "inbound" or v125 == "boarding") then
					local v129 = {
						["key"] = "x_helipad",
						["kind"] = "extract_heli",
						["icon"] = "heli",
						["short"] = "Evac heli",
						["detail"] = nil,
						["pos"] = nil,
						["zone"] = nil,
						["arrow"] = true,
						["edge"] = true,
						["color"] = nil,
						["order"] = 1,
						["startAt"] = nil
					}
					local v130 = v125 == "inbound" and "Inbound " or "Boarding "
					local v131 = v127 + 0.5
					local v132 = math.floor(v131)
					local v133 = math.max(0, v132)
					v129.detail = v130 .. string.format("%d:%02d", v133 // 60, v133 % 60)
					v129.pos = v122.Position
					v129.zone = v122
					local v134
					if v125 == "boarding" then
						v134 = v_u_9.success
					else
						v134 = v_u_9.info
					end
					v129.color = v134
					v129.startAt = v84 - 1
					table.insert(v81, v129)
				else
					if v124 ~= "pickup" and v128 ~= "Vehicle" or v125 ~= "running" then
						continue
					end
					local v135 = tonumber(v122:GetAttribute("Seats")) or 0
					local v136 = {
						["key"] = "x_pickup",
						["kind"] = "pickup",
						["icon"] = "truck",
						["short"] = "Pickup",
						["detail"] = nil,
						["pos"] = nil,
						["zone"] = nil,
						["arrow"] = true,
						["edge"] = false,
						["color"] = nil,
						["order"] = 2,
						["startAt"] = nil
					}
					local v137 = v127 + 0.5
					local v138 = math.floor(v137)
					local v139 = math.max(0, v138)
					v136.detail = string.format("%d:%02d", v139 // 60, v139 % 60) .. "  \194\183  " .. v135 .. (v135 == 1 and " seat" or " seats")
					v136.pos = v122.Position
					v136.zone = v122
					v136.color = v_u_9.success
					v136.startAt = v84 - 1
					table.insert(v81, v136)
				end
			end
		end
		table.sort(v81, function(p140, p141)
			if p140.order == p141.order then
				return p140.startAt < p141.startAt
			else
				return p140.order < p141.order
			end
		end)
		return v81
	end
	local v_u_143 = v_u_7.new("Frame", {
		["Name"] = "EventBar",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -40, 0, v_u_7.topInset() + 58),
		["Size"] = UDim2.fromOffset(300, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_6.root)
	local v_u_144 = v_u_7.layout(v_u_143, "v", 4)
	v_u_144.HorizontalAlignment = Enum.HorizontalAlignment.Right
	local v_u_145 = {}
	local v_u_146 = 300
	local v_u_147 = (1 / 0)
	local function v_u_156(p148) -- name: makeChip
		-- upvalues: (copy) v_u_7, (copy) v_u_9, (ref) v_u_146, (copy) v_u_143
		local v149 = v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Name"] = "Chip_" .. p148.key,
			["BackgroundColor3"] = v_u_9.bg,
			["Size"] = UDim2.fromOffset(v_u_146, 24)
		}, v_u_143)
		v_u_7.stroke(v149, v_u_9.line, 1, 0.2)
		local v150 = v_u_7.new("Frame", {
			["Name"] = "Tick",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = p148.color,
			["Size"] = UDim2.new(0, 2, 1, 0)
		}, v149)
		local v151 = v_u_7.icon(p148.icon, {
			["parent"] = nil,
			["size"] = 14,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v149,
			["color"] = p148.color,
			["position"] = UDim2.new(0, 10, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5)
		})
		local v152 = v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["valign"] = "center",
			["parent"] = v149,
			["text"] = p148.short,
			["color"] = v_u_9.text,
			["position"] = UDim2.fromOffset(30, 0),
			["size"] = UDim2.new(0, 94, 1, 0)
		})
		v152.TextTruncate = Enum.TextTruncate.AtEnd
		local v153 = v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["valign"] = "center",
			["track"] = false,
			["parent"] = v149,
			["text"] = p148.detail,
			["color"] = v_u_9.text2,
			["position"] = UDim2.fromOffset(126, 0),
			["size"] = UDim2.new(1, -200, 1, 0)
		})
		v153.TextTruncate = Enum.TextTruncate.AtEnd
		local v154 = v_u_7.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["valign"] = "center",
			["track"] = false,
			["parent"] = v149,
			["color"] = v_u_9.text2,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.new(1, -24, 0, 0),
			["size"] = UDim2.fromOffset(50, 24)
		})
		local v155 = v_u_7.icon("arrowUp", {
			["parent"] = nil,
			["size"] = 14,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v149,
			["color"] = p148.color,
			["position"] = UDim2.new(1, -6, 0.5, 0),
			["anchor"] = Vector2.new(1, 0.5)
		})
		return {
			["frame"] = v149,
			["tick"] = v150,
			["icon"] = v151,
			["iconName"] = p148.icon,
			["name"] = v152,
			["detail"] = v153,
			["dist"] = v154,
			["arrow"] = v155
		}
	end
	local function v_u_184() -- name: paintChips
		-- upvalues: (ref) v_u_14, (ref) v_u_147, (copy) p_u_6, (ref) v_u_80, (copy) v_u_145, (copy) v_u_156, (ref) v_u_146, (copy) v_u_7, (copy) v_u_67, (ref) v_u_13, (copy) v_u_11, (ref) v_u_26, (copy) v_u_143
		local v157 = v_u_14 and 2 or 4
		if v_u_14 and v_u_147 ~= (1 / 0) then
			local v158 = (v_u_147 + 4) / 28
			local v159 = math.floor(v158)
			local v160 = math.max(0, v159)
			v157 = math.min(v157, v160)
		end
		local v161 = v_u_14
		if v161 then
			local v162 = p_u_6.mods
			if v162 then
				v162 = v162.HUDClock
			end
			local v163
			if v162 then
				v163 = v162.bandBusy or v162.isShown
			else
				v163 = nil
			end
			if type(v163) == "function" then
				local v164
				v161, v164 = pcall(v163)
				if v161 then
					v161 = v164 == true
				end
			else
				v161 = false
			end
		end
		local v165 = 0
		local v166 = {}
		for v167, v168 in v_u_80 do
			if v157 <= v165 then
				break
			end
			v165 = v165 + 1
			v166[v168.key] = true
			local v169 = v_u_145[v168.key]
			if not v169 then
				v169 = v_u_156(v168)
				v_u_145[v168.key] = v169
			end
			v169.frame.LayoutOrder = v167
			v169.frame.Size = UDim2.fromOffset(v_u_146, 24)
			if v169.name:GetAttribute("Src") ~= v168.short then
				v169.name:SetAttribute("Src", v168.short)
				v_u_7.setText(v169.name, v168.short)
			end
			if v169.detail.Text ~= v168.detail then
				v169.detail.Text = v168.detail
			end
			if v169.color ~= v168.color then
				v169.color = v168.color
				v169.tick.BackgroundColor3 = v168.color
				v_u_7.setIconColor(v169.icon, v168.color)
				v_u_7.setIconColor(v169.arrow, v168.color)
			end
			local v170, v171
			if v168.arrow and v168.pos then
				v170, v171 = v_u_67(v168.pos)
			else
				v170 = nil
				v171 = nil
			end
			local v172 = v169.dist
			local v173
			if v170 then
				local v174 = v170 + 0.5
				local v175 = math.floor(v174)
				v173 = tostring(v175) .. " m"
			else
				v173 = ""
			end
			v172.Text = v173
			local v176 = v168.zone
			local v177 = v_u_13 or v_u_11.Character
			if v177 then
				v177 = v177:FindFirstChild("HumanoidRootPart")
			end
			local v178
			if v177 then
				v178 = v177.Position
			else
				local v179 = workspace.CurrentCamera
				v178 = v179 and v179.Focus.Position or nil
			end
			if v176 and (v178 and (v_u_26 and v168.arrow)) then
				v169.dist.Text = v_u_26.distanceText(v176.CFrame, v176.Size, v178)
			end
			v169.arrow.Visible = v171 ~= nil
			if not v171 then
				continue
			end
			v169.arrow.Rotation = v171
		end
		for v180, v181 in v_u_145 do
			if v166[v180] then
				continue
			end
			v181.frame:Destroy()
			v_u_145[v180] = nil
		end
		local v182 = v_u_143
		local v183
		if v165 > 0 then
			v183 = not v161
		else
			v183 = false
		end
		v182.Visible = v183
		p_u_6.eventBarH = (v_u_14 or v165 == 0) and 0 or v165 * 28 + 4
	end
	local v_u_185 = {}
	local function v_u_200() -- name: touchRects
		-- upvalues: (copy) v_u_10, (ref) v_u_14, (copy) v_u_7
		local v186 = {}
		local v_u_187 = v_u_10.controllers
		if v_u_187 then
			v_u_187 = v_u_10.controllers.Input
		end
		if not (v_u_14 and (v_u_187 and v_u_187.touchRects)) then
			return v186
		end
		local v188 = v_u_187.touchRects
		local v189, v190 = pcall(v188)
		if not v189 or type(v190) ~= "table" then
			return v186
		end
		local v_u_191 = Vector2.zero
		local function v193()
			-- upvalues: (copy) v_u_187, (ref) v_u_191
			local v192 = v_u_187.touch
			if v192 then
				v192 = v_u_187.touch()
			end
			if v192 then
				v192 = v192.root
			end
			if v192 and v192:IsA("GuiObject") then
				v_u_191 = v192.AbsolutePosition
			end
		end
		pcall(v193)
		local v194 = v_u_191
		for v195, v196 in v190 do
			if typeof(v196) ~= "Rect" or v195 == "moveZone" then
				continue
			end
			local v197 = v_u_7.absToOverlay(v194 + v196.Min)
			local v198 = v_u_7.absToOverlay(v194 + v196.Max)
			local v199 = {
				v197.X,
				v197.Y,
				v198.X,
				v198.Y
			}
			table.insert(v186, v199)
		end
		return v186
	end
	local v_u_201 = {}
	local v_u_202 = 1
	local function v_u_260(p203, p204) -- name: placeEdges
		-- upvalues: (copy) v_u_185, (ref) v_u_31, (copy) p_u_6, (ref) v_u_202, (ref) v_u_201, (copy) v_u_200, (copy) v_u_8, (copy) v_u_7, (ref) v_u_14, (ref) v_u_80, (copy) v_u_67, (ref) v_u_13, (copy) v_u_11, (ref) v_u_26
		for _, v205 in v_u_185 do
			v205.used = false
		end
		local v206, v207
		if v_u_31 and p_u_6.fx then
			v_u_202 = v_u_202 + p203
			if v_u_202 > 0.5 then
				v_u_202 = 0
				v_u_201 = v_u_200()
			end
			local v208 = nil
			local v209 = p_u_6.edgeAvoid
			local v210
			if type(v209) == "function" then
				local v211 = p_u_6.edgeAvoid
				local v212
				v212, v210 = pcall(v211)
				if v212 and type(v210) == "table" then
					if #v210 <= 0 then
						v210 = v208
					end
				else
					v210 = v208
				end
			else
				v210 = v208
			end
			local v213 = v_u_8.refSize()
			local v214 = v_u_7.topInset() + (v_u_14 and 76 or 78)
			local v215
			if v_u_31.safeBox then
				v215 = v_u_31.safeBox(v213, v_u_7.safeInsets(), v214, v_u_14 and 40 or 132, nil, v_u_8.isPhone())
			else
				v215 = {
					46,
					v214,
					v213.X - 46,
					v213.Y - (v_u_14 and 40 or 132)
				}
			end
			local v216 = {}
			for _, v217 in v_u_80 do
				if not (v217.edge and v217.pos) then
					continue
				end
				local v218 = v217.pos + Vector3.new(0, 3, 0)
				local v219, v220, v221 = v_u_7.screenMarker(v218, v215[1], v215[2], v215[3], v215[4], true)
				if v221 then
					continue
				end
				if not (v210 and v_u_31.avoidMarker) and #v_u_201 > 0 then
					v219 = v_u_31.avoid(v219, v_u_201, v215, 36)
				end
				local v222 = v_u_185[v217.key]
				if not v222 then
					local v223 = v_u_31.new
					local v224 = v_u_7
					local v225 = v_u_8
					local v226 = p_u_6.fx
					local v227, v228 = pcall(v223, v224, v225, v226)
					if v227 and v228 then
						v222 = {
							["m"] = nil,
							["used"] = false,
							["m"] = v228
						}
						v_u_185[v217.key] = v222
					end
				end
				if not v222 then
					continue
				end
				v222.used = true
				local v229 = v_u_67(v217.pos)
				local v230 = v222.m
				local v231 = {
					["label"] = nil,
					["color"] = nil,
					["meters"] = nil,
					["downed"] = false,
					["bleeding"] = false,
					["t"] = nil
				}
				local v232
				if v_u_14 then
					v232 = v217.kind == "airdrop" and "Drop" or "Heli"
				else
					v232 = v217.short
				end
				v231.label = v232
				v231.color = v217.color
				local v233, v234
				if v229 then
					local v235, v236
					if v217.zone then
						local v237 = v_u_13 or v_u_11.Character
						if v237 then
							v237 = v237:FindFirstChild("HumanoidRootPart")
						end
						local v238
						if v237 then
							v238 = v237.Position
						else
							local v239 = workspace.CurrentCamera
							v238 = v239 and v239.Focus.Position or nil
						end
						if v238 and v_u_26 then
							local v240 = v_u_26.distanceText
							local v241 = v217.zone.CFrame
							local v242 = v217.zone.Size
							local v243 = v_u_13 or v_u_11.Character
							if v243 then
								v243 = v243:FindFirstChild("HumanoidRootPart")
							end
							local v244
							if v243 then
								v244 = v243.Position
							else
								local v245 = workspace.CurrentCamera
								v244 = v245 and v245.Focus.Position or nil
							end
							v233 = v240(v241, v242, v244)
							v231.meters = v233
							v231.t = p204
							v230:set(v231)
							v222.m:setTouch(v_u_14)
							v234 = v222.m:extent()
							if v210 and v_u_31.avoidMarker then
								v219 = v_u_31.avoidMarker(v219, v220, v234, v210, v215, 8)
							end
							table.insert(v216, {
								["ed"] = v222,
								["pos"] = v219,
								["dir"] = v220,
								["ext"] = v234
							})
						else
							v235 = v229 + 0.5
							v236 = math.floor(v235)
							v233 = tostring(v236) .. " m"
							v231.meters = v233
							v231.t = p204
							v230:set(v231)
							v222.m:setTouch(v_u_14)
							v234 = v222.m:extent()
							if v210 and v_u_31.avoidMarker then
								v219 = v_u_31.avoidMarker(v219, v220, v234, v210, v215, 8)
							end
							table.insert(v216, {
								["ed"] = v222,
								["pos"] = v219,
								["dir"] = v220,
								["ext"] = v234
							})
						end
					else
						v235 = v229 + 0.5
						v236 = math.floor(v235)
						v233 = tostring(v236) .. " m"
						v231.meters = v233
						v231.t = p204
						v230:set(v231)
						v222.m:setTouch(v_u_14)
						v234 = v222.m:extent()
						if v210 and v_u_31.avoidMarker then
							v219 = v_u_31.avoidMarker(v219, v220, v234, v210, v215, 8)
						end
						table.insert(v216, {
							["ed"] = v222,
							["pos"] = v219,
							["dir"] = v220,
							["ext"] = v234
						})
					end
				else
					v233 = "-"
					v231.meters = v233
					v231.t = p204
					v230:set(v231)
					v222.m:setTouch(v_u_14)
					v234 = v222.m:extent()
					if v210 and v_u_31.avoidMarker then
						v219 = v_u_31.avoidMarker(v219, v220, v234, v210, v215, 8)
					end
					table.insert(v216, {
						["ed"] = v222,
						["pos"] = v219,
						["dir"] = v220,
						["ext"] = v234
					})
				end
			end
			if #v216 > 1 and v_u_31.stack then
				local v246 = v_u_31.stack
				pcall(v246, v216, v215)
			end
			for _, v247 in v216 do
				v247.ed.m:place(v247.pos, v247.dir)
			end
			v206 = {}
			for v254, v255 in v_u_185 do
				v255.m:setShown(v255.used)
				if v255.used then
					continue
				end
				v207 = false
				for v256, v257 in v_u_80 do
					if v257.key ~= v254 then
						continue
					end
					v207 = true
				end
				if v207 then
					break
				end
				table.insert(v206, v254)
			end
			for v258, v259 in v206 do
				v_u_185[v259].m:destroy()
				v_u_185[v259] = nil
			end
		else
			v206 = {}
			for v254, v255 in v_u_185 do
				v255.m:setShown(v255.used)
				if v255.used then
					continue
				end
				v207 = false
				for v256, v257 in v_u_80 do
					if v257.key ~= v254 then
						continue
					end
					v207 = true
				end
				if v207 then
					break
				end
				table.insert(v206, v254)
			end
			for v258, v259 in v206 do
				v_u_185[v259].m:destroy()
				v_u_185[v259] = nil
			end
		end
	end
	local v_u_261, v_u_262 = v_u_7.screen("HushEventCard", v_u_8.layer.toast - 1, {
		["insets"] = "None"
	})
	local v_u_263 = {}
	local v_u_264 = nil
	local function v_u_275(p265) -- name: cardPos
		-- upvalues: (copy) p_u_6, (ref) v_u_14, (copy) v_u_7
		local v266 = p_u_6.centerColumn
		local v267
		if v_u_14 and type(v266) == "function" then
			local v268
			v268, v267 = pcall(v266)
			if not v268 or type(v267) ~= "table" then
				v267 = nil
			end
		else
			v267 = nil
		end
		if v267 then
			local v269 = UDim2.fromOffset
			local v270 = v267.cx + v_u_7.safeInsets().l
			return v269(math.floor(v270), p265)
		end
		local v271
		if v_u_14 then
			local v272 = p_u_6.noticeSpot
			if type(v272) == "function" then
				v271 = p_u_6.noticeSpot()
			else
				v271 = nil
			end
		else
			v271 = nil
		end
		if not v271 then
			return UDim2.new(0.5, 0, 0, p265)
		end
		local v273 = UDim2.fromOffset
		local v274 = v271.cx + v_u_7.safeInsets().l
		return v273(math.floor(v274), p265)
	end
	local function v_u_290() -- name: toastBottom
		-- upvalues: (copy) p_u_6, (ref) v_u_14, (copy) v_u_7, (copy) v_u_11, (copy) v_u_8
		local v276 = p_u_6.centerColumn
		local v277
		if v_u_14 and type(v276) == "function" then
			local v278
			v278, v277 = pcall(v276)
			if not v278 or type(v277) ~= "table" then
				v277 = nil
			end
		else
			v277 = nil
		end
		local v279
		if v277 then
			local v280 = v277.top + v_u_7.safeInsets().t
			v279 = math.floor(v280)
		else
			v279 = v_u_14 and 12 or v_u_7.topInset() + 8
		end
		local v_u_281 = 0
		if not (v277 or p_u_6.toastsUnderCard) then
			local function v286()
				-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_281
				local v282 = v_u_11:FindFirstChildOfClass("PlayerGui")
				if v282 then
					v282 = v282:FindFirstChild("HushToast")
				end
				if v282 then
					v282 = v282:FindFirstChild("Root")
				end
				if v282 then
					v282 = v282:FindFirstChild("Toasts")
				end
				if v282 then
					local v283 = v_u_8.uiScale
					local v284 = math.max(0.01, v283())
					for _, v285 in v282:GetChildren() do
						if v285.Name ~= "Toast" or not v285:IsA("GuiObject") then
							continue
						end
						v_u_281 = v_u_281 + (v285.AbsoluteSize.Y / v284 + 8)
					end
				end
			end
			pcall(v286)
			return v279 + v_u_281
		end
		local v287
		if v277 or not v_u_14 then
			v287 = nil
		else
			local v288 = p_u_6.noticeSpot
			if type(v288) == "function" then
				v287 = p_u_6.noticeSpot()
			else
				v287 = nil
			end
		end
		if not v287 then
			return v279
		end
		local v289 = v287.top + v_u_7.safeInsets().t
		return math.floor(v289)
	end
	local function v_u_319(p291, p292) -- name: buildCompact
		-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_7, (copy) v_u_275, (copy) v_u_290, (copy) v_u_262, (copy) v_u_78
		local v293 = v_u_10.lib.HudLayout
		local v294 = p292.w
		local v295 = math.floor(v294)
		local v296 = p291.kind == "danger" and "danger" or (p291.kind == "success" and "success" or (p291.kind == "info" and "info" or "warn"))
		local v297
		if v296 == "danger" then
			v297 = v_u_9.danger
		elseif v296 == "success" then
			v297 = v_u_9.success
		elseif v296 == "info" then
			v297 = v_u_9.info
		else
			v297 = v_u_9.accent
		end
		local v298 = v_u_7.new("Frame", {
			["Name"] = "EventCard",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.04,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_9.bg,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = v_u_275((v_u_290())),
			["Size"] = UDim2.fromOffset(v295, v293.K.NOTICE_CARD_H)
		}, v_u_262)
		v_u_7.stroke(v298, v_u_9.lineStrong, 1, 0)
		v_u_7.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v297,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v298)
		local v299 = v295 < 220
		local v300 = v299 and 10 or 30
		if not v299 then
			local v301 = v_u_7.icon
			local v302 = p291.icon or "info"
			v301(tostring(v302), {
				["parent"] = nil,
				["size"] = 16,
				["color"] = nil,
				["position"] = nil,
				["parent"] = v298,
				["color"] = v297,
				["position"] = UDim2.fromOffset(9, 5)
			})
		end
		local v303 = p291.phoneText or (p291.text or "")
		local v304 = tostring(v303)
		local v305 = nil
		local v306 = nil
		local v307 = p291.pos
		local v308, v309, v310, v311, v312, v313, v314, v315
		if typeof(v307) == "Vector3" then
			p291.place = p291.place or v_u_78(p291.pos)
			v308 = "-"
			v309 = v308 ~= ""
			if v309 then
				v310 = false
			else
				v310 = #v304 * 8 > v295 - v300 - 8
			end
			v311 = v310 and 34 or 18
			v312 = v_u_7.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = 15,
				["wrap"] = nil,
				["fitWrap"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v298,
				["text"] = v304,
				["wrap"] = v310,
				["position"] = UDim2.fromOffset(v300, 5),
				["size"] = UDim2.new(1, -(v300 + 8), 0, v311)
			})
			if v310 then
				v312.TextYAlignment = Enum.TextYAlignment.Top
				v312.TextTruncate = Enum.TextTruncate.AtEnd
			end
			v313 = UDim2.fromOffset
			if v309 then
				v314 = v293.K.NOTICE_CARD_H
			else
				v314 = v311 + 5 + 5
			end
			v298.Size = v313(v295, v314)
			v315 = p291.pos
			if typeof(v315) == "Vector3" then
				v306 = v_u_7.icon("arrowUp", {
					["parent"] = nil,
					["size"] = 12,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v298,
					["color"] = v297,
					["position"] = UDim2.new(1, -8, 0, 25),
					["anchor"] = Vector2.new(1, 0.5)
				})
				v305 = v_u_7.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "mono",
					["textSize"] = 12,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["valign"] = "center",
					["track"] = false,
					["parent"] = v298,
					["color"] = v_u_9.text,
					["position"] = UDim2.fromOffset(v300, 23),
					["size"] = UDim2.new(1, -(v300 + 26), 0, 16)
				})
			elseif v309 then
				v_u_7.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["textSize"] = 12,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["valign"] = "center",
					["track"] = false,
					["parent"] = v298,
					["text"] = v308,
					["color"] = v_u_9.text2,
					["position"] = UDim2.fromOffset(v300, 23),
					["size"] = UDim2.new(1, -(v300 + 8), 0, 16)
				})
			end
			return {
				["frame"] = nil,
				["where"] = nil,
				["arrow"] = nil,
				["line"] = nil,
				["compact"] = true,
				["frame"] = v298,
				["where"] = v305,
				["arrow"] = v306,
				["line"] = v_u_7.new("Frame", {
					["Name"] = "Time",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.35,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v297,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, 2)
				}, v298)
			}
		else
			local v316 = p291.phoneSub
			if type(v316) == "string" then
				v308 = p291.phoneSub
				v309 = v308 ~= ""
				if v309 then
					v310 = false
				else
					v310 = #v304 * 8 > v295 - v300 - 8
				end
				v311 = v310 and 34 or 18
				v312 = v_u_7.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "h3",
					["textSize"] = 15,
					["wrap"] = nil,
					["fitWrap"] = false,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v298,
					["text"] = v304,
					["wrap"] = v310,
					["position"] = UDim2.fromOffset(v300, 5),
					["size"] = UDim2.new(1, -(v300 + 8), 0, v311)
				})
				if v310 then
					v312.TextYAlignment = Enum.TextYAlignment.Top
					v312.TextTruncate = Enum.TextTruncate.AtEnd
				end
				v313 = UDim2.fromOffset
				if v309 then
					v314 = v293.K.NOTICE_CARD_H
				else
					v314 = v311 + 5 + 5
				end
				v298.Size = v313(v295, v314)
				v315 = p291.pos
				if typeof(v315) == "Vector3" then
					v306 = v_u_7.icon("arrowUp", {
						["parent"] = nil,
						["size"] = 12,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v298,
						["color"] = v297,
						["position"] = UDim2.new(1, -8, 0, 25),
						["anchor"] = Vector2.new(1, 0.5)
					})
					v305 = v_u_7.label({
						["parent"] = nil,
						["text"] = "",
						["style"] = "mono",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "center",
						["track"] = false,
						["parent"] = v298,
						["color"] = v_u_9.text,
						["position"] = UDim2.fromOffset(v300, 23),
						["size"] = UDim2.new(1, -(v300 + 26), 0, 16)
					})
				elseif v309 then
					v_u_7.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "center",
						["track"] = false,
						["parent"] = v298,
						["text"] = v308,
						["color"] = v_u_9.text2,
						["position"] = UDim2.fromOffset(v300, 23),
						["size"] = UDim2.new(1, -(v300 + 8), 0, 16)
					})
				end
				return {
					["frame"] = nil,
					["where"] = nil,
					["arrow"] = nil,
					["line"] = nil,
					["compact"] = true,
					["frame"] = v298,
					["where"] = v305,
					["arrow"] = v306,
					["line"] = v_u_7.new("Frame", {
						["Name"] = "Time",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.35,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v297,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.fromScale(0, 1),
						["Size"] = UDim2.new(1, 0, 0, 2)
					}, v298)
				}
			else
				if p291.summary then
					local v317 = p291.sub
					if type(v317) == "string" then
						local v318 = select(2, string.gsub(p291.sub, "\n", "")) + 1
						v308 = v293.firstSentence(p291.sub, 60) .. (v318 <= 1 and "" or " +" .. v318 - 1)
						v309 = v308 ~= ""
						if v309 then
							v310 = false
						else
							v310 = #v304 * 8 > v295 - v300 - 8
						end
						v311 = v310 and 34 or 18
						v312 = v_u_7.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "h3",
							["textSize"] = 15,
							["wrap"] = nil,
							["fitWrap"] = false,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v298,
							["text"] = v304,
							["wrap"] = v310,
							["position"] = UDim2.fromOffset(v300, 5),
							["size"] = UDim2.new(1, -(v300 + 8), 0, v311)
						})
						if v310 then
							v312.TextYAlignment = Enum.TextYAlignment.Top
							v312.TextTruncate = Enum.TextTruncate.AtEnd
						end
						v313 = UDim2.fromOffset
						if v309 then
							v314 = v293.K.NOTICE_CARD_H
						else
							v314 = v311 + 5 + 5
						end
						v298.Size = v313(v295, v314)
						v315 = p291.pos
						if typeof(v315) == "Vector3" then
							v306 = v_u_7.icon("arrowUp", {
								["parent"] = nil,
								["size"] = 12,
								["color"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["parent"] = v298,
								["color"] = v297,
								["position"] = UDim2.new(1, -8, 0, 25),
								["anchor"] = Vector2.new(1, 0.5)
							})
							v305 = v_u_7.label({
								["parent"] = nil,
								["text"] = "",
								["style"] = "mono",
								["textSize"] = 12,
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["valign"] = "center",
								["track"] = false,
								["parent"] = v298,
								["color"] = v_u_9.text,
								["position"] = UDim2.fromOffset(v300, 23),
								["size"] = UDim2.new(1, -(v300 + 26), 0, 16)
							})
						elseif v309 then
							v_u_7.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "small",
								["textSize"] = 12,
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["valign"] = "center",
								["track"] = false,
								["parent"] = v298,
								["text"] = v308,
								["color"] = v_u_9.text2,
								["position"] = UDim2.fromOffset(v300, 23),
								["size"] = UDim2.new(1, -(v300 + 8), 0, 16)
							})
						end
						return {
							["frame"] = nil,
							["where"] = nil,
							["arrow"] = nil,
							["line"] = nil,
							["compact"] = true,
							["frame"] = v298,
							["where"] = v305,
							["arrow"] = v306,
							["line"] = v_u_7.new("Frame", {
								["Name"] = "Time",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.35,
								["BorderSizePixel"] = 0,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v297,
								["AnchorPoint"] = Vector2.new(0, 1),
								["Position"] = UDim2.fromScale(0, 1),
								["Size"] = UDim2.new(1, 0, 0, 2)
							}, v298)
						}
					end
					v308 = v293.firstSentence(p291.sub, 80)
				else
					v308 = v293.firstSentence(p291.sub, 80)
				end
				v309 = v308 ~= ""
				if v309 then
					v310 = false
				else
					v310 = #v304 * 8 > v295 - v300 - 8
				end
				v311 = v310 and 34 or 18
				v312 = v_u_7.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "h3",
					["textSize"] = 15,
					["wrap"] = nil,
					["fitWrap"] = false,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v298,
					["text"] = v304,
					["wrap"] = v310,
					["position"] = UDim2.fromOffset(v300, 5),
					["size"] = UDim2.new(1, -(v300 + 8), 0, v311)
				})
				if v310 then
					v312.TextYAlignment = Enum.TextYAlignment.Top
					v312.TextTruncate = Enum.TextTruncate.AtEnd
				end
				v313 = UDim2.fromOffset
				if v309 then
					v314 = v293.K.NOTICE_CARD_H
				else
					v314 = v311 + 5 + 5
				end
				v298.Size = v313(v295, v314)
				v315 = p291.pos
				if typeof(v315) == "Vector3" then
					v306 = v_u_7.icon("arrowUp", {
						["parent"] = nil,
						["size"] = 12,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v298,
						["color"] = v297,
						["position"] = UDim2.new(1, -8, 0, 25),
						["anchor"] = Vector2.new(1, 0.5)
					})
					v305 = v_u_7.label({
						["parent"] = nil,
						["text"] = "",
						["style"] = "mono",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "center",
						["track"] = false,
						["parent"] = v298,
						["color"] = v_u_9.text,
						["position"] = UDim2.fromOffset(v300, 23),
						["size"] = UDim2.new(1, -(v300 + 26), 0, 16)
					})
				elseif v309 then
					v_u_7.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "center",
						["track"] = false,
						["parent"] = v298,
						["text"] = v308,
						["color"] = v_u_9.text2,
						["position"] = UDim2.fromOffset(v300, 23),
						["size"] = UDim2.new(1, -(v300 + 8), 0, 16)
					})
				end
				return {
					["frame"] = nil,
					["where"] = nil,
					["arrow"] = nil,
					["line"] = nil,
					["compact"] = true,
					["frame"] = v298,
					["where"] = v305,
					["arrow"] = v306,
					["line"] = v_u_7.new("Frame", {
						["Name"] = "Time",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.35,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v297,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.fromScale(0, 1),
						["Size"] = UDim2.new(1, 0, 0, 2)
					}, v298)
				}
			end
		end
	end
	local function v_u_346(p320) -- name: buildCard
		-- upvalues: (copy) p_u_6, (ref) v_u_14, (copy) v_u_319, (copy) v_u_9, (copy) v_u_7, (copy) v_u_275, (copy) v_u_290, (copy) v_u_262, (ref) v_u_5, (copy) v_u_78
		local v321 = p_u_6.centerColumn
		local v322
		if v_u_14 and type(v321) == "function" then
			local v323
			v323, v322 = pcall(v321)
			if not v323 or type(v322) ~= "table" then
				v322 = nil
			end
		else
			v322 = nil
		end
		if v322 and v322.compact then
			return v_u_319(p320, v322)
		end
		local v324
		if v322 then
			local v325 = v322.w
			v324 = math.floor(v325)
		else
			v324 = v_u_14 and 320 or 460
		end
		local v326 = p320.kind == "danger" and "danger" or (p320.kind == "success" and "success" or (p320.kind == "info" and "info" or "warn"))
		local v327
		if v326 == "danger" then
			v327 = v_u_9.danger
		elseif v326 == "success" then
			v327 = v_u_9.success
		elseif v326 == "info" then
			v327 = v_u_9.info
		else
			v327 = v_u_9.accent
		end
		local v328 = v_u_7.new("Frame", {
			["Name"] = "EventCard",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.04,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundColor3"] = v_u_9.bg,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = v_u_275((v_u_290())),
			["Size"] = UDim2.fromOffset(v324, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_262)
		v_u_7.stroke(v328, v_u_9.lineStrong, 1, 0)
		v_u_7.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v327,
			["Size"] = UDim2.new(0, 4, 1, 0)
		}, v328)
		local v329 = v_u_14 and 26 or 32
		local v330
		if v322 == nil then
			v330 = false
		else
			v330 = v322.w < 260
		end
		local v331 = v_u_7.icon
		local v332 = p320.icon or "info"
		v331(tostring(v332), {
			["parent"] = v328,
			["size"] = v329,
			["color"] = v327,
			["position"] = UDim2.fromOffset(18, 14)
		}).Visible = not v330
		local v333 = v_u_7.new("Frame", {
			["Name"] = "Body",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v328)
		v_u_7.pad(v333, {
			v330 and 14 or v329 + 30,
			14,
			10,
			12
		})
		v_u_7.layout(v333, "v", 2)
		local v334
		if p320.summary then
			v334 = "Raid events"
		else
			local v335 = p320.category
			if type(v335) == "string" then
				v334 = p320.category
			else
				local v336 = v_u_5
				local v337 = p320.icon
				v334 = v336[tostring(v337)] or "Raid event"
			end
		end
		v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["size"] = nil,
			["order"] = 0,
			["parent"] = v333,
			["text"] = v334,
			["color"] = v327,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		local v338 = v_u_7.label
		local v339 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["textSize"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v333
		}
		local v340 = p320.text or ""
		v339.text = tostring(v340)
		v339.textSize = v_u_14 and 17 or 20
		v338(v339)
		local v341 = p320.sub
		if type(v341) == "string" and p320.sub ~= "" then
			v_u_7.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["parent"] = v333,
				["text"] = p320.sub
			})
		end
		local v342 = p320.pos
		local v343, v344
		if typeof(v342) == "Vector3" then
			local v345 = v_u_7.new("Frame", {
				["Name"] = "Where",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 3,
				["Size"] = UDim2.new(1, 0, 0, 22)
			}, v333)
			v343 = v_u_7.icon("arrowUp", {
				["parent"] = nil,
				["size"] = 16,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v345,
				["color"] = v327,
				["position"] = UDim2.new(0, 0, 0.5, 0),
				["anchor"] = Vector2.new(0, 0.5)
			})
			v344 = v_u_7.label({
				["parent"] = nil,
				["text"] = "",
				["style"] = "mono",
				["textSize"] = 14,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "center",
				["track"] = false,
				["parent"] = v345,
				["color"] = v_u_9.text,
				["position"] = UDim2.fromOffset(24, 0),
				["size"] = UDim2.new(1, -24, 1, 0)
			})
			v344.TextTruncate = Enum.TextTruncate.AtEnd
			if v322 then
				v344.TextTruncate = Enum.TextTruncate.None
				v344.TextWrapped = true
				v344.AutomaticSize = Enum.AutomaticSize.Y
				v344.Size = UDim2.new(1, -24, 0, 22)
				v345.AutomaticSize = Enum.AutomaticSize.Y
			end
			p320.place = p320.place or v_u_78(p320.pos)
		else
			v344 = nil
			v343 = nil
		end
		return {
			["frame"] = v328,
			["where"] = v344,
			["arrow"] = v343,
			["line"] = v_u_7.new("Frame", {
				["Name"] = "Time",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.35,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v327,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, 2)
			}, v328)
		}
	end
	local function v_u_357(p347, p348) -- name: paintWhere
		-- upvalues: (copy) v_u_67
		if p347.where then
			local v349 = p348.pos
			if typeof(v349) == "Vector3" then
				local v350, v351 = v_u_67(p348.pos)
				local v352
				if p348.place then
					local v353 = p348.place
					v352 = "near " .. tostring(v353)
				else
					v352 = ""
				end
				local v354
				if v350 then
					local v355 = v350 + 0.5
					local v356 = math.floor(v355)
					v354 = tostring(v356) .. " m"
					if v352 ~= "" then
						v354 = v352 .. "  \194\183  " .. v354
					end
				else
					v354 = v352
				end
				if p347.where.Text ~= v354 then
					p347.where.Text = v354
				end
				if p347.arrow then
					p347.arrow.Visible = v351 ~= nil
					if v351 then
						p347.arrow.Rotation = v351
					end
				end
				return
			end
		end
	end
	local function v_u_377(p358) -- name: sting
		-- upvalues: (copy) v_u_7, (copy) v_u_10
		local v359 = p358.sting
		if v359 == "none" or v359 == "land" then
			if v359 == "land" then
				v_u_7.sound("toast")
			end
			return
		elseif p358.summary then
			v_u_7.sound("toast")
		else
			local v360 = p358.icon or ""
			local v361 = tostring(v360)
			if v361 == "horde" then
				local v362 = v_u_10.controllers
				if v362 then
					v362 = v_u_10.controllers.Audio
				end
				local v363
				if v362 then
					local v364 = v362.play
					if type(v364) == "function" then
						local v365 = v362.play
						local v366
						v363, v366 = pcall(v365, "ev_sting_horde")
						if v363 then
							v363 = v366 ~= nil
						end
					else
						v363 = false
					end
				else
					v363 = false
				end
				if not v363 then
					v_u_7.sound("toast")
					return
				end
			else
				if v361 == "siren" then
					return
				end
				local v367 = v_u_10.controllers
				if v367 then
					v367 = v_u_10.controllers.Audio
				end
				local v368
				if v367 then
					local v369 = v367.play
					if type(v369) == "function" then
						local v370 = v367.play
						local v371
						v368, v371 = pcall(v370, "ev_sting_alert")
						if v368 then
							v368 = v371 ~= nil
						end
					else
						v368 = false
					end
				else
					v368 = false
				end
				local v372 = v_u_10.controllers
				if v372 then
					v372 = v_u_10.controllers.Audio
				end
				if v372 then
					local v373 = v372.play
					if type(v373) == "function" then
						local v374 = v372.play
						local v375, v376 = pcall(v374, "ev_radio_burst")
						if v375 then
							local _ = v376 == nil
						end
					end
				end
				if not v368 then
					v_u_7.sound("toast")
				end
			end
		end
	end
	local function v_u_385() -- name: showNext
		-- upvalues: (copy) v_u_263, (copy) v_u_346, (ref) v_u_264, (copy) v_u_357, (copy) v_u_7, (copy) v_u_290, (copy) v_u_275, (copy) v_u_377
		local v378 = table.remove(v_u_263, 1)
		if v378 then
			local v379 = v_u_346(v378)
			local v380
			if #v_u_263 >= 2 then
				v380 = 4.5
			else
				local v381 = v378.dur
				if type(v381) == "number" then
					local v382 = v378.dur
					v380 = math.clamp(v382, 3, 15)
				else
					v380 = 7
				end
			end
			if v379.compact then
				local v383 = #v_u_263 >= 1 and 3.5 or 5
				v380 = math.min(v380, v383)
			end
			v_u_264 = {
				["p"] = v378,
				["card"] = v379,
				["shownAt"] = os.clock(),
				["dur"] = v380,
				["key"] = v378._key
			}
			v_u_357(v379, v378)
			v_u_7.fade(v379.frame, 0, "slow", {
				["from"] = 1
			})
			local v384 = v_u_290()
			v379.frame.Position = v_u_275(v384 - 10)
			v_u_7.tween(v379.frame, {
				["Position"] = v_u_275(v384)
			}, "slow", Enum.EasingStyle.Quint)
			v_u_377(v378)
		end
	end
	function v_u_12.cardHeight() -- name: cardHeight
		-- upvalues: (ref) v_u_264, (copy) v_u_8
		local v386 = v_u_264
		if not (v386 and (v386.card and (v386.card.frame.Parent and v386.card.frame.Visible))) then
			return 0
		end
		local v387 = v386.card.frame.AbsoluteSize.Y
		local v388 = v_u_8.uiScale
		return v387 / math.max(0.01, v388())
	end
	local function v_u_391() -- name: hideCurrent
		-- upvalues: (ref) v_u_264, (copy) v_u_7
		local v389 = v_u_264
		v_u_264 = nil
		if v389 then
			local v_u_390 = v389.card.frame
			v_u_7.fade(v_u_390, 1, "slow", {
				["onDone"] = function() -- name: onDone
					-- upvalues: (copy) v_u_390
					v_u_390:Destroy()
				end
			})
		end
	end
	function v_u_12.announce(p392) -- name: announce
		-- upvalues: (ref) v_u_15, (ref) v_u_264, (copy) v_u_263
		if v_u_15 and type(p392) == "table" then
			local v393 = p392.event or ""
			local v394 = tostring(v393)
			local v395 = p392.text or ""
			local v396 = v394 .. "|" .. tostring(v395)
			if not v_u_264 or v_u_264.key ~= v396 then
				for _, v397 in v_u_263 do
					if v397._key ~= v396 then
						continue
					end
					return
				end
				p392._key = v396
				local v398 = v_u_263
				table.insert(v398, p392)
				if v_u_264 and #v_u_263 >= 2 then
					local v399 = v_u_264
					local v400 = v_u_264.dur
					local v401 = math.min(v400, 4.5)
					local v402 = os.clock() - v_u_264.shownAt + 0.5
					v399.dur = math.max(v401, v402, 3)
				end
			end
		else
			return
		end
	end
	local function v_u_428() -- name: updateCard
		-- upvalues: (ref) v_u_264, (copy) v_u_357, (copy) v_u_7, (copy) v_u_290, (copy) p_u_6, (ref) v_u_14, (copy) v_u_8, (copy) v_u_275, (copy) v_u_391, (copy) v_u_263, (copy) v_u_385
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v403, v404, v405, v406, v407, v408, v409, v410, v411, v412, v413, v414, v415, v416, v417, v418, v419, v420, v421, v422, v423, v424, v425, v426
		local v427 = 9
		while true do
			if v427 == 1 then
				if not v_u_264 and #v_u_263 > 0 then
					v_u_385()
				end
				return
			elseif v427 == 2 then
				if v412 then
					v419.cx = v412.cx
				end
				if v421 > 1 then
					v425 = v419.card.frame.Position.Y.Offset - v409
					if math.abs(v425) > 1 then
						v419.card.frame.Position = v_u_275(v409)
					end
				end
				if v419.dur <= v421 then
					v_u_391()
				end
				v427 = 1
			elseif v427 == 3 then
				if v412 then
					v419.cx = v412.cx
				end
				if v421 > 1 then
					v425 = v419.card.frame.Position.Y.Offset - v409
					if math.abs(v425) > 1 then
						v419.card.frame.Position = v_u_275(v409)
					end
				end
				if v419.dur <= v421 then
					v_u_391()
				end
				v427 = 1
			elseif v427 == 4 then
				v426 = v419.card.frame
				v403 = UDim2.fromOffset
				v404 = v412.w
				v426.Size = v403(math.floor(v404), not v419.card.compact and 0 or v419.card.frame.Size.Y.Offset)
				v419.card.frame.Position = v_u_275(v409)
				v427 = 2
			elseif v427 == 5 then
				v405 = v419.card.frame.Size.X.Offset
				v406 = v412.w
				v407 = v405 - math.floor(v406)
				if math.abs(v407) > 1 then
					v427 = 4
				else
					v427 = 7
				end
			elseif v427 == 6 then
				if v412 then
					v419.cx = v412.cx
				end
				if v421 > 1 then
					v425 = v419.card.frame.Position.Y.Offset - v409
					if math.abs(v425) > 1 then
						v419.card.frame.Position = v_u_275(v409)
					end
				end
				if v419.dur <= v421 then
					v_u_391()
				end
				v427 = 1
			elseif v427 == 7 then
				v408 = (v419.cx or v412.cx) - v412.cx
				if math.abs(v408) > 1 then
					v427 = 8
				else
					v427 = 3
				end
			elseif v427 == 8 then
				v426 = v419.card.frame
				v403 = UDim2.fromOffset
				v404 = v412.w
				v426.Size = v403(math.floor(v404), not v419.card.compact and 0 or v419.card.frame.Size.Y.Offset)
				v419.card.frame.Position = v_u_275(v409)
				v427 = 2
			else
				if not v_u_264 then
					if not v_u_264 and #v_u_263 > 0 then
						v_u_385()
					end
					return
				end
				v419 = v_u_264
				v420 = os.clock()
				if v419.hidden and v419.lastT then
					v419.shownAt = v419.shownAt + (v420 - v419.lastT)
				end
				v419.lastT = v420
				v421 = v420 - v419.shownAt
				v_u_357(v419.card, v419.p)
				if v419.card.compact and (v421 >= 2 and not (v419.dimmed or v419.hidden)) then
					v419.dimmed = true
					v_u_7.fade(v419.card.frame, 0.5, "slow")
				end
				v422 = v419.card.line
				v423 = UDim2.new
				v424 = 1 - v421 / v419.dur
				v422.Size = v423(math.clamp(v424, 0, 1), 0, 0, 2)
				v409 = v_u_290()
				v410 = p_u_6.centerColumn
				if v_u_14 and type(v410) == "function" then
					v411, v412 = pcall(v410)
					if not v411 or type(v412) ~= "table" then
						v412 = nil
					end
				else
					v412 = nil
				end
				if v412 then
					v413 = p_u_6.columnLimit
					if type(v413) == "function" then
						v414 = v419.card.frame
						if v414.Visible and v414.AbsoluteSize.Y > 2 then
							v415 = v414.AbsoluteSize.Y
							v416 = v_u_8.uiScale
							v419.h = v415 / math.max(0.01, v416())
						end
						v417 = p_u_6.columnLimit()
						if type(v417) == "number" then
							v418 = v412.top + (v419.h or 0) <= v417 + 1
							v419.hidden = not v418
							if v414.Visible ~= v418 then
								v414.Visible = v418
							end
						end
					end
				end
				if v412 then
					v427 = 5
				else
					v427 = 6
				end
			end
		end
	end
	local function v_u_435(p429) -- name: summaryPayload
		-- upvalues: (copy) v_u_142, (copy) v_u_78
		local v430 = {}
		for _, v431 in v_u_142() do
			if v431.startAt >= p429 or v431.detail == "emptied" then
				continue
			end
			local v432 = v431.short
			if v431.pos then
				local v433 = v_u_78(v431.pos)
				if v433 then
					v432 = v432 .. " near " .. v433
				end
			end
			local v434 = v432 .. "  (" .. v431.detail .. ")"
			table.insert(v430, v434)
		end
		return #v430 ~= 0 and {
			["summary"] = true,
			["text"] = "Raid events in progress",
			["sub"] = nil,
			["kind"] = "info",
			["icon"] = "info",
			["event"] = "summary",
			["sub"] = table.concat(v430, "\n")
		} or nil
	end
	local v_u_436 = v_u_2.now()
	task.spawn(function()
		-- upvalues: (copy) p_u_6, (copy) v_u_10, (ref) v_u_4, (ref) v_u_15, (copy) v_u_11, (copy) v_u_435, (copy) v_u_436, (copy) v_u_12
		local v437 = p_u_6.raid
		local v438 = not (v437 and v437.Parent) and v_u_10.runtime
		if v438 then
			v438 = v438:FindFirstChild("Raid")
		end
		if v438 then
			local v439 = v438:GetAttribute("RaidId") or v438:GetAttribute("StartedAt") or ""
			v438 = tostring(v439)
		end
		if v438 and (v438 ~= "" and not v_u_4[v438]) then
			v_u_4[v438] = true
			local v440 = os.clock() + 25
			while v_u_15 and (v_u_11:GetAttribute("LoadingVisible") == true and os.clock() < v440) do
				task.wait(0.25)
			end
			task.wait(1.5)
			if v_u_15 then
				local v441 = v_u_435(v_u_436 - 2)
				if v441 then
					v_u_12.announce(v441)
				end
			end
		else
			return
		end
	end)
	function v_u_12.summary() -- name: summary
		-- upvalues: (copy) v_u_435, (ref) v_u_2, (copy) v_u_12
		local v442 = v_u_435(v_u_2.now() + 1)
		if v442 then
			v442.event = "summary_test"
			v_u_12.announce(v442)
		end
		return v442 ~= nil
	end
	local v_u_443 = nil
	local v444, v445 = pcall(function()
		-- upvalues: (copy) v_u_10
		return v_u_10.lib.HUDExtractCoach
	end)
	if v444 and type(v445) == "table" then
		local v446 = v445.new
		if type(v446) == "function" then
			local v447 = v445.new
			local v448 = v_u_12.announce
			local v449, v450 = pcall(v447, p_u_6, v448)
			if v449 then
				v_u_443 = v450
			else
				warn("[HUDEvents] extract coach failed:", v450)
			end
		end
	end
	function v_u_12.setCharacter(p451) -- name: setCharacter
		-- upvalues: (ref) v_u_13
		v_u_13 = p451
	end
	local function v_u_463(p452) -- name: placeTouchBar
		-- upvalues: (copy) p_u_6, (copy) v_u_143, (ref) v_u_147, (copy) v_u_8
		local v453 = p_u_6.bandOffset
		local v454 = type(v453) ~= "function" and 0 or p_u_6.bandOffset("EventBar")
		local v455 = p452.listY
		local v456
		if type(v455) == "number" then
			v456 = p452.listY
		else
			v456 = p452.top + 96
		end
		local v457 = v456 + v454
		local v458 = v_u_143
		local v459 = UDim2.fromOffset
		local v460 = p452.bandLeft or p452.left
		v458.Position = v459(math.floor(v460), (math.floor(v457)))
		local v461
		if v_u_8.isPhone() then
			local v462 = p452.listBottom
			v461 = type(v462) ~= "number" and (1 / 0) or p452.listBottom - v457
		else
			v461 = (1 / 0)
		end
		v_u_147 = v461
	end
	function v_u_12.layout(p464) -- name: layout
		-- upvalues: (ref) v_u_14, (copy) p_u_6, (copy) v_u_8, (ref) v_u_146, (copy) v_u_143, (copy) v_u_144, (copy) v_u_463, (ref) v_u_147, (copy) v_u_7, (ref) v_u_264, (copy) v_u_275, (copy) v_u_290, (copy) v_u_184
		v_u_14 = p464
		local v465
		if p464 and p_u_6.touchFrame then
			v465 = p_u_6.touchFrame()
		else
			v465 = nil
		end
		if v465 then
			local v466 = v_u_8.isPhone()
			local v467 = v465.listW
			local v468 = (type(v467) ~= "number" and 260 or v465.listW) - (v466 and 20 or 40)
			local v469 = math.clamp(v468, 200, v466 and 280 or 260)
			v_u_146 = math.floor(v469)
			v_u_143.AnchorPoint = Vector2.new(0, 0)
			v_u_144.HorizontalAlignment = Enum.HorizontalAlignment.Left
			v_u_463(v465)
		else
			v_u_147 = (1 / 0)
			v_u_146 = 300
			local v470 = p_u_6.freeTag
			v_u_143.AnchorPoint = Vector2.new(1, 0)
			v_u_143.Position = UDim2.new(1, -40, 0, v_u_7.topInset() + (v470 and v470.Parent and 88 or 58))
			v_u_144.HorizontalAlignment = Enum.HorizontalAlignment.Right
		end
		v_u_143.Size = UDim2.fromOffset(v_u_146, 0)
		if v_u_264 then
			local v471 = p_u_6.centerColumn
			local v472
			if v_u_14 and type(v471) == "function" then
				local v473
				v473, v472 = pcall(v471)
				if not v473 or type(v472) ~= "table" then
					v472 = nil
				end
			else
				v472 = nil
			end
			local v474 = v_u_264.card.frame
			local v475 = UDim2.fromOffset
			local v476
			if v472 then
				local v477 = v472.w
				v476 = math.floor(v477)
			else
				v476 = v_u_14 and 320 or 460
			end
			v474.Size = v475(v476, not v_u_264.card.compact and 0 or v_u_264.card.frame.Size.Y.Offset)
			if v472 then
				v_u_264.card.frame.Position = v_u_275((v_u_290()))
			end
		end
		v_u_184()
	end
	local v_u_478 = 1
	local v_u_479 = 0
	local v_u_480 = 0
	function v_u_12.update(p481) -- name: update
		-- upvalues: (ref) v_u_479, (ref) v_u_478, (ref) v_u_80, (copy) v_u_142, (ref) v_u_14, (copy) p_u_6, (copy) v_u_7, (copy) v_u_143, (copy) v_u_463, (copy) v_u_184, (copy) v_u_145, (copy) v_u_67, (copy) v_u_260, (copy) v_u_428, (ref) v_u_443, (ref) v_u_480, (copy) v_u_11, (copy) v_u_12
		v_u_479 = v_u_479 + p481
		v_u_478 = v_u_478 + p481
		if v_u_478 >= 0.25 then
			v_u_478 = 0
			v_u_80 = v_u_142()
			if v_u_14 then
				local v482
				if p_u_6.touchFrame then
					v482 = p_u_6.touchFrame()
				else
					v482 = nil
				end
				if v482 then
					v_u_463(v482)
				end
			else
				local v483 = p_u_6.freeTag
				local v484 = v_u_7.topInset() + (v483 and v483.Parent and 88 or 58)
				if v_u_143.Position.Y.Offset ~= v484 then
					v_u_143.Position = UDim2.new(1, -40, 0, v484)
				end
			end
			v_u_184()
		else
			for _, v485 in v_u_80 do
				local v486 = v_u_145[v485.key]
				if not (v486 and (v485.arrow and v485.pos)) then
					continue
				end
				local _, v487 = v_u_67(v485.pos)
				if not v487 then
					continue
				end
				v486.arrow.Rotation = v487
			end
		end
		v_u_260(p481, v_u_479)
		v_u_428()
		if v_u_443 then
			local v488 = v_u_443.update
			local v489, v490 = pcall(v488, p481)
			if not v489 then
				warn("[HUDEvents] extract coach:", v490)
				v_u_443 = nil
			end
		end
		v_u_480 = v_u_480 + p481
		if v_u_480 > 1 then
			v_u_480 = 0
			v_u_11:SetAttribute("EventFeedState", v_u_12.state())
		end
	end
	function v_u_12.state() -- name: state
		-- upvalues: (ref) v_u_80, (copy) v_u_185, (ref) v_u_264, (copy) v_u_263, (copy) v_u_143
		local v491 = {}
		for _, v492 in v_u_80 do
			local v493 = v492.kind .. ":" .. v492.detail
			table.insert(v491, v493)
		end
		local v494 = 0
		for _, v495 in v_u_185 do
			if not v495.used then
				continue
			end
			v494 = v494 + 1
		end
		local v496 = string.format
		local v497 = "card=%s queue=%d chips=%s barVisible=%s edges=%d"
		local v498
		if v_u_264 then
			local v499 = v_u_264.p.text
			v498 = tostring(v499)
		else
			v498 = "-"
		end
		local v500 = #v_u_263
		local v501 = table.concat(v491, ",")
		local v502 = v_u_143.Visible
		return v496(v497, v498, v500, v501, tostring(v502), v494)
	end
	function v_u_12.destroy() -- name: destroy
		-- upvalues: (ref) v_u_15, (ref) v_u_443, (copy) v_u_185, (copy) v_u_143, (copy) v_u_261, (copy) p_u_6, (copy) v_u_11
		v_u_15 = false
		if v_u_443 then
			local v503 = v_u_443.destroy
			pcall(v503)
			v_u_443 = nil
		end
		for _, v504 in v_u_185 do
			local v505 = v504.m.destroy
			local v506 = v504.m
			pcall(v505, v506)
		end
		table.clear(v_u_185)
		v_u_143:Destroy()
		v_u_261:Destroy()
		p_u_6.eventBarH = 0
		v_u_11:SetAttribute("EventFeedState", nil)
	end
	return v_u_12
end
return v3