-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GlobeInput

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("GuiService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_6 = require(v_u_5:WaitForChild("Theme"))
local v_u_7 = require(v_u_5:WaitForChild("GlobeMath"))
local v_u_8 = require(v_u_5:WaitForChild("GlobeInputRule"))
local v_u_9 = require(script.Parent:WaitForChild("HushUI"))
local v_u_10 = require(script.Parent:WaitForChild("UiPointer"))
local v_u_11 = require(script.Parent:WaitForChild("VirtualPad"))
local v_u_12 = v1.LocalPlayer
local v_u_13 = v_u_7.CONST
local v_u_14 = Enum.KeyCode
local v_u_15 = Enum.UserInputType
local v_u_16 = math.min
local v_u_17 = math.max
local v_u_18 = math.abs
local v_u_19 = {
	["TUNING"] = {
		["OPEN_LOCK_S"] = 0.2,
		["STOP_TAP_S"] = 0.3,
		["NAV_NEAR_DEG"] = 1,
		["RIM_S"] = 0.12,
		["FLAG"] = "GlobeGamepad",
		["TAB_GRACE_S"] = 0.1,
		["SEL_DELAY_S"] = 0.05,
		["R3_STICK"] = 0.5,
		["R3_QUIET_S"] = 0.3,
		["SNAP_FACTOR"] = 2,
		["HELD_PXS"] = 1
	}
}
local v_u_20 = v_u_19.TUNING
local function v_u_31() -- name: newSignal
	local v_u_21 = {}
	return {
		["Connect"] = function(_, p22) -- name: Connect
			-- upvalues: (copy) v_u_21
			local v_u_23 = {
				["fn"] = p22
			}
			local v24 = v_u_21
			table.insert(v24, v_u_23)
			return {
				["Connected"] = true,
				["Disconnect"] = function(p25) -- name: Disconnect
					-- upvalues: (ref) v_u_21, (copy) v_u_23
					p25.Connected = false
					local v26 = table.find(v_u_21, v_u_23)
					if v26 then
						table.remove(v_u_21, v26)
					end
				end
			}
		end,
		["Fire"] = function(_, ...) -- name: Fire
			-- upvalues: (copy) v_u_21
			for _, v27 in table.clone(v_u_21) do
				local v28 = v27.fn
				local v29, v30 = pcall(v28, ...)
				if v29 then
					continue
				end
				warn("GlobeInput: handler failed: " .. tostring(v30))
			end
		end
	}
end
function v_u_19.new(p32) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_31, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_3, (copy) v_u_20, (copy) v_u_8, (copy) v_u_15, (copy) v_u_4, (copy) v_u_6, (copy) v_u_14, (copy) v_u_13, (copy) v_u_18, (copy) v_u_16, (copy) v_u_7, (copy) v_u_17, (copy) v_u_5
	local v_u_33 = p32 or {}
	local v_u_34 = {}
	local v_u_35 = v_u_33.clock or os.clock
	local v_u_36 = v_u_33.source or v_u_2
	local v_u_37 = v_u_33.pad or v_u_11
	local v_u_38 = v_u_33.kind or "pc"
	local v_u_39 = nil
	local v_u_40 = nil
	local v_u_41 = nil
	local v_u_42 = nil
	local v_u_43 = false
	local v_u_44 = false
	local v_u_45 = 0
	local v_u_46 = {}
	local v_u_47 = true
	local v_u_48 = -1000000000
	local v_u_49 = nil
	local v_u_50 = -1000000000
	local v_u_51 = false
	local v_u_52 = {}
	local v_u_53 = {}
	local v_u_54 = {}
	local v_u_55 = nil
	local v_u_56 = nil
	local v_u_57 = nil
	local v_u_58 = false
	local v_u_59 = 0
	local v_u_60 = 0
	local v_u_61 = false
	local v_u_62 = false
	local v_u_63 = {}
	local v_u_64 = {
		["lat0"] = 1000000000,
		["lon0"] = 1000000000,
		["z"] = -1
	}
	local v_u_65 = nil
	local v_u_66 = -1
	local v_u_67 = false
	local v_u_68 = nil
	local v_u_69 = {
		["presses"] = 0,
		["wheels"] = 0,
		["picks"] = 0,
		["padA"] = 0,
		["aborts"] = 0,
		["steps"] = 0,
		["pulses"] = 0
	}
	local v_u_70 = {
		["began"] = v_u_31(),
		["changed"] = v_u_31(),
		["ended"] = v_u_31(),
		["focusLost"] = v_u_31()
	}
	v_u_34.fakePressed = {}
	v_u_34.fakeMouse = nil
	function v_u_34.inputKind() -- name: inputKind
		-- upvalues: (copy) v_u_33, (ref) v_u_9
		if v_u_33.inputKind then
			return v_u_33.inputKind()
		end
		local v71 = v_u_9.device
		local v72, v73 = pcall(v71)
		if v72 then
			if v73 == "Gamepad" then
				return "pad"
			end
			if v73 == "Touch" then
				return "touch"
			end
		end
		return "mouse"
	end
	function v_u_34.keyName(p74) -- name: keyName
		-- upvalues: (copy) v_u_33, (ref) v_u_9
		if v_u_33.keyName then
			return v_u_33.keyName(p74)
		else
			local v75 = v_u_9.hint
			local v76, v77 = pcall(v75, p74)
			if v76 and (type(v77) == "string" and v77 ~= "") then
				return v77
			else
				return nil
			end
		end
	end
	local function v_u_80() -- name: pageVisible
		-- upvalues: (ref) v_u_39, (ref) v_u_40, (copy) v_u_33
		if not (v_u_39 and v_u_40) then
			return false
		end
		if v_u_33.pageVisible and not v_u_33.pageVisible() then
			return false
		end
		local v78 = v_u_40
		while v78 and not v78:IsA("LayerCollector") do
			if v78:IsA("GuiObject") and not v78.Visible then
				return false
			end
			v78 = v78.Parent
		end
		local v79
		if v78 == nil then
			v79 = false
		else
			v79 = not v78:IsA("ScreenGui") or v78.Enabled
		end
		return v79
	end
	function v_u_34.usable() -- name: usable
		-- upvalues: (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12
		if not v_u_44 then
			return false
		end
		local v81 = v_u_80()
		if v81 then
			local v82, v83
			if v_u_33.modalCount then
				local v84 = v_u_33.modalCount
				v82, v83 = pcall(v84)
			else
				local v85 = v_u_9.modalCount
				v82, v83 = pcall(v85)
			end
			if v82 then
				if type(v83) == "number" then
					v82 = v83 > 0
				else
					v82 = false
				end
			end
			v81 = not v82
			if v81 then
				local v86
				if v_u_33.windowOpen == nil then
					v86 = false
				else
					v86 = v_u_33.windowOpen() == true
				end
				v81 = not v86
				if v81 then
					local v87
					if v_u_12 == nil then
						v87 = false
					else
						v87 = v_u_12:GetAttribute("CrateStageOn") == true
					end
					v81 = not v87
				end
			end
		end
		return v81
	end
	function v_u_34.padOwns() -- name: padOwns
		-- upvalues: (ref) v_u_47, (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20
		if v_u_47 then
			local v88 = v_u_44 and v_u_80()
			if v88 then
				local v89, v90
				if v_u_33.modalCount then
					local v91 = v_u_33.modalCount
					v89, v90 = pcall(v91)
				else
					local v92 = v_u_9.modalCount
					v89, v90 = pcall(v92)
				end
				if v89 then
					if type(v90) == "number" then
						v89 = v90 > 0
					else
						v89 = false
					end
				end
				v88 = not v89
				if v88 then
					local v93
					if v_u_33.windowOpen == nil then
						v93 = false
					else
						v93 = v_u_33.windowOpen() == true
					end
					v88 = not v93
					if v88 then
						local v94
						if v_u_12 == nil then
							v94 = false
						else
							v94 = v_u_12:GetAttribute("CrateStageOn") == true
						end
						v88 = not v94
					end
				end
			end
			if v88 then
				local v95
				if v_u_33.selected then
					v95 = v_u_33.selected()
				else
					v95 = v_u_3.SelectedObject
				end
				if v95 == nil or v95 == v_u_41 then
					return true
				end
				local v96
				if v95.Name == "Tab_play" then
					v96 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
				else
					v96 = false
				end
				return v96
			end
		end
		return false
	end
	local function v_u_104() -- name: blockRects
		-- upvalues: (ref) v_u_39, (copy) v_u_33
		local v97 = {}
		if v_u_39 and v_u_39.buttons then
			for _, v98 in v_u_39.buttons do
				local v99 = v98 and (v98.Parent and v98.Visible) and {
					["x"] = v98.AbsolutePosition.X,
					["y"] = v98.AbsolutePosition.Y,
					["w"] = v98.AbsoluteSize.X,
					["h"] = v98.AbsoluteSize.Y
				} or nil
				table.insert(v97, v99)
			end
		end
		local v100 = v_u_39 and v_u_39.listParts
		if v100 then
			v100 = v_u_39.listParts()
		end
		if v100 then
			local v101 = v100.frame
			local v102 = v101 and (v101.Parent and v101.Visible) and {
				["x"] = v101.AbsolutePosition.X,
				["y"] = v101.AbsolutePosition.Y,
				["w"] = v101.AbsoluteSize.X,
				["h"] = v101.AbsoluteSize.Y
			} or nil
			table.insert(v97, v102)
		end
		if v_u_33.blockRects then
			for _, v103 in v_u_33.blockRects() do
				table.insert(v97, v103)
			end
		end
		return v97
	end
	local function v_u_110() -- name: scrollRects
		-- upvalues: (ref) v_u_39, (copy) v_u_33
		local v105 = {}
		local v106 = v_u_39 and v_u_39.listParts
		if v106 then
			v106 = v_u_39.listParts()
		end
		if v106 then
			local v107 = v106.frame
			local v108 = v107 and (v107.Parent and v107.Visible) and {
				["x"] = v107.AbsolutePosition.X,
				["y"] = v107.AbsolutePosition.Y,
				["w"] = v107.AbsoluteSize.X,
				["h"] = v107.AbsoluteSize.Y
			} or nil
			table.insert(v105, v108)
		end
		if v_u_33.scrollRects then
			for _, v109 in v_u_33.scrollRects() do
				table.insert(v105, v109)
			end
		end
		return v105
	end
	local function v_u_115(p111) -- name: makeRule
		-- upvalues: (ref) v_u_43, (ref) v_u_39, (ref) v_u_42, (ref) v_u_8, (ref) v_u_45, (copy) v_u_34, (ref) v_u_64
		v_u_43 = p111
		local v112 = v_u_39.view
		local v113 = v_u_8.new
		local v114 = {
			["lensR"] = v_u_45 / 2,
			["view"] = {
				["lat0"] = v112.lat0,
				["lon0"] = v112.lon0,
				["z"] = v112.z
			},
			["touch"] = p111
		}
		v_u_42 = v113(v114)
		v_u_34.rule = v_u_42
		v_u_64 = {
			["lat0"] = v112.lat0,
			["lon0"] = v112.lon0,
			["z"] = v112.z
		}
	end
	local function v_u_134() -- name: abort
		-- upvalues: (copy) v_u_69, (ref) v_u_42, (ref) v_u_56, (copy) v_u_52, (copy) v_u_53, (copy) v_u_54, (ref) v_u_55, (ref) v_u_57, (ref) v_u_58, (ref) v_u_61, (ref) v_u_59, (ref) v_u_39, (ref) v_u_64
		local v116 = v_u_69
		v116.aborts = v116.aborts + 1
		local v117
		if v_u_42 == nil then
			v117 = false
		else
			v117 = (v_u_42.state ~= "IDLE" or v_u_56 ~= nil) and true or next(v_u_52) ~= nil
		end
		if v_u_42 then
			v_u_42.cancel()
		end
		table.clear(v_u_52)
		table.clear(v_u_53)
		table.clear(v_u_54)
		v_u_55 = nil
		v_u_56 = nil
		v_u_57 = nil
		v_u_58 = false
		v_u_61 = false
		v_u_59 = 0
		if v_u_39 and v_u_42 then
			if v117 and not v_u_39.flying() then
				local v118 = v_u_42.view
				v_u_39.setViewRaw(v118.lat0, v118.lon0, v118.z)
				local v119 = v_u_39.view
				local v120 = v_u_64
				local v121 = v_u_64
				local v122 = v_u_64
				local v123 = v119.lat0
				local v124 = v119.lon0
				local v125 = v119.z
				v120.lat0 = v123
				v121.lon0 = v124
				v122.z = v125
				return
			end
			local v126 = v_u_39.view
			v_u_42.flyTo(v126.lat0, v126.lon0, v126.z, true)
			local v127 = v_u_39.view
			local v128 = v_u_64
			local v129 = v_u_64
			local v130 = v_u_64
			local v131 = v127.lat0
			local v132 = v127.lon0
			local v133 = v127.z
			v128.lat0 = v131
			v129.lon0 = v132
			v130.z = v133
		end
	end
	function v_u_34.justDragged() -- name: justDragged
		-- upvalues: (ref) v_u_42, (copy) v_u_35, (ref) v_u_59, (ref) v_u_56, (ref) v_u_55, (ref) v_u_60
		if not v_u_42 then
			return false
		end
		local v135 = v_u_35()
		local v136
		if v_u_59 == (1 / 0) then
			v136 = (v_u_56 ~= nil or v_u_55 ~= nil) and true or v_u_42.state ~= "IDLE"
		else
			v136 = false
		end
		return v_u_42.justDragged(v135) or (v136 or (v_u_59 ~= (1 / 0) and v135 < v_u_59 and true or v135 < v_u_60))
	end
	local function v_u_169(p137, p138, p139) -- name: beginPointer
		-- upvalues: (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (ref) v_u_40, (ref) v_u_45, (copy) v_u_104, (ref) v_u_8, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42, (ref) v_u_43, (copy) v_u_115, (copy) v_u_35, (ref) v_u_56, (ref) v_u_61, (ref) v_u_59, (copy) v_u_69
		local v140 = v_u_44 and v_u_80()
		if v140 then
			local v141, v142
			if v_u_33.modalCount then
				local v143 = v_u_33.modalCount
				v141, v142 = pcall(v143)
			else
				local v144 = v_u_9.modalCount
				v141, v142 = pcall(v144)
			end
			if v141 then
				if type(v142) == "number" then
					v141 = v142 > 0
				else
					v141 = false
				end
			end
			v140 = not v141
			if v140 then
				local v145
				if v_u_33.windowOpen == nil then
					v145 = false
				else
					v145 = v_u_33.windowOpen() == true
				end
				v140 = not v145
				if v140 then
					local v146
					if v_u_12 == nil then
						v146 = false
					else
						v146 = v_u_12:GetAttribute("CrateStageOn") == true
					end
					v140 = not v146
				end
			end
		end
		if not v140 then
			return false
		end
		local v147 = v_u_10.toLocal(v_u_40, p138)
		local v148 = v147.X - v_u_45 / 2
		local v149 = v147.Y - v_u_45 / 2
		if v148 * v148 + v149 * v149 > v_u_45 / 2 * (v_u_45 / 2) then
			return false
		end
		local v150 = {}
		for _, v151 in v_u_104() do
			if not v151 then
				continue
			end
			table.insert(v150, v151)
		end
		if v_u_8.overAny(v150, p138.X, p138.Y) then
			return false
		end
		local v152 = v_u_39.view
		if v152.lat0 ~= v_u_64.lat0 or (v152.lon0 ~= v_u_64.lon0 or v152.z ~= v_u_64.z) then
			if v_u_42.state == "IDLE" then
				v_u_42.flyTo(v152.lat0, v152.lon0, v152.z, true)
			end
			local v153 = v_u_39.view
			local v154 = v_u_64
			local v155 = v_u_64
			local v156 = v_u_64
			local v157 = v153.lat0
			local v158 = v153.lon0
			local v159 = v153.z
			v154.lat0 = v157
			v155.lon0 = v158
			v156.z = v159
		end
		if p139 ~= v_u_43 and (v_u_42.state == "IDLE" and not v_u_42.busy()) then
			v_u_115(p139)
		end
		local v160 = v_u_42.state ~= "IDLE" and true or (v_u_42.flying() or v_u_39.flying())
		v_u_39.cancelFlight()
		local v161 = v_u_39.pickAt
		local v162 = v147.X
		local v163 = v147.Y
		local v164, v165 = pcall(v161, v162, v163)
		local v166 = v164 and v165 ~= nil and true or false
		local v167 = v_u_42.press(p137, v147.X, v147.Y, v_u_35(), v166)
		if v167 then
			v_u_56 = p137
			v_u_61 = v160
			if v160 then
				v_u_59 = (1 / 0)
			end
			local v168 = v_u_69
			v168.presses = v168.presses + 1
			v_u_39.gesture()
			v_u_39.wake()
		end
		return v167
	end
	local function v_u_179(p170, p171) -- name: releasePointer
		-- upvalues: (ref) v_u_56, (ref) v_u_10, (ref) v_u_40, (ref) v_u_42, (copy) v_u_35, (ref) v_u_61, (ref) v_u_59, (ref) v_u_20, (ref) v_u_39
		if v_u_56 == p170 then
			local v172 = v_u_10.toLocal(v_u_40, p171)
			local v173 = v_u_42.release(p170, v172.X, v172.Y, v_u_35())
			v_u_56 = nil
			if v_u_61 then
				v_u_59 = v_u_35() + v_u_20.STOP_TAP_S
				v_u_61 = false
			end
			if v173 == "drag" then
				v_u_39.gesture()
			elseif v173 == "tap" and v_u_39.listOpen() then
				local v174 = v_u_39.pickAt
				local v175 = v172.X
				local v176 = v172.Y
				local v177, v178 = pcall(v174, v175, v176)
				if not v177 or v178 == nil then
					v_u_39.closeList()
				end
			end
			v_u_39.wake()
		end
	end
	local function v_u_187() -- name: pinchUpdate
		-- upvalues: (ref) v_u_8, (copy) v_u_53, (copy) v_u_52, (ref) v_u_10, (ref) v_u_40, (ref) v_u_55, (ref) v_u_42, (ref) v_u_56, (copy) v_u_35, (ref) v_u_39
		local v180, v181 = v_u_8.pickTouches(v_u_53, v_u_52)
		if v180 ~= nil and v181 ~= nil then
			local v182 = v_u_52[v180]
			local v183 = v_u_10.toLocal(v_u_40, v182)
			local v184 = v_u_52[v181]
			local v185 = v_u_10.toLocal(v_u_40, v184)
			local v186 = v_u_55
			if v186 == nil or (v186[1] ~= v180 or v186[2] ~= v181) then
				if v_u_42.state == "PINCH" then
					v_u_42.pinchEnd()
				end
				v_u_55 = { v180, v181 }
			end
			v_u_56 = nil
			v_u_42.pinch(v183.X, v183.Y, v185.X, v185.Y, v_u_35())
			v_u_39.gesture()
			v_u_39.wake()
		end
	end
	local function v_u_214(p188, _) -- name: onBegan
		-- upvalues: (ref) v_u_44, (ref) v_u_15, (ref) v_u_10, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_40, (ref) v_u_45, (copy) v_u_104, (ref) v_u_8, (copy) v_u_52, (copy) v_u_53, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42, (copy) v_u_187, (copy) v_u_169, (ref) v_u_57, (ref) v_u_58
		if v_u_44 then
			local v189 = p188.UserInputType
			if v189 == v_u_15.Touch then
				local v190 = v_u_10.ioAbs(p188)
				local v191 = v_u_44 and v_u_80()
				if v191 then
					local v192, v193
					if v_u_33.modalCount then
						local v194 = v_u_33.modalCount
						v192, v193 = pcall(v194)
					else
						local v195 = v_u_9.modalCount
						v192, v193 = pcall(v195)
					end
					if v192 then
						if type(v193) == "number" then
							v192 = v193 > 0
						else
							v192 = false
						end
					end
					v191 = not v192
					if v191 then
						local v196
						if v_u_33.windowOpen == nil then
							v196 = false
						else
							v196 = v_u_33.windowOpen() == true
						end
						v191 = not v196
						if v191 then
							local v197
							if v_u_12 == nil then
								v197 = false
							else
								v197 = v_u_12:GetAttribute("CrateStageOn") == true
							end
							v191 = not v197
						end
					end
				end
				if v191 then
					local v198 = v_u_10.toLocal(v_u_40, v190)
					local v199 = v198.X - v_u_45 / 2
					local v200 = v198.Y - v_u_45 / 2
					if v199 * v199 + v200 * v200 <= v_u_45 / 2 * (v_u_45 / 2) then
						local v201 = {}
						for _, v202 in v_u_104() do
							if not v202 then
								continue
							end
							table.insert(v201, v202)
						end
						if v_u_8.overAny(v201, v190.X, v190.Y) then
							return
						else
							v_u_52[p188] = v190
							local v203 = v_u_53
							table.insert(v203, p188)
							local v204 = 0
							for _ in v_u_52 do
								v204 = v204 + 1
							end
							if v204 >= 2 then
								local v205 = v_u_39.view
								if v205.lat0 ~= v_u_64.lat0 or (v205.lon0 ~= v_u_64.lon0 or v205.z ~= v_u_64.z) then
									if v_u_42.state == "IDLE" then
										v_u_42.flyTo(v205.lat0, v205.lon0, v205.z, true)
									end
									local v206 = v_u_39.view
									local v207 = v_u_64
									local v208 = v_u_64
									local v209 = v_u_64
									local v210 = v206.lat0
									local v211 = v206.lon0
									local v212 = v206.z
									v207.lat0 = v210
									v208.lon0 = v211
									v209.z = v212
								end
								v_u_39.cancelFlight()
								v_u_187()
							else
								v_u_169(p188, v190, true)
							end
						end
					else
						return
					end
				else
					return
				end
			else
				if v189 == v_u_15.MouseButton1 or (v189 == v_u_15.MouseButton2 or v189 == v_u_15.MouseButton3) then
					if v_u_57 ~= nil then
						return
					end
					local v213
					if type(p188) == "table" then
						v213 = rawget(p188, "fake") == true
					else
						v213 = false
					end
					v_u_58 = v213
					if v_u_169("mouse", v_u_10.ioAbs(p188), false) then
						v_u_57 = v189
						return
					end
					v_u_58 = false
				end
				return
			end
		else
			return
		end
	end
	local function v_u_287(p215, _) -- name: onChanged
		-- upvalues: (ref) v_u_44, (ref) v_u_15, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (copy) v_u_34, (ref) v_u_10, (ref) v_u_40, (ref) v_u_45, (ref) v_u_8, (copy) v_u_110, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42, (copy) v_u_35, (copy) v_u_69, (copy) v_u_52, (copy) v_u_134, (copy) v_u_187, (copy) v_u_54, (ref) v_u_56, (ref) v_u_57, (ref) v_u_58, (ref) v_u_2, (ref) v_u_62, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_4, (ref) v_u_20, (ref) v_u_6
		if v_u_44 then
			local v216 = p215.UserInputType
			if v216 == v_u_15.MouseWheel then
				local v217 = v_u_44 and v_u_80()
				if v217 then
					local v218, v219
					if v_u_33.modalCount then
						local v220 = v_u_33.modalCount
						v218, v219 = pcall(v220)
					else
						local v221 = v_u_9.modalCount
						v218, v219 = pcall(v221)
					end
					if v218 then
						if type(v219) == "number" then
							v218 = v219 > 0
						else
							v218 = false
						end
					end
					v217 = not v218
					if v217 then
						local v222
						if v_u_33.windowOpen == nil then
							v222 = false
						else
							v222 = v_u_33.windowOpen() == true
						end
						v217 = not v222
						if v217 then
							local v223
							if v_u_12 == nil then
								v223 = false
							else
								v223 = v_u_12:GetAttribute("CrateStageOn") == true
							end
							v217 = not v223
						end
					end
				end
				if v217 then
					local v224 = p215.Position.Z
					if v224 == 0 then
						return
					else
						local v225
						if v_u_34.fakeMouse then
							v225 = v_u_34.fakeMouse
						elseif v_u_33.mouseAbs then
							v225 = v_u_33.mouseAbs()
						else
							v225 = v_u_10.mouseAbs()
						end
						local v226 = v_u_10.toLocal(v_u_40, v225)
						local v227 = v226.X - v_u_45 / 2
						local v228 = v226.Y - v_u_45 / 2
						if v227 * v227 + v228 * v228 <= v_u_45 / 2 * (v_u_45 / 2) then
							local v229 = v_u_8.overAny
							local v230 = {}
							for _, v231 in v_u_110() do
								if not v231 then
									continue
								end
								table.insert(v230, v231)
							end
							if not v229(v230, v225.X, v225.Y) then
								local v232 = v_u_39.view
								if v232.lat0 ~= v_u_64.lat0 or (v232.lon0 ~= v_u_64.lon0 or v232.z ~= v_u_64.z) then
									if v_u_42.state == "IDLE" then
										v_u_42.flyTo(v232.lat0, v232.lon0, v232.z, true)
									end
									local v233 = v_u_39.view
									local v234 = v_u_64
									local v235 = v_u_64
									local v236 = v_u_64
									local v237 = v233.lat0
									local v238 = v233.lon0
									local v239 = v233.z
									v234.lat0 = v237
									v235.lon0 = v238
									v236.z = v239
								end
								v_u_39.cancelFlight()
								v_u_42.wheel(v224, v226.X, v226.Y, v_u_35())
								local v240 = v_u_69
								v240.wheels = v240.wheels + 1
								v_u_39.gesture()
								v_u_39.wake()
							end
						else
							return
						end
					end
				else
					return
				end
			elseif v216 == v_u_15.Touch then
				if v_u_52[p215] == nil then
					return
				else
					local v241 = v_u_10.ioAbs(p215)
					v_u_52[p215] = v241
					local v242 = v_u_44 and v_u_80()
					if v242 then
						local v243, v244
						if v_u_33.modalCount then
							local v245 = v_u_33.modalCount
							v243, v244 = pcall(v245)
						else
							local v246 = v_u_9.modalCount
							v243, v244 = pcall(v246)
						end
						if v243 then
							if type(v244) == "number" then
								v243 = v244 > 0
							else
								v243 = false
							end
						end
						v242 = not v243
						if v242 then
							local v247
							if v_u_33.windowOpen == nil then
								v247 = false
							else
								v247 = v_u_33.windowOpen() == true
							end
							v242 = not v247
							if v242 then
								local v248
								if v_u_12 == nil then
									v248 = false
								else
									v248 = v_u_12:GetAttribute("CrateStageOn") == true
								end
								v242 = not v248
							end
						end
					end
					if v242 then
						local v249 = 0
						for _ in v_u_52 do
							v249 = v249 + 1
						end
						if v249 >= 2 then
							v_u_187()
						elseif not v_u_54[p215] then
							if v_u_56 ~= p215 then
								return
							end
							local v250 = v_u_10.toLocal(v_u_40, v241)
							v_u_42.move(p215, v250.X, v250.Y, v_u_35())
							v_u_39.gesture()
							v_u_39.wake()
						end
					else
						v_u_134()
						return
					end
				end
			else
				if v216 == v_u_15.MouseMovement then
					local v251 = v_u_10.ioAbs(p215)
					if v_u_57 ~= nil and v_u_56 == "mouse" then
						local v252 = v_u_44 and v_u_80()
						if v252 then
							local v253, v254
							if v_u_33.modalCount then
								local v255 = v_u_33.modalCount
								v253, v254 = pcall(v255)
							else
								local v256 = v_u_9.modalCount
								v253, v254 = pcall(v256)
							end
							if v253 then
								if type(v254) == "number" then
									v253 = v254 > 0
								else
									v253 = false
								end
							end
							v252 = not v253
							if v252 then
								local v257
								if v_u_33.windowOpen == nil then
									v257 = false
								else
									v257 = v_u_33.windowOpen() == true
								end
								v252 = not v257
								if v252 then
									local v258
									if v_u_12 == nil then
										v258 = false
									else
										v258 = v_u_12:GetAttribute("CrateStageOn") == true
									end
									v252 = not v258
								end
							end
						end
						if v252 then
							local v259 = v_u_57
							local v260
							if v_u_58 then
								v260 = v_u_34.fakePressed[v259] == true
							elseif v_u_33.mousePressed then
								v260 = v_u_33.mousePressed(v259) == true
							else
								local v261 = v_u_2.IsMouseButtonPressed
								local v262 = v_u_2
								local v263
								v260, v263 = pcall(v261, v262, v259)
								if v260 then
									v260 = v263 == true
								end
							end
							if v260 then
								if v_u_56 == "mouse" then
									local v264 = v_u_10.toLocal(v_u_40, v251)
									v_u_42.move("mouse", v264.X, v264.Y, v_u_35())
									v_u_39.gesture()
									v_u_39.wake()
								end
							else
								v_u_134()
								return
							end
						else
							v_u_134()
							return
						end
					end
					local v265 = v_u_10.toLocal(v_u_40, v251)
					local v266 = v265.X - v_u_45 / 2
					local v267 = v265.Y - v_u_45 / 2
					local v_u_268 = v266 * v266 + v267 * v267 <= v_u_45 / 2 * (v_u_45 / 2)
					if v_u_268 or v_u_62 then
						local v269
						if v_u_33.inputKind then
							v269 = v_u_33.inputKind()
						else
							local v270 = v_u_9.device
							local v271, v272 = pcall(v270)
							v269 = v271 and (v272 == "Gamepad" and "pad" or (v272 == "Touch" and "touch" or "mouse")) or "mouse"
						end
						if v269 == "mouse" then
							if v_u_268 then
								local v273 = v_u_35()
								if v273 - v_u_66 > 0.05 then
									local v274 = v_u_44 and v_u_80()
									if v274 then
										local v275, v276
										if v_u_33.modalCount then
											local v277 = v_u_33.modalCount
											v275, v276 = pcall(v277)
										else
											local v278 = v_u_9.modalCount
											v275, v276 = pcall(v278)
										end
										if v275 then
											if type(v276) == "number" then
												v275 = v276 > 0
											else
												v275 = false
											end
										end
										v274 = not v275
										if v274 then
											local v279
											if v_u_33.windowOpen == nil then
												v279 = false
											else
												v279 = v_u_33.windowOpen() == true
											end
											v274 = not v279
											if v274 then
												local v280
												if v_u_12 == nil then
													v280 = false
												else
													v280 = v_u_12:GetAttribute("CrateStageOn") == true
												end
												v274 = not v280
											end
										end
									end
									v_u_66 = v273
									v_u_67 = v274
								end
								v_u_268 = v_u_67
							end
							if v_u_268 then
								v_u_39.setPointer(v265.X, v265.Y)
							elseif v_u_62 then
								v_u_39.setPointer(nil, nil)
							end
							if v_u_268 ~= v_u_62 then
								v_u_62 = v_u_268
								if v_u_68 then
									local function v286()
										-- upvalues: (ref) v_u_4, (ref) v_u_68, (ref) v_u_20, (ref) v_u_268, (ref) v_u_6
										local v281 = v_u_4
										local v282 = v_u_68
										local v283 = TweenInfo.new(v_u_20.RIM_S)
										local v284 = {}
										local v285
										if v_u_268 then
											v285 = v_u_6.color.text2
										else
											v285 = v_u_6.color.lineStrong
										end
										v284.Color = v285
										v281:Create(v282, v283, v284):Play()
									end
									pcall(v286)
								end
							end
						end
					end
				end
				return
			end
		else
			return
		end
	end
	local function v_u_297(p288, _) -- name: onEnded
		-- upvalues: (ref) v_u_44, (ref) v_u_15, (copy) v_u_52, (ref) v_u_10, (ref) v_u_55, (copy) v_u_53, (copy) v_u_187, (ref) v_u_42, (ref) v_u_56, (ref) v_u_61, (ref) v_u_59, (copy) v_u_35, (ref) v_u_20, (copy) v_u_169, (copy) v_u_54, (copy) v_u_179, (ref) v_u_39, (ref) v_u_57, (ref) v_u_58
		if v_u_44 then
			local v289 = p288.UserInputType
			if v289 == v_u_15.Touch then
				if v_u_52[p288] ~= nil then
					local v290 = v_u_10.ioAbs(p288)
					v_u_52[p288] = v290
					local v291 = v_u_55
					v_u_52[p288] = nil
					local v292 = table.find(v_u_53, p288)
					if v292 then
						table.remove(v_u_53, v292)
					end
					local v293 = 0
					for _ in v_u_52 do
						v293 = v293 + 1
					end
					if v293 >= 2 then
						v_u_187()
					else
						if v_u_42.state == "PINCH" then
							v_u_42.pinchEnd()
							v_u_55 = nil
							v_u_56 = nil
							if v_u_61 then
								v_u_59 = v_u_35() + v_u_20.STOP_TAP_S
								v_u_61 = false
							end
							for v294, v295 in v_u_52 do
								if v_u_169(v294, v295, true) then
									continue
								end
								v_u_54[v294] = true
							end
						elseif v291 == nil and not v_u_54[p288] then
							v_u_179(p288, v290)
						end
						if v293 == 0 then
							table.clear(v_u_54)
							v_u_55 = nil
							if v_u_56 == p288 then
								v_u_56 = nil
								if v_u_61 then
									v_u_59 = v_u_35() + v_u_20.STOP_TAP_S
									v_u_61 = false
								end
							end
						end
					end
					v_u_54[p288] = nil
					v_u_39.wake()
				end
			else
				if v_u_57 ~= nil and v289 == v_u_57 then
					local v296 = v_u_10.ioAbs(p288)
					v_u_57 = nil
					v_u_58 = false
					v_u_179("mouse", v296)
				end
				return
			end
		else
			return
		end
	end
	local v_u_298 = {
		[v_u_14.Up] = true,
		[v_u_14.Down] = true,
		[v_u_14.Left] = true,
		[v_u_14.Right] = true
	}
	local function v_u_327() -- name: keysAllowed
		-- upvalues: (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_2, (ref) v_u_47, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (copy) v_u_34, (ref) v_u_10, (ref) v_u_40, (ref) v_u_45
		local v299 = v_u_44 and v_u_80()
		if v299 then
			local v300, v301
			if v_u_33.modalCount then
				local v302 = v_u_33.modalCount
				v300, v301 = pcall(v302)
			else
				local v303 = v_u_9.modalCount
				v300, v301 = pcall(v303)
			end
			if v300 then
				if type(v301) == "number" then
					v300 = v301 > 0
				else
					v300 = false
				end
			end
			v299 = not v300
			if v299 then
				local v304
				if v_u_33.windowOpen == nil then
					v304 = false
				else
					v304 = v_u_33.windowOpen() == true
				end
				v299 = not v304
				if v299 then
					local v305
					if v_u_12 == nil then
						v305 = false
					else
						v305 = v_u_12:GetAttribute("CrateStageOn") == true
					end
					v299 = not v305
				end
			end
		end
		if v299 then
			local v306
			if v_u_33.textFocused then
				v306 = v_u_33.textFocused() == true
			else
				local v307 = v_u_2.GetFocusedTextBox
				local v308 = v_u_2
				local v309
				v306, v309 = pcall(v307, v308)
				if v306 then
					v306 = v309 ~= nil
				end
			end
			if not v306 then
				local v310
				if v_u_47 then
					local v311 = v_u_44 and v_u_80()
					if v311 then
						local v312, v313
						if v_u_33.modalCount then
							local v314 = v_u_33.modalCount
							v312, v313 = pcall(v314)
						else
							local v315 = v_u_9.modalCount
							v312, v313 = pcall(v315)
						end
						if v312 then
							if type(v313) == "number" then
								v312 = v313 > 0
							else
								v312 = false
							end
						end
						v311 = not v312
						if v311 then
							local v316
							if v_u_33.windowOpen == nil then
								v316 = false
							else
								v316 = v_u_33.windowOpen() == true
							end
							v311 = not v316
							if v311 then
								local v317
								if v_u_12 == nil then
									v317 = false
								else
									v317 = v_u_12:GetAttribute("CrateStageOn") == true
								end
								v311 = not v317
							end
						end
					end
					if v311 then
						local v318
						if v_u_33.selected then
							v318 = v_u_33.selected()
						else
							v318 = v_u_3.SelectedObject
						end
						if v318 == nil or v318 == v_u_41 then
							v310 = true
						elseif v318.Name == "Tab_play" then
							v310 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
						else
							v310 = false
						end
					else
						v310 = false
					end
				else
					v310 = false
				end
				if v310 then
					local v319
					if v_u_33.inputKind then
						v319 = v_u_33.inputKind()
					else
						local v320 = v_u_9.device
						local v321, v322 = pcall(v320)
						v319 = v321 and (v322 == "Gamepad" and "pad" or (v322 == "Touch" and "touch" or "mouse")) or "mouse"
					end
					if v319 == "pad" then
						return true
					end
				end
				local v323
				if v_u_34.fakeMouse then
					v323 = v_u_34.fakeMouse
				elseif v_u_33.mouseAbs then
					v323 = v_u_33.mouseAbs()
				else
					v323 = v_u_10.mouseAbs()
				end
				local v324 = v_u_10.toLocal(v_u_40, v323)
				local v325 = v324.X - v_u_45 / 2
				local v326 = v324.Y - v_u_45 / 2
				return v325 * v325 + v326 * v326 <= v_u_45 / 2 * (v_u_45 / 2)
			end
		end
		return false
	end
	local function v_u_338(p328, _) -- name: onKeyBegan
		-- upvalues: (ref) v_u_44, (ref) v_u_15, (copy) v_u_298, (copy) v_u_327, (copy) v_u_63, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42, (ref) v_u_14
		if v_u_44 and p328.UserInputType == v_u_15.Keyboard then
			local v329 = p328.KeyCode
			if v_u_298[v329] then
				if v_u_327() then
					v_u_63[v329] = true
					local v330 = v_u_39.view
					if v330.lat0 ~= v_u_64.lat0 or (v330.lon0 ~= v_u_64.lon0 or v330.z ~= v_u_64.z) then
						if v_u_42.state == "IDLE" then
							v_u_42.flyTo(v330.lat0, v330.lon0, v330.z, true)
						end
						local v331 = v_u_39.view
						local v332 = v_u_64
						local v333 = v_u_64
						local v334 = v_u_64
						local v335 = v331.lat0
						local v336 = v331.lon0
						local v337 = v331.z
						v332.lat0 = v335
						v333.lon0 = v336
						v334.z = v337
					end
					v_u_39.cancelFlight()
					v_u_39.gesture()
					v_u_39.wake()
					return
				end
			elseif v329 == v_u_14.Equals or (v329 == v_u_14.Plus or v329 == v_u_14.KeypadPlus) then
				if v_u_327() then
					v_u_39.gesture()
					v_u_39.zoomStep(1)
					return
				end
			elseif (v329 == v_u_14.Minus or v329 == v_u_14.KeypadMinus) and v_u_327() then
				v_u_39.gesture()
				v_u_39.zoomStep(-1)
			end
		end
	end
	local function v_u_340(p339, _) -- name: onKeyEnded
		-- upvalues: (ref) v_u_15, (copy) v_u_298, (copy) v_u_63
		if p339.UserInputType == v_u_15.Keyboard and v_u_298[p339.KeyCode] then
			v_u_63[p339.KeyCode] = nil
		end
	end
	local function v_u_355(p341) -- name: readPad
		-- upvalues: (ref) v_u_42, (copy) v_u_37, (ref) v_u_14, (ref) v_u_13, (ref) v_u_18, (ref) v_u_20, (ref) v_u_50, (copy) v_u_35, (ref) v_u_16
		if not p341 then
			v_u_42.stick(0, 0)
			v_u_42.trigger(0)
			return false
		end
		local v342 = v_u_37.gamepadState
		local v343, v344 = pcall(v342)
		local v345 = 0
		local v346 = 0
		local v347 = 0
		local v348 = 0
		if v343 and type(v344) == "table" then
			for _, v349 in v344 do
				local v350 = v349.KeyCode
				if v350 == v_u_14.Thumbstick2 then
					v345 = v349.Position.X
					v346 = v349.Position.Y
				elseif v350 == v_u_14.ButtonR2 then
					v347 = v347 + v349.Position.Z
				else
					if v350 ~= v_u_14.ButtonL2 then
						continue
					end
					v348 = v348 + v349.Position.Z
				end
			end
		end
		local v351 = v345 * v345 + v346 * v346
		local v352 = math.sqrt(v351)
		if v352 <= v_u_13.STICK_DEAD then
			v345 = 0
			v346 = 0
		end
		local v353 = v347 - v348
		local v354 = v_u_18(v353) <= v_u_13.TRIGGER_DEAD and 0 or v353
		v_u_42.stick(v345, v346)
		v_u_42.trigger(v354)
		if v_u_20.R3_STICK < v352 then
			v_u_50 = v_u_35()
		end
		return (v_u_13.STICK_DEAD >= v352 and 0 or ((v_u_16(v352, 1) - v_u_13.STICK_DEAD) / (1 - v_u_13.STICK_DEAD)) ^ v_u_13.STICK_CURVE * v_u_13.STICK_PX) > v_u_20.HELD_PXS and true or v_u_18(v347 - v348) > v_u_13.TRIGGER_DEAD
	end
	local function v_u_361() -- name: stickMagnitude
		-- upvalues: (copy) v_u_37, (ref) v_u_14
		local v356 = v_u_37.gamepadState
		local v357, v358 = pcall(v356)
		if v357 and type(v358) == "table" then
			for _, v359 in v358 do
				if v359.KeyCode ~= v_u_14.Thumbstick2 then
					continue
				end
				local v360 = v359.Position.X * v359.Position.X + v359.Position.Y * v359.Position.Y
				return math.sqrt(v360)
			end
		end
		return 0
	end
	local function v_u_382() -- name: padWatchTick
		-- upvalues: (ref) v_u_44, (ref) v_u_47, (copy) v_u_33, (ref) v_u_9, (copy) v_u_80, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (ref) v_u_49, (copy) v_u_37, (ref) v_u_14, (ref) v_u_13, (ref) v_u_39
		local v362 = v_u_44 and v_u_47
		if v362 then
			v362 = false
			local v363
			if v_u_33.inputKind then
				v363 = v_u_33.inputKind()
			else
				local v364 = v_u_9.device
				local v365, v366 = pcall(v364)
				v363 = v365 and (v366 == "Gamepad" and "pad" or (v366 == "Touch" and "touch" or "mouse")) or "mouse"
			end
			if v363 == "pad" then
				if v_u_47 then
					local v367 = v_u_44 and v_u_80()
					if v367 then
						local v368, v369
						if v_u_33.modalCount then
							local v370 = v_u_33.modalCount
							v368, v369 = pcall(v370)
						else
							local v371 = v_u_9.modalCount
							v368, v369 = pcall(v371)
						end
						if v368 then
							if type(v369) == "number" then
								v368 = v369 > 0
							else
								v368 = false
							end
						end
						v367 = not v368
						if v367 then
							local v372
							if v_u_33.windowOpen == nil then
								v372 = false
							else
								v372 = v_u_33.windowOpen() == true
							end
							v367 = not v372
							if v367 then
								local v373
								if v_u_12 == nil then
									v373 = false
								else
									v373 = v_u_12:GetAttribute("CrateStageOn") == true
								end
								v367 = not v373
							end
						end
					end
					if v367 then
						local v374
						if v_u_33.selected then
							v374 = v_u_33.selected()
						else
							v374 = v_u_3.SelectedObject
						end
						if v374 == nil or v374 == v_u_41 then
							v362 = true
						elseif v374.Name == "Tab_play" then
							v362 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
						else
							v362 = false
						end
					else
						v362 = false
					end
				else
					v362 = false
				end
			end
		end
		if v362 then
			local v375 = v_u_37.gamepadState
			local v376, v377 = pcall(v375)
			if v376 and type(v377) == "table" then
				for _, v378 in v377 do
					local v379 = v378.KeyCode
					if v379 == v_u_14.Thumbstick2 then
						local v380 = v378.Position.X
						local v381 = v378.Position.Y
						if v380 * v380 + v381 * v381 <= v_u_13.STICK_DEAD * v_u_13.STICK_DEAD then
							continue
						end
						v_u_39.wake()
					else
						if v379 ~= v_u_14.ButtonL2 and v379 ~= v_u_14.ButtonR2 or v378.Position.Z <= v_u_13.TRIGGER_DEAD then
							continue
						end
						v_u_39.wake()
					end
				end
			end
		else
			if v_u_49 then
				v_u_49:Disconnect()
				v_u_49 = nil
			end
			return
		end
	end
	local function v_u_399() -- name: updatePadWatch
		-- upvalues: (ref) v_u_44, (ref) v_u_47, (copy) v_u_33, (ref) v_u_9, (copy) v_u_80, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (ref) v_u_49, (copy) v_u_382
		local v383 = v_u_44 and v_u_47
		if v383 then
			v383 = false
			local v384
			if v_u_33.inputKind then
				v384 = v_u_33.inputKind()
			else
				local v385 = v_u_9.device
				local v386, v387 = pcall(v385)
				v384 = v386 and (v387 == "Gamepad" and "pad" or (v387 == "Touch" and "touch" or "mouse")) or "mouse"
			end
			if v384 == "pad" then
				if v_u_47 then
					local v388 = v_u_44 and v_u_80()
					if v388 then
						local v389, v390
						if v_u_33.modalCount then
							local v391 = v_u_33.modalCount
							v389, v390 = pcall(v391)
						else
							local v392 = v_u_9.modalCount
							v389, v390 = pcall(v392)
						end
						if v389 then
							if type(v390) == "number" then
								v389 = v390 > 0
							else
								v389 = false
							end
						end
						v388 = not v389
						if v388 then
							local v393
							if v_u_33.windowOpen == nil then
								v393 = false
							else
								v393 = v_u_33.windowOpen() == true
							end
							v388 = not v393
							if v388 then
								local v394
								if v_u_12 == nil then
									v394 = false
								else
									v394 = v_u_12:GetAttribute("CrateStageOn") == true
								end
								v388 = not v394
							end
						end
					end
					if v388 then
						local v395
						if v_u_33.selected then
							v395 = v_u_33.selected()
						else
							v395 = v_u_3.SelectedObject
						end
						if v395 == nil or v395 == v_u_41 then
							v383 = true
						elseif v395.Name == "Tab_play" then
							v383 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
						else
							v383 = false
						end
					else
						v383 = false
					end
				else
					v383 = false
				end
			end
		end
		if v383 and not v_u_49 then
			local function v396()
				-- upvalues: (ref) v_u_33, (ref) v_u_382
				return (v_u_33.heartbeat or game:GetService("RunService").Heartbeat):Connect(v_u_382)
			end
			local v397, v398 = pcall(v396)
			if v397 then
				v_u_49 = v398
				return
			end
		elseif not v383 and v_u_49 then
			v_u_49:Disconnect()
			v_u_49 = nil
		end
	end
	local function v_u_422() -- name: refresh
		-- upvalues: (ref) v_u_44, (ref) v_u_39, (copy) v_u_33, (ref) v_u_9, (ref) v_u_47, (copy) v_u_80, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (copy) v_u_399, (ref) v_u_51
		if v_u_44 and v_u_39 then
			local v400
			if v_u_33.inputKind then
				v400 = v_u_33.inputKind()
			else
				local v401 = v_u_9.device
				local v402, v403 = pcall(v401)
				v400 = v402 and (v403 == "Gamepad" and "pad" or (v403 == "Touch" and "touch" or "mouse")) or "mouse"
			end
			local v404 = v400 == "pad"
			local v405
			if v_u_47 then
				local v406 = v_u_44 and v_u_80()
				if v406 then
					local v407, v408
					if v_u_33.modalCount then
						local v409 = v_u_33.modalCount
						v407, v408 = pcall(v409)
					else
						local v410 = v_u_9.modalCount
						v407, v408 = pcall(v410)
					end
					if v407 then
						if type(v408) == "number" then
							v407 = v408 > 0
						else
							v407 = false
						end
					end
					v406 = not v407
					if v406 then
						local v411
						if v_u_33.windowOpen == nil then
							v411 = false
						else
							v411 = v_u_33.windowOpen() == true
						end
						v406 = not v411
						if v406 then
							local v412
							if v_u_12 == nil then
								v412 = false
							else
								v412 = v_u_12:GetAttribute("CrateStageOn") == true
							end
							v406 = not v412
						end
					end
				end
				if v406 then
					local v413
					if v_u_33.selected then
						v413 = v_u_33.selected()
					else
						v413 = v_u_3.SelectedObject
					end
					if v413 == nil or v413 == v_u_41 then
						v405 = true
					elseif v413.Name == "Tab_play" then
						v405 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
					else
						v405 = false
					end
				else
					v405 = false
				end
			else
				v405 = false
			end
			v_u_39.setPadActive(v405 and v404)
			local v414 = v_u_47 and v404
			if v_u_41.Selectable ~= v414 then
				if not v414 then
					local v415
					if v_u_33.selected then
						v415 = v_u_33.selected()
					else
						v415 = v_u_3.SelectedObject
					end
					if v415 == v_u_41 then
						v_u_3.SelectedObject = nil
					end
				end
				v_u_41.Selectable = v414
			end
			if v_u_39.refreshChrome then
				v_u_39.refreshChrome()
			end
			v_u_399()
			if v404 and (v414 and (not v_u_51 and v_u_80())) then
				local v416
				if v_u_33.selected then
					v416 = v_u_33.selected()
				else
					v416 = v_u_3.SelectedObject
				end
				if v416 ~= nil and (v416 ~= v_u_41 and v416.Name == "Tab_play") then
					v_u_51 = true
					task.delay(v_u_20.SEL_DELAY_S, function()
						-- upvalues: (ref) v_u_51, (ref) v_u_44, (ref) v_u_41, (ref) v_u_33, (ref) v_u_9, (ref) v_u_80, (ref) v_u_3
						v_u_51 = false
						if v_u_44 and v_u_41.Parent then
							local v417
							if v_u_33.inputKind then
								v417 = v_u_33.inputKind()
							else
								local v418 = v_u_9.device
								local v419, v420 = pcall(v418)
								v417 = v419 and (v420 == "Gamepad" and "pad" or (v420 == "Touch" and "touch" or "mouse")) or "mouse"
							end
							if v417 == "pad" and (v_u_41.Selectable and v_u_80()) then
								local v421
								if v_u_33.selected then
									v421 = v_u_33.selected()
								else
									v421 = v_u_3.SelectedObject
								end
								if v421 ~= nil and v421.Name == "Tab_play" then
									v_u_3.SelectedObject = v_u_41
								end
								return
							end
						end
					end)
				end
			end
		end
	end
	v_u_34.refresh = v_u_422
	function v_u_34.setPadFlag(p423) -- name: setPadFlag
		-- upvalues: (ref) v_u_47, (ref) v_u_42, (copy) v_u_422
		v_u_47 = p423 ~= false
		if v_u_42 and not v_u_47 then
			v_u_42.stick(0, 0)
			v_u_42.trigger(0)
		end
		v_u_422()
	end
	local function v_u_428() -- name: orderedPins
		-- upvalues: (ref) v_u_39
		local v424 = {}
		for _, v425 in v_u_39.pins() do
			if type(v425) ~= "table" or not v425.geo then
				continue
			end
			table.insert(v424, v425)
		end
		table.sort(v424, function(p426, p427)
			return (p426.order or 0) < (p427.order or 0)
		end)
		return v424
	end
	local function v_u_454(p429) -- name: padStep
		-- upvalues: (copy) v_u_428, (ref) v_u_39, (ref) v_u_7, (ref) v_u_20, (ref) v_u_65, (ref) v_u_64, (ref) v_u_42, (ref) v_u_17
		local v430 = v_u_428()
		if #v430 ~= 0 then
			local v431 = v_u_39.view
			local v432 = 1000000000
			local v433 = nil
			for v434, v435 in v430 do
				local v436, v437
				if v435.hidden and v435.fuzz then
					v436 = v435.fuzz.lat
					v437 = v435.fuzz.lon
				else
					v436 = v435.geo.lat
					v437 = v435.geo.lon
				end
				local v438 = v_u_7.angleBetween({
					["lat"] = v431.lat0,
					["lon"] = v431.lon0
				}, {
					["lat"] = v436,
					["lon"] = v437
				}) * 180 / 3.141592653589793
				if v438 >= v432 then
					continue
				end
				v433 = v434
				v432 = v438
			end
			local v439
			if v433 and v432 <= v_u_20.NAV_NEAR_DEG then
				v439 = v433
			else
				v439 = nil
				for v440, v441 in v430 do
					if v441.id ~= v_u_65 then
						continue
					end
					v439 = v440
				end
				if v439 == nil then
					v439 = (v433 or 1) - p429
				end
			end
			local v442 = v430[(v439 - 1 + p429) % #v430 + 1]
			v_u_65 = v442.id
			local v443, v444
			if v442.hidden and v442.fuzz then
				v443 = v442.fuzz.lat
				v444 = v442.fuzz.lon
			else
				v443 = v442.geo.lat
				v444 = v442.geo.lon
			end
			local v445 = v_u_39.homeView().z
			local v446 = v_u_39.view
			if v446.lat0 ~= v_u_64.lat0 or (v446.lon0 ~= v_u_64.lon0 or v446.z ~= v_u_64.z) then
				if v_u_42.state == "IDLE" then
					v_u_42.flyTo(v446.lat0, v446.lon0, v446.z, true)
				end
				local v447 = v_u_39.view
				local v448 = v_u_64
				local v449 = v_u_64
				local v450 = v_u_64
				local v451 = v447.lat0
				local v452 = v447.lon0
				local v453 = v447.z
				v448.lat0 = v451
				v449.lon0 = v452
				v450.z = v453
			end
			v_u_42.flyTo(v431.lat0, v431.lon0, v431.z, true)
			v_u_39.gesture()
			v_u_39.flyTo({
				["lat0"] = v443,
				["lon0"] = v444,
				["z"] = v_u_17(v431.z, v445)
			})
		end
	end
	local function v_u_462() -- name: focusItem
		-- upvalues: (ref) v_u_39, (ref) v_u_13, (ref) v_u_45
		local v455 = v_u_39.focusItem()
		if v455 then
			return v455
		end
		local v456 = v_u_13.CATCH_PX * v_u_13.CATCH_PX
		local v457 = nil
		for _, v458 in v_u_39.items().items do
			if v458.kind == "fuzz" then
				continue
			end
			local v459 = v458.x - v_u_45 / 2
			local v460 = v458.y - v_u_45 / 2
			local v461 = v459 * v459 + v460 * v460
			if v461 > v456 then
				continue
			end
			v457 = v458
			v456 = v461
		end
		return v457
	end
	local function v_u_469() -- name: nearestItem
		-- upvalues: (ref) v_u_13, (ref) v_u_20, (ref) v_u_39, (ref) v_u_45
		local v463 = (v_u_13.CATCH_PX * v_u_20.SNAP_FACTOR) ^ 2
		local v464 = nil
		for _, v465 in v_u_39.items().items do
			if v465.kind == "fuzz" then
				continue
			end
			local v466 = v465.x - v_u_45 / 2
			local v467 = v465.y - v_u_45 / 2
			local v468 = v466 * v466 + v467 * v467
			if v468 > v463 then
				continue
			end
			v464 = v465
			v463 = v468
		end
		return v464
	end
	local function v_u_487() -- name: padA
		-- upvalues: (ref) v_u_47, (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (copy) v_u_34, (copy) v_u_462, (copy) v_u_469, (copy) v_u_69, (ref) v_u_39
		local v470
		if v_u_47 then
			local v471 = v_u_44 and v_u_80()
			if v471 then
				local v472, v473
				if v_u_33.modalCount then
					local v474 = v_u_33.modalCount
					v472, v473 = pcall(v474)
				else
					local v475 = v_u_9.modalCount
					v472, v473 = pcall(v475)
				end
				if v472 then
					if type(v473) == "number" then
						v472 = v473 > 0
					else
						v472 = false
					end
				end
				v471 = not v472
				if v471 then
					local v476
					if v_u_33.windowOpen == nil then
						v476 = false
					else
						v476 = v_u_33.windowOpen() == true
					end
					v471 = not v476
					if v471 then
						local v477
						if v_u_12 == nil then
							v477 = false
						else
							v477 = v_u_12:GetAttribute("CrateStageOn") == true
						end
						v471 = not v477
					end
				end
			end
			if v471 then
				local v478
				if v_u_33.selected then
					v478 = v_u_33.selected()
				else
					v478 = v_u_3.SelectedObject
				end
				if v478 == nil or v478 == v_u_41 then
					v470 = true
				elseif v478.Name == "Tab_play" then
					v470 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
				else
					v470 = false
				end
			else
				v470 = false
			end
		else
			v470 = false
		end
		if v470 then
			if v_u_34.justDragged() then
				return
			else
				local v479 = v_u_462() or v_u_469()
				if v479 then
					local v480 = v_u_69
					v480.padA = v480.padA + 1
					v_u_39.gesture()
					if v479.kind == "cluster" then
						v_u_39.openList(v479.ids, v479.key)
						local v481 = v_u_39.listParts()
						if v481 and v481.rows[1] then
							local v482
							if v_u_33.inputKind then
								v482 = v_u_33.inputKind()
							else
								local v483 = v_u_9.device
								local v484, v485 = pcall(v483)
								v482 = v484 and (v485 == "Gamepad" and "pad" or (v485 == "Touch" and "touch" or "mouse")) or "mouse"
							end
							if v482 == "pad" then
								v_u_3.SelectedObject = v481.rows[1]
								return
							end
						end
					else
						v_u_39.activate(v479, nil)
					end
				else
					local v486 = v_u_69
					v486.pulses = v486.pulses + 1
					if v_u_39.pulseCross then
						v_u_39.pulseCross()
					end
				end
			end
		else
			return
		end
	end
	local function v_u_501() -- name: padB
		-- upvalues: (ref) v_u_47, (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_39, (ref) v_u_41, (ref) v_u_3, (copy) v_u_422
		if v_u_47 then
			local v488 = v_u_44 and v_u_80()
			if v488 then
				local v489, v490
				if v_u_33.modalCount then
					local v491 = v_u_33.modalCount
					v489, v490 = pcall(v491)
				else
					local v492 = v_u_9.modalCount
					v489, v490 = pcall(v492)
				end
				if v489 then
					if type(v490) == "number" then
						v489 = v490 > 0
					else
						v489 = false
					end
				end
				v488 = not v489
				if v488 then
					local v493
					if v_u_33.windowOpen == nil then
						v493 = false
					else
						v493 = v_u_33.windowOpen() == true
					end
					v488 = not v493
					if v488 then
						local v494
						if v_u_12 == nil then
							v494 = false
						else
							v494 = v_u_12:GetAttribute("CrateStageOn") == true
						end
						v488 = not v494
					end
				end
			end
			if v488 and v_u_39.listOpen() then
				if v_u_12 then
					v_u_12:SetAttribute("GlobePadB", "fold")
				end
				v_u_39.closeList()
				if v_u_33.hooks and v_u_33.hooks.onBack then
					local v495 = v_u_33.hooks.onBack
					pcall(v495, true)
				end
				task.defer(function()
					-- upvalues: (ref) v_u_44, (ref) v_u_41, (ref) v_u_33, (ref) v_u_9, (ref) v_u_3, (ref) v_u_422
					if v_u_44 and v_u_41.Parent then
						local v496
						if v_u_33.inputKind then
							v496 = v_u_33.inputKind()
						else
							local v497 = v_u_9.device
							local v498, v499 = pcall(v497)
							v496 = v498 and (v499 == "Gamepad" and "pad" or (v499 == "Touch" and "touch" or "mouse")) or "mouse"
						end
						if v496 == "pad" and v_u_41.Selectable then
							v_u_3.SelectedObject = v_u_41
						end
					end
					v_u_422()
				end)
				return
			end
		end
		if v_u_12 then
			v_u_12:SetAttribute("GlobePadB", "pass")
		end
		if v_u_33.hooks and v_u_33.hooks.onBack then
			local v500 = v_u_33.hooks.onBack
			pcall(v500, false)
		end
	end
	local function v_u_550(p502, _) -- name: onPadBegan
		-- upvalues: (ref) v_u_44, (ref) v_u_14, (copy) v_u_501, (copy) v_u_487, (ref) v_u_47, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (ref) v_u_39, (copy) v_u_361, (ref) v_u_50, (ref) v_u_64, (ref) v_u_42, (copy) v_u_454, (copy) v_u_422
		if v_u_44 then
			local v503 = p502.KeyCode
			if v503 == v_u_14.ButtonB then
				v_u_501()
			else
				if v503 == v_u_14.ButtonA then
					v_u_487()
				elseif v503 == v_u_14.ButtonY then
					local v504
					if v_u_47 then
						local v505 = v_u_44 and v_u_80()
						if v505 then
							local v506, v507
							if v_u_33.modalCount then
								local v508 = v_u_33.modalCount
								v506, v507 = pcall(v508)
							else
								local v509 = v_u_9.modalCount
								v506, v507 = pcall(v509)
							end
							if v506 then
								if type(v507) == "number" then
									v506 = v507 > 0
								else
									v506 = false
								end
							end
							v505 = not v506
							if v505 then
								local v510
								if v_u_33.windowOpen == nil then
									v510 = false
								else
									v510 = v_u_33.windowOpen() == true
								end
								v505 = not v510
								if v505 then
									local v511
									if v_u_12 == nil then
										v511 = false
									else
										v511 = v_u_12:GetAttribute("CrateStageOn") == true
									end
									v505 = not v511
								end
							end
						end
						if v505 then
							local v512
							if v_u_33.selected then
								v512 = v_u_33.selected()
							else
								v512 = v_u_3.SelectedObject
							end
							if v512 == nil or v512 == v_u_41 then
								v504 = true
							elseif v512.Name == "Tab_play" then
								v504 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
							else
								v504 = false
							end
						else
							v504 = false
						end
					else
						v504 = false
					end
					if v504 and v_u_33.list then
						v_u_39.gesture()
						local v513 = v_u_33.list
						pcall(v513)
					end
				elseif v503 == v_u_14.ButtonR3 then
					local v514
					if v_u_361() <= v_u_20.R3_STICK then
						v514 = v_u_35() - v_u_50 >= v_u_20.R3_QUIET_S
					else
						v514 = false
					end
					local v515
					if v_u_47 then
						local v516 = v_u_44 and v_u_80()
						if v516 then
							local v517, v518
							if v_u_33.modalCount then
								local v519 = v_u_33.modalCount
								v517, v518 = pcall(v519)
							else
								local v520 = v_u_9.modalCount
								v517, v518 = pcall(v520)
							end
							if v517 then
								if type(v518) == "number" then
									v517 = v518 > 0
								else
									v517 = false
								end
							end
							v516 = not v517
							if v516 then
								local v521
								if v_u_33.windowOpen == nil then
									v521 = false
								else
									v521 = v_u_33.windowOpen() == true
								end
								v516 = not v521
								if v516 then
									local v522
									if v_u_12 == nil then
										v522 = false
									else
										v522 = v_u_12:GetAttribute("CrateStageOn") == true
									end
									v516 = not v522
								end
							end
						end
						if v516 then
							local v523
							if v_u_33.selected then
								v523 = v_u_33.selected()
							else
								v523 = v_u_3.SelectedObject
							end
							if v523 == nil or v523 == v_u_41 then
								v515 = true
							elseif v523.Name == "Tab_play" then
								v515 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
							else
								v515 = false
							end
						else
							v515 = false
						end
					else
						v515 = false
					end
					if v515 and v514 then
						local v524 = v_u_39.view
						if v524.lat0 ~= v_u_64.lat0 or (v524.lon0 ~= v_u_64.lon0 or v524.z ~= v_u_64.z) then
							if v_u_42.state == "IDLE" then
								v_u_42.flyTo(v524.lat0, v524.lon0, v524.z, true)
							end
							local v525 = v_u_39.view
							local v526 = v_u_64
							local v527 = v_u_64
							local v528 = v_u_64
							local v529 = v525.lat0
							local v530 = v525.lon0
							local v531 = v525.z
							v526.lat0 = v529
							v527.lon0 = v530
							v528.z = v531
						end
						v_u_42.flyTo(v_u_39.view.lat0, v_u_39.view.lon0, v_u_39.view.z, true)
						v_u_39.gesture()
						v_u_39.homeStep()
					end
				elseif v503 == v_u_14.DPadUp then
					local v532
					if v_u_47 then
						local v533 = v_u_44 and v_u_80()
						if v533 then
							local v534, v535
							if v_u_33.modalCount then
								local v536 = v_u_33.modalCount
								v534, v535 = pcall(v536)
							else
								local v537 = v_u_9.modalCount
								v534, v535 = pcall(v537)
							end
							if v534 then
								if type(v535) == "number" then
									v534 = v535 > 0
								else
									v534 = false
								end
							end
							v533 = not v534
							if v533 then
								local v538
								if v_u_33.windowOpen == nil then
									v538 = false
								else
									v538 = v_u_33.windowOpen() == true
								end
								v533 = not v538
								if v533 then
									local v539
									if v_u_12 == nil then
										v539 = false
									else
										v539 = v_u_12:GetAttribute("CrateStageOn") == true
									end
									v533 = not v539
								end
							end
						end
						if v533 then
							local v540
							if v_u_33.selected then
								v540 = v_u_33.selected()
							else
								v540 = v_u_3.SelectedObject
							end
							if v540 == nil or v540 == v_u_41 then
								v532 = true
							elseif v540.Name == "Tab_play" then
								v532 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
							else
								v532 = false
							end
						else
							v532 = false
						end
					else
						v532 = false
					end
					if v532 then
						v_u_454(-1)
					end
				elseif v503 == v_u_14.DPadDown then
					local v541
					if v_u_47 then
						local v542 = v_u_44 and v_u_80()
						if v542 then
							local v543, v544
							if v_u_33.modalCount then
								local v545 = v_u_33.modalCount
								v543, v544 = pcall(v545)
							else
								local v546 = v_u_9.modalCount
								v543, v544 = pcall(v546)
							end
							if v543 then
								if type(v544) == "number" then
									v543 = v544 > 0
								else
									v543 = false
								end
							end
							v542 = not v543
							if v542 then
								local v547
								if v_u_33.windowOpen == nil then
									v547 = false
								else
									v547 = v_u_33.windowOpen() == true
								end
								v542 = not v547
								if v542 then
									local v548
									if v_u_12 == nil then
										v548 = false
									else
										v548 = v_u_12:GetAttribute("CrateStageOn") == true
									end
									v542 = not v548
								end
							end
						end
						if v542 then
							local v549
							if v_u_33.selected then
								v549 = v_u_33.selected()
							else
								v549 = v_u_3.SelectedObject
							end
							if v549 == nil or v549 == v_u_41 then
								v541 = true
							elseif v549.Name == "Tab_play" then
								v541 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
							else
								v541 = false
							end
						else
							v541 = false
						end
					else
						v541 = false
					end
					if v541 then
						v_u_454(1)
					end
				end
				v_u_422()
			end
		else
			return
		end
	end
	local function v_u_570(p551, _) -- name: onPadChanged
		-- upvalues: (ref) v_u_44, (ref) v_u_14, (ref) v_u_47, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42
		if v_u_44 then
			local v552 = p551.KeyCode
			if v552 == v_u_14.Thumbstick2 or (v552 == v_u_14.ButtonL2 or v552 == v_u_14.ButtonR2) then
				local v553
				if v_u_47 then
					local v554 = v_u_44 and v_u_80()
					if v554 then
						local v555, v556
						if v_u_33.modalCount then
							local v557 = v_u_33.modalCount
							v555, v556 = pcall(v557)
						else
							local v558 = v_u_9.modalCount
							v555, v556 = pcall(v558)
						end
						if v555 then
							if type(v556) == "number" then
								v555 = v556 > 0
							else
								v555 = false
							end
						end
						v554 = not v555
						if v554 then
							local v559
							if v_u_33.windowOpen == nil then
								v559 = false
							else
								v559 = v_u_33.windowOpen() == true
							end
							v554 = not v559
							if v554 then
								local v560
								if v_u_12 == nil then
									v560 = false
								else
									v560 = v_u_12:GetAttribute("CrateStageOn") == true
								end
								v554 = not v560
							end
						end
					end
					if v554 then
						local v561
						if v_u_33.selected then
							v561 = v_u_33.selected()
						else
							v561 = v_u_3.SelectedObject
						end
						if v561 == nil or v561 == v_u_41 then
							v553 = true
						elseif v561.Name == "Tab_play" then
							v553 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
						else
							v553 = false
						end
					else
						v553 = false
					end
				else
					v553 = false
				end
				if v553 then
					local v562 = v_u_39.view
					if v562.lat0 ~= v_u_64.lat0 or (v562.lon0 ~= v_u_64.lon0 or v562.z ~= v_u_64.z) then
						if v_u_42.state == "IDLE" then
							v_u_42.flyTo(v562.lat0, v562.lon0, v562.z, true)
						end
						local v563 = v_u_39.view
						local v564 = v_u_64
						local v565 = v_u_64
						local v566 = v_u_64
						local v567 = v563.lat0
						local v568 = v563.lon0
						local v569 = v563.z
						v564.lat0 = v567
						v565.lon0 = v568
						v566.z = v569
					end
					v_u_39.wake()
				end
			end
		end
	end
	local function v_u_608(p571) -- name: inputStep
		-- upvalues: (ref) v_u_44, (ref) v_u_42, (copy) v_u_69, (ref) v_u_39, (ref) v_u_64, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_56, (copy) v_u_52, (copy) v_u_134, (ref) v_u_47, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (copy) v_u_355, (copy) v_u_63, (copy) v_u_327, (ref) v_u_14
		if not (v_u_44 and v_u_42) then
			return false
		end
		local v572 = v_u_69
		v572.steps = v572.steps + 1
		local v573 = v_u_39.view
		if v573.lat0 ~= v_u_64.lat0 or (v573.lon0 ~= v_u_64.lon0 or v573.z ~= v_u_64.z) then
			if v_u_42.state == "IDLE" then
				v_u_42.flyTo(v573.lat0, v573.lon0, v573.z, true)
			end
			local v574 = v_u_39.view
			local v575 = v_u_64
			local v576 = v_u_64
			local v577 = v_u_64
			local v578 = v574.lat0
			local v579 = v574.lon0
			local v580 = v574.z
			v575.lat0 = v578
			v576.lon0 = v579
			v577.z = v580
		end
		local v581 = v_u_44 and v_u_80()
		if v581 then
			local v582, v583
			if v_u_33.modalCount then
				local v584 = v_u_33.modalCount
				v582, v583 = pcall(v584)
			else
				local v585 = v_u_9.modalCount
				v582, v583 = pcall(v585)
			end
			if v582 then
				if type(v583) == "number" then
					v582 = v583 > 0
				else
					v582 = false
				end
			end
			v581 = not v582
			if v581 then
				local v586
				if v_u_33.windowOpen == nil then
					v586 = false
				else
					v586 = v_u_33.windowOpen() == true
				end
				v581 = not v586
				if v581 then
					local v587
					if v_u_12 == nil then
						v587 = false
					else
						v587 = v_u_12:GetAttribute("CrateStageOn") == true
					end
					v581 = not v587
				end
			end
		end
		if not v581 then
			if v_u_42.state ~= "IDLE" or (v_u_56 ~= nil or next(v_u_52) ~= nil) then
				v_u_134()
			end
			v_u_42.stick(0, 0)
			v_u_42.trigger(0)
			v_u_42.arrows(0, 0)
			return false
		end
		local v588
		if v_u_47 then
			local v589 = v_u_44 and v_u_80()
			if v589 then
				local v590, v591
				if v_u_33.modalCount then
					local v592 = v_u_33.modalCount
					v590, v591 = pcall(v592)
				else
					local v593 = v_u_9.modalCount
					v590, v591 = pcall(v593)
				end
				if v590 then
					if type(v591) == "number" then
						v590 = v591 > 0
					else
						v590 = false
					end
				end
				v589 = not v590
				if v589 then
					local v594
					if v_u_33.windowOpen == nil then
						v594 = false
					else
						v594 = v_u_33.windowOpen() == true
					end
					v589 = not v594
					if v589 then
						local v595
						if v_u_12 == nil then
							v595 = false
						else
							v595 = v_u_12:GetAttribute("CrateStageOn") == true
						end
						v589 = not v595
					end
				end
			end
			if v589 then
				local v596
				if v_u_33.selected then
					v596 = v_u_33.selected()
				else
					v596 = v_u_3.SelectedObject
				end
				if v596 == nil or v596 == v_u_41 then
					v588 = true
				elseif v596.Name == "Tab_play" then
					v588 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
				else
					v588 = false
				end
			else
				v588 = false
			end
		else
			v588 = false
		end
		local v597 = v_u_355(v588)
		local v598 = 0
		local v599 = 0
		if next(v_u_63) ~= nil then
			if v_u_327() then
				v598 = (v_u_63[v_u_14.Right] and 1 or 0) - (v_u_63[v_u_14.Left] and 1 or 0)
				v599 = (v_u_63[v_u_14.Up] and 1 or 0) - (v_u_63[v_u_14.Down] and 1 or 0)
			else
				table.clear(v_u_63)
			end
		end
		v_u_42.arrows(v598, v599)
		if (v597 or (v598 ~= 0 or v599 ~= 0)) and v_u_39.flying() then
			v_u_39.cancelFlight()
		end
		if v_u_42.step(p571) then
			local v600 = v_u_42.view
			v_u_39.setViewRaw(v600.lat0, v600.lon0, v600.z)
			local v601 = v_u_39.view
			local v602 = v_u_64
			local v603 = v_u_64
			local v604 = v_u_64
			local v605 = v601.lat0
			local v606 = v601.lon0
			local v607 = v601.z
			v602.lat0 = v605
			v603.lon0 = v606
			v604.z = v607
		end
		return v_u_42.busy() or (v597 or (v598 ~= 0 and true or v599 ~= 0))
	end
	local v_u_609 = {}
	v_u_34.fake = v_u_609
	local function v_u_619(p610, p611, p612, p613, p614) -- name: fio
		-- upvalues: (ref) v_u_40, (ref) v_u_10, (ref) v_u_14
		local v615 = v_u_40.AbsolutePosition + Vector2.new(p611, p612) * v_u_10.scaleOf(v_u_40)
		local v616 = {
			["UserInputType"] = nil,
			["UserInputState"] = nil,
			["Position"] = nil,
			["KeyCode"] = nil,
			["fake"] = true,
			["UserInputType"] = p610,
			["UserInputState"] = p614 or Enum.UserInputState.Change
		}
		local v617 = v615.X
		local v618 = v615.Y
		v616.Position = Vector3.new(v617, v618, p613 or 0)
		v616.KeyCode = v_u_14.Unknown
		return v616
	end
	function v_u_609.mouseDown(p620, p621, p622, p623) -- name: mouseDown
		-- upvalues: (copy) v_u_34, (ref) v_u_40, (ref) v_u_10, (copy) v_u_70, (copy) v_u_619
		v_u_34.fakePressed[p620] = true
		v_u_34.fakeMouse = v_u_40.AbsolutePosition + Vector2.new(p621, p622) * v_u_10.scaleOf(v_u_40)
		v_u_70.began:Fire(v_u_619(p620, p621, p622, 0, Enum.UserInputState.Begin), p623 == true)
	end
	function v_u_609.mouseMove(p624, p625) -- name: mouseMove
		-- upvalues: (copy) v_u_34, (ref) v_u_40, (ref) v_u_10, (copy) v_u_70, (copy) v_u_619, (ref) v_u_15
		v_u_34.fakeMouse = v_u_40.AbsolutePosition + Vector2.new(p624, p625) * v_u_10.scaleOf(v_u_40)
		v_u_70.changed:Fire(v_u_619(v_u_15.MouseMovement, p624, p625), false)
	end
	function v_u_609.mouseUp(p626, p627, p628, p629) -- name: mouseUp
		-- upvalues: (copy) v_u_34, (ref) v_u_40, (ref) v_u_10, (copy) v_u_70, (copy) v_u_619
		v_u_34.fakePressed[p626] = nil
		v_u_34.fakeMouse = v_u_40.AbsolutePosition + Vector2.new(p627, p628) * v_u_10.scaleOf(v_u_40)
		v_u_70.ended:Fire(v_u_619(p626, p627, p628, 0, Enum.UserInputState.End), p629 == true)
	end
	function v_u_609.wheel(p630, p631, p632, p633) -- name: wheel
		-- upvalues: (copy) v_u_34, (ref) v_u_40, (ref) v_u_10, (copy) v_u_70, (copy) v_u_619, (ref) v_u_15
		v_u_34.fakeMouse = v_u_40.AbsolutePosition + Vector2.new(p631, p632) * v_u_10.scaleOf(v_u_40)
		v_u_70.changed:Fire(v_u_619(v_u_15.MouseWheel, p631, p632, p630), p633 == true)
	end
	function v_u_609.touchDown(p634, p635, p636) -- name: touchDown
		-- upvalues: (copy) v_u_619, (ref) v_u_15, (copy) v_u_70
		local v637 = v_u_619(v_u_15.Touch, p634, p635, 0, Enum.UserInputState.Begin)
		v_u_70.began:Fire(v637, p636 == true)
		return v637
	end
	function v_u_609.touchMove(p638, p639, p640) -- name: touchMove
		-- upvalues: (ref) v_u_40, (ref) v_u_10, (copy) v_u_70
		local v641 = v_u_40.AbsolutePosition + Vector2.new(p639, p640) * v_u_10.scaleOf(v_u_40)
		local v642 = v641.X
		local v643 = v641.Y
		p638.Position = Vector3.new(v642, v643, 0)
		v_u_70.changed:Fire(p638, false)
	end
	function v_u_609.touchUp(p644, p645, p646) -- name: touchUp
		-- upvalues: (ref) v_u_40, (ref) v_u_10, (copy) v_u_70
		if p645 and p646 then
			local v647 = v_u_40.AbsolutePosition + Vector2.new(p645, p646) * v_u_10.scaleOf(v_u_40)
			local v648 = v647.X
			local v649 = v647.Y
			p644.Position = Vector3.new(v648, v649, 0)
		end
		v_u_70.ended:Fire(p644, false)
	end
	function v_u_609.key(p650, p651) -- name: key
		-- upvalues: (ref) v_u_15, (copy) v_u_70
		local v652 = {
			["UserInputType"] = nil,
			["UserInputState"] = nil,
			["Position"] = Vector3.new(0, 0, 0),
			["KeyCode"] = nil,
			["fake"] = true,
			["UserInputType"] = v_u_15.Keyboard
		}
		local v653
		if p651 then
			v653 = Enum.UserInputState.Begin
		else
			v653 = Enum.UserInputState.End
		end
		v652.UserInputState = v653
		v652.KeyCode = p650
		if p651 then
			v_u_70.began:Fire(v652, false)
		else
			v_u_70.ended:Fire(v652, false)
		end
	end
	function v_u_609.focusLost() -- name: focusLost
		-- upvalues: (copy) v_u_70
		v_u_70.focusLost:Fire()
	end
	function v_u_34.drag(p654, p655, p656, p657) -- name: drag
		-- upvalues: (ref) v_u_15, (ref) v_u_45, (ref) v_u_17, (copy) v_u_609
		local v658 = p657 or v_u_15.MouseButton1
		local v659 = v_u_45 / 2 - p654 / 2
		local v660 = v_u_45 / 2 - p655 / 2
		local v661 = (p656 or 0.4) * 60
		local v662 = v_u_17(2, (math.floor(v661)))
		v_u_609.mouseMove(v659, v660)
		v_u_609.mouseDown(v658, v659, v660)
		for v663 = 1, v662 do
			game:GetService("RunService").Heartbeat:Wait()
			v_u_609.mouseMove(v659 + p654 * v663 / v662, v660 + p655 * v663 / v662)
		end
		v_u_609.mouseUp(v658, v659 + p654, v660 + p655)
	end
	function v_u_34.pinch(p664, p665) -- name: pinch
		-- upvalues: (copy) v_u_609, (ref) v_u_45, (ref) v_u_17
		local v666 = v_u_609.touchDown(v_u_45 / 2 - 100, v_u_45 / 2)
		local v667 = v_u_609.touchDown(v_u_45 / 2 + 100, v_u_45 / 2)
		local v668 = (p665 or 0.4) * 60
		local v669 = v_u_17(2, (math.floor(v668)))
		for v670 = 1, v669 do
			game:GetService("RunService").Heartbeat:Wait()
			local v671 = ((p664 - 1) * v670 / v669 + 1) * 100
			v_u_609.touchMove(v666, v_u_45 / 2 - v671, v_u_45 / 2)
			v_u_609.touchMove(v667, v_u_45 / 2 + v671, v_u_45 / 2)
		end
		v_u_609.touchUp(v666)
		v_u_609.touchUp(v667)
	end
	function v_u_34.commands(p672) -- name: commands
		-- upvalues: (copy) v_u_34, (copy) v_u_609, (ref) v_u_45
		local function v680(p673)
			-- upvalues: (ref) v_u_34
			local v674 = p673[1]
			local v675 = tonumber(v674) or 0
			local v676 = p673[2]
			local v677 = tonumber(v676) or 0
			local v678 = p673[3]
			local v679 = tonumber(v678) or 0.4
			task.spawn(v_u_34.drag, v675, v677, v679)
			return string.format("drag %d %d in %.2f s", v675, v677, v679)
		end
		pcall(p672, "globe.drag", v680)
		local function v684(p681)
			-- upvalues: (ref) v_u_34
			local v682 = p681[1]
			local v683 = tonumber(v682) or 2
			task.spawn(v_u_34.pinch, v683, 0.4)
			return "pinch x" .. tostring(v683)
		end
		pcall(p672, "globe.pinch", v684)
		local function v688(p685)
			-- upvalues: (ref) v_u_609, (ref) v_u_45
			local v686 = p685[1]
			local v687 = tonumber(v686) or 1
			v_u_609.wheel(v687, v_u_45 / 2, v_u_45 / 2, false)
			return "wheel " .. tostring(v687)
		end
		pcall(p672, "globe.wheel", v688)
	end
	function v_u_34.stats() -- name: stats
		-- upvalues: (copy) v_u_69, (ref) v_u_42, (copy) v_u_52, (ref) v_u_47, (ref) v_u_44, (copy) v_u_80, (copy) v_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_3, (ref) v_u_41, (copy) v_u_35, (ref) v_u_48, (ref) v_u_20, (copy) v_u_46, (ref) v_u_49
		local v689 = {
			["presses"] = v_u_69.presses,
			["wheels"] = v_u_69.wheels,
			["padA"] = v_u_69.padA,
			["aborts"] = v_u_69.aborts,
			["steps"] = v_u_69.steps,
			["state"] = v_u_42 and v_u_42.state or "none"
		}
		local v690 = 0
		for _ in v_u_52 do
			v690 = v690 + 1
		end
		v689.touches = v690
		local v691
		if v_u_47 then
			local v692 = v_u_44 and v_u_80()
			if v692 then
				local v693, v694
				if v_u_33.modalCount then
					local v695 = v_u_33.modalCount
					v693, v694 = pcall(v695)
				else
					local v696 = v_u_9.modalCount
					v693, v694 = pcall(v696)
				end
				if v693 then
					if type(v694) == "number" then
						v693 = v694 > 0
					else
						v693 = false
					end
				end
				v692 = not v693
				if v692 then
					local v697
					if v_u_33.windowOpen == nil then
						v697 = false
					else
						v697 = v_u_33.windowOpen() == true
					end
					v692 = not v697
					if v692 then
						local v698
						if v_u_12 == nil then
							v698 = false
						else
							v698 = v_u_12:GetAttribute("CrateStageOn") == true
						end
						v692 = not v698
					end
				end
			end
			if v692 then
				local v699
				if v_u_33.selected then
					v699 = v_u_33.selected()
				else
					v699 = v_u_3.SelectedObject
				end
				if v699 == nil or v699 == v_u_41 then
					v691 = true
				elseif v699.Name == "Tab_play" then
					v691 = v_u_35() - v_u_48 <= v_u_20.TAB_GRACE_S
				else
					v691 = false
				end
			else
				v691 = false
			end
		else
			v691 = false
		end
		v689.padOwns = v691
		v689.flag = v_u_47
		v689.conns = #v_u_46
		v689.padWatch = v_u_49 ~= nil
		v689.pulses = v_u_69.pulses
		return v689
	end
	function v_u_34.attach(p_u_700) -- name: attach
		-- upvalues: (ref) v_u_39, (ref) v_u_40, (ref) v_u_41, (ref) v_u_45, (ref) v_u_44, (ref) v_u_38, (copy) v_u_33, (copy) v_u_115, (ref) v_u_48, (copy) v_u_35, (ref) v_u_68, (copy) v_u_608, (ref) v_u_49, (copy) v_u_134, (ref) v_u_42, (ref) v_u_64, (copy) v_u_63, (copy) v_u_422, (copy) v_u_34, (ref) v_u_3, (ref) v_u_9, (ref) v_u_60, (ref) v_u_20, (copy) v_u_69, (copy) v_u_36, (copy) v_u_214, (copy) v_u_46, (copy) v_u_287, (copy) v_u_297, (copy) v_u_338, (copy) v_u_340, (copy) v_u_70, (copy) v_u_37, (copy) v_u_550, (copy) v_u_570, (ref) v_u_2, (ref) v_u_5
		v_u_39 = p_u_700
		v_u_40 = p_u_700.lens
		v_u_41 = p_u_700.focus
		v_u_45 = p_u_700.root.Size.X.Offset
		v_u_44 = true
		local v701 = v_u_38 ~= "pc"
		if v_u_33.touch then
			v701 = v_u_33.touch() == true
		end
		v_u_115(v701)
		v_u_48 = v_u_35()
		v_u_41.NextSelectionUp = v_u_41
		v_u_41.NextSelectionDown = v_u_41
		local v702 = v_u_33.hooks
		if v702 then
			if v702.rail then
				v_u_41.NextSelectionLeft = v702.rail
			end
			if v702.columnFirst then
				v_u_41.NextSelectionRight = v702.columnFirst
			end
			if v702.leftEdge then
				for _, v703 in v702.leftEdge do
					v703.NextSelectionLeft = v_u_41
				end
			end
		end
		local v704 = v_u_40:FindFirstChild("Rim")
		if v704 then
			v704 = v_u_40.Rim:FindFirstChild("Ring")
		end
		if v704 then
			v704 = v704:FindFirstChildOfClass("UIStroke")
		end
		v_u_68 = v704
		p_u_700.inputStep = v_u_608
		local v_u_705 = p_u_700.stats
		function p_u_700.stats() -- name: stats
			-- upvalues: (copy) v_u_705, (ref) v_u_49
			local v706 = v_u_705()
			v706.padWatch = v_u_49 ~= nil
			return v706
		end
		local v_u_707 = p_u_700.hide
		local v_u_708 = p_u_700.show
		local v_u_709 = p_u_700.destroy
		local v_u_710 = p_u_700.setSize
		local v_u_711 = p_u_700.openList
		local v_u_712 = p_u_700.closeList
		local v_u_713 = p_u_700.activateId
		function p_u_700.hide() -- name: hide
			-- upvalues: (ref) v_u_134, (ref) v_u_42, (copy) p_u_700, (ref) v_u_39, (ref) v_u_64, (copy) v_u_707, (ref) v_u_63, (ref) v_u_422
			v_u_134()
			v_u_42.flyTo(p_u_700.view.lat0, p_u_700.view.lon0, p_u_700.view.z, true)
			local v714 = v_u_39.view
			local v715 = v_u_64
			local v716 = v_u_64
			local v717 = v_u_64
			local v718 = v714.lat0
			local v719 = v714.lon0
			local v720 = v714.z
			v715.lat0 = v718
			v716.lon0 = v719
			v717.z = v720
			v_u_707()
			table.clear(v_u_63)
			v_u_422()
		end
		function p_u_700.show() -- name: show
			-- upvalues: (ref) v_u_48, (ref) v_u_35, (copy) v_u_708, (ref) v_u_39, (ref) v_u_64, (ref) v_u_42, (ref) v_u_422
			v_u_48 = v_u_35()
			v_u_708()
			local v721 = v_u_39.view
			if v721.lat0 ~= v_u_64.lat0 or (v721.lon0 ~= v_u_64.lon0 or v721.z ~= v_u_64.z) then
				if v_u_42.state == "IDLE" then
					v_u_42.flyTo(v721.lat0, v721.lon0, v721.z, true)
				end
				local v722 = v_u_39.view
				local v723 = v_u_64
				local v724 = v_u_64
				local v725 = v_u_64
				local v726 = v722.lat0
				local v727 = v722.lon0
				local v728 = v722.z
				v723.lat0 = v726
				v724.lon0 = v727
				v725.z = v728
			end
			v_u_422()
		end
		function p_u_700.destroy() -- name: destroy
			-- upvalues: (ref) v_u_34, (copy) v_u_709
			v_u_34.destroy()
			v_u_709()
		end
		function p_u_700.setSize(p729, p730) -- name: setSize
			-- upvalues: (copy) v_u_710, (ref) v_u_45, (ref) v_u_42, (ref) v_u_38
			v_u_710(p729, p730)
			v_u_45 = p729
			v_u_42.setLens(p729 / 2)
			if p730 then
				v_u_38 = p730
			end
		end
		function p_u_700.openList(p731, p732) -- name: openList
			-- upvalues: (copy) v_u_711, (copy) p_u_700, (ref) v_u_41
			v_u_711(p731, p732)
			local v733 = p_u_700.listParts()
			if v733 then
				local v734 = v733.rows
				for v735, v736 in v734 do
					v736.NextSelectionUp = v734[v735 - 1] or v736
					v736.NextSelectionDown = v734[v735 + 1] or v736
					v736.NextSelectionLeft = v_u_41
					v736.NextSelectionRight = v_u_41
				end
			end
		end
		function p_u_700.closeList() -- name: closeList
			-- upvalues: (copy) p_u_700, (copy) v_u_712, (ref) v_u_33, (ref) v_u_3, (ref) v_u_40, (ref) v_u_41, (ref) v_u_9
			local v737 = p_u_700.listOpen()
			v_u_712()
			if v737 then
				local v738
				if v_u_33.selected then
					v738 = v_u_33.selected()
				else
					v738 = v_u_3.SelectedObject
				end
				if v738 and (v738:IsDescendantOf(v_u_40) and v738 ~= v_u_41) then
					local v739
					if v_u_33.inputKind then
						v739 = v_u_33.inputKind()
					else
						local v740 = v_u_9.device
						local v741, v742 = pcall(v740)
						v739 = v741 and (v742 == "Gamepad" and "pad" or (v742 == "Touch" and "touch" or "mouse")) or "mouse"
					end
					if v739 == "pad" and v_u_41.Selectable then
						v_u_3.SelectedObject = v_u_41
					end
				end
			end
		end
		function p_u_700.activateId(p743, p744) -- name: activateId
			-- upvalues: (ref) v_u_35, (ref) v_u_60, (copy) v_u_713, (ref) v_u_20, (ref) v_u_69
			local v745 = v_u_35()
			if v745 < v_u_60 then
				return true
			end
			local v746 = v_u_713(p743, p744)
			if v746 then
				v_u_60 = v745 + v_u_20.OPEN_LOCK_S
				local v747 = v_u_69
				v747.picks = v747.picks + 1
			end
			return v746
		end
		local v_u_748 = p_u_700.flyTo
		local v_u_749 = p_u_700.zoomStep
		local v_u_750 = p_u_700.setView
		function p_u_700.flyTo(p751, p752) -- name: flyTo
			-- upvalues: (ref) v_u_44, (ref) v_u_42, (copy) p_u_700, (ref) v_u_39, (ref) v_u_64, (copy) v_u_748
			if v_u_44 and v_u_42.state == "INERTIA" then
				v_u_42.flyTo(p_u_700.view.lat0, p_u_700.view.lon0, p_u_700.view.z, true)
				local v753 = v_u_39.view
				local v754 = v_u_64
				local v755 = v_u_64
				local v756 = v_u_64
				local v757 = v753.lat0
				local v758 = v753.lon0
				local v759 = v753.z
				v754.lat0 = v757
				v755.lon0 = v758
				v756.z = v759
			end
			v_u_748(p751, p752)
		end
		function p_u_700.zoomStep(p760) -- name: zoomStep
			-- upvalues: (ref) v_u_44, (ref) v_u_42, (copy) p_u_700, (ref) v_u_39, (ref) v_u_64, (copy) v_u_749
			if v_u_44 and v_u_42.state == "INERTIA" then
				v_u_42.flyTo(p_u_700.view.lat0, p_u_700.view.lon0, p_u_700.view.z, true)
				local v761 = v_u_39.view
				local v762 = v_u_64
				local v763 = v_u_64
				local v764 = v_u_64
				local v765 = v761.lat0
				local v766 = v761.lon0
				local v767 = v761.z
				v762.lat0 = v765
				v763.lon0 = v766
				v764.z = v767
			end
			v_u_749(p760)
		end
		function p_u_700.setView(p768, p769, p770) -- name: setView
			-- upvalues: (ref) v_u_44, (ref) v_u_42, (copy) p_u_700, (ref) v_u_39, (ref) v_u_64, (copy) v_u_750
			if v_u_44 and v_u_42.state == "INERTIA" then
				v_u_42.flyTo(p_u_700.view.lat0, p_u_700.view.lon0, p_u_700.view.z, true)
				local v771 = v_u_39.view
				local v772 = v_u_64
				local v773 = v_u_64
				local v774 = v_u_64
				local v775 = v771.lat0
				local v776 = v771.lon0
				local v777 = v771.z
				v772.lat0 = v775
				v773.lon0 = v776
				v774.z = v777
			end
			v_u_750(p768, p769, p770)
		end
		function v_u_34.restore()
			-- upvalues: (copy) p_u_700, (copy) v_u_707, (copy) v_u_708, (copy) v_u_709, (copy) v_u_710, (copy) v_u_711, (copy) v_u_712, (copy) v_u_713, (copy) v_u_748, (copy) v_u_749, (copy) v_u_750, (copy) v_u_705
			local v778 = p_u_700
			local v779 = p_u_700
			local v780 = p_u_700
			local v781 = p_u_700
			local v782 = p_u_700
			local v783 = p_u_700
			local v784 = v_u_708
			local v785 = v_u_709
			local v786 = v_u_710
			local v787 = v_u_711
			local v788 = v_u_712
			local v789 = v_u_713
			p_u_700.hide = v_u_707
			v778.show = v784
			v779.destroy = v785
			v780.setSize = v786
			v781.openList = v787
			v782.closeList = v788
			v783.activateId = v789
			local v790 = p_u_700
			local v791 = p_u_700
			local v792 = v_u_749
			local v793 = v_u_750
			p_u_700.flyTo = v_u_748
			v790.zoomStep = v792
			v791.setView = v793
			p_u_700.stats = v_u_705
		end
		local v_u_794 = v_u_36.InputBegan
		local v_u_795 = v_u_214
		if v_u_794 ~= nil and v_u_44 then
			local v796, v797 = pcall(function()
				-- upvalues: (copy) v_u_794, (copy) v_u_795
				return v_u_794:Connect(v_u_795)
			end)
			if v796 and v797 then
				local v798 = v_u_46
				table.insert(v798, v797)
			end
		end
		local v_u_799 = v_u_36.InputChanged
		local v_u_800 = v_u_287
		if v_u_799 ~= nil and v_u_44 then
			local v801, v802 = pcall(function()
				-- upvalues: (copy) v_u_799, (copy) v_u_800
				return v_u_799:Connect(v_u_800)
			end)
			if v801 and v802 then
				local v803 = v_u_46
				table.insert(v803, v802)
			end
		end
		local v_u_804 = v_u_36.InputEnded
		local v_u_805 = v_u_297
		if v_u_804 ~= nil and v_u_44 then
			local v806, v807 = pcall(function()
				-- upvalues: (copy) v_u_804, (copy) v_u_805
				return v_u_804:Connect(v_u_805)
			end)
			if v806 and v807 then
				local v808 = v_u_46
				table.insert(v808, v807)
			end
		end
		local v_u_809 = v_u_36.InputBegan
		local v_u_810 = v_u_338
		if v_u_809 ~= nil and v_u_44 then
			local v811, v812 = pcall(function()
				-- upvalues: (copy) v_u_809, (copy) v_u_810
				return v_u_809:Connect(v_u_810)
			end)
			if v811 and v812 then
				local v813 = v_u_46
				table.insert(v813, v812)
			end
		end
		local v_u_814 = v_u_36.InputEnded
		local v_u_815 = v_u_340
		if v_u_814 ~= nil and v_u_44 then
			local v816, v817 = pcall(function()
				-- upvalues: (copy) v_u_814, (copy) v_u_815
				return v_u_814:Connect(v_u_815)
			end)
			if v816 and v817 then
				local v818 = v_u_46
				table.insert(v818, v817)
			end
		end
		local v_u_819 = v_u_36.WindowFocusReleased
		local v_u_820 = v_u_134
		if v_u_819 ~= nil and v_u_44 then
			local v821, v822 = pcall(function()
				-- upvalues: (copy) v_u_819, (copy) v_u_820
				return v_u_819:Connect(v_u_820)
			end)
			if v821 and v822 then
				local v823 = v_u_46
				table.insert(v823, v822)
			end
		end
		local v_u_824 = v_u_70.began
		local v_u_825 = v_u_214
		if v_u_824 ~= nil and v_u_44 then
			local v826, v827 = pcall(function()
				-- upvalues: (copy) v_u_824, (copy) v_u_825
				return v_u_824:Connect(v_u_825)
			end)
			if v826 and v827 then
				local v828 = v_u_46
				table.insert(v828, v827)
			end
		end
		local v_u_829 = v_u_70.changed
		local v_u_830 = v_u_287
		if v_u_829 ~= nil and v_u_44 then
			local v831, v832 = pcall(function()
				-- upvalues: (copy) v_u_829, (copy) v_u_830
				return v_u_829:Connect(v_u_830)
			end)
			if v831 and v832 then
				local v833 = v_u_46
				table.insert(v833, v832)
			end
		end
		local v_u_834 = v_u_70.ended
		local v_u_835 = v_u_297
		if v_u_834 ~= nil and v_u_44 then
			local v836, v837 = pcall(function()
				-- upvalues: (copy) v_u_834, (copy) v_u_835
				return v_u_834:Connect(v_u_835)
			end)
			if v836 and v837 then
				local v838 = v_u_46
				table.insert(v838, v837)
			end
		end
		local v_u_839 = v_u_70.began
		local v_u_840 = v_u_338
		if v_u_839 ~= nil and v_u_44 then
			local v841, v842 = pcall(function()
				-- upvalues: (copy) v_u_839, (copy) v_u_840
				return v_u_839:Connect(v_u_840)
			end)
			if v841 and v842 then
				local v843 = v_u_46
				table.insert(v843, v842)
			end
		end
		local v_u_844 = v_u_70.ended
		local v_u_845 = v_u_340
		if v_u_844 ~= nil and v_u_44 then
			local v846, v847 = pcall(function()
				-- upvalues: (copy) v_u_844, (copy) v_u_845
				return v_u_844:Connect(v_u_845)
			end)
			if v846 and v847 then
				local v848 = v_u_46
				table.insert(v848, v847)
			end
		end
		local v_u_849 = v_u_70.focusLost
		local v_u_850 = v_u_134
		if v_u_849 ~= nil and v_u_44 then
			local v851, v852 = pcall(function()
				-- upvalues: (copy) v_u_849, (copy) v_u_850
				return v_u_849:Connect(v_u_850)
			end)
			if v851 and v852 then
				local v853 = v_u_46
				table.insert(v853, v852)
			end
		end
		local v_u_854 = v_u_37.InputBegan
		local v_u_855 = v_u_550
		if v_u_854 ~= nil and v_u_44 then
			local v856, v857 = pcall(function()
				-- upvalues: (copy) v_u_854, (copy) v_u_855
				return v_u_854:Connect(v_u_855)
			end)
			if v856 and v857 then
				local v858 = v_u_46
				table.insert(v858, v857)
			end
		end
		local v_u_859 = v_u_37.InputChanged
		local v_u_860 = v_u_570
		if v_u_859 ~= nil and v_u_44 then
			local v861, v862 = pcall(function()
				-- upvalues: (copy) v_u_859, (copy) v_u_860
				return v_u_859:Connect(v_u_860)
			end)
			if v861 and v862 then
				local v863 = v_u_46
				table.insert(v863, v862)
			end
		end
		local v_u_864 = v_u_37.activeChanged
		local function v_u_865()
			-- upvalues: (ref) v_u_422
			v_u_422()
		end
		if v_u_864 ~= nil and v_u_44 then
			local v866, v867 = pcall(function()
				-- upvalues: (copy) v_u_864, (copy) v_u_865
				return v_u_864:Connect(v_u_865)
			end)
			if v866 and v867 then
				local v868 = v_u_46
				table.insert(v868, v867)
			end
		end
		local function v872()
			-- upvalues: (ref) v_u_46, (ref) v_u_3, (ref) v_u_422
			local v869 = v_u_46
			local v870 = v_u_3:GetPropertyChangedSignal("SelectedObject")
			local v871 = v_u_422
			table.insert(v869, v870:Connect(v871))
		end
		pcall(v872)
		local function v876()
			-- upvalues: (ref) v_u_46, (ref) v_u_2, (ref) v_u_422
			local v873 = v_u_46
			local v874 = v_u_2.LastInputTypeChanged
			local v875 = v_u_422
			table.insert(v873, v874:Connect(v875))
		end
		pcall(v876)
		task.spawn(function()
			-- upvalues: (ref) v_u_33, (ref) v_u_34, (ref) v_u_5, (ref) v_u_20, (ref) v_u_44, (ref) v_u_46
			if v_u_33.flag then
				v_u_33.flag(function(p877)
					-- upvalues: (ref) v_u_34
					v_u_34.setPadFlag(p877 ~= false)
				end)
			else
				local function v878()
					-- upvalues: (ref) v_u_5
					return require(v_u_5:WaitForChild("Config"))
				end
				local v879, v880 = pcall(v878)
				local v_u_882 = v879 and (v880 and (v880.watchFlag and v880.watchFlag(v_u_20.FLAG, function(p881)
					-- upvalues: (ref) v_u_44, (ref) v_u_34
					if v_u_44 then
						v_u_34.setPadFlag(p881 ~= false)
					end
				end)))
				if v_u_882 then
					if v_u_44 then
						local v883 = v_u_46
						table.insert(v883, v_u_882)
						return
					end
					pcall(function()
						-- upvalues: (copy) v_u_882
						v_u_882:Disconnect()
					end)
				end
			end
		end)
		v_u_422()
	end
	function v_u_34.destroy() -- name: destroy
		-- upvalues: (ref) v_u_44, (copy) v_u_134, (ref) v_u_49, (copy) v_u_46, (ref) v_u_39
		if v_u_44 then
			v_u_44 = false
			v_u_134()
			if v_u_49 then
				v_u_49:Disconnect()
				v_u_49 = nil
			end
			for _, v_u_884 in v_u_46 do
				pcall(function()
					-- upvalues: (copy) v_u_884
					v_u_884:Disconnect()
				end)
			end
			table.clear(v_u_46)
			if v_u_39 then
				v_u_39.inputStep = nil
			end
		end
	end
	return v_u_34
end
function v_u_19.probe(p885) -- name: probe
	-- upvalues: (copy) v_u_19
	local v886 = p885 or {}
	local v887 = require(script.Parent:WaitForChild("GlobeView"))
	local v888 = v_u_19.new(v886)
	local v889 = {}
	for v890, v891 in v886 do
		v889[v890] = v891
	end
	v889.justDragged = v888.justDragged
	v889.padOwns = v888.padOwns
	v889.inputKind = v888.inputKind
	v889.keyName = v888.keyName
	local v892 = v887.probe(v889)
	v888.attach(v892)
	return v892, v888
end
return v_u_19