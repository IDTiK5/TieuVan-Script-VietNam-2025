-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSettingsLayout

local v_u_1 = {
	["GAP"] = 4,
	["RAIL_MIN"] = 150,
	["RAIL_MAX"] = 220,
	["PANE_GAP"] = 16,
	["SCROLL_BAR"] = 12,
	["ROW_MAX"] = 640,
	["HEADING_H"] = 44,
	["CARD_BTN_W"] = 150,
	["CARD_WIDE"] = 460,
	["RAID_BTN_X"] = 168,
	["RAID_FREE_TO"] = 460,
	["TITLE_MAX"] = 150,
	["RAIL_TEXT_SIZE"] = 16,
	["CATEGORIES"] = {
		{
			["id"] = "gameplay",
			["bar"] = "GAMEPLAY",
			["heading"] = "Gameplay",
			["line"] = "Loot, maps, crates and how a raid starts."
		},
		{
			["id"] = "controls",
			["bar"] = "CONTROLS",
			["heading"] = "Controls",
			["line"] = "Keys, controller and aim assist."
		},
		{
			["id"] = "touch",
			["bar"] = "TOUCH AND HUD",
			["heading"] = "Touch and HUD",
			["line"] = "Your buttons, sticks and fire control on a touch screen."
		},
		{
			["id"] = "camera",
			["bar"] = "CAMERA",
			["heading"] = "Camera",
			["line"] = "Zoom, shake and the FIRST / THIRD PERSON view."
		},
		{
			["id"] = "graphics",
			["bar"] = "GRAPHICS",
			["heading"] = "Graphics",
			["line"] = "Quality, effects and the gear you see."
		},
		{
			["id"] = "audio",
			["bar"] = "AUDIO",
			["heading"] = "Audio",
			["line"] = "Volumes and voice."
		},
		{
			["id"] = "interface",
			["bar"] = "INTERFACE",
			["heading"] = "Interface",
			["line"] = "Interface size, outlines, chat, missions, menu style, clan colors and recording."
		},
		{
			["id"] = "account",
			["bar"] = "ACCOUNT",
			["heading"] = "Account",
			["line"] = "Your profile, trades, the tour and codes."
		}
	}
}
local v_u_2 = {}
local v_u_3 = {}
for v4, v5 in v_u_1.CATEGORIES do
	v_u_2[v5.id] = v5
	v_u_3[v5.id] = v4
end
v_u_1.BY_ID = v_u_2
v_u_1.INDEX = v_u_3
v_u_1.ROWS = {
	{
		["id"] = "closeSearchOnHit",
		["cat"] = "gameplay",
		["kind"] = "T",
		["label"] = "Close search when hit",
		["key"] = "closeSearchOnHit",
		["name"] = "CloseSearchOnHit"
	},
	{
		["id"] = "ammoStackNoAsk",
		["cat"] = "gameplay",
		["kind"] = "T",
		["label"] = "Ask before stacking found in raid items",
		["key"] = "ammoStackNoAsk",
		["name"] = "AmmoStackAsk"
	},
	{
		["id"] = "entryMode",
		["cat"] = "gameplay",
		["kind"] = "D",
		["label"] = "Entry animation",
		["key"] = "entryMode",
		["name"] = "EntryMode"
	},
	{
		["id"] = "mapTasks",
		["cat"] = "gameplay",
		["kind"] = "T",
		["label"] = "Map shows tasks",
		["key"] = "mapTasks",
		["name"] = "MapTasks"
	},
	{
		["id"] = "mapLabels",
		["cat"] = "gameplay",
		["kind"] = "T",
		["label"] = "Map shows labels",
		["key"] = "mapLabels",
		["name"] = "MapLabels"
	},
	{
		["id"] = "crateQuick",
		["cat"] = "gameplay",
		["kind"] = "T",
		["label"] = "Quick case opening",
		["key"] = "crateQuick",
		["name"] = "CrateQuick"
	},
	{
		["id"] = "ff",
		["cat"] = "gameplay",
		["kind"] = "I",
		["label"] = "Friendly fire in your squad",
		["notRaid"] = true
	},
	{
		["id"] = "aimAssist",
		["cat"] = "controls",
		["kind"] = "T",
		["label"] = "Aim assist",
		["key"] = "aimAssist",
		["name"] = "AimAssist"
	},
	{
		["id"] = "keybinds",
		["cat"] = "controls",
		["kind"] = "B",
		["label"] = "Key bindings",
		["src"] = "MenuKeybinds"
	},
	{
		["id"] = "padHelp",
		["cat"] = "controls",
		["kind"] = "N",
		["label"] = "Controller note",
		["name"] = "PadHelp"
	},
	{
		["id"] = "hudCard",
		["cat"] = "touch",
		["kind"] = "K",
		["label"] = "HUD LAYOUT",
		["name"] = "HudCard"
	},
	{
		["id"] = "editHud",
		["cat"] = "touch",
		["kind"] = "K",
		["label"] = "Edit HUD",
		["name"] = "EditHud"
	},
	{
		["id"] = "touchFire",
		["cat"] = "touch",
		["kind"] = "D",
		["label"] = "Fire control",
		["key"] = "touchFire",
		["name"] = "TouchFire"
	},
	{
		["id"] = "touchFireNote",
		["cat"] = "touch",
		["kind"] = "N",
		["label"] = "Fire control note",
		["name"] = "TouchFireNote"
	},
	{
		["id"] = "touchSize",
		["cat"] = "touch",
		["kind"] = "D",
		["label"] = "Touch button size",
		["key"] = "touchSize",
		["name"] = "TouchSize"
	},
	{
		["id"] = "touchStick",
		["cat"] = "touch",
		["kind"] = "D",
		["label"] = "Touch stick size",
		["key"] = "touchStick",
		["name"] = "TouchStick"
	},
	{
		["id"] = "touchMoveFixed",
		["cat"] = "touch",
		["kind"] = "D",
		["label"] = "Touch move stick",
		["key"] = "touchMoveFixed",
		["name"] = "TouchMoveFixed"
	},
	{
		["id"] = "touchOpacity",
		["cat"] = "touch",
		["kind"] = "D",
		["label"] = "Touch control opacity",
		["key"] = "touchOpacity",
		["name"] = "TouchOpacity"
	},
	{
		["id"] = "touchLayoutNote",
		["cat"] = "touch",
		["kind"] = "N",
		["label"] = "Touch layout note",
		["name"] = "TouchLayoutNote"
	},
	{
		["id"] = "touchHelp",
		["cat"] = "touch",
		["kind"] = "B",
		["label"] = "Touch controls",
		["name"] = "TouchHelp"
	},
	{
		["id"] = "cameraZoom",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Default camera zoom",
		["key"] = "cameraZoom"
	},
	{
		["id"] = "cameraShake",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Camera shake",
		["key"] = "cameraShake"
	},
	{
		["id"] = "fov",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Field of view",
		["key"] = "fov",
		["name"] = "FpFov"
	},
	{
		["id"] = "sensitivity",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Look sensitivity",
		["key"] = "sensitivity",
		["name"] = "FpSensitivity"
	},
	{
		["id"] = "fpAdsSens",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Aim sensitivity",
		["key"] = "fpAdsSens",
		["name"] = "FpAdsSens"
	},
	{
		["id"] = "fpPadSens",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Controller look speed",
		["key"] = "fpPadSens",
		["name"] = "FpPadSens"
	},
	{
		["id"] = "fpTouchSens",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Touch look speed",
		["key"] = "fpTouchSens",
		["name"] = "FpTouchSens"
	},
	{
		["id"] = "fpInvertY",
		["cat"] = "camera",
		["kind"] = "T",
		["label"] = "Invert look",
		["key"] = "fpInvertY",
		["name"] = "FpInvertY"
	},
	{
		["id"] = "fpBob",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Head bob",
		["key"] = "fpBob",
		["name"] = "FpBob"
	},
	{
		["id"] = "fpSway",
		["cat"] = "camera",
		["kind"] = "S",
		["label"] = "Weapon sway",
		["key"] = "fpSway",
		["name"] = "FpSway"
	},
	{
		["id"] = "fpShoulder",
		["cat"] = "camera",
		["kind"] = "D",
		["label"] = "Shoulder",
		["key"] = "fpShoulder",
		["name"] = "FpShoulder"
	},
	{
		["id"] = "graphics",
		["cat"] = "graphics",
		["kind"] = "D",
		["label"] = "Quality",
		["key"] = "graphics"
	},
	{
		["id"] = "showFps",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "FPS, ping and server",
		["key"] = "showFps",
		["name"] = "ShowFps"
	},
	{
		["id"] = "reduceFlashing",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Reduce flashing",
		["key"] = "reduceFlashing",
		["name"] = "ReduceFlashing"
	},
	{
		["id"] = "skinFx",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Skin effects",
		["key"] = "skinFx",
		["name"] = "SkinFx"
	},
	{
		["id"] = "weaponSkins",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Weapon skins",
		["key"] = "weaponSkins",
		["name"] = "WeaponSkins"
	},
	{
		["id"] = "hideMyGear",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Hide my armor, boots and backpack",
		["key"] = "hideMyGear",
		["name"] = "HideMyGear"
	},
	{
		["id"] = "hideOthersGear",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Hide armor, boots and backpacks of others",
		["key"] = "hideOthersGear",
		["name"] = "HideOthersGear"
	},
	{
		["id"] = "hideHeadwear",
		["cat"] = "graphics",
		["kind"] = "T",
		["label"] = "Hide hair and hats under helmets",
		["key"] = "hideHeadwear",
		["name"] = "HideHeadwear"
	},
	{
		["id"] = "masterVolume",
		["cat"] = "audio",
		["kind"] = "S",
		["label"] = "Master",
		["key"] = "masterVolume"
	},
	{
		["id"] = "musicVolume",
		["cat"] = "audio",
		["kind"] = "S",
		["label"] = "Music",
		["key"] = "musicVolume"
	},
	{
		["id"] = "sfxVolume",
		["cat"] = "audio",
		["kind"] = "S",
		["label"] = "Effects",
		["key"] = "sfxVolume"
	},
	{
		["id"] = "ambienceVolume",
		["cat"] = "audio",
		["kind"] = "S",
		["label"] = "Ambience",
		["key"] = "ambienceVolume"
	},
	{
		["id"] = "uiVolume",
		["cat"] = "audio",
		["kind"] = "S",
		["label"] = "Interface",
		["key"] = "uiVolume"
	},
	{
		["id"] = "voiceNoise",
		["cat"] = "audio",
		["kind"] = "T",
		["label"] = "Voice draws the infected",
		["key"] = "voiceNoise",
		["name"] = "VoiceNoise"
	},
	{
		["id"] = "voiceNoiseNote",
		["cat"] = "audio",
		["kind"] = "N",
		["label"] = "Voice note",
		["name"] = "VoiceNoiseNote"
	},
	{
		["id"] = "uiScale",
		["cat"] = "interface",
		["kind"] = "S",
		["label"] = "Interface scale",
		["key"] = "uiScale"
	},
	{
		["id"] = "statusOutline",
		["cat"] = "interface",
		["kind"] = "T",
		["label"] = "Status outline",
		["key"] = "statusOutline",
		["name"] = "StatusOutline"
	},
	{
		["id"] = "squadChat",
		["cat"] = "interface",
		["kind"] = "T",
		["label"] = "Squad chat",
		["key"] = "squadChat",
		["name"] = "SquadChat"
	},
	{
		["id"] = "taskTracker",
		["cat"] = "interface",
		["kind"] = "D",
		["label"] = "Mission list",
		["key"] = "taskTracker",
		["name"] = "TaskTracker"
	},
	{
		["id"] = "menuStyle",
		["cat"] = "interface",
		["kind"] = "D",
		["label"] = "Menu style",
		["key"] = "menuStyle",
		["name"] = "MenuStyle",
		["notRaid"] = true
	},
	{
		["id"] = "showClanColors",
		["cat"] = "interface",
		["kind"] = "T",
		["label"] = "Show clan colors",
		["key"] = "showClanColors",
		["name"] = "ShowClanColors"
	},
	{
		["id"] = "objectOutlines",
		["cat"] = "interface",
		["kind"] = "T",
		["label"] = "Object outlines",
		["key"] = "objectOutlines",
		["name"] = "ObjectOutlines"
	},
	{
		["id"] = "hideUi",
		["cat"] = "interface",
		["kind"] = "T",
		["label"] = "Hide interface",
		["name"] = "HideUi"
	},
	{
		["id"] = "tradeRequests",
		["cat"] = "account",
		["kind"] = "D",
		["label"] = "Trade requests",
		["key"] = "tradeRequests",
		["name"] = "TradeRequests"
	},
	{
		["id"] = "build",
		["cat"] = "account",
		["kind"] = "I",
		["label"] = "Build",
		["notRaid"] = true
	},
	{
		["id"] = "profile",
		["cat"] = "account",
		["kind"] = "I",
		["label"] = "Profile",
		["notRaid"] = true
	},
	{
		["id"] = "tempNote",
		["cat"] = "account",
		["kind"] = "N",
		["label"] = "Profile not saved note",
		["name"] = "TempNote",
		["notRaid"] = true
	},
	{
		["id"] = "marketNote",
		["cat"] = "account",
		["kind"] = "N",
		["label"] = "Market note",
		["name"] = "MarketNote",
		["notRaid"] = true
	},
	{
		["id"] = "tourButton",
		["cat"] = "account",
		["kind"] = "K",
		["label"] = "Show menu tour again",
		["name"] = "TourButton",
		["notRaid"] = true
	},
	{
		["id"] = "replayTutorial",
		["cat"] = "account",
		["kind"] = "K",
		["label"] = "Replay tutorial",
		["name"] = "ReplayTutorial",
		["notRaid"] = true
	},
	{
		["id"] = "replayNote",
		["cat"] = "account",
		["kind"] = "N",
		["label"] = "Replay note",
		["name"] = "ReplayNote",
		["notRaid"] = true
	},
	{
		["id"] = "codes",
		["cat"] = "account",
		["kind"] = "B",
		["label"] = "Redeem code",
		["src"] = "MenuCodes.build",
		["notRaid"] = true
	}
}
v_u_1.NO_ROW_KEYS = {
	["hudLayoutP"] = true,
	["hudLayoutT"] = true
}
function v_u_1.initial(p6) -- name: initial
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v7
	if type(p6) == "table" then
		v7 = p6.visible
	else
		v7 = nil
	end
	if type(p6) == "table" and p6.touch == true then
		local v8
		if v_u_2.touch == nil then
			v8 = false
		else
			v8 = type(v7) ~= "table" and true or v7.touch ~= false
		end
		if v8 then
			return "touch"
		end
	end
	if type(p6) == "table" then
		local v9 = p6.last
		local v10
		if type(v9) == "string" and v_u_2[v9] ~= nil then
			v10 = type(v7) ~= "table" and true or v7[v9] ~= false
		else
			v10 = false
		end
		if v10 then
			return p6.last
		end
	end
	local v11
	if v_u_2.gameplay == nil then
		v11 = false
	else
		v11 = type(v7) ~= "table" and true or v7.gameplay ~= false
	end
	if v11 then
		return "gameplay"
	end
	for _, v12 in v_u_1.CATEGORIES do
		local v13 = v12.id
		local v14
		if type(v13) == "string" and v_u_2[v13] ~= nil then
			v14 = type(v7) ~= "table" and true or v7[v13] ~= false
		else
			v14 = false
		end
		if not v14 then
			continue
		end
		return v12.id
	end
	return "gameplay"
end
function v_u_1.step(p15, p16, p17) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v18 = #v_u_1.CATEGORIES
	local v19 = v_u_3[p15] or 1
	local v20 = p16 < 0 and -1 or 1
	for _ = 1, v18 do
		v19 = (v19 - 1 + v20) % v18 + 1
		local v21 = v_u_1.CATEGORIES[v19].id
		if type(p17) == "table" and p17[v21] == false then
			continue
		end
		return v21
	end
	return p15
end
function v_u_1.visible(p22) -- name: visible
	-- upvalues: (copy) v_u_1
	local v23
	if type(p22) == "table" then
		v23 = p22.raid == true
	else
		v23 = false
	end
	local v24
	if type(p22) == "table" then
		v24 = p22.tradeOn == true
	else
		v24 = false
	end
	local v25 = {}
	for _, v26 in v_u_1.CATEGORIES do
		v25[v26.id] = true
	end
	if v23 and not v24 then
		v25.account = false
	end
	return v25
end
function v_u_1.subTabOf(p27) -- name: subTabOf
	return p27 == "controls" and "controls" or "general"
end
function v_u_1.window(p28, p29) -- name: window
	local v30 = p28 - 48
	return math.min(p29 and 900 or 1100, v30)
end
function v_u_1.height(p31) -- name: height
	local v32 = p31 - 8
	return math.min(800, v32)
end
function v_u_1.compute(p33, p34, p35) -- name: compute
	-- upvalues: (copy) v_u_1
	local v36 = p35.scale
	local v37 = tonumber(v36) or 1
	local v38 = math.max(v37, 0.01)
	local v39 = p35.touch == true
	local v40 = p35.raid == true
	local v41 = p33 < 800 and 12 or 16
	local v42 = 40
	local v43
	if v39 then
		local v44 = 44 / v38 - 1e-6
		local v45 = math.ceil(v44)
		v43 = math.max(44, v45)
	else
		v43 = 44
	end
	local v46 = math.max(v42, v43)
	if v40 then
		local v47
		if v39 then
			local v48 = 44 / v38 - 1e-6
			local v49 = math.ceil(v48)
			v47 = math.max(36, v49)
		else
			v47 = 36
		end
		local v50 = v47 + 12 + 8
		v46 = math.max(v46, v50)
	end
	local v51 = p33 - v41 * 2
	local v52 = v51 * 0.24
	local v53 = math.floor(v52)
	local v54 = v_u_1.RAIL_MIN
	local v55 = v_u_1.RAIL_MAX
	local v56 = math.clamp(v53, v54, v55)
	local v57 = v41 + v56 + v_u_1.PANE_GAP
	local v58 = v51 - v56 - v_u_1.PANE_GAP
	local v59 = v58 - v_u_1.SCROLL_BAR
	local v60 = v_u_1.ROW_MAX
	local v61 = math.min(v59, v60)
	local v62
	if v39 then
		local v63 = 44 / v38 - 1e-6
		local v64 = math.ceil(v63)
		v62 = math.max(44, v64)
	else
		v62 = 44
	end
	local v65 = {}
	local v66 = p35.ids
	if type(v66) == "table" then
		for _, v67 in p35.ids do
			table.insert(v65, v67)
		end
	else
		for _, v68 in v_u_1.CATEGORIES do
			local v69 = v68.id
			table.insert(v65, v69)
		end
	end
	local v70 = {}
	for v71, v72 in v65 do
		v70[v72] = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = (v71 - 1) * (v62 + v_u_1.GAP),
			["w"] = v56,
			["h"] = v62
		}
	end
	local v73 = p34 - v46 - v41
	local v74 = math.max(0, v73)
	local v75 = {
		["pad"] = v41,
		["headerH"] = v46
	}
	local v76 = v_u_1.TITLE_MAX
	local v77 = v_u_1.RAID_BTN_X - v41
	v75.title = {
		["x"] = nil,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["x"] = v41,
		["w"] = math.min(v76, v77),
		["h"] = v46
	}
	v75.rail = {
		["x"] = v41,
		["y"] = v46,
		["w"] = v56,
		["h"] = v74
	}
	v75.items = v70
	v75.itemH = v62
	v75.railText = {
		["x"] = 12,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["w"] = v56 - 24,
		["h"] = v62
	}
	local v78 = #v65 * v62
	local v79 = #v65 - 1
	v75.railContentH = v78 + math.max(0, v79) * v_u_1.GAP
	v75.pane = {
		["x"] = v57,
		["y"] = v46,
		["w"] = v58,
		["h"] = v74
	}
	v75.heading = {
		["x"] = v57,
		["y"] = v46,
		["w"] = v58,
		["h"] = v_u_1.HEADING_H
	}
	local v80 = v46 + v_u_1.HEADING_H
	local v81 = v74 - v_u_1.HEADING_H
	v75.list = {
		["x"] = v57,
		["y"] = v80,
		["w"] = v58,
		["h"] = math.max(0, v81)
	}
	v75.rowW = v61
	v75.kbW = v58 - v_u_1.SCROLL_BAR
	local v82
	if v39 then
		local v83 = 44 / v38 - 1e-6
		local v84 = math.ceil(v83)
		v82 = math.max(44, v84)
	else
		v82 = 44
	end
	v75.btnH = v82
	if p35.cardOn == true then
		local v85 = v_u_1.CARD_BTN_W
		local v86
		if v39 then
			local v87 = 44 / v38 - 1e-6
			local v88 = math.ceil(v87)
			v86 = math.max(44, v88)
		else
			v86 = 44
		end
		local v89, v90, v91
		if v_u_1.CARD_WIDE <= v61 then
			local v92 = v86 + 24
			local v93 = math.max(76, v92)
			local v94 = v61 - 14 - v85
			local v95 = (v93 - v86) / 2
			v89 = {
				["x"] = v94,
				["y"] = math.floor(v95),
				["w"] = v85,
				["h"] = v86
			}
			v90 = {
				["x"] = 14,
				["y"] = 10,
				["w"] = nil,
				["h"] = nil,
				["w"] = v89.x - 12 - 14,
				["h"] = v93 - 20
			}
			v91 = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v61,
				["h"] = v93
			}
		else
			v90 = {
				["x"] = 14,
				["y"] = 10,
				["w"] = nil,
				["h"] = 40,
				["w"] = v61 - 28
			}
			local v96 = v61 - 28
			v89 = {
				["x"] = 14,
				["y"] = 58,
				["w"] = nil,
				["h"] = nil,
				["w"] = math.min(v85, v96),
				["h"] = v86
			}
			v91 = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v61,
				["h"] = v89.y + v86 + 12
			}
		end
		v75.card = v91
		v75.cardText = v90
		v75.cardButton = v89
	end
	return v75
end
function v_u_1.scrollInto(p97, p98, p99, p100, p101) -- name: scrollInto
	local v102 = p98 - p97
	local v103 = math.max(0, v102)
	if p99 < p101 then
		p101 = p99
	elseif p99 + p100 > p101 + p97 then
		p101 = p99 + p100 - p97
	end
	return math.clamp(p101, 0, v103)
end
return v_u_1