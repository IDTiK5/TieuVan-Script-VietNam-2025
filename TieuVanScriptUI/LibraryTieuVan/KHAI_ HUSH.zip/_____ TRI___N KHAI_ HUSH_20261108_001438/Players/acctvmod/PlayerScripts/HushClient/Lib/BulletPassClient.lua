-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / BulletPassClient

local v_u_1 = {
	["CACHE_S"] = 0.5,
	["_env"] = nil
}
local v_u_2 = (-1 / 0)
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local function v_u_9() -- name: rules
	-- upvalues: (copy) v_u_1, (ref) v_u_4
	local v6 = v_u_1._env
	if v6 == nil or v6.rules == nil then
		if v_u_4 == nil then
			local v7, v8 = pcall(function()
				return require(game:GetService("ReplicatedStorage").Hush.Shared.BulletPassRules)
			end)
			if not v7 or type(v8) ~= "table" then
				v8 = false
			end
			v_u_4 = v8
		end
		if v_u_4 then
			return v_u_4
		else
			return nil
		end
	else
		return v6.rules
	end
end
local function v_u_13() -- name: switchOn
	-- upvalues: (copy) v_u_1
	local v10 = v_u_1._env
	if v10 ~= nil and v10.flag ~= nil then
		return v10.flag("BulletPass") ~= false
	end
	local v11, v12 = pcall(function()
		return require(game:GetService("ReplicatedStorage").Hush.Shared.Config).flag("BulletPass")
	end)
	if v11 then
		v11 = v12 == false
	end
	return not v11
end
local function v_u_17() -- name: okAttr
	-- upvalues: (copy) v_u_1
	local v14 = v_u_1._env
	if v14 ~= nil and v14.attr ~= nil then
		return v14.attr("BulletPassOk") == true
	end
	local v15, v16 = pcall(function()
		return workspace:GetAttribute("BulletPassOk")
	end)
	if v15 then
		v15 = v16 == true
	end
	return v15
end
local function v_u_22(p_u_18) -- name: registered
	-- upvalues: (copy) v_u_1
	local v19 = v_u_1._env
	if v19 ~= nil and v19.registered ~= nil then
		return v19.registered(p_u_18) == true
	end
	local v20, v21 = pcall(function()
		-- upvalues: (copy) p_u_18
		return game:GetService("PhysicsService"):IsCollisionGroupRegistered(p_u_18)
	end)
	if v20 then
		v20 = v21 == true
	end
	return v20
end
local function v_u_26() -- name: compute
	-- upvalues: (copy) v_u_9, (copy) v_u_13, (copy) v_u_17, (copy) v_u_22
	local v23 = v_u_9()
	if v23 ~= nil then
		local v24 = v23.GROUP
		if type(v24) == "table" then
			local v25 = v23.GROUP.BULLET
			if type(v25) == "string" then
				if v_u_13() and v_u_17() then
					if v_u_22(v23.GROUP.BULLET) then
						return v23.GROUP.BULLET
					else
						return nil
					end
				else
					return nil
				end
			end
		end
	end
	return nil
end
function v_u_1.group() -- name: group
	-- upvalues: (copy) v_u_1, (ref) v_u_2, (ref) v_u_3, (copy) v_u_26
	local v27 = v_u_1._env
	local v28
	if v27 == nil or v27.now == nil then
		v28 = os.clock()
	else
		v28 = v27.now()
	end
	if v28 - v_u_2 >= v_u_1.CACHE_S or v28 < v_u_2 then
		v_u_2 = v28
		v_u_3 = v_u_26()
	end
	return v_u_3
end
function v_u_1.reset() -- name: reset
	-- upvalues: (ref) v_u_2, (ref) v_u_3
	v_u_2 = (-1 / 0)
	v_u_3 = nil
end
function v_u_1.params(p29) -- name: params
	-- upvalues: (ref) v_u_5, (copy) v_u_1
	local v30 = v_u_5
	if v30 == nil then
		v30 = RaycastParams.new()
		v30.FilterType = Enum.RaycastFilterType.Exclude
		v30.IgnoreWater = true
		v_u_5 = v30
	end
	v30.FilterDescendantsInstances = p29
	v30.CollisionGroup = v_u_1.group() or "Default"
	return v30
end
function v_u_1.isShell(p_u_31) -- name: isShell
	-- upvalues: (copy) v_u_9
	local v32 = v_u_9()
	if v32 ~= nil and p_u_31 ~= nil then
		local v33 = v32.GROUP
		if type(v33) == "table" then
			local v34, v35 = pcall(function()
				-- upvalues: (copy) p_u_31
				return p_u_31.CollisionGroup
			end)
			if v34 then
				v34 = v35 == v32.GROUP.BULLET_ONLY
			end
			return v34
		end
	end
	return false
end
function v_u_1.doorFor(p36) -- name: doorFor
	-- upvalues: (copy) v_u_13, (copy) v_u_9
	if v_u_13() then
		local v37 = v_u_9()
		if v37 == nil or p36 == nil then
			return nil
		else
			local v38 = p36.Name
			if v38 == "Leaf" or v38 == "Leaf2" then
				local v_u_39 = p36:FindFirstAncestorOfClass("Model")
				if v_u_39 == nil then
					return nil
				else
					local v40, v41 = pcall(function()
						-- upvalues: (copy) v_u_39
						return game:GetService("CollectionService"):HasTag(v_u_39, "HushDoor")
					end)
					if v40 and v41 then
						if v37.isWoodDoor(v_u_39:GetAttribute("Kind"), v_u_39:GetAttribute("Metal"), p36.Material.Name) then
							return v_u_39
						else
							return nil
						end
					else
						return nil
					end
				end
			else
				return nil
			end
		end
	else
		return nil
	end
end
function v_u_1.weaponPasses(p42) -- name: weaponPasses
	-- upvalues: (copy) v_u_13, (copy) v_u_9
	if not v_u_13() then
		return false
	end
	local v43 = v_u_9()
	local v44
	if v43 == nil then
		v44 = false
	else
		v44 = v43.weaponPasses(p42) == true
	end
	return v44
end
function v_u_1.exitPoint(p45, p46, p47) -- name: exitPoint
	-- upvalues: (copy) v_u_9
	local v48 = v_u_9()
	local v49 = p45.CFrame
	local v50 = v49:PointToObjectSpace(p46)
	local v51 = v49:VectorToObjectSpace(p47)
	local v52 = p45.Size
	local v53
	if v48 == nil then
		v53 = nil
	else
		v53 = v48.exitT({
			["x"] = v50.X,
			["y"] = v50.Y,
			["z"] = v50.Z
		}, {
			["x"] = v51.X,
			["y"] = v51.Y,
			["z"] = v51.Z
		}, {
			["x"] = v52.X / 2,
			["y"] = v52.Y / 2,
			["z"] = v52.Z / 2
		})
	end
	if v53 == nil or v53 <= 0 then
		local v54 = v52.X
		local v55 = v52.Y
		local v56 = v52.Z
		v53 = math.min(v54, v55, v56)
	end
	return p46 + p47 * v53
end
function v_u_1.passDoor(p57, p58, p59, p60, p61) -- name: passDoor
	-- upvalues: (copy) v_u_1
	local v62 = v_u_1.exitPoint(p58.Instance, p58.Position, p59)
	p57.impact(p58.Position, p58.Normal, "Wood")
	p57.impact(v62, p59, "Wood")
	table.insert(p60, p61)
	return v62
end
function v_u_1.slideTravel(p_u_63, p64, p_u_65) -- name: slideTravel
	if type(p64) == "table" then
		local v66 = p64.id
		if type(v66) == "string" then
			local v67 = p64.id
			if string.sub(v67, 1, 12) == "pistol_m1911" then
				local v69, v70 = pcall(function()
					-- upvalues: (copy) p_u_65, (copy) p_u_63
					local v68 = p_u_65.M1911Model
					return v68.get(v68.rev(p_u_63)).slideTravel
				end)
				if v69 and type(v70) == "number" then
					return v70
				end
			end
		end
	end
	return 0.13
end
return v_u_1