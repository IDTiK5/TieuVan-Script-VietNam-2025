-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayLadder

local v_u_167 = {
	["DIFFS"] = { "Normal", "Hard", "Nightmare" },
	["RANK"] = {
		["Normal"] = 0,
		["Hard"] = 1,
		["Nightmare"] = 2
	},
	["SKULLS"] = 5,
	["ROW_MARKS_MIN_W"] = 500,
	["PRODUCT"] = {
		["Hard"] = "unlock_hard",
		["Nightmare"] = "unlock_nightmare"
	},
	["BUY_ORDER"] = 14,
	["BUY_GAP"] = 2,
	["skulls"] = function(p1) -- name: skulls
		-- upvalues: (copy) v_u_167
		local v2 = tonumber(p1)
		if v2 == nil or v2 ~= v2 then
			return nil
		end
		local v3 = math.floor(v2)
		local v4 = v_u_167.SKULLS
		local v5 = math.clamp(v3, 0, v4)
		if v5 < 1 then
			return nil
		end
		local v6 = {}
		for v7 = 1, v_u_167.SKULLS do
			v6[v7] = v7 <= v5
		end
		return v6
	end,
	["dangerText"] = function(p8) -- name: dangerText
		-- upvalues: (copy) v_u_167
		local v9 = v_u_167.skulls(p8)
		if v9 == nil then
			return ""
		end
		local v10 = 0
		for _, v11 in v9 do
			if not v11 then
				continue
			end
			v10 = v10 + 1
		end
		return ("Danger %d of %d"):format(v10, v_u_167.SKULLS)
	end,
	["rowMarks"] = function(p12) -- name: rowMarks
		-- upvalues: (copy) v_u_167
		local v13 = tonumber(p12) or 0
		return (v13 ~= v13 and 0 or math.floor(v13)) >= v_u_167.ROW_MARKS_MIN_W
	end,
	["tile"] = function(p14, p15, p16) -- name: tile
		-- upvalues: (copy) v_u_167
		local v17 = tonumber(p14)
		local v18 = p16 ~= false
		local v19 = {
			["skulls"] = v_u_167.skulls(p15)
		}
		local v20
		if v18 then
			v20 = v17 == nil and true or v17 < 1
		else
			v20 = v18
		end
		v19.hard = v20
		if v18 then
			v18 = v17 == nil and true or v17 < 2
		end
		v19.nightmare = v18
		return v19
	end,
	["lowestLocked"] = function(p21) -- name: lowestLocked
		local v22 = tonumber(p21)
		return (v22 == nil or v22 < 1) and "Hard" or (v22 < 2 and "Nightmare" or nil)
	end,
	["maxOf"] = function(p23) -- name: maxOf
		-- upvalues: (copy) v_u_167
		local v24 = tonumber(p23) or 0
		local v25 = v_u_167.DIFFS
		local v26 = math.floor(v24)
		return v25[math.clamp(v26, 0, 2) + 1]
	end,
	["findProduct"] = function(p27, p28) -- name: findProduct
		if type(p27) == "table" then
			local v29 = p27.products
			if type(v29) == "table" then
				for _, v30 in p27.products do
					if type(v30) ~= "table" or v30.id ~= p28 then
						continue
					end
					if v30.enabled == false or v30.offSale == true then
						return nil
					else
						return v30
					end
				end
				return nil
			end
		end
		return nil
	end,
	["mapWord"] = function(p31) -- name: mapWord
		return (type(p31) ~= "string" or (p31 == "" or string.find(p31, "^[%?%s]+$") ~= nil)) and "the next area" or p31
	end,
	["priceRich"] = function(p32, p33, p34) -- name: priceRich
		local v35 = tonumber(p32)
		if v35 == nil then
			return ""
		end
		local v36
		if p34 == nil then
			local v37 = math.floor(v35)
			v36 = tostring(v37)
		else
			v36 = p34(v35)
		end
		return ("<font face=\"GothamBold\">%s</font> %s"):format(p33, v36)
	end,
	["new"] = function(p_u_38, p_u_39, p_u_40) -- name: new
		-- upvalues: (copy) v_u_167
		local v_u_41 = {}
		local function v_u_49(p42, ...) -- name: safe
			-- upvalues: (copy) p_u_38
			local v43 = p_u_38
			local v44
			if type(v43) == "table" then
				local v45 = p_u_38[p42]
				v44 = type(v45) == "function"
			else
				v44 = false
			end
			if v44 then
				local v46 = p_u_38[p42]
				local v47, v48 = pcall(v46, ...)
				if v47 then
					return v48
				else
					return nil
				end
			else
				return nil
			end
		end
		function v_u_41.complete() -- name: complete
			-- upvalues: (copy) p_u_38
			local v50 = p_u_38
			local v51
			if type(v50) == "table" then
				local v52 = p_u_38.parseAttr
				v51 = type(v52) == "function"
			else
				v51 = false
			end
			if v51 then
				local v53 = p_u_38
				if type(v53) == "table" then
					local v54 = p_u_38.levelFromAttr
					v51 = type(v54) == "function"
				else
					v51 = false
				end
				if v51 then
					local v55 = p_u_38
					if type(v55) == "table" then
						local v56 = p_u_38.hasFromAttr
						v51 = type(v56) == "function"
					else
						v51 = false
					end
					if v51 then
						local v57 = p_u_38
						if type(v57) == "table" then
							local v58 = p_u_38.squadMax
							v51 = type(v58) == "function"
						else
							v51 = false
						end
						if v51 then
							local v59 = p_u_38
							if type(v59) == "table" then
								local v60 = p_u_38.canon
								v51 = type(v60) == "function"
							else
								v51 = false
							end
							if v51 then
								local v61 = p_u_38
								if type(v61) == "table" then
									local v62 = p_u_38.nextLacking
									v51 = type(v62) == "function"
								else
									v51 = false
								end
								if v51 then
									local v63 = p_u_38
									if type(v63) == "table" then
										local v64 = p_u_38.howLine
										v51 = type(v64) == "function"
									else
										v51 = false
									end
								end
							end
						end
					end
				end
			end
			return v51
		end
		function v_u_41.on() -- name: on
			-- upvalues: (copy) v_u_41, (copy) p_u_38
			if not v_u_41.complete() then
				return false
			end
			local v65 = p_u_38
			local v66
			if type(v65) == "table" then
				local v67 = p_u_38.enabled
				v66 = type(v67) == "function"
			else
				v66 = false
			end
			if v66 then
				local v68 = p_u_38.enabled
				local v69, v70 = pcall(v68)
				if v69 and v70 == false then
					return false
				end
			end
			return true
		end
		function v_u_41.levels(p71) -- name: levels
			-- upvalues: (copy) v_u_49
			if type(p71) == "string" and p71 ~= "" then
				local v72 = v_u_49("parseAttr", p71)
				if type(v72) == "table" then
					return v72
				else
					return nil
				end
			else
				return nil
			end
		end
		function v_u_41.canon(p73) -- name: canon
			-- upvalues: (copy) v_u_49
			if type(p73) == "string" then
				local v74 = v_u_49("canon", p73)
				if type(v74) == "string" then
					return v74
				else
					return nil
				end
			else
				return nil
			end
		end
		function v_u_41.inLadder(p75) -- name: inLadder
			-- upvalues: (copy) v_u_41, (copy) p_u_38
			local v76 = v_u_41.canon(p75)
			if v76 == nil then
				return false
			end
			local v77 = p_u_38
			local v78
			if type(v77) == "table" then
				v78 = p_u_38.FOLLOWS
			else
				v78 = nil
			end
			local v79
			if type(v78) == "table" then
				local v80 = v78[v76]
				if type(v80) == "string" then
					v79 = v78[v76]
				else
					v79 = nil
				end
			else
				v79 = nil
			end
			if v79 ~= nil then
				return true
			end
			local v81 = p_u_38
			local v82
			if type(v81) == "table" then
				v82 = p_u_38.CHAIN
			else
				v82 = nil
			end
			local v83
			if type(v82) == "table" then
				v83 = table.find(v82, v76) ~= nil
			else
				v83 = false
			end
			return v83
		end
		function v_u_41.isFirst(p84) -- name: isFirst
			-- upvalues: (copy) v_u_41, (copy) p_u_38
			local v85 = v_u_41.canon(p84)
			if v85 == nil then
				return false
			end
			local v86 = p_u_38
			local v87
			if type(v86) == "table" then
				v87 = p_u_38.CHAIN
			else
				v87 = nil
			end
			local v88
			if type(v87) == "table" then
				v88 = v87[1]
			else
				v88 = nil
			end
			local v89
			if v88 == nil then
				v89 = false
			elseif v85 == v88 then
				v89 = true
			else
				local v90 = p_u_38
				local v91
				if type(v90) == "table" then
					v91 = p_u_38.FOLLOWS
				else
					v91 = nil
				end
				local v92
				if type(v91) == "table" then
					local v93 = v91[v85]
					if type(v93) == "string" then
						v92 = v91[v85]
					else
						v92 = nil
					end
				else
					v92 = nil
				end
				v89 = v92 == v88
			end
			return v89
		end
		function v_u_41.level(p94, p95) -- name: level
			-- upvalues: (copy) v_u_41, (copy) v_u_49
			if type(p94) ~= "table" or not v_u_41.inLadder(p95) then
				return nil
			end
			local v96 = v_u_49
			return tonumber(v96("levelFromAttr", p94, p95))
		end
		function v_u_41.has(p97, p98, p99) -- name: has
			-- upvalues: (ref) v_u_167, (copy) v_u_49
			if v_u_167.RANK[p99] == nil then
				return false
			end
			if p99 == "Normal" then
				return true
			end
			local v100
			if type(p97) == "table" then
				v100 = v_u_49("hasFromAttr", p97, p98, p99) == true
			else
				v100 = false
			end
			return v100
		end
		function v_u_41.how(p101, p102, p103) -- name: how
			-- upvalues: (copy) v_u_49
			local v104 = v_u_49("howLine", p101, p102, {
				["shop"] = p103 == true
			})
			return type(v104) ~= "string" and "" or v104
		end
		function v_u_41.diffState(p105, p106) -- name: diffState
			-- upvalues: (ref) v_u_167, (copy) v_u_41, (copy) p_u_39
			local v107 = v_u_167.RANK[p106]
			if v107 == nil or v107 == 0 then
				return {
					["ok"] = true,
					["selfLacks"] = false,
					["who"] = nil,
					["unknown"] = false,
					["lock"] = nil,
					["who"] = {}
				}
			end
			local v108 = p105.shop
			local v109 = type(v108) ~= "table" and {} or p105.shop
			if not v_u_41.inLadder(p105.mapId) then
				local v110 = p105.unlocked
				local v111
				if type(v110) == "table" then
					v111 = p105.unlocked[p106] == true
				else
					v111 = false
				end
				local v112 = {
					["ok"] = nil,
					["selfLacks"] = nil,
					["who"] = nil,
					["unknown"] = false,
					["lock"] = nil,
					["ok"] = v111,
					["selfLacks"] = not v111,
					["who"] = {}
				}
				local v113
				if v111 then
					v113 = nil
				else
					v113 = p_u_39.diffLock(p106, p105.hp)
				end
				v112.lock = v113
				return v112
			end
			local v114 = p105.mine
			if type(v114) ~= "table" then
				return {
					["ok"] = false,
					["selfLacks"] = true,
					["who"] = nil,
					["unknown"] = true,
					["lock"] = nil,
					["who"] = {},
					["lock"] = p_u_39.diffLock(p106, p105.hp, {
						["unknown"] = true
					})
				}
			end
			local v115 = v_u_41.has(p105.mine, p105.mapId, p106)
			local v116 = p105.members
			local v117 = {}
			for _, v118 in type(v116) ~= "table" and {} or p105.members do
				if type(v118) ~= "table" then
					continue
				end
				local v119 = v118.levels
				if type(v119) ~= "table" or v_u_41.has(v118.levels, p105.mapId, p106) then
					continue
				end
				local v120 = v118.name
				local v121 = tostring(v120)
				table.insert(v117, v121)
			end
			local v122 = nil
			if v115 then
				if #v117 > 0 then
					local v123 = p_u_39.lackLock
					local v124 = p105.mapName
					v122 = v123(v117, p106, (tostring(v124)))
				end
			else
				local v125 = p_u_39.diffLock
				local v126 = p105.hp
				local v127 = {}
				local v128 = p105.mapName
				v127.map = tostring(v128)
				v127.first = v_u_41.isFirst(p105.mapId)
				v127.how = v_u_41.how(p105.mapId, p106, v109[p106] == true)
				v122 = v125(p106, v126, v127)
			end
			local v129 = {
				["ok"] = nil,
				["selfLacks"] = nil,
				["who"] = nil,
				["unknown"] = false,
				["lock"] = nil
			}
			local v130
			if v115 then
				v130 = #v117 == 0
			else
				v130 = v115
			end
			v129.ok = v130
			v129.selfLacks = not v115
			v129.who = v117
			v129.lock = v122
			return v129
		end
		function v_u_41.fitDiff(p131, p132) -- name: fitDiff
			-- upvalues: (ref) v_u_167, (copy) v_u_41, (copy) v_u_49
			local v133 = v_u_167.RANK[p132]
			if v133 ~= nil then
				local v134 = p131.mine
				if type(v134) == "table" and v_u_41.inLadder(p131.mapId) then
					local v135 = { p131.mine }
					local v136 = p131.members
					for _, v137 in type(v136) ~= "table" and {} or p131.members do
						if type(v137) ~= "table" then
							continue
						end
						local v138 = v137.levels
						if type(v138) ~= "table" then
							continue
						end
						local v139 = v137.levels
						table.insert(v135, v139)
					end
					local v140 = v_u_167.RANK
					local v141 = v_u_49
					local v142 = p131.mapId
					local v143 = v140[tostring(v141("squadMax", v135, v142))] or 0
					return v_u_167.DIFFS[math.min(v133, v143) + 1]
				end
			end
			return p132
		end
		function v_u_41.offer(p144, p145, p146) -- name: offer
			-- upvalues: (ref) v_u_167, (copy) v_u_41, (copy) v_u_49, (copy) p_u_40, (copy) p_u_38
			local v147 = p144.mine
			if type(v147) ~= "table" then
				return nil
			end
			if p145 == "Normal" or (v_u_167.RANK[p145] == nil or v_u_41.has(p144.mine, p144.mapId, p145)) then
				p145 = v_u_167.lowestLocked(v_u_41.level(p144.mine, p144.mapId))
			end
			if p145 == nil or not v_u_41.inLadder(p144.mapId) then
				return nil
			end
			local v148 = v_u_167.findProduct(p146, v_u_167.PRODUCT[p145])
			if v148 == nil then
				return nil
			end
			local v149 = v148.unlock
			if type(v149) == "table" then
				local v150 = v149.state
				if type(v150) == "string" and v149.state ~= "open" then
					return nil
				end
			end
			local v151
			if type(v149) == "table" then
				local v152 = v149.target
				if type(v152) == "string" then
					v151 = v149.target
				else
					v151 = nil
				end
			else
				v151 = nil
			end
			if v151 == nil then
				v151 = v_u_49("nextLacking", p144.mine, p145, true)
			end
			if type(v151) ~= "string" then
				return nil
			end
			local v153 = v_u_167.mapWord(p144.nameOf(v151))
			if p_u_40 ~= nil then
				v153 = p_u_40.mapWord(v153)
			end
			local v154
			if type(v149) == "table" then
				local v155 = v149.levels
				if type(v155) == "table" then
					v154 = v149.levels
				else
					v154 = nil
				end
			else
				v154 = nil
			end
			local v156 = v_u_41.canon(p144.mapId)
			local v157
			if v_u_41.canon(v151) == nil then
				v157 = false
			elseif v_u_41.canon(v151) == v156 then
				v157 = true
			elseif v156 == nil then
				v157 = false
			else
				local v158 = p_u_38
				local v159
				if type(v158) == "table" then
					v159 = p_u_38.FOLLOWS
				else
					v159 = nil
				end
				local v160
				if type(v159) == "table" then
					local v161 = v159[v156]
					if type(v161) == "string" then
						v160 = v159[v156]
					else
						v160 = nil
					end
				else
					v160 = nil
				end
				v157 = v160 == v_u_41.canon(v151)
			end
			local v162
			if v154 == nil then
				v162 = v_u_41.has(p144.mine, p144.mapId, p145)
			else
				v162 = v_u_49("hasFromAttr", v154, p144.mapId, p145) == true
			end
			local v163 = {
				["id"] = v_u_167.PRODUCT[p145],
				["diff"] = p145,
				["target"] = v151,
				["name"] = v153,
				["here"] = v157
			}
			local v164
			if p_u_40 == nil then
				v164 = v_u_167.mapWord(p144.nameOf(p144.mapId))
			else
				v164 = p_u_40.mapWord(v_u_167.mapWord(p144.nameOf(p144.mapId)))
			end
			v163.shownName = v164
			v163.shownHas = v162
			v163.levels = v154
			local v165 = v148.price
			v163.price = tonumber(v165)
			v163.text = ("Unlock next %s: %s"):format(p145, v153)
			local v166
			if v157 then
				v166 = ("Opens %s here."):format(p145)
			else
				v166 = ("Opens %s on %s, the first map where you lack it."):format(p145, v153)
			end
			v163.note = v166
			if p_u_40 ~= nil then
				v163.text = p_u_40.textFor(p145, v153)
				v163.warn = p_u_40.warnLine(v163)
				v163.note = p_u_40.noteFor(v163)
				v163.confirm = p_u_40.confirmFor(v163)
			end
			return v163
		end
		return v_u_41
	end
}
local v_u_168 = nil
function v_u_167.bind(p_u_169) -- name: bind
	-- upvalues: (ref) v_u_168, (copy) v_u_167
	local v_u_170 = nil
	local v_u_171 = nil
	local v_u_172 = nil
	local function v173()
		-- upvalues: (ref) v_u_170, (copy) p_u_169, (ref) v_u_171
		v_u_170 = p_u_169.cctx.shared.MapLadder
		v_u_171 = p_u_169.cctx.lib.PlayWhy
	end
	local v174 = pcall(v173)
	local function v175()
		-- upvalues: (ref) v_u_172, (copy) p_u_169
		v_u_172 = p_u_169.cctx.lib.UnlockChain
	end
	pcall(v175)
	if v174 then
		local v176 = v_u_170
		if type(v176) == "table" then
			local v177 = v_u_171
			if type(v177) == "table" then
				if v_u_168 == nil or (v_u_168.ML ~= v_u_170 or (v_u_168.W ~= v_u_171 or v_u_168.UC ~= v_u_172)) then
					v_u_168 = {
						["ML"] = v_u_170,
						["W"] = v_u_171,
						["UC"] = v_u_172,
						["L"] = v_u_167.new(v_u_170, v_u_171, v_u_172)
					}
				end
				return v_u_168.L
			end
		end
	end
	return nil
end
function v_u_167.memberLack(p178, p179, p180, p181) -- name: memberLack
	-- upvalues: (copy) v_u_167
	local v182
	if type(p179) == "table" then
		v182 = p179.settings
	else
		v182 = nil
	end
	if type(v182) == "table" and type(p180) == "table" then
		local v183 = v182.difficulty
		local v184 = v182.mapId
		if type(v183) == "string" and ((v_u_167.RANK[v183] or 0) >= 1 and type(v184) == "string") then
			local v185 = v_u_167.bind(p178)
			if v185 == nil or not (v185.on() and v185.inLadder(v184)) then
				return nil
			else
				local v186 = p180.userId
				local v187 = p181:GetPlayerByUserId(tonumber(v186) or 0)
				if v187 then
					local v188 = v185.levels(v187:GetAttribute("MapLv"))
					if v188 == nil or v185.has(v188, v184, v183) then
						return nil
					else
						return ("No %s here"):format(v183)
					end
				else
					return nil
				end
			end
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_217(p_u_189, p_u_190, p191, p192) -- name: makeStrip
	-- upvalues: (copy) v_u_167
	local v193 = p192.size
	local v_u_194 = p_u_189.new("Frame", {
		["Name"] = "Ladder",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["AnchorPoint"] = p192.anchor,
		["Position"] = p192.position,
		["Size"] = UDim2.fromOffset(0, p192.height),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["LayoutOrder"] = p192.order or 1
	}, p191)
	p_u_189.layout(v_u_194, "h", p192.gap or 8, p192.rightAlign and "right" or nil)
	local v195 = p_u_189.new("Frame", {
		["Name"] = "Skulls",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.fromOffset(v_u_167.SKULLS * v193 + (v_u_167.SKULLS - 1) * 2, v193)
	}, v_u_194)
	p_u_189.layout(v195, "h", 2)
	local v_u_196 = {}
	for v197 = 1, v_u_167.SKULLS do
		local v198 = p_u_189.icon("skull", {
			["size"] = nil,
			["thickness"] = 1,
			["color"] = nil,
			["size"] = v193,
			["color"] = p_u_190.line
		})
		v198.LayoutOrder = v197
		v198.Parent = v195
		v_u_196[v197] = v198
	end
	local v_u_199 = {}
	if p192.marks == true then
		local v200 = p_u_189.new("Frame", {
			["Name"] = "Locks",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.fromOffset(0, v193 + 2),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v_u_194)
		p_u_189.layout(v200, "h", 6)
		for v201, v202 in { "Hard", "Nightmare" } do
			local v203 = p_u_189.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Name"] = "Lock" .. v202,
				["Size"] = UDim2.fromOffset(0, v193 + 2),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = v201
			}, v200)
			p_u_189.layout(v203, "h", 2)
			local v204 = p_u_189.icon("lock", {
				["size"] = nil,
				["thickness"] = 1,
				["color"] = nil,
				["size"] = v193 + 1,
				["color"] = p_u_190.text2
			})
			v204.LayoutOrder = 1
			v204.Parent = v203
			local v205 = p_u_189.label
			local v206 = {
				["parent"] = nil,
				["name"] = "Letter",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["track"] = false,
				["order"] = 2,
				["parent"] = v203
			}
			local v207
			if p192.words then
				v207 = string.upper(v202)
			else
				v207 = string.sub(v202, 1, 1)
			end
			v206.text = v207
			v206.color = p_u_190.text2
			v206.size = UDim2.fromOffset(0, v193 + 2)
			v205(v206)
			v_u_199[v202] = v203
		end
	end
	local v_u_216 = {
		["frame"] = v_u_194,
		["skulls"] = v_u_196,
		["marks"] = v_u_199,
		["lit"] = {},
		["setSkulls"] = function(p208) -- name: setSkulls
			-- upvalues: (copy) v_u_194, (copy) v_u_196, (copy) v_u_216, (copy) p_u_189, (copy) p_u_190
			v_u_194.Visible = p208 ~= nil
			for v209, v210 in v_u_196 do
				local v211
				if p208 == nil then
					v211 = false
				else
					v211 = p208[v209] == true
				end
				if v_u_216.lit[v209] == v211 then
					continue
				end
				v_u_216.lit[v209] = v211
				local v212 = p_u_189.setIconColor
				local v213
				if v211 then
					v213 = p_u_190.danger
				else
					v213 = p_u_190.line
				end
				v212(v210, v213)
			end
		end,
		["setMarks"] = function(p214, p215) -- name: setMarks
			-- upvalues: (copy) v_u_199
			if v_u_199.Hard then
				v_u_199.Hard.Visible = p214
				v_u_199.Nightmare.Visible = p215
			end
		end
	}
	return v_u_216
end
function v_u_167.attach(p_u_218, p_u_219, p_u_220) -- name: attach
	-- upvalues: (copy) v_u_167, (copy) v_u_217
	if type(p_u_220) ~= "table" or p_u_220.pvpve == true then
		return nil
	end
	local v_u_221 = nil
	local v_u_222 = nil
	local v_u_223 = nil
	local function v224()
		-- upvalues: (ref) v_u_221, (copy) p_u_218, (ref) v_u_222
		v_u_221 = p_u_218.cctx.shared.MapLadder
		v_u_222 = p_u_218.cctx.lib.PlayWhy
	end
	local v225 = pcall(v224)
	local function v226()
		-- upvalues: (ref) v_u_223, (copy) p_u_218
		v_u_223 = p_u_218.cctx.lib.UnlockChain
	end
	pcall(v226)
	if v225 then
		local v227 = v_u_221
		if type(v227) == "table" then
			local v228 = v_u_222
			if type(v228) == "table" then
				local v_u_229 = v_u_167.new(v_u_221, v_u_222, v_u_223)
				if not v_u_229.complete() then
					return nil
				end
				local v_u_230 = p_u_220.players or game:GetService("Players")
				local v_u_231 = p_u_220.me or v_u_230.LocalPlayer
				local v_u_232 = p_u_218.ui
				local v_u_233 = p_u_218.theme
				local v_u_234 = v_u_233.color
				local v235 = v_u_233.space.m
				local v_u_236 = p_u_220.sel
				local v_u_237 = {}
				local v_u_238 = nil
				local function v239()
					-- upvalues: (ref) v_u_238, (copy) p_u_218
					v_u_238 = p_u_218.cctx.shared.Maps
				end
				pcall(v239)
				local function v_u_245(p240) -- name: nameOf
					-- upvalues: (ref) v_u_238, (ref) v_u_167, (copy) p_u_219
					local v241 = nil
					if v_u_238 ~= nil then
						local v242 = v_u_238.get
						if type(v242) == "function" then
							local v243 = v_u_238.get
							local v244
							v244, v241 = pcall(v243, p240)
							if not v244 then
								v241 = nil
							end
						end
					end
					if v241 == nil then
						return tostring(p240)
					else
						return v_u_167.mapWord(p_u_219.displayName(v241))
					end
				end
				local v_u_246 = false
				local function v_u_251(p247) -- name: shopFlags
					-- upvalues: (ref) v_u_167
					local v248 = {}
					for v249, v250 in v_u_167.PRODUCT do
						v248[v249] = v_u_167.findProduct(p247, v250) ~= nil
					end
					return v248
				end
				local v_u_252 = nil
				local v_u_253 = -10
				local function v_u_270() -- name: ctx
					-- upvalues: (copy) p_u_220, (ref) v_u_252, (ref) v_u_253, (copy) p_u_218, (copy) v_u_231, (copy) v_u_230, (copy) v_u_229, (ref) v_u_167, (copy) p_u_219, (copy) v_u_251, (ref) v_u_246, (copy) v_u_245
					local v254 = p_u_220.map()
					if v_u_252 ~= nil and (v_u_252.mapId == v254.id and os.clock() - v_u_253 < 0.2) then
						return v_u_252
					end
					local v255 = {}
					local v256 = p_u_218.myParty()
					if v256 ~= nil and (#v256.members > 1 and p_u_218.isLeader()) then
						for _, v257 in v256.members do
							local v258
							if v257.userId == v_u_231.UserId then
								v258 = nil
							else
								local v259 = v_u_230
								local v260 = v257.userId
								v258 = v259:GetPlayerByUserId(tonumber(v260) or 0)
							end
							if not v258 then
								continue
							end
							local v261 = {}
							local v262 = v257.displayName or (v257.name or "A squad mate")
							v261.name = tostring(v262)
							v261.levels = v_u_229.levels(v258:GetAttribute("MapLv"))
							table.insert(v255, v261)
						end
					end
					local v263 = p_u_218.profile
					local v264 = {
						["mapId"] = v254.id,
						["mapName"] = v_u_167.mapWord(p_u_219.displayName(v254)),
						["mine"] = v_u_229.levels(v_u_231:GetAttribute("MapLv")),
						["members"] = v255,
						["hp"] = p_u_218.derived().hardProgress
					}
					local v265 = v_u_251
					local v266
					if v_u_246 then
						v266 = nil
					else
						local v267 = p_u_218.cache
						local v268
						if type(v267) == "table" then
							v268 = p_u_218.cache.store
						else
							v268 = nil
						end
						if type(v268) == "table" then
							v266 = v268.data
						else
							v266 = nil
						end
					end
					v264.shop = v265(v266)
					local v269
					if type(v263) == "table" then
						v269 = v263.unlocked
					else
						v269 = nil
					end
					v264.unlocked = v269
					v264.nameOf = v_u_245
					v_u_252 = v264
					v_u_253 = os.clock()
					return v_u_252
				end
				function v_u_237.on() -- name: on
					-- upvalues: (copy) v_u_229
					return v_u_229.on()
				end
				function v_u_237.state(p271) -- name: state
					-- upvalues: (copy) v_u_229, (copy) v_u_270
					return v_u_229.diffState(v_u_270(), p271)
				end
				function v_u_237.unlocked(p272) -- name: unlocked
					-- upvalues: (copy) v_u_229, (copy) v_u_270
					local v273 = v_u_229.diffState(v_u_270(), p272)
					if v273.ok then
						return true, "Unlocked"
					else
						return false, v273.lock.short
					end
				end
				function v_u_237.lock(p274) -- name: lock
					-- upvalues: (copy) v_u_229, (copy) v_u_270
					return v_u_229.diffState(v_u_270(), p274).lock
				end
				function v_u_237.tap(p275) -- name: tap
					-- upvalues: (copy) v_u_229, (copy) v_u_270, (copy) v_u_232, (copy) v_u_233
					local v276 = v_u_229.diffState(v_u_270(), p275)
					if v276.ok then
						return false
					end
					v_u_232.sound(v_u_233.sounds.error)
					v_u_232.toast(p275 .. " is locked", "warn", v276.lock.long)
					return true
				end
				function v_u_237.fit() -- name: fit
					-- upvalues: (ref) v_u_252, (copy) v_u_229, (copy) v_u_270, (copy) v_u_236
					v_u_252 = nil
					local v277 = v_u_229.fitDiff(v_u_270(), v_u_236.difficulty)
					if v277 ~= v_u_236.difficulty then
						v_u_236.difficulty = v277
					end
				end
				local v278 = v_u_167.rowMarks(p_u_220.w)
				local v279 = v_u_167.SKULLS * 9 + 8 + (v278 and 58 or 0)
				local v_u_280 = v_u_252
				local v_u_281 = v_u_223
				local v_u_282 = v_u_246
				local v_u_283 = v_u_221
				local v_u_284 = {}
				for v285, v286 in p_u_220.rows do
					local v287 = v_u_217(v_u_232, v_u_234, v286.btn, {
						["size"] = 9,
						["height"] = 14,
						["marks"] = nil,
						["anchor"] = nil,
						["position"] = nil,
						["rightAlign"] = true,
						["gap"] = 8,
						["marks"] = v278,
						["anchor"] = Vector2.new(1, 0),
						["position"] = UDim2.new(0.62, -4, 0, 9)
					})
					v287.frame.ZIndex = 2
					v286.name.Size = UDim2.new(0.62, -14 - v279 - 4, 0, 22)
					v_u_284[v285] = {
						["strip"] = v287,
						["def"] = v286.def
					}
				end
				local v_u_288 = v_u_232.new("Frame", {
					["Name"] = "LadderCard",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 5,
					["Visible"] = false,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, p_u_220.op)
				v_u_232.layout(v_u_288, "v", 3)
				local v289 = v_u_232.new("Frame", {
					["Name"] = "Danger",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 18)
				}, v_u_288)
				v_u_232.label({
					["parent"] = nil,
					["name"] = "Caption",
					["text"] = "Danger",
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["position"] = nil,
					["track"] = true,
					["parent"] = v289,
					["color"] = v_u_234.muted,
					["size"] = UDim2.fromOffset(52, 18),
					["position"] = UDim2.fromOffset(0, 0)
				})
				local v_u_290 = v_u_217(v_u_232, v_u_234, v289, {
					["size"] = 12,
					["height"] = 18,
					["marks"] = true,
					["words"] = true,
					["anchor"] = nil,
					["position"] = nil,
					["gap"] = 12,
					["anchor"] = Vector2.new(0, 0),
					["position"] = UDim2.fromOffset(54, 0)
				})
				local v_u_291 = v_u_232.label({
					["parent"] = nil,
					["name"] = "How",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v_u_288,
					["color"] = v_u_234.accent
				})
				local v_u_292 = v_u_232.new("Frame", {
					["Name"] = "UnlockBuy",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = nil,
					["Visible"] = false,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["LayoutOrder"] = v_u_167.BUY_ORDER
				}, p_u_220.facts.Parent)
				v_u_232.pad(v_u_292, {
					v235,
					v235,
					4,
					0
				})
				v_u_232.layout(v_u_292, "v", 4)
				local v293 = p_u_220.w
				local v294 = tonumber(v293)
				local v295 = v_u_232.button
				local v296 = {
					["parent"] = nil,
					["name"] = "UnlockBtn",
					["text"] = "Unlock next Hard",
					["kind"] = "primary",
					["maxTextWidth"] = nil,
					["size"] = nil,
					["onClick"] = nil,
					["parent"] = v_u_292
				}
				local v297
				if v294 == nil then
					v297 = nil
				else
					local v298 = v294 - 2 * v235 - 60
					v297 = math.max(120, v298)
				end
				v296.maxTextWidth = v297
				v296.size = UDim2.new(1, 0, 0, v_u_233.touch(p_u_220.compact and 44 or 48))
				function v296.onClick() -- name: onClick
					-- upvalues: (copy) v_u_237
					v_u_237.buyNow()
				end
				local v299, v_u_300 = v295(v296)
				v299.LayoutOrder = 1
				local v301 = v_u_232.new("Frame", {
					["Name"] = "UnlockInfo",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["BackgroundColor3"] = v_u_234.bg,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_292)
				v_u_232.pad(v301, {
					8,
					8,
					6,
					6
				})
				v_u_232.layout(v301, "v", 2)
				if v_u_232.stroke then
					v_u_232.stroke(v301, v_u_234.line, 1, 0.35)
				end
				local v302 = v_u_232.label
				local v303 = {
					["parent"] = nil,
					["name"] = "Note",
					["text"] = "",
					["style"] = "small",
					["textSize"] = nil,
					["color"] = nil,
					["rich"] = true,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 1,
					["track"] = false,
					["parent"] = v301
				}
				local v304 = v_u_233.phoneText
				v303.textSize = type(v304) ~= "function" and 13 or v_u_233.phoneText(13, "text")
				v303.color = v_u_234.text2
				local v_u_305 = v302(v303)
				local v_u_306 = p_u_220.compact ~= true
				local v_u_307 = ""
				local v_u_308
				if v_u_281 == nil then
					v_u_308 = nil
				else
					v_u_308 = v_u_281.build(v_u_232, v_u_234, v_u_292, {
						["width"] = nil,
						["name"] = "UnlockChain",
						["order"] = 3,
						["theme"] = nil,
						["width"] = v294 == nil and 360 or v294 - 2 * v235,
						["theme"] = v_u_233
					})
				end
				local v309 = v_u_232.new("Frame", {
					["Name"] = "UnlockStore",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 4,
					["Size"] = UDim2.new(1, 0, 0, v_u_233.touch(34))
				}, v_u_292)
				if v_u_308 ~= nil and p_u_220.compact == true then
					local _, v310 = v_u_232.button({
						["parent"] = nil,
						["name"] = "ChainToggle",
						["text"] = "Show your unlocks",
						["kind"] = "ghost",
						["height"] = 32,
						["width"] = 170,
						["anchor"] = nil,
						["position"] = nil,
						["onClick"] = nil,
						["parent"] = v309,
						["anchor"] = Vector2.new(0, 0.5),
						["position"] = UDim2.fromScale(0, 0.5),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_306, (ref) v_u_307, (copy) v_u_237
							v_u_306 = not v_u_306
							v_u_307 = ""
							v_u_237.paint()
						end
					})
					v_u_237.toggleApi = v310
				end
				v_u_232.button({
					["parent"] = nil,
					["name"] = "StoreLink",
					["text"] = "More in store",
					["kind"] = "ghost",
					["height"] = 32,
					["width"] = 130,
					["anchor"] = nil,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v309,
					["anchor"] = Vector2.new(1, 0.5),
					["position"] = UDim2.fromScale(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_237, (copy) p_u_218
						local v311 = v_u_237.offerNow
						local v312 = p_u_218.openStore
						if type(v312) == "function" then
							local v313 = p_u_218.openStore
							local v314
							if v311 then
								v314 = v311.id
							else
								v314 = nil
							end
							pcall(v313, v314)
						else
							local v315 = p_u_218.setTab
							if type(v315) == "function" then
								local v316 = p_u_218.setTab
								pcall(v316, "store")
							end
						end
					end
				})
				v_u_237.offerNow = nil
				local v_u_317 = -10
				function v_u_237.buyNow() -- name: buyNow
					-- upvalues: (copy) v_u_237, (ref) v_u_317, (ref) v_u_167, (copy) p_u_218, (ref) v_u_281
					local v_u_318 = v_u_237.offerNow
					if v_u_318 == nil or os.clock() - v_u_317 < v_u_167.BUY_GAP then
						return
					else
						v_u_317 = os.clock()
						local function v319() -- name: send
							-- upvalues: (ref) p_u_218, (copy) v_u_318
							p_u_218.op({
								["op"] = "storeBuy",
								["id"] = nil,
								["id"] = v_u_318.id
							})
						end
						if v_u_281 == nil then
							p_u_218.op({
								["op"] = "storeBuy",
								["id"] = nil,
								["id"] = v_u_318.id
							})
						else
							v_u_281.confirm(p_u_218, v_u_318, v319, v_u_237.chainModel(v_u_318))
						end
					end
				end
				function v_u_237.chainModel(p320) -- name: chainModel
					-- upvalues: (ref) v_u_281, (copy) v_u_270, (ref) v_u_283, (copy) v_u_245
					if v_u_281 == nil then
						return nil
					end
					local v321 = v_u_270()
					local v322 = v_u_283.CHAIN
					local v323
					if type(p320) == "table" then
						local v324 = p320.levels
						if type(v324) == "table" then
							v323 = p320.levels
							if type(v323) == "table" and type(v322) == "table" then
								return v_u_281.model(v323, v322, v_u_245, p320)
							else
								return nil
							end
						else
							v323 = v321.mine
							if type(v323) == "table" and type(v322) == "table" then
								return v_u_281.model(v323, v322, v_u_245, p320)
							else
								return nil
							end
						end
					else
						v323 = v321.mine
						if type(v323) == "table" and type(v322) == "table" then
							return v_u_281.model(v323, v322, v_u_245, p320)
						else
							return nil
						end
					end
				end
				local function v_u_332(p325) -- name: levelsSig
					-- upvalues: (ref) v_u_283
					if type(p325) == "table" then
						local v326 = p325.levels
						if type(v326) == "table" then
							local v327 = v_u_283.CHAIN
							if type(v327) == "table" then
								local v328 = {}
								for _, v329 in v_u_283.CHAIN do
									local v330 = p325.levels[v329]
									local v331 = tostring(v330)
									table.insert(v328, v331)
								end
								return table.concat(v328, "")
							end
						end
					end
					return ""
				end
				local v_u_333 = -100
				local v_u_334 = false
				local function v_u_338() -- name: askStore
					-- upvalues: (ref) v_u_334, (ref) v_u_333, (copy) p_u_218, (ref) v_u_280, (copy) p_u_220, (copy) p_u_219
					if not v_u_334 and os.clock() - v_u_333 >= 60 then
						local v335 = p_u_218.fetch
						if type(v335) == "function" then
							v_u_334 = true
							v_u_333 = os.clock()
							task.spawn(function()
								-- upvalues: (ref) p_u_218, (ref) v_u_334, (ref) v_u_280, (ref) p_u_220, (ref) p_u_219
								local v336 = p_u_218.fetch
								pcall(v336, "store", nil, 120)
								v_u_334 = false
								v_u_280 = nil
								if p_u_220.op.Parent ~= nil then
									local v337 = p_u_219.paint
									pcall(v337)
								end
							end)
							return
						end
					end
				end
				local v_u_339 = 0
				local v_u_340 = nil
				local function v341()
					-- upvalues: (ref) v_u_340, (copy) p_u_218
					v_u_340 = p_u_218.cctx.lib.SquadsWhy
				end
				pcall(v341)
				function v_u_237.paint() -- name: paint
					-- upvalues: (copy) v_u_229, (ref) v_u_340, (ref) v_u_283, (copy) v_u_251, (ref) v_u_282, (copy) p_u_218, (copy) v_u_270, (copy) p_u_220, (copy) v_u_236, (ref) v_u_167, (copy) v_u_338, (copy) v_u_231, (copy) v_u_332, (ref) v_u_306, (ref) v_u_307, (copy) v_u_284, (copy) v_u_288, (copy) v_u_290, (copy) v_u_232, (copy) v_u_291, (copy) v_u_237, (copy) v_u_292, (copy) v_u_300, (copy) v_u_305, (ref) v_u_281, (copy) v_u_234, (ref) v_u_308
					local v342 = v_u_229.on()
					if v_u_340 ~= nil then
						local v343 = v_u_340.setSource
						if type(v343) == "function" then
							v_u_340.setSource(v_u_283, function(p344, p345)
								-- upvalues: (ref) v_u_229, (ref) v_u_251, (ref) v_u_282, (ref) p_u_218
								local v346 = v_u_229.how
								local v347 = v_u_251
								local v348
								if v_u_282 then
									v348 = nil
								else
									local v349 = p_u_218.cache
									local v350
									if type(v349) == "table" then
										v350 = p_u_218.cache.store
									else
										v350 = nil
									end
									if type(v350) == "table" then
										v348 = v350.data
									else
										v348 = nil
									end
								end
								return v346(p344, p345, v347(v348)[p345] == true)
							end)
						end
					end
					local v351 = v_u_270()
					local v352
					if v_u_282 then
						v352 = nil
					else
						local v353 = p_u_218.cache
						local v354
						if type(v353) == "table" then
							v354 = p_u_218.cache.store
						else
							v354 = nil
						end
						if type(v354) == "table" then
							v352 = v354.data
						else
							v352 = nil
						end
					end
					local v355 = p_u_220.view()
					local v356 = v_u_229.level(v351.mine, v355.id)
					local v357 = v_u_229.inLadder(v355.id)
					local v358
					if v342 then
						v358 = v_u_229.offer(v351, v_u_236.difficulty, v352)
					else
						v358 = nil
					end
					local v359
					if v357 and v342 then
						local v360 = v_u_167.lowestLocked
						local v361
						if v351.mine == nil then
							v361 = nil
						else
							v361 = v356
						end
						v359 = v360(v361)
					else
						v359 = nil
					end
					if v342 and (v359 ~= nil or v358 ~= nil) then
						v_u_338()
					end
					local v362 = table.concat
					local v363 = {}
					local v364 = tostring(v342)
					local v365 = v_u_231
					local v366 = tostring(v365:GetAttribute("MapLv"))
					local v367 = v355.id
					local v368 = tostring(v367)
					local v369 = v351.mapId
					local v370 = tostring(v369)
					local v371 = v_u_236.difficulty
					local v372 = tostring(v371)
					local v373 = v351.shop.Hard
					local v374 = tostring(v373)
					local v375 = v351.shop.Nightmare
					local v376 = tostring(v375)
					local v377
					if v358 then
						v377 = v358.id
					else
						v377 = v358
					end
					local v378 = tostring(v377)
					local v379
					if v358 then
						v379 = v358.target
					else
						v379 = v358
					end
					local v380 = tostring(v379)
					local v381
					if v358 then
						v381 = v_u_332(v358)
					else
						v381 = v358
					end
					local v382 = tostring(v381)
					local v383
					if v358 then
						v383 = v358.here
					else
						v383 = v358
					end
					local v384 = tostring(v383)
					local v385
					if v358 then
						v385 = v358.shownHas
					else
						v385 = v358
					end
					local v386 = tostring(v385)
					local v387
					if v358 then
						v387 = v358.price
					else
						v387 = v358
					end
					local v388 = tostring(v387)
					local v389 = #v351.members
					local v390 = v_u_282
					local v391 = v_u_306
					__set_list(v363, 1, {v364, v366, v368, v370, v372, v374, v376, v378, v380, v382, v384, v386, v388, tostring(v389), tostring(v390), (tostring(v391))})
					local v392 = v362(v363, "|")
					if v392 ~= v_u_307 then
						v_u_307 = v392
						for _, v393 in v_u_284 do
							local v394 = v_u_167.tile(v_u_229.level(v351.mine, v393.def.id), v393.def.danger, v_u_229.inLadder(v393.def.id))
							local v395 = v393.strip.frame
							local v396
							if v342 then
								v396 = v394.skulls ~= nil
							else
								v396 = v342
							end
							v395.Visible = v396
							local v397 = v393.strip.setSkulls
							local v398
							if v342 then
								v398 = v394.skulls
							else
								v398 = nil
							end
							v397(v398)
							v393.strip.setMarks(v394.hard, v394.nightmare)
						end
						local v399 = v_u_167.tile(v356, v355.danger, v357)
						local v400 = v_u_288
						local v401
						if v342 then
							v401 = v399.skulls ~= nil
						else
							v401 = v342
						end
						v400.Visible = v401
						local v402 = v_u_290.setSkulls
						local v403
						if v342 then
							v403 = v399.skulls
						else
							v403 = nil
						end
						v402(v403)
						v_u_290.setMarks(v399.hard, v399.nightmare)
						local v404 = (v359 == nil or v351.mine == nil) and "" or v_u_229.how(v355.id, v359, v351.shop[v359] == true)
						v_u_232.setText(v_u_291, v404)
						v_u_291.Visible = v404 ~= ""
						v_u_237.offerNow = v358
						v_u_292.Visible = v358 ~= nil
						if v358 == nil then
							if v_u_308 ~= nil then
								v_u_308.set(nil)
							end
						else
							v_u_300.setText(v358.text)
							local v405 = utf8.char(57346)
							v_u_305.RichText = true
							v_u_305.Text = ((v358.warn == nil or v_u_281 == nil) and "" or ("<font face=\"GothamBold\" color=\"%s\">%s</font>  "):format(v_u_281.hex(v_u_234.accent), v358.warn)) .. (not v358.price and "" or v_u_167.priceRich(v358.price, v405, v_u_232.commas) .. "  ") .. v358.note
							if v_u_308 ~= nil then
								local v406 = v_u_308.set
								local v407
								if v_u_306 then
									v407 = v_u_237.chainModel(v358)
								else
									v407 = nil
								end
								v406(v407, p_u_220.compact == true)
								if v_u_237.toggleApi ~= nil then
									v_u_237.toggleApi.setText(v_u_306 and "Hide your unlocks" or "Show your unlocks")
									return
								end
							end
						end
					end
				end
				local v408 = p_u_220.conns
				local v409 = v_u_231:GetAttributeChangedSignal("MapLv")
				local function v415()
					-- upvalues: (ref) v_u_280, (copy) p_u_218, (ref) v_u_339, (ref) v_u_282, (ref) v_u_333, (copy) p_u_220, (copy) p_u_219
					v_u_280 = nil
					local v410 = p_u_218.fetch
					if type(v410) == "function" then
						v_u_339 = v_u_339 + 1
						local v_u_411 = v_u_339
						v_u_282 = true
						v_u_333 = os.clock()
						task.spawn(function()
							-- upvalues: (ref) p_u_218, (copy) v_u_411, (ref) v_u_339, (ref) v_u_282, (ref) v_u_280, (ref) p_u_220, (ref) p_u_219
							local v412 = p_u_218.fetch
							pcall(v412, "store", nil, 0)
							if v_u_411 == v_u_339 then
								v_u_282 = false
							end
							v_u_280 = nil
							if v_u_411 == v_u_339 and p_u_220.op.Parent ~= nil then
								local v413 = p_u_219.paint
								pcall(v413)
							end
						end)
					end
					if p_u_220.op.Parent ~= nil then
						local v414 = p_u_219.paint
						pcall(v414)
					end
				end
				table.insert(v408, v409:Connect(v415))
				local v_u_416 = false
				local function v_u_421(p417)
					-- upvalues: (copy) p_u_218
					local v418 = p_u_218.profile
					local v419
					if type(v418) == "table" then
						local v420 = v418.unlocked
						v419 = type(v420) ~= "table" and {} or v418.unlocked
					else
						v419 = {}
					end
					return p417 == "Normal" and true or v419[p417] == true, "Locked"
				end
				local v_u_422 = v_u_237.unlocked
				local v_u_423 = "unlocked"
				function v_u_237.unlocked(...)
					-- upvalues: (copy) v_u_422, (ref) v_u_416, (copy) v_u_423, (copy) v_u_421
					local v424 = v_u_422
					local v425, v426, v427 = pcall(v424, ...)
					if v425 then
						return v426, v427
					end
					if not v_u_416 then
						v_u_416 = true
						warn("[PlayLadder] " .. v_u_423 .. " failed: " .. tostring(v426))
					end
					return v_u_421(...)
				end
				local function v_u_428()
					return nil
				end
				local v_u_429 = v_u_237.lock
				local v_u_430 = "lock"
				function v_u_237.lock(...)
					-- upvalues: (copy) v_u_429, (ref) v_u_416, (copy) v_u_430, (copy) v_u_428
					local v431 = v_u_429
					local v432, v433, v434 = pcall(v431, ...)
					if v432 then
						return v433, v434
					end
					if not v_u_416 then
						v_u_416 = true
						warn("[PlayLadder] " .. v_u_430 .. " failed: " .. tostring(v433))
					end
					return v_u_428(...)
				end
				local function v_u_435()
					return false
				end
				local v_u_436 = v_u_237.tap
				local v_u_437 = "tap"
				function v_u_237.tap(...)
					-- upvalues: (copy) v_u_436, (ref) v_u_416, (copy) v_u_437, (copy) v_u_435
					local v438 = v_u_436
					local v439, v440, v441 = pcall(v438, ...)
					if v439 then
						return v440, v441
					end
					if not v_u_416 then
						v_u_416 = true
						warn("[PlayLadder] " .. v_u_437 .. " failed: " .. tostring(v440))
					end
					return v_u_435(...)
				end
				local function v_u_442() end
				local v_u_443 = v_u_237.fit
				local v_u_444 = "fit"
				function v_u_237.fit(...)
					-- upvalues: (copy) v_u_443, (ref) v_u_416, (copy) v_u_444, (copy) v_u_442
					local v445 = v_u_443
					local v446, v447, v448 = pcall(v445, ...)
					if v446 then
						return v447, v448
					end
					if not v_u_416 then
						v_u_416 = true
						warn("[PlayLadder] " .. v_u_444 .. " failed: " .. tostring(v447))
					end
					return v_u_442(...)
				end
				return v_u_237
			end
		end
	end
	return nil
end
return v_u_167