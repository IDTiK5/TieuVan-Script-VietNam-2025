-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Prompts

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ProximityPromptService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("CollectionService")
local v_u_7 = {
	["name"] = "Prompts",
	["order"] = 35
}
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = v_u_3.LocalPlayer
local v_u_12 = {}
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = 0
local v_u_16 = false
local v_u_17 = true
local v_u_18 = 0
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = 3
local v_u_24 = -1
local function v_u_35() -- name: listMax
	-- upvalues: (ref) v_u_10, (ref) v_u_24, (ref) v_u_23, (ref) v_u_8
	if v_u_10 ~= nil then
		local v25 = v_u_10.isPhone
		if type(v25) == "function" and v_u_10.isPhone() then
			if os.clock() - v_u_24 < 0.2 then
				return v_u_23
			end
			v_u_24 = os.clock()
			local v_u_26 = 3
			local function v34()
				-- upvalues: (ref) v_u_8, (ref) v_u_26, (ref) v_u_10
				local v27 = v_u_8
				if v27 then
					v27 = v_u_8.controllers.HUD
				end
				local v28
				if v27 and v27.touchFrame then
					v28 = v27.touchFrame()
				else
					v28 = nil
				end
				local v29
				if v27 and v27.bandOffset then
					v29 = v27.bandOffset("__end")
				else
					v29 = nil
				end
				if v28 then
					local v30 = v28.refH
					if type(v30) == "number" and type(v29) == "number" then
						local v31 = v28.listY + (v29 <= 0 and -8 or v29)
						local v32 = (v28.refH - v28.promptBottom - 66 - v31 - 10) / (v_u_10.touch(30) + 2)
						local v33 = math.floor(v32)
						v_u_26 = math.clamp(v33, 1, 3)
					end
				end
			end
			pcall(v34)
			v_u_23 = v_u_26
			return v_u_26
		end
	end
	return 4
end
local function v_u_45() -- name: listSuppressed
	-- upvalues: (copy) v_u_11, (ref) v_u_10, (ref) v_u_8
	local v36 = v_u_11.Character
	local v37
	if v36 then
		v37 = v36:GetAttribute("Action")
	else
		v37 = nil
	end
	if type(v37) == "string" and (v37 ~= "" and v37 ~= "Extract") then
		return true
	end
	if v_u_10 ~= nil then
		local v38 = v_u_10.isTouch
		if type(v38) == "function" and v_u_10.isTouch() then
			local function v42()
				-- upvalues: (ref) v_u_8
				local v39 = v_u_8
				if v39 then
					v39 = v_u_8.controllers.Input
				end
				local v40 = v39 and v39.touch
				if v40 then
					v40 = v39.touch()
				end
				local v41
				if v40 == nil then
					v41 = false
				else
					v41 = v40.trayOpen == true
				end
				return v41
			end
			local v43, v44 = pcall(v42)
			if v43 then
				v43 = v44 == true
			end
			return v43
		end
	end
	return false
end
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = 0
local function v_u_60() -- name: cardPlace
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_10
	if not v_u_9 or v_u_9.device() ~= "Touch" then
		return UDim2.new(0.5, 0, 1, -124), 360, Vector2.new(0.5, 1)
	end
	local v_u_52 = v_u_8
	if v_u_52 then
		v_u_52 = v_u_8.controllers.HUD
	end
	local v54, v55 = pcall(function()
		-- upvalues: (copy) v_u_52
		local v53 = v_u_52 and v_u_52.touchFrame
		if v53 then
			v53 = v_u_52.touchFrame()
		end
		return v53
	end)
	if not v54 or type(v55) ~= "table" then
		return UDim2.new(0.5, 0, 1, -100), 220, Vector2.new(0.5, 1)
	end
	local v56 = UDim2.new(0, v55.promptRight, 1, -v55.promptBottom)
	local v57 = v55.promptMaxW - 124
	local v58
	if v_u_10 == nil then
		v58 = 120
	else
		local v59 = v_u_10.isPhone
		v58 = type(v59) == "function" and v_u_10.isPhone() and 72 or 120
	end
	return v56, math.clamp(v57, v58, 360), Vector2.new(1, 1)
end
local v_u_61 = Enum.KeyCode.F13
local v_u_62 = Enum.KeyCode.ButtonCenter
local v_u_63 = {
	"Style",
	"KeyboardKeyCode",
	"GamepadKeyCode",
	"ClickablePrompt",
	"Exclusivity",
	"RequiresLineOfSight"
}
local function v_u_71(p_u_64) -- name: prepare
	-- upvalues: (copy) v_u_61, (copy) v_u_62, (ref) v_u_50, (copy) v_u_63
	if not p_u_64:GetAttribute("HushPrepared") then
		p_u_64:SetAttribute("HushPrepared", true)
		local function v66()
			-- upvalues: (copy) p_u_64, (ref) v_u_61, (ref) v_u_62, (ref) v_u_50
			if p_u_64.Style ~= Enum.ProximityPromptStyle.Custom then
				p_u_64.Style = Enum.ProximityPromptStyle.Custom
			end
			if p_u_64.KeyboardKeyCode ~= v_u_61 then
				p_u_64.KeyboardKeyCode = v_u_61
			end
			if p_u_64.GamepadKeyCode ~= v_u_62 then
				p_u_64.GamepadKeyCode = v_u_62
			end
			if p_u_64.ClickablePrompt then
				p_u_64.ClickablePrompt = false
			end
			if p_u_64.Exclusivity ~= Enum.ProximityPromptExclusivity.AlwaysShow then
				p_u_64.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
			end
			if p_u_64.RequiresLineOfSight then
				p_u_64.RequiresLineOfSight = false
			end
			local v65
			if v_u_50 then
				v65 = v_u_50.distance(p_u_64:GetAttribute("Kind"), p_u_64.MaxActivationDistance)
			else
				v65 = nil
			end
			if v65 then
				p_u_64.MaxActivationDistance = v65
			end
		end
		pcall(v66)
		for _, v67 in v_u_63 do
			p_u_64:GetPropertyChangedSignal(v67):Connect(function()
				-- upvalues: (copy) p_u_64, (ref) v_u_61, (ref) v_u_62, (ref) v_u_50
				local v_u_68 = p_u_64
				local function v70()
					-- upvalues: (copy) v_u_68, (ref) v_u_61, (ref) v_u_62, (ref) v_u_50
					if v_u_68.Style ~= Enum.ProximityPromptStyle.Custom then
						v_u_68.Style = Enum.ProximityPromptStyle.Custom
					end
					if v_u_68.KeyboardKeyCode ~= v_u_61 then
						v_u_68.KeyboardKeyCode = v_u_61
					end
					if v_u_68.GamepadKeyCode ~= v_u_62 then
						v_u_68.GamepadKeyCode = v_u_62
					end
					if v_u_68.ClickablePrompt then
						v_u_68.ClickablePrompt = false
					end
					if v_u_68.Exclusivity ~= Enum.ProximityPromptExclusivity.AlwaysShow then
						v_u_68.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
					end
					if v_u_68.RequiresLineOfSight then
						v_u_68.RequiresLineOfSight = false
					end
					local v69
					if v_u_50 then
						v69 = v_u_50.distance(v_u_68:GetAttribute("Kind"), v_u_68.MaxActivationDistance)
					else
						v69 = nil
					end
					if v69 then
						v_u_68.MaxActivationDistance = v69
					end
				end
				pcall(v70)
			end)
		end
	end
end
local function v_u_74(p72) -- name: promptPos
	local v73 = p72.Parent
	if v73 then
		if v73:IsA("Attachment") then
			return v73.WorldPosition
		elseif v73:IsA("BasePart") then
			return v73.Position
		elseif v73:IsA("Model") then
			return v73:GetPivot().Position
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_75 = {
	["raw"] = "",
	["set"] = nil,
	["name"] = nil,
	["set"] = {}
}
local function v_u_86(p76) -- name: lockpickTexts
	-- upvalues: (copy) v_u_11, (copy) v_u_75, (ref) v_u_8
	if p76:GetAttribute("Kind") ~= "doorKey" then
		return nil, nil
	end
	local v77 = p76:GetAttribute("NeedsKey")
	local v78 = v_u_11:GetAttribute("DoorPicks")
	if type(v77) ~= "string" or (type(v78) ~= "string" or v78 == "") then
		return nil, nil
	end
	if v78 ~= v_u_75.raw then
		v_u_75.raw = v78
		table.clear(v_u_75.set)
		for _, v79 in string.split(v78, ",") do
			v_u_75.set[v79] = true
		end
	end
	if not v_u_75.set[v77] then
		return nil, nil
	end
	if not v_u_75.name then
		local function v80()
			-- upvalues: (ref) v_u_8
			return v_u_8.shared.Items.get("key_lockpick_rook")
		end
		local v81, v82 = pcall(v80)
		local v83 = v_u_75
		local v84
		if v81 and type(v82) == "table" then
			local v85 = v82.name
			v84 = type(v85) ~= "string" and "Rook\'s Lockpick" or v82.name
		else
			v84 = "Rook\'s Lockpick"
		end
		v83.name = v84
	end
	return "Use lockpick", v_u_75.name
end
local function v_u_97(p87) -- name: reservedState
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_11, (ref) v_u_50
	local v88 = p87.Parent
	local v89 = nil
	for _ = 1, 4 do
		if not v88 or v88 == workspace then
			break
		end
		if v_u_6:HasTag(v88, "HushContainer") then
			v89 = v88
			break
		end
		v88 = v88.Parent
	end
	if v89 then
		local v90 = v89:GetAttribute("ReservedUntil")
		local v91 = v89:GetAttribute("ReservedSquad")
		if type(v90) == "number" and type(v91) == "string" then
			local v92 = v90 - v_u_2.now()
			if v92 <= 0 then
				return nil, false
			else
				local v93 = v_u_11:GetAttribute("LootSquad")
				if type(v93) ~= "string" or v93 == "" then
					v93 = v_u_11:GetAttribute("SquadId")
					if type(v93) ~= "string" or v93 == "" then
						v93 = v_u_11.Character
						if v93 then
							v93 = v93:GetAttribute("SquadId")
						end
					end
					if type(v93) ~= "string" or v93 == "" then
						local v94 = v_u_11.UserId
						v93 = "solo:" .. tostring(v94)
					end
				end
				if v_u_50 and v89:GetAttribute("Zone") == "vehicle" then
					return v_u_50.stashPrefix(v91, v93)
				else
					local v95 = math.ceil(v92)
					local v96 = string.format("%d:%02d", v95 // 60, v95 % 60)
					if v93 == v91 then
						return "Yours: " .. v96, false
					else
						return "Reserved: " .. v96, true
					end
				end
			end
		else
			return nil, false
		end
	else
		return nil, false
	end
end
local function v_u_109(p98) -- name: lockKeyTexts
	-- upvalues: (copy) v_u_6, (ref) v_u_8, (copy) v_u_11
	if p98.ActionText ~= "Unlock" then
		return nil, nil
	end
	local v99 = p98.Parent
	local v_u_100 = nil
	for _ = 1, 4 do
		if not v99 or v99 == workspace then
			break
		end
		if v_u_6:HasTag(v99, "HushContainer") then
			v_u_100 = v99
			break
		end
		v99 = v99.Parent
	end
	if v_u_100 then
		v_u_100 = v_u_100:GetAttribute("Locked")
	end
	if type(v_u_100) == "string" and v_u_100 ~= "" then
		local v_u_101 = v_u_100
		local function v104()
			-- upvalues: (ref) v_u_8, (copy) v_u_100, (ref) v_u_101
			local v102 = v_u_8.shared.Items.get(v_u_100)
			if type(v102) == "table" then
				local v103 = v102.name
				if type(v103) == "string" then
					v_u_101 = v102.name
				end
			end
		end
		pcall(v104)
		local v105 = p98.ObjectText
		if string.sub(v105, -12) == "  \194\183  Locked" then
			local v106 = #v105 - 12
			v105 = string.sub(v105, 1, v106)
		end
		local v107 = v_u_11:GetAttribute("LockKeys")
		local v108
		if type(v107) == "string" then
			v108 = string.find("," .. v107 .. ",", "," .. v_u_100 .. ",", 1, true) ~= nil
		else
			v108 = false
		end
		if v108 then
			return "Unlock", v105 .. "  \194\183  " .. v_u_101
		else
			return "Locked", v105 .. "  \194\183  Needs " .. v_u_101
		end
	else
		return nil, nil
	end
end
local function v_u_122(p110) -- name: textsOf
	-- upvalues: (copy) v_u_86, (copy) v_u_109, (ref) v_u_47, (copy) v_u_97
	local v111, v112 = v_u_86(p110)
	if v111 then
		return v111, v112 or p110.ObjectText
	end
	local v113, v114 = v_u_109(p110)
	if v113 then
		return v113, v114 or p110.ObjectText
	end
	local v115 = p110.ActionText
	local v116 = p110.ObjectText
	local v117, v118
	if v_u_47 then
		local v119 = v_u_47.texts
		local v120
		v120, v117, v118 = pcall(v119, p110)
		if v120 then
			if type(v117) ~= "string" then
				v117 = v115
			end
			if type(v118) ~= "string" then
				v118 = v116
			end
		else
			v117 = v115
			v118 = v116
		end
	else
		v117 = v115
		v118 = v116
	end
	local v121 = v_u_97(p110)
	if v121 then
		if v118 ~= "" then
			return v117, v121 .. "  \194\183  " .. v118
		end
	else
		v121 = v118
	end
	return v117, v121
end
function v_u_7.texts(p123) -- name: texts
	-- upvalues: (copy) v_u_122
	return v_u_122(p123)
end
local function v_u_162() -- name: build
	-- upvalues: (ref) v_u_19, (ref) v_u_10, (ref) v_u_9, (copy) v_u_7, (ref) v_u_13, (copy) v_u_21, (ref) v_u_20
	if not (v_u_19 and v_u_19.Parent) then
		local v124 = v_u_10.color
		local v125, v126 = v_u_9.screen("HushPrompts", v_u_10.layer.prompts, {
			["insets"] = "Device"
		})
		v_u_19 = v125
		local _, v127 = v_u_9.screen("HushPromptMarker", v_u_10.layer.world, {
			["insets"] = "None"
		})
		local v128 = v_u_9.new("TextButton", {
			["Name"] = "Card",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["Selectable"] = false,
			["BackgroundColor3"] = v124.bg,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -124),
			["Size"] = UDim2.fromOffset(0, 60),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v126)
		v_u_9.stroke(v128, v124.line)
		local v129 = v_u_9.new("UIScale", {}, v128)
		local v130 = v_u_9.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v124.accent,
			["Size"] = UDim2.new(0, 2, 1, 0)
		}, v128)
		local v131 = v_u_9.new("Frame", {
			["Name"] = "Inner",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.fromOffset(0, 60),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v128)
		v_u_9.pad(v131, {
			12,
			24,
			0,
			0
		})
		v_u_9.layout(v131, "h", 14)
		local v132 = v_u_9.new("Frame", {
			["Name"] = "Key",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.fromOffset(44, 44)
		}, v131)
		local v133 = v_u_9.ring({
			["parent"] = nil,
			["size"] = 44,
			["segments"] = 32,
			["thickness"] = 3,
			["value"] = 0,
			["color"] = nil,
			["bgColor"] = nil,
			["bgTransparency"] = 0.5,
			["parent"] = v132,
			["color"] = v124.accent,
			["bgColor"] = v124.line
		})
		local v134 = v_u_9.keyHint("interact", {
			["parent"] = nil,
			["size"] = 24,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v132,
			["position"] = UDim2.fromScale(0.5, 0.5),
			["anchor"] = Vector2.new(0.5, 0.5)
		})
		local v135 = v_u_9.icon("hand", {
			["parent"] = nil,
			["size"] = 18,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v132,
			["color"] = v124.text,
			["position"] = UDim2.fromScale(0.5, 0.5),
			["anchor"] = Vector2.new(0.5, 0.5)
		})
		v135.Visible = false
		local v136 = v_u_9.new("Frame", {
			["Name"] = "Texts",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.fromOffset(0, 44),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v131)
		v_u_9.layout(v136, "v", 0)
		local v137 = v_u_9.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "h3",
			["autoX"] = true,
			["size"] = nil,
			["order"] = 1,
			["maxSize"] = nil,
			["parent"] = v136,
			["size"] = UDim2.fromOffset(0, 24),
			["maxSize"] = Vector2.new(360, 24)
		})
		local v138 = v_u_9.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["maxSize"] = nil,
			["parent"] = v136,
			["color"] = v124.text2,
			["size"] = UDim2.fromOffset(0, 18),
			["maxSize"] = Vector2.new(360, 18)
		})
		local v139 = v_u_9.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 3,
			["parent"] = v131,
			["color"] = v124.muted,
			["size"] = UDim2.fromOffset(0, 44)
		})
		local v140 = v_u_9.new("Frame", {
			["Name"] = "Marker",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(18, 18)
		}, v127)
		v_u_9.icon("ping", {
			["parent"] = nil,
			["size"] = 18,
			["color"] = nil,
			["parent"] = v140,
			["color"] = v124.accent
		})
		local v141 = v_u_9.new("Frame", {
			["Name"] = "Choices",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v124.bg,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.XY
		}, v126)
		v_u_9.stroke(v141, v124.line)
		v_u_9.layout(v141, "v", 0)
		local v142 = {}
		for v143 = 1, 4 do
			local v144 = v_u_10.touch(30)
			local v_u_145 = v_u_9.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Selectable"] = false,
				["Name"] = "Row" .. v143,
				["BackgroundColor3"] = v124.bg,
				["Size"] = UDim2.fromOffset(0, v144),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = v143
			}, v141)
			local v146 = v_u_9.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Visible"] = false,
				["BackgroundColor3"] = v124.accent,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}, v_u_145)
			local v147 = v_u_9.new("Frame", {
				["Name"] = "Inner",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = UDim2.fromOffset(0, v144),
				["AutomaticSize"] = Enum.AutomaticSize.X
			}, v_u_145)
			v_u_9.pad(v147, {
				12,
				14,
				0,
				0
			})
			v_u_9.layout(v147, "h", 8)
			local v_u_148 = {
				["row"] = nil,
				["bar"] = nil,
				["act"] = nil,
				["obj"] = nil,
				["prompt"] = nil,
				["row"] = v_u_145,
				["bar"] = v146,
				["act"] = v_u_9.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "bodyStrong",
					["autoX"] = true,
					["size"] = nil,
					["order"] = 1,
					["maxSize"] = nil,
					["parent"] = v147,
					["size"] = UDim2.fromOffset(0, v144),
					["maxSize"] = Vector2.new(180, v144)
				}),
				["obj"] = v_u_9.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 2,
					["maxSize"] = nil,
					["parent"] = v147,
					["color"] = v124.muted,
					["size"] = UDim2.fromOffset(0, v144),
					["maxSize"] = Vector2.new(200, v144)
				})
			}
			v_u_145.InputBegan:Connect(function(p149)
				-- upvalues: (copy) v_u_148, (ref) v_u_7
				if p149.UserInputType == Enum.UserInputType.Touch or p149.UserInputType == Enum.UserInputType.MouseButton1 then
					local v150 = v_u_148.prompt
					if v150 and v150.Parent then
						v_u_7.pick(v150)
						v_u_7.trigger(true)
					end
				end
			end)
			v_u_145.InputEnded:Connect(function(p151)
				-- upvalues: (ref) v_u_7
				if p151.UserInputType == Enum.UserInputType.Touch or p151.UserInputType == Enum.UserInputType.MouseButton1 then
					v_u_7.trigger(false)
				end
			end)
			v_u_145.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_148, (ref) v_u_13, (copy) v_u_145
				if v_u_148.prompt ~= v_u_13 then
					v_u_145.BackgroundTransparency = 0.6
				end
			end)
			v_u_145.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_145, (copy) v_u_148, (ref) v_u_13
				v_u_145.BackgroundTransparency = v_u_148.prompt == v_u_13 and 0.3 or 1
			end)
			v142[v143] = v_u_148
		end
		local v152 = v_u_9.new("Frame", {
			["Name"] = "PadHint",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 5,
			["Visible"] = false,
			["Size"] = UDim2.fromOffset(0, 26),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v141)
		v_u_9.pad(v152, {
			12,
			14,
			2,
			4
		})
		v_u_9.layout(v152, "h", 4)
		local v153 = v_u_9.badge("D-Pad", "muted", {
			["parent"] = nil,
			["height"] = 18,
			["order"] = 1,
			["parent"] = v152
		}):FindFirstChildWhichIsA("TextLabel")
		v_u_9.icon("chevronUp", {
			["parent"] = nil,
			["size"] = 18,
			["color"] = nil,
			["thickness"] = 2,
			["parent"] = v152,
			["color"] = v124.text2
		}).LayoutOrder = 2
		v_u_9.icon("chevronDown", {
			["parent"] = nil,
			["size"] = 18,
			["color"] = nil,
			["thickness"] = 2,
			["parent"] = v152,
			["color"] = v124.text2
		}).LayoutOrder = 3
		v_u_9.label({
			["parent"] = nil,
			["text"] = "Choose",
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 4,
			["parent"] = v152,
			["color"] = v124.muted,
			["size"] = UDim2.fromOffset(0, 18)
		})
		local v154 = v_u_10.touch(44)
		local v155 = v_u_9.new("TextButton", {
			["Name"] = "Next",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Selectable"] = false,
			["BackgroundColor3"] = v124.bg,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(0, -6, 1, 0),
			["Size"] = UDim2.fromOffset(v154, 60)
		}, v128)
		v_u_9.stroke(v155, v124.line)
		v_u_9.label({
			["parent"] = nil,
			["text"] = "Next",
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["align"] = "center",
			["parent"] = v155,
			["color"] = v124.text2,
			["position"] = UDim2.new(0, 0, 0, 10),
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		local v156 = v_u_9.label({
			["parent"] = nil,
			["text"] = "1/2",
			["style"] = "monoS",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["align"] = "center",
			["parent"] = v155,
			["color"] = v124.accent,
			["position"] = UDim2.new(0, 0, 0, 30),
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v156.TextXAlignment = Enum.TextXAlignment.Center
		v155.InputBegan:Connect(function(p157)
			-- upvalues: (ref) v_u_21, (ref) v_u_13, (ref) v_u_7, (ref) v_u_9
			if p157.UserInputType == Enum.UserInputType.Touch or p157.UserInputType == Enum.UserInputType.MouseButton1 then
				local v158 = #v_u_21
				if v158 >= 2 then
					local v159 = v_u_13 and table.find(v_u_21, v_u_13) or 1
					v_u_7.pick(v_u_21[v159 % v158 + 1])
					v_u_9.sound("tick")
				end
			else
				return
			end
		end)
		v_u_20 = {
			["next"] = v155,
			["nextCount"] = v156,
			["card"] = v128,
			["scale"] = v129,
			["accent"] = v130,
			["ring"] = v133,
			["chip"] = v134,
			["tapIcon"] = v135,
			["action"] = v137,
			["object"] = v138,
			["more"] = v139,
			["marker"] = v140,
			["fxGui"] = v127.Parent,
			["list"] = v141,
			["rows"] = v142,
			["padHint"] = v152,
			["padKey"] = v153
		}
		v128.InputBegan:Connect(function(p160)
			-- upvalues: (ref) v_u_7
			if p160.UserInputType == Enum.UserInputType.Touch or p160.UserInputType == Enum.UserInputType.MouseButton1 then
				v_u_7.trigger(true)
			end
		end)
		v128.InputEnded:Connect(function(p161)
			-- upvalues: (ref) v_u_7
			if p161.UserInputType == Enum.UserInputType.Touch or p161.UserInputType == Enum.UserInputType.MouseButton1 then
				v_u_7.trigger(false)
			end
		end)
	end
end
local function v_u_163() -- name: flash
	-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_10
	if v_u_20 then
		v_u_20.scale.Scale = 1.04
		v_u_9.tween(v_u_20.scale, {
			["Scale"] = 1
		}, "slow")
		v_u_20.card.BackgroundColor3 = v_u_10.color.accentDeep
		v_u_9.tween(v_u_20.card, {
			["BackgroundColor3"] = v_u_10.color.bg
		}, 0.35)
	end
end
local function v_u_169() -- name: holdBegin
	-- upvalues: (ref) v_u_13, (ref) v_u_17, (ref) v_u_49, (copy) v_u_163, (ref) v_u_9, (ref) v_u_14
	local v_u_164 = v_u_13
	if v_u_164 and v_u_17 then
		if v_u_49 and v_u_49.isPrompt(v_u_164) then
			local v165 = v_u_49.trigger
			local v166, v167 = pcall(v165)
			if v166 and v167 then
				v_u_163()
				v_u_9.sound("click")
			end
		else
			if v_u_14 and v_u_14 ~= v_u_164 then
				local function v168()
					-- upvalues: (ref) v_u_14
					v_u_14:InputHoldEnd()
				end
				pcall(v168)
			end
			v_u_14 = v_u_164
			pcall(function()
				-- upvalues: (copy) v_u_164
				v_u_164:InputHoldBegin()
			end)
		end
	else
		return
	end
end
function v_u_7.trigger(p170) -- name: trigger
	-- upvalues: (copy) v_u_169, (ref) v_u_14, (ref) v_u_18, (ref) v_u_13
	if p170 == true then
		v_u_169()
	elseif p170 == false then
		local v_u_171 = v_u_14
		v_u_14 = nil
		if v_u_171 then
			pcall(function()
				-- upvalues: (copy) v_u_171
				v_u_171:InputHoldEnd()
			end)
			return
		end
	else
		v_u_18 = v_u_18 + 1
		local v_u_172 = v_u_18
		local v173 = v_u_13
		v_u_169()
		local v174 = not v173 and 0 or v173.HoldDuration
		task.delay(v174 + 0.08, function()
			-- upvalues: (copy) v_u_172, (ref) v_u_18, (ref) v_u_14
			if v_u_172 == v_u_18 then
				local v_u_175 = v_u_14
				v_u_14 = nil
				if v_u_175 then
					pcall(function()
						-- upvalues: (copy) v_u_175
						v_u_175:InputHoldEnd()
					end)
				end
			end
		end)
	end
end
function v_u_7.active() -- name: active
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_7.pick(p176) -- name: pick
	-- upvalues: (ref) v_u_22, (copy) v_u_11, (ref) v_u_13, (ref) v_u_14, (ref) v_u_16
	if p176 then
		local v177 = v_u_11.Character
		if v177 then
			v177 = v177:FindFirstChild("HumanoidRootPart")
		end
		v_u_22 = {
			["p"] = p176,
			["at"] = not v177 and Vector3.new(0, 0, 0) or v177.Position
		}
		if v_u_13 ~= p176 then
			if v_u_14 and v_u_14 ~= p176 then
				local v_u_178 = v_u_14
				v_u_14 = nil
				if v_u_178 then
					pcall(function()
						-- upvalues: (copy) v_u_178
						v_u_178:InputHoldEnd()
					end)
				end
			end
			v_u_13 = p176
			v_u_16 = false
		end
	else
		v_u_22 = nil
	end
end
function v_u_7.choiceListVisible() -- name: choiceListVisible
	-- upvalues: (ref) v_u_20, (ref) v_u_17, (ref) v_u_46
	local v179 = v_u_20 ~= nil and v_u_17
	if v179 then
		if v_u_46 == nil then
			v179 = v_u_20.list.Visible == true
		else
			v179 = false
		end
	end
	return v179
end
function v_u_7.cycle(p180) -- name: cycle
	-- upvalues: (copy) v_u_21, (ref) v_u_17, (ref) v_u_13, (copy) v_u_7
	local v181 = #v_u_21
	if v181 < 2 or not v_u_17 then
		return nil
	end
	local v182 = v_u_21[((v_u_13 and table.find(v_u_21, v_u_13) or 1) - 1 + p180) % v181 + 1]
	v_u_7.pick(v182)
	return v182
end
function v_u_7.candidates() -- name: candidates
	-- upvalues: (copy) v_u_21
	return table.clone(v_u_21)
end
function v_u_7.setEnabled(p183) -- name: setEnabled
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_14, (ref) v_u_16, (copy) v_u_11
	local v184 = p183 ~= false
	if v184 ~= v_u_17 then
		v_u_17 = v184
		if not v184 then
			v_u_18 = v_u_18 + 1
			local v_u_185 = v_u_14
			v_u_14 = nil
			if v_u_185 then
				pcall(function()
					-- upvalues: (copy) v_u_185
					v_u_185:InputHoldEnd()
				end)
			end
			v_u_16 = false
		end
		v_u_11:SetAttribute("PromptsEnabled", v184)
	end
end
function v_u_7.isEnabled() -- name: isEnabled
	-- upvalues: (ref) v_u_17
	return v_u_17
end
local v_u_186 = RaycastParams.new()
v_u_186.FilterType = Enum.RaycastFilterType.Exclude
v_u_186.IgnoreWater = true
local v_u_187 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_190(p188) -- name: containerOf
	-- upvalues: (copy) v_u_6
	local v189 = p188.Parent
	for _ = 1, 4 do
		if not v189 or v189 == workspace then
			return nil
		end
		if v_u_6:HasTag(v189, "HushContainer") then
			return v189
		end
		v189 = v189.Parent
	end
	return nil
end
local v_u_191 = nil
local function v_u_208(p192, p193, p194) -- name: containerBlocked
	-- upvalues: (ref) v_u_191, (ref) v_u_8, (copy) v_u_3
	if not v_u_191 then
		local function v195()
			-- upvalues: (ref) v_u_8
			return v_u_8.shared.LootSight
		end
		local v196, v197 = pcall(v195)
		if not v196 or type(v197) ~= "table" then
			return nil
		end
		v_u_191 = v197
	end
	local v198 = { p194 }
	for _, v199 in { "HushLocal", "HushLoot" } do
		local v200 = workspace:FindFirstChild(v199)
		if not v200 then
			continue
		end
		table.insert(v198, v200)
	end
	local v201 = workspace:FindFirstChild("Raid")
	if v201 then
		v201 = v201:FindFirstChild("Items")
	end
	if v201 then
		table.insert(v198, v201)
	end
	for _, v202 in v_u_3:GetPlayers() do
		if not v202.Character or v202.Character == p194 then
			continue
		end
		local v203 = v202.Character
		table.insert(v198, v203)
	end
	local v204 = v_u_191.clear
	local v205 = v_u_191.eye(p193)
	local v206, v207 = pcall(v204, v205, p192, v198)
	if v206 then
		return not v207
	else
		return nil
	end
end
local function v_u_226(p209, p210, p211, p212) -- name: blocked
	-- upvalues: (copy) v_u_187, (copy) v_u_190, (copy) v_u_208, (copy) v_u_6, (copy) v_u_186
	local v213 = os.clock()
	local v214 = v_u_187[p209]
	if v214 and v213 - v214.t < 0.15 then
		return v214.blocked
	end
	local v215 = v_u_190(p209)
	if v215 then
		local v216 = v_u_208(v215, p210, p212)
		if v216 ~= nil then
			v_u_187[p209] = {
				["t"] = v213,
				["blocked"] = v216
			}
			return v216
		end
	end
	local v217 = { p212 }
	local v218 = p209:FindFirstAncestorOfClass("Model")
	if not v218 or (v218 == workspace or v_u_6:HasTag(v218, "HushBuilding")) then
		v218 = p209.Parent
		if v218 and v218:IsA("Attachment") then
			v218 = v218.Parent
		end
	end
	if v218 then
		table.insert(v217, v218)
	end
	local v219 = workspace:FindFirstChild("HushLocal")
	if v219 then
		table.insert(v217, v219)
	end
	v_u_186.FilterDescendantsInstances = v217
	local v220 = p210 + Vector3.new(0, 1.2, 0)
	local v221 = p211 - v220
	local v222 = false
	if v221.Magnitude > 0.5 then
		local v223 = workspace:Raycast(v220, v221.Unit * (v221.Magnitude - 0.4), v_u_186)
		local v224
		if v223 then
			v224 = v223.Instance
		else
			v224 = v223
		end
		if v223 and (v224 and (v224.CanCollide and v224.Transparency < 0.95)) then
			local v225 = v224:FindFirstAncestorOfClass("Model")
			v222 = (v_u_6:HasTag(v224, "HushWall") or (v_u_6:HasTag(v224, "HushWindow") or v225 and (v_u_6:HasTag(v225, "HushDoor") and v225:GetAttribute("State") == "Closed"))) and true or (v224.Size.Y >= 5 and (v223.Position - p211).Magnitude > 2.5 and true or v222)
		end
	end
	v_u_187[p209] = {
		["t"] = v213,
		["blocked"] = v222
	}
	return v222
end
local v_u_227 = {}
local v_u_228 = 0
function v_u_7.paidBoatHidden(p229) -- name: paidBoatHidden
	-- upvalues: (ref) v_u_228, (copy) v_u_11
	local v230 = p229.ActionText
	local v231
	if string.sub(v230, 1, 3) == "Pay" then
		local v232 = p229.Parent
		if v232 then
			v232 = v232.Parent
		end
		if v232 == nil then
			v231 = false
		else
			v231 = v232:GetAttribute("ExtractId") == "smuggler_boat"
		end
	else
		v231 = false
	end
	if not v231 then
		return false
	end
	if os.clock() < v_u_228 then
		return true
	end
	local v233 = v_u_11:GetAttribute("PaidBoatRaid")
	local v234
	if v233 == nil then
		v234 = false
	else
		v234 = v233 == v_u_11:GetAttribute("RaidId")
	end
	return v234
end
local function v_u_238(p235) -- name: handsOnHold
	-- upvalues: (copy) v_u_11
	if p235:GetAttribute("Kind") == "handsOn" then
		local v236 = v_u_11:GetAttribute("HandsOnHoldTime")
		if type(v236) == "number" and (v236 == v236 and (v236 >= 0.5 and v236 <= 15)) then
			local v237 = p235.HoldDuration - v236
			if math.abs(v237) > 0.01 then
				p235.HoldDuration = v236
			end
		end
	end
end
local function v_u_244(p_u_239) -- name: vehPredict
	-- upvalues: (ref) v_u_50, (ref) v_u_8
	local v240 = p_u_239
	while p_u_239 ~= nil and p_u_239:GetAttribute("VehType") == nil do
		p_u_239 = p_u_239.Parent
	end
	if p_u_239 == nil then
		return
	else
		local v_u_241, v_u_242 = v_u_50.predictArgs(v240.Name, p_u_239:GetAttribute("BoardAnim"))
		if v_u_241 ~= nil and v_u_242 ~= nil then
			local function v243()
				-- upvalues: (ref) v_u_8, (copy) p_u_239, (copy) v_u_241, (copy) v_u_242
				v_u_8.lib.VehAnimPlay.predict(p_u_239, v_u_241, v_u_242)
			end
			pcall(v243)
		end
	end
end
local function v_u_298() -- name: choose
	-- upvalues: (copy) v_u_21, (copy) v_u_11, (ref) v_u_50, (ref) v_u_8, (ref) v_u_9, (copy) v_u_227, (ref) v_u_49, (copy) v_u_12, (copy) v_u_71, (ref) v_u_47, (ref) v_u_228, (copy) v_u_190, (copy) v_u_74, (copy) v_u_226, (ref) v_u_22
	table.clear(v_u_21)
	local v245 = v_u_11.Character
	local v246
	if v245 then
		v246 = v245:FindFirstChild("HumanoidRootPart")
	else
		v246 = v245
	end
	if v245 and (v245:GetAttribute("Downed") == true or v245:GetAttribute("Dead") == true) then
		return nil
	end
	if v245 and (v_u_50 and v_u_50.busy(v245:GetAttribute("RideVehicle"), v245:GetAttribute("Action"))) then
		return nil
	end
	local v247
	if v246 then
		v247 = v246.Position
	else
		v247 = nil
	end
	local v248 = nil
	local v249 = nil
	local v250 = v_u_8.controllers.Input
	local v251
	if v250 and v250.aimDir then
		local v252 = v250.aimDir
		local v253
		v253, v251 = pcall(v252)
		if v253 then
			if typeof(v251) ~= "Vector3" then
				v251 = v248
			end
		else
			v251 = v248
		end
	else
		v251 = v248
	end
	local v254
	if v250 and (v250.aimPoint and v_u_9.device() == "Keyboard") then
		local v255 = v250.aimPoint
		local v256
		v256, v254 = pcall(v255)
		if v256 then
			if typeof(v254) ~= "Vector3" then
				v254 = v249
			end
		else
			v254 = v249
		end
	else
		v254 = v249
	end
	table.clear(v_u_227)
	if v_u_49 then
		local v257 = v_u_49.prompt
		local v258, v259 = pcall(v257)
		if not v258 then
			v259 = nil
		end
		for v260 in v_u_12 do
			if not v_u_49.isPrompt(v260) or v260 == v259 then
				continue
			end
			v_u_12[v260] = nil
		end
		if v259 then
			v_u_71(v259)
			v_u_12[v259] = true
		end
	end
	for v261 in v_u_12 do
		if not v261.Parent or (not v261.Enabled or (v261:GetAttribute("OwnerUserId") == v_u_11.UserId or v245 and v261:IsDescendantOf(v245))) or v_u_47 and v_u_47.hidden(v261) then
			continue
		end
		local v262 = v261.ActionText
		local v263
		if string.sub(v262, 1, 3) == "Pay" then
			local v264 = v261.Parent
			if v264 then
				v264 = v264.Parent
			end
			if v264 == nil then
				v263 = false
			else
				v263 = v264:GetAttribute("ExtractId") == "smuggler_boat"
			end
		else
			v263 = false
		end
		local v265
		if v263 then
			if os.clock() < v_u_228 then
				v265 = true
			else
				local v266 = v_u_11:GetAttribute("PaidBoatRaid")
				if v266 == nil then
					v265 = false
				else
					v265 = v266 == v_u_11:GetAttribute("RaidId")
				end
			end
		else
			v265 = false
		end
		if v265 then
			continue
		end
		local v267
		if v261:GetAttribute("Kind") == "doorListen" then
			local v268 = v_u_11:GetAttribute("Perk_doorListen")
			local v269
			if v268 == true then
				v269 = true
			elseif type(v268) == "number" then
				v269 = v268 > 0
			else
				v269 = false
			end
			v267 = not v269
		else
			v267 = false
		end
		if v267 then
			continue
		end
		local v270
		if v261:GetAttribute("Kind") == "handsOn" then
			local v271 = v_u_11:GetAttribute("HandsOnFor")
			v270 = (type(v271) ~= "number" or v271 == 0) and true or v271 ~= v261:GetAttribute("OwnerUserId")
		else
			v270 = false
		end
		if v270 then
			continue
		end
		local v272 = v_u_190(v261)
		if v272 and (v272:GetAttribute("Cargo") == true and tonumber(v272:GetAttribute("CargoOwner")) ~= v_u_11.UserId) then
			continue
		end
		local v273 = v261:GetAttribute("Priority")
		local v274 = type(v273) ~= "number" and 0 or v273
		local v275 = v274 < 20 and 0 or v274
		local v276 = v274 >= 20 and 0 or v274
		local v277 = 0
		local v278 = v_u_74(v261)
		if v247 and (v278 and (v245 and v_u_226(v261, v247, v278, v245))) then
			continue
		end
		local v279
		if v261:GetAttribute("Wearable") == nil then
			v279 = false
		else
			local v280 = v261.ActionText
			v279 = string.sub(v280, 1, 4) == "Swap"
		end
		if v247 and v278 then
			local v281 = v278 - v247
			local v282 = v281.X
			local v283 = v281.Z
			local v284 = Vector3.new(v282, 0, v283)
			local v285 = v284.Magnitude
			local v286
			if v251 and v285 > 0.1 then
				v286 = v284.Unit:Dot(v251)
				v277 = v285 - v286 * 2.5
				if v286 < -0.2 and v285 > 2 then
					v277 = v277 + 2
				end
			else
				v277 = v285
				v286 = 1
			end
			if v254 then
				local v287 = v254.X - v278.X
				local v288 = v254.Z - v278.Z
				local v289 = Vector3.new(v287, 0, v288).Magnitude
				if v289 < 3 then
					v277 = v277 - (3 - v289) * 1.2
				end
			end
			if v279 then
				if v286 < 0.55 or v285 > 6 then
					continue
				end
				v277 = v277 + 1.5
				v276 = 0
			end
		end
		local v290 = v277 - v276 * 0.45
		local v291 = v_u_190(v261)
		if v291 and v291:GetAttribute("Looted") == true then
			v290 = v290 + 1.5
		end
		local v292 = v_u_227
		table.insert(v292, {
			["p"] = v261,
			["tier"] = v275,
			["score"] = v290
		})
	end
	table.sort(v_u_227, function(p293, p294)
		if p293.tier == p294.tier then
			return p293.score < p294.score
		else
			return p293.tier > p294.tier
		end
	end)
	for v295, v296 in v_u_227 do
		v_u_21[v295] = v296.p
	end
	local v297 = v_u_22
	if v297 then
		if (v247 == nil and true or (v247 - v297.at).Magnitude <= 4) and table.find(v_u_21, v297.p) then
			return v297.p
		end
		v_u_22 = nil
	end
	return v_u_21[1]
end
local function v_u_331(p299) -- name: renderList
	-- upvalues: (ref) v_u_20, (copy) v_u_35, (copy) v_u_45, (copy) v_u_21, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (copy) v_u_122
	if v_u_20 then
		local v300 = v_u_35()
		local v301
		if p299 and not v_u_45() then
			local v302 = #v_u_21
			v301 = math.min(v302, v300)
		else
			v301 = 0
		end
		local v303 = v_u_9.device() == "Touch"
		local v304
		if p299 then
			v304 = table.find(v_u_21, p299)
		else
			v304 = nil
		end
		local v305 = v_u_20.next
		local v306
		if v303 then
			if p299 == nil then
				v306 = false
			else
				v306 = v300 < #v_u_21
			end
		else
			v306 = v303
		end
		v305.Visible = v306
		if v_u_20.next.Visible then
			local v307 = string.format("%d/%d", v304 or 1, #v_u_21)
			if v_u_20.nextCount.Text ~= v307 then
				v_u_20.nextCount.Text = v307
			end
		end
		v_u_20.list.Visible = v301 >= 2
		if v301 < 2 then
			for _, v308 in v_u_20.rows do
				v308.prompt = nil
			end
		else
			local v309 = (not v304 or v301 >= v304) and 1 or v304 - v301 + 1
			local v310 = v_u_9.device() == "Gamepad"
			v_u_20.padHint.Visible = not v303
			if not v303 and v_u_20.padKey then
				local v_u_311 = v_u_8.controllers.Input
				local v312
				if v310 then
					local v314, v315 = pcall(function()
						-- upvalues: (copy) v_u_311
						local v313 = v_u_311
						if v313 then
							v313 = v_u_311.hint("promptUp")
						end
						return v313
					end)
					v312 = (not v314 or (type(v315) ~= "string" or v315 == "")) and "D-Pad" or string.gsub(v315, "%s*Up$", "")
				else
					local v317, v318 = pcall(function()
						-- upvalues: (copy) v_u_311
						local v316 = v_u_311
						if v316 then
							v316 = v_u_311.hint("promptDown")
						end
						return v316
					end)
					v312 = "Wheel" .. ((not v317 or (type(v318) ~= "string" or v318 == "")) and "" or " / " .. v318)
				end
				if v_u_20.padKey.Text ~= v312 then
					v_u_9.setText(v_u_20.padKey, v312)
				end
			end
			local v319 = v_u_20.card
			local v320 = v319.AnchorPoint
			v_u_20.list.AnchorPoint = Vector2.new(v320.X, 1)
			v_u_20.list.Position = v319.Position - UDim2.fromOffset(0, 66)
			for v321, v322 in v_u_20.rows do
				local v323 = v_u_21[v309 + v321 - 1]
				if v321 <= v301 and v323 then
					v322.row.Visible = true
					v322.prompt = v323
					local v324 = v323 == p299
					v322.bar.Visible = v324
					local v325 = v322.row
					local v326
					if v324 then
						v326 = v_u_10.color.accentDeep
					else
						v326 = v_u_10.color.bg
					end
					v325.BackgroundColor3 = v326
					v322.row.BackgroundTransparency = v324 and 0.3 or 1
					local v327, v328 = v_u_122(v323)
					if v322.act.Text ~= v327 then
						v322.act.Text = v327
					end
					local v329 = v322.act
					local v330
					if v324 then
						v330 = v_u_10.color.accent
					else
						v330 = v_u_10.color.text
					end
					v329.TextColor3 = v330
					if v322.obj.Text == v328 then
						continue
					end
					v322.obj.Text = v328
				else
					v322.row.Visible = false
					v322.prompt = nil
				end
			end
		end
	else
		return
	end
end
local v_u_332 = {
	{ "Search", "Medicine cabinet in the kitchen" },
	{ "Open", "Kitchen door  \194\183  Locked" },
	{ "Pick up", "Bandage" },
	{ "Take", "Jerrycan" }
}
local function v_u_346(p333) -- name: renderFakeList
	-- upvalues: (ref) v_u_20, (copy) v_u_45, (copy) v_u_35, (ref) v_u_9, (copy) v_u_332, (ref) v_u_10
	if v_u_20 then
		local v334
		if v_u_45() then
			v334 = 0
		else
			local v335 = math.floor(p333)
			local v336 = v_u_35()
			v334 = math.min(v335, v336)
		end
		v_u_20.list.Visible = v334 >= 2
		if v334 >= 2 then
			local v337 = v_u_9.device() == "Touch"
			v_u_20.padHint.Visible = not v337
			local v338 = v_u_20.card
			v_u_20.list.AnchorPoint = Vector2.new(v338.AnchorPoint.X, 1)
			v_u_20.list.Position = v338.Position - UDim2.fromOffset(0, 66)
			for v339, v340 in v_u_20.rows do
				local v341 = v_u_332[v339]
				if v339 <= v334 and v341 then
					v340.row.Visible = true
					v340.prompt = nil
					v340.bar.Visible = v339 == 1
					local v342 = v340.row
					local v343
					if v339 == 1 then
						v343 = v_u_10.color.accentDeep
					else
						v343 = v_u_10.color.bg
					end
					v342.BackgroundColor3 = v343
					v340.row.BackgroundTransparency = v339 == 1 and 0.3 or 1
					v340.act.Text = v341[1]
					local v344 = v340.act
					local v345
					if v339 == 1 then
						v345 = v_u_10.color.accent
					else
						v345 = v_u_10.color.text
					end
					v344.TextColor3 = v345
					v340.obj.Text = v341[2]
				else
					v340.row.Visible = false
				end
			end
		end
	else
		return
	end
end
local v_u_347 = nil
local v_u_348 = false
local v_u_349 = -1
local function v_u_357() -- name: publishTop
	-- upvalues: (ref) v_u_20, (ref) v_u_348, (ref) v_u_10, (ref) v_u_349, (copy) v_u_11
	local v350
	if v_u_20 and v_u_348 then
		local v351 = -v_u_20.card.Position.Y.Offset
		v350 = v351 + 60
		if v_u_20.list.Visible then
			local v352 = v351 + 66
			local v353 = v_u_20.list.AbsoluteSize.Y
			local v354 = v_u_10.uiScale
			v350 = v352 + v353 / math.max(0.01, v354())
		end
	else
		v350 = 0
	end
	local v355 = v350 + 0.5
	local v356 = math.floor(v355)
	if v356 ~= v_u_349 then
		v_u_349 = v356
		v_u_11:SetAttribute("PromptTopY", v356)
	end
end
local function v_u_361(p358) -- name: showCard
	-- upvalues: (ref) v_u_20, (ref) v_u_348, (copy) v_u_60, (ref) v_u_9
	if v_u_20 and v_u_348 ~= p358 then
		v_u_348 = p358
		if p358 then
			v_u_20.card.Visible = true
			local v359, _, v360 = v_u_60()
			v_u_20.card.AnchorPoint = v360
			v_u_20.card.Position = v359 + UDim2.fromOffset(0, 8)
			v_u_9.tween(v_u_20.card, {
				["Position"] = v359
			}, "slow")
			v_u_20.card.BackgroundTransparency = 0.5
			v_u_9.tween(v_u_20.card, {
				["BackgroundTransparency"] = 0.12
			}, "slow")
		else
			v_u_20.card.Visible = false
			v_u_20.marker.Visible = false
			v_u_20.list.Visible = false
		end
	else
		return
	end
end
local function v_u_373(p362) -- name: applyDevice
	-- upvalues: (ref) v_u_20, (copy) v_u_60, (ref) v_u_10
	if v_u_20 then
		v_u_20.tapIcon.Visible = p362 == "Touch"
		v_u_20.chip:SetAttribute("ForceHidden", p362 == "Touch")
		v_u_20.chip.Visible = p362 ~= "Touch"
		local v363, v364, v365 = v_u_60()
		v_u_20.card.AnchorPoint = v365
		v_u_20.card.Position = v363
		local v366 = v_u_10.touch(30)
		for _, v367 in v_u_20.rows do
			v367.row.Size = UDim2.fromOffset(0, v366)
			local v368 = v367.row:FindFirstChild("Inner")
			if v368 then
				v368.Size = UDim2.fromOffset(0, v366)
			end
			v367.act.Size = UDim2.fromOffset(0, v366)
			v367.obj.Size = UDim2.fromOffset(0, v366)
			if p362 ~= "Touch" or not v_u_10.isPhone() then
				continue
			end
			local v369 = v367.act:FindFirstChildOfClass("UISizeConstraint")
			if v369 then
				v369.MaxSize = Vector2.new(90, v369.MaxSize.Y)
			end
			local v370 = v367.obj:FindFirstChildOfClass("UISizeConstraint")
			if not v370 then
				continue
			end
			v370.MaxSize = Vector2.new(v364, v370.MaxSize.Y)
		end
		v_u_20.next.Size = UDim2.fromOffset(v_u_10.touch(44), 60)
		for _, v371 in { v_u_20.action, v_u_20.object } do
			local v372 = v371:FindFirstChildOfClass("UISizeConstraint")
			if not v372 then
				continue
			end
			v372.MaxSize = Vector2.new(v364, v372.MaxSize.Y)
		end
	end
end
local function v_u_375() -- name: rebuild
	-- upvalues: (ref) v_u_348, (ref) v_u_19, (ref) v_u_20, (copy) v_u_162, (copy) v_u_373, (ref) v_u_9
	local v374 = v_u_348
	if v_u_19 then
		v_u_19:Destroy()
	end
	if v_u_20 and v_u_20.fxGui then
		v_u_20.fxGui:Destroy()
	end
	v_u_19 = nil
	v_u_20 = nil
	v_u_348 = false
	v_u_162()
	v_u_373(v_u_9.device())
	if v_u_20 and v374 then
		v_u_348 = true
		v_u_20.card.Visible = true
	end
end
function v_u_7.init(p_u_376) -- name: init
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_7, (ref) v_u_47, (ref) v_u_48, (ref) v_u_50, (ref) v_u_49, (copy) v_u_12, (ref) v_u_13, (copy) v_u_21, (ref) v_u_14, (ref) v_u_17, (ref) v_u_22, (ref) v_u_20, (ref) v_u_46, (ref) v_u_228, (copy) v_u_11, (copy) v_u_122, (copy) v_u_74, (copy) v_u_187, (copy) v_u_226
	v_u_8 = p_u_376
	v_u_9 = p_u_376.lib.HushUI
	v_u_9.bind(p_u_376)
	v_u_10 = p_u_376.shared.Theme
	v_u_7.changed = p_u_376.shared.Signal.new()
	local v377, v378 = pcall(function()
		-- upvalues: (copy) p_u_376
		return p_u_376.lib.DoorClient
	end)
	if v377 and type(v378) == "table" then
		local v379 = v378.init
		local v380, v381 = pcall(v379, p_u_376)
		if v380 then
			v_u_47 = v378
		else
			p_u_376.log("Prompts", "DoorClient.init failed", v381)
		end
	end
	local function v382()
		-- upvalues: (ref) v_u_48, (copy) p_u_376
		v_u_48 = p_u_376.lib.PromptPredict
	end
	pcall(v382)
	local function v383()
		-- upvalues: (ref) v_u_50, (copy) p_u_376
		v_u_50 = p_u_376.lib.PromptRide
	end
	pcall(v383)
	local v384, v385 = pcall(function()
		-- upvalues: (copy) p_u_376
		return p_u_376.lib.FenceVault
	end)
	if v384 and type(v385) == "table" then
		local v386 = v385.init
		local v387, v388 = pcall(v386, p_u_376)
		if v387 then
			v_u_49 = v385
		else
			p_u_376.log("Prompts", "FenceVault.init failed", v388)
		end
	end
	p_u_376.command("prompts.predict", function()
		-- upvalues: (ref) v_u_48
		return not v_u_48 and "no PromptPredict" or v_u_48.state()
	end)
	p_u_376.command("prompts.state", function()
		-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_21, (ref) v_u_14, (ref) v_u_17, (ref) v_u_22, (ref) v_u_7, (ref) v_u_20
		local v389 = 0
		for _ in v_u_12 do
			v389 = v389 + 1
		end
		local v390
		if v_u_13 then
			local v391 = v_u_13
			local v392 = string.format
			local v393 = v391.KeyboardKeyCode.Name
			local v394 = v391.GamepadKeyCode.Name
			local v395 = v391.RequiresLineOfSight
			v390 = v392(" keys=%s/%s los=%s", v393, v394, (tostring(v395)))
		else
			v390 = ""
		end
		local v396 = {}
		for v397, v398 in v_u_21 do
			v396[v397] = v398.ActionText .. "/" .. v398.ObjectText
		end
		local v399
		if v_u_13 then
			v399 = table.find(v_u_21, v_u_13)
		else
			v399 = nil
		end
		local v400 = string.format
		local v401 = "shown=%d active=%s held=%s enabled=%s%s cand=[%s] pinned=%s list=%s idx=%s padHint=%s"
		local v402 = not v_u_13 and "nil" or v_u_13:GetFullName()
		local v403 = v_u_14 ~= nil
		local v404 = tostring(v403)
		local v405 = v_u_17
		local v406 = tostring(v405)
		local v407 = table.concat(v396, "; ")
		local v408 = v_u_22 ~= nil
		local v409 = tostring(v408)
		local v410 = v_u_7.choiceListVisible
		local v411 = tostring(v410())
		local v412 = tostring(v399)
		local v413
		if v_u_20 == nil then
			v413 = false
		else
			v413 = v_u_20.padHint.Visible
		end
		return v400(v401, v389, v402, v404, v406, v390, v407, v409, v411, v412, (tostring(v413)))
	end)
	p_u_376.command("prompts.tap", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_7
		local v414 = v_u_13
		v_u_7.trigger()
		return "tap " .. (not v414 and "none" or v414.ActionText .. "/" .. v414.ObjectText)
	end)
	p_u_376.command("prompts.fake", function(p415)
		-- upvalues: (ref) v_u_46
		local v416 = table.concat(p415, " ")
		if v416 == "" or v416 == "off" then
			v_u_46 = nil
			return "fake off"
		end
		local v417 = string.split(v416, "|")
		local v418 = {
			["action"] = v417[1] or "Search",
			["object"] = v417[2] or ""
		}
		local v419 = v417[3] or ""
		v418.ring = tonumber(v419) or 0
		local v420 = v417[4] or ""
		v418.rows = tonumber(v420) or 0
		v_u_46 = v418
		return "fake " .. v_u_46.action
	end)
	p_u_376.command("prompts.boat", function()
		-- upvalues: (ref) v_u_228, (ref) v_u_11
		local v421 = {}
		for _, v422 in workspace:GetDescendants() do
			if not v422:IsA("ProximityPrompt") then
				continue
			end
			local v423 = v422.ActionText
			if string.sub(v423, 1, 3) ~= "Pay" then
				continue
			end
			local v424 = v422.Parent
			if v424 then
				v424 = v422.Parent.Parent
			end
			if not v424 or v424:GetAttribute("ExtractId") ~= "smuggler_boat" then
				continue
			end
			local v425 = string.format
			local v426 = "%s enabled=%s hidden=%s"
			local v427 = v422.ActionText
			local v428 = v422.Enabled
			local v429 = tostring(v428)
			local v430 = v422.ActionText
			local v431
			if string.sub(v430, 1, 3) == "Pay" then
				local v432 = v422.Parent
				if v432 then
					v432 = v432.Parent
				end
				if v432 == nil then
					v431 = false
				else
					v431 = v432:GetAttribute("ExtractId") == "smuggler_boat"
				end
			else
				v431 = false
			end
			local v433
			if v431 then
				if os.clock() < v_u_228 then
					v433 = true
				else
					local v434 = v_u_11:GetAttribute("PaidBoatRaid")
					if v434 == nil then
						v433 = false
					else
						v433 = v434 == v_u_11:GetAttribute("RaidId")
					end
				end
			else
				v433 = false
			end
			local v435 = tostring(v433)
			table.insert(v421, v425(v426, v427, v429, v435))
		end
		local v436 = v_u_11
		local v437 = v_u_11
		return string.format("raid=%s paid=%s prompts=%d %s", tostring(v436:GetAttribute("RaidId")), tostring(v437:GetAttribute("PaidBoatRaid")), #v421, table.concat(v421, " | "))
	end)
	p_u_376.command("prompts.lock", function(p438)
		-- upvalues: (ref) v_u_11, (ref) v_u_122
		local v439 = v_u_11.Character
		if v439 then
			v439 = v439:FindFirstChild("HumanoidRootPart")
		end
		local v440 = p438[1]
		local v441 = tonumber(v440) or 400
		local v442 = {}
		for _, v443 in workspace:GetDescendants() do
			if not v443:IsA("ProximityPrompt") or (v443.Name ~= "HushPrompt" or v443.ActionText ~= "Unlock") then
				continue
			end
			local v444
			if v443.Parent and v443.Parent:IsA("BasePart") then
				v444 = v443.Parent.Position or nil
			else
				v444 = nil
			end
			if v439 and (v444 and (v444 - v439.Position).Magnitude > v441) then
				continue
			end
			local v445, v446 = v_u_122(v443)
			local v447 = v445 .. " | " .. v446
			table.insert(v442, v447)
		end
		local v448 = v_u_11
		return string.format("LockKeys=%s n=%d %s", tostring(v448:GetAttribute("LockKeys")), #v442, table.concat(v442, " || "))
	end)
	p_u_376.command("prompts.los", function(p449)
		-- upvalues: (ref) v_u_11, (ref) v_u_74, (ref) v_u_187, (ref) v_u_226, (ref) v_u_12
		local v450 = v_u_11.Character
		local v451
		if v450 then
			v451 = v450:FindFirstChild("HumanoidRootPart")
		else
			v451 = v450
		end
		if not (v450 and v451) then
			return "no character"
		end
		local v452 = p449[1]
		local v453 = tonumber(v452) or 12
		local v454 = {}
		for _, v455 in workspace:GetDescendants() do
			if not v455:IsA("ProximityPrompt") then
				continue
			end
			local v456 = v_u_74(v455)
			if not v456 or (v456 - v451.Position).Magnitude > v453 then
				continue
			end
			v_u_187[v455] = nil
			local v457 = string.format
			local v458 = v455.Parent and (v455.Parent.Name or "?") or "?"
			local v459 = (v456 - v451.Position).Magnitude
			local v460 = v455.MaxActivationDistance
			local v461 = v_u_226(v455, v451.Position, v456, v450)
			local v462 = tostring(v461)
			local v463 = v_u_12[v455] == true
			local v464 = tostring(v463)
			table.insert(v454, v457("%s d=%.1f max=%.1f blocked=%s shown=%s", v458, v459, v460, v462, v464))
		end
		return #v454 .. " near: " .. table.concat(v454, " | ")
	end)
end
function v_u_7.start() -- name: start
	-- upvalues: (copy) v_u_162, (ref) v_u_49, (ref) v_u_8, (ref) v_u_47, (copy) v_u_5, (copy) v_u_7, (ref) v_u_51, (copy) v_u_71, (copy) v_u_4, (copy) v_u_238, (copy) v_u_12, (copy) v_u_11, (ref) v_u_22, (ref) v_u_14, (ref) v_u_13, (ref) v_u_16, (ref) v_u_15, (copy) v_u_163, (ref) v_u_9, (ref) v_u_228, (ref) v_u_50, (copy) v_u_244, (ref) v_u_48, (copy) v_u_97, (copy) v_u_169, (copy) v_u_373, (copy) v_u_375, (ref) v_u_20
	v_u_162()
	if v_u_49 then
		local v465 = v_u_49.start
		local v466, v467 = pcall(v465)
		if not v466 then
			v_u_8.log("Prompts", "FenceVault.start failed", v467)
		end
	end
	local function v468()
		-- upvalues: (ref) v_u_8
		v_u_8.lib.PaidHide.start(v_u_8)
	end
	pcall(v468)
	if v_u_47 then
		local v469 = v_u_47.start
		local v470, v471 = pcall(v469)
		if not v470 then
			v_u_8.log("Prompts", "DoorClient.start failed", v471)
		end
	end
	v_u_5.InputChanged:Connect(function(p472)
		-- upvalues: (ref) v_u_7, (ref) v_u_51
		if p472.UserInputType == Enum.UserInputType.MouseWheel and v_u_7.choiceListVisible() then
			local v473 = os.clock()
			if v473 - v_u_51 < 0.12 then
				return
			else
				v_u_51 = v473
				if p472.Position.Z > 0 then
					v_u_7.cycle(-1)
				elseif p472.Position.Z < 0 then
					v_u_7.cycle(1)
				end
			end
		else
			return
		end
	end)
	workspace.DescendantAdded:Connect(function(p474)
		-- upvalues: (ref) v_u_71
		if p474:IsA("ProximityPrompt") then
			v_u_71(p474)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71
		for v475, v476 in workspace:GetDescendants() do
			if v476:IsA("ProximityPrompt") then
				v_u_71(v476)
			end
			if v475 % 4000 ~= 0 then
				continue
			end
			task.wait()
		end
	end)
	v_u_4.PromptShown:Connect(function(p477)
		-- upvalues: (ref) v_u_71, (ref) v_u_238, (ref) v_u_12
		v_u_71(p477)
		local v478 = v_u_238
		pcall(v478, p477)
		v_u_12[p477] = true
	end)
	v_u_11:GetAttributeChangedSignal("HandsOnHoldTime"):Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_238
		for v479 in v_u_12 do
			if not v479.Parent then
				continue
			end
			local v480 = v_u_238
			pcall(v480, v479)
		end
	end)
	v_u_4.PromptHidden:Connect(function(p481)
		-- upvalues: (ref) v_u_12, (ref) v_u_22, (ref) v_u_14
		v_u_12[p481] = nil
		if v_u_22 and v_u_22.p == p481 then
			v_u_22 = nil
		end
		if v_u_14 == p481 then
			local v_u_482 = v_u_14
			v_u_14 = nil
			if v_u_482 then
				pcall(function()
					-- upvalues: (copy) v_u_482
					v_u_482:InputHoldEnd()
				end)
			end
		end
	end)
	v_u_4.PromptButtonHoldBegan:Connect(function(p483, p484)
		-- upvalues: (ref) v_u_13, (ref) v_u_16, (ref) v_u_15, (ref) v_u_47, (ref) v_u_11
		if p483 == v_u_13 then
			v_u_16 = true
			v_u_15 = os.clock()
		end
		if v_u_47 and (p484 == nil or p484 == v_u_11) then
			local v485 = v_u_47.onHoldBegan
			pcall(v485, p483)
		end
		if (p484 == nil or p484 == v_u_11) and p483:GetAttribute("Kind") == "handsOn" then
			v_u_11:SetAttribute("PredAction", "Revive")
			v_u_11:SetAttribute("PredActionEnds", os.clock() + p483.HoldDuration + 0.2)
		end
	end)
	v_u_4.PromptButtonHoldEnded:Connect(function(p486, p487)
		-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_16, (ref) v_u_47, (ref) v_u_11
		if p486 == v_u_13 or p486 == v_u_14 then
			v_u_16 = false
		end
		if v_u_47 and (p487 == nil or p487 == v_u_11) then
			local v488 = v_u_47.onHoldEnded
			pcall(v488, p486)
		end
		if (p487 == nil or p487 == v_u_11) and (p486:GetAttribute("Kind") == "handsOn" and v_u_11:GetAttribute("PredAction") == "Revive") then
			v_u_11:SetAttribute("PredAction", nil)
			v_u_11:SetAttribute("PredActionEnds", nil)
		end
	end)
	v_u_4.PromptTriggered:Connect(function(p489, p490)
		-- upvalues: (ref) v_u_13, (ref) v_u_16, (ref) v_u_163, (ref) v_u_9, (ref) v_u_11, (ref) v_u_228, (ref) v_u_47, (ref) v_u_50, (ref) v_u_244, (ref) v_u_48, (ref) v_u_97, (ref) v_u_8
		if p489 == v_u_13 then
			v_u_16 = false
			v_u_163()
			v_u_9.sound("click")
		end
		if p490 == nil or p490 == v_u_11 then
			local v491 = p489.ActionText
			local v492
			if string.sub(v491, 1, 3) == "Pay" then
				local v493 = p489.Parent
				if v493 then
					v493 = v493.Parent
				end
				if v493 == nil then
					v492 = false
				else
					v492 = v493:GetAttribute("ExtractId") == "smuggler_boat"
				end
			else
				v492 = false
			end
			if v492 then
				v_u_228 = os.clock() + 4
			end
		end
		if v_u_47 and (p490 == nil or p490 == v_u_11) then
			local v494 = v_u_47.onTriggered
			pcall(v494, p489)
		end
		if v_u_50 and (p490 == nil or p490 == v_u_11) and p489:GetAttribute("Kind") == "Vehicle" then
			v_u_244(p489)
		end
		if v_u_48 and (p490 == nil or p490 == v_u_11) and not select(2, v_u_97(p489)) then
			local v495 = v_u_48.onTriggered
			local v496 = v_u_8
			pcall(v495, p489, v496)
		end
	end)
	local v497 = v_u_8.controllers.Input
	if v497 and v497.bind then
		v497.bind("interact", function()
			-- upvalues: (ref) v_u_169
			v_u_169()
		end, function()
			-- upvalues: (ref) v_u_14
			local v_u_498 = v_u_14
			v_u_14 = nil
			if v_u_498 then
				pcall(function()
					-- upvalues: (copy) v_u_498
					v_u_498:InputHoldEnd()
				end)
			end
		end)
		v497.bind("promptUp", function()
			-- upvalues: (ref) v_u_7
			if v_u_7.choiceListVisible() then
				v_u_7.cycle(-1)
			end
		end)
		v497.bind("promptDown", function()
			-- upvalues: (ref) v_u_7
			if v_u_7.choiceListVisible() then
				v_u_7.cycle(1)
			end
		end)
	else
		v_u_5.InputBegan:Connect(function(p499, p500)
			-- upvalues: (ref) v_u_169
			if not p500 then
				if p499.KeyCode == Enum.KeyCode.F or p499.KeyCode == Enum.KeyCode.ButtonA then
					v_u_169()
				end
			end
		end)
		v_u_5.InputEnded:Connect(function(p501)
			-- upvalues: (ref) v_u_14
			if p501.KeyCode == Enum.KeyCode.F or p501.KeyCode == Enum.KeyCode.ButtonA then
				local v_u_502 = v_u_14
				v_u_14 = nil
				if v_u_502 then
					pcall(function()
						-- upvalues: (copy) v_u_502
						v_u_502:InputHoldEnd()
					end)
				end
			end
		end)
	end
	v_u_9.onDevice(v_u_373)
	v_u_373(v_u_9.device())
	v_u_8.on("ui.rebuild", v_u_375)
	local v503 = v_u_8.on
	local function v504()
		-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_373
		if v_u_20 and v_u_9.device() == "Touch" then
			v_u_373("Touch")
		end
	end
	pcall(v503, "touch.layout", v504)
	v_u_11.CharacterRemoving:Connect(function()
		-- upvalues: (ref) v_u_14, (ref) v_u_12
		local v_u_505 = v_u_14
		v_u_14 = nil
		if v_u_505 then
			pcall(function()
				-- upvalues: (copy) v_u_505
				v_u_505:InputHoldEnd()
			end)
		end
		table.clear(v_u_12)
	end)
	local v506 = v_u_8.session
	if v506 and v506.onPlaceChanged then
		local v507 = v506.onPlaceChanged
		local function v510(p508, p509)
			-- upvalues: (ref) v_u_7
			if p508 ~= p509 then
				v_u_7.setEnabled(true)
			end
		end
		pcall(v507, v510)
	end
end
function v_u_7.step(p511) -- name: step
	-- upvalues: (ref) v_u_48, (ref) v_u_47, (copy) v_u_11, (ref) v_u_49, (ref) v_u_20, (ref) v_u_46, (copy) v_u_361, (ref) v_u_9, (copy) v_u_346, (copy) v_u_357, (ref) v_u_17, (copy) v_u_298, (ref) v_u_347, (ref) v_u_14, (ref) v_u_13, (ref) v_u_16, (copy) v_u_122, (copy) v_u_7, (ref) v_u_348, (copy) v_u_331, (copy) v_u_21, (ref) v_u_15, (copy) v_u_74
	if v_u_48 then
		local v512 = v_u_48.step
		pcall(v512, p511)
	end
	if v_u_47 then
		local v513 = v_u_47.step
		local v514, v515 = pcall(v513, p511)
		if not v514 then
			v_u_11:SetAttribute("ClientError", "DoorClient.step: " .. tostring(v515))
		end
	end
	if v_u_49 then
		local v516 = v_u_49.step
		local v517, v518 = pcall(v516, p511)
		if not v517 then
			v_u_11:SetAttribute("ClientError", "FenceVault.step: " .. tostring(v518))
		end
	end
	if v_u_20 then
		if v_u_46 then
			v_u_361(true)
			if v_u_20.action:GetAttribute("Src") ~= v_u_46.action then
				v_u_20.action:SetAttribute("Src", v_u_46.action)
				v_u_9.setText(v_u_20.action, v_u_46.action)
			end
			v_u_20.object.Text = v_u_46.object
			v_u_20.object.Visible = v_u_46.object ~= ""
			v_u_20.more.Visible = false
			v_u_20.ring.set(v_u_46.ring)
			v_u_20.marker.Visible = false
			v_u_346(v_u_46.rows or 0)
			v_u_357()
			return
		else
			local v519
			if v_u_17 then
				v519 = v_u_298()
			else
				v519 = nil
			end
			if v519 ~= v_u_347 then
				if v_u_14 and v_u_14 ~= v519 then
					local v_u_520 = v_u_14
					v_u_14 = nil
					if v_u_520 then
						pcall(function()
							-- upvalues: (copy) v_u_520
							v_u_520:InputHoldEnd()
						end)
					end
				end
				v_u_347 = v519
				v_u_13 = v519
				v_u_16 = false
				v_u_20.ring.set(0)
				v_u_11:SetAttribute("PromptActive", not v519 and "" or v_u_122(v519))
				if v_u_7.changed then
					v_u_7.changed:Fire(v519)
				end
				if v519 then
					v_u_9.sound("tick")
				end
			end
			if v519 then
				v_u_361(true)
				v_u_331(v519)
				local v521, v522 = v_u_122(v519)
				if v_u_20.action:GetAttribute("Src") ~= v521 then
					v_u_20.action:SetAttribute("Src", v521)
					v_u_9.setText(v_u_20.action, v521)
					v_u_11:SetAttribute("PromptActive", v521)
				end
				local v523 = v519:GetAttribute("Kind") == "blocked"
				local v524 = v_u_9.device() == "Touch"
				local v525 = v_u_20.chip
				local v526 = not v523
				if v526 then
					v526 = not v524
				end
				v525.Visible = v526
				v_u_20.tapIcon.Visible = not v523 and v524
				if v_u_20.object.Text ~= v522 then
					v_u_20.object.Text = v522
					v_u_20.object.Visible = v522 ~= ""
				end
				local v527 = #v_u_21 - 4
				local v528 = math.max(0, v527)
				v_u_20.more.Text = v528 <= 0 and "" or "+" .. v528
				v_u_20.more.Visible = v528 > 0
				if v519.HoldDuration > 0 and v_u_16 then
					local v529 = v_u_20.ring.set
					local v530 = (os.clock() - v_u_15) / v519.HoldDuration
					v529((math.clamp(v530, 0, 1)))
				elseif not v_u_16 then
					v_u_20.ring.set(0)
				end
				v_u_357()
				local v531 = v_u_74(v519)
				if v531 then
					local v532, v533 = v_u_9.worldToScreen(v531 + Vector3.new(0, 1.5, 0), true)
					v_u_20.marker.Visible = v533
					if v533 then
						local v534 = v_u_20.marker
						local v535 = UDim2.fromOffset
						local v536 = v532.X
						local v537 = v532.Y
						local v538 = os.clock() * 3
						v534.Position = v535(v536, v537 + math.sin(v538) * 2)
						return
					end
				else
					v_u_20.marker.Visible = false
				end
			else
				if v_u_20 and v_u_348 ~= false then
					v_u_348 = false
					v_u_20.card.Visible = false
					v_u_20.marker.Visible = false
					v_u_20.list.Visible = false
				end
				v_u_357()
			end
		end
	else
		return
	end
end
return v_u_7