-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FriendsJoinLayout

local v_u_63 = {
	["PAD"] = 14,
	["RIGHT"] = 8,
	["GAP"] = 8,
	["BTN_W"] = 84,
	["TAG_W"] = 38,
	["TAG_H"] = 18,
	["HEAD_H"] = 16,
	["HEAD_GAP"] = 6,
	["ROW_GAP"] = 4,
	["MESSAGE_H"] = 36,
	["NAME_H"] = 20,
	["SUB_H"] = 14,
	["MIN_ROW_H"] = 48,
	["MIN_BTN_H"] = 32,
	["SCROLL"] = 8,
	["NAME_SIZE"] = 16,
	["SUB_SIZE"] = 12,
	["CHAR"] = 0.62,
	["LIST_MIN"] = 96,
	["LIST_BASE_MIN"] = 160,
	["LIST_BASE_MAX"] = 420,
	["CHROME"] = 230,
	["FOOTER"] = 70,
	["RESERVE"] = 130,
	["BODY_FIXED"] = 159,
	["MODAL_FOOTER"] = 90,
	["MODAL_MAX"] = 0.9,
	["OVERFLOW_TOL"] = 8,
	["rowHeight"] = function(p1) -- name: rowHeight
		-- upvalues: (copy) v_u_63
		local v2 = v_u_63.MIN_BTN_H
		local v3 = p1 or v_u_63.MIN_BTN_H
		local v4 = math.max(v2, v3)
		local v5 = v_u_63.MIN_ROW_H
		local v6 = v4 + 8
		return math.max(v5, v6)
	end,
	["textW"] = function(p7, p8) -- name: textW
		-- upvalues: (copy) v_u_63
		local v9 = (utf8.len(p7) or #p7) * p8 * v_u_63.CHAR + 2
		return math.ceil(v9)
	end,
	["fits"] = function(p10, p11, p12) -- name: fits
		-- upvalues: (copy) v_u_63
		return v_u_63.textW(p10, p11) <= p12
	end,
	["listHeight"] = function(p13, p14) -- name: listHeight
		-- upvalues: (copy) v_u_63
		local v15 = p13 - 420
		local v16 = v_u_63.LIST_BASE_MIN
		local v17 = v_u_63.LIST_BASE_MAX
		local v18 = math.clamp(v15, v16, v17)
		if p14 <= 0 then
			return v18
		end
		local v19 = p13 * 0.9 - v_u_63.FOOTER
		local v20 = v_u_63.CHROME + v18 + p14 + 8
		if v20 <= v19 then
			return v18
		end
		local v21 = v20 - v19
		local v22 = v_u_63.RESERVE
		local v23 = math.min(v21, v22)
		local v24 = v_u_63.LIST_MIN
		local v25 = v18 - v23
		local v26 = math.floor(v25)
		return math.max(v24, v26)
	end,
	["blockFirst"] = function(p27, p28) -- name: blockFirst
		-- upvalues: (copy) v_u_63
		if p28 <= 0 then
			return false
		end
		local v29 = v_u_63.listHeight(p27, p28)
		return v_u_63.BODY_FIXED + v29 + p28 > v_u_63.MODAL_MAX * p27 - v_u_63.MODAL_FOOTER + v_u_63.OVERFLOW_TOL
	end,
	["layout"] = function(p30, p31) -- name: layout
		-- upvalues: (copy) v_u_63
		local v32 = type(p31) ~= "table" and {} or p31
		local v33 = v32.state ~= "rows" and (v32.state ~= "empty" and v32.state ~= "loading") and "none" or v32.state
		local v34 = v_u_63.MIN_BTN_H
		local v35 = v32.btnH
		local v36 = tonumber(v35) or v_u_63.MIN_BTN_H
		local v37 = math.max(v34, v36)
		local v38 = v_u_63.rowHeight(v37)
		local v39 = v32.refY
		local v40 = tonumber(v39) or 1080
		local v41
		if v33 == "rows" then
			local v42 = v32.n
			local v43 = tonumber(v42) or 0
			local v44 = math.floor(v43)
			v41 = math.max(0, v44)
		else
			v41 = 0
		end
		local v45 = v33 == "rows" and v41 == 0 and "empty" or v33
		if v45 == "none" then
			return {
				["state"] = "none",
				["w"] = nil,
				["h"] = 0,
				["rowH"] = nil,
				["btnH"] = nil,
				["heading"] = nil,
				["rows"] = nil,
				["listH"] = nil,
				["w"] = p30,
				["rowH"] = v38,
				["btnH"] = v37,
				["heading"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0
				},
				["rows"] = {},
				["listH"] = v_u_63.listHeight(v40, 0)
			}
		end
		local v46 = v_u_63.HEAD_H + v_u_63.HEAD_GAP
		local v47 = {
			["state"] = v45,
			["w"] = p30,
			["rowH"] = v38,
			["btnH"] = v37,
			["heading"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p30,
				["h"] = v_u_63.HEAD_H
			},
			["rows"] = {}
		}
		if v45 == "rows" then
			local v48 = p30 - v_u_63.SCROLL
			for v49 = 1, v41 do
				local v50 = v46 + (v49 - 1) * (v38 + v_u_63.ROW_GAP)
				local v51 = v48 - v_u_63.RIGHT - v_u_63.BTN_W
				local v52 = (v38 - v37) / 2
				local v53 = {
					["x"] = v51,
					["y"] = math.floor(v52),
					["w"] = v_u_63.BTN_W,
					["h"] = v37
				}
				local v54 = v53.x - v_u_63.GAP - v_u_63.TAG_W
				local v55 = (v38 - v_u_63.TAG_H) / 2
				local v56 = {
					["x"] = v54,
					["y"] = math.floor(v55),
					["w"] = v_u_63.TAG_W,
					["h"] = v_u_63.TAG_H
				}
				local v57 = v56.x - v_u_63.GAP - v_u_63.PAD
				local v58 = (v38 - (v_u_63.NAME_H + 1 + v_u_63.SUB_H)) / 2
				local v59 = math.floor(v58)
				local v60 = v47.rows
				local v61 = {
					["box"] = {
						["x"] = 0,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["y"] = v50,
						["w"] = v48,
						["h"] = v38
					},
					["name"] = {
						["x"] = v_u_63.PAD,
						["y"] = v59,
						["w"] = v57,
						["h"] = v_u_63.NAME_H
					},
					["sub"] = {
						["x"] = v_u_63.PAD,
						["y"] = v59 + v_u_63.NAME_H + 1,
						["w"] = v57,
						["h"] = v_u_63.SUB_H
					},
					["chip"] = v56,
					["button"] = v53
				}
				table.insert(v60, v61)
			end
			v47.h = v46 + v41 * v38 + (v41 - 1) * v_u_63.ROW_GAP
		else
			v47.message = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v46,
				["w"] = p30,
				["h"] = v_u_63.MESSAGE_H
			}
			v47.h = v46 + v_u_63.MESSAGE_H
		end
		v47.listH = v_u_63.listHeight(v40, v47.h)
		local v62
		if v45 == "rows" then
			v62 = v_u_63.blockFirst(v40, v47.h)
		else
			v62 = false
		end
		v47.first = v62
		return v47
	end
}
return v_u_63