-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / WaterBody

local v_u_1 = game:GetService("Players")
local v2 = {
	["name"] = "WaterBody",
	["order"] = 21
}
local v_u_3 = nil
local v_u_4 = 0
local v_u_5 = false
local v_u_6 = 0
local v_u_7 = {}
local v_u_8 = nil
local function v_u_33(p9, p10) -- name: waterNear
	local v11 = p9.Position
	local v12 = (not p10 and 2 or p10.HipHeight) + p9.Size.Y / 2
	local v13 = v11.X - 8
	local v14 = v11.Y - v12 - 4
	local v15 = v11.Z - 8
	local v_u_16 = Vector3.new(v13, v14, v15)
	local v17 = v11.X + 8
	local v18 = v11.Y + 3
	local v19 = v11.Z + 8
	local v_u_20 = Vector3.new(v17, v18, v19)
	local v22, v23, v24 = pcall(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_20
		local v21 = Region3.new(v_u_16, v_u_20):ExpandToGrid(4)
		return workspace.Terrain:ReadVoxels(v21, 4)
	end)
	if not (v22 and v23) then
		return false
	end
	local v25 = v23.Size
	for v26 = 1, v25.X do
		local v27 = v23[v26]
		local v28 = v24[v26]
		for v29 = 1, v25.Y do
			local v30 = v27[v29]
			local v31 = v28[v29]
			for v32 = 1, v25.Z do
				if v30[v32] ~= Enum.Material.Water or v31[v32] <= 0.2 then
					continue
				end
				return true
			end
		end
	end
	return false
end
local function v_u_38(p34, p35) -- name: arm
	-- upvalues: (copy) v_u_7
	for _, v36 in p34:GetDescendants() do
		if not v36:IsA("BasePart") or (v36 == p35 or not v36.Massless) then
			continue
		end
		v36.Massless = false
		local v37 = v_u_7
		table.insert(v37, v36)
	end
end
function v2.init(p39) -- name: init
	-- upvalues: (ref) v_u_3
	v_u_3 = p39
end
function v2.start() -- name: start end
function v2.step(_) -- name: step
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (ref) v_u_8, (copy) v_u_7, (ref) v_u_5, (copy) v_u_33, (ref) v_u_6, (copy) v_u_38
	local v40 = os.clock()
	if v40 - v_u_4 < 0.1 then
		return
	else
		v_u_4 = v40
		local v41 = v_u_1.LocalPlayer
		local v42 = v41.Character
		if v_u_8 and v_u_8 ~= v42 then
			table.clear(v_u_7)
			v_u_5 = false
			v_u_8 = nil
			v41:SetAttribute("WaterArmed", false)
		end
		local v43
		if v42 then
			v43 = v42:FindFirstChild("HumanoidRootPart")
		else
			v43 = v42
		end
		if v42 and (v43 and (not v43.Anchored and v42:GetAttribute("Dead") ~= true)) then
			if v_u_33(v43, (v42:FindFirstChildOfClass("Humanoid"))) then
				v_u_6 = v40
				if not v_u_5 then
					v_u_5 = true
					v_u_8 = v42
					v41:SetAttribute("WaterArmed", true)
				end
				v_u_38(v42, v43)
			elseif v_u_5 and v40 - v_u_6 >= 1.5 then
				v_u_5 = false
				for _, v44 in v_u_7 do
					if not v44.Parent then
						continue
					end
					v44.Massless = true
				end
				table.clear(v_u_7)
				v41:SetAttribute("WaterArmed", false)
			end
		else
			return
		end
	end
end
return v2