-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RidePose

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.RidePosePlan)
local v_u_4 = nil
local v_u_5 = -1000000000
local function v_u_8() -- name: leanPlan
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	if v_u_4 ~= nil then
		return v_u_4
	end
	if os.clock() - v_u_5 < 5 then
		return nil
	end
	v_u_5 = os.clock()
	local v6, v7 = pcall(function()
		return require(script.Parent.RideLeanPlan)
	end)
	if v6 and type(v7) == "table" then
		v_u_4 = v7
	end
	return v_u_4
end
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = v_u_1.LocalPlayer
local v_u_13 = math.rad
local v_u_14 = math.deg
local v_u_15 = {
	["seated"] = 0,
	["leaned"] = 0,
	["ejected"] = 0,
	["drive"] = 0,
	["miss"] = 0,
	["errors"] = 0,
	["leanFrames"] = 0,
	["leanErrors"] = 0
}
local v_u_16 = {}
local v_u_17 = {}
local function v_u_30(p18) -- name: shared
	-- upvalues: (copy) v_u_16, (copy) v_u_17, (copy) v_u_2, (copy) v_u_15
	local v19 = v_u_16[p18]
	if v19 ~= nil then
		return v19
	end
	local v20 = os.clock()
	local v21 = v_u_17[p18]
	if v21 ~= nil and v20 - v21 < 3 then
		return nil
	end
	local v22 = v_u_2:FindFirstChild("Hush")
	local v23
	if v22 == nil then
		v23 = nil
	else
		v23 = v22:FindFirstChild("Shared")
	end
	local v24
	if v23 == nil then
		v24 = nil
	else
		v24 = v23:FindFirstChild(p18)
	end
	if v24 ~= nil then
		local v25 = require
		local v26, v27 = pcall(v25, v24)
		if v26 and type(v27) == "table" then
			v_u_16[p18] = v27
			return v27
		end
		local v28 = "require " .. p18
		local v29 = v_u_15
		v29.errors = v29.errors + 1
		if v_u_15.errors <= 3 then
			warn("[RidePose] " .. v28 .. ": " .. tostring(v27))
		end
	end
	v_u_17[p18] = v20
	return nil
end
local v_u_31 = -1000000000
local v_u_32 = true
local function v_u_37() -- name: classicLeanOk
	-- upvalues: (ref) v_u_31, (copy) v_u_30, (ref) v_u_32
	local v33 = os.clock()
	if v33 - v_u_31 > 2 then
		v_u_31 = v33
		local v_u_34 = v_u_30("Config")
		local v35, v36 = pcall(function()
			-- upvalues: (copy) v_u_34
			return v_u_34.flag("RideLeanClassic")
		end)
		v_u_32 = not v35 or v36 ~= false
	end
	return v_u_32
end
local v_u_38 = nil
local v_u_39 = -1000000000
local function v_u_44() -- name: animPlay
	-- upvalues: (ref) v_u_38, (ref) v_u_39, (copy) v_u_30, (copy) v_u_15
	if v_u_38 ~= nil then
		return v_u_38
	end
	local v40 = os.clock()
	if v40 - v_u_39 < 3 then
		return nil
	end
	v_u_39 = v40
	if v_u_30("VehAnim") == nil or (v_u_30("VehBoardRules") == nil or v_u_30("VehicleSpec") == nil) then
		return nil
	end
	local v41, v42 = pcall(function()
		return require(script.Parent.VehAnimPlay)
	end)
	if v41 and type(v42) == "table" then
		v_u_38 = v42
		return v42
	end
	local v43 = v_u_15
	v43.errors = v43.errors + 1
	if v_u_15.errors <= 3 then
		warn("[RidePose] " .. "require VehAnimPlay" .. ": " .. tostring(v42))
	end
	return nil
end
local v_u_45 = {}
local v_u_46 = {}
local function v_u_55(p47) -- name: modelOf
	-- upvalues: (copy) v_u_45, (copy) v_u_46, (copy) v_u_15
	local v48 = v_u_45[p47]
	if v48 ~= nil and v48.Parent ~= nil then
		return v48
	end
	local v49 = os.clock()
	local v50 = v_u_46[p47]
	if v50 ~= nil and v49 - v50 < 0.5 then
		return nil
	end
	local v51 = workspace:FindFirstChild("Raid")
	local v52
	if v51 == nil then
		v52 = nil
	else
		v52 = v51:FindFirstChild("Vehicles")
	end
	if v52 ~= nil then
		for _, v53 in v52:GetChildren() do
			if tostring(v53:GetAttribute("VehId")) ~= p47 then
				continue
			end
			v_u_45[p47] = v53
			v_u_46[p47] = nil
			return v53
		end
	end
	v_u_46[p47] = v49
	local v54 = v_u_15
	v54.miss = v54.miss + 1
	return nil
end
local function v_u_66(p56, p57) -- name: leanNameOf
	-- upvalues: (copy) v_u_30
	local v58 = v_u_30("VehicleSpec")
	local v59
	if v58 == nil then
		v59 = nil
	else
		local v60 = v58.TYPES
		if type(v60) == "table" then
			v59 = v58.TYPES[p56]
		else
			v59 = nil
		end
	end
	local v61
	if v59 == nil then
		v61 = nil
	else
		local v62 = v59.geometry
		if type(v62) == "table" then
			v61 = v59.geometry.leanPose
		else
			v61 = nil
		end
	end
	if type(v61) ~= "table" or type(p57) ~= "string" then
		return nil
	end
	local v63 = string.match(p57, "^Seat_(.+)$")
	local v64
	if v63 == nil then
		v64 = nil
	else
		v64 = v61["Lean_" .. v63]
	end
	if type(v64) == "table" then
		local v65 = v64.pose
		if type(v65) == "string" then
			return v64.pose
		end
	end
	return nil
end
local function v_u_74(p67, p68) -- name: seatRow
	-- upvalues: (copy) v_u_30
	local v69 = v_u_30("VehicleSpec")
	local v70
	if v69 == nil then
		v70 = nil
	else
		local v71 = v69.TYPES
		if type(v71) == "table" then
			v70 = v69.TYPES[p67]
		else
			v70 = nil
		end
	end
	if v70 ~= nil then
		local v72 = v70.seats
		if type(v72) == "table" then
			for _, v73 in v70.seats do
				if v73.name ~= p68 then
					continue
				end
				return v73
			end
			return nil
		end
	end
	return nil
end
local function v_u_78(p75, p76, p77) -- name: eulerCF
	-- upvalues: (copy) v_u_13
	return CFrame.fromEulerAnglesYXZ(v_u_13(p75), v_u_13(p76), (v_u_13(p77)))
end
local function v_u_106(p79, p80, p81, p82, p83) -- name: applyPose
	-- upvalues: (copy) v_u_3, (copy) v_u_13
	local v84
	if p82 == nil then
		v84 = false
	else
		v84 = p83 < 1
	end
	local v85, v86, v87 = v_u_3.rootT(p81)
	local v88, v89, v90 = v_u_3.rootEuler(p81)
	local v91 = CFrame.new(v85, v86, v87) * CFrame.fromEulerAnglesYXZ(v_u_13(v88), v_u_13(v89), (v_u_13(v90)))
	if v84 then
		local v92, v93, v94 = v_u_3.rootT(p82)
		local v95, v96, v97 = v_u_3.rootEuler(p82)
		v91 = (CFrame.new(v92, v93, v94) * CFrame.fromEulerAnglesYXZ(v_u_13(v95), v_u_13(v96), (v_u_13(v97)))):Lerp(v91, p83)
	end
	p79:setT("Root", v91)
	for _, v98 in p80 do
		if v98 == "Root" then
			continue
		end
		local v99, v100, v101 = v_u_3.jointEuler(p81, v98)
		local v102 = CFrame.fromEulerAnglesYXZ(v_u_13(v99), v_u_13(v100), (v_u_13(v101)))
		if v84 then
			local v103, v104, v105 = v_u_3.jointEuler(p82, v98)
			v102 = CFrame.fromEulerAnglesYXZ(v_u_13(v103), v_u_13(v104), (v_u_13(v105))):Lerp(v102, p83)
		end
		p79:setT(v98, v102)
	end
	p79:apply()
end
local v_u_374 = false
local v_u_108 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_109 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_110 = {
	["freeze"] = nil,
	["accel"] = nil,
	["kick"] = nil
}
local function v_u_126(p111, p112, p113, p114) -- name: seatFix
	-- upvalues: (copy) v_u_30, (copy) v_u_13
	local v115 = p112:FindFirstChild(p113)
	if v115 == nil or not v115:IsA("Attachment") then
		return nil
	else
		local v116 = v_u_30("VehicleSpec")
		local v117
		if v116 == nil then
			v117 = nil
		else
			local v118 = v116.TYPES
			if type(v118) == "table" then
				v117 = v116.TYPES[p114]
			else
				v117 = nil
			end
		end
		local v119
		if v117 == nil then
			v119 = nil
		else
			v119 = v117.geometry
		end
		local v120
		if v119 == nil then
			v120 = 0
		else
			local v121 = v119.seatYaw
			if type(v121) == "table" then
				local v122 = v119.seatYaw[p113]
				v120 = type(v122) ~= "number" and 0 or v119.seatYaw[p113]
			else
				v120 = 0
			end
		end
		local v123 = p112.CFrame * v115.CFrame * CFrame.Angles(0, v_u_13(v120), 0)
		local v124 = p111.root.CFrame:ToObjectSpace(v123)
		local _, v125 = v124:ToAxisAngle()
		if v124.Position.Magnitude < 0.02 and math.abs(v125) < 0.008726646259971648 then
			return nil
		else
			return v124
		end
	end
end
local function v_u_133(p127, p128, p129) -- name: accelOf
	local v130 = p128.AssemblyLinearVelocity
	local v131 = p127.prevVel
	p127.prevVel = v130
	if v131 == nil or p129 <= 0 then
		return {
			["lat"] = 0,
			["long"] = 0,
			["vert"] = 0
		}
	end
	local v132 = p128.CFrame:VectorToObjectSpace((v130 - v131) / math.max(p129, 0.004166666666666667))
	return {
		["lat"] = v132.X,
		["long"] = -v132.Z,
		["vert"] = v132.Y
	}
end
local v_u_134 = nil
local v_u_135 = -1000000000
local function v_u_138() -- name: weaponRide
	-- upvalues: (ref) v_u_134, (ref) v_u_135
	if v_u_134 ~= nil then
		return v_u_134
	end
	if os.clock() - v_u_135 < 5 then
		return nil
	end
	v_u_135 = os.clock()
	local v136, v137 = pcall(function()
		return require(script.Parent.WeaponRide)
	end)
	if v136 and type(v137) == "table" then
		v_u_134 = v137
	end
	return v_u_134
end
local function v_u_158(p139, p140, p141) -- name: aimOf
	-- upvalues: (copy) v_u_110, (copy) v_u_138, (copy) v_u_14
	if v_u_110.aim == nil or not p139.isLocal then
		local v142 = p141.CFrame.LookVector
		local v143 = -v142.X
		local v144 = -v142.Z
		local v145 = math.atan2(v143, v144)
		if p139.isLocal then
			local v146 = v_u_138()
			if v146 ~= nil then
				local v147, v148 = v146.aim()
				if v147 ~= nil and v148 ~= nil then
					local v149 = v145 - v147
					local v150 = (v149 + 3.141592653589793) / 6.283185307179586
					return v_u_14(v149 - 6.283185307179586 * math.floor(v150)), v_u_14(v148)
				end
				local v151, v152 = v146.rawAim()
				if v151 ~= nil then
					return v151, v152
				end
			end
		end
		local v153 = p140:GetAttribute("AimYaw")
		if type(v153) == "number" then
			local v154 = p140:GetAttribute("AimPitch")
			local v155 = v145 - v153
			local v156 = (v155 + 3.141592653589793) / 6.283185307179586
			local v157 = v_u_14(v155 - 6.283185307179586 * math.floor(v156))
			if type(v154) == "number" then
				return v157, v_u_14(v154)
			else
				return v157, 0
			end
		else
			return nil, nil
		end
	else
		return v_u_110.aim[1], v_u_110.aim[2]
	end
end
local v_u_159 = -1000000000
local v_u_160 = nil
local v_u_161 = nil
local function v_u_170() -- name: viewCeil
	-- upvalues: (ref) v_u_159, (ref) v_u_160, (ref) v_u_161, (copy) v_u_30, (copy) v_u_12
	if os.clock() - v_u_159 < 1 then
		return v_u_160, v_u_161
	end
	v_u_159 = os.clock()
	local v162 = v_u_30("RideArc")
	local v_u_163 = v_u_30("ViewMode")
	if v162 == nil or (v_u_163 == nil or v_u_12 == nil) then
		return nil, nil
	end
	local function v164()
		-- upvalues: (copy) v_u_163, (ref) v_u_12
		return v_u_163.pitchLimits(v_u_12:GetAttribute(v_u_163.PLAYER_ATTR))
	end
	local v165, v166, v167 = pcall(v164)
	if v165 and (type(v166) == "number" and type(v167) == "number") then
		local v168 = v162.slopeDeg(v166)
		local v169 = v162.slopeDeg(-v167)
		v_u_160 = v168
		v_u_161 = v169
	end
	return v_u_160, v_u_161
end
local function v_u_189(p171, p172, p173, p174) -- name: jumpOf
	local v175 = p171.prevJ
	local v176 = {}
	local v177 = 0
	for v178, v179 in p172.pose.j do
		v176[v178] = v179
		local v180
		if v175 == nil then
			v180 = nil
		else
			v180 = v175[v178]
		end
		if v180 == nil or v178 == "Root" then
			continue
		end
		local v181 = v179[1] - v180[1]
		local v182 = math.abs(v181)
		local v183 = v179[2] - v180[2]
		local v184 = math.abs(v183)
		local v185 = v179[3] - v180[3]
		local v186 = math.abs(v185)
		local v187 = math.max(v182, v184, v186) / math.max(p174, 0.004166666666666667)
		v177 = math.max(v177, v187)
	end
	p171.prevJ = v176
	p171.jumps = p171.jumps or {}
	local v188 = p171.jumps
	table.insert(v188, { p173, v177 })
	while #p171.jumps > 0 and p173 - p171.jumps[1][1] > 2 do
		table.remove(p171.jumps, 1)
	end
end
local function v_u_197(p190) -- name: holdOf
	-- upvalues: (ref) v_u_10
	local v191 = p190.model
	local v192 = v191:GetAttribute("HoldType") or "none"
	local v_u_193 = v191:GetAttribute("Weapon")
	local v194
	if type(v_u_193) == "string" and (v_u_193 ~= "" and v_u_10 ~= nil) then
		local function v195()
			-- upvalues: (ref) v_u_10, (copy) v_u_193
			return v_u_10.shared.Weapons.get(v_u_193)
		end
		local v196
		v196, v194 = pcall(v195)
		if not v196 then
			v194 = nil
		end
	else
		v194 = nil
	end
	if (v192 == "none" or v192 == "") and (v194 ~= nil and (v194.holdType and v191:FindFirstChild("HeldWeapon"))) then
		v192 = v194.holdType
	end
	return v192, v_u_193, v194
end
local function v_u_214(p198) -- name: weaponInfo
	-- upvalues: (copy) v_u_197, (ref) v_u_10
	local v199, v_u_200, v_u_201 = v_u_197(p198)
	local v202 = (v199 == "pistol" or v199 == "rifle") and true or v199 == "shotgun"
	local v203 = {
		["holdType"] = nil,
		["wid"] = nil,
		["def"] = nil,
		["gun"] = nil,
		["class"] = "rifle",
		["twin"] = false,
		["stanceAim"] = 0,
		["holdType"] = v199,
		["wid"] = v_u_200,
		["def"] = v_u_201,
		["gun"] = v202
	}
	if v202 and v_u_10 ~= nil then
		local function v207()
			-- upvalues: (ref) v_u_10, (copy) v_u_200, (copy) v_u_201
			local v204 = v_u_10.lib.AnimClassPoses.classOf
			local v205 = v_u_200
			local v206
			if type(v205) == "string" then
				v206 = v_u_200
			else
				v206 = nil
			end
			return v204(v206, v_u_201, nil)
		end
		local v208, v209 = pcall(v207)
		if v208 and type(v209) == "string" then
			v203.class = v209
		end
		local v210
		if p198.model:GetAttribute("TwinPair") == true then
			v210 = p198.model:FindFirstChild("HeldWeapon2") ~= nil
		else
			v210 = false
		end
		v203.twin = v210
		if v199 == "rifle" or v199 == "shotgun" then
			local v211 = v_u_10.lib.AnimArms.stance
			if type(v_u_200) ~= "string" then
				v_u_200 = nil
			end
			local v212, v213 = pcall(v211, v_u_200, v_u_201)
			if v212 and type(v213) == "number" then
				v203.stanceAim = v213
			end
		end
	end
	return v203
end
local v_u_215 = -1000000000
local v_u_216 = true
local function v_u_229(p217, p218, p219) -- name: armsOf
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_215, (ref) v_u_216
	if v_u_10 ~= nil and v_u_11 ~= nil then
		if os.clock() - v_u_215 > 1 then
			v_u_215 = os.clock()
			local v220 = v_u_10.config.flag
			local v221, v222 = pcall(v220, "NewAnims")
			v_u_216 = not v221 or v222 ~= false
		end
		if v_u_216 and p218.gun then
			local v223 = p217.model:FindFirstChild("HeldWeapon")
			if v223 ~= nil and (p217.weapon == nil or p217.weapon.model ~= v223) then
				p217.weaponCheck = 0
			end
			if p217.weaponCheck <= 0 then
				p217.weaponCheck = 0.3
				p217.weapon = v_u_11(p217)
			else
				p217.weaponCheck = p217.weaponCheck - p219.dt
			end
			local v224 = {
				["st"] = nil,
				["holdType"] = nil,
				["def"] = nil,
				["wid"] = nil,
				["chest"] = nil,
				["stanceChest"] = nil,
				["bobY"] = 0,
				["busyAction"] = false,
				["handsAction"] = nil,
				["swing"] = nil,
				["swingDur"] = nil,
				["bashing"] = false,
				["bashU"] = 0,
				["gunHold"] = true,
				["now"] = nil,
				["aimPitch"] = 0,
				["st"] = p217,
				["holdType"] = p218.holdType,
				["def"] = p218.def
			}
			local v225 = p218.wid
			local v226
			if type(v225) == "string" then
				v226 = p218.wid
			else
				v226 = nil
			end
			v224.wid = v226
			v224.chest = p219.chest
			v224.stanceChest = p219.stanceChest
			v224.swingDur = p217.swingDur
			v224.now = os.clock()
			for v227, v228 in p219.env do
				v224[v227] = v228
			end
			v_u_10.lib.AnimArms.armed(v224)
			return true
		end
	end
	return false
end
local function v_u_452(p230, p231, p232, p233, p234, p235, p236, p237, p238, p239) -- name: leanBranch
	-- upvalues: (ref) v_u_374, (copy) v_u_30, (copy) v_u_8, (ref) v_u_4, (copy) v_u_74, (copy) v_u_3, (copy) v_u_66, (copy) v_u_109, (copy) v_u_214, (ref) v_u_10, (copy) v_u_12, (copy) v_u_37, (copy) v_u_158, (copy) v_u_110, (copy) v_u_133, (copy) v_u_170, (copy) v_u_14, (copy) v_u_189, (copy) v_u_126, (copy) v_u_13, (copy) v_u_229, (copy) v_u_15
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v358, v359, v360, v361, v362, v363, v364, v365, v366, v367, v368, v369, v370, v371, v372, v373, v375, v376, v377, v378, v379, v380, v381, v382, v383, v384, v385, v386, v387, v388, v389, v390, v391, v392, v393, v394, v395, v396, v397, v398, v399, v400, v401, v402, v403, v404, v405, v406, v407, v408, v409, v410, v411, v412, v413, v414, v415, v416, v417, v418, v419, v420, v421, v422, v423, v424, v425, v426, v427, v428, v429, v430, v431, v432, v433, v434, v435, v436, v437, v438, v439, v440, v441, v442, v443, v444, v445, v446
	local v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v358, v359, v360, v361, v362, v363, v364, v365, v366, v367, v368, v369, v370, v371, v372, v373, v_u_374, v375, v376, v377, v378, v379, v380, v381, v382, v383, v384, v385, v386, v387, v388, v389, v390, v391, v392, v393, v394, v395, v396, v397, v398, v399, v400, v401, v402, v403, v404, v405, v406, v407, v408, v409, v410, v411, v412, v413, v414, v415, v416, v417, v418, v419, v420, v421, v422, v423, v424, v425, v426, v427, v428, v429, v430, v431, v432, v433, v434, v435, v436, v437, v438, v439, v440, v441, v442, v443, v444, v445, v446
	local v447 = 12
	while true do
		if v447 == 1 then
			v362 = p230.model:GetAttribute("Aiming") == true
			if v362 and (v_u_12 ~= nil and (v_u_12:GetAttribute("ViewMode") == "fptp" or v_u_37())) then
				v447 = 10
			else
				v447 = 2
			end
		elseif v447 == 2 then
			v422.predAt = nil
			v447 = 11
		elseif v447 == 3 then
			v422.predAt = nil
			v447 = 11
		elseif v447 == 4 then
			if v385.gun and not p230.reloading then
				v447 = 6
			else
				v447 = 5
			end
		elseif v447 == 5 then
			v422.predAt = nil
			v447 = 11
		elseif v447 == 6 then
			if p230.isLocal and (v_u_10 ~= nil and v_u_10.controllers.Input) then
				v447 = 8
			else
				v447 = 7
			end
		elseif v447 == 7 then
			v362 = p230.model:GetAttribute("Aiming") == true
			if v362 and (v_u_12 ~= nil and (v_u_12:GetAttribute("ViewMode") == "fptp" or v_u_37())) then
				v447 = 10
			else
				v447 = 2
			end
		elseif v447 == 8 then
			v363 = v_u_10.controllers.Input.isAiming
			v378, v379 = pcall(v363)
			if v378 then
				v447 = 9
			else
				v447 = 1
			end
		elseif v447 == 9 then
			v362 = v379 == true
			if v362 and (v_u_12 ~= nil and (v_u_12:GetAttribute("ViewMode") == "fptp" or v_u_37())) then
				v447 = 10
			else
				v447 = 2
			end
		elseif v447 == 10 then
			if v422.predAt == nil then
				v422.predAt = p238
			end
			v380 = p238 - v422.predAt < 0.8
			v447 = 11
		elseif v447 == 11 then
			v415, v416 = v_u_158(p230, p232, v358)
			v381 = p230.reloading == true
			if v_u_110.freeze ~= nil and p230.isLocal then
				v346 = v_u_110.freeze
				v380 = true
				v381 = v346.stance == "TUCK"
				v347 = v_u_4.stancesOf(v384, v418.arc, p237)
				v348 = v346.stance
				if v348 == "TUCK" then
					v348 = v422.L.stance or next(v347)
				end
				v395 = v347[v348]
				if v395 ~= nil then
					v415 = (v395.neutral or 0) + v346.u
					v416 = v346.p
				end
			end
			v360 = v_u_133(v422, v358, p239)
			if v_u_110.accel ~= nil then
				if p238 < v_u_110.accel.untilT then
					v360 = {
						["lat"] = nil,
						["long"] = nil,
						["vert"] = 0,
						["lat"] = v_u_110.accel.lat,
						["long"] = v_u_110.accel.long
					}
				else
					v_u_110.accel = nil
				end
			end
			v361 = p230.kickN
			v382 = v385.class
			if v_u_110.kick ~= nil and p230.isLocal then
				v361 = v361 + 1
				v382 = v_u_110.kick
				v_u_110.kick = nil
				v422.kickBonus = (v422.kickBonus or 0) + 1
			end
			v402, v387 = v_u_170()
			v388 = v358.AssemblyLinearVelocity
			v389 = {
				["now"] = p238,
				["leanOn"] = v380,
				["aimPhi"] = v415,
				["aimTheta"] = v416,
				["isLocal"] = p230.isLocal == true,
				["arc"] = v418.arc,
				["seatName"] = p237,
				["viewUp"] = v402,
				["viewDown"] = v387,
				["class"] = v382,
				["twin"] = v385.twin,
				["bladed"] = v_u_14(v385.stanceAim) * (v422.stanceMul or 0.5),
				["sit"] = p236.poses[v419]
			}
			if v383 == nil then
				v442 = nil
			else
				v442 = p236.poses[v383]
			end
			v389.legacyPose = v442
			v389.kickN = v361 + (v422.kickBonus or 0)
			v389.kickScale = p230.kickScale
			v389.flinch = p230.flinch
			v389.flinchYaw = p230.flinchYaw
			v389.reloading = v381
			v389.accel = v360
			v393 = v388.X * v388.X + v388.Z * v388.Z
			v389.speed = math.sqrt(v393)
			v389.seed = p230.seed
			v344 = p230.kick
			v394 = math.min(p239, 0.1) * -9
			p230.kick = v344 * math.exp(v394)
			v345 = p230.flinch
			v439 = math.min(p239, 0.1) * -6
			p230.flinch = v345 * math.exp(v439)
			v440 = v_u_4.step(v422.L, p239, v389, v384, v420)
			v422.stanceMul = v440.stanceMul
			v422.out = v440
			v422.at = os.clock()
			v_u_189(v422, v440, p238, p239)
			v386 = v_u_126(p230, v358, p237, p235)
			v441 = v440.pose
			v401 = v440.motion
			v364, v365, v366 = v_u_3.jointEuler(v441, "Root")
			v390 = v441.rootT
			v443 = CFrame.new(v390[1], v390[2] + v401.ly, v390[3]) * CFrame.fromEulerAnglesYXZ(v_u_13(v401.rx), 0, (v_u_13(v401.rz))) * CFrame.fromEulerAnglesYXZ(v_u_13(v364), v_u_13(v365), (v_u_13(v366)))
			v444 = "Root"
			if v386 ~= nil then
				v445 = p231.joints.Root
				v443 = v445.c0:Inverse() * v386 * v445.c0 * v443
			end
			p231:setT(v444, v443)
			v446 = v440.add or {}
			v343 = v440.twist or {
				["Waist"] = 0,
				["Neck"] = 0
			}
			for _, v448 in p234.JOINTS do
				if v448 == "Root" then
					continue
				end
				v391, v392, v410 = v_u_3.jointEuler(v441, v448)
				v411 = v446[v448]
				if v411 ~= nil then
					v391 = v391 + v411[1]
					v392 = v392 + v411[2]
					v410 = v410 + v411[3]
				end
				v375 = CFrame.fromEulerAnglesYXZ(v_u_13(v391), v_u_13(v392), (v_u_13(v410)))
				if v448 == "Waist" and v343.Waist ~= 0 then
					v375 = v375 * CFrame.Angles(0, v_u_13(v343.Waist), 0)
				elseif v448 == "Neck" then
					if v343.Neck ~= 0 then
						v375 = v375 * CFrame.Angles(0, v_u_13(v343.Neck), 0)
					end
					if p231.joints.Neck ~= nil and (v401.rx ~= 0 or v401.rz ~= 0) then
						v412 = p231:pivot("Neck").Rotation
						v376 = CFrame.fromEulerAnglesYXZ(-v_u_13(v401.rx) * v401.neckPitch, 0, -v_u_13(v401.rz) * v401.neckRoll)
						v375 = v412:Inverse() * v376 * v412 * v375
					end
				end
				p231:setT(v448, v375)
			end
			v413 = p230.root.CFrame.LookVector
			v377 = -v413.X
			v414 = -v413.Z
			v396 = math.atan2(v377, v414)
			v349 = v358.CFrame.LookVector
			v397 = -v349.X
			v350 = -v349.Z
			v359 = math.atan2(v397, v350)
			v398 = v440.armPhi or v440.phiTarget or (v440.phi or 0)
			v399 = v359 - v396 - v_u_13(v398)
			v400 = (v399 + 3.141592653589793) / 6.283185307179586
			v417 = v399 - 6.283185307179586 * math.floor(v400)
			if v440.active and p231.joints.Neck ~= nil then
				v423 = p231.joints.Neck.child
				v424 = (p231.part[v423] * p231.bind[v423]:Inverse()).LookVector
				v403 = -v424.X
				v404 = -v424.Z
				v405 = math.atan2(v403, v404)
				v406 = v_u_13(v440.neckMax or v_u_4.TUNE.NECK_MAX)
				v425 = v417 - v405
				v426 = (v425 + 3.141592653589793) / 6.283185307179586
				v407 = v425 - 6.283185307179586 * math.floor(v426)
				v408 = -v406
				v409 = math.clamp(v407, v408, v406)
				v431 = v440.aimW
				v432 = v409 * math.clamp(v431, 0, 1)
				if math.abs(v432) > 0.0001 then
					v427 = p231:pivot("Neck").Rotation
					p231:setT("Neck", v427:Inverse() * CFrame.Angles(0, v432, 0) * v427 * p231.T.Neck)
				end
			end
			if v440.active and v385.gun then
				v433 = p231.joints.Waist.child
				v434 = p231.part[v433] * p231.bind[v433]:Inverse()
				p230.wAim = v440.aimW
				p230.wSneak = 0
				p230.wSprint = 0
				p230.gw = 0
				v428 = {
					"LeftShoulder",
					"LeftElbow",
					"LeftWrist",
					"RightShoulder",
					"RightElbow",
					"RightWrist"
				}
				v429 = {}
				for _, v449 in v428 do
					if p231.joints[v449] == nil then
						continue
					end
					v429[v449] = p231.T[v449]
				end
				v430 = v401.gripShare or 0.2
				v351 = {
					["aimYawAbs"] = v417 + v_u_13((v440.idleYaw or 0) - v430 * v401.rz),
					["aimPitchAbs"] = v_u_13((v440.theta or 0) + (v440.idlePitch or 0) + v430 * v401.rx + (v440.muzzle or 0)),
					["yawCap"] = v_u_13(v440.rhoCap or 30),
					["oneHand"] = v440.oneHand == true
				}
				if v440.boxes ~= nil then
					v435 = {}
					for _, v450 in v440.boxes do
						v436 = CFrame.new(v450.c[1], v450.c[2], v450.c[3]) * CFrame.Angles(0, v_u_13(v450.yaw or 0), 0)
						if v386 ~= nil then
							v436 = v386 * v436
						end
						v437 = {
							["cf"] = nil,
							["inv"] = nil,
							["half"] = nil,
							["group"] = "vehicle",
							["cf"] = v436,
							["inv"] = v436:Inverse()
						}
						v438 = v450.s[1]
						v367 = v450.s[2]
						v368 = v450.s[3]
						v437.half = Vector3.new(v438, v367, v368) * 0.5
						table.insert(v435, v437)
					end
					v351.extraBoxes = v435
				end
				if v440.lh ~= nil and v440.lh.w > 0.001 then
					v352 = v440.lh.x
					v353 = v440.lh.y
					v354 = v440.lh.z
					v369 = Vector3.new(v352, v353, v354)
					v370 = {}
					if v386 ~= nil then
						v369 = v386 * v369
					end
					v370.pos = v369
					v370.w = v440.lh.w
					v351.leftPlant = v370
				end
				if v_u_229(p230, v385, {
					["dt"] = p239,
					["chest"] = v434,
					["stanceChest"] = v_u_13(v_u_14(v385.stanceAim) * v440.stanceMul) * v440.aimW,
					["env"] = v351
				}) then
					v371 = v440.armW or 1
					v372 = math.clamp(v371, 0, 1)
					if v372 < 1 then
						for _, v451 in v428 do
							v355 = v429[v451]
							if v355 == nil then
								continue
							end
							p231:setT(v451, v355:Lerp(p231.T[v451], v372))
						end
					end
				end
			end
			p231:apply()
			v356 = v_u_15
			v356.leanFrames = v356.leanFrames + 1
			return true
		else
			if v_u_374 then
				v357 = true
			else
				v373 = v_u_30("RideArc")
				if v373 == nil or v_u_8() == nil then
					v357 = false
				else
					v_u_4.useArc(v373)
					v_u_374 = true
					v357 = true
				end
			end
			if not v357 then
				return false
			end
			v418 = v_u_74(p235, p237)
			v358 = p233:FindFirstChild("Chassis")
			if v418 == nil or (v418.arc == nil or (v358 == nil or not v358:IsA("BasePart"))) then
				return false
			end
			v419 = v_u_3.poseKey(p236.poses, p237, p232:GetAttribute("RideRole"), false, nil)
			if v419 == nil then
				return false
			end
			v383 = v_u_3.poseKey(p236.poses, p237, p232:GetAttribute("RideRole"), true, (v_u_66(p235, p237)))
			v420 = v_u_30("VehLean_" .. p235)
			if v420 == nil then
				v420 = nil
			else
				v421 = v420.seats
				if type(v421) ~= "table" then
					v420 = nil
				end
			end
			if v420 == nil then
				v384 = nil
			else
				v384 = v420.seats[p237]
			end
			v422 = v_u_109[p232]
			if v422 == nil then
				v422 = {
					["L"] = nil,
					["prevVel"] = nil,
					["L"] = v_u_4.newState()
				}
				v_u_109[p232] = v422
			elseif v422.at ~= nil and os.clock() - v422.at > 0.5 then
				v422.L = v_u_4.newState()
				v422.prevVel = nil
				v422.predAt = nil
				v422.prevJ = nil
				v422.out = nil
			end
			v385 = v_u_214(p230)
			v380 = p232:GetAttribute("RideLean") == true
			if p230.isLocal and not v380 then
				v447 = 4
			else
				v447 = 3
			end
		end
	end
end
local function v_u_491(p453, p454, p455, p456) -- name: seated
	-- upvalues: (copy) v_u_55, (copy) v_u_30, (copy) v_u_109, (copy) v_u_66, (ref) v_u_10, (copy) v_u_452, (copy) v_u_15, (ref) v_u_4, (copy) v_u_3, (copy) v_u_108, (copy) v_u_106
	local v457 = p453.model
	local v458
	if p454 == nil then
		v458 = false
	else
		local v459 = p454.joints
		if type(v459) == "table" then
			v458 = p454.joints.Root ~= nil
		else
			v458 = false
		end
	end
	if not v458 then
		return false
	end
	local v460 = v_u_55((tostring(v457:GetAttribute("RideVehicle"))))
	local v461 = v_u_30("VehAnim")
	local v462
	if v460 == nil then
		v462 = nil
	else
		v462 = v460:GetAttribute("VehType")
	end
	if v460 == nil or (v461 == nil or type(v462) ~= "string") then
		return false
	end
	local v463 = v461.clips(v462)
	if v463 ~= nil then
		local v464 = v463.poses
		if type(v464) == "table" then
			local v465 = v457:GetAttribute("RideSeat")
			local v466 = v457:GetAttribute("RideLean") == true
			local v467 = v_u_109[v457]
			if (v467 == nil or (v467.errors or 0) < 3) and (v457:GetAttribute("RideRole") ~= "driver" and (v_u_66(v462, v465) ~= nil and v_u_10 ~= nil)) then
				local v468 = v_u_452
				local v469, v470 = pcall(v468, p453, p454, v457, v460, v461, v462, v463, v465, p455, p456)
				if v469 then
					if v470 then
						if v466 then
							local v471 = v_u_15
							v471.leaned = v471.leaned + 1
						else
							local v472 = v_u_15
							v472.seated = v472.seated + 1
						end
						return true
					end
				else
					local v473 = v_u_15
					v473.leanErrors = v473.leanErrors + 1
					local v474 = v_u_15
					v474.errors = v474.errors + 1
					if v_u_15.errors <= 3 then
						warn("[RidePose] " .. "lean" .. ": " .. tostring(v470))
					end
					local v475 = v_u_109[v457]
					if v475 == nil then
						v475 = {
							["L"] = v_u_4.newState()
						}
						v_u_109[v457] = v475
					end
					v475.errors = (v475.errors or 0) + 1
				end
			end
			local v476 = v_u_3.poseKey
			local v477 = v463.poses
			local v478 = v457:GetAttribute("RideRole")
			local v479
			if v466 then
				v479 = v_u_66(v462, v465)
			else
				v479 = nil
			end
			local v480 = v476(v477, v465, v478, v466, v479)
			if v480 == nil then
				return false
			end
			local v481 = v_u_108[v457]
			if v481 == nil then
				v481 = v_u_3.blendNew()
				v_u_108[v457] = v481
			end
			local v482, v483, v484 = v_u_3.blendStep(v481, v480, p455)
			local v485 = v_u_106
			local v486 = v461.JOINTS
			local v487 = v463.poses[v483]
			local v488
			if v482 == nil then
				v488 = nil
			else
				v488 = v463.poses[v482]
			end
			v485(p454, v486, v487, v488, v484)
			if v466 then
				local v489 = v_u_15
				v489.leaned = v489.leaned + 1
			else
				local v490 = v_u_15
				v490.seated = v490.seated + 1
			end
			return true
		end
	end
	return false
end
local v_u_492 = {}
local v_u_493 = false
local function v_u_503(p494, p495, p496) -- name: lyingFrame
	-- upvalues: (copy) v_u_492
	local v497 = v_u_492[p494.player == nil and 0 or p494.player.UserId]
	local v498 = p495:GetAttribute("VehEject")
	if v497 ~= nil and v497.at == v498 then
		return v497.cf
	end
	local v499 = p494.root
	local v500 = (p496 == nil and 2 or p496.HipHeight) + v499.Size.Y / 2
	local v501 = v499.Position
	local _, v502 = v499.CFrame:ToOrientation()
	return CFrame.new(v501.X, v501.Y - v500 + 0.6, v501.Z) * CFrame.Angles(0, v502, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
end
local function v_u_526(p504, p505) -- name: ejected
	-- upvalues: (ref) v_u_493, (copy) v_u_1, (copy) v_u_492, (copy) v_u_13, (copy) v_u_15, (copy) v_u_3, (copy) v_u_78, (copy) v_u_503
	local v506
	if p505 == nil then
		v506 = false
	else
		local v507 = p505.joints
		if type(v507) == "table" then
			v506 = p505.joints.Root ~= nil
		else
			v506 = false
		end
	end
	if not v506 then
		return false
	end
	local v508 = p504.model
	if not v_u_493 then
		v_u_493 = true
		local function v514()
			-- upvalues: (ref) v_u_1, (ref) v_u_492, (ref) v_u_13
			require(script.Parent.EjectRagdoll).onHandoff(function(p509, p510)
				-- upvalues: (ref) v_u_1, (ref) v_u_492, (ref) v_u_13
				local v511 = v_u_1:GetPlayerByUserId(p509)
				local v512
				if v511 == nil then
					v512 = nil
				else
					v512 = v511.Character
				end
				local v513
				if v512 == nil then
					v513 = nil
				else
					v513 = v512:GetAttribute("VehEject")
				end
				if type(p510) == "table" and type(v513) == "number" then
					v_u_492[p509] = {
						["at"] = v513,
						["cf"] = CFrame.new(p510.x, p510.y, p510.z) * CFrame.Angles(0, v_u_13(p510.yawDeg), 0) * CFrame.Angles(v_u_13(p510.pitchDeg), 0, 0)
					}
				end
			end)
		end
		local v515, v516 = pcall(v514)
		if not v515 then
			v_u_493 = false
			local v517 = v_u_15
			v517.errors = v517.errors + 1
			if v_u_15.errors <= 3 then
				warn("[RidePose] " .. "EjectRagdoll hook" .. ": " .. tostring(v516))
			end
		end
	end
	local v518, v519 = v_u_3.eject(workspace:GetServerTimeNow(), v508:GetAttribute("VehEject"), v508:GetAttribute("ActionEndsAt"))
	if v518 == "done" then
		v_u_492[p504.player == nil and 0 or p504.player.UserId] = nil
		return false
	end
	for v520, v521 in v_u_3.LYING do
		p505:setT(v520, v_u_78(v521[1] * v519, v521[2] * v519, v521[3] * v519))
	end
	local v522 = p504.root
	local v523 = p505.joints.Root
	local v524 = v523.c0:Inverse() * v522.CFrame:ToObjectSpace((v_u_503(p504, v508, p504.hum))) * v523.c1
	p505:setT("Root", CFrame.identity:Lerp(v524, v519))
	p505:apply()
	local v525 = v_u_15
	v525.ejected = v525.ejected + 1
	return true
end
local function v_u_535(p527, p528, p529, p530, p531, p532) -- name: run
	-- upvalues: (copy) v_u_44, (copy) v_u_15, (copy) v_u_526, (copy) v_u_491
	if p530 then
		local v533 = v_u_44()
		if v533 == nil then
			return false
		end
		local v534 = v_u_15
		v534.drive = v534.drive + 1
		return v533.drive(p527, p528, p529) == true
	elseif p531 then
		return v_u_526(p527, p528)
	else
		return v_u_491(p527, p528, p529, p532)
	end
end
local v_u_536 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_9.pose(p537, p538, p539) -- name: pose
	-- upvalues: (copy) v_u_12, (copy) v_u_536, (copy) v_u_535, (copy) v_u_15
	local v540 = p537.model
	local v541 = v540:GetAttribute("VehAnim") == nil and p537.isLocal
	if v541 then
		if v_u_12 == nil then
			v541 = false
		else
			v541 = v_u_12:GetAttribute("PredVehAnim") ~= nil
		end
	end
	local v542 = v540:GetAttribute("Action") == "Eject"
	if not v541 and (not v542 and v540:GetAttribute("RideVehicle") == nil) then
		return false
	end
	local v543 = v_u_536[v540]
	v_u_536[v540] = p539
	local v544
	if v543 == nil then
		v544 = 0.016666666666666666
	else
		local v545 = p539 - v543
		v544 = math.clamp(v545, 0.004166666666666667, 0.1)
	end
	local v546 = v_u_535
	local v547, v548 = pcall(v546, p537, p538, p539, v541, v542, v544)
	if v547 then
		return v548 == true
	end
	local v549 = v_u_15
	v549.errors = v549.errors + 1
	if v_u_15.errors <= 3 then
		warn("[RidePose] " .. "pose" .. ": " .. tostring(v548))
	end
	return false
end
function v_u_9.init(p550, p551) -- name: init
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (copy) v_u_9
	v_u_10 = p550
	v_u_11 = p551
	for _, v_u_552 in {
		"aim",
		"freeze",
		"sway",
		"kick",
		"state"
	} do
		p550.command("ride." .. v_u_552, function(p553)
			-- upvalues: (ref) v_u_9, (copy) v_u_552
			return v_u_9.debug(v_u_552, p553)
		end)
	end
end
function v_u_9.vel(p554) -- name: vel
	-- upvalues: (copy) v_u_12, (ref) v_u_38
	if p554:GetAttribute("VehAnim") == nil and (v_u_12 == nil or (p554 ~= v_u_12.Character or v_u_12:GetAttribute("PredVehAnim") == nil)) then
		return nil
	else
		local v555 = v_u_38
		if v555 == nil then
			return nil
		else
			local v556 = v555.velOverride
			local v557, v558 = pcall(v556, p554)
			if v557 then
				return v558
			else
				return nil
			end
		end
	end
end
function v_u_9.stats() -- name: stats
	-- upvalues: (copy) v_u_15
	return table.clone(v_u_15)
end
function v_u_9.hull(p559, p560, p561) -- name: hull
	-- upvalues: (ref) v_u_374, (copy) v_u_30, (copy) v_u_8, (ref) v_u_4, (copy) v_u_9
	if type(p561) == "table" then
		local v562
		if v_u_374 then
			v562 = true
		else
			local v563 = v_u_30("RideArc")
			if v563 == nil or v_u_8() == nil then
				v562 = false
			else
				v_u_4.useArc(v563)
				v_u_374 = true
				v562 = true
			end
		end
		if v562 then
			local v564 = v_u_30("VehLean_" .. p559)
			if v564 == nil then
				v564 = nil
			else
				local v565 = v564.seats
				if type(v565) ~= "table" then
					v564 = nil
				end
			end
			local v566
			if v564 == nil then
				v566 = nil
			else
				v566 = v564.seats[p560]
			end
			local v567 = p559 .. "/" .. p560
			local v568 = v_u_9._hulls
			if v568 == nil then
				v568 = {}
				v_u_9._hulls = v568
			end
			local v569 = v568[v567]
			if v569 ~= nil and (v569.D == v566 and v569.arc == p561) then
				return v569.hull
			end
			local v570 = v_u_4.hull(p561, v566, p560)
			v568[v567] = {
				["D"] = v566,
				["arc"] = p561,
				["hull"] = v570
			}
			return v570
		end
	end
	return p561
end
function v_u_9.leanInfo(p571) -- name: leanInfo
	-- upvalues: (copy) v_u_12, (copy) v_u_109, (ref) v_u_4
	if not p571 then
		if v_u_12 == nil then
			p571 = nil
		else
			p571 = v_u_12.Character
		end
	end
	if p571 == nil then
		return nil
	end
	local v572 = v_u_109[p571]
	if v572 == nil or v572.out == nil then
		return nil
	end
	local v573 = v572.out
	local v574 = v_u_4.info(v573)
	v574.at = v572.at
	return v574
end
function v_u_9.debug(p575, p576) -- name: debug
	-- upvalues: (copy) v_u_138, (copy) v_u_110, (copy) v_u_12, (copy) v_u_109
	if p575 == "aim" then
		local v577 = p576[1]
		local v578 = tonumber(v577)
		local v579 = p576[2]
		local v580 = tonumber(v579)
		local v581 = v_u_138()
		if v578 == nil then
			v_u_110.aim = nil
			if v581 ~= nil then
				v581.dbgAim = nil
			end
			return "ride.aim off"
		else
			v_u_110.aim = { v578, v580 or 0 }
			if v581 ~= nil then
				v581.dbgAim = { v578, v580 or 0 }
			end
			return string.format("ride.aim phi=%.1f theta=%.1f", v578, v580 or 0)
		end
	else
		if p575 == "freeze" then
			local v582 = p576[1]
			if v582 == nil or string.lower(v582) == "off" then
				v_u_110.freeze = nil
				return "ride.freeze off"
			end
			local v583 = v_u_110
			local v584 = {
				["stance"] = string.upper(v582)
			}
			local v585 = p576[2]
			v584.u = tonumber(v585) or 0
			local v586 = p576[3]
			v584.p = tonumber(v586) or 0
			v583.freeze = v584
			return string.format("ride.freeze %s u=%.1f p=%.1f", v_u_110.freeze.stance, v_u_110.freeze.u, v_u_110.freeze.p)
		end
		if p575 == "sway" then
			local v587 = p576[1]
			local v588 = tonumber(v587) or 0
			local v589 = p576[2]
			local v590 = tonumber(v589) or 0
			local v591 = p576[3]
			local v592 = tonumber(v591) or 1
			v_u_110.accel = {
				["long"] = v588,
				["lat"] = v590,
				["untilT"] = os.clock() + v592
			}
			return string.format("ride.sway long=%.1f lat=%.1f for %.1f s", v588, v590, v592)
		end
		if p575 == "kick" then
			v_u_110.kick = p576[1] or "rifle"
			return "ride.kick " .. v_u_110.kick
		end
		if p575 ~= "state" then
			return "ride." .. p575 .. ": unknown"
		end
		local v593
		if v_u_12 == nil then
			v593 = nil
		else
			v593 = v_u_12.Character
		end
		local v594
		if v593 == nil then
			v594 = nil
		else
			v594 = v_u_109[v593]
		end
		if v594 == nil or v594.out == nil then
			return "ride.state: the local figure is not a lean capable passenger"
		end
		local v595 = v594.out
		local v596 = 0
		for _, v597 in v594.jumps or {} do
			local v598 = v597[2]
			v596 = math.max(v596, v598)
		end
		local v599 = string.format
		local v600 = v595.mode
		local v601 = tostring(v600)
		local v602 = v595.stance
		local v603 = tostring(v602)
		local v604 = v595.clip
		local v605 = tostring(v604)
		local v606 = v595.phi or 0
		local v607 = v595.theta or 0
		local v608 = v595.t or 0
		local v609 = v595.canFire
		local v610 = tostring(v609)
		local v611 = v595.off or 0
		local v612 = v595.legacy
		return v599("ride.state mode=%s stance=%s clip=%s phi=%.1f theta=%.1f t=%.2f canFire=%s off=%.1f legacy=%s pelvis=%.1f rhoCap=%.0f maxJump2s=%.0f deg/s", v601, v603, v605, v606, v607, v608, v610, v611, tostring(v612), v595.pelvis or 0, v595.rhoCap or 0, v596)
	end
end
return v_u_9