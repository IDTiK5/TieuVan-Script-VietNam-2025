-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuShellRoute

local v_u_1 = {
	["MAX_STACK"] = 6
}
local v_u_2 = nil
function v_u_1.setCategories(p3) -- name: setCategories
	-- upvalues: (ref) v_u_2
	v_u_2 = p3
end
function v_u_1.new() -- name: new
	return {
		["stack"] = nil,
		["id"] = nil,
		["sub"] = nil,
		["stack"] = {}
	}
end
function v_u_1.resolve(p4) -- name: resolve
	-- upvalues: (ref) v_u_2
	if type(p4) ~= "string" or p4 == "" then
		return nil, nil
	end
	if v_u_2 == nil then
		local v5, v6 = pcall(function()
			return require(script.Parent.MenuCategories)
		end)
		if not v5 or type(v6) ~= "table" then
			v6 = false
		end
		v_u_2 = v6
	end
	local v7
	if v_u_2 then
		v7 = v_u_2
	else
		v7 = nil
	end
	if v7 == nil then
		return nil, nil
	end
	if v7.byId(p4) ~= nil then
		return p4, nil
	end
	local v8, v9 = v7.fromOldTab(p4)
	return v8, v9
end
function v_u_1.current(p10) -- name: current
	return p10.id, p10.sub
end
function v_u_1.depth(p11) -- name: depth
	return #p11.stack
end
function v_u_1.top(p12) -- name: top
	-- upvalues: (ref) v_u_2
	local v13 = p12.stack[#p12.stack]
	if v13 ~= nil then
		return v13.id, v13.sub
	end
	if p12.id ~= nil then
		if v_u_2 == nil then
			local v14, v15 = pcall(function()
				return require(script.Parent.MenuCategories)
			end)
			if not v14 or type(v15) ~= "table" then
				v15 = false
			end
			v_u_2 = v15
		end
		local v16
		if v_u_2 then
			v16 = v_u_2
		else
			v16 = nil
		end
		if v16 ~= nil and v16.backOf(p12.id) == "hideout" then
			return "hideout", nil
		end
	end
	return nil, nil
end
function v_u_1.go(p17, p18, p19) -- name: go
	-- upvalues: (copy) v_u_1
	if p17.id == p18 and p17.sub == p19 then
		return false
	end
	if p17.id == p18 then
		p17.sub = p19
		return true
	end
	for v20 = #p17.stack, 1, -1 do
		if p17.stack[v20].id ~= p18 then
			continue
		end
		for v21 = #p17.stack, v20, -1 do
			table.remove(p17.stack, v21)
		end
	end
	if p17.id ~= nil then
		local v22 = p17.stack
		local v23 = {
			["id"] = p17.id,
			["sub"] = p17.sub
		}
		table.insert(v22, v23)
		while #p17.stack > v_u_1.MAX_STACK do
			table.remove(p17.stack, 1)
		end
	end
	p17.id = p18
	p17.sub = p19
	return true
end
function v_u_1.home(p24) -- name: home
	p24.stack = {}
	p24.id = nil
	p24.sub = nil
end
function v_u_1.back(p25) -- name: back
	-- upvalues: (ref) v_u_2
	local v26 = table.remove(p25.stack)
	if v26 == nil then
		local v27 = nil
		if p25.id ~= nil then
			if v_u_2 == nil then
				local v28, v29 = pcall(function()
					return require(script.Parent.MenuCategories)
				end)
				if not v28 or type(v29) ~= "table" then
					v29 = false
				end
				v_u_2 = v29
			end
			local v30
			if v_u_2 then
				v30 = v_u_2
			else
				v30 = nil
			end
			v27 = v30 ~= nil and v30.backOf(p25.id) == "hideout" and "hideout" or v27
		end
		p25.id = v27
		p25.sub = nil
		return p25.id, p25.sub
	else
		local v31 = v26.id
		local v32 = v26.sub
		p25.id = v31
		p25.sub = v32
		return p25.id, p25.sub
	end
end
function v_u_1.subOf(p33, p34) -- name: subOf
	if type(p33) == "table" then
		local v35 = p33.subs
		if type(v35) == "table" then
			for _, v36 in p33.subs do
				if v36.id ~= p34 then
					continue
				end
				return v36
			end
			return p33.subs[1]
		end
	end
	return nil
end
function v_u_1.pageKey(p37, p38) -- name: pageKey
	-- upvalues: (copy) v_u_1
	if type(p37) == "table" then
		local v39 = p37.subs
		if type(v39) == "table" then
			local v40 = v_u_1.subOf(p37, p38)
			if v40 == nil then
				return p37.id
			else
				return v40.id
			end
		elseif p38 == nil or p38 == "" then
			local v41 = p37.oldTab
			if type(v41) == "string" then
				return p37.oldTab
			else
				return p37.id
			end
		else
			return p38
		end
	else
		return ""
	end
end
local v_u_42 = {
	["character"] = true,
	["traders"] = true,
	["tasks"] = true,
	["collection"] = true,
	["leaderboard"] = true,
	["store"] = true,
	["settings"] = true,
	["market"] = true
}
function v_u_1.whereTab(p43, p44) -- name: whereTab
	-- upvalues: (copy) v_u_42
	if p43 == nil or p43 == "deploy" then
		return "play"
	elseif p43 == "collection" and p44 == "leaderboard" then
		return "leaderboard"
	elseif v_u_42[p43] == true then
		return p43
	else
		return nil
	end
end
function v_u_1.cycle(p45, p46, p47, p48) -- name: cycle
	local v49 = #p45
	if v49 == 0 then
		return nil
	end
	local v50 = p48 or {}
	local v51 = 0
	for v52, v53 in p45 do
		if v53 ~= p46 then
			continue
		end
		v51 = v52
	end
	if v51 == 0 then
		v51 = p47 >= 0 and 0 or v49 + 1
	end
	for _ = 1, v49 do
		v51 = (v51 - 1 + (p47 >= 0 and 1 or -1)) % v49 + 1
		if v50[p45[v51]] == true then
			continue
		end
		return p45[v51]
	end
	return nil
end
function v_u_1.clockText(p54, p55) -- name: clockText
	if type(p54) ~= "number" or p54 ~= p54 then
		return nil
	end
	local v56 = p54 - p55
	local v57 = math.floor(v56)
	if v57 <= 0 then
		return nil
	end
	local v58 = v57 // 3600
	local v59 = v57 % 3600 // 60
	local v60 = v57 % 60
	return string.format("RAID WINDOW %d:%02d:%02d", v58, v59, v60)
end
function v_u_1.pvpChipText(p61) -- name: pvpChipText
	return p61 and "PVP ON" or "PVP OFF"
end
function v_u_1.viewChipText(p62) -- name: viewChipText
	return p62 == "fptp" and "FP / TP" or "CLASSIC"
end
function v_u_1.badgeText(p63) -- name: badgeText
	local v64 = tonumber(p63)
	if v64 == nil or v64 <= 0 then
		return nil
	end
	local v65 = math.floor(v64)
	return v65 > 9 and "9+" or tostring(v65)
end
function v_u_1.deviceWantsV2(p66) -- name: deviceWantsV2
	if type(p66) ~= "table" then
		return false
	end
	if p66.menuStyle == "v2" then
		return true
	end
	if p66.menuStyle == "classic" then
		return false
	end
	if p66.onPc == true or p66.tenFoot == true then
		return true
	end
	local v67
	if p66.touch == true then
		v67 = p66.keyboard ~= true
	else
		v67 = false
	end
	return v67
end
function v_u_1.deployMode(p68) -- name: deployMode
	return p68 == true and "party" or "page"
end
function v_u_1.pvpPlan(_, p69, p70) -- name: pvpPlan
	return p69 == true and p70 ~= false and "worldSwitch" or "door"
end
function v_u_1.viewPlan(p71, p72, p73) -- name: viewPlan
	local v74 = p73 == "fptp" and "fptp" or "classic"
	return p71 and p72 == true and {
		["kind"] = "worldSwitch",
		["pvp"] = true,
		["view"] = nil,
		["view"] = v74
	} or {
		["kind"] = "setting",
		["pvp"] = nil,
		["view"] = nil,
		["pvp"] = p71,
		["view"] = v74
	}
end
function v_u_1.headerGap(p75) -- name: headerGap
	return p75 and 8 or 12
end
function v_u_1.headerShift(p76, p77, p78) -- name: headerShift
	local v79 = p76.header
	local v80 = p76.back
	local v81 = p76.cash
	local v82 = v79.x + v79.w
	local v83 = v80.x
	if v83 < p77 then
		local v84 = v81.x - p78 - v80.w
		local v85 = v80.x
		local v86 = math.max(v85, v84)
		local v87 = math.min(p77, v86)
		v83 = math.max(v83, v87)
	end
	local v88 = v83 + v80.w + p78
	local v89 = v81.x - p78 - v88
	local v90 = math.max(0, v89)
	if v82 >= v88 then
		v82 = v88
	end
	local v91 = {
		["back"] = {
			["x"] = v83,
			["y"] = v80.y,
			["w"] = v80.w,
			["h"] = v80.h
		},
		["title"] = {
			["x"] = v82,
			["y"] = p76.title.y,
			["w"] = v90,
			["h"] = p76.title.h
		}
	}
	return v91
end
function v_u_1.fitParty(p92, p93, p94, p95) -- name: fitParty
	local v96 = p92.party
	local v97 = p92.invite.x - p94
	local v98 = v97 - p95
	local v99 = math.max(p93, v98)
	if p92.portrait == true then
		local v100 = v96.x
		local v101 = v97 - p95
		v99 = math.max(v100, v101)
	end
	local v102 = math.min(v99, v97)
	local v103 = v96.y
	local v104 = v97 - v102
	return {
		["x"] = v102,
		["y"] = v103,
		["w"] = math.max(0, v104),
		["h"] = v96.h
	}
end
function v_u_1.homeCash(p105, p106, p107, p108, p109) -- name: homeCash
	local v110 = p105.cash
	if p106 <= v110.x or p108 == nil then
		return {
			["x"] = v110.x,
			["y"] = v110.y,
			["w"] = v110.w,
			["h"] = v110.h
		}
	end
	local v111 = p108.x - p109 - p107
	return v111 < p106 and {
		["x"] = v110.x,
		["y"] = v110.y,
		["w"] = v110.w,
		["h"] = v110.h
	} or {
		["x"] = v111,
		["y"] = v110.y,
		["w"] = p107,
		["h"] = v110.h
	}
end
function v_u_1.partyLeftMin(p112, p113, p114, p115) -- name: partyLeftMin
	local v116 = p112.list.x + p112.list.w + p115
	if p112.cash.x < p113 and p112.portrait ~= true then
		local v117 = p113 + p114 + p115
		v116 = math.max(v116, v117)
	end
	return v116
end
function v_u_1.rebuildAllowed(p118, p119, p120, p121) -- name: rebuildAllowed
	for v122 = #p118, 1, -1 do
		if p121 >= p119 - p118[v122] then
			continue
		end
		table.remove(p118, v122)
	end
	if #p118 >= p120 then
		return false
	end
	table.insert(p118, p119)
	return true
end
v_u_1.CARDS_GAP = 8
v_u_1.TASK_H = 76
v_u_1.TASK_H_PHONE = 64
v_u_1.TASK_PAD_X = 16
v_u_1.TASK_RIGHT = 28
v_u_1.TASK_SUB_H = 14
v_u_1.TASK_LABEL_H = 22
v_u_1.TASK_TEXT_GAP = 2
v_u_1.ROW_PAD = 8
v_u_1.MIN_TITLE_ROOM = 100
v_u_1.NARROW_COLUMN = 440
v_u_1.HUNT_MIN_H = 24
function v_u_1.taskH(p123, p124) -- name: taskH
	-- upvalues: (copy) v_u_1
	local v125
	if p124 then
		v125 = v_u_1.TASK_H_PHONE
	else
		v125 = v_u_1.TASK_H
	end
	return math.max(p123, v125)
end
function v_u_1.taskTexts(p126, p127) -- name: taskTexts
	-- upvalues: (copy) v_u_1
	local v128 = (p127 - (v_u_1.TASK_SUB_H + v_u_1.TASK_TEXT_GAP + v_u_1.TASK_LABEL_H)) / 2
	local v129 = math.floor(v128)
	local v130 = math.max(0, v129)
	local v131 = p126 - v_u_1.TASK_PAD_X - v_u_1.TASK_RIGHT
	local v132 = math.max(0, v131)
	local v133 = {
		["sub"] = {
			["x"] = v_u_1.TASK_PAD_X,
			["y"] = v130,
			["w"] = v132,
			["h"] = v_u_1.TASK_SUB_H
		},
		["label"] = {
			["x"] = v_u_1.TASK_PAD_X,
			["y"] = v130 + v_u_1.TASK_SUB_H + v_u_1.TASK_TEXT_GAP,
			["w"] = v132,
			["h"] = v_u_1.TASK_LABEL_H
		}
	}
	return v133
end
function v_u_1.cardsPlan(p134, p135) -- name: cardsPlan
	-- upvalues: (copy) v_u_1
	local v136 = 0
	local v137
	if p134 then
		v137 = p134.w
	else
		v137 = p134
	end
	local v138 = tonumber(v137) or 0
	local v139 = math.max(v136, v138)
	local v140 = 0
	if p134 then
		p134 = p134.h
	end
	local v141 = tonumber(p134) or 0
	local v142 = math.max(v140, v141)
	local v143 = v_u_1.CARDS_GAP
	local v144 = v_u_1.taskH
	local v145
	if p135 then
		v145 = p135.touch
	else
		v145 = p135
	end
	local v146 = tonumber(v145) or 44
	local v147
	if p135 == nil then
		v147 = false
	else
		v147 = p135.phone == true
	end
	local v148 = v144(v146, v147)
	local v149 = {
		["host"] = nil,
		["colW"] = nil,
		["narrow"] = nil,
		["form"] = "row",
		["tutorial"] = nil,
		["tutorialClipped"] = false,
		["tutorialHidden"] = false,
		["task"] = nil,
		["taskH"] = nil,
		["hunt"] = nil,
		["huntKind"] = nil,
		["host"] = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v139,
			["h"] = v142
		},
		["colW"] = v139,
		["narrow"] = v139 < v_u_1.NARROW_COLUMN,
		["taskH"] = v148
	}
	local v150 = v139 < v_u_1.NARROW_COLUMN and 120 or 140
	local v151 = v139 < v_u_1.NARROW_COLUMN and 96 or 112
	v149.titleRoom = v139 - 2 * v_u_1.ROW_PAD - (v150 + v151 + 16 + 8)
	local v152 = v149.titleRoom >= v_u_1.MIN_TITLE_ROOM
	v149.rowOk = v152
	if v139 <= 0 or v142 <= 0 then
		return v149
	end
	local v153
	if p135 == nil then
		v153 = nil
	else
		v153 = p135.tutorial
	end
	local v154
	if type(v153) == "table" then
		v154 = v153.shown == true
	else
		v154 = false
	end
	local v155 = 0
	if v154 then
		local v156 = v153.cardH
		local v157 = tonumber(v156) or 0
		local v158 = math.ceil(v157)
		local v159 = v153.rowH
		local v160 = tonumber(v159) or 0
		local v161 = math.ceil(v160)
		if v158 > 0 and v158 + v143 + v148 <= v142 then
			v149.form = "card"
			v161 = v158
		elseif v152 and v161 + v143 + v148 <= v142 then
			v149.form = "row"
		elseif v158 > 0 and v158 <= v142 then
			v149.form = "card"
			v161 = v158
		elseif v152 then
			v149.form = "row"
			if v142 < v161 then
				v149.tutorialClipped = true
				v161 = v142
			end
		else
			v149.tutorialHidden = true
		end
		if not v149.tutorialHidden then
			v149.tutorial = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v139,
				["h"] = v161
			}
			v155 = v161 + v143
		end
	end
	local v162
	if p135 == nil then
		v162 = nil
	else
		v162 = p135.hunt
	end
	if not v154 and type(v162) == "table" then
		local v163 = v162.kinds
		if type(v163) == "table" then
			for _, v164 in v162.kinds do
				local v165
				if type(v164) == "table" then
					local v166 = v164.w
					local v167 = tonumber(v166) or 0
					v165 = math.ceil(v167)
				else
					v165 = 0
				end
				local v168
				if type(v164) == "table" then
					local v169 = v164.h
					local v170 = tonumber(v169) or 0
					v168 = math.ceil(v170)
				else
					v168 = 0
				end
				if v165 <= 0 or (v168 <= 0 or (v165 > v139 or v168 + v143 + v148 > v142)) then
					continue
				end
				local v171 = (v139 - v165) / 2
				v149.hunt = {
					["x"] = nil,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["x"] = math.floor(v171),
					["w"] = v165,
					["h"] = v168
				}
				local v172 = v164.kind
				v149.huntKind = tostring(v172)
				v155 = v168 + v143
			end
		end
	end
	if v155 + v148 <= v142 then
		v149.task = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v155,
			["w"] = v139,
			["h"] = v148
		}
		local v173 = v_u_1.taskTexts(v139, v148)
		local v174 = v173.sub
		local v175 = v173.label
		v149.taskSub = v174
		v149.taskLabel = v175
	end
	return v149
end
return v_u_1