-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewCamera

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
local v_u_5 = {}
function v_u_4.use(p6) -- name: use
	-- upvalues: (ref) v_u_5
	v_u_5 = type(p6) ~= "table" and {} or p6
end
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = false
local v_u_10 = "FOLLOW"
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = false
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = 0
local v_u_23 = 0
local v_u_24 = 0
local v_u_25 = "none"
local v_u_26 = nil
local v_u_27 = 0
local v_u_28 = 0
local v_u_29 = 0
function v_u_4.onPacket(p30) -- name: onPacket
	-- upvalues: (ref) v_u_14
	v_u_14 = p30
end
function v_u_4.mode() -- name: mode
	-- upvalues: (ref) v_u_10
	return v_u_10
end
function v_u_4.follow() -- name: follow
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_4.loss() -- name: loss
	-- upvalues: (ref) v_u_13, (ref) v_u_5, (copy) v_u_2
	if v_u_13 == nil then
		return nil
	end
	local v31
	if v_u_5.rules == nil then
		v31 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v31 = v_u_5.rules
	end
	return v31.lossPct(v_u_13)
end
function v_u_4.targetRoot() -- name: targetRoot
	-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) v_u_1
	if v_u_5.targetRoot == nil then
		if v_u_8 == nil then
			return nil
		else
			local v32 = v_u_1:GetPlayerByUserId(v_u_8)
			if v32 then
				v32 = v32.Character
			end
			if v32 then
				v32 = v32:FindFirstChild("HumanoidRootPart")
			end
			if v32 and v32:IsA("BasePart") then
				return v32
			else
				return nil
			end
		end
	else
		return v_u_5.targetRoot()
	end
end
function v_u_4.status() -- name: status
	-- upvalues: (ref) v_u_9, (ref) v_u_11, (ref) v_u_20, (ref) v_u_5, (copy) v_u_2, (ref) v_u_10, (copy) v_u_4, (ref) v_u_21
	if not v_u_9 or (v_u_11 == nil or v_u_20 == nil) then
		return "OFF"
	end
	local v33
	if v_u_5.clock == nil then
		v33 = os.clock()
	else
		v33 = v_u_5.clock()
	end
	local v34
	if v_u_5.rules == nil then
		v34 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v34 = v_u_5.rules
	end
	return v34.cameraStatus(v_u_10, v_u_11, v33, v_u_20.has == true, v_u_4.targetRoot() ~= nil and 0 or (v_u_21 == nil and 1000000000 or v33 - v_u_21))
end
function v_u_4.source() -- name: source
	-- upvalues: (ref) v_u_25
	return v_u_25
end
function v_u_4.rootPosition() -- name: rootPosition
	-- upvalues: (ref) v_u_9, (ref) v_u_20
	if not v_u_9 or (v_u_20 == nil or v_u_20.has ~= true) then
		return nil
	end
	local v35 = v_u_20.x
	local v36 = v_u_20.y
	local v37 = v_u_20.z
	return Vector3.new(v35, v36, v37)
end
function v_u_4.focusPoint() -- name: focusPoint
	-- upvalues: (ref) v_u_9, (ref) v_u_18
	if v_u_9 then
		return v_u_18
	else
		return nil
	end
end
function v_u_4.noteInfoRoot(p38, p39, p40) -- name: noteInfoRoot
	-- upvalues: (ref) v_u_9, (ref) v_u_19, (ref) v_u_5, (copy) v_u_2
	if v_u_9 and v_u_19 ~= nil then
		local v41
		if v_u_5.rules == nil then
			v41 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v41 = v_u_5.rules
		end
		local v42
		if v_u_5.clock == nil then
			v42 = os.clock()
		else
			v42 = v_u_5.clock()
		end
		local v43 = v41.rootAge(v_u_19, v42)
		if v43 == nil or v43 > 0.6 then
			v41.rootFeed(v_u_19, p38, p39, p40, v42)
		end
	end
end
local function v_u_49(p44) -- name: onRaw
	-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_2, (ref) v_u_8, (ref) v_u_11, (ref) v_u_13, (ref) v_u_19, (ref) v_u_14
	if v_u_9 then
		local v45
		if v_u_5.rules == nil then
			v45 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v45 = v_u_5.rules
		end
		local v46 = v45.cleanCam(p44)
		if v46 == nil then
			return
		elseif v46.t == nil or (v_u_8 == nil or v46.t == v_u_8) then
			local v47
			if v_u_5.clock == nil then
				v47 = os.clock()
			else
				v47 = v_u_5.clock()
			end
			v45.followFeed(v_u_11, v46, v47)
			v45.lossNote(v_u_13, v46.s, v47)
			if v46.px ~= nil and v_u_19 ~= nil then
				v45.rootFeed(v_u_19, v46.px, v46.py, v46.pz, v47)
			end
			if v_u_14 then
				local v48 = v_u_14
				pcall(v48, v46, v47)
			end
		end
	else
		return
	end
end
v_u_4._onRaw = v_u_49
function v_u_4._connectRemote() -- name: connectRemote
	-- upvalues: (ref) v_u_17, (ref) v_u_5, (copy) v_u_2, (copy) v_u_49
	if not v_u_17 and v_u_5.noRemote ~= true then
		v_u_17 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_49
			local v50 = v_u_2:FindFirstChild("HushNet") or v_u_2:WaitForChild("HushNet", 30)
			if v50 ~= nil then
				local v_u_51 = false
				local v_u_52 = nil
				local function v54(p53) -- name: hook
					-- upvalues: (ref) v_u_51, (ref) v_u_49, (ref) v_u_52
					if not v_u_51 and (p53.Name == "rv.cam.out" and (p53:IsA("UnreliableRemoteEvent") or p53:IsA("RemoteEvent"))) then
						v_u_51 = true
						p53.OnClientEvent:Connect(v_u_49)
						if v_u_52 then
							v_u_52:Disconnect()
							v_u_52 = nil
						end
					end
				end
				local v55 = v50:FindFirstChild("rv.cam.out")
				if v55 then
					v54(v55)
				else
					v_u_52 = v50.ChildAdded:Connect(v54)
				end
			end
		end)
	end
end
function v_u_4._bound() -- name: _bound
	-- upvalues: (ref) v_u_17
	return v_u_17
end
local function v_u_57() -- name: zoomTable
	-- upvalues: (ref) v_u_7
	local v56 = v_u_7 and v_u_7.controllers
	if v56 then
		v56 = v_u_7.controllers.Camera
	end
	return not (v56 and v56.ZOOM_LEVELS) and {
		{
			["dist"] = 80,
			["fov"] = 22
		},
		{
			["dist"] = 104,
			["fov"] = 22
		},
		{
			["dist"] = 132,
			["fov"] = 22
		},
		{
			["dist"] = 176,
			["fov"] = 22
		}
	} or v56.ZOOM_LEVELS
end
local function v_u_59() -- name: holdView
	-- upvalues: (ref) v_u_5
	local v58
	if v_u_5.camera == nil then
		v58 = workspace.CurrentCamera
	else
		v58 = v_u_5.camera()
	end
	if v58 == nil then
		return nil, nil
	else
		return v58.CFrame, v58.FieldOfView
	end
end
local v_u_60 = nil
local function v_u_90(p61) -- name: render
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (ref) v_u_19, (ref) v_u_20, (copy) v_u_4, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (copy) v_u_59, (ref) v_u_60, (ref) v_u_10, (ref) v_u_12, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_11, (ref) v_u_18
	local v62
	if v_u_5.rules == nil then
		v62 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v62 = v_u_5.rules
	end
	if v_u_19 == nil or v_u_20 == nil then
		return nil, nil
	end
	local v63
	if v_u_5.clock == nil then
		v63 = os.clock()
	else
		v63 = v_u_5.clock()
	end
	local v64 = v_u_4.targetRoot()
	if v64 ~= nil then
		local v65 = v64.Position
		local v66 = v65.X
		local v67 = v65.Y
		local v68 = v65.Z
		v_u_21 = v63
		v_u_22 = v66
		v_u_23 = v67
		v_u_24 = v68
	end
	local v69 = v62.pickFocus
	local v70 = v64 ~= nil
	local v71 = v62.rootAge(v_u_19, v63)
	local v72
	if v_u_21 == nil then
		v72 = nil
	else
		v72 = v63 - v_u_21
	end
	local v73 = v69(v70, v71, v72)
	v_u_25 = v73
	local v74, v75, v76
	if v73 == "body" then
		v74 = v_u_22
		v75 = v_u_23
		v76 = v_u_24
	elseif v73 == "packet" then
		v74 = v_u_19.x
		v75 = v_u_19.y
		v76 = v_u_19.z
	else
		if v73 ~= "last" then
			return v_u_59()
		end
		v74 = v_u_22
		v75 = v_u_23
		v76 = v_u_24
	end
	local v77, v78, v79
	if v73 == "body" then
		v77, v78, v79 = v62.posStepBody(v_u_20, v74, v75, v76, p61)
	else
		v77, v78, v79 = v62.posStep(v_u_20, v74, v75, v76, p61)
	end
	local v80 = v_u_5.iso
	if v80 == nil then
		if v_u_60 == nil then
			v_u_60 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Iso"))
		end
		v80 = v_u_60
	end
	local v81
	if v_u_10 == "FREE" then
		v81 = v62.freeStep(v_u_12, p61)
		local v82 = v78 - 0.6
		v_u_27 = v77
		v_u_28 = v82
		v_u_29 = v79
	else
		v81 = v62.followStep(v_u_11, p61)
		local v83 = v77 + v81.ox
		local v84 = v78 + v81.oh
		local v85 = v79 + v81.oo
		v_u_27 = v83
		v_u_28 = v84
		v_u_29 = v85
	end
	local v86 = v_u_27
	local v87 = v_u_28
	local v88 = v_u_29
	local v89 = Vector3.new(v86, v87, v88)
	v_u_18 = v89
	return v80.cameraCFrame(v89, v81.yaw, v80.PITCH, v81.dist), v81.fov
end
v_u_4._render = v_u_90
function v_u_4._xyz() -- name: _xyz
	-- upvalues: (ref) v_u_27, (ref) v_u_28, (ref) v_u_29
	return v_u_27, v_u_28, v_u_29
end
function v_u_4.init(p91) -- name: init
	-- upvalues: (ref) v_u_7, (ref) v_u_17, (ref) v_u_5, (copy) v_u_2, (copy) v_u_49, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (copy) v_u_4, (ref) v_u_12
	v_u_7 = p91
	if not v_u_17 and v_u_5.noRemote ~= true then
		v_u_17 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_49
			local v92 = v_u_2:FindFirstChild("HushNet") or v_u_2:WaitForChild("HushNet", 30)
			if v92 ~= nil then
				local v_u_93 = false
				local v_u_94 = nil
				local function v96(p95) -- name: hook
					-- upvalues: (ref) v_u_93, (ref) v_u_49, (ref) v_u_94
					if not v_u_93 and (p95.Name == "rv.cam.out" and (p95:IsA("UnreliableRemoteEvent") or p95:IsA("RemoteEvent"))) then
						v_u_93 = true
						p95.OnClientEvent:Connect(v_u_49)
						if v_u_94 then
							v_u_94:Disconnect()
							v_u_94 = nil
						end
					end
				end
				local v97 = v92:FindFirstChild("rv.cam.out")
				if v97 then
					v96(v97)
				else
					v_u_94 = v92.ChildAdded:Connect(v96)
				end
			end
		end)
	end
	if p91.on then
		p91.on("camera.rotate", function(p98)
			-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (ref) v_u_4
			if v_u_9 and (v_u_10 == "FREE" and type(p98) == "number") then
				local v99 = v_u_15
				v_u_15 = p98
				if v99 ~= nil and v99 ~= p98 then
					local v100 = (p98 - v99) % 4
					v_u_4.turn(v100 == 1 and 1 or (v100 == 3 and -1 or 0))
				end
			else
				if type(p98) ~= "number" then
					p98 = v_u_15
				end
				v_u_15 = p98
			end
		end)
		p91.on("camera.zoom", function(p101)
			-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5, (ref) v_u_2
			if v_u_9 and (v_u_10 == "FREE" and (type(p101) == "number" and v_u_12 ~= nil)) then
				local v102
				if v_u_5.rules == nil then
					v102 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
				else
					v102 = v_u_5.rules
				end
				local v103 = p101 - v_u_12.level
				if v103 ~= 0 then
					v102.freeInput(v_u_12, 0, v103 > 0 and 1 or -1)
				end
			end
		end)
	end
end
function v_u_4.turn(p104) -- name: turn
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5, (copy) v_u_2
	if v_u_9 and (v_u_10 == "FREE" and (v_u_12 ~= nil and p104 ~= 0)) then
		local v105
		if v_u_5.rules == nil then
			v105 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v105 = v_u_5.rules
		end
		v105.freeInput(v_u_12, p104, 0)
	end
end
function v_u_4.zoom(p106) -- name: zoom
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5, (copy) v_u_2
	if v_u_9 and (v_u_10 == "FREE" and (v_u_12 ~= nil and p106 ~= 0)) then
		local v107
		if v_u_5.rules == nil then
			v107 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v107 = v_u_5.rules
		end
		v107.freeInput(v_u_12, 0, p106)
	end
end
function v_u_4.setMode(p108) -- name: setMode
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11, (copy) v_u_57, (ref) v_u_12
	if p108 == "FOLLOW" or p108 == "FREE" then
		local v109
		if v_u_5.rules == nil then
			v109 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v109 = v_u_5.rules
		end
		if p108 == "FREE" and (v_u_10 ~= "FREE" and v_u_11 ~= nil) then
			local v110 = v_u_57()
			v_u_12 = v109.freeNew(v_u_11.yaw, v109.nearestZoom(v110, v_u_11.dist), v110)
			v_u_12.dist = v_u_11.dist
		end
		v_u_10 = p108
	end
end
function v_u_4.toggle() -- name: toggle
	-- upvalues: (copy) v_u_4, (ref) v_u_10
	v_u_4.setMode(v_u_10 == "FOLLOW" and "FREE" or "FOLLOW")
	return v_u_10
end
function v_u_4.begin(p111) -- name: begin
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (ref) v_u_8, (ref) v_u_11, (ref) v_u_13, (copy) v_u_57, (ref) v_u_12, (ref) v_u_10, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (ref) v_u_9, (ref) v_u_17, (copy) v_u_49, (ref) v_u_7, (ref) v_u_26, (copy) v_u_90, (ref) v_u_16, (copy) v_u_3, (copy) v_u_4
	local v112
	if v_u_5.rules == nil then
		v112 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v112 = v_u_5.rules
	end
	v_u_8 = p111
	v_u_11 = v112.followNew()
	v_u_13 = v112.lossNew()
	local v113 = v_u_57()
	v_u_12 = v112.freeNew(0, 2, v113)
	v_u_10 = "FOLLOW"
	v_u_18 = nil
	v_u_19 = v112.rootNew()
	v_u_20 = v112.posNew()
	v_u_21 = nil
	v_u_22 = 0
	v_u_23 = 0
	v_u_24 = 0
	v_u_25 = "none"
	v_u_9 = true
	if not v_u_17 and v_u_5.noRemote ~= true then
		v_u_17 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_49
			local v114 = v_u_2:FindFirstChild("HushNet") or v_u_2:WaitForChild("HushNet", 30)
			if v114 ~= nil then
				local v_u_115 = false
				local v_u_116 = nil
				local function v118(p117) -- name: hook
					-- upvalues: (ref) v_u_115, (ref) v_u_49, (ref) v_u_116
					if not v_u_115 and (p117.Name == "rv.cam.out" and (p117:IsA("UnreliableRemoteEvent") or p117:IsA("RemoteEvent"))) then
						v_u_115 = true
						p117.OnClientEvent:Connect(v_u_49)
						if v_u_116 then
							v_u_116:Disconnect()
							v_u_116 = nil
						end
					end
				end
				local v119 = v114:FindFirstChild("rv.cam.out")
				if v119 then
					v118(v119)
				else
					v_u_116 = v114.ChildAdded:Connect(v118)
				end
			end
		end)
	end
	local v120 = v_u_7 and v_u_7.controllers
	if v120 then
		v120 = v_u_7.controllers.Camera
	end
	if v120 and v120.setOverride then
		if v120.mode ~= nil and v120.setMode ~= nil then
			local v121 = v120.mode
			local v122, v123 = pcall(v121)
			if v122 and v123 == "scripted" then
				v_u_26 = "scripted"
				local v124 = v120.setMode
				pcall(v124, "iso")
			end
		end
		v120.setOverride(v_u_90)
	end
	if v_u_16 == nil and v_u_5.noInput ~= true then
		v_u_16 = v_u_3.InputChanged:Connect(function(p125, p126)
			-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_4
			if not p126 and (v_u_9 and (v_u_10 == "FREE" and p125.UserInputType == Enum.UserInputType.MouseWheel)) then
				v_u_4.zoom(p125.Position.Z > 0 and -1 or 1)
			end
		end)
	end
end
function v_u_4.retarget(p127) -- name: retarget
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (ref) v_u_5, (copy) v_u_2, (ref) v_u_11, (ref) v_u_8, (ref) v_u_13, (ref) v_u_19, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25
	if v_u_9 then
		local v128
		if v_u_5.rules == nil then
			v128 = require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
		else
			v128 = v_u_5.rules
		end
		local v129 = v_u_11
		v_u_8 = p127
		v_u_11 = v128.followNew()
		if v129 ~= nil then
			local v130 = v_u_11
			local v131 = v_u_11
			local v132 = v_u_11
			local v133 = v_u_11
			local v134 = v_u_11
			local v135 = v_u_11
			local v136 = v129.yaw
			local v137 = v129.dist
			local v138 = v129.fov
			local v139 = v129.ox
			local v140 = v129.oh
			local v141 = v129.oo
			v130.yaw = v136
			v131.dist = v137
			v132.fov = v138
			v133.ox = v139
			v134.oh = v140
			v135.oo = v141
			local v142 = v_u_11
			local v143 = v_u_11
			local v144 = v_u_11
			local v145 = v_u_11
			local v146 = v_u_11
			local v147 = v_u_11
			local v148 = v129.yaw
			local v149 = v129.dist
			local v150 = v129.fov
			local v151 = v129.ox
			local v152 = v129.oh
			local v153 = v129.oo
			v142.tYaw = v148
			v143.tDist = v149
			v144.tFov = v150
			v145.tx = v151
			v146.th = v152
			v147.to = v153
		end
		v_u_13 = v128.lossNew()
		v_u_19 = v128.rootNew()
		v_u_21 = nil
		v_u_22 = 0
		v_u_23 = 0
		v_u_24 = 0
		v_u_25 = "none"
	else
		v_u_4.begin(p127)
	end
end
function v_u_4.finish() -- name: finish
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_25, (ref) v_u_7, (ref) v_u_26, (ref) v_u_16
	if v_u_9 then
		v_u_9 = false
		v_u_8 = nil
		v_u_18 = nil
		v_u_19 = nil
		v_u_20 = nil
		v_u_21 = nil
		v_u_25 = "none"
		local v154 = v_u_7 and v_u_7.controllers
		if v154 then
			v154 = v_u_7.controllers.Camera
		end
		if v154 and v154.setOverride then
			v154.setOverride(nil)
			if v_u_26 ~= nil and v154.setMode ~= nil then
				local v155 = v154.setMode
				local v156 = v_u_26
				pcall(v155, v156)
			end
		end
		v_u_26 = nil
		if v_u_16 then
			v_u_16:Disconnect()
			v_u_16 = nil
		end
	end
end
return v_u_4