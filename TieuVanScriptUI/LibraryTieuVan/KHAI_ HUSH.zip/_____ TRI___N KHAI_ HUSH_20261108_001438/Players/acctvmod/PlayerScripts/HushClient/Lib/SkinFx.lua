-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SkinFx

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {
	["MAX_ACTIVE"] = 6,
	["PARTS"] = 6,
	["LIFE"] = 0.4,
	["GAP"] = 0.4,
	["MAX_DIST"] = 80
}
local v_u_5 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v6, v7 = pcall(function()
	-- upvalues: (copy) v_u_5
	return require(v_u_5:WaitForChild("SkinVisibility", 5))
end)
local v_u_8 = (not v6 or type(v7) ~= "table") and {
	["enabled"] = function() -- name: enabled
		return true
	end
} or v7
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local function v_u_21() -- name: deps
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (ref) v_u_10, (ref) v_u_11
	if v_u_9 == nil then
		local function v12()
			-- upvalues: (ref) v_u_5
			return require(v_u_5:WaitForChild("SkinApply", 5))
		end
		local v13, v14 = pcall(v12)
		if not v13 then
			v14 = false
		end
		v_u_9 = v14
	end
	if v_u_10 == nil then
		local function v15()
			-- upvalues: (ref) v_u_5
			return require(v_u_5:WaitForChild("Skins", 5))
		end
		local v16, v17 = pcall(v15)
		if not v16 then
			v17 = false
		end
		v_u_10 = v17
	end
	if v_u_11 == nil then
		local function v18()
			-- upvalues: (ref) v_u_5
			return require(v_u_5:WaitForChild("SkinFinishes", 5))
		end
		local v19, v20 = pcall(v18)
		if not v19 then
			v20 = false
		end
		v_u_11 = v20
	end
	return v_u_9 and (v_u_10 and v_u_11) and true or false
end
local function v_u_26(p22) -- name: rgb
	if type(p22) == "table" then
		local v23 = p22[1]
		if type(v23) == "number" then
			local v24 = p22[2]
			if type(v24) == "number" then
				local v25 = p22[3]
				if type(v25) == "number" then
					return Color3.fromRGB(p22[1], p22[2], p22[3])
				end
			end
		end
	end
	return nil
end
function v_u_4.pickColor(p27, p28) -- name: pickColor
	-- upvalues: (copy) v_u_26
	if type(p27) ~= "table" then
		return nil
	end
	local v29
	if p28 % 2 == 1 then
		v29 = p27.a
	else
		v29 = p27.b or p27.a
	end
	return v_u_26(v29)
end
local v_u_30 = nil
local function v_u_35(p31, p32) -- name: fxOfRaw
	-- upvalues: (copy) v_u_21, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
	if typeof(p31) == "Instance" and (type(p32) == "string" and v_u_21()) then
		if v_u_8.enabled() then
			local v33 = v_u_9.equippedFor(p31, p32)
			if v33 then
				local v34 = v_u_10.get(v33)
				if v34 then
					v34 = v_u_11.get(v34.finish)
				end
				if v34 then
					v34 = v34.fx
				end
				if type(v34) == "table" and (v34.tracer or (v34.muzzle or v34.kill)) then
					return v34
				else
					return nil
				end
			else
				return nil
			end
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_4.fxOf(p36, p37) -- name: fxOf
	-- upvalues: (copy) v_u_35
	local v38 = v_u_35
	local v39, v40 = pcall(v38, p36, p37)
	if v39 then
		return v40
	else
		return nil
	end
end
local v_u_41 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_49() -- name: buildPool
	-- upvalues: (ref) v_u_30, (copy) v_u_4, (copy) v_u_3
	if v_u_30 == nil then
		local v_u_42 = {
			["list"] = nil,
			["folder"] = nil,
			["conn"] = nil,
			["active"] = 0,
			["list"] = {}
		}
		v_u_30 = v_u_42
		task.defer(function()
			-- upvalues: (ref) v_u_30, (copy) v_u_42, (ref) v_u_4, (ref) v_u_3
			if v_u_30 == v_u_42 then
				local function v48()
					-- upvalues: (ref) v_u_4, (ref) v_u_42, (ref) v_u_3
					local v43 = Instance.new("Folder")
					v43.Name = "SkinFxPool"
					for v44 = 1, v_u_4.MAX_ACTIVE do
						local v45 = {
							["parts"] = nil,
							["active"] = false,
							["t0"] = 0,
							["vel"] = nil,
							["origin"] = Vector3.new(0, 0, 0),
							["kind"] = "pixels",
							["g"] = 0,
							["shooter"] = nil,
							["parts"] = {},
							["vel"] = {}
						}
						for v46 = 1, v_u_4.PARTS do
							local v47 = Instance.new("Part")
							v47.Name = "K" .. v44 .. "_" .. v46
							v47.Anchored = true
							v47.CanCollide = false
							v47.CanQuery = false
							v47.CanTouch = false
							v47.CastShadow = false
							v47.Material = Enum.Material.Neon
							v47.Size = Vector3.new(0.3, 0.3, 0.3)
							v47.Transparency = 1
							v47.CFrame = CFrame.new(0, -500, 0)
							v47.Parent = v43
							v45.parts[v46] = v47
						end
						v_u_42.list[v44] = v45
					end
					v43.Parent = v_u_3
					v_u_42.folder = v43
				end
				if not pcall(v48) then
					v_u_42.list = {}
				end
			end
		end)
	end
end
function v_u_4.tints(p_u_50, p_u_51) -- name: tints
	-- upvalues: (copy) v_u_35, (copy) v_u_1, (copy) v_u_41, (copy) v_u_49, (copy) v_u_4
	local function v55()
		-- upvalues: (ref) v_u_35, (copy) p_u_50, (copy) p_u_51, (ref) v_u_1, (ref) v_u_41, (ref) v_u_49, (ref) v_u_4
		local v52 = v_u_35(p_u_50, p_u_51)
		if not v52 then
			return nil, nil
		end
		if p_u_50 ~= v_u_1.LocalPlayer then
			local v53 = v_u_1.LocalPlayer
			if v53 ~= nil and v53:GetAttribute("SkinFx") == false then
				return nil, nil
			end
		end
		local v54 = (v_u_41[p_u_50] or 0) + 1
		v_u_41[p_u_50] = v54
		if v52.kill then
			v_u_49()
		end
		return v_u_4.pickColor(v52.tracer, v54), v_u_4.pickColor(v52.muzzle, v54)
	end
	local v56, v57, v58 = pcall(v55)
	if v56 then
		return v57, v58
	else
		return nil, nil
	end
end
local v_u_59 = Random.new(3721)
local v_u_60 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_65(p61) -- name: park
	-- upvalues: (ref) v_u_30
	p61.active = false
	p61.shooter = nil
	for _, v62 in p61.parts do
		v62.Transparency = 1
		v62.CFrame = CFrame.new(0, -500, 0)
	end
	if v_u_30 then
		local v63 = v_u_30
		local v64 = v_u_30.active - 1
		v63.active = math.max(0, v64)
		if v_u_30.active == 0 and v_u_30.conn then
			v_u_30.conn:Disconnect()
			v_u_30.conn = nil
		end
	end
end
local function v_u_80() -- name: step
	-- upvalues: (ref) v_u_30, (copy) v_u_4, (copy) v_u_65
	local v66 = os.clock()
	for _, v67 in v_u_30.list do
		if not v67.active then
			continue
		end
		local v68 = v66 - v67.t0
		if v_u_4.LIFE <= v68 then
			v_u_65(v67)
		else
			local v69 = v68 / v_u_4.LIFE
			local v70 = 0.15 + 0.85 * v69 * v69
			for v71, v72 in v67.parts do
				local v73 = v67.vel[v71]
				local v74 = v67.origin + v73 * v68
				local v75 = 0.5 * v67.g * v68 * v68
				local v76 = v74 + Vector3.new(0, v75, 0)
				if v67.kind == "shards" then
					local v77 = CFrame.lookAt
					local v78 = v76 + v73
					local v79 = v67.g * v68
					v72.CFrame = v77(v76, v78 + Vector3.new(0, v79, 0))
				else
					v72.CFrame = CFrame.new(v76)
				end
				v72.Transparency = v70
			end
		end
	end
end
local function v_u_85(p81) -- name: distOk
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4
	local v82 = v_u_1.LocalPlayer
	if v82 == nil then
		return true
	end
	local v83 = v82.Character
	if v83 then
		v83 = v83:FindFirstChild("HumanoidRootPart")
	end
	local v84
	if v83 and v83:IsA("BasePart") then
		v84 = v83.Position
	else
		v84 = v_u_3.CurrentCamera
		if v84 then
			v84 = v_u_3.CurrentCamera.CFrame.Position
		end
	end
	return not v84 and true or (p81 - v84).Magnitude <= v_u_4.MAX_DIST
end
local function v_u_121(p86, p87, p88) -- name: killRaw
	-- upvalues: (ref) v_u_30, (copy) v_u_35, (copy) v_u_49, (copy) v_u_1, (copy) v_u_60, (copy) v_u_4, (copy) v_u_85, (copy) v_u_59, (copy) v_u_2, (copy) v_u_80, (copy) v_u_65
	if typeof(p88) ~= "Vector3" or (v_u_30 == nil or v_u_30.folder == nil) then
		if v_u_30 == nil and (typeof(p86) == "Instance" and v_u_35(p86, p87)) then
			v_u_49()
		end
		return false
	end
	local v89 = v_u_35(p86, p87)
	if v89 then
		v89 = v89.kill
	end
	if not v89 then
		return false
	end
	if p86 ~= v_u_1.LocalPlayer then
		local v90 = v_u_1.LocalPlayer
		if v90 ~= nil and v90:GetAttribute("SkinFx") == false then
			return false
		end
	end
	local v91 = os.clock()
	if v_u_60[p86] and v91 - v_u_60[p86] < v_u_4.GAP then
		return false
	end
	if v_u_30.active >= v_u_4.MAX_ACTIVE or not v_u_85(p88) then
		return false
	end
	local v92 = nil
	for _, v93 in v_u_30.list do
		if v93.active then
			continue
		end
		v92 = v93
	end
	if not v92 then
		return false
	end
	v_u_60[p86] = v91
	local v94 = v89.a
	local v95
	if type(v94) == "table" then
		local v96 = v94[1]
		if type(v96) == "number" then
			local v97 = v94[2]
			if type(v97) == "number" then
				local v98 = v94[3]
				if type(v98) == "number" then
					v95 = Color3.fromRGB(v94[1], v94[2], v94[3])
				else
					v95 = nil
				end
			else
				v95 = nil
			end
		else
			v95 = nil
		end
	else
		v95 = nil
	end
	local v99 = v89.b or v89.a
	local v100
	if type(v99) == "table" then
		local v101 = v99[1]
		if type(v101) == "number" then
			local v102 = v99[2]
			if type(v102) == "number" then
				local v103 = v99[3]
				if type(v103) == "number" then
					v100 = Color3.fromRGB(v99[1], v99[2], v99[3])
				else
					v100 = nil
				end
			else
				v100 = nil
			end
		else
			v100 = nil
		end
	else
		v100 = nil
	end
	local v104 = v89.kind
	local v105 = p88 + Vector3.new(0, 1.2, 0)
	v92.active = true
	v92.t0 = v91
	v92.origin = v105
	v92.kind = v104
	v92.shooter = p86
	v92.g = v104 == "shards" and -26 or (v104 == "embers" and 3 or 0)
	for v106, v107 in v92.parts do
		local v108 = v_u_59:NextNumber(-1, 1)
		local v109 = v_u_59:NextNumber(-0.3, 1)
		local v110 = v_u_59
		local v111 = Vector3.new(v108, v109, v110:NextNumber(-1, 1))
		local v112 = (v111.Magnitude < 0.1 and Vector3.new(0, 1, 0) or v111).Unit
		if v104 == "pixels" then
			v92.vel[v106] = v112 * v_u_59:NextNumber(6, 10)
			v107.Size = Vector3.new(0.34, 0.34, 0.34)
		elseif v104 == "shards" then
			v92.vel[v106] = (v112 + Vector3.new(0, 0.5, 0)).Unit * v_u_59:NextNumber(8, 13)
			v107.Size = Vector3.new(0.12, 0.12, 0.6)
		else
			local v113 = v92.vel
			local v114 = v_u_59:NextNumber(-1.5, 1.5)
			local v115 = v_u_59:NextNumber(3, 6)
			local v116 = v_u_59
			v113[v106] = Vector3.new(v114, v115, v116:NextNumber(-1.5, 1.5))
			v107.Size = Vector3.new(0.22, 0.22, 0.22)
		end
		local v117
		if v106 % 2 == 1 then
			v117 = v95
		else
			v117 = v100
		end
		v107.Color = v117
		v107.Transparency = 0.15
		v107.CFrame = CFrame.new(v92.origin)
	end
	local v118 = v_u_30
	v118.active = v118.active + 1
	if v_u_30.conn == nil then
		v_u_30.conn = v_u_2.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_30, (ref) v_u_80, (ref) v_u_65
			if v_u_30 ~= nil and v_u_30.active ~= 0 then
				local v119 = v_u_80
				if not pcall(v119) then
					for _, v120 in v_u_30.list do
						if not v120.active then
							continue
						end
						v_u_65(v120)
					end
				end
			end
		end)
	end
	return true
end
function v_u_4.killAt(p122, p123, p124) -- name: killAt
	-- upvalues: (copy) v_u_121
	local v125 = v_u_121
	local v126, v127 = pcall(v125, p122, p123, p124)
	if v126 then
		v126 = v127 == true
	end
	return v126
end
function v_u_4.activeCount() -- name: activeCount
	-- upvalues: (ref) v_u_30
	return not v_u_30 and 0 or v_u_30.active
end
function v_u_4.reset() -- name: reset
	-- upvalues: (ref) v_u_30, (copy) v_u_60, (copy) v_u_41
	if v_u_30 then
		if v_u_30.conn then
			v_u_30.conn:Disconnect()
		end
		if v_u_30.folder then
			v_u_30.folder:Destroy()
		end
	end
	v_u_30 = nil
	table.clear(v_u_60)
	table.clear(v_u_41)
end
return v_u_4