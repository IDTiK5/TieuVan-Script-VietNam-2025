-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuBook

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = {
	{
		["id"] = "all",
		["text"] = "All"
	},
	{
		["id"] = "weapon",
		["text"] = "Weapons"
	},
	{
		["id"] = "gear",
		["text"] = "Gear"
	},
	{
		["id"] = "med",
		["text"] = "Medical"
	},
	{
		["id"] = "loot",
		["text"] = "Valuables"
	},
	{
		["id"] = "mat",
		["text"] = "Materials"
	},
	{
		["id"] = "story",
		["text"] = "Story"
	},
	{
		["id"] = "infected",
		["text"] = "Infected"
	}
}
local function v_u_5(p4) -- name: catOf
	return string.find(p4, "^zombie_") and "infected" or ((string.find(p4, "^pistol_") or (string.find(p4, "^rifle_") or (string.find(p4, "^smg_") or (string.find(p4, "^shotgun_") or (string.find(p4, "^revolver_") or (string.find(p4, "^melee_") or (string.find(p4, "^ammo_") or (string.find(p4, "^att_") or string.find(p4, "^throw_"))))))))) and "weapon" or ((string.find(p4, "^vest_") or (string.find(p4, "^helmet_") or (string.find(p4, "^bag_") or (string.find(p4, "^secure_") or (string.find(p4, "^key") or (string.find(p4, "^boots_") or string.find(p4, "^legs_"))))))) and "gear" or ((string.find(p4, "^med_") or string.find(p4, "^food_")) and "med" or (string.find(p4, "^val_") and "loot" or (string.find(p4, "^mat_") and "mat" or "story")))))
end
v_u_1.FOUND_SHORT = "Counts when you carry it out of a raid alive."
v_u_1.FOUND_LONG = "An item counts when you carry it out of a raid alive. Items from traders and lost gear do not count."
function v_u_1.foundCount(p6, p7, p8, p9) -- name: foundCount
	return not p6 and (p7 and "Could not load. Open the tab again." or "Loading...") or ("%d / %d FOUND"):format(p8, p9)
end
function v_u_1.collection(p_u_10, p_u_11) -- name: collection
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_5
	local v_u_12 = p_u_10.ui
	local v_u_13 = p_u_10.theme
	local v_u_14 = v_u_13.color
	local v_u_15 = p_u_10.kit
	local v_u_16 = p_u_10.compact()
	local v_u_17 = {}
	local v_u_18 = p_u_10.collectionKeep
	if type(v_u_18) ~= "table" then
		v_u_18 = {
			["cat"] = "all",
			["zombie"] = nil
		}
		p_u_10.collectionKeep = v_u_18
	end
	local v19 = v_u_18.cat
	local v20 = type(v19) ~= "string" and "all" or v_u_18.cat
	local v_u_21 = nil
	local v_u_22 = false
	local v_u_23 = false
	local v24 = v_u_18.zombie
	local v_u_25
	if type(v24) == "string" then
		v_u_25 = v_u_18.zombie
	else
		v_u_25 = nil
	end
	local _, v_u_26 = v_u_12.panel({
		["parent"] = nil,
		["name"] = "Collection",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 16,
		["parent"] = p_u_11,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v_u_27 = v_u_16 and 250 or 360
	local v28 = v_u_12.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, -v_u_27 - 16, 0, 44)
	}, v_u_26)
	v_u_12.label({
		["parent"] = nil,
		["text"] = "Collection",
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v28,
		["size"] = UDim2.new(0.5, 0, 0, 30)
	})
	local v_u_29 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v28,
		["position"] = UDim2.fromScale(0.5, 0),
		["size"] = UDim2.new(0.5, 0, 0, 30)
	})
	local v30 = v_u_12.label({
		["parent"] = nil,
		["name"] = "FoundNote",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v28,
		["text"] = v_u_1.FOUND_SHORT,
		["color"] = v_u_14.text2,
		["position"] = UDim2.fromOffset(0, 30),
		["size"] = UDim2.new(1, 0, 0, 14)
	})
	v_u_12.tooltip(v_u_29, function()
		-- upvalues: (ref) v_u_1
		return {
			["title"] = "FOUND",
			["body"] = nil,
			["body"] = v_u_1.FOUND_LONG
		}
	end)
	v_u_12.tooltip(v30, function()
		-- upvalues: (ref) v_u_1
		return {
			["title"] = "FOUND",
			["body"] = nil,
			["body"] = v_u_1.FOUND_LONG
		}
	end)
	local v31 = false
	local v_u_32 = v_u_16 and 330 or 420
	for _, v33 in v_u_3 do
		if v33.id ~= v20 then
			continue
		end
		v31 = true
	end
	local v_u_34 = not v31 and "all" or v20
	local _, v_u_36 = v_u_12.tabs({
		["parent"] = v_u_26,
		["tabs"] = v_u_3,
		["selected"] = v_u_34,
		["position"] = UDim2.fromOffset(0, 44),
		["size"] = UDim2.new(1, -v_u_27 - 16, 0, v_u_13.touch(36)),
		["onChange"] = function(p35) -- name: onChange
			-- upvalues: (ref) v_u_34, (ref) v_u_18, (copy) v_u_17
			v_u_34 = p35
			v_u_18.cat = p35
			v_u_17.draw()
		end
	})
	local v_u_37 = 44 + v_u_13.touch(36) + 10
	local v_u_38 = v_u_12.new("ScrollingFrame", {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_37),
		["Size"] = UDim2.new(1, -v_u_27 - 16, 1, -v_u_37),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarThickness"] = v_u_13.scrollBar,
		["ScrollBarImageColor3"] = v_u_14.lineStrong,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, v_u_26)
	local v_u_39 = v_u_12.new("UIGridLayout", {
		["CellSize"] = UDim2.fromOffset(60, 60),
		["CellPadding"] = UDim2.fromOffset(6, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v_u_38)
	v_u_12.pad(v_u_38, {
		0,
		6,
		0,
		6
	})
	local v_u_40 = v_u_12.divider({
		["parent"] = nil,
		["vertical"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_26,
		["position"] = UDim2.new(1, -v_u_27 - 8, 0, 0),
		["size"] = UDim2.new(0, 1, 1, 0)
	})
	local v_u_41 = v_u_12.list({
		["parent"] = nil,
		["name"] = "Sets",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 8,
		["parent"] = v_u_26,
		["position"] = UDim2.new(1, -v_u_27, 0, 0),
		["size"] = UDim2.new(0, v_u_27, 1, 0)
	})
	local v_u_42 = v_u_12.new("Frame", {
		["Name"] = "Detail",
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.new(1, -v_u_32, 0, v_u_37),
		["Size"] = UDim2.new(0, v_u_32, 1, -v_u_37)
	}, v_u_26)
	local v_u_43 = nil
	local function v44()
		-- upvalues: (ref) v_u_43, (copy) p_u_10
		v_u_43 = p_u_10.cctx.lib.MenuBestiary
	end
	pcall(v44)
	local v_u_45 = nil
	local v46 = v_u_43
	if type(v46) == "table" then
		local v47 = v_u_43.new
		if type(v47) == "function" then
			local v48 = v_u_43.new
			local v50 = {
				["visible"] = function() -- name: visible
					-- upvalues: (ref) v_u_23, (copy) p_u_11, (ref) v_u_34
					local v49 = v_u_23 and p_u_11.Visible
					if v49 then
						v49 = v_u_34 == "infected"
					end
					return v49
				end
			}
			local v51, v52 = pcall(v48, p_u_10, v50)
			if v51 then
				v_u_45 = v52
				v_u_45.detail(v_u_42, v_u_32)
			end
		end
	end
	local v_u_53 = not v_u_45 and {
		"walker",
		"runner",
		"crawler",
		"brute",
		"screamer",
		"listener",
		"hazmat",
		"ringer",
		"riot",
		"boss_surgeon",
		"boss_hale"
	} or v_u_43.ORDER
	local v_u_54 = 60
	local function v_u_65() -- name: layout
		-- upvalues: (ref) v_u_34, (ref) v_u_45, (copy) v_u_32, (copy) v_u_27, (copy) v_u_37, (copy) v_u_38, (copy) v_u_40, (copy) v_u_41, (copy) v_u_42, (copy) v_u_16, (copy) v_u_13, (ref) v_u_54, (copy) v_u_39
		local v55
		if v_u_34 == "infected" then
			v55 = v_u_45 ~= nil
		else
			v55 = false
		end
		local v56
		if v55 then
			v56 = v_u_32
		else
			v56 = v_u_27
		end
		local v57 = not v55 and 0 or v_u_37
		v_u_38.Size = UDim2.new(1, -v56 - 16, 1, -v_u_37)
		v_u_40.Position = UDim2.new(1, -v56 - 8, 0, v57)
		v_u_40.Size = UDim2.new(0, 1, 1, -v57)
		v_u_41.Visible = not v55
		v_u_42.Visible = v55
		local v58
		if v55 then
			v58 = v_u_16 and 92 or 150
		else
			v58 = v_u_16 and 60 or 76
		end
		local v59 = v_u_13.safeRefSize().X - 48 - 32 - v56 - 16 - 9
		local v60 = (v59 + 6) / (v58 + 6)
		local v61 = math.floor(v60)
		local v62 = math.max(v55 and 3 or 4, v61)
		local v63 = (v59 + 6) / v62
		local v64 = math.floor(v63) - 6
		v_u_54 = math.max(48, v64)
		v_u_39.CellSize = UDim2.fromOffset(v_u_54, v_u_54)
	end
	local function v_u_87() -- name: allKeys
		-- upvalues: (copy) p_u_10, (ref) v_u_5, (ref) v_u_53
		local v66 = {}
		local function v67()
			-- upvalues: (ref) p_u_10
			return p_u_10.cctx.shared.Items
		end
		local v68, v69 = pcall(v67)
		if v68 and type(v69) == "table" then
			local v70 = v69.all
			if type(v70) == "function" then
				local v71 = v69.all
				local v72, v73 = pcall(v71)
				if v72 and type(v73) == "table" then
					local v74 = table.clone(v73)
					table.sort(v74, function(p75, p76)
						-- upvalues: (ref) v_u_5
						local v77 = v_u_5(p75.id)
						local v78 = v_u_5(p76.id)
						if v77 == v78 then
							if (p75.shown or (p75.rarity or 1)) == (p76.shown or (p76.rarity or 1)) then
								return p75.id < p76.id
							else
								return (p75.shown or (p75.rarity or 1)) > (p76.shown or (p76.rarity or 1))
							end
						else
							return v77 < v78
						end
					end)
					local v_u_79 = false
					local function v80()
						-- upvalues: (ref) v_u_79, (ref) p_u_10
						v_u_79 = p_u_10.cctx.config.flag("VhsTapes") == true
					end
					pcall(v80)
					local v81 = v_u_79
					for _, v82 in v74 do
						if not v81 and string.find(v82.id, "^vhs_") then
							continue
						end
						local v83 = v82.tags
						if type(v83) == "table" and table.find(v82.tags, "displayOnly") then
							continue
						end
						local v84 = v82.id
						table.insert(v66, v84)
					end
				end
			end
		end
		for _, v85 in v_u_53 do
			local v86 = "zombie_" .. v85
			table.insert(v66, v86)
		end
		return v66
	end
	local function v_u_98(p88) -- name: zstate
		-- upvalues: (ref) v_u_21
		local v89 = v_u_21
		local v90
		if type(v89) == "table" then
			local v91 = v_u_21.entries
			v90 = type(v91) == "table" and (v_u_21.entries or {}) or {}
		else
			v90 = {}
		end
		if v90["zombie_" .. p88] ~= true then
			local v92 = v_u_21
			local v93
			if type(v92) == "table" then
				local v94 = v_u_21.entries
				v93 = type(v94) == "table" and (v_u_21.entries or {}) or {}
			else
				v93 = {}
			end
			if v93["zaway_" .. p88] ~= true then
				local v95 = v_u_21
				local v96
				if type(v95) == "table" then
					local v97 = v_u_21.seen
					if type(v97) == "table" then
						v96 = v_u_21.seen or nil
					else
						v96 = nil
					end
				else
					v96 = nil
				end
				return v96 and v96[p88] == true and "seen" or false
			end
		end
		return true
	end
	local function v_u_100(p99) -- name: pick
		-- upvalues: (ref) v_u_45, (ref) v_u_18, (ref) v_u_34, (ref) v_u_25, (copy) v_u_36, (copy) v_u_98
		if v_u_45 then
			v_u_18.zombie = p99
			if v_u_34 == "infected" then
				v_u_45.select(p99, (v_u_98(p99)))
			else
				v_u_25 = p99
				v_u_36.select("infected")
			end
		else
			return
		end
	end
	local function v_u_102(p101) -- name: focusPick
		-- upvalues: (ref) v_u_45, (ref) v_u_34, (ref) v_u_18, (copy) v_u_98
		if v_u_45 and v_u_34 == "infected" then
			v_u_18.zombie = p101
			v_u_45.select(p101, (v_u_98(p101)))
		end
	end
	function v_u_17.draw() -- name: draw
		-- upvalues: (copy) v_u_65, (copy) v_u_12, (copy) v_u_26, (ref) v_u_45, (copy) v_u_15, (copy) v_u_38, (copy) v_u_41, (ref) v_u_21, (ref) v_u_43, (copy) v_u_98, (ref) v_u_53, (copy) v_u_87, (ref) v_u_34, (ref) v_u_5, (ref) v_u_23, (ref) v_u_54, (copy) v_u_100, (copy) v_u_102, (copy) v_u_29, (ref) v_u_1, (ref) v_u_22, (copy) p_u_10, (copy) v_u_14, (copy) v_u_13, (ref) v_u_25, (ref) v_u_18
		v_u_65()
		v_u_12.keepScroll(v_u_26, function()
			-- upvalues: (ref) v_u_45, (ref) v_u_15, (ref) v_u_38, (ref) v_u_41, (ref) v_u_21, (ref) v_u_43, (ref) v_u_98, (ref) v_u_53, (ref) v_u_87, (ref) v_u_34, (ref) v_u_5, (ref) v_u_23, (ref) v_u_54, (ref) v_u_100, (ref) v_u_102, (ref) v_u_29, (ref) v_u_1, (ref) v_u_22, (ref) v_u_12, (ref) p_u_10, (ref) v_u_14, (ref) v_u_13, (ref) v_u_25, (ref) v_u_18
			if v_u_45 then
				v_u_45.detach()
			end
			v_u_15.clear(v_u_38)
			v_u_15.clear(v_u_41)
			local v103 = v_u_21
			local v104
			if type(v103) == "table" then
				local v105 = v_u_21.entries
				v104 = type(v105) == "table" and v_u_21.entries or {}
			else
				v104 = {}
			end
			if v_u_45 then
				local v106 = v_u_43.order
				if type(v106) == "function" then
					local v107 = v_u_43.order
					local v108 = v_u_98
					local v109, v110 = pcall(v107, v108)
					if v109 and (type(v110) == "table" and #v110 > 0) then
						v_u_53 = v110
					end
				end
			end
			local v111 = v_u_87()
			local v112 = #v111
			local v113 = 0
			local v114 = 0
			for _, v115 in v111 do
				local v116 = v104[v115] == true
				if v116 then
					v113 = v113 + 1
				end
				if v_u_34 ~= "all" and v_u_5(v115) ~= v_u_34 then
					continue
				end
				v114 = v114 + 1
				if v_u_45 and (v_u_5(v115) == "infected" and v_u_23) then
					local v117 = string.sub(v115, 8)
					v_u_45.cell(v_u_38, v117, v116 and true or v_u_98(v117), v_u_54, v114, v_u_100, v_u_102)
				else
					local v118 = v_u_21
					local v119 = type(v118) == "table"
					local v120 = v_u_15.itemCell
					local v121 = v_u_38
					local v122 = v115
					local v123 = {
						["size"] = v_u_54
					}
					local v124
					if v119 then
						v124 = not v116
					else
						v124 = v119
					end
					v123.dim = v124
					local v125 = v119 and not v116
					if v125 then
						v125 = v_u_5(v115) == "infected"
					end
					v123.hideName = v125
					v123.order = v114
					v120(v121, v122, v123)
				end
			end
			local v126 = v_u_21
			v_u_29.Text = v_u_1.foundCount(type(v126) == "table", v_u_22, v113, v112)
			v_u_12.label({
				["parent"] = nil,
				["text"] = "Sets",
				["style"] = "h3",
				["order"] = 0,
				["size"] = nil,
				["parent"] = v_u_41,
				["size"] = UDim2.new(1, 0, 0, 26)
			})
			local v127 = v_u_21
			local v128
			if type(v127) == "table" then
				local v129 = v_u_21.sets
				if type(v129) == "table" then
					v128 = v_u_21.sets or nil
				else
					v128 = nil
				end
			else
				v128 = nil
			end
			if v128 then
				local v_u_130 = nil
				local function v131()
					-- upvalues: (ref) v_u_130, (ref) p_u_10
					v_u_130 = p_u_10.cctx.shared.Tasks
				end
				pcall(v131)
				local v132 = {}
				for _, v133 in v_u_130 and v_u_130.collectionSets or {} do
					if type(v133) ~= "table" or v133.flag == nil then
						continue
					end
					local v134 = v133.id
					v132[tostring(v134)] = v133.flag
				end
				v128 = {}
				for _, v135 in v128 do
					local v_u_136
					if type(v135) == "table" then
						local v137 = v135.id
						v_u_136 = v132[tostring(v137)] or nil
					else
						v_u_136 = nil
					end
					local function v138()
						-- upvalues: (copy) v_u_136, (ref) p_u_10
						return v_u_136 == nil and true or p_u_10.cctx.config.flag(v_u_136) == true
					end
					local v139, v140 = pcall(v138)
					if not (v139 and v140) then
						continue
					end
					table.insert(v128, v135)
				end
			end
			if not v128 then
				local v_u_141 = nil
				local function v142()
					-- upvalues: (ref) v_u_141, (ref) p_u_10
					v_u_141 = p_u_10.cctx.shared.Tasks
				end
				pcall(v142)
				v128 = {}
				for _, v_u_143 in v_u_141 and v_u_141.collectionSets or {} do
					local function v144()
						-- upvalues: (copy) v_u_143, (ref) p_u_10
						return v_u_143.flag == nil and true or p_u_10.cctx.config.flag(v_u_143.flag) == true
					end
					local v145, v146 = pcall(v144)
					if not (v145 and v146) then
						continue
					end
					local v147 = 0
					for _, v148 in v_u_143.entries do
						if not v104[v148] then
							continue
						end
						v147 = v147 + 1
					end
					local v149 = {
						["id"] = nil,
						["name"] = nil,
						["desc"] = nil,
						["have"] = nil,
						["total"] = nil,
						["done"] = nil,
						["reward"] = nil,
						["unknown"] = true,
						["id"] = v_u_143.id,
						["name"] = v_u_143.name,
						["desc"] = v_u_143.desc,
						["have"] = v147,
						["total"] = #v_u_143.entries,
						["done"] = #v_u_143.entries <= v147,
						["reward"] = v_u_143.reward
					}
					table.insert(v128, v149)
				end
			end
			for v150, v_u_151 in v128 do
				local v152, v153 = v_u_15.card(v_u_41, {
					["order"] = nil,
					["gap"] = 4,
					["padding"] = 12,
					["order"] = v150
				})
				local v154 = v_u_151.have
				local v155 = tonumber(v154) or 0
				local v156 = v_u_151.total
				local v157 = tonumber(v156) or 1
				local v158 = math.max(1, v157)
				local v159
				if v_u_151.done == true then
					v159 = v158 <= v155
				else
					v159 = false
				end
				v152.Size = UDim2.new(1, -6, 0, 0)
				local v160 = v_u_12.label
				local v161 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "h3",
					["textSize"] = 16,
					["order"] = 1,
					["size"] = nil,
					["color"] = nil,
					["parent"] = v153
				}
				local v162 = v_u_151.name
				v161.text = tostring(v162)
				v161.size = UDim2.new(1, 0, 0, 20)
				local v163
				if v159 then
					v163 = v_u_14.success
				else
					v163 = v_u_14.text
				end
				v161.color = v163
				v160(v161)
				local v164 = v_u_12.label
				local v165 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v153
				}
				local v166 = v_u_151.desc or ""
				v165.text = tostring(v166)
				v164(v165)
				local v_u_167 = nil
				local function v168()
					-- upvalues: (ref) v_u_167, (ref) p_u_10, (copy) v_u_151
					v_u_167 = p_u_10.cctx.shared.CollectionHome.note(v_u_151.id)
				end
				pcall(v168)
				if v_u_167 then
					v_u_12.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 3,
						["color"] = nil,
						["parent"] = v153,
						["text"] = v_u_167,
						["color"] = v_u_14.accent
					})
				end
				local v169 = v_u_151.unknown == true
				if not v169 then
					local v170 = v_u_15.bar
					local v171 = {
						["value"] = nil,
						["color"] = nil,
						["order"] = 4,
						["value"] = v155 / v158
					}
					local v172
					if v159 then
						v172 = v_u_14.success
					else
						v172 = v_u_14.accent
					end
					v171.color = v172
					v170(v153, v171)
				end
				local v173 = v_u_151.reward
				local v174 = type(v173) == "table" and (v_u_151.reward or {}) or {}
				local v175 = {}
				if v174.cash then
					local v176 = v_u_15.money
					local v177 = v174.cash
					table.insert(v175, v176(v177))
				end
				if v174.title then
					local v178 = string.upper
					local v179 = string.gsub
					local v180 = v174.title
					local v181 = "title " .. v178((v179(tostring(v180), "_", " ")))
					table.insert(v175, v181)
				end
				local v182 = ("%d / %d  \194\183  %s"):format(v155, v158, table.concat(v175, ", "))
				if v169 then
					v182 = #v175 <= 0 and "" or "Reward: " .. table.concat(v175, ", ")
				elseif v_u_151.done == true and not v159 then
					v182 = ("%d / %d  \194\183  reward paid"):format(v155, v158)
				end
				if v_u_13.isPhone() then
					v_u_12.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "monoS",
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 5,
						["parent"] = v153,
						["text"] = v182
					})
				else
					v_u_12.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "monoS",
						["order"] = 5,
						["size"] = nil,
						["parent"] = v153,
						["text"] = v182,
						["size"] = UDim2.new(1, 0, 0, 16)
					})
				end
			end
			if v_u_45 and (v_u_34 == "infected" and v_u_23) then
				local v183 = v_u_25 or v_u_45.stats().selected
				v_u_25 = nil
				if not v183 then
					for _, v184 in v_u_53 do
						if v_u_98(v184) == false then
							continue
						end
						v183 = v184
					end
				end
				local v185 = v183 or v_u_53[1]
				v_u_18.zombie = v185
				v_u_45.select(v185, (v_u_98(v185)))
			end
		end)
	end
	function v_u_17.show() -- name: show
		-- upvalues: (ref) v_u_23, (ref) v_u_45, (ref) v_u_21, (copy) p_u_10, (ref) v_u_22, (copy) p_u_11, (copy) v_u_17
		v_u_23 = true
		if v_u_45 then
			v_u_45.start()
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_21, (ref) p_u_10, (ref) v_u_22, (ref) p_u_11, (ref) v_u_23, (ref) v_u_17
			v_u_21 = p_u_10.fetch("collection", nil, 30)
			v_u_22 = v_u_21 == nil
			if p_u_11.Parent and v_u_23 then
				v_u_17.draw()
			end
		end)
		v_u_17.draw()
	end
	function v_u_17.hide() -- name: hide
		-- upvalues: (ref) v_u_23, (ref) v_u_45
		v_u_23 = false
		if v_u_45 then
			v_u_45.stop()
		end
	end
	local v_u_186 = {
		["conn"] = nil,
		["init"] = false,
		["last"] = nil,
		["dead"] = false
	}
	task.spawn(function()
		-- upvalues: (copy) p_u_10, (copy) v_u_186, (ref) v_u_23, (copy) p_u_11, (copy) v_u_17, (ref) v_u_21
		local v187 = p_u_10.cctx.config.watchFlag
		local function v190(p188)
			-- upvalues: (ref) v_u_186, (ref) p_u_10, (ref) v_u_23, (ref) p_u_11, (ref) v_u_17, (ref) v_u_21
			if v_u_186.init then
				if p188 ~= v_u_186.last and not v_u_186.dead then
					v_u_186.last = p188
					local function v189()
						-- upvalues: (ref) p_u_10
						p_u_10.cache.collection = nil
					end
					pcall(v189)
					if v_u_23 and p_u_11.Parent then
						v_u_17.draw()
						task.spawn(function()
							-- upvalues: (ref) v_u_21, (ref) p_u_10, (ref) v_u_23, (ref) p_u_11, (ref) v_u_186, (ref) v_u_17
							v_u_21 = p_u_10.fetch("collection", nil, 0)
							if v_u_23 and (p_u_11.Parent and not v_u_186.dead) then
								v_u_17.draw()
							end
						end)
					end
				end
			else
				v_u_186.init = true
				v_u_186.last = p188
				return
			end
		end
		local v191, v192 = pcall(v187, "VhsTapes", v190)
		if v191 and v192 then
			if v_u_186.dead then
				v192:Disconnect()
				return
			end
			v_u_186.conn = v192
		end
	end)
	function v_u_17.refresh(p193) -- name: refresh
		-- upvalues: (ref) v_u_23, (copy) v_u_17
		if p193 == "profile" and v_u_23 then
			v_u_17.show()
		end
	end
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (ref) v_u_23, (copy) v_u_186, (ref) v_u_45
		v_u_23 = false
		v_u_186.dead = true
		if v_u_186.conn then
			v_u_186.conn:Disconnect()
			v_u_186.conn = nil
		end
		if v_u_45 then
			v_u_45.stop()
		end
	end
	return v_u_17
end
local v_u_194 = {
	{
		["id"] = "totalValue",
		["text"] = "Total score",
		["col"] = "Total score",
		["money"] = true
	},
	{
		["id"] = "extracts",
		["text"] = "Extracts",
		["col"] = "Extracts",
		["money"] = false
	},
	{
		["id"] = "bestValue",
		["text"] = "Best raid",
		["col"] = "Best raid score",
		["money"] = true
	}
}
local v_u_195 = {
	["weekly"] = { "Weekly leaderboard", "Loot you found yourself and carried out alive this week. Survival counts, not kills." },
	["alltime"] = { "All-time leaderboard", "Loot you found yourself and carried out alive. Survival counts, not kills." },
	["factions"] = { "Faction war", "Doc, Gunner and Rook compete every week. The best average per raider wins." },
	["clans"] = { "Clan ranking", "The best clans of this week. Total points count everything a clan earned so far." }
}
function v_u_1.diffTabs(p196) -- name: diffTabs
	local v197, v198 = pcall(function()
		return require((script.Parent:WaitForChild("MenuPlayPvpve", 5)))
	end)
	if v197 and type(v198) == "table" then
		return v198.leaderTabs(p196)
	else
		return p196
	end
end
function v_u_1.boardTexts(p199, p200, p201, p202) -- name: boardTexts
	-- upvalues: (copy) v_u_195, (copy) v_u_194
	local v203
	if type(p202) == "table" then
		local v204 = p202.Hard
		v203 = tonumber(v204) or 1.5
	else
		v203 = 1.5
	end
	local v205
	if type(p202) == "table" then
		local v206 = p202.Nightmare
		v205 = tonumber(v206) or 2
	else
		v205 = 2
	end
	local v207 = ("Score: loot you found yourself, at trader prices. Hard counts x%s, Nightmare x%s."):format(string.format("%g", v203), string.format("%g", v205))
	if p199 == "weekly" then
		return p200 == "All" and {
			["title"] = "Weekly leaderboard",
			["sub"] = nil,
			["col"] = "Score",
			["sub"] = v207
		} or {
			["title"] = "Weekly leaderboard",
			["sub"] = nil,
			["col"] = "Extracted value",
			["sub"] = v_u_195.weekly[2]
		}
	end
	if p199 ~= "alltime" then
		return p199 == "clans" and {
			["title"] = nil,
			["sub"] = nil,
			["col"] = "",
			["title"] = v_u_195.clans[1],
			["sub"] = v_u_195.clans[2]
		} or {
			["title"] = nil,
			["sub"] = nil,
			["col"] = "",
			["title"] = v_u_195.factions[1],
			["sub"] = v_u_195.factions[2]
		}
	end
	local v208 = "Total score"
	for _, v209 in v_u_194 do
		if v209.id ~= p201 then
			continue
		end
		v208 = v209.col
	end
	return p201 == "extracts" and {
		["title"] = "All-time leaderboard",
		["sub"] = "Every extract counts, on any difficulty. Survival counts, not kills.",
		["col"] = nil,
		["col"] = v208
	} or {
		["title"] = "All-time leaderboard",
		["sub"] = nil,
		["col"] = nil,
		["sub"] = v207,
		["col"] = v208
	}
end
function v_u_1.ownRow(p210, p211, p212) -- name: ownRow
	local v213 = tonumber(p210)
	local v214 = tonumber(p211) or 0
	local v215 = math.max(0, v214)
	return v213 and {
		["rank"] = nil,
		["note"] = "",
		["rank"] = ("#%d"):format(v213)
	} or (p212 and {
		["rank"] = "offline",
		["note"] = "The global board could not be read. Your value counts when it is back."
	} or (v215 > 0 and {
		["rank"] = "100+",
		["note"] = "Only the top 100 get a number. Your value counts."
	} or {
		["rank"] = "none",
		["note"] = "Nothing counted yet. Extract with loot you found yourself."
	}))
end
function v_u_1.rewardsLine(p216, p217) -- name: rewardsLine
	local v218 = tonumber(p216) or 100000
	local v219 = math.floor(v218)
	return ("At the reset (All board): top 100 get the title TOP 100. Places 1 to 3 with a score of $%s or more also get LEADERBOARD TOP 1, 2 or 3. Log in during the next week to collect."):format(p217((math.max(0, v219))))
end
function v_u_1.leaderboard(p_u_220, p_u_221) -- name: leaderboard
	-- upvalues: (copy) v_u_195, (copy) v_u_1, (copy) v_u_194, (copy) v_u_2
	local v_u_222 = p_u_220.ui
	local v223 = p_u_220.theme
	local v_u_224 = v223.color
	local v_u_225 = p_u_220.kit
	local v_u_226 = {}
	local v_u_227 = "weekly"
	local v_u_228 = "All"
	local v_u_229 = "totalValue"
	local v_u_230 = nil
	local v_u_231 = 0
	local v_u_232 = nil
	local v_u_233 = nil
	local function v234()
		-- upvalues: (ref) v_u_233, (copy) p_u_220
		v_u_233 = p_u_220.cctx.lib.MenuTipOnce
	end
	pcall(v234)
	local v_u_235 = nil
	local v_u_236 = false
	local v_u_237 = false
	local function v238()
		-- upvalues: (ref) v_u_237, (copy) p_u_220
		v_u_237 = p_u_220.cctx.shared.GameMode.rule("clans") == true
	end
	pcall(v238)
	local v239 = v223.safeRefSize().X - 48
	local v_u_240 = math.min(1100, v239)
	local _, v241 = v_u_222.panel({
		["parent"] = nil,
		["name"] = "Leaderboard",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["padding"] = 16,
		["parent"] = p_u_221,
		["position"] = UDim2.new(0.5, 0, 0, 8),
		["anchor"] = Vector2.new(0.5, 0),
		["size"] = UDim2.new(0, v_u_240, 1, -8)
	})
	local v242 = v_u_222.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 58)
	}, v241)
	local v_u_243 = v_u_222.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v242,
		["text"] = v_u_195.weekly[1],
		["size"] = UDim2.new(0.55, 0, 0, 30)
	})
	local v_u_244 = v_u_222.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = nil,
		["style"] = "small",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v242,
		["text"] = v_u_195.weekly[2],
		["position"] = UDim2.fromOffset(0, 32),
		["size"] = UDim2.new(0.62, 0, 0, 26)
	})
	v_u_244.TextWrapped = true
	v_u_244.TextYAlignment = Enum.TextYAlignment.Top
	v_u_244.TextTruncate = Enum.TextTruncate.AtEnd
	local function v_u_245() end
	local v_u_246 = v_u_222.label({
		["parent"] = nil,
		["name"] = "Reset",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v242,
		["position"] = UDim2.new(0.62, 0, 0, 38),
		["size"] = UDim2.new(0.38, 0, 0, 18)
	})
	local v_u_248, v_u_249 = v_u_222.tabs({
		["parent"] = nil,
		["name"] = "DiffTabs",
		["position"] = nil,
		["size"] = nil,
		["tabs"] = nil,
		["selected"] = "All",
		["onChange"] = nil,
		["parent"] = v241,
		["position"] = UDim2.fromOffset(0, 60),
		["size"] = UDim2.new(1, 0, 0, v223.touch(36)),
		["tabs"] = v_u_1.diffTabs({
			{
				["id"] = "All",
				["text"] = "All"
			},
			{
				["id"] = "Normal",
				["text"] = "Normal"
			},
			{
				["id"] = "Hard",
				["text"] = "Hard"
			},
			{
				["id"] = "Nightmare",
				["text"] = "Nightmare"
			}
		}),
		["onChange"] = function(p247) -- name: onChange
			-- upvalues: (ref) v_u_228, (ref) v_u_245, (copy) v_u_226
			v_u_228 = p247
			v_u_245()
			v_u_226.load()
		end
	})
	local v_u_250 = v_u_233
	local v_u_251 = v_u_237
	local v_u_252 = v_u_228
	local v_u_253 = v_u_245
	local v254 = {}
	local v_u_255 = nil
	for _, v256 in v_u_194 do
		local v257 = {
			["id"] = v256.id,
			["text"] = v256.text
		}
		table.insert(v254, v257)
	end
	local v_u_259, v_u_260 = v_u_222.tabs({
		["parent"] = nil,
		["name"] = "StatTabs",
		["position"] = nil,
		["size"] = nil,
		["tabs"] = nil,
		["selected"] = "totalValue",
		["onChange"] = nil,
		["parent"] = v241,
		["position"] = UDim2.fromOffset(0, 60),
		["size"] = UDim2.new(1, 0, 0, v223.touch(36)),
		["tabs"] = v254,
		["onChange"] = function(p258) -- name: onChange
			-- upvalues: (ref) v_u_229, (ref) v_u_253, (copy) v_u_226
			v_u_229 = p258
			v_u_253()
			v_u_226.load()
		end
	})
	v_u_259.Visible = false
	local v261 = 60 + v223.touch(36) + 8
	local v_u_262 = v_u_222.new("Frame", {
		["Name"] = "Cols",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v261),
		["Size"] = UDim2.new(1, 0, 0, 22)
	}, v241)
	v_u_222.label({
		["parent"] = nil,
		["text"] = "Rank",
		["style"] = "micro",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_262,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(0, 80, 1, 0)
	})
	v_u_222.label({
		["parent"] = nil,
		["text"] = "Survivor",
		["style"] = "micro",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_262,
		["position"] = UDim2.fromOffset(100, 0),
		["size"] = UDim2.new(0.5, 0, 1, 0)
	})
	local v_u_263 = v_u_222.label({
		["parent"] = nil,
		["name"] = "ValueCol",
		["text"] = "Extracted value",
		["style"] = "micro",
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["parent"] = v_u_262,
		["position"] = UDim2.new(1, -12, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0.4, 0, 1, 0)
	})
	local v_u_264 = v_u_222.list({
		["parent"] = nil,
		["position"] = nil,
		["size"] = nil,
		["gap"] = 2,
		["parent"] = v241,
		["position"] = UDim2.fromOffset(0, v261 + 24),
		["size"] = UDim2.new(1, 0, 1, -(v261 + 24) - 64 - 30)
	})
	local v_u_265 = v_u_222.label({
		["parent"] = nil,
		["name"] = "Rewards",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["wrap"] = true,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v241,
		["color"] = v_u_224.text2,
		["anchor"] = Vector2.new(0, 1),
		["position"] = UDim2.new(0, 0, 1, -58),
		["size"] = UDim2.new(1, 0, 0, 26)
	})
	v_u_265.TextYAlignment = Enum.TextYAlignment.Top
	v_u_265.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_266 = v_u_222.new("Frame", {
		["Name"] = "Me",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_224.accentDeep,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 52)
	}, v241)
	v_u_222.stroke(v_u_266, v_u_224.accent)
	local v_u_267 = v_u_222.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoL",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_266,
		["color"] = v_u_224.accent,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(0, 80, 1, 0)
	})
	v_u_222.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "bodyStrong",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_266,
		["text"] = v_u_2.DisplayName .. "  (you)",
		["position"] = UDim2.fromOffset(100, 4),
		["size"] = UDim2.new(0.5, 0, 0, 26)
	})
	local v_u_268 = v_u_222.label({
		["parent"] = nil,
		["name"] = "MeNote",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_266,
		["color"] = v_u_224.text2,
		["position"] = UDim2.fromOffset(100, 30),
		["size"] = UDim2.new(0.55, 0, 0, 16)
	})
	v_u_222.tooltip(v_u_266, function()
		-- upvalues: (copy) v_u_268
		return {
			["title"] = "YOUR ROW",
			["body"] = nil,
			["body"] = v_u_268.Text == "" and "Your place and your value on this board." or v_u_268.Text
		}
	end)
	local v_u_269 = v_u_222.label({
		["parent"] = nil,
		["text"] = "$0",
		["style"] = "monoL",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["parent"] = v_u_266,
		["color"] = v_u_224.text,
		["position"] = UDim2.new(1, -12, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0.4, 0, 1, 0)
	})
	local v_u_270 = v_u_222.new("Frame", {
		["Name"] = "FactionHolder",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Position"] = UDim2.fromOffset(0, 62),
		["Size"] = UDim2.new(1, 0, 1, -62)
	}, v241)
	local v_u_271 = v_u_222.new("Frame", {
		["Name"] = "ClanHolder",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Position"] = UDim2.fromOffset(0, 62),
		["Size"] = UDim2.new(1, 0, 1, -62)
	}, v241)
	local v_u_272 = v_u_222.new("Frame", {
		["Name"] = "ClanCols",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 22)
	}, v_u_271)
	local v_u_273 = v_u_222.list({
		["parent"] = nil,
		["name"] = "ClanList",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 2,
		["parent"] = v_u_271,
		["position"] = UDim2.fromOffset(0, 24),
		["size"] = UDim2.new(1, 0, 1, -24)
	})
	local v_u_274 = nil
	local v_u_275 = nil
	local v_u_276 = 0
	local v_u_277 = 0
	local function v_u_308() -- name: drawClans
		-- upvalues: (copy) v_u_225, (copy) v_u_272, (copy) v_u_273, (copy) p_u_220, (ref) v_u_274, (ref) v_u_275, (copy) v_u_240, (copy) v_u_222, (copy) v_u_224
		v_u_225.clear(v_u_272)
		v_u_225.clear(v_u_273)
		local v_u_278 = nil
		local v_u_279 = nil
		local function v280()
			-- upvalues: (ref) v_u_278, (ref) p_u_220, (ref) v_u_279
			v_u_278 = p_u_220.cctx.lib.MenuClanShopModel
			v_u_279 = p_u_220.cctx.lib.MenuClanShopPlan
		end
		pcall(v280)
		if v_u_274 == nil or (v_u_278 == nil or v_u_279 == nil) then
			v_u_225.empty(v_u_273, v_u_275 == "retry" and "Could not load the clan ranking. Retrying..." or (v_u_275 == "gave_up" and "The clan ranking is not available right now. Open the tab again to retry." or "Loading the clan ranking..."))
			return
		else
			local v281 = v_u_240 - 32 - 6
			local v282 = v_u_279.boardRow(v281, 22, v_u_274.hasTotal)
			v_u_222.label({
				["parent"] = nil,
				["text"] = "Rank",
				["style"] = "micro",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_272,
				["position"] = UDim2.fromOffset(v282.place.x, 0),
				["size"] = UDim2.fromOffset(v282.place.w, 22)
			})
			v_u_222.label({
				["parent"] = nil,
				["text"] = "Clan",
				["style"] = "micro",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_272,
				["position"] = UDim2.fromOffset(v282.tag.x, 0),
				["size"] = UDim2.fromOffset(v282.name.w, 22)
			})
			v_u_222.label({
				["parent"] = nil,
				["text"] = "This week",
				["style"] = "micro",
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_272,
				["position"] = UDim2.fromOffset(v282.weekly.x, 0),
				["size"] = UDim2.fromOffset(v282.weekly.w, 22)
			})
			if v282.total then
				v_u_222.label({
					["parent"] = nil,
					["text"] = "Total points",
					["style"] = "micro",
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_272,
					["position"] = UDim2.fromOffset(v282.total.x, 0),
					["size"] = UDim2.fromOffset(v282.total.w, 22)
				})
			end
			if #v_u_274.rows == 0 then
				v_u_225.empty(v_u_273, "No clan is on the board yet. Extract with your clan to be the first.")
			else
				local v_u_283 = nil
				local function v284()
					-- upvalues: (ref) v_u_283, (ref) p_u_220
					v_u_283 = p_u_220.cctx.shared.ClanTag
				end
				pcall(v284)
				local v285 = v_u_283
				local v286 = v_u_279
				for v287, v288 in v_u_274.rows do
					local v289 = v286.boardRow(v281, 40, v_u_274.hasTotal)
					local v290 = v_u_222.new
					local v291 = "Frame"
					local v292 = {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "R" .. v287
					}
					local v293
					if v288.mine then
						v293 = v_u_224.accentDeep
					else
						v293 = v_u_224.raised
					end
					v292.BackgroundColor3 = v293
					v292.BackgroundTransparency = v287 % 2 == 0 and 0.5 or 0.3
					v292.Size = UDim2.new(1, -6, 0, 40)
					v292.LayoutOrder = v287
					local v294 = v290(v291, v292, v_u_273)
					local v295 = v_u_222.label
					local v296 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v294,
						["text"] = ("#%d"):format(v288.rank)
					}
					local v297
					if v288.rank == 1 then
						v297 = v_u_224.accent
					elseif v288.rank <= 3 then
						v297 = v_u_224.text
					else
						v297 = v_u_224.text2
					end
					v296.color = v297
					v296.position = UDim2.fromOffset(v289.place.x, 0)
					v296.size = UDim2.fromOffset(v289.place.w, 40)
					v295(v296)
					local v298 = v_u_224.text2
					local v299
					if v285 then
						local v300 = v285.color
						if type(v300) == "function" then
							local v301 = v288.id
							if type(v301) == "string" then
								local v302 = v285.color
								local v303 = v288.id
								local v304
								v304, v299 = pcall(v302, v303, 0.55, 0.95)
								if v304 then
									if typeof(v299) ~= "Color3" then
										v299 = v298
									end
								else
									v299 = v298
								end
							else
								v299 = v298
							end
						else
							v299 = v298
						end
					else
						v299 = v298
					end
					v_u_222.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "monoS",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v294,
						["text"] = "[" .. v288.tag .. "]",
						["color"] = v299,
						["position"] = UDim2.fromOffset(v289.tag.x, v289.tag.y),
						["size"] = UDim2.fromOffset(v289.tag.w, v289.tag.h)
					})
					local v305 = v_u_222.label
					local v306 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v294,
						["text"] = v288.name
					}
					local v307
					if v288.mine then
						v307 = v_u_224.accent
					else
						v307 = v_u_224.text
					end
					v306.color = v307
					v306.position = UDim2.fromOffset(v289.name.x, 0)
					v306.size = UDim2.fromOffset(v289.name.w, 40)
					v305(v306)
					v_u_222.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v294,
						["text"] = v_u_222.commas(v288.weekly),
						["position"] = UDim2.fromOffset(v289.weekly.x, 0),
						["size"] = UDim2.fromOffset(v289.weekly.w, 40)
					})
					if not (v289.total and v288.total) then
						continue
					end
					v_u_222.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v294,
						["text"] = v_u_222.commas(v288.total),
						["color"] = v_u_224.text2,
						["position"] = UDim2.fromOffset(v289.total.x, 0),
						["size"] = UDim2.fromOffset(v289.total.w, 40)
					})
				end
			end
		end
	end
	v_u_245 = function()
		-- upvalues: (copy) p_u_220, (ref) v_u_1, (ref) v_u_227, (ref) v_u_252, (ref) v_u_229, (copy) v_u_222, (copy) v_u_243, (copy) v_u_244, (copy) v_u_263, (copy) v_u_265
		local v_u_309 = nil
		local function v311()
			-- upvalues: (ref) p_u_220, (ref) v_u_309
			local v310 = p_u_220.cctx.shared.Difficulty
			v_u_309 = {
				["Hard"] = v310.scoreWeight("Hard"),
				["Nightmare"] = v310.scoreWeight("Nightmare")
			}
		end
		pcall(v311)
		local v312 = v_u_1.boardTexts(v_u_227, v_u_252, v_u_229, v_u_309)
		v_u_222.setText(v_u_243, v312.title)
		v_u_222.setText(v_u_244, v312.sub)
		v_u_263.Text = v312.col
		local v_u_313 = ""
		if v_u_227 == "weekly" then
			local function v314()
				-- upvalues: (ref) v_u_313, (ref) v_u_1, (ref) p_u_220, (ref) v_u_222
				v_u_313 = v_u_1.rewardsLine(p_u_220.cctx.shared.TitleRarity.RULES.rankMinScore, v_u_222.commas)
			end
			pcall(v314)
		end
		v_u_265.Text = v_u_313
		v_u_265.Visible = v_u_313 ~= ""
	end
	local function v_u_343(p315, p316) -- name: row
		-- upvalues: (ref) v_u_2, (copy) v_u_222, (copy) v_u_224, (copy) v_u_264, (ref) v_u_227, (ref) v_u_194, (ref) v_u_229, (copy) v_u_225
		local v317 = p316.userId
		local v318 = tonumber(v317) == v_u_2.UserId
		local v319 = v_u_222.new
		local v320 = "Frame"
		local v321 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "R" .. p315
		}
		local v322
		if v318 then
			v322 = v_u_224.accentDeep
		else
			v322 = v_u_224.raised
		end
		v321.BackgroundColor3 = v322
		v321.BackgroundTransparency = p315 % 2 == 0 and 0.5 or 0.3
		v321.Size = UDim2.new(1, -6, 0, 40)
		v321.LayoutOrder = p315
		local v323 = v319(v320, v321, v_u_264)
		local v324 = p316.rank
		local v325 = tonumber(v324) or p315
		local v326 = v_u_222.label
		local v327 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v323,
			["text"] = ("#%d"):format(v325)
		}
		local v328
		if v325 == 1 then
			v328 = v_u_224.accent
		elseif v325 <= 3 then
			v328 = v_u_224.text
		else
			v328 = v_u_224.text2
		end
		v327.color = v328
		v327.position = UDim2.fromOffset(12, 0)
		v327.size = UDim2.new(0, 80, 1, 0)
		v326(v327)
		local v329 = v_u_222.label
		local v330 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v323
		}
		local v331 = p316.name or "?"
		v330.text = tostring(v331)
		local v332
		if v318 then
			v332 = v_u_224.accent
		else
			v332 = v_u_224.text
		end
		v330.color = v332
		v330.position = UDim2.fromOffset(100, 0)
		v330.size = UDim2.new(0.5, 0, 1, 0)
		v329(v330)
		local v333 = v_u_222.label
		local v334 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "mono",
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["parent"] = v323
		}
		local v335 = p316.value
		local v336, v337, v338, v339, v340
		if v_u_227 == "alltime" then
			for _, v342 in v_u_194 do
				if v342.id ~= v_u_229 then
					continue
				end
			end
			local v342 = v_u_194[1]
			if v342.money then
				v336 = v_u_225.money(v335)
				v334.text = v336
				v334.position = UDim2.new(1, -12, 0, 0)
				v334.anchor = Vector2.new(1, 0)
				v334.size = UDim2.new(0.4, 0, 1, 0)
				v333(v334)
				if v325 <= 3 then
					v337 = v_u_222.new
					v338 = "Frame"
					v339 = {
						["Name"] = "Medal",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil
					}
					if v325 == 1 then
						v340 = v_u_224.accent
					else
						v340 = v_u_224.lineStrong
					end
					v339.BackgroundColor3 = v340
					v339.Size = UDim2.new(0, 3, 1, 0)
					v337(v338, v339, v323)
				end
			else
				v336 = v_u_222.commas(tonumber(v335) or 0)
				v334.text = v336
				v334.position = UDim2.new(1, -12, 0, 0)
				v334.anchor = Vector2.new(1, 0)
				v334.size = UDim2.new(0.4, 0, 1, 0)
				v333(v334)
				if v325 <= 3 then
					v337 = v_u_222.new
					v338 = "Frame"
					v339 = {
						["Name"] = "Medal",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil
					}
					if v325 == 1 then
						v340 = v_u_224.accent
					else
						v340 = v_u_224.lineStrong
					end
					v339.BackgroundColor3 = v340
					v339.Size = UDim2.new(0, 3, 1, 0)
					v337(v338, v339, v323)
				end
			end
		else
			v336 = v_u_225.money(v335)
			v334.text = v336
			v334.position = UDim2.new(1, -12, 0, 0)
			v334.anchor = Vector2.new(1, 0)
			v334.size = UDim2.new(0.4, 0, 1, 0)
			v333(v334)
			if v325 <= 3 then
				v337 = v_u_222.new
				v338 = "Frame"
				v339 = {
					["Name"] = "Medal",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil
				}
				if v325 == 1 then
					v340 = v_u_224.accent
				else
					v340 = v_u_224.lineStrong
				end
				v339.BackgroundColor3 = v340
				v339.Size = UDim2.new(0, 3, 1, 0)
				v337(v338, v339, v323)
			end
			return
		end
	end
	local v_u_344 = nil
	local v_u_345 = 0
	function v_u_226.draw() -- name: draw
		-- upvalues: (ref) v_u_227, (copy) v_u_225, (copy) v_u_264, (ref) v_u_230, (ref) v_u_344, (ref) v_u_2, (copy) v_u_343, (ref) v_u_1, (copy) v_u_267, (copy) v_u_268, (copy) v_u_269, (ref) v_u_194, (ref) v_u_229, (copy) v_u_222
		if v_u_227 == "factions" or v_u_227 == "clans" then
			return
		end
		v_u_225.clear(v_u_264)
		local v346 = v_u_230
		if type(v346) ~= "table" then
			local v347 = v_u_227 == "alltime" and "the all-time board" or "the weekly board"
			local v348 = v_u_225.empty
			local v349 = v_u_264
			local v350
			if v_u_344 == "retry" then
				v350 = ("Could not load %s. Retrying..."):format(v347)
			else
				v350 = v_u_344 ~= "gave_up" and "Loading the board..." or ("Could not load %s. Open the tab again to retry."):format(v347)
			end
			v348(v349, v350)
			v_u_2:SetAttribute("BoardView", ("%s %s"):format(v_u_227, v_u_344 or "loading"))
			return
		end
		local v351 = v_u_2
		local v352 = v_u_227
		local v353 = v_u_230.entries
		v351:SetAttribute("BoardView", ("%s ok %d"):format(v352, type(v353) == "table" and #v_u_230.entries or 0))
		local v354 = v_u_230.entries
		local v355 = type(v354) == "table" and v_u_230.entries or {}
		for v356, v357 in v355 do
			if type(v357) ~= "table" then
				continue
			end
			v_u_343(v356, v357)
		end
		if #v355 == 0 then
			if v_u_230.offline then
				v_u_225.empty(v_u_264, "Global board offline. Nobody on this server has extracted yet.")
			else
				v_u_225.empty(v_u_264, v_u_227 == "alltime" and "Nobody is on this board yet. Extract to be the first." or "Nobody has extracted anything this week. Be the first.")
			end
		elseif v_u_230.offline then
			v_u_225.empty(v_u_264, "Global board offline. Showing survivors on this server.", 1000)
		end
		local v358 = v_u_230.me
		local v359 = type(v358) == "table" and (v_u_230.me or {}) or {}
		local v360 = v359.rank
		local v361 = tonumber(v360)
		local v362 = v359.value
		local v363 = tonumber(v362)
		if v363 == nil or v361 == nil then
			for v364, v365 in v355 do
				if type(v365) ~= "table" then
					continue
				end
				local v366 = v365.userId
				if tonumber(v366) ~= v_u_2.UserId then
					continue
				end
				if not v361 then
					local v367 = v365.rank
					v361 = tonumber(v367) or v364
				end
				if v363 ~= nil then
					continue
				end
				local v368 = v365.value
				v363 = tonumber(v368)
			end
		end
		local v369 = v363 or 0
		local v370 = v_u_1.ownRow(v361, v369, v_u_230.offline)
		v_u_267.Text = v370.rank
		v_u_268.Text = v370.note
		local v371 = v_u_269
		local v372
		if v_u_227 == "alltime" then
			for _, v374 in v_u_194 do
				if v374.id ~= v_u_229 then
					continue
				end
			end
			local v374 = v_u_194[1]
			if v374.money then
				v372 = v_u_225.money(v369)
				v371.Text = v372
			else
				v372 = v_u_222.commas(tonumber(v369) or 0)
				v371.Text = v372
			end
		else
			v372 = v_u_225.money(v369)
			v371.Text = v372
			return
		end
	end
	function v_u_226.load() -- name: load
		-- upvalues: (ref) v_u_231, (ref) v_u_227, (ref) v_u_232, (ref) v_u_276, (ref) v_u_274, (ref) v_u_275, (copy) v_u_308, (copy) p_u_220, (ref) v_u_2, (copy) p_u_221, (ref) v_u_277, (ref) v_u_230, (ref) v_u_344, (copy) v_u_226, (ref) v_u_252, (ref) v_u_229, (ref) v_u_345
		v_u_231 = v_u_231 + 1
		local v_u_375 = v_u_231
		if v_u_227 == "factions" then
			if v_u_232 then
				v_u_232.show()
			end
			return
		elseif v_u_227 == "clans" then
			v_u_276 = v_u_276 + 1
			local v_u_376 = v_u_276
			v_u_274 = nil
			v_u_275 = nil
			v_u_308()
			task.spawn(function()
				-- upvalues: (ref) p_u_220, (ref) v_u_2, (copy) v_u_376, (ref) v_u_276, (ref) p_u_221, (ref) v_u_275, (ref) v_u_308, (ref) v_u_274, (ref) v_u_277
				local v_u_377 = nil
				local function v378()
					-- upvalues: (ref) v_u_377, (ref) p_u_220
					v_u_377 = p_u_220.cctx.lib.MenuClanShopModel
				end
				pcall(v378)
				local v_u_379 = nil
				local function v380()
					-- upvalues: (ref) v_u_379, (ref) p_u_220
					v_u_379 = p_u_220.profile.clan.id
				end
				pcall(v380)
				local v_u_381 = false
				local function v384()
					-- upvalues: (ref) v_u_2, (ref) v_u_381
					local v382 = v_u_2:GetAttribute("DevClanState")
					local v383 = game:GetService("RunService"):IsStudio()
					if v383 then
						if type(v382) == "string" then
							v383 = v382 ~= ""
						else
							v383 = false
						end
					end
					v_u_381 = v383
				end
				pcall(v384)
				local v385 = v_u_379
				local v386 = v_u_377
				local v387 = v_u_381
				local v388 = nil
				for v389 = 0, 3 do
					if v389 > 0 then
						task.wait(2 ^ (v389 - 1) * 3)
						if v_u_376 ~= v_u_276 or not p_u_221.Parent then
							return
						end
					end
					if v387 and v386 then
						v388 = {
							["rows"] = nil,
							["resetIn"] = 259200,
							["rows"] = v386.fakeBoard(v385, "HUSH")
						}
					else
						v388 = p_u_220.fetch("clanBoard", nil, v389 > 0 and 0 or 30)
					end
					if v_u_376 ~= v_u_276 or not p_u_221.Parent then
						return
					end
					if type(v388) == "table" then
						local v390 = v388.rows
						if type(v390) == "table" then
							break
						end
					end
					v388 = nil
					v_u_275 = v389 < 3 and "retry" or "gave_up"
					v_u_308()
				end
				if v_u_376 == v_u_276 and (p_u_221.Parent and (v388 ~= nil and v386)) then
					v_u_274 = v386.board(v388.rows, v385)
					local v391 = os.clock()
					local v392 = v388.resetIn
					v_u_277 = v391 + (tonumber(v392) or 0)
					v_u_275 = "ok"
					v_u_308()
				end
			end)
		else
			v_u_230 = nil
			v_u_344 = nil
			v_u_226.draw()
			local v_u_393 = v_u_227
			local v_u_394 = v_u_252
			local v_u_395 = v_u_229
			task.spawn(function()
				-- upvalues: (copy) v_u_375, (ref) v_u_231, (ref) p_u_221, (ref) v_u_345, (copy) v_u_393, (ref) p_u_220, (copy) v_u_395, (copy) v_u_394, (ref) v_u_344, (ref) v_u_226, (ref) v_u_230
				local v396 = nil
				for v397 = 0, 4 do
					if v397 > 0 then
						task.wait(2 ^ (v397 - 1) * 3)
						if v_u_375 ~= v_u_231 or not p_u_221.Parent then
							return
						end
					end
					if v_u_345 > 0 then
						v_u_345 = v_u_345 - 1
						v396 = nil
					elseif v_u_393 == "alltime" then
						v396 = p_u_220.fetch("leaderboardAll", {
							["id"] = v_u_395
						}, v397 > 0 and 0 or 60)
					else
						v396 = p_u_220.fetch("leaderboard", {
							["difficulty"] = v_u_394
						}, v397 > 0 and 0 or 60)
					end
					if v_u_375 ~= v_u_231 or not p_u_221.Parent then
						return
					end
					if v396 ~= nil then
						break
					end
					v_u_344 = v397 < 4 and "retry" or "gave_up"
					v_u_226.draw()
				end
				if v_u_375 == v_u_231 and p_u_221.Parent then
					v_u_230 = v396
					if v396 ~= nil then
						v_u_344 = nil
					end
					v_u_226.draw()
				end
			end)
		end
	end
	local function v_u_411(p398) -- name: setMode
		-- upvalues: (ref) v_u_251, (ref) v_u_250, (copy) p_u_220, (ref) v_u_227, (copy) v_u_271, (copy) v_u_248, (copy) v_u_259, (copy) v_u_262, (copy) v_u_264, (copy) v_u_266, (copy) v_u_270, (ref) v_u_245, (ref) v_u_232, (ref) v_u_255, (copy) v_u_246, (copy) v_u_226
		if p398 == "weekly" or (p398 == "alltime" or (p398 == "factions" or p398 == "clans" and v_u_251)) then
			if p398 == "factions" and v_u_250 then
				local v399 = v_u_250.markSeen
				local v400 = p_u_220
				pcall(v399, v400, "lbfac")
			end
			v_u_227 = p398
			local v401
			if p398 == "factions" then
				v401 = false
			else
				v401 = p398 ~= "clans"
			end
			v_u_271.Visible = p398 == "clans"
			v_u_248.Visible = p398 == "weekly"
			v_u_259.Visible = p398 == "alltime"
			v_u_262.Visible = v401
			v_u_264.Visible = v401
			v_u_266.Visible = v401
			v_u_270.Visible = not v401
			v_u_245()
			if p398 == "factions" and not v_u_232 then
				local function v402()
					-- upvalues: (ref) p_u_220
					return p_u_220.cctx.lib.MenuFactions
				end
				local v403, v404 = pcall(v402)
				if v403 and type(v404) == "table" then
					local v405 = v404.mount
					if type(v405) == "function" then
						local v406 = v404.mount
						local v407 = p_u_220
						local v408 = v_u_270
						local v409, v410 = pcall(v406, v407, v408)
						if v409 then
							v_u_232 = v410
						else
							warn("[MenuBook] factions view failed:", v410)
						end
					end
				end
			end
			if v_u_232 then
				if p398 == "factions" then
					v_u_232.show()
				else
					v_u_232.hide()
				end
			end
			if v_u_255 and v_u_255.get() ~= p398 then
				v_u_255.select(p398, true)
			end
			v_u_246.Text = ""
			v_u_226.load()
		end
	end
	local v412 = {
		{
			["id"] = "weekly",
			["text"] = "Weekly"
		},
		{
			["id"] = "alltime",
			["text"] = "All time"
		},
		{
			["id"] = "factions",
			["text"] = "Factions"
		}
	}
	if v_u_251 then
		table.insert(v412, {
			["id"] = "clans",
			["text"] = "Clans"
		})
	end
	local v414, v415 = v_u_222.tabs({
		["parent"] = nil,
		["name"] = "ModeTabs",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["tabs"] = nil,
		["selected"] = "weekly",
		["onChange"] = nil,
		["parent"] = v242,
		["position"] = UDim2.new(1, 0, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0, v_u_251 and 470 or 360, 0, v223.touch(36)),
		["tabs"] = v412,
		["onChange"] = function(p413) -- name: onChange
			-- upvalues: (copy) v_u_411
			v_u_411(p413)
		end
	})
	local _ = v415
	local v_u_416 = v414
	v_u_245()
	local function v_u_424() -- name: showTip
		-- upvalues: (ref) v_u_250, (ref) v_u_236, (ref) v_u_416, (copy) p_u_220, (copy) p_u_221, (ref) v_u_235
		if v_u_250 and (v_u_236 and v_u_416) then
			local v417 = v_u_250.show
			local v418 = p_u_220
			local v421 = {
				["host"] = p_u_221,
				["target"] = function() -- name: target
					-- upvalues: (ref) v_u_416
					local v419 = v_u_416:FindFirstChild("Tab_factions", true)
					if v419 and v419:IsA("GuiObject") then
						return v419
					else
						return nil
					end
				end,
				["active"] = function() -- name: active
					-- upvalues: (ref) v_u_236, (ref) p_u_221
					local v420 = v_u_236 and p_u_221.Visible
					if v420 then
						v420 = p_u_221.Parent ~= nil
					end
					return v420
				end,
				["sides"] = { "right", "below", "left" }
			}
			local v422, v423 = pcall(v417, v418, "lbfac", v421)
			if v422 then
				v_u_235 = v423
			else
				warn("[MenuBook] tip failed:", v423)
			end
		else
			return
		end
	end
	function v_u_226.openMode(p425) -- name: openMode
		-- upvalues: (ref) v_u_227, (copy) v_u_411
		if p425 ~= v_u_227 then
			v_u_411(p425)
		end
	end
	local v_u_429 = v_u_2:GetAttributeChangedSignal("DevLeaderboard"):Connect(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_252, (copy) v_u_249, (ref) v_u_229, (copy) v_u_260, (ref) v_u_227, (copy) v_u_226, (copy) v_u_411
		local v426 = v_u_2:GetAttribute("DevLeaderboard")
		if type(v426) == "string" then
			v_u_2:SetAttribute("DevLeaderboard", nil)
			local v427, v428 = string.match(v426, "^(%a+):?(%w*)$")
			if v427 == "weekly" and v428 ~= "" then
				v_u_252 = v428
				v_u_249.select(v428, true)
			elseif v427 == "alltime" and v428 ~= "" then
				v_u_229 = v428
				v_u_260.select(v428, true)
			end
			if v427 then
				if v427 == v_u_227 then
					v_u_226.load()
					return
				end
				v_u_411(v427)
			end
		end
	end)
	local v_u_433 = v_u_2:GetAttributeChangedSignal("DevBoardFail"):Connect(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_345
		local v430 = v_u_2
		local v431 = tonumber(v430:GetAttribute("DevBoardFail"))
		if v431 and game:GetService("RunService"):IsStudio() then
			v_u_2:SetAttribute("DevBoardFail", nil)
			local v432 = math.floor(v431)
			v_u_345 = math.clamp(v432, 0, 10)
		end
	end)
	p_u_221.Destroying:Connect(function()
		-- upvalues: (copy) v_u_429, (copy) v_u_433
		v_u_429:Disconnect()
		v_u_433:Disconnect()
	end)
	function v_u_226.show() -- name: show
		-- upvalues: (ref) v_u_236, (copy) v_u_226, (copy) v_u_424
		v_u_236 = true
		v_u_226.load()
		v_u_424()
	end
	function v_u_226.hide() -- name: hide
		-- upvalues: (ref) v_u_236, (ref) v_u_235
		v_u_236 = false
		if v_u_235 then
			local v434 = v_u_235.dismiss
			pcall(v434, "left")
			v_u_235 = nil
		end
	end
	function v_u_226.refresh(p435, p436) -- name: refresh
		-- upvalues: (ref) v_u_236, (copy) v_u_424, (ref) v_u_232, (ref) v_u_227
		if p435 == "profile" and v_u_236 then
			v_u_424()
		end
		if v_u_232 and v_u_227 == "factions" then
			v_u_232.refresh(p435, p436)
		end
	end
	function v_u_226.tick() -- name: tick
		-- upvalues: (ref) v_u_227, (ref) v_u_230, (ref) v_u_232, (copy) p_u_220, (copy) v_u_246, (ref) v_u_277
		local v437 = nil
		if v_u_227 == "weekly" then
			local v438 = v_u_230
			if type(v438) == "table" then
				local v439 = v_u_230.endsAt
				v437 = tonumber(v439)
			elseif v_u_227 == "factions" and v_u_232 then
				v437 = v_u_232.endsAt()
			end
		elseif v_u_227 == "factions" and v_u_232 then
			v437 = v_u_232.endsAt()
		end
		if v437 then
			local v440 = os.time()
			local v441
			if v_u_227 == "weekly" then
				local function v442()
					-- upvalues: (ref) p_u_220
					return p_u_220.cctx.lib.MenuFactions.serverNow()
				end
				local v443
				v443, v441 = pcall(v442)
				if v443 and type(v441) == "number" then
					if v441 ~= v441 then
						v441 = v440
					end
				else
					v441 = v440
				end
			else
				v441 = v440
			end
			local v444 = v437 - v441
			local v445 = math.max(0, v444)
			v_u_246.Text = ("RESETS IN %dd %02dh %02dm"):format(v445 // 86400, v445 % 86400 // 3600, v445 % 3600 // 60)
			return
		elseif v_u_227 == "clans" and v_u_277 > 0 then
			local v446 = v_u_277 - os.clock()
			local v447 = math.floor(v446)
			local v448 = math.max(0, v447)
			v_u_246.Text = ("RESETS IN %dd %02dh %02dm"):format(v448 // 86400, v448 % 86400 // 3600, v448 % 3600 // 60)
		elseif v_u_227 == "alltime" then
			v_u_246.Text = ""
		end
	end
	function v_u_226.destroy() -- name: destroy
		-- upvalues: (ref) v_u_236, (ref) v_u_235, (ref) v_u_232
		v_u_236 = false
		if v_u_235 then
			local v449 = v_u_235.detach
			pcall(v449)
			v_u_235 = nil
		end
		if v_u_232 then
			local v450 = v_u_232.destroy
			pcall(v450)
		end
	end
	return v_u_226
end
return v_u_1