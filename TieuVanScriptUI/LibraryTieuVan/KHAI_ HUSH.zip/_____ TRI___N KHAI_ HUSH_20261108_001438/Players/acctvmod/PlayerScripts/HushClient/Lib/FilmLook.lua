-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmLook

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = require(script.Parent:WaitForChild("FilmClean"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
v_u_4.LOOKS = {
	"Natural",
	"Cold horror",
	"Warm dusk",
	"Bleach",
	"Noir"
}
local v_u_6 = {
	["Natural"] = nil,
	["Cold horror"] = {
		["b"] = -0.02,
		["c"] = 0.14,
		["s"] = -0.35,
		["tint"] = nil,
		["tint"] = Color3.fromRGB(200, 214, 236)
	},
	["Warm dusk"] = {
		["b"] = 0.03,
		["c"] = 0.08,
		["s"] = 0.1,
		["tint"] = nil,
		["tint"] = Color3.fromRGB(255, 222, 190)
	},
	["Bleach"] = {
		["b"] = 0.04,
		["c"] = 0.2,
		["s"] = -0.55,
		["tint"] = nil,
		["tint"] = Color3.fromRGB(242, 240, 230)
	},
	["Noir"] = {
		["b"] = 0.04,
		["c"] = 0.22,
		["s"] = -1,
		["tint"] = nil,
		["tint"] = Color3.new(1, 1, 1)
	}
}
local v_u_7 = "Natural"
local v_u_8 = "off"
local v_u_9 = 0.6
local v_u_10 = 20
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = ""
local v_u_17 = false
local v_u_18 = "auto"
function v_u_4.setLook(p19) -- name: setLook
	-- upvalues: (copy) v_u_6, (ref) v_u_7, (copy) v_u_5, (ref) v_u_11
	local v20 = v_u_6[p19]
	if p19 == "Natural" or v20 then
		v_u_7 = p19
		v_u_5:SetAttribute("FilmLook", p19)
		if v20 then
			local v21 = workspace.CurrentCamera
			if v21 then
				if not v_u_11 or v_u_11.Parent ~= v21 then
					local v22 = Instance.new("ColorCorrectionEffect")
					v22.Name = "FilmLook"
					v22:SetAttribute("FilmMode", true)
					v22.Parent = v21
					v_u_11 = v22
				end
				local v23 = v_u_11
				v23.Brightness = v20.b
				v23.Contrast = v20.c
				v23.Saturation = v20.s
				v23.TintColor = v20.tint
				v23.Enabled = true
			end
		else
			if v_u_11 then
				v_u_11:Destroy()
				v_u_11 = nil
			end
			return
		end
	else
		return
	end
end
function v_u_4.look() -- name: look
	-- upvalues: (ref) v_u_7
	return v_u_7
end
local function v_u_25() -- name: releaseDofs
	-- upvalues: (ref) v_u_13, (copy) v_u_3
	for v24 in v_u_13 do
		v_u_3.release(v24, "Enabled")
	end
	v_u_13 = {}
end
function v_u_4.setDof(p26, p27, p28) -- name: setDof
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_5, (ref) v_u_12, (copy) v_u_25, (copy) v_u_2, (ref) v_u_13, (copy) v_u_3
	if p26 == "off" or (p26 == "player" or (p26 == "point" or (p26 == "distance" or p26 == "target"))) then
		v_u_8 = p26
		if type(p27) == "number" then
			v_u_9 = math.clamp(p27, 0, 1)
		end
		if type(p28) == "number" then
			v_u_10 = math.clamp(p28, 0.5, 500)
		end
		v_u_5:SetAttribute("FilmDof", p26)
		if p26 == "off" then
			if v_u_12 then
				v_u_12:Destroy()
				v_u_12 = nil
			end
			v_u_25()
			return
		else
			local v29 = workspace.CurrentCamera
			if v29 then
				if not v_u_12 or v_u_12.Parent ~= v29 then
					local v30 = Instance.new("DepthOfFieldEffect")
					v30.Name = "FilmDof"
					v30:SetAttribute("FilmMode", true)
					v30.Parent = v29
					v_u_12 = v30
				end
				local v31 = v_u_12
				v31.FarIntensity = v_u_9
				v31.NearIntensity = v_u_9 * 0.7
				local v32 = (1 - v_u_9) * 6 + 1.5
				v31.InFocusRadius = math.max(1.5, v32)
				v31.Enabled = true
				for _, v33 in v_u_2:GetDescendants() do
					if not v33:IsA("DepthOfFieldEffect") or v_u_13[v33] then
						continue
					end
					v_u_13[v33] = true
					v_u_3.force(v33, "Enabled", false)
				end
			end
		end
	else
		return
	end
end
function v_u_4.dof() -- name: dof
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v_u_4.setTarget(p34) -- name: setTarget
	-- upvalues: (ref) v_u_15
	v_u_15 = p34
end
function v_u_4.update(p35, p36) -- name: update
	-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (copy) v_u_5, (ref) v_u_15
	local v37 = v_u_12
	if v37 and v_u_8 ~= "off" then
		local v38 = v_u_10
		if v_u_8 == "player" then
			local v39 = v_u_5.Character
			if v39 then
				v39 = v39:FindFirstChild("HumanoidRootPart")
			end
			if v39 and v39:IsA("BasePart") then
				v38 = (v39.Position + Vector3.new(0, 1.5, 0) - p35.Position).Magnitude
			end
		elseif v_u_8 == "point" and p36 then
			v38 = (p36 - p35.Position).Magnitude
		elseif v_u_8 == "target" and v_u_15 then
			v38 = (v_u_15 - p35.Position).Magnitude
		end
		v37.FocusDistance = math.clamp(v38, 0, 200)
	end
end
local function v_u_49(p40, p41, p42, p43, p44, p45) -- name: zone
	local v46 = Instance.new("Frame")
	v46.Name = p41
	v46.BackgroundColor3 = p45
	v46.BackgroundTransparency = 0.88
	v46.BorderSizePixel = 0
	v46.Position = p42
	v46.Size = p43
	local v47 = Instance.new("UIStroke")
	v47.Color = p45
	v47.Thickness = 1
	v47.Transparency = 0.35
	v47.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v47.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v47.Parent = v46
	local v48 = Instance.new("TextLabel")
	v48.BackgroundTransparency = 1
	v48.Text = p44
	v48.TextColor3 = p45
	v48.TextTransparency = 0.2
	v48.TextSize = 13
	v48.FontFace = Font.fromName("RobotoMono")
	v48.TextTruncate = Enum.TextTruncate.AtEnd
	v48.Position = UDim2.fromOffset(6, 4)
	v48.Size = UDim2.new(1, -12, 0, 16)
	v48.TextXAlignment = Enum.TextXAlignment.Left
	v48.Parent = v46
	v46.Parent = p40
end
local function v_u_54(p50, p51) -- name: inner
	local v52 = Instance.new("Frame")
	v52.Name = "Safe"
	v52.BackgroundTransparency = 1
	v52.Position = UDim2.fromScale(p51, p51)
	v52.Size = UDim2.fromScale(1 - p51 * 2, 1 - p51 * 2)
	local v53 = Instance.new("UIStroke")
	v53.Color = Color3.new(1, 1, 1)
	v53.Transparency = 0.7
	v53.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v53.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v53.Parent = v52
	v52.Parent = p50
end
function v_u_4.setGuideFrame(p55, p56, p57) -- name: setGuideFrame
	-- upvalues: (ref) v_u_14, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) v_u_5, (copy) v_u_49, (copy) v_u_54
	if v_u_14 then
		v_u_14:Destroy()
		v_u_14 = nil
	end
	local v58 = p55 ~= "916" and (p55 ~= "1:1" and p55 ~= "16:9") and "" or p55
	local v59 = p56 == true
	v_u_16 = v58
	v_u_17 = v59
	v_u_18 = p57 or "auto"
	v_u_5:SetAttribute("FilmGuides", v58 .. (p56 and "+thirds" or ""))
	if v58 == "" and not p56 then
		return
	else
		local v60 = v_u_5:FindFirstChildOfClass("PlayerGui")
		if v60 then
			local v61 = Instance.new("ScreenGui")
			v61.Name = "HushFilmGuides"
			v61.IgnoreGuiInset = true
			v61.ResetOnSpawn = false
			v61.DisplayOrder = 900
			v61.ScreenInsets = Enum.ScreenInsets.None
			local v62 = Color3.fromRGB(232, 163, 61)
			local v63 = Instance.new("Frame")
			v63.Name = "Frame"
			v63.BackgroundTransparency = 1
			v63.AnchorPoint = Vector2.new(0.5, 0.5)
			v63.Position = UDim2.fromScale(0.5, 0.5)
			v63.Size = UDim2.fromScale(1, 1)
			v63.Parent = v61
			if v58 ~= "" then
				local v64 = Instance.new("UIAspectRatioConstraint")
				v64.AspectRatio = v58 == "916" and 0.5625 or (v58 == "1:1" and 1 or 1.7777777777777777)
				local v65
				if v58 == "16:9" then
					v65 = Enum.DominantAxis.Width
				else
					v65 = Enum.DominantAxis.Height
				end
				v64.DominantAxis = v65
				v64.Parent = v63
				local v66 = Instance.new("UIStroke")
				v66.Color = v62
				v66.Thickness = 2
				v66.Transparency = 0.15
				v66.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				v66.BorderStrokePosition = Enum.BorderStrokePosition.Inner
				v66.Parent = v63
				local v67 = Instance.new("TextLabel")
				v67.Name = "Tag"
				v67.BackgroundTransparency = 1
				v67.Text = v58 == "916" and "9:16" or (v58 == "1:1" and "1:1  ICON" or "16:9  THUMBNAIL")
				v67.TextColor3 = v62
				v67.TextSize = 14
				v67.FontFace = Font.fromName("RobotoMono")
				v67.Position = UDim2.fromOffset(8, 6)
				v67.Size = UDim2.fromOffset(200, 18)
				v67.TextXAlignment = Enum.TextXAlignment.Left
				v67.Parent = v63
			end
			if v58 == "916" then
				local v68 = UDim2.fromScale(0, 0.8)
				local v69 = UDim2.new(1, 0, 0, 1)
				local v70 = Instance.new("Frame")
				v70.BackgroundColor3 = v62
				v70.BackgroundTransparency = 0.6
				v70.BorderSizePixel = 0
				v70.Position = v68
				v70.Size = v69
				v70.Parent = v63
				local v71 = UDim2.fromScale(0.85, 0)
				local v72 = UDim2.new(0, 1, 1, 0)
				local v73 = Instance.new("Frame")
				v73.BackgroundColor3 = v62
				v73.BackgroundTransparency = 0.6
				v73.BorderSizePixel = 0
				v73.Position = v71
				v73.Size = v72
				v73.Parent = v63
			elseif v58 == "1:1" then
				for _, v74 in { 0, 1 } do
					local v75 = Instance.new("Frame")
					v75.Name = "Mask"
					v75.BackgroundColor3 = Color3.new(0, 0, 0)
					v75.BackgroundTransparency = 0.45
					v75.BorderSizePixel = 0
					v75.AnchorPoint = Vector2.new(1 - v74, 0)
					v75.Position = UDim2.fromScale(v74, 0)
					v75.Size = UDim2.new(1, 0, 1, 0)
					v75.Parent = v63
				end
				local v76 = v_u_18 == "auto" and "bottom" or v_u_18
				if v76 == "bottom" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.1, 0.68), UDim2.fromScale(0.8, 0.22), "LOGO", v62)
				elseif v76 == "top" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.1, 0.1), UDim2.fromScale(0.8, 0.22), "LOGO", v62)
				end
				v_u_54(v63, 0.1)
			elseif v58 == "16:9" then
				v_u_54(v63, 0.05)
				local v77 = v_u_18 == "auto" and "left" or v_u_18
				if v77 == "left" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.06, 0.56), UDim2.fromScale(0.38, 0.36), "LOGO SPACE", v62)
				elseif v77 == "right" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.56, 0.56), UDim2.fromScale(0.38, 0.36), "LOGO SPACE", v62)
				elseif v77 == "bottom" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.25, 0.68), UDim2.fromScale(0.5, 0.26), "LOGO SPACE", v62)
				elseif v77 == "top" then
					v_u_49(v63, "Logo", UDim2.fromScale(0.25, 0.06), UDim2.fromScale(0.5, 0.26), "LOGO SPACE", v62)
				end
			end
			if p56 then
				local v78 = Color3.new(1, 1, 1)
				local v79 = UDim2.fromScale(0.3333333333333333, 0)
				local v80 = UDim2.new(0, 1, 1, 0)
				local v81 = Instance.new("Frame")
				v81.BackgroundColor3 = v78
				v81.BackgroundTransparency = 0.55
				v81.BorderSizePixel = 0
				v81.Position = v79
				v81.Size = v80
				v81.Parent = v63
				local v82 = UDim2.fromScale(0.6666666666666666, 0)
				local v83 = UDim2.new(0, 1, 1, 0)
				local v84 = Instance.new("Frame")
				v84.BackgroundColor3 = v78
				v84.BackgroundTransparency = 0.55
				v84.BorderSizePixel = 0
				v84.Position = v82
				v84.Size = v83
				v84.Parent = v63
				local v85 = UDim2.fromScale(0, 0.3333333333333333)
				local v86 = UDim2.new(1, 0, 0, 1)
				local v87 = Instance.new("Frame")
				v87.BackgroundColor3 = v78
				v87.BackgroundTransparency = 0.55
				v87.BorderSizePixel = 0
				v87.Position = v85
				v87.Size = v86
				v87.Parent = v63
				local v88 = UDim2.fromScale(0, 0.6666666666666666)
				local v89 = UDim2.new(1, 0, 0, 1)
				local v90 = Instance.new("Frame")
				v90.BackgroundColor3 = v78
				v90.BackgroundTransparency = 0.55
				v90.BorderSizePixel = 0
				v90.Position = v88
				v90.Size = v89
				v90.Parent = v63
			end
			v61.Parent = v60
			v_u_14 = v61
		end
	end
end
function v_u_4.setGuides(p91, p92) -- name: setGuides
	-- upvalues: (copy) v_u_4
	v_u_4.setGuideFrame(p91 and "916" or "", p92)
end
function v_u_4.guides() -- name: guides
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_18
	return v_u_16, v_u_17, v_u_18
end
function v_u_4.clear() -- name: clear
	-- upvalues: (copy) v_u_4, (ref) v_u_11, (ref) v_u_12, (ref) v_u_15
	v_u_4.setLook("Natural")
	v_u_4.setDof("off")
	v_u_4.setGuides(false, false)
	local v93 = workspace.CurrentCamera
	if v93 then
		for _, v94 in v93:GetChildren() do
			if v94:GetAttribute("FilmMode") ~= true then
				continue
			end
			v94:Destroy()
		end
	end
	v_u_11 = nil
	v_u_12 = nil
	v_u_15 = nil
end
return v_u_4