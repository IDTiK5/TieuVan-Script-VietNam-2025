-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvLayerRules

local v_u_35 = {
	["containerId"] = function(p1) -- name: containerId
		return "in:" .. p1
	end,
	["visibleCaseCount"] = function(p2) -- name: visibleCaseCount
		-- upvalues: (copy) v_u_35
		if type(p2) == "table" then
			local v3 = p2.cases
			if type(v3) == "table" then
				local v4 = p2.containers
				if type(v4) == "table" then
					local v5 = 0
					for _, v6 in p2.cases do
						if type(v6) ~= "string" then
							continue
						end
						local v7 = p2.containers[v_u_35.containerId(v6)]
						if type(v7) ~= "table" or v7.case ~= true then
							continue
						end
						v5 = v5 + 1
					end
					return v5
				end
			end
		end
		return 0
	end,
	["staleEntries"] = function(p8) -- name: staleEntries
		-- upvalues: (copy) v_u_35
		local v9 = {}
		if type(p8) == "table" then
			local v10 = p8.cases
			if type(v10) == "table" then
				local v11 = p8.containers
				local v12 = type(v11) ~= "table" and {} or p8.containers
				for _, v13 in p8.cases do
					local v14
					if type(v13) == "string" then
						v14 = v12[v_u_35.containerId(v13)]
					else
						v14 = nil
					end
					if type(v14) == "table" and v14.case == true then
						continue
					end
					table.insert(v9, v13)
				end
				return v9
			end
		end
		return v9
	end,
	["decide"] = function(p15) -- name: decide
		-- upvalues: (copy) v_u_35
		local v16 = {
			["layer"] = nil,
			["result"] = false,
			["stale"] = nil,
			["target"] = nil,
			["stale"] = {}
		}
		if type(p15) ~= "table" then
			return v16
		end
		local v17 = v_u_35.firstLayer({
			["drag"] = p15.drag,
			["ctx"] = p15.ctx,
			["inspect"] = p15.inspect,
			["sel"] = p15.sel,
			["selShown"] = p15.selShown
		})
		if v17 ~= nil then
			v16.layer = v17
			v16.result = true
			return v16
		end
		if p15.modal == true then
			v16.layer = "modal"
			v16.result = true
			return v16
		end
		local v18 = p15.mounts
		local v19 = type(v18) ~= "table" and {} or p15.mounts
		local v20 = {}
		for v21, v22 in v19 do
			if type(v22) ~= "table" or (v22.shown ~= true or (v22.raid == true or v22.dead == true)) then
				continue
			end
			local v23 = v22.work
			if type(v23) ~= "table" then
				continue
			end
			v20[v21] = true
			for _, v24 in v_u_35.staleEntries(v22.work) do
				local v25 = v16.stale
				table.insert(v25, {
					["mount"] = v21,
					["uid"] = v24
				})
			end
		end
		local v26 = p15.last
		local v27 = tonumber(v26)
		local v28
		if v27 == nil then
			for v31 = #v19, 1, -1 do
				if v20[v31] == true then
					v28 = v_u_35.visibleCaseCount(v19[v31].work) > 0
				else
					v28 = false
				end
				if not v28 then
					continue
				end
				v16.target = v31
			end
			if v16.target ~= nil then
				v16.layer = "case"
				v16.result = true
			end
			return v16
		else
			local v30
			if v20[v27] == true then
				v30 = v_u_35.visibleCaseCount(v19[v27].work) > 0
			else
				v30 = false
			end
			if v30 then
				v16.target = v27
				if v16.target ~= nil then
					v16.layer = "case"
					v16.result = true
				end
				return v16
			else
				for v31 = #v19, 1, -1 do
					if v20[v31] == true then
						v28 = v_u_35.visibleCaseCount(v19[v31].work) > 0
					else
						v28 = false
					end
					if not v28 then
						continue
					end
					v16.target = v31
				end
				if v16.target ~= nil then
					v16.layer = "case"
					v16.result = true
				end
				return v16
			end
		end
	end,
	["firstLayer"] = function(p32) -- name: firstLayer
		if type(p32) ~= "table" then
			return nil
		end
		if p32.drag == true then
			return "drag"
		end
		if p32.ctx == true then
			return "context"
		end
		if p32.inspect == true then
			return "inspect"
		end
		if p32.sel == true and p32.selShown == true then
			return "selection"
		end
		if p32.modal == true then
			return "modal"
		end
		local v33 = p32.cases
		return (tonumber(v33) or 0) > 0 and "case" or nil
	end,
	["visibleOnlyForKey"] = function(p34) -- name: visibleOnlyForKey
		return p34 == true
	end
}
return v_u_35