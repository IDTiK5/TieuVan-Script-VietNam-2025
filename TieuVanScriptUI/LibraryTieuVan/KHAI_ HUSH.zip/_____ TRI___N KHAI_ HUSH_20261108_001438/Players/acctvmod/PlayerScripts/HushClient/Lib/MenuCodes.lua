-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCodes

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = {}
local function v_u_6() -- name: texts
	-- upvalues: (copy) v_u_1
	local function v3()
		-- upvalues: (ref) v_u_1
		return require((v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("CodesRules")))
	end
	local v4, v5 = pcall(v3)
	return (not v4 or type(v5) ~= "table") and {
		["empty"] = "Type a code first.",
		["tooLong"] = "That is too long for a code. Type only the letters and numbers.",
		["network"] = "Could not reach the server. Check your connection and try again.",
		["off"] = "Codes are switched off right now."
	} or v5.TEXT
end
function v2.build(p_u_7, p8, p9, p10) -- name: build
	-- upvalues: (copy) v_u_6
	local v11 = p_u_7.ui
	local v12 = p_u_7.theme
	local v_u_13 = v12.color
	local v14 = p_u_7.kit
	local v_u_15 = v_u_6()
	local v_u_16 = true
	local v_u_17 = false
	local v_u_18 = false
	local v_u_19 = false
	local v_u_20 = v11.new("Frame", {
		["Name"] = "CodesRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p10
	}, p8)
	v11.layout(v_u_20, "v", 6)
	v_u_20.Destroying:Connect(function()
		-- upvalues: (ref) v_u_16
		v_u_16 = false
	end)
	v11.new("Frame", {
		["Name"] = "Gap",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 0,
		["Size"] = UDim2.new(1, 0, 0, 10)
	}, v_u_20)
	v14.section(v_u_20, "Redeem code", 1)
	v11.label({
		["parent"] = nil,
		["name"] = "CodesHelp",
		["text"] = "Got a code? Enter it here. Capital and small letters both work, spaces and dashes are ignored. Codes can end or run out, and many last only a few hours, so use them early. A code that has ended gives the same answer as a wrong one.",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 2,
		["parent"] = v_u_20,
		["color"] = v_u_13.text2
	})
	local v21 = math.min(p9, 300)
	local v_u_22, v_u_23 = v11.input({
		["parent"] = nil,
		["name"] = "CodeInput",
		["placeholder"] = "Enter code (codes expire)",
		["size"] = nil,
		["maxLength"] = 32,
		["parent"] = v_u_20,
		["size"] = UDim2.fromOffset(v21, v12.touch(44))
	})
	v_u_22.LayoutOrder = 3
	v_u_23.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_24 = v11.label({
		["parent"] = nil,
		["name"] = "CodeResult",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 5,
		["parent"] = v_u_20,
		["color"] = v_u_13.text2
	})
	local v_u_25 = nil
	local function v_u_36() -- name: press
		-- upvalues: (ref) v_u_17, (ref) v_u_16, (ref) v_u_19, (copy) v_u_15, (copy) v_u_24, (copy) v_u_13, (ref) v_u_18, (copy) v_u_23, (ref) v_u_25, (copy) p_u_7
		if v_u_17 or not v_u_16 then
			return
		elseif v_u_19 then
			v_u_24.Text = v_u_15.off or "Codes are switched off right now."
			v_u_24.TextColor3 = v_u_13.text2
			v_u_18 = false
			return
		else
			local v_u_26 = v_u_23.Text
			if string.find(v_u_26, "%S") == nil then
				v_u_24.Text = v_u_15.empty or "Type a code first."
				v_u_24.TextColor3 = v_u_13.danger
				v_u_18 = false
				return
			elseif #v_u_26 > 32 then
				v_u_24.Text = v_u_15.tooLong or "That is too long for a code. Type only the letters and numbers."
				v_u_24.TextColor3 = v_u_13.danger
				v_u_18 = false
			else
				v_u_17 = true
				v_u_25.setEnabled(false)
				v_u_25.setText("Redeeming...")
				v_u_24.Text = ""
				v_u_24.TextColor3 = v_u_13.text2
				v_u_18 = false
				task.spawn(function()
					-- upvalues: (ref) p_u_7, (copy) v_u_26, (ref) v_u_17, (ref) v_u_16, (ref) v_u_25, (ref) v_u_19, (ref) v_u_24, (ref) v_u_13, (ref) v_u_18, (ref) v_u_23, (ref) v_u_15
					local v27 = p_u_7.cctx.net.invoke
					local v28 = v_u_26
					local v29, v30 = pcall(v27, "codes.redeem", v28)
					v_u_17 = false
					if not v_u_16 then
						return
					end
					v_u_25.setText("Redeem")
					v_u_25.setEnabled(not v_u_19)
					if v29 and type(v30) == "table" then
						local v31 = v30.text
						if type(v31) == "string" then
							local v32 = v30.text
							local v33 = v30.ok == true
							v_u_24.Text = v32
							local v34 = v_u_24
							local v35
							if v33 == true then
								v35 = v_u_13.success
							elseif v33 == false then
								v35 = v_u_13.danger
							else
								v35 = v_u_13.text2
							end
							v34.TextColor3 = v35
							v_u_18 = v33 == true
							if v30.ok == true then
								v_u_23.Text = ""
								return
							end
						else
							v_u_24.Text = v_u_15.network or "Could not reach the server. Check your connection and try again."
							v_u_24.TextColor3 = v_u_13.danger
							v_u_18 = false
						end
					else
						v_u_24.Text = v_u_15.network or "Could not reach the server. Check your connection and try again."
						v_u_24.TextColor3 = v_u_13.danger
						v_u_18 = false
						return
					end
				end)
			end
		end
	end
	v_u_23.FocusLost:Connect(function(p37)
		-- upvalues: (copy) v_u_36
		if p37 then
			v_u_36()
		end
	end)
	local v38, v39 = v11.button({
		["parent"] = nil,
		["name"] = "CodeRedeem",
		["text"] = "Redeem",
		["kind"] = "secondary",
		["height"] = 44,
		["width"] = nil,
		["order"] = 4,
		["onClick"] = nil,
		["parent"] = v_u_20,
		["width"] = v21,
		["onClick"] = v_u_36
	})
	local v_u_40 = v38
	v_u_25 = v39
	v_u_40.LayoutOrder = 4
	local function v43()
		-- upvalues: (copy) p_u_7, (ref) v_u_16, (copy) v_u_20, (ref) v_u_19, (ref) v_u_17, (ref) v_u_25, (copy) v_u_23, (copy) v_u_15, (copy) v_u_24, (copy) v_u_13, (ref) v_u_18
		p_u_7.config.watchFlag("Codes", function(p41)
			-- upvalues: (ref) v_u_16, (ref) v_u_20, (ref) v_u_19, (ref) v_u_17, (ref) v_u_25, (ref) v_u_23, (ref) v_u_15, (ref) v_u_24, (ref) v_u_13, (ref) v_u_18
			if v_u_16 and v_u_20.Parent then
				v_u_20.Visible = true
				local v42 = v_u_19
				v_u_19 = p41 == false
				if not v_u_17 then
					v_u_25.setEnabled(not v_u_19)
				end
				v_u_23.TextEditable = not v_u_19
				if v_u_19 then
					v_u_24.Text = v_u_15.off or "Codes are switched off right now."
					v_u_24.TextColor3 = v_u_13.text2
					v_u_18 = false
					return
				end
				if v42 then
					v_u_24.Text = ""
					v_u_24.TextColor3 = v_u_13.text2
					v_u_18 = false
				end
			end
		end)
	end
	pcall(v43)
	local v_u_45 = {
		["root"] = v_u_20,
		["setText"] = function(p44) -- name: setText
			-- upvalues: (copy) v_u_23
			v_u_23.Text = p44
		end,
		["press"] = function() -- name: press
			-- upvalues: (copy) v_u_36
			v_u_36()
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_17, (copy) v_u_24, (ref) v_u_18, (copy) v_u_23, (copy) v_u_20, (ref) v_u_25, (ref) v_u_40, (copy) v_u_22
			return {
				["busy"] = v_u_17,
				["result"] = v_u_24.Text,
				["ok"] = v_u_18,
				["box"] = v_u_23.Text,
				["visible"] = v_u_20.Visible,
				["buttonText"] = v_u_25.label.Text,
				["buttonH"] = v_u_40.AbsoluteSize.Y,
				["boxH"] = v_u_22.AbsoluteSize.Y
			}
		end
	}
	local function v55()
		-- upvalues: (copy) p_u_7, (ref) v_u_16, (copy) v_u_45, (copy) v_u_36
		p_u_7.cctx.command("codes.ui", function(p46)
			-- upvalues: (ref) v_u_16, (ref) v_u_45, (ref) v_u_36
			if not v_u_16 then
				return "gone"
			end
			if p46[1] == "type" then
				v_u_45.setText(table.concat(p46, " ", 2))
				return "typed"
			end
			if p46[1] == "press" then
				v_u_36()
				return "pressed"
			end
			local v47 = v_u_45.state()
			local v48 = v47.busy
			local v49 = tostring(v48)
			local v50 = v47.ok
			local v51 = tostring(v50)
			local v52 = v47.result
			local v53 = v47.box
			local v54 = v47.visible
			return ("busy=%s ok=%s result=[%s] box=[%s] visible=%s button=[%s] buttonH=%d boxH=%d"):format(v49, v51, v52, v53, tostring(v54), v47.buttonText, v47.buttonH, v47.boxH)
		end)
	end
	pcall(v55)
	return v_u_45
end
return v2