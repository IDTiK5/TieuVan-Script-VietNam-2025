-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassXp

return {
	["open"] = function(p1, p2, p3, p4, p5) -- name: open
		local v_u_6 = p1.ui
		local v_u_7 = p1.theme.color
		local v_u_8 = p2.xpGuide(p3)
		if not v_u_8.ok then
			return nil
		end
		local v9 = v_u_6.modal
		local v31 = {
			["title"] = v_u_8.title,
			["width"] = math.min(560, p4 or 480),
			["buttons"] = {
				{
					["text"] = nil,
					["kind"] = "primary",
					["text"] = p2.TEXT.close
				}
			},
			["onClose"] = p5,
			["build"] = function(p10) -- name: build
				-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_7
				local v11 = 0
				local v12 = v_u_6.label({
					["parent"] = nil,
					["name"] = "Intro",
					["text"] = nil,
					["style"] = "small",
					["textSize"] = 13,
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = p10,
					["text"] = v_u_8.intro,
					["color"] = v_u_7.text2
				})
				v11 = v11 + 1
				v12.LayoutOrder = v11
				local v13 = v_u_6.label({
					["parent"] = nil,
					["name"] = "SourcesHead",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["parent"] = p10,
					["text"] = v_u_8.sourcesHead,
					["color"] = v_u_7.accent,
					["size"] = UDim2.new(1, 0, 0, 18)
				})
				v11 = v11 + 1
				v13.LayoutOrder = v11
				local v14 = v11
				for _, v15 in v_u_8.rows do
					local v16 = v_u_6.new
					local v17 = {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "Source_" .. v15.key,
						["BackgroundColor3"] = v_u_7.raised,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}
					v11 = v14 + 1
					v17.LayoutOrder = v11
					local v18 = v16("Frame", v17, p10)
					v_u_6.stroke(v18, v_u_7.line, 1, 0.2)
					v_u_6.pad(v18, 8)
					local v19 = v_u_6.new("Frame", {
						["Name"] = "IconBox",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_7.accentDeep,
						["Position"] = UDim2.fromOffset(0, 0),
						["Size"] = UDim2.fromOffset(30, 30)
					}, v18)
					v_u_6.stroke(v19, v_u_7.accent, 1, 0.5)
					local v20 = v_u_6.icon(v15.icon, {
						["parent"] = nil,
						["size"] = 18,
						["color"] = nil,
						["parent"] = v19,
						["color"] = v_u_7.accent
					})
					v20.AnchorPoint = Vector2.new(0.5, 0.5)
					v20.Position = UDim2.fromScale(0.5, 0.5)
					local v21 = v_u_6.new("Frame", {
						["Name"] = "Body",
						["BackgroundTransparency"] = 1,
						["Position"] = nil,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["Position"] = UDim2.fromOffset(40, 0),
						["Size"] = UDim2.new(1, -40, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}, v18)
					v_u_6.layout(v21, "v", 2)
					v_u_6.label({
						["parent"] = nil,
						["name"] = "Title",
						["text"] = nil,
						["style"] = "h3",
						["textSize"] = 14,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = v21,
						["text"] = v15.title,
						["color"] = v_u_7.text
					})
					v_u_6.label({
						["parent"] = nil,
						["name"] = "Amount",
						["text"] = nil,
						["style"] = "monoS",
						["textSize"] = 12,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["parent"] = v21,
						["text"] = v15.amount,
						["color"] = v_u_7.accent
					})
					if v15.note ~= "" then
						v_u_6.label({
							["parent"] = nil,
							["name"] = "Note",
							["text"] = nil,
							["style"] = "small",
							["textSize"] = 12,
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 3,
							["parent"] = v21,
							["text"] = v15.note,
							["color"] = v_u_7.text2
						})
					end
					v_u_6.new("UISizeConstraint", {
						["MinSize"] = Vector2.new(0, 46)
					}, v18)
					v14 = v11
				end
				local v22 = v_u_6.label({
					["parent"] = nil,
					["name"] = "LimitHead",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["parent"] = p10,
					["text"] = v_u_8.limitHead,
					["color"] = v_u_7.accent,
					["size"] = UDim2.new(1, 0, 0, 18)
				})
				v11 = v14 + 1
				v22.LayoutOrder = v11
				local v23 = v_u_6.new
				local v24 = {
					["Name"] = "Limit",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = nil,
					["BackgroundColor3"] = v_u_7.raised,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}
				v11 = v11 + 1
				v24.LayoutOrder = v11
				local v25 = v23("Frame", v24, p10)
				v_u_6.stroke(v25, v_u_7.info, 1, 0.5)
				v_u_6.pad(v25, 10)
				v_u_6.layout(v25, "v", 4)
				for v26, v27 in v_u_8.limit do
					local v28 = v_u_6.label
					local v29 = {
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 13,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v25,
						["name"] = "Line" .. v26,
						["text"] = v27
					}
					local v30
					if v26 == 1 then
						v30 = v_u_7.text
					else
						v30 = v_u_7.text2
					end
					v29.color = v30
					v29.order = v26
					v28(v29)
				end
			end
		}
		return v9(v31)
	end
}