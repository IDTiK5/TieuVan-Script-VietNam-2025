-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTabFade

local v_u_62 = {
	["FADE_W"] = 56,
	["MIN_REAL"] = 19,
	["TOL"] = 2,
	["TOUCH"] = 44,
	["MAX_OUT"] = 32,
	["rightHit"] = function(p1, p2, p3) -- name: rightHit
		-- upvalues: (copy) v_u_62
		local v4 = p2
		for _, v5 in p1 do
			if v5.r <= p2 + v_u_62.TOL or v5.l >= p2 - v_u_62.TOL then
				continue
			end
			local v6 = v5.l
			v4 = math.min(v4, v6)
		end
		local v7 = p2 - v4
		local v8 = math.max(p3, 0.01)
		local v9 = v7 / v8 + 0.5
		local v10 = math.floor(v9)
		local v11 = v_u_62.MIN_REAL / v8
		local v12 = math.ceil(v11)
		local v13 = v_u_62.FADE_W
		return math.clamp(v10, v12, v13)
	end,
	["leftHit"] = function(p14, p15, p16) -- name: leftHit
		-- upvalues: (copy) v_u_62
		local v17 = p15
		for _, v18 in p14 do
			if v18.l >= p15 - v_u_62.TOL or v18.r <= p15 + v_u_62.TOL then
				continue
			end
			local v19 = v18.r
			v17 = math.max(v17, v19)
		end
		local v20 = v17 - p15
		local v21 = math.max(p16, 0.01)
		local v22 = v20 / v21 + 0.5
		local v23 = math.floor(v22)
		local v24 = v_u_62.MIN_REAL / v21
		local v25 = math.ceil(v24)
		local v26 = v_u_62.FADE_W
		return math.clamp(v23, v25, v26)
	end,
	["outside"] = function(p27, p28, p29) -- name: outside
		-- upvalues: (copy) v_u_62
		local v30 = math.max(p28, 0.01)
		local v31 = (v_u_62.TOUCH - p27 * v30) / v30 - 0.0001
		local v32 = math.ceil(v31)
		local v33 = p29 or v_u_62.MAX_OUT
		local v34 = math.max(0, v33)
		return math.clamp(v32, 0, v34)
	end,
	["leftGap"] = function(p35, p36) -- name: leftGap
		local v37 = p35 - p36 - 1
		return math.max(0, v37)
	end,
	["areas"] = function(p38, p39, p40, p41, p42) -- name: areas
		-- upvalues: (copy) v_u_62
		local v43 = v_u_62.rightHit(p38, p40, p41)
		local v44 = v_u_62.leftHit(p38, p39, p41)
		local v45 = {
			["right"] = {
				["w"] = v43,
				["out"] = v_u_62.outside(v43, p41)
			},
			["left"] = {
				["w"] = v44,
				["out"] = v_u_62.outside(v44, p41, p42)
			}
		}
		return v45
	end,
	["areasFor"] = function(p46, p47, p48, p49, p50, p51) -- name: areasFor
		-- upvalues: (copy) v_u_62
		return v_u_62.areas(p46, p47, p48, p49, v_u_62.leftGap(p50, p51))
	end,
	["hitsRight"] = function(p52, p53, p54, p55) -- name: hitsRight
		local v56
		if p53 - p54 * p55 <= p52 then
			v56 = p52 <= p53
		else
			v56 = false
		end
		return v56
	end,
	["hitsLeft"] = function(p57, p58, p59, p60) -- name: hitsLeft
		local v61
		if p58 <= p57 then
			v61 = p57 <= p58 + p59 * p60
		else
			v61 = false
		end
		return v61
	end
}
return v_u_62