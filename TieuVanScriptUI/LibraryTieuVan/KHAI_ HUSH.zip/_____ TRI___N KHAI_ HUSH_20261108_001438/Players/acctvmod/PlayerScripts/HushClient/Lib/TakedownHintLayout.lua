-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TakedownHintLayout

local v_u_42 = {
	["CROSS_HALF"] = 28,
	["PANEL_H"] = 44,
	["CHIP"] = 28,
	["PAD"] = 10,
	["GAP"] = 8,
	["TEXT_W"] = 112,
	["MARGIN"] = 12,
	["compute"] = function(p1, p2, p3) -- name: compute
		-- upvalues: (copy) v_u_42
		local v4 = (type(p1) ~= "number" or (p1 ~= p1 or p1 <= 0)) and 1920 or p1
		local v5 = (type(p2) ~= "number" or (p2 ~= p2 or p2 <= 0)) and 1080 or p2
		if p3 then
			return {
				["show"] = false,
				["panel"] = nil,
				["label"] = nil,
				["anchorX"] = nil,
				["anchorY"] = nil,
				["panel"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0
				},
				["label"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0
				},
				["anchorX"] = v4 / 2,
				["anchorY"] = v5 / 2
			}
		end
		local v6 = v_u_42.PAD + v_u_42.CHIP + v_u_42.GAP + v_u_42.TEXT_W + v_u_42.PAD
		local v7 = v_u_42.PANEL_H
		local v8 = v4 / 2
		local v9 = v5 / 2
		local v10 = v8 - v6 / 2
		local v11 = v_u_42.MARGIN
		local v12 = v_u_42.MARGIN
		local v13 = v4 - v_u_42.MARGIN - v6
		local v14 = math.max(v12, v13)
		local v15 = math.clamp(v10, v11, v14)
		local v16 = v9 + v_u_42.CROSS_HALF + 22
		local v17 = v_u_42.MARGIN
		local v18 = v_u_42.MARGIN
		local v19 = v5 - v_u_42.MARGIN - v7
		local v20 = math.max(v18, v19)
		local v21 = math.clamp(v16, v17, v20)
		local v22 = {
			["x"] = v15,
			["y"] = v21,
			["w"] = v6,
			["h"] = v7
		}
		local v23 = {
			["x"] = v15 + v_u_42.PAD,
			["y"] = v21 + (v7 - v_u_42.CHIP) / 2,
			["w"] = v_u_42.CHIP,
			["h"] = v_u_42.CHIP
		}
		local v24 = v23.x + v23.w + v_u_42.GAP
		return {
			["show"] = true,
			["panel"] = nil,
			["chip"] = nil,
			["label"] = nil,
			["anchorX"] = nil,
			["anchorY"] = nil,
			["panel"] = v22,
			["chip"] = v23,
			["label"] = {
				["x"] = v24,
				["y"] = v21,
				["w"] = v15 + v6 - v_u_42.PAD - v24,
				["h"] = v7
			},
			["anchorX"] = v8,
			["anchorY"] = v9
		}
	end,
	["fitChip"] = function(p25, p26, p27) -- name: fitChip
		-- upvalues: (copy) v_u_42
		if type(p25) == "table" and p25.show == true then
			local v28 = p25.chip
			if type(v28) == "table" then
				if type(p27) ~= "number" or (p27 ~= p27 or p27 <= 0) then
					p27 = p25.anchorX * 2
				end
				if type(p26) ~= "number" or (p26 ~= p26 or p25.chip.w >= p26) then
					p26 = p25.chip.w
				end
				local v29 = v_u_42.PAD + p26 + v_u_42.GAP + v_u_42.TEXT_W + v_u_42.PAD
				local v30 = p25.anchorX - v29 / 2
				local v31 = v_u_42.MARGIN
				local v32 = v_u_42.MARGIN
				local v33 = p27 - v_u_42.MARGIN - v29
				local v34 = math.max(v32, v33)
				local v35 = math.clamp(v30, v31, v34)
				local v36 = p25.panel.y
				local v37 = {
					["x"] = v35,
					["y"] = v36,
					["w"] = v29,
					["h"] = p25.panel.h
				}
				local v38 = {
					["x"] = v35 + v_u_42.PAD,
					["y"] = p25.chip.y,
					["w"] = p26,
					["h"] = p25.chip.h
				}
				local v39 = v38.x + v38.w + v_u_42.GAP
				return {
					["show"] = true,
					["panel"] = nil,
					["chip"] = nil,
					["label"] = nil,
					["anchorX"] = nil,
					["anchorY"] = nil,
					["panel"] = v37,
					["chip"] = v38,
					["label"] = {
						["x"] = v39,
						["y"] = v36,
						["w"] = v35 + v29 - v_u_42.PAD - v39,
						["h"] = p25.panel.h
					},
					["anchorX"] = p25.anchorX,
					["anchorY"] = p25.anchorY
				}
			end
		end
		return p25
	end,
	["textFits"] = function(p40, p41) -- name: textFits
		return p40 <= p41.w
	end
}
return v_u_42