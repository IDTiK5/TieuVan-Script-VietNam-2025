-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketLayout

local v_u_101 = {
	["STRIP_H"] = 48,
	["STRIP_H_PHONE"] = 40,
	["WARN_H"] = 30,
	["VIEW_W"] = 156,
	["VIEW_H"] = 36,
	["MAIL_W"] = 120,
	["MAIL_H"] = 26,
	["MARGIN"] = 8,
	["TEXT_X"] = 14,
	["metrics"] = function(p1, p2) -- name: metrics
		return {
			["panelX"] = p1 and (p2 and 12 or 20) or 24,
			["panelY"] = p1 and (p2 and 2 or 6) or 8,
			["padL"] = p1 and 10 or 16,
			["padR"] = p1 and 10 or 16,
			["padT"] = p1 and 6 or 10,
			["padB"] = p1 and 4 or 8,
			["hdr"] = p1 and 32 or 56,
			["gap"] = p1 and 4 or 8,
			["bannerH"] = p1 and 24 or 28
		}
	end,
	["frame"] = function(p3, p4, p5, p6) -- name: frame
		-- upvalues: (copy) v_u_101
		local v7 = v_u_101.metrics(p5, p6)
		local v8 = v7.panelX
		local v9 = v7.panelY
		local v10 = p3 - 2 * v7.panelX
		local v11 = math.max(0, v10)
		local v12 = p4 - v7.panelY
		local v13 = {
			["x"] = v8,
			["y"] = v9,
			["w"] = v11,
			["h"] = math.max(0, v12)
		}
		local v14 = v13.x + v7.padL
		local v15 = v13.y + v7.padT
		local v16 = v13.w - v7.padL - v7.padR
		local v17 = math.max(0, v16)
		local v18 = v13.h - v7.padT - v7.padB
		local v19 = {
			["x"] = v14,
			["y"] = v15,
			["w"] = v17,
			["h"] = math.max(0, v18)
		}
		return {
			["panel"] = v13,
			["inner"] = v19,
			["header"] = {
				["x"] = v19.x,
				["y"] = v19.y,
				["w"] = v19.w,
				["h"] = v7.hdr
			}
		}
	end,
	["strip"] = function(p20) -- name: strip
		-- upvalues: (copy) v_u_101
		local v21 = type(p20) ~= "table" and {} or p20
		local v22 = v21.phone == true
		local v23 = v21.floor
		local v24 = (type(v23) ~= "number" or (v23 ~= v23 or (v23 <= (-1 / 0) or v23 >= (1 / 0)))) and 1 or v23
		local v25 = math.ceil(v24)
		local v26 = math.max(1, v25)
		local v27 = v21.w
		local v28 = (type(v27) ~= "number" or (v27 ~= v27 or (v27 <= (-1 / 0) or v27 >= (1 / 0)))) and 0 or v27
		local v29 = math.max(0, v28)
		local v30 = v_u_101.MARGIN
		local v31, v32, v33
		if v22 then
			local v34 = v_u_101.STRIP_H_PHONE
			v31 = math.max(v34, v26)
			local v35 = v29 - v30 - v31
			v32 = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = math.max(0, v35),
				["w"] = v31,
				["h"] = v31
			}
			v33 = v31
		else
			local v36 = v_u_101.VIEW_H
			local v37 = math.max(v36, v26)
			local v38 = v_u_101.STRIP_H
			local v39 = v37 + 8
			v33 = math.max(v38, v39)
			v31 = v_u_101.VIEW_W
			local v40 = v29 - v30 - v31
			local v41 = math.max(0, v40)
			local v42 = (v33 - v37) / 2
			v32 = {
				["x"] = v41,
				["y"] = math.floor(v42),
				["w"] = v31,
				["h"] = v37
			}
		end
		local v43 = v29 - (v_u_101.TEXT_X + v31 + 12)
		local v44 = math.max(0, v43)
		local v45 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v_u_101.TEXT_X,
			["w"] = v44,
			["h"] = v33
		}
		local v46 = (v33 - 44) / 2
		local v47 = math.floor(v46)
		local v48 = math.max(0, v47)
		local v49 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 26,
			["x"] = v_u_101.TEXT_X,
			["y"] = v48,
			["w"] = v44
		}
		local v50 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 18,
			["x"] = v_u_101.TEXT_X,
			["y"] = v48 + 26,
			["w"] = v44
		}
		local v51 = v_u_101.MAIL_H
		local v52 = math.max(v51, v26)
		local v53 = v_u_101.WARN_H
		local v54 = v52 + 4
		local v55 = math.max(v53, v54)
		local v56 = v29 - v30 - v_u_101.MAIL_W
		local v57 = math.max(0, v56)
		local v58 = (v55 - v52) / 2
		local v59 = {
			["x"] = v57,
			["y"] = v33 + math.floor(v58),
			["w"] = v_u_101.MAIL_W,
			["h"] = v52
		}
		local v60 = v_u_101.TEXT_X
		local v61 = v29 - (v_u_101.TEXT_X + v_u_101.MAIL_W + 16)
		local v62 = {
			["x"] = v60,
			["y"] = v33,
			["w"] = math.max(0, v61),
			["h"] = v55
		}
		return {
			["mainH"] = v33,
			["warnH"] = v55,
			["total"] = v33 + (v21.warn ~= true and 0 or v55),
			["view"] = v32,
			["text"] = v45,
			["textTop"] = v49,
			["drop"] = v50,
			["mail"] = v59,
			["warnText"] = v62,
			["viewW"] = v31
		}
	end,
	["stack"] = function(p63) -- name: stack
		-- upvalues: (copy) v_u_101
		local v64 = type(p63) ~= "table" and {} or p63
		local v65 = v64.compact == true
		local v66 = v_u_101.metrics(v65, v64.phone == true)
		local v67 = v64.subH
		local v68 = (type(v67) ~= "number" or (v67 ~= v67 or (v67 <= (-1 / 0) or v67 >= (1 / 0)))) and 40 or v67
		local v69 = math.max(0, v68)
		local v70 = v64.stripPx
		local v71 = (type(v70) ~= "number" or (v70 ~= v70 or (v70 <= (-1 / 0) or v70 >= (1 / 0)))) and 0 or v70
		local v72 = math.max(0, v71)
		local v73 = v64.subHidden == true
		local v74 = v66.hdr + v66.gap
		local v75
		if v72 > 0 then
			v75 = not (v73 and v65)
		else
			v75 = false
		end
		local v76 = not v75 and 0 or v72 + v66.gap
		local v77
		if v73 then
			v77 = v74
		else
			v77 = v74 + v69 + v66.gap
		end
		local v78 = v77 + v76
		local v79
		if v64.bannerShown == true then
			v79 = v78 + (v66.bannerH + v66.gap)
		else
			v79 = v78
			v78 = nil
		end
		return {
			["stripShown"] = v75,
			["stripY"] = v74,
			["stripH"] = not v75 and 0 or v72,
			["subRowY"] = v74 + v76,
			["bannerY"] = v78,
			["bodyY"] = v79
		}
	end,
	["rects"] = function(p80, p81, p82) -- name: rects
		-- upvalues: (copy) v_u_101
		local v83 = type(p82) ~= "table" and {} or p82
		local v84 = v83.compact == true
		local v85 = v83.phone == true
		local v86 = v_u_101.frame(p80, p81, v84, v85)
		local v87 = v_u_101.stack(v83)
		local v88 = v_u_101.metrics(v84, v85)
		local v89 = v86.inner
		local v90 = v83.subH
		local v91 = (type(v90) ~= "number" or (v90 ~= v90 or (v90 <= (-1 / 0) or v90 >= (1 / 0)))) and 40 or v90
		local v92 = math.max(0, v91)
		local v93 = v87.stripShown and {
			["x"] = v89.x,
			["y"] = v89.y + v87.stripY,
			["w"] = v89.w,
			["h"] = v87.stripH
		} or nil
		local v94 = v83.subHidden ~= true and {
			["x"] = v89.x,
			["y"] = v89.y + v87.subRowY,
			["w"] = v89.w,
			["h"] = v92
		} or nil
		local v95 = v87.bannerY ~= nil and {
			["x"] = v89.x,
			["y"] = v89.y + v87.bannerY,
			["w"] = v89.w,
			["h"] = v88.bannerH
		} or nil
		local v96 = v89.x
		local v97 = v89.y + v87.bodyY
		local v98 = v89.w
		local v99 = v89.h - v87.bodyY
		local v100 = {
			["x"] = v96,
			["y"] = v97,
			["w"] = v98,
			["h"] = math.max(0, v99)
		}
		return {
			["panel"] = v86.panel,
			["inner"] = v89,
			["header"] = v86.header,
			["strip"] = v93,
			["subRow"] = v94,
			["banner"] = v95,
			["body"] = v100,
			["stack"] = v87
		}
	end
}
return v_u_101