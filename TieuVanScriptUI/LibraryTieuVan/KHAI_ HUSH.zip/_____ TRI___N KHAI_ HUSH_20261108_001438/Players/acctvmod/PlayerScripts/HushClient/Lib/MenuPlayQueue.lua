-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayQueue

local v_u_1 = {
	["PAD"] = 12,
	["GAP"] = 8,
	["TITLE_H"] = 20,
	["LABEL"] = 15,
	["LABEL_LINE"] = 20,
	["NOTE"] = 12,
	["NOTE_LINE"] = 16,
	["SWITCH_W"] = 64,
	["CHIP_MIN"] = 96,
	["CHIP_TEXT"] = 14,
	["CHIP_PAD"] = 8,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["ORDER"] = {
		"NA",
		"SA",
		"EU",
		"AS",
		"OC",
		"MEA"
	}
}
local v_u_2 = game:GetService("ReplicatedStorage")
function v_u_1.textW(p3, p4, p5) -- name: textW
	-- upvalues: (copy) v_u_1
	local v6 = (utf8.len(p3) or #p3) * p4
	local v7
	if p5 == true then
		v7 = v_u_1.CHAR_CAPS
	else
		v7 = v_u_1.CHAR
	end
	local v8 = v6 * v7 + 2
	return math.ceil(v8)
end
function v_u_1.lines(p9, p10, p11) -- name: lines
	local v12 = (utf8.len(p9) or #p9) * p10 * 0.6
	local v13 = p11 * 0.92
	local v14 = v12 / math.max(40, v13)
	local v15 = math.ceil(v14)
	return math.max(1, v15)
end
function v_u_1.layout(p16, p17) -- name: layout
	-- upvalues: (copy) v_u_1
	local v18 = v_u_1
	local v19 = p17.T
	local v20 = v18.PAD
	local v21 = v18.GAP
	local v22 = p16 - 2 * v20
	local v23 = p17.touchH
	local v24 = type(v23) ~= "number" and 40 or p17.touchH
	local v25 = {
		["x"] = v20,
		["y"] = v20,
		["w"] = v22,
		["h"] = v18.TITLE_H
	}
	local v26 = v20 + (v18.TITLE_H + v21)
	local v27 = {
		["w"] = p16,
		["title"] = v25
	}
	if p17.optIn then
		local v28 = v22 - v18.SWITCH_W - v21
		local v29 = v19.OPTIN
		local v30 = v18.LABEL
		local v31 = (utf8.len(v29) or #v29) * v30 * 0.6
		local v32 = v28 * 0.92
		local v33 = v31 / math.max(40, v32)
		local v34 = math.ceil(v33)
		local v35 = math.max(1, v34)
		local v36 = v35 * v18.LABEL_LINE + 8
		local v37 = math.max(v24, v36)
		local v38 = {
			["label"] = {
				["x"] = v20,
				["y"] = v26,
				["w"] = v28,
				["h"] = v37
			},
			["switch"] = {
				["x"] = v20 + v22 - v18.SWITCH_W,
				["y"] = v26,
				["w"] = v18.SWITCH_W,
				["h"] = v37
			},
			["rowH"] = v37,
			["labelLines"] = v35
		}
		local v39 = v26 + (v37 + 2)
		local v40 = v19.OPTIN_NOTE
		local v41 = v18.NOTE
		local v42 = (utf8.len(v40) or #v40) * v41 * 0.6
		local v43 = v22 * 0.92
		local v44 = v42 / math.max(40, v43)
		local v45 = math.ceil(v44)
		v38.note = {
			["x"] = v20,
			["y"] = v39,
			["w"] = v22,
			["h"] = math.max(1, v45) * v18.NOTE_LINE
		}
		local v46 = v39 + v38.note.h
		if p17.agree then
			local v47 = v46 + 2
			v38.agree = {
				["x"] = v20,
				["y"] = v47,
				["w"] = v22,
				["h"] = v18.NOTE_LINE
			}
			v46 = v47 + v18.NOTE_LINE
		end
		v26 = v46 + v21
		v27.opt = v38
	end
	if p17.regionsOn then
		local v48 = {
			["header"] = {
				["x"] = v20,
				["y"] = v26,
				["w"] = v22,
				["h"] = v18.LABEL_LINE
			}
		}
		local v49 = v26 + (v18.LABEL_LINE + 2)
		local v50 = v19.REGIONS_NOTE
		local v51 = v18.NOTE
		local v52 = (utf8.len(v50) or #v50) * v51 * 0.6
		local v53 = v22 * 0.92
		local v54 = v52 / math.max(40, v53)
		local v55 = math.ceil(v54)
		v48.note = {
			["x"] = v20,
			["y"] = v49,
			["w"] = v22,
			["h"] = math.max(1, v55) * v18.NOTE_LINE
		}
		local v56 = v49 + (v48.note.h + v21)
		local v57 = p17.chipMin
		local v58
		if type(v57) == "number" then
			v58 = p17.chipMin
		else
			v58 = v18.CHIP_MIN
		end
		local v59 = (v22 + v21) / (v58 + v21)
		local v60 = math.floor(v59)
		local v61 = math.max(2, v60)
		local v62 = math.min(3, v61)
		local v63 = (v22 - (v62 - 1) * v21) / v62
		local v64 = math.floor(v63)
		v48.chips = {}
		for v65 = 1, #v18.ORDER do
			local v66 = (v65 - 1) / v62
			local v67 = math.floor(v66)
			local v68 = (v65 - 1) % v62
			v48.chips[v65] = {
				["x"] = v20 + v68 * (v64 + v21),
				["y"] = v56 + v67 * (v24 + v21),
				["w"] = v64,
				["h"] = v24
			}
		end
		local v69 = #v18.ORDER / v62
		local v70 = math.ceil(v69)
		v26 = v56 + (v70 * v24 + (v70 - 1) * v21)
		v27.cols = v62
		v27.chipW = v64
		v48.hints = {}
		for _, v71 in p17.hints or {} do
			local v72 = v26 + 4
			local v73 = v18.NOTE
			local v74 = (utf8.len(v71) or #v71) * v73 * 0.6
			local v75 = v22 * 0.92
			local v76 = v74 / math.max(40, v75)
			local v77 = math.ceil(v76)
			local v78 = math.max(1, v77) * v18.NOTE_LINE
			local v79 = v48.hints
			table.insert(v79, {
				["x"] = v20,
				["y"] = v72,
				["w"] = v22,
				["h"] = v78
			})
			v26 = v72 + v78
		end
		if p17.full then
			local v80 = v26 + 4
			local v81 = v19.REGIONS_LIMIT
			local v82 = v18.NOTE
			local v83 = (utf8.len(v81) or #v81) * v82 * 0.6
			local v84 = v22 * 0.92
			local v85 = v83 / math.max(40, v84)
			local v86 = math.ceil(v85)
			v48.limit = {
				["x"] = v20,
				["y"] = v80,
				["w"] = v22,
				["h"] = math.max(1, v86) * v18.NOTE_LINE
			}
			v26 = v80 + v48.limit.h
		end
		v27.reg = v48
	end
	v27.h = v26 + v20
	v27.touchH = v24
	return v27
end
function v_u_1.chipMinFor(p_u_87) -- name: chipMinFor
	-- upvalues: (copy) v_u_1
	local v88, v89 = pcall(function()
		-- upvalues: (copy) p_u_87
		return p_u_87.isTouch()
	end)
	local v90
	if v88 and v89 == true then
		local v91, v92 = pcall(function()
			-- upvalues: (copy) p_u_87
			return p_u_87.uiScale()
		end)
		local v93 = (not v91 or type(v92) ~= "number") and 1 or v92
		local v94 = 20 / math.max(v93, 0.5)
		local v95 = math.ceil(v94)
		v90 = math.max(20, v95)
	else
		v90 = 20
	end
	return v_u_1.textW("MEA", 17, true) + v90 * 2
end
function v_u_1.toggleRegion(p96, p97, p98, p99) -- name: toggleRegion
	-- upvalues: (copy) v_u_1
	local v100 = false
	for _, v101 in v_u_1.ORDER do
		if v101 ~= p97 then
			continue
		end
		v100 = true
	end
	if not v100 then
		return p96, "unknown"
	end
	if p97 == p98 then
		return p96, "own"
	end
	local v102 = {}
	local v103 = false
	for _, v104 in p96 do
		if v104 == p97 then
			v103 = true
		else
			table.insert(v102, v104)
		end
	end
	if v103 then
		return v102, nil
	end
	if p99 <= #v102 then
		return p96, "limit"
	end
	table.insert(v102, p97)
	return v102, nil
end
function v_u_1.hintsFor(_, p105, p106, p107) -- name: hintsFor
	local v108 = {}
	for _, v109 in p106 do
		local v110 = v109 .. ": " .. p105.pingHint(p107, v109)
		table.insert(v108, v110)
	end
	return v108
end
local function v_u_117(p_u_111) -- name: rulesMod
	-- upvalues: (copy) v_u_2
	local v112, v113 = pcall(function()
		-- upvalues: (copy) p_u_111
		return p_u_111.cctx.shared.PaidRules
	end)
	if v112 and type(v113) == "table" then
		return v113
	else
		local function v114()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("PaidRules", 5)))
		end
		local v115, v116 = pcall(v114)
		if v115 and type(v116) == "table" then
			return v116
		else
			return nil
		end
	end
end
local function v_u_123(p_u_118) -- name: storeMod
	local v119, v120 = pcall(function()
		-- upvalues: (copy) p_u_118
		return p_u_118.cctx.lib.QueueOptionsStore
	end)
	if v119 and type(v120) == "table" then
		return v120
	elseif v119 and v120 == false then
		return nil
	else
		local v121, v122 = pcall(function()
			return require((script.Parent:WaitForChild("QueueOptionsStore", 5)))
		end)
		if v121 and type(v122) == "table" then
			return v122
		else
			return nil
		end
	end
end
function v_u_1.build(p_u_124, p125, p126) -- name: build
	-- upvalues: (copy) v_u_117, (copy) v_u_123, (copy) v_u_1
	local v_u_127 = p_u_124.ui
	local v_u_128 = p_u_124.theme
	local v_u_129 = v_u_128.color
	local v_u_130 = v_u_117(p_u_124)
	local v_u_131 = v_u_123(p_u_124)
	local v_u_132 = not v_u_130 and {} or v_u_130.QUEUE_TEXT
	local v_u_133
	if type(p126) == "table" then
		local v134 = p126.width
		v_u_133 = type(v134) ~= "number" and 360 or p126.width
	else
		v_u_133 = 360
	end
	local v_u_135
	if type(p126) == "table" then
		local v136 = p126.send
		v_u_135 = type(v136) ~= "function" and function(p138)
			-- upvalues: (copy) p_u_124
			p_u_124.partyOp(p138)
		end or p126.send
	else
		v_u_135 = function(p138)
			-- upvalues: (copy) p_u_124
			p_u_124.partyOp(p138)
		end
	end
	local v_u_139 = v_u_127.new("Frame", {
		["Name"] = "QueueOptions",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_129.raised,
		["Size"] = UDim2.fromOffset(v_u_133, 10),
		["LayoutOrder"] = (type(p126) ~= "table" or not p126.order) and 0 or p126.order
	}, p125)
	pcall(function()
		-- upvalues: (copy) v_u_127, (copy) v_u_139, (copy) v_u_129
		v_u_127.corner(v_u_139, 8)
		v_u_127.stroke(v_u_139, v_u_129.line)
	end)
	local v_u_140 = {}
	if v_u_131 == nil then
		warn("[MenuPlayQueue] QueueOptionsStore is missing: the queue options stay hidden")
		function v_u_140.set() -- name: set end
		function v_u_140.lock() -- name: lock end
		function v_u_140.height() -- name: height
			return 0
		end
		function v_u_140.destroy() -- name: destroy
			-- upvalues: (copy) v_u_139
			v_u_139:Destroy()
		end
		return v_u_139, v_u_140
	end
	local v_u_141
	if type(p126) == "table" and p126.store ~= nil then
		v_u_141 = p126.store
	else
		v_u_141 = v_u_131.new()
	end
	v_u_140.store = v_u_141
	v_u_140.send = v_u_135
	local v_u_142 = ""
	local v_u_143 = 10
	local v_u_144 = nil
	local function v_u_222(p_u_145) -- name: paint
		-- upvalues: (copy) v_u_139, (copy) v_u_130, (ref) v_u_1, (copy) v_u_133, (copy) v_u_132, (copy) v_u_128, (copy) v_u_127, (copy) v_u_129, (copy) v_u_141, (copy) v_u_135, (copy) v_u_140, (ref) v_u_144, (ref) v_u_143
		for _, v146 in v_u_139:GetChildren() do
			if v146:IsA("UICorner") or v146:IsA("UIStroke") then
				continue
			end
			v146:Destroy()
		end
		if p_u_145 == nil or v_u_130 == nil then
			v_u_139.Visible = false
		else
			local v_u_147 = p_u_145.regions or {}
			local v148 = v_u_1.layout
			local v149 = v_u_133
			local v150 = {
				["T"] = v_u_132,
				["optIn"] = p_u_145.optIn == true,
				["regionsOn"] = p_u_145.regionsOn == true
			}
			local v151
			if p_u_145.optIn == true then
				local v152 = p_u_145.of
				v151 = (tonumber(v152) or 0) > 1
			else
				v151 = false
			end
			v150.agree = v151
			v150.hints = v_u_1.hintsFor(v_u_132, v_u_130, v_u_147, p_u_145.own)
			local v153 = #v_u_147
			local v154 = p_u_145.max
			v150.full = (tonumber(v154) or 3) <= v153
			v150.touchH = v_u_128.touch(40)
			v150.chipMin = v_u_1.chipMinFor(v_u_128)
			local v155 = v148(v149, v150)
			local v156 = v_u_127.label
			local v157 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_139,
				["text"] = v_u_132.TITLE,
				["color"] = v_u_129.muted
			}
			local v158 = v155.title
			v157.position = UDim2.fromOffset(v158.x, v158.y)
			local v159 = v155.title
			v157.size = UDim2.fromOffset(v159.w, v159.h)
			v156(v157)
			if v155.opt then
				local v160 = v155.opt
				local v161 = v_u_127.label
				local v162 = {
					["parent"] = nil,
					["name"] = "OptInLabel",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_139,
					["text"] = v_u_132.OPTIN,
					["color"] = v_u_129.text
				}
				local v163 = v160.label
				v162.position = UDim2.fromOffset(v163.x, v163.y)
				local v164 = v160.label
				v162.size = UDim2.fromOffset(v164.w, v164.h)
				v161(v162)
				local v165 = v_u_127.toggle
				local v166 = {
					["parent"] = nil,
					["name"] = "OptIn",
					["label"] = "",
					["value"] = nil,
					["width"] = nil,
					["position"] = nil,
					["onChange"] = nil,
					["parent"] = v_u_139,
					["value"] = p_u_145.freeOptIn == true,
					["width"] = v160.switch.w
				}
				local v167 = UDim2.fromOffset
				local v168 = v160.switch.x
				local v169 = v160.switch.y
				local v170 = (v160.rowH - v155.touchH) / 2
				v166.position = v167(v168, v169 + math.floor(v170))
				function v166.onChange(p171) -- name: onChange
					-- upvalues: (ref) v_u_141, (ref) v_u_127, (ref) v_u_132, (ref) v_u_135, (ref) v_u_140, (ref) v_u_144
					local v172 = {
						["freeOptIn"] = p171
					}
					local v173
					if v_u_141.locked() then
						v_u_127.toast(v_u_132.SEARCHING or "Locked while your squad is searching.", "warn")
						v173 = false
					else
						v172.op = "queuePrefs"
						v_u_135(v172)
						v173 = true
					end
					if v173 then
						v_u_141.patchQueue({
							["freeOptIn"] = p171
						}, os.clock(), v_u_140)
					else
						v_u_144(true)
					end
				end
				local v174 = v165(v166)
				local v175 = v_u_127.label
				local v176 = {
					["parent"] = nil,
					["name"] = "OptInNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_139,
					["text"] = v_u_132.OPTIN_NOTE,
					["color"] = v_u_129.text2
				}
				local v177 = v160.note
				v176.position = UDim2.fromOffset(v177.x, v177.y)
				local v178 = v160.note
				v176.size = UDim2.fromOffset(v178.w, v178.h)
				v175(v176)
				if v160.agree then
					local v179 = v_u_127.label
					local v180 = {
						["parent"] = nil,
						["name"] = "OptInAgree",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v_u_139
					}
					local v181 = string.format
					local v182 = v_u_132.OPTIN_MATES
					local v183 = p_u_145.agree
					local v184 = tonumber(v183) or 0
					local v185 = p_u_145.of
					v180.text = v181(v182, v184, tonumber(v185) or 0)
					v180.color = v_u_129.info
					local v186 = v160.agree
					v180.position = UDim2.fromOffset(v186.x, v186.y)
					local v187 = v160.agree
					v180.size = UDim2.fromOffset(v187.w, v187.h)
					v179(v180)
				end
				if v174 then
					v174.Name = "OptIn"
				end
			end
			if v155.reg then
				local v188 = v155.reg
				local v189 = v_u_127.label
				local v190 = {
					["parent"] = nil,
					["name"] = "RegionsHeader",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_139,
					["text"] = v_u_132.REGIONS,
					["color"] = v_u_129.text
				}
				local v191 = v188.header
				v190.position = UDim2.fromOffset(v191.x, v191.y)
				local v192 = v188.header
				v190.size = UDim2.fromOffset(v192.w, v192.h)
				v189(v190)
				local v193 = v_u_127.label
				local v194 = {
					["parent"] = nil,
					["name"] = "RegionsNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_139,
					["text"] = v_u_132.REGIONS_NOTE,
					["color"] = v_u_129.text2
				}
				local v195 = v188.note
				v194.position = UDim2.fromOffset(v195.x, v195.y)
				local v196 = v188.note
				v194.size = UDim2.fromOffset(v196.w, v196.h)
				v193(v194)
				local v197 = {}
				for _, v198 in v_u_147 do
					v197[v198] = true
				end
				for v199, v_u_200 in v_u_1.ORDER do
					local v201 = v188.chips[v199]
					local v202 = v_u_200 == p_u_145.own
					v_u_127.button({
						["parent"] = v_u_139,
						["name"] = "Region_" .. v_u_200,
						["text"] = v_u_200,
						["kind"] = v197[v_u_200] and "primary" or (v202 and "ghost" or "secondary"),
						["size"] = UDim2.fromOffset(v201.w, v201.h),
						["position"] = UDim2.fromOffset(v201.x, v201.y),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_1, (copy) v_u_147, (copy) v_u_200, (copy) p_u_145, (ref) v_u_127, (ref) v_u_132, (ref) v_u_141, (ref) v_u_135
							local v203 = v_u_1.toggleRegion
							local v204 = v_u_147
							local v205 = v_u_200
							local v206 = p_u_145.own
							local v207 = p_u_145.max
							local v208, v209 = v203(v204, v205, v206, tonumber(v207) or 3)
							if v209 == "own" then
								v_u_127.toast(v_u_132.REGIONS_OWN .. ": always searched first.", "info")
								return
							elseif v209 == "limit" then
								v_u_127.toast(v_u_132.REGIONS_LIMIT, "info")
							elseif v209 == nil then
								local v210 = {
									["regions"] = v208
								}
								local v211
								if v_u_141.locked() then
									v_u_127.toast(v_u_132.SEARCHING or "Locked while your squad is searching.", "warn")
									v211 = false
								else
									v210.op = "queuePrefs"
									v_u_135(v210)
									v211 = true
								end
								if v211 then
									v_u_141.patchQueue({
										["regions"] = v208
									}, os.clock())
								end
							end
						end
					})
				end
				for v212, v213 in v_u_1.hintsFor(v_u_132, v_u_130, v_u_147, p_u_145.own) do
					local v214 = v_u_127.label
					local v215 = {
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v_u_139,
						["name"] = "Ping" .. v212,
						["text"] = v213,
						["color"] = v_u_129.text2
					}
					local v216 = v188.hints[v212]
					v215.position = UDim2.fromOffset(v216.x, v216.y)
					local v217 = v188.hints[v212]
					v215.size = UDim2.fromOffset(v217.w, v217.h)
					v214(v215)
				end
				if v188.limit then
					local v218 = v_u_127.label
					local v219 = {
						["parent"] = nil,
						["name"] = "RegionsLimit",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v_u_139,
						["text"] = v_u_132.REGIONS_LIMIT,
						["color"] = v_u_129.muted
					}
					local v220 = v188.limit
					v219.position = UDim2.fromOffset(v220.x, v220.y)
					local v221 = v188.limit
					v219.size = UDim2.fromOffset(v221.w, v221.h)
					v218(v219)
				end
			end
			v_u_143 = v155.h
			v_u_139.Size = UDim2.fromOffset(v_u_133, v155.h)
			v_u_139.Visible = true
		end
	end
	local v_u_223
	if type(p126) == "table" then
		v_u_223 = p126.keepFocus == true
	else
		v_u_223 = false
	end
	v_u_144 = function(p224) -- name: render
		-- upvalues: (copy) v_u_141, (copy) v_u_130, (copy) v_u_131, (ref) v_u_142, (copy) v_u_223, (copy) v_u_127, (copy) v_u_139, (copy) v_u_222
		local v225 = v_u_141.queue()
		if type(v225) ~= "table" or (v_u_130 == nil or v225.optIn ~= true and v225.regionsOn ~= true) then
			v225 = nil
		end
		local v226
		if v225 == nil then
			v226 = "hidden"
		else
			local v227 = v_u_131.queueSig(v225)
			local v228 = v_u_141.locked
			v226 = v227 .. "|" .. tostring(v228())
		end
		if p224 == true or v226 ~= v_u_142 then
			v_u_142 = v226
			local v_u_229 = v_u_141.queue()
			if type(v_u_229) ~= "table" or (v_u_130 == nil or v_u_229.optIn ~= true and v_u_229.regionsOn ~= true) then
				v_u_229 = nil
			end
			local v_u_230 = false
			if v_u_223 then
				local v231 = v_u_127.keepScroll
				if type(v231) == "function" then
					local v232 = v_u_127.keepScroll
					local v233 = v_u_139
					local function v234()
						-- upvalues: (ref) v_u_230, (ref) v_u_222, (copy) v_u_229
						v_u_230 = true
						v_u_222(v_u_229)
					end
					local v235, v236 = pcall(v232, v233, v234)
					if not v235 and v_u_230 then
						warn("[MenuPlayQueue] redraw failed:", v236)
					end
				end
			end
			if not v_u_230 then
				v_u_222(v_u_229)
			end
		end
	end
	local v_u_237 = nil
	v_u_237 = v_u_141.subscribe(function(_, p238)
		-- upvalues: (copy) v_u_139, (ref) v_u_237, (copy) v_u_140, (ref) v_u_142, (copy) v_u_141, (copy) v_u_130, (copy) v_u_131, (ref) v_u_144
		if v_u_139.Parent == nil then
			v_u_237()
			return
		elseif p238 == v_u_140 then
			local v239 = v_u_141.queue()
			if type(v239) ~= "table" or (v_u_130 == nil or v239.optIn ~= true and v239.regionsOn ~= true) then
				v239 = nil
			end
			local v240
			if v239 == nil then
				v240 = "hidden"
			else
				local v241 = v_u_131.queueSig(v239)
				local v242 = v_u_141.locked
				v240 = v241 .. "|" .. tostring(v242())
			end
			v_u_142 = v240
		else
			v_u_144(false)
		end
	end)
	function v_u_140.set(p243) -- name: set
		-- upvalues: (copy) v_u_141, (ref) v_u_144
		v_u_141.setQueue(p243, os.clock())
		v_u_144(false)
	end
	function v_u_140.lock(p244) -- name: lock
		-- upvalues: (copy) v_u_141, (ref) v_u_144
		v_u_141.setLocked(p244 == true)
		v_u_144(false)
	end
	function v_u_140.height() -- name: height
		-- upvalues: (ref) v_u_143
		return v_u_143
	end
	function v_u_140.destroy() -- name: destroy
		-- upvalues: (ref) v_u_237, (copy) v_u_139
		v_u_237()
		v_u_139:Destroy()
	end
	v_u_144(false)
	return v_u_139, v_u_140
end
return v_u_1