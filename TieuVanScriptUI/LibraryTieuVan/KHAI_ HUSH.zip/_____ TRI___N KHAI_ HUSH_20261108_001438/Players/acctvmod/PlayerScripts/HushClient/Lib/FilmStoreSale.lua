-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmStoreSale

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {
	["TUNE"] = {
		["autoRefresh"] = 15,
		["confirmSec"] = 6,
		["allOffSec"] = 6,
		["maxText"] = 40
	},
	["FILTERS"] = {
		{
			["id"] = "all",
			["text"] = "All"
		},
		{
			["id"] = "on",
			["text"] = "On sale"
		},
		{
			["id"] = "passes",
			["text"] = "Passes"
		},
		{
			["id"] = "kits",
			["text"] = "Kits"
		},
		{
			["id"] = "cash",
			["text"] = "Cash"
		},
		{
			["id"] = "other",
			["text"] = "Other"
		}
	}
}
local v_u_5 = nil
function v_u_4.setRules(p6) -- name: setRules
	-- upvalues: (ref) v_u_5
	v_u_5 = p6
end
function v_u_4.layout(p7) -- name: layout
	local v8 = p7 - 20
	return {
		["pad"] = 10,
		["gap"] = 6,
		["avail"] = nil,
		["check"] = 28,
		["name"] = nil,
		["list"] = 64,
		["price"] = 112,
		["wasLbl"] = 34,
		["wasIn"] = 72,
		["liveB"] = 84,
		["endsLbl"] = 42,
		["endsIn"] = 140,
		["textLbl"] = 40,
		["textIn"] = nil,
		["avail"] = v8,
		["name"] = v8 - 28 - 64 - 112 - 18,
		["textIn"] = v8 - 412 - 36
	}
end
function v_u_4.filterOf(p9) -- name: filterOf
	local v10
	if type(p9) == "table" then
		v10 = p9.category
	else
		v10 = nil
	end
	return v10 == "PASSES" and "passes" or (v10 == "KITS" and "kits" or (v10 == "CASH" and "cash" or "other"))
end
function v_u_4.matches(p11, p12, p13, p14) -- name: matches
	-- upvalues: (copy) v_u_4
	if p11 == "on" then
		if not p14 then
			return false
		end
	elseif p11 ~= "all" and p11 ~= v_u_4.filterOf(p13) then
		return false
	end
	local v15 = string.lower
	local v16
	if type(p12) == "string" then
		local v17 = string.gsub(p12, "^%s+", "")
		v16 = string.gsub(v17, "%s+$", "")
	else
		v16 = ""
	end
	local v18 = v15(v16)
	if v18 == "" then
		return true
	end
	local v19 = string.lower
	local v20 = p13.name or ""
	local v21 = tostring(v20)
	local v22 = p13.id or ""
	local v23 = tostring(v22)
	local v24 = p13.category or ""
	local v25 = v19(v21 .. " " .. v23 .. " " .. tostring(v24))
	return string.find(v25, v18, 1, true) ~= nil
end
function v_u_4.listText(p26) -- name: listText
	return p26 == "pve" and "PVE" or (p26 == "pvp" and "PVP" or "PVE+PVP")
end
local function v_u_34(p27) -- name: commas
	local v28 = math.floor(p27)
	local v29 = tostring(v28)
	local v30 = #v29
	local v31 = ""
	for v32 = 1, v30 do
		v31 = v31 .. string.sub(v29, v32, v32)
		local v33 = v30 - v32
		if v33 <= 0 or v33 % 3 ~= 0 then
			continue
		end
		v31 = v31 .. ","
	end
	return v31
end
v_u_4.commas = v_u_34
function v_u_4.priceText(p35) -- name: priceText
	-- upvalues: (copy) v_u_34
	if p35.offSale == true then
		return "Off sale"
	end
	if p35.live ~= true then
		return "Coming soon"
	end
	local v36 = p35.price
	return type(v36) ~= "number" and "price unknown" or "live R$ " .. v_u_34(p35.price)
end
function v_u_4.parseWas(p37) -- name: parseWas
	local v38 = tostring(p37 or "")
	local v39
	if type(v38) == "string" then
		local v40 = string.gsub(v38, "^%s+", "")
		v39 = string.gsub(v40, "%s+$", "")
	else
		v39 = ""
	end
	if v39 == "" then
		return true, nil
	else
		local v41 = string.gsub(v39, ",", "")
		local v42 = tonumber(v41)
		if v42 == nil or (v42 ~= v42 or (v42 < 1 or (v42 > 1000000 or v42 ~= math.floor(v42)))) then
			return false, nil
		else
			return true, v42
		end
	end
end
function v_u_4.initialEdit(p43, p44) -- name: initialEdit
	if type(p43) ~= "table" then
		return {
			["ticked"] = false,
			["wasText"] = "",
			["endsText"] = "",
			["endsInit"] = "",
			["endsAt"] = nil,
			["textText"] = ""
		}
	end
	local v45 = p43.ends
	local v46 = type(v45) ~= "number" and "" or p44(p43.ends)
	local v47 = {
		["ticked"] = true,
		["wasText"] = nil,
		["endsText"] = nil,
		["endsInit"] = nil,
		["endsAt"] = nil,
		["textText"] = nil
	}
	local v48
	if p43.was == nil then
		v48 = ""
	else
		local v49 = p43.was
		v48 = tostring(v49)
	end
	v47.wasText = v48
	v47.endsText = v46
	v47.endsInit = v46
	v47.endsAt = p43.ends
	v47.textText = p43.text or ""
	return v47
end
function v_u_4.rowDirty(p50, p51) -- name: rowDirty
	-- upvalues: (copy) v_u_4
	local v52 = p50 ~= nil
	if p51.ticked ~= v52 then
		return true
	end
	if not v52 then
		return false
	end
	local v53, v54 = v_u_4.parseWas(p51.wasText)
	if not v53 then
		return true
	end
	if v54 ~= p50.was then
		return true
	end
	local v55 = p51.endsText
	local v56
	if type(v55) == "string" then
		local v57 = string.gsub(v55, "^%s+", "")
		v56 = string.gsub(v57, "%s+$", "")
	else
		v56 = ""
	end
	local v58 = p51.endsInit
	local v59
	if type(v58) == "string" then
		local v60 = string.gsub(v58, "^%s+", "")
		v59 = string.gsub(v60, "%s+$", "")
	else
		v59 = ""
	end
	if v56 ~= v59 then
		return true
	end
	local v61 = p51.textText
	local v62
	if type(v61) == "string" then
		local v63 = string.gsub(v61, "^%s+", "")
		v62 = string.gsub(v63, "%s+$", "")
	else
		v62 = ""
	end
	return v62 ~= (p50.text or "")
end
function v_u_4.countDirty(p64, p65, p66) -- name: countDirty
	-- upvalues: (copy) v_u_4
	local v67 = 0
	for _, v68 in p64 do
		local v69 = p66[v68]
		if v69 == nil or not v_u_4.rowDirty(p65[v68], v69) then
			continue
		end
		v67 = v67 + 1
	end
	return v67
end
function v_u_4.payload(p70, p71) -- name: payload
	-- upvalues: (copy) v_u_4
	local v72 = {}
	for _, v73 in p70 do
		local v74 = p71[v73]
		if v74 == nil or v74.ticked ~= true then
			continue
		end
		local v75 = {}
		local v76, v77 = v_u_4.parseWas(v74.wasText)
		if v76 then
			v75.was = v77
		else
			local v78 = v74.wasText
			local v79
			if type(v78) == "string" then
				local v80 = string.gsub(v78, "^%s+", "")
				v79 = string.gsub(v80, "%s+$", "")
			else
				v79 = ""
			end
			v75.was = v79
		end
		local v81 = v74.endsText
		local v82
		if type(v81) == "string" then
			local v83 = string.gsub(v81, "^%s+", "")
			v82 = string.gsub(v83, "%s+$", "")
		else
			v82 = ""
		end
		local v84, v85, v86
		if v74.endsAt == nil then
			if v82 ~= "" then
				v75.ends = v82
			end
			v84 = v74.textText
			if type(v84) == "string" then
				v85 = string.gsub(v84, "^%s+", "")
				v86 = string.gsub(v85, "%s+$", "")
			else
				v86 = ""
			end
			if v86 ~= "" then
				v75.text = v86
			end
			v72[v73] = v75
		else
			local v87 = v74.endsInit
			local v88
			if type(v87) == "string" then
				local v89 = string.gsub(v87, "^%s+", "")
				v88 = string.gsub(v89, "%s+$", "")
			else
				v88 = ""
			end
			if v82 == v88 then
				v75.endsAt = v74.endsAt
				v84 = v74.textText
				if type(v84) == "string" then
					v85 = string.gsub(v84, "^%s+", "")
					v86 = string.gsub(v85, "%s+$", "")
				else
					v86 = ""
				end
				if v86 ~= "" then
					v75.text = v86
				end
				v72[v73] = v75
			else
				if v82 ~= "" then
					v75.ends = v82
				end
				v84 = v74.textText
				if type(v84) == "string" then
					v85 = string.gsub(v84, "^%s+", "")
					v86 = string.gsub(v85, "%s+$", "")
				else
					v86 = ""
				end
				if v86 ~= "" then
					v75.text = v86
				end
				v72[v73] = v75
			end
		end
	end
	return v72
end
function v_u_4.endsNote(p90, p91, p92, p93) -- name: endsNote
	-- upvalues: (ref) v_u_5, (copy) v_u_2
	if v_u_5 == nil then
		local function v94()
			-- upvalues: (ref) v_u_5, (ref) v_u_2
			v_u_5 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v94)
	end
	local v95 = v_u_5
	if p90.endsAt ~= nil then
		local v96 = p90.endsText
		local v97
		if type(v96) == "string" then
			local v98 = string.gsub(v96, "^%s+", "")
			v97 = string.gsub(v98, "%s+$", "")
		else
			v97 = ""
		end
		local v99 = p90.endsInit
		local v100
		if type(v99) == "string" then
			local v101 = string.gsub(v99, "^%s+", "")
			v100 = string.gsub(v101, "%s+$", "")
		else
			v100 = ""
		end
		if v97 == v100 then
			local v102 = p90.endsAt
			local v103 = p93(v102)
			local v104 = ("%02d.%02d. %02d:%02d Berlin"):format(v103.day, v103.month, v103.hour, v103.min)
			return v102 <= p91 and {
				["text"] = nil,
				["bad"] = true,
				["ends"] = nil,
				["text"] = "ended " .. v104,
				["ends"] = v102
			} or {
				["text"] = nil,
				["bad"] = false,
				["ends"] = nil,
				["text"] = "ends " .. v104 .. ", in " .. v95.timerText(v102 - p91),
				["ends"] = v102
			}
		end
	end
	local v105, v106, v107 = v95.parseEnds(p90.endsText, p91, p92)
	if not v105 then
		return {
			["text"] = nil,
			["bad"] = true,
			["text"] = tostring(v107)
		}
	end
	if v106 == nil then
		return {
			["text"] = "no end, the sale runs until you untick it",
			["bad"] = false
		}
	end
	local v108 = p93(v106)
	return {
		["text"] = nil,
		["bad"] = false,
		["ends"] = nil,
		["text"] = ("ends %02d.%02d. %02d:%02d Berlin, in %s"):format(v108.day, v108.month, v108.hour, v108.min, v95.timerText(v106 - p91)),
		["ends"] = v106
	}
end
function v_u_4.previewFor(p109, p110, p111, p112, p113) -- name: previewFor
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_4
	if v_u_5 == nil then
		local function v114()
			-- upvalues: (ref) v_u_5, (ref) v_u_2
			v_u_5 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v114)
	end
	local v115 = v_u_5
	if p110.ticked ~= true then
		return {
			["text"] = "",
			["level"] = "info",
			["seen"] = false
		}
	end
	local v116 = v_u_4.endsNote(p110, p111, p112, p113)
	local v117 = v116.ends
	local v118
	if v116.bad and v117 == nil then
		v118 = v116.text
	else
		v118 = nil
	end
	local v119, v120 = v_u_4.parseWas(p110.wasText)
	return not v119 and {
		["text"] = "WAS must be a whole number from 1 to 1,000,000",
		["level"] = "warn",
		["seen"] = false
	} or v115.rowPreview({
		["ticked"] = true,
		["was"] = nil,
		["ends"] = nil,
		["endsErr"] = nil,
		["live"] = nil,
		["offSale"] = nil,
		["soon"] = nil,
		["listed"] = nil,
		["was"] = v120,
		["ends"] = v117,
		["endsErr"] = v118,
		["live"] = p109.price,
		["offSale"] = p109.offSale == true,
		["soon"] = p109.live ~= true,
		["listed"] = p109.listed
	}, p111)
end
function v_u_4.headText(p121, p122) -- name: headText
	if type(p121) ~= "table" then
		return "not read yet"
	end
	local v123 = {}
	local v124 = p121.v or 0
	local v125 = "v" .. tostring(v124)
	local v126 = p121.running or 0
	__set_list(v123, 1, {v125, tostring(v126) .. " on sale"})
	if p121.byName ~= nil then
		local v127 = p121.at
		if type(v127) == "number" and p121.at > 0 then
			local v128 = p122(p121.at)
			local v129 = p121.byName
			local v130 = tostring(v129)
			local v131 = v128.year
			local v132 = v128.month
			local v133 = v128.day
			local v134 = v128.hour
			local v135 = v128.min
			table.insert(v123, ("by %s %04d-%02d-%02d %02d:%02d Berlin"):format(v130, v131, v132, v133, v134, v135))
		end
	end
	local v136 = p121.good and "store good" or "NOT READ YET"
	table.insert(v123, v136)
	return table.concat(v123, "  ")
end
function v_u_4.saveLabel(p137) -- name: saveLabel
	return p137 <= 0 and "Save" or ("Save %d change%s"):format(p137, p137 == 1 and "" or "s")
end
function v_u_4.build(p_u_138) -- name: build
	-- upvalues: (copy) v_u_1, (ref) v_u_5, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
	local v_u_139 = v_u_1.LocalPlayer
	if v_u_139:GetAttribute("FilmAllowed") ~= true then
		return nil
	end
	local v140, v_u_141 = pcall(function()
		return require(script.Parent:WaitForChild("HushUI", 5))
	end)
	if v_u_5 == nil then
		local function v142()
			-- upvalues: (ref) v_u_5, (ref) v_u_2
			v_u_5 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v142)
	end
	local v_u_143 = v_u_5
	if not v140 or v_u_143 == nil then
		warn("[FilmStoreSale] HushUI or SaleRules missing")
		return nil
	end
	local v_u_144 = v_u_141.Theme
	local v_u_145 = v_u_144.color
	local v_u_146, v_u_147 = pcall(function()
		return require(script.Parent:WaitForChild("ServerClock", 5))
	end)
	local function v148()
		-- upvalues: (ref) v_u_2
		return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("BmRs", 5)))
	end
	local v149, v_u_150 = pcall(v148)
	if not v149 or type(v_u_150) ~= "table" then
		warn("[FilmStoreSale] BmRs missing")
		return nil
	end
	local function v_u_152(p151) -- name: fmtEnds
		-- upvalues: (copy) v_u_143, (copy) v_u_150
		return v_u_143.fmtBerlin(p151, v_u_150.berlin)
	end
	local v_u_153 = p_u_138.body
	local v_u_154 = p_u_138.api
	local v155 = p_u_138.inner
	local v_u_156 = v_u_4.layout(v155)
	local v_u_157 = true
	p_u_138.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_157
		v_u_157 = false
	end)
	local v158 = 0
	local v_u_159 = {}
	local v_u_160 = {}
	local v_u_161 = {}
	local v_u_162 = {}
	local v163 = nil
	local v_u_164 = {}
	local v_u_165 = {}
	local v_u_166 = "all"
	local v_u_167 = ""
	local v168 = false
	local v169 = false
	local v_u_170 = 0
	local v_u_171 = (-1 / 0)
	local v172 = ""
	local v_u_173 = (-1 / 0)
	local v_u_174 = {}
	local v_u_175 = nil
	local function v176() -- name: dirtyCount
		-- upvalues: (ref) v_u_4, (ref) v_u_160, (ref) v_u_162, (copy) v_u_164
		return v_u_4.countDirty(v_u_160, v_u_162, v_u_164)
	end
	local v177 = v_u_141.label({
		["parent"] = nil,
		["text"] = "Store sale  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_153,
		["color"] = v_u_145.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	v158 = v158 + 1
	v177.LayoutOrder = v158
	local v_u_178 = v_u_141.label({
		["parent"] = nil,
		["name"] = "SaleHead",
		["text"] = "not read yet",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_153,
		["color"] = v_u_145.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v158 = v158 + 1
	v_u_178.LayoutOrder = v158
	v_u_178.RichText = false
	local v179 = v_u_141.label({
		["parent"] = nil,
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["text"] = "Lower the price in the Creator Hub, tick SALE here and press SAVE. A discount shows only while WAS is above the live price. USE LIVE copies the live price into WAS, so the discount appears by itself once you lower the price. The limited time windows of the Minigun and Crimson bundles are in the SERVER tab.",
		["parent"] = v_u_153,
		["color"] = v_u_145.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v158 = v158 + 1
	v179.LayoutOrder = v158
	v179.RichText = false
	local v180 = v_u_141.new("Frame", {
		["Name"] = "SaleBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_144.touch(32))
	}, v_u_153)
	v158 = v158 + 1
	v180.LayoutOrder = v158
	v_u_141.layout(v180, "h", 6)
	local function v_u_181() end
	local function v_u_182() end
	local function v_u_183() end
	local function v184()
		-- upvalues: (ref) v_u_181
		v_u_181()
	end
	local v185, v_u_186 = v_u_141.button({
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v180,
		["height"] = v_u_144.touch(32),
		["onClick"] = v184
	})
	v185.Name = "SaleRefresh"
	local function v187()
		-- upvalues: (ref) v_u_182
		v_u_182()
	end
	local v188, v189 = v_u_141.button({
		["parent"] = nil,
		["text"] = "Save",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 190,
		["onClick"] = nil,
		["maxTextWidth"] = 178,
		["parent"] = v180,
		["height"] = v_u_144.touch(32),
		["onClick"] = v187
	})
	local v_u_190 = v189
	v188.Name = "SaleSave"
	local function v191()
		-- upvalues: (ref) v_u_183
		v_u_183()
	end
	local v192, v_u_193 = v_u_141.button({
		["parent"] = nil,
		["text"] = "All off",
		["kind"] = "ghost",
		["height"] = nil,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v180,
		["height"] = v_u_144.touch(32),
		["onClick"] = v191
	})
	v192.Name = "SaleAllOff"
	local v_u_194 = v_u_141.new("Frame", {
		["Name"] = "SaleConfirm",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_145.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_153)
	v158 = v158 + 1
	v_u_194.LayoutOrder = v158
	v_u_194.Visible = false
	v_u_141.stroke(v_u_194, v_u_145.accent)
	v_u_141.pad(v_u_194, {
		12,
		12,
		10,
		10
	})
	v_u_141.layout(v_u_194, "v", 8)
	local v_u_195 = v_u_141.label({
		["parent"] = nil,
		["name"] = "Question",
		["text"] = "",
		["style"] = "bodyStrong",
		["track"] = false,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_194,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_195.LayoutOrder = 1
	v_u_195.RichText = false
	local v196 = v_u_141.new("Frame", {
		["Name"] = "Buttons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, v_u_144.touch(32))
	}, v_u_194)
	v_u_141.layout(v196, "h", 6)
	local function v_u_197() end
	local function v_u_198() end
	local function v199()
		-- upvalues: (ref) v_u_197
		v_u_197()
	end
	local v200, v_u_201 = v_u_141.button({
		["parent"] = nil,
		["text"] = "Yes, save",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 160,
		["onClick"] = nil,
		["maxTextWidth"] = 148,
		["parent"] = v196,
		["height"] = v_u_144.touch(32),
		["onClick"] = v199
	})
	v200.Name = "SaleYes"
	local function v202()
		-- upvalues: (ref) v_u_198
		v_u_198()
	end
	local v203, _ = v_u_141.button({
		["parent"] = nil,
		["text"] = "Cancel",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 120,
		["onClick"] = nil,
		["maxTextWidth"] = 108,
		["parent"] = v196,
		["height"] = v_u_144.touch(32),
		["onClick"] = v202
	})
	v203.Name = "SaleNo"
	local v_u_204 = v_u_141.label({
		["parent"] = nil,
		["name"] = "SaleStatus",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_153,
		["color"] = v_u_145.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v158 = v158 + 1
	v_u_204.LayoutOrder = v158
	v_u_204.RichText = false
	local v205, v_u_206 = v_u_141.input({
		["parent"] = nil,
		["name"] = "SaleSearch",
		["size"] = nil,
		["placeholder"] = "Search the list",
		["parent"] = v_u_153,
		["size"] = UDim2.new(1, 0, 0, v_u_144.touch(34))
	})
	v158 = v158 + 1
	v205.LayoutOrder = v158
	local v207 = v_u_141.new("Frame", {
		["Name"] = "SaleFilters",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_144.touch(30))
	}, v_u_153)
	v158 = v158 + 1
	v207.LayoutOrder = v158
	v_u_141.layout(v207, "h", 4)
	local v208 = (v155 - 20) / 6
	local v209 = math.floor(v208)
	local v_u_210 = v_u_160
	local v211 = v158
	local v_u_212 = v_u_162
	local v_u_213 = v_u_157
	local v_u_214 = v169
	local v_u_215 = v168
	local v_u_216 = v172
	local v_u_217 = v163
	for _, v218 in v_u_4.FILTERS do
		local v_u_219 = v218.id
		local v220 = v218.text
		local v221, v222 = v_u_141.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "ghost",
			["height"] = nil,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v207,
			["text"] = v220,
			["height"] = v_u_144.touch(32),
			["width"] = v209,
			["onClick"] = function()
				-- upvalues: (ref) v_u_166, (copy) v_u_219, (ref) v_u_175
				v_u_166 = v_u_219
				v_u_175()
			end,
			["maxTextWidth"] = v209 - 12
		})
		v221.Name = "SaleFilter_" .. v_u_219
		v_u_174[v_u_219] = {
			["btn"] = v221,
			["api"] = v222,
			["text"] = v218.text
		}
	end
	local v_u_223 = v_u_141.new("Frame", {
		["Name"] = "SaleList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_153)
	v158 = v211 + 1
	v_u_223.LayoutOrder = v158
	v_u_141.layout(v_u_223, "v", 4)
	local v_u_224 = v_u_141.label({
		["parent"] = nil,
		["name"] = "SaleListNote",
		["text"] = "Loading the list ...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_223,
		["color"] = v_u_145.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_224.LayoutOrder = 0
	local function v_u_245(p225) -- name: paintRow
		-- upvalues: (copy) v_u_165, (copy) v_u_164, (ref) v_u_161, (copy) v_u_145, (copy) v_u_146, (copy) v_u_147, (ref) v_u_4, (copy) v_u_150, (ref) v_u_212, (ref) v_u_166, (ref) v_u_167
		local v226 = v_u_165[p225]
		local v227 = v_u_164[p225]
		local v228 = v_u_161[p225]
		if v226 ~= nil and (v227 ~= nil and v228 ~= nil) then
			v226.fill.Visible = v227.ticked
			local v229 = v226.stroke
			local v230
			if v227.ticked then
				v230 = v_u_145.accent
			else
				v230 = v_u_145.line
			end
			v229.Color = v230
			v226.row2.Visible = v227.ticked
			v226.endsNote.Visible = v227.ticked
			v226.preview.Visible = v227.ticked
			v226.count.Visible = v227.ticked
			if v227.ticked then
				local v231
				if v_u_146 and (v_u_147 and v_u_147.now) then
					local v232 = v_u_147.now()
					v231 = math.floor(v232)
				else
					v231 = os.time()
				end
				local v233 = v_u_4.endsNote(v227, v231, v_u_150.berlinToUtc, v_u_150.berlin)
				v226.endsNote.Text = "ENDS: " .. v233.text
				local v234 = v226.endsNote
				local v235
				if v233.bad then
					v235 = v_u_145.danger
				else
					v235 = v_u_145.muted
				end
				v234.TextColor3 = v235
				local v236 = v_u_4.previewFor(v228, v227, v231, v_u_150.berlinToUtc, v_u_150.berlin)
				v226.preview.Text = v236.text == "" and "" or v236.text
				local v237 = v226.preview
				local v238
				if v236.level == "warn" then
					v238 = v_u_145.danger
				elseif v236.level == "ok" then
					v238 = v_u_145.success
				else
					v238 = v_u_145.text2
				end
				v237.TextColor3 = v238
				local v239 = v226.count
				local v240 = "%d/%d"
				local v241 = v227.textText
				local v242
				if type(v241) == "string" then
					local v243 = string.gsub(v241, "^%s+", "")
					v242 = string.gsub(v243, "%s+$", "")
				else
					v242 = ""
				end
				v239.Text = v240:format(#v242, v_u_4.TUNE.maxText)
			end
			local v244 = v_u_4.rowDirty(v_u_212[p225], v227)
			v226.dirtyMark.Visible = v244
			v226.frame.Visible = v_u_4.matches(v_u_166, v_u_167, v228, v227.ticked)
		end
	end
	local function v_u_251() -- name: paintButtons
		-- upvalues: (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164, (copy) v_u_190, (ref) v_u_215, (ref) v_u_214, (copy) v_u_186, (copy) v_u_193, (copy) v_u_201, (copy) v_u_174, (ref) v_u_166, (copy) v_u_194, (copy) v_u_195, (copy) v_u_178, (ref) v_u_217, (copy) v_u_150, (copy) v_u_139, (ref) v_u_216
		local v246 = v_u_4.countDirty(v_u_210, v_u_212, v_u_164)
		v_u_190.setText(v_u_4.saveLabel(v246))
		local v247 = v_u_190.setEnabled
		local v248 = v246 > 0 and not v_u_215
		if v248 then
			v248 = not v_u_214
		end
		v247(v248)
		v_u_186.setEnabled(not v_u_215)
		v_u_193.setEnabled(not v_u_215)
		v_u_201.setEnabled(not v_u_215)
		for v249, v250 in v_u_174 do
			v250.api.setEnabled(true)
			if not v250.api.setKind then
				continue
			end
			v250.api.setKind(v249 == v_u_166 and "primary" or "ghost")
		end
		v_u_194.Visible = v_u_214
		if v_u_214 then
			v_u_195.Text = ("Save %d change%s for all servers?"):format(v246, v246 == 1 and "" or "s")
		end
		if v_u_178 then
			v_u_178.Text = v_u_4.headText(v_u_217, v_u_150.berlin)
		end
		v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
	end
	local function v_u_253()
		-- upvalues: (ref) v_u_210, (copy) v_u_245, (copy) v_u_251
		for _, v252 in v_u_210 do
			v_u_245(v252)
		end
		v_u_251()
	end
	local function v_u_309() -- name: buildRows
		-- upvalues: (copy) v_u_223, (copy) v_u_224, (copy) v_u_165, (ref) v_u_159, (copy) v_u_141, (copy) v_u_145, (copy) v_u_156, (copy) v_u_144, (ref) v_u_4, (copy) v_u_164, (ref) v_u_214, (ref) v_u_253
		for _, v254 in v_u_223:GetChildren() do
			if not v254:IsA("GuiObject") or v254 == v_u_224 then
				continue
			end
			v254:Destroy()
		end
		table.clear(v_u_165)
		v_u_224.Visible = #v_u_159 == 0
		for v255, v_u_256 in v_u_159 do
			local v_u_257 = v_u_256.id
			local v258 = v_u_141.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Sale_" .. v_u_257,
				["BackgroundColor3"] = v_u_145.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = v255
			}, v_u_223)
			local v259 = v_u_141.stroke(v258, v_u_145.line)
			v_u_141.pad(v258, {
				v_u_156.pad,
				v_u_156.pad,
				6,
				6
			})
			v_u_141.layout(v258, "v", 4)
			local v260 = v_u_141.new("Frame", {
				["Name"] = "Row1",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, v_u_144.touch(30))
			}, v258)
			v_u_141.layout(v260, "h", v_u_156.gap, "center")
			local v261 = v_u_141.new("TextButton", {
				["Name"] = "Tick",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Selectable"] = true,
				["BackgroundColor3"] = v_u_145.bg,
				["Size"] = UDim2.fromOffset(v_u_156.check, v_u_156.check)
			}, v260)
			v_u_141.stroke(v261, v_u_145.lineStrong)
			local v262 = v_u_141.new("Frame", {
				["Name"] = "Fill",
				["Size"] = nil,
				["Position"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Visible"] = false,
				["Size"] = UDim2.fromOffset(v_u_156.check - 12, v_u_156.check - 12),
				["Position"] = UDim2.fromOffset(6, 6),
				["BackgroundColor3"] = v_u_145.accent
			}, v261)
			local v263 = v_u_141.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["track"] = false,
				["size"] = nil,
				["parent"] = v260,
				["text"] = v_u_256.name,
				["size"] = UDim2.fromOffset(v_u_156.name, 20)
			})
			v263.LayoutOrder = 2
			v263.RichText = false
			local v264 = v_u_141.label({
				["parent"] = nil,
				["name"] = "Listed",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["track"] = false,
				["size"] = nil,
				["parent"] = v260,
				["text"] = v_u_4.listText(v_u_256.listed),
				["color"] = v_u_145.text2,
				["size"] = UDim2.fromOffset(v_u_156.list, 16)
			})
			v264.LayoutOrder = 3
			v264.RichText = false
			local v265 = v_u_141.label
			local v266 = {
				["parent"] = nil,
				["name"] = "Price",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["align"] = "right",
				["track"] = false,
				["size"] = nil,
				["parent"] = v260,
				["text"] = v_u_4.priceText(v_u_256)
			}
			local v267
			if v_u_256.offSale or not v_u_256.live then
				v267 = v_u_145.muted
			else
				v267 = v_u_145.text2
			end
			v266.color = v267
			v266.size = UDim2.fromOffset(v_u_156.price, 18)
			local v268 = v265(v266)
			v268.LayoutOrder = 4
			v268.RichText = false
			local v269 = v_u_141.new("Frame", {
				["Name"] = "Dirty",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Visible"] = false,
				["LayoutOrder"] = 5,
				["Size"] = UDim2.fromOffset(6, 6),
				["BackgroundColor3"] = v_u_145.accent
			}, v260)
			local v_u_270 = v_u_141.new("Frame", {
				["Name"] = "Row2",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Visible"] = false,
				["Size"] = UDim2.new(1, 0, 0, v_u_144.touch(32))
			}, v258)
			v_u_141.layout(v_u_270, "h", v_u_156.gap, "center")
			local function v275(p271, p272, p273) -- name: lab
				-- upvalues: (ref) v_u_141, (copy) v_u_270, (ref) v_u_145
				local v274 = v_u_141.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["track"] = false,
					["size"] = nil,
					["parent"] = v_u_270,
					["text"] = p271,
					["color"] = v_u_145.muted,
					["size"] = UDim2.fromOffset(p272, 16)
				})
				v274.LayoutOrder = p273
				v274.RichText = false
			end
			v275("WAS", v_u_156.wasLbl, 1)
			local v276, v_u_277 = v_u_141.input({
				["parent"] = nil,
				["name"] = "Was",
				["size"] = nil,
				["placeholder"] = "old R$",
				["parent"] = v_u_270,
				["size"] = UDim2.fromOffset(v_u_156.wasIn, v_u_144.touch(30))
			})
			v276.LayoutOrder = 2
			local v278 = v_u_156.liveB
			local v279, v280 = v_u_141.button({
				["parent"] = nil,
				["text"] = "Use live",
				["kind"] = "ghost",
				["height"] = nil,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v_u_270,
				["height"] = v_u_144.touch(32),
				["width"] = v278,
				["onClick"] = function() end,
				["maxTextWidth"] = v278 - 12
			})
			v279.Name = "UseLive"
			v279.LayoutOrder = 3
			v275("ENDS", v_u_156.endsLbl, 4)
			local v281, v_u_282 = v_u_141.input({
				["parent"] = nil,
				["name"] = "Ends",
				["size"] = nil,
				["placeholder"] = "48 or 2026-11-02 18:00",
				["parent"] = v_u_270,
				["size"] = UDim2.fromOffset(v_u_156.endsIn, v_u_144.touch(30))
			})
			v281.LayoutOrder = 5
			v275("TEXT", v_u_156.textLbl, 6)
			local v283, v_u_284 = v_u_141.input({
				["parent"] = nil,
				["name"] = "Text",
				["size"] = nil,
				["placeholder"] = "short text",
				["maxLength"] = nil,
				["parent"] = v_u_270,
				["size"] = UDim2.fromOffset(v_u_156.textIn, v_u_144.touch(30)),
				["maxLength"] = v_u_4.TUNE.maxText
			})
			v283.LayoutOrder = 7
			local v285 = v_u_141.label({
				["parent"] = nil,
				["name"] = "Count",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["align"] = "right",
				["track"] = false,
				["size"] = nil,
				["parent"] = v258,
				["color"] = v_u_145.muted,
				["size"] = UDim2.new(1, 0, 0, 12)
			})
			v285.LayoutOrder = 3
			v285.Visible = false
			local v286 = v_u_141.label({
				["parent"] = nil,
				["name"] = "EndsNote",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["track"] = false,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v258,
				["color"] = v_u_145.muted,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v286.LayoutOrder = 4
			v286.RichText = false
			v286.Visible = false
			local v287 = v_u_141.label({
				["parent"] = nil,
				["name"] = "Preview",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["track"] = false,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v258,
				["color"] = v_u_145.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v287.LayoutOrder = 5
			v287.RichText = false
			v287.Visible = false
			local v_u_288 = {
				["frame"] = nil,
				["stroke"] = nil,
				["fill"] = nil,
				["row2"] = nil,
				["endsNote"] = nil,
				["preview"] = nil,
				["wasBox"] = nil,
				["endsBox"] = nil,
				["textBox"] = nil,
				["count"] = nil,
				["dirtyMark"] = nil,
				["syncing"] = false,
				["frame"] = v258,
				["stroke"] = v259,
				["fill"] = v262,
				["row2"] = v_u_270,
				["endsNote"] = v286,
				["preview"] = v287,
				["wasBox"] = v_u_277,
				["endsBox"] = v_u_282,
				["textBox"] = v_u_284,
				["count"] = v285,
				["dirtyMark"] = v269
			}
			v_u_165[v_u_257] = v_u_288
			local function v290() -- name: toggle
				-- upvalues: (ref) v_u_164, (copy) v_u_257, (ref) v_u_214, (ref) v_u_253
				local v289 = v_u_164[v_u_257]
				if v289 ~= nil then
					v289.ticked = not v289.ticked
					v_u_214 = false
					v_u_253()
				end
			end
			v_u_288.toggle = v290
			v261.Activated:Connect(v290)
			local function v298() -- name: useLive
				-- upvalues: (ref) v_u_164, (copy) v_u_257, (copy) v_u_256, (ref) v_u_165, (ref) v_u_214, (ref) v_u_253
				local v291 = v_u_164[v_u_257]
				if v291 ~= nil then
					local v292 = v_u_256.price
					if type(v292) == "number" then
						local v293 = v_u_256.price
						local v294 = math.floor(v293)
						v291.wasText = tostring(v294)
						local v295 = v_u_257
						local v296 = v_u_165[v295]
						local v297 = v_u_164[v295]
						if v296 ~= nil and v297 ~= nil then
							v296.syncing = true
							v296.wasBox.Text = v297.wasText
							v296.endsBox.Text = v297.endsText
							v296.textBox.Text = v297.textText
							v296.syncing = false
						end
						v_u_214 = false
						v_u_253()
					end
				end
			end
			v_u_288.useLive = v298
			local v299 = v280.setEnabled
			local v300 = v_u_256.price
			v299(type(v300) == "number")
			v279.Activated:Connect(v298)
			local v_u_301 = "wasText"
			v_u_277:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (copy) v_u_288, (ref) v_u_164, (copy) v_u_257, (copy) v_u_301, (copy) v_u_277, (ref) v_u_214, (ref) v_u_253
				if v_u_288.syncing then
					return
				else
					local v302 = v_u_164[v_u_257]
					if v302 ~= nil then
						v302[v_u_301] = v_u_277.Text
						v_u_214 = false
						v_u_253()
					end
				end
			end)
			local v_u_303 = "endsText"
			v_u_282:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (copy) v_u_288, (ref) v_u_164, (copy) v_u_257, (copy) v_u_303, (copy) v_u_282, (ref) v_u_214, (ref) v_u_253
				if v_u_288.syncing then
					return
				else
					local v304 = v_u_164[v_u_257]
					if v304 ~= nil then
						v304[v_u_303] = v_u_282.Text
						v_u_214 = false
						v_u_253()
					end
				end
			end)
			local v_u_305 = "textText"
			v_u_284:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (copy) v_u_288, (ref) v_u_164, (copy) v_u_257, (copy) v_u_305, (copy) v_u_284, (ref) v_u_214, (ref) v_u_253
				if v_u_288.syncing then
					return
				else
					local v306 = v_u_164[v_u_257]
					if v306 ~= nil then
						v306[v_u_305] = v_u_284.Text
						v_u_214 = false
						v_u_253()
					end
				end
			end)
			local v307 = v_u_165[v_u_257]
			local v308 = v_u_164[v_u_257]
			if v307 == nil then
				continue
			end
			if v308 == nil then
				continue
			end
			v307.syncing = true
			v307.wasBox.Text = v308.wasText
			v307.endsBox.Text = v308.endsText
			v307.textBox.Text = v308.textText
			v307.syncing = false
		end
	end
	local function v_u_327(p310, p311) -- name: take
		-- upvalues: (ref) v_u_217, (ref) v_u_212, (ref) v_u_159, (ref) v_u_210, (ref) v_u_161, (copy) v_u_164, (ref) v_u_4, (copy) v_u_152, (copy) v_u_309, (copy) v_u_165, (ref) v_u_253
		v_u_217 = p310.status
		local v312 = v_u_217
		local v313
		if type(v312) == "table" then
			local v314 = v_u_217.items
			v313 = type(v314) ~= "table" and {} or v_u_217.items
		else
			v313 = {}
		end
		v_u_212 = v313
		local v315 = p310.catalog
		local v316 = type(v315) ~= "table" and {} or p310.catalog
		local v317 = #v316 == #v_u_159
		if v317 then
			for v318, v319 in v316 do
				if v_u_159[v318] ~= nil and (v_u_159[v318].id == v319.id and (v_u_159[v318].price == v319.price and (v_u_159[v318].offSale == v319.offSale and v_u_159[v318].live == v319.live))) then
					continue
				end
				v317 = false
			end
		end
		v_u_159 = v316
		v_u_210 = {}
		v_u_161 = {}
		for _, v320 in v_u_159 do
			local v321 = v_u_210
			local v322 = v320.id
			table.insert(v321, v322)
			v_u_161[v320.id] = v320
		end
		for _, v323 in v_u_210 do
			v_u_164[v323] = v_u_4.initialEdit(v_u_212[v323], v_u_152)
		end
		if p311 or not v317 then
			v_u_309()
		else
			for _, v324 in v_u_210 do
				local v325 = v_u_165[v324]
				local v326 = v_u_164[v324]
				if v325 == nil then
					continue
				end
				if v326 == nil then
					continue
				end
				v325.syncing = true
				v325.wasBox.Text = v326.wasText
				v325.endsBox.Text = v326.endsText
				v325.textBox.Text = v326.textText
				v325.syncing = false
			end
		end
		v_u_253()
	end
	local function v_u_338(p_u_328, p_u_329) -- name: load
		-- upvalues: (ref) v_u_215, (copy) v_u_154, (ref) v_u_173, (copy) v_u_251, (ref) v_u_213, (copy) v_u_327, (copy) v_u_204, (copy) v_u_145, (ref) v_u_216, (copy) v_u_139, (ref) v_u_217, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164, (ref) v_u_214, (copy) v_u_224, (ref) v_u_159
		if not v_u_215 and v_u_154 then
			v_u_215 = true
			v_u_173 = os.clock()
			v_u_251()
			local v330
			if p_u_328 and v_u_154.callQuiet then
				v330 = v_u_154.callQuiet
			else
				v330 = v_u_154.call
			end
			v330("store.sale", {
				["cmd"] = "list"
			}, function(p331)
				-- upvalues: (ref) v_u_215, (ref) v_u_213, (ref) v_u_327, (copy) p_u_329, (copy) p_u_328, (ref) v_u_204, (ref) v_u_145, (ref) v_u_216, (ref) v_u_139, (ref) v_u_217, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (ref) v_u_164, (ref) v_u_214, (ref) v_u_224, (ref) v_u_159, (ref) v_u_251
				v_u_215 = false
				if not v_u_213 then
					return
				end
				local v332, v333, v334, v335
				if type(p331) == "table" and p331.ok then
					local v336 = p331.data
					if type(v336) == "table" then
						v_u_327(p331.data, p_u_329 == true)
						if not p_u_328 then
							local v337 = p331.msg or "Read."
							v_u_204.Text = tostring(v337)
							v_u_204.TextColor3 = v_u_145.text2
							v_u_216 = ""
							v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
						end
						v_u_251()
					else
						v332 = v_u_224
						v333 = p331 and (p331.msg or "The server did not answer.") or "The server did not answer."
						v332.Text = tostring(v333)
						v_u_224.TextColor3 = v_u_145.danger
						v_u_224.Visible = #v_u_159 == 0
						v334 = p331 and p331.msg or "The server did not answer."
						v335 = tostring(v334)
						v_u_204.Text = v335
						v_u_204.TextColor3 = v_u_145.danger
						v_u_216 = string.gsub(v335, "[|]", "/")
						v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
						v_u_251()
					end
				else
					v332 = v_u_224
					v333 = p331 and (p331.msg or "The server did not answer.") or "The server did not answer."
					v332.Text = tostring(v333)
					v_u_224.TextColor3 = v_u_145.danger
					v_u_224.Visible = #v_u_159 == 0
					v334 = p331 and p331.msg or "The server did not answer."
					v335 = tostring(v334)
					v_u_204.Text = v335
					v_u_204.TextColor3 = v_u_145.danger
					v_u_216 = string.gsub(v335, "[|]", "/")
					v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
					v_u_251()
					return
				end
			end)
		end
	end
	v_u_181 = function()
		-- upvalues: (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164, (copy) v_u_204, (copy) v_u_145, (ref) v_u_216, (copy) v_u_139, (ref) v_u_217, (ref) v_u_215, (ref) v_u_214, (ref) v_u_170, (copy) v_u_338
		if v_u_4.countDirty(v_u_210, v_u_212, v_u_164) > 0 then
			v_u_204.Text = "There are unsaved changes. Save them or press REFRESH again to drop them."
			v_u_204.TextColor3 = v_u_145.danger
			v_u_216 = string.gsub("There are unsaved changes. Save them or press REFRESH again to drop them.", "[|]", "/")
			v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
			if os.clock() - v_u_170 <= v_u_4.TUNE.confirmSec then
				v_u_170 = (-1 / 0)
				v_u_338(false, false)
			else
				v_u_170 = os.clock()
			end
		else
			v_u_338(false, false)
			return
		end
	end
	v_u_182 = function()
		-- upvalues: (ref) v_u_215, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164, (ref) v_u_214, (ref) v_u_170, (ref) v_u_213, (copy) v_u_251
		if v_u_215 then
			return
		elseif v_u_4.countDirty(v_u_210, v_u_212, v_u_164) ~= 0 then
			v_u_214 = true
			v_u_170 = os.clock()
			task.delay(v_u_4.TUNE.confirmSec, function()
				-- upvalues: (ref) v_u_213, (ref) v_u_214, (ref) v_u_170, (ref) v_u_4, (ref) v_u_251
				if v_u_213 and (v_u_214 and os.clock() - v_u_170 >= v_u_4.TUNE.confirmSec - 0.1) then
					v_u_214 = false
					v_u_251()
				end
			end)
			v_u_251()
		end
	end
	v_u_197 = function()
		-- upvalues: (ref) v_u_215, (ref) v_u_214, (ref) v_u_4, (ref) v_u_210, (copy) v_u_164, (ref) v_u_217, (copy) v_u_251, (copy) v_u_154, (ref) v_u_213, (copy) v_u_327, (copy) v_u_204, (copy) v_u_145, (ref) v_u_216, (copy) v_u_139, (ref) v_u_212
		if not v_u_215 and v_u_214 then
			local v339 = {
				["cmd"] = "save",
				["items"] = nil,
				["expect"] = nil,
				["confirm"] = true,
				["items"] = v_u_4.payload(v_u_210, v_u_164)
			}
			local v340
			if v_u_217 then
				v340 = v_u_217.v
			else
				v340 = nil
			end
			v339.expect = v340
			v_u_215 = true
			v_u_214 = false
			v_u_251()
			local v_u_341 = "Saved."
			v_u_154.call("store.sale", v339, function(p342)
				-- upvalues: (ref) v_u_215, (ref) v_u_213, (ref) v_u_327, (copy) v_u_341, (ref) v_u_204, (ref) v_u_145, (ref) v_u_216, (ref) v_u_139, (ref) v_u_217, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (ref) v_u_164, (ref) v_u_214, (ref) v_u_251
				v_u_215 = false
				if not v_u_213 then
					return
				end
				local v343, v344
				if type(p342) == "table" and p342.ok then
					local v345 = p342.data
					if type(v345) == "table" then
						v_u_327(p342.data, false)
						local v346 = p342.msg or v_u_341
						v_u_204.Text = tostring(v346)
						v_u_204.TextColor3 = v_u_145.text2
						v_u_216 = ""
						v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
						v_u_251()
					else
						v343 = p342 and p342.msg or "The server did not answer."
						v344 = tostring(v343)
						v_u_204.Text = v344
						v_u_204.TextColor3 = v_u_145.danger
						v_u_216 = string.gsub(v344, "[|]", "/")
						v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
						v_u_251()
					end
				else
					v343 = p342 and p342.msg or "The server did not answer."
					v344 = tostring(v343)
					v_u_204.Text = v344
					v_u_204.TextColor3 = v_u_145.danger
					v_u_216 = string.gsub(v344, "[|]", "/")
					v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
					v_u_251()
					return
				end
			end)
		end
	end
	v_u_198 = function()
		-- upvalues: (ref) v_u_214, (copy) v_u_251
		v_u_214 = false
		v_u_251()
	end
	v_u_183 = function()
		-- upvalues: (ref) v_u_215, (ref) v_u_171, (ref) v_u_4, (copy) v_u_193, (ref) v_u_214, (copy) v_u_251, (copy) v_u_154, (ref) v_u_213, (copy) v_u_327, (copy) v_u_204, (copy) v_u_145, (ref) v_u_216, (copy) v_u_139, (ref) v_u_217, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164
		if v_u_215 then
			return
		else
			local v347 = os.clock()
			if v347 - v_u_171 <= v_u_4.TUNE.allOffSec then
				v_u_171 = (-1 / 0)
				v_u_193.setText("All off")
				v_u_215 = true
				v_u_214 = false
				v_u_251()
				local v_u_348 = "All sales are off."
				v_u_154.call("store.sale", {
					["cmd"] = "clear",
					["confirm"] = true
				}, function(p349)
					-- upvalues: (ref) v_u_215, (ref) v_u_213, (ref) v_u_327, (copy) v_u_348, (ref) v_u_204, (ref) v_u_145, (ref) v_u_216, (ref) v_u_139, (ref) v_u_217, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (ref) v_u_164, (ref) v_u_214, (ref) v_u_251
					v_u_215 = false
					if not v_u_213 then
						return
					end
					local v350, v351
					if type(p349) == "table" and p349.ok then
						local v352 = p349.data
						if type(v352) == "table" then
							v_u_327(p349.data, false)
							local v353 = p349.msg or v_u_348
							v_u_204.Text = tostring(v353)
							v_u_204.TextColor3 = v_u_145.text2
							v_u_216 = ""
							v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
							v_u_251()
						else
							v350 = p349 and p349.msg or "The server did not answer."
							v351 = tostring(v350)
							v_u_204.Text = v351
							v_u_204.TextColor3 = v_u_145.danger
							v_u_216 = string.gsub(v351, "[|]", "/")
							v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
							v_u_251()
						end
					else
						v350 = p349 and p349.msg or "The server did not answer."
						v351 = tostring(v350)
						v_u_204.Text = v351
						v_u_204.TextColor3 = v_u_145.danger
						v_u_216 = string.gsub(v351, "[|]", "/")
						v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
						v_u_251()
						return
					end
				end)
			else
				v_u_171 = v347
				v_u_193.setText("Press again")
				v_u_204.Text = ("Press ALL OFF again within %d seconds to switch every sale off."):format(v_u_4.TUNE.allOffSec)
				v_u_204.TextColor3 = v_u_145.text2
				v_u_216 = ""
				v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
				task.delay(v_u_4.TUNE.allOffSec, function()
					-- upvalues: (ref) v_u_213, (ref) v_u_171, (ref) v_u_4, (ref) v_u_193
					if v_u_213 and os.clock() - v_u_171 >= v_u_4.TUNE.allOffSec - 0.1 then
						v_u_193.setText("All off")
					end
				end)
			end
		end
	end
	v_u_206:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_167, (copy) v_u_206, (ref) v_u_253
		v_u_167 = v_u_206.Text
		v_u_253()
	end)
	if v_u_3:IsStudio() then
		local v_u_365 = v_u_139:GetAttributeChangedSignal("FilmStoreSaleCmd"):Connect(function()
			-- upvalues: (copy) v_u_139, (copy) v_u_165, (copy) v_u_164, (ref) v_u_253, (ref) v_u_182, (ref) v_u_197, (ref) v_u_198, (ref) v_u_183, (copy) v_u_338, (ref) v_u_166, (copy) v_u_206
			local v354 = v_u_139:GetAttribute("FilmStoreSaleCmd")
			if type(v354) == "string" and v354 ~= "" then
				v_u_139:SetAttribute("FilmStoreSaleCmd", nil)
				local v355, v356 = string.match(v354, "^(%a+)%s*(.*)$")
				local v357, v358 = string.match(v356 or "", "^(%S+)%s*(.*)$")
				if v355 == "tick" and (v357 and v_u_165[v357]) then
					v_u_165[v357].toggle()
					return
				elseif v355 == "was" and (v357 and v_u_164[v357]) then
					v_u_164[v357].wasText = v358
					local v359 = v_u_165[v357]
					local v360 = v_u_164[v357]
					if v359 ~= nil and v360 ~= nil then
						v359.syncing = true
						v359.wasBox.Text = v360.wasText
						v359.endsBox.Text = v360.endsText
						v359.textBox.Text = v360.textText
						v359.syncing = false
					end
					v_u_253()
					return
				elseif v355 == "ends" and (v357 and v_u_164[v357]) then
					v_u_164[v357].endsText = v358
					local v361 = v_u_165[v357]
					local v362 = v_u_164[v357]
					if v361 ~= nil and v362 ~= nil then
						v361.syncing = true
						v361.wasBox.Text = v362.wasText
						v361.endsBox.Text = v362.endsText
						v361.textBox.Text = v362.textText
						v361.syncing = false
					end
					v_u_253()
					return
				elseif v355 == "text" and (v357 and v_u_164[v357]) then
					v_u_164[v357].textText = v358
					local v363 = v_u_165[v357]
					local v364 = v_u_164[v357]
					if v363 ~= nil and v364 ~= nil then
						v363.syncing = true
						v363.wasBox.Text = v364.wasText
						v363.endsBox.Text = v364.endsText
						v363.textBox.Text = v364.textText
						v363.syncing = false
					end
					v_u_253()
					return
				elseif v355 == "uselive" and (v357 and v_u_165[v357]) then
					v_u_165[v357].useLive()
					return
				elseif v355 == "save" then
					v_u_182()
					return
				elseif v355 == "yes" then
					v_u_197()
					return
				elseif v355 == "no" then
					v_u_198()
					return
				elseif v355 == "alloff" then
					v_u_183()
					return
				elseif v355 == "refresh" then
					v_u_338(false, false)
					return
				elseif v355 == "filter" and v357 then
					v_u_166 = v357
					v_u_253()
				elseif v355 == "search" then
					v_u_206.Text = v356 or ""
				end
			else
				return
			end
		end)
		p_u_138.gui.Destroying:Connect(function()
			-- upvalues: (copy) v_u_365
			v_u_365:Disconnect()
		end)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_213, (copy) p_u_138, (copy) v_u_153, (copy) v_u_338, (ref) v_u_215, (ref) v_u_214, (ref) v_u_4, (ref) v_u_210, (ref) v_u_212, (copy) v_u_164, (ref) v_u_173, (ref) v_u_253
		local v366 = false
		local v367 = 0
		while v_u_213 do
			local v368 = p_u_138.gui.Enabled
			if v368 then
				v368 = v_u_153.Visible
			end
			if v368 then
				if v366 then
					if not v_u_215 and (not v_u_214 and (v_u_4.countDirty(v_u_210, v_u_212, v_u_164) == 0 and os.clock() - v_u_173 >= v_u_4.TUNE.autoRefresh)) then
						v_u_338(true, false)
					end
				else
					v_u_338(false, false)
				end
				if os.clock() - v367 >= 1 then
					v367 = os.clock()
					v_u_253()
				end
			end
			task.wait(0.5)
			v366 = v368
		end
	end)
	v_u_139:SetAttribute("FilmStoreSale", ("v=%d|on=%d|dirty=%d|busy=%d|confirm=%d|err=%s"):format(v_u_217 and (v_u_217.v or 0) or 0, v_u_217 and (v_u_217.running or 0) or 0, v_u_4.countDirty(v_u_210, v_u_212, v_u_164), v_u_215 and 1 or 0, v_u_214 and 1 or 0, v_u_216))
	return {
		["refresh"] = function() -- name: refresh
			-- upvalues: (copy) v_u_338
			v_u_338(false, false)
		end,
		["tick"] = function(p369) -- name: tick
			-- upvalues: (copy) v_u_165
			if v_u_165[p369] then
				v_u_165[p369].toggle()
			end
		end,
		["state"] = function() -- name: state
			-- upvalues: (copy) v_u_139
			local v370 = v_u_139
			return tostring(v370:GetAttribute("FilmStoreSale"))
		end,
		["edits"] = function() -- name: edits
			-- upvalues: (copy) v_u_164
			return v_u_164
		end,
		["dirty"] = v176
	}
end
return v_u_4