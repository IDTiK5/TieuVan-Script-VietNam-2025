-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TestTag

local v1 = game:GetService("Players")
local v_u_2 = require(script.Parent:WaitForChild("HushUI"))
local v_u_3 = v_u_2.Theme
local v_u_4 = v_u_3.color
local v_u_5 = {}
local v_u_6 = {
	["desk"] = {
		["padH"] = 12,
		["padV"] = 3,
		["title"] = 11,
		["titleH"] = 12,
		["line"] = 11,
		["lineH"] = 13,
		["edge"] = 4
	},
	["touch"] = {
		["padH"] = 14,
		["padV"] = 4,
		["title"] = 12,
		["titleH"] = 14,
		["line"] = 12,
		["lineH"] = 15,
		["edge"] = 4
	},
	["menu"] = {
		["padH"] = 12,
		["padV"] = 2,
		["title"] = 11,
		["titleH"] = 11,
		["line"] = 11,
		["lineH"] = 12,
		["edge"] = 2
	},
	["phone"] = {
		["padH"] = 10,
		["padV"] = 1,
		["title"] = 13,
		["titleH"] = 16,
		["line"] = 13,
		["lineH"] = 16,
		["edge"] = 2,
		["row"] = true,
		["titleOnly"] = true
	},
	["menuPhone"] = {
		["padH"] = 10,
		["padV"] = 2,
		["title"] = 13,
		["titleH"] = 16,
		["line"] = 13,
		["lineH"] = 16,
		["edge"] = 2,
		["row"] = true
	}
}
local v_u_7 = v1.LocalPlayer
local v_u_8 = false
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = {}
local v_u_12 = nil
local v_u_13 = {}
local function v_u_29() -- name: place
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2
	local v14 = v_u_10
	if v14 then
		local v15 = v_u_7:GetAttribute("MenuOpen") == true and "menu" or "hud"
		local v16 = v_u_3.isPhone()
		local v17
		if v15 == "menu" then
			if v16 then
				v17 = v_u_6.menuPhone
			else
				v17 = v_u_6.menu
			end
		elseif v16 then
			v17 = v_u_6.phone
		elseif v_u_2.device() == "Touch" then
			v17 = v_u_6.touch
		else
			v17 = v_u_6.desk
		end
		local v18 = v14:FindFirstChildOfClass("UIPadding")
		if v18 then
			v18.PaddingLeft = UDim.new(0, v17.padH)
			v18.PaddingRight = UDim.new(0, v17.padH)
			v18.PaddingTop = UDim.new(0, v17.padV)
			v18.PaddingBottom = UDim.new(0, v17.padV)
		end
		local v19 = v14:FindFirstChild("Text")
		local v20
		if v19 then
			v20 = v19:FindFirstChild("Title")
		else
			v20 = v19
		end
		local v21
		if v19 then
			v21 = v19:FindFirstChild("Line")
		else
			v21 = v19
		end
		local v22
		if v17.row then
			local v23 = v17.titleH
			local v24 = v17.lineH
			v22 = math.max(v23, v24)
		else
			v22 = v17.titleH + v17.lineH
		end
		local v25 = not v17.titleOnly and v17.row
		if v25 then
			v25 = v_u_3.viewport().X < 700
		end
		local v26 = not v25
		if v19 then
			v19.Size = UDim2.fromOffset(0, v22)
			local v27 = v19:FindFirstChildOfClass("UIListLayout")
			if v27 then
				local v28
				if v17.row then
					v28 = Enum.FillDirection.Horizontal
				else
					v28 = Enum.FillDirection.Vertical
				end
				v27.FillDirection = v28
				v27.Padding = UDim.new(0, v17.row and 8 or 0)
				v27.VerticalAlignment = Enum.VerticalAlignment.Center
			end
		end
		if v20 then
			v20.TextSize = v17.title
			v20.Size = UDim2.fromOffset(0, v17.titleH)
		end
		if v21 then
			v21.TextSize = v17.line
			v21.Size = UDim2.fromOffset(0, v17.lineH)
			v21.Visible = v26
		end
		v14.Size = UDim2.fromOffset(0, v22 + 2 * v17.padV)
		if v15 == "menu" then
			v14.AnchorPoint = Vector2.new(0.5, 1)
			v14.Position = UDim2.new(0.5, 0, 1, -v17.edge)
		else
			v14.AnchorPoint = Vector2.new(0.5, 0)
			v14.Position = UDim2.new(0.5, 0, 0, v17.edge)
		end
	else
		return
	end
end
local function v_u_35() -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (ref) v_u_9, (copy) v_u_6, (copy) v_u_4, (ref) v_u_10, (copy) v_u_29
	local v30, v31 = v_u_2.screen("HushTestTag", v_u_3.layer.menu + 1)
	v_u_9 = v30
	local v32 = v_u_6.desk
	local v33 = v_u_2.new("Frame", {
		["Name"] = "TestTag",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Active"] = false,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_4.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, v32.edge),
		["Size"] = UDim2.fromOffset(0, v32.titleH + v32.lineH + 2 * v32.padV),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v31)
	v_u_2.stroke(v33, v_u_4.accent, 1, 0.55)
	v_u_2.pad(v33, {
		v32.padH,
		v32.padH,
		v32.padV,
		v32.padV
	})
	local v34 = v_u_2.new("Frame", {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Active"] = false,
		["Size"] = UDim2.fromOffset(0, v32.titleH + v32.lineH),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v33)
	v_u_2.layout(v34, "v", 0)
	v_u_2.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "TEST GAME",
		["style"] = "caps",
		["textSize"] = nil,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 1,
		["align"] = "center",
		["parent"] = v34,
		["textSize"] = v32.title,
		["color"] = v_u_4.accent,
		["size"] = UDim2.fromOffset(0, v32.titleH)
	}).Active = false
	v_u_2.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = "Your progress is a copy of your live save. Nothing here counts live.",
		["style"] = "small",
		["textSize"] = nil,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 2,
		["track"] = false,
		["align"] = "center",
		["parent"] = v34,
		["textSize"] = v32.line,
		["color"] = v_u_4.text2,
		["size"] = UDim2.fromOffset(0, v32.lineH)
	}).Active = false
	v_u_10 = v33
	v_u_29()
end
function v_u_5.start(p36) -- name: start
	-- upvalues: (ref) v_u_8, (copy) v_u_2, (copy) v_u_35, (copy) v_u_11, (copy) v_u_3, (copy) v_u_29, (ref) v_u_12, (copy) v_u_7, (copy) v_u_13, (ref) v_u_9, (copy) v_u_5
	if not v_u_8 and (p36 and (p36.config and p36.config.IS_TEST == true)) then
		v_u_8 = true
		v_u_2.bind(p36)
		v_u_35()
		local v37 = v_u_11
		local v38 = v_u_3.scaleChanged
		local v39 = v_u_29
		table.insert(v37, v38:Connect(v39))
		v_u_12 = v_u_2.onDevice(function()
			-- upvalues: (ref) v_u_29
			v_u_29()
		end)
		local v40 = v_u_11
		local v41 = v_u_7:GetAttributeChangedSignal("MenuOpen")
		local v42 = v_u_29
		table.insert(v40, v41:Connect(v42))
		if p36.on then
			local v43 = v_u_13
			local v44 = p36.on
			local function v45()
				-- upvalues: (ref) v_u_9, (ref) v_u_29
				if v_u_9 and v_u_9.Parent then
					v_u_29()
				end
			end
			table.insert(v43, v44("ui.rebuild", v45))
		end
		if p36.command then
			p36.command("testtag.state", function()
				-- upvalues: (ref) v_u_5
				local v46 = v_u_5.state()
				local v47 = v46.rect
				local v48 = v46.visible
				return ("visible %s, device %s, context %s, viewport %dx%d, rect x %d y %d w %d h %d"):format(tostring(v48), v46.device, v46.context, v46.viewport.X, v46.viewport.Y, v47.x, v47.y, v47.w, v47.h)
			end)
			p36.command("testtag.overlaps", function()
				-- upvalues: (ref) v_u_5
				local v49, v50 = v_u_5.overlaps()
				return (#v49 == 0 and "nothing under the tag" or #v49 .. " UNDER the tag: " .. table.concat(v49, " | ")) .. "; " .. (#v50 == 0 and "nothing above it" or #v50 .. " above it (cover the tag): " .. table.concat(v50, " | "))
			end)
		end
	end
end
function v_u_5.state() -- name: state
	-- upvalues: (ref) v_u_10, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (ref) v_u_9
	local v51 = v_u_10
	if not (v51 and v51.Parent) then
		return {
			["visible"] = false,
			["device"] = nil,
			["context"] = nil,
			["rect"] = nil,
			["viewport"] = nil,
			["device"] = v_u_2.device(),
			["context"] = v_u_7:GetAttribute("MenuOpen") == true and "menu" or "hud",
			["rect"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 0,
				["h"] = 0
			},
			["viewport"] = v_u_3.viewport()
		}
	end
	local v52 = v51.AbsolutePosition
	local v53 = v51.AbsoluteSize
	local v54 = {}
	local v55 = v_u_9 ~= nil and v_u_9.Enabled
	if v55 then
		v55 = v51.Visible
	end
	v54.visible = v55
	v54.device = v_u_2.device()
	v54.context = v_u_7:GetAttribute("MenuOpen") == true and "menu" or "hud"
	local v56 = {}
	local v57 = v52.X + 0.5
	v56.x = math.floor(v57)
	local v58 = v52.Y + 0.5
	v56.y = math.floor(v58)
	local v59 = v53.X + 0.5
	v56.w = math.floor(v59)
	local v60 = v53.Y + 0.5
	v56.h = math.floor(v60)
	v54.rect = v56
	v54.viewport = v_u_3.viewport()
	return v54
end
local function v_u_66(p61, p62) -- name: draws
	if string.find(p61.Name, "Shade") or p61.Name == "Grain" then
		return false
	elseif p61.AbsoluteSize.X >= p62.X * 0.8 and p61.AbsoluteSize.Y >= p62.Y * 0.6 then
		return false
	elseif p61.BackgroundTransparency < 0.9 then
		return true
	elseif p61:IsA("TextLabel") or p61:IsA("TextButton") then
		local v63
		if p61.Text == "" then
			v63 = false
		else
			v63 = p61.TextTransparency < 0.9
		end
		return v63
	elseif p61:IsA("ImageLabel") or p61:IsA("ImageButton") then
		local v64
		if p61.Image == "" then
			v64 = false
		else
			v64 = p61.ImageTransparency < 0.9
		end
		return v64
	else
		for _, v65 in p61:GetChildren() do
			if not v65:IsA("UIStroke") or (not v65.Enabled or v65.Transparency >= 0.9) then
				continue
			end
			return true
		end
		return false
	end
end
local function v_u_79(p67) -- name: drawnRect
	local v68 = p67.AbsolutePosition
	local v69 = p67.AbsoluteSize
	if not (p67:IsA("TextLabel") or p67:IsA("TextButton")) or p67.BackgroundTransparency < 0.9 then
		return v68, v69
	end
	local v70 = p67.TextBounds
	local v71 = v70.X
	local v72 = v69.X
	local v73 = math.min(v71, v72)
	local v74 = v70.Y
	local v75 = v69.Y
	local v76 = math.min(v74, v75)
	local v77 = v68.X
	local v78 = v68.Y
	if p67.TextXAlignment == Enum.TextXAlignment.Right then
		v77 = v68.X + v69.X - v73
	elseif p67.TextXAlignment == Enum.TextXAlignment.Center then
		v77 = v68.X + (v69.X - v73) / 2
	end
	if p67.TextYAlignment == Enum.TextYAlignment.Center then
		v78 = v68.Y + (v69.Y - v76) / 2
	elseif p67.TextYAlignment == Enum.TextYAlignment.Bottom then
		v78 = v68.Y + v69.Y - v76
	end
	return Vector2.new(v77, v78), Vector2.new(v73, v76)
end
local function v_u_81(p80) -- name: shown
	while p80 and not p80:IsA("ScreenGui") do
		if p80:IsA("GuiObject") and not p80.Visible then
			return false
		end
		p80 = p80.Parent
	end
	return true
end
function v_u_5.overlaps() -- name: overlaps
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (ref) v_u_9, (copy) v_u_3, (copy) v_u_81, (copy) v_u_66, (copy) v_u_79
	local v82 = {}
	local v83 = {}
	local v84 = v_u_10
	local v85 = v_u_7:FindFirstChildOfClass("PlayerGui")
	if not (v84 and (v84.Parent and (v85 and v_u_9))) then
		return v82, v83
	end
	local v86 = v84.AbsolutePosition
	local v87 = v84.AbsoluteSize
	local v88 = v_u_3.viewport()
	for _, v89 in v85:GetChildren() do
		if not v89:IsA("ScreenGui") or (not v89.Enabled or v89 == v_u_9) then
			continue
		end
		local v90
		if v89.DisplayOrder > v_u_9.DisplayOrder then
			v90 = v83
		else
			v90 = v82
		end
		for _, v91 in v89:GetDescendants() do
			if #v90 >= 12 or not (v91:IsA("GuiObject") and (v_u_81(v91) and v_u_66(v91, v88))) then
				continue
			end
			local v92, v93 = v_u_79(v91)
			if v92.X >= v86.X + v87.X or (v92.X + v93.X <= v86.X or (v92.Y >= v86.Y + v87.Y or v92.Y + v93.Y <= v86.Y)) then
				continue
			end
			local v94 = v91.Name
			local v95 = v91.Parent
			if v95 and v95 ~= v89 then
				v94 = v95.Name .. "." .. v94
				v95 = v95.Parent
			end
			if v95 and v95 ~= v89 then
				v94 = v95.Name .. "." .. v94
				v95 = v95.Parent
			end
			if v95 and v95 ~= v89 then
				v94 = v95.Name .. "." .. v94
				local _ = v95.Parent
			end
			local v96 = v89.Name .. "." .. v94
			table.insert(v90, v96)
		end
	end
	return v82, v83
end
function v_u_5.destroy() -- name: destroy
	-- upvalues: (ref) v_u_8, (copy) v_u_11, (ref) v_u_12, (copy) v_u_13, (ref) v_u_9, (ref) v_u_10
	v_u_8 = false
	for _, v97 in v_u_11 do
		v97:Disconnect()
	end
	table.clear(v_u_11)
	if v_u_12 then
		v_u_12()
		v_u_12 = nil
	end
	for _, v98 in v_u_13 do
		v98()
	end
	table.clear(v_u_13)
	if v_u_9 then
		v_u_9:Destroy()
		v_u_9 = nil
	end
	v_u_10 = nil
end
return v_u_5