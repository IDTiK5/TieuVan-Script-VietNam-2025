-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FlareShellFx

local v_u_1 = game:GetService("Workspace")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v4 = {}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = nil
local function v_u_15() -- name: ensureFolder
	-- upvalues: (ref) v_u_7, (copy) v_u_1
	local v12 = v_u_7
	if v12 and v12.Parent then
		return v12
	end
	local v13 = v_u_1:FindFirstChild("HushLocal")
	if not v13 then
		v13 = Instance.new("Folder")
		v13.Name = "HushLocal"
		v13.Parent = v_u_1
	end
	local v14 = v13:FindFirstChild("FlareFx")
	if not v14 then
		v14 = Instance.new("Folder")
		v14.Name = "FlareFx"
		v14.Parent = v13
	end
	v_u_7 = v14
	return v_u_7
end
local function v_u_24(...) -- name: numSeq
	local v16 = { ... }
	local v17 = {}
	for v18, v19 in v16 do
		local v20 = NumberSequenceKeypoint.new
		local v21 = v18 - 1
		local v22 = #v16 - 1
		local v23 = v21 / math.max(1, v22)
		table.insert(v17, v20(v23, v19))
	end
	return NumberSequence.new(v17)
end
local function v_u_33(p25, p26, p27, p28, p29, p30, p31) -- name: smokeEmitter
	-- upvalues: (copy) v_u_24
	local v32 = Instance.new("ParticleEmitter")
	v32.Name = "Smoke"
	v32.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v32.Color = ColorSequence.new(p26, p26:Lerp(Color3.fromRGB(70, 70, 74), 0.6))
	v32.LightEmission = 0.25
	v32.LightInfluence = 0.2
	v32.Transparency = v_u_24(0.45, 0.65, 1)
	v32.Size = v_u_24(p28, p29)
	v32.Lifetime = NumberRange.new(p30 * 0.7, p30)
	v32.Rate = p27
	v32.Speed = NumberRange.new(0.5, 2)
	v32.SpreadAngle = Vector2.new(25, 25)
	v32.Acceleration = Vector3.new(0.4, p31, 0.2)
	v32.RotSpeed = NumberRange.new(-30, 30)
	v32.EmissionDirection = Enum.NormalId.Top
	v32.Parent = p25
	return v32
end
local function v_u_38(p34, p35, p36) -- name: sparkEmitter
	-- upvalues: (copy) v_u_24
	local v37 = Instance.new("ParticleEmitter")
	v37.Name = "Sparks"
	v37.Texture = "rbxasset://textures/particles/fire_sparks_main.dds"
	v37.Color = ColorSequence.new(p35, Color3.new(1, 1, 1))
	v37.LightEmission = 1
	v37.LightInfluence = 0
	v37.Orientation = Enum.ParticleOrientation.VelocityParallel
	v37.Squash = NumberSequence.new(1.4)
	v37.Size = v_u_24(0.32, 0)
	v37.Lifetime = NumberRange.new(0.3, 0.7)
	v37.Rate = p36
	v37.Speed = NumberRange.new(3, 9)
	v37.SpreadAngle = Vector2.new(50, 50)
	v37.Acceleration = Vector3.new(0, -14, 0)
	v37.EmissionDirection = Enum.NormalId.Top
	v37.Parent = p34
	return v37
end
local function v_u_105(p39, p40, p41, p42, p43, p44) -- name: startBurn
	-- upvalues: (copy) v_u_15, (copy) v_u_9, (copy) v_u_33, (copy) v_u_24, (copy) v_u_38, (ref) v_u_5, (ref) v_u_6, (ref) v_u_11
	local v45 = v_u_15()
	while #v_u_9 >= 12 do
		local v46 = table.remove(v_u_9, 1)
		if not (v46 and v46.root) then
			continue
		end
		v46.root:Destroy()
	end
	local v47 = Instance.new("Model")
	local v48 = p39 and (p39.key or "dud") or "dud"
	v47.Name = "Burn_" .. tostring(v48)
	v47.Parent = v45
	local v49 = CFrame.new(p40 + Vector3.new(0, 0.3, 0))
	local v50 = Color3.new(1, 1, 1)
	local v51 = Instance.new("Part")
	v51.Name = "Base"
	v51.Anchored = true
	v51.CanCollide = false
	v51.CanQuery = false
	v51.CanTouch = false
	v51.CastShadow = false
	v51.Size = Vector3.new(0.4, 0.4, 0.4)
	v51.CFrame = v49
	v51.Color = v50
	v51.Material = Enum.Material.Neon
	v51.Parent = v47
	v51.Transparency = 1
	local v52 = {
		["root"] = nil,
		["base"] = nil,
		["t0"] = nil,
		["dur"] = nil,
		["key"] = nil,
		["ring"] = 0,
		["color"] = nil,
		["root"] = v47,
		["base"] = v51,
		["t0"] = os.clock(),
		["dur"] = p41,
		["key"] = not p39 and "dud" or p39.key
	}
	local v53
	if p39 then
		v53 = p39.color
	else
		v53 = Color3.fromRGB(120, 120, 124)
	end
	v52.color = v53
	if p42 or not p39 then
		local v54 = v_u_33(v51, Color3.fromRGB(150, 150, 154), 0, 1, 4, 1.6, 0.6)
		v54.Transparency = v_u_24(0.6, 0.8, 1)
		v54:Emit(10)
		v52.dur = 2.5
		local v55 = v_u_9
		table.insert(v55, v52)
	else
		local v56 = p39.color
		local v57 = p39.key
		local v58 = Instance.new("PointLight")
		v58.Color = v56
		v58.Shadows = false
		v58.Range = 40
		v58.Brightness = 3
		v58.Parent = v51
		v52.light = v58
		v52.baseBright = 3
		v52.untilAt = os.clock() + p41
		if v57 == "white" then
			v58.Range = 70
			v58.Brightness = 5
			v52.baseBright = 5
			v58.Color = Color3.fromRGB(235, 240, 255)
			local v59 = CFrame.new(p40 + Vector3.new(0, 1, 0))
			local v60 = Color3.fromRGB(245, 248, 255)
			local v61 = Instance.new("Part")
			v61.Name = "Ball"
			v61.Anchored = true
			v61.CanCollide = false
			v61.CanQuery = false
			v61.CanTouch = false
			v61.CastShadow = false
			v61.Size = Vector3.new(1.3, 1.3, 1.3)
			v61.CFrame = v59
			v61.Color = v60
			v61.Material = Enum.Material.Neon
			v61.Parent = v47
			v61.Shape = Enum.PartType.Ball
			v52.ball = v61
			v_u_38(v51, Color3.fromRGB(235, 240, 255), 50)
			v_u_33(v51, Color3.fromRGB(235, 235, 240), 6, 1, 6, 4, 1.5)
		elseif v57 == "yellow" then
			v58.Range = 36
			v_u_38(v51, v56, 60)
			v_u_33(v51, v56, 8, 1, 6, 3.5, 1.5)
		elseif v57 == "orange" then
			v58.Range = 30
			v58.Brightness = 2
			v52.baseBright = 2
			if not v_u_5 then
				local v62, v63 = pcall(function()
					return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
				end)
				if not v62 then
					v63 = nil
				end
				v_u_5 = v63
			end
			local v64
			if v_u_5 then
				if not v_u_5 then
					local v65, v66 = pcall(function()
						return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
					end)
					if not v65 then
						v66 = nil
					end
					v_u_5 = v66
				end
				v64 = v_u_5.T.orange.radius or 16
			else
				v64 = 16
			end
			local v67 = v64 * 1.5
			local v68 = v64 * 1.5
			local v69 = Vector3.new(v67, 3, v68)
			local v70 = CFrame.new(p40 + Vector3.new(0, 2.5, 0))
			local v71 = Instance.new("Part")
			v71.Name = "Cloud"
			v71.Anchored = true
			v71.CanCollide = false
			v71.CanQuery = false
			v71.CanTouch = false
			v71.CastShadow = false
			v71.Size = v69
			v71.CFrame = v70
			v71.Color = v56
			v71.Material = Enum.Material.SmoothPlastic
			v71.Parent = v47
			v71.Transparency = 1
			local v72 = v_u_33(v71, v56, 22, 9, 24, 5, 0.8)
			v72.SpreadAngle = Vector2.new(180, 180)
			v72.Speed = NumberRange.new(0.2, 1)
			v72.Transparency = v_u_24(0.5, 0.55, 1)
			v72.LightEmission = 0.15
			v_u_38(v51, v56, 25)
		elseif v57 == "blue" then
			v58.Range = 44
			v_u_38(v51, v56, 40)
			local v73 = Instance.new("Attachment")
			v73.Parent = v51
			local v74 = Instance.new("Attachment")
			v74.Position = Vector3.new(0, 150, 0)
			v74.Parent = v51
			for _, v75 in {
				{ 2.2, 0.8, 0.4 },
				{ 9, 4, 0.85 }
			} do
				local v76 = Instance.new("Beam")
				v76.Attachment0 = v73
				v76.Attachment1 = v74
				v76.Width0 = v75[1]
				v76.Width1 = v75[2]
				v76.FaceCamera = true
				v76.LightEmission = 1
				v76.LightInfluence = 0
				v76.Segments = 1
				v76.Color = ColorSequence.new(v56)
				local v77 = v_u_24
				local v78 = v75[3]
				local v79 = v75[3] + 0.25
				v76.Transparency = v77(v78, math.min(1, v79), 1)
				v76.Parent = v51
			end
			if p43 then
				local v80 = Instance.new("BillboardGui")
				v80.Name = "Label"
				v80.Adornee = v51
				v80.AlwaysOnTop = true
				v80.LightInfluence = 0
				v80.Size = UDim2.fromOffset(180, 40)
				v80.StudsOffsetWorldSpace = Vector3.new(0, 12, 0)
				v80.MaxDistance = 3000
				v80.ResetOnSpawn = false
				v80.Parent = v51
				local v81 = Instance.new("TextLabel")
				v81.BackgroundTransparency = 1
				v81.Size = UDim2.fromScale(1, 1)
				v81.Font = Enum.Font.GothamBold
				v81.TextSize = 15
				v81.TextColor3 = v56
				v81.TextStrokeTransparency = 0.4
				v81.TextStrokeColor3 = Color3.new(0, 0, 0)
				v81.Text = p43
				v81.Parent = v80
				v52.label = v81
				v52.labelText = p43
			end
		elseif v57 == "violet" then
			v58.Range = 46
			v58.Brightness = 3
			v52.baseBright = 3
			v_u_38(v51, v56, 45)
			v_u_33(v51, v56, 14, 3, 18, 8, 8)
		else
			v58.Range = 44
			v58.Brightness = 3.4
			v52.baseBright = 3.4
			v_u_38(v51, v56, 70)
			v_u_33(v51, v56, 12, 3, 16, 7, 7)
		end
		local v82 = v_u_6 and v_u_6.controllers
		if v82 then
			v82 = v_u_6.controllers.Audio
		end
		if v82 and v82.play3D then
			local v83 = v82.play3D
			pcall(v83, "ev_flare_ignite", p40)
		end
		local v84 = v58.Range
		if not v_u_5 then
			local v85, v86 = pcall(function()
				return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
			end)
			if not v85 then
				v86 = nil
			end
			v_u_5 = v86
		end
		local v87
		if v_u_5 then
			if not v_u_5 then
				local v88, v89 = pcall(function()
					return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
				end)
				if not v88 then
					v89 = nil
				end
				v_u_5 = v89
			end
			v87 = v_u_5.T.lights.maxRange or 70
		else
			v87 = 70
		end
		v52.range0 = math.min(v84, v87)
		local v90 = v_u_9
		table.insert(v90, v52)
		if not v_u_5 then
			local v91, v92 = pcall(function()
				return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
			end)
			if not v91 then
				v92 = nil
			end
			v_u_5 = v92
		end
		local v93 = v_u_5
		if v93 then
			local v94 = v93.bookAdd
			if type(v94) == "function" then
				if not v_u_11 then
					v_u_11 = v93.bookNew()
				end
				local v95 = os.clock()
				for _, v96 in v93.bookAdd(v_u_11, p44 or 0, v57, v95, p41, v52) do
					local v97 = v96.id
					if type(v97) ~= "table" or (v97 == v52 or (not v97.untilAt or v95 >= v97.untilAt)) then
						continue
					end
					if not v_u_5 then
						local v98, v99 = pcall(function()
							return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
						end)
						if not v98 then
							v99 = nil
						end
						v_u_5 = v99
					end
					local v100
					if v_u_5 then
						if not v_u_5 then
							local v101, v102 = pcall(function()
								return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
							end)
							if not v101 then
								v102 = nil
							end
							v_u_5 = v102
						end
						v100 = v_u_5.T.lights.fade or 1.2
					else
						v100 = 1.2
					end
					local v103 = v97.dur
					local v104 = v95 - v97.t0 + v100
					v97.dur = math.min(v103, v104)
				end
			end
		end
	end
end
local function v_u_129(p106) -- name: startShell
	-- upvalues: (ref) v_u_5, (copy) v_u_15, (copy) v_u_8, (copy) v_u_24
	if not v_u_5 then
		local v107, v108 = pcall(function()
			return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
		end)
		if not v107 then
			v108 = nil
		end
		v_u_5 = v108
	end
	local v109 = v_u_5
	if v109 then
		local v110 = v109.byN(p106.n)
		local v111 = p106.path
		local v112 = p106.t
		local v113 = tonumber(v112)
		if type(v111) == "table" and (#v111 >= 2 and (#v111 <= 64 and (v113 and v113 == v113))) then
			for _, v114 in v111 do
				if typeof(v114) == "Vector3" then
					continue
				end
				return
			end
			local v115 = math.clamp(v113, 0.1, 3)
			local v116 = v_u_15()
			local v117 = v109.T.lights and v109.T.lights.maxShells
			if not v117 then
				v117 = 12
			end
			while v117 <= #v_u_8 do
				local v118 = table.remove(v_u_8, 1)
				if not (v118 and v118.model) then
					continue
				end
				v118.model:Destroy()
			end
			local v119
			if v110 then
				v119 = v110.color
			else
				v119 = Color3.fromRGB(200, 200, 200)
			end
			local v120 = Instance.new("Model")
			v120.Name = "Shell"
			v120.Parent = v116
			local v121 = CFrame.new(v111[1])
			local v122 = Instance.new("Part")
			v122.Name = "Body"
			v122.Anchored = true
			v122.CanCollide = false
			v122.CanQuery = false
			v122.CanTouch = false
			v122.CastShadow = false
			v122.Size = Vector3.new(0.34, 0.34, 0.9)
			v122.CFrame = v121
			v122.Color = v119
			v122.Material = Enum.Material.Neon
			v122.Parent = v120
			local v123 = Instance.new("Attachment")
			v123.Position = Vector3.new(0, 0, -0.3)
			v123.Parent = v122
			local v124 = Instance.new("Attachment")
			v124.Position = Vector3.new(0, 0, 0.5)
			v124.Parent = v122
			local v125 = Instance.new("Trail")
			v125.Attachment0 = v123
			v125.Attachment1 = v124
			v125.Lifetime = 0.55
			v125.LightEmission = 1
			v125.Color = ColorSequence.new(v119, v119:Lerp(Color3.new(1, 1, 1), 0.5))
			v125.Transparency = v_u_24(0.1, 1)
			v125.WidthScale = v_u_24(1, 0.1)
			v125.Parent = v122
			local v126 = Instance.new("PointLight")
			v126.Color = v119
			v126.Range = 14
			v126.Brightness = 2.5
			v126.Shadows = false
			v126.Parent = v122
			local v127 = v_u_8
			local v128 = {
				["model"] = v120,
				["body"] = v122,
				["path"] = v111,
				["t"] = v115,
				["t0"] = os.clock(),
				["c"] = v110,
				["data"] = p106
			}
			table.insert(v127, v128)
		end
	else
		return
	end
end
local function v_u_142(p130, p131) -- name: samplePath
	local v132 = #p130
	local v133 = math.clamp(p131, 0, 1) * (v132 - 1)
	local v134 = v132 - 1
	local v135 = math.floor(v133) + 1
	local v136 = math.min(v134, v135)
	local v137 = p130[v136]
	local v138 = p130[v136 + 1]
	local v139 = v133 - (v136 - 1)
	local v140 = v137:Lerp(v138, (math.clamp(v139, 0, 1)))
	local v141 = v138 - v137
	if v141.Magnitude > 0.01 then
		return v140, v141.Unit
	else
		return v140, Vector3.new(0, -1, 0)
	end
end
local function v_u_161(p143) -- name: startBeacon
	-- upvalues: (ref) v_u_5, (copy) v_u_105, (copy) v_u_2, (ref) v_u_6
	if not v_u_5 then
		local v144, v145 = pcall(function()
			return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
		end)
		if not v144 then
			v145 = nil
		end
		v_u_5 = v145
	end
	local v146 = v_u_5
	local v_u_147 = p143.p
	if v146 and typeof(v_u_147) == "Vector3" then
		local v148 = v146.byN(p143.n) or v146.byKey("blue")
		local v149 = p143.dur
		local v150 = tonumber(v149) or 60
		local v151 = math.clamp(v150, 5, 120)
		local v152 = p143.name
		local v153
		if type(v152) == "string" then
			local v154 = p143.name
			v153 = string.sub(v154, 1, 24)
		else
			v153 = "SQUAD"
		end
		local v155 = v_u_105
		local v156 = string.upper(v153) .. "  BEACON"
		local v157 = p143.s
		v155(v148, v_u_147, v151, false, v156, (tonumber(v157)))
		if p143.s == v_u_2.LocalPlayer.UserId and (v_u_6 and (v_u_6.controllers and v_u_6.controllers.Comms)) then
			local function v160()
				-- upvalues: (ref) v_u_6, (copy) v_u_147
				local v158 = v_u_6.controllers.Comms
				local v159 = v158.pingAt
				if type(v159) == "function" then
					v158.pingAt("go", v_u_147)
				end
			end
			pcall(v160)
		end
	end
end
local function v_u_225(_) -- name: step
	-- upvalues: (copy) v_u_8, (copy) v_u_142, (copy) v_u_105, (copy) v_u_1, (copy) v_u_9, (ref) v_u_5, (copy) v_u_15, (ref) v_u_10
	local v162 = os.clock()
	local v163 = {}
	for _, v164 in v_u_8 do
		local v165 = (v162 - v164.t0) / v164.t
		if v165 >= 1 or not v164.body.Parent then
			table.insert(v163, v164)
		else
			local v166, v167 = v_u_142(v164.path, v165)
			v164.body.CFrame = CFrame.lookAt(v166, v166 + v167)
		end
	end
	for _, v168 in v163 do
		local v169 = table.find(v_u_8, v168)
		if v169 then
			table.remove(v_u_8, v169)
		end
		local v170 = v168.path[#v168.path]
		v168.model:Destroy()
		local v171 = v_u_105
		local v172 = v168.c
		local v173 = v168.data.dur
		local v174 = tonumber(v173) or 30
		local v175 = v168.data.bad == true
		local v176 = v168.data.s
		v171(v172, v170, v174, v175, nil, (tonumber(v176)))
	end
	local v177 = v_u_1.CurrentCamera
	local v178 = 0
	local v179 = {}
	local v180 = {}
	for _, v181 in v_u_9 do
		if not v181.light or (not v181.baseBright or v162 - v181.t0 >= v181.dur) then
			continue
		end
		local v182 = v181.baseBright
		local v183 = (v181.dur - (v162 - v181.t0)) / 1.2
		v178 = v178 + v182 * math.clamp(v183, 0, 1)
	end
	if not v_u_5 then
		local v184, v185 = pcall(function()
			return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
		end)
		if not v184 then
			v185 = nil
		end
		v_u_5 = v185
	end
	local v186 = v_u_5
	local v187
	if v186 then
		local v188 = v186.lightScale
		v187 = type(v188) ~= "function" and 1 or v186.lightScale(v178)
	else
		v187 = 1
	end
	for _, v189 in v_u_9 do
		local v190 = v162 - v189.t0
		if v189.dur <= v190 or not v189.root.Parent then
			table.insert(v179, v189)
		else
			local v191 = v189.dur - v190
			local v192 = v191 / 1.2
			local v193 = math.clamp(v192, 0, 1)
			if v189.light then
				local v194 = v189.light
				local v195 = (v189.baseBright - 0.8 + math.random() * 1.6) * v193 * v187
				v194.Brightness = math.max(0, v195)
				if v189.range0 then
					v189.light.Range = v189.range0 * (0.55 + 0.45 * v187)
				end
			end
			if v189.key == "white" and v189.ball then
				v189.ball.Transparency = 1 - v193
			end
			if v189.key == "yellow" and v189.ring <= v190 then
				v189.ring = v190 + 3
				local v196 = v_u_15()
				local v197 = v189.base.Position
				local v198 = CFrame.new(v197)
				local v199 = v189.color
				local v200 = Instance.new("Part")
				v200.Name = "Pulse"
				v200.Anchored = true
				v200.CanCollide = false
				v200.CanQuery = false
				v200.CanTouch = false
				v200.CastShadow = false
				v200.Size = Vector3.new(0.4, 0.3, 0.4)
				v200.CFrame = v198
				v200.Color = v199
				v200.Material = Enum.Material.Neon
				v200.Parent = v196
				v200.Shape = Enum.PartType.Cylinder
				local v201 = {
					["root"] = nil,
					["base"] = nil,
					["t0"] = nil,
					["dur"] = 1.1,
					["key"] = "ring",
					["ring"] = 0,
					["color"] = nil,
					["grow"] = nil,
					["root"] = v200,
					["base"] = v200,
					["t0"] = v162,
					["color"] = v189.color
				}
				if not v_u_5 then
					local v202, v203 = pcall(function()
						return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
					end)
					if not v202 then
						v203 = nil
					end
					v_u_5 = v203
				end
				local v204
				if v_u_5 then
					if not v_u_5 then
						local v205, v206 = pcall(function()
							return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("FlareAmmo")))
						end)
						if not v205 then
							v206 = nil
						end
						v_u_5 = v206
					end
					v204 = v_u_5.T.yellow.radius or 150
				else
					v204 = 150
				end
				v201.grow = v204 * 0.28
				table.insert(v180, v201)
			end
			if v189.key == "violet" and (v189.ring <= v190 and v191 > 2) then
				v189.ring = v190 + 4
				local v207 = v_u_15()
				local v208 = v189.base.Position
				local v209 = CFrame.new(v208)
				local v210 = v189.color
				local v211 = Instance.new("Part")
				v211.Name = "Pulse"
				v211.Anchored = true
				v211.CanCollide = false
				v211.CanQuery = false
				v211.CanTouch = false
				v211.CastShadow = false
				v211.Size = Vector3.new(0.4, 0.3, 0.4)
				v211.CFrame = v209
				v211.Color = v210
				v211.Material = Enum.Material.Neon
				v211.Parent = v207
				v211.Shape = Enum.PartType.Cylinder
				local v212 = {
					["root"] = nil,
					["base"] = nil,
					["t0"] = nil,
					["dur"] = 2.2,
					["key"] = "ring",
					["ring"] = 0,
					["color"] = nil,
					["grow"] = 14,
					["root"] = v211,
					["base"] = v211,
					["t0"] = v162,
					["color"] = v189.color
				}
				table.insert(v180, v212)
			end
			if v189.key == "ring" then
				local v213 = v190 / v189.dur
				local v214 = math.clamp(v213, 0, 1)
				local v215 = 1 + v214 * v189.grow * 2
				v189.base.Size = Vector3.new(0.25, v215, v215)
				v189.base.CFrame = CFrame.new(v189.base.Position) * CFrame.Angles(0, 0, 1.5707963267948966)
				v189.base.Transparency = v214 * 0.65 + 0.35
			end
			if not (v189.label and v177) then
				continue
			end
			local v216 = (v177.CFrame.Position - v189.base.Position).Magnitude
			local v217 = v189.label
			local v218 = v189.labelText
			local v219 = string.format
			local v220 = v216 * 0.28 + 0.5
			v217.Text = v218 .. v219("  %d m", (math.floor(v220)))
		end
	end
	for _, v221 in v179 do
		local v222 = table.find(v_u_9, v221)
		if v222 then
			table.remove(v_u_9, v222)
		end
		v221.root:Destroy()
	end
	for _, v223 in v180 do
		local v224 = v_u_9
		table.insert(v224, v223)
	end
	if #v_u_8 == 0 and (#v_u_9 == 0 and v_u_10) then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
end
function v4.init(p226) -- name: init
	-- upvalues: (ref) v_u_6
	v_u_6 = p226
end
function v4.onFx(p227) -- name: onFx
	-- upvalues: (copy) v_u_129, (copy) v_u_161, (ref) v_u_10, (copy) v_u_3, (copy) v_u_225
	if type(p227) == "table" then
		if p227.k == "flareshell" then
			v_u_129(p227)
		else
			if p227.k ~= "flarebeacon" then
				return
			end
			v_u_161(p227)
		end
		if not v_u_10 then
			v_u_10 = v_u_3.Heartbeat:Connect(v_u_225)
		end
	end
end
function v4.count() -- name: count
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	return #v_u_8 + #v_u_9
end
function v4.clear() -- name: clear
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (ref) v_u_11, (ref) v_u_10
	for _, v228 in v_u_8 do
		v228.model:Destroy()
	end
	for _, v229 in v_u_9 do
		v229.root:Destroy()
	end
	table.clear(v_u_8)
	table.clear(v_u_9)
	v_u_11 = nil
	if v_u_10 then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
end
return v4