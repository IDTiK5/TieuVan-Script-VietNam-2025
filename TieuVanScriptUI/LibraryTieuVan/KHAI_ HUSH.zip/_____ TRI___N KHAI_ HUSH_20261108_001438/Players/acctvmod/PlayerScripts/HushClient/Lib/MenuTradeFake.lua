-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTradeFake

local v_u_1 = game:GetService("Players")
local v2 = {}
local v_u_3 = {
	["normal"] = true,
	["empty"] = true,
	["many"] = true,
	["off"] = true,
	["korea"] = true,
	["slow"] = true,
	["swap"] = true,
	["noroom"] = true,
	["norooms"] = true,
	["nopartner"] = true
}
function v2.new(p_u_4) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_5 = {
		["scenarioName"] = "normal"
	}
	local v_u_6 = "TradeRules"
	local v7, v_u_8 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_6
		return p_u_4.shared[v_u_6]
	end)
	if not v7 then
		v_u_8 = nil
	end
	local v_u_9 = "Items"
	local v10, v_u_11 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_9
		return p_u_4.shared[v_u_9]
	end)
	if not v10 then
		v_u_11 = nil
	end
	local v_u_12 = "Skins"
	local v13, v_u_14 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_12
		return p_u_4.shared[v_u_12]
	end)
	if not v13 then
		v_u_14 = nil
	end
	local v_u_15 = p_u_4.notes
	local v_u_16 = v_u_1.LocalPlayer.UserId
	local v_u_17 = os.clock
	local v_u_18 = {
		["delay"] = 1.5,
		["tab"] = true,
		["noRoom"] = false,
		["partnerNoRoom"] = false,
		["silent"] = false,
		["swap"] = false,
		["many"] = false,
		["empty"] = false
	}
	local v_u_19 = 0
	local v_u_20 = nil
	local v_u_21 = nil
	local v_u_22 = {}
	local v_u_23 = {}
	local v_u_24 = 3
	local v_u_25 = 1200000
	local v_u_26 = true
	local v_u_27 = 6400000
	local v_u_28 = {}
	local v29 = p_u_4.scenario
	local v30 = (v29 == nil or not v_u_3[v29]) and "normal" or v29
	v_u_5.scenarioName = v30
	v_u_18.tab = v30 ~= "off" and v30 ~= "korea"
	v_u_18.empty = v30 == "empty"
	v_u_18.many = v30 == "many"
	v_u_18.noRoom = v30 == "noroom"
	v_u_18.partnerNoRoom = v30 == "norooms"
	v_u_18.silent = v30 == "nopartner"
	v_u_18.swap = v30 == "swap"
	v_u_18.delay = v30 == "slow" and 8 or 1.5
	local v_u_31 = {}
	local function v_u_40() -- name: buildPlayers
		-- upvalues: (ref) v_u_31, (copy) v_u_18
		v_u_31 = {}
		if not v_u_18.empty then
			for _, v32 in {
				{
					9001,
					"Fenris",
					"Fenris",
					true,
					true
				},
				{
					9002,
					"Ashgrove_77",
					"Ash",
					true,
					true
				},
				{
					9003,
					"Quillon_the_Long_Named_One",
					"Quillon",
					true,
					false
				},
				{
					9004,
					"MorrowRun",
					"Morrow",
					false,
					false
				},
				{
					9005,
					"Tamsin_k",
					"Tamsin",
					true,
					false
				},
				{
					9006,
					"ZaneSRS",
					"Zane",
					true,
					false
				}
			} do
				local v33 = v_u_31
				local v34 = {
					["u"] = v32[1],
					["n"] = v32[2],
					["d"] = v32[3],
					["ok"] = v32[4],
					["sq"] = v32[5]
				}
				table.insert(v33, v34)
			end
			if v_u_18.many then
				for v35 = 1, 54 do
					local v36 = v_u_31
					local v37 = {
						["u"] = nil,
						["n"] = nil,
						["d"] = nil,
						["ok"] = nil,
						["sq"] = false,
						["u"] = v35 + 9100,
						["n"] = ("Survivor_%02d"):format(v35),
						["d"] = ("Survivor %d"):format(v35),
						["ok"] = v35 % 7 ~= 0
					}
					table.insert(v36, v37)
				end
			end
			table.sort(v_u_31, function(p38, p39)
				if p38.sq == p39.sq then
					return string.lower(p38.n) < string.lower(p39.n)
				else
					return p38.sq
				end
			end)
		end
	end
	v_u_40()
	local v_u_41 = {}
	(function() -- name: buildStash
		-- upvalues: (ref) v_u_41, (copy) v_u_11
		v_u_41 = {}
		if v_u_11 ~= nil then
			local v_u_42 = 0
			local function v52(p43, p44, p45) -- name: add
				-- upvalues: (ref) v_u_11, (ref) v_u_42, (ref) v_u_41
				local v46 = 0
				for _, v47 in v_u_11.all() do
					if not p43(v47) then
						continue
					end
					v_u_42 = v_u_42 + 1
					v46 = v46 + 1
					local v48 = {
						["uid"] = nil,
						["id"] = nil,
						["x"] = 0,
						["y"] = 0,
						["r"] = false,
						["n"] = 1,
						["uid"] = ("ft%03d"):format(v_u_42),
						["id"] = v47.id
					}
					if p44 then
						for v49, v50 in p44 do
							v48[v49] = v50
						end
					end
					local v51 = v_u_41
					table.insert(v51, v48)
					if (p45 or 1) > v46 then
						continue
					end
					return
				end
			end
			v52(function(p53)
				local v54
				if p53.category == "firearm" and p53.rarity == 2 then
					v54 = not p53.gold
				else
					v54 = false
				end
				return v54
			end, {
				["dur"] = 0.82
			})
			v52(function(p55)
				local v56
				if p55.category == "firearm" and p55.rarity >= 3 then
					v56 = not p55.gold
				else
					v56 = false
				end
				return v56
			end, {
				["dur"] = 0.47,
				["mods"] = nil,
				["ammo"] = 12,
				["mods"] = {
					{
						["uid"] = "ftm1",
						["id"] = "x"
					}
				}
			})
			v52(function(p57)
				local v58
				if p57.category == "firearm" and p57.rarity >= 2 then
					v58 = not p57.gold
				else
					v58 = false
				end
				return v58
			end, {
				["dur"] = 0.9
			}, 3)
			v52(function(p59)
				local v60
				if p59.category == "ammo" then
					v60 = p59.stack >= 30
				else
					v60 = false
				end
				return v60
			end, {
				["n"] = 60,
				["fir"] = true
			})
			v52(function(p61)
				local v62
				if p61.category == "ammo" then
					v62 = p61.stack >= 30
				else
					v62 = false
				end
				return v62
			end, {
				["n"] = 24
			})
			v52(function(p63)
				return p63.category == "medical"
			end, {
				["n"] = 3,
				["fir"] = true
			}, 2)
			v52(function(p64)
				return p64.category == "food"
			end, {
				["n"] = 2
			}, 2)
			v52(function(p65)
				return p65.category == "material"
			end, {
				["n"] = 4
			}, 3)
			v52(function(p66)
				local v67
				if p66.category == "armor" then
					v67 = p66.equip == "armor"
				else
					v67 = false
				end
				return v67
			end, {
				["dur"] = 0.9
			})
			v52(function(p68)
				return p68.category == "quest"
			end)
			v52(function(p69)
				return p69.category == "throwable"
			end, {
				["n"] = 2
			})
			local v70 = v_u_41
			table.insert(v70, {
				["uid"] = "ftc1",
				["id"] = "skin_crate_field",
				["x"] = 0,
				["y"] = 0,
				["r"] = false,
				["n"] = 3
			})
			local v71 = v_u_41
			table.insert(v71, {
				["uid"] = "ftc2",
				["id"] = "skin_crate_tacet",
				["x"] = 0,
				["y"] = 0,
				["r"] = false,
				["n"] = 1
			})
		end
	end)()
	local v_u_72 = {}
	local function v_u_74(p73) -- name: hex
		return ("%016x"):format(p73 * 7919 + 78193085696)
	end
	local function v_u_86(p75) -- name: buildCopies
		-- upvalues: (ref) v_u_72, (copy) v_u_14, (copy) v_u_16, (copy) v_u_74
		v_u_72 = {}
		if v_u_14 ~= nil then
			local v76 = v_u_14.LIST
			local v77 = #v76
			local v78 = 6 + (p75 or 0)
			local v79 = 0
			for v80 = 1, math.min(v77, v78) do
				local v81 = v76[v80]
				for v82 = 1, v80 % 3 == 0 and 3 or (v80 % 2 == 0 and 2 or 1) do
					v79 = v79 + 1
					local v83 = {
						["uid"] = ("S%d-%s"):format(v82 == 2 and 8123 or v_u_16, v_u_74(v79)),
						["s"] = v81.id,
						["t"] = os.time() - v79 % 9 * 86400
					}
					local v84
					if v80 == 2 then
						v84 = v82 == 1
					else
						v84 = false
					end
					v83.eq = v84
					if v82 == 1 and v80 % 2 == 0 then
						v83.k = v80 * 31 + 40
					end
					if v80 == 4 and v82 == 2 then
						v83.k = 1284
					end
					local v85 = v_u_72
					table.insert(v85, v83)
				end
			end
		end
	end
	v_u_86()
	local function v_u_95(p87, p88, p89) -- name: lineOf
		-- upvalues: (ref) v_u_41, (copy) v_u_11, (ref) v_u_72
		if p87 == "item" then
			for _, v90 in v_u_41 do
				if v90.uid ~= p88 then
					continue
				end
				local v91 = v90.n or 1
				local v92 = p89 or v91
				if v92 < 1 or v91 < v92 then
					return nil, "That amount is not possible."
				elseif v90.mods == nil or #v90.mods <= 0 then
					if v90.ammo == nil or v90.ammo <= 0 then
						local v93 = v_u_11 and v_u_11.get(v90.id)
						if v93 then
							v93 = v_u_11.get(v90.id).category
						end
						if v93 == "quest" then
							return nil, "This item cannot be traded."
						else
							return {
								["kind"] = "item",
								["id"] = nil,
								["n"] = nil,
								["uid"] = nil,
								["dur"] = nil,
								["fir"] = nil,
								["id"] = v90.id,
								["n"] = v92,
								["uid"] = p88,
								["dur"] = v90.dur,
								["fir"] = v90.fir == true and true or nil
							}
						end
					else
						return nil, "Unload it first."
					end
				else
					return nil, "Remove the attachments first."
				end
			end
			return nil, "Item not found."
		else
			for _, v94 in v_u_72 do
				if v94.uid ~= p88 then
					continue
				end
				if v94.eq then
					return nil, "Take it off first."
				else
					return {
						["kind"] = "skin",
						["id"] = nil,
						["n"] = 1,
						["uid"] = nil,
						["s"] = nil,
						["k"] = nil,
						["id"] = v94.s,
						["uid"] = p88,
						["s"] = v94.s,
						["k"] = v94.k
					}
				end
			end
			return nil, "Item not found."
		end
	end
	local function v_u_101() -- name: limitsView
		-- upvalues: (ref) v_u_24, (ref) v_u_25, (copy) v_u_8
		local v96 = 86400 - os.time() % 86400
		local v97
		if v96 >= 3600 then
			local v98 = v96 / 3600
			v97 = ("%d h"):format((math.ceil(v98)))
		else
			local v99 = v96 / 60
			local v100 = math.ceil(v99)
			v97 = ("%d min"):format((math.max(1, v100)))
		end
		return {
			["tradesLeft"] = nil,
			["cashLeft"] = nil,
			["trades"] = nil,
			["cash"] = nil,
			["tradesMax"] = 20,
			["cashMax"] = 5000000,
			["resets"] = nil,
			["line"] = nil,
			["tradesLeft"] = 20 - v_u_24,
			["cashLeft"] = 5000000 - v_u_25,
			["trades"] = v_u_24,
			["cash"] = v_u_25,
			["resets"] = v_u_8.text("resets", v97),
			["line"] = v_u_8.text("limitsLine", v_u_24, 20, v_u_8.money(v_u_25), v_u_8.money(5000000))
		}
	end
	local function v_u_111() -- name: theirPool
		-- upvalues: (copy) v_u_11, (copy) v_u_14
		local v102 = {}
		if v_u_11 ~= nil then
			local v103 = {}
			for _, v104 in v_u_11.all() do
				if v104.category == "ammo" and #v103 < 1 then
					local v105 = v104.id
					table.insert(v103, v105)
				elseif v104.category == "medical" and #v103 < 2 then
					local v106 = v104.id
					table.insert(v103, v106)
				end
				if #v103 < 2 then
					continue
				end
			end
			for v107, v108 in v103 do
				local v109 = {
					["kind"] = "item",
					["id"] = nil,
					["n"] = nil,
					["uid"] = nil,
					["dur"] = nil,
					["fir"] = nil,
					["id"] = v108,
					["n"] = 5 * v107,
					["uid"] = "pt" .. v107,
					["fir"] = v107 == 1 and true or nil
				}
				table.insert(v102, v109)
			end
		end
		if v_u_14 ~= nil then
			local v110 = {
				["kind"] = "skin",
				["id"] = nil,
				["n"] = 1,
				["uid"] = nil,
				["s"] = nil,
				["k"] = 212,
				["id"] = v_u_14.LIST[3].id,
				["uid"] = "S9001-" .. ("%016x"):format(78193695459),
				["s"] = v_u_14.LIST[3].id
			}
			table.insert(v102, v110)
		end
		return v102
	end
	local function v_u_129() -- name: view
		-- upvalues: (ref) v_u_21, (ref) v_u_20, (copy) v_u_17, (copy) v_u_18, (copy) v_u_8
		if v_u_21 ~= nil and v_u_20 == nil then
			local v112 = {
				["phase"] = "ask",
				["to"] = nil,
				["name"] = nil,
				["left"] = nil,
				["to"] = v_u_21.to,
				["name"] = v_u_21.name
			}
			local v113 = v_u_21.expires - v_u_17()
			local v114 = math.ceil(v113)
			v112.left = math.max(0, v114)
			return v112
		end
		if v_u_20 == nil then
			return nil
		end
		local v115 = v_u_20
		local function v121(p116) -- name: rows
			local v117 = {}
			for v118, v119 in p116 do
				local v120 = {
					["line"] = v118,
					["kind"] = v119.kind,
					["id"] = v119.id,
					["n"] = v119.n,
					["uid"] = v119.uid,
					["dur"] = v119.dur,
					["fir"] = v119.fir,
					["s"] = v119.s,
					["k"] = v119.k
				}
				table.insert(v117, v120)
			end
			return v117
		end
		local v122 = v115.lockUntil - v_u_17()
		local v123 = math.ceil(v122)
		local v124 = math.max(0, v123)
		local v125 = true
		local v126 = nil
		if v_u_18.noRoom then
			v126 = v_u_8.TEXT.room
			v125 = false
		elseif v_u_18.partnerNoRoom then
			local _ = #v115.you.lines > 0
		end
		if v_u_18.partnerNoRoom and #v115.me.lines > 0 then
			v126 = v_u_8.TEXT.theyRoom
			v125 = false
		end
		local v127 = {
			["sid"] = v115.sid,
			["ver"] = v115.ver,
			["phase"] = v115.phase,
			["me"] = {
				["lines"] = v121(v115.me.lines),
				["cash"] = v115.me.cash,
				["ready"] = v115.me.ready,
				["confirm"] = v115.me.confirm
			},
			["you"] = {
				["id"] = v115.partner.u,
				["name"] = v115.partner.n,
				["lines"] = v121(v115.you.lines),
				["cash"] = v115.you.cash,
				["ready"] = v115.you.ready,
				["confirm"] = v115.you.confirm
			},
			["lockLeft"] = v124,
			["fee"] = {
				["pct"] = 5,
				["youGet"] = nil,
				["theyGet"] = nil,
				["youGet"] = v_u_8.net(v115.you.cash),
				["theyGet"] = v_u_8.net(v115.me.cash)
			},
			["booked"] = v115.phase == "go"
		}
		if v125 then
			v125 = v115.phase == "edit" and true or v115.phase == "review"
		end
		v127.canReady = v125
		v127.why = v126
		local v128
		if v115.phase == "review" and v124 == 0 then
			v128 = not v115.me.confirm
		else
			v128 = false
		end
		v127.canConfirm = v128
		return v127
	end
	local function v_u_137(p130) -- name: startSession
		-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_18, (copy) v_u_111, (ref) v_u_21, (copy) v_u_15, (copy) v_u_129
		v_u_19 = v_u_19 + 1
		local v131 = {
			["sid"] = nil,
			["ver"] = 1,
			["phase"] = "edit",
			["partner"] = nil,
			["lockUntil"] = 0,
			["me"] = nil,
			["you"] = nil,
			["swapped"] = false,
			["sid"] = "fk" .. v_u_19,
			["partner"] = p130,
			["me"] = {
				["lines"] = nil,
				["cash"] = 0,
				["ready"] = false,
				["confirm"] = false,
				["lines"] = {}
			},
			["you"] = {
				["lines"] = nil,
				["cash"] = 0,
				["ready"] = false,
				["confirm"] = false,
				["lines"] = {}
			}
		}
		v_u_20 = v131
		if not v_u_18.empty then
			local v132 = v_u_111()
			local v133 = #v132
			for v134 = 1, math.min(v133, 3) do
				local v135 = v_u_20.you.lines
				local v136 = v132[v134]
				table.insert(v135, v136)
			end
			v_u_20.you.cash = 200000
		end
		v_u_21 = nil
		if v_u_15 ~= nil then
			v_u_15.inject({
				["k"] = "upd",
				["s"] = nil,
				["s"] = v_u_129()
			})
		end
	end
	local function v_u_156(p138) -- name: finish
		-- upvalues: (ref) v_u_41, (ref) v_u_72, (ref) v_u_27, (copy) v_u_8, (ref) v_u_24, (ref) v_u_25, (copy) v_u_23, (ref) v_u_20, (copy) v_u_15
		for _, v139 in p138.me.lines do
			if v139.kind == "item" then
				for v140 = #v_u_41, 1, -1 do
					if v_u_41[v140].uid ~= v139.uid then
						continue
					end
					local v141 = (v_u_41[v140].n or 1) - v139.n
					if v141 <= 0 then
						table.remove(v_u_41, v140)
					else
						v_u_41[v140].n = v141
					end
				end
			else
				for v142 = #v_u_72, 1, -1 do
					if v_u_72[v142].uid ~= v139.uid then
						continue
					end
					table.remove(v_u_72, v142)
				end
			end
		end
		v_u_27 = v_u_27 - p138.me.cash + v_u_8.net(p138.you.cash)
		v_u_24 = v_u_24 + 1
		v_u_25 = v_u_25 + (p138.me.cash + p138.you.cash)
		local v143 = {
			["it"] = 0,
			["sk"] = 0,
			["c"] = nil,
			["c"] = p138.me.cash
		}
		local v144 = {
			["it"] = 0,
			["sk"] = 0,
			["c"] = nil,
			["c"] = v_u_8.net(p138.you.cash)
		}
		for _, v145 in p138.me.lines do
			if v145.kind == "skin" then
				v143.sk = v143.sk + 1
			else
				v143.it = v143.it + 1
			end
		end
		for _, v146 in p138.you.lines do
			if v146.kind == "skin" then
				v144.sk = v144.sk + 1
				local v147 = v_u_72
				local v148 = {
					["uid"] = v146.uid,
					["s"] = v146.s,
					["t"] = os.time(),
					["k"] = v146.k
				}
				table.insert(v147, v148)
			else
				v144.it = v144.it + 1
				local v149 = v_u_41
				local v150 = {
					["uid"] = nil,
					["id"] = nil,
					["x"] = 0,
					["y"] = 0,
					["r"] = false,
					["n"] = nil,
					["dur"] = nil,
					["uid"] = "gt" .. #v_u_41,
					["id"] = v146.id,
					["n"] = v146.n,
					["dur"] = v146.dur
				}
				table.insert(v149, v150)
			end
		end
		local v151 = v_u_23
		local v152 = {
			["t"] = os.time(),
			["id"] = "t" .. p138.sid,
			["w"] = p138.partner.u,
			["f"] = v_u_8.fee(p138.me.cash),
			["gi"] = v143,
			["ge"] = v144
		}
		table.insert(v151, 1, v152)
		v_u_20 = nil
		if v_u_15 ~= nil then
			local v153 = v_u_15.inject
			local v154 = {
				["k"] = "done",
				["beleg"] = nil,
				["text"] = nil
			}
			local v155 = {
				["tid"] = nil,
				["t"] = nil,
				["w"] = nil,
				["got"] = nil,
				["fee"] = nil,
				["overflow"] = 0,
				["tid"] = p138.sid,
				["t"] = os.time(),
				["w"] = p138.partner.u,
				["got"] = {
					["items"] = v144.it,
					["finishes"] = v144.sk,
					["cash"] = v144.c
				},
				["fee"] = v_u_8.fee(p138.me.cash)
			}
			v154.beleg = v155
			v154.text = v_u_8.TEXT.done
			v153(v154)
		end
	end
	local function v_u_172() -- name: botStep
		-- upvalues: (ref) v_u_20, (copy) v_u_18, (copy) v_u_17, (copy) v_u_15, (copy) v_u_129, (copy) v_u_172, (ref) v_u_26, (copy) v_u_156
		local v_u_157 = v_u_20
		if v_u_157 == nil or v_u_18.silent then
			return
		else
			local v_u_158 = v_u_157.ver
			if v_u_157.phase == "edit" and (v_u_157.me.ready and not v_u_157.you.ready) then
				local v159 = v_u_18.delay
				local function v_u_168()
					-- upvalues: (ref) v_u_20, (copy) v_u_157, (copy) v_u_158, (ref) v_u_18, (ref) v_u_17, (ref) v_u_15, (ref) v_u_129, (ref) v_u_172
					if v_u_20 == v_u_157 and (v_u_157.ver == v_u_158 and (v_u_157.phase == "edit" and (v_u_157.me.ready and not v_u_157.you.ready))) then
						if v_u_18.swap and not v_u_157.swapped then
							v_u_157.swapped = true
							local v160 = v_u_157
							v160.ver = v160.ver + 1
							local v161 = v160.me
							local v162 = v160.me
							local v163 = v160.you
							local v164 = v160.you
							v161.ready = false
							v162.confirm = false
							v163.ready = false
							v164.confirm = false
							v160.phase = "edit"
							v160.lockUntil = v_u_17() + 3
							v_u_157.you.cash = 20000
							if #v_u_157.you.lines > 0 then
								table.remove(v_u_157.you.lines)
							end
							if v_u_15 ~= nil then
								v_u_15.inject({
									["k"] = "upd",
									["s"] = nil,
									["s"] = v_u_129()
								})
							end
							return
						end
						v_u_157.you.ready = true
						v_u_157.phase = "review"
						local v165 = v_u_157
						local v166 = v_u_157.lockUntil
						local v167 = v_u_17() + 2
						v165.lockUntil = math.max(v166, v167)
						if v_u_15 ~= nil then
							v_u_15.inject({
								["k"] = "upd",
								["s"] = nil,
								["s"] = v_u_129()
							})
						end
						v_u_172()
					end
				end
				task.delay(v159, function()
					-- upvalues: (ref) v_u_26, (copy) v_u_168
					if v_u_26 then
						v_u_168()
					end
				end)
			elseif v_u_157.phase == "review" and not v_u_157.you.confirm then
				local v169 = v_u_18.delay + 1
				local function v_u_171()
					-- upvalues: (ref) v_u_20, (copy) v_u_157, (copy) v_u_158, (ref) v_u_15, (ref) v_u_129, (ref) v_u_156, (ref) v_u_26
					if v_u_20 == v_u_157 and (v_u_157.ver == v_u_158 and (v_u_157.phase == "review" and not v_u_157.you.confirm)) then
						v_u_157.you.confirm = true
						if v_u_157.me.confirm then
							v_u_157.phase = "go"
							if v_u_15 ~= nil then
								v_u_15.inject({
									["k"] = "upd",
									["s"] = nil,
									["s"] = v_u_129()
								})
							end
							local function v_u_170()
								-- upvalues: (ref) v_u_20, (ref) v_u_157, (ref) v_u_156
								if v_u_20 == v_u_157 then
									v_u_156(v_u_157)
								end
							end
							task.delay(3.5, function()
								-- upvalues: (ref) v_u_26, (copy) v_u_170
								if v_u_26 then
									v_u_170()
								end
							end)
							return
						end
						if v_u_15 ~= nil then
							v_u_15.inject({
								["k"] = "upd",
								["s"] = nil,
								["s"] = v_u_129()
							})
						end
					end
				end
				task.delay(v169, function()
					-- upvalues: (ref) v_u_26, (copy) v_u_171
					if v_u_26 then
						v_u_171()
					end
				end)
			end
		end
	end
	function v_u_5.stash(_) -- name: stash
		-- upvalues: (ref) v_u_41
		return v_u_41
	end
	function v_u_5.cash(_) -- name: cash
		-- upvalues: (ref) v_u_27
		return v_u_27
	end
	function v_u_5.get(_, p173, p174) -- name: get
		-- upvalues: (copy) v_u_18, (copy) v_u_23, (copy) v_u_101, (copy) v_u_22, (copy) v_u_17, (copy) v_u_129, (copy) v_u_8, (ref) v_u_31, (ref) v_u_20, (ref) v_u_72, (copy) v_u_14
		if p173 == "tradeState" then
			local v175 = {
				["tab"] = nil,
				["ok"] = nil,
				["phase"] = "none",
				["fee"] = 5,
				["lines"] = 16,
				["recent"] = nil,
				["limits"] = nil,
				["reqs"] = nil,
				["setting"] = "everyone",
				["tab"] = v_u_18.tab,
				["ok"] = v_u_18.tab,
				["recent"] = v_u_23,
				["limits"] = v_u_101(),
				["reqs"] = {}
			}
			if not v_u_18.tab then
				v175.ok = false
				return v175
			end
			for _, v176 in v_u_22 do
				local v177 = v175.reqs
				local v178 = {
					["from"] = v176.from,
					["name"] = v176.name
				}
				local v179 = v176.expires - v_u_17()
				local v180 = math.ceil(v179)
				v178.left = math.max(0, v180)
				table.insert(v177, v178)
			end
			local v181 = v_u_129()
			if v181 ~= nil then
				v175.phase = v181.phase
				v175.sid = v181.sid
				v175.s = v181
				if v181.phase == "go" then
					v175.finishing = v_u_8.TEXT.completing
				end
			end
			return v175
		end
		if p173 == "tradePlayers" then
			if not v_u_18.tab then
				return {
					["rows"] = {},
					["why"] = v_u_8.TEXT.off
				}
			end
			local v182 = {}
			for _, v183 in v_u_31 do
				local v184 = {
					["u"] = v183.u,
					["n"] = v183.n,
					["d"] = v183.d
				}
				local v185 = v183.ok
				if v185 then
					v185 = v_u_20 == nil
				end
				v184.ok = v185
				v184.sq = v183.sq
				table.insert(v182, v184)
			end
			return {
				["rows"] = v182
			}
		end
		if p173 == "crates" then
			local v186 = {}
			local v187 = {}
			for _, v188 in v_u_72 do
				local v189 = v186[v188.s]
				if v189 == nil then
					v189 = {
						["n"] = 0,
						["tally"] = nil,
						["tally"] = {}
					}
					v186[v188.s] = v189
				end
				v189.n = v189.n + 1
				if v188.k ~= nil then
					local v190 = v189.tally
					local v191 = {
						["uid"] = v188.uid,
						["k"] = v188.k
					}
					table.insert(v190, v191)
				end
				if not v188.eq or (v_u_14 == nil or not v_u_14.get(v188.s)) then
					continue
				end
				v187[v_u_14.get(v188.s).weapon] = v188.uid
			end
			for _, v192 in v186 do
				table.sort(v192.tally, function(p193, p194)
					return p193.k > p194.k
				end)
				local v195
				if v192.tally[1] then
					v195 = v192.tally[1].k
				else
					v195 = nil
				end
				v192.best = v195
			end
			return {
				["items"] = nil,
				["equippedUid"] = nil,
				["uid"] = true,
				["tally"] = true,
				["items"] = v186,
				["equippedUid"] = v187
			}
		end
		if p173 ~= "skinCopies" then
			return {
				["error"] = "unknown"
			}
		end
		local v196 = {}
		for _, v197 in v_u_72 do
			if v197.s ~= p174.skin then
				continue
			end
			local v198 = {
				["uid"] = v197.uid,
				["t"] = v197.t,
				["k"] = v197.k,
				["eq"] = v197.eq == true
			}
			table.insert(v196, v198)
		end
		table.sort(v196, function(p199, p200)
			return (p199.k or -1) > (p200.k or -1)
		end)
		local v201 = p174.offset
		local v202 = tonumber(v201) or 0
		local v203 = v202 + 1
		local v204 = #v196
		local v205 = v202 + 25
		local v206 = {}
		for v207 = v203, math.min(v204, v205) do
			local v208 = v196[v207]
			table.insert(v206, v208)
		end
		return {
			["rows"] = v206,
			["total"] = #v196
		}
	end
	function v_u_5.op(_, p209, p210) -- name: op
		-- upvalues: (copy) v_u_18, (copy) v_u_8, (ref) v_u_31, (ref) v_u_20, (ref) v_u_21, (copy) v_u_17, (copy) v_u_15, (copy) v_u_129, (copy) v_u_137, (ref) v_u_26, (copy) v_u_22, (copy) v_u_28, (copy) v_u_95, (ref) v_u_27, (copy) v_u_172, (copy) v_u_156
		if not v_u_18.tab then
			return false, v_u_8.TEXT.off, nil
		end
		if p209 == "tradeSeen" then
			return true
		end
		if p209 == "tradeAsk" then
			local v211 = p210.to
			for _, v_u_213 in v_u_31 do
				if v_u_213.u ~= v211 then
					continue
				end
			end
			local v_u_213 = nil
			if v_u_213 == nil then
				return false, v_u_8.TEXT.bad
			end
			if not v_u_213.ok then
				return false, v_u_8.TEXT.notYet
			end
			if v_u_20 ~= nil or v_u_21 ~= nil then
				return false, v_u_8.TEXT.askOpen
			end
			v_u_21 = {
				["to"] = v_u_213.u,
				["name"] = v_u_213.n,
				["expires"] = v_u_17() + 30
			}
			if v_u_15 ~= nil then
				v_u_15.inject({
					["k"] = "upd",
					["s"] = nil,
					["s"] = v_u_129()
				})
			end
			local v_u_214 = v_u_21
			if not v_u_18.silent then
				local v215 = v_u_18.delay
				local function v_u_216()
					-- upvalues: (ref) v_u_21, (copy) v_u_214, (ref) v_u_20, (ref) v_u_137, (copy) v_u_213
					if v_u_21 == v_u_214 and v_u_20 == nil then
						v_u_137(v_u_213)
					end
				end
				task.delay(v215, function()
					-- upvalues: (ref) v_u_26, (copy) v_u_216
					if v_u_26 then
						v_u_216()
					end
				end)
			end
			local function v_u_217()
				-- upvalues: (ref) v_u_21, (copy) v_u_214, (ref) v_u_15, (ref) v_u_8
				if v_u_21 == v_u_214 then
					v_u_21 = nil
					if v_u_15 then
						v_u_15.inject({
							["k"] = "end",
							["why"] = "expired",
							["text"] = nil,
							["sid"] = false,
							["text"] = v_u_8.TEXT.expired
						})
					end
				end
			end
			task.delay(30, function()
				-- upvalues: (ref) v_u_26, (copy) v_u_217
				if v_u_26 then
					v_u_217()
				end
			end)
			return true
		end
		if p209 == "tradeAnswer" then
			for v218, v219 in v_u_22 do
				if v219.from ~= p210.from then
					continue
				end
				table.remove(v_u_22, v218)
				if p210.accept == true then
					local v220 = p210.from
					for _, v222 in v_u_31 do
						if v222.u ~= v220 then
							continue
						end
					end
					local v222 = nil
					v_u_137(v222 or {
						["u"] = nil,
						["n"] = nil,
						["d"] = nil,
						["ok"] = true,
						["sq"] = false,
						["u"] = p210.from,
						["n"] = v219.name,
						["d"] = v219.name
					})
				elseif p210.block == true then
					v_u_28[p210.from] = true
				end
				return true
			end
			return false, v_u_8.TEXT.expired
		end
		local v_u_223 = v_u_20
		if p209 == "tradeCancel" then
			if v_u_21 ~= nil and v_u_223 == nil then
				v_u_21 = nil
				if v_u_15 then
					v_u_15.inject({
						["k"] = "end",
						["why"] = "cancelled",
						["text"] = nil,
						["sid"] = false,
						["text"] = v_u_8.TEXT.ended
					})
				end
				return true
			end
			if v_u_223 == nil then
				return false, v_u_8.TEXT.notInTrade
			end
			if v_u_223.phase == "go" then
				return false, v_u_8.TEXT.beingCompleted
			end
			v_u_20 = nil
			if v_u_15 then
				v_u_15.inject({
					["k"] = "end",
					["why"] = "cancelled",
					["text"] = nil,
					["sid"] = nil,
					["text"] = v_u_8.TEXT.ended,
					["sid"] = v_u_223.sid
				})
			end
			return true
		end
		if v_u_223 == nil then
			return false, v_u_8.TEXT.notInTrade
		end
		if p209 ~= "tradeAdd" then
			if p209 == "tradeRemove" then
				if v_u_223.me.lines[p210.line] == nil then
					return false, v_u_8.TEXT.bad
				end
				table.remove(v_u_223.me.lines, p210.line)
				v_u_223.ver = v_u_223.ver + 1
				local v224 = v_u_223.me
				local v225 = v_u_223.me
				local v226 = v_u_223.you
				local v227 = v_u_223.you
				v224.ready = false
				v225.confirm = false
				v226.ready = false
				v227.confirm = false
				v_u_223.phase = "edit"
				v_u_223.lockUntil = v_u_17() + 3
				if v_u_15 ~= nil then
					v_u_15.inject({
						["k"] = "upd",
						["s"] = nil,
						["s"] = v_u_129()
					})
				end
				return true
			end
			if p209 ~= "tradeCash" then
				if p209 == "tradeReady" then
					if p210.ver ~= v_u_223.ver then
						return false, v_u_8.TEXT.stale
					end
					if p210.on == true then
						if v_u_18.noRoom or v_u_18.partnerNoRoom and #v_u_223.me.lines > 0 then
							local v228 = false
							if v_u_18.noRoom then
								return v228, v_u_8.TEXT.room
							else
								return v228, v_u_8.TEXT.theyRoom
							end
						end
						v_u_223.me.ready = true
						if v_u_223.you.ready then
							v_u_223.phase = "review"
							local v229 = v_u_223.lockUntil
							local v230 = v_u_17() + 2
							v_u_223.lockUntil = math.max(v229, v230)
						end
					else
						v_u_223.me.ready = false
						v_u_223.phase = "edit"
						local v231 = v_u_223.me
						local v232 = v_u_223.you
						v231.confirm = false
						v232.confirm = false
					end
					if v_u_15 ~= nil then
						v_u_15.inject({
							["k"] = "upd",
							["s"] = nil,
							["s"] = v_u_129()
						})
					end
					v_u_172()
					return true
				end
				if p209 ~= "tradeConfirm" then
					return false, v_u_8.TEXT.bad
				end
				if v_u_223.phase ~= "review" then
					return false, v_u_8.TEXT.notReady
				end
				if p210.ver ~= v_u_223.ver then
					return false, v_u_8.TEXT.stale
				end
				if v_u_17() < v_u_223.lockUntil then
					return false, v_u_8.TEXT.locked
				end
				v_u_223.me.confirm = true
				if v_u_223.you.confirm then
					v_u_223.phase = "go"
					if v_u_15 ~= nil then
						v_u_15.inject({
							["k"] = "upd",
							["s"] = nil,
							["s"] = v_u_129()
						})
					end
					local function v_u_233()
						-- upvalues: (ref) v_u_20, (copy) v_u_223, (ref) v_u_156
						if v_u_20 == v_u_223 then
							v_u_156(v_u_223)
						end
					end
					task.delay(3.5, function()
						-- upvalues: (ref) v_u_26, (copy) v_u_233
						if v_u_26 then
							v_u_233()
						end
					end)
				else
					if v_u_15 ~= nil then
						v_u_15.inject({
							["k"] = "upd",
							["s"] = nil,
							["s"] = v_u_129()
						})
					end
					v_u_172()
				end
				return true
			end
			if v_u_27 < p210.n then
				return false, v_u_8.TEXT.cashShort
			end
			v_u_223.me.cash = p210.n
			v_u_223.ver = v_u_223.ver + 1
			local v234 = v_u_223.me
			local v235 = v_u_223.me
			local v236 = v_u_223.you
			local v237 = v_u_223.you
			v234.ready = false
			v235.confirm = false
			v236.ready = false
			v237.confirm = false
			v_u_223.phase = "edit"
			v_u_223.lockUntil = v_u_17() + 3
			if v_u_15 ~= nil then
				v_u_15.inject({
					["k"] = "upd",
					["s"] = nil,
					["s"] = v_u_129()
				})
			end
			return true
		end
		if #v_u_223.me.lines >= 16 then
			return false, v_u_8.TEXT.tooMany
		end
		for _, v238 in v_u_223.me.lines do
			if v238.uid ~= p210.uid then
				continue
			end
			return false, v_u_8.TEXT.sameLine
		end
		local v239, v240 = v_u_95(p210.kind, p210.uid, p210.n)
		if v239 == nil then
			return false, v240
		end
		local v241 = v_u_223.me.lines
		table.insert(v241, v239)
		v_u_223.ver = v_u_223.ver + 1
		local v242 = v_u_223.me
		local v243 = v_u_223.me
		local v244 = v_u_223.you
		local v245 = v_u_223.you
		v242.ready = false
		v243.confirm = false
		v244.ready = false
		v245.confirm = false
		v_u_223.phase = "edit"
		v_u_223.lockUntil = v_u_17() + 3
		if v_u_15 ~= nil then
			v_u_15.inject({
				["k"] = "upd",
				["s"] = nil,
				["s"] = v_u_129()
			})
		end
		return true
	end
	function v_u_5.command(_, p246) -- name: command
		-- upvalues: (ref) v_u_31, (copy) v_u_22, (copy) v_u_17, (copy) v_u_15, (ref) v_u_20, (copy) v_u_129, (copy) v_u_8, (ref) v_u_24, (copy) v_u_86, (ref) v_u_72, (ref) v_u_41, (copy) v_u_11, (ref) v_u_3, (copy) v_u_5, (copy) v_u_18, (copy) v_u_40
		local v247 = p246[1] or ""
		if v247 == "req" then
			local v248 = p246[2] or "Fenris"
			local v249 = nil
			for _, v250 in v_u_31 do
				if string.lower(v250.n) ~= string.lower(v248) then
					continue
				end
				v249 = v250
			end
			local v251 = not v249 and 9001 or v249.u
			local v252 = v_u_22
			local v253 = {
				["from"] = v251
			}
			local v254
			if v249 then
				v254 = v249.n
			else
				v254 = v248
			end
			v253.name = v254
			v253.expires = v_u_17() + 30
			table.insert(v252, v253)
			if v_u_15 then
				local v255 = v_u_15.inject
				local v256 = {
					["k"] = "req",
					["from"] = nil,
					["name"] = nil,
					["left"] = 30,
					["from"] = v251
				}
				local v257
				if v249 then
					v257 = v249.n
				else
					v257 = v248
				end
				v256.name = v257
				v255(v256)
			end
			return "request from " .. v248
		end
		if v247 == "ready" and v_u_20 then
			v_u_20.you.ready = true
			if v_u_20.me.ready then
				v_u_20.phase = "review"
				local v258 = v_u_20
				local v259 = v_u_20.lockUntil
				local v260 = v_u_17() + 2
				v258.lockUntil = math.max(v259, v260)
			end
			if v_u_15 ~= nil then
				v_u_15.inject({
					["k"] = "upd",
					["s"] = nil,
					["s"] = v_u_129()
				})
			end
			return "partner ready"
		end
		if v247 == "edit" and v_u_20 then
			local v261 = v_u_20
			v261.ver = v261.ver + 1
			local v262 = v261.me
			local v263 = v261.me
			local v264 = v261.you
			local v265 = v261.you
			v262.ready = false
			v263.confirm = false
			v264.ready = false
			v265.confirm = false
			v261.phase = "edit"
			v261.lockUntil = v_u_17() + 3
			v_u_20.you.cash = v_u_20.you.cash == 200000 and 950000 or 200000
			if v_u_15 ~= nil then
				v_u_15.inject({
					["k"] = "upd",
					["s"] = nil,
					["s"] = v_u_129()
				})
			end
			return "partner changed the offer"
		end
		if v247 == "confirm" and v_u_20 then
			v_u_20.you.confirm = true
			if v_u_15 ~= nil then
				v_u_15.inject({
					["k"] = "upd",
					["s"] = nil,
					["s"] = v_u_129()
				})
			end
			return "partner confirmed"
		end
		if v247 == "leave" and v_u_20 then
			local v266 = v_u_20
			v_u_20 = nil
			if v_u_15 then
				v_u_15.inject({
					["k"] = "end",
					["why"] = "left",
					["text"] = nil,
					["sid"] = nil,
					["text"] = v_u_8.text("left", v266.partner.n),
					["sid"] = v266.sid
				})
			end
			return "partner left"
		end
		if v247 == "limits" then
			local v267 = p246[2]
			v_u_24 = tonumber(v267) or v_u_24
			return "limits"
		end
		if v247 == "skins" then
			local v268 = v_u_86
			local v269 = p246[2]
			v268((tonumber(v269)))
			return "finishes " .. #v_u_72
		end
		if v247 ~= "bigstash" then
			if v247 == "stash" then
				local v270 = {}
				for _, v271 in v_u_41 do
					local v272 = v271.uid
					local v273 = v271.id
					table.insert(v270, ("%s=%s"):format(v272, v273))
				end
				return table.concat(v270, " ")
			end
			if v247 == "copies" then
				local v274 = {}
				for _, v275 in v_u_72 do
					local v276 = v275.uid
					local v277 = v275.s
					local v278 = not v275.k and "" or " k" .. v275.k
					local v279 = v275.eq and " eq" or ""
					table.insert(v274, ("%s=%s%s%s"):format(v276, v277, v278, v279))
				end
				return table.concat(v274, " ")
			end
			if v247 ~= "scenario" then
				return "commands: req <name>, ready, edit, confirm, leave, limits <n>, skins <extra>, bigstash <n>, scenario <name>"
			end
			local v280 = p246[2]
			local v281 = (v280 == nil or not v_u_3[v280]) and "normal" or v280
			v_u_5.scenarioName = v281
			v_u_18.tab = v281 ~= "off" and v281 ~= "korea"
			v_u_18.empty = v281 == "empty"
			v_u_18.many = v281 == "many"
			v_u_18.noRoom = v281 == "noroom"
			v_u_18.partnerNoRoom = v281 == "norooms"
			v_u_18.silent = v281 == "nopartner"
			v_u_18.swap = v281 == "swap"
			v_u_18.delay = v281 == "slow" and 8 or 1.5
			v_u_40()
			if v_u_15 then
				v_u_15.inject({
					["k"] = "end",
					["why"] = "reset",
					["text"] = "",
					["sid"] = false
				})
			end
			return "scenario " .. v_u_5.scenarioName
		end
		local v282 = p246[2]
		local v283 = tonumber(v282) or 60
		local v284 = math.clamp(v283, 1, 400)
		local v285 = {}
		for _, v286 in v_u_41 do
			v285[v286.id] = true
		end
		local v287 = 0
		if v_u_11 ~= nil then
			for _, v288 in v_u_11.all() do
				if v284 <= v287 then
					break
				end
				local v289 = v288.id
				if type(v289) ~= "string" or v285[v288.id] then
					continue
				end
				v287 = v287 + 1
				local v290 = v_u_41
				local v291 = {
					["uid"] = nil,
					["id"] = nil,
					["x"] = 0,
					["y"] = 0,
					["r"] = false,
					["n"] = 1,
					["uid"] = ("fb%03d"):format(v287),
					["id"] = v288.id
				}
				table.insert(v290, v291)
			end
		end
		return "stash " .. #v_u_41
	end
	function v_u_5.destroy(_) -- name: destroy
		-- upvalues: (ref) v_u_26
		v_u_26 = false
	end
	return v_u_5
end
return v2