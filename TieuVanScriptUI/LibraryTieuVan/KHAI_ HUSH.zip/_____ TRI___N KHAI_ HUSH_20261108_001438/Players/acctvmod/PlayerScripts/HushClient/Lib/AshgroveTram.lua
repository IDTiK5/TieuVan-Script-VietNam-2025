-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AshgroveTram

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = v_u_4:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Extracts"))
local v_u_7 = require(v5:WaitForChild("AshgroveTramPlan"))
local v_u_23 = {
	["at"] = function(p8, p9, p10, p11, p12) -- name: at
		local v13 = p8 / math.max(p9, 0.1)
		local v14 = p11 % ((v13 + p10) * 2)
		local v15
		if v14 < p10 then
			v15 = 0
		elseif v14 < p10 + v13 then
			v15 = (v14 - p10) * p9
		elseif v14 < p10 * 2 + v13 then
			v15 = p8
		else
			v15 = p8 - (v14 - p10 * 2 - v13) * p9
		end
		local v16 = math.clamp(v15, 0, p8)
		if p12 then
			return p8 - v16
		else
			return v16
		end
	end,
	["positions"] = function(p17, p18, p19, p20, p21) -- name: positions
		-- upvalues: (copy) v_u_23
		local v22 = v_u_23.at(p17, p19, p20, p21, false)
		return v22, (1 - (p17 <= 0 and 0 or v22 / p17)) * p18
	end
}
local v_u_24 = false
local v_u_25 = nil
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = nil
local v_u_29 = nil
local function v_u_33(p30) -- name: loadFolder
	-- upvalues: (ref) v_u_28, (copy) v_u_6, (copy) v_u_26
	v_u_28 = p30
	for _, v31 in { "A", "B" } do
		local v32 = v_u_6.decodePath((p30:GetAttribute("TramPath" .. v31)))
		v_u_26[v31] = {
			["pts"] = v32,
			["len"] = v_u_6.pathLength(v32)
		}
	end
end
local function v_u_65() -- name: step
	-- upvalues: (ref) v_u_28, (copy) v_u_1, (copy) v_u_4, (ref) v_u_29, (copy) v_u_27, (copy) v_u_26, (copy) v_u_23, (copy) v_u_7
	local v34 = v_u_28
	if v34 and v34.Parent then
		local v35 = v34:GetAttribute("TramSag") or 0.012
		local v36 = v34:GetAttribute("TramSpeed") or 12
		local v37 = v34:GetAttribute("TramDwell") or 20
		local v38 = v34:GetAttribute("TramHang") or 7.3
		local v39 = v34:GetAttribute("TramFlatSpan") or 0
		local v40 = v34:GetAttribute("TramBlend") or 0
		local v41 = v34:GetAttribute("TramCabYaw") or 0
		local v42 = math.rad(v41)
		local v43 = v_u_1.now()
		local v44 = v_u_4:FindFirstChild("HushRuntime")
		if v44 then
			v44 = v44:FindFirstChild("Raid")
		end
		if v44 then
			v44 = v44:GetAttribute("AshTramCut")
		end
		if type(v44) == "number" then
			v_u_29 = v_u_29 or v44
			v43 = v_u_29
		else
			v_u_29 = nil
		end
		for v45 in v_u_27 do
			if not v45.Parent then
				continue
			end
			local v46 = v45:GetAttribute("TramLine")
			local v47
			if type(v46) == "string" then
				v47 = v_u_26[v46]
			else
				v47 = nil
			end
			if not v47 or #v47.pts < 2 then
				continue
			end
			local v48 = v_u_26.A
			local v49 = v_u_26.B
			local v50 = v_u_23.positions
			local v51
			if v48 then
				v51 = v48.len
			else
				v51 = v47.len
			end
			local v52
			if v49 then
				v52 = v49.len
			else
				v52 = v47.len
			end
			local v54, v54 = v50(v51, v52, v36, v37, v43)
			local _ = v46 == "B"
			local v55, _ = v_u_7.pointAt(v47.pts, v54, v35, v39)
			local v56 = v_u_7.headingAt(v47.pts, v54, v40)
			local v57 = CFrame.lookAt
			local v58 = v55.X
			local v59 = v55.Y - v38
			local v60 = v55.Z
			local v61 = Vector3.new(v58, v59, v60)
			local v62 = v55.X + v56.X
			local v63 = v55.Y - v38
			local v64 = v55.Z + v56.Z
			v45:PivotTo(v57(v61, (Vector3.new(v62, v63, v64))) * CFrame.Angles(0, v42, 0))
		end
	end
end
function v_u_23.start() -- name: start
	-- upvalues: (ref) v_u_24, (copy) v_u_2, (copy) v_u_33, (copy) v_u_27, (ref) v_u_25, (copy) v_u_3, (copy) v_u_65
	if not v_u_24 then
		v_u_24 = true
		local v66 = script.Parent:FindFirstChild("AshgroveEndFx")
		if v66 and v66:IsA("ModuleScript") then
			local v67 = require
			local v68, v69 = pcall(v67, v66)
			if v68 and type(v69) == "table" then
				local v70 = v69.start
				if type(v70) == "function" then
					local v71 = v69.start
					pcall(v71)
				end
			end
		end
		v_u_2:GetInstanceAddedSignal("AshTram"):Connect(v_u_33)
		for _, v72 in v_u_2:GetTagged("AshTram") do
			v_u_33(v72)
		end
		v_u_2:GetInstanceAddedSignal("AshTramCab"):Connect(function(p73)
			-- upvalues: (ref) v_u_27
			if p73:IsA("Model") then
				v_u_27[p73] = true
			end
		end)
		v_u_2:GetInstanceRemovedSignal("AshTramCab"):Connect(function(p74)
			-- upvalues: (ref) v_u_27
			v_u_27[p74] = nil
		end)
		for _, v75 in v_u_2:GetTagged("AshTramCab") do
			if not v75:IsA("Model") then
				continue
			end
			v_u_27[v75] = true
		end
		v_u_25 = v_u_3.Heartbeat:Connect(v_u_65)
	end
end
function v_u_23.stop() -- name: stop
	-- upvalues: (ref) v_u_25, (ref) v_u_24, (copy) v_u_27, (ref) v_u_28
	if v_u_25 then
		v_u_25:Disconnect()
		v_u_25 = nil
	end
	v_u_24 = false
	table.clear(v_u_27)
	v_u_28 = nil
end
return v_u_23