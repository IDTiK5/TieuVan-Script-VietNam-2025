-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewTrail

local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = {}
local v_u_3 = {}
function v2.use(p4) -- name: use
	-- upvalues: (ref) v_u_3
	v_u_3 = type(p4) ~= "table" and {} or p4
end
local v_u_5 = nil
local v_u_6 = Color3.fromRGB(70, 214, 255)
local v_u_7 = false
local v_u_8 = true
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = 0
local v_u_15 = 0
local function v_u_24(p16) -- name: maintain
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_1, (ref) v_u_9, (ref) v_u_15, (ref) v_u_8, (copy) v_u_12, (copy) v_u_13
	local v17
	if v_u_3.rules == nil then
		if v_u_5 == nil then
			v_u_5 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewTrailRules"))
		end
		v17 = v_u_5
	else
		v17 = v_u_3.rules
	end
	v17.expire(v_u_9, p16)
	v_u_15 = v_u_9.count
	if not v_u_8 then
		for v18 = 1, #v_u_12 do
			if v_u_13[v18] == -1 then
				continue
			end
			v_u_12[v18].Visible = false
			v_u_13[v18] = -1
		end
		return
	end
	for v19 = 1, v_u_9.cap do
		if v17.isLive(v_u_9, v19) then
			local v20 = v_u_12[v19]
			local v21 = v17.fade(v17.age(v_u_9, v19, p16), v_u_9.seconds)
			local v22 = v_u_13[v19]
			if v22 == -1 then
				v20.Transparency = v21
				v_u_13[v19] = v21
				if v20.Visible then
					continue
				end
				v20.Visible = true
			else
				local v23 = v21 - v22
				if math.abs(v23) > 0.01 then
					v20.Transparency = v21
					v_u_13[v19] = v21
					if v20.Visible then
						continue
					end
					v20.Visible = true
				else
					if v20.Visible then
						continue
					end
					v20.Visible = true
				end
			end
		else
			if v_u_13[v19] == -1 then
				continue
			end
			v_u_12[v19].Visible = false
			v_u_13[v19] = -1
		end
	end
end
function v2.start() -- name: start
	-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_6, (copy) v_u_12, (copy) v_u_13, (ref) v_u_14, (ref) v_u_15
	if not v_u_7 then
		v_u_7 = true
		local v25
		if v_u_3.rules == nil then
			if v_u_5 == nil then
				v_u_5 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewTrailRules"))
			end
			v25 = v_u_5
		else
			v25 = v_u_3.rules
		end
		v_u_9 = v25.new()
		local v26 = workspace:FindFirstChild("HushLocal") or workspace
		local v27 = Instance.new("Folder")
		v27.Name = "ReviewTrail"
		v27.Parent = v26
		v_u_10 = v27
		local v28 = Instance.new("Part")
		v28.Name = "ReviewTrailAnchor"
		v28.Anchored = true
		v28.CanCollide = false
		v28.CanQuery = false
		v28.CanTouch = false
		v28.Transparency = 1
		v28.Size = Vector3.new(0.2, 0.2, 0.2)
		v28.CFrame = CFrame.new(0, 0, 0)
		v28.Parent = v27
		v_u_11 = v28
		for v29 = 1, v_u_9.cap do
			local v30 = Instance.new("BoxHandleAdornment")
			v30.Name = "Dot" .. v29
			v30.Adornee = v28
			v30.AlwaysOnTop = true
			v30.ZIndex = 1
			v30.Color3 = v_u_6
			v30.Size = Vector3.new(0.4, 0.4, 0.4)
			v30.Transparency = 1
			v30.Visible = false
			v30.Parent = v28
			v_u_12[v29] = v30
			v_u_13[v29] = -1
		end
		v_u_14 = 0
		v_u_15 = 0
	end
end
function v2.stop() -- name: stop
	-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (copy) v_u_12, (copy) v_u_13, (ref) v_u_9, (ref) v_u_15
	if v_u_7 then
		v_u_7 = false
		if v_u_10 then
			v_u_10:Destroy()
		end
		v_u_10 = nil
		v_u_11 = nil
		table.clear(v_u_12)
		table.clear(v_u_13)
		v_u_9 = nil
		v_u_15 = 0
	end
end
function v2.push(p31, p32) -- name: push
	-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_5, (copy) v_u_1, (ref) v_u_15, (copy) v_u_12, (copy) v_u_13, (ref) v_u_8
	if not v_u_7 or v_u_9 == nil then
		return
	end
	local v33
	if v_u_3.rules == nil then
		if v_u_5 == nil then
			v_u_5 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewTrailRules"))
		end
		v33 = v_u_5
	else
		v33 = v_u_3.rules
	end
	local v34 = v33.push(v_u_9, p31, p32.X, p32.Y - 2.5, p32.Z)
	if v34 == nil then
		return
	end
	v_u_15 = v_u_9.count
	v_u_12[v34].CFrame = CFrame.new(p32.X, p32.Y - 2.5, p32.Z)
	v_u_13[v34] = -1
	if v_u_8 then
		local v35 = v_u_12[v34]
		local v36 = v33.fade(v33.age(v_u_9, v34, p31), v_u_9.seconds)
		local v37 = v_u_13[v34]
		if v37 == -1 then
			v35.Transparency = v36
			v_u_13[v34] = v36
			if not v35.Visible then
				v35.Visible = true
			end
		else
			local v38 = v36 - v37
			if math.abs(v38) > 0.01 then
				v35.Transparency = v36
				v_u_13[v34] = v36
				if not v35.Visible then
					v35.Visible = true
				end
			elseif not v35.Visible then
				v35.Visible = true
			end
		end
	end
end
function v2.step(p39) -- name: step
	-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_14, (copy) v_u_24
	if v_u_7 and v_u_9 ~= nil then
		v_u_14 = v_u_14 + p39
		if v_u_14 >= 0.25 then
			v_u_14 = 0
			v_u_24(os.clock())
		end
	else
		return
	end
end
function v2.setOn(p40) -- name: setOn
	-- upvalues: (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (copy) v_u_24
	v_u_8 = p40 == true
	if v_u_7 and v_u_9 ~= nil then
		v_u_24(os.clock())
	end
end
function v2.isOn() -- name: isOn
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v2.count() -- name: count
	-- upvalues: (ref) v_u_15
	return v_u_15
end
function v2.state() -- name: state
	-- upvalues: (ref) v_u_8, (ref) v_u_7, (ref) v_u_15
	return ("on=%d running=%d live=%d"):format(v_u_8 and 1 or 0, v_u_7 and 1 or 0, v_u_15)
end
return v2