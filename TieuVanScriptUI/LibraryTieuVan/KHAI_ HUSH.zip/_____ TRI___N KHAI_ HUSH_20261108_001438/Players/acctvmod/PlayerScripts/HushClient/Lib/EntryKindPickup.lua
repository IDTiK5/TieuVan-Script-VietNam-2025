-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryKindPickup

local v_u_1 = require(script.Parent:WaitForChild("EntryMath"))
local v_u_2 = {
	["LANE"] = 9,
	["START"] = 70,
	["CRUISE"] = 24,
	["BRAKE"] = 1,
	["JUMP_AT"] = 0.35,
	["STAGGER"] = 0.4,
	["JUMP"] = 0.7,
	["APEX"] = 1.9,
	["RECOVER"] = 0.4,
	["LEAVE_AFTER"] = 0.35,
	["ACCEL"] = 14,
	["BED_Y"] = 2.75,
	["BED_CENTER_Z"] = 4.9,
	["TAIL"] = 2.5,
	["LIGHTS_LEAD"] = 60
}
local v_u_3 = {
	{ -1.6, 3.6 },
	{ 1.6, 3.6 },
	{ -1.6, 6.4 },
	{ 1.6, 6.4 }
}
function v_u_2.bedSlot(p4) -- name: bedSlot
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v5 = v_u_3[math.clamp(p4, 1, 4)]
	return {
		["x"] = v5[1],
		["y"] = v_u_2.BED_Y,
		["z"] = v5[2]
	}
end
function v_u_2.timing(p6) -- name: timing
	-- upvalues: (copy) v_u_2
	local v7 = (v_u_2.START - v_u_2.CRUISE * v_u_2.BRAKE / 2) / v_u_2.CRUISE
	local v8 = v7 + v_u_2.BRAKE
	local v9 = v8 + v_u_2.JUMP_AT
	local v10 = v9 + v_u_2.STAGGER * (p6.n - 1)
	return {
		["cruise"] = v7,
		["arrive"] = v8,
		["firstJump"] = v9,
		["lastJump"] = v10,
		["leave"] = v10 + v_u_2.LEAVE_AFTER,
		["lastLand"] = v10 + v_u_2.JUMP
	}
end
local function v_u_17(p11, p12) -- name: remaining
	-- upvalues: (copy) v_u_2
	if p12 <= 0 then
		return v_u_2.START
	end
	if p11.arrive <= p12 then
		return 0
	end
	if p12 <= p11.cruise then
		return v_u_2.START - v_u_2.CRUISE * p12
	end
	local v13 = p12 - p11.cruise
	local v14 = v_u_2.CRUISE / v_u_2.BRAKE
	local v15 = v_u_2.CRUISE * p11.cruise + v_u_2.CRUISE * v13 - 0.5 * v14 * v13 * v13
	local v16 = v_u_2.START - v15
	return math.max(v16, 0)
end
v_u_2.remaining = v_u_17
local function v_u_33(p18, p19, p20) -- name: truckPos
	-- upvalues: (copy) v_u_2, (copy) v_u_17
	local v21 = p18.f
	local v22 = p18.r
	local v23 = p18.side
	local v24 = -v_u_2.BED_CENTER_Z
	local v25 = 0
	local v26
	if p20 < p19.arrive then
		v26 = v24 + v_u_17(p19, p20)
	elseif p19.leave < p20 then
		local v27 = p20 - p19.leave
		v26 = v24 - 0.5 * v_u_2.ACCEL * v27 * v27
		v25 = v_u_2.ACCEL * v27
	else
		v26 = v24
	end
	local v28 = v24 + v_u_2.START - v26
	local v29 = p18.cen
	local v30 = p18.places[1]
	local v31 = v30.x + v21.x * -v_u_2.LANE
	local v32 = v30.z + v21.z * -v_u_2.LANE
	return {
		["x"] = v31 + v22.x * v23 * v26,
		["y"] = v29.y,
		["z"] = v32 + v22.z * v23 * v26
	}, v25, v28
end
function v_u_2.sample(p34, p35) -- name: sample
	-- upvalues: (copy) v_u_2, (copy) v_u_33, (copy) v_u_1
	local v36 = v_u_2.timing(p34)
	local v_u_37 = p34.f
	local v_u_38 = p34.r
	local v_u_39 = p34.side
	local v_u_40, v41, v42 = v_u_33(p34, v36, p35)
	local v43 = -v_u_39 * v_u_38.x
	local v44 = -v_u_39 * v_u_38.z
	local v45 = v_u_1.yawOfDir(v43, v44)
	local v46 = 0
	if v36.cruise < p35 and p35 < v36.arrive then
		local v47 = 3.141592653589793 * (p35 - v36.cruise) / v_u_2.BRAKE
		v46 = math.sin(v47) * -0.04363323129985824
	elseif v36.leave < p35 then
		v46 = 0.03490658503988659 * v_u_1.smooth((p35 - v36.leave) / 0.8)
	end
	local v48 = v_u_1.smooth(v_u_1.unlerp(v36.cruise - v_u_2.LIGHTS_LEAD, v36.cruise - v_u_2.LIGHTS_LEAD + 0.4, p35))
	local v49
	if v36.cruise < p35 then
		v49 = p35 < v36.arrive + 0.3
	else
		v49 = false
	end
	local v50 = {
		["x"] = v_u_40.x,
		["y"] = v_u_40.y,
		["z"] = v_u_40.z,
		["yaw"] = v45,
		["pitch"] = v46,
		["vis"] = p35 < v36.leave + v_u_2.TAIL + 4,
		["speed"] = v41,
		["dist"] = v42,
		["lit"] = v48,
		["brake"] = v49
	}
	local function v54(p51, p52) -- name: bedWorld
		-- upvalues: (ref) v_u_2, (copy) v_u_40, (copy) v_u_39, (copy) v_u_37, (copy) v_u_38
		local v53 = v_u_2.bedSlot(p51)
		return {
			["x"] = v_u_40.x + v_u_39 * v_u_37.x * v53.x + v_u_39 * v_u_38.x * v53.z,
			["y"] = v_u_40.y + v53.y + p52,
			["z"] = v_u_40.z + v_u_39 * v_u_37.z * v53.x + v_u_39 * v_u_38.z * v53.z
		}
	end
	local v55 = {}
	for v56, v57 in p34.places do
		local v58 = v36.firstJump + v_u_2.STAGGER * (v56 - 1)
		local v59 = {
			["x"] = nil,
			["y"] = nil,
			["z"] = nil,
			["yaw"] = nil,
			["pose"] = "idle",
			["k"] = 0,
			["vx"] = 0,
			["vz"] = 0,
			["vis"] = true,
			["x"] = v57.x,
			["y"] = v57.y,
			["z"] = v57.z,
			["yaw"] = p34.yaw
		}
		if p35 < v58 then
			local v60
			if p35 < v36.arrive then
				local v61 = p35 * 17 + v56 * 1.7
				v60 = math.sin(v61) * 0.05 * (1 - v_u_1.smooth((p35 - v36.cruise) / v_u_2.BRAKE))
			else
				v60 = 0
			end
			local v62 = v54(v56, v60)
			local v63 = v62.x
			local v64 = v62.y
			local v65 = v62.z
			v59.x = v63
			v59.y = v64
			v59.z = v65
			v59.pose = "bed_crouch"
			v59.k = v_u_1.smooth(v_u_1.unlerp(v36.arrive - 0.6, v36.arrive, p35))
		elseif p35 < v58 + v_u_2.JUMP then
			local v66 = (p35 - v58) / v_u_2.JUMP
			local v67 = v54(v56, 0)
			local v68 = v_u_1.lerp(v67.x, v57.x, v66)
			local v69 = v_u_1.lerp(v67.z, v57.z, v66)
			local v70 = v_u_1.lerp(v67.y, v57.y, v66) + v_u_2.APEX * 4 * v66 * (1 - v66)
			v59.x = v68
			v59.y = v70
			v59.z = v69
			v59.pose = "jump"
			v59.k = v66
		else
			local v71 = p35 - (v58 + v_u_2.JUMP)
			if v71 < v_u_2.RECOVER then
				v59.pose = "crouch_land"
				v59.k = 1 - v_u_1.smooth(v71 / v_u_2.RECOVER)
			end
		end
		v55[v56] = v59
	end
	local v72 = p34.cen
	local v73 = {
		["x"] = v72.x + v_u_37.x * 11 - v_u_38.x * v_u_39 * 6,
		["y"] = v72.y + 2,
		["z"] = v72.z + v_u_37.z * 11 - v_u_38.z * v_u_39 * 6
	}
	local v74 = {
		["x"] = v72.x + v_u_37.x * 9 - v_u_38.x * v_u_39 * 3,
		["y"] = v72.y + 3.2,
		["z"] = v72.z + v_u_37.z * 9 - v_u_38.z * v_u_39 * 3
	}
	local v75 = p34.dur - p34.hand
	local v76 = v_u_1.smooth(v_u_1.unlerp(0, v75, p35))
	local v77 = v_u_1.mix(v73, v74, v76)
	local v78 = {
		["x"] = v_u_40.x,
		["y"] = v_u_40.y + 2.4,
		["z"] = v_u_40.z
	}
	local v79 = {
		["x"] = v72.x,
		["y"] = v72.y + 1.5,
		["z"] = v72.z
	}
	local v80 = v_u_1.smooth(v_u_1.unlerp(v36.arrive - 0.8, v36.firstJump + 0.2, p35))
	local v81 = v_u_1.mix(v78, v79, v80)
	local v82 = v_u_1.lerp(52, 50, v76)
	return {
		["cam"] = {
			["px"] = v77.x,
			["py"] = v77.y,
			["pz"] = v77.z,
			["tx"] = v81.x,
			["ty"] = v81.y,
			["tz"] = v81.z,
			["fov"] = v82
		},
		["actors"] = v55,
		["props"] = {
			["pickup"] = v50
		}
	}
end
function v_u_2.cues(p83) -- name: cues
	-- upvalues: (copy) v_u_2
	local v84 = v_u_2.timing(p83)
	return {
		{
			["t"] = 0,
			["name"] = "engine"
		},
		{
			["t"] = nil,
			["name"] = "brake",
			["t"] = v84.cruise
		},
		{
			["t"] = nil,
			["name"] = "door_slam",
			["t"] = v84.arrive + 0.1
		},
		{
			["t"] = nil,
			["name"] = "engine_leave",
			["t"] = v84.leave
		}
	}
end
return v_u_2