-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuQueueWindow

local v_u_1 = {
	["WIDTH"] = 520,
	["ORDER_RULE"] = 100,
	["ORDER_OPTIONS"] = 101,
	["ORDER_INPUT"] = 102
}
local function v_u_8(p_u_2, p_u_3) -- name: libMod
	local v4, v5 = pcall(function()
		-- upvalues: (copy) p_u_2, (copy) p_u_3
		return p_u_2.cctx.lib[p_u_3]
	end)
	if v4 and type(v5) == "table" then
		return v5
	else
		local v6, v7 = pcall(function()
			-- upvalues: (copy) p_u_3
			return require((script.Parent:WaitForChild(p_u_3, 5)))
		end)
		if v6 and type(v7) == "table" then
			return v7
		else
			return nil
		end
	end
end
function v_u_1.panelWidth(p_u_9, p10) -- name: panelWidth
	-- upvalues: (copy) v_u_8
	local v11 = v_u_8(p_u_9, "QueueWindowLayout")
	local v12 = 1920
	local v13 = 1080
	local v14, v15 = pcall(function()
		-- upvalues: (copy) p_u_9
		return p_u_9.theme.refSize()
	end)
	if v14 and v15 ~= nil then
		local v16 = v15.X
		if type(v16) == "number" then
			local v17 = v15.Y
			if type(v17) == "number" then
				v12 = v15.X
				v13 = v15.Y
			end
		end
	end
	local v18 = nil
	local v19, v20 = pcall(function()
		-- upvalues: (copy) p_u_9
		return p_u_9.ui.safeInsets()
	end)
	if v19 then
		if type(v20) ~= "table" then
			v20 = v18
		end
	else
		v20 = v18
	end
	if v11 == nil then
		return p10 - 48
	else
		return v11.bodyWidth(p10, v12, v13, v20)
	end
end
function v_u_1.extend(p_u_21, p22, p23) -- name: extend
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v_u_24
	if type(p22) == "table" then
		v_u_24 = p22.queueApi
	else
		v_u_24 = nil
	end
	if type(v_u_24) == "table" then
		local v25 = v_u_24.store
		if type(v25) ~= "table" then
			v_u_24 = nil
		end
	else
		v_u_24 = nil
	end
	local v_u_26
	if type(p22) == "table" then
		v_u_26 = p22.inputApi
	else
		v_u_26 = nil
	end
	if type(v_u_26) == "table" then
		local v27 = v_u_26.store
		if type(v27) ~= "table" then
			v_u_26 = nil
		end
	else
		v_u_26 = nil
	end
	if v_u_24 == nil and v_u_26 == nil then
		return p23
	end
	local v_u_28 = v_u_8(p_u_21, "MenuPlayQueue")
	local v_u_29 = v_u_8(p_u_21, "MenuInputQueue")
	if v_u_24 ~= nil and v_u_28 == nil or (v_u_26 ~= nil and v_u_29 == nil or v_u_8(p_u_21, "QueueWindowLayout") == nil) then
		return p23
	end
	local v_u_30 = {}
	for v31, v32 in p23 do
		v_u_30[v31] = v32
	end
	v_u_30.width = v_u_1.WIDTH
	local v_u_33 = {}
	function v_u_30.after(p34) -- name: after
		-- upvalues: (copy) p_u_21, (ref) v_u_1, (copy) v_u_30, (ref) v_u_8, (copy) v_u_24, (copy) v_u_28, (copy) v_u_33, (copy) v_u_26, (copy) v_u_29
		local v35 = p_u_21.ui
		local v36 = p_u_21.theme.color
		local v37 = v_u_1.panelWidth(p_u_21, v_u_30.width)
		local v38 = v_u_8(p_u_21, "QueueWindowLayout")
		local v_u_39 = v35.new("Frame", {
			["Name"] = "QueueRule",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Active"] = false,
			["BackgroundColor3"] = v36.line,
			["Size"] = UDim2.new(1, 0, 0, v38.RULE),
			["LayoutOrder"] = v_u_1.ORDER_RULE
		}, p34)
		local v_u_40 = {}
		if v_u_24 ~= nil then
			local v41, v42 = v_u_28.build(p_u_21, p34, {
				["width"] = nil,
				["order"] = nil,
				["store"] = nil,
				["send"] = nil,
				["keepFocus"] = true,
				["width"] = v37,
				["order"] = v_u_1.ORDER_OPTIONS,
				["store"] = v_u_24.store,
				["send"] = v_u_24.send
			})
			table.insert(v_u_40, v41)
			local v43 = v_u_33
			table.insert(v43, {
				["api"] = v42
			})
		end
		if v_u_26 ~= nil then
			local v44, v45 = v_u_29.build(p_u_21, p34, {
				["width"] = nil,
				["order"] = nil,
				["store"] = nil,
				["send"] = nil,
				["keepFocus"] = true,
				["width"] = v37,
				["order"] = v_u_1.ORDER_INPUT,
				["store"] = v_u_26.store,
				["send"] = v_u_26.send
			})
			table.insert(v_u_40, v44)
			local v46 = v_u_33
			table.insert(v46, {
				["api"] = v45
			})
		end
		local v47 = false
		local function v50() -- name: sync
			-- upvalues: (copy) v_u_40, (copy) v_u_39
			local v48 = false
			for _, v49 in v_u_40 do
				if v49.Visible ~= true then
					continue
				end
				v48 = true
			end
			v_u_39.Visible = v48
		end
		for _, v51 in v_u_40 do
			if v51.Visible ~= true then
				continue
			end
			v47 = true
		end
		v_u_39.Visible = v47
		if v_u_24 ~= nil then
			local v52 = v_u_33
			local v53 = {
				["off"] = v_u_24.store.subscribe(v50)
			}
			table.insert(v52, v53)
		end
		if v_u_26 ~= nil then
			local v54 = v_u_33
			local v55 = {
				["off"] = v_u_26.store.subscribe(v50)
			}
			table.insert(v54, v55)
		end
	end
	function v_u_30.onClose() -- name: onClose
		-- upvalues: (copy) v_u_33
		for _, v56 in v_u_33 do
			if v56.off ~= nil then
				local v57 = v56.off
				pcall(v57)
			end
			if v56.api == nil then
				continue
			end
			local v58 = v56.api.destroy
			pcall(v58)
		end
		table.clear(v_u_33)
	end
	return v_u_30
end
return v_u_1