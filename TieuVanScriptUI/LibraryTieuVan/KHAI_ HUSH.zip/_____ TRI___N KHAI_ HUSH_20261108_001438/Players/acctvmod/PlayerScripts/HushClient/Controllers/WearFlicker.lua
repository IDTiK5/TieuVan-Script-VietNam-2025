-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / WearFlicker

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = {
	["name"] = "WearFlicker",
	["order"] = 91,
	["TAG"] = "HushWearGlow",
	["TUNE"] = {
		["rate"] = 12,
		["scan"] = 1,
		["maxParts"] = 24,
		["maxDim"] = 0.34,
		["maxStep"] = 0.16,
		["range"] = 120
	}
}
local v_u_4 = v_u_3.TUNE
function v_u_3.level(p5, p6) -- name: level
	-- upvalues: (copy) v_u_4
	local v7 = p6 % 997
	local v8 = p5 * 2.3 + v7
	local v9 = math.sin(v8) * 0.5 + 0.5
	local v10 = p5 * 5.1 + v7 * 1.7
	local v11 = math.sin(v10) * 0.5 + 0.5
	local v12 = p5 * 13.7 + v7 * 0.37
	local v13 = math.sin(v12)
	local v14 = math.max(0, v13)
	local v15 = (v9 * 0.45 + v11 * 0.35 * v9 + v14 * 0.2 * v11) * v_u_4.maxDim
	local v16 = v_u_4.maxDim
	return math.clamp(v15, 0, v16)
end
function v_u_3.seedOf(p17) -- name: seedOf
	local v18 = 0
	for v19 = 1, #p17 do
		v18 = (v18 * 31 + string.byte(p17, v19)) % 100003
	end
	return v18 * 0.01
end
function v_u_3.pick(p20, _, p21) -- name: pick
	local v22 = {}
	for _, v23 in p20 do
		table.insert(v22, v23)
	end
	table.sort(v22, function(p24, p25)
		if p24.dist ~= p25.dist then
			return p24.dist < p25.dist
		end
		local v26 = p24.part.Name
		local v27 = tostring(v26)
		local v28 = p25.part.Name
		return v27 < tostring(v28)
	end)
	local v29 = #v22
	local v30 = {}
	for v31 = 1, math.min(p21, v29) do
		local v32 = v22[v31]
		table.insert(v30, v32)
	end
	return v30
end
local v_u_33 = {}
local v_u_34 = (-1 / 0)
local v_u_35 = 0
function v_u_3.scan(p36) -- name: scan
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_33
	local v37 = workspace.CurrentCamera
	if not p36 then
		if v37 then
			p36 = v37.CFrame.Position
		else
			p36 = nil
		end
	end
	local v38 = {}
	for _, v39 in v_u_1:GetTagged(v_u_3.TAG) do
		if not (v39:IsA("BasePart") and v39:IsDescendantOf(workspace)) then
			continue
		end
		local v40 = not p36 and 0 or (v39.Position - p36).Magnitude
		if v40 > v_u_4.range then
			continue
		end
		table.insert(v38, {
			["part"] = v39,
			["dist"] = v40
		})
	end
	local v41 = {}
	for _, v42 in v_u_3.pick(v38, p36, v_u_4.maxParts) do
		v41[v42.part] = true
		if v_u_33[v42.part] ~= nil then
			continue
		end
		local v43 = v_u_33
		local v44 = v42.part
		local v45 = {
			["base"] = nil,
			["seed"] = nil,
			["last"] = nil,
			["base"] = v42.part.Transparency
		}
		local v46 = v_u_3.seedOf
		local v47 = v42.part.Name
		local v48 = v42.part.Parent and v42.part.Parent.Name or ""
		v45.seed = v46(v47 .. tostring(v48))
		v43[v44] = v45
	end
	for v49, v50 in table.clone(v_u_33) do
		if v41[v49] then
			continue
		end
		if v49.Parent ~= nil and (v49:IsA("BasePart") and v50.last ~= nil) then
			local v51 = v49.Transparency - v50.last
			if math.abs(v51) < 1e-6 then
				v49.Transparency = v50.base
			end
		end
		v_u_33[v49] = nil
	end
end
function v_u_3.update(p52) -- name: update
	-- upvalues: (copy) v_u_33, (copy) v_u_3, (copy) v_u_4
	for v53, v54 in table.clone(v_u_33) do
		if v53.Parent == nil or not v53:IsA("BasePart") then
			v_u_33[v53] = nil
		else
			local v55 = v54.base + v_u_3.level(p52, v54.seed) * (1 - v54.base)
			local v56 = v54.last or v54.base
			local v57 = v55 - v56
			local v58 = -v_u_4.maxStep
			local v59 = v_u_4.maxStep
			local v60 = v56 + math.clamp(v57, v58, v59)
			v54.last = v60
			v53.Transparency = v60
		end
	end
end
function v_u_3.active() -- name: active
	-- upvalues: (copy) v_u_33
	local v61 = 0
	for _ in v_u_33 do
		v61 = v61 + 1
	end
	return v61
end
function v_u_3.stop() -- name: stop
	-- upvalues: (copy) v_u_33, (ref) v_u_35, (ref) v_u_34
	for v62, v63 in table.clone(v_u_33) do
		if v62.Parent ~= nil and (v62:IsA("BasePart") and v63.last ~= nil) then
			local v64 = v62.Transparency - v63.last
			if math.abs(v64) < 1e-6 then
				v62.Transparency = v63.base
			end
		end
		v_u_33[v62] = nil
	end
	v_u_35 = 0
	v_u_34 = (-1 / 0)
end
function v_u_3.init(p65) -- name: init
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	p65.command("wearflicker.state", function()
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_2
		local v66 = v_u_3.active()
		local v67 = v_u_4.maxParts
		local v68 = v_u_2.LocalPlayer
		return ("wear flicker: %d parts flicker (budget %d), switch %s"):format(v66, v67, (v68 == nil and true or v68:GetAttribute("WearFlicker") ~= false) and "on" or "off")
	end)
end
function v_u_3.step(p69) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_33, (copy) v_u_3, (ref) v_u_34, (copy) v_u_4, (ref) v_u_35
	local v70 = v_u_2.LocalPlayer
	if v70 == nil and true or v70:GetAttribute("WearFlicker") ~= false then
		local v71 = os.clock()
		if v71 - v_u_34 >= v_u_4.scan then
			v_u_34 = v71
			v_u_3.scan()
		end
		if next(v_u_33) ~= nil then
			v_u_35 = v_u_35 + p69
			if v_u_35 >= 1 / v_u_4.rate then
				v_u_35 = 0
				v_u_3.update(v71)
			end
		end
	else
		if next(v_u_33) ~= nil then
			v_u_3.stop()
		end
		return
	end
end
return v_u_3