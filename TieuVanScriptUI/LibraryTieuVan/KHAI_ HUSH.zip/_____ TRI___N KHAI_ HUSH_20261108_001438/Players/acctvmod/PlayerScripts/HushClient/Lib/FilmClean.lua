-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmClean

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = {}
local v_u_6 = 0
function v_u_3.force(p_u_7, p_u_8, p_u_9, p10) -- name: force
	-- upvalues: (copy) v_u_5, (ref) v_u_6
	local v11 = p10 or "film"
	local v12 = v_u_5[p_u_7]
	if not v12 then
		v12 = {}
		v_u_5[p_u_7] = v12
	end
	local v13 = v12[p_u_8]
	if v13 then
		v13.value = p_u_9
		v13.holders[v11] = true
		pcall(function()
			-- upvalues: (copy) p_u_7, (copy) p_u_8, (copy) p_u_9
			p_u_7[p_u_8] = p_u_9
		end)
		return
	else
		local v14, v15 = pcall(function()
			-- upvalues: (copy) p_u_7, (copy) p_u_8
			return p_u_7[p_u_8]
		end)
		if v14 then
			local v_u_16 = {
				["want"] = nil,
				["value"] = nil,
				["conn"] = nil,
				["dconn"] = nil,
				["holders"] = nil,
				["want"] = v15,
				["value"] = p_u_9,
				["holders"] = {
					[v11] = true
				}
			}
			v12[p_u_8] = v_u_16
			v_u_6 = v_u_6 + 1
			v_u_16.conn = p_u_7:GetPropertyChangedSignal(p_u_8):Connect(function()
				-- upvalues: (copy) p_u_7, (copy) p_u_8, (copy) v_u_16
				local v17 = p_u_7[p_u_8]
				if v17 ~= v_u_16.value then
					v_u_16.want = v17
					local v_u_18 = p_u_7
					local v_u_19 = p_u_8
					local v_u_20 = v_u_16.value
					pcall(function()
						-- upvalues: (copy) v_u_18, (copy) v_u_19, (copy) v_u_20
						v_u_18[v_u_19] = v_u_20
					end)
				end
			end)
			v_u_16.dconn = p_u_7.Destroying:Connect(function()
				-- upvalues: (ref) v_u_5, (copy) p_u_7, (ref) v_u_6
				local v21 = v_u_5[p_u_7]
				if v21 then
					for _, v22 in v21 do
						if v22.conn then
							v22.conn:Disconnect()
						end
						if v22.dconn then
							v22.dconn:Disconnect()
						end
						v_u_6 = v_u_6 - 1
					end
					v_u_5[p_u_7] = nil
				end
			end)
			pcall(function()
				-- upvalues: (copy) p_u_7, (copy) p_u_8, (copy) p_u_9
				p_u_7[p_u_8] = p_u_9
			end)
		end
	end
end
function v_u_3.release(p_u_23, p_u_24, p25) -- name: release
	-- upvalues: (copy) v_u_5, (ref) v_u_6, (copy) v_u_2
	local v26 = v_u_5[p_u_23]
	local v27
	if v26 then
		v27 = v26[p_u_24]
	else
		v27 = v26
	end
	if v26 and v27 then
		v27.holders[p25 or "film"] = nil
		if next(v27.holders) == nil then
			v26[p_u_24] = nil
			v_u_6 = v_u_6 - 1
			if v27.conn then
				v27.conn:Disconnect()
			end
			if v27.dconn then
				v27.dconn:Disconnect()
			end
			if next(v26) == nil then
				v_u_5[p_u_23] = nil
			end
			if p_u_23.Parent ~= nil or p_u_23 == v_u_2 then
				local v_u_28 = v27.want
				pcall(function()
					-- upvalues: (copy) p_u_23, (copy) p_u_24, (copy) v_u_28
					p_u_23[p_u_24] = v_u_28
				end)
			end
		end
	else
		return
	end
end
function v_u_3.isForced(p29, p30, p31) -- name: isForced
	-- upvalues: (copy) v_u_5
	local v32 = v_u_5[p29]
	if v32 then
		v32 = v32[p30]
	end
	if v32 then
		return p31 == nil and true or v32.holders[p31] == true
	else
		return false
	end
end
local v_u_33 = false
local v_u_34 = {}
local v_u_35 = {}
local v_u_36 = {
	["ScreenGui"] = "Enabled",
	["BillboardGui"] = "Enabled",
	["Highlight"] = "Enabled",
	["SelectionBox"] = "Visible",
	["SelectionSphere"] = "Visible",
	["BoxHandleAdornment"] = "Visible",
	["SphereHandleAdornment"] = "Visible",
	["CylinderHandleAdornment"] = "Visible",
	["LineHandleAdornment"] = "Visible",
	["ConeHandleAdornment"] = "Visible"
}
local v_u_37 = {}
local function v_u_40(p38) -- name: hideObj
	-- upvalues: (copy) v_u_36, (ref) v_u_34, (copy) v_u_37, (copy) v_u_3
	local v39 = v_u_36[p38.ClassName]
	if v39 and not v_u_34[p38] then
		if v39 ~= "Enabled" or (p38.ClassName ~= "ScreenGui" or not v_u_37[p38.Name]) then
			v_u_34[p38] = v39
			v_u_3.force(p38, v39, false)
		end
	else
		return
	end
end
function v_u_3.setClean(p41) -- name: setClean
	-- upvalues: (ref) v_u_33, (copy) v_u_4, (copy) v_u_36, (ref) v_u_34, (copy) v_u_37, (copy) v_u_3, (ref) v_u_35, (copy) v_u_40, (copy) v_u_2
	local v42 = p41 == true
	if v42 == v_u_33 then
		return
	else
		v_u_33 = v42
		v_u_4:SetAttribute("FilmClean", v42)
		if v42 then
			local v43 = v_u_4:FindFirstChildOfClass("PlayerGui")
			if v43 then
				for _, v44 in v43:GetChildren() do
					local v45 = v_u_36[v44.ClassName]
					if not v45 then
						continue
					end
					if v_u_34[v44] then
						continue
					end
					if v45 == "Enabled" and (v44.ClassName == "ScreenGui" and v_u_37[v44.Name]) then
						continue
					end
					v_u_34[v44] = v45
					v_u_3.force(v44, v45, false)
				end
				for _, v46 in v43:GetDescendants() do
					local v47 = v_u_36[v46.ClassName]
					if not v47 then
						continue
					end
					if v_u_34[v46] then
						continue
					end
					if v47 == "Enabled" and (v46.ClassName == "ScreenGui" and v_u_37[v46.Name]) then
						continue
					end
					v_u_34[v46] = v47
					v_u_3.force(v46, v47, false)
				end
				local v48 = v_u_35
				local v49 = v43.DescendantAdded
				local v50 = v_u_40
				table.insert(v48, v49:Connect(v50))
			end
			for _, v51 in workspace:GetDescendants() do
				local v52 = v_u_36[v51.ClassName]
				if not v52 then
					continue
				end
				if v_u_34[v51] then
					continue
				end
				if v52 == "Enabled" and (v51.ClassName == "ScreenGui" and v_u_37[v51.Name]) then
					continue
				end
				v_u_34[v51] = v52
				v_u_3.force(v51, v52, false)
			end
			local v53 = v_u_35
			local v54 = workspace.DescendantAdded
			local v55 = v_u_40
			table.insert(v53, v54:Connect(v55))
			v_u_3.force(v_u_2, "MouseIconEnabled", false)
		else
			for _, v56 in v_u_35 do
				v56:Disconnect()
			end
			v_u_35 = {}
			for v57, v58 in v_u_34 do
				v_u_3.release(v57, v58)
			end
			v_u_34 = {}
			v_u_3.release(v_u_2, "MouseIconEnabled")
		end
	end
end
function v_u_3.isClean() -- name: isClean
	-- upvalues: (ref) v_u_33
	return v_u_33
end
function v_u_3.exempt(p59, p60) -- name: exempt
	-- upvalues: (copy) v_u_37, (ref) v_u_33, (copy) v_u_4, (ref) v_u_34, (copy) v_u_3, (copy) v_u_36
	v_u_37[p59] = p60 and true or nil
	if v_u_33 then
		local v61 = v_u_4:FindFirstChildOfClass("PlayerGui")
		if v61 then
			for _, v62 in v61:GetChildren() do
				if not v62:IsA("ScreenGui") or v62.Name ~= p59 then
					continue
				end
				if p60 and v_u_34[v62] then
					v_u_34[v62] = nil
					v_u_3.release(v62, "Enabled")
				else
					if p60 then
						continue
					end
					local v63 = v_u_36[v62.ClassName]
					if not v63 then
						continue
					end
					if v_u_34[v62] then
						continue
					end
					if v63 == "Enabled" and (v62.ClassName == "ScreenGui" and v_u_37[v62.Name]) then
						continue
					end
					v_u_34[v62] = v63
					v_u_3.force(v62, v63, false)
				end
			end
		end
	else
		return
	end
end
function v_u_3.isExempt(p64) -- name: isExempt
	-- upvalues: (copy) v_u_37
	return v_u_37[p64] == true
end
local v_u_65 = false
local v_u_66 = nil
local v_u_67 = {}
local v_u_68 = {}
local function v_u_70(p69) -- name: hidePart
	-- upvalues: (ref) v_u_67
	if p69:IsA("BasePart") or p69:IsA("Decal") then
		if v_u_67[p69] == nil then
			v_u_67[p69] = p69.LocalTransparencyModifier
		end
		p69.LocalTransparencyModifier = 1
	end
end
local function v_u_74() -- name: unhideAll
	-- upvalues: (ref) v_u_67, (ref) v_u_68, (ref) v_u_66
	for v_u_71, v_u_72 in v_u_67 do
		if not v_u_71.Parent then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_71, (copy) v_u_72
			v_u_71.LocalTransparencyModifier = v_u_72
		end)
	end
	v_u_67 = {}
	for _, v73 in v_u_68 do
		v73:Disconnect()
	end
	v_u_68 = {}
	v_u_66 = nil
end
local function v_u_80() -- name: hookChar
	-- upvalues: (copy) v_u_4, (ref) v_u_66, (copy) v_u_74, (ref) v_u_67, (ref) v_u_68, (copy) v_u_70
	local v75 = v_u_4.Character
	if v75 == v_u_66 then
		return
	else
		v_u_74()
		if v75 then
			v_u_66 = v75
			for _, v76 in v75:GetDescendants() do
				if not (v76:IsA("BasePart") or v76:IsA("Decal")) then
					continue
				end
				if v_u_67[v76] == nil then
					v_u_67[v76] = v76.LocalTransparencyModifier
				end
				v76.LocalTransparencyModifier = 1
			end
			local v77 = v_u_68
			local v78 = v75.DescendantAdded
			local v79 = v_u_70
			table.insert(v77, v78:Connect(v79))
		end
	end
end
function v_u_3.setCharacterHidden(p81) -- name: setCharacterHidden
	-- upvalues: (ref) v_u_65, (copy) v_u_4, (copy) v_u_80, (copy) v_u_74
	v_u_65 = p81 == true
	v_u_4:SetAttribute("FilmCharHidden", v_u_65)
	if v_u_65 then
		v_u_80()
	else
		v_u_74()
	end
end
function v_u_3.isCharacterHidden() -- name: isCharacterHidden
	-- upvalues: (ref) v_u_65
	return v_u_65
end
function v_u_3.step() -- name: step
	-- upvalues: (ref) v_u_65, (copy) v_u_80, (ref) v_u_67, (ref) v_u_33, (copy) v_u_2
	if v_u_65 then
		v_u_80()
		for v82 in v_u_67 do
			if not v82.Parent or v82.LocalTransparencyModifier == 1 then
				continue
			end
			v82.LocalTransparencyModifier = 1
		end
	end
	if v_u_33 and v_u_2.MouseIconEnabled then
		v_u_2.MouseIconEnabled = false
	end
end
function v_u_3.stats() -- name: stats
	-- upvalues: (ref) v_u_34, (ref) v_u_6, (ref) v_u_33, (ref) v_u_65
	local v83 = 0
	for _ in v_u_34 do
		v83 = v83 + 1
	end
	return {
		["forced"] = v_u_6,
		["cleanObjects"] = v83,
		["clean"] = v_u_33,
		["hidden"] = v_u_65
	}
end
return v_u_3