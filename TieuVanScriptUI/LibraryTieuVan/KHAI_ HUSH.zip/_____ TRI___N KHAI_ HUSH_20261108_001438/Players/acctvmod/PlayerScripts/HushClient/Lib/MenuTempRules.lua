-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTempRules

local v_u_21 = {
	["REJOIN_COOLDOWN"] = 15,
	["GAP"] = 12,
	["needsPopup"] = function(p1) -- name: needsPopup
		if type(p1) ~= "table" then
			return false
		end
		local v2
		if p1.isTemp == true and (p1.told ~= true and p1.open == true) then
			v2 = p1.place == "Menu"
		else
			v2 = false
		end
		return v2
	end,
	["rejoinTarget"] = function(p3, p4) -- name: rejoinTarget
		if type(p3) ~= "number" or (p3 ~= p3 or (p3 == (1 / 0) or p3 == (-1 / 0))) then
			p3 = nil
		end
		if p3 == nil or p3 <= 0 then
			if type(p4) ~= "number" or (p4 ~= p4 or (p4 == (1 / 0) or p4 == (-1 / 0))) then
				p4 = nil
			end
			if p4 == nil or p4 <= 0 then
				return nil
			else
				return math.floor(p4)
			end
		else
			return math.floor(p3)
		end
	end,
	["rejoinReady"] = function(p5, p6) -- name: rejoinReady
		-- upvalues: (copy) v_u_21
		if type(p5) ~= "number" or (p5 ~= p5 or (p5 == (1 / 0) or p5 == (-1 / 0))) then
			p5 = nil
		end
		if type(p6) ~= "number" or (p6 ~= p6 or (p6 == (1 / 0) or p6 == (-1 / 0))) then
			p6 = nil
		end
		if p5 == nil then
			return true
		elseif p6 == nil then
			return false
		else
			return p6 < p5 and true or p6 - p5 >= v_u_21.REJOIN_COOLDOWN
		end
	end,
	["layout"] = function(p7, p8, p9, p10, p11) -- name: layout
		-- upvalues: (copy) v_u_21
		local v12 = p7.holdLayout(p8, p9, p10, p11)
		local v13 = v12.btn.h
		local v14 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v12.btn.w,
			["h"] = v13
		}
		local v15 = v13 + v_u_21.GAP
		local v16 = {
			["rejoin"] = v14
		}
		local v17 = v12.btn
		v16.btn = {
			["x"] = v17.x,
			["y"] = v17.y + v15,
			["w"] = v17.w,
			["h"] = v17.h
		}
		local v18 = v12.fill
		v16.fill = {
			["x"] = v18.x,
			["y"] = v18.y + v15,
			["w"] = v18.w,
			["h"] = v18.h
		}
		local v19 = v12.label
		v16.label = {
			["x"] = v19.x,
			["y"] = v19.y + v15,
			["w"] = v19.w,
			["h"] = v19.h
		}
		local v20 = v12.hint
		v16.hint = {
			["x"] = v20.x,
			["y"] = v20.y + v15,
			["w"] = v20.w,
			["h"] = v20.h
		}
		v16.height = v15 + v12.height
		return v16
	end
}
return v_u_21