-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / TestTagBoot

return {
	["name"] = "TestTagBoot",
	["order"] = 90,
	["init"] = function(p_u_1) -- name: init
		if p_u_1.config.IS_TEST then
			local v2, v3 = pcall(function()
				-- upvalues: (copy) p_u_1
				p_u_1.lib.TestTag.start(p_u_1)
			end)
			if not v2 then
				warn("[TestTagBoot] the test tag failed to start:", v3)
				p_u_1.player:SetAttribute("ClientError", "testtag: " .. tostring(v3))
			end
		end
	end
}