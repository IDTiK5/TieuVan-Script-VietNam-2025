-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RidePosePlan

local v_u_1 = {
	["VERSION"] = 1,
	["TUNE"] = {
		["BLEND_S"] = 0.18,
		["RISE_S"] = 0.5,
		["LIE_S"] = 1
	}
}
local v_u_2 = v_u_1.TUNE
v_u_1.LYING = {
	["Neck"] = { 8, 0, 0 },
	["LeftShoulder"] = { 18, 0, -26 },
	["RightShoulder"] = { 12, 0, 24 },
	["LeftElbow"] = { 16, 0, 0 },
	["RightElbow"] = { 30, 0, 0 },
	["LeftHip"] = { -6, 0, -5 },
	["RightHip"] = { 4, 0, 6 },
	["LeftKnee"] = { -12, 0, 0 },
	["RightKnee"] = { -22, 0, 0 }
}
function v_u_1.smooth(p3) -- name: smooth
	local v4 = p3 < 0 and 0 or (p3 > 1 and 1 or p3)
	return v4 * v4 * (3 - v4 * 2)
end
function v_u_1.candidates(p5, p6, p7, p8) -- name: candidates
	local v9 = type(p5) ~= "string" and "" or p5
	local v10 = type(p5) ~= "string" and "" or (string.match(p5, "^Seat_(.+)$") or p5)
	local v11 = {}
	if p7 == true then
		if type(p8) == "string" and p8 ~= "" then
			table.insert(v11, p8)
		end
		local v12 = v9 .. "_LEAN"
		table.insert(v11, v12)
		local v13 = "BED_LEAN_" .. v10
		table.insert(v11, v13)
		table.insert(v11, "LEAN")
		return v11
	end
	if p6 == "driver" then
		local v14 = v9 .. "_DRIVE"
		table.insert(v11, v14)
		table.insert(v11, "DRIVE")
		table.insert(v11, "KART")
		return v11
	end
	local v15 = v9 .. "_SIT"
	table.insert(v11, v15)
	local v16 = "BED_KNEEL_" .. v10
	table.insert(v11, v16)
	table.insert(v11, "SIT")
	table.insert(v11, "BED_KNEEL")
	return v11
end
function v_u_1.choose(p17, p18) -- name: choose
	if type(p17) ~= "table" or type(p18) ~= "table" then
		return nil
	end
	for _, v19 in p18 do
		if p17[v19] == nil then
			continue
		end
		return v19
	end
	return nil
end
function v_u_1.poseKey(p20, p21, p22, p23, p24) -- name: poseKey
	-- upvalues: (copy) v_u_1
	local v25 = v_u_1.choose(p20, v_u_1.candidates(p21, p22, p23, p24))
	if v25 == nil and p23 == true then
		return v_u_1.choose(p20, v_u_1.candidates(p21, p22, false, nil))
	else
		return v25
	end
end
function v_u_1.jointEuler(p26, p27) -- name: jointEuler
	local v28
	if type(p26) == "table" then
		local v29 = p26.j
		if type(v29) == "table" then
			v28 = p26.j[p27]
		else
			v28 = nil
		end
	else
		v28 = nil
	end
	if type(v28) == "table" then
		local v30 = v28[1]
		local v31 = (type(v30) ~= "number" or (v30 ~= v30 or (v30 == (1 / 0) or v30 == (-1 / 0)))) and 0 or v30
		local v32 = v28[2]
		local v33 = (type(v32) ~= "number" or (v32 ~= v32 or (v32 == (1 / 0) or v32 == (-1 / 0)))) and 0 or v32
		local v34 = v28[3]
		if type(v34) == "number" and (v34 == v34 and (v34 ~= (1 / 0) and v34 ~= (-1 / 0))) then
			return v31, v33, v34
		else
			return v31, v33, 0
		end
	else
		return 0, 0, 0
	end
end
function v_u_1.rootEuler(p35) -- name: rootEuler
	-- upvalues: (copy) v_u_1
	return v_u_1.jointEuler(p35, "Root")
end
function v_u_1.rootT(p36) -- name: rootT
	local v37
	if type(p36) == "table" then
		v37 = p36.rootT
	else
		v37 = nil
	end
	if type(v37) == "table" then
		local v38 = v37[1]
		local v39 = (type(v38) ~= "number" or (v38 ~= v38 or (v38 == (1 / 0) or v38 == (-1 / 0)))) and 0 or v38
		local v40 = v37[2]
		local v41 = (type(v40) ~= "number" or (v40 ~= v40 or (v40 == (1 / 0) or v40 == (-1 / 0)))) and 0 or v40
		local v42 = v37[3]
		if type(v42) == "number" and (v42 == v42 and (v42 ~= (1 / 0) and v42 ~= (-1 / 0))) then
			return v39, v41, v42
		else
			return v39, v41, 0
		end
	else
		return 0, 0, 0
	end
end
function v_u_1.blendNew() -- name: blendNew
	return {
		["key"] = nil,
		["prev"] = nil,
		["t0"] = -1000000000
	}
end
function v_u_1.blendStep(p43, p44, p45) -- name: blendStep
	-- upvalues: (copy) v_u_2
	if p43.key ~= p44 then
		p43.prev = p43.key
		p43.key = p44
		p43.t0 = p45
	end
	if p43.prev == nil then
		return nil, p44, 1
	end
	local v46 = (p45 - p43.t0) / v_u_2.BLEND_S
	if v46 >= 1 then
		p43.prev = nil
		return nil, p44, 1
	end
	local v47 = p43.prev
	local v48 = v46 < 0 and 0 or (v46 > 1 and 1 or v46)
	return v47, p44, v48 * v48 * (3 - v48 * 2)
end
function v_u_1.eject(p49, p50, p51) -- name: eject
	-- upvalues: (copy) v_u_2
	if type(p49) == "number" and p49 == p49 then
		local v52 = (type(p51) ~= "number" or (p51 ~= p51 or (p51 == (1 / 0) or p51 == (-1 / 0)))) and 0 or p51
		if v52 <= 0 or v52 <= p49 then
			return "done", 0
		else
			local v53 = v52 - v_u_2.RISE_S
			if v53 <= p49 then
				local v54 = (p49 - v53) / v_u_2.RISE_S
				local v55 = v54 < 0 and 0 or (v54 > 1 and 1 or v54)
				return "rise", 1 - v55 * v55 * (3 - v55 * 2)
			else
				local v56 = (type(p50) ~= "number" or (p50 ~= p50 or (p50 == (1 / 0) or p50 == (-1 / 0)))) and 0 or p50
				if v56 > 0 and p49 < v56 then
					return "flight", 1
				else
					return "lie", 1
				end
			end
		end
	else
		return "done", 0
	end
end
return v_u_1