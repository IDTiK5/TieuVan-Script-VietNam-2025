-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / TokyoWarnBlinkBoot

return {
	["name"] = "TokyoWarnBlinkBoot",
	["order"] = 93,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.TokyoWarnBlink.start(p_u_1)
		end)
		if not v2 then
			warn("[TokyoWarnBlinkBoot] the warning lamps failed to start:", v3)
			p_u_1.player:SetAttribute("ClientError", "warnblink: " .. tostring(v3))
		end
	end
}