-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIMoveAll

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v_u_1.withAmmo() -- name: withAmmo
	-- upvalues: (copy) v_u_2
	return v_u_2:GetAttribute("MoveAllAmmo") == true
end
function v_u_1.setAmmo(p3) -- name: setAmmo
	-- upvalues: (copy) v_u_2
	v_u_2:SetAttribute("MoveAllAmmo", p3)
end
function v_u_1.op() -- name: op
	-- upvalues: (copy) v_u_1
	return {
		["op"] = "moveAll",
		["ammo"] = nil,
		["ammo"] = v_u_1.withAmmo()
	}
end
local v_u_4 = nil
local function v_u_11(p5) -- name: ammoText
	-- upvalues: (ref) v_u_4
	if v_u_4 == nil then
		local v6, v7 = pcall(function()
			return require((script.Parent:WaitForChild("InvUIWhy", 3)))
		end)
		if not v6 or type(v7) ~= "table" then
			v7 = false
		end
		v_u_4 = v7
	end
	if v_u_4 then
		local v8 = v_u_4.pocketAmmoLabel
		local v9, v10 = pcall(v8, p5)
		if v9 and type(v10) == "string" then
			return v10
		end
	end
	return p5 and "+ Pocket ammo" or "Keep pocket ammo"
end
function v_u_1.stashTools(p12, p13, p_u_14, p_u_15) -- name: stashTools
	-- upvalues: (copy) v_u_11, (copy) v_u_1
	local v16 = {}
	local v_u_17 = nil
	local function v20() -- name: paint
		-- upvalues: (ref) v_u_17, (ref) v_u_11, (ref) v_u_1, (copy) p_u_15
		if v_u_17 then
			v_u_17.Text = string.upper((v_u_11(v_u_1.withAmmo())))
			local v18 = v_u_17
			local v19
			if v_u_1.withAmmo() then
				v19 = p_u_15.accent
			else
				v19 = p_u_15.text2
			end
			v18.TextColor3 = v19
		end
	end
	local v21 = p13(p12, "All to stash", "primary", 2, function()
		-- upvalues: (copy) p_u_14, (ref) v_u_1
		p_u_14(v_u_1.op())
	end)
	v21.Name = "Btn_MoveAll"
	table.insert(v16, v21)
	v_u_17 = p13(p12, v_u_11(v_u_1.withAmmo()), "ghost", 2, function()
		-- upvalues: (ref) v_u_1, (ref) v_u_17, (ref) v_u_11, (copy) p_u_15
		v_u_1.setAmmo(not v_u_1.withAmmo())
		if v_u_17 then
			v_u_17.Text = string.upper((v_u_11(v_u_1.withAmmo())))
			local v22 = v_u_17
			local v23
			if v_u_1.withAmmo() then
				v23 = p_u_15.accent
			else
				v23 = p_u_15.text2
			end
			v22.TextColor3 = v23
		end
	end)
	local v24 = v_u_17
	v24.Name = "Btn_MoveAllAmmo"
	v24.MouseLeave:Connect(v20)
	if v_u_17 then
		v_u_17.Text = string.upper((v_u_11(v_u_1.withAmmo())))
		local v25
		if v_u_1.withAmmo() then
			v25 = p_u_15.accent
		else
			v25 = p_u_15.text2
		end
		v_u_17.TextColor3 = v25
	end
	table.insert(v16, v24)
	return v16
end
function v_u_1.debriefRow(p_u_26, p27, p28) -- name: debriefRow
	-- upvalues: (copy) v_u_1, (copy) v_u_11
	local v29 = p_u_26.ui
	local v30 = p_u_26.theme
	local v31 = p28.height or v30.touch(52)
	local v32 = v29.new("Frame", {
		["Name"] = "MoveAllRow",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Position"] = p28.position,
		["AnchorPoint"] = p28.anchor or Vector2.new(0, 1),
		["Size"] = UDim2.fromOffset(p28.width or 400, v31)
	}, p27)
	local v33 = p28.width or 400
	local v34 = v33 * 0.45
	local v35 = math.floor(v34)
	local v_u_36 = false
	local v37, _ = v29.button({
		["parent"] = nil,
		["text"] = "Move all to stash",
		["kind"] = "secondary",
		["size"] = nil,
		["onClick"] = nil,
		["parent"] = v32,
		["size"] = UDim2.new(0, v33 - v35 - 8, 0, v31),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_36, (copy) p_u_26, (ref) v_u_1
			if not v_u_36 then
				v_u_36 = true
				p_u_26.op(v_u_1.op())
				task.delay(1, function()
					-- upvalues: (ref) v_u_36
					v_u_36 = false
				end)
			end
		end
	})
	v37.Name = "MoveAll"
	local v38, v_u_39 = v29.button({
		["parent"] = nil,
		["text"] = nil,
		["kind"] = "ghost",
		["size"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v32,
		["text"] = v_u_11(v_u_1.withAmmo()),
		["size"] = UDim2.new(0, v35, 0, v31),
		["position"] = UDim2.fromOffset(v33 - v35, 0),
		["onClick"] = function() -- name: onClick end
	})
	v38.Name = "MoveAllAmmo"
	v38.Activated:Connect(function()
		-- upvalues: (ref) v_u_1, (copy) v_u_39, (ref) v_u_11
		v_u_1.setAmmo(not v_u_1.withAmmo())
		if v_u_39 and v_u_39.setText then
			v_u_39.setText((v_u_11(v_u_1.withAmmo())))
		end
	end)
	return v32
end
return v_u_1