-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmMail

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = v_u_4.Theme
local v_u_6 = v_u_5.color
local v7 = {}
local v_u_8 = v1.LocalPlayer
function v7.build(p_u_9) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_8, (copy) v_u_2
	local v_u_10 = p_u_9.body
	local v_u_11 = p_u_9.api
	local v_u_12 = true
	p_u_9.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_12
		v_u_12 = false
	end)
	local v_u_13 = require((v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MailcastRules")))
	local v_u_14 = v_u_13.TUNE
	local v_u_15 = 0
	local function v18(p16) -- name: section
		-- upvalues: (ref) v_u_4, (copy) v_u_10, (ref) v_u_6, (ref) v_u_15
		local v17 = v_u_4.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_10,
			["text"] = p16,
			["color"] = v_u_6.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_15 = v_u_15 + 1
		v17.LayoutOrder = v_u_15
		return v17
	end
	local function v22(p19, p20) -- name: note
		-- upvalues: (ref) v_u_4, (copy) v_u_10, (ref) v_u_6, (ref) v_u_15
		local v21 = v_u_4.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_10,
			["text"] = p19,
			["color"] = p20 or v_u_6.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_15 = v_u_15 + 1
		v21.LayoutOrder = v_u_15
		return v21
	end
	local function v_u_23(_) end
	local v_u_24 = false
	local v_u_25 = {}
	local v_u_26 = 0
	local v_u_27 = v_u_14.listMax
	local v28 = "news"
	v18("Broadcast mail  \194\183  all players")
	v22("A letter for every player: online players get it at once, everybody else at their next join. Plain text only. Revoke takes it away from players who have not opened it.")
	local v29 = (p_u_9.inner - 6) / 2
	local v30 = math.floor(v29)
	local v_u_31 = v_u_12
	local v_u_32 = v28
	local v33 = v_u_15
	local v_u_34 = nil
	local v_u_35 = {}
	local function v_u_36() end
	local function v_u_37(_) end
	local v_u_38 = false
	local v_u_39 = nil
	local v_u_40 = {}
	local v_u_41 = ""
	local v_u_42 = {}
	for v43 = 1, 2 do
		local v44 = v_u_4.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = "TagRow" .. v43,
			["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(32))
		}, v_u_10)
		v_u_15 = v33 + 1
		v44.LayoutOrder = v_u_15
		v_u_4.layout(v44, "h", 6)
		v33 = v_u_15
		for v45 = 1, 2 do
			local v_u_46 = v_u_13.TAGS[(v43 - 1) * 2 + v45]
			local v47 = v_u_13.tagLabel(v_u_46)
			local v50, v51 = v_u_4.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v44,
				["text"] = v47,
				["width"] = v30,
				["onClick"] = function()
					-- upvalues: (ref) v_u_32, (copy) v_u_46, (ref) v_u_34, (copy) v_u_35, (ref) v_u_36
					v_u_32 = v_u_46
					v_u_34 = nil
					for v48, v49 in v_u_35 do
						v49.setKind(v48 == v_u_32 and "primary" or "secondary")
					end
					v_u_36()
				end,
				["maxTextWidth"] = (v30 or 160) - 12
			})
			v50.Name = "Tag_" .. v_u_46
			v50.LayoutOrder = v45
			v_u_35[v_u_46] = v51
		end
	end
	for v52, v53 in v_u_35 do
		v53.setKind(v52 == v_u_32 and "primary" or "secondary")
	end
	local v54, v_u_55 = v_u_4.input({
		["parent"] = nil,
		["name"] = "MailSubject",
		["size"] = nil,
		["placeholder"] = nil,
		["parent"] = v_u_10,
		["size"] = UDim2.new(1, 0, 0, v_u_5.touch(36)),
		["placeholder"] = ("Subject (up to %d characters)"):format(v_u_14.subjectMax)
	})
	v_u_15 = v33 + 1
	v54.LayoutOrder = v_u_15
	local v_u_56 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailSubjectCount",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_10,
		["text"] = ("0 / %d"):format(v_u_14.subjectMax),
		["color"] = v_u_6.muted,
		["size"] = UDim2.new(1, 0, 0, 14)
	})
	v_u_15 = v_u_15 + 1
	v_u_56.LayoutOrder = v_u_15
	local v57, v_u_58 = v_u_4.input({
		["parent"] = nil,
		["name"] = "MailBody",
		["size"] = nil,
		["placeholder"] = nil,
		["parent"] = v_u_10,
		["size"] = UDim2.new(1, 0, 0, v_u_5.touch(150)),
		["placeholder"] = ("Message (up to %d characters, line breaks are kept)"):format(v_u_14.bodyMax)
	})
	v_u_15 = v_u_15 + 1
	v57.LayoutOrder = v_u_15
	v_u_58.MultiLine = true
	v_u_58.TextWrapped = true
	v_u_58.TextTruncate = Enum.TextTruncate.None
	v_u_58.TextYAlignment = Enum.TextYAlignment.Top
	v_u_58.Position = UDim2.fromOffset(12, 8)
	v_u_58.Size = UDim2.new(1, -24, 1, -16)
	local v_u_59 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailBodyCount",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_10,
		["text"] = ("0 / %d"):format(v_u_14.bodyMax),
		["color"] = v_u_6.muted,
		["size"] = UDim2.new(1, 0, 0, 14)
	})
	v_u_15 = v_u_15 + 1
	v_u_59.LayoutOrder = v_u_15
	v18("Preview  \194\183  as the players see it")
	local v60 = v_u_4.new("Frame", {
		["Name"] = "MailPreview",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_6.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_10)
	v_u_15 = v_u_15 + 1
	v60.LayoutOrder = v_u_15
	v_u_4.stroke(v60, v_u_6.accentDim)
	v_u_4.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_6.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v60)
	local v61 = v_u_4.new("Frame", {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v60)
	v_u_4.pad(v61, {
		16,
		14,
		10,
		12
	})
	v_u_4.layout(v61, "v", 6)
	local v62 = v_u_4.new("Frame", {
		["Name"] = "Top",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, 0, 0, 18)
	}, v61)
	local v_u_63 = v_u_4.label({
		["parent"] = nil,
		["name"] = "Tag",
		["text"] = "NEWS",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v62,
		["color"] = v_u_6.accent,
		["size"] = UDim2.new(0.6, 0, 1, 0)
	})
	local v_u_64 = v_u_4.label({
		["parent"] = nil,
		["name"] = "Date",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v62,
		["color"] = v_u_6.text2,
		["position"] = UDim2.fromScale(0.6, 0),
		["size"] = UDim2.fromScale(0.4, 1)
	})
	local v_u_65 = v_u_4.label({
		["parent"] = nil,
		["name"] = "Subject",
		["text"] = "",
		["style"] = "bodyStrong",
		["textSize"] = 16,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["size"] = nil,
		["order"] = 2,
		["parent"] = v61,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v_u_66 = v_u_4.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = "",
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["size"] = nil,
		["order"] = 3,
		["parent"] = v61,
		["color"] = v_u_6.text,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_66.TextYAlignment = Enum.TextYAlignment.Top
	local v67 = v_u_15
	for _, v68 in {
		v_u_63,
		v_u_64,
		v_u_65,
		v_u_66
	} do
		v68.RichText = false
	end
	local v_u_69 = {
		["news"] = v_u_6.accent,
		["changelog"] = v_u_6.success,
		["bugs"] = v_u_6.danger,
		["maintenance"] = v_u_6.text
	}
	local function v_u_77()
		-- upvalues: (copy) v_u_13, (ref) v_u_32, (copy) v_u_55, (copy) v_u_58, (copy) v_u_63, (copy) v_u_69, (ref) v_u_6, (copy) v_u_64, (copy) v_u_65, (copy) v_u_66
		local v70, v71 = v_u_13.validate({
			["tag"] = v_u_32,
			["subject"] = v_u_55.Text,
			["body"] = v_u_58.Text
		})
		local v72 = not v70 and {
			["subject"] = v_u_55.Text,
			["body"] = v_u_58.Text
		} or v71
		v_u_63.Text = string.upper(v_u_13.tagLabel(v_u_32)) .. "  \194\183  FROM HUSH"
		v_u_63.TextColor3 = v_u_69[v_u_32] or v_u_6.accent
		v_u_64.Text = v_u_13.dateText(os.time())
		v_u_65.Text = v72.subject == "" and "(no subject yet)" or v72.subject
		local v73 = v_u_65
		local v74
		if v72.subject == "" then
			v74 = v_u_6.muted
		else
			v74 = v_u_6.text
		end
		v73.TextColor3 = v74
		v_u_66.Text = v72.body == "" and "(no message yet)" or v72.body
		local v75 = v_u_66
		local v76
		if v72.body == "" then
			v76 = v_u_6.muted
		else
			v76 = v_u_6.text
		end
		v75.TextColor3 = v76
	end
	local v_u_78 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_10,
		["color"] = v_u_6.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_15 = v67 + 1
	v_u_78.LayoutOrder = v_u_15
	v_u_78.Visible = false
	local v_u_79 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailOk",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_10,
		["color"] = v_u_6.success,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_15 = v_u_15 + 1
	v_u_79.LayoutOrder = v_u_15
	v_u_79.Visible = false
	local function v96() -- name: onChange
		-- upvalues: (ref) v_u_34, (copy) v_u_55, (copy) v_u_14, (copy) v_u_58, (copy) v_u_56, (copy) v_u_59, (ref) v_u_38, (ref) v_u_8, (ref) v_u_39, (ref) v_u_77
		v_u_34 = nil
		local v80 = v_u_55
		local v81 = v_u_55.Text
		local v82 = v_u_14.subjectMax
		local v83 = utf8.len(v81)
		if v83 ~= nil and v83 > v82 then
			local v84 = utf8.offset(v81, v82 + 1)
			if v84 then
				local v85 = v84 - 1
				v81 = string.sub(v81, 1, v85)
			end
		end
		v80.Text = v81
		local v86 = v_u_58
		local v87 = v_u_58.Text
		local v88 = v_u_14.bodyMax
		local v89 = utf8.len(v87)
		if v89 ~= nil and v89 > v88 then
			local v90 = utf8.offset(v87, v88 + 1)
			if v90 then
				local v91 = v90 - 1
				v87 = string.sub(v87, 1, v91)
			end
		end
		v86.Text = v87
		local v92 = v_u_56
		local v93 = v_u_55.Text
		v92.Text = ("%d / %d"):format(utf8.len(v93) or #v93, v_u_14.subjectMax)
		local v94 = v_u_59
		local v95 = v_u_58.Text
		v94.Text = ("%d / %d"):format(utf8.len(v95) or #v95, v_u_14.bodyMax)
		if v_u_38 then
			v_u_38 = false
			v_u_8:SetAttribute("FilmMailConfirm", false)
			if v_u_39 then
				v_u_39.setText("Send to all players")
				v_u_39.setKind("primary")
			end
		end
		v_u_77()
	end
	v_u_55:GetPropertyChangedSignal("Text"):Connect(v96)
	v_u_58:GetPropertyChangedSignal("Text"):Connect(v96)
	local function v_u_100(p97) -- name: setBusy
		-- upvalues: (ref) v_u_24, (ref) v_u_39, (copy) v_u_40, (ref) v_u_8, (ref) v_u_25, (ref) v_u_32
		v_u_24 = p97
		if v_u_39 then
			v_u_39.setEnabled(not p97)
		end
		for _, v98 in v_u_40 do
			v98.setEnabled(not p97)
		end
		local v99 = v_u_24
		v_u_8:SetAttribute("FilmMail", ("%d|%s|%s"):format(#v_u_25, tostring(v99), v_u_32))
	end
	local function v_u_106(p101) -- name: apply
		-- upvalues: (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (copy) v_u_14, (ref) v_u_8, (ref) v_u_24, (ref) v_u_32, (ref) v_u_37
		if type(p101) == "table" then
			local v102 = p101.items
			if type(v102) == "table" then
				v_u_25 = p101.items
				local v103 = p101.count
				v_u_26 = tonumber(v103) or #v_u_25
				local v104 = p101.max
				v_u_27 = tonumber(v104) or v_u_14.listMax
				local v105 = v_u_24
				v_u_8:SetAttribute("FilmMail", ("%d|%s|%s"):format(#v_u_25, tostring(v105), v_u_32))
				v_u_37()
				return
			end
		end
	end
	local function v_u_116() -- name: doSend
		-- upvalues: (ref) v_u_24, (copy) v_u_13, (ref) v_u_32, (copy) v_u_55, (copy) v_u_58, (copy) v_u_78, (ref) v_u_8, (ref) v_u_34, (ref) v_u_2, (copy) v_u_79, (copy) v_u_100, (ref) v_u_39, (copy) v_u_11, (copy) v_u_106
		if v_u_24 then
			return
		else
			local v107, v108 = v_u_13.validate({
				["tag"] = v_u_32,
				["subject"] = v_u_55.Text,
				["body"] = v_u_58.Text
			})
			if v107 then
				v_u_34 = v_u_34 or v_u_2:GenerateGUID(false)
				local v109 = {
					["tag"] = v_u_32,
					["subject"] = v_u_55.Text,
					["body"] = v_u_58.Text,
					["nonce"] = v_u_34
				}
				v_u_78.Text = ""
				v_u_78.Visible = false
				v_u_8:SetAttribute("FilmMailError", "")
				v_u_79.Visible = false
				v_u_100(true)
				v_u_39.setText("Sending...")
				v_u_11.call("mail.send", {
					["draft"] = v109
				}, function(p110)
					-- upvalues: (ref) v_u_100, (ref) v_u_39, (ref) v_u_55, (ref) v_u_58, (ref) v_u_34, (ref) v_u_79, (ref) v_u_106, (ref) v_u_78, (ref) v_u_8
					v_u_100(false)
					v_u_39.setText("Send to all players")
					v_u_39.setKind("primary")
					if p110 and p110.ok then
						v_u_55.Text = ""
						v_u_58.Text = ""
						v_u_34 = nil
						local v111 = v_u_79
						local v112 = p110.msg or "Sent."
						v111.Text = tostring(v112)
						v_u_79.Visible = true
						v_u_106(p110.data)
					else
						local v113 = p110 and p110.msg or "The server did not answer."
						local v114 = tostring(v113) or ""
						v_u_78.Text = v114
						v_u_78.Visible = v114 ~= ""
						v_u_8:SetAttribute("FilmMailError", v114)
					end
				end)
			else
				local v115 = tostring(v108) or ""
				v_u_78.Text = v115
				v_u_78.Visible = v115 ~= ""
				v_u_8:SetAttribute("FilmMailError", v115)
			end
		end
	end
	local v117 = p_u_9.inner
	local function v121()
		-- upvalues: (ref) v_u_24, (copy) v_u_13, (ref) v_u_32, (copy) v_u_55, (copy) v_u_58, (copy) v_u_78, (ref) v_u_8, (ref) v_u_38, (ref) v_u_39, (ref) v_u_31, (copy) v_u_116
		if v_u_24 then
			return
		else
			local v118, v119 = v_u_13.validate({
				["tag"] = v_u_32,
				["subject"] = v_u_55.Text,
				["body"] = v_u_58.Text
			})
			if v118 then
				v_u_78.Text = ""
				v_u_78.Visible = false
				v_u_8:SetAttribute("FilmMailError", "")
				if v_u_38 then
					v_u_38 = false
					v_u_8:SetAttribute("FilmMailConfirm", false)
					v_u_116()
				else
					v_u_38 = true
					v_u_8:SetAttribute("FilmMailConfirm", true)
					v_u_39.setText("Click again: send to ALL players now")
					v_u_39.setKind("danger")
					task.delay(5, function()
						-- upvalues: (ref) v_u_31, (ref) v_u_38, (ref) v_u_24, (ref) v_u_8, (ref) v_u_39
						if v_u_31 and (v_u_38 and not v_u_24) then
							v_u_38 = false
							v_u_8:SetAttribute("FilmMailConfirm", false)
							v_u_39.setText("Send to all players")
							v_u_39.setKind("primary")
						end
					end)
				end
			else
				local v120 = tostring(v119) or ""
				v_u_78.Text = v120
				v_u_78.Visible = v120 ~= ""
				v_u_8:SetAttribute("FilmMailError", v120)
				return
			end
		end
	end
	local v122, v123 = v_u_4.button({
		["parent"] = nil,
		["text"] = "Send to all players",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_10,
		["width"] = v117,
		["onClick"] = v121,
		["maxTextWidth"] = (v117 or 160) - 12
	})
	local v124 = v123
	v122.Name = "MailSend"
	v_u_15 = v_u_15 + 1
	v122.LayoutOrder = v_u_15
	v18("Sent mails  \194\183  newest first")
	local v125 = v_u_4.new("Frame", {
		["Name"] = "MailHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(32))
	}, v_u_10)
	v_u_15 = v_u_15 + 1
	v125.LayoutOrder = v_u_15
	v_u_4.layout(v125, "h", 6)
	local v_u_126 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailCount",
		["text"] = "...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v125,
		["color"] = v_u_6.text2,
		["size"] = UDim2.fromOffset(p_u_9.inner - 126, v_u_5.touch(32))
	})
	v_u_126.LayoutOrder = 1
	local v127 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v125,
		["onClick"] = function()
			-- upvalues: (copy) v_u_78, (ref) v_u_8, (ref) v_u_23
			v_u_78.Text = ""
			v_u_78.Visible = false
			v_u_8:SetAttribute("FilmMailError", "")
			v_u_23(false)
		end
	}
	local v128, _ = v_u_4.button(v127)
	v128.Name = "MailRefresh"
	v128.LayoutOrder = 2
	local v_u_129 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailListError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_10,
		["color"] = v_u_6.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_15 = v_u_15 + 1
	v_u_129.LayoutOrder = v_u_15
	v_u_129.Visible = false
	local v_u_130 = v_u_4.new("Frame", {
		["Name"] = "MailList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_10)
	v_u_15 = v_u_15 + 1
	v_u_130.LayoutOrder = v_u_15
	v_u_4.layout(v_u_130, "v", 8)
	local v_u_131 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailEmpty",
		["text"] = "Nothing sent yet.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_130,
		["color"] = v_u_6.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_131.LayoutOrder = 0
	v18("Delivery mail  \194\183  test states")
	v22("Shows the mail window of a player who buys in the Blackmarket and the store: fake data, no server. Open the main menu first (the PLAY tab shows the badge), then pick a state and OPEN MAIL.")
	local v_u_132 = v_u_4.label({
		["parent"] = nil,
		["name"] = "MailStateLine",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_10,
		["color"] = v_u_6.success,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_15 = v_u_15 + 1
	v_u_132.LayoutOrder = v_u_15
	v_u_132.Visible = false
	local function v_u_137() -- name: railAndCtx
		local v_u_133 = script.Parent:FindFirstChild("MenuRail")
		local v134, v135 = pcall(function()
			-- upvalues: (copy) v_u_133
			if v_u_133 and v_u_133:IsA("ModuleScript") then
				return require(v_u_133)
			else
				return nil
			end
		end)
		if v134 and type(v135) == "table" then
			local v136 = v135.menuCtx
			if type(v136) == "function" then
				return v135, v135.menuCtx()
			end
		end
		return v135, nil
	end
	local function v147(p138, p_u_139) -- name: stateBtn
		-- upvalues: (copy) v_u_137, (copy) v_u_132, (ref) v_u_6, (ref) v_u_8
		return p138, function()
			-- upvalues: (ref) v_u_137, (ref) v_u_132, (ref) v_u_6, (ref) v_u_8, (copy) p_u_139
			local v140, v141 = v_u_137()
			if v141 then
				local v142 = p_u_139
				local v143, v144 = pcall(v142, v140, v141)
				if v143 then
					local v145 = v144 or ""
					v_u_132.Text = v145
					v_u_132.TextColor3 = v_u_6.success
					v_u_132.Visible = v145 ~= ""
					v_u_8:SetAttribute("FilmMailState", v145)
				else
					local v146 = "That did not work: " .. tostring(v144)
					v_u_132.Text = v146
					v_u_132.TextColor3 = v_u_6.danger
					v_u_132.Visible = v146 ~= ""
					v_u_8:SetAttribute("FilmMailState", v146)
				end
			else
				v_u_132.Text = "The main menu is not built yet. Open the menu first."
				v_u_132.TextColor3 = v_u_6.danger
				v_u_132.Visible = true
				v_u_8:SetAttribute("FilmMailState", "The main menu is not built yet. Open the menu first.")
				return
			end
		end
	end
	local v186 = {
		{ v147("Deliveries", function(p148, p149)
				p148.setStub(p149, "mail", "deliveries")
				return "Fake mailbox: 3 Blackmarket deliveries (12 d, 2 d 4 h, 5 h), a store package of 9 items."
			end) },
		{ v147("Mixed", function(p150, p151)
				p150.setStub(p151, "mail", "mixed")
				return "Fake mailbox: the deliveries and 3 insurance returns."
			end) },
		{ v147("Expired note", function(p152, p153)
				p152.setStub(p153, "mail", "expiry")
				return "Fake mailbox: the deliveries and the note \"2 deliveries expired\"."
			end) },
		{ v147("Full stash", function(p154, p155)
				p154.setStub(p155, "mail", "full")
				return "Fake mailbox: every claim meets a full stash."
			end) },
		{ v147("Insurance only", function(p156, p157)
				p156.setStub(p157, "mail", 3)
				return "Fake mailbox: 3 insurance returns, as before the delivery mail."
			end) },
		{ v147("Empty", function(p158, p159)
				p158.setStub(p159, "mail", "empty")
				return "Fake mailbox: nothing in it."
			end) },
		{ v147("Guide: store", function(_, p_u_160)
				local v_u_161 = "MailGuide"
				local v162, v163 = pcall(function()
					-- upvalues: (copy) p_u_160, (copy) v_u_161
					return p_u_160.cctx.lib[v_u_161]
				end)
				if not v162 or type(v163) ~= "table" then
					v163 = nil
				end
				if not v163 then
					return "No MailGuide module."
				end
				local v164 = v163.demo
				return "Guide (first store purchase): " .. tostring(v164(p_u_160, "store", true))
			end) },
		{ v147("Guide: market", function(_, p_u_165)
				local v_u_166 = "MailGuide"
				local v167, v168 = pcall(function()
					-- upvalues: (copy) p_u_165, (copy) v_u_166
					return p_u_165.cctx.lib[v_u_166]
				end)
				if not v167 or type(v168) ~= "table" then
					v168 = nil
				end
				if not v168 then
					return "No MailGuide module."
				end
				local v169 = v168.demo
				return "Guide (first market purchase): " .. tostring(v169(p_u_165, "bm", true))
			end) },
		{ v147("Toast: store", function(_, p_u_170)
				local v_u_171 = "MailGuide"
				local v172, v173 = pcall(function()
					-- upvalues: (copy) p_u_170, (copy) v_u_171
					return p_u_170.cctx.lib[v_u_171]
				end)
				if not v172 or type(v173) ~= "table" then
					v173 = nil
				end
				if not v173 then
					return "No MailGuide module."
				end
				local v174 = v173.demo
				return "A later store purchase: " .. tostring(v174(p_u_170, "store", false))
			end) },
		{ v147("Toast: market", function(_, p_u_175)
				local v_u_176 = "MailGuide"
				local v177, v178 = pcall(function()
					-- upvalues: (copy) p_u_175, (copy) v_u_176
					return p_u_175.cctx.lib[v_u_176]
				end)
				if not v177 or type(v178) ~= "table" then
					v178 = nil
				end
				if not v178 then
					return "No MailGuide module."
				end
				local v179 = v178.demo
				return "A later market purchase: " .. tostring(v179(p_u_175, "bm", false))
			end) },
		{ v147("Open mail", function(_, p_u_180)
				local v_u_181 = "MenuMail"
				local v182, v183 = pcall(function()
					-- upvalues: (copy) p_u_180, (copy) v_u_181
					return p_u_180.cctx.lib[v_u_181]
				end)
				if not v182 or type(v183) ~= "table" then
					v183 = nil
				end
				if v183 then
					v183.open(p_u_180, nil, {
						["view"] = "deliveries"
					})
				end
				return "The mail window."
			end) },
		{ v147("Stub off", function(p184, p185)
				p184.setStub(p185, "mail", -1)
				return "The real mailbox is back."
			end) }
	}
	local v_u_187 = v_u_77
	local v_u_188 = v124
	local v189 = v_u_15
	for v190 = 1, #v186 // 2 do
		local v191 = v_u_4.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = "StateRow" .. v190,
			["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(32))
		}, v_u_10)
		v_u_15 = v189 + 1
		v191.LayoutOrder = v_u_15
		v_u_4.layout(v191, "h", 6)
		v189 = v_u_15
		for v192 = 1, 2 do
			local v193 = v186[(v190 - 1) * 2 + v192]
			local v194 = v193[1]
			local v195 = v193[2]
			local v196, _ = v_u_4.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v191,
				["text"] = v194,
				["width"] = v30,
				["onClick"] = v195,
				["maxTextWidth"] = (v30 or 160) - 12
			})
			v196.Name = "State_" .. string.gsub(v193[1], "%W", "")
			v196.LayoutOrder = v192
		end
	end
	local function v_u_204(p197, p198) -- name: doRevoke
		-- upvalues: (ref) v_u_24, (copy) v_u_100, (copy) v_u_11, (copy) v_u_129, (copy) v_u_106, (copy) v_u_79, (ref) v_u_37
		if not v_u_24 then
			v_u_100(true)
			p198.setText("Revoking...")
			v_u_11.call("mail.revoke", {
				["id"] = p197.id
			}, function(p199)
				-- upvalues: (ref) v_u_100, (ref) v_u_129, (ref) v_u_106, (ref) v_u_79, (ref) v_u_37
				v_u_100(false)
				if p199 and p199.ok then
					v_u_129.Visible = false
					v_u_106(p199.data)
					local v200 = v_u_79
					local v201 = p199.msg or "Revoked."
					v200.Text = tostring(v201)
					v_u_79.Visible = true
				else
					local v202 = v_u_129
					local v203 = p199 and p199.msg or "The server did not answer."
					v202.Text = tostring(v203)
					v_u_129.Visible = true
					v_u_37(true)
				end
			end)
		end
	end
	local function v_u_241(p_u_205, p206) -- name: buildCard
		-- upvalues: (ref) v_u_4, (ref) v_u_6, (copy) v_u_130, (copy) v_u_13, (copy) v_u_42, (copy) p_u_9, (copy) v_u_204, (ref) v_u_37, (ref) v_u_31, (copy) v_u_40, (ref) v_u_24
		local v207 = v_u_4.new
		local v208 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil
		}
		local v209 = p_u_205.id
		v208.Name = "Mail_" .. tostring(v209)
		v208.BackgroundColor3 = v_u_6.raised
		v208.Size = UDim2.new(1, 0, 0, 0)
		v208.AutomaticSize = Enum.AutomaticSize.Y
		v208.LayoutOrder = p206
		local v210 = v207("Frame", v208, v_u_130)
		local v211 = v_u_4.stroke
		local v212
		if p_u_205.revoked then
			v212 = v_u_6.line
		else
			v212 = v_u_6.accentDim
		end
		v211(v210, v212)
		v_u_4.pad(v210, {
			10,
			10,
			8,
			10
		})
		v_u_4.layout(v210, "v", 6)
		local v213 = v_u_4.label
		local v214 = {
			["parent"] = nil,
			["name"] = "Meta",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v210
		}
		local v215 = p_u_205.id
		local v216 = p_u_205.label
		v214.text = ("#%d  \194\183  %s  \194\183  %s  \194\183  %s"):format(v215, tostring(v216), v_u_13.dateText(p_u_205.at), p_u_205.revoked and "REVOKED" or "LIVE")
		local v217
		if p_u_205.revoked then
			v217 = v_u_6.muted
		else
			v217 = v_u_6.success
		end
		v214.color = v217
		v214.size = UDim2.new(1, 0, 0, 0)
		local v218 = v213(v214)
		v218.LayoutOrder = 1
		v218.RichText = false
		local v219 = v_u_4.label
		local v220 = {
			["parent"] = nil,
			["name"] = "Subject",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v210
		}
		local v221 = p_u_205.subject
		v220.text = tostring(v221)
		local v222
		if p_u_205.revoked then
			v222 = v_u_6.muted
		else
			v222 = v_u_6.text
		end
		v220.color = v222
		v220.size = UDim2.new(1, 0, 0, 0)
		local v223 = v219(v220)
		v223.LayoutOrder = 2
		v223.RichText = false
		local v224 = v_u_4.label
		local v225 = {
			["parent"] = nil,
			["name"] = "Info",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v210
		}
		local v226 = p_u_205.chars
		local v227 = tonumber(v226) or 0
		local v228 = p_u_205.chars
		local v229 = tonumber(v228) == 1 and "character" or "characters"
		local v230 = p_u_205.byName or ""
		v225.text = ("%d %s  \194\183  sent by %s"):format(v227, v229, (tostring(v230)))
		v225.color = v_u_6.muted
		v225.size = UDim2.new(1, 0, 0, 14)
		local v231 = v224(v225)
		v231.LayoutOrder = 3
		v231.RichText = false
		if not p_u_205.revoked then
			local v232
			if v_u_42[p_u_205.id] == nil then
				v232 = false
			else
				v232 = os.clock() - v_u_42[p_u_205.id] < 5
			end
			local v_u_233 = nil
			local v234 = p_u_9.inner - 20
			local function v236()
				-- upvalues: (ref) v_u_42, (copy) p_u_205, (ref) v_u_204, (ref) v_u_233, (ref) v_u_37, (ref) v_u_31
				local v235 = v_u_42[p_u_205.id]
				if v235 == nil or os.clock() - v235 >= 5 then
					v_u_42[p_u_205.id] = os.clock()
					v_u_37(true)
					task.delay(5.2, function()
						-- upvalues: (ref) v_u_31, (ref) v_u_42, (ref) p_u_205, (ref) v_u_37
						if v_u_31 and (v_u_42[p_u_205.id] ~= nil and os.clock() - v_u_42[p_u_205.id] >= 5) then
							v_u_42[p_u_205.id] = nil
							v_u_37(true)
						end
					end)
				else
					v_u_42[p_u_205.id] = nil
					v_u_204(p_u_205, v_u_233)
				end
			end
			local v237, v238 = v_u_4.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "danger",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v210,
				["text"] = v232 and "Click again to revoke" or "Revoke",
				["width"] = v234,
				["onClick"] = v236,
				["maxTextWidth"] = (v234 or 160) - 12
			})
			v_u_233 = v238
			v237.Name = "MailRevoke"
			v237.LayoutOrder = 4
			if v232 then
				v_u_4.stroke(v237, v_u_6.danger)
			end
			local v239 = v_u_40
			local v240 = v_u_233
			table.insert(v239, v240)
			if v_u_24 then
				v_u_233.setEnabled(false)
			end
		end
	end
	local function _(p242)
		-- upvalues: (ref) v_u_2, (ref) v_u_25, (ref) v_u_26, (copy) v_u_42, (copy) v_u_126, (ref) v_u_27, (ref) v_u_41, (copy) v_u_130, (copy) v_u_131, (copy) v_u_40, (copy) v_u_241
		local v243 = v_u_26
		local v244 = v_u_2:JSONEncode(v_u_25) .. "|" .. tostring(v243)
		for v245, v246 in v_u_42 do
			local v247 = tostring(v245)
			local v248 = os.clock() - v246 < 5
			v244 = v244 .. "|c" .. v247 .. tostring(v248)
		end
		v_u_126.Text = ("%d of %d mails in the list"):format(v_u_26, v_u_27)
		if v244 ~= v_u_41 or p242 == true then
			v_u_41 = v244
			for _, v249 in v_u_130:GetChildren() do
				if not v249:IsA("GuiObject") or v249 == v_u_131 then
					continue
				end
				v249:Destroy()
			end
			table.clear(v_u_40)
			v_u_131.Visible = #v_u_25 == 0
			for v250, v251 in v_u_25 do
				v_u_241(v251, v250)
			end
		end
	end
	local function v_u_257(p_u_252)
		-- upvalues: (copy) v_u_129, (copy) v_u_106, (copy) v_u_11
		local function v256(p253) -- name: done
			-- upvalues: (ref) v_u_129, (ref) v_u_106, (copy) p_u_252
			if p253 and p253.ok then
				v_u_129.Visible = false
				v_u_106(p253.data)
			elseif not p_u_252 then
				local v254 = v_u_129
				local v255 = p253 and p253.msg or "The server did not answer."
				v254.Text = tostring(v255)
				v_u_129.Visible = true
			end
		end
		if p_u_252 then
			v_u_11.callQuiet("mail.list", {}, v256)
		else
			v_u_11.call("mail.list", {}, v256)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_31, (copy) p_u_9, (copy) v_u_10, (ref) v_u_24, (ref) v_u_257
		local v258 = false
		local v259 = 0
		while v_u_31 do
			local v260 = p_u_9.gui.Enabled
			if v260 then
				v260 = v_u_10.Visible
			end
			if v260 and (not v258 and p_u_9.handle) then
				local v261 = p_u_9.handle.status
				if type(v261) == "function" then
					local v262 = p_u_9.handle.status
					pcall(v262, "Mail to all players.")
				end
			end
			if v260 and (not v258 or os.clock() - v259 >= 20) and not v_u_24 then
				v259 = os.clock()
				v_u_257(true)
			end
			task.wait(0.3)
			v258 = v260
		end
	end)
	v_u_187()
	return {
		["refresh"] = function() -- name: refresh
			-- upvalues: (ref) v_u_257
			v_u_257(false)
		end,
		["list"] = function() -- name: list
			-- upvalues: (ref) v_u_25
			return v_u_25
		end,
		["setDraft"] = function(p263, p264, p265) -- name: setDraft
			-- upvalues: (ref) v_u_32, (copy) v_u_35, (copy) v_u_55, (copy) v_u_58, (ref) v_u_187
			v_u_32 = p263
			for v266, v267 in v_u_35 do
				v267.setKind(v266 == v_u_32 and "primary" or "secondary")
			end
			v_u_55.Text = p264
			v_u_58.Text = p265
			v_u_187()
		end,
		["send"] = function() -- name: send
			-- upvalues: (copy) v_u_116
			v_u_116()
		end,
		["formState"] = function() -- name: formState
			-- upvalues: (ref) v_u_32, (copy) v_u_55, (copy) v_u_58, (copy) v_u_78, (copy) v_u_79, (ref) v_u_24, (ref) v_u_38, (ref) v_u_25, (copy) v_u_65, (copy) v_u_66, (copy) v_u_63, (ref) v_u_188
			return {
				["tag"] = v_u_32,
				["subject"] = v_u_55.Text,
				["body"] = v_u_58.Text,
				["error"] = v_u_78.Text,
				["ok"] = v_u_79.Text,
				["busy"] = v_u_24,
				["confirming"] = v_u_38,
				["items"] = #v_u_25,
				["previewSubject"] = v_u_65.Text,
				["previewBody"] = v_u_66.Text,
				["previewTag"] = v_u_63.Text,
				["previewRich"] = v_u_66.RichText or v_u_65.RichText,
				["sendText"] = not v_u_188 and "" or v_u_188.label.Text
			}
		end
	}
end
return v7