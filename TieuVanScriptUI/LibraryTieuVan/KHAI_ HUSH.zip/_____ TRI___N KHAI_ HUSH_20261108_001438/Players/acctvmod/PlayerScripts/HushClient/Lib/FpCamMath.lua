-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpCamMath

local v_u_1 = {
	["DEG_PER_PX"] = 0.12,
	["PITCH_LIMIT"] = 1.3962634015954636,
	["PAD_EXPONENT"] = 1.7,
	["PAD_YAW_DEG"] = 240,
	["PAD_PITCH_DEG"] = 160,
	["PAD_ADS_FACTOR"] = 0.55,
	["PAD_FRICTION"] = 0.65,
	["PAD_FRICTION_DEG"] = 2.5,
	["LOCK_RATE"] = 14,
	["LOCK_YAW_DEG_S"] = 90,
	["LOCK_PITCH_DEG_S"] = 90,
	["LOCK_TAIL_DEG"] = 0.05,
	["TOGGLE_TIME"] = 0.25,
	["ADS_TIME"] = 0.18,
	["FOV_DEFAULT"] = 75,
	["FOV_BASE_MAX"] = 90,
	["FOV_KEEN_MAX"] = { 95, 100 }
}
local v_u_2 = v_u_1.FOV_BASE_MAX
v_u_1.SPRING_OMEGA = 18
v_u_1.EYE_UP = 0.12
v_u_1.EYE_FORWARD = 0.28
v_u_1.EYE_SNAP_Y = 5
v_u_1.EYE_MAX_LAG = 1.2
v_u_1.TP = {
	["pivotUp"] = 1.9,
	["right"] = 1.55,
	["up"] = 0.35,
	["back"] = 5.2,
	["radius"] = 0.4,
	["minDist"] = 0.8,
	["fadeBelow"] = 1.5,
	["fadeLeave"] = 1.8,
	["recoverSpeed"] = 12,
	["downedPivotUp"] = 0.9,
	["downedBack"] = 4.2,
	["downedUp"] = 0.2
}
v_u_1.DEATH_FALL = 1.5
v_u_1.DEATH_DROP = 0.5
v_u_1.DEATH_ROLL_DEG = 45
v_u_1.DEATH_PITCH_DEG = 15
v_u_1.DEATH_ORBIT_DEG_PER_S = 10
v_u_1.DEATH_ORBIT_DIST = 7.5
v_u_1.DEATH_ORBIT_PITCH_DEG = 22
v_u_1.DEATH_ORBIT_PIVOT_UP = 1.2
v_u_1.CHASE_PITCH_LIMIT = 1.0471975511965976
v_u_1.BOB_CYCLE_STUDS = 9
v_u_1.BOB_WALK = 0.05
v_u_1.BOB_SPRINT = 0.09
v_u_1.BOB_ROLL_DEG = 0.6
v_u_1.KICK_MAX_PITCH_DEG = 12
v_u_1.KICK_MAX_YAW_DEG = 6
v_u_1.BODY_HIDDEN = 1
v_u_1.BODY_HALF = 0.5
v_u_1.BODY_SHOWN = 0
v_u_1.SETTINGS = {
	{
		["key"] = "fov",
		["attr"] = "Fov",
		["kind"] = "number",
		["default"] = 75,
		["lo"] = 50,
		["hi"] = 90
	},
	{
		["key"] = "sensitivity",
		["attr"] = "Sensitivity",
		["kind"] = "number",
		["default"] = 1,
		["lo"] = 0.1,
		["hi"] = 6
	},
	{
		["key"] = "fpAdsSens",
		["attr"] = "FpAdsSens",
		["kind"] = "number",
		["default"] = 1,
		["lo"] = 0.2,
		["hi"] = 2
	},
	{
		["key"] = "fpPadSens",
		["attr"] = "FpPadSens",
		["kind"] = "number",
		["default"] = 1,
		["lo"] = 0.2,
		["hi"] = 6
	},
	{
		["key"] = "fpTouchSens",
		["attr"] = "FpTouchSens",
		["kind"] = "number",
		["default"] = 1,
		["lo"] = 0.2,
		["hi"] = 6
	},
	{
		["key"] = "fpInvertY",
		["attr"] = "FpInvertY",
		["kind"] = "boolean",
		["default"] = false
	},
	{
		["key"] = "fpBob",
		["attr"] = "FpBob",
		["kind"] = "number",
		["default"] = 0.6,
		["lo"] = 0,
		["hi"] = 1
	},
	{
		["key"] = "fpSway",
		["attr"] = "FpSway",
		["kind"] = "number",
		["default"] = 0.6,
		["lo"] = 0,
		["hi"] = 1
	},
	{
		["key"] = "fpShoulder",
		["attr"] = "FpShoulder",
		["kind"] = "enum",
		["default"] = "right",
		["values"] = nil,
		["values"] = { "right", "left" }
	}
}
local v_u_3 = {}
for _, v4 in v_u_1.SETTINGS do
	v_u_3[v4.key] = v4
end
function v_u_1.fovCeilFor(p5) -- name: fovCeilFor
	-- upvalues: (copy) v_u_1
	if type(p5) == "number" and (p5 == p5 and p5 >= 1) then
		if p5 >= 2 then
			return v_u_1.FOV_KEEN_MAX[2]
		else
			return v_u_1.FOV_KEEN_MAX[1]
		end
	else
		return v_u_1.FOV_BASE_MAX
	end
end
function v_u_1.setFovCeil(p6) -- name: setFovCeil
	-- upvalues: (copy) v_u_1, (ref) v_u_2
	if type(p6) == "number" and (p6 == p6 and v_u_1.FOV_BASE_MAX < p6) then
		local v7 = v_u_1.FOV_KEEN_MAX[2]
		v_u_2 = math.min(p6, v7)
	else
		v_u_2 = v_u_1.FOV_BASE_MAX
	end
end
function v_u_1.fovCeilNow() -- name: fovCeilNow
	-- upvalues: (ref) v_u_2
	return v_u_2
end
function v_u_1.readSetting(p8, p9) -- name: readSetting
	-- upvalues: (copy) v_u_3, (ref) v_u_2
	local v10 = v_u_3[p8]
	if v10 == nil then
		return nil
	elseif v10.kind == "number" then
		if type(p9) ~= "number" or p9 ~= p9 then
			return v10.default
		end
		local v11 = v10.lo
		local v12
		if p8 == "fov" then
			v12 = v_u_2
		else
			v12 = v10.hi
		end
		return math.clamp(p9, v11, v12)
	elseif v10.kind == "boolean" then
		if type(p9) == "boolean" then
			return p9
		else
			return v10.default
		end
	else
		for _, v13 in v10.values do
			if p9 ~= v13 then
				continue
			end
			return p9
		end
		return v10.default
	end
end
function v_u_1.defaultOf(p14) -- name: defaultOf
	-- upvalues: (copy) v_u_3
	local v15 = v_u_3[p14]
	if v15 then
		return v15.default
	else
		return nil
	end
end
function v_u_1.sideOf(p16) -- name: sideOf
	return p16 == "tp" and "tp" or "fp"
end
function v_u_1.wrapYaw(p17) -- name: wrapYaw
	if p17 ~= p17 then
		return 0
	end
	local v18 = (p17 + 3.141592653589793) % 6.283185307179586
	if v18 < 0 then
		v18 = v18 + 6.283185307179586
	end
	local v19 = v18 - 3.141592653589793
	return v19 <= -3.141592653589793 and 3.141592653589793 or v19
end
function v_u_1.clampPitch(p20) -- name: clampPitch
	-- upvalues: (copy) v_u_1
	if p20 ~= p20 then
		return 0
	end
	local v21 = -v_u_1.PITCH_LIMIT
	local v22 = v_u_1.PITCH_LIMIT
	return math.clamp(p20, v21, v22)
end
function v_u_1.lookDir(p23, p24) -- name: lookDir
	local v25 = math.cos(p24)
	return -math.sin(p23) * v25, math.sin(p24), -math.cos(p23) * v25
end
function v_u_1.angleDeg(p26, p27, p28, p29, p30, p31) -- name: angleDeg
	local v32 = p26 * p26 + p27 * p27 + p28 * p28
	local v33 = math.sqrt(v32)
	local v34 = p29 * p29 + p30 * p30 + p31 * p31
	local v35 = math.sqrt(v34)
	if v33 < 1e-9 or v35 < 1e-9 then
		return 180
	end
	local v36 = p27 * p31 - p28 * p30
	local v37 = p28 * p29 - p26 * p31
	local v38 = p26 * p30 - p27 * p29
	local v39 = v36 * v36 + v37 * v37 + v38 * v38
	local v40 = math.sqrt(v39)
	local v41 = p26 * p29 + p27 * p30 + p28 * p31
	local v42 = math.atan2(v40, v41)
	return math.deg(v42)
end
function v_u_1.smoothAngle(p43, p44, p45, p46) -- name: smoothAngle
	-- upvalues: (copy) v_u_1
	local v47 = v_u_1.wrapYaw(p44 - p43)
	local v48 = -p45 * math.max(p46, 0)
	local v49 = 1 - math.exp(v48)
	return v_u_1.wrapYaw(p43 + v47 * v49)
end
function v_u_1.approachAngle(p50, p51, p52, p53) -- name: approachAngle
	-- upvalues: (copy) v_u_1
	local v54 = v_u_1.wrapYaw(p51 - p50)
	local v55 = math.max(p52, 0) * math.max(p53, 0)
	local v56 = v_u_1.wrapYaw
	local v57 = -v55
	return v56(p50 + math.clamp(v54, v57, v55))
end
function v_u_1.lockStep(p58, p59, p60, p61, p62) -- name: lockStep
	-- upvalues: (copy) v_u_1
	local v63 = math.max(p62, 0)
	local v64 = -v_u_1.LOCK_RATE * v63
	local v65 = 1 - math.exp(v64)
	local v66 = v_u_1.LOCK_YAW_DEG_S
	local v67 = math.rad(v66) * v63
	local v68 = v_u_1.LOCK_PITCH_DEG_S
	local v69 = math.rad(v68) * v63
	local v70 = v_u_1.wrapYaw(p60 - p58) * v65
	local v71 = -v67
	local v72 = math.clamp(v70, v71, v67)
	local v73 = (v_u_1.clampPitch(p61) - p59) * v65
	local v74 = -v69
	local v75 = math.clamp(v73, v74, v69)
	return v_u_1.wrapYaw(p58 + v72), v_u_1.clampPitch(p59 + v75)
end
function v_u_1.tailStep(p76, p77, p78, p79, p80) -- name: tailStep
	-- upvalues: (copy) v_u_1
	local v81, v82 = v_u_1.lockStep(p76, p77, p78, p79, p80)
	local v83 = v_u_1.LOCK_TAIL_DEG
	local v84 = math.rad(v83)
	local v85 = v_u_1.wrapYaw(p78 - v81)
	local v86
	if math.abs(v85) <= v84 then
		local v87 = v_u_1.clampPitch(p79) - v82
		v86 = math.abs(v87) <= v84
	else
		v86 = false
	end
	return v81, v82, v86
end
function v_u_1.adsLookFactor(p88, p89, p90, p91) -- name: adsLookFactor
	local v92 = math.clamp(p88, 0, 1)
	if v92 <= 0 then
		return 1
	end
	local v93
	if p90 == nil or p91 <= 0 then
		v93 = 1
	else
		local v94 = p90 / p91
		v93 = math.clamp(v94, 0.05, 1.5)
	end
	return (p89 * v93 - 1) * v92 + 1
end
function v_u_1.mouseLook(p95, p96, p97, p98, p99, p100, p101) -- name: mouseLook
	-- upvalues: (copy) v_u_1
	local v102 = v_u_1.DEG_PER_PX * p99 * p100
	local v103 = v_u_1.wrapYaw
	local v104 = p97 * v102
	local v105 = v103(p95 - math.rad(v104))
	local v106 = v_u_1.clampPitch
	local v107 = p98 * v102
	return v105, v106(p96 - math.rad(v107) * (p101 and -1 or 1))
end
function v_u_1.padCurve(p108) -- name: padCurve
	-- upvalues: (copy) v_u_1
	return p108 ~= p108 and 0 or math.clamp(p108, 0, 1) ^ v_u_1.PAD_EXPONENT
end
function v_u_1.frictionFactor(p109, p110) -- name: frictionFactor
	-- upvalues: (copy) v_u_1
	return (not p110 or (p109 == nil or p109 > v_u_1.PAD_FRICTION_DEG)) and 1 or v_u_1.PAD_FRICTION
end
function v_u_1.padRates(p111, p112, p113, p114, p115) -- name: padRates
	-- upvalues: (copy) v_u_1
	local v116 = p111 * p111 + p112 * p112
	local v117 = math.sqrt(v116)
	if v117 < 1e-6 then
		return 0, 0
	end
	local v118 = v_u_1.padCurve(v117)
	local v119 = 1 + (v_u_1.PAD_ADS_FACTOR - 1) * math.clamp(p114, 0, 1)
	local v120 = v118 * p113 * v119 * p115
	local v121 = -(p111 / v117) * v120
	local v122 = v_u_1.PAD_YAW_DEG
	local v123 = v121 * math.rad(v122)
	local v124 = p112 / v117 * v120
	local v125 = v_u_1.PAD_PITCH_DEG
	return v123, v124 * math.rad(v125)
end
function v_u_1.padLook(p126, p127, p128, p129, p130, p131, p132, p133, p134) -- name: padLook
	-- upvalues: (copy) v_u_1
	local v135, v136 = v_u_1.padRates(p128, p129, p131, p132, p133)
	return v_u_1.wrapYaw(p126 + v135 * p130), v_u_1.clampPitch(p127 + v136 * p130 * (p134 and -1 or 1))
end
function v_u_1.touchLook(p137, p138, p139, p140, p141) -- name: touchLook
	-- upvalues: (copy) v_u_1
	return v_u_1.wrapYaw(p137 + math.rad(p139)), v_u_1.clampPitch(p138 + math.rad(p140) * (p141 and -1 or 1))
end
function v_u_1.eyePosition(p142, p143, p144, p145) -- name: eyePosition
	-- upvalues: (copy) v_u_1
	return p142 - math.sin(p145) * v_u_1.EYE_FORWARD, p143 + v_u_1.EYE_UP, p144 - math.cos(p145) * v_u_1.EYE_FORWARD
end
v_u_1.EYE_HOLD_ACTIONS = {
	["Search"] = true,
	["Revive"] = true
}
v_u_1.STAND_UP_MIN = 0.5
v_u_1.STAND_UP_MAX = 4
v_u_1.STAND_SIDE_MAX = 1.5
function v_u_1.holdsEye(p146) -- name: holdsEye
	-- upvalues: (copy) v_u_1
	local v147
	if type(p146) == "string" then
		v147 = v_u_1.EYE_HOLD_ACTIONS[p146] == true
	else
		v147 = false
	end
	return v147
end
function v_u_1.standHead(p148, p149, p150) -- name: standHead
	-- upvalues: (copy) v_u_1
	if type(p148) ~= "number" or (type(p149) ~= "number" or (type(p150) ~= "number" or (p148 ~= p148 or (p149 ~= p149 or p150 ~= p150)))) then
		return false
	end
	local v151
	if v_u_1.STAND_UP_MIN < p149 and (p149 < v_u_1.STAND_UP_MAX and math.abs(p148) <= v_u_1.STAND_SIDE_MAX) then
		v151 = math.abs(p150) <= v_u_1.STAND_SIDE_MAX
	else
		v151 = false
	end
	return v151
end
function v_u_1.effectiveAction(p152, p153, p154, p155) -- name: effectiveAction
	if type(p153) == "string" and (p153 ~= "" and (type(p154) == "number" and (type(p155) == "number" and p155 < p154))) then
		return p153
	else
		return type(p152) ~= "string" and "" or p152
	end
end
function v_u_1.rotateYP(p156, p157, p158, p159, p160) -- name: rotateYP
	local v161 = math.cos(p157)
	local v162 = math.sin(p157)
	local v163 = p159 * v161 - p160 * v162
	local v164 = p159 * v162 + p160 * v161
	local v165 = math.cos(p156)
	local v166 = math.sin(p156)
	return p158 * v165 + v164 * v166, v163, -p158 * v166 + v164 * v165
end
function v_u_1.tpOffset(p167, p168) -- name: tpOffset
	-- upvalues: (copy) v_u_1
	local v169 = v_u_1.TP
	local v170
	if p167 == "left" then
		v170 = -v169.right
	else
		v170 = v169.right
	end
	if p168 then
		return v170, v169.downedUp, v169.downedBack, v169.downedPivotUp
	else
		return v170, v169.up, v169.back, v169.pivotUp
	end
end
function v_u_1.nextView(p171, p172) -- name: nextView
	if p171 == "tp" then
		if p172 == true then
			return "fp", false
		else
			return "tp", true
		end
	else
		return "tp", false
	end
end
function v_u_1.tpOffsetMix(p173, p174, p175) -- name: tpOffsetMix
	-- upvalues: (copy) v_u_1
	local v176, v177, v178, v179 = v_u_1.tpOffset(p173, p174)
	return v176 * (1 - 2 * ((type(p175) ~= "number" or p175 ~= p175) and 0 or v_u_1.smooth(p175))), v177, v178, v179
end
function v_u_1.tpCameraPos(p180, p181, p182, p183, p184, p185, p186, p187) -- name: tpCameraPos
	-- upvalues: (copy) v_u_1
	local v188, v189, v190 = v_u_1.rotateYP(p183, p184, p185, p186, p187)
	return p180 + v188, p181 + v189, p182 + v190
end
function v_u_1.tpDistance(p191, p192, p193) -- name: tpDistance
	-- upvalues: (copy) v_u_1
	local v194 = p193 or v_u_1.TP.minDist
	if p192 <= v194 then
		return p192
	elseif p191 == nil then
		return p192
	else
		return math.clamp(p191, v194, p192)
	end
end
function v_u_1.tpRecover(p195, p196, p197) -- name: tpRecover
	-- upvalues: (copy) v_u_1
	if p196 <= p195 then
		return p196
	end
	local v198 = p195 + v_u_1.TP.recoverSpeed * math.max(p197, 0)
	return math.min(p196, v198)
end
function v_u_1.bodyLevel(p199, p200, p201) -- name: bodyLevel
	-- upvalues: (copy) v_u_1
	if p199 == "tp" then
		local v202
		if p201 == v_u_1.BODY_HALF then
			v202 = v_u_1.TP.fadeLeave
		else
			v202 = v_u_1.TP.fadeBelow
		end
		if p200 < v202 then
			return v_u_1.BODY_HALF
		else
			return v_u_1.BODY_SHOWN
		end
	else
		return v_u_1.BODY_HIDDEN
	end
end
function v_u_1.fovFor(p203, p204, p205) -- name: fovFor
	local v206 = math.clamp(p203, 1, 120)
	if p204 == nil then
		return v206
	end
	local v207 = math.clamp(p205, 0, 1)
	return v206 + (math.clamp(p204, 1, 120) - v206) * v207
end
function v_u_1.blendStep(p208, p209, p210, p211) -- name: blendStep
	if p211 <= 0 then
		return p209
	else
		local v212 = math.max(p210, 0) / p211
		if p208 < p209 then
			local v213 = p208 + v212
			return math.min(p209, v213)
		else
			local v214 = p208 - v212
			return math.max(p209, v214)
		end
	end
end
function v_u_1.smooth(p215) -- name: smooth
	local v216 = math.clamp(p215, 0, 1)
	return v216 * v216 * (3 - v216 * 2)
end
function v_u_1.effectiveSide(p217, p218) -- name: effectiveSide
	return p217 >= 0.5 and p218 < 0.5 and "tp" or "fp"
end
function v_u_1.deathFall(p219) -- name: deathFall
	-- upvalues: (copy) v_u_1
	local v220 = p219 / v_u_1.DEATH_FALL
	local v221 = math.clamp(v220, 0, 1)
	local v222 = v221 * v221 * (3 - v221 * 2)
	local v223 = v_u_1.DEATH_DROP * v222
	local v224 = v_u_1.DEATH_ROLL_DEG
	local v225 = math.rad(v224) * v222
	local v226 = v_u_1.DEATH_PITCH_DEG
	return v223, v225, -math.rad(v226) * v222
end
function v_u_1.deathOrbitYaw(p227) -- name: deathOrbitYaw
	-- upvalues: (copy) v_u_1
	local v228 = v_u_1.DEATH_ORBIT_DEG_PER_S
	local v229 = math.rad(v228)
	local v230 = p227 - v_u_1.DEATH_FALL
	return v229 * math.max(v230, 0)
end
function v_u_1.chaseAngles(p231, p232, p233) -- name: chaseAngles
	-- upvalues: (copy) v_u_1
	if type(p231) == "number" and p231 == p231 then
		p233 = p231
	end
	local v234 = (type(p232) ~= "number" or p232 ~= p232) and 0 or p232
	local v235 = v_u_1.wrapYaw(p233)
	local v236 = -v_u_1.CHASE_PITCH_LIMIT
	local v237 = v_u_1.CHASE_PITCH_LIMIT
	return v235, math.clamp(v234, v236, v237)
end
function v_u_1.bobPhase(p238, p239, p240) -- name: bobPhase
	-- upvalues: (copy) v_u_1
	return (p238 + math.max(p239, 0) / v_u_1.BOB_CYCLE_STUDS * 3.141592653589793 * 2 * math.max(p240, 0)) % 6.283185307179586
end
function v_u_1.bobOffset(p241, p242, p243, p244, p245, p246) -- name: bobOffset
	-- upvalues: (copy) v_u_1
	local v247
	if p243 then
		v247 = v_u_1.BOB_SPRINT
	else
		v247 = v_u_1.BOB_WALK
	end
	local v248 = math.clamp(p244, 0, 1) * (1 - math.clamp(p245, 0, 1) * 0.7) * math.clamp(p246, 0, 1) * math.clamp(p242, 0, 1)
	local v249 = v247 * v248
	local v250 = p241 * 2
	local v251 = v249 * math.sin(v250)
	local v252 = v247 * 0.5 * v248 * math.sin(p241)
	local v253 = v_u_1.BOB_ROLL_DEG
	return v251, v252, math.rad(v253) * v248 * math.sin(p241)
end
function v_u_1.kickStep(p254, p255, p256, p257) -- name: kickStep
	local v258 = -math.max(p256, 0) * math.max(p257, 0)
	local v259 = math.exp(v258)
	return p254 * v259, p255 * v259
end
function v_u_1.kickAdd(p260, p261, p262, p263) -- name: kickAdd
	-- upvalues: (copy) v_u_1
	local v264 = p260 + p262
	local v265 = -v_u_1.KICK_MAX_PITCH_DEG
	local v266 = v_u_1.KICK_MAX_PITCH_DEG
	local v267 = math.clamp(v264, v265, v266)
	local v268 = p261 + p263
	local v269 = -v_u_1.KICK_MAX_YAW_DEG
	local v270 = v_u_1.KICK_MAX_YAW_DEG
	return v267, math.clamp(v268, v269, v270)
end
function v_u_1.spring(p271, p272, p273, p274, p275) -- name: spring
	local v276 = p271 - p273
	local v277 = -p274 * p275
	local v278 = math.exp(v277)
	local v279 = (p272 + p274 * v276) * p275
	return p273 + (v276 + v279) * v278, (p272 - p274 * v279) * v278
end
function v_u_1.eyeSpring(p280, p281, p282, p283) -- name: eyeSpring
	-- upvalues: (copy) v_u_1
	local v284 = p282 - p280
	if math.abs(v284) > v_u_1.EYE_SNAP_Y then
		return p282, 0
	end
	local v285, v286 = v_u_1.spring(p280, p281, p282, v_u_1.SPRING_OMEGA, p283)
	if v285 - p282 > v_u_1.EYE_MAX_LAG then
		return p282 + v_u_1.EYE_MAX_LAG, 0
	end
	if p282 - v285 > v_u_1.EYE_MAX_LAG then
		v285 = p282 - v_u_1.EYE_MAX_LAG
		v286 = 0
	end
	return v285, v286
end
return v_u_1