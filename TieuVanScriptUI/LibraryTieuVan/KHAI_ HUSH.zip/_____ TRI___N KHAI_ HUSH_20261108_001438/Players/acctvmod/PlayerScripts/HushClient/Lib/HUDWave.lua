-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDWave

local v_u_1 = game:GetService("Players")
return {
	["new"] = function(p_u_2, p_u_3, p4) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_5 = p_u_2.lib.HushUI
		local v_u_6 = p_u_2.shared.Theme
		local v_u_7 = p_u_2.shared.BanWaveRules
		local v_u_8 = v_u_6.color
		local v_u_9 = v_u_7.TIMING
		local v_u_10 = type(p4) ~= "table" and {} or p4
		local v_u_11
		if v_u_10.player == nil then
			v_u_11 = v_u_1.LocalPlayer
		else
			v_u_11 = v_u_10.player
		end
		local v12 = v_u_10.clock
		local v_u_13
		if type(v12) == "function" then
			v_u_13 = v_u_10.clock
		else
			v_u_13 = os.clock
		end
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = v_u_7.newBursts()
		local v_u_17 = {}
		local v_u_18 = {}
		local v_u_19 = 0
		local v_u_20 = nil
		local v_u_21 = nil
		local v_u_22 = nil
		local v_u_23 = false
		local v_u_24 = false
		local v_u_25 = 0
		local v_u_26 = 0
		local v_u_27 = v_u_7.brand(p_u_2.shared.Config)
		local v_u_28 = 0
		local v_u_29 = ""
		local v_u_30 = {
			["shown"] = 0,
			["skipped"] = 0,
			["dropped"] = 0,
			["held"] = 0,
			["pushed"] = 0,
			["maxActive"] = 0,
			["resets"] = 0,
			["updN"] = 0,
			["updSum"] = 0,
			["updMax"] = 0,
			["cardHeld"] = 0
		}
		local v_u_31 = 0
		local v_u_32 = nil
		local v_u_33 = 0
		local v_u_34 = {
			["hint"] = nil,
			["deb"] = nil
		}
		local v_u_35 = -1000000000
		local v_u_36 = -1000000000
		local v_u_37 = false
		local function v_u_39(p38) -- name: effShown
			if p38 == nil or p38.Parent == nil then
				return false
			end
			while p38 ~= nil do
				if p38:IsA("GuiObject") then
					if not p38.Visible then
						return false
					end
				elseif p38:IsA("LayerCollector") then
					return p38.Enabled
				end
				p38 = p38.Parent
			end
			return false
		end
		local function v_u_51(p40) -- name: cardsUp
			-- upvalues: (copy) v_u_10, (copy) v_u_6, (ref) v_u_35, (ref) v_u_37, (copy) v_u_34, (ref) v_u_36, (copy) v_u_11, (copy) v_u_39
			local v41 = v_u_10.cards
			if type(v41) == "function" then
				local v42 = v_u_10.cards
				local v43, v44 = pcall(v42)
				if not v43 or type(v44) ~= "table" then
					return false
				end
				local v45
				if v44.report == true then
					v45 = true
				elseif v44.hint == true then
					v45 = v_u_6.isPhone() == true
				else
					v45 = false
				end
				return v45
			end
			if p40 - v_u_35 < 0.25 then
				return v_u_37
			end
			v_u_35 = p40
			local v46 = v_u_34.hint
			local v47 = v_u_34.deb
			if (v46 == nil or (v46.Parent == nil or (v47 == nil or v47.Parent == nil))) and p40 - v_u_36 >= 1 then
				v_u_36 = p40
				local v48 = v_u_11:FindFirstChildOfClass("PlayerGui")
				local v49
				if v48 then
					v49 = v48:FindFirstChild("HushMenu")
				else
					v49 = nil
				end
				if v49 then
					if v46 == nil or v46.Parent == nil then
						v46 = v49:FindFirstChild("SquadHint", true)
						v_u_34.hint = v46
					end
					if v47 == nil or v47.Parent == nil then
						v47 = v49:FindFirstChild("Debrief", true)
						v_u_34.deb = v47
					end
				end
			end
			local v50 = v_u_39(v47)
			if not v50 then
				if v_u_6.isPhone() == true then
					v50 = v_u_39(v46)
				else
					v50 = false
				end
			end
			v_u_37 = v50
			return v_u_37
		end
		local function v_u_56() -- name: suppressed
			-- upvalues: (copy) v_u_11
			local v52 = v_u_11:GetAttribute("IntroState")
			if type(v52) == "string" and (v52 ~= "off" and v52 ~= "done") then
				return true
			end
			if v_u_11:GetAttribute("FilmClean") == true or v_u_11:GetAttribute("LoadingVisible") == true then
				return true
			end
			local v53 = v_u_11:GetAttribute("Place") or "Menu"
			local v54 = tostring(v53)
			local v55
			if v54 == "Menu" or v54 == "Hideout" then
				v55 = false
			else
				v55 = v54 ~= "Raid"
			end
			return v55
		end
		local function v_u_64(p57) -- name: phoneFit
			-- upvalues: (ref) v_u_21
			local v58 = p57.feedRoom
			local v59 = ((tonumber(v58) or 0) + 6) / 34
			local v60 = math.floor(v59)
			local v61 = math.max(0, v60)
			local v62 = v_u_21
			if v62 ~= nil then
				for _, v63 in v62:GetChildren() do
					if v63.Name ~= "Line" or not (v63:IsA("GuiObject") and v63.Visible) then
						continue
					end
					v61 = v61 - 1
				end
			end
			return v61
		end
		local function v_u_75() -- name: limitNow
			-- upvalues: (ref) v_u_21, (copy) v_u_7, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6, (ref) v_u_22, (ref) v_u_25, (copy) p_u_2
			local v65 = v_u_21
			local v66 = v_u_7.lineCap
			local v67 = v_u_11:GetAttribute("Place") or "Menu"
			local v68 = v66(tostring(v67), v_u_5.device() == "Touch", v_u_6.isPhone())
			if v65 == nil then
				return v68
			end
			if v_u_22 ~= nil then
				return v_u_7.menuRows(v68, v_u_6.refSize().Y - v_u_25)
			end
			local v69
			if v_u_6.isPhone() then
				local v70 = v_u_11:GetAttribute("Place") or "Menu"
				if tostring(v70) == "Raid" and v_u_5.device() == "Touch" then
					local v71 = p_u_2.controllers
					if v71 then
						v71 = p_u_2.controllers.HUD
					end
					if v71 and v71.columnState then
						v69 = v71.columnState()
					else
						v69 = nil
					end
				else
					v69 = nil
				end
			else
				v69 = nil
			end
			if v69 ~= nil then
				return v68
			end
			local v72 = 0
			for _, v73 in v65:GetChildren() do
				if v73.Name ~= "Line" or not (v73:IsA("GuiObject") and v73.Visible) then
					continue
				end
				v72 = v72 + 1
			end
			local v74 = v68 - v72
			return math.max(1, v74)
		end
		local function v_u_79() -- name: makeLine
			-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
			local v76 = v_u_5.new("Frame", {
				["Name"] = "WaveLine",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.08,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_8.dangerDeep,
				["Size"] = UDim2.fromOffset(360, 28)
			})
			v_u_5.stroke(v76, v_u_8.danger, 1, 0.25)
			v_u_5.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_8.danger,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v76)
			local v77 = v_u_7.ICON
			if type(v77) == "string" and v_u_7.ICON ~= "" then
				v_u_5.new("ImageLabel", {
					["Name"] = "Mark",
					["BackgroundTransparency"] = 1,
					["Image"] = nil,
					["ScaleType"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Image"] = v_u_7.ICON,
					["ScaleType"] = Enum.ScaleType.Fit,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 8, 0.5, 0),
					["Size"] = UDim2.fromOffset(22, 22)
				}, v76)
			else
				v_u_5.icon("shield", {
					["parent"] = nil,
					["name"] = "Mark",
					["size"] = 18,
					["color"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["parent"] = v76,
					["color"] = v_u_8.danger:Lerp(Color3.new(1, 1, 1), 0.2),
					["anchor"] = Vector2.new(0, 0.5),
					["position"] = UDim2.new(0, 10, 0.5, 0)
				})
			end
			local v78 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = "",
				["style"] = "small",
				["textSize"] = 13,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v76,
				["color"] = v_u_8.text,
				["position"] = UDim2.fromOffset(36, 0),
				["size"] = UDim2.new(1, -44, 1, 0)
			})
			v78.RichText = false
			v78.TextTruncate = Enum.TextTruncate.AtEnd
			return {
				["f"] = nil,
				["lbl"] = nil,
				["phone"] = false,
				["gone"] = false,
				["f"] = v76,
				["lbl"] = v78
			}
		end
		local function v_u_84(p80, p81) -- name: configure
			p80.phone = p81
			local v82 = p80.f
			local v83 = p80.lbl
			if p81 then
				v82.Size = UDim2.new(1, 0, 0, 28)
				v82.AutomaticSize = Enum.AutomaticSize.Y
				v83.TextWrapped = true
				v83.TextTruncate = Enum.TextTruncate.None
				v83.AutomaticSize = Enum.AutomaticSize.Y
				v83.Size = UDim2.new(1, -44, 0, 28)
			else
				v82.AutomaticSize = Enum.AutomaticSize.None
				v82.Size = UDim2.fromOffset(360, 28)
				v83.AutomaticSize = Enum.AutomaticSize.None
				v83.TextWrapped = false
				v83.TextTruncate = Enum.TextTruncate.AtEnd
				v83.Size = UDim2.new(1, -44, 1, 0)
			end
		end
		local function v_u_90(p85) -- name: park
			-- upvalues: (copy) v_u_17, (copy) v_u_18, (ref) v_u_19
			if p85.gone then
				return
			else
				for v86, v87 in v_u_17 do
					if v87.rec ~= p85 then
						continue
					end
					table.remove(v_u_17, v86)
				end
				p85.f.Parent = nil
				p85.f.Visible = false
				if #v_u_18 < 10 then
					local v88 = v_u_18
					table.insert(v88, p85)
				else
					p85.f:Destroy()
					local v89 = v_u_19 - 1
					v_u_19 = math.max(0, v89)
				end
			end
		end
		local function v_u_94() -- name: dropOldest
			-- upvalues: (copy) v_u_17, (copy) v_u_5, (copy) v_u_90
			local v91 = table.remove(v_u_17, 1)
			if v91 then
				local v_u_92 = v91.rec
				v_u_92.f.Visible = false
				local v93 = {
					["onDone"] = function() -- name: onDone
						-- upvalues: (ref) v_u_90, (copy) v_u_92
						v_u_90(v_u_92)
					end
				}
				v_u_5.fade(v_u_92.f, 1, 0, v93)
			end
		end
		local function v_u_113(p_u_95, p96) -- name: retarget
			-- upvalues: (copy) v_u_17, (copy) v_u_18, (ref) v_u_19, (ref) v_u_22, (ref) v_u_20, (ref) v_u_21, (ref) v_u_23, (ref) v_u_24, (copy) v_u_6, (copy) v_u_5, (copy) v_u_7, (ref) v_u_25, (copy) v_u_30
			for _, v97 in v_u_17 do
				v97.rec.gone = true
			end
			table.clear(v_u_17)
			table.clear(v_u_18)
			v_u_19 = 0
			if v_u_22 ~= nil then
				local v_u_98 = v_u_22
				v_u_22 = nil
				pcall(function()
					-- upvalues: (copy) v_u_98
					v_u_98:Destroy()
				end)
			end
			v_u_20 = p_u_95
			v_u_21 = p_u_95
			v_u_23 = p96
			v_u_24 = v_u_6.isPhone() == true
			if p_u_95 ~= nil and (p96 and p_u_95.Parent ~= nil) then
				local function v109()
					-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_24, (copy) p_u_95, (ref) v_u_25
					local v99 = v_u_5.safeInsets()
					local v100 = v_u_7.MENU_COLUMN
					local v101 = v_u_5.new
					local v102 = "Frame"
					local v103 = {
						["Name"] = "WaveFeed",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1)
					}
					local v104 = UDim2.new
					local v105 = 0
					local v106
					if v_u_24 then
						v106 = v100.PHONE_X
					else
						v106 = v100.X
					end
					v103.Position = v104(v105, v106 + v99.l, 1, -(v100.BOTTOM + v99.b))
					v103.Size = UDim2.fromOffset(v100.WIDTH, v_u_7.CAPS.menu * v100.PITCH)
					local v107 = v101(v102, v103, p_u_95.Parent)
					local v108 = v_u_5.layout(v107, "v", 6)
					v108.VerticalAlignment = Enum.VerticalAlignment.Bottom
					v108.HorizontalAlignment = Enum.HorizontalAlignment.Left
					v_u_25 = v99.b
					return v107
				end
				local v110, v111 = pcall(v109)
				if v110 then
					v_u_22 = v111
					v_u_21 = v_u_22
				end
			end
			local v112 = v_u_30
			v112.resets = v112.resets + 1
		end
		local function v_u_118() -- name: syncFeed
			-- upvalues: (copy) p_u_3, (copy) v_u_11, (ref) v_u_22, (ref) v_u_20, (ref) v_u_23, (ref) v_u_24, (copy) v_u_6, (copy) v_u_113
			local v114
			if p_u_3 and p_u_3.feedFrame then
				v114 = p_u_3.feedFrame()
			else
				v114 = nil
			end
			if v114 ~= nil and v114.Parent == nil then
				v114 = nil
			end
			local v115
			if v114 == nil then
				v115 = false
			else
				local v116 = v_u_11:GetAttribute("Place") or "Menu"
				v115 = tostring(v116) == "Menu"
			end
			local v117
			if v_u_22 == nil then
				v117 = false
			else
				v117 = v_u_22.Parent == nil
			end
			if v114 ~= v_u_20 or (v115 ~= v_u_23 or v117) or v115 and v_u_24 ~= (v_u_6.isPhone() == true) then
				v_u_113(v114, v115)
			end
		end
		local function v_u_130(p119) -- name: show
			-- upvalues: (ref) v_u_21, (copy) v_u_75, (copy) v_u_17, (copy) v_u_94, (copy) v_u_18, (ref) v_u_19, (copy) v_u_79, (ref) v_u_26, (copy) v_u_84, (copy) v_u_6, (copy) v_u_11, (copy) v_u_5, (copy) p_u_2, (copy) v_u_9, (copy) v_u_13, (ref) v_u_31, (copy) v_u_30
			local v120 = v_u_21
			if not v120 then
				return false
			end
			local v121 = v_u_75()
			while v121 <= #v_u_17 do
				v_u_94()
			end
			local v122 = table.remove(v_u_18)
			if not v122 then
				if v_u_19 < 10 then
					v_u_19 = v_u_19 + 1
					v122 = v_u_79()
				else
					v_u_94()
					v122 = table.remove(v_u_18)
				end
			end
			if not v122 then
				return false
			end
			v_u_26 = v_u_26 + 1
			local v123 = v_u_84
			local v124
			if v_u_6.isPhone() then
				local v125 = v_u_11:GetAttribute("Place") or "Menu"
				if tostring(v125) == "Raid" and v_u_5.device() == "Touch" then
					local v126 = p_u_2.controllers
					if v126 then
						v126 = p_u_2.controllers.HUD
					end
					if v126 and v126.columnState then
						v124 = v126.columnState()
					else
						v124 = nil
					end
				else
					v124 = nil
				end
			else
				v124 = nil
			end
			v123(v122, v124 ~= nil)
			v122.lbl.Text = p119
			v122.f.LayoutOrder = v_u_26 + 1000000
			v122.f.Visible = true
			v122.f.Parent = v120
			v_u_5.fade(v122.f, 0, v_u_9.FADE_IN, {
				["from"] = 1
			})
			local v127 = v_u_17
			local v128 = {
				["rec"] = nil,
				["born"] = nil,
				["out"] = false,
				["rec"] = v122,
				["born"] = v_u_13() - v_u_31
			}
			table.insert(v127, v128)
			local v129 = v_u_30
			v129.shown = v129.shown + 1
			if #v_u_17 > v_u_30.maxActive then
				v_u_30.maxActive = #v_u_17
			end
			return true
		end
		function v_u_14.push(p131) -- name: push
			-- upvalues: (ref) v_u_15, (copy) v_u_7, (ref) v_u_27, (copy) p_u_2, (copy) v_u_16, (copy) v_u_13, (ref) v_u_31, (copy) v_u_30
			if v_u_15 then
				local v132, v133, v134 = v_u_7.cleanFeed(p131)
				if v132 == nil then
					return
				else
					v_u_27 = v133 or v_u_7.brand(p_u_2.shared.Config)
					if v_u_16.push(v134, v132, v_u_13() - v_u_31) == "full" then
						local v135 = v_u_30
						v135.dropped = v135.dropped + #v132
					else
						local v136 = v_u_30
						v136.pushed = v136.pushed + #v132
					end
				end
			else
				return
			end
		end
		function v_u_14.test(p137) -- name: test
			-- upvalues: (ref) v_u_28, (copy) v_u_7, (copy) v_u_14, (copy) p_u_2
			v_u_28 = v_u_28 + 1
			local v138 = tonumber(p137) or 12
			local v139 = math.floor(v138)
			local v140 = v_u_7.LIMITS.WAVE_NAMES
			local v141 = math.clamp(v139, 1, v140)
			local v142 = v_u_7.sampleNames(v141)
			for v143 = 1, #v142, v_u_7.LIMITS.NAMES_PER_MSG do
				local v144 = v143 + v_u_7.LIMITS.NAMES_PER_MSG - 1
				local v145 = #v142
				local v146 = {}
				for v147 = v143, math.min(v144, v145) do
					local v148 = v142[v147]
					table.insert(v146, v148)
				end
				v_u_14.push({
					["names"] = v146,
					["by"] = v_u_7.brand(p_u_2.shared.Config),
					["wave"] = ("test%d"):format(v_u_28)
				})
			end
		end
		function v_u_14._raw(p149) -- name: _raw
			-- upvalues: (copy) v_u_118, (copy) v_u_130
			v_u_118()
			return v_u_130((tostring(p149)))
		end
		function v_u_14.update(_) -- name: update
			-- upvalues: (ref) v_u_15, (copy) v_u_118, (copy) v_u_13, (ref) v_u_22, (copy) v_u_16, (copy) v_u_17, (copy) v_u_51, (ref) v_u_32, (ref) v_u_33, (ref) v_u_31, (ref) v_u_21, (copy) v_u_18, (ref) v_u_19, (copy) v_u_7, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6, (copy) v_u_79, (copy) p_u_2, (copy) v_u_64, (copy) v_u_56, (copy) v_u_30, (copy) v_u_130, (ref) v_u_27, (ref) v_u_29, (copy) v_u_9, (copy) v_u_90, (copy) v_u_75, (copy) v_u_94, (copy) v_u_84
			if v_u_15 then
				local v150 = os.clock()
				v_u_118()
				local v151 = v_u_13()
				local v152
				if v_u_22 == nil or not v_u_16.busy() and #v_u_17 <= 0 then
					v152 = false
				else
					v152 = v_u_51(v151)
				end
				if v152 then
					if v_u_32 ~= nil then
						local v153 = v151 - v_u_32
						local v154 = math.max(0, v153)
						v_u_33 = v_u_33 + v154
						if v_u_33 <= 60 then
							v_u_31 = v_u_31 + v154
						end
					end
				else
					v_u_33 = 0
				end
				v_u_32 = v151
				local v155 = v151 - v_u_31
				if v_u_21 ~= nil and #v_u_18 < 2 then
					local v156 = v_u_19
					local v157 = v_u_7.lineCap
					local v158 = v_u_11:GetAttribute("Place") or "Menu"
					local v159 = v157(tostring(v158), v_u_5.device() == "Touch", v_u_6.isPhone())
					if v156 < math.min(v159, 10) and (v_u_16.busy() or #v_u_17 > 0) then
						v_u_19 = v_u_19 + 1
						local v160 = v_u_18
						local v161 = v_u_79()
						table.insert(v160, v161)
					end
				end
				local v162 = v_u_16.busy()
				local v163
				if (v162 or #v_u_17 > 0) and v_u_6.isPhone() then
					local v164 = v_u_11:GetAttribute("Place") or "Menu"
					if tostring(v164) == "Raid" and v_u_5.device() == "Touch" then
						local v165 = p_u_2.controllers
						if v165 then
							v165 = p_u_2.controllers.HUD
						end
						if v165 and v165.columnState then
							v163 = v165.columnState()
						else
							v163 = nil
						end
					else
						v163 = nil
					end
				else
					v163 = nil
				end
				local v166 = (not v162 or v163 == nil) and true or false or (v_u_64(v163) > 0 and true or v_u_56())
				if not v166 then
					local v167 = v_u_30
					v167.held = v167.held + 1
				end
				if v152 then
					local v168 = v_u_30
					v168.cardHeld = v168.cardHeld + 1
					v166 = false
				end
				for _, v169 in v_u_16.step(v155, v166) do
					if v_u_56() or v_u_21 == nil then
						local v170 = v_u_30
						v170.skipped = v170.skipped + 1
					else
						if not v_u_130(v_u_7.lineText(v169.name, v_u_27)) or v_u_29 == v169.wave then
							continue
						end
						v_u_29 = v169.wave
						local v171 = v_u_5.sound
						local v172 = v_u_6.sounds.hit
						local v173 = v_u_6.sounds.toast
						pcall(v171, v172, v173)
					end
				end
				for _, v174 in v_u_17 do
					if v174.out or v155 - v174.born < v_u_9.HOLD then
						continue
					end
					v174.out = true
					local v_u_175 = v174.rec
					local v176 = {
						["onDone"] = function() -- name: onDone
							-- upvalues: (ref) v_u_90, (copy) v_u_175
							v_u_90(v_u_175)
						end
					}
					v_u_5.fade(v_u_175.f, 1, v_u_9.FADE_OUT, v176)
				end
				if #v_u_17 > 0 then
					if not v163 then
						local v177 = v_u_75()
						while v177 < #v_u_17 do
							v_u_94()
						end
					end
					for _, v178 in v_u_17 do
						if v178.rec.phone == (v163 ~= nil) then
							continue
						end
						v_u_84(v178.rec, v163 ~= nil)
					end
					if v163 then
						local v179 = v_u_64(v163)
						for v180, v181 in v_u_17 do
							local v182 = #v_u_17 - v180 < v179
							if v181.rec.f.Visible == v182 then
								continue
							end
							v181.rec.f.Visible = v182
						end
					elseif v152 then
						for _, v183 in v_u_17 do
							if not v183.rec.f.Visible then
								continue
							end
							v183.rec.f.Visible = false
						end
					else
						for _, v184 in v_u_17 do
							if v184.rec.f.Visible then
								continue
							end
							v184.rec.f.Visible = true
						end
					end
				end
				local v185 = (os.clock() - v150) * 1000
				local v186 = v_u_30
				v186.updN = v186.updN + 1
				local v187 = v_u_30
				v187.updSum = v187.updSum + v185
				if v_u_30.updMax < v185 then
					v_u_30.updMax = v185
				end
			end
		end
		function v_u_14.state() -- name: state
			-- upvalues: (copy) v_u_16, (copy) v_u_17, (ref) v_u_19, (copy) v_u_18, (copy) v_u_30, (copy) v_u_7, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6, (ref) v_u_22
			local v188 = v_u_16.state()
			local v189 = #v_u_17
			local v190 = v_u_19
			local v191 = #v_u_18
			local v192 = v_u_30.shown
			local v193 = v_u_30.skipped
			local v194 = v_u_30.dropped
			local v195 = v_u_30.held
			local v196 = v_u_30.maxActive
			local v197 = v_u_30.resets
			local v198 = v_u_7.lineCap
			local v199 = v_u_11:GetAttribute("Place") or "Menu"
			local v200 = v198(tostring(v199), v_u_5.device() == "Touch", v_u_6.isPhone())
			local v201 = v_u_22 ~= nil
			return ("%s lines=%d created=%d pool=%d shown=%d skipped=%d dropped=%d held=%d max=%d resets=%d cap=%d own=%s upd=%.3f/%.3fms cardHeld=%d"):format(v188, v189, v190, v191, v192, v193, v194, v195, v196, v197, v200, tostring(v201), v_u_30.updN <= 0 and 0 or v_u_30.updSum / v_u_30.updN, v_u_30.updMax, v_u_30.cardHeld)
		end
		function v_u_14.stats() -- name: stats
			-- upvalues: (copy) v_u_30, (copy) v_u_17, (ref) v_u_19, (copy) v_u_18, (copy) v_u_16, (ref) v_u_22
			return {
				["shown"] = v_u_30.shown,
				["skipped"] = v_u_30.skipped,
				["dropped"] = v_u_30.dropped,
				["held"] = v_u_30.held,
				["cardHeld"] = v_u_30.cardHeld,
				["pushed"] = v_u_30.pushed,
				["maxActive"] = v_u_30.maxActive,
				["lines"] = #v_u_17,
				["created"] = v_u_19,
				["pool"] = #v_u_18,
				["busy"] = v_u_16.busy(),
				["pending"] = v_u_16.pending(),
				["own"] = v_u_22 ~= nil,
				["updN"] = v_u_30.updN,
				["updAvgMs"] = v_u_30.updN <= 0 and 0 or v_u_30.updSum / v_u_30.updN,
				["updMaxMs"] = v_u_30.updMax
			}
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15, (copy) v_u_17, (copy) v_u_18, (ref) v_u_22
			v_u_15 = false
			for _, v_u_202 in v_u_17 do
				pcall(function()
					-- upvalues: (copy) v_u_202
					v_u_202.rec.f:Destroy()
				end)
			end
			table.clear(v_u_17)
			for _, v_u_203 in v_u_18 do
				pcall(function()
					-- upvalues: (copy) v_u_203
					v_u_203.f:Destroy()
				end)
			end
			table.clear(v_u_18)
			if v_u_22 ~= nil then
				local function v204()
					-- upvalues: (ref) v_u_22
					v_u_22:Destroy()
				end
				pcall(v204)
				v_u_22 = nil
			end
		end
		return v_u_14
	end
}