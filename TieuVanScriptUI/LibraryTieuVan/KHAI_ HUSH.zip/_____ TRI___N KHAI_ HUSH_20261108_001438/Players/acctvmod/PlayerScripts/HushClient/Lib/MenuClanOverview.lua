-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanOverview

return {
	["mount"] = function(p_u_1, p2) -- name: mount
		local v_u_3 = p_u_1.UI
		local _ = p_u_1.Theme
		local v_u_4 = p_u_1.C
		local v_u_5 = p_u_1.Kit
		local v_u_6 = p_u_1.U
		local v_u_7 = p_u_1.M
		local v_u_8 = p_u_1.m
		local v_u_9 = p_u_1.lib("MenuClanPlan")
		local v_u_10 = p_u_1.lib("MenuClanLook")
		local v_u_11 = {}
		local v_u_12 = true
		local v_u_13 = false
		local v_u_14 = 0
		local v_u_15 = nil
		local v_u_16 = nil
		local v_u_17 = nil
		local v_u_18 = -1000
		local v_u_19 = false
		local v_u_20 = nil
		local v_u_21 = -1000
		local v_u_22 = false
		local v_u_23 = v_u_3.list({
			["parent"] = nil,
			["name"] = "List",
			["size"] = nil,
			["gap"] = 8,
			["padding"] = nil,
			["parent"] = p2,
			["size"] = UDim2.fromScale(1, 1),
			["padding"] = {
				0,
				6,
				0,
				12
			}
		})
		local v_u_24 = v_u_8.inner - 18
		local function v_u_39(p25) -- name: tagColor
			-- upvalues: (ref) v_u_20, (copy) p_u_1, (copy) v_u_4
			if v_u_20 ~= nil then
				local v_u_26 = p_u_1.lib("MenuClanShopModel")
				local function v28()
					-- upvalues: (copy) v_u_26, (ref) v_u_20, (ref) p_u_1
					local v27 = v_u_26.styleOf(v_u_20, nil)
					if v27 then
						return p_u_1.cctx.shared.ClanStyle.color3(v27)
					else
						return nil
					end
				end
				local v29, v30 = pcall(v28)
				if v29 and typeof(v30) == "Color3" then
					return v30
				end
			end
			local v_u_31 = nil
			local function v32()
				-- upvalues: (ref) v_u_31, (ref) p_u_1
				v_u_31 = p_u_1.cctx.shared.ClanTag
			end
			pcall(v32)
			if v_u_31 then
				local v33 = v_u_31.color
				if type(v33) == "function" then
					local v34 = p25.id
					if type(v34) == "string" then
						local v35 = v_u_31.color
						local v36 = p25.id
						local v37, v38 = pcall(v35, v36, 0.55, 0.95)
						if v37 and typeof(v38) == "Color3" then
							return v38
						end
					end
				end
			end
			return v_u_4.accent
		end
		local function v_u_54(p40, p41, p42) -- name: resultCard
			-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_4, (copy) p_u_1
			local v_u_43 = p41.res
			local v44 = v_u_6.card(p40, "ResultCard", p42)
			local v45 = v_u_9.parts(p42.w, p42.h)
			v_u_6.text(v44, "Head", "LAST WEEK", v45.title, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text2
			})
			local v46 = v_u_6.text
			local v47 = v_u_43.rank
			v46(v44, "T", ("Place %d"):format(tonumber(v47) or 0), {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 24,
				["x"] = v45.body.x,
				["y"] = v45.body.y,
				["w"] = v45.body.w - 110 - 8
			}, {
				["style"] = "bodyStrong"
			})
			local v48 = v_u_6.text
			local v49 = v_u_43.title
			v48(v44, "S", type(v49) == "string" and v_u_43.title ~= "" and "Rewards are in your account." or "Thank you for playing.", {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 16,
				["x"] = v45.body.x,
				["y"] = v45.body.y + 26,
				["w"] = v45.body.w - 110 - 8
			}, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text2
			})
			v_u_6.btn({
				["parent"] = nil,
				["text"] = "VIEW",
				["kind"] = "secondary",
				["width"] = 110,
				["name"] = "View",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v44,
				["position"] = UDim2.fromOffset(p42.w - 110 - v_u_9.PAD, p42.h - v_u_9.TOUCH - 10),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_1, (copy) v_u_43
					local v50 = p_u_1.lib("MenuClanBoard")
					if v50 and v50.resultModal then
						local v51 = v50.resultModal
						local v52 = p_u_1
						local v53 = v_u_43
						pcall(v51, v52, v53)
					end
				end
			})
		end
		local function v_u_72(p55, p56, p57, p58) -- name: expandCard
			-- upvalues: (copy) p_u_1, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4
			local v59 = p_u_1.lib("MenuClanShopModel")
			local v60 = p58.next
			local v61 = v_u_6.card(p55, "ExpandCard", p56)
			local v62 = p58.pts + p58.ptsWeek
			local v63 = v_u_6.text
			local v64 = v_u_3.commas
			local v65 = v60.pts
			v63(v61, "Text", ("%s / %s CLAN POINTS TO THE NEXT SLOTS"):format(v64((math.min(v62, v65))), v_u_3.commas(v60.pts)), p57.text, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text
			})
			local v66 = v_u_3.new("Frame", {
				["Name"] = "BarTrack",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_4.bg,
				["Position"] = UDim2.fromOffset(p57.bar.x, p57.bar.y),
				["Size"] = UDim2.fromOffset(p57.bar.w, p57.bar.h)
			}, v61)
			local v67 = v_u_3.new
			local v68 = {
				["Name"] = "BarFill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_4.accent
			}
			local v69 = UDim2.new
			local v70 = v60.pts <= 0 and 1 or v62 / v60.pts
			v68.Size = v69(math.clamp(v70, 0, 1), 0, 1, 0)
			v67("Frame", v68, v66)
			local v71 = v60.ok and "" or v59.expandReason(p58)
			v_u_6.text(v61, "Reason", v71, p57.reason, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.accent
			})
			v_u_6.btn({
				["parent"] = nil,
				["text"] = "EXPAND",
				["kind"] = "primary",
				["width"] = nil,
				["maxTextWidth"] = nil,
				["name"] = "Expand",
				["position"] = nil,
				["disabled"] = nil,
				["onClick"] = nil,
				["parent"] = v61,
				["width"] = p57.button.w,
				["maxTextWidth"] = p57.button.w - 40,
				["position"] = UDim2.fromOffset(p57.button.x, p57.button.y),
				["disabled"] = not v60.ok,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_1
					p_u_1.shopCat = "slots"
					p_u_1.setTab("shop")
				end
			})
		end
		local function v_u_84(p73, _, p74, p75, p76) -- name: standingCard
			-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7
			local v77 = v_u_6.card(p73, "StandingCard", p74)
			local v78 = v_u_9.parts(p74.w, p74.h)
			v_u_6.text(v77, "Head", "WEEKLY STANDING", v78.title, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text2
			})
			if p75 then
				v_u_6.text(v77, "Place", ("#%d"):format(p75.place), {
					["x"] = nil,
					["y"] = nil,
					["w"] = 90,
					["h"] = 40,
					["x"] = v78.body.x,
					["y"] = v78.body.y
				}, {
					["style"] = "monoL",
					["color"] = nil,
					["color"] = v_u_4.accent
				})
				v_u_6.text(v77, "Of", ("of %d clans"):format(p75.total), {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 18,
					["x"] = v78.body.x + 92,
					["y"] = v78.body.y + 4,
					["w"] = v78.body.w - 92
				}, {
					["style"] = "small",
					["color"] = nil,
					["color"] = v_u_4.text2
				})
				v_u_6.text(v77, "Pts", v_u_3.commas(p75.pts) .. " points", {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 18,
					["x"] = v78.body.x + 92,
					["y"] = v78.body.y + 22,
					["w"] = v78.body.w - 92
				}, {
					["style"] = "small"
				})
				local v79
				if p75.ahead then
					v79 = ("%s points to reach #%d"):format(v_u_3.commas(p75.ahead.gap), p75.ahead.place)
				else
					v79 = p75.behind and "You lead the board." or "Alone on the board."
				end
				v_u_6.text(v77, "Gap", v79, {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 18,
					["x"] = v78.body.x,
					["y"] = v78.body.y + 46,
					["w"] = v78.body.w
				}, {
					["style"] = "micro",
					["color"] = nil,
					["color"] = v_u_4.text2
				})
			else
				v_u_6.text(v77, "None", "Not ranked yet", {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 26,
					["x"] = v78.body.x,
					["y"] = v78.body.y,
					["w"] = v78.body.w
				}, {
					["style"] = "bodyStrong"
				})
				local v80 = (type(p76) ~= "table" or not p76.needActive) and "Extract with your clan to get on the board." or v_u_7.UI.NEEDS_ACTIVE
				local v81 = v_u_6.text
				local v82 = {
					["x"] = v78.body.x,
					["y"] = v78.body.y + 28,
					["w"] = v78.body.w
				}
				local v83 = v78.body.h - 28
				v82.h = math.max(18, v83)
				v81(v77, "Why", v80, v82, {
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["valign"] = "top",
					["color"] = v_u_4.text2
				})
			end
		end
		local function v_u_94(p85, p86) -- name: topMembers
			-- upvalues: (copy) v_u_10
			local v87 = {}
			for _, v88 in v_u_10.sortMembers(p85.members) do
				table.insert(v87, v88)
			end
			table.sort(v87, function(p89, p90)
				local v91 = p89.pts
				local v92 = tonumber(v91) or 0
				local v93 = p90.pts
				return (tonumber(v93) or 0) < v92
			end)
			while p86 < #v87 do
				table.remove(v87)
			end
			return v87
		end
		local function v_u_141(p95, _, p96, p97, p98) -- name: topsCard
			-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) p_u_1, (copy) v_u_3, (copy) v_u_10
			local v99 = v_u_6.card(p95, "TopsCard", p96)
			v_u_6.text(v99, "Head", "TOP MEMBERS THIS WEEK", p98.title, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text2
			})
			local v100 = 1
			for _, v101 in p97 do
				local v102 = v101.pts
				local v103 = tonumber(v102) or 0
				v100 = math.max(v100, v103)
			end
			for v104, v105 in p97 do
				local v106 = p98["row" .. v104]
				local v107 = v105.uid
				local v108 = tostring(v107) == p_u_1.selfUid
				local v109 = v_u_6.frame(v99, "Top" .. v104, UDim2.fromOffset(v106.w, v106.h), UDim2.fromOffset(v106.x, v106.y))
				local v110 = v105.pts
				local v111 = tonumber(v110) or 0
				local v112 = v_u_3.label
				local v113 = {
					["parent"] = nil,
					["name"] = "Place",
					["text"] = nil,
					["style"] = "mono",
					["color"] = nil,
					["align"] = "center",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v109,
					["text"] = tostring(v104)
				}
				local v114
				if v104 == 1 then
					v114 = v_u_4.accent
				else
					v114 = v_u_4.text2
				end
				v113.color = v114
				v113.position = UDim2.fromOffset(0, 0)
				v113.size = UDim2.fromOffset(24, v106.h)
				v112(v113)
				local v115 = v_u_6.avatar
				local v116 = "Avatar"
				local v117 = v105.uid
				local v118 = v105.name
				local v119 = {
					["x"] = 28,
					["y"] = 6,
					["w"] = nil,
					["h"] = nil,
					["w"] = v106.h - 12,
					["h"] = v106.h - 12
				}
				local v120 = {}
				local v121
				if v105.online == true then
					v121 = v_u_4.success
				else
					v121 = nil
				end
				v120.dot = v121
				v115(v109, v116, v117, v118, v119, v120)
				local v122 = 28 + v106.h - 12 + 8
				local v123 = v_u_3.label
				local v124 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v109
				}
				local v125 = v105.name or "?"
				v124.text = tostring(v125) .. (v108 and " (you)" or "")
				local v126
				if v108 then
					v126 = v_u_4.accent
				else
					v126 = v_u_4.text
				end
				v124.color = v126
				v124.position = UDim2.fromOffset(v122, 2)
				local v127 = UDim2.fromOffset
				local v128 = v106.w - v122 - 64 - 8
				local v129 = math.max(40, v128)
				local v130 = (v106.h - 4) / 2
				v124.size = v127(v129, math.floor(v130) + 2)
				v123(v124)
				local v131 = v106.w - v122 - 64 - 8
				local v132 = math.max(8, v131)
				local v133 = v_u_3.new("Frame", {
					["Name"] = "BarTrack",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_4.bg,
					["Position"] = UDim2.fromOffset(v122, v106.h - 12),
					["Size"] = UDim2.fromOffset(v132, 4)
				}, v109)
				local v134 = v_u_3.new
				local v135 = {
					["Name"] = "BarFill",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_10.rankColor(v105.rank)
				}
				local v136 = UDim2.new
				local v137 = v111 / v100
				v135.Size = v136(math.clamp(v137, 0, 1), 0, 1, 0)
				v134("Frame", v135, v133)
				local v138 = v_u_3.label
				local v139 = {
					["parent"] = nil,
					["name"] = "Pts",
					["text"] = nil,
					["style"] = "mono",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v109,
					["text"] = v_u_3.commas(v111)
				}
				local v140
				if v108 then
					v140 = v_u_4.accent
				else
					v140 = v_u_4.text
				end
				v139.color = v140
				v139.position = UDim2.fromOffset(v106.w - 64, 0)
				v139.size = UDim2.fromOffset(64, v106.h)
				v138(v139)
			end
		end
		local function v_u_175(p142, p143, p144, p145, p146) -- name: boardMiniCard
			-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_3
			local v147 = v_u_6.card(p142, "BoardMiniCard", p144)
			v_u_6.text(v147, "Head", "CLAN BOARD THIS WEEK", p146.title, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_4.text2
			})
			for v148, v149 in p145 do
				local v150 = p146["row" .. v148]
				local v151 = v149.id == p143.id
				local v152 = v_u_6.frame(v147, "Clan" .. v148, UDim2.fromOffset(v150.w, v150.h), UDim2.fromOffset(v150.x, v150.y))
				v152.BackgroundTransparency = v151 and 0.7 or 1
				v152.BackgroundColor3 = v_u_4.accentDeep
				v_u_3.corner(v152, 6)
				local v153 = v149.rank
				local v154 = tonumber(v153) or v148
				local v155 = v_u_3.label
				local v156 = {
					["parent"] = nil,
					["name"] = "Place",
					["text"] = nil,
					["style"] = "mono",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v152,
					["text"] = ("#%d"):format(v154)
				}
				local v157
				if v154 == 1 then
					v157 = v_u_4.accent
				else
					v157 = v_u_4.text2
				end
				v156.color = v157
				v156.position = UDim2.fromOffset(8, 0)
				v156.size = UDim2.fromOffset(34, v150.h)
				v155(v156)
				local v158 = v_u_6.pill
				local v159 = "Tag"
				local v160 = v149.tag or "????"
				local v161 = tostring(v160)
				local v162
				if v151 then
					v162 = v_u_4.accent
				else
					v162 = v_u_4.text2
				end
				local v163 = {
					["x"] = 46,
					["y"] = nil,
					["w"] = 64,
					["h"] = 22
				}
				local v164 = (v150.h - 22) / 2
				v163.y = math.floor(v164)
				v158(v152, v159, v161, v162, v163)
				local v165 = v_u_3.label
				local v166 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v152
				}
				local v167 = v149.name or "?"
				v166.text = tostring(v167)
				local v168
				if v151 then
					v168 = v_u_4.accent
				else
					v168 = v_u_4.text
				end
				v166.color = v168
				v166.position = UDim2.fromOffset(118, 0)
				local v169 = UDim2.fromOffset
				local v170 = v150.w - 118 - 76 - 8
				v166.size = v169(math.max(40, v170), v150.h)
				v165(v166)
				local v171 = v_u_3.label
				local v172 = {
					["parent"] = nil,
					["name"] = "Pts",
					["text"] = nil,
					["style"] = "mono",
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v152
				}
				local v173 = v_u_3.commas
				local v174 = v149.pts
				v172.text = v173(tonumber(v174) or 0)
				v172.position = UDim2.fromOffset(v150.w - 76 - 8, 0)
				v172.size = UDim2.fromOffset(76, v150.h)
				v171(v172)
			end
		end
		local function v_u_199(p176, p177) -- name: offerCard
			-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7, (copy) p_u_1, (ref) v_u_12, (ref) v_u_16
			local v178 = p176.offerForMe
			if type(v178) == "table" then
				local v179 = v_u_6.frame(v_u_23, "OfferCard", UDim2.new(1, -8, 0, 128), nil, p177)
				v179.BackgroundTransparency = 0.3
				v179.BackgroundColor3 = v_u_4.accentDeep
				v_u_3.corner(v179, 6)
				v_u_3.stroke(v179, v_u_4.accent)
				local v180 = v178.byName
				local v181 = (type(v180) ~= "string" or v178.byName == "") and "The owner" or v178.byName
				local v182 = v_u_3.label
				local v183 = {
					["parent"] = nil,
					["name"] = "T",
					["text"] = nil,
					["style"] = "bodyStrong",
					["wrap"] = true,
					["valign"] = "top",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v179
				}
				local v184 = p176.tag
				v183.text = ("%s offers you the leadership of [%s]."):format(v181, (tostring(v184)))
				v183.position = UDim2.fromOffset(12, 8)
				v183.size = UDim2.new(1, -24, 0, 40)
				v182(v183)
				v_u_3.label({
					["parent"] = nil,
					["name"] = "C",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["valign"] = "top",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v179,
					["text"] = v_u_7.UI.PASS_NEEDED_ACCEPT .. "  Expires in " .. v_u_7.timeText(v_u_6.left(v178.ex)) .. ".",
					["color"] = v_u_4.text2,
					["position"] = UDim2.fromOffset(12, 50),
					["size"] = UDim2.new(1, -24, 0, 28)
				})
				local v_u_185 = {}
				local function v_u_196(p186) -- name: answer
					-- upvalues: (copy) v_u_185, (ref) p_u_1, (ref) v_u_12, (ref) v_u_16, (ref) v_u_7
					for _, v187 in v_u_185 do
						v187.busy(true, "...")
					end
					p_u_1.send("clanTransferAnswer", {
						["accept"] = p186
					}, function(p188, p189, p190, p191)
						-- upvalues: (ref) v_u_12, (ref) v_u_185, (ref) v_u_16, (ref) v_u_7
						if v_u_12 then
							for _, v192 in v_u_185 do
								local v193 = v192.busy
								pcall(v193, false)
							end
							if not p188 then
								local v194 = v_u_16.set
								local v195 = v_u_7.reasonFor
								if not p191 then
									p191 = {
										["msg"] = p189,
										["data"] = p190
									}
								end
								v194(v195(p191), "danger")
							end
						end
					end, 25)
				end
				local _, v197 = v_u_6.btn({
					["parent"] = nil,
					["text"] = "ACCEPT",
					["kind"] = "primary",
					["width"] = 130,
					["name"] = "Accept",
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v179,
					["position"] = UDim2.fromOffset(12, 78),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_196
						v_u_6.confirm({
							["title"] = "TAKE OVER THE CLAN",
							["body"] = nil,
							["yes"] = "ACCEPT",
							["no"] = "CANCEL",
							["onYes"] = nil,
							["body"] = v_u_7.CONFIRM.accept(),
							["onYes"] = function() -- name: onYes
								-- upvalues: (ref) v_u_196
								v_u_196(true)
							end
						})
					end
				})
				local _, v198 = v_u_6.btn({
					["parent"] = nil,
					["text"] = "DECLINE",
					["kind"] = "secondary",
					["width"] = 130,
					["name"] = "Decline",
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v179,
					["position"] = UDim2.fromOffset(150, 78),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_196
						v_u_196(false)
					end
				})
				v_u_185[1] = v197
				v_u_185[2] = v198
			end
		end
		function v_u_11.draw() -- name: draw
			-- upvalues: (ref) v_u_12, (copy) v_u_3, (copy) v_u_23, (copy) v_u_5, (copy) p_u_1, (copy) v_u_7, (ref) v_u_16, (copy) v_u_6, (copy) v_u_199, (ref) v_u_17, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_94, (copy) v_u_24, (ref) v_u_20, (copy) v_u_39, (copy) v_u_4, (ref) v_u_14, (ref) v_u_15, (copy) v_u_72, (copy) v_u_84, (copy) v_u_54, (copy) v_u_141, (copy) v_u_175
			if v_u_12 then
				v_u_3.keepScroll(v_u_23, function()
					-- upvalues: (ref) v_u_5, (ref) v_u_23, (ref) p_u_1, (ref) v_u_7, (ref) v_u_16, (ref) v_u_6, (ref) v_u_199, (ref) v_u_17, (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (ref) v_u_94, (ref) v_u_24, (ref) v_u_20, (ref) v_u_39, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_15, (ref) v_u_72, (ref) v_u_84, (ref) v_u_54, (ref) v_u_141, (ref) v_u_175, (ref) v_u_12
					v_u_5.clear(v_u_23)
					local v_u_200 = p_u_1.clan()
					if v_u_200 then
						local v201 = p_u_1.state()
						local v202 = 0
						local v203 = v_u_6.status
						local v204 = v_u_23
						local v205 = {
							["name"] = "Msg",
							["text"] = "",
							["style"] = "small",
							["size"] = nil,
							["order"] = nil,
							["visible"] = false,
							["size"] = UDim2.new(1, -8, 0, 20)
						}
						v202 = v202 + 1
						v205.order = v202
						v_u_16 = v203(v204, v205)
						local v206 = v201.tx
						if type(v206) == "table" and v201.tx.kind == "disband" then
							local v207 = v_u_6.status
							local v208 = v_u_23
							local v209 = {
								["name"] = "Closing",
								["text"] = nil,
								["kind"] = "warn",
								["size"] = nil,
								["order"] = nil,
								["text"] = v_u_7.UI.CLOSING,
								["size"] = UDim2.new(1, -8, 0, 22)
							}
							v202 = v202 + 1
							v209.order = v202
							v207(v208, v209)
						end
						local v210 = v201.review
						if (tonumber(v210) or 0) > 0 then
							local v211 = v_u_6.status
							local v212 = v_u_23
							local v213 = {
								["name"] = "Review",
								["text"] = nil,
								["kind"] = "info",
								["size"] = nil,
								["order"] = nil,
								["text"] = v_u_7.UI.STASH_REVIEW,
								["size"] = UDim2.new(1, -8, 0, 22)
							}
							v202 = v202 + 1
							v213.order = v202
							v211(v212, v213)
						end
						local v214 = v_u_199
						v202 = v202 + 1
						v214(v_u_200, v202)
						local v215 = v_u_17
						local v216, v217
						if type(v215) == "table" then
							v216 = v_u_10.standing(v_u_17.rows, v_u_200.id)
							if v216 then
								v217 = true
							else
								v216 = nil
								local v218 = v_u_17.mine
								if type(v218) == "table" then
									v217 = true
								else
									v217 = false
								end
							end
						else
							v216 = nil
							v217 = false
						end
						local v219 = v_u_200.wk
						local v220 = type(v219) ~= "table" and {} or v_u_200.wk
						local v221, v222 = v_u_10.modeLook(v_u_200.mode)
						local v223 = v_u_10.rankChipText(v_u_200, v_u_200.rank)
						local v224 = v_u_200.count
						local v225 = tonumber(v224) or 0
						local v226 = v_u_200.cap
						local v227 = tonumber(v226) or 30
						local v228 = v_u_200.crit
						local v229 = type(v228) ~= "table" and {} or v_u_200.crit
						local v230 = v229.raids
						local v231 = tonumber(v230) or 0
						local v232 = math.floor(v231)
						local v233 = math.max(0, v232)
						local v234 = v229.pct
						local v235 = tonumber(v234) or 0
						local v236 = math.floor(v235)
						local v237 = math.max(0, v236)
						local v238 = {}
						if v233 > 0 then
							local v239 = v233 == 1 and "1 raid" or ("%d raids"):format(v233)
							table.insert(v238, v239)
						end
						if v237 > 0 then
							table.insert(v238, ("%d%% extraction rate"):format(v237))
						end
						local v240 = #v238 == 0 and { "No requirements" } or v238
						local v241 = {}
						for v242, v243 in v240 do
							v241[v242] = v_u_9.chipW(v243)
						end
						local v244 = v_u_200.desc
						local v245 = (type(v244) ~= "string" or v_u_200.desc == "") and "No description." or v_u_200.desc
						local v246 = ("%d / %d members"):format(v225, v227)
						local v247 = v_u_8.kind == "phone" and 3 or v_u_9.PREVIEW_MAX
						local v248 = v_u_94(v_u_200, v247)
						local v249 = {}
						local v250 = v_u_17
						if type(v250) == "table" then
							local v251 = v_u_17.rows
							if type(v251) == "table" then
								for _, v252 in v_u_17.rows do
									if type(v252) ~= "table" or #v249 >= v247 then
										continue
									end
									table.insert(v249, v252)
								end
							end
						end
						local v253 = p_u_1.shopOn == true and "Your clan sign hangs on the walls of your hideout. Banner styles from the shop change its look." or "Your clan sign hangs on the walls of your hideout."
						local v254 = v_u_7.hintOverviewFor(v220.countsAt, v_u_6.now())
						local v255 = v_u_9.overview
						local v256 = v_u_24
						local v257 = v_u_8.kind
						local v258 = {
							["chips"] = { v221, v223, v246 },
							["critWidths"] = v241,
							["desc"] = v245,
							["standing"] = v217
						}
						local v259 = v_u_200.res
						v258.result = type(v259) == "table"
						v258.tops = #v248
						v258.boardRows = #v249
						local v260
						if v_u_20 == nil then
							v260 = false
						else
							v260 = v_u_20.next ~= nil
						end
						v258.expand = v260
						v258.touch = v_u_8.touch
						v258.hint = v253
						v258.hint2 = v254
						local v261 = v255(v256, v257, v258)
						local v262 = v_u_6.frame
						local v263 = v_u_23
						local v264 = UDim2.new(1, -8, 0, v261.height)
						v202 = v202 + 1
						local v265 = v262(v263, "Sheet", v264, nil, v202)
						local v266 = v_u_39(v_u_200)
						local v267 = v261.headerParts
						local v268 = v_u_6.card(v265, "Header", v261.header, {
							["fill"] = nil,
							["transparency"] = 0.1,
							["fill"] = v_u_4.raised
						})
						local v269 = v_u_6.card(v268, "TagBadge", v267.badge, {
							["fill"] = nil,
							["transparency"] = 0.1,
							["stroke"] = nil,
							["strokeTransparency"] = 0.1,
							["fill"] = v_u_4.bg,
							["stroke"] = v266
						})
						local v270 = v_u_200.tag or "????"
						local v271 = tostring(v270)
						v_u_3.label({
							["parent"] = nil,
							["name"] = "Tag",
							["text"] = nil,
							["style"] = nil,
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["track"] = false,
							["parent"] = v269,
							["text"] = v271,
							["style"] = v_u_8.kind == "phone" and "h3" or "h2",
							["color"] = v266,
							["size"] = UDim2.fromScale(1, 1)
						})
						local v272 = v_u_6.text
						local v273 = v_u_200.name or ""
						v272(v268, "Name", tostring(v273), v267.name, {
							["style"] = v_u_8.kind == "phone" and "h3" or "h2"
						})
						v_u_6.pill(v268, "ModeChip", v221, v_u_10.rgbColor(v222), v267.chip1)
						v_u_6.pill(v268, "RankChip", v223, v_u_10.rankColor(v_u_200.rank), v267.chip2, {
							["fill"] = v_u_4.bg
						})
						v_u_6.text(v268, "Count", v246, v267.chip3, {
							["style"] = "small",
							["color"] = nil,
							["color"] = v_u_4.text2
						})
						local v274 = {}
						local v275 = {
							"Members",
							("%d / %d"):format(v225, v227),
							v_u_4.text,
							v225 / math.max(1, v227)
						}
						local v276 = {}
						local v277 = v_u_3.commas
						local v278 = v220.pts
						__set_list(v276, 1, {"Clan points", v277(tonumber(v278) or 0), v_u_4.text, nil})
						local v279 = {}
						local v280 = v_u_3.commas
						local v281 = v220.mine
						__set_list(v279, 1, {"Your points", v280(tonumber(v281) or 0), v_u_4.accent, nil})
						local v282 = {}
						local v283 = v_u_7.timeText
						local v284 = v220.resetIn
						__set_list(v282, 1, {"Resets in", v283(tonumber(v284) or 0), v_u_4.text, nil})
						__set_list(v274, 1, {v275, v276, v279, v282})
						local v285 = os.clock()
						local v286 = v220.resetIn
						v_u_14 = v285 + (tonumber(v286) or 0)
						for v287, v288 in v274 do
							local v289 = v261.stats[v287]
							local v290 = v_u_6.card(v265, "StatCard" .. v287, v289.box)
							v_u_6.text(v290, "Label", v288[1], v289.parts.label, {
								["style"] = "micro",
								["color"] = nil,
								["color"] = v_u_4.text2
							})
							local v291 = v_u_6.text(v290, "Value", v288[2], v289.parts.value, {
								["style"] = "monoL",
								["color"] = nil,
								["color"] = v288[3]
							})
							if v287 == 4 then
								v_u_15 = v291
							end
							if v288[4] == nil then
								continue
							end
							local v292 = v_u_3.new("Frame", {
								["Name"] = "BarTrack",
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_4.bg,
								["Position"] = UDim2.fromOffset(v289.parts.bar.x, v289.parts.bar.y),
								["Size"] = UDim2.fromOffset(v289.parts.bar.w, v289.parts.bar.h)
							}, v290)
							local v293 = v_u_3.new
							local v294 = {
								["Name"] = "BarFill",
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_4.accent
							}
							local v295 = UDim2.new
							local v296 = v288[4]
							v294.Size = v295(math.clamp(v296, 0, 1), 0, 1, 0)
							v293("Frame", v294, v292)
						end
						if v261.expand then
							v_u_72(v265, v261.expand, v261.expandParts, v_u_20)
						end
						if v261.hint2 then
							local v297 = v_u_6.card(v265, "PointsHint", v261.hint2, {
								["fill"] = nil,
								["transparency"] = 0.5,
								["strokeTransparency"] = 0.5,
								["fill"] = v_u_4.bg
							})
							v_u_6.fitLine(v_u_6.text(v297, "Text", v254, v261.hint2Parts.text, {
								["style"] = "small",
								["color"] = nil,
								["valign"] = "center",
								["color"] = v_u_4.text2
							}), v261.hint2Parts.text.w)
						end
						if v261.hint then
							local v298 = v_u_6.card(v265, "SignHint", v261.hint, {
								["fill"] = nil,
								["transparency"] = 0.5,
								["strokeTransparency"] = 0.5,
								["fill"] = v_u_4.bg
							})
							v_u_6.text(v298, "Text", v253, v261.hintParts.text, {
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["valign"] = "center",
								["color"] = v_u_4.text2
							})
						end
						local v299 = v_u_6.card(v265, "RequirementsCard", v261.body.crit)
						local v300 = v_u_9.parts(v261.body.crit.w, v261.body.crit.h)
						v_u_6.text(v299, "Head", "REQUIREMENTS", v300.title, {
							["style"] = "micro",
							["color"] = nil,
							["color"] = v_u_4.text2
						})
						local v301 = v_u_9.chipRow(v300.body.w, v241, 26, 6)
						for v302, v303 in v240 do
							local v304 = v301[v302]
							local v305 = v_u_6.pill
							local v306 = "Req" .. v302
							local v307
							if #v240 == 1 and (v233 == 0 and v237 == 0) then
								v307 = v_u_4.text2
							else
								v307 = v_u_4.accent
							end
							v305(v299, v306, v303, v307, {
								["x"] = v300.body.x + v304.x,
								["y"] = v300.body.y + v304.y,
								["w"] = v304.w,
								["h"] = v304.h
							})
						end
						local v308 = v_u_6.card(v265, "DescCard", v261.body.desc)
						local v309 = v_u_9.parts(v261.body.desc.w, v261.body.desc.h)
						v_u_6.text(v308, "Head", "DESCRIPTION", v309.title, {
							["style"] = "micro",
							["color"] = nil,
							["color"] = v_u_4.text2
						})
						local v310 = v_u_6.text
						local v311 = "Desc"
						local v312 = v309.body
						local v313 = {
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["valign"] = "top"
						}
						local v314
						if v_u_200.desc and v_u_200.desc ~= "" then
							v314 = v_u_4.text
						else
							v314 = v_u_4.text2
						end
						v313.color = v314
						v310(v308, v311, v245, v312, v313)
						if v261.body.standing then
							local v315 = v_u_84
							local v316 = v261.body.standing
							local v317 = v_u_17
							if v317 then
								v317 = v_u_17.mine
							end
							v315(v265, v_u_200, v316, v216, v317)
						end
						if v261.body.result then
							v_u_54(v265, v_u_200, v261.body.result)
						end
						if v261.preview.tops then
							v_u_141(v265, v_u_200, v261.preview.tops, v248, v261.previewRows.tops)
						end
						if v261.preview.boardMini then
							v_u_175(v265, v_u_200, v261.preview.boardMini, v249, v261.previewRows.boardMini)
						end
						local v318 = v261.footerParts
						local v319 = v_u_6.card(v265, "Footer", v261.footer, {
							["fill"] = nil,
							["transparency"] = 0.5,
							["strokeTransparency"] = 0.5,
							["fill"] = v_u_4.bg
						})
						if v_u_200.rank == "owner" then
							v_u_6.text(v319, "OwnerNote", v_u_7.TEXT.OWNER_LEAVE, v318.note, {
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["valign"] = "center",
								["color"] = v_u_4.text2
							})
						else
							v_u_6.text(v319, "Note", "Membership. You can leave at any time; joining another clan afterwards needs a short wait.", v318.note, {
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["valign"] = "center",
								["color"] = v_u_4.text2
							})
							local v_u_320 = nil
							local _, v332 = v_u_6.btn({
								["parent"] = nil,
								["text"] = "LEAVE",
								["kind"] = "danger",
								["width"] = nil,
								["name"] = "Leave",
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = v319,
								["width"] = v318.button.w,
								["position"] = UDim2.fromOffset(v318.button.x, v318.button.y),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_200, (ref) v_u_320, (ref) p_u_1, (ref) v_u_12, (ref) v_u_16
									local v321 = v_u_6.confirm
									local v322 = {
										["title"] = "LEAVE CLAN",
										["body"] = nil,
										["yes"] = "LEAVE",
										["no"] = "CANCEL",
										["danger"] = true,
										["onYes"] = nil
									}
									local v323 = v_u_7.CONFIRM.leave
									local v324 = v_u_200.tag
									v322.body = v323((tostring(v324)))
									function v322.onYes() -- name: onYes
										-- upvalues: (ref) v_u_320, (ref) v_u_7, (ref) p_u_1, (ref) v_u_12, (ref) v_u_16
										v_u_320.busy(true, v_u_7.UI.LEAVING)
										p_u_1.send("clanLeave", {}, function(p325, p326, p327, p328)
											-- upvalues: (ref) v_u_12, (ref) v_u_320, (ref) v_u_16, (ref) v_u_7
											if v_u_12 then
												local v329 = v_u_320.busy
												pcall(v329, false)
												if not p325 then
													local v330 = v_u_16.set
													local v331 = v_u_7.reasonFor
													if not p328 then
														p328 = {
															["msg"] = p326,
															["data"] = p327
														}
													end
													v330(v331(p328), "danger")
												end
											end
										end, 25)
									end
									v321(v322)
								end
							})
							v_u_320 = v332
						end
					else
						v_u_5.empty(v_u_23, v_u_7.UI.LOADING, 1)
					end
				end)
			end
		end
		local function v_u_340() -- name: loadShop
			-- upvalues: (ref) v_u_22, (ref) v_u_12, (ref) v_u_21, (copy) p_u_1, (ref) v_u_20, (copy) v_u_11
			if not v_u_22 and (v_u_12 and os.clock() - v_u_21 >= 30) then
				local v333 = p_u_1.shopOn == true
				local v_u_334 = p_u_1.lib("MenuClanShop")
				if v333 and v_u_334 ~= nil then
					local v335 = v_u_334.fetch
					if type(v335) == "function" then
						v_u_22 = true
						task.spawn(function()
							-- upvalues: (copy) v_u_334, (ref) p_u_1, (ref) v_u_22, (ref) v_u_12, (ref) v_u_20, (ref) v_u_21, (ref) v_u_11
							local v336 = v_u_334.fetch
							local v337 = p_u_1
							local v338, v339 = pcall(v336, v337, 30)
							v_u_22 = false
							if v_u_12 then
								if v338 and type(v339) == "table" then
									v_u_20 = v339
									v_u_21 = os.clock()
									v_u_11.draw()
								end
							end
						end)
						return
					end
				end
			end
		end
		function v_u_11.show() -- name: show
			-- upvalues: (ref) v_u_13, (copy) v_u_11, (ref) v_u_19, (ref) v_u_12, (ref) v_u_18, (copy) p_u_1, (ref) v_u_17, (copy) v_u_340
			v_u_13 = true
			v_u_11.draw()
			if not v_u_19 and (v_u_12 and os.clock() - v_u_18 >= 30) then
				v_u_19 = true
				task.spawn(function()
					-- upvalues: (ref) p_u_1, (ref) v_u_19, (ref) v_u_12, (ref) v_u_17, (ref) v_u_18, (ref) v_u_11
					local v341 = p_u_1.fetch("clanBoard", nil, 30)
					v_u_19 = false
					if v_u_12 then
						if type(v341) == "table" then
							local v342 = v341.rows
							if type(v342) == "table" then
								v_u_17 = v341
								v_u_18 = os.clock()
								v_u_11.draw()
							end
						end
					end
				end)
			end
			v_u_340()
		end
		function v_u_11.hide() -- name: hide
			-- upvalues: (ref) v_u_13
			v_u_13 = false
		end
		function v_u_11.refresh(p343) -- name: refresh
			-- upvalues: (copy) v_u_11
			if p343 == "state" then
				v_u_11.draw()
			end
		end
		function v_u_11.tick() -- name: tick
			-- upvalues: (ref) v_u_15, (ref) v_u_14, (copy) v_u_7
			local v344 = v_u_15
			if v344 and (v344.Parent and v_u_14 > 0) then
				local v345 = v_u_7.timeText
				local v346 = v_u_14 - os.clock()
				v344.Text = v345((math.max(0, v346)))
			end
		end
		function v_u_11.destroy() -- name: destroy
			-- upvalues: (ref) v_u_12
			v_u_12 = false
		end
		return v_u_11
	end
}